

# Generated at 2022-06-25 17:10:36.074826
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj = cached_property
    cls = None
    ret = obj.__get__(cls)
    assert ret is obj


# Generated at 2022-06-25 17:10:44.645216
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test of method `cached_property.__get__`."""

    def test_case_0():
        test_cached_property_0 = cached_property(0)
        test_cached_property_0.__get__(None, None)

        test_cached_property_1 = cached_property(0)
        test_cached_property_1.__get__(object(), object())

    def test_case_1():
        test_cached_property_0 = cached_property(0)
        test_cached_property_0.__get__(object(), object())

        test_cached_property_1 = cached_property(0)
        test_cached_property_1.__get__(object(), object())

    def test_case_2():
        test_cached_property_0

# Generated at 2022-06-25 17:10:50.479726
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'chmod'
    cached_property_0 = cached_property(str_0)
    obj = None
    cls = None
    cached_property_0.__get__(obj, cls)


# Generated at 2022-06-25 17:10:54.970097
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    assert True


# Generated at 2022-06-25 17:10:59.954813
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    @cached_property
    def int_0(int_0):
        return int_0


# Generated at 2022-06-25 17:11:03.142725
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    args_0 = None
    kwargs_0 = None
    obj_0 = cached_property_0.__get__(args_0, kwargs_0)
    assert obj_0 is not None


# Generated at 2022-06-25 17:11:08.652211
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'bash'
    cached_property_0 = cached_property(str_0)
    obj_0 = MyClass()
    try:
        obj_0.bash
    except:
        print('Expected')



# Generated at 2022-06-25 17:11:19.185946
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Local variables
    an_object: object = object()

    # Test closure
    def expected(): return 'barf'

    # Test init
    str_0 = 'bash'
    cached_property_0 = cached_property(str_0)

    # Test callables
    try:
        class Test:
            @cached_property
            def foo(self):
                raise StopIteration('bar')

        test = Test()
        test.foo

    except StopIteration:
        # Expected to raise exception
        pass

    try:
        class Test:
            @cached_property
            def foo(self):
                raise StopAsyncIteration()

        test = Test()
        test.foo

    except StopAsyncIteration:
        # Expected to raise exception
        pass


# Generated at 2022-06-25 17:11:25.615873
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'bash'
    cached_property_0 = cached_property(str_0)
    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    test_0 = obj.y


# Generated at 2022-06-25 17:11:29.560073
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    try:
        test_case_0()
    except TypeError as e:
        if 'is not a callable object' in str(e):
            pass
        else:
            raise e
    else:
        raise AssertionError("Expected TypeError, but did not get it.")

# Generated at 2022-06-25 17:11:40.905584
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'bash'
    cached_property_0 = cached_property(str_0)
    str_1 = 'bash'
    str_2 = 'bash'
    str_3 = 'bash'
    str_4 = 'bash'
    str_5 = 'bash'
    str_6 = 'bash'
    str_7 = 'bash'
    # nothing.
    cached_property_0.__get__(str_1, str_2)
    # nothing.
    cached_property_0.__get__(str_3, str_4)
    # nothing.
    cached_property_0.__get__(str_5, str_6)
    # nothing.
    cached_property_0.__get__(str_7, str_8)


# Generated at 2022-06-25 17:11:42.059174
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()



# Generated at 2022-06-25 17:11:49.006918
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = '{'
    cached_property_0 = cached_property(str_0)
    int_0 = 0
    cached_property_0.__get__(int_0, cached_property)
    int_1 = 1
    cached_property_0.__get__(int_1, cached_property)
    int_2 = 2
    cached_property_0.__get__(int_2, cached_property)
    int_3 = 3
    cached_property_0.__get__(int_3, cached_property)


# Generated at 2022-06-25 17:11:51.633397
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    global cached_property_0
    cached_property_0.__get__(arg_0, arg_1)


# Generated at 2022-06-25 17:12:01.293728
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'bash'
    cached_property_0 = cached_property(str_0)
    obj_0 = MyClass()
    y_1 = cached_property_0.__get__(obj_0, str_0)
    y_2 = cached_property_0.__get__(obj_0, str_0)
    assert y_1 == 6
    assert y_2 == 6
    assert obj_0.y == 6


# Generated at 2022-06-25 17:12:07.102783
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test whether the ``__get__`` method of the `cached_property` class
    works.
    """
    from io import StringIO
    from unittest import TestCase

    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5
            self.y = 10
            self.z = 15

        @cached_property
        def some_property(self):
            return self.y + self.z

    case = TestCase()
    tc = MyClass()
    result = MyClass.some_property
    case.assertIsInstance(result, cached_property)
    case.assertIsNot(result, MyClass.some_property)
    case.assertIs(result.func, MyClass.some_property.func)
    case.assertIs

# Generated at 2022-06-25 17:12:09.501468
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'bash'
    cached_property_0 = cached_property(str_0)
    cached_property_0.__get__(None, None)
    cached_property_0.__get__(None, None)


# Generated at 2022-06-25 17:12:12.838595
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'bash'
    cached_property_0 = cached_property(str_0)
    class_0 = 'cksum'
    assert cached_property_0.__get__(None, class_0) is cached_property_0

# Generated at 2022-06-25 17:12:14.356174
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()

if __name__ == '__main__':
    test_cached_property___get__()

# Generated at 2022-06-25 17:12:26.188796
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'dummy'
    str_1 = 'dummy'
    cached_property_0 = cached_property(str_0)
    cached_property_1 = cached_property(str_1)
    cached_property_2 = cached_property(str_0)
    cached_property_3 = cached_property(str_1)
    cached_property_4 = cached_property(str_0)
    cached_property_5 = cached_property(str_1)
    cached_property_6 = cached_property(str_0)
    cached_property_7 = cached_property(str_1)
    cached_property_8 = cached_property(str_0)
    cached_property_9 = cached_property(str_1)
    assert(0)



# Generated at 2022-06-25 17:12:32.097947
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'bash'
    cached_property_0 = cached_property(str_0)
    cached_property_0()


# Generated at 2022-06-25 17:12:37.572058
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""
    # Get the Class
    cached_property_cls = cached_property

    # Implicit instantiation of cached_property on call of classmethod
    # __get__
    cached_property_0 = cached_property_cls.__get__(str, str)


# Generated at 2022-06-25 17:12:42.682211
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cls_0_type = type
    cls_0_type_0 = cls_0_type(cls_0_type)
    cls_0 = cls_0_type_0()
    func_0 = str
    cached_property_1 = cached_property(func_0)
    cached_property_1.__get__(cls_0, cls_0)


# Generated at 2022-06-25 17:12:50.785633
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Create an instance of Class0
    str_0 = 'bash'
    cached_property_0 = cached_property(str_0)
    class0 = Class0()

    # Call method __get__ of cached_property_0
    ret_0 = cached_property_0.__get__(class0)
    assert ret_0 == None

    # Call method __get__ of cached_property_0
    str_0 = 'bash'
    cached_property_0 = cached_property(str_0)
    class0 = Class0()

    # Call method __get__ of cached_property_0
    ret_0 = cached_property_0.__get__(class0)
    assert ret_0 == None



# Generated at 2022-06-25 17:12:54.478430
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Example:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    example = Example()
    assert example.y == 6


# Test to ensure this is a new styled class

# Generated at 2022-06-25 17:13:00.984576
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    @cached_property
    def func(self):
        return self.x + 1

    class MyClass:
        def __init__(self):
            self.x = 5

    obj = MyClass()
    cached_property_0 = func(obj)



# Generated at 2022-06-25 17:13:02.689192
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'bash'
    cached_property_0 = cached_property(str_0)

# Generated at 2022-06-25 17:13:14.763872
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    line_0 = 'from flutils.decorators import cached_property'
    line_1 = ''
    line_2 = 'class MyClass:'

    line_3 = '    def __init__(self):'
    line_4 = '        self.x = 5'
    line_5 = ''
    line_6 = '    @cached_property'
    line_7 = '    def y(self):'
    line_8 = '        return self.x + 1'
    line_9 = ' '
    line_10 = 'Usage:'

    line_11 = '>>> obj = MyClass()'
    line_12 = '>>> obj.y'
    line_13 = '6'

    string_0 = 'test_cached_property___get__0'

# Generated at 2022-06-25 17:13:21.381632
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # CASE_0
    # Instantiate a cached_property object.
    str_0 = 'ls'
    # Return its __doc__.
    cached_property_0 = cached_property(str_0)
    assert cached_property_0.__get__() == 'ls'
    # CASE_1
    # Instantiate a cached_property object.
    str_1 = 'date -r'
    # Return its __doc__.
    cached_property_1 = cached_property(str_1)
    assert cached_property_1.__get__() == 'date -r'


# Generated at 2022-06-25 17:13:22.801625
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'bash'
    cached_property_0 = cached_property(str_0)


# Generated at 2022-06-25 17:13:30.612861
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()


# Generated at 2022-06-25 17:13:37.005814
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert(obj.y == 6)


if __name__ == '__main__':
    test_cached_property___get__()

# Generated at 2022-06-25 17:13:40.986679
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()


if __name__ == '__main__':
    import sys
    import pytest

    pytest.main(sys.argv)

# Generated at 2022-06-25 17:13:44.386082
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'bash'
    cached_property_0 = cached_property(str_0)
    cached_property_0.__get__([str_0], str)


# Generated at 2022-06-25 17:13:53.231286
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class Example:

        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    example_0 = Example(1)
    assert example_0.y == 2, example_0.y

    example_1 = Example(2)
    assert example_1.y == 3, example_1.y

    example_0.x = 10

    assert example_0.y == 11, example_0.y


# Generated at 2022-06-25 17:14:07.238777
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Test 0
    str_0 = 'bash'
    cached_property_0 = cached_property(str_0)
    str_1 = 'dir '
    str_2 = 'dir '
    obj_0 = 'dir '
    str_3 = 'dir '
    str_4 = str_3
    str_5 = str_3
    str_6 = str_3
    str_7 = str_3
    str_8 = str_3
    str_9 = str_3
    str_10 = str_3
    str_11 = str_3
    str_12 = str_3
    str_13 = str_3
    str_14 = str_3
    str_15 = str_3
    str_16 = str_3
    str_17 = str_3
    str_18 = str_

# Generated at 2022-06-25 17:14:08.924652
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'bash'
    cached_property_0 = cached_property(str_0)
    cached_property_0.__get__(
        str_0, )


# Generated at 2022-06-25 17:14:19.347507
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'bash'
    cached_property_0 = cached_property(str_0)
    obj = MyClass()
    # Note:
    #
    #     MyClass.cached_property_0 -> cached_property_0.__get__(None, MyClass)
    #     obj.cached_property_0 -> cached_property_0.__get__(obj, MyClass)
    #
    # The change in arguments is due to the fact that obj is an instance of
    # MyClass - therefore MyClass is passed as the second argument.
    #
    MyClass.cached_property_0
    obj.cached_property_0
    cached_property_0 = cached_property('bash')
    # the property exists in the cache, so return it; the line below
    # will not trigger __get__ again.

# Generated at 2022-06-25 17:14:24.739624
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Make a cached_property object from the string 'bash'.
    str_0 = 'bash'
    cached_property_0 = cached_property(str_0)
    obj = cached_property_0
    # Explicitly call the __get__ method of cached_property_0
    result = obj.__get__(None, None)


# Generated at 2022-06-25 17:14:34.209315
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # === BEGIN TEST CASE ===

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # === END TEST CASE ===

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__.get('y') == 6


# Generated at 2022-06-25 17:14:50.857796
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    t1 = test_case_0()


# Generated at 2022-06-25 17:14:54.037128
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'bash'
    cached_property_0 = cached_property(str_0)


# Generated at 2022-06-25 17:14:57.401967
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    with pytest.raises(Exception):
        cached_property_0 = cached_property(str_0)
        cached_property.__get__(cached_property_0, cached_property_0, None)
        pytest.fail('AssertionError: Not implemented')


# Generated at 2022-06-25 17:14:59.067061
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    #TODO: Test the method
    pass


# Generated at 2022-06-25 17:15:09.641495
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'bash'
    cached_property_0 = cached_property(str_0)
    obj_0 = type('', (), {})
    class_0 = type('', (), {})
    class_0.attr_0 = cached_property_0
    obj_1 = class_0()
    assert obj_1.attr_0 == 'bash'
    obj_1.attr_0 = 'f'
    assert obj_1.attr_0 == 'f'
    obj_2 = class_0()
    assert obj_2.attr_0 == 'bash'
    obj_2.attr_0 = 'w'
    assert obj_2.attr_0 == 'w'


# Generated at 2022-06-25 17:15:10.679065
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()


# Generated at 2022-06-25 17:15:17.140428
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    
    print('Running test for method __get__ of class cached_property')
    try:
        test_case_0()
    except Exception as err:
        print('Exception caught: ', err)
    else:
        print('No exception caught')

if __name__ == '__main__':

    test_cached_property___get__()

# Generated at 2022-06-25 17:15:20.130576
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj  = MyClass()
    val = obj.y
    assert val == 6


# Generated at 2022-06-25 17:15:23.901951
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()

if __name__ == '__main__':
    test_cached_property___get__()

# Generated at 2022-06-25 17:15:38.959221
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property(
        'bioluminescent',
        doc='superfine',
    )
    # noinspection PyUnusedLocal
    class object_0:
        # noinspection PyAttributeOutsideInit
        def __init__(self):
            self.resipiscence = True

        # noinspection PyUnusedLocal
        @cached_property_0
        def argenteous(self):
            return self.resipiscence
            # return (self.resipiscence, )
    object_0_0 = object_0()
    # noinspection PyTypeChecker
    cached_property_0_0 = cached_property_0.__get__(object_0_0)
    cached_property_0_0
    assert(cached_property_0_0 == True)

# Generated at 2022-06-25 17:16:37.808876
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'bash'
    cached_property_0 = cached_property(str_0)
    cached_property_0.__doc__ = 'bash'
    cached_property_0.func = str_0
    class_0 = TestClass1
    class_0.__dict__['TestClass1'] = 'TestClass1'

    result = cached_property_0.__get__(class_0, class_0)

    assert isinstance(result, cached_property)
    assert result.__doc__ == 'bash'
    assert result.func == str_0
    # TODO assert result is cached_property_0


# Generated at 2022-06-25 17:16:42.589794
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    x = cached_property(3)
    r = x.__get__('aa', 'bb')

    r = x.__get__(None, 'bb')



# Generated at 2022-06-25 17:16:53.162853
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'bash'
    cached_property_0 = cached_property(str_0)
    # Test for Exception raised
    with pytest.raises(Exception):
        cached_property_0.__get__(str_0, str_0)
    # Test for Exception raised
    with pytest.raises(Exception):
        cached_property_0.__get__(str_0, str_0)
    # Test for Exception raised
    with pytest.raises(Exception):
        cached_property_0.__get__(str_0, str_0)
    # Test for Exception raised
    with pytest.raises(Exception):
        cached_property_0.__get__(str_0, str_0)
    # Test for Exception raised
    with pytest.raises(Exception):
        cached_property

# Generated at 2022-06-25 17:16:58.297050
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'bash'
    cached_property_0 = cached_property(str_0)
    int_0 = 10
    float_0 = float(int_0)
    float_1 = float_0


# Generated at 2022-06-25 17:17:06.897522
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from datetime import date
    from dateutil.parser import parse
    from flutils.decorators import cached_property
    from urllib.parse import urlparse

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    cached_property_obj = obj.x
    assert 6 == cached_property_obj, 'Instance of cached_property did not create instance attribute with expected value.'



# Generated at 2022-06-25 17:17:10.887638
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Test no arguments
    # Expected output:
    #     None
    assert cached_property.__get__ == cached_property.__get__


# Generated at 2022-06-25 17:17:17.144393
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Test(object):
        def __init__(self):
            self.x = 1

        @cached_property
        def y(self):
            return self.x * 2

        @cached_property
        def z(self):
            return self.x * 3

    obj = Test()
    assert obj.y == 2
    assert obj.z == 3

    obj.x = 10

    assert obj.y == 20
    assert obj.z == 30



# Generated at 2022-06-25 17:17:18.630907
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case__0()

# Generated at 2022-06-25 17:17:23.702607
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # Call of __get__
    assert cached_property_0.__get__(cached_property_0, test_cached_property___get__) == str_0

# Generated at 2022-06-25 17:17:27.374544
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Testing for case 0:
    str_0 = 'bash'
    cached_property_0 = cached_property(str_0)
    raise NotImplementedError('Test not implemented')

# Generated at 2022-06-25 17:19:29.256885
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""
    str_0 = 'bash'
    cached_property_0 = cached_property(str_0)
    assert 'bash'



# Generated at 2022-06-25 17:19:30.114177
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    assert False


# Generated at 2022-06-25 17:19:34.508806
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class info_0:

        def __init__(self, default_0):
            self._default_0 = default_0

        @cached_property
        def default(self):
            return self._default_0

    info_1 = info_0(default_0=None)
    assert info_1.default == info_1._default_0



# Generated at 2022-06-25 17:19:39.887185
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # cache_0 = ['foo']

    class TestCase_0:
        def func(self):
            return 'bar'

        cached_prop = cached_property(func)

    test_case_0 = TestCase_0()
    val_0 = test_case_0.cached_prop
    assert val_0 == 'bar'
    val_1 = test_case_0.cached_prop
    assert val_1 == 'bar'



# Generated at 2022-06-25 17:19:40.969041
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'bash'
    cached_property_0 = cached_property(str_0)

# Generated at 2022-06-25 17:19:52.076424
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'bash'
    int_0 = 0
    bool_0 = bool(int_0)
    bool_1 = bool_0
    cached_property_0 = cached_property(str_0)
    str_1 = cached_property_0.__get__(str_0, bool_1)
    str_2 = 'bash'
    str_3 = str(str_2)
    int_1 = 0
    bool_2 = bool(int_1)
    bool_3 = bool_2
    test_case_1(str_3, bool_3)


# Generated at 2022-06-25 17:19:55.975395
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'bash'
    cached_property_0 = cached_property(str_0)
    cached_property_0.__get__(None, str_0)


# Generated at 2022-06-25 17:19:57.295094
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj0 = cached_property(None)
    assert False


# Generated at 2022-06-25 17:20:02.611285
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'bash'
    cached_property_0 = cached_property(str_0)
    obj = MyClass()
    obj.y


# Generated at 2022-06-25 17:20:04.679436
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'bash'
    cached_property_0 = cached_property(str_0)
    cached_property_0.__get__()

