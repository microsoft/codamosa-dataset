

# Generated at 2022-06-25 17:10:38.628329
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    from flutils.decorators import cached_property
    from .test_case_0 import test_case_0

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    test_case_0(obj)


# Generated at 2022-06-25 17:10:45.846560
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    int_0 = 2
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()
    test_case_23()


# Generated at 2022-06-25 17:10:51.089904
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'Hl'
    cached_property_0 = cached_property(str_0)


if __name__ == '__main__':
    test_case_0()
    test_cached_property___get__()

# Generated at 2022-06-25 17:11:02.878151
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import MagicMock, Mock, patch
    from flutils.decorators import cached_property

    obj = Mock(name="obj")
    cls = Mock(name="cls")
    cached_property_0 = cached_property(lambda obj: obj.foo())

    with patch("flutils.decorators.cached_property._wrap_in_coroutine") as coro:
        coro.side_effect = Exception("coroutine should not be called.")
        cached_property_0.__get__(obj, cls)

    with patch.object(cached_property, "func", new_callable=MagicMock) as func:
        func.return_value = "return value"
        retval = cached_property_0.__get__(obj, cls)

    assert func.call_

# Generated at 2022-06-25 17:11:08.354179
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    val_object_0 = object()
    cached_property_0 = cached_property(val_object_0)
    cached_property_0.__get__(val_object_0, cached_property_0)


# Generated at 2022-06-25 17:11:11.324931
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj_0 = object()
    cached_property_0 = cached_property('1')
    cached_property___get___0 = cached_property_0.__get__(obj_0)


# Generated at 2022-06-25 17:11:14.376800
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    try:
        str_0 = 'cT'
        cached_property_0 = cached_property(str_0)
    except Exception:
        pass


# Generated at 2022-06-25 17:11:21.131418
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = '9Xl'
    cached_property_0 = cached_property(str_0)
    str_1 = '64,8'
    float_0 = 35.3088
    float_1 = 4.16109
    class_0 = MyClass(str_1, float_0, float_1)
    cached_property_0.__get__(class_0, MyClass)
    cached_property_0.__get__(class_0, None) # Error

# Generated at 2022-06-25 17:11:29.889997
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'Bq'
    cached_property_0 = cached_property(str_0)
    str_1 = 'U'
    str_2 = '_'
    str_3 = 'b'
    str_4 = 'C'
    str_5 = 'g'
    cached_property_0.__get__(str_1, str_2)
    str_6 = 'o'
    str_7 = 'u'
    str_8 = 'r'
    str_9 = 'l'
    str_10 = 'T'
    str_11 = 'v'
    str_12 = ' '
    str_13 = 'M'
    str_14 = 'y'
    str_15 = 'W'
    str_16 = 'x'
    str_17 = 't'
   

# Generated at 2022-06-25 17:11:38.497277
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Test for __get__(obj, cls )

    str_0 = 'cT'
    cached_property_0 = cached_property(str_0)
    class_0 = object
    cached_property___get___0 = cached_property_0.__get__(cached_property_0, class_0)
    assert(cached_property___get___0 == 'cT')


# Generated at 2022-06-25 17:11:46.718038
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Verify calling function from class

    # Verify calling function from class

    # Verify using attribute from instance
    assert int_0 == 2
    # Verify using attribute from class
    assert int_0 == 2
    assert int_0 == 2


# Generated at 2022-06-25 17:11:50.038640
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()


# Generated at 2022-06-25 17:11:55.587050
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


# Generated at 2022-06-25 17:12:03.704332
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    print("testing cached_property.__get__ ...")
    int_0 = cached_property()
    assert( int_0._cached_property__get__ is None)
    int_0._cached_property__get__ = "s"
    assert( int_0._cached_property__get__ == "s")
    int_0._cached_property__get__ = 'foo'
    assert( int_0._cached_property__get__ == 'foo')


# Generated at 2022-06-25 17:12:05.877691
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    int_0 = 2
    int_1 = 2
    cached_property_instance_0 = cached_property(test_case_0)
    str_0 = cached_property_instance_0.__get__(int_0, int_1)


# Generated at 2022-06-25 17:12:10.224501
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Case 0: get function
    assert test_case_0.__closure__[0].cell_contents == int_0

# Generated at 2022-06-25 17:12:12.427096
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj_0 = cached_property(test_case_0)
    obj_0.__get__(test_case_0(), cached_property)

# Generated at 2022-06-25 17:12:16.005530
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()


# Generated at 2022-06-25 17:12:18.610436
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    int_0 = 2
    class_0 = MyClass()
    assert class_0.y == 6


# Generated at 2022-06-25 17:12:19.638716
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass


# Generated at 2022-06-25 17:12:25.222183
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    int_0 = 13
    int_2 = 3
    int_3 = 9
    cached_property_0 = cached_property(int_0)
    cached_property_0.__get__((int_2), (int_3))


# Generated at 2022-06-25 17:12:39.092147
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'cT'
    tuple_0 = (())
    assert hasattr(tuple_0, '__iter__')
    dict_0 = {tuple_0: True}
    cached_property_0 = cached_property(str_0)
    assert not hasattr(cached_property_0.func, 'items')
    assert not hasattr(cached_property_0.func, 'join')
    assert not hasattr(cached_property_0.func, 'find')
    assert hasattr(cached_property_0.func, '__getitem__')
    assert cached_property_0.func.__name__ > str_0
    # assert not hasattr(cached_property_0.func, 'keys')
    assert cached_property_0.__doc__ is None

# Generated at 2022-06-25 17:12:43.072065
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    int_0 = 1
    str_0 = 'cT'
    cached_property_0 = cached_property(str_0)
    cached_property_0.__get__(int_0)


# Generated at 2022-06-25 17:12:45.773888
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    @cached_property
    def y_x(x):
        return x + 1

    x_v = 5
    y_v = y_x(x_v)
    assert y_v == 6, f'result should be 6, but {y_v}'


# Generated at 2022-06-25 17:12:49.380259
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'cT'
    cached_property_0 = cached_property(str_0)
    cached_property_1 = cached_property_0.__get__(None, 'tv')


# Generated at 2022-06-25 17:12:53.392204
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'E7'
    cached_property_0 = cached_property(str_0)
    """Test the method cached_property.__get__."""
    pass


# Generated at 2022-06-25 17:12:57.315365
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj_0 = cached_property_0;
    assert_equal(cached_property_0.__get__
                 (obj_0, str_0), 'cT');


# Generated at 2022-06-25 17:12:58.680788
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()

# Generated at 2022-06-25 17:13:09.254058
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj_0 = cached_property(cached_property_0)
    cls_0 = test_case_0()
    return_value_0 = cached_property.__get__(obj_0, cls_0)
    return_value_1 = cached_property.__get__(obj_0, cls_0)
    return_value_2 = cached_property.__get__(obj_0, cls_0)
    return_value_3 = cached_property.__get__(obj_0, cls_0)
    return_value_4 = cached_property.__get__(obj_0, cls_0)
    assert return_value_0 is None
    assert return_value_1 is None
    assert return_value_2 is None
    assert return_value_3 is None
    assert return_

# Generated at 2022-06-25 17:13:13.772011
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class A:

        @cached_property
        def x():
            return str('abc')

    A_0 = A()
    str_0 = 'abc'
    cached_property_0 = cached_property(str_0)



# Generated at 2022-06-25 17:13:19.506717
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    if __name__ == '__main__':
        test_case_0()
    pass

# Generated at 2022-06-25 17:13:21.801365
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'iambe'
    cached_property_0 = cached_property(str_0)
    cached_property_0.__get__(None, None)


# Generated at 2022-06-25 17:13:31.182064
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import asyncio
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    import asyncio
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        @asyncio.coroutine
        def y(self):
            import asyncio
            y = yield from asyncio.sleep(0, self.x + 1)
            return y

    obj = MyClass()
    assert asyncio.iscoroutine(obj.y)
    assert asyncio.iscoroutinefunction(obj.y)
    import asyncio
    assert asyncio.iscoroutine(obj.y)

# Generated at 2022-06-25 17:13:36.735250
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cls_0 = test_case_0()
    cls_0.cached_property___get__(None, None)
    cls_0.cached_property___get__(None, None)


# Generated at 2022-06-25 17:13:46.940221
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    #
    # Test case
    #
    def test_case_0():
        str_0 = 'cT'
        cached_property_0 = cached_property(str_0)
    #
    # Test case
    #
    def test_case_1():
        str_0 = 'T2'
        cached_property_0 = cached_property(str_0)
    #
    # Test case
    #
    def test_case_2():
        str_0 = '@'
        cached_property_0 = cached_property(str_0)
    #
    # Test case
    #
    def test_case_3():
        str_0 = 'D'
        cached_property_0 = cached_property(str_0)
    #
    # Test case
    #

# Generated at 2022-06-25 17:13:49.247240
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass


# Generated at 2022-06-25 17:13:50.255457
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass


# Generated at 2022-06-25 17:13:59.047604
# Unit test for method __get__ of class cached_property

# Generated at 2022-06-25 17:14:02.607302
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # No exception thrown

    obj = cached_property.cached_property(lambda: 42)
    assert obj.__get__() == 42


# Generated at 2022-06-25 17:14:06.110584
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj = object()
    cls = object()
    cached_property_0 = cached_property(object())
    cached_property_0.__get__(obj, cls)


# Generated at 2022-06-25 17:14:15.625220
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'str_0'
    cached_property_0 = cached_property(str_0)
    class_0 = test_case_0
    obj = class_0()
    func = cached_property_0.__get__(obj, class_0)
    assert func == 'cT'


# Generated at 2022-06-25 17:14:24.774914
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'cT'
    cached_property_0 = cached_property(str_0)
    obj_0 = 'foo'
    cls_0 = object()
    str_1 = 'foo'
    cached_property_1 = cached_property(str_1)
    cached_property_1 = cached_property_0.__get__(obj_0, cls_0)
    assert (cached_property_0 == cached_property_1)
    assert (cached_property_0 is not cached_property_1)



# Generated at 2022-06-25 17:14:30.705540
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()


if __name__ == '__main__':
    test_cached_property___get__()

# Generated at 2022-06-25 17:14:42.831626
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'cT'
    cached_property_0 = cached_property(str_0)
    str_1 = 'cached_property'
    str_2 = 'K#'
    obj_0 = (cached_property_0, str_1, str_2)  # type: Tuple[cached_property, Any, Any]
    obj_1 = obj_0[0]
    str_3 = '__get__'
    str_4 = 'obj_0'
    str_5 = 'obj_1'
    str_6 = 'obj_0'
    str_7 = 'K#'
    obj_2 = (str_3, str_4, str_5, str_6, str_7)  # type: Tuple[str, str, str, str, Any]
    cached_

# Generated at 2022-06-25 17:14:45.481616
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()
    str_0 = 'cT'
    cached_property_0 = cached_property(str_0)
    class_0 = MyClass
    cached_property_0.__get__(class_0())
    assert True


if __name__ == '__main__':
    import pytest
    pytest.main()

# Generated at 2022-06-25 17:14:58.334470
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'q'
    str_1 = 'j'
    str_2 = 'W'
    str_3 = 'Ue'
    int_0 = 0
    int_1 = -600
    int_2 = 19
    float_0 = -9161.662282
    int_3 = -1745
    set_0 = {str_0, str_1, str_2}
    set_1 = {str_3, float_0, int_3}
    list_0 = [str_2, str_0, str_3]
    list_1 = [int_3, int_3, float_0, int_3, int_3, int_3, int_3, int_3, int_3, int_3,
              int_3, int_3, int_3]


# Generated at 2022-06-25 17:15:04.675665
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__['y'] == 6


# Generated at 2022-06-25 17:15:10.453748
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class test_case_1:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = test_case_1()
    cached_property_0 = test_case_1.__dict__['y'].__get__(obj, test_case_1)
    assert cached_property_0 == 6
    test_case_1.__dict__['y'].__get__(None, test_case_1)


# Generated at 2022-06-25 17:15:17.891458
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from types import MethodType
    test_case_0()
    # Input variables
    obj = cached_property_0
    cls = cached_property_0
    # Expected output variables
    expected_0 = MethodType
    expected_1 = None
    expected_2 = None
    # Test function
    test_method_type(obj, cls, expected_0, expected_1, expected_2)


# Generated at 2022-06-25 17:15:19.886349
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()


# Generated at 2022-06-25 17:15:37.760377
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 17:15:40.198610
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestClass:
        pass

    TestClass.test_cached_property___get__ = cached_property(test_cached_property___get__)
    return TestClass().test_cached_property___get__


# Generated at 2022-06-25 17:15:41.057516
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()

# Generated at 2022-06-25 17:15:51.128888
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from sys import version_info
    from types import CodeType, FunctionType
    from typing import Any
    from unittest.mock import Mock, patch
    import asyncio
    from flutils.decorators import cached_property

    # Mock functions for patch
    mock_func_1 = Mock()
    mock_func_1.__doc__ = 'Mock method __doc__'
    mock_func_1.__name__ = '__foo__'
    mock_func_2 = Mock()
    mock_func_2.__doc__ = 'Mock method __doc__'
    mock_func_2.__name__ = '__bar__'
    mock_func_3 = Mock()
    mock_func_3.__doc__ = 'Mock method __doc__'

# Generated at 2022-06-25 17:15:56.815407
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'cT'
    cached_property_0 = cached_property(str_0)
    assert cached_property_0.__get__ is not None

# Generated at 2022-06-25 17:16:03.369374
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test case 0."""
    # Tests method __get__ of class cached_property with parameter 0
    assert test_case_0() == 'Test successful'


if __name__ == '__main__':
    _result_ = [test_cached_property___get__()]
    print(_result_)

# Generated at 2022-06-25 17:16:11.602208
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'cT'
    cached_property_0 = cached_property(str_0)
    dict_0 = dict()
    dict_1 = dict()
    dict_1['cT'] = 'cT'
    cached_property_0.__get__(dict_0, dict_1)


# Generated at 2022-06-25 17:16:15.493364
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # case 0
    obj_0 = MyClass()
    cached_property___get___retval_0 = obj_0.y
    assert cached_property___get___retval_0 == 6


# Generated at 2022-06-25 17:16:16.776583
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'cT'
    cached_property_0 = cached_property(str_0)


# Generated at 2022-06-25 17:16:24.801711
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    method_0 = cached_property.__get__
    str_0 = 'cT'
    cached_property_0 = cached_property(str_0)
    str_1 = 'vx'
    method_0(cached_property_0, str_1, str_0)



# Generated at 2022-06-25 17:17:07.090392
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'cT'
    cached_property_0 = cached_property(str_0)
    cached_property_1 = cached_property(str_0)
    func_0 = lambda: cached_property_1


# Generated at 2022-06-25 17:17:12.279889
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class TestClass0:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    tc_0 = TestClass0()

    # invoke __get__ on instance of cached_property
    cp_0 = tc_0.y
    assert cp_0 == 6

    # invoke __get__ on instance of cached_property
    cp_1 = tc_0.y
    assert cp_1 == 6

    # invoke __get__ on instance of cached_property
    cp_2 = tc_0.y
    assert cp_2 == 6

# Generated at 2022-06-25 17:17:16.054327
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'cT'
    cached_property_0 = cached_property(str_0)
    assert cached_property_0.__get__(None, None) is str_0

# 

# Generated at 2022-06-25 17:17:22.166427
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'cT'
    cached_property_0 = cached_property(str_0)
    bool_0 = isinstance(cached_property_0, cached_property)
    bool_1 = bool_0
    return bool_1

# Generated at 2022-06-25 17:17:28.777309
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'cT'
    cached_property_0 = cached_property(str_0)
    cls___0 = test_cached_property___get___gen_0(str_0)
    obj___0 = test_cached_property___get___gen_1(str_0)

    test_cached_property___get___gen_2(obj___0, str_0)
    return test_cached_property___get___gen_3(obj___0, str_0)


# Generated at 2022-06-25 17:17:31.664008
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from types import DynamicClassAttribute

    str_0 = 's'
    cached_property_0 = cached_property(str_0)
    func = 'func'
    func = cached_property_0
    assert func is not None
    str_1 = 'cls'
    int_0 = cached_property_0.__get__(str_1, str_0)
    assert isinstance(int_0, DynamicClassAttribute)
    assert int_0 is not None


# Generated at 2022-06-25 17:17:34.012842
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    #
    # __get__(obj, cls)
    #
    test_case_0()

if __name__ == '__main__':
    import unittest

    unittest.main()

# Generated at 2022-06-25 17:17:37.108589
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'G7'
    cached_property_0 = cached_property(str_0)
    str_1 = 'd)p$&e'
    cached_property_0.__get__(str_1)


# Generated at 2022-06-25 17:17:47.606674
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class class_0(object):

        def __init__(self):
            self.__dict__ = {'int_0': 1}

    str_0 = 'z'
    def_0 = lambda x: x.int_0

    # Test with a method
    def_1 = lambda x: x.int_0 + 1
    class_1 = class_0()

    print('type(def_1)', type(def_1))
    print('type(class_1)', type(class_1))
    print('def_1(class_1)', def_1(class_1))

    cached_property_1 = cached_property(def_1)
    print('cached_property_1', cached_property_1)

    # Get the resulting attribute
    # Should now return the results of the evaluation of def_1

# Generated at 2022-06-25 17:17:49.385364
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass


# Generated at 2022-06-25 17:19:53.446188
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = '5k'
    cached_property_0 = cached_property(str_0)

# Unit tests for class cached_property

# Generated at 2022-06-25 17:20:06.342951
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import random
    import string
    import sys
    import unittest

    class TestCachedProperty(unittest.TestCase):

        def setUp(self):
            self.size = 1000
            self.str_0 = ''.join([random.choice(string.ascii_lowercase)
                                  for _ in range(self.size)])
            self.str_1 = ''.join([random.choice(string.ascii_lowercase)
                                  for _ in range(self.size)])
            self.str_2 = ''.join([random.choice(string.ascii_lowercase)
                                  for _ in range(self.size)])
            self.str_3 = ''.join([random.choice(string.ascii_lowercase)
                                  for _ in range(self.size)])

# Generated at 2022-06-25 17:20:13.212967
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass(object):

        def __init__(self):
            self.x = 0

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 1

    obj.x = 5
    assert obj.y == 1

    del obj.y
    assert obj.y == 6

    assert isinstance(obj.y, int)



# Generated at 2022-06-25 17:20:20.570417
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'am'
    str_1 = 'aum'
    cached_property_0 = cached_property(str_0)
    cached_property_1 = cached_property(str_1)
    cached_property_0.__doc__ = {'key_1': 'value_1'}  # type: ignore
    cached_property_1.__doc__ = 'jn'  # type: ignore
    cached_property_0.__doc__
    cached_property_0.x = 'value_2'
    cached_property_1.__doc__
    assert(cached_property_0.x == 'value_2')


# Generated at 2022-06-25 17:20:27.476912
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property
    str_0 = 'cT'
    cached_property_0 = cached_property(str_0)
    obj_0 = 'i'
    cls_0 = '_G'
    cached_property_0.__get__(obj_0, cls_0)


# Generated at 2022-06-25 17:20:28.787445
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'cT'
    obj_0 = MyClass_0(str_0)
    obj_0.y

# Generated at 2022-06-25 17:20:30.852930
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'cT'
    cached_property_0 = cached_property(str_0)

    cached_property_0.__get__()

