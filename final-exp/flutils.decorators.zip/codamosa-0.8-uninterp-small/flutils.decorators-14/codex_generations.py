

# Generated at 2022-06-25 17:10:37.402811
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Case 0: Uninitialized cached_property
    test_case_0()

# Generated at 2022-06-25 17:10:46.581565
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property
    import functools
    class TestClass:
        def __init__(self):
            self.x = 5
            self.y = cached_property(self._foo)
            self.t = functools.lru_cache(maxsize=1024)(self._foo)
        def _foo(self):
            return self.x + 1
        def bar(self):
            return self.x + 1
    obj = TestClass()
    assert obj.y.__doc__ == ''
    assert obj.y == 6
    assert obj.y == 6
    obj.x = 12
    assert obj.y == 13
    assert obj.y == 13
    obj.x = 18
    assert obj.y == 19
    assert obj.y == 19
    obj.x = -4


# Generated at 2022-06-25 17:10:54.673157
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestClass_0:
        def __init__(self):
            self.log = []
            self.x = 5
            self.y = 6

        @cached_property
        def some_property(self):
            self.log.append('some_property')
            return self.x + self.y

    tc = TestClass_0()
    assert tc.some_property == 11
    assert tc.log == ['some_property']
    tc.x = 10
    assert tc.some_property == 11

    del tc.some_property
    assert tc.some_property == 16
    assert tc.log == ['some_property', 'some_property']

# Generated at 2022-06-25 17:10:59.785318
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    _val_0 = None
    _val_1 = None
    _val_1 = cached_property(_val_0)
    _val_1 = _val_1.__get__(_val_0, _val_0)


# Generated at 2022-06-25 17:11:02.322301
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = None
    cached_property_0 = cached_property(float_0)
    cached_property_0.__get__(True)



# Generated at 2022-06-25 17:11:05.305736
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    try:
        float_0 = None
        cached_property_0 = cached_property(float_0)
    except:
        pass


# Generated at 2022-06-25 17:11:11.198097
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    print('')
    print('Testing __get__ of class cached_property')

    def test_case_0():
        float_0 = None
        cached_property_0 = cached_property(float_0)
        test_case_0.func_name = 'test_case_0'
    test_case_0()



# Generated at 2022-06-25 17:11:15.002916
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    @cached_property
    def bool_0():
        pass

    @cached_property
    def list_0():
        pass
    # TEST
    assert bool_0.func is None and list_0.func is None


# Generated at 2022-06-25 17:11:18.878581
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj_0 = cached_property(test_case_0)
    pass


# Generated at 2022-06-25 17:11:28.261824
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property(float, (float,), {})
    cached_property_0.__get__((float,), bool)
    bool_0 = None
    cached_property_1 = cached_property(bool_0)
    cached_property_1.__get__((bool,), bool)
    dict_0 = {}
    cached_property_1.__get__(dict_0, str)
    cached_property_2 = cached_property("")
    cached_property_2.__get__("", int)
    int_0 = None
    cached_property_3 = cached_property(int_0)
    cached_property_3.__get__(("<class \'list\'>",), bool)


# Generated at 2022-06-25 17:11:39.962116
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    def function(param):
        print(param)

    cached_property_0 = cached_property(function)
    cached_property_0.func = function
    cached_property_0.__doc__ = None
    cached_property_0.__name__ = 'cached_property'
    MyClass = type('MyClass',(object,),{'__init__': lambda self: None})
    myclass_inst = MyClass()
    expected = cached_property_0.func(myclass_inst)
    actual = cached_property_0.__get__(myclass_inst,MyClass)
    assert actual == expected


# Generated at 2022-06-25 17:11:48.109181
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    @cached_property
    def get_dict(self):
        return self.dict

    class Esref:

        def __init__(self):
            self.dict = {}

    esref_0 = Esref()
    cached_property_0 = Esref.__dict__.get('get_dict')
    try:
        get_dict_0 = cached_property_0.__get__(esref_0)
    except Exception as e:
        print(e)

# Generated at 2022-06-25 17:11:54.695404
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = None
    cached_property_0 = cached_property(float_0)
    obj = object
    cls = object

# Generated at 2022-06-25 17:12:01.479908
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # 1. Arrange
    float_0 = None
    cached_property_0 = cached_property(float_0)

    # 1. Act
    obj = cached_property_0.__get__(None, type(None))

    # 1. Assert
    assert obj == cached_property_0, "expected cached_property_0 to be equal"

# Generated at 2022-06-25 17:12:05.281986
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = None
    cached_property_0 = cached_property(float_0)
    float_1 = cached_property_0.__get__(None, object)
    assert float_1 == cached_property_0

    # Is a Python 3.8 feature; should not fail
    try:
        cached_property_0.__get__(None, object)
    except Exception:
        pass

# Generated at 2022-06-25 17:12:12.581954
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Simple test
    import unittest

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6, "Test failure: method __get__ of class cached_property"


# Generated at 2022-06-25 17:12:13.358045
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()

# Generated at 2022-06-25 17:12:21.393846
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property(float)
    object_0 = object()
    try:
        assert_equal(cached_property_0.__get__(object_0, cached_property_0), float.__get__(object_0, cached_property_0))
    except AssertionError as e:
        print(str(e))
    else:
        pass



# Generated at 2022-06-25 17:12:22.928327
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    double_0 = 1.0
    cached_property_0 = cached_property(double_0)


# Generated at 2022-06-25 17:12:27.009645
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class z:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    z_0 = z(2)
    assert z_0.y == 3


# Generated at 2022-06-25 17:12:32.959285
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj = cached_property(list)
    assert obj.func == list


# Generated at 2022-06-25 17:12:35.288982
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import math
    assert (math.pi == 3.141592653589793)
    assert (math.factorial(7) == 5040)


# Generated at 2022-06-25 17:12:37.421485
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # TODO: Impl. test for class cached_property
    assert True

# Generated at 2022-06-25 17:12:38.426472
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    assert 1 == 1


# Generated at 2022-06-25 17:12:42.713865
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    if (obj.y != 6):
        raise MyClassError("Not working")
    return None


# Generated at 2022-06-25 17:12:47.625988
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = None
    cached_property_0 = cached_property(float_0)
    obj = MyClass()
    # TEST START HERE
    cached_property_0.__get__(obj, obj.__class__)


test_cached_property___get__()

# Generated at 2022-06-25 17:12:58.622574
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    :return:
    """
    cls = Test_class_0()
    assert cls.cached_property_0 == 0
    cls._var_0 = 1
    assert cls.cached_property_0 == 1
    cls._var_0 = 2
    assert cls.cached_property_0 == 2
    cls._var_0 = 3
    assert cls.cached_property_0 == 3
    cls._var_0 = 4
    assert cls.cached_property_0 == 4
    cls._var_0 = 5
    assert cls.cached_property_0 == 5
    cls._var_0 = 6
    assert cls.cached_property_0 == 6
    cls._var_0 = 7
    assert cls.cached_property

# Generated at 2022-06-25 17:13:00.248598
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class_0 = test_case_0()
    assert_not_equal(None, class_0)


# Generated at 2022-06-25 17:13:08.453659
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj = MyClass()
    cached_property_0 = cached_property(obj)
    cached_property_1 = cached_property(obj)
    assert (cached_property_0.__get__(obj, None) == 6)
    assert (cached_property_1.__get__(obj, None) == 6)
    assert (cached_property_0.__get__(MyClass(), None) ==
            cached_property_0)
    assert (cached_property_1.__get__(MyClass(), None) ==
            cached_property_0)


# Generated at 2022-06-25 17:13:14.801748
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = None
    cached_property_0 = cached_property(float_0)
    int_0 = None
    cached_property_0.__get__(int_0, float_0)

# Generated at 2022-06-25 17:13:33.985080
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import asyncio
    from flutils.decorators import cached_property

    class ClassA:

        def __init__(self):
            pass

        def get_a(self):
            return self.a

        @cached_property
        def a(self):
            return self.get_a()

    class ClassB:

        def __init__(self):
            self.a = 1

        def get_a(self):
            return self.a

        @cached_property
        def a(self):
            return self.get_a()

    class ClassC:

        def __init__(self):
            pass

        async def get_a(self):
            await asyncio.sleep(0.5)
            return self.a

        @cached_property
        async def a(self):
            return await self

# Generated at 2022-06-25 17:13:36.927581
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    @cached_property
    def float_0():
        return 5.0

    test_case_0()
    test_case_0()
    assert 5.0 == float_0

# Test case for method __init__ of class cached_property

# Generated at 2022-06-25 17:13:45.071578
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class ClassTest:

        def __init__(self, string_0):
            self.string_0 = string_0
        # noinspection PyMethodMayBeStatic
        def float_0(self):
            float_0 = float()
            float_0 = float()
            return float_0

    class_test_0 = ClassTest('a string')

    # Test for Exception raised, exception raised
    assert_raises(Exception, cached_property_0.__get__(class_test_0))



# Generated at 2022-06-25 17:13:50.521415
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    val = obj.y
    assert val == 6



# Generated at 2022-06-25 17:13:59.192950
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = None
    cached_property_0 = cached_property(float_0)
    float_1 = None
    cached_property_0 = cached_property(float_1)
    str_0 = None
    cached_property_0 = cached_property(str_0)
    float_2 = None
    cached_property_0 = cached_property(float_2)
    str_1 = None
    cached_property_0 = cached_property(str_1)
    float_3 = None
    cached_property_0 = cached_property(float_3)
    int_0 = None
    cached_property_0 = cached_property(int_0)
    int_1 = None
    cached_property_0 = cached_property(int_1)
    str_2 = None
    cached_property_0 = cached

# Generated at 2022-06-25 17:14:05.622197
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Declare
    float_0 = 0.0
    NoneType_1 = type(None)
    cached_property_0 = cached_property(float_0)

    # Invoke
    var_1 = float_0.__get__(NoneType_1)

    # Assert
    assert cached_property_0 == var_1

# Generated at 2022-06-25 17:14:09.086638
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = None
    cached_property_0 = cached_property(float_0)
    obj_0 = obj_0()
    cls_0 = None
    assert cached_property_0.__get__(obj_0, cls_0) == cached_property_0

# Generated at 2022-06-25 17:14:19.028288
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    try:
        # Test for this issue from Brian Jones:
        # https://bit.ly/2NUxF6N
        float_1 = float("nan")
        cached_property_1 = cached_property(float_1)
        test_case_1 = TestCase_for_CA3a3d7b98f911ea9fdf8c839030b9c5()
        test_case_1.tearDown()
        test_case_1.setUp()
        test_case_1.test_case_1()
        cached_property_1.__get__(test_case_1, cached_property)
    except:
        assert False  # failure
    else:
        assert True


# Generated at 2022-06-25 17:14:23.526181
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property
    """
    # Test for method __get__ (slot) of class cached_property
    cached_property_0 = cached_property(float_0)



# Generated at 2022-06-25 17:14:26.886370
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = None
    cached_property_0 = None
    cached_property_1 = cached_property(float_0)
    cached_property_0 = cached_property_1.__get__(cached_property_0, cached_property_1)

# Generated at 2022-06-25 17:14:49.947287
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = cached_property(2.0)
    assert float_0 == 2.0

# Generated at 2022-06-25 17:14:55.919283
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # Test to see if __get__ exists and is callable
    try:
        test_case_0()
    except:
        assert False, "Method __get__ does not exist or not callable."
        return

    # Test if None
    obj = MyClass()
    assert obj.y is None, "Method __get__ does not return None."
    return


# Generated at 2022-06-25 17:14:59.020487
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Expect: AssertionError
    test_case_0()

if __name__ == '__main__':
    test_cached_property___get__()

# Generated at 2022-06-25 17:15:04.195426
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    try:
        cached_property_0 = cached_property(None)
        cached_property___get__(cached_property_0, None)
    except Exception:
        assert False


# Generated at 2022-06-25 17:15:07.209826
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property(float_0)

# Generated at 2022-06-25 17:15:20.271851
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import copy
    import functools
    import six
    import sys

    class A(object):
        def __init__(self):
            pass

        @cached_property
        def foo(self):
            """The foo attribute.

            Returns:
                The foo attribute.

            """
            return 42

        @property
        def bar(self):
            """The bar attribute.

            Returns:
                The bar attribute.

            """
            return 42
    a = A()

    # __get__ of cached_property is tested.
    # Check that the docstring is copied from the original.
    # Check that the property is cached.
    # Check that the property of a different instance is not cached.
    # Check that the property can be deleted.
    # Check that the property still works when accessed via a superclass.
    # Check that

# Generated at 2022-06-25 17:15:29.346324
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Test when obj is None and cls is None
    # See if the result is cached_property_0.__doc__

    # Test when obj is None and cls is not None
    # See if the result is cached_property_0.func

    # Test when obj is not None and cls is None
    # See if the result is cached_property_0._wrap_in_coroutine(obj)

    # Test when obj is not None and cls is not None
    # See if the result is cached_property_0._wrap_in_coroutine(obj)

    pass



# Generated at 2022-06-25 17:15:34.759075
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    string_0 = "modemetric"
    string_1 = "modemetric"
    cached_property_0 = cached_property((lambda string_1: string_1))
    string_0 = cached_property_0.__get__(string_0, string_1)


# Generated at 2022-06-25 17:15:37.977452
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_1 = None
    cached_property_1 = cached_property(float_1)
    cached_property_1.__get__()



# Generated at 2022-06-25 17:15:41.846540
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Class0:
        def __init__(self):
            self.x = 5
        cached_property_0 = cached_property(property_0)
    cached_property_0 = Class0()
    cached_property_0.cached_property_0 = cached_property_0
    int_0 = 0
    int_0 = cached_property_0.cached_property_0.__get__(cached_property_0, Class0)
    assert int_0 == 0


# Generated at 2022-06-25 17:16:37.774028
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    num_0 = NumbaPrange(3)
    array_obj_0 = nb.deferred_type()
    array_obj_1 = nb.typeof(num_0)


# Generated at 2022-06-25 17:16:42.872524
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = None
    cached_property_0 = cached_property(float_0)
    obj = cached_property_0.__get__(float_0, float_0)


# Generated at 2022-06-25 17:16:50.480355
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Test : Verify that cached_property___get__()
    # works as a descriptor
    from flutils.decorators import cached_property

    class CacheCase:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = CacheCase()
    assert obj.y == 6
    assert hasattr(obj, "y")
    assert obj.y == 6



# Generated at 2022-06-25 17:16:59.653678
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = None
    cached_property_0 = cached_property(float_0)
    float_1 = None
    cached_property_0 = cached_property(float_1)
    float_2 = None
    cached_property_0 = cached_property(float_2)
    float_3 = None
    cached_property_0 = cached_property(float_3)
    float_4 = None
    cached_property_0 = cached_property(float_4)
    float_5 = None
    cached_property_0 = cached_property(float_5)
    float_6 = None
    cached_property_0 = cached_property(float_6)
    float_7 = None
    cached_property_0 = cached_property(float_7)
    float_8 = None
    cached_property_0 = cached

# Generated at 2022-06-25 17:17:00.491519
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass


# Generated at 2022-06-25 17:17:07.057729
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = None
    cached_property_0 = cached_property(float_0)
    obj = object()
    obj_1 = object()
    cls = type(obj_1)
    obj_2 = cached_property_0.__get__(obj, cls)
    assert isinstance(obj_2, cached_property)


# Generated at 2022-06-25 17:17:11.247610
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    def float_0():
        pass

    cached_property_0 = cached_property(float_0)
    # assert cached_property_0.__get__() == None


# Generated at 2022-06-25 17:17:15.656103
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = None
    cached_property_0 = cached_property(float_0)
    obj = ""
    cls = ""
    assert cached_property_0.__get__(obj, cls) == None


# Generated at 2022-06-25 17:17:20.042296
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test method __get__"""
    float_0 = None
    cached_property_0 = cached_property(float_0)
    assert isinstance(cached_property_0.__get__(cached_property_0, type), cached_property)


# Generated at 2022-06-25 17:17:26.466171
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = None
    cached_property_0 = cached_property(float_0)
    obj = None
    cls = None
    assert cached_property_0.__get__(obj, cls) == cached_property_0



# Generated at 2022-06-25 17:19:37.191358
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = None
    cached_property_0 = cached_property(float_0)
    int_0 = None
    with pytest.raises(RuntimeError):
        cached_property_0.__get__(int_0, float_0)


# Generated at 2022-06-25 17:19:40.192042
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj = None
    cls = None
    cached_property_0 = cached_property(obj)
    assert cached_property_0.__get__(obj, cls) == None

# Generated at 2022-06-25 17:19:40.825513
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    return cached_property___get__()



# Generated at 2022-06-25 17:19:45.063377
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    assert test_case_0() == None



# Generated at 2022-06-25 17:19:53.525169
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import mock
    from flutils.decorators import cached_property
    test_cached_property___get___mock_0 = mock.MagicMock()
    test_cached_property___get___mock_0.__get__ = mock.MagicMock(name='mock_instance_method_0')
    test_cached_property___get___mock_0.__get__.return_value = None
    mock_obj = cached_property(test_cached_property___get___mock_0)
    mock_obj.__get__(None, None)
    mock_obj.__get__.assert_called_with(None, None)

# Generated at 2022-06-25 17:20:01.564474
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import asyncio, inspect
    float_0 = None
    cached_property_0 = cached_property(float_0)
    # Class cached_property has no public method __get__
    assert_raises_regex(AttributeError, "cached_property",
                        cached_property_0.__get__)


# Generated at 2022-06-25 17:20:05.319429
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = None
    cached_property_0 = cached_property(float_0)
    cached_property_0.__get__()
    str_0 = None
    None
    cached_property_0.__get__('', str_0)


# Generated at 2022-06-25 17:20:09.578026
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = None
    cached_property_0 = cached_property(float_0)
    unicode_0 = None
    cached_property_0.__get__(unicode_0, unicode_0)


# Generated at 2022-06-25 17:20:11.765763
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property(float)
    _cached_property___get__(cached_property_0)


# Generated at 2022-06-25 17:20:17.657779
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # __doc__ (as of 2008-08-02) for pygame.sdlmain_osx.cached_property.__get__:

    # x.__get__(self, obj) <==> x.get(obj)
    assert cached_property_0.__get__(cached_property_0, cached_property_0) is cached_property_0
    assert cached_property_0.__get__(cached_property_0) is cached_property_0
    assert cached_property_0.__get__() is cached_property_0