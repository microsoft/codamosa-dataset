

# Generated at 2022-06-25 17:10:33.472001
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()


# Generated at 2022-06-25 17:10:37.450885
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Setup
    integer_0 = int('$i|<')

    # Call to cached_property
    cached_property_0 = cached_property(integer_0)




# Generated at 2022-06-25 17:10:47.214157
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = '>~^QJy"&gvIW'
    cached_property_0 = cached_property(str_0)
    cached_property_1 = cached_property(str_0)
    cached_property_2 = cached_property(str_0)
    cached_property_3 = cached_property(str_0)
    cached_property_4 = cached_property(str_0)
    cached_property_5 = cached_property(str_0)
    cached_property_6 = cached_property(str_0)



# Generated at 2022-06-25 17:10:54.830539
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = '>~^QJy"&gvIW'
    cached_property_0 = cached_property(str_0)
    assert isinstance(cached_property_0, object) is True
    assert isinstance(cached_property_0, cached_property) is True
    assert isinstance(cached_property_0, str) is False
    assert isinstance(cached_property_0, (list, tuple)) is False
    assert isinstance(cached_property_0, (dict, set)) is False
    assert callable(cached_property_0) is False


# Generated at 2022-06-25 17:10:56.781090
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj_0 = cached_property(str)
    obj_0.func



# Generated at 2022-06-25 17:10:59.966333
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = '{kN57Z]pzA'
    test_case_0()
    test_case_1(str_0)
    test_case_2(str_0)


# Generated at 2022-06-25 17:11:04.508262
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = '>~^QJy"&gvIW'
    cached_property_0 = cached_property(str_0)
    cached_property_0.__get__()
    cached_property_0.__get__()


# Generated at 2022-06-25 17:11:11.036824
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'YUg>u`7V('
    cached_property_0 = cached_property(str_0)
    int_0 = 0
    cls = int_0.__class__
    obj = 0.0
    cached_property_0.__get__(obj, cls)



# Generated at 2022-06-25 17:11:14.427436
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'CJlwrqkq'
    cached_property_0 = cached_property(str_0)
    assert len("cached_property") == len("cached_property")


# Generated at 2022-06-25 17:11:18.219095
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()



# Generated at 2022-06-25 17:11:22.474842
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    xb = cached_property.__get__(str_0,str_0)
    return xb


# Generated at 2022-06-25 17:11:28.357766
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_1 = '=n2y'
    test_case_0()


# Generated at 2022-06-25 17:11:40.277730
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Initialize property
    str_0 = 'NdDk-hNHg'

    @cached_property
    def method_0():
        value = str_0

        # Return the magic value
        return value

    method_0.assert_any_call()

    # Initialize property
    str_1 = 'E|BcCA#wz'

    @cached_property
    def method_1():
        value = str_1

        # Return the magic value
        return value

    method_1.assert_any_call()

    # Initialize property
    str_2 = '3-k^EY*!A'

    @cached_property
    def method_2():
        value = str_2

        # Return the magic value
        return value

    method_2.assert_any_call()

   

# Generated at 2022-06-25 17:11:49.706326
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import unittest
    import flutils.decorators
    def test__0(obj, cls):
        unittest.TestCase().assertEqual(flutils.decorators.cached_property.__get__(obj, cls).__name__, '<lambda>')
    cached_property_instance__0 = flutils.decorators.cached_property(lambda *args: None)
    str_0 = '{kN57Z]pzA'
    class MyClass_0:
        def __init__(self):
            self.x = 5
        @flutils.decorators.cached_property
        def y(self):
            return self.x + 1
    obj_0 = MyClass_0()
    test__0(cached_property_instance__0, str_0)
   

# Generated at 2022-06-25 17:11:55.243990
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = '{kN57Z]pzA'
    cached_property_instance = cached_property(None)
    cached_property_instance.func = str_0
    assert cached_property_instance.__get__(None, None) == str_0

# Generated at 2022-06-25 17:12:05.513303
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property(test_case_0)
    str_0 = 'd\x13]\x14J\x1aS\.\x1aI\x1b'
    int_0 = 14
    str_1 = '\x0f\x05T%\t\x1bq\x06\x1bm'
    int_1 = 11
    cached_property_0.__get__(str_1, int_1)
    str_2 = '\x02\x00\x1eD\x1c\x0e\x1e\x19\x0f'
    str_3 = '\x06\rZW\r\x15\x0e\x0c\x1de'

# Generated at 2022-06-25 17:12:09.657984
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()

    str_0 = '{kN57Z]pzA'


# Generated at 2022-06-25 17:12:18.554879
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()
    # Test case 0
    str_0 = '{kN57Z]pzA'
    str_1 = 'X$iZ'
    str_2 = '|nW{P>'
    char_0 = 'c'
    char_1 = 'q'
    char_2 = 'a'
    int_0 = 7
    int_1 = 9
    int_2 = 14
    float_0 = 5.8
    float_1 = 1.5
    float_2 = 7.8
    buffer_0 = bytearray([101, 97, 102, 127, 85, 85, 124, 114, 56, 125, 64, 116, 87, 53])

# Generated at 2022-06-25 17:12:28.153867
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # check for function/class documentation
    assert cached_property.__doc__ is not None
    assert cached_property.__init__.__doc__ is not None
    assert cached_property.__get__.__doc__ is not None
    assert cached_property._wrap_in_coroutine.__doc__ is not None

    # check for correct functionality of method __get__
    class ATestClass():
        def __init__(self):
            self.x = 5
            self.y = None

        @cached_property
        def y(self):
            return self.x + 1
    a_obj = ATestClass()
    assert a_obj.y != None
    assert a_obj.y == 6

    a_obj_from_class = ATestClass()
    assert a_obj_from_class.y != None
   

# Generated at 2022-06-25 17:12:29.134789
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()
    return True


# Generated at 2022-06-25 17:12:32.903323
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = '{kN57Z]pzA'



# Generated at 2022-06-25 17:12:34.484179
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj = MyClass()

    assert obj.y == 6


# Generated at 2022-06-25 17:12:35.426519
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    return 'do some magic!'


# Generated at 2022-06-25 17:12:37.561598
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    assert test_case_0() == '{kN57Z]pzA'

# Generated at 2022-06-25 17:12:43.924382
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = '{kN57Z]pzA'

    # Test for method __get__ of class cached_property
    class Foo:

        @cached_property
        def property(self):
            return str_0

        def __init__(self):
            pass

    foo = Foo()
    assert foo.property == '{kN57Z]pzA'
    assert foo.property == '{kN57Z]pzA'
    assert foo.property == '{kN57Z]pzA'


# Generated at 2022-06-25 17:12:46.901137
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    try:
        test_case_0()
    except Exception as e:
        raise Exception('Test failed', e)

# noinspection PyUnusedLocal

# Generated at 2022-06-25 17:12:53.799053
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property
    class str_0:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    arg_0 = str_0()
    arg_1 = str_0
    ret = cached_property___get__(arg_0, arg_1)
    assert ret == 6


# Test for method __get__ of class cached_property

# Generated at 2022-06-25 17:13:02.428174
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'kN57Z]pzA'
    for i in range(0, 19):
        if i != 18:
            if i != 15:
                str_0 = str_0
            else:
                pass
        else:
            str_0 = str_0

    assert str_0 == 'kN57Z]pzA'

test_cached_property___get__()

# Generated at 2022-06-25 17:13:07.109242
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj = cached_property(test_case_0)
    cls = None
    assert obj.__get__(obj, cls) == cached_property(test_case_0)
    assert obj.__get__(obj, cls) == cached_property(test_case_0)


# Generated at 2022-06-25 17:13:09.479245
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()

if __name__ == '__main__':
    test_cached_property___get__()

# Generated at 2022-06-25 17:13:13.940337
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj = test_case_0()
    assert obj.y == 6


# Generated at 2022-06-25 17:13:16.044240
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj_0 = cached_property(test_case_0)
    obj_0.__get__((obj_0), cached_property)

test_cached_property___get__()


# Generated at 2022-06-25 17:13:21.110781
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = ''
    obj_0 = MyClass()
    assert type(cached_property.__get__(obj_0, MyClass)) == types.MethodType
    assert MyClass.y.__get__(obj_0) == 6


# Generated at 2022-06-25 17:13:21.942159
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()

# Main function

# Generated at 2022-06-25 17:13:22.764029
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    assert True



# Generated at 2022-06-25 17:13:27.598399
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    data = {}
    data['Key'] = 'Value'
    str_0 = str(data)
    # if data['Key'] != 'Value':
    #     raise Exception
    # if str_0 != "{'Key': 'Value'}":
    #     raise Exception



# Generated at 2022-06-25 17:13:35.757007
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from pickle import dumps, loads

    class A:
        def __init__(self):
            self._x = 123

        @cached_property
        def x(self):
            return self._x

    a = A()

    return_value_1 = isinstance(A.x, cached_property)
    return_value_2 = isinstance(a.x, int)
    return_value_3 = a.x
    return_value_4 = a.x is a._x
    return_value_5 = a.x

    a.x = 456

    return_value_6 = (a._x, a.x)

    del a.x

    return_value_7 = (a._x, a.x)

    a.x = 789

    return_value_8 = a.x


# Generated at 2022-06-25 17:13:41.295674
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    '''
    Method __get__
    '''
    print("Test #1: cached_property.__get__ | ", end="")
    obj_0 = cached_property(test_case_0)
    obj_0.__get__(None, str_0)
    print("passed")


# Generated at 2022-06-25 17:13:49.561170
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    val = 16
    str_0 = 'A{e777l'
    str_0 = 'j_$%c=zEf$!Zk8z'

# Generated at 2022-06-25 17:13:58.692217
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # Debug starting of test
    print('Starting test_cached_property___get__')

    # Initialize test variables
    func_0 = test_case_0

    # Setup
    decorated_func_0 = cached_property(func_0)

    # Expected results
    expected_result_0 = None
    expected_result_1 = None
    expected_result_2 = None
    expected_result_3 = None
    expected_result_4 = None

    # Actual results
    actual_result_0 = decorated_func_0.__doc__
    actual_result_1 = decorated_func_0.func
    actual_result_2 = decorated_func_0.__name__
    actual_result_3 = decorated_func_0.__qualname__
    actual_result_4 = decorated_func_0.__module__

# Generated at 2022-06-25 17:14:09.433939
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # test_case_0
    cached_property_0 = cached_property
    str_0 = '6>L!6&^z;LG'
    cached_property_0 = cached_property_0(str_0)
    assert cached_property_0.__get__ == cached_property(str_0).__get__
    # test_case_1
    cached_property_1 = cached_property
    str_1 = 'NMb|[y1'
    cached_property_1 = cached_property_1(str_1)
    assert cached_property_1.__get__ == cached_property(str_1).__get__


# Generated at 2022-06-25 17:14:13.575095
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    try:
        cached_property_0 = cached_property(int, str)
        cached_property_0
    except:
        print('Exception caught: ')


# Generated at 2022-06-25 17:14:17.236266
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = '>~^QJy"&gvIW'
    cached_property_0 = cached_property(str_0)
    return cached_property_0.__get__()

# Generated at 2022-06-25 17:14:19.593440
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # TODO: Unit test for method __get__ of class cached_property
    return True


# Generated at 2022-06-25 17:14:24.651475
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj = ['T', 0]
    func = 'wL&p!N+'
    cached_property_0 = cached_property(func)
    # Call cached_property.__get__ and compare result to expected output
    assert cached_property_0.__get__(obj, obj) is None


# Generated at 2022-06-25 17:14:31.553449
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = '>~^QJy"&gvIW'
    cached_property_0 = cached_property(str_0)

if __name__ == '__main__':
    from flutils.decorators import cached_property
    cached_property.test_cached_property___get__()


# Source: flutils\decorators.py
# Edits:
#   2020-10-17 (NG):
#       - Updated docstrings
#   2020-01-31 (NG):
#       - Converted to flutils.decorators.py module
#   2020-01-29 (NG):
#       - Original code
#   2020-01-24 (NG):
#       - Added support for async coroutines
#   2019-02-20 (NG):
#       - Initial code
#       - Added

# Generated at 2022-06-25 17:14:33.962607
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property(str)
    # call method __get__ of class cached_property
    cached_property_0.__get__(cached_property, cached_property)


# Generated at 2022-06-25 17:14:44.649816
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Call function __get__ of cached_property
    # Return type: int
    try:
        cached_property_0 = cached_property(str)
        cached_property___get__ = cached_property_0.__get__(str, float)
        assert isinstance(cached_property___get__, float)
    except:
        pass

    try:
        cached_property_0 = cached_property(str)
        cached_property___get__ = cached_property_0.__get__(str, int)
        assert isinstance(cached_property___get__, int)
    except:
        pass


# Generated at 2022-06-25 17:14:48.621236
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = ')i*#?A/){q3b'
    cached_property_0 = cached_property(str_0)
    cached_property_0.__get__()


# Generated at 2022-06-25 17:14:58.629020
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = '}jT@H^y&laeh'
    cached_property_1 = cached_property(str_0)
    str_1 = 'rwr'
    str_2 = 'rwr'
    str_3 = 'rwr'
    str_4 = 'rwr'
    str_5 = 'rwr'
    str_6 = 'rwr'
    str_7 = 'rwr'
    str_8 = 'rwr'
    tuple_0 = (str_1, str_2, str_3, str_4, str_5, str_6, str_7, str_8)
    set_0 = {str_0, tuple_0}

# Generated at 2022-06-25 17:15:03.246802
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    return (cached_property(cached_property).__get__, cached_property)

# Generated at 2022-06-25 17:15:07.971257
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    instance_0 = cached_property('')
    str_0 = 'yU,@.&S|^{m'
    cached_property_0 = cached_property(str_0)
    class_0 = type
    assert (cached_property_0.__get__(instance_0, class_0)) == cached_property_0


# Generated at 2022-06-25 17:15:09.935684
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'cL_!(!|UlR5'
    cached_property_0 = cached_property(str_0)



# Generated at 2022-06-25 17:15:11.585761
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = '}G<V*JF)Zr'
    test_case_0()



# Generated at 2022-06-25 17:15:15.479993
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str1 = '@'
    cached_property_1 = cached_property(str1)


# Generated at 2022-06-25 17:15:21.644465
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    str_0 = '0;-`b}\.R?hf|{6U'
    cached_property_0 = cached_property(str_0)
    str_1 = ')jKw{I'
    str_2 = ' )jKw{I'
    assert (cached_property_0.__get__(str_1)) == (str_2)


# Generated at 2022-06-25 17:15:29.900096
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = '?jZzI7a'
    cached_property_0 = cached_property(str_0)
    str_1 = 'mVuJT'
    dict_0 = {'in': str_1}
    str_2 = '2]\x06'
    str_3 = '\x13'
    list_0 = [str_2, str_3]
    dict_1 = {'+': list_0}
    list_1 = [dict_0, dict_1]
    cached_property_0.__get__(list_1, bool)


# Generated at 2022-06-25 17:15:40.020037
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # Test for method __get__ of class cached_property
    # Unit test for method __get__ of class cached_property
    #
    # This method tests :obj:`flutils.decorators.cached_property.__get__`.
    #
    # An exception should be raised if the "obj" is None.
    #
    # Test Case 0
    #
    class TestCase:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    test_case_0 = TestCase()
    print('test_case_0.y', test_case_0.y)
    print(TestCase.y)

# Generated at 2022-06-25 17:15:43.236195
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = '!sk{KGA:$Pae'
    cached_property_0 = cached_property(str_0)
    str_1 = 'A|,f7V{?E0#>'
    cached_property_0.__get__(str_0, str_1)


# Generated at 2022-06-25 17:15:52.468845
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = ')'
    cached_property_0 = cached_property(str_0)
    str_1 = '0m(8I[0_'
    cached_property_1 = cached_property(str_1)
    str_2 = '"1^!TlK%T'
    cached_property_2 = cached_property(str_2)
    str_3 = '<,@QPw#`j'
    cached_property_3 = cached_property(str_3)
    str_4 = 'lVnI)p#+'
    cached_property_4 = cached_property(str_4)
    str_5 = 'PQ.Gmr+~'
    cached_property_5 = cached_property(str_5)
    str_6 = 'MFq3TK^'


# Generated at 2022-06-25 17:16:09.090842
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = '>~^QJy"&gvIW'
    cached_property_0 = cached_property(str_0)
    obj = cached_property_0

    cached_property_0.__get__(obj)


# Generated at 2022-06-25 17:16:12.315353
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'Y-R\Ae5FG@F'
    cached_property_0 = cached_property(str_0)


# Generated at 2022-06-25 17:16:13.211823
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    test_case_0()


# Generated at 2022-06-25 17:16:16.865168
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    try:
        cached_property_0 = cached_property()
    except Exception as exception_0:
        with raises(IsADirectoryError):
            test_case_0()
    else:
        with raises(IsADirectoryError):
            test_case_0()

# Generated at 2022-06-25 17:16:27.086969
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Test case 0

    str_0 = ''
    str_1 = '\x1c'
    cached_property_0 = cached_property(str_1)
    cached_property_1 = cached_property(str_0)
    cached_property_1.__get__(cached_property_0, str_0)
    test_case_0()

    str_0 = 'I'
    str_1 = 'bq8W'
    cached_property_0 = cached_property(str_1)
    cached_property_1 = cached_property(str_0)
    cached_property_1.__get__(cached_property_0, str_0)


# Generated at 2022-06-25 17:16:28.704598
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()

# Generated at 2022-06-25 17:16:32.981524
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = '>~^QJy"&gvIW'
    cached_property_0 = cached_property(str_0)
    assert isinstance(cached_property_0, cached_property)

# Generated at 2022-06-25 17:16:40.366506
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = '/mV7(Jx_I'
    cached_property_0 = cached_property(str_0)
    assert not hasattr(cached_property_0, 'x')

    class MyClass():

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    my_obj = MyClass()
    assert my_obj.x == 5
    assert my_obj.y == 6
    assert my_obj.__dict__ == {'y': 6, 'x': 5}
    assert hasattr(my_obj, 'y')
    assert my_obj.y == 6
    assert my_obj.__dict__ == {'y': 6, 'x': 5}

# Generated at 2022-06-25 17:16:44.491578
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'b'
    cached_property_0 = cached_property(str_0)

    str_1 = 'b'
    cached_property_1 = cached_property(str_1)
    cached_property_1_1 = cached_property_1.__get__(cached_property_0, cached_property_1)
    assert_equal(cached_property_1_1, cached_property_1)


# Generated at 2022-06-25 17:16:53.897510
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'CWbPC0m2Z'
    cached_property_0 = cached_property(str_0)
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()
    bool_10 = bool()
    bool_11 = bool()
    bool_12 = bool()
    bool_13 = bool()
    bool_14 = bool()
    bool_15 = bool()
    bool_16 = bool()
    bool_17 = bool()
    bool_18 = bool()
    bool_19 = bool()

# Generated at 2022-06-25 17:17:26.238237
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = '>~^QJy"&gvIW'
    cached_property_0 = cached_property(str_0)
    m_0 = mock.Mock(return_value=cached_property_0)
    m_0.__get__()
    m_0.__get__(None)
    m_0.__get__(None, dict)


# Generated at 2022-06-25 17:17:33.517877
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Create an instance of class cached_property
    cached_property_0 = cached_property(func)

    # To store the results of the call of the method
    # __get__ of class cached_property
    result = None

    # Invoke the method __get__ of class cached_property
    result = cached_property_0.__get__(obj, cls)

    # Check the result type
    assert isinstance(result, cached_property)



# Generated at 2022-06-25 17:17:34.364885
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()

# Generated at 2022-06-25 17:17:37.142072
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property('')
    # __get__(self, obj: Any, cls)
    cached_property_0.__get__(None, None)


# Generated at 2022-06-25 17:17:37.961030
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()


# Generated at 2022-06-25 17:17:48.467213
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test for method __get__ of class cached_property
    """
    # Test for method __get__ of class cached_property
    str_0 = 'aR'
    cached_property_0 = cached_property(str_0)
    assert (cached_property_0.__get__('>z') == 'aR')

    # Test for method __get__ of class cached_property
    str_0 = '#4'
    cached_property_0 = cached_property(str_0)
    assert (cached_property_0.__get__('AW') == '#4')

    # Test for method __get__ of class cached_property
    str_0 = 'o/'
    cached_property_0 = cached_property(str_0)

# Generated at 2022-06-25 17:17:52.759461
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import random
    import time

    class cls_0(object):
        def __init__(self, arg_0):
            self.attr_0 = arg_0

        @cached_property
        def prop_0(self):
            time.sleep(random.randint(1, 5))
            return self.attr_0

    obj_0 = cls_0(10)
    assert obj_0.prop_0 == 10
    assert obj_0.prop_0 == 10

    obj_0 = cls_0(20)
    assert obj_0.prop_0 == 20
    assert obj_0.prop_0 == 20



# Generated at 2022-06-25 17:17:55.717393
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'Q"&gvI'
    cached_property_0 = cached_property(str_0)

    str_1 = ':>~^'
    str_2 = cached_property_0.__get__(str_1)


# Generated at 2022-06-25 17:18:01.951697
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test __get__ of cached_property
    """
    str_0 = '=6I;d6[kU%nK'
    cached_property_0 = cached_property(str_0)
    tuple_0 = (type, id)
    cached_property_0.__get__(tuple_0, None)


# Generated at 2022-06-25 17:18:05.304473
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Code snippet from source.
    str_0 = '>~^QJy"&gvIW'
    cached_property_0 = cached_property(str_0)

    str_1 = '>~^QJy"&gvIW'
    cached_property_1 = cached_property(str_1)


# Generated at 2022-06-25 17:19:10.202346
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = '#JeNbXC-WxulBsj{CQ'
    str_1 = 'W>phF0Vbutc#1,!Xp}CJ'
    str_2 = 'Bz?V,>u#-j:n7qELa"e}'
    str_3 = 'v"fz|+}\'Ib?4d1H-\';`'
    str_4 = "r+rT6H'w3OyC6TM) U\x7f"
    cached_property_0 = cached_property(cached_property)
    cached_property_1 = cached_property(cached_property)
    cached_property_2 = cached_property(cached_property)
    str_5 = 'cached_property'
    cached_property_2

# Generated at 2022-06-25 17:19:12.832673
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = '_q3tanwn)'
    value_0 = 'dû}zq3M'
    cached_property_0 = cached_property(str_0)
    cached_property_0(value_0)

# Generated at 2022-06-25 17:19:16.579702
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    val = obj.y
    res = (val == 6)
    assert res


# Generated at 2022-06-25 17:19:23.219799
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Test for method __get__ of class cached_property
    # Test for __get__ for an instance method.
    #
    # We can't try this for unbound methods, because those are
    # defined to always return themselves.
    str_0 = 'Qr'
    cached_property_0 = cached_property(str_0)
    str_1 = 'Lf'
    cached_property_0.__get__(str_1)

    # Test for __get__ for a class method.
    str_2 = 'wq'
    cached_property_1 = cached_property(str_2)
    str_3 = 'm$'
    cached_property_1.__get__(str_3)


# Generated at 2022-06-25 17:19:24.433045
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()
    # Empty String


# Generated at 2022-06-25 17:19:29.667443
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = '5jQAFS|\\'
    int_0 = 0
    cached_property_0 = cached_property(str_0)
    cached_property_0 = cached_property_0.__get__(int_0, int)



# Generated at 2022-06-25 17:19:33.978722
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_1 = '5$}e'
    int_1 = 1
    cached_property_1 = cached_property(str_1)
    try:
        cached_property_1.__get__({}, int_1)
    except:
        pass



# Generated at 2022-06-25 17:19:37.445736
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = '>~^QJy"&gvIW'
    cached_property_0 = cached_property(str_0)



# Generated at 2022-06-25 17:19:38.539205
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass


# Generated at 2022-06-25 17:19:43.475893
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = {'a': '->', None: 'a', 'c': 'a', 'b': 'a', 'e': 'a', 'd': 'a', 'g': 'a', 'f': 'a', 'i': 'a', 'h': 'a', 'k': 'a', 'j': 'a', 'm': 'a', 'l': 'a', 'o': 'a', 'n': 'a', 'q': 'a', 'p': 'a', 's': 'a', 'r': 'a', 'u': 'a', 't': 'a', 'w': 'a', 'v': 'a', 'y': 'a', 'x': 'a', 'z': 'a'}
    str_1 = 'a'
    str_2 = 'a'