

# Generated at 2022-06-21 12:34:48.196422
# Unit test for constructor of class cached_property
def test_cached_property():
    # noinspection PyPep8Naming
    class MyClass:
        # noinspection PyPep8Naming
        @cached_property
        def x(self):
            return 5

    obj = MyClass()

    assert obj.x == 5
    assert 'x' in obj.__dict__

    obj.x = 17

    assert obj.x == 17
    assert 'x' in obj.__dict__



# Generated at 2022-06-21 12:34:59.980415
# Unit test for constructor of class cached_property
def test_cached_property():
    import pytest

    # noinspection PyShadowingNames,PyUnusedLocal
    class TestClass:
        """Class to test cached_property"""

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.y == 6, "Cached property does not work"

    obj = TestClass()
    assert obj.y == 6, "Cached property does not work"

    def test_typical_use_case(self):
        class TestClass:
            """Class to test cached_property"""

            def __init__(self):
                self.x = 5

        test_class = TestClass()
        test_class.cached_property = cached_property()
        assert test_class.c

# Generated at 2022-06-21 12:35:04.221770
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class TestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.y == 6
    obj.x = 7
    assert obj.y == 6

# Generated at 2022-06-21 12:35:08.350135
# Unit test for constructor of class cached_property
def test_cached_property():
    """ Unit test for class :class:`cached_property`. """

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:35:12.020871
# Unit test for constructor of class cached_property
def test_cached_property():
    class A:
        @cached_property
        def x(self):
            return 42

    a = A()
    assert a.x == 42
    assert 'x' in a.__dict__
    del a.x
    assert 'x' not in a.__dict__


# Generated at 2022-06-21 12:35:22.784142
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import sys
    import os
    import pytest
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    # Using the built-in cached_property decorator
    class MyClass2:

        def __init__(self):
            self.x = 5

        @functools.cached_property
        def y(self):
            return self.x + 1

    obj2 = MyClass2()
    assert obj2.y == 6

# Generated at 2022-06-21 12:35:30.074314
# Unit test for constructor of class cached_property
def test_cached_property():
    class CachedPropertyExample:
        _cached_property = cached_property(lambda self: self.times_called)
        times_called = 0

        @_cached_property
        def evaluate(self):
            self.times_called += 1
            return self.times_called

    obj = CachedPropertyExample()

    assert obj.evaluate == 1
    assert obj.evaluate == 1
    # Incrementing the value should not have an effect
    obj.times_called += 1
    # The value should still be cached and equal to 1
    assert obj.evaluate == 1



# Generated at 2022-06-21 12:35:34.744665
# Unit test for constructor of class cached_property
def test_cached_property():
    """ Unit test for :class:`cached_property <flutils.decorators.cached_property>`
    """

    class Obj:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Obj()
    assert obj.y == 6



# Generated at 2022-06-21 12:35:38.007775
# Unit test for constructor of class cached_property
def test_cached_property():
    # Test __init__
    cp = cached_property(lambda x: 1)
    assert cp.__doc__ is None
    assert cp.func(None) == 1


# Generated at 2022-06-21 12:35:40.344093
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property"""
    print(cached_property.__doc__)


# Generated at 2022-06-21 12:35:54.296589
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():  # noqa: D202,D301
    class CachedPropertyTest(object):
        """Test class for cached_property"""

        def __init__(self):
            self.x = 5

        @cached_property
        def add(self):
            return self.x + 1

    obj = CachedPropertyTest()
    assert obj.add == 6
    assert obj.add == 6

    class AsyncCachedPropertyTest(object):
        """Test class for cached_property"""

        def __init__(self):
            self.x = 5

        @cached_property
        def add(self):  # noqa: D102
            async def addition():
                return self.x + 1

            return addition()

    obj = AsyncCachedPropertyTest()
    assert asyncio.run(obj.add) == 6

# Generated at 2022-06-21 12:35:56.619320
# Unit test for constructor of class cached_property
def test_cached_property():
    # Basic test for constructor for cached_property class
    test = cached_property(lambda: None)
    assert test.func() is None

# Generated at 2022-06-21 12:36:01.554672
# Unit test for constructor of class cached_property
def test_cached_property():
    def constructor():
        x = 5
        x = cached_property(x)
        return x
    x = constructor()
    return x
cached_property_object = test_cached_property()
assert isinstance(cached_property_object, cached_property)
del cached_property_object
del test_cached_property


# Generated at 2022-06-21 12:36:12.573449
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    def test_case(cls: Any) -> None:
        class CacheTest:
            def __init__(self):
                self._cache = 0

            @cls()
            def x(self):
                return self._cache

            @cls()
            def y(self):
                return self._cache + 1

        obj = CacheTest()

        assert obj.x == 0
        assert obj.y == 1

        obj._cache = 1

        assert obj.x == 1
        assert obj.y == 2

        obj._cache = 2

        assert obj.x == 2
        assert obj.y == 3

    test_case(cached_property)
    test_case(functools.cached_property)



# Generated at 2022-06-21 12:36:13.801523
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """No unit test is available."""



# Generated at 2022-06-21 12:36:21.180496
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6
    assert obj.__dict__['y'] == 6

    obj.x = 8

    assert obj.y == 6
    assert obj.__dict__['y'] == 6



# Generated at 2022-06-21 12:36:29.920710
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from . import async_property
    from . import cached_property
    from . import get_class_that_defined_method
    from . import get_default_class_name
    from . import use_asyncio
    from itertools import cycle
    from types import FunctionType

    def coro_func(obj, *args, **kwargs):
        return obj.x

    def sync_func(obj, *args, **kwargs):
        return obj.x + 1

    class MyClass:

        @async_property
        async def x(self):
            return 1

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    # Make sure all functions are bound to the instance, then rebind and
    # unbind the asyncio functions to ensure asyncio.isc

# Generated at 2022-06-21 12:36:40.163336
# Unit test for constructor of class cached_property
def test_cached_property():
    import flutils

    @flutils.decorators.cached_property
    def test(self):
        return 20

    class Test:
        prop = test

        def __init__(self):
            self.x = 10

        def __hash__(self):
            return id(self)

    obj = Test()
    a = obj.prop
    b = obj.prop
    assert a == b
    obj.x = 5
    assert a == obj.prop
    del obj.prop
    obj.x = 20
    c = obj.prop
    assert c == 20
    obj.__dict__["prop"] = 5
    assert c == 20

# Generated at 2022-06-21 12:36:50.816738
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    import asyncio
    from unittest import TestCase, mock
    from flutils.decorators import cached_property

    class MyObj:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class TestCachedProperty___get__(TestCase):

        @mock.patch('asyncio.iscoroutinefunction', new=mock.MagicMock())
        def test_MyObj(self):
            myobj = MyObj()
            self.assertIsNone(myobj.y)

        @mock.patch('asyncio.iscoroutinefunction', new=mock.MagicMock(return_value=True))
        def test_MyObj_wrap_in_coroutine(self):
            myobj = MyObj

# Generated at 2022-06-21 12:36:58.384850
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    # Using in a class without an instance of that class.
    assert MyClass.y == cached_property


# Generated at 2022-06-21 12:37:11.198789
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # This function tests a method of a class used by the decorator
    # cached_property and is invoked by the decorator's own unit tests.

    # Test cached_property.__get__()
    class MyClass(object):
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass(5)
    assert obj.__dict__.get("y") is None  # Not present
    obj.y
    assert isinstance(obj.__dict__.get("y"), int)  # Present
    assert obj.y == 6  # Cached

    del obj.y
    assert "y" not in obj.__dict__  # Deleted


# Generated at 2022-06-21 12:37:20.113107
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test for constructor of cached_property."""

    class MockObj:
        """A mock object for testing cached_property."""

        @cached_property
        def foo(self):
            """A property that returns the string 'foo'."""
            return 'foo'

    obj = MockObj()
    assert obj.foo == 'foo'
    # Make sure that x is not a property
    assert isinstance(obj.__dict__['foo'], str)

    # Make sure that caching works
    obj.foo = 'bar'
    assert obj.foo == 'foo'

# Generated at 2022-06-21 12:37:24.027625
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property"""

    class A(object):

        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    a = A(5)
    assert a.y == 6

# Generated at 2022-06-21 12:37:31.322453
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest import TestCase  # noqa

    class TestCachedProperty(TestCase):
        def test_cached_property_constructor(self):
            """Test the constructor of the class cached_property."""

            def testfunc():
                pass

            cp = cached_property(testfunc)

            self.assertIsInstance(cp, cached_property)
            self.assertEqual(cp.func, testfunc)

    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-21 12:37:35.566579
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # noinspection PyUnusedLocal

    class Example:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    e = Example()

    assert e.y == 6
    assert e.__dict__['y'] == 6



# Generated at 2022-06-21 12:37:40.678761
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest.mock import Mock

    func = Mock()
    func.__doc__ = "Test docstring"
    decorate = cached_property(func)

    assert decorate.func == func
    assert decorate.__doc__ == "Test docstring"



# Generated at 2022-06-21 12:37:48.105584
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Create an object with a "y" property.
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    # The "y" property is not yet cached.
    assert "y" not in obj.__dict__

    # The "y" property is read.
    obj.y

    # The "y" property is now cached.
    assert "y" in obj.__dict__

    # The "y" property is read again.
    obj.y

    # The cached "y" property has not been overwritten.
    assert "y" in obj.__dict__

# Generated at 2022-06-21 12:37:54.932021
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest.mock import patch
    from flutils.decorators import cached_property
    from flutils.decorators import cached_property as _cached_property

    # pylint: disable=unused-variable
    @cached_property  # noqa
    def _test_cached_property():
        return "TEST"

    class TestCachedProperty:

        def __init__(self):
            pass

        @cached_property  # noqa
        def test_cached_property(self):
            return "TEST"

    # Test the module level
    with patch('flutils.decorators.cached_property.__init__') as mock_init:
        _cached_property(lambda x: x)
        mock_init.assert_called()

    # Test the class level
   

# Generated at 2022-06-21 12:38:00.647770
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit tests for flutils.decorators.cached_property.
    """

    # noinspection PyClassHasNoInit
    class TestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def prop1(self):
            return self.x + 1

        @cached_property
        def prop2(self):
            return (self.x + 1, self.x + 2)

    return TestClass()



# Generated at 2022-06-21 12:38:13.284657
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    This also tests the support for
    `asyncio <https://docs.python.org/3/library/asyncio.html>`_
    in cached_property.
    """

    # noinspection PyMethodMayBeStatic
    class Obj:
        def __init__(self):
            self.__dict__['x'] = 0

        @cached_property
        def x(self):
            return 1

        @cached_property
        async def y(self):
            return 2

        @cached_property
        async def z(self):
            return 3

    obj = Obj()
    assert obj.x == 1
    assert isinstance(obj.__dict__['x'], int)
    assert obj.x == 1

    loop = asyncio.get_event_loop()
    loop.run_until

# Generated at 2022-06-21 12:38:25.768487
# Unit test for constructor of class cached_property
def test_cached_property():
    import pytest
    from flutils.decorators import cached_property

    class C(object):

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    c = C()
    assert c.y == 6
    assert hasattr(c.y, "__self__")

    with pytest.raises(AssertionError):
        c.y = 2

    del c.y
    assert not hasattr(c, 'y')

    # Ensure that the instance method can be accessed via the class
    assert C.y(c) == 6

if __name__ == '__main__':
    import sys
    import pytest

    pytest.main([__file__] + sys.argv[1:])

# Generated at 2022-06-21 12:38:29.743442
# Unit test for constructor of class cached_property
def test_cached_property():

    class x:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = x()
    assert obj.y == 6


# Unit tests for method __init__

# Generated at 2022-06-21 12:38:33.539877
# Unit test for constructor of class cached_property
def test_cached_property():
    class Foo:
        def __init__(self):
            self._bar = None

        @cached_property
        def bar(self):
            return "foo"

    foo = Foo()
    assert foo.bar == "foo"
    assert foo._bar == "foo"



# Generated at 2022-06-21 12:38:39.442978
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from . import cached_property
    import pytest
    import inspect
    import asyncio

    class MyClass(object):
        def __init__(self):
            self.x = 1

        @cached_property
        def cached_property(self):
            self.x += 1
            return self.x

        @cached_property
        def async_cached_property(self):
            @asyncio.coroutine
            def coroutine():
                yield from asyncio.sleep(2)
                self.x += 1
                return self.x

            return coroutine()

    @pytest.mark.asyncio
    async def test_cached_property___get__():
        """
        Tests for cached_property.__get__
        """
        cls_obj = MyClass()

        # cached_property

# Generated at 2022-06-21 12:38:43.709736
# Unit test for constructor of class cached_property
def test_cached_property(): # pragma: no cover
    
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    print(obj.y)

# Generated at 2022-06-21 12:38:53.817070
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import mock

    class obj:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    o = obj()

    with mock.patch('flutils.decorators.cached_property.cached_property.func'):
        # obj is not None
        o.__dict__.pop('y', None)
        o.y

        # obj is None
        obj.y

        # asyncio.iscoroutinefunction(self.func)
        class obj_2:
            def __init__(self):
                self.x = 5

            @cached_property
            async def y(self):
                return self.x + 1

        o_2 = obj_2()
        o_2.__dict

# Generated at 2022-06-21 12:38:59.702144
# Unit test for constructor of class cached_property
def test_cached_property():
    """ """

    # noinspection PyUnusedLocal
    def _test_cached_property():
        """Test cached_property.

        """
        # noinspection PyUnusedLocal
        class MyClass:

            def __init__(self):
                self.x = 5

            @cached_property
            def y(self):
                return self.x + 1

        obj = MyClass()
        assert obj.y == 6
        return

    _test_cached_property()
    return

# Generated at 2022-06-21 12:39:12.006682
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self, text):
            self.text = text

        @cached_property
        def upper(self):
            return self.text.upper()

        @cached_property
        def lower(self):
            return self.text.lower()

        @staticmethod
        @cached_property
        def static_upper(text):
            return text.upper()

        @staticmethod
        @cached_property
        def static_lower(text):
            return text.lower()

        @classmethod
        @cached_property
        def class_upper(cls, text):
            return text.upper()

        @classmethod
        @cached_property
        def class_lower(cls, text):
            return text.lower()

    txt = 'Text'

# Generated at 2022-06-21 12:39:15.339690
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

    obj = MyClass()
    assert not hasattr(obj, 'y')
    assert MyClass.__dict__['__init__'][1].__doc__ is not None

# Generated at 2022-06-21 12:39:19.051334
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:39:25.066040
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:39:30.318376
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test the constructor of :obj:`~flutils.decorators.cached_property`."""
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:39:37.874145
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Unit tests for constructor of class cached_property.
    """
    def func1(self):
        return 'foo'

    def func2(self):
        return 'bar'

    class A:
        b = cached_property(func1)
        c = cached_property(func2)

    a = A()
    assert a.b is a.b
    assert a.c is a.c

    # test that the doc from the func is copied over to the property
    assert func1.__doc__ == a.b.__doc__
    assert func2.__doc__ == a.c.__doc__


# Generated at 2022-06-21 12:39:43.782132
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""
    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__ == {'x': 5, 'y': 6}

# Generated at 2022-06-21 12:39:54.285527
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    global is_called

    class MyClass:
        is_called = False

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            MyClass.is_called = True
            return self.x + 1

    my_obj = MyClass()
    assert not MyClass.is_called
    assert my_obj.y == 6
    assert MyClass.is_called
    assert my_obj.y == 6
    assert my_obj.__dict__ == {'x': 5, 'y': 6}

    delattr(my_obj, 'y')
    del MyClass.is_called
    MyClass.is_called = False
    assert my_obj.y == 6
    assert MyClass.is_called

# Generated at 2022-06-21 12:39:59.516892
# Unit test for constructor of class cached_property
def test_cached_property():
    cnt = 0
    class C:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            nonlocal cnt
            cnt += 1
            return self.x * 5
        @cached_property
        def z(self):
            return self.x + 5

    c = C()
    c.y
    c.y
    assert cnt == 1
    assert c.z == 10

# Generated at 2022-06-21 12:40:08.029842
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import asyncio
    from unittest.mock import MagicMock
    from unittest.mock import patch

    @cached_property
    def my_coro(self):
        return self.x

    @cached_property
    def my_other_coro(self):
        return self.my_coro + 1

    # Patch the `asyncio.ensure_future` method of class `asyncio.coroutine`
    with patch(
        "asyncio.coroutine.ensure_future",
        new_callable=MagicMock(
            return_value=asyncio.Future(loop=asyncio.get_event_loop())
        ),
    ) as ensure_future_mock:
        mock = MagicMock(__dict__=dict(x=1))
        # Call the

# Generated at 2022-06-21 12:40:11.977898
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    result = obj.y
    assert result == obj.y

# Generated at 2022-06-21 12:40:22.274166
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test `cached_property`

    **Unit test for constructor of class cached_property.**

    """

    def test():
        return 5

    test_property = cached_property(test)
    assert test_property.__doc__ == test.__doc__
    assert test_property.func == test
    assert test_property.__get__(None, None) == test_property
    assert test_property.__get__(5, None) == 5

    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    test_object = TestClass()
    assert test_object.y == 6
    test_object.x = 10
    assert test_object.y == 6

# Generated at 2022-06-21 12:40:30.347678
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property."""

    import os
    import sys
    import unittest

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    path = os.path.abspath(os.path.join('flutils', 'decorators.py'))
    with patch.dict('sys.modules', {'flutils': None}):
        if path in sys.modules:
            del sys.modules[path]

        from flutils.decorators import cached_property  # noqa: E402

    class TestCachedProperty(unittest.TestCase):
        """Unit test for constructor of class cached_property."""

        def test_cached_property__init__(self):
            """Unit test for constructor of class cached_property."""



# Generated at 2022-06-21 12:40:42.025221
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    # NOTE:  This doesn't actually run the property decorator
    assert isinstance(obj.y, cached_property)
    #   It returns a cached_property object

    assert not isinstance(obj.__dict__.get('y'), asyncio.Future)
    #   It does not set "y" in __dict__

    assert 'y' not in obj.__dict__
    #   It does not set "y" in __dict__

    # NOTE:  This runs the property decorator
    assert obj.y == 6
    #   It returns 6


# Generated at 2022-06-21 12:40:52.338678
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest
    import asyncio
    from unittest.mock import patch, MagicMock

    @cached_property
    def foo(self):
        return 1

    x = foo.__get__(1, int)
    assert x == 1

    x = foo.__get__(None, int)
    assert x is foo

    # ----------
    # Tests for async

    class Foo:
        x = 5

        @cached_property
        async def bar(self):
            return self.x + 1

    async def do_foo():
        f = Foo()
        return f.bar

    foo = do_foo()
    assert await foo == 6

    @cached_property
    def foo(self):
        return 1

    x = foo.__get__(1, int)
    assert x == 1

# Generated at 2022-06-21 12:40:54.254570
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import doctest

    doctest.testmod()

    if doctest.master is None:
        print("*** ALL TESTS PASSED ***")

# Generated at 2022-06-21 12:40:56.056328
# Unit test for constructor of class cached_property
def test_cached_property():
    obj = cached_property(lambda: 5)
    assert obj.func(None) == obj.__get__(None, None)

# Generated at 2022-06-21 12:40:58.661151
# Unit test for constructor of class cached_property
def test_cached_property():
    import doctest
    doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE, verbose=0)

# Generated at 2022-06-21 12:41:00.862885
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1



    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:41:04.374395
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self._x = 5

        @cached_property
        def y(self):
            return self._x + 1

    obj = MyClass()
    assert obj.y == 6

    # Test that the actual property the decorator returns
    # is a coroutine.
    assert asyncio.iscoroutinefunction(MyClass.y)

    # Test that the property that object "has" is a future
    assert isinstance(obj.y, asyncio.Future)

    # Test that the future has the correct value
    assert asyncio.run(obj.y) == 6

# Generated at 2022-06-21 12:41:10.145246
# Unit test for constructor of class cached_property
def test_cached_property():
    # noinspection PyMissingConstructor
    class Class:
        def __init__(self):
            self.x = 1

        @cached_property
        def adder(self):
            return self.x + 2

    obj = Class()

    assert not hasattr(obj, "adder")
    assert obj.adder == 3
    assert hasattr(obj, "adder")
    assert obj.adder == 3



# Generated at 2022-06-21 12:41:12.938055
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:41:20.415212
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property.__doc__
    assert cached_property.__init__.__doc__
    assert cached_property.__get__.__doc__
    assert cached_property.__module__ == 'flutils.decorators'
    assert cached_property.__name__ == 'cached_property'


if __name__ == '__main__':
    import pytest

    pytest.main([__file__])

# Generated at 2022-06-21 12:41:34.909202
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit tests for cached_property decorator."""

    from unittest import TestCase


    class Dummy:
        def __init__(self, value):
            self.value = value
            self.run_count = 0

        @cached_property
        def value2(self):
            self.run_count += 1
            return self.value


    class TestCachedProperty(TestCase):

        def test_cached_property(self):
            dummy = Dummy(1)

            # First call will run func
            self.assertEqual(dummy.value2, 1)
            self.assertEqual(dummy.run_count, 1)

            # Second call will not run func
            self.assertEqual(dummy.value2, 1)

# Generated at 2022-06-21 12:41:42.883736
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from collections import namedtuple
    from types import FunctionType, SimpleNamespace

    MyClass: Any = namedtuple('MyClass', ['x'])

    func = FunctionType(lambda x: x.x + 1, MyClass, 'y')

    assert cached_property.__get__(MyClass, func, MyClass) == 6

    obj = MyClass(5)
    assert cached_property.__get__(obj, func, MyClass) == 6

    assert obj.y == 6

    obj = SimpleNamespace(x=10)
    assert cached_property.__get__(obj, func, SimpleNamespace) == 11

    assert obj.y == 11

# Generated at 2022-06-21 12:41:47.990492
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test for the cached_property class.
    """

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:41:52.600242
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert getattr(obj, 'y', "Not set") == 6

# Generated at 2022-06-21 12:42:00.581940
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # A property that is only computed once per instance and then replaces
    # itself with an ordinary attribute.  Deleting the attribute resets the
    # property.

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    # Now y is a computed attribute
    assert obj.y == 6
    # And it replaces the property with a regular attribute
    assert hasattr(obj, 'y')

    # However, if you delete the attribute, the property will be re-computed
    del obj.y
    assert obj.y == 6



# Generated at 2022-06-21 12:42:06.903691
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # 1. Define class Future:
    class Future:
        @cached_property
        def y(self):
            return self.x + 1

    # 2. Define class MyClass:
    class MyClass:
        def __init__(self):
            self.x = 5

    # 3. Check value of property y:
    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:42:18.471564
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property.
    """

    import types
    from flutils.decorators import cached_property

    class Test1(object):

        @cached_property
        def x(self):
            return 5

    class Test2(object):

        @cached_property
        def x(self):
            return 5

    class Test3(object):

        @cached_property
        def x(self):
            return 5

    t1 = Test1()
    assert isinstance(t1.x, int)
    assert t1.x == 5
    assert 'x' not in t1.__dict__
    t1.x = 10
    assert t1.x == 10
    assert 'x' in t1.__dict__
    del t1.x

# Generated at 2022-06-21 12:42:27.431696
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from sys import version_info

    from unittest import TestCase
    from unittest.mock import patch

    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class Test_cached_property___get__(TestCase):

        def test_get_cached_property(self, *patches):
            obj = MyClass()
            self.assertEqual(obj.y, 6)
            self.assertNotEqual(obj.y, 7)


# Generated at 2022-06-21 12:42:38.615662
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for class cached_property."""

    # This function mimics a function originally used in the test code. It is
    # moved to the top level of this module so it can be tested.
    def _get_answer_to_life_the_universe_and_everything():
        """Return the answer to life, the universe and everything."""
        return 42

    class CacheTest(object):  # noqa: N801
        # This class mimics a class originally used in the test code. It is
        # moved to the top level of this module so it can be tested.

        def __init__(self):
            self.x = 5

        @cached_property
        def pow_x(self):
            return self.x ** 2

        @cached_property
        def ttl_pow_x(self):
            return

# Generated at 2022-06-21 12:42:42.610378
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property.

    """
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:42:52.756114
# Unit test for constructor of class cached_property
def test_cached_property():
    class A:
        @cached_property
        def my_property(self):
            return 1
    a = A()
    assert a.my_property == 1
    assert a.__dict__["my_property"] == 1
    assert a.my_property == 1


# Generated at 2022-06-21 12:42:53.641538
# Unit test for constructor of class cached_property
def test_cached_property():
    pass


# Generated at 2022-06-21 12:43:03.487909
# Unit test for constructor of class cached_property
def test_cached_property():
    import flutils

    class _TestClass:

        def __init__(self, value=1):
            self.value = value

        @flutils.decorators.cached_property
        def value_squared(self):
            return self.value ** 2

    # Test it works
    test_obj = _TestClass()
    assert test_obj.value_squared == 1

    # Test it was saved
    assert test_obj.__dict__["value_squared"] == 1

    # Test it's cached
    test_obj.value = 2
    assert test_obj.value_squared == 1

    # Test resetting works
    del test_obj.value_squared
    assert "value_squared" not in test_obj.__dict__
    assert test_obj.value_squared == 4



# Generated at 2022-06-21 12:43:07.537574
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    # Call cached property a few times
    for _ in range(5):
        obj.y
    assert obj.__dict__['y'] == 6

# Generated at 2022-06-21 12:43:17.313278
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit tests for method __get__ of class cached_property"""
    import asyncio
    from contextlib import suppress
    from unittest import TestCase

    from flutils.decorators import cached_property

    class CachedAsyncPropertyTest(TestCase):

        def test_cached_async_property(self):

            class MyClass:
                def __init__(self):
                    self.x = 5

                @cached_property
                def y(self):
                    return self.x + 1

            obj = MyClass()
            self.assertEqual(obj.y, 6)

        def test_cached_async_property_coroutine(self):

            class MyClass:
                def __init__(self):
                    self.x = 5


# Generated at 2022-06-21 12:43:19.371498
# Unit test for constructor of class cached_property
def test_cached_property():
    try:
        getattr(cached_property, '__init__')
    except AttributeError:
        raise AssertionError("Invalid __init__ attribute")


# Generated at 2022-06-21 12:43:24.045619
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import TestCase, main

    class MyTestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    my_test_class = MyTestClass()
    assert my_test_class.y == 6
    assert 'y' in my_test_class.__dict__

    class TestCachedProperty___get__(TestCase):

        def test_cached_property___get__(self):
            my_test_class = MyTestClass()
            self.assertEqual(my_test_class.y, 6)
            self.assertTrue('y' in my_test_class.__dict__)

    main()



# Generated at 2022-06-21 12:43:31.867914
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest import TestCase

    class TestCachedProperty:
        def __init__(self, num):
            self.num = num

        @cached_property
        def square(self):
            return self.num ** 2

    class TestCachedPropertyTestCase(TestCase):
        def setUp(self):
            self.test_cached_property = TestCachedProperty(2)

        def test_cached_property(self):
            self.assertEqual(self.test_cached_property.square.__class__,
                             asyncio.Future)

        def test_cached_property_async(self):
            self.test_cached_property.square.cancel()

            # execute the async property


# Generated at 2022-06-21 12:43:38.115577
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # noinspection PyMissingOrEmptyDocstring,PyMissingTypeHints
    class Foo:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Foo()
    assert obj.y == 6
    assert obj.y == 6
    assert obj.y == 6



# Generated at 2022-06-21 12:43:46.768893
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""

    import doctest
    import inspect
    import sys
    import unittest

    # noinspection PyUnresolvedReferences
    import flutils.decorators
    import flutils.decorators.tests

    sys.path[0:0] = ['.', '../..']  # type: ignore
    from flutils.decorators.tests.test_cached_property import test_cached_property___get___TestClass

    # noinspection PyUnusedLocal
    def load_tests(loader, tests, ignore):
        tests.addTests(doctest.DocTestSuite(
            flutils.decorators.tests.test_cached_property.test_cached_property___get__))
        return tests


# Generated at 2022-06-21 12:44:10.413849
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # test for valid __get__
    class C:
        def __init__(self):
            self.x = 0

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        async def z(self):
            return self.x + 1

        @cached_property
        def __get__(self):
            return self.x + 1

    c = C()
    assert c.y == 1
    assert c.x == 0

    # test for valid __get__ with async function
    loop = asyncio.get_event_loop()
    loop.run_until_complete(c.z)
    assert c.z == 1
    assert c.z.done()

    # test for valid __get__ with a callable named __get__ as a property

# Generated at 2022-06-21 12:44:11.405295
# Unit test for constructor of class cached_property
def test_cached_property():
    from .. import cached_property



# Generated at 2022-06-21 12:44:19.820344
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # type: () -> None
    """
    Verify that :py:meth:`cached_property.__get__` behaves as expected.

    Created: 2018-09-26

    *New in version 0.2.0*
    """

    class MyClass():

        def __init__(self):
            # type: () -> None
            self.x = 5

        @cached_property
        def y(self):
            # type: () -> int
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:44:29.807922
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property

    :rtype: None

    """

    def _test_method(obj, cls):
        return obj()

    class TestClass:

        @cached_property
        def test_method(self):
            return _test_method

    obj = TestClass()

    # Sanity check
    assert obj.test_method

    # Verify the attributes of the method
    for attr in dir(obj.test_method):
        if not attr.startswith('_'):
            print(f"{attr}: {getattr(obj.test_method, attr)}")
            assert getattr(obj.test_method, attr) == getattr(_test_method,
                                                             attr)

    # Verify that the method returns the correct object

# Generated at 2022-06-21 12:44:33.154715
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Example:
        def __init__(self, x: int):
            self.x = x

        @cached_property
        def val(self):
            return self.x + 1

    obj = Example(5)
    assert obj.val == 6



# Generated at 2022-06-21 12:44:38.454361
# Unit test for constructor of class cached_property
def test_cached_property():
    class MockObj:
        def __init__(self, value):
            self.x = value

        @cached_property
        def y(self):
            return self.x * 2

    obj = MockObj(11)
    assert obj.y == 22

