

# Generated at 2022-06-21 12:34:52.032823
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestClass:
        def __init__(self):
            self.var = None
        @cached_property
        def method(self):
            return self.var

    obj = TestClass()
    obj.method  # compute the cached_property
    assert obj.__dict__ == {'var': None, 'method': None}
    obj.var = 'hi'
    assert obj.method == 'hi'
    obj.var = 5
    assert obj.method == 5
    assert obj.__dict__ == {'var': 5, 'method': 5}


# Generated at 2022-06-21 12:35:02.981024
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test the cached_property decorator.

    """

    import pytest
    from random import choice

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """Get y."""
            return self.x + 1

    # Test doc string
    assert MyClass.y.__doc__ == 'Get y.'

    @asyncio.coroutine
    def get_y(_):
        return _.x + 1

    class MyAsyncClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """Get y."""
            return get_y(self)

    # Test doc string
    assert MyAsyncClass.y.__doc__ == 'Get y.'



# Generated at 2022-06-21 12:35:03.952119
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property
    return



# Generated at 2022-06-21 12:35:05.438431
# Unit test for constructor of class cached_property
def test_cached_property():
    assert callable(cached_property)


# Generated at 2022-06-21 12:35:08.673926
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    return MyClass

# Generated at 2022-06-21 12:35:15.727627
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit tests for :obj:`~flutils.decorators.cached_property`.

    See:
        :obj:`~flutils.decorators.cached_property`
        `Tests: flutils.tests.decorators_tests.test_cached_property`
        `Coverage: flutils.tests.decorators_tests.test_cached_property`

    """
    class Obj:
        def __init__(self, val):
            self.val = val

        @cached_property
        def prop(self):
            return self.val + 1

    obj = Obj(val=7)
    print(obj.prop)
    assert obj.prop == 8

if __name__ == '__main__':
    test_cached_property()

# Generated at 2022-06-21 12:35:17.480177
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property.__doc__ is not None



# Generated at 2022-06-21 12:35:25.054640
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import TestCase
    import functools

    class C(TestCase):
        def __init__(self, n):
            self.n = n

        @functools.cached_property
        def x(self):
            return self.n

        @cached_property
        def y(self):
            return self.n

    c = C(42)
    assert c.x == 42
    assert c.y == 42

# Generated at 2022-06-21 12:35:28.614185
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    p = obj.y
    assert p == 6



# Generated at 2022-06-21 12:35:34.977015
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for the method __get__ of class cached_property."""

    from unittest import TestCase

    from flutils import decorators

    class MyClass:

        def __init__(self):
            self.x = 5

        @decorators.cached_property
        def y(self):
            return self.x + 1

    class MyTestCase(TestCase):

        def test_cached_property___get__(self):
            self.assertEqual(MyClass.y, decorators.cached_property(MyClass.y))
            obj = MyClass()
            self.assertEqual(obj.y, 6)

    testcase = MyTestCase()
    testcase.test_cached_property___get__()



# Generated at 2022-06-21 12:35:48.405452
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""
    import pytest
    from unittest.mock import MagicMock, patch

    from flutils.decorators import cached_property

    # Test for a class
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Test that you can get the value
    obj = MyClass()
    assert obj.y == 6

    # Test that the property is deleted
    obj = MyClass()
    assert obj.y == 6
    del obj.y
    with pytest.raises(AttributeError):
        obj.y

    # Test that the value is being cached
    def my_func(obj):
        return 3

    obj = Magic

# Generated at 2022-06-21 12:35:59.597084
# Unit test for constructor of class cached_property
def test_cached_property():
    from collections import namedtuple

    def func(x):
        return x + 1
    func.__doc__ = "func docstring"

    cp = cached_property(func)
    assert isinstance(cp, cached_property)
    assert cp.__doc__ == "func docstring"
    assert cp.func == func

    cp = cached_property(func, name="wrong_name")
    assert isinstance(cp, cached_property)
    assert cp.__doc__ == "func docstring"
    assert cp.func == func

    nt = namedtuple("nt", ["x"])
    obj = nt(5)
    assert cp.__get__(obj, None) == 6



# Generated at 2022-06-21 12:36:05.414509
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test :meth:`cached_property.__get__`.
    """

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert hasattr(obj.__class__, 'y')
    assert obj.y == 6
    assert obj.__dict__['y'] == 6
    del obj.y
    assert 'y' not in obj.__dict__
    assert obj.y == 6
    assert obj.__dict__['y'] == 6



# Generated at 2022-06-21 12:36:15.570086
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property


    class TestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # noinspection PyUnusedLocal
    class TestClass2:

        def __init__(self):
            self.x = 15

        @cached_property
        def y(self):
            return self.x + 11


    def coroutine_func(obj):
        async def coroutine():
            return obj.x + 3
        return coroutine()


    class CoroutineTestClass:

        def __init__(self):
            self.x = 15

        @cached_property
        def y(self):
            return coroutine_func(self)


    # noins

# Generated at 2022-06-21 12:36:17.258270
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """To be implemented.

    """
    assert True == True



# Generated at 2022-06-21 12:36:23.247185
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property
    """
    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.y == 6

# Generated at 2022-06-21 12:36:28.292686
# Unit test for constructor of class cached_property
def test_cached_property():
    class Foo:
        def __init__(self):
            self.counter = 0

        @cached_property
        def cached_method(self):
            self.counter += 1
            return self.counter

    foo = Foo()
    assert foo.cached_method == 1
    assert foo.counter == 1
    assert foo.cached_method == 1
    assert foo.counter == 1


# Generated at 2022-06-21 12:36:30.652908
# Unit test for constructor of class cached_property
def test_cached_property():
    obj = cached_property(None)
    assert obj.__doc__ == None
    assert obj.func == None

# Generated at 2022-06-21 12:36:37.928124
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class Foo:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert isinstance(Foo.y, cached_property)
    assert Foo.y.__doc__ is None
    assert Foo.y.func(Foo()) == 6



# Generated at 2022-06-21 12:36:48.769503
# Unit test for constructor of class cached_property
def test_cached_property():
    # In this case, the object H should be the same as the object G
    # except that G has a cached property that should be equal to 6
    class G:
        a = 5
        b = cached_property(lambda s: s.a + 1)

    g = G()
    print(g.b)
    del g.b
    print(g.b)
    del g.b
    print(g.b)
    print("")
    # In this case, the object F should be the same as the object E
    # except that E has a cached property that should be equal to 4
    class E:
        a = 2
        b = cached_property(lambda s: s.a + 2)

    e = E()
    print(e.b)
    print(e.b)
    print("")
    # In

# Generated at 2022-06-21 12:36:59.066386
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class TestClass:
        def __init__(self):
            assert self.cached_prop.done()
            self.x = 5

        @cached_property
        def cached_prop(self):
            return asyncio.Future()

    async def main():
        test_obj = TestClass()
        await test_obj.cached_prop

    asyncio.get_event_loop().run_until_complete(main())

# Generated at 2022-06-21 12:37:05.473298
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property.

    *New in version 0.2.0*
    """

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:37:16.657030
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import posixpath
    import io
    import gzip
    import tarfile
    import tempfile
    import asyncio

    async def coro(x):
        await asyncio.sleep(.01)
        return x
    class C:
        def __init__(self):
            self.x = 1

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return coro(self.x + 1)

    c = C()

    assert c.y == 2
    assert isinstance(c.z, asyncio.Future)
    assert c.z.result() == 2
    def g(name):
        x = C()
        x.__dict__['f'] = name
        return x.f

# Generated at 2022-06-21 12:37:23.825459
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property
    """
    class test_class:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = test_class()

    print(f'obj.y = {obj.y}')
    print(f"obj.__dict__ = {obj.__dict__}")


if __name__ == '__main__':
    test_cached_property___get__()

# Generated at 2022-06-21 12:37:29.385452
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test to confirm that the __get__ method works as expected.
    """

    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:37:33.021692
# Unit test for constructor of class cached_property
def test_cached_property():
    class DummyClass:

        @cached_property
        def foo(self):
            return "foo"

    dummy = DummyClass()
    assert dummy.foo == "foo"
# End unit test for constructor of class cached_property

# Generated at 2022-06-21 12:37:40.271624
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    cls = MyClass(1)
    assert cls.y == 2
    assert "y" in cls.__dict__
    assert cls.y == 2
    assert cls.y == cls.__dict__["y"]

# Generated at 2022-06-21 12:37:45.152396
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test constructor of class :obj:`cached_property`.

    """

    @cached_property
    def x(self):
        return self.y + 1

    assert isinstance(x, cached_property)
    assert x.__doc__ == getattr(x.func, "__doc__")


# Unit tests for getter of class cached_property

# Generated at 2022-06-21 12:37:53.209724
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property.
    """

    from flutils.decorators import cached_property

    @cached_property
    def foo(self):
        return 'bar'

    # The original __get__ method raises TypeError since it's expecting an
    # object.  The cached_property __get__ method returns the actual function
    # if given an object of None.
    assert foo.__get__(None, int) == foo
    assert cached_property(foo).__get__(None, int) == foo

    # In Python 3.8 this works

    # class C(object):
    #     @cached_property
    #     def foo(self):
    #         return 'bar'

    # obj = C()
    # assert obj.foo == 'bar'


# Generated at 2022-06-21 12:37:59.798185
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor"""
    import unittest
    from unittest.mock import Mock, patch

    class Tester(cached_property):
        def __init__(self, func):
            self.func = func

        def _wrap_in_coroutine(self, obj):
            return Mock()

    test_obj = Tester(Mock())
    cls = Mock()
    assert test_obj.__get__(1, cls)



# Generated at 2022-06-21 12:38:11.311374
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.y == 6
    obj.x = 4
    assert obj.y == 6



# Generated at 2022-06-21 12:38:16.961725
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self, x=0):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass(x=5)
    assert obj.y == 6

    # Reset y
    del obj.y
    assert obj.y == 6

    # New object, new value
    obj = MyClass(x=10)
    assert obj.y == 11



# Generated at 2022-06-21 12:38:22.199553
# Unit test for constructor of class cached_property
def test_cached_property():
    # Test cached_property()
    class CachedExample:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Test
    obj = CachedExample()
    assert obj.y == 6
    assert obj.__dict__['y'] == 6

    return True

# Generated at 2022-06-21 12:38:29.919664
# Unit test for constructor of class cached_property
def test_cached_property():
    class Object:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """I am the 'y' property."""
            return self.x + 1

    obj = Object()
    assert obj.y == 6
    assert obj.y == 6

    obj.x = -3
    assert obj.y == -2
    assert obj.y == -2

    del obj.y
    assert obj.y == 3
    assert obj.y == 3

    obj.__dict__['y'] = 6
    assert obj.y == 6
    assert obj.y == 6

    obj.y = 7
    assert obj.y == 7
    assert obj.y == 7

    with pytest.raises(AttributeError) as excinfo:
        del obj.y
   

# Generated at 2022-06-21 12:38:33.702893
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:38:35.490894
# Unit test for constructor of class cached_property
def test_cached_property():
    class Class:
        def foo(self):
            pass
    obj = Class()
    assert '__doc__' in vars(obj.foo)

# Generated at 2022-06-21 12:38:40.641799
# Unit test for constructor of class cached_property
def test_cached_property():
    from pytest import raises

    class SomeClass(object):

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    s = SomeClass()

    assert s.y == 6
    assert s.x == 5
    with raises(AttributeError):
        s.y = 0

    assert s.x == 5

# Generated at 2022-06-21 12:38:44.994106
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:38:47.782224
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Tests the constructor of class cached_property

    :return: Nothing
    """

    # call the constructor
    cp = cached_property(None)
    assert cp is not None, "cached_property constructor not working"

# Generated at 2022-06-21 12:38:57.996392
# Unit test for constructor of class cached_property
def test_cached_property():
    import unittest
    import asyncio

    class CachedPropertyTestCase(unittest.TestCase):

        class Foo:

            def __init__(self):
                self.x = 5

            @cached_property
            def y(self):
                return self.x + 1

        def test_func_is_called_once_per_instance(self):
            foo1 = self.Foo()
            foo2 = self.Foo()
            self.assertEqual(foo1.y, 6)
            self.assertEqual(foo2.y, 6)
            foo1.x = 10
            self.assertEqual(foo1.y, 6)  # 6 because we already calculated it once for x=5

    unittest.main()

if __name__ == '__main__':
    test_c

# Generated at 2022-06-21 12:39:24.134052
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property
    from flutils.decorators import cached_property as python38cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1


# Generated at 2022-06-21 12:39:29.960790
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1
    p = MyClass(5)
    assert p.y == 6
    assert p.y == 6
    p.x = 7
    assert p.y == 7
    assert p.y == 7

# Generated at 2022-06-21 12:39:30.914712
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property.__doc__

# Generated at 2022-06-21 12:39:34.628051
# Unit test for constructor of class cached_property
def test_cached_property():
    class Foo:

        def __init__(self):
            self.x = 42

        @cached_property
        def y(self):
            return self.x + 1

    foo = Foo()

    assert 42 == foo.x
    assert 43 == foo.y

# Generated at 2022-06-21 12:39:39.217679
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import Mock

    class MyClass(object):
        def __init__(self):
            self.__dict__['x'] = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y

    with_value = {'y': 6}

    assert obj.__dict__ == with_value

# Generated at 2022-06-21 12:39:42.230353
# Unit test for constructor of class cached_property
def test_cached_property():
    from .dicts import AttrDict

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:39:53.175565
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    '''
    Unit test for method __get__ of class cached_property
    '''

    import flutils.decorators

    # Create a new class
    class MyClass:
        def __init__(self):
            self.x = 5

        @flutils.decorators.cached_property
        def y(self):
            return self.x + 1

    # Create an instance of MyClass
    obj = MyClass()
    # Call the property and ensure that the value is returned.
    assert obj.y == 6

    # Second call to property should return the same value without
    # calling the function.
    assert obj.y == 6

    # Change the value of the property
    obj.y = 7
    # Call the property and ensure the new value is returned.
    assert obj.y == 7

    # Delete the value of

# Generated at 2022-06-21 12:39:54.114191
# Unit test for constructor of class cached_property
def test_cached_property():

    # TODO: Add argparse tests
    pass

# Generated at 2022-06-21 12:39:59.358352
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import doctest

    # noinspection PyPep8Naming
    class _MyClass:
        """A mock class for testing.

        Example:
            >>> obj = _MyClass()
            >>> obj.y
            6
        """

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """The mock property."""
            return self.x + 1

    doctest.testmod(verbose=False)

# Generated at 2022-06-21 12:40:04.872947
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # method __get__ of class cached_property

    # docstring
    assert cached_property.__get__.__doc__ == 'Return an attribute of instance, which is typically its value.'

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:40:50.198685
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    del obj.y
    obj.x = 10
    assert obj.y == 11



# Generated at 2022-06-21 12:40:53.897699
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # noinspection PyMethodParameters
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


# Generated at 2022-06-21 12:40:56.323392
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from os import getcwd

    class tmp:
        @cached_property
        def x(self):
            return getcwd()

    t = tmp()
    assert t.x == t.x

# Generated at 2022-06-21 12:41:02.623090
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Setup test objects
    class MyClass(object):
        def __init__(self, x):
            self.x = x

        def __eq__(self, other):
            return self.x == other.x

        @cached_property
        def y(self):
            return self.x + 1

    obj_1 = MyClass(1)
    obj_2 = MyClass(2)

    # Assert the get operation
    assert obj_1.y == 2
    assert obj_2.y == 3

    # Assert the cached values
    assert obj_1.__dict__['y'] == 2
    assert obj_2.__dict__['y'] == 3

    # Redefine the y property
    obj_1.__dict__['y'] = 4

    # Assert the redefinition
    assert obj_1

# Generated at 2022-06-21 12:41:06.169128
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:41:10.016311
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property

    """
    with pytest.raises(AssertionError):
        cached_property.__get__(cached_property, None)



# Generated at 2022-06-21 12:41:12.049433
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property


if __name__ == "__main__":

    # Unit test
    test_cached_property()

# Generated at 2022-06-21 12:41:16.792483
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:41:22.034128
# Unit test for constructor of class cached_property
def test_cached_property():
    class myclass:
        x = 1
        @cached_property
        def x(self):
            return self
    assert isinstance(myclass().x, myclass)


if __name__ == '__main__':
    import pytest
    sys.exit(pytest.main([__file__]))

# Generated at 2022-06-21 12:41:32.921882
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property
    from inspect import getdoc
    from inspect import iscoroutinefunction
    from inspect import isclass

    c = cached_property(lambda x:x*x)
    assert c.__doc__ == getdoc(lambda x:x*x)
    assert not iscoroutinefunction(c.__get__)

    class MyClass(object):
        @cached_property
        def y(self):
            """Test cached_property"""
            return self.x * 2

    assert isclass(MyClass)
    assert MyClass.y.__doc__ == "Test cached_property"
    assert MyClass().y == 0


if __name__ == '__main__':
    test_cached_property()

# Generated at 2022-06-21 12:43:07.836529
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for `cached_property` class"""
    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    obj.x = 10
    assert obj.y == 6



# Generated at 2022-06-21 12:43:10.858157
# Unit test for constructor of class cached_property
def test_cached_property():
    class myClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = myClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:43:20.671120
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            pass

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        async def y_async(self):
            return await self.x_async + 1

    obj = MyClass()
    obj.x = 5

    # Test 1: y, regular function
    del obj.__dict__['y']
    assert obj.y == 6

    # Test 2: y_async, coroutine function
    del obj.__dict__['y_async']
    async def async_x():
        obj.x_async = 5
        return obj.x_async

    loop = asyncio.get_event_loop()
    loop.run_until_complete(async_x())


# Generated at 2022-06-21 12:43:27.670076
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from collections import namedtuple

    class Foo:

        @cached_property
        def y(self):
            return self.x + 1

    foo = Foo()
    foo.x = 5
    assert foo.y == 6

    # Added in version 0.3.0
    Point = namedtuple("Point", ["x", "y"])

    class Bar:

        @cached_property
        def x(self):
            return Point(1, 2)

    bar = Bar()
    assert bar.x.x == 1
    assert bar.x.y == 2

# Generated at 2022-06-21 12:43:30.861720
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:43:34.693485
# Unit test for constructor of class cached_property
def test_cached_property():
    import pytest
    from flutils.decorators import cached_property

    test_values = [
        (5, 6),
        (6, 7),
        (10, 11)
    ]

    class TestObject:
        def __init__(self, value):
            self.x = value

        @cached_property
        def y(self):
            return self.x + 1

    results = [TestObject(x).y for x, _ in test_values]

    for actual, expected in zip(results, [y for _, y in test_values]):
        assert actual == expected

# Generated at 2022-06-21 12:43:39.649887
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj = AsyncClass()
    assert isinstance(obj.y, asyncio.Future)
    assert obj.y is obj.__dict__['y']

    loop = asyncio.get_event_loop()
    loop.run_until_complete(obj.y)
    assert obj.y.result() == 6

# Generated at 2022-06-21 12:43:41.098035
# Unit test for constructor of class cached_property
def test_cached_property():
    """ Unit test for cached_property."""
    assert cached_property



# Generated at 2022-06-21 12:43:42.253737
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property

# Generated at 2022-06-21 12:43:51.919635
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x + 2

    obj = MyClass()
    assert obj.y == 6
    assert obj.z == 7
    obj.x = 3
    assert obj.y == 6
    assert obj.z == 7
    del obj.y
    assert obj.y == 4
    assert obj.z == 7
    del obj.z
    assert obj.y == 4
    assert obj.z == 5
