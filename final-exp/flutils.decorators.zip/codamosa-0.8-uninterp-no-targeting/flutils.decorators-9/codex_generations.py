

# Generated at 2022-06-21 12:34:52.575917
# Unit test for constructor of class cached_property
def test_cached_property():
    # noinspection PyUnresolvedReferences
    """
    >>> from flutils.decorators import cached_property
    >>> class MyClass:
    ...     @cached_property
    ...     def name(self):
    ...         return 'Bob'
    >>> obj = MyClass()
    >>> obj.name
    'Bob'
    >>> del obj.name
    >>> obj.__dict__
    {}
    >>> obj.name
    'Bob'
    """
    pass


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 12:35:02.391790
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property
    from types import MethodType

    # mock a object and a method as property
    class Obj(object):
        def __init__(self):
            self.x = 0

        @cached_property
        def add_x(self, value):
            self.x += value
            return self.x

    # test that the property is not a method
    obj = Obj()
    assert isinstance(obj.add_x, MethodType) is False

    # test that the property is cached
    obj.add_x(5)
    orig_dict = obj.__dict__.copy()
    obj.add_x(5)
    assert orig_dict == obj.__dict__

# Generated at 2022-06-21 12:35:03.205471
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property



# Generated at 2022-06-21 12:35:09.919755
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    import asyncio
    from types import MethodType

    class MyClass:

        def __init__(self):
            self.x = 5
            self.y = cached_property(self.calc_y)

        def calc_y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6
    assert obj.__dict__['y'], 6
    assert obj.__dict__['calc_y'] is None
    assert isinstance(obj.y, MethodType)



# Generated at 2022-06-21 12:35:12.844431
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    def func(obj):
        return 5

    obj = Mock()
    property = cached_property(func)
    assert property.__get__(obj, None) == 5
    assert obj.__dict__ == {'func': 5}

# Generated at 2022-06-21 12:35:19.020186
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test method __get__ of class cached_property.

    :return: Nothing

    """

    def test_func(self):
        """A function used for testing class cached_property."""
        return 'test_value'

    class TestClass:
        x = cached_property(test_func)

    test = TestClass()
    assert test.x == 'test_value'

# Generated at 2022-06-21 12:35:27.368662
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6
    assert obj.__dict__ == {'x': 5, 'y': 6}

    del obj.y
    assert obj.__dict__ == {'x': 5}

    obj.y
    assert obj.__dict__ == {'x': 5, 'y': 6}



# Generated at 2022-06-21 12:35:31.534012
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Foo:
        def __init__(self):
            self.x = 5
            self.y = cached_property(self.__get_y)

        def __get_y(self):
            return self.x + 1

    foo = Foo()
    assert foo.y == 6
    del foo.y
    assert foo.y == 6



# Generated at 2022-06-21 12:35:34.875447
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    >>> t = cached_property(lambda x: 'something')
    >>> t.func
    <function cached_property.<locals>.<lambda> at 0x10bdba6a8>
    """



# Generated at 2022-06-21 12:35:46.736326
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    def test_value():
        obj = MyClass()
        assert obj.y == 6

    def test_value_async():
        obj = MyClass()

        @asyncio.coroutine
        def test():
            assert (yield from obj.y) == 6

        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(test())
        loop.close()

    def test_value_async_future():
        obj = MyClass()


# Generated at 2022-06-21 12:35:51.626204
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import doctest
    doctest.testmod()


if __name__ == "__main__":
    import doctest
    print(doctest.testmod())

# Generated at 2022-06-21 12:35:56.879592
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:36:02.048898
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property.

    .. versionadded:: 0.9.0

    """

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:36:10.901571
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert isinstance(obj.__dict__['y'], int)  # cached property

    # The initialization value is cached in the class as well.
    assert obj.y is obj.y
    assert obj.__dict__['y'] is obj.y
    assert obj.__class__.y is not obj.y



# Generated at 2022-06-21 12:36:12.611595
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    raise NotImplementedError



# Generated at 2022-06-21 12:36:17.858486
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property


    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:36:19.322925
# Unit test for constructor of class cached_property
def test_cached_property():
    '''
    Unit test for constructor of class cached_property
    '''
    pass

# Generated at 2022-06-21 12:36:26.103265
# Unit test for constructor of class cached_property
def test_cached_property():
    class C:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    c = C()
    assert c.y == 6
    assert c.y == 6
    c.x = 10
    assert c.y == 11
    assert c.y == 11
    del c.y
    assert c.y == 11
    assert c.y == 11


# Generated at 2022-06-21 12:36:35.701895
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for cached_property class

    :return: None
    :rtype: None

    :Example:

    >>> from flutils.decorators import cached_property
    >>> @cached_property
    ... def x(self):
    ...     return 5
    >>> test = cached_property(x)
    >>> test.func
    <function cached_property.x at 0x7f2a2a974840>
    >>> test.__doc__
    None
    >>> test.__name__ = 'test'
    >>> test.__doc__ = 'Test doc'
    >>> test.__doc__
    'Test doc'
    """
    pass

# Generated at 2022-06-21 12:36:41.944057
# Unit test for constructor of class cached_property
def test_cached_property():
    class TestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.y == 6


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 12:36:48.176540
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class A:

        @cached_property
        def prop(self):
            return 'prop'

    a = A()
    assert a.prop == 'prop'



# Generated at 2022-06-21 12:36:59.719015
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import unittest
    import asyncio

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class TestCacheProperty(unittest.TestCase):

        def test_cached_property(self):
            obj = MyClass()
            self.assertTrue(isinstance(obj.y, int))
            self.assertEqual(obj.y, 6)
            obj.x = 3
            self.assertEqual(obj.y, 6)

        def test_async_cached_property(self):
            class MyClass:

                def __init__(self):
                    self.x = 5

                @cached_property
                async def y(self):
                    return self.x + 1



# Generated at 2022-06-21 12:37:09.116443
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """ Unit test for method __get__ of class cached_property """
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return asyncio.sleep(3, self.x + 1)

    obj = MyClass()

    assert obj.y == 6
    assert obj.__dict__['y'] == 6

    assert asyncio.iscoroutine(obj.z)
    assert not obj.__dict__['z']

# Unit tests for cached_property

# Generated at 2022-06-21 12:37:20.966007
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest import mock

    class TestClass:
        def __init__(self):
            self.x = 5

        def _get_y(self):
            return self.x + 1

        @cached_property
        def y(self):
            return self._get_y()

    y = TestClass.y
    y_instance = TestClass.y
    func = TestClass.y.func
    del TestClass.y
    del TestClass.y
    del TestClass.y
    del TestClass.y
    TestClass.y = cached_property(func)

    assert TestClass.y
    assert TestClass.y.__doc__
    assert TestClass.y.func
    assert TestClass.y.__name__
    assert y == TestClass.y

    tc = TestClass()
    assert y_instance

# Generated at 2022-06-21 12:37:32.669749
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import TestCase, main


    class TestClass(TestCase):

        # noinspection PyPep8Naming
        @cached_property
        def x(self):
            """
            The value of x.

            :return: The value of x.
            :rtype: int
            """
            return 5

        # noinspection PyPep8Naming
        @cached_property
        def z(self):
            # noinspection PyUnresolvedReferences
            """
            The value of z.

            :return: The value of z.
            :rtype: int
            """
            return self.x / self.y

        # noinspection PyPep8Naming

# Generated at 2022-06-21 12:37:35.605571
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6

# Generated at 2022-06-21 12:37:46.516147
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # noinspection PyClassHasNoInit,PyMissingTypeHints
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def func(self):
            return self.x + 1

    # Test regular function

    obj = MyClass()
    assert isinstance(obj.func, int), 'Cached property not of type int'

    # Test async function

    # noinspection PyClassHasNoInit,PyMissingTypeHints
    class MyAsyncClass:
        def __init__(self):
            self.x = 5

        @cached_property
        async def func(self):
            return self.x + 1

    obj = MyAsyncClass()

# Generated at 2022-06-21 12:37:52.728345
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property

    This unit test uses only public methods and attributes of the
    :obj:`~flutils.decorators.cached_property` class.
    """
    from flutils.decorators import cached_property

    class Test:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Test()
    result = obj.y
    assert result == 6, "Expected 6, got {value}".format(value=result)



# Generated at 2022-06-21 12:38:02.015674
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property
    assert cached_property.__name__ == 'cached_property'
    assert cached_property.__doc__

    # Get value of attribute 'func'
    func = cached_property.__dict__['func']

    # Validate that the value of attribute 'func' is a 'function'
    assert isinstance(
        func,
        type(lambda: None)
    )

    # Get the doc string
    doc = func.__dict__['__doc__']
    assert isinstance(doc, str)

# Generated at 2022-06-21 12:38:06.571323
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:38:20.720767
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest.mock import Mock

    mock1 = Mock()
    mock2 = Mock()
    foo = mock1.foo
    foo2 = mock2.foo
    assert foo is foo2
    assert foo is mock1.foo
    assert foo is mock2.foo
    assert foo is foo2


if __name__ == '__main__':
    import pytest

    pytest.main([__file__])

# Generated at 2022-06-21 12:38:29.018000
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest import TestCase, main


# Generated at 2022-06-21 12:38:37.279915
# Unit test for constructor of class cached_property
def test_cached_property():
    """Tests :func:`~flutils.decorators.cached_property` decorator,
    which is tested because it is used to define
    :attr:`~flutils.funcutils.utils.Utils.is_windows` as well as
    :attr:`~flutils.funcutils.utils.Utils.is_osx`, which in turn is
    used for testing :func:`~flutils.funcutils.utils.Utils.swapcase`.

    *New in version 0.1.0*
    """

    from flutils.funcutils.utils import Utils

    def test_func(self):
        return "test"

    assert test_func.__name__ == "test_func"

    assert Utils.is_windows() is not None
    assert Utils.is_osx()

# Generated at 2022-06-21 12:38:44.670124
# Unit test for constructor of class cached_property
def test_cached_property():
    call_count = 0

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            nonlocal call_count
            call_count += 1
            return self.x + 1

    obj = MyClass()
    # Check call count and if property is cached.
    assert call_count == 0
    assert obj.y == 6
    assert 'y' in obj.__dict__
    assert call_count == 1


# Generated at 2022-06-21 12:38:54.579667
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Testing 'cached_property' decorator.

    This function tests only the '__get__' method of class 'cached_property'
    for coverage.

    """

    class Foo:
        """Test class for testing 'cached_property' decorator."""

        def __init__(self):
            self._cached_prop = None

        @cached_property
        def cached_prop(self):
            """Test cached_property."""
            self._cached_prop = 'cached_property'
            return self._cached_prop

    foo = Foo()
    foo.cached_prop
    assert foo._cached_prop == 'cached_property'

    # get attribute again; __get__ should not be called
    foo.cached_prop
    assert foo._cached_prop == 'cached_property'

# Generated at 2022-06-21 12:39:02.196622
# Unit test for constructor of class cached_property
def test_cached_property():

    # Each value of the following list will be returned
    # by a call to `test_method`
    test_method_returns = [1, 2, 3]

    # Expected results for each call to `test_method`
    expected_results = [1, 1, 1]

    assert len(test_method_returns) == len(expected_results)

    # The class under test
    class MyClass:

        def test_method(self):
            return test_method_returns.pop(0)

        def set_test_method(self):
            self.test_method = test_method_returns.pop(0)

    my_object = MyClass()

    # Function is decorated without a leading @
    my_object.test_method = cached_property(my_object.test_method)

    # Call the function

# Generated at 2022-06-21 12:39:03.110457
# Unit test for constructor of class cached_property
def test_cached_property():
    pass

# Generated at 2022-06-21 12:39:10.590942
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest

    class ClassCachedPropertyTest:

        def __init__(self, y):
            self.y = y

        # noinspection PyUnusedLocal
        @cached_property
        def x(self):
            return self.y + 1

    obj = ClassCachedPropertyTest(7)

    assert obj.x == 8
    assert obj.__dict__['x'] == 8

    assert obj.x == 8

    # Verify the value is cached
    obj.y = 5
    assert obj.x == 8



# Generated at 2022-06-21 12:39:17.527316
# Unit test for constructor of class cached_property
def test_cached_property():
    import flutils.decorators

    # Ensure cached_property works in Python 3.8
    assert flutils.decorators.cached_property == functools.cached_property

    # This is a derivative work of cached_property
    # https://bit.ly/2R9U3Qa
    #
    # Copyright © 2015 Daniel Greenfeld; All Rights Reserved
    # https://bit.ly/2CwtJM1

    # This is a derivative work of cached_property
    # https://bit.ly/2JbYB5L
    #
    # Copyright © 2011 Marcel Hellkamp



# Generated at 2022-06-21 12:39:22.940945
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    obj.x = 10
    assert obj.y == 6
    del obj.y
    assert obj.y == 11



# Generated at 2022-06-21 12:39:46.347294
# Unit test for constructor of class cached_property
def test_cached_property():
    import pytest
    from pytest import mark

    @mark.asyncio
    async def test_properties():
        class MyClass:

            def __init__(self):
                self.x = 5

            @cached_property
            def y(self):
                return self.x + 1

            @cached_property
            async def z(self):
                return self.x + 2

        obj = MyClass()
        assert await obj.z == 7
        assert obj.y == 6

    from asyncio import gather

    gather(test_properties())
    pytest.main([__file__])

# Generated at 2022-06-21 12:39:48.410100
# Unit test for constructor of class cached_property
def test_cached_property():
    # set up
    # test
    with pytest.raises(TypeError):
        cached_property()



# Generated at 2022-06-21 12:39:58.608180
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """ Test cached_property().__get__()

    Test cache when a method is invoked and is a coroutine.

    Test cache when a method is invoked and is not a coroutine.

    Test not caching when the method is not invoked and it is a coroutine.

    """

    class TestCachedProperty:

        def __init__(self):
            self.x = 1

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        async def z(self):
            self.x += 1
            await asyncio.sleep(0.25)
            return self.x + 1

    test = TestCachedProperty()

    # Test cache when a method is invoked and is a coroutine.
    assert test.y == 2

# Generated at 2022-06-21 12:40:02.089038
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass(5)
    assert obj.y == 6

# Generated at 2022-06-21 12:40:04.671855
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Test caching a property

    :return:
    """
    assert eval("cached_property") == cached_property
    assert cached_property.__class__.__name__ == 'cached_property'

# Generated at 2022-06-21 12:40:07.916720
# Unit test for constructor of class cached_property
def test_cached_property():
    class Test:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    c = Test()
    assert c.y == 6

# Generated at 2022-06-21 12:40:11.945611
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class Foo:
        @cached_property
        def x(self):
            return 42

    obj = Foo()
    obj.x
    obj.__dict__
    obj.x
    obj.__dict__
    del obj.x
    obj.__dict__


# Generated at 2022-06-21 12:40:14.303693
# Unit test for constructor of class cached_property
def test_cached_property():
    class Tester:

        @cached_property
        def y(self):
            return 2

    assert Tester().y is 2

# Generated at 2022-06-21 12:40:24.012642
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property

    """
    from unittest.mock import patch

    class PropertyTest():
        testvar: str = None

        @cached_property
        def test_property(self):
            self.testvar += 'a'
            return self.testvar

    obj = PropertyTest()
    obj.testvar = 'b'
    result = obj.test_property
    assert result == 'ba'

    obj.testvar = 'b'
    result = obj.test_property
    assert result == 'ba'


cached_property.__test__ = False


if __name__ == "__main__":
    # noinspection PyUnresolvedReferences
    import pytest

    pytest.main([__file__])

# Generated at 2022-06-21 12:40:29.067159
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    x = MyClass()
    y = x.y
    assert y == (x.x + 1)
    x.x = 25
    y = x.y
    assert y == (x.x + 1)
    x.y = 50
    y = x.y
    assert y == 50

# Generated at 2022-06-21 12:41:10.920373
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property(lambda x: x).__init__(lambda x: x) == None

# Generated at 2022-06-21 12:41:15.010342
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class A:
        @cached_property
        def p(self):
            return 0

    a = A()
    assert a.p == 0



# Generated at 2022-06-21 12:41:21.571176
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # pylint: disable=too-few-public-methods
    class Foo:

        def __init__(self):
            self.x = 5

        # pylint: disable=arguments-differ
        @cached_property
        def y(self):
            """Bar"""
            return self.x + 1

    obj = Foo()
    assert obj.y == 6
    assert obj.y == 6

# Generated at 2022-06-21 12:41:27.924339
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    myclass = MyClass()
    myclass.y
    assert myclass.__dict__['y'] == 6

    # test overriding a cached property
    myclass.__dict__['y'] = 101
    assert myclass.y == 101



# Generated at 2022-06-21 12:41:35.385454
# Unit test for constructor of class cached_property
def test_cached_property():
    class TestClass:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x * 2

    obj1 = TestClass(5)
    obj2 = TestClass(5)
    assert obj1.x == obj2.x
    assert obj1.y == obj2.y
    obj1.x = 10
    assert obj1.x != obj2.x
    assert obj1.y != obj2.y



# Generated at 2022-06-21 12:41:44.628348
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class cp(cached_property):
        def __init__(self, func):
            self.func = func

        def __get__(self, obj: Any, cls):
            if obj is None:
                return self

            value = obj.__dict__[self.func.__name__] = self.func(obj)
            return value

    class cp2(cached_property):
        def __init__(self, func):
            self.func = func

        def __get__(self, obj: Any, cls):
            if obj is None:
                return self

            if asyncio.iscoroutinefunction(self.func):
                return self._wrap_in_coroutine(obj)

            value = obj.__dict__[self.func.__name__] = self.func(obj)
            return value

       

# Generated at 2022-06-21 12:41:46.919434
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property."""
    pass



# Generated at 2022-06-21 12:41:47.516538
# Unit test for constructor of class cached_property
def test_cached_property():
    pass

# Generated at 2022-06-21 12:41:50.106168
# Unit test for constructor of class cached_property
def test_cached_property():
    @cached_property
    def foo(self):
        return 'bar'

    assert foo.__doc__ == 'bar'


# Generated at 2022-06-21 12:41:51.282388
# Unit test for constructor of class cached_property
def test_cached_property():
    assert callable(cached_property)

# Generated at 2022-06-21 12:43:20.429615
# Unit test for constructor of class cached_property
def test_cached_property():
    """ Unit test for constructor of class cached_property """
    import flutils.decorators
    print(flutils.decorators.cached_property)



# Generated at 2022-06-21 12:43:22.094172
# Unit test for constructor of class cached_property
def test_cached_property():
    f = cached_property(None)
    assert f
    pass


# Generated at 2022-06-21 12:43:30.587192
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Check that asyncio.iscoroutine functions are wrapped in coroutine
    """

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    value = obj.__dict__[MyClass.y.func.__name__] = 6
    assert value == 6

    @asyncio.coroutine
    def coro(x):
        return x

    class MyClassA:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return coro(self.x + 1)

    obj = MyClassA()
    value = obj.__dict__[MyClassA.y.func.__name__]

# Generated at 2022-06-21 12:43:41.190215
# Unit test for constructor of class cached_property
def test_cached_property():
    # (1) Make sure cached_property decorator works as expected.
    class A:
        def __init__(self):
            self.x = 5
            self.run_count = 0

        @cached_property
        def y(self):
            self.run_count += 1
            return self.x + 1

    a = A()
    assert a.y == 6
    assert a.run_count == 1
    assert a.y == 6
    assert a.run_count == 1
    del a.y
    assert a.y == 6
    assert a.run_count == 2
    a.x = 10
    assert a.y == 11
    assert a.run_count == 3
    del a.y
    assert a.y == 11
    assert a.run_count == 4

    # (2) Make

# Generated at 2022-06-21 12:43:45.640858
# Unit test for constructor of class cached_property
def test_cached_property():
    import pytest

    class TestClass:
        pass

    with pytest.raises(AttributeError) as err:
        TestClass.x
    assert err.value.args[0] == "'TestClass' object has no attribute 'x'"

    class TestClass:
        @cached_property
        def x(self):
            return 2

    assert TestClass.x == 2

# Generated at 2022-06-21 12:43:51.781970
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class A:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            self.x += 1
            return self.x

    a = A()
    a.x
    a.y
    a.y
    a.x = 10
    a.y
    a.y



# Generated at 2022-06-21 12:43:55.444146
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property"""

    def cprop_mock_func(self):
        return 'mock func'

    cprop_mock = cached_property(cprop_mock_func)
    assert cprop_mock_func.__doc__ == cprop_mock.__doc__

# Generated at 2022-06-21 12:43:58.715766
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:44:04.703511
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    assert obj.y == 6

# Generated at 2022-06-21 12:44:05.361089
# Unit test for constructor of class cached_property
def test_cached_property():
    pass  # No constructor