

# Generated at 2022-06-21 12:34:43.643363
# Unit test for constructor of class cached_property
def test_cached_property():
    with pytest.raises(TypeError):
        cached_property(None)

    class Demo:
        pass

    _ = cached_property(Demo)



# Generated at 2022-06-21 12:34:52.081623
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test method"""
    import sys

    import pytest

    if sys.version_info[:2] < (3, 8):
        @cached_property
        def y():
            return test_cached_property.x + 1

        test_cached_property.x = 5
        assert y == 6
        del y
        pytest.raises(AttributeError, getattr, test_cached_property, "y")
    else:
        pytest.skip("Python 3.8 or greater")

# Generated at 2022-06-21 12:34:54.964799
# Unit test for constructor of class cached_property
def test_cached_property():
    x = 5
    obj = cached_property(x)
    assert obj.__doc__ == getattr(x, "__doc__")
    assert obj.func == x


# Generated at 2022-06-21 12:35:02.189028
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method `cached_property.__get__`."""

    class MyClass:
        """test class."""

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """test property."""
            return self.x + 1

    obj = MyClass()
    first_val = obj.y
    second_val = obj.y

    assert obj.y == first_val
    assert obj.y == second_val

# Generated at 2022-06-21 12:35:03.277301
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass

# noinspection PyPep8Naming

# Generated at 2022-06-21 12:35:07.796270
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    print("test start\n")
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    print("test end\n")



# Generated at 2022-06-21 12:35:10.451953
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    assert "y" in obj.__dict__
    del obj.y
    assert "y" not in obj.__dict__

# Generated at 2022-06-21 12:35:22.356706
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # This is the class definition which is used in the test methods
    class MyClass:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    # Test cache population
    obj = MyClass(5)
    assert obj.y == 6
    assert 'y' in obj.__dict__

    # Test cache population (async)
    obj = MyClass(5)
    async def test_method():
        return await asyncio.sleep(0.1, 6)
    obj.y = test_method
    asyncio.get_event_loop().run_until_complete(obj.y)
    assert obj.y == 6
    assert isinstance(obj.y, asyncio.futures.Future)

# Generated at 2022-06-21 12:35:23.065495
# Unit test for constructor of class cached_property
def test_cached_property():
    # TODO: Add tests
    pass

# Generated at 2022-06-21 12:35:32.247760
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""

    import pytest

    from .decorators import cached_property

    @cached_property
    def y(obj):
        """Return y from x."""
        return obj.x + 1

    class MyClass:
        """Class for testing cached_property"""

        def __init__(self):
            self.x = 5

    my_class = MyClass()

    # Test __doc__
    assert y.__doc__ == "Return y from x."

    # Test __get__ when called with no arguments
    y = y.__get__(None, MyClass)
    # Test __get__ when called with arguments
    assert y.__get__(my_class, MyClass) == 6

    # Test __get__ when called with no arguments after calling with arguments
   

# Generated at 2022-06-21 12:35:45.820129
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import asyncio
    from types import MethodType
    from unittest import TestCase, mock

    from flutils.decorators import cached_property
    from flutils.helpers import Future

    class DummyClass:

        _init_: bool = False
        _val: int = 0

        def __init__(self):
            self._init_ = True

        @cached_property
        def property_with_default_value(self):
            if not self._init_:
                raise ValueError('Instance not initialized in property.')
            return self._val

        @cached_property
        def property_with_coroutine(self):
            if not self._init_:
                raise ValueError('Instance not initialized in property.')
            return self._val


# Generated at 2022-06-21 12:35:47.666006
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """test_cached_property___get__()
    """
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert 6 == obj.y
    return True

# Generated at 2022-06-21 12:35:52.220745
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    print(obj.__dict__)

# Generated at 2022-06-21 12:35:54.084541
# Unit test for constructor of class cached_property
def test_cached_property():
    assert issubclass(cached_property, object)

# Generated at 2022-06-21 12:36:00.608635
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for class ``cached_property``
    """

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert hasattr(obj, 'x')
    assert hasattr(obj, 'y')
    assert obj.x == 5
    assert obj.y == 6



# Generated at 2022-06-21 12:36:10.022329
# Unit test for constructor of class cached_property
def test_cached_property():

    # noinspection PyArgumentList
    def test_func(self):
        return 'test'

    # noinspection PyArgumentList
    def test_func2(self):
        return 'test2'

    # noinspection PyArgumentList
    class TestObj:

        def __init__(self):
            self.x = 5

        # noinspection PyArgumentList
        @cached_property
        def y(self):
            return test_func2(self)


# Generated at 2022-06-21 12:36:14.686043
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @staticmethod
        def get_x():
            return 5

    obj = MyClass()
    assert obj.y == 6
    assert MyClass.get_x() == 5



# Generated at 2022-06-21 12:36:20.593589
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import unittest
    from unittest import mock

    async def async_func(obj):
        """An async function"""
        return obj

    class MyClass:

        def __init__(self):
            pass

        @cached_property
        def func(self):
            """A function"""
            return self

    class Test1(unittest.TestCase):

        def test(self):
            obj = MyClass()
            self.assertFalse(hasattr(obj, 'func'))
            func = obj.func
            self.assertEqual(func, obj)
            self.assertTrue(hasattr(obj, 'func'))


# Generated at 2022-06-21 12:36:29.652214
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """ Unit test for method __get__ of class cached_property
    """

    class TestClass(object):
        @cached_property
        def x(self):
            return 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    # On the first access to obj.y, it will be computed.
    assert obj.y == 6

    # The value of obj.y will be cached. The cached value will be returned on
    # each subsequent access.
    assert obj.y == 6

    # The value of obj.y can be overwritten by setting `obj.y = 6`
    # On the next access to obj.y, it will be computed again.
    obj.y = 6
    assert obj.y == 6

    # The value of obj.y can be deleted

# Generated at 2022-06-21 12:36:36.878735
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import MagicMock

    obj = MagicMock()
    obj.x = 5
    obj.y = MagicMock()
    func = MagicMock()
    method = cached_property(func)
    assert method.__get__(obj, MagicMock) == obj.y
    func.assert_called_once_with(obj)
    assert func() == obj.__dict__[method.func.__name__]

# Generated at 2022-06-21 12:36:51.331150
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""
    global _fail_count
    global _test_count
    global _test_fail_count
    global _test_skip_count

    _test_count += 1
    try:
        from flutils.decorators import cached_property
        class MyClass:

            def __init__(self, *args, **kwargs):
                pass

            @cached_property
            def foo(self):
                return 'foo'

        instance = MyClass()
        assert instance.foo == 'foo'
        assert type(instance.foo) == str
    except AssertionError:
        _test_fail_count += 1
        _fail_count += 1
        raise AssertionError('Test Failure: test_cached_property___get__().')

# Generated at 2022-06-21 12:37:01.883932
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class A(object):

        def __init__(self, value):
            self._value = value

        @cached_property
        def value(self):
            return self._value

    a = A('1')
    assert hasattr(a, '_value')
    assert hasattr(a, 'value')
    assert not hasattr(a, 'value1')

    assert a.value == '1'
    assert a._value == '1'

    assert not hasattr(a, 'value1')
    def set_value1(obj):
        obj.value1 = '2'
    set_value1(a)
    assert a.value1 == '2'

    a.value = '3'

    assert a._value == '1'
    assert a.value == '3'



# Generated at 2022-06-21 12:37:06.852325
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 3

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    assert obj.y == 4
    obj.x = 5
    assert obj.y == 4

# Generated at 2022-06-21 12:37:10.115095
# Unit test for constructor of class cached_property
def test_cached_property():
 
    class Foo:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Foo()

    assert obj.y == 6

# Generated at 2022-06-21 12:37:12.107682
# Unit test for constructor of class cached_property
def test_cached_property():
    # Instantiation
    obj = cached_property(lambda: 5)
    assert obj



# Generated at 2022-06-21 12:37:15.979876
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Dummy:
        val = 12

        @cached_property
        def val_plus10(self):
            return self.val + 10

    dummy = Dummy()
    assert dummy.val_plus10 == 22

# Generated at 2022-06-21 12:37:21.468272
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit tests for :func:`~flutils.cached_property`.

    """
    class TestClass:

        @cached_property
        def foo(self):
            return 'bar'

    obj = TestClass()
    # Property is defined.
    assert hasattr(obj, 'foo')
    assert obj.foo == 'bar'



# Generated at 2022-06-21 12:37:28.213745
# Unit test for constructor of class cached_property
def test_cached_property():

    class C:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = C()
    assert 'y' not in obj.__dict__
    assert obj.y == 6
    assert obj.__dict__['y'] == 6

    # Now try again to see that we get the same value
    assert obj.y == 6



# Generated at 2022-06-21 12:37:35.177676
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest

    from .decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        async def z(self):
            return await self.x + 1

    m = MyClass()
    assert m.y == 6
    assert m.__dict__['y'] == 6

    with pytest.raises(TypeError):
        m.z

# Generated at 2022-06-21 12:37:42.609953
# Unit test for constructor of class cached_property
def test_cached_property():
    class ClassWithCachedProperty(object):
        def __init__(self):
            self.x = 1

        @cached_property
        def cached_property(self):
            return self.x + 1

    obj = ClassWithCachedProperty()
    assert obj.cached_property == 2
    assert obj.__dict__["cached_property"] == 2
    obj.x = 2
    assert obj.cached_property == 2


# Generated at 2022-06-21 12:37:55.068985
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import Mock

    obj = Mock(spec=MyObject)
    obj.size = 1
    obj.__dict__['size'] = 1

    assert obj.size == 1
    assert obj.getSize() == 1
    assert obj.size == 1



# Generated at 2022-06-21 12:38:06.183394
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    from flutils.decorators import cached_property

    # Verifies correct function of class when used as a normal class
    class MyClassNormal:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj_normal = MyClassNormal()
    assert (obj_normal.y == 6)

    # Verifies correct function of class when used as a dataclass
    import dataclasses

    @dataclasses.dataclass
    class MyClassDataclass:

        x: int = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj_dataclass = MyClassDataclass(5)
    assert (obj_dataclass.y == 6)

    # Verifies

# Generated at 2022-06-21 12:38:12.054095
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test cached_property __get__.
    """
    class Foo:

        @cached_property
        def bar(self):
            return 5

    foo = Foo()

    assert foo.bar == 5
    assert isinstance(foo.__dict__['bar'], int)

    assert foo.bar == 5
    assert foo.__dict__['bar'] == 5

# Generated at 2022-06-21 12:38:18.071611
# Unit test for constructor of class cached_property
def test_cached_property():
    import pytest
    from flutils.decorators import cached_property

    class A:
        @cached_property
        def foo(self):
            return 'bar'

    a = A()
    assert a.foo == 'bar'

    # assert a.foo == 'bar'
    with pytest.raises(AttributeError) as excinfo:
        a.foo = 'qux'
    assert str(excinfo.value) == "can't set attribute"  # "can't set attribute"

    del a.foo
    assert 'foo' not in a.__dict__

# Generated at 2022-06-21 12:38:21.405991
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:38:26.578102
# Unit test for constructor of class cached_property
def test_cached_property():
    """This function tests the constructor of class cached_property"""
    # TODO: Unit test


if __name__ == '__main__':
    cached_property.__doc__ = cached_property.__doc__.format(
        func="cached_property",
        cls="cached_property"
    )
    # doctest.testmod()
    print(cached_property.__doc__)
    print(__doc__)

# Generated at 2022-06-21 12:38:35.233357
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # noinspection PyUnresolvedReferences
    """This method is tested via the decorator usage in the class MyClass
    below.  Should the decorator usage change, this test may need to be updated
    to reflect the changes.
    """

    @cached_property
    def test_method(self):
        return 'Test string'

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert test_method(__name__) == "Test string"
    assert test_method.__doc__ is None

    obj = MyClass()
    assert obj.y == 6
    assert obj.y is obj.y



# Generated at 2022-06-21 12:38:41.645542
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property
    from flutils.decorators import cached_property as cached_property_orig

    def f():
        pass

    # Create a class
    class C:
        @cached_property
        def x(self):
            pass

    c = C()
    assert isinstance(c.x, cached_property_orig)
    assert f.__doc__ == c.x.__doc__
    assert f.__module__ == c.x.__module__

# Generated at 2022-06-21 12:38:43.720690
# Unit test for constructor of class cached_property
def test_cached_property():
    c = cached_property(None)
    assert callable(c)



# Generated at 2022-06-21 12:38:47.367620
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class TestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:39:04.482011
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # create class
    class TestClass:

        def __init__(self, value):
            self.x = value


# Generated at 2022-06-21 12:39:06.695188
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    assert obj.y == 6
    obj.x = 7
    assert obj.y == 6

# Generated at 2022-06-21 12:39:11.058536
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Obj():
        def __init__(self, val):
            self.val = val

        @cached_property
        def y(self):
            return self.val + 1

    obj = Obj(5)
    assert obj.y == 6



# Generated at 2022-06-21 12:39:14.166684
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    print(obj.y)
    print(obj.y)


if __name__ == "__main__":
    test_cached_property___get__()

# Generated at 2022-06-21 12:39:16.765308
# Unit test for constructor of class cached_property
def test_cached_property():

    def cached_property_constructor_check():
        x = cached_property(lambda x: x)
        assert x.__doc__ is None
        assert x.func(5) == 5

    cached_property_constructor_check()


# Generated at 2022-06-21 12:39:21.245844
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    from flutils.decorators import cached_property
    from flutils.decorators import cached_property

    class MyClass:

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.x = 5
    assert obj.y == 6

# Generated at 2022-06-21 12:39:22.743223
# Unit test for constructor of class cached_property
def test_cached_property():
    with pytest.raises(TypeError):
        cached_property(object())

# Generated at 2022-06-21 12:39:33.563242
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test method ``cached_property.__get__``."""

    #
    # Setup
    #

    class MyClass:
        """Class to test the :obj:`~flutils.decorators.cached_property`
        decorator.
        """

        def __init__(self):
            self._x = 5

        @cached_property
        def y(self):
            """The value of y is x plus 1."""
            return self._x + 1

    myobj = MyClass()

    #
    # Test
    #

    # Test getter (no setter)
    assert myobj.y == 6

    # Test cached_property
    assert myobj.y == 6

    # Test cached_property
    myobj._x = 10
    assert myobj.y == 6

    #
    #

# Generated at 2022-06-21 12:39:41.844801
# Unit test for constructor of class cached_property
def test_cached_property():

    class MyClass:

        def __init__(self):
            self.x = 5
            self.y = None

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6, "expected 6 got: {}".format(obj.y)
    assert obj.__dict__['y'] == 6, "expected 6 got: {}".format(obj.__dict__['y'])
    assert isinstance(obj.__dict__['y'], int), "expected int got: {}".format(type(obj.__dict__['y']))
    assert obj.y == obj.__dict__['y'], "expected {} got: {}".format(obj.y, obj.__dict__['y'])

# Generated at 2022-06-21 12:39:46.388528
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property
    """

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    assert obj.y == 6

# Generated at 2022-06-21 12:40:18.505813
# Unit test for constructor of class cached_property
def test_cached_property():
    cp = cached_property(lambda x: 3)
    assert cp.func(3) == 3

# Generated at 2022-06-21 12:40:25.504096
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Define MyClass
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    # Delete attribute y.
    del obj.y

    # Now y has been reset.
    assert obj.y == 6


# Import guards
if __name__ == '__main__':
    # Unit test this module.
    test_cached_property___get__()

# Generated at 2022-06-21 12:40:36.381870
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
# AssertionError: Expected :
# asyncio.tasks.Task(<coroutine object cached_property.<locals>.wrapper at 0x7fb4379f4ba0>)
# to equal:
# 'test'
    import asyncio

    class Dummy:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x - 1

        @cached_property
        async def zz(self):
            return self.x * 2

    obj = Dummy()
    # Call once to trigger cached_property
    obj.z
    # Call to test
    obj.z = 'test'

    loop = asyncio.get_event_loop()


# Generated at 2022-06-21 12:40:42.438802
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property

    """

    import asyncio

    from unittest import TestCase, mock
    from flutils.decorators import cached_property

    class MockClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class Testcase__get__(TestCase):

        @classmethod
        def setUpClass(cls):
            cls.mc = MockClass()

        @classmethod
        def tearDownClass(cls):
            cls.mc = None

        def test__get__(self):
            self.assertEqual(Testcase__get__.mc.y, 6)

# Generated at 2022-06-21 12:40:46.271758
# Unit test for constructor of class cached_property
def test_cached_property():
    class CachedPropertyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = CachedPropertyClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:40:51.562914
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property"""

    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:40:54.773580
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import Mock, call

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.__dict__['y'] = Mock()
    obj.__dict__['y'].return_value = 7
    assert obj.y == 7
    obj.__dict__['y'].assert_called_with()



# Generated at 2022-06-21 12:41:01.939948
# Unit test for constructor of class cached_property
def test_cached_property():
    # Setup
    class Test:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Exercise
    test = Test()

    # Verify
    assert test.y == 6
    assert test.y == 6
    delattr(test, 'y')
    test.x = 10
    assert test.y == 11
    assert test.y == 11
    assert 'y' in test.__dict__


# Generated at 2022-06-21 12:41:06.504837
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    @cached_property
    def _test_cached_property__get__(self):
        return self

    assert id(TestCachedPropertyGetObject()._test_cached_property__get__) == \
        id(TestCachedPropertyGetObject()._test_cached_property__get__)



# Generated at 2022-06-21 12:41:14.021868
# Unit test for constructor of class cached_property
def test_cached_property():
    from collections import namedtuple

    class Foo(object):

        def __init__(self, x):
            self._x = x

        @cached_property
        def y(self):
            return self._x + 1

        @cached_property
        def z(self):
            return self._x + 2

    N = namedtuple("N", "x y z")

    @cached_property
    def t(self):
        return self.x + 3

    n = N(1, 2, 3)
    n.__dict__["t"] = t
    foo = Foo(10)

    assert foo.y == 11, "{} != 11".format(foo.y)

# Generated at 2022-06-21 12:42:43.046206
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():  # noqa: D103

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @classmethod
        def z(cls):
            return 7

    # We don't want to namespace pollute the module we're testing
    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__ == {"x": 5, "y": 6}

    # Test delete
    del obj.y
    assert obj.__dict__ == {"x": 5}

    obj.y
    assert obj.__dict__ == {"x": 5, "y": 6}

    # Test classmethod
    obj.z()
    assert "z" not in obj.__dict__

    # Test that cached_property

# Generated at 2022-06-21 12:42:44.319163
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj = CachedPropertyTestClass()
    obj.y



# Generated at 2022-06-21 12:42:49.911385
# Unit test for constructor of class cached_property
def test_cached_property():  # pragma: no cover
    class TestClass:

        def __init__(self):
            self.x = True

        @cached_property
        def x(self):
            """Return True."""
            return True

    obj = TestClass()
    assert obj.x is True


# Generated at 2022-06-21 12:42:53.516990
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test the constructor of class cached_property."""
    from functools import wraps

    class MyClass:

        @cached_property
        def y(self):
            return self.x + 1

    assert MyClass.y.__doc__ == 'None'



# Generated at 2022-06-21 12:42:58.961423
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest
    from flutils.decorators import cached_property

    class TestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    testclass = TestClass()
    assert testclass.y == 6

    testclass = TestClass()
    assert testclass.y == 6


# Generated at 2022-06-21 12:43:01.700118
# Unit test for constructor of class cached_property
def test_cached_property():
    class Class:
        def __init__(self): pass

    c = Class()
    assert not c.__dict__
    assert isinstance(cached_property(lambda x: x), cached_property)

# Generated at 2022-06-21 12:43:06.735969
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class A():
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    a = A()
    assert a.y == 6
    assert a.__dict__['y'] == 6
    a.x = 7
    assert a.y == 8
    assert a.__dict__['y'] == 8



# Generated at 2022-06-21 12:43:12.077655
# Unit test for constructor of class cached_property
def test_cached_property():
    # noinspection PyUnusedLocal
    class Foo:
        def __init__(self):
            self.x = 5
            self.y = 2

        @cached_property
        def add_x(self):
            """
            Addx
            """
            return self.x + self.y

    obj = Foo()
    assert obj.x == 5
    assert obj.y == 2

    assert obj.add_x == 7

    assert obj.__doc__ == '''
    Addx
    '''

    assert obj.__dict__ == {'x': 5, 'y': 2, 'add_x': 7}

    assert isinstance(obj.add_x, int)

    del obj.add_x

    assert obj.__dict__ == {'x': 5, 'y': 2}


# Generated at 2022-06-21 12:43:16.346485
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    obj.x = 5

    obj.y

    assert obj.y == 6

    obj.x = 8

    assert obj.y == 6

# Generated at 2022-06-21 12:43:25.528475
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    This method tests the method cached_property.__get__.

    Expected result:
        Method __get__ should return an object of type asyncio.futures.Future
        if func is a coroutine that is asyncio.iscoroutinefunction(func) is
        True.  Method __get__ should return the result of calling func
        with the first argument being obj if func is not a coroutine.

    Test procedure:
        1. Instantiate MyClass
        2. Check that obj.y is the result of calling MyClass.y
        3. Check that calling obj.y again does not call MyClass.y again
        4. Check that calling obj.z returns a coroutine
        5. Check that calling asyncio.ensure_future(obj.z) returns a
           Future that runs the coroutine defined in MyClass.z
    """
