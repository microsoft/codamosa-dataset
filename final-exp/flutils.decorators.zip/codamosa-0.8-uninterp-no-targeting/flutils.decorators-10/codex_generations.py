

# Generated at 2022-06-21 12:34:46.745191
# Unit test for constructor of class cached_property
def test_cached_property():
    """ unit test for class cached_property
    """

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:34:53.036013
# Unit test for constructor of class cached_property
def test_cached_property():
    """ Unit test for constructor of class :func:`~flutils.decorators.cached_property`.

    *New in version 0.2.0*

    """
    from pytest import raises

    def _foo():
        pass

    with raises(TypeError):
        _foo = cached_property(_foo)


if __name__ == "__main__":
    from pytest import main

    main([__file__])

# Generated at 2022-06-21 12:34:54.171638
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    >>> obj = MyClass()
    >>> obj.y
    6
    """



# Generated at 2022-06-21 12:35:01.308623
# Unit test for constructor of class cached_property
def test_cached_property():
    import pytest

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    y = obj.y
    assert isinstance(y, int)
    assert y == obj.y
    obj.y += 1
    with pytest.raises(AttributeError):
        obj.y += 1



# Generated at 2022-06-21 12:35:06.306800
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property.

    """
    # pylint: disable=too-few-public-methods
    class Test(object):

        def __init__(self):
            self._x = 0

        @cached_property
        def x(self):
            return self._x + 1

        @staticmethod
        def test_decorator(x_val):
            """Test for cached_property decorator.

            """
            inst = Test()
            inst.x
            inst.x
            return inst.x == x_val

    assert Test.test_decorator(2)

# Generated at 2022-06-21 12:35:13.592930
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class Obj:
        def __init__(self, x=5):
            self.x = x
            self.num_calls = 0

        @cached_property
        def y(self):
            self.num_calls += 1
            return self.x + 1

    obj = Obj()
    # y is a property descriptor
    assert not isinstance(obj.y, int)
    # result of first access
    assert obj.y == 6
    assert obj.num_calls == 1
    # result of second access
    assert obj.y == 6
    assert obj.num_calls == 1



# Generated at 2022-06-21 12:35:26.389580
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest
    from functools import partial
    from inspect import iscoroutinefunction

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """My docstring"""
            return self.x + 1

    obj = MyClass()
    cp = cached_property(lambda: 0)
    assert cp.__get__(obj) == 0
    assert not iscoroutinefunction(cp.__get__(obj))

    cp = cached_property(partial(asyncio.sleep, 0.1))
    assert not iscoroutinefunction(cp.__get__(obj))
    assert asyncio.iscoroutinefunction(cp._wrap_in_coroutine(obj))

    assert obj.y == 6
    assert obj.y == 6

# Generated at 2022-06-21 12:35:30.764561
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from inspect import iscoroutinefunction

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def test_property(self):
            return self.x + 1

        @cached_property
        async def test_async_property(self):
            return self.x + 1

    obj = MyClass()

    assert obj.test_property == 6
    assert obj.__dict__['test_property'] == 6
    assert iscoroutinefunction(obj.test_async_property) is False
    assert iscoroutinefunction(obj.test_async_property.__wrapped__) is True

# Generated at 2022-06-21 12:35:34.787042
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Unit test for constructor of class cached_property
    :return:
    """

    class CachedProperty(cached_property):
        pass

    try:
        CachedProperty(None)
    except TypeError:
        pass
    else:
        raise AssertionError("No error raised")

# Generated at 2022-06-21 12:35:40.599846
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    assert obj.y == 6
    obj.y
    assert obj.y == 6



# Generated at 2022-06-21 12:35:54.524337
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # Fixture for cached_property
    import pytest


    @pytest.fixture
    def cp(request):
        return cached_property(lambda s: "func")


    def test_func_attr_does_not_exist(cp):
        # Fixture: Mock class and instance of class

        class MockClass(object):
            pass

        mc = MockClass()
        cp.func = None
        # Exercise and verify expectations
        assert "func" == cp.__get__(mc, MockClass)
        assert "func" == mc.func


    def test_obj_is_None_and_func_attr_does_not_exist(cp):
        # Exercise and verify expectations
        assert cp == cp.__get__(None, None)
        assert "func" == cp.func



# Generated at 2022-06-21 12:36:04.033811
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest import mock
    from flutils.decorators import cached_property

    class TestClass:
        def __init__(self):
            self.__x = 5

        @cached_property
        def y(self):
            return self.__x + 1

    obj = TestClass()
    assert obj.y == 6
    assert obj.__dict__['y'] == 6

    obj.__x = 42
    assert obj.y == 6
    assert obj.__dict__['y'] == 6

    with mock.patch.object(type(obj), 'y', 42):
        assert obj.y == 42

    with pytest.raises(AttributeError):
        del obj.y

    assert 'y' not in obj.__dict__
    assert obj.y == 6
    assert obj.__dict__['y']

# Generated at 2022-06-21 12:36:08.652360
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    return obj

# Generated at 2022-06-21 12:36:18.975146
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # The @cached_property decorator should add doc strings as well as
    # attributes to MyClass
    assert isinstance(MyClass.y.__doc__, str) is True
    assert isinstance(MyClass().y.__doc__, str) is True

    obj = MyClass()

    # The @cached_property decorator should be callable; even if it was
    # already called
    assert cached_property(MyClass.y)(obj) is obj.__dict__['y']
    assert cached_property(MyClass.y)(obj) is obj.__dict__['y']

   

# Generated at 2022-06-21 12:36:21.075750
# Unit test for constructor of class cached_property
def test_cached_property():
    # constructor of class cached_property
    from flutils.decorators import cached_property

    assert cached_property

# Generated at 2022-06-21 12:36:24.509225
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import MagicMock

    obj = MagicMock()
    cls = MagicMock()

    _ = cached_property.__get__(obj, cls)


# Generated at 2022-06-21 12:36:28.946087
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class TestObj:
        def __init__(self):
            pass

        @cached_property
        def x(self):
            self.y = 15
            return 123

    obj = TestObj()
    assert obj.x == 123
    assert obj.__dict__['x'] == 123
    assert obj.__dict__['x'] == obj.x
    assert obj.y == 15



# Generated at 2022-06-21 12:36:41.861691
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Since it's a descriptor, you can't call __get__ without passing either a
    # class or an object (instance) to it.  The class is used to resolve the
    # attribute value.

    # If no class is passed, an exception should be raised.
    with pytest.raises(TypeError):
        cached_property.__get__(None, object)

    # If no object (instance) is passed, return the descriptor itself.
    assert cached_property.__get__(None, cached_property) == cached_property

    # If a class and an object are passed, the method should return the
    # function to be decorated.
    class DummyClass:
        def func(self):
            pass

    # Test

# Generated at 2022-06-21 12:36:46.321816
# Unit test for constructor of class cached_property
def test_cached_property():

    orig_func = lambda self: self.x + 1

    cp = cached_property(orig_func)
    assert cp.func == orig_func


# Generated at 2022-06-21 12:36:51.252327
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestClass:
        def __init__(self):
            self.x = 10

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.y == 11
    assert obj.__dict__["y"] == 11

# Generated at 2022-06-21 12:36:57.740338
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y

# Generated at 2022-06-21 12:37:05.022489
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class C:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    print(f'C.y, {C.y}')
    assert C.y == cached_property

    obj = C()
    print(f'obj.y, {obj.y}')
    assert obj.y == 6



# Generated at 2022-06-21 12:37:15.365236
# Unit test for constructor of class cached_property
def test_cached_property():
    x = 1

    # noinspection PyPep8Naming
    class Example(object):
        # noinspection PyPep8Naming
        @cached_property
        def x(self):
            return x

    obj = Example()
    assert obj.x == 1

    # noinspection PyPep8Naming
    class Example(object):
        @cached_property
        def x(self):
            return print('hey')

    obj = Example()
    # noinspection PyUnusedLocal
    dummy = obj.x
    assert obj.__dict__['x'] == 'hey'
    del obj.x
    assert obj.x == 'hey'
    assert obj.__dict__['x'] == 'hey'

# Generated at 2022-06-21 12:37:20.414141
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest import TestCase, main

    class Test(TestCase):

        def test(self):

            class CacheProp:

                x = 5

                @cached_property
                def x1(self):
                    return self.x + 1

            obj = CacheProp()
            self.assertEqual(obj.x1, 6)

    main()

# Generated at 2022-06-21 12:37:24.950434
# Unit test for constructor of class cached_property
def test_cached_property():

    class ClassTest:

        @cached_property
        def y(self):
            return self.x + 1

        def __init__(self, x):
            self.x = x

    obj = ClassTest(5)
    assert obj.y == 6

# Generated at 2022-06-21 12:37:35.492161
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 0

        @cached_property
        def y(self):
            self.x += 1
            return self.x

    obj = MyClass()
    assert obj.y == 1
    assert obj.y == 1
    obj.y += 1
    assert obj.y == 2
    obj.x = -1
    assert obj.y == 2
    del obj.y
    assert obj.y == 3
    assert obj.x == 2
    obj.x = -1
    assert obj.y == 3
    obj.y += 1
    assert obj.y == 4
    assert obj.x == 3
    del obj.y
    assert obj.y == 5
    assert obj.x == 4
    obj.x = -1
    assert obj.y

# Generated at 2022-06-21 12:37:43.045593
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for cached_property.__get__"""

    class Foo(object):

        _id = 0

        def __init__(self):
            self.id = Foo._id
            Foo._id += 1

        @cached_property
        def bar(self):
            return self.id + 1

    for _ in range(3):
        a = Foo()
        assert a.bar == a.id + 1
        assert a.bar == a.id + 1



# Generated at 2022-06-21 12:37:48.105663
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 10

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.__dict__ == {}

    assert obj.y == 11
    assert obj.__dict__ == {'x': 10, 'y': 11}

    assert obj.y == 11
    assert obj.__dict__ == {'x': 10, 'y': 11}



# Generated at 2022-06-21 12:37:52.792005
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Unit tests for the constructor of :obj:`flutils.decorators.cached_property`.

    *New in version 0.2.0*
    """
    # noinspection PyUnusedLocal
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6

# Generated at 2022-06-21 12:37:57.093637
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyObj:

        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    obj1 = MyObj(5)
    assert obj1.y == 6
    assert 'y' in obj1.__dict__
    assert obj1.__dict__['y'] == 6

    obj2 = MyObj(5)
    assert obj2.y == 6
    assert obj2.__dict__['y'] == 6



# Generated at 2022-06-21 12:38:03.605316
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # raise NotImplementedError("Method not implemented.")

    # Verify results.
    assert True

# Token: Unit test for class cached_property

# Generated at 2022-06-21 12:38:15.138760
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():  # noqa: D102
    from unittest.mock import MagicMock
    from unittest.mock import patch

    # Setup
    with patch.object(cached_property, "cached_property", autospec=True) as mock:
        with patch.object(cached_property, '_wrap_in_coroutine', autospec=True):

            test_obj = MagicMock(spec=cached_property)
            test_cls = MagicMock()
            test_cls.__name__ = 'cached_property'

            # Exercise
            actual_return = cached_property.__get__(test_obj, test_cls)

            # Verify
            mock.assert_called_once_with(cached_property)
            assert actual_return == test_obj



# Generated at 2022-06-21 12:38:21.650184
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class A:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x

    # Test default
    a = A(3)
    assert a.y == 3
    # Test cached
    a.x = 5
    assert a.y == 3
    # Test invalidation
    del a.y
    assert a.y == 5



# Generated at 2022-06-21 12:38:27.064493
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x

    obj = MyClass()
    assert MyClass.__dict__['y'].__doc__ == MyClass.y.__doc__ == obj.y.__doc__
    assert obj.y is obj.__dict__['y']
    assert obj.x == obj.y



# Generated at 2022-06-21 12:38:33.247807
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for :class:`~flutils.decorators.cached_property` and
    :obj:`~flutils.decorators.cached_property`.

    """

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.x == 5
    assert obj.y == 6
    assert hasattr(obj, 'y')

# Generated at 2022-06-21 12:38:39.414988
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Test:

        def __init__(self):
            self.val: int=0

        @cached_property
        def get_val(self):
            return self.val

    test = Test()

    assert test.get_val == 0

    test.val = 1

    # Call again, value should be cached
    assert test.get_val == 0

    # Delete cached value
    del test.get_val

    # Call again, value should be updated
    assert test.get_val == 1

# Generated at 2022-06-21 12:38:49.969468
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.commonutils import timed_property

    class TestClass:

        @cached_property
        def y(self):
            return self.x + 1

        @timed_property(use_future=True)
        def z(self):
            return self.x + 1

    x = TestClass()
    x.x = 1

    assert isinstance(x.y, int)
    assert x.y == 2
    assert 'y' in x.__dict__
    assert 'y' not in TestClass.__dict__

    assert isinstance(x.z, asyncio.Future)
    assert x.z.done()
    assert 'z' in x.__dict__
    assert 'z' not in TestClass.__dict__

    del x.y
    assert 'y' not in x.__dict__

   

# Generated at 2022-06-21 12:38:52.520388
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import mock, main

    def testfunc(obj: Any):
        return obj
    testobj = mock.MagicMock()
    testobj.__dict__ = {}
    cp = cached_property(testfunc).__get__(testobj, None)
    assert cp is testobj



# Generated at 2022-06-21 12:39:00.681083
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class ACoroutine:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return asyncio.ensure_future(self.x + 1)

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__['y'] == 6

    obj = ACoroutine()
    assert asyncio.iscoroutine(obj.y)
    assert obj.__dict__['y'].done()
    assert obj.__dict__['y'].result() == 6

# Generated at 2022-06-21 12:39:12.289544
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from contextlib import suppress

    import pytest

    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        async def z(self):
            return await self.x + 1

    obj = MyClass()
    with pytest.raises(NotImplementedError):
        assert obj.z == 6

    obj.z
    assert obj.z == 6

    obj.y
    assert obj.y == 6

    with suppress(AttributeError):
        del obj.y

    # noinspection PyStatementEffect
    obj.y
    assert obj.y == 6

    # noinspection PyStatementEffect
    obj.z


# Generated at 2022-06-21 12:39:24.132658
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property as c

    class myclass:
        def __init__(self):
            self.x = 5

        @c
        def y(self):
            return self.x + 1

    obj = myclass()
    assert obj.y == 6



# Generated at 2022-06-21 12:39:34.865267
# Unit test for constructor of class cached_property
def test_cached_property():
    """ Tests for the cached_property decorator.
    """
    from pprint import pprint

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    # check __doc__
    assert obj.y.__doc__.strip() == 'A property decorator that is only ' \
                                    'computed once per instance and then ' \
                                    'replaces itself with an ordinary ' \
                                    'attribute.'

    # check deleting attribute resets the property
    del obj.y
    assert obj.y == 6

    # check with async coroutine
    async def my_coro(n):
        await asyncio.sleep(n)
        return

# Generated at 2022-06-21 12:39:35.333916
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property

# Generated at 2022-06-21 12:39:36.179904
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property.__init__(lambda x: x)

# Generated at 2022-06-21 12:39:45.390760
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property
    from datetime import date
    from pathlib import Path

    class MyClass:

        def __init__(self):
            self.x = 5

            # noinspection PyPep8Naming
            @cached_property
            def y(self):
                return self.x + 1

    obj = MyClass()
    my_func = obj.y
    assert my_func == 6, "Invalid return value from cached property"
    assert obj.__dict__.get('y', None) is not None, "Missing cached property"

    # Test for proper handling of erroneous function input
    obj.x = "abcd"
    with pytest.raises(TypeError):
        obj.y

# Generated at 2022-06-21 12:39:51.114221
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    obj.x = 7
    assert obj.y == 8


# noinspection PyPep8Naming

# Generated at 2022-06-21 12:39:55.875590
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Sample class
    class DummyClass:
        # Constructor
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Sample object
    obj = DummyClass()

    # Test
    assert obj.y == 6

# Generated at 2022-06-21 12:39:57.748275
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test constructor of cached_property."""
    obj = cached_property(lambda x: x * 2)
    assert obj.func(5) == 10

# Generated at 2022-06-21 12:40:02.958274
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test the method `cached_property.__get__` for class
    `cached_property`

    """
    from unittest.mock import Mock, call

    obj = Mock()
    cp = cached_property(lambda: None)
    cp.__get__(obj)
    obj.__dict__.update.assert_has_calls([call({cp.func.__name__: None})])

# Generated at 2022-06-21 12:40:06.863357
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # noinspection PyPep8Naming
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    obj.x = 8
    assert obj.y == 6



# Generated at 2022-06-21 12:40:24.914415
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:40:31.444801
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for :method:`flutils.decorators.cached_property.__get__`

    This function must be run with pytest.
    """
    # noinspection PyUnusedLocal,PyUnusedLocal
    @cached_property
    def foo(self):
        return 5

    # noinspection PyUnusedLocal,PyUnusedLocal
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__["y"] == 6

# Generated at 2022-06-21 12:40:35.552076
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    p = cached_property(lambda self: 'foo')

    class O:
        foo = p

    o = O()
    assert o.foo == 'foo'
    assert 'foo' in o.__dict__



# Generated at 2022-06-21 12:40:47.522575
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property

    """
    def testit():
        pass

    d = {"doc": "Testing", "func": testit}
    t = cached_property(**d)
    del d["func"]
    for k, v in d.items():
        assert t.__getattribute__(k) == v

    t = cached_property(testit)

    for x in range(4):
        assert t.__get__(t) is t

    testit.__doc__ = "Testing 2"
    t = cached_property(testit)
    assert t.__get__("") is t

    assert t.__get__("") is t

    # Unit test for method _wrap_in_coroutine of class cached_property
    # noinspection PyUnusedLocal



# Generated at 2022-06-21 12:40:56.734700
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import asyncio
    import unittest
    from unittest import mock

    class Foo:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    @asyncio.coroutine
    def async_foo(self):
        return self.x + 1

    foo = Foo()

    # Case 1: obj is None and function is a coroutine function.
    cp_mock = mock.Mock()
    cp_mock._wrap_in_coroutine.return_value = 1
    cp_mock.func.return_value = async_foo
    cp_mock.__get__(None, Foo)
    assert asyncio.iscoroutinefunction(cp_mock.func.return_value)
    cp_m

# Generated at 2022-06-21 12:40:59.379592
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit testing for constructor of class cached_property."""
    class Object(object):
        """Class to use for testing cached property."""

        @cached_property
        def test(self):
            """Property to test."""
            return True

    o = Object()
    o.test

# Generated at 2022-06-21 12:41:02.980730
# Unit test for constructor of class cached_property
def test_cached_property():
    import unittest

    class TestCachedProperty(unittest.TestCase):

        def setUp(self):
            class MyClass:

                def __init__(self):
                    self.x = 5

                @cached_property
                def y(self):
                    return self.x + 1

            self.obj = MyClass()

        def test_cached_property_value(self):
            self.assertEqual(self.obj.y, 6)

    unittest.main()

# Generated at 2022-06-21 12:41:12.907587
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y

    assert obj.y == 6
    obj.x = 3
    assert obj.y == 6
    del obj.y
    assert obj.y == 4

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        async def y(self):
            return self.x + 1

    obj = MyClass()
    asyncio.get_event_loop().run_until_complete(obj.y)

    assert obj.y == 6
    obj.x = 3
    assert obj.y == 6
    del obj.y

# Generated at 2022-06-21 12:41:24.340383
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import time
    import asyncio
    from asyncio import coroutine
    from functools import partial

    class TestClass:

        #: Use of a variable, as opposed to a constant, permits testing that
        #: the return value is computed once only.
        call_count = 0

        def __init__(self):
            """Test constructor"""
            self.x = 5

        # noinspection PyPep8Naming
        @cached_property
        def y(self):
            """Test property"""
            #: This value is computed only once
            self.call_count += 1
            return self.x + 1

        # noinspection PyPep8Naming
        @cached_property
        def z(self):
            """Test property with nested function"""
            def _z():
                """Nested function"""
                return

# Generated at 2022-06-21 12:41:30.110039
# Unit test for constructor of class cached_property
def test_cached_property():
    # instantiate class
    class C:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """Docstring"""
            return self.x + 1

    instance = C()
    assert instance.y == 6
    assert instance.__dict__['y'] == 6
    assert instance.y == 6


# Generated at 2022-06-21 12:42:12.061264
# Unit test for constructor of class cached_property
def test_cached_property():
    class cached_property_test_class:
        def __init__(self, func):
            self.__doc__ = getattr(func, "__doc__")
            self.func = func

        def __get__(self, obj, cls):
            if obj is None:
                return self

        @cached_property
        def cached_property_method(self): return 'Cached_property_method'

    my_cached_property_object = cached_property_test_class(
        cached_property_test_class.cached_property_method())
    assert my_cached_property_object.cached_property_method is not None

# Generated at 2022-06-21 12:42:13.851142
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property."""
    assert cached_property(lambda self: self)

# Generated at 2022-06-21 12:42:24.909944
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    .. versionadded:: 0.1.6

    Unit test for decorator :func:`cached_property`
    """
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert hasattr(MyClass.y, "__doc__")
    assert callable(MyClass.y)

    obj = MyClass()
    assert MyClass.y.__get__(None, obj) is MyClass.y

    assert obj.__dict__.get("y") is None
    assert obj.y == 6
    assert "y" in obj.__dict__
    assert obj.__dict__.get("y") == 6


# Generated at 2022-06-21 12:42:35.355604
# Unit test for constructor of class cached_property
def test_cached_property():
    value = 1


    class Test_Class(object):

        def __init__(self):
            self.count = 0

        @cached_property
        def cached_value(self):
            self.count += 1
            return value

    test_class = Test_Class()
    assert test_class.cached_value == 1
    assert test_class.count == 1
    assert test_class.cached_value == 1
    assert test_class.count == 1

    value = 2
    assert test_class.cached_value == 1
    assert test_class.count == 1
    assert test_class.cached_value == 1
    assert test_class.count == 1

    del test_class.cached_value
    assert test_class.cached_value == 2
    assert test_class.count == 2



# Generated at 2022-06-21 12:42:40.087026
# Unit test for constructor of class cached_property
def test_cached_property():
    """Generic tests for the :obj:`cached_property` object

    *New in version 0.2.0*

    """

    def fff(self):
        return self.x + 1

    obj = cached_property(fff)
    assert obj.__doc__ == fff.__doc__
    assert obj.func == fff

# Generated at 2022-06-21 12:42:43.192336
# Unit test for constructor of class cached_property
def test_cached_property():
    # Setup, Exercise, Verify
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:42:44.473220
# Unit test for constructor of class cached_property
def test_cached_property():
    assert isinstance(cached_property, type)


# Generated at 2022-06-21 12:42:55.969514
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        def _y(self):
            return self.x + 1

        # noinspection PyPep8Naming
        @cached_property
        def y1(self):
            return self.x + 1

        # noinspection PyPep8Naming
        @cached_property
        def y2(self):
            return self.x + 1

        # noinspection PyPep8Naming
        @cached_property
        def y3(self):
            return self.x + 1

        # noinspection PyPep8Naming
        @cached_property
        def y4(self):
            return self.x + 1

    # noinspection PyPep8Naming
    obj = MyClass()

    #

# Generated at 2022-06-21 12:43:03.369567
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit tests for constructor of class cached_property."""

    import unittest

    class cached_propertyTestCase(unittest.TestCase):
        """Unit test for :obj:`cached_property`."""

        def test_constructor(self):
            """Test constructor of class cached_property."""

            from flutils.decorators import cached_property

            @cached_property
            def _test(self):
                return True

            self.assertTrue(_test)

    unittest.main()

if __name__ == '__main__':
    test_cached_property()

# Generated at 2022-06-21 12:43:04.316474
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    return True


# Generated at 2022-06-21 12:44:29.838816
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from inspect import iscoroutinefunction, iscoroutine

    class A:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = A()

    # Test that self.func.__name__ is not in obj.__dict__
    assert self.func.__name__ not in obj.__dict__
    # Test that iscoroutinefunction returns False
    assert not iscoroutinefunction(self.func)
    # Test that self.func is called and its value is saved
    assert 6 == obj.__dict__[self.func.__name__]
    assert obj.y == obj.__dict__[self.func.__name__]  # y is cached
    obj.x = 2
    assert obj.y == obj.__

# Generated at 2022-06-21 12:44:40.710571
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""
    from flutils.misc import run_unittest

    def unit_test():
        """Unit test for method _cached_property__get__"""
        from unittest import mock

        class MyClass:
            """A test class"""

            def __init__(self, value):
                self.value = value

            def func(self):
                """The test function"""
                return self.value + 1

            @cached_property
            def my_cached_property(self):
                """The test cached_property"""
                return self.func()

        my_obj = MyClass(5)
        my_cached_property = cached_property(my_obj.func)
        my_cached_property.__get__(my_obj, MyClass)
       