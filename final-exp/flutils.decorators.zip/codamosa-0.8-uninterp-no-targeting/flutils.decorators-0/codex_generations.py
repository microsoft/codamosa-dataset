

# Generated at 2022-06-21 12:34:48.525194
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""
    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:34:49.599279
# Unit test for constructor of class cached_property
def test_cached_property():
    ...



# Generated at 2022-06-21 12:35:01.482461
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # Ensure that the base functionality is not lost by the coroutine
    # functionality.
    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Use `TestClass` to ensure that the base functionality is not lost by the
    # coroutine functionality.
    obj = TestClass()
    assert obj.y == 6

    # Use `TestClass` to ensure that the base functionality is not lost by the
    # coroutine functionality.
    del obj.y
    assert obj.y == 6

    # A class with coroutine methods.
    class TestCoroutineClass:
        def __init__(self):
            self.x = 5


# Generated at 2022-06-21 12:35:02.649599
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test cached_property
    """
    return None



# Generated at 2022-06-21 12:35:04.924485
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.__x = 5

        @cached_property
        def y(self):
            return self.__x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:35:12.729123
# Unit test for constructor of class cached_property
def test_cached_property():
    class TestClass(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.y == 6

    class TestClassAsync(object):
        def __init__(self):
            self.x = 5

        @cached_property
        async def y(self):
            await asyncio.sleep(0.01)
            return self.x + 1

    obj = TestClassAsync()
    loop = asyncio.get_event_loop()
    y = loop.run_until_complete(obj.y)
    assert y == 6

# Generated at 2022-06-21 12:35:16.402771
# Unit test for constructor of class cached_property
def test_cached_property():
    for name, obj in inspect.getmembers(cached_property):
        if name in ('__module__', '__doc__'):
            continue
        assert not inspect.isroutine(obj)


# Generated at 2022-06-21 12:35:21.415618
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        def __get__(self, obj, cls):
            return "cached_property test string"

    obj = MyClass()

    assert obj.x == 'cached_property test string'

# Generated at 2022-06-21 12:35:23.158482
# Unit test for constructor of class cached_property
def test_cached_property():
    obj = cached_property(lambda x: 5)
    assert obj is not None

# Generated at 2022-06-21 12:35:27.380440
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test method __get__ of class cached_property"""

    class TestClass(object):
        @cached_property
        def method(self):
            return 4
    t = TestClass()
    assert t.method == 4
    assert t.method == 4


# Generated at 2022-06-21 12:35:35.328323
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""

    import pytest

    # noinspection PyShadowingNames
    def get_prop(obj):
        return obj.prop

    # noinspection PyShadowingNames
    def get_prop_with_doc(obj, doc='doc'):
        return obj

    # noinspection PyShadowingNames
    def coroutine_get_prop(obj):
        return asyncio.sleep(1, obj)

    class Obj:

        @cached_property
        def prop(self):
            return 'prop'

        @cached_property
        def prop_with_doc(self):
            return self

    class AsyncObj:

        @cached_property
        def prop(self):
            return asyncio.sleep(1, 'prop')


# Generated at 2022-06-21 12:35:43.802059
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test for flutils.decorators.cached_property()
    """
    import pytest

    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6
    assert obj.y == 6

    obj.x = 10

    assert obj.y == 11
    assert obj.y == 11



# Generated at 2022-06-21 12:35:48.502089
# Unit test for constructor of class cached_property
def test_cached_property():

    import pytest
    from types import FunctionType

    with pytest.raises(TypeError):
        cached_property()

    @cached_property
    def fp():
        pass

    assert fp.__class__ is cached_property
    assert fp.func.__class__ is FunctionType



# Generated at 2022-06-21 12:35:52.406520
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    c = MyClass()
    assert c.y == 6

# Generated at 2022-06-21 12:36:01.829646
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from pathlib import Path

    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = Path(__file__)
            self.z = False

        @cached_property
        def y(self):
            return self.x.stat()

        @cached_property
        def w(self):
            if self.z:
                raise Exception()
            return self.x.stat()

    m = MyClass()

    assert m.y is m.y
    assert m.w is m.w
    m.z = True
    assert m.w is not m.w

# Generated at 2022-06-21 12:36:13.400159
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import asyncio
    import pytest
    import unittest.mock

    async def test_func(obj):
        obj.x = 5
        return obj.x + 1

    class TestClass:
        def __init__(self):
            self.loop = asyncio.get_event_loop()

    def func(obj):
        return 1

    def test_async(monkeypatch):
        monkeypatch.setattr(asyncio, 'iscoroutinefunction', lambda x: True)
        t = TestClass()
        t.test_func = cached_property(test_func)
        t.test_func()
        assert t.test_func._wrap_in_coroutine()


# Generated at 2022-06-21 12:36:14.853777
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test class cached_property"""



# Generated at 2022-06-21 12:36:26.104372
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property
    """

    from flutils.miscutils import (
        classproperty,
        class_or_instancemethod,
        instancemethod,
        classmethod,
        iscoroutinefunction,
        isclassmethod,
        isinstancemethod,
        )

    # noinspection PyClassHasNoInit
    class MyClass:
        """MyClass
        """

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """y
            """
            return self.x + 1

    obj = MyClass()

    assert obj.x == 5
    assert obj.y == 6
    assert obj.__dict__['y'] == 6
    assert obj.y is obj.x + 1
    assert obj.__dict__

# Generated at 2022-06-21 12:36:29.032725
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    return MyClass


# =============================================================================
# The contents of this file are in the public domain.
# -----------------------------------------------------------------------------

# Generated at 2022-06-21 12:36:40.111238
# Unit test for constructor of class cached_property
def test_cached_property():
    try:
        import asyncio
    except ImportError:
        return
    class Test(object):
        def __init__(self, message):
            self.message = message

        @cached_property
        @asyncio.coroutine
        def from_coro(self):
            yield from asyncio.sleep(0)
            return self.message

    t = Test('test')
    assert asyncio.iscoroutinefunction(t.from_coro)
    ret = asyncio.get_event_loop().run_until_complete(t.from_coro)
    assert ret == 'test'
    assert isinstance(ret, str)
    assert not asyncio.iscoroutinefunction(t.from_coro)

# Generated at 2022-06-21 12:36:46.893423
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class A(object):

        @cached_property
        def y(self):
            return self.x + 1

    a = A()
    a.x = 5
    y = a.y
    assert y == 6



# Generated at 2022-06-21 12:36:50.769321
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class my_class:  # noqa
        pass

    @cached_property
    def x():  # noqa
        return 7

    obj = my_class()
    v = obj.x
    assert v == 7



# Generated at 2022-06-21 12:36:55.046297
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property
    """

    class Cls:
        @cached_property
        def x(self):
            return 10

    assert Cls().x == 10

# Generated at 2022-06-21 12:36:58.827332
# Unit test for constructor of class cached_property
def test_cached_property():
    class A:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = A()
    assert obj.y == 6

# Generated at 2022-06-21 12:37:04.068960
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:37:10.611234
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import inspect
    import sys
    import pytest
    if sys.version_info >= (3, 8):
        pytest.skip('Deprecated. Use the built-in functools.cached_property.')

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.y == 6



# Generated at 2022-06-21 12:37:15.008115
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:37:18.190725
# Unit test for constructor of class cached_property
def test_cached_property():
    """ Unit test for cached_property

    :return: None
    """

    def testfunc():
        pass

    testprop = cached_property(testfunc)
    assert testprop.func is testfunc

# Generated at 2022-06-21 12:37:24.884740
# Unit test for constructor of class cached_property
def test_cached_property():

    def test_init():
        assert decorated_cached_property.__doc__ == "A property that caches its results."
        assert decorated_cached_property.func.__doc__ == "A property that caches its results."
        assert decorated_cached_property.func.__name__ == "cached_property"

    def test_doc():
        assert func.__doc__ == "A property that caches its results."

    def test_get():
        return

    # Tests
    test_init()
    test_doc()
    test_get()

# Generated at 2022-06-21 12:37:30.951134
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test case for method __get__ of class cached_property.
    """

    class Foo:

        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    obj = Foo(5)
    assert obj.y == 6
    obj.x = 10
    assert obj.y == 6


# Generated at 2022-06-21 12:37:38.584279
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class C:

        @cached_property
        def x(self):
            return []

    c1 = C()
    c2 = C()
    assert c1.x is c2.x


# Generated at 2022-06-21 12:37:39.917549
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass


# Generated at 2022-06-21 12:37:44.901962
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        """Class to test cached_property decorator."""

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """A property that is only computed once per instance."""
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:37:47.885602
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    my_obj = MyClass()
    assert my_obj.y == 6

# Generated at 2022-06-21 12:37:56.021576
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property."""
    pytest_disabled_reason = (
        "class cached_property is a "
        "wrapper of functools.cached_property and is tested in svg_to_pdf. "
        "The only purpose of cached_property is to provide a cached_property "
        "for < Python 3.8."
    )
    pytest.skip(pytest_disabled_reason)

# Generated at 2022-06-21 12:38:03.255506
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property


    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1


    assert hasattr(cached_property, "__doc__")
    obj = MyClass()
    assert obj.y == 6


if __name__ == '__main__':
    import pytest

    sys.exit(pytest.main([__file__]))

# Generated at 2022-06-21 12:38:08.368571
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__['y'] == 6



# Generated at 2022-06-21 12:38:09.621559
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass

# Generated at 2022-06-21 12:38:13.437749
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class ClassWithCachedProperty:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = ClassWithCachedProperty()
    assert obj.y == 6
    assert obj.__dict__ == {'x': 5, 'y': 6}



# Generated at 2022-06-21 12:38:18.822487
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property."""
    docstring = 'Test function used in unit tests'

    def myfunc(obj):
        return obj.x + 1

    myfunc.__doc__ = docstring
    testcp = cached_property(myfunc)
    assert isinstance(testcp.__doc__, str)
    assert testcp.__doc__ == docstring

# Generated at 2022-06-21 12:38:26.963268
# Unit test for constructor of class cached_property
def test_cached_property():

    assert callable(cached_property)

# Generated at 2022-06-21 12:38:32.475346
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Test public methods of :obj:`flutils.decorators.cached_property`
    """
    class Demo:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Demo()

    # make sure the values are correct
    assert obj.y == 6
    assert obj.__dict__['y'] == 6

# Generated at 2022-06-21 12:38:42.681517
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from .cached_property import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y

    assert obj.__dict__["y"] == 6
    assert obj.y == 6

    obj.x = 7
    assert obj.__dict__["y"] == 6
    assert obj.y == 6

    del obj.y
    assert "y" not in obj.__dict__
    assert obj.y == 8

    obj.x = 9
    assert obj.__dict__["y"] == 8
    assert obj.y == 8

    del obj.y
    assert "y" not in obj.__dict__
    assert obj.y == 10



# Generated at 2022-06-21 12:38:50.364027
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        def __getattribute__(self, item):
            if item == 'y':
                import os
                os.environ['FUTURE_TEST'] = '1'
                return MyClass.y

            return super().__getattribute__(item)

        @cached_property
        def y(self):
            return self.x + 1
    obj = MyClass()
    assert obj.y == 6
    assert obj.y == 6
    assert 'FUTURE_TEST' not in os.environ


# Generated at 2022-06-21 12:38:50.739482
# Unit test for constructor of class cached_property
def test_cached_property():
    pass

# Generated at 2022-06-21 12:38:54.577146
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


# Generated at 2022-06-21 12:38:58.312668
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property(lambda x: x).__doc__ == (
        "A property decorator that is only computed once per instance "
        "and then replaces itself with an ordinary attribute.\n\n"
        "Deleting the attribute resets the property.\n"
    )

# Generated at 2022-06-21 12:39:04.481638
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    """
    # noinspection PyUnusedLocal
    class MyClass:
        def __init__(self):
            self.x = 5

        # noinspection PyPep8Naming
        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:39:08.281808
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass(5)
    assert obj.y == 6

# Generated at 2022-06-21 12:39:12.053806
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class flutils.decorators.cached_property."""

    from flutils.decorators import cached_property
    from flutils.lib import MyClass

    obj = MyClass()
    assert obj.y == 8

# Generated at 2022-06-21 12:39:35.451594
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from pytest import raises

    class MyClass:
        def __init__(self):
            self.x = 5

    @cached_property
    def y(self):
        return self.x + 1

    myclass = MyClass()
    myclass.y = 100
    assert myclass.y == 100
    assert myclass.__dict__['y'] == 100
    raises(
        AttributeError,
        cached_property.__get__,
        MyClass,
        None
    )

# Generated at 2022-06-21 12:39:37.452776
# Unit test for constructor of class cached_property
def test_cached_property():
    # Create a dummy class
    class DummyClass:
        pass
    # Create an instance of this dummy class
    dummy_class = DummyClass()
    # Add a property to this dummy class
    dummy_class.__doc__ = 'A dummy class'
    dummy_class.x = 5
    dummy_class.y = 6

# Generated at 2022-06-21 12:39:38.018034
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass

# Generated at 2022-06-21 12:39:42.475865
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    # obj.y is 1st call
    result = obj.y
    assert 6 == result
    # obj.y is 2nd call, should be cached
    result = obj.y
    assert 6 == result


# Generated at 2022-06-21 12:39:53.368610
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test cached_property.__get__"""
    from .flutils_testing import capture

    # a function to decorate
    def func(x):
        return x + 1

    # decorate the function
    c = cached_property(func)

    # call __get__; should return a wrapped function
    assert c.__get__(None, None), cached_property
    # call __get__ on the wrapped function; should return the result of calling
    # the wrapped function
    assert c.__get__(1, None), 2
    # call __get__ on the wrapped function; should return the cached result
    assert c.__get__(1, None), 2

    obj = MyClass()
    assert obj.y, 6

    # create a class with a cached property.

# Generated at 2022-06-21 12:39:57.992546
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test the constructor of cached_property."""

    class Obj(object):

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """A cached property that adds 1 to x."""
            return self.x + 1
    assert Obj.y.__doc__ == "A cached property that adds 1 to x."
    assert Obj().y == 6

# Generated at 2022-06-21 12:40:06.897880
# Unit test for constructor of class cached_property
def test_cached_property():
    import unittest

    class ClassWithConstructor(unittest.TestCase):
        def __init__(self):
            self.x = 'x'

        @cached_property
        def y(self):
            return self.x + 'y'

    class ClassWithoutConstructor(unittest.TestCase):
        @cached_property
        def y(self):
            return self.x + 'y'

        @cached_property
        def x(self):
            return 'x'

    class ClassWithConstructorCoroutineMethod(unittest.TestCase):
        
        def __init__(self):
            self.x = 'x'
            
        @cached_property
        async def y(self):
            return self.x + 'y'


# Generated at 2022-06-21 12:40:15.114743
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    @cached_property
    def x(obj):
        return obj.kai + 1

    class SomeClass:
        def __init__(self):
            self.kai = 5

    obj1 = SomeClass()
    assert obj1.kai == 5
    obj1.x
    assert obj1.kai == 5
    assert obj1.x == obj1.kai + 1
    obj1.x = 77
    assert obj1.x == 77
    obj2 = SomeClass()
    assert obj2.x == 6
    assert obj1.x == 77



# Generated at 2022-06-21 12:40:18.300333
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:40:24.539338
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Verify results of constructor.

    :return: ``True`` if passed, ``False`` otherwise
    :rtype: bool
    """
    x = 5
    # noinspection PyUnusedLocal

    class MyClass:

        def __init__(self):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    return True

# Generated at 2022-06-21 12:41:06.779524
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Unit test for constructor of class :class:`~flutils.decorators.cached_property`
    """

    assert cached_property



# Generated at 2022-06-21 12:41:11.786608
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property


    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    assert obj.__dict__ == {'x': 5, 'y': 6}



# Generated at 2022-06-21 12:41:17.481263
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyTestClass:

        def __init__(self):
            self._x = 0

        @cached_property
        def x(self):
            self._x += 1
            return self._x

    obj = MyTestClass()
    assert obj.x == 1
    assert obj.x == 1

# Generated at 2022-06-21 12:41:27.112779
# Unit test for constructor of class cached_property
def test_cached_property():
    # noinspection PyShadowingNames
    def func(self):
        """"""

    # noinspection PyUnusedLocal
    def func2(self):
        """"""

    # noinspection PyShadowingNames
    def func3(self):
        """"""
        return self.x

    # noinspection PyShadowingNames
    def func4(self):
        """"""
        return self.x

    # noinspection PyShadowingNames
    def func5(self):
        """"""
        return self.x

    # noinspection PyShadowingNames
    def func6(self):
        """"""
        return self.x

    # noinspection PyShadowingNames
    def func7(self):
        """"""

    # noinspection PyShadowingNames

# Generated at 2022-06-21 12:41:31.641954
# Unit test for constructor of class cached_property
def test_cached_property():
    class A:
        def __init__(self):
            self._x = "foo"

        @cached_property
        def x(self):
            return self._x

    obj = A()
    assert obj.x == "foo"



# Generated at 2022-06-21 12:41:36.316935
# Unit test for constructor of class cached_property
def test_cached_property():
    class TestClass:
        pass

    tc = TestClass()
    assert not hasattr(tc, "a")
    tc.a = 1
    assert hasattr(tc, "a")
    setattr(tc, "a", 2)
    assert tc.a == 2
    delattr(tc, "a")
    assert not hasattr(tc, "a")


# Generated at 2022-06-21 12:41:45.451279
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""
    from unittest.mock import Mock

    # Test case: __get__ method of class cached_property for a class
    # with a synchronous function
    # ----------------------------------------------------------------
    class C:
        def __init__(self, x):
            self.x = x

        @cached_property
        def add_x(self):
            return self.x + 1

    c = C(5)
    assert c.add_x == 6

    # Test case: __get__ method of class cached_property for a class
    # with an asynchronous function
    # ----------------------------------------------------------------
    class C:
        def __init__(self, x):
            self.x = x


# Generated at 2022-06-21 12:41:50.018999
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test class constructor"""
    func = lambda t: None
    cp = cached_property(func)
    assert cp.func is func
    assert cp.__doc__ is None
    assert cp.__dict__ == {}



# Generated at 2022-06-21 12:41:51.236104
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property


# Generated at 2022-06-21 12:41:56.326539
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6
    assert isinstance(obj.y, int)
    assert obj.__dict__["y"] == 6



# Generated at 2022-06-21 12:43:26.848353
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class test_class:
        def __init__(self,foo):
            self.foo = foo

        @cached_property
        def bar(self):
            return self.foo + 'bar'

    my_obj = test_class('foo')
    assert my_obj.bar == 'foobar'

# Generated at 2022-06-21 12:43:35.952164
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Unit tests for the cached_property class
    """

    class MyClass:
        called = 0

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            self.called += 1
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6
    assert obj.called == 1
    obj.x = 10
    assert obj.called == 1
    assert obj.y == 6

    del obj.y
    assert obj.called == 2
    assert obj.y == 11

    # noinspection PyAttributeOutsideInit
    obj.y = 15
    assert obj.called == 2
    assert obj.y == 15

    del obj.y
    assert obj.called == 3
    assert obj.y == 11


# Unit test

# Generated at 2022-06-21 12:43:45.756087
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """ Test for method __get__ of class cached_property.
    """
    class TestClass:
        def __init__(self, *args, **kwargs):
            self.counter = 0

        @cached_property
        def double(self):
            self.counter += 1
            return 2

        @cached_property
        def triple(self):
            self.counter += 1
            return 3

        @cached_property
        def square(self):
            self.counter += 1
            return 4

        @cached_property
        def quad(self):
            self.counter += 1
            return 9

        @cached_property
        def pent(self):
            self.counter += 1
            return 25

        @cached_property
        def cume(self):
            self.counter += 1

# Generated at 2022-06-21 12:43:54.407512
# Unit test for constructor of class cached_property
def test_cached_property():
    import unittest.mock

    class A(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """I am a property"""
            return self.x + 1

    a = A()

    assert a.y == 6
    assert a.y == 6
    assert a.y == 6
    assert a.y == 6
    assert a.y == 6

    assert a.__dict__ == {'x': 5, 'y': 6}

    assert A.y.__doc__ == "I am a property"



# Generated at 2022-06-21 12:43:57.641475
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Test cached_property
    class Dummy:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    dummy = Dummy()
    assert dummy.y == 6
    dummy.x = 6
    assert dummy.y == 6



# Generated at 2022-06-21 12:44:04.386713
# Unit test for constructor of class cached_property
def test_cached_property():
    from operator import __eq__
    from unittest import TestCase

    class A(TestCase):

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    A()
    __eq__(A().__dict__, {'x': 5, 'y': 6})


# Generated at 2022-06-21 12:44:09.960161
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""

    def func():
        return 5

    class MyClass:
        @cached_property
        def x(self):
            return func()

    my_obj = MyClass()
    my_obj.x

    assert "x" in my_obj.__dict__
    assert my_obj.__dict__["x"] == func()

    my_obj = MyClass()
    my_obj.__dict__["x"] = 6
    assert my_obj.x == 6

# Generated at 2022-06-21 12:44:17.168423
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property
    from flutils.decorators import get_cached_property_value
    @cached_property
    def my_cached_property():
        return None
    assert my_cached_property.__get__(None, None) == my_cached_property
    assert my_cached_property.__get__(object(), None) is None
    assert get_cached_property_value(object(), my_cached_property) is None


# Generated at 2022-06-21 12:44:24.710851
# Unit test for constructor of class cached_property
def test_cached_property():
    import flutils
    from flutils.decorators import cached_property

    # noinspection PyPep8Naming
    class CachedPropertyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    o = CachedPropertyClass()
    assert o.y == 6
    assert o.__dict__['y'] == 6

    with flutils.CaptureStdIO() as captured:
        print(o.y)

    assert captured.out == "6\n"

# Generated at 2022-06-21 12:44:26.833222
# Unit test for constructor of class cached_property
def test_cached_property():

    # Does not throw exception
    cached_property(lambda: None)

    # Does not throw exception
    cached_property(lambda cls: cls)


if __name__ == '__main__':
    import pytest

    pytest.main([__file__])