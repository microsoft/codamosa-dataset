

# Generated at 2022-06-21 12:34:41.705873
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Foo:
        def __init__(self, x: int):
            self.x = x

        @cached_property
        def a(self):
            return self.x

    foo = Foo(2)
    foo.a

# Generated at 2022-06-21 12:34:54.162053
# Unit test for constructor of class cached_property
def test_cached_property():
    import pytest
    import functools
    import asyncio
    from flutils.decorators import cached_property

    def test_1():
        """Test :class:`flutils.decorators.cached_property`."""

        class MyClass:
            def __init__(self):
                self.x = 5

            @cached_property
            def y(self):
                return self.x + 1

        obj = MyClass()
        assert obj.y == 6

    def test_2():
        """Test :class:`flutils.decorators.cached_property`."""

        class MyClass:
            def __init__(self):
                self.x = 5


# Generated at 2022-06-21 12:35:04.803534
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""

    # pylint:disable=C0115,C0116
    import sys
    import time

    from pytest import fixture
    from io import StringIO
    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 17

        @cached_property
        def y(self):
            return self.x + 1

    def test_async(_call, _method, _capfd, _loop):
        out, err = _call.pytest.capfd.readouterr()
        assert out == ""
        assert err == ""

        _method.y()

        out, err = _capfd.readouterr()
        assert out == ""
        assert err == ""

        _loop

# Generated at 2022-06-21 12:35:06.299436
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""



# Generated at 2022-06-21 12:35:10.187151
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property"""

    # noinspection PyProtectedMember
    def _test_cached_property(func):
        """

        Args:
            func:

        Returns:

        """
        return cached_property(func)

    return _test_cached_property

# Generated at 2022-06-21 12:35:15.664930
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest
    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    obj.x = 6
    assert obj.y == 6



# Generated at 2022-06-21 12:35:22.784468
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    #
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    #
    obj = MyClass()
    obj.y
    assert hasattr(obj, "y")

    #
    del obj.y
    assert not hasattr(obj, "y")



# Generated at 2022-06-21 12:35:29.431594
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Tests :meth:`cached_property.__get__`.

    *New in version 0.2.0*
    """
    from flutils.decorators import cached_property

    class MyClass:
        @cached_property
        def y(self):
            return 5

    obj = MyClass()
    assert obj.y == 5


if __name__ == '__main__':
    import sys
    sys.exit(pytest.main(args=[__file__]))

# Generated at 2022-06-21 12:35:33.383440
# Unit test for constructor of class cached_property
def test_cached_property():
    class ExampleClass:  # Class to test cached_property
        def __init__(self, val):
            self.val = val

        @cached_property
        def my_property(self):
            return self.val

        @cached_property
        def my_property2(self):
            return self.val + 1
    ex = ExampleClass(4)
    assert ex.my_property == 4
    assert ex.my_property2 == 5

# Generated at 2022-06-21 12:35:39.871208
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class Class:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class_ = Class()

    assert(class_.y == 6)
    assert(class_.y == 6)

    class_.x = 10

    assert(class_.y == 6)



# Generated at 2022-06-21 12:35:53.584070
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import unittest
    import unittest.mock

    class Test(unittest.TestCase):

        def setUp(self):
            class MyClass:

                def __init__(self):
                    self.x = 5

                @cached_property
                def y(self):
                    return self.x + 1

            self.MyClass = MyClass
            self.__class__.obj = unittest.mock.MagicMock(spec=self.MyClass)
            self.func = unittest.mock.MagicMock(__name__="y")

        def test___get__(self):
            self.__class__.obj.__dict__["y"] = "string"
            obj = self.MyClass()
            obj.y

        def test__wrap_in_coroutine(self):
            self

# Generated at 2022-06-21 12:35:57.245277
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass():
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:36:00.451704
# Unit test for constructor of class cached_property
def test_cached_property():
    """ Unit test for constructor of class cached_property.
    """
    from .funcutils import _test_func
    _test_func(cached_property)

# Generated at 2022-06-21 12:36:00.950922
# Unit test for constructor of class cached_property
def test_cached_property():
    pass

# Generated at 2022-06-21 12:36:07.645824
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class McTest:
        def __init__(self, to_return):
            self._to_return = to_return

        @cached_property
        def test(self):
            return self._to_return

    obj = McTest('test')
    assert obj.test == 'test'
    assert obj._to_return == 'test'



# Generated at 2022-06-21 12:36:14.595927
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest import TestCase, main

    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class TestCachedProperty(TestCase):

        def test_property(self):
            obj = MyClass()
            self.assertEqual(obj.y, 6)

    main()


if __name__ == '__main__':
    test_cached_property()

# Generated at 2022-06-21 12:36:19.438189
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    obj.x = 3
    assert obj.y == 6


# Generated at 2022-06-21 12:36:27.228745
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test cached_property class constructor.  This must not be run
    as part of the Python package test suite.  This is to ensure
    that the cached_property decorator is working at the Python
    level.
    """

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__ == {'x': 5, 'y': 6}



# Generated at 2022-06-21 12:36:40.111316
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property.

    :return: None.
    :raises: AssertionError if any unit test fails.
    """
    from collections import namedtuple
    from flutils.decorators import cached_property

    @cached_property
    def test_property(self):
        return id(self)

    Test = namedtuple('Test', ['property'])

    obj = Test(property=None)

    old_id = id(obj)
    del obj
    obj = Test(property=None)
    assert old_id == id(obj), \
        'id(obj) == {0!r}, expected {1!r}'.format(id(obj), old_id)


# Generated at 2022-06-21 12:36:44.296805
# Unit test for constructor of class cached_property
def test_cached_property():
    class Test(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    temp = Test()
    assert temp.y == 6



# Generated at 2022-06-21 12:36:50.534826
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert isinstance(obj.y == 6, bool)
    assert isinstance(obj.y == 6, bool)
    assert isinstance(obj.y == 6, bool)

# Generated at 2022-06-21 12:36:57.740387
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestClass:

        def __init__(self):
            self.set_attribute_to_true()

        @cached_property
        def get_attribute(self):
            return "attribute"

        def set_attribute_to_true(self):
            self.get_attribute = True

    test_obj = TestClass()
    assert not test_obj.get_attribute



# Generated at 2022-06-21 12:37:09.251496
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    my_obj = MyClass()
    assert my_obj.y == 6
    assert my_obj.__dict__['y'] == 6

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        async def y(self):
            return self.x + 1

    my_obj = MyClass()
    assert my_obj.y == 6
    assert my_obj.__dict__['y'] == 6
    loop = asyncio.get_event_loop()
    res = loop.run_until_complete(my_obj.y)
    assert res == 6
    assert my_obj

# Generated at 2022-06-21 12:37:12.860652
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class TestClass:

        def __init__(self):
            self.x = 5

        # noinspection PyUnusedLocal
        def method_returning_self(self):
            return self

        @cached_property
        def prop(self):
            return self.x + 1

    obj = TestClass()
    assert isinstance(obj.prop, int)
    assert obj.prop == 6
    obj.x = 10
    assert obj.prop == 6

# Generated at 2022-06-21 12:37:19.315871
# Unit test for constructor of class cached_property
def test_cached_property():
    # Tests to make sure that the constructor
    # for cached_property works properly

    # Setup
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    # Exercise
    y = obj.y

    # Verify
    assert y == 6



# Generated at 2022-06-21 12:37:24.777412
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class Test:

        def __init__(self, x):
            self.x = x

        @cached_property
        def foo(self):
            return self.x*2

    t = Test(2)

    assert(t.foo == 4)
    assert(t.foo == 4)
    t.x = 4
    assert(t.foo == 8)
    del t.foo
    assert(t.foo == 8)

# Generated at 2022-06-21 12:37:28.712567
# Unit test for constructor of class cached_property
def test_cached_property():
    """A unit test for the constructor of class cached_property.

    *New in version 0.4.0*
    """
    from functools import cached_property as python_cached_property
    assert cached_property is python_cached_property

# Generated at 2022-06-21 12:37:32.410206
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:37:39.291207
# Unit test for constructor of class cached_property
def test_cached_property():
    class Foo:
        def __init__(self, xyzzy):
            self.xyzzy = xyzzy

        @cached_property
        def __test(self):
            return self.xyzzy + 1

    foo = Foo(10)
    assert foo.__test == 11
    foo.__test = 12
    assert foo.__test == 12
    del foo.__test
    assert foo.__test == 11
    assert foo.__dict__['__test'] == 11

# Generated at 2022-06-21 12:37:41.089285
# Unit test for constructor of class cached_property
def test_cached_property():
    with pytest.raises(TypeError):
        cached_property()

# Generated at 2022-06-21 12:37:52.922097
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property

    *New in version:* 0.2.0

    """
    class Foo:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    foo = Foo()
    assert foo.y == 6
    assert foo.__dict__['y'] == foo.y


if __name__ == '__main__':
    # Test setup
    import sys
    sys.path.append('../flutils')

    # Run tests
    import pytest
    (good, bad) = pytest.main(['--capture=no', 'test_cached_property.py'])
    # The following lines are not run when running this file as a program
    assert good == 0  # test failed

# Generated at 2022-06-21 12:37:57.986113
# Unit test for constructor of class cached_property
def test_cached_property():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """This is my docstring."""
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:38:10.265502
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class
    :class:`~flutils.decorators.cached_property`
    """
    import logging
    import unittest

    from flutils.tests.helpers import log_test_function

    class TestClass(unittest.TestCase):
        # logging setup
        log_test_function()
        log = logging.getLogger("TestClass")

        class TestClass:
            def __init__(self):
                self.x = 5

            @cached_property
            def y(self):
                return self.x + 1

        def test___get__(self):
            obj = self.TestClass()
            value = obj.y
            self.assertEqual(value, 6)

    # run tests
    unittest.main()



# Generated at 2022-06-21 12:38:11.414527
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property(lambda self: self.x)

# Generated at 2022-06-21 12:38:15.574266
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    assert obj.x == 5
    assert obj.__dict__['y'] == 6

# Generated at 2022-06-21 12:38:18.615069
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    # Check that the property is cached
    obj.y
    obj.__dict__.pop('y', None)
    obj.y

# Generated at 2022-06-21 12:38:24.085618
# Unit test for constructor of class cached_property
def test_cached_property():
    property_value = 'Unchanged'

    class ClassWithCachedProperty:

        @cached_property
        def property(self):
            return property_value

    class_with_cached_property = ClassWithCachedProperty()
    assert class_with_cached_property.property == 'Unchanged'
    property_value = 'Changed'
    assert class_with_cached_property.property == 'Unchanged'



# Generated at 2022-06-21 12:38:30.364953
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6     # Initialize
    assert obj.y == 6     # Already initialized
    del obj.y             # Remove cached property
    assert obj.y == 6     # Initialize again

    class MyClass:

        def __init__(self):
            self.x = 5

        def y(self):
            return self.x + 1

    obj = MyClass()
    with pytest.raises(AttributeError):
        obj.y

# Generated at 2022-06-21 12:38:39.763860
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Create test object
    class Test(object):

        @cached_property
        def test_property(self):
            return 1

    # Initialize test object
    obj = Test()

    # Object should have the test_property attribute
    assert hasattr(obj, 'test_property')
    # and should be of the cached_property class
    assert isinstance(obj.test_property, cached_property)
    # and should be 1
    assert obj.test_property == 1

    # Assign a value to the test_property attribute
    obj.test_property = 2

    # Object should have the test_property attribute
    # and should have a value of 2
    assert obj.test_property == 2

    # Delete the test_property attribute
    del obj.test_property

    # Object should not have the test_property attribute

# Generated at 2022-06-21 12:38:44.530741
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


# Generated at 2022-06-21 12:38:56.769700
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""

    # Given
    response = 'c1'
    x = 5

    class ClassOne:
        def __init__(self):
            self.x = x

        @cached_property
        def get_response(self):
            return response

    # When
    obj1 = ClassOne()
    obj2 = ClassOne()

    # Then
    assert obj1.get_response == obj2.get_response == response
    assert f"<bound method ClassOne.{'get_response'} of {obj1}>" == str(type(obj1.get_response))

# Generated at 2022-06-21 12:38:59.809335
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


# Generated at 2022-06-21 12:39:04.531860
# Unit test for constructor of class cached_property
def test_cached_property():
    class A:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = A()
    assert obj.y == 6

# Generated at 2022-06-21 12:39:09.373847
# Unit test for constructor of class cached_property
def test_cached_property():
    def test_method_1(obj):
        return 5

    def test_method_2(obj):
        return 10

    def test_method_3(obj):
        return 15

    cls_1 = cached_property(test_method_1)
    assert cls_1.__doc__ == getattr(test_method_1, "__doc__")
    assert cls_1.func == test_method_1

    cls_2 = cached_property(test_method_2)
    assert cls_2.__doc__ == getattr(test_method_2, "__doc__")
    assert cls_2.func == test_method_2

    cls_3 = cached_property(test_method_3)

# Generated at 2022-06-21 12:39:17.306557
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest.mock import Mock

    cached_property_class = Mock(spec_set=cached_property)
    cached_property_mock = cached_property(cached_property_class)

    args = [cached_property_mock, 'foo']
    cached_property_mock.__get__(*args)

    args = [cached_property_mock, 'foo', 'bar']
    cached_property_mock.__get__(*args)

    cached_property_class.assert_any_call('foo')
    cached_property_class.assert_any_call('foo', 'bar')
    assert cached_property_class.call_count == 2

# Generated at 2022-06-21 12:39:21.815693
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y


if __name__ == '__main__':
    test_cached_property()

# Generated at 2022-06-21 12:39:32.640620
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():  # noqa: D103
    from flutils import decorators as decs

    # Non-asyncio case
    class SampleClass1:
        def __init__(self, x=0):
            self.x = x

        @decs.cached_property
        def y(self):
            return self.x + 1

        def __repr__(self):
            return f"{self.__class__.__name__}(x={self.x})"

    obj1 = SampleClass1(x=5)

    # The @cached_property overrides __get__ and returns the value of the
    # attribute referenced by the @cached_property decorated method.
    assert obj1.y == 6
    assert hasattr(obj1, "y")
    assert obj1.__dict__["y"] == 6

    # Calling

# Generated at 2022-06-21 12:39:41.256565
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class TestClass(object):

        def __init__(self, value):
            self.value = value

        @cached_property
        def double(self):
            return self.value * 2

    # Test
    obj = TestClass(2)
    assert obj.double == 4
    # Set the cached property
    obj.double = 8
    # Now the cached property is an ordinary attribute
    assert obj.double == 8
    del obj.double
    # Ensure the cached property is still a property
    assert obj.double == 4
    # Delete the cached property again
    del obj.double
    # ValueError: 'double' property is missing
    with pytest.raises(ValueError):
        assert obj.double == 4
    # Set the cached property
    obj.double = 8
    # Now the cached property is an ordinary attribute
   

# Generated at 2022-06-21 12:39:44.339496
# Unit test for constructor of class cached_property
def test_cached_property():
    obj = cached_property(lambda x: x * 2)
    assert obj.__doc__ is None
    assert obj.func(4) == 8

    obj = cached_property(test_cached_property)
    assert obj.__doc__ == test_cached_property.__doc__
    assert obj.func is test_cached_property

# end of file

# Generated at 2022-06-21 12:39:54.759535
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest import TestCase, mock

    class TestCachedProperty(TestCase):
        def test_init(self):
            func = mock.MagicMock(side_effect=Exception("foo"))
            cd = cached_property(func)
            self.assertEqual(cd.func, func)
            self.assertTrue(cd.__doc__ is None)

            func.assert_not_called()

            func.return_value = "foo"
            cd = cached_property(func)
            self.assertEqual(cd.__doc__, "foo")
            self.assertEqual(cd.func, func)

    test_cached_property()


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 12:40:20.551506
# Unit test for constructor of class cached_property
def test_cached_property():

    import unittest

    class TestCase(unittest.TestCase):

        def test_cached_property(self):

            class MyClass:

                def __init__(self):
                    self.x = 5

                @cached_property
                def y(self):
                    return self.x + 1

            obj = MyClass()
            y = obj.y
            self.assertEqual(y, 6)

    unittest.main()


if __name__ == '__main__':
    test_cached_property()

# Generated at 2022-06-21 12:40:25.925514
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property."""
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    obj.x = 17
    assert obj.y == 6

# Generated at 2022-06-21 12:40:31.105437
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class :obj:`cached_property`."""

    from flutils.decorators import cached_property
    from flutils.decorators import cached_property as testme

    assert cached_property.__doc__ == testme.__doc__
    assert cached_property.__module__ == testme.__module__



# Generated at 2022-06-21 12:40:40.161205
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method ``__get__`` of class ``cached_property``."""

    # ********************************************************************
    # *  No cached property attribute exists at the start of the call    *
    # ********************************************************************
    # noinspection PyClassHasNoInit
    class Foo:
        """Foo"""
        # Reference set() for sets in Python 3.4
        sets = {}

        # noinspection PyMissingTypeHints
        def __init__(self):
            """Creates an instance of :obj:`~test_cached_property___get__.Foo`."""
            self.x = 5

        @cached_property
        def y(self):
            """Calculate the value of property ``y``."""
            return self.x + 1


# Generated at 2022-06-21 12:40:45.900436
# Unit test for constructor of class cached_property
def test_cached_property():
    class TestClass(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert isinstance(obj, TestClass)
    assert obj.y == 6
    assert obj.y == 6
    assert callable(obj.y)


test_cached_property()

# Generated at 2022-06-21 12:40:51.215158
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # setup
    class MyClass:
        def __init__(self):
            self.x = 5
        @cached_property
        def y(self):
            return self.x + 1
    obj = MyClass()

    # expected
    expected = 6

    # run test and assert
    assert obj.y == expected

    # cleanup
    del obj


# Generated at 2022-06-21 12:40:55.790592
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # Arrange
    class TestClass(object):

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Act
    obj = TestClass()
    result = TestClass.__dict__['y'].__get__(obj)

    # Assert
    assert result == 6

# Generated at 2022-06-21 12:41:01.620518
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import Mock, patch

    mock = Mock()
    mock_get = patch.object(mock, '__get__')
    mock_get.return_value = 'mocked'
    mocked = mock()
    patch.stopall()
    assert mocked == 'mocked'

# Generated at 2022-06-21 12:41:05.860982
# Unit test for constructor of class cached_property
def test_cached_property():
    my_class = cached_property

    # test format of output
    assert isinstance(my_class, type(cached_property.__init__))

    # test __doc__ returns expected output
    assert my_class.__doc__ == cached_property.__init__.__doc__

# Generated at 2022-06-21 12:41:10.411133
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils._testing import run_doctest

    results = run_doctest('flutils.decorators', module=__name__)
    assert results.failures == 0


if __name__ == '__main__':
    import pytest

    pytest.main([__file__])

# Generated at 2022-06-21 12:42:02.919721
# Unit test for constructor of class cached_property
def test_cached_property():
    class Foo:
        @cached_property
        def bar(self):
            "This is a docstring"
            print("Computing!")
            return 42

    foo = Foo()
    # Docstring should be copied over
    assert foo.bar.__doc__ == "This is a docstring"
    # Foo.bar is a cached_property instance
    assert isinstance(Foo.bar, cached_property)
    # Compute and cache the value
    assert foo.bar == 42
    # Subsequent accesses use the cached value
    assert foo.bar == 42
    # foo.bar is no longer a cached_property instance
    assert not isinstance(foo.bar, cached_property)
    # Deleting foo.bar deletes the cached value
    del foo.bar
    # Accessing foo.bar recomputes the value
    assert foo

# Generated at 2022-06-21 12:42:13.207739
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method ``__get__`` of class :obj:`cached_property`.

    *New in version 0.2.0*

    """

    class MyClass:

        def __init__(self, x=5):
            self.x = x

        @cached_property
        def y(self):
            """This is the cached property ``y``."""
            return self.x + 1

    obj = MyClass()
    obj.__dict__.pop("y", None)
    assert obj.y == 6
    assert isinstance(obj.y, int)
    assert obj.__dict__["y"] == 6
    assert obj.y == 6



# Generated at 2022-06-21 12:42:21.795522
# Unit test for constructor of class cached_property
def test_cached_property():
    class ValueHolder:
        def __init__(self, x=0):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    obj = ValueHolder()
    obj.x = 5

    try:
        assert obj.y == 6
    except:
        assert obj.y == 0

    obj.x = 10

    try:
        assert obj.y == 11
    except:
        assert obj.y == 0


if __name__ == '__main__':
    test_cached_property()

# Generated at 2022-06-21 12:42:30.948348
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method cached_property.__get__."""

    import asyncio
    import unittest.mock

    from flutils.decorators import cached_property

    class MyClass:

        @cached_property
        def my_method(self):
            return 'a'

    def test_method(obj):
        return obj.my_method

    class TestCase(unittest.TestCase):

        def test_cached_property___get__(self):
            """Unit test for method cached_property.__get__."""

            # run the test twice to verify that the value is cached
            for i in range(2):
                obj = MyClass()
                value = test_method(obj)
                self.assertEqual(value, 'a')

# Generated at 2022-06-21 12:42:34.742771
# Unit test for constructor of class cached_property
def test_cached_property():
    @cached_property
    def property_name(self):
        return 1
    assert property_name.__doc__ is None
    assert property_name.func(None) == 1

# Generated at 2022-06-21 12:42:37.068008
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property.__name__ == "cached_property"
    assert cached_property.__doc__ is not None



# Generated at 2022-06-21 12:42:41.475882
# Unit test for constructor of class cached_property
def test_cached_property():
    """ Unit test for the constructor of class cached_property

    """
    class MyClass:
        def __init__(self):
            self.x = 12

        @cached_property
        def y(self):
            return self.x + 1

    assert MyClass().y == 13
    assert MyClass().y == 13


# Generated at 2022-06-21 12:42:43.189710
# Unit test for constructor of class cached_property
def test_cached_property():
    obj = cached_property("MyProperty")
    assert obj.__doc__ is None
    assert obj.func == "MyProperty"



# Generated at 2022-06-21 12:42:49.749428
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    unit test for constructor of class cached_property
    """
    class Test(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    t = Test()
    assert t.y == 6


if __name__ == '__main__':
    test_cached_property()

# Generated at 2022-06-21 12:42:53.725054
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__ == {'x': 5, 'y': 6}

# Generated at 2022-06-21 12:44:42.666334
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property

    Test Cases:

        1. Test that func is called once to get value and that value is
           updated to dict of obj.

        2. Test that func is called when value is deleted from obj's dict.
    """
    # mock obj
    class Foo:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    # Test Case #1
    f = Foo(5)
    assert f.y == 6
    assert f.__dict__['y'] == 6

    # Test Case #2
    del f.__dict__['y']
    assert f.y == 6
    assert f.__dict__['y'] == 6