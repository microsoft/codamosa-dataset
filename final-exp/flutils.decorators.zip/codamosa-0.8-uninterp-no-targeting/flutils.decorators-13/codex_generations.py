

# Generated at 2022-06-21 12:34:42.403738
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class :obj:`cached_property`."""

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:34:47.921709
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # noinspection DuplicatedCode
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:34:59.756168
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Tests for method ``__get__`` of class ``cached_property``.
    """

    async def async_gen():
        """Generator function.

        This should be converted to a coroutine
        """
        x = 0
        while True:
            x += 1
            await asyncio.sleep(0.5)
            yield x

    class Test:
        """Test class.
        """

        def __init__(self):
            self._x = 5

        @cached_property
        def x(self):
            """Return the value of ``_x``.
            """
            return self._x

        @cached_property
        def y(self):
            """Return the result of ``x + 1``.
            """
            return self.x + 1


# Generated at 2022-06-21 12:35:03.996643
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1
    # End class MyClass

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:35:13.196183
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import mock

    def func(val: int) -> int:
        if val > 0:
            return val + 1

    class MyClass:
        def __init__(self, val: int):
            self.val = val

        @cached_property
        def cached_property_method(self) -> int:
            return func(self.val)

    # Check that the property is cached.
    val, expected = 1, 2
    obj = MyClass(val)
    assert obj.cached_property_method == expected

    # Verify func was called once when accessing the property.
    assert func.call_count == 1

    # Verify that accessing the property is cached.
    for i in range(3):
        assert obj.cached_property_method == expected
        assert func.call_count == 1

    # Verify

# Generated at 2022-06-21 12:35:16.345126
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit tests for the class :obj:`~flutils.decorators.cached_property`
    """

    obj = CachedPropertyTest()

    assert obj.y == 6

# Generated at 2022-06-21 12:35:21.882088
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """ Unittest for cached property.
    """
    class MyClass:
        @cached_property
        def y(self):
            self.y = self.x + 1
            return self.y

    obj = MyClass()
    obj.x = 10
    result = obj.y
    assert result == 11

# Generated at 2022-06-21 12:35:27.129083
# Unit test for constructor of class cached_property
def test_cached_property():
    @cached_property
    def x():
        "I am the 'x' property"
        return 5

    assert x.__doc__ == "I am the 'x' property"
    assert x.__name__ == 'x'
    assert x.__module__ == 'test_decorators'
    assert x() == 5


# Generated at 2022-06-21 12:35:34.329750
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Create the unit test instance of class cached_property
    class MyClass1:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Get a property as an attribute.
    obj = MyClass1()
    assert obj.y == 6
    #
    # Get a property as an unbound method.
    obj2 = MyClass1()
    assert obj2.__class__.y.__get__(obj2) == 6
    #
    # Get a property as a bound method.
    assert obj.y == 6

    # Create the unit test instance of class cached_property
    class MyClass2:

        def __init__(self):
            self.x = 5


# Generated at 2022-06-21 12:35:46.074924
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import sys
    import pytest
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    answer = 6
    if sys.version_info >= (3, 8):
        # Python >= 3.8
        assert obj.__dict__ == {}
    else:
        # Python < 3.8
        assert obj.__dict__ == {'_y': None}
    assert obj.y == answer
    if sys.version_info >= (3, 8):
        # Python >= 3.8
        assert obj.__dict__ == {'y': answer}

# Generated at 2022-06-21 12:35:59.908362
# Unit test for constructor of class cached_property
def test_cached_property():
    def testfunc(self):
        return lambda x: x + 1

    testfunc.__name__ = 'x'

    cp = cached_property(testfunc)

    assert testfunc.__doc__ == cp.__doc__
    assert testfunc == cp.func
    assert cached_property.__doc__ == cached_property.__init__.__doc__

    class testclass:
        def __init__(self):
            self.x = 5

        def testfunc(self):
            return self.x + 1

    testclass.testfunc.__name__ = 'x'

    b = testclass()

    assert b.x == cp.__get__(b, testclass)
    assert testclass.testfunc(b) == cp.__get__(b, testclass)

# Generated at 2022-06-21 12:36:06.356783
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    def myfunc():
        pass

    cp = cached_property(myfunc)

    obj = cp.__get__(None, None)
    assert obj is cp

    class MyClass:
        def __init__(self):
            self.val = 0

        @cp
        def myprop(self):
            self.val += 1
            return self.val

    obj = MyClass()
    assert obj.myprop == 1
    assert obj.myprop == 1

    obj = MyClass()
    assert obj.myprop == 1
    assert obj.myprop == 1

    obj.__dict__.pop('myprop', None)

    assert obj.__dict__.get('myprop') is None
    assert obj.myprop == 1
    assert obj.myprop == 1

    assert obj.myprop == 1

# Generated at 2022-06-21 12:36:08.651674
# Unit test for constructor of class cached_property
def test_cached_property():
    obj = cached_property(lambda: 0)
    assert type(obj.__doc__) is str

# Generated at 2022-06-21 12:36:16.350233
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Test when obj is None

    class TestClass1:

        @cached_property
        def test_method(self):
            return self.data

        def __init__(self, data):
            self.data = data

    c = TestClass1('testing')
    assert c.test_method == 'testing'

    # Test when obj is not None

    class TestClass2:
        @cached_property
        def test_method(self):
            return self.data

        def __init__(self, data):
            self.data = data

    c = TestClass2('testing')
    assert c.test_method == 'testing'

# Generated at 2022-06-21 12:36:20.490015
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Tests the operation of `cached_property.__get__` method. """

    class MyClass:
        x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:36:28.212575
# Unit test for constructor of class cached_property
def test_cached_property():
    # noinspection PyUnusedLocal
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            self.x += 1
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.z == 7
    assert obj.x == 6
    assert obj.y == 6

    del obj.y
    assert obj.y == 6

    del obj.z
    assert obj.z == 8

# Generated at 2022-06-21 12:36:35.152250
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Unit test for class cached_property
    """
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    if obj.y == 6:
        assert True
    else:
        raise AssertionError('Expected True. Returned False.')
    return

# Generated at 2022-06-21 12:36:40.738980
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property
    """

    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:36:47.480192
# Unit test for constructor of class cached_property
def test_cached_property():
    class A:

        def __init__(self):
            self.a = 0

        @cached_property
        def b(self):
            return self.a + 1

    a = A()
    assert a.b == 1
    a.a = 5
    assert a.b == 1  # Returned cached value


# Generated at 2022-06-21 12:36:49.969241
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:36:57.114555
# Unit test for constructor of class cached_property
def test_cached_property():
    """ Unit testing for class cached_property."""

    def test(x):
        return x + 5

    obj = cached_property(test)
    x = 6
    assert obj.func(x) == 11



# Generated at 2022-06-21 12:37:03.187162
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    def x():
        pass

    assert cached_property(x).__get__(None) == x
    assert cached_property(x).__get__(None).__doc__ == x.__doc__
    assert cached_property(x).__get__(object()).__doc__ == x.__doc__



# Generated at 2022-06-21 12:37:06.723792
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.prop = 4
        @cached_property
        def my_property(self):
            return self.prop + 1
    assert MyClass().my_property == 5


# Generated at 2022-06-21 12:37:10.413348
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:37:13.433238
# Unit test for constructor of class cached_property
def test_cached_property():
    cache = cached_property(lambda t: "Cached")
    assert 'Cached' == cache.__get__(None, None)


# noinspection PyPep8Naming

# Generated at 2022-06-21 12:37:24.349011
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Unit test for constructor of class cached_property
    """
    from flutils.decorators import cached_property
    import pytest
    from testfixtures import compare
    from unittest import mock

    # Test cached_property with a simple function
    @cached_property
    def func(obj):
        return 5

    compare(mock.call(), func.__get__(object, object))
    compare(5, func.__get__(object, object))

    # Test cached_property as an async function
    @cached_property
    async def async_func(obj):
        return 5

    compare(mock.call(), async_func.__get__(object, object))
    compare(5, async_func.__get__(object, object))

# Generated at 2022-06-21 12:37:35.017802
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    def _test(obj):

        assert obj.y == 6
        del obj.y
        assert obj.y == 6

    obj = MyClass()
    _test(obj)

    obj = MyClass()
    asyncio.ensure_future(_test(obj))
    asyncio.get_event_loop().run_forever()
    asyncio.get_event_loop().close()

    obj = MyClass()
    asyncio.ensure_future(_test(obj))
    loop = asyncio.new_event_loop()
    loop.run_forever()
    loop.close()
    assert loop.is_closed()


# Unit

# Generated at 2022-06-21 12:37:46.288519
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """pytest for cached_property's method __get__."""

    #
    # Assert that only once instance of a cached_property
    # is computed.
    #

    class MyClass:
        """Class definition for testing cached_property."""

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """Property definition for testing cached_property."""
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    obj.x = 6
    assert obj.y == 6

    #
    # Assert that deleting the attribute resets the property.
    #

    del obj.y
    assert obj.y == 7

    #
    # Assert cached_property works as a class attribute.
    #


# Generated at 2022-06-21 12:37:49.711806
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.y == 6



# Generated at 2022-06-21 12:38:00.842188
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class TestClass(object):

        def __init__(self):
            self.x = 10

        @cached_property
        def y(self):
            return self.x + 1

    # Test for @cached_property
    @cached_property
    def w(self):
        return self.x + 1

    # Test for @asynccached_property
    @asynccached_property
    def v(self):
        return self.x + 1

    @asynccached_property
    @asyncio.coroutine
    def async_v(self):
        return self.x + 1

    test_instance = TestClass()

    assert isinstance(test_instance.y, int)

    with pytest.raises(AttributeError):
        test_instance.y = 5


# Generated at 2022-06-21 12:38:08.674746
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test __get__ method of cached_property class.
    """

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    exp = 6
    res = obj.y
    assert res == exp



# Generated at 2022-06-21 12:38:16.218744
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import MagicMock

    class MockAndDict:
        def __init__(self):
            self.__dict__ = {}
            self.x = 5
            self.y = MagicMock()

    ms = MockAndDict()
    cached_property_instance = cached_property(ms.y)
    cached_property_instance.__get__(ms, MockAndDict)
    ms.y.assert_not_called()
    cached_property_instance.__get__(ms, MockAndDict)
    ms.y.assert_called_once()

# Generated at 2022-06-21 12:38:20.766238
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    return obj.y



# Generated at 2022-06-21 12:38:23.909264
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:38:32.150680
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Unit tests for the :obj:`~flutils.decorators.cached_property` class.

    *New in version 0.2.0*
    """
    class TestClass:

        def __init__(self):
            self.count = 0

        @cached_property
        def increments_count(self):
            self.count += 1
            return self.count

    tc = TestClass()

    expected = 1
    actual = tc.increments_count
    assert expected == actual

    expected = 1
    actual = tc.increments_count
    assert expected == actual

    expected = 1
    actual = tc.count
    assert expected == actual

# Generated at 2022-06-21 12:38:34.419342
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass(5)
    expected = 6
    actual = obj.y
    assert expected == actual



# Generated at 2022-06-21 12:38:38.951313
# Unit test for constructor of class cached_property
def test_cached_property():
    class AnObject:
        @cached_property
        def x(self):
            return 1

    a = AnObject()
    x1 = a.x
    x2 = a.x
    assert x1 == x2


if __name__ == '__main__':
    # test_cached_property()
    pass

# Generated at 2022-06-21 12:38:49.559164
# Unit test for method __get__ of class cached_property

# Generated at 2022-06-21 12:38:50.991694
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert MyClass().y == 6

# Generated at 2022-06-21 12:38:57.558100
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test for method __get__ of class :obj:`cached_property`."""

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    # Test for normal attributes
    obj.x = 8
    assert obj.y == 9

    # Test that the attribute was cached
    obj.x = 50
    assert obj.y == 9

    # Test that deleting the attribute resets the property
    del obj.y
    assert obj.y == 6

    # Test class level attribute
    MyClass.x = 15
    assert obj.y == 16

    # Test class level attribute after changing instance attribute
    obj.x = 7
    assert obj.y == 16

    # Test that class

# Generated at 2022-06-21 12:39:05.245569
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """ Unit test for method __get__ of class cached_property """

    def foo(obj):
        return 'bar'

    obj = object()
    result = cached_property(foo).__get__(obj)
    assert isinstance(result, object) and not isinstance(result, cached_property)

# Generated at 2022-06-21 12:39:10.751038
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property."""
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y



# Generated at 2022-06-21 12:39:19.259268
# Unit test for constructor of class cached_property
def test_cached_property():

    # Create a dummy class
    class MyClass:
        def __init__(self, val=0, *, incr=1):
            self.val = val
            self.incr = incr

        @cached_property
        def func(self):
            return self.val + self.incr

    # Check the docstring
    assert MyClass.func.__doc__ is None
    assert MyClass.func._cached_property__doc__ is None

    # Check the expected value from the function
    obj = MyClass(2, incr=17)
    assert obj.func == 19

    # Check the value from the property
    assert obj.func == 19

    # Check for instance docstring
    assert MyClass.func.__doc__ is None

    # Test a coroutine version

# Generated at 2022-06-21 12:39:28.768733
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Tests that the method :func:`~cached_property.__get__` returns the value
    of the property and replaces itself with an ordinary attribute.

    """

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """
            A cached property.

            """
            return self.x + 1

    obj = MyClass()

    # Test that the method returns the value of the property
    assert obj.y == 6

    # Test that the property is replaced with the ordinary attribute
    assert obj.__dict__['y'] == 6

# Generated at 2022-06-21 12:39:38.186561
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""

    from flutils.decorators import cached_property
    from unittest.mock import MagicMock

    class TestClass:

        def __init__(self):
            self.foo = None

        @cached_property
        def foo(self):
            return "bar"

    # Test first call if cache is empty
    tc = TestClass()
    assert tc.foo == "bar"
    assert isinstance(tc.foo, str)

    # Test second call if cache is not empty
    tc = TestClass()
    assert tc.foo == "bar"
    assert isinstance(tc.foo, str)

    # Test if cache (in form of function with obj passed as first
    # argument, i.e. self) is in the instance object
    tc.foo

# Generated at 2022-06-21 12:39:41.315221
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        @cached_property
        def get_value(self):
            """
            :return: a value
            """
            return 1

    obj = MyClass()
    assert obj.get_value == 1
    # value will be cached
    assert obj.get_value == 1

# Generated at 2022-06-21 12:39:43.662928
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:39:48.298640
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for :class:`~flutils.decorators.cached_property`."""
    from flutils.decorators import cached_property

    class Foo:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    foo = Foo(1)
    assert foo.x == 1
    assert foo.y == 2
    foo.x = 10
    assert foo.x == 10
    assert foo.y == 2  # cached_property uses the original value
    del foo.y
    assert foo.x == 10
    assert foo.y == 11  # now it recalculates the property



# Generated at 2022-06-21 12:39:53.763811
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property
    """

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:40:03.036731
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from datetime import datetime as dt
    from unittest import mock

    # __doc__ set?
    def f(o):
        pass
    f.__doc__ = "func doc"
    cp = cached_property(f)
    assert cp.__doc__ == "func doc"
    # wrap_in_coroutine called?
    @mock.patch('flutils.decorators.cached_property._wrap_in_coroutine')
    def test(mock_winc):
        class Foo:
            @cached_property
            def bar(o):
                pass
        f = Foo()
        f.bar
        assert mock_winc.called
    test()
    # wrap_in_coroutine returns correct value?

# Generated at 2022-06-21 12:40:08.830609
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class Foo:

        @cached_property
        def bar(self):
            return 42

    foo = Foo()

    assert foo.bar == 42
    assert foo.__dict__['bar'] == 42



# Generated at 2022-06-21 12:40:13.929795
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property

    *New in version 0.2.0*

    """

    # Test for property y
    class Test:
        x = 5
        @cached_property
        def y(self):
            """Return self.x + 1."""
            return self.x + 1

    test = Test()
    assert test.y == 6

    # Test for property z
    class Test:
        x = 5
        @cached_property
        def z(self):
            """Return self.x + 1."""
            return self.x + 1

    test = Test()
    assert test.z == 6

    # Test for property iscoroutinefunction
    class Test:
        x = 5

# Generated at 2022-06-21 12:40:24.117468
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import unittest

    class TestSuccess(unittest.TestCase):

        def setUp(self) -> None:
            self.obj = Test()

        def test_return_self__when_obj_is_none(self):
            self.assertIsInstance(Test.y, cached_property,
                                  'Class method __get__ of class cached_property did not return self when '
                                  'obj is None.')

        def test_return_obj_dict__when_obj_is_not_none(self):
            self.assertEqual(self.obj.y, 6,
                             'Class method __get__ of class cached_property did not return obj.__dict__[self.func.__name__]'
                             ' when obj is not None.')


# Generated at 2022-06-21 12:40:27.064770
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:40:32.153764
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class Test:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        async def z(self):
            return self.x + 2

    test = Test()

    assert test.y == 6
    # assert test.z == 7


# Generated at 2022-06-21 12:40:35.453608
# Unit test for constructor of class cached_property
def test_cached_property():
    @cached_property
    def foo(self):
        return 1

    assert foo.__doc__ is None
    assert foo.func is None



# Generated at 2022-06-21 12:40:44.038888
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    The method __get__ of the class cached_property will return the value of
    the decorated method once called. It will not call again the original
    method on subsequent calls.
    """
    class TestClass:

        @cached_property
        def test_method(self):
            return self.x + 1

    obj = TestClass()
    obj.x = 5
    assert obj.test_method == 6
    obj.x = 6
    assert obj.test_method == 6


# Generated at 2022-06-21 12:40:51.558972
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass1:
        """Test cached_property with __get__.
        """

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj1 = MyClass1()
    assert obj1.y == 6
    obj1.y = 7
    assert obj1.y == 7
    del obj1.y
    assert obj1.y == 6
    assert MyClass1.y.__doc__ == "Test cached_property with __get__."



# Generated at 2022-06-21 12:40:55.163886
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """ Unit test for method __get__ of class cached_property. """

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:40:58.050630
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest.mock import patch, call

    with patch('flutils.decorators.cached_property') as mock_cached_property:
        from flutils.decorators import cached_property
        assert mock_cached_property.called



# Generated at 2022-06-21 12:41:04.918252
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from .testing import CachedPropertyTest

    CachedPropertyTest().test_cached_property___get__()

    print('=====\n')

    CachedPropertyTest().test_cached_property___get__()



# Generated at 2022-06-21 12:41:10.353447
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class C:
        def __init__(self, val):
            self._val = val

        def __eq__(self, other):
            return self._val == other._val

        @cached_property
        def prop(self):
            return self._val

    c = C(5)
    a, b = c.prop, c.prop
    assert a is b

# Generated at 2022-06-21 12:41:15.210546
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import sys
    if sys.version_info[:2] < (3, 8):
        class MyClass:

            def __init__(self):
                self.x = 5

            @cached_property
            def y(self):
                return self.x + 1

        obj = MyClass()
        assert obj.y == 6
        assert hasattr(obj, 'y')
        del obj.y
        assert not hasattr(obj, 'y')



# Generated at 2022-06-21 12:41:16.324264
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property(lambda x: x).func

# Generated at 2022-06-21 12:41:25.851905
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest import TestCase
    from unittest.mock import patch

    class Test(TestCase):
        @cached_property
        def test(self, obj):
            return 7

        def test_get(self):
            # Test get method.
            obj = Test()
            assert obj.test == 7

    test = Test()
    # Test value assignment
    assert test.test == 7
    # Test overwriting of value
    test.test = 5
    assert test.test == 5

    # Test constructor
    with patch('flutils.decorators.cached_property.__init__') as mocked:
        assert mocked.call_count == 0
        cached_property(test)
        assert mocked.call_count == 1

# Generated at 2022-06-21 12:41:27.057145
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # type: () -> None
    pass

# Generated at 2022-06-21 12:41:29.733540
# Unit test for constructor of class cached_property
def test_cached_property():
    prop = cached_property(lambda self: self)
    assert prop.func(prop) is prop
    assert prop.__doc__ == '<lambda>'

# Generated at 2022-06-21 12:41:35.695746
# Unit test for constructor of class cached_property
def test_cached_property():
    """ Unit tests for class cached_property
    
    """

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    y = obj.y

    assert y == 6

    obj.__dict__.pop(obj.y)
    y = obj.y

    assert y == 6



# Generated at 2022-06-21 12:41:39.471491
# Unit test for constructor of class cached_property
def test_cached_property():

    class A:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    a = A()
    assert a.y == 6
    assert isinstance(a.y, int)



# Generated at 2022-06-21 12:41:47.483897
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import asyncio
    from flutils.decorators import cached_property

    class TestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        async def z(self):
            await asyncio.sleep(0.2)
            return self.x + 1

    obj = TestClass()

    assert obj.y == 6

    # Verify that cache worked
    obj.x = 6
    assert obj.y == 6

    # Verify that deleting attribute resets property
    del obj.y
    assert obj.y == 7

    # Verify that awaitable coroutine works
    loop = asyncio.get_event_loop()
    future = asyncio.ensure_future(obj.z)
    loop

# Generated at 2022-06-21 12:42:00.289294
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property
    from .testutils import TestBase
    from .testutils import TestClass

    class TestClass2(TestClass):
        def __init__(self, a, b, x=None):
            self.a = a
            self.b = b
            self.x = x

        @cached_property
        def result(self):
            return self.a + self.b + self.x

    test_obj = TestClass2(2, 3, 5)
    assert(test_obj.result == 10)
    test_obj.a = 4
    assert(test_obj.result == 10)  # cached


# Generated at 2022-06-21 12:42:03.271107
# Unit test for constructor of class cached_property
def test_cached_property():
    class Example:
        @cached_property
        def y(self):
            return self.x + 1

    example = Example()
    example.x = 5
    assert example.y == 6

# Generated at 2022-06-21 12:42:09.552824
# Unit test for constructor of class cached_property
def test_cached_property():
    class Foo:
        @cached_property
        def bar(self):
            return "bar"
    assert Foo.bar.__doc__ is None
    assert Foo().bar == "bar"
    assert Foo().bar == "bar"
    del Foo().bar
    assert Foo().bar == "bar"
    assert Foo().bar == "bar"


# Generated at 2022-06-21 12:42:21.031803
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyCacheClass:
        def __init__(self):
            self.x = 1
            self.y = 2

        # noinspection PyUnusedLocal
        @cached_property
        def calc(self):
            print(f"calc called")
            return self.x + self.y

    obj = MyCacheClass()

    assert hasattr(obj, 'calc')
    assert hasattr(obj, 'calc')

    # Delete attribute, so calc must be called again
    delattr(obj, 'calc')
    assert hasattr(obj, 'calc')

    # Set attribute to another value, so calc must be called again
    obj.calc = "Another value"
    assert hasattr(obj, 'calc')

    # Test caching of coroutine

# Generated at 2022-06-21 12:42:29.586623
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test constructor for class cached_property."""

    # Test for:
    #   return self.func(obj)
    # Code
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    # Test for:
    #   return self.func(obj)
    # Code
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        async def y(self):
            return self.x + 1

    @asyncio.coroutine
    def test():
        obj = MyClass()
        assert (await obj.y) == 6

    loop = asyncio.get_

# Generated at 2022-06-21 12:42:35.713740
# Unit test for constructor of class cached_property
def test_cached_property():
    @cached_property
    def location():
        return 'San Diego'

    obj = object()
    assert location is not obj.__dict__.get('location')
    assert location.__doc__ is obj.__dict__.get('location').__doc__
    assert location == 'San Diego'
    assert obj.__dict__['location'] == 'San Diego'

# Generated at 2022-06-21 12:42:44.439998
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""

    class MyClass:

        def __init__(self):
            self.x = None
            self.y = None
            self.z = None
            self.n = None

        @cached_property
        def p(self):
            return [5, 6, 7]

        @cached_property
        def q(self):
            return {'p': None, 'q': None}

        @cached_property
        def r(self):
            return {'p': {'foo': 'bar'}, 'q': None}

    obj = MyClass()

    assert obj.p == [5, 6, 7]

    obj.p.append(8)
    assert obj.p == [5, 6, 7, 8]


# Generated at 2022-06-21 12:42:53.137162
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from .utils import Obj

    class Class(Obj):

        def __init__(self, x):
            super().__init__()
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    obj = Class(5)
    assert obj.y == 6
    obj.x = 6
    assert obj.y == 7
    def setx(x):
        obj.x = x

    obj.watch(setx, 'x')

    obj.x = 7
    assert obj.y == 8


# Generated at 2022-06-21 12:42:57.588997
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert isinstance(obj.y, int)



# Generated at 2022-06-21 12:42:58.809041
# Unit test for constructor of class cached_property
def test_cached_property():
    with pytest.raises(TypeError):
        cached_property()

# Generated at 2022-06-21 12:43:12.748266
# Unit test for constructor of class cached_property
def test_cached_property():
    from .asserts import assert_equal

    class Test(object):

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert_equal(Test().y, 6)

# Generated at 2022-06-21 12:43:14.517057
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property
    assert cached_property.__doc__



# Generated at 2022-06-21 12:43:24.204846
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method ``__get__`` of class :class:`cached_property`."""

    class Base:

        @cached_property
        def x(self):
            return 5

    class BaseChild(Base):

        def __init__(self):
            super().__init__()
            self.x = 10

        def __eq__(self, other):
            if self.x != other.x:
                return False
            return True

    base = Base()
    expected = base.x
    actual = base.__dict__[base.x.__name__]
    assert expected == actual
    assert base.x == actual

    base_child = BaseChild()
    expected = base_child.x
    actual = base_child.__dict__[base_child.x.__name__]

# Generated at 2022-06-21 12:43:31.968054
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method cached_property.__get__ of class cached_property.
    """
    from flutils.decorators import cached_property

    class C(object):
        def __init__(self, value=None):
            if value is None:
                self._val = 3
            else:
                self._val = value

        @cached_property
        def value(self):
            """This is a cached property."""
            return self._val

    c = C()
    assert c.value == c.value

    # Test the __doc__ attribute
    assert C.value.__doc__ == "This is a cached property."

    c2 = C(5)
    assert c2.value == c2.value

    # Test the __doc__ attribute

# Generated at 2022-06-21 12:43:43.469525
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property

    Note:

        This does not check that decorator works with the @ syntax. This
        tests only the underpinnings with the __get__ method.
    """

    class foo:

        def __init__(self):
            self.x = 5
            self.y = 0
            self.z = 0
            self.a = 0

        def get_y(self):
            self.y += 1
            return self.y

        def get_z(self):
            self.z += 1
            return self.z

        @asyncio.coroutine
        def get_a(self):
            yield from asyncio.sleep(0.1)
            self.a += 1
            return self.a


# Generated at 2022-06-21 12:43:54.133563
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import asyncio

    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return "abc"

        @cached_property
        def z(self):
            return self.x + 1

        @cached_property
        async def a(self):
            await asyncio.sleep(1)
            return self.x + 1

    obj = TestClass()

    # Scenario 1: access a cached_property attribute that is not a coroutine

    # Run
    obj.y

    # Check
    assert obj.__dict__["y"] == "abc"

    # Scenario 2: access a cached_property attribute that is a coroutine

    # Run
    obj.z

    # Check
    assert obj.__dict__["z"] == 6

# Generated at 2022-06-21 12:43:58.546183
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.y == 6



# Generated at 2022-06-21 12:44:04.953347
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property
    from collections.abc import Mapping

    class testclass(Mapping):
        def __init__(self):
            self.x = 5
        @cached_property
        def y(self):
            return self.x + 1

    test = testclass()
    return test.y


# Generated at 2022-06-21 12:44:12.158215
# Unit test for constructor of class cached_property
def test_cached_property():
    class Foo(object):

        @cached_property
        def foo(self):
            """hello"""
            return 42

        @foo.setter
        def foo(self, value):
            """hello"""
            return 23

        @foo.deleter
        def foo(self):
            """hello"""
            return

    foo = Foo()
    assert foo.foo == 42
    assert foo.foo == 42
    assert foo.__dict__ == {'foo': 42}
    foo.foo = 23
    assert foo.foo == 42
    assert foo.__dict__ == {'foo': 42}
    del foo.foo
    assert foo.foo == 42
    assert foo.__dict__ == {'foo': 42}
    assert foo.__class__.foo.__doc__ == "hello"



# Generated at 2022-06-21 12:44:23.313600
# Unit test for constructor of class cached_property
def test_cached_property():
    obj = cached_property(lambda: 56)