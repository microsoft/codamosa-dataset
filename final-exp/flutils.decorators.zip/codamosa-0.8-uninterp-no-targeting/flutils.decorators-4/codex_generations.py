

# Generated at 2022-06-21 12:34:45.588550
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import patch
    from unittest.mock import Mock

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    with patch('flutils.decorators.cached_property.asyncio') as m:

        # use the class cached_property as a class method
        assert isinstance(MyClass.y, cached_property)

        # use the class cached_property as an instance method
        assert obj.y == 6

        # add another instance method
        obj.z = cached_property(obj.y)

        # test that asyncio.iscoroutinefunction() was called
        assert m.iscoroutinefunction.called

        # mock out the cor

# Generated at 2022-06-21 12:34:50.456770
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    del obj.y
    assert obj.y == 6

# Generated at 2022-06-21 12:34:52.129196
# Unit test for constructor of class cached_property
def test_cached_property():
    with pytest.raises(TypeError):
        cached_property()



# Generated at 2022-06-21 12:34:58.670446
# Unit test for constructor of class cached_property
def test_cached_property():
    import pytest
    from functools import cached_property as builtin_cached_property

    class Foo:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Foo()
    res = obj.y
    assert res == 6

    # Teardown
    del obj
    del res

# Generated at 2022-06-21 12:35:03.927237
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class :obj:`cached_property`

    This function is called automatically by
    :func:`flutils.tests.doctest_module`

    There are actually no assertions in this test.  It exists
    simply to make sure that the constructor works without error.

    """

    class MyClass():
        def __init__(self):
            self.foo = 1

        @cached_property
        def bar(self):
            """A property that returns 42."""
            return 42

    x = MyClass()
    y = x.bar
    del x.bar

# Generated at 2022-06-21 12:35:13.126682
# Unit test for constructor of class cached_property
def test_cached_property():
    class TestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Test 1:  ensure the property is called the first time it's accessed
    assert TestClass().y == 5 + 1

    # Test 2:  ensure the cached property is returned
    assert TestClass().y == 5 + 1

    # Test 2.1:  delete the attribute and confirm it is reset
    obj = TestClass()
    del obj.y
    assert obj.y == 5 + 1

    # Test 3:  make sure the cached property is returned for that instance
    assert obj.y == 5 + 1

    # Test 4:  make sure the cached property persists for that instance
    x = TestClass().y
    assert x == 5 + 1

    # Test

# Generated at 2022-06-21 12:35:23.065795
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        @asyncio.coroutine
        def z(self):
            return self.x * 2

    obj = MyClass()
    assert obj.y == 6
    assert asyncio.iscoroutine(obj.z)
    assert asyncio.iscoroutine(obj.z())
    assert isinstance(obj.z(), asyncio.Future)

# Generated at 2022-06-21 12:35:27.935810
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Unit test for cached_property.

    Returns
    -------
    None.
    """

    class Foo:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    foo = Foo()
    assert foo.y == 6

# Generated at 2022-06-21 12:35:32.708436
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test :obj:`~flutils.decorators.cached_property`"""

    class TestCached:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestCached()
    assert obj.y == 6
    obj.x = 10
    assert obj.y == 11


if __name__ == "__main__":
    test_cached_property()

# Generated at 2022-06-21 12:35:39.555555
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit tests for `cached_property`"""
    class A:
        @cached_property
        def x(self):
            return 5
    a = A()
    assert a.x == 5
    a.x = 4
    assert a.x == 4
    del a.x
    assert a.x == 5
    assert isinstance(a.x, int)
    assert isinstance(A().x, int)


# Generated at 2022-06-21 12:35:46.746442
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    result = obj.y

    assert result == 6


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 12:35:59.035800
# Unit test for constructor of class cached_property
def test_cached_property():

    class MyClass:

        def __init__(self, x=5):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x + 2

    obj = MyClass()
    result = obj.x == 5 and obj.y == 6 and obj.z == 7

    to_delete = ['x', 'y', 'z']
    for i in to_delete:
        delattr(obj, i)

    result &= not hasattr(obj, 'x') and not hasattr(obj, 'y') and not hasattr(
        obj, 'z')

    assert result, f'Error: cached_property constructor failed with {obj!r}'

# Generated at 2022-06-21 12:36:05.549537
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import MagicMock
    from unittest.mock import patch

    class MockClass:
        @cached_property
        def y(self):
            return self.x + 1

    obj = MockClass()
    obj.x = 11111

    m1 = MagicMock()

    @patch.object(MockClass, '__get__', m1, create=True)
    @patch.object(obj, '__dict__', {'x': 11111})
    def test():
        obj.y
    test()

    # assert that func is set as an attribute in the instance's __dict__
    assert m1.call_count == 0



# Generated at 2022-06-21 12:36:15.673734
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test constructor of class cached_property."""

    class CachedPropertyClass:

        def __init__(self):
            self.done = False

        @cached_property
        def lazy_property(self):
            self.done = True
            return 42

    obj = CachedPropertyClass()
    # noinspection PyTypeHints
    assert obj.__dict__ == {}
    # noinspection PyTypeHints
    assert not obj.done
    assert obj.lazy_property == 42
    # noinspection PyTypeHints
    assert obj.__dict__ == {'lazy_property': 42, 'done': True}
    assert obj.lazy_property == 42
    # noinspection PyTypeHints
    assert obj.__dict__ == {'lazy_property': 42, 'done': True}

# Generated at 2022-06-21 12:36:19.426099
# Unit test for constructor of class cached_property
def test_cached_property():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:36:23.876118
# Unit test for constructor of class cached_property
def test_cached_property():
    class DummyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    dummy_obj = DummyClass()
    assert dummy_obj.y == 6


# Generated at 2022-06-21 12:36:25.182290
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def func(self):
            return self.x + 1

    assert MyClass.func.__doc__ is not None



# Generated at 2022-06-21 12:36:25.734254
# Unit test for constructor of class cached_property
def test_cached_property():
    obj = cached_property(None)
    assert obj

# Generated at 2022-06-21 12:36:31.110655
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method ``__get__`` of class ``cached_property``."""

    class A:

        def __init__(self) -> None:
            self.x = 5

        @cached_property
        def y(self) -> int:
            return self.x + 1

    obj = A()

    assert obj.y == 6
    assert obj.__dict__['y'] == 6



# Generated at 2022-06-21 12:36:35.046315
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert MyClass().y == 6

# Generated at 2022-06-21 12:36:38.214279
# Unit test for constructor of class cached_property
def test_cached_property():
    class Foo:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Foo()
    assert obj.y == 6

# Generated at 2022-06-21 12:36:42.425651
# Unit test for constructor of class cached_property
def test_cached_property():
    class Foo:
        def __init__(self):
            pass

        @cached_property
        def bar(self):
            return 'bar'

    assert Foo().bar == 'bar'
    assert Foo().bar == 'bar'


# Generated at 2022-06-21 12:36:51.759326
# Unit test for constructor of class cached_property
def test_cached_property():
    """ Test cached_property """
    import asyncio
    import asyncio.coroutines
    import flutils.decorators

    class TestClass:

        @flutils.decorators.cached_property
        def coroutine(self):
            return asyncio.sleep(.5)

    instance = TestClass()
    assert instance.coroutine.__class__ is asyncio.Future
    assert instance.coroutine.__class__ is not asyncio.coroutines.CoroWrapper

    class TestClass:

        @flutils.decorators.cached_property
        def coroutine(self):
            yield from asyncio.sleep(.5)

    instance = TestClass()
    assert instance.coroutine.__class__ is asyncio.Future

# Generated at 2022-06-21 12:36:57.787981
# Unit test for constructor of class cached_property
def test_cached_property():
    class TestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    tc = TestClass()
    assert tc.y == 6
    assert tc.__dict__['y'] == 6



# Generated at 2022-06-21 12:37:09.252008
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method ``cached_property.__get__``."""

    from flutils.decorators import cached_property

    obj = type('Foo', (object,), {})()

    # Test for None check

    def test_func():
        pass

    @cached_property
    def cached_func():
        return 12

    assert cached_func.__get__(None, obj) is cached_func
    assert test_func.__get__(None, obj) == test_func

    # Test for ``__dict__`` set with non-coroutine function

    @cached_property
    def _get_my_val():
        return 12

    assert obj._get_my_val == 12

    # Test for ``__dict__`` set with coroutine function


# Generated at 2022-06-21 12:37:14.796037
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Unit test for :class:`cached_property`.

    """
    import pytest
    from inspect import iscoroutinefunction

    from .decorators import cached_property as _cached_property

    @_cached_property
    def iscoroutinefunction(self):
        return iscoroutinefunction(self)

    with pytest.raises(TypeError, match='descriptor \'iscoroutinefunction\' of .* requires a .* object'):
        iscoroutinefunction

    class TestClass:
        @_cached_property
        def iscoroutinefunction(self):
            return iscoroutinefunction(self)

    assert TestClass.iscoroutinefunction.__doc__ == iscoroutinefunction.__doc__

    test_obj = TestClass()
    assert test_obj.iscoroutinefunction is False

# Generated at 2022-06-21 12:37:24.920219
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # cached_property - __get__, the obj is not None
    class CPClass:

        def __init__(self):
            self.x = 1

        @cached_property
        def y(self):

            return self.x + 1

    obj = CPClass()
    assert obj.y == 2

    # cached_property - __get__, the obj is None
    @cached_property
    def yy(self):

        return 1

    assert yy.__class__ == cached_property

    # cached_property - __get__, the obj is not None and the
    #   func is a coroutine
    class CPClass2:

        def __init__(self):
            self.x = 1

        # noinspection PyUnusedLocal

# Generated at 2022-06-21 12:37:28.867594
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:37:32.563161
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit tests for the method cached_property.__get__"""
    # Note that the following is tested in the test_cached_property_method
    # test, but I've got to make sure that the method is there!



# Generated at 2022-06-21 12:37:37.640705
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # noinspection PyUnusedLocal
    class MyClass:
        def __init__(self, a):
            self.a = a

        @cached_property
        def my_property(self):
            return self.a * 10

    obj = MyClass(5)
    assert obj.a == 5
    assert obj.my_property == 50
    with pytest.raises(AttributeError):
        obj.my_property = 500

# Generated at 2022-06-21 12:37:48.897876
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Test cached_property method __get__ works for non-coroutine function

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


@pytest.mark.unit
@pytest.mark.asyncio
async def test_cached_property___get___with_coroutine():
    # Test cached_property method __get__ works for coroutine function

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        async def y(self):
            return self.x + 1

    obj = MyClass()
    assert await obj.y == 6



# Generated at 2022-06-21 12:38:00.583745
# Unit test for constructor of class cached_property
def test_cached_property():
    from . import cached_property
    import sys
    import platform

    obj = cached_property

    assert hasattr(obj, "__init__")
    assert hasattr(obj, "__get__")
    assert hasattr(obj, "_wrap_in_coroutine")
    assert hasattr(obj, "__doc__")

    assert cached_property.__name__ == "cached_property"
    assert cached_property.__module__ == "flutils.decorators"

    assert obj.__init__ is not obj.__get__
    assert obj.__init__ is not obj._wrap_in_coroutine
    assert obj.__get__ is not obj._wrap_in_coroutine

    assert obj.__doc__ != ""

    assert platform.python_implementation() != "PyPy"
    assert platform.python_implementation()

# Generated at 2022-06-21 12:38:10.866314
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import asyncio
    from flutils.decorators import cached_property

    class TestCache:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestCache()
    assert obj.y == 6

    class TestCacheAsync:

        def __init__(self):
            self.x = 5

        @cached_property
        @asyncio.coroutine
        def y(self):
            return self.x + 1

    obj = TestCacheAsync()
    assert asyncio.ensure_future(obj.y).result() == 6

# Generated at 2022-06-21 12:38:15.499835
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        @cached_property
        def x(self):
            return 5

    assert isinstance(MyClass.x, cached_property)
    my_obj = MyClass()
    assert my_obj.x == 5
    assert not isinstance(my_obj.x, cached_property)



# Generated at 2022-06-21 12:38:19.655061
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:38:28.349812
# Unit test for constructor of class cached_property
def test_cached_property():
    # Define a test case consisting of a class and its constructor.

    class TestClass(object):
        _y = None

        # noinspection PyPep8Naming
        @cached_property
        def y(self):
            return self._y

    # Create an instance of the test case class with _y set to 1.
    obj = TestClass()
    obj._y = 1

    # The value returned by y should be 1.
    assert obj.y == 1

    # The value returned by y should be 1 (unchanged).
    assert obj.y == 1

    # Changed the underlying value of the cached property.
    obj._y = 2

    # The value returned should be the new value.
    assert obj.y == 2

    # The value returned should still be the new value.
    assert obj.y == 2

    #

# Generated at 2022-06-21 12:38:32.906490
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test cached_property.__get__ property.
    """

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert hasattr(obj, 'y')
    assert obj.y == 6



# Generated at 2022-06-21 12:38:37.454534
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    print(f'obj.y: {obj.y}')
    print(f'obj.__dict__: {obj.__dict__}')
    assert obj.y == 6
    assert obj.__dict__ == {'x': 5, 'y': 6}

# Generated at 2022-06-21 12:38:48.168893
# Unit test for constructor of class cached_property
def test_cached_property():

    class MyClass(object):

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    # Unit test for method __get__ of class cached_property
    def test__get__():
        obj.y

    assert obj.y == 6
    tx = type(obj.y)
    assert tx == int

    # Unit test for method _wrap_in_coroutine of class cached_property
    def test__wrap_in_coroutine():

        class MyClass(object):

            def __init__(self):
                self.x = 5

            @cached_property
            async def y(self):
                return self.x + 1

        obj = MyClass()

        # Unit test for method __get__

# Generated at 2022-06-21 12:38:54.158805
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Person:
        def __init__(self, first_name, last_name):
            self.first_name = first_name
            self.last_name  = last_name

        @cached_property
        def full_name(self):
            return f'{self.first_name} {self.last_name}'

    person = Person('Tom', 'Jones')
    assert person.full_name == 'Tom Jones'



# Generated at 2022-06-21 12:39:13.287388
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of cached_property
    """
    import unittest.mock
    from flutils.decorators import cached_property

    class CachedProperty(cached_property):
        def __init__(self, func):
            self.func = func

    class Example:  # pylint: disable=too-few-public-methods
        def __init__(self, x):
            self.x = x

        @CachedProperty
        def y(self):
            return self.x + 1

    with unittest.mock.patch('flutils.decorators.asyncio.iscoroutinefunction'):
        example = Example(5)
        assert example.y == 6


# Generated at 2022-06-21 12:39:22.745227
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test cached_property.__get__()

    Notes:
        2020-03-27
            Test covers use case when func is callable by wrapping in
            coroutine.

        2020-03-28
            Test the use case when func is a coroutine.

    """

    from datetime import datetime
    from unittest.mock import Mock, patch

    import pytest
    from flutils.decorators import cached_property

    def test_func():
        # print('test_func called...')
        return datetime.now()

    async def async_test_func():
        # print('async_test_func called...')
        return datetime.now()

    class TestClass:

        def __init__(self):
            pass


# Generated at 2022-06-21 12:39:24.230145
# Unit test for constructor of class cached_property
def test_cached_property():
    assert hasattr(cached_property, '__doc__')

# Generated at 2022-06-21 12:39:28.142385
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:39:34.344538
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test cached_property constructor."""

    property_ = functools.cached_property(lambda self: self.x + 1)

    class MyClass:
        def __init__(self):
            self.x = 5

        y = property_

    assert MyClass.y.__doc__ is None
    assert isinstance(MyClass.y, functools.cached_property)

    obj = MyClass()

    assert obj.y == 6



# Generated at 2022-06-21 12:39:37.709666
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class ExampleClass(object):
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x

    instance = ExampleClass(1)
    assert instance.y == 1



# Generated at 2022-06-21 12:39:44.259758
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property.
    """
    from flutils.decorators import cached_property

    class MyClass:
        """Test Class"""

        def __init__(self, x):
            self.x = x

        @cached_property
        def new(self):
            return self.x + 1

    my_obj = MyClass(3)
    my_obj.y = 7
    assert my_obj.new == 4
    assert my_obj.y == 7


# Generated at 2022-06-21 12:39:55.101978
# Unit test for constructor of class cached_property
def test_cached_property():
    # type: () -> None
    """Unit test for constructor of class cached_property"""

    import types
    from flutils.decorators import cached_property

    class Test:

        @cached_property
        def x(self):
            return 5

        @cached_property
        def y(self):
            return self.x + 1

    test = Test()
    assert isinstance(test.x, int)
    assert isinstance(test.y, int)
    assert test.x == 5
    assert test.y == 6

    orig_func = Test.x

    # cpython 3.6 and 3.7, pypy 3.5
    if sys.version_info[:2] >= (3, 6):
        assert type(test.x) is int
        assert type(test.y) is int
    #

# Generated at 2022-06-21 12:39:56.349685
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass
# vim: set fileencoding=utf-8 sw=4 ts=4 et:

# Generated at 2022-06-21 12:39:59.202781
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:40:24.494004
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # noinspection PyShadowingNames
    class Example:
        def __init__(self, val):
            self._val = val

        @cached_property
        def value(self):
            return self._val

    obj = Example(42)
    assert obj.value == 42
    obj._val = 43
    assert obj.value == 42



# Generated at 2022-06-21 12:40:29.005883
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    assert obj.__dict__ == {'x': 5, 'y': 6}

## Unit test for method __get__ of class cached_property

# Generated at 2022-06-21 12:40:33.372032
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6

    obj.x = 42

    assert obj.y == 6

# Generated at 2022-06-21 12:40:41.184967
# Unit test for constructor of class cached_property
def test_cached_property():
    """ Returns a value if the test case passes.

        Pass:  This function returns the string 'pass' if the test case passes.
    """


# Generated at 2022-06-21 12:40:45.432070
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:40:51.475133
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class TestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.y + 1

    obj = TestClass()
    assert obj.x == 5
    assert obj.y == 6
    assert obj.z == 7
    assert obj.y == 6



# Generated at 2022-06-21 12:40:56.324772
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Unit test for constructor of class cached_property
    :return:
    """
    import sys
    import doctest
    import flutils
    results = doctest.testmod(flutils.decorators.cached_property)
    if results.failed == 0:
        print('OK')
    else:
        sys.exit(results)


if __name__ == "__main__":
    test_cached_property()

# Generated at 2022-06-21 12:41:02.320706
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:41:07.853817
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.meta import doc_inherit

    # noinspection PyPep8
    @doc_inherit
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:41:13.507591
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5
        @cached_property
        def y(self):
            return self.x + 1
    obj = MyClass()
    assert obj.y == 6

if __name__ == '__main__':
    """Run the unit tests.

    CommandLine:
        python -m flutils.decorators
        python3 -m flutils.decorators
    """
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-21 12:42:01.688326
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class ClassC:

        def __init__(self):
            pass

        @cached_property
        def my_property(self):
            return self.x + 1


    # Create the object and set a value for property x
    obj = ClassC()
    obj.x = 5
    # Call the method __get__
    assert obj.my_property == 6
    # Change the value of property x
    obj.x = 6
    # Call the method __get__
    assert obj.my_property == 7

# Generated at 2022-06-21 12:42:08.253739
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest  # type: ignore

    from .decorators import cached_property

    class C:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    c = C()
    pytest.raises(AttributeError, lambda _: c.y())
    pytest.raises(AttributeError, lambda _: c.y)

# Generated at 2022-06-21 12:42:19.934822
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test for constructor of class cached_property"""

    class TestClass:
        """Class for testing the cached_property constructor."""

        def __init__(self, value_1, value_2):
            """Initialize the object."""
            self.value_1 = value_1
            self.value_2 = value_2

        @cached_property
        def test_value_1(self):
            """Test for cached_property"""
            return self.value_1 * 2

        @cached_property
        def test_value_2(self):
            """Test for cached_property"""
            return self.value_2 * 2

        @cached_property
        @asyncio.coroutine
        def test_value_3(self):
            """Test for cached_property"""
            yield  # pragma: no cover


# Generated at 2022-06-21 12:42:25.063336
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from aiohttp.web_response import Response
    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    obj2 = MyClass()
    with pytest.raises(AttributeError) as ex:
        obj2.y

    obj3 = MyClass()
    obj3.y = 7
    assert obj3.y == 7



# Generated at 2022-06-21 12:42:27.571329
# Unit test for constructor of class cached_property
def test_cached_property():
    import functools
    # noinspection PyComparisonWithNone
    assert cached_property == functools.cached_property  # pylint: disable=comparison-with-callable

# Generated at 2022-06-21 12:42:32.587150
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property
    """

    class Foo:
        counter = 0

        @cached_property
        def foo(self):
            Foo.counter += 1
            return Foo.counter

    f = Foo()
    assert f.foo == 1
    assert f.foo == 1
    assert Foo.counter == 1



# Generated at 2022-06-21 12:42:38.874341
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():  # noqa: D103
    class Example:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Example()
    assert obj.y == obj.y == 6
    obj.x = 0
    assert obj.y == 6
    del obj.y
    assert obj.y == 1



# Generated at 2022-06-21 12:42:44.351422
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestCachedProperty:

        @cached_property
        def x(self):
            return asyncio.sleep(1)

    @asyncio.coroutine
    def test_coroutine():
        obj = TestCachedProperty()
        assert asyncio.iscoroutinefunction(obj.x)
        yield from obj.x  # noqa: PY38
        assert isinstance(obj.x, asyncio.Future)

    loop = asyncio.get_event_loop()
    loop.run_until_complete(test_coroutine())

# Generated at 2022-06-21 12:42:49.539663
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:42:53.933461
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__ == {'x': 5, 'y': 6}


# Generated at 2022-06-21 12:44:39.857793
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestClass:
        def __init__(self):
            pass

        @cached_property
        def foo(self):
            return "Foo"

    @cached_property
    def coroutine():
        return asyncio.sleep(1)

    tc = TestClass()
    assert isinstance(tc.foo, str)
    assert isinstance(coroutine, asyncio.Task)