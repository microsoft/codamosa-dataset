

# Generated at 2022-06-21 12:34:41.739384
# Unit test for constructor of class cached_property
def test_cached_property():
    class Test:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """Test cached_property"""
            return self.x + 1

    obj = Test()
    assert obj.y == 6

test_cached_property()

# Generated at 2022-06-21 12:34:51.535708
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """ tests method __get__ of class cached_property

        Args:
            None

        Returns:
            None

        Raises:
            AssertionError if any tests fail
    """
    from flutils.decorators import cached_property

    class TestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert hasattr(obj, "y") is False
    assert obj.y == 6
    assert hasattr(obj, "y") is True



# Generated at 2022-06-21 12:34:57.055860
# Unit test for constructor of class cached_property
def test_cached_property():
    """ Test constructor of class cached_property

    Test:
        >>> test_cached_property()
    """

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    m = MyClass()
    assert m.y == 6

# Generated at 2022-06-21 12:35:04.953232
# Unit test for constructor of class cached_property
def test_cached_property():
    from .flutils_test import BaseTestCase

    class TestClass(BaseTestCase):

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.x = 5

        @cached_property
        def y(self):
            """A test doc string."""
            return self.x + 1

    t = TestClass('test_cached_property')
    t.assert_(hasattr(t.y, '__doc__'), 'Instance has no __doc__ attribute.')
    t.assertEqual(t.y.__doc__, 'A test doc string.')

# Generated at 2022-06-21 12:35:11.493455
# Unit test for constructor of class cached_property
def test_cached_property():
    from io import StringIO
    from contextlib import redirect_stdout

    class TestClass:

        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1


    obj = TestClass(5)
    assert obj.y == 6

    f = StringIO()
    with redirect_stdout(f):
        print(TestClass.y.__doc__)

    assert f.getvalue() == TestClass.y.__doc__

# Generated at 2022-06-21 12:35:19.715380
# Unit test for constructor of class cached_property
def test_cached_property():

    class _Mock:

        def __init__(self):
            self.x = 0

        def __repr__(self):
            return f"{self.__class__.__name__}({self.x!r})"

        @cached_property
        def x(self):
            return self.x

    expected = "cached_property(<function <lambda> at 0x"
    assert repr(cached_property(lambda: _Mock))[:len(expected)] == expected



# Generated at 2022-06-21 12:35:24.858478
# Unit test for constructor of class cached_property
def test_cached_property():
    class Test:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Test()
    obj.y

    assert obj.__dict__['y'] == 6



# Generated at 2022-06-21 12:35:32.708473
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest import TestCase
    from unittest.mock import Mock
    from unittest.mock import patch

    class TestClass(TestCase):

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.test = 0

        @cached_property
        def test_property(self):
            return self.test

    test_obj = TestClass()
    assert test_obj.test_property == test_obj.test
    test_obj.test = 5
    assert test_obj.test_property == test_obj.test
    del test_obj.test_property
    assert test_obj.test_property == test_obj.test


# Generated at 2022-06-21 12:35:40.813800
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import unittest

    class Test(unittest.TestCase):

        class MyClass:
            def __init__(self, val: int):
                self.value = val

            @cached_property
            def y(self):
                return self.value + 1

        def test_cached_property___get__(self):
            obj = self.MyClass(5)
            self.assertEqual(obj.y, 6)

    # noinspection PyUnresolvedReferences
    unittest.main()



# Generated at 2022-06-21 12:35:52.220843
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # If obj is None, returns self but do not tests that here.
    # Does not raise a TypeError if called on a class.
    # Does not raise a TypeError if called on an unbound method.
    # Raises an AttributeError if called on an instance of a class with
    # no __dict__ attribute.

    class ClassNoDict:
        @cached_property
        def prop(self):
            return 5

    obj = ClassNoDict()
    with pytest.raises(AttributeError):
        prop = obj.prop

    # Checks that property is computed once.
    # Checks that deleted property is recomputed

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = My

# Generated at 2022-06-21 12:36:03.583685
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property
    """
    import inspect

    import pytest

    from flutils.decorators import cached_property

    @cached_property
    def testfunc1(self):
        return self.test

    class TestClass(object):
        def __init__(self, test):
            self.test = test

    test_obj = TestClass(1)
    test_get = inspect.getfullargspec(cached_property.__get__)
    assert test_get.args == ['self', 'obj', 'cls']
    assert test_get.varargs is None
    assert test_get.varkw is None
    assert test_get.defaults is None
    assert test_get.kwonlyargs == []

# Generated at 2022-06-21 12:36:08.599815
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    obj.x = 4
    assert obj.y == 6


# Generated at 2022-06-21 12:36:09.224411
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass

# Generated at 2022-06-21 12:36:17.927502
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for `cached_property` function.

    """
    from flutils.decorators import cached_property

    def get_value():
        return 5

    class MyClass:

        @cached_property
        def value(self):
            return 5

    c = MyClass()
    assert c.value == 5, "`c.value` is not 5!"
    del c.value
    assert c.value == 5, "`c.value` is not 5!"

    class MyClass:

        @cached_property
        def value(self):
            return 6

    c = MyClass()
    assert c.value == 6, "`c.value` is not 6!"

    class MyClass:

        def __init__(self):
            self._value = 6


# Generated at 2022-06-21 12:36:28.017237
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Tests :meth:`cached_property.__get__` method.
    """
    # noinspection PyPep8Naming
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


if __name__ == "__main__":
    import sys
    import pytest

    print(f"Python {sys.version} on {sys.platform}")
    print(f"pytest {pytest.__version__}")

    # Run unittests
    pytest.main(args=[__file__, "--doctest-modules", "-v"])

# Generated at 2022-06-21 12:36:33.713979
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyTestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    my_obj = MyTestClass()

    assert my_obj.y == 6
    assert my_obj.__dict__ == {'x': 5, 'y': 6}

# Generated at 2022-06-21 12:36:41.997649
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Initialize class MyClass
    class MyClass:

        def __init__(self):
            self.x = None

        @cached_property
        def y(self):
            return self.x + 1

    # Test
    obj = MyClass()
    obj.x = 1
    assert obj.y == 2
    obj.y = 3
    assert obj.y == 3
    del obj.y
    obj.x = 2
    assert obj.y == 3



# Generated at 2022-06-21 12:36:51.673001
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # Test case 1 - normal
    class TestClass:

        @cached_property
        def propA(self):
            return 5

        @cached_property
        def propB(self):
            return 'Testing B'

    obj = TestClass()
    assert obj.propA == 5
    assert obj.propB == 'Testing B'

    obj2 = TestClass()
    assert obj.propA == 5
    assert obj.propB == 'Testing B'

    assert obj.propA is obj2.propA
    assert obj.propB is obj2.propB

    del obj.propA
    assert obj.propA == 5
    assert obj.propA is obj2.propA

    assert id(obj.propA) != id(obj2.propA)

    # Test case 2 - non-string

# Generated at 2022-06-21 12:36:53.955327
# Unit test for constructor of class cached_property
def test_cached_property():
    assert 'cached_property' == cached_property.__name__

# Generated at 2022-06-21 12:37:00.647273
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for the cached_property decorator.

    *New in version 0.2.0*

    """
    @cached_property
    def cached_property_test(self):
        return 3

    class Foo:
        _cached_property_test = cached_property_test

    foo = Foo()

    assert foo._cached_property_test == 3

    foo.__dict__['_cached_property_test'] = 5

    assert foo._cached_property_test == 5



# Generated at 2022-06-21 12:37:06.901628
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class Foo(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Foo()
    assert obj.y == 6



# Generated at 2022-06-21 12:37:18.243039
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    __tracebackhide__ = True

    import asyncio
    import logging
    import unittest
    from unittest.mock import patch

    from flutils.decorators import cached_property

    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)

    # noinspection PyTypeChecker
    class MyClass:
        """Return x + 1.

        Args:
            x (int): Value to add to 1.

        Returns:
            int: Value of ``x`` plus 1.

        """

        def __init__(self):
            log.debug(f"Running __init__ for {self}.")
            self.x = 5


# Generated at 2022-06-21 12:37:24.385580
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        async def z(self):
            return await self.x + 2

    obj = MyClass()
    assert isinstance(obj.y, int)
    assert isinstance(obj.y, int)
    assert isinstance(obj.z, asyncio.Future)

# Generated at 2022-06-21 12:37:30.866686
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class foo:

        @cached_property
        def _cached_func(self):
            return self.x + 1

    obj = foo()
    obj.x = 5

    print('obj._cached_func: %s' % obj._cached_func)
    print('obj.__dict__: %s' % obj.__dict__)


if __name__ == '__main__':
    test_cached_property___get__()

# Generated at 2022-06-21 12:37:35.216503
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import Mock
    prop = cached_property(lambda self: self.x)
    obj = Mock(x=10)
    assert obj.x == 10
    assert prop.__get__(obj) == 10
    assert prop.__get__(obj) == 10
    assert obj.x == 10



# Generated at 2022-06-21 12:37:43.769464
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """ Test the cached_property() method __get__()"""
    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """Return value of `x` + 1"""
            return self.x + 1

    obj = TestClass()
    assert obj.y == 6  # y is cached_property

    obj.x = 10  # change the value of x
    assert obj.y == 6  # y value is unchanged because it is cached


# Generated at 2022-06-21 12:37:47.964237
# Unit test for constructor of class cached_property
def test_cached_property():
    new_cp = cached_property(lambda: 5)
    assert new_cp.__doc__ is None
    assert new_cp.func() == 5

    class MyClass:
        @cached_property
        def x(self):
            return 5
    assert MyClass.x.__doc__ == 5
    assert MyClass().x == 5

# Generated at 2022-06-21 12:37:59.953057
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest.mock import Mock, sentinel  # noqa: S404

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    assert obj.__dict__ == {'x': 5, 'y': 6}
    assert obj.y is 6

    obj.y = sentinel.Y  # noqa: S106
    assert obj.__dict__ == {'x': 5, 'y': sentinel.Y}
    assert obj.y is sentinel.Y
    del obj.y
    assert obj.__dict__ == {'x': 5}
    assert obj.y == 6  # noqa: S106



# Generated at 2022-06-21 12:38:03.833645
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    return MyClass

# Generated at 2022-06-21 12:38:13.570544
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unittest for method __get__ of class cached_property."""

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            self.x += 1
            return self.x

    obj = MyClass()
    y = obj.y
    # y is a cached_property, and x is incremented in the setter
    assert y == 6
    obj.x = 1
    # y is not affected by change to x
    assert y == 6
    z = obj.y
    # z should be the same as y
    assert z == y



# Generated at 2022-06-21 12:38:25.684331
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

   class Dummy(object):
      def __init__(self, val):
         self.val = val

      @cached_property
      def _val(self):
         return self.val

      @cached_property
      def __junk(self):
         return self._val

   d = Dummy(1)
   assert d._val == 1
   assert d._val == 1
   assert d.__junk == 1
   assert d.__junk == 1
   d._val = 2
   assert d.__junk == 2
   del d._val
   assert d.__junk == 1
   d.__junk = 3
   assert d.__junk == 3


# Generated at 2022-06-21 12:38:29.028709
# Unit test for constructor of class cached_property
def test_cached_property():
    obj = MyClass()
    assert obj.y == 6
    del obj.y
    assert obj.y == 6
    obj.x = 10
    del obj.y
    assert obj.y == 11



# Generated at 2022-06-21 12:38:37.165157
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # If parameter is None, return class
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert cached_property.__get__(my_object=None, cls=MyClass) == MyClass.y

    # Add property value to __dict__ of instance
    my_class = MyClass()
    assert my_class.y == 6
    assert 'y' in my_class.__dict__
    assert my_class.__dict__['y'] == 6

    # Delete property and readd value to __dict__ of instance
    del my_class.y
    assert 'y' not in my_class.__dict__
    assert my_class.y == 6
    assert 'y' in my_class

# Generated at 2022-06-21 12:38:46.734657
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import asyncio
    from concurrent.futures import Future
    from typing import Any

    class MyObj:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self) -> int:
            return self.x + 1

        @cached_property
        def z(self) -> Future:
            return asyncio.Future()

    obj = MyObj()
    assert obj.y == 6 and isinstance(obj.y, int)
    assert obj.z == obj.z and isinstance(obj.z, Future)

    obj.z.set_result("foo")
    assert obj.z.result() == "foo"



# Generated at 2022-06-21 12:38:51.858969
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    assert obj.__dict__ == {'x': 5, 'y': 6}
    assert type(obj.__dict__['y']) is int



# Generated at 2022-06-21 12:39:00.910992
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test the constructor of class "cached_property"."""
    import sys
    import os
    import platform
    import pytest


    # Passed values
    __s = sys.version_info
    __pyver = "%s.%s.%s" % (__s[0], __s[1], __s[2])
    __machine = platform.machine()

    __expect = (
        "Python " + __pyver + " on "
        + platform.system() + " " + platform.release() + " "
        + __machine + " (" + platform.version() + ") "
        + platform.architecture()[0]
        )

    _log = "Expected: " + __expect + "; got: " + platform._syscmd_uname()


# Generated at 2022-06-21 12:39:06.133897
# Unit test for constructor of class cached_property
def test_cached_property():

    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        # noinspection PyPep8Naming
        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:39:09.558666
# Unit test for constructor of class cached_property
def test_cached_property():
    class cls:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert cls().y == 6

# Generated at 2022-06-21 12:39:13.903339
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators.test_decorators import CachedPropertyTestObject

    obj = CachedPropertyTestObject(1, 2)
    print(obj.x)
    print(obj.x_plus_x)
    print(obj.x_plus_x)
    print(obj.x_plus_x)

# Generated at 2022-06-21 12:39:17.112957
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class Example:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Example()
    assert obj.y == 6
    assert obj.__dict__['y'] == 6



# Generated at 2022-06-21 12:39:31.786952
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property."""
    from unittest import TestCase
    from unittest.mock import patch, call

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class TestCachedProperty(TestCase):
        def test_cached_property(self):
            with patch.object(MyClass, 'y', return_value=True) as mock_method:
                obj = MyClass()
                self.assertEqual(obj.y, True)
                self.assertEqual(mock_method.call_count, 1)
                obj.y
                obj.y
                self.assertEqual(mock_method.call_count, 1)


# Generated at 2022-06-21 12:39:32.776258
# Unit test for constructor of class cached_property
def test_cached_property():
    cached_property

# Generated at 2022-06-21 12:39:33.465592
# Unit test for constructor of class cached_property
def test_cached_property():
    pass

# Generated at 2022-06-21 12:39:38.587193
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    obj.x = 1
    assert obj.y == obj.z
    assert obj.y == 2

# Generated at 2022-06-21 12:39:42.887264
# Unit test for constructor of class cached_property
def test_cached_property():
    """ Unit test for the constructor of class cached_property """

    class MyClass:
        def __init__(self):
            self.x = 1

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 2
    assert obj.y == 2
    obj.x = 2
    assert obj.y == 2
    del obj.y
    assert obj.y == 3


# Generated at 2022-06-21 12:39:47.547406
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    expected = 5

    class MyClass:

        def __init__(self):
            self.x = expected

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert expected == obj.y


if __name__ == '__main__':
    test_cached_property___get__()

# Generated at 2022-06-21 12:39:51.024812
# Unit test for constructor of class cached_property
def test_cached_property():
    # Create instance of class cached_property
    prop = cached_property(lambda self: None)
    # Check return type of method __init__()
    assert(isinstance(prop, cached_property))


# Generated at 2022-06-21 12:39:56.515041
# Unit test for constructor of class cached_property
def test_cached_property():

    class TestClass(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    t = TestClass()
    assert t.y == 6
    t.x = 10
    assert t.y == 11
    del t.y
    t.x = 15
    assert t.y == 16

# Generated at 2022-06-21 12:40:00.049695
# Unit test for constructor of class cached_property
def test_cached_property():
    """ Unit test for cached_property constructor. """
    import pytest  # noqa
    test_obj = cached_property(lambda x, y: x + y)
    assert test_obj.__doc__ == 'None'
    assert test_obj(5, 6) == 11


# Generated at 2022-06-21 12:40:08.356302
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    This method only tests the *__get__()* method of *cached_property...
    """
    # Test the property decorator with an async method
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        async def y(self):
            await asyncio.sleep(0)
            return self.x + 1

    obj = MyClass()
    obj_y = obj.y
    assert isinstance(obj_y, asyncio.Future)
    assert obj_y.done() is False

    loop = asyncio.get_event_loop()
    loop.run_until_complete(obj_y)
    assert obj_y.result() == 6

    # Test the property decorator with an non-async method

# Generated at 2022-06-21 12:40:24.208940
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test initialized cached_property"""
    class AClass:
        """A test class"""

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    expect = {'x': 5, 'y': 6}
    for key, val in AClass().__dict__.items():
        assert expect == val


# Generated at 2022-06-21 12:40:29.535509
# Unit test for constructor of class cached_property
def test_cached_property():
    from datetime import datetime

    def now():
        print("Computing now...")
        return datetime.now()

    class DateTime:
        @cached_property
        def now(self):
            return now()

    if __name__ == "__main__":
        date_time = DateTime()
        print("First time:", date_time.now)
        print("Second time:", date_time.now)
        print("Accessing __dict__:", date_time.__dict__)



# Generated at 2022-06-21 12:40:39.293278
# Unit test for constructor of class cached_property
def test_cached_property():
    class Obj:

        def __init__(self):
            self.x = 0

        @cached_property
        def y(self):
            return self.x + 1

    obj = Obj()
    assert obj.y == 1

    # Check value is cached
    obj.__dict__['x'] = 1
    assert obj.y == 1

    # Check cached value is deleted
    del obj.y
    assert obj.y == 2

    # Check cached value is deleted on delete
    del obj.__dict__['x']
    assert obj.y == 1

    # Check cached value is deleted on set
    obj.y = 5
    assert obj.y == 5
    assert obj.__dict__['y'] == 5

    # Check cached value is deleted on delitem
    del obj.__dict__['y']

# Generated at 2022-06-21 12:40:50.480622
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test for
    :obj:`~flutils.decorators.cached_property.cached_property`
    """
    from io import StringIO
    from unittest import main
    from unittest.mock import patch
    from pytest import raises
    from flutils.decorators import cached_property

    class _MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    with raises(TypeError):
        cached_property()

    with raises(TypeError):
        cached_property('bogus')

    mock_class = _MyClass()

    assert mock_class.y == 6
    assert mock_class.__dict__ == {'x': 5, 'y': 6}

    #

# Generated at 2022-06-21 12:40:55.789452
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Obj(object):

        @cached_property
        def x(self):
            return 10

        @cached_property
        def y(self):
            return asyncio.ensure_future(self._get_async_y())

        @asyncio.coroutine
        def _get_async_y(self):
            return 15

    obj = Obj()
    assert obj.x == 10
    assert obj.y == 15



# Generated at 2022-06-21 12:41:02.311170
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # make an instance variable
    obj = MyClass()

    # run as a standard method to make sure everything
    # is working as expected
    assert obj.run() == 1

    # make sure the property is using the right value
    assert obj.var == 1

    # make sure that the cached property is available
    # and is correct
    assert obj.y == 1

    # make sure the property is using the right value
    assert obj.var == 1

    # make sure the cached property is available
    # and is correct
    assert obj.y == 1

    # make sure the cached property is available
    # and is correct before it is deleted
    assert obj.y == 1

    # delete the cached property
    del obj.y

    # make sure the property is using the right value
    assert obj.var == 2

    # make sure the cached property

# Generated at 2022-06-21 12:41:12.628634
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    from unittest.mock import MagicMock, patch

    # Mock classes used by unit tests
    class MockCls:

        def __init__(self):
            self.x = 1

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x + 2

    # First unit test
    @patch.object(MockCls, 'x', 1)
    def test_cached_property___get__1(mock_obj):

        mock_obj.y  # call __get__() with obj = mock_obj and cls = None
        mock_obj.z  # call __get__() with obj = mock_obj and cls = None

        mock_obj.__dict__['y'] = 2
        mock

# Generated at 2022-06-21 12:41:20.365115
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Unit test for constructor of class :obj:`cached_property`

    """
    from flutils.decorators import cached_property
    import types

    obj = MyMockClass()
    assert not obj.__dict__
    assert obj.y
    assert obj.__dict__
    assert isinstance(obj.y, types.CoroutineType)
    assert obj.__dict__
    return



# Generated at 2022-06-21 12:41:25.700736
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    from unittest import mock
    from unittest.mock import MagicMock

    def test_get__method(obj):
        obj.__dict__[test_get__method.__name__] = 1
        return 2

    m = mock.Mock()
    prop = cached_property(test_get__method)
    prop.__get__(m, m)
    assert m.__dict__[test_get__method.__name__] == 2



# Generated at 2022-06-21 12:41:36.422342
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.py23 import assertCountEqual
    from unittest import TestCase, main

    class ClassA(TestCase):

        def __init__(self):
            super(ClassA, self).__init__()
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class ClassB(ClassA):
        pass

    cla = ClassA()
    clb = ClassB()
    assert cla.y == 6
    assert cla.y == 6
    assert clb.y == 6
    assert clb.y == 6
    cla.x = 3
    assert cla.y == 4
    assert clb.y == 4  # because underlying property still == 6

    assert cla.x == 3
    assert clb.x == 3
    # py2.

# Generated at 2022-06-21 12:42:08.301238
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property"""

    class Class:
        """A class with a cached property"""

        def __init__(self):
            self._x = 5

        @cached_property
        def cached_property(self):
            """A cached property"""
            return self._x + 1

    assert Class.cached_property.__doc__ == "A cached property"
    assert Class.cached_property.__name__ == "cached_property"

    obj = Class()
    assert obj.cached_property == 6

# Generated at 2022-06-21 12:42:13.938646
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class :obj:`~flutils.decorators.cached_property`."""

    # pylint: disable=missing-function-docstring
    class TestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:42:19.476293
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from . import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:42:27.888200
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Initialization
    from inspect import signature as sig

    def test_func(obj):
        return obj.x + 1

    callable_object = cached_property(test_func)

    class MyClass:

        def __init__(self):
            self.x = 5

    object = MyClass()

    # Test the signature (parameters and return type)
    assert sig(callable_object.__get__).parameters == sig(test_func.__get__).parameters
    assert sig(callable_object.__get__).return_annotation is sig(test_func.__get__).return_annotation

    # Test if the function was called
    assert object.x == 5
    assert object.__dict__[test_func.__name__] == 6

# Generated at 2022-06-21 12:42:39.148064
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    global obj
    global cls
    global self

    import sys

    if sys.version_info >= (3, 8):  # pragma: no cover
        import pytest
        pytest.skip('Python >= 3.8 has functools.cached_property')

    from flutils.testing import MockObject

    class MyClass(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x + 2

    # Test as a property
    obj = MyClass()
    cls = int
    assert self.__get__(obj, cls) == obj.y
    # Test as a method
    cls = None
    assert self.__

# Generated at 2022-06-21 12:42:42.754394
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest import mock

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:42:47.354251
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 2

        @cached_property
        def y(self):
            return self.x + 3

    obj = MyClass()
    assert obj.y == 5
    assert obj.__dict__ == {'x': 2, 'y': 5}



# Generated at 2022-06-21 12:42:58.427314
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test for method __get__ of class cached_property
    """

    # ---
    # Setup
    from functools import partial
    from unittest import mock

    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    # ---

    m = mock.MagicMock()

    with mock.patch("flutils.decorators.cached_property.func", m):
        assert obj.y == 6
        m.assert_called_once_with(obj)

    m.reset_mock()


# Generated at 2022-06-21 12:43:03.668503
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import asyncio
    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 2

        def add_one(self):
            x = self.x + 1
            return x

        def add_one_async(self):
            yield from asyncio.sleep(0, 1)
            yield from asyncio.sleep(0, 1)
            yield from asyncio.sleep(0, 1)
            yield from asyncio.sleep(0, 1)
            return self.x + 1

        @cached_property
        def prop(self):
            return self.add_one()

        @cached_property
        def prop_async(self):
            return self.add_one_async()

    obj = MyClass()
    # add_one


# Generated at 2022-06-21 12:43:06.814263
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:44:07.116742
# Unit test for constructor of class cached_property
def test_cached_property():  # pragma: no cover
    """
    Constructor of class cached_property
    """

    class SomeClass:
        """Class to test cached_property"""

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = SomeClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:44:13.758251
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # @cached_property
    @property
    def complex_thing(self):
        """Return a complex thing."""
        return 2 + 2j

    assert complex_thing.__doc__ == 'Return a complex thing.'

    assert complex_thing.__get__(complex(0, 0), complex) == complex_thing
    assert complex_thing.__get__(complex(1, 1), complex) == complex_thing
    assert complex_thing.__get__(complex(3, 2), complex) == complex_thing



# Generated at 2022-06-21 12:44:19.981740
# Unit test for constructor of class cached_property
def test_cached_property():

    class class_name:
        """Define the class_name class."""

        def __init__(self):
            """Initialize the class."""
            self.x = 5

        @cached_property
        def y(self):
            """A cached property."""
            return self.x + 1

    obj = class_name()
    assert obj.y == 6

# Generated at 2022-06-21 12:44:26.426848
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import mock
    from unittest.mock import Mock

    obj = Mock()
    obj.x = 5

    func = mock.MagicMock()
    func.__name__ = 'y'
    func.__doc__ = 'doc'

    @cached_property
    def y(self):
        return self.x + 1

    assert y.__get__(obj, None) == 6

    func.assert_called_once_with(obj)



# Generated at 2022-06-21 12:44:31.448422
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 0

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 1
    assert obj.__dict__ == {'x': 0, 'y': 1}



# Generated at 2022-06-21 12:44:37.057318
# Unit test for constructor of class cached_property
def test_cached_property():
    """Tests for cached_property.
    """

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

