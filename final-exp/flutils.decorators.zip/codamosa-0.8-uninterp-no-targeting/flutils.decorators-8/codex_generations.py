

# Generated at 2022-06-21 12:34:48.866777
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    obj.y
    assert (obj.y, obj.__dict__) == (6, {'x': 5, 'y': 6})

# Generated at 2022-06-21 12:35:00.841900
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property.
    """
    # This magic number tests code coverage in method __get__.
    MAGIC_NUMBER = 1086

    # noinspection PyUnresolvedReferences
    class MyClass:

        def __init__(self, x: int = 7):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 2

        @staticmethod
        def get_magic_number() -> int:
            return MAGIC_NUMBER

    mycls = MyClass()

    assert mycls.y == 9
    assert isinstance(mycls.y, int)
    assert mycls.get_magic_number() == MAGIC_NUMBER

    # This magic number tests code coverage in method __get__.
    MAG

# Generated at 2022-06-21 12:35:04.151493
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == obj.y

# Generated at 2022-06-21 12:35:11.160237
# Unit test for constructor of class cached_property
def test_cached_property():

    class A:
        def __init__(self):
            self.x = 0

        @cached_property
        def incr(self):
            self.x += 1
            return self.x

    a = A()

    assert a.incr == 1
    assert a.incr == 1

    a.incr = 10
    assert a.incr == 10

    a.__dict__['incr'] = 0
    assert a.incr == 0

    del a.incr
    assert a.incr == 1
    assert a.incr == 1

# Generated at 2022-06-21 12:35:19.781410
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Test:
        def __init__(self, a, b):
            self.a = a
            self.b = b

        @cached_property
        def add(self):
            return self.a + self.b

    t1 = Test(1, 2)
    assert t1._Test__dict__ == {'a': 1, 'b': 2}
    assert t1.add == 3
    assert t1._Test__dict__ == {'a': 1, 'b': 2, 'add': 3}



# Generated at 2022-06-21 12:35:23.862304
# Unit test for constructor of class cached_property
def test_cached_property():
    class Foo:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Foo()
    assert obj.y == 6

# Generated at 2022-06-21 12:35:28.776787
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method `__get__` of class `cached_property`.

    *Tested in version 0.2.0*

    """
    c = int
    t = cached_property(c)
    assert t.__doc__ == c.__doc__
    assert t.func == c

    obj = object()
    assert t.__get__(obj) == obj

# Generated at 2022-06-21 12:35:29.328646
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass

# Generated at 2022-06-21 12:35:35.488160
# Unit test for constructor of class cached_property
def test_cached_property():
    # Test using simple function
    @cached_property
    def simple_function(self):
        return 5

    assert simple_function.__doc__ is None
    assert simple_function.__name__ == "simple_function"

    # Test using simple class
    @cached_property
    class simple_class:

        def __init__(self):
            pass

    assert simple_class.__doc__ is None
    assert simple_class.__name__ == "simple_class"

    # Test using class
    @cached_property
    class docstring_class:

        def __init__(self):
            """Class docstring"""

    assert docstring_class.__doc__ == "Class docstring"
    assert docstring_class.__name__ == "docstring_class"



# Generated at 2022-06-21 12:35:45.740787
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test the cached_property__get__ method of the cached_property class
    """

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def coroutine(self):
            asyncio.sleep(1)
            return self.x + 1

    obj = MyClass()

    # The first call to the method 'coroutine' returns a coroutine object
    assert inspect.iscoroutinefunction(obj.coroutine) is False
    assert isinstance(obj.coroutine, asyncio.Future) is True
    assert obj.coroutine.done() is False

    # The second time call to the method 'coroutine' returns th

# Generated at 2022-06-21 12:36:00.151655
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class ClassA:

        def __init__(self):
            self.a = 'A'

        @cached_property
        def b(self):
            return self.a + 'B'

    objA = ClassA()

    assert objA.b == 'AB'
    assert 'b' in objA.__dict__
    assert objA.__dict__['b'] == 'AB'

    objA.b = 'C'

    assert objA.b == 'C'
    assert 'b' in objA.__dict__
    assert objA.__dict__['b'] == 'C'

    del objA.b

    assert objA.b == 'AB'
    assert 'b' in objA.__dict__
    assert objA.__dict__['b'] == 'AB'

# Generated at 2022-06-21 12:36:05.386247
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


# Generated at 2022-06-21 12:36:10.229070
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class Foo:

        def __init__(self):
            self.x = 1

        @cached_property
        def y(self):
            return self.x + 1

    foo = Foo()
    assert foo.y == 2



# Generated at 2022-06-21 12:36:18.461452
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Tests the constructor of the class cached_property

    :return: no return
    """
    from .miscutils import Echo
    from .helpers import assert_code_equal
    from .exceptions import AssertionError

    obj = Echo()
    obj.x = 5

    assert_code_equal('''
        @cached_property
        def y(self):
            return self.x + 1
    ''', cached_property)

    assert_code_equal('''
        obj = Echo()
        obj.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        obj.y
    ''', obj.y, value=6)


# Generated at 2022-06-21 12:36:28.657566
# Unit test for constructor of class cached_property

# Generated at 2022-06-21 12:36:41.765366
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Code to execute the tests in :attr:`test_cached_property___get__`.

    See Also:
        :attr:`test_cached_property___get__`

    *New in version 0.2.0*

    """
    # pylint: disable=no-member
    # pylint: disable=not-callable
    # pylint: disable=no-value-for-parameter

    class Mock:
        def __init__(self):
            self.i = 0

        @cached_property
        def j(self):
            self.i += 1
            return self.i

    obj = Mock()
    assert obj.j == 1
    obj.j
    assert obj.j == 1

    class Mock:
        def __init__(self):
            self.i = 0


# Generated at 2022-06-21 12:36:51.618247
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self._a = 14
            self._b = 15

        @cached_property
        def a(self):
            return self._a

        @cached_property
        def b(self):
            return self._b

    class MyAsyncClass:

        def __init__(self):
            self._a = 2
            self._b = 3

        @cached_property
        async def a(self):
            await asyncio.sleep(.1)
            return self._a

        @cached_property
        async def b(self):
            await asyncio.sleep(.1)
            return self._b

    for cls in [MyClass, MyAsyncClass]:
        loop = asyncio.get_event_loop()
        obj = cls()

# Generated at 2022-06-21 12:36:59.307829
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from .decorators import cached_property

    class MyClass:

        def __init__(self):
            pass

        @cached_property
        def x(self):
            return 5

    assert isinstance(MyClass.x, cached_property)
    assert MyClass.x.__doc__ is None

    m = MyClass()
    assert isinstance(m.x, int)
    assert m.x == 5
    assert m.__dict__['x'] == 5



# Generated at 2022-06-21 12:37:07.038635
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test ``cached_property.__get__()`` method.

    """

    class Foo:

        @cached_property
        def bar(self):
            return "bar"

        @cached_property
        def baz(self):
            return "baz"

    obj = Foo()
    expected = "bar"
    actual = obj.bar
    assert expected == actual

    expected = "baz"
    actual = obj.baz
    assert expected == actual

# Generated at 2022-06-21 12:37:13.811686
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit tests for flutils.cached_property
    """
    @cached_property
    def foo(self):
        return 'foo'

    class Bar(object):
        foo = foo

    bar = Bar()
    bar.foo
    assert bar.foo == 'foo'


if __name__ == "__main__":
    # Run unit test
    test_cached_property()
    print('{} passed all tests...'.format(__file__))

# Generated at 2022-06-21 12:37:21.943686
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property
    from flutils import die

    assert cached_property

    class MyClass(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1
    obj = MyClass()
    obj.y
    assert obj.y == 6
    obj.x = 10
    obj.y



# Generated at 2022-06-21 12:37:31.674406
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Test:
        def __init__(self):
            self.x = "foo"

        @cached_property
        def y(self):
            return self.x + "bar"

    # Normal usage
    obj = Test()
    assert obj.y == "foobar"
    assert obj.__dict__ == {"x": "foo", "y": "foobar"}

    # Deleted after use
    del obj.y
    assert obj.__dict__ == {"x": "foo"}

    # Computed again after deleted
    assert obj.y == "foobar"
    assert obj.__dict__ == {"x": "foo", "y": "foobar"}


# Generated at 2022-06-21 12:37:32.369142
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    ...

# Generated at 2022-06-21 12:37:33.335972
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property


# Generated at 2022-06-21 12:37:40.680247
# Unit test for constructor of class cached_property
def test_cached_property():
    import pytest
    from flutils.decorators import cached_property
    from unittest import mock

    class MyClass:
        @cached_property
        def y(self):
            return "y"

        @property
        def z(self):
            return "z"

    obj = MyClass()

    assert obj.y == "y"
    assert obj.y == "y"
    with mock.patch.object(MyClass, 'y', "abcd"):
        assert obj.y == "abcd"
    # Ensure that the @property decorator does not raise an exception.
    assert obj.z == "z"
    assert obj.z == "z"
    with mock.patch.object(MyClass, 'z', "efgh"):
        assert obj.z == "efgh"


# Generated at 2022-06-21 12:37:47.962189
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test cached_property's __get__ method."""

    class C:
        """Instantiate class C."""

        @cached_property
        def foo(self):
            """Get foo."""

            return 2

        @cached_property
        def bar(self):
            """Get bar."""

            return "hello"

    # Test basic functionality
    c = C()
    assert c.foo == 2
    assert c.bar == "hello"

    c = C()
    assert c.foo == 2
    assert c.bar == "hello"

    # Test replacement
    c = C()
    assert c.foo == 2
    assert c.bar == "hello"
    assert c.foo == 2
    assert c.bar == "hello"
    c.foo == 3
    c.bar = "goodbye"
   

# Generated at 2022-06-21 12:37:54.616399
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 1

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    obj.y
    assert obj.y == 2
    assert obj.__dict__ == {'x': 1, 'y': 2}



# Generated at 2022-06-21 12:38:00.349877
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test the constructor of the class cached_property"""

    class MyClass():
        """This is a class to test the decrator cached_property"""
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """This is the cached property y"""
            return self.x + 1

    obj = MyClass()
    assert obj.x == 5
    assert obj.y == 6

# Generated at 2022-06-21 12:38:12.990513
# Unit test for constructor of class cached_property
def test_cached_property():
    import unittest

    class _Testcached_property(unittest.TestCase):
        def test_no_docstring(self):
            class myclass:
                @cached_property
                def myprop():
                    pass

            self.assertIsNone(myclass.myprop.__doc__)

        def test_with_docstring(self):
            class myclass:
                @cached_property
                def myprop():
                    """My docstring"""
                    return 1

            self.assertEqual(myclass.myprop.__doc__, "My docstring")

        def test_cached(self):
            class myclass:
                def __init__(self):
                    self.count = 0

                @cached_property
                def myprop(self):
                    self.count += 1
                    return self.count

# Generated at 2022-06-21 12:38:21.499432
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # noinspection PyUnusedLocal
    class MyClass:
        def __init__(self) -> None:
            self.x = 5
            self.y1 = 0

        @cached_property
        def y(self):
            self.y1 = self.x + 1
            return self.y1

        @cached_property
        def z(self):
            return self.x + 1

    obj = MyClass()
    # noinspection PyTypeChecker
    assert obj.y == 6
    assert obj.y1 == 0

    # noinspection PyTypeChecker
    assert obj.z == 6



# Generated at 2022-06-21 12:38:29.290633
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:38:36.203392
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Class:

        def __init__(self):
            self.value = None

        @cached_property
        def method(self):
            return self.value + 1

    obj = Class()
    obj.value = 1
    assert obj.method == 2
    assert obj.__dict__['method'] == 2
    obj.value = 2
    assert obj.method == 2
    assert obj.__dict__['method'] == 2
    del obj.method
    assert 'method' not in obj.__dict__
    obj.value = 3
    assert obj.method == 4
    assert obj.__dict__['method'] == 4

# Generated at 2022-06-21 12:38:39.583630
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    clas = MyClass()

    assert clas.y == 6

# Generated at 2022-06-21 12:38:50.145948
# Unit test for constructor of class cached_property
def test_cached_property():
    """  Tests constructor of cached_property class"""
    from collections import namedtuple
    from unittest import TestCase
    from unittest.mock import Mock

    class MockTestCase(TestCase):
        @classmethod
        def setUpClass(cls):
            """ Runs before all tests"""
            cls.mocked_cached_property = cached_property(Mock())  # type: ignore
            cls.mock_func = Mock()

        def test_cached_property_constructed_properly(self):
            """ tests if the cached_property object is constructed properly"""
            _ = cached_property(self.mock_func)

            self.assertEqual(_.func, self.mock_func)
            self.assertEqual(_.__doc__, self.mock_func.__doc__)

# Generated at 2022-06-21 12:38:59.703090
# Unit test for constructor of class cached_property
def test_cached_property():
    from dataclasses import dataclass
    from typing import Any, Callable, Dict, Optional, TypeVar

    T = TypeVar("T")

    @dataclass
    class Foo:
        x: int
        _y: Dict[int, int] = dataclass_field(init=False, default_factory=dict)

        @cached_property
        def y(self) -> int:
            return self.x + 1

        @cached_property
        def y1(self) -> int:
            return self.x + 1

        @cached_property
        def y2(self) -> int:
            return self.x + 2

    assert Foo.y  # Type ignore as mypy doesn't understand decorators

    foo = Foo(5)
    assert foo.y == 6
    foo.x = 6

# Generated at 2022-06-21 12:39:04.487238
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:39:10.750379
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    def test_stub(self):
        return 5

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return test_stub(self)

    obj = MyClass()
    assert obj.y == 5
    obj.__dict__[obj.y.func.__name__] = 6
    assert obj.y == 6



# Generated at 2022-06-21 12:39:12.006635
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property(None)



# Generated at 2022-06-21 12:39:17.122071
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestCachedProperty___get__:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    t = TestCachedProperty___get__()
    # On first call, returns value
    assert t.y == 6

    # On second call, returns cached value
    assert t.y == 6

    # After deleting the cached value, the next call will return a new value
    del t.y
    assert t.y == 6



# Generated at 2022-06-21 12:39:26.435481
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test constructor of class cached_property."""

    @cached_property
    def x(self):
        return 1

    @cached_property
    async def y(self):
        return 2

    assert x.__doc__ == y.__doc__ is None
    assert x.__class__.__name__ == 'cached_property'
    assert x.func.__name__ == 'x'
    assert y.func.__name__ == 'y'


if __name__ == '__main__':

    import pytest

    # Run unit tests
    pytest.main(args=['-xrs', '--durations=10', '--color=yes', __file__])

# Generated at 2022-06-21 12:39:42.046576
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class :class:`~flutils.decorators.cached_property`."""

    print(test_cached_property.__doc__)

    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__['y'] == 6

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x * 2

    obj = MyClass

# Generated at 2022-06-21 12:39:52.953970
# Unit test for constructor of class cached_property
def test_cached_property():

    from unittest import TestCase, mock

    obj = TestCase()
    test = cached_property(mock.MagicMock())

# Generated at 2022-06-21 12:40:00.288939
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    obj.x = 2
    assert obj.y == 6

    del obj.y
    assert obj.y == 3

    # noinspection PyUnresolvedReferences
    def z(self):
        return self.x

    MyClass.z = cached_property(z)
    assert obj.z == 2

    obj.x = 7
    assert obj.z == 7

    del obj.z
    assert obj.z == 7

# Generated at 2022-06-21 12:40:05.374614
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test the constructor of class cached_property

    *New in version 0.2.0*

    """
    def test_func():
        """Test function for cached_property test.

        *New in version 0.2.0*

        """
        pass

    cp = cached_property(func=test_func)
    assert cp.func == test_func
    assert cp.__doc__ == test_func.__doc__

# Generated at 2022-06-21 12:40:08.063994
# Unit test for constructor of class cached_property
def test_cached_property():
    @cached_property
    def bar(self):
        return 6

    assert bar.__doc__ == None
    assert bar.func.__name__ == 'bar'


# Generated at 2022-06-21 12:40:15.426128
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property
    import asyncio

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6
    assert obj.__dict__['y'] == 6

    assert asyncio.iscoroutinefunction(obj.y) is False
    assert obj.y is obj.y
    assert obj.__dict__['y'] == 6



# Generated at 2022-06-21 12:40:23.093372
# Unit test for constructor of class cached_property
def test_cached_property():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    # Remove y and make sure it is recalculated.
    del obj.y
    assert obj.y == 6

    # Test that y is removed when we delete it.
    assert obj.__dict__ == {'x': 5}

    # Test that y is removed when we delete it.
    obj.x = 11
    assert obj.y == 12


test_cached_property()

# Generated at 2022-06-21 12:40:27.774813
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test the constructor of the cached_property class."""

    from flutils.decorators import cached_property as _cached_property

    class _MyClass:

        def __init__(self):
            self.x = 5

        @_cached_property
        def y(self):
            return self.x + 1

    assert _MyClass.y == _cached_property



# Generated at 2022-06-21 12:40:33.580332
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self, name: str, x: int):
            self.name = name
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass('junk', 5)
    obj.y
    assert obj.__dict__ == {'name': 'junk', 'x': 5, 'y': 6}

# Generated at 2022-06-21 12:40:38.287697
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        pass

    def f():
        return 2 + 2

    cp = cached_property(f)
    my_obj = MyClass()

    assert cp.__get__(my_obj, MyClass) == 4
    assert my_obj.__dict__[f.__name__] == 4
    assert cp.__get__(my_obj, MyClass) == 4

# Generated at 2022-06-21 12:41:03.178263
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:41:07.193599
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class Foo:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Foo()
    assert obj.y == obj.__dict__['y'] == 6


# Generated at 2022-06-21 12:41:08.983811
# Unit test for constructor of class cached_property
def test_cached_property():
    obj = cached_property(lambda x: 10*10)
    assert obj.func(10) == 100

# Generated at 2022-06-21 12:41:11.592423
# Unit test for constructor of class cached_property
def test_cached_property():
    from .testdata import MyClass

    obj = MyClass()

    # Verify that cached_property decorator is working.
    assert obj.x + 1 == obj.y

# Generated at 2022-06-21 12:41:14.171435
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # the main test is a simple example in the class docstring
    return



# Generated at 2022-06-21 12:41:24.916690
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    def test_func(obj):
        obj.__dict__['test_func'] = 'test'

    c = cached_property(test_func)
    assert c.func == test_func
    assert isinstance(c, cached_property)
    assert isinstance(c.__get__(None, None), cached_property)
    assert callable(c.__get__(None, None))
    assert not c.__get__(None, None).__name__
    assert not c.__get__(None, None).__doc__

    class test_class:
        pass

    tc1 = test_class()
    dct = dict(test_func='test')
    assert c.__get__(tc1, None).__self__ == tc1
    assert c.__get__(tc1, None).__func__ == test

# Generated at 2022-06-21 12:41:32.043178
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit tests for cached_property.__get__()."""
    # noinspection PyShadowingNames
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """Calculate y."""
            return self.x + 1

    import doctest

    doctest.testmod()

    # Usage
    obj = MyClass()
    assert obj.y == 6
    assert obj.y == 6

# Generated at 2022-06-21 12:41:42.043668
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit tests for decorator :obj:`flutils.decorators.cached_property`."""

    class Foo:
        """A simple class."""

        def __init__(self):
            """Initialize the class."""
            self.x = 'foo'

        @cached_property
        def bar(self):
            """Please don't call me."""
            return self.x + 'bar'

        @cached_property
        def baz(self):
            """Please don't call me."""
            return self.x + 'baz'

        @cached_property
        def coro(self):
            """Please don't call me."""
            return asyncio.sleep(0.1, result='coro')


# Generated at 2022-06-21 12:41:53.906042
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test the method ``__get__`` of  class ``cached_property``
    """

    from flutils.decorators import cached_property

    class P:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x + 1

        @cached_property
        @asyncio.coroutine
        def q(self):
            return self.x + 1

        @cached_property
        def a(self):
            @asyncio.coroutine
            def run():
                return self.x + 1

            return run()

    p = P()

    assert hasattr(p, "_P__y")
    assert p.y == 6

# Generated at 2022-06-21 12:42:02.919114
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # A class with a cached attribute
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class AsyncMyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        @asyncio.coroutine
        def y(self):
            yield from asyncio.sleep(1)
            return self.x + 1

    # Instantiate an object
    obj = MyClass()
    # The attribute y should be 6
    assert obj.y == 6
    # The attribute x should be 5
    assert obj.x == 5
    # The attribute y is stored as in obj.__dict__
    assert isinstance(obj.__dict__['y'], int)



# Generated at 2022-06-21 12:42:51.818933
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert(obj.y == 6)

# Generated at 2022-06-21 12:42:56.490570
# Unit test for constructor of class cached_property
def test_cached_property():
    import pytest
    from flutils.decorators import cached_property

    @cached_property
    def y(self):
        return self.x + 1

    class MyClass:

        def __init__(self):
            self.x = 5

    obj = MyClass()
    with pytest.raises(AttributeError):
        obj.y



# Generated at 2022-06-21 12:42:57.846917
# Unit test for constructor of class cached_property
def test_cached_property():
    return


# Generated at 2022-06-21 12:43:03.060346
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    :return: None
    """
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__['y'] == 6
    del obj.__dict__['y']
    assert obj.y == 6


# Generated at 2022-06-21 12:43:10.420241
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""

    from types import MethodType

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    # check basic function
    assert obj.y == 6
    obj.x = 2
    assert obj.y == 3

    # check delete
    del obj.y
    assert obj.y == 3

    # check docstring
    assert obj.y.__doc__ == \
           obj.__class__.y.__doc__ == \
           MyClass.y.__doc__ == \
           MyClass.__dict__['y'].__doc__ == \
           "A property decorator that is only computed once per instance and "

# Generated at 2022-06-21 12:43:16.294318
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    # Delete the property, then recompute it
    del obj.y
    assert obj.y == 6


# Generated at 2022-06-21 12:43:19.690054
# Unit test for constructor of class cached_property
def test_cached_property():  # pragma: no cover
    """Unit test for constructor of class cached_property."""

    class Foo:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Foo()
    assert obj.y == 6

# Generated at 2022-06-21 12:43:28.987176
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    import time
    from unittest.mock import call, Mock, patch

    # Mocks setup
    lock = asyncio.Lock()
    sleep: Mock = Mock()
    sleep.return_value = None
    lock.acquire.return_value = sleep

    class Obj:
        @cached_property
        def prop(self):
            return 1

    # Create instance of Obj class
    obj = Obj()

    # Run first use of cached_property
    start = time.perf_counter()
    obj.prop
    first = time.perf_counter() - start

    # Run second use of cached_property
    start = time.perf_counter()
    obj.prop
    second = time.perf_counter() - start

    assert second < first

    # Run use of cached_property that needs to lock it
   

# Generated at 2022-06-21 12:43:29.875016
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass



# Generated at 2022-06-21 12:43:32.262696
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Unit test for constructor of class cached_property
    """
    assert cached_property  # Exists
    assert 'cached_property' in globals()  # is in globals()
    assert 'cached_property' in locals()  # is in locals()