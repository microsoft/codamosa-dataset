

# Generated at 2022-06-21 12:34:48.391069
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit tests for method `~flutils.decorators.cached_property.__get__`"""

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:34:54.632475
# Unit test for constructor of class cached_property
def test_cached_property():
    from pytest import raises

    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x + 1

    obj = TestClass()
    assert obj.y == 6
    with raises(AttributeError):
        obj.z

# Generated at 2022-06-21 12:34:56.775337
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:35:01.524163
# Unit test for constructor of class cached_property
def test_cached_property():
    import pytest
    from flutils.decorators import cached_property

    # Testing __init__

    # Actually this does nothing.
    # We just need a function to decorate
    @cached_property
    def prop_func():
        pass

    with pytest.raises(TypeError):
        cached_property(1)

# Generated at 2022-06-21 12:35:04.341654
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:35:07.752258
# Unit test for constructor of class cached_property
def test_cached_property():
    cc = cached_property(lambda x: x + 100)

    assert hasattr(cc, '__init__')
    assert hasattr(cc, 'func')
    assert hasattr(cc, '_wrap_in_coroutine')

# Generated at 2022-06-21 12:35:11.537187
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:35:16.764129
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    '''
    Unit test for method __get__ of class cached_property.
    '''
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:35:23.258133
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import asyncio

    class MyClass:
        @cached_property
        def y(self):
            return self.x + 1

    def run_sync(coro):
        return asyncio.get_event_loop().run_until_complete(coro)

    obj = MyClass()
    obj.x = 5
    assert run_sync(obj.y) == 6

# Generated at 2022-06-21 12:35:28.737245
# Unit test for constructor of class cached_property
def test_cached_property():
    class A:
        def __init__(self, val):
            self.val = val

        @cached_property
        async def cache_me(self):
            return self.val

    val = 'foo'
    a = A(val)
    assert a.cache_me == val  # First access is non-cached
    assert a.cache_me == val  # Return the cached value

# Generated at 2022-06-21 12:35:31.770143
# Unit test for constructor of class cached_property
def test_cached_property():
    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:35:38.240084
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Unit test for constructor of class cached_property
    """

    class MyClass:
        """
        MyClass for testing
        """

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """
            This is a property function
            """
            return self.x + 1

    obj = MyClass()
    # print(obj.y)
    assert obj.y == 6

# Generated at 2022-06-21 12:35:39.714115
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass



# Generated at 2022-06-21 12:35:46.380370
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        async def z(self):
            return self.x + 1

    obj = MyClass()
    assert(obj.y == 6)
    assert(obj.__dict__['y'] == 6)
    assert(obj.z == 6)



# Generated at 2022-06-21 12:35:50.675303
# Unit test for constructor of class cached_property
def test_cached_property():
    class Foo:
        def __init__(self, name):
            self.name = name

        @cached_property
        def name(self):
            return "Shodan"

    foo = Foo("Shodan")
    assert foo.name == "Shodan"

# Generated at 2022-06-21 12:35:55.782729
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


# Generated at 2022-06-21 12:36:00.934427
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # noinspection PyPep8Naming
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__['y'] == 6

# Generated at 2022-06-21 12:36:13.101865
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    from unittest import TestCase, main

    class MyClass():
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    class Test_cached_property___get__(TestCase):
        # def test_cached_property___get__00(self):
        #     obj = MyClass(5)
        #     obj.y # FIXME
        #     obj.x = 6
        #     obj.y # FIXME

        def test_cached_property___get__01(self):
            obj = MyClass(5)
            self.assertEqual(obj.y, 6)

# Generated at 2022-06-21 12:36:15.536712
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property"""
    import doctest

    doctest.testmod()



# Generated at 2022-06-21 12:36:20.717099
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Test(object):
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x ** 2

    obj = Test(2)
    assert obj.y == 4
    assert obj.__dict__ == {'x': 2, 'y': 4}



# Generated at 2022-06-21 12:36:26.719691
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


# Generated at 2022-06-21 12:36:34.316481
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():  # noqa: MC0001
    # Initialize
    def test_func():
        pass

    # Test
    assert isinstance(cached_property(test_func), cached_property)
    assert isinstance(cached_property.__get__(cached_property(test_func),
                                              cached_property), cached_property)
    assert isinstance(cached_property.__get__(cached_property(test_func),
                                              cached_property), cached_property)

# Generated at 2022-06-21 12:36:40.311718
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest
    from flutils.decorators import cached_property

    class TestClass:
        @cached_property
        def test_method(self):
            return 5

    obj = TestClass()

    assert isinstance(obj.test_method, int)

    assert obj.test_method == 5



# Generated at 2022-06-21 12:36:48.506470
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test cached_property.__get__()"""

    class MyClass(object):
        """An example class"""

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """Docstring for cached property y"""
            return self.x + 1

        @cached_property
        def z(self):
            """Docstring for cached property z"""
            return self.x + 1

    obj = MyClass()
    assert isinstance(obj.y, int)
    assert isinstance(obj.z, int)



# Generated at 2022-06-21 12:36:51.596820
# Unit test for constructor of class cached_property
def test_cached_property():
    # Just instantiate
    cached_property(lambda obj: obj)


if __name__ == '__main__':
    from pytest import main

    main(['-v', __file__])

# Generated at 2022-06-21 12:37:02.065201
# Unit test for constructor of class cached_property
def test_cached_property():

    class MyTestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """Method y."""
            return self.x + 1

    test_obj = MyTestClass()

    assert test_obj.y == 6

    assert test_obj.__dict__.keys() == ['x', 'y']
    assert test_obj.__dict__.values() == [5, 6]

    test_obj.x = 6

    assert test_obj.y == 6

    assert test_obj.__dict__.keys() == ['x', 'y']
    assert test_obj.__dict__.values() == [6, 6]

    del test_obj.y

    assert test_obj.y == 7

    assert test_obj.__dict__.keys()

# Generated at 2022-06-21 12:37:06.449041
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Unit test for constructor of class cached_property
    """

    @cached_property
    def add_one(self):
        """
        Add one
        """
        return self.x + 1

    assert add_one.__doc__ == "Add one"


# EOF

# Generated at 2022-06-21 12:37:17.720265
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test ``cached_property.__get__`` method.

    """

    cls = cached_property

    def test(obj, i):
        return obj + i

    #: Test: Get the function of a cached_property and verify it.
    t = cls(test)
    rv = t.__get__(None, '')
    assert rv == test

    #: Test: Get the value of a cached_property and verify it.
    rv = t.__get__(1, '')
    assert rv == 2

    #: Test: Get the attribute of a cached_property and verify it.
    rv = t.__get__(None, '')
    assert rv == t

    #: Test: Verify the cached_property is a property.
    assert isinstance(t, property)

    #:

# Generated at 2022-06-21 12:37:26.495164
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import sys
    import asyncio
    from random import randint

    # random.randint is a synchronous function
    def sync_randint(mim, max):
        return randint(min, max)

    # random.randint is an asynchronous function
    @asyncio.coroutine
    def async_randint(min, max):
        return randint(min, max)

    # class with sync_randint
    class SyncClass(object):
        def __init__(self):
            pass

        @cached_property
        def randint(self):
            return sync_randint(0, 99)


    # class with async_randint
    class AsyncClass(object):
        def __init__(self):
            pass

        @cached_property
        def randint(self):
            return async_

# Generated at 2022-06-21 12:37:37.060998
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property."""

    def test_class():
        """Test class."""

        class TestClass:

            def __init__(self, x: int) -> None:
                self.x = x

            @cached_property
            def y(self) -> int:
                return self.x + 1

        return TestClass

    # Test instance of test class
    Instance = test_class()(5)

    # Test ordinary attribute
    assert Instance.x == 5
    assert Instance.__dict__ == {'x': 5}

    # Test cached attribute
    assert Instance.y == 6
    assert Instance.__dict__ == {'x': 5, 'y': 6}

    # Test changing ordinary attribute
    Instance.x = 10

# Generated at 2022-06-21 12:37:45.482228
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import types

    class X:
        @cached_property
        def x(self):
            return "x"

    x = X()
    assert isinstance(x.x, types.CoroutineType) is False
    assert x.x == "x"



# Generated at 2022-06-21 12:37:47.885032
# Unit test for constructor of class cached_property
def test_cached_property():

    class TestClass:
        @cached_property
        def x(self):
            return 'test'


    obj = TestClass()
    assert 'test' == obj.x



# Generated at 2022-06-21 12:37:54.663768
# Unit test for constructor of class cached_property
def test_cached_property():
    """Tests for the :obj:`~flutils.decorators.cached_property` class."""

    # noinspection PyUnresolvedReferences
    class TestClass:
        """Class for testing the :obj:`~flutils.decorators.cached_property`
        class constructor.
        """

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    test_obj = TestClass()
    assert test_obj.y == 6

    test_obj.x = 15
    assert test_obj.y == 6

    del test_obj.y
    assert not hasattr(test_obj, 'y')
    assert test_obj.y == 16

# Generated at 2022-06-21 12:37:59.287471
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.x = 2
    assert obj.y == 3
    obj.x = 3
    assert obj.y == 3
    del obj.y
    obj.x = 4
    assert obj.y == 5

# Generated at 2022-06-21 12:38:06.683217
# Unit test for constructor of class cached_property
def test_cached_property():
    # test class for cached_property usage example
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert isinstance(obj.y, int)
    obj.x = 10
    assert obj.y == 6
    del obj.y
    assert obj.y == 11

# Generated at 2022-06-21 12:38:16.717586
# Unit test for constructor of class cached_property
def test_cached_property():

    class Foo:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        async def async_y(self):
            return self.x + 1

    obj = Foo()

    # test the cached property
    assert obj.y == 6
    assert obj.__dict__['y'] == 6

    # test the async cached property (awaits completion before assigning)
    assert await obj.async_y == 6
    assert isinstance(obj.__dict__['async_y'], asyncio.Future)
    assert obj.__dict__['async_y'].done()


if __name__ == '__main__':
    test_cached_property()

# Generated at 2022-06-21 12:38:26.503550
# Unit test for constructor of class cached_property

# Generated at 2022-06-21 12:38:30.326900
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6



# Generated at 2022-06-21 12:38:34.744370
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class Class1(object):
        def __init__(self):
            self.__dict__ = {}

    def func1(self):
        return True

    x = cached_property(func1)
    assert x.func is func1 and x.__doc__ == func1.__doc__



# Generated at 2022-06-21 12:38:37.838284
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class _Class_:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert _Class_().y == 6



# Generated at 2022-06-21 12:38:58.429635
# Unit test for constructor of class cached_property
def test_cached_property():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    def test_my_class():
        obj = MyClass()
        assert obj.y == 6
        obj.x = 10
        assert obj.y == 11
        del obj.y
        assert obj.y == 16

    def test_class_cached_property():
        class MyClass2:

            def __init__(self):
                self.x = 5

            @cached_property
            def y(self):
                return self.x + 1

        obj = MyClass2()
        assert obj.y == 6
        obj.x = 10
        assert obj.y == 11
        del obj.y
        assert obj.y == 16



# Generated at 2022-06-21 12:39:03.051534
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:39:06.796366
# Unit test for constructor of class cached_property
def test_cached_property():

    # noinspection PyMissingOrEmptyDocstring
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:39:08.672437
# Unit test for constructor of class cached_property
def test_cached_property():
    assert issubclass(cached_property, object)


# Generated at 2022-06-21 12:39:12.749457
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property.
    """
    def test_func():
        pass

    c = cached_property(test_func)
    assert c.func == test_func
    assert c.__doc__ == test_func.__doc__



# Generated at 2022-06-21 12:39:19.161227
# Unit test for constructor of class cached_property
def test_cached_property():
    # We're in the global scope here.
    #  Would get the following failure without explicit reference to the class:
    #     NameError: name 'cached_property' is not defined

    class Foo:
        @cached_property.cached_property
        def bar(self):
            return object()

    foo = Foo()
    b1 = foo.bar
    b2 = foo.bar
    assert b1 is b2
    del foo.bar
    b3 = foo.bar
    assert b3 is not b2

    # Test for coroutine function
    c = foo.bar
    assert asyncio.iscoroutine(c)

# Generated at 2022-06-21 12:39:25.862799
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    # Test the __get__ method behaves as a normal property
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Test the __get__ method behaves as a normal property
    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:39:30.453913
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # noinspection PyPep8Naming
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:39:31.412900
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass


# Generated at 2022-06-21 12:39:38.550575
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""

    class MyClass:

        # noinspection PyMethodMayBeStatic
        def __init__(self):
            self.x = 5

        # noinspection PyMethodMayBeStatic
        @cached_property
        def y(self):
            """Test."""
            return self.x + 1

    obj = MyClass()
    assert type(obj.y) is int
    assert obj.y == 6
    assert type(MyClass().y) is int
    assert obj.__class__.y.__doc__ == "Test."



# Generated at 2022-06-21 12:40:03.372163
# Unit test for constructor of class cached_property
def test_cached_property():
    class TestClass:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    test_instance = TestClass(5)
    assert test_instance.y == 6

# Generated at 2022-06-21 12:40:06.365433
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    obj.y
    assert obj.y == 6

# Generated at 2022-06-21 12:40:12.114986
# Unit test for constructor of class cached_property
def test_cached_property():
    class Example:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    ex = Example(5)
    assert ex.y == 6
    assert 'y' in ex.__dict__
    delattr(ex, 'y')
    assert 'y' not in ex.__dict__

# Generated at 2022-06-21 12:40:22.424800
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property
    import asyncio
    class Foo:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            async def async_z():
                await asyncio.sleep(1)
                return self.x + 2

            return async_z

    f = Foo(1)
    assert f.y == 2
    assert isinstance(f.y, int)
    # cached
    assert f.y == 2
    assert isinstance(f.y, int)
    assert f.z == f.z
    assert isinstance(f.z, asyncio.Future)
    loop = asyncio.get_event_loop()


# Generated at 2022-06-21 12:40:30.435232
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import sys
    import os
    import unittest

    class Test(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test__cached_property___get__(self):
            if sys.version_info[:2] < (3, 8):
                self.assertTrue(False)

        @unittest.skipUnless(sys.version_info[:2] < (3, 8), "Requires Python < 3.8")
        def test__cached_property___get___no38(self):
            from flutils.decorators import cached_property

            class MyClass:

                def __init__(self):
                    self.x = 5

                @cached_property
                def y(self):
                    return self.x + 1

           

# Generated at 2022-06-21 12:40:34.833164
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property"""

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:40:35.740362
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass

# Generated at 2022-06-21 12:40:37.844910
# Unit test for constructor of class cached_property
def test_cached_property():
    assert(cached_property is not None)



# Generated at 2022-06-21 12:40:44.270003
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__ == {'x': 5, 'y': 6}
    obj.x = 8
    assert obj.y == 6



# Generated at 2022-06-21 12:40:48.776023
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property"""

    class A:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """Test pydoc."""
            return self.x + 1

    obj = A()
    assert obj.y == 6

# Generated at 2022-06-21 12:41:38.959444
# Unit test for constructor of class cached_property
def test_cached_property():
    # create a class with a cached_property
    class A:
        def __init__(self):
            self.x = 5

        # this is the cached_property
        @cached_property
        def y(self):
            return self.x + 1

    # create an object
    a = A()

    # test cached_property
    assert a.y == 6

# Generated at 2022-06-21 12:41:47.112395
# Unit test for constructor of class cached_property
def test_cached_property():
    import pytest
    from flutils._decorators import cached_property

    # Test basic class
    class Test(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def myprop(self):
            return self.x


    t = Test()
    assert t.myprop == 5
    assert t.myprop == 5
    t.x = 7
    assert t.myprop == 7
    assert t.myprop == 7

    # Test docstring
    class Test(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def myprop(self):
            'docstring'
            return self.x

    t = Test()
    assert t.myprop.__doc__ == 'docstring'


    #

# Generated at 2022-06-21 12:41:51.428413
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:41:58.462900
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self, x: int) -> None:
            self.x = x

        @cached_property
        def y(self) -> int:
            return self.x + 1

    # Get the property value
    obj = MyClass(1)
    assert obj.y == 2

    # Delete the property
    del obj.y
    with pytest.raises(KeyError):
        _ = obj.y

    # Show that the property is re-computed
    obj.x = 2
    assert obj.y == 3

# Generated at 2022-06-21 12:42:02.667822
# Unit test for constructor of class cached_property
def test_cached_property():

    class MyClass(object):

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    assert obj.y == 6

    # Clean up
    del obj


if __name__ == '__main__':
    test_cached_property()

# Generated at 2022-06-21 12:42:13.976552
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from pytest import mark, raises

    from flutils.decorators import cached_property

    # noinspection PyUnusedLocal
    @cached_property
    def _cached_property_test__func(obj):
        class TestClass:

            def __init__(self):
                # noinspection PyAttributeOutsideInit
                self.x = 5

            @cached_property
            def y(self):
                return self.x + 1

        obj = TestClass()
        assert obj.y == 6
        assert obj.__dict__ == {'x': 5, 'y': 6}
        del obj.y
        assert obj.__dict__ == {'x': 5}

        @cached_property
        def y(obj):
            return obj.x + 1


# Generated at 2022-06-21 12:42:21.129511
# Unit test for constructor of class cached_property
def test_cached_property():
    class Test:
        def __init__(self):
            self._x = 5

        @cached_property
        def x(self):
            return self._x

        @x.deleter
        def x(self):
            del self._x

    t = Test()
    assert t.x == 5
    t.x = 6
    assert t.x == 6
    del t.x
    assert t.x == 5



# Generated at 2022-06-21 12:42:25.698491
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property."""

    # noinspection PyUnusedLocal
    class MyClass:

        def __init__(self):
            self.x = 5
            self.y = None

        @cached_property
        def y(self):
            self.y = self.x + 1
            return self.y

    obj = MyClass()
    assert obj.y == obj.x + 1

# Generated at 2022-06-21 12:42:30.144007
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """ Unit test for method __get__ of class cached_property """

    class MyClass:
        @cached_property
        def y(self):
            return self.x + 1

        def __init__(self):
            self.x = 5

    obj = MyClass()
    assert obj.y == 6
    assert obj.y == 6



# Generated at 2022-06-21 12:42:30.945781
# Unit test for constructor of class cached_property
def test_cached_property():
    return



# Generated at 2022-06-21 12:44:19.352221
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:44:29.297496
# Unit test for constructor of class cached_property
def test_cached_property():
    from types import MethodType
    from functools import wraps

    from flutils import create_future, ErrorMessage

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.y == 6

    def wibblez(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            return func(*args, **kwargs)
        return wrapper

    @wibblez
    @cached_property
    def z(self):
        return self.x + 1

    class MyClass2:

        def __init__(self):
            self.x = 5

        z = z

    obj = MyClass2

# Generated at 2022-06-21 12:44:33.026825
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Pytest for cached_property
    """

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y



# Generated at 2022-06-21 12:44:42.073326
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit tests for cached_property.

    *New in version 0.2.0*

    """

    def get_id(obj):
        """Get an attributes id."""
        return id(obj)

    class MyClass:
        """The class instance to be tested."""

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """The method to be decorated."""
            return self.x + 1

    obj = MyClass()
    assert get_id(obj) == get_id(obj)
    assert get_id(obj) == get_id(obj.y)

