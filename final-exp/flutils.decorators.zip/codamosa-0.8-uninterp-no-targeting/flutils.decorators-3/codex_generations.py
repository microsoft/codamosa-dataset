

# Generated at 2022-06-21 12:34:48.619494
# Unit test for constructor of class cached_property
def test_cached_property():

    print(__doc__)

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    print(obj.y)


if __name__ == "__main__":
    test_cached_property()

# Generated at 2022-06-21 12:35:00.575064
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Pure Python
    import io
    import os
    import re
    import sys
    import unittest

    class cached_propertyTests(unittest.TestCase):
        """Unit test for class cached_property."""

        def setUp(self):
            """Set up each test."""
            self.inst = cached_property()

        def test_property(self):
            """Test property of cached_property."""
            self.assertEqual(self.inst.property, self.inst.property)
            self.assertIsNotNone(self.inst.__dict__["property"])

        def test_property_of_instance(self):
            """Test property on instance of cached_property."""
            self.assertEqual(self.inst.property_of_instance,
                             self.inst.property_of_instance)


# Generated at 2022-06-21 12:35:04.270021
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:
        ''' Test class for cached_property constructor '''

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1



# Generated at 2022-06-21 12:35:10.575577
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property
    from time import time


    class MyClass:

        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass(3)
    assert obj.y == 4

    # Delete the attribute and reset the property
    del obj.y
    assert obj.y == 4

    # Cleanup
    del obj



# Generated at 2022-06-21 12:35:13.879561
# Unit test for constructor of class cached_property
def test_cached_property():
    class A:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = A()
    assert obj.y == 6

# Generated at 2022-06-21 12:35:26.598790
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    @cached_property
    def x(obj):
        return 5 + 1

    # Test 1
    obj = object()
    result = x.__get__(obj, object)
    assert result is not x
    assert result() == 6

    # Test 2
    result = x.__get__(None, object)
    assert result is x
    assert result.func is x.func

    # Test 3
    result = x.__get__(None, object)
    assert result is x
    assert result.func is x.func

    # Test 4
    result = x.__get__(None, object)
    assert result is x
    assert result.func is x.func

    # Test 5
    result = x.__get__(None, object)
    assert result is x
    assert result.func is x.func

# Generated at 2022-06-21 12:35:30.089814
# Unit test for constructor of class cached_property
def test_cached_property():
    class Foo:
        @cached_property
        def bar(self):
            return 'baz'
    f = Foo()
    assert f.bar == 'baz'  # Test property
    assert f.__dict__ == {'bar': 'baz'}  # Test caching

# Generated at 2022-06-21 12:35:41.182094
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Something:
        @cached_property
        def x(self):
            return self.foo

        def update_x(self, foo):
            self.foo = foo

    obj = Something()
    assert obj.x is None

    obj.update_x(10)
    assert obj.x == 10

    obj.update_x(20)
    assert obj.x == 10

    obj.update_x(40)
    assert obj.x == 10

    del obj.x
    assert obj.x is None

    obj.update_x(20)
    assert obj.x == 20

    obj.update_x(10)
    assert obj.x == 20

    del obj.x
    assert obj.x is None


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 12:35:48.502721
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest import mock

    class MyClass:
        pass

    myobj = MyClass()

    m_getattr = mock.Mock()
    getattr(myobj, '__dict__')['__doc__'] = 'Test'
    with mock.patch('flutils.decorators.cached_property.get', m_getattr):
        cm = cached_property(mock.Mock(__name__='test'))
        cm.__get__(myobj, myobj.__class__)

# Generated at 2022-06-21 12:35:56.199962
# Unit test for constructor of class cached_property
def test_cached_property():
    # Create class with property
    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Make instance of class
    test_obj = TestClass()
    # Make sure that y is 6
    assert test_obj.y == 6
    # Change x
    test_obj.x = 10
    # Make sure y is still 6
    assert test_obj.y == 6

# Generated at 2022-06-21 12:36:02.048540
# Unit test for constructor of class cached_property
def test_cached_property():
    class A:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    a = A()
    assert a.y == 6
    a.x = 10
    assert a.y == 6

# Generated at 2022-06-21 12:36:12.884535
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x + 1

    obj = TestClass()
    # Test return value of function y
    assert obj.y == 6
    # Test that function y function is cached
    # and returns the cached value
    obj.x = 10
    assert obj.y == 6
    # Test that function y can be deleted
    del obj.y
    assert obj.y == 7
    # Test that function z can be deleted
    del obj.z
    assert obj.z == 7



# Generated at 2022-06-21 12:36:16.346076
# Unit test for constructor of class cached_property
def test_cached_property():
    def f():
        pass

    # noinspection PyTypeChecker
    obj = cached_property(f)
    assert isinstance(obj, cached_property)

# Generated at 2022-06-21 12:36:18.627686
# Unit test for constructor of class cached_property
def test_cached_property():
    from .is_decorator import is_decorator
    assert is_decorator(cached_property)


# Generated at 2022-06-21 12:36:26.239686
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property
    import pytest
    from pytest import raises
    import gc

    # =========================================================================
    # test_cached_property_1
    # -------------------------------------------------------------------------
    class A:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # -------------------------------------------------------------------------
    a = A()
    # -------------------------------------------------------------------------
    assert a.y == 6

    # =========================================================================
    # tes

# Generated at 2022-06-21 12:36:28.096330
# Unit test for constructor of class cached_property
def test_cached_property():
    @cached_property
    def x(self):
        self.x = 5

    obj = x()
    assert x == obj

# Generated at 2022-06-21 12:36:35.490742
# Unit test for constructor of class cached_property
def test_cached_property():
    # noinspection PyPep8Naming
    class Test:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Test cached_property
    t = Test()
    assert t.y == 6
    t.x = 8
    assert t.y == 9
    t.x = -14
    assert t.y == 9

# Generated at 2022-06-21 12:36:46.140823
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    from threading import RLock
    from unittest.mock import Mock, patch
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == obj.__dict__['y']
    assert obj.y == 6

    obj.__dict__.pop('y')
    obj.x = 10
    assert obj.y == obj.__dict__['y']
    assert obj.y == 11


# Generated at 2022-06-21 12:36:52.719876
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method ``__get__`` of class `cached_property`."""
    class TestUnitTest:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return int(self.x) + 1

        @property
        def m(self):
            return self.x + 1

    assert TestUnitTest.y.__doc__ == 'A property decorator that is only computed once per instance and then replaces itself with an ordinary attribute.\n\nDeleting the attribute resets the property.'
    assert TestUnitTest().y == 6
    obj = TestUnitTest()
    assert obj.__dict__ == {'x': 5}
    assert obj.z == 6

# Generated at 2022-06-21 12:36:58.214434
# Unit test for constructor of class cached_property
def test_cached_property():
    class Test(object):
        @cached_property
        def test(self):
            return 1

    obj = Test()
    first = obj.test
    second = obj.test
    assert first == second
    del obj.test
    third = obj.test
    assert first == third



# Generated at 2022-06-21 12:37:11.146659
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest import TestCase

    class MyTest(TestCase):

        def test_cached_property(self):
            obj = MyClass()
            self.assertEqual(type(obj.y), cached_property)

    class MyClass:

        @cached_property
        def y(self):
            return None

    try:
        MyTest()
        MyTest.test_cached_property()
    except TypeError as e:
        # noinspection PyUnresolvedReferences
        MyTest.Y = type('', (), {})()
        MyTest.assertEqual = lambda self, a, b: None
        MyTest()
        MyTest.test_cached_property()

# Generated at 2022-06-21 12:37:22.734255
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        async def z(self):
            return self.x + 2

    obj = MyClass()

    assert "y" not in obj.__dict__
    assert obj.y == 6
    assert "y" in obj.__dict__
    assert "z" not in obj.__dict__
    assert asyncio.iscoroutine(obj.z)
    assert "z" in obj.__dict__
    assert asyncio.iscoroutine(obj.z)

    old_y = obj.y
    old_z = obj.z
    obj.x = 6
    assert old_y == obj.y

# Generated at 2022-06-21 12:37:33.782951
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""
    import types
    import sys

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    if sys.version_info >= (3, 8):
        assert isinstance(obj.y, types.AsyncGeneratorType)
        assert isinstance(obj.y, types.CoroutineType)

        async def coro():
            return obj.y

        loop = asyncio.get_event_loop()
        future = asyncio.ensure_future(coro())
        loop.run_until_complete(future)
        loop.close()

        assert future.result() == 6
    else:
        obj.y

# Generated at 2022-06-21 12:37:44.437538
# Unit test for constructor of class cached_property
def test_cached_property():
    from types import FunctionType
    from copy import copy

    cp = cached_property(None)
    assert isinstance(cp, cached_property)
    assert isinstance(cp.__init__, FunctionType)
    assert isinstance(cached_property.__doc__, str)
    assert isinstance(cached_property.__dict__, dict)
    assert isinstance(cached_property.__init__, FunctionType)
    assert isinstance(cp.__get__, FunctionType)
    assert isinstance(cp._wrap_in_coroutine, FunctionType)
    assert isinstance(cp.__new__, FunctionType)
    assert copy(cp) is cp


# Generated at 2022-06-21 12:37:47.847245
# Unit test for constructor of class cached_property
def test_cached_property():

    # noinspection PyPep8Naming
    class c:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    x = c()
    assert x.y == 6

# Generated at 2022-06-21 12:37:49.750831
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.miscutils import DummyClassForUnitTests

    obj = DummyClassForUnitTests()

    assert obj.y == 6

# Generated at 2022-06-21 12:38:00.831404
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self, value):
            self.value = value

        @cached_property
        def x6(self):
            return self.value * 6

        @cached_property
        async def x6_async(self):
            await asyncio.sleep(1)
            return self.value * 6

    obj = MyClass(5)
    assert obj.x6 == 30
    assert isinstance(obj.__dict__['x6'], int)

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    # noinspection PyCallingNonCallable
    assert loop.run_until_complete(obj.x6_async) == 30
    # noinspection PyTypeChecker

# Generated at 2022-06-21 12:38:06.019787
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    m = MyClass()
    assert m.y == 6



# Generated at 2022-06-21 12:38:09.576983
# Unit test for constructor of class cached_property
def test_cached_property():
    @cached_property
    def f():
        return 1
    assert f is not 1
    assert f() == 1
    assert callable(f().__class__)
    assert f() == 1

# Generated at 2022-06-21 12:38:13.035230
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property."""
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert MyClass().y == 6

# Generated at 2022-06-21 12:38:26.059999
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert 6 == obj.y

# Generated at 2022-06-21 12:38:34.249254
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Unit tests for constructor of class cached_property
    """
    #   GIVEN
    class Widget:

        # noinspection PyPep8Naming
        @cached_property
        def get_widget_type(self):
            return self.type

    w = Widget()
    w.type = 9

    #   WHEN
    int_result = w.get_widget_type

    #   THEN
    assert (int_result == 9)
    del w.get_widget_type
    #   WHEN
    int_result = w.get_widget_type

    #   THEN
    assert (int_result == 9)



# Generated at 2022-06-21 12:38:37.090208
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyTestClass:

        @cached_property
        def test_func(self):
            return "test"

    assert MyTestClass.test_func.__doc__ == "test_func"



# Generated at 2022-06-21 12:38:41.780433
# Unit test for constructor of class cached_property
def test_cached_property():

    class TestClass:
        @cached_property
        def test_property(self):
            return 5

    tc = TestClass()

    assert tc.test_property == TestClass.test_property.__get__(tc, TestClass)
    tc.__dict__['test_property'] = 6
    assert tc.test_property == 6

# Generated at 2022-06-21 12:38:49.272507
# Unit test for constructor of class cached_property
def test_cached_property():

    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


if __name__ == "__main__":
    """
    To test the class cached_property do:

    .. code-block:: python

        python -m flutils.decorators
    """

    import doctest

    doctest.testmod()

# Generated at 2022-06-21 12:38:58.990926
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit tests for :obj:`flutils.decorators.cached_property`

    Tests for:

    * class initialization
    * basic class function
    * class function for async methods

    """

    class regular_class:
        """A regular class"""
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """A regular cached_property method"""
            return self.x + 1

        @cached_property
        def z(self):
            """An async cached_property method"""
            return asyncio.create_task(self._async_z())

        async def _async_z(self):
            """A private method to test the async wrapper"""
            return self.x + 1

    import sys

# Generated at 2022-06-21 12:39:05.835363
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    def __get__(obj, cls):
        # pylint: disable=unused-argument
        if obj is None:
            return cls

        return obj + cls

    # noinspection PyTypeChecker
    obj = cached_property(__get__)
    # pylint: disable=unsubscriptable-object
    assert obj.__get__(1, 2) == 3

# Generated at 2022-06-21 12:39:14.508530
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class CTest:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    objTest = CTest()
    assert objTest.y == 6

    class CTestAsync:
        def __init__(self):
            self.x = 5

        @cached_property
        async def y(self):
            await asyncio.sleep(1)
            return self.x + 1

    objTestAsync = CTestAsync()
    # noinspection PyTypeChecker
    assert asyncio.iscoroutinefunction(objTestAsync.y)

# Generated at 2022-06-21 12:39:18.252537
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Test cached_property
    """

    class _class1:

        def __init__(self, *args, **kwargs):
            pass

        @cached_property
        def _test(self):
            return 'test'

    c1 = _class1()
    assert c1._test == 'test'



# Generated at 2022-06-21 12:39:29.861703
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Method to test the getter of :class:`cached_property`

    *New in version 0.6.0*

    """

    from unittest.mock import Mock

    class MyClass:
        def __init__(self, func):
            self.func = func
            self.other = func

        # noinspection PyPep8Naming
        @cached_property
        def calc(self):
            return self.func()

        @calc.setter
        def calc(self, val):
            self.__dict__["calc"] = val

        # noinspection PyPep8Naming
        @cached_property
        def calc2(self):
            return self.other()

    _func = Mock(return_value=5)
    obj = MyClass(_func)


# Generated at 2022-06-21 12:39:55.489362
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""
    class A:
        def __init__(self):
            self.a = 1

        @cached_property
        def get_a(self):
            return self.a

    a = A()
    assert a.a == a.get_a


# Generated at 2022-06-21 12:40:00.405175
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    myclass = MyClass()
    assert myclass.y == 6
    assert hasattr(myclass, 'y')
    myclass.y = 7
    assert myclass.y == 7
    del myclass.y
    assert myclass.y == 6

# Generated at 2022-06-21 12:40:03.777494
# Unit test for constructor of class cached_property
def test_cached_property():
    """ Unit tests for constructor of class cached_property
    """
    print('Testing cached_property constructor')
    cached_property(test_cached_coroutine)
    cached_property(test_cached_function)



# Generated at 2022-06-21 12:40:11.080601
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    def func():
        pass

    cp = cached_property(func)

    assert cp.__get__(None, None) == cp

    # __get__ returns value of obj.__dict__[self.func.__name__]
    # if that exists
    obj = Mock()
    obj.__dict__['func'] = 'return value'
    assert cp.__get__(obj, None) == 'return value'

    # __get__ sets value of obj.__dict__[self.func.__name__], and returns
    # that value, if obj.__dict__[self.func.__name__] does not already exist
    obj = Mock()
    obj.__dict__ = {}
    cp.func = Mock()
    returned = cp.__get__(obj, None)
    assert cp.func.called
    assert obj

# Generated at 2022-06-21 12:40:21.263799
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import asyncio
    from collections.abc import Coroutine

    class Method:
        def __init__(self):
            self.flag = False

        @cached_property
        def method(self):
            self.flag = True
            return 1

    class CoroMethod:
        def __init__(self):
            self.flag = False

        @cached_property
        @asyncio.coroutine
        def coro_method(self):
            self.flag = True
            return 1

    method = Method()
    coro_method = CoroMethod()
    assert not method.flag
    assert method.method == 1
    assert method.flag
    assert list(method.__dict__.keys()) == ['method']
    assert method.__dict__['method'] == 1
    assert not coro_method.flag
   

# Generated at 2022-06-21 12:40:25.048021
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:40:30.388807
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == obj.__dict__['y'] == 6

    obj.x = 7

    assert obj.y == 6



# Generated at 2022-06-21 12:40:39.713815
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""

    class MyClass:

        # noinspection PyPep8Naming
        @cached_property
        def y(self):
            """The y property."""
            return self.x + 1

    obj = MyClass()
    obj.x = 5

    # Check a lazy object property
    assert hasattr(obj.__class__, "y")
    assert obj.y == 6
    assert "y" in obj.__dict__

    # Check a lazy class property
    assert hasattr(MyClass, "y")
    assert MyClass.y is not None
    assert MyClass.y.__doc__ == "The y property."

    # Check class property deletion
    del MyClass.y
    assert hasattr(MyClass, "y")

# Generated at 2022-06-21 12:40:43.801097
# Unit test for constructor of class cached_property
def test_cached_property():
    class A:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = A()
    return obj.y



# Generated at 2022-06-21 12:40:47.613253
# Unit test for constructor of class cached_property
def test_cached_property():
    # Set up
    class TestClass:
        @cached_property
        def test_property(self):
            return 'hello world'

    # Exercise
    test_obj = TestClass()

    # Verify
    assert test_obj.test_property == 'hello world'



# Generated at 2022-06-21 12:41:39.322554
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test method cached_property.__get__
    """

    class MyClass:

        def __init__(self, x):
            self.x = x
            self._y = None
            self._z = None

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            if self._z is None:
                self._z = self.x + 1

        @cached_property
        def a(self):
            return None

        @cached_property
        def b(self):
            pass

    obj = MyClass(5)
    assert obj.y
    assert obj.z
    assert not obj.a
    assert not obj.b

# Generated at 2022-06-21 12:41:43.361288
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for :func:`flutils.decorators.cached_property:__init__`."""

    def func(obj):
        return obj.x + 1

    prop = cached_property(func)
    assert prop.__doc__ == func.__doc__

# Generated at 2022-06-21 12:41:54.673296
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import inspect
    import pytest

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert "y" in obj.__dict__
    assert obj.__dict__["y"] == 6
    assert "y" not in MyClass.__dict__
    assert inspect.ismethod(obj.y)
    assert inspect.isbuiltin(obj.y.__func__)

    del obj.y
    assert "y" not in obj.__dict__
    assert isinstance(obj.y, cached_property)


# Generated at 2022-06-21 12:42:03.196178
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property
    from flutils.loaders import to_module
    from logging import getLogger
    from inspect import signature

    logger = getLogger(__name__)

    def func():
        pass

    cpd = cached_property(func)
    assert cpd.func is func

    cpd = cached_property(func=func)
    assert cpd.func is func

    assert signature(cpd).return_annotation is None

    class TestClass:

        @cached_property
        def test_method(self):
            pass

    assert type(TestClass.test_method) is cached_property

    assert to_module(TestClass.test_method) == "flutils.decorators"



# Generated at 2022-06-21 12:42:14.554643
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import mock

    class C:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # class C has a new member function: y
    assert C.__dict__['y'].__name__ == 'y'
    assert C.__dict__['y'].__doc__ == 'y(self)'

    # Test when obj is None
    obj = C()
    mock_func = mock.Mock(return_value=1)
    cp = cached_property(mock_func)
    func = cp.__get__(obj=None, cls=C)
    assert func.__name__ == 'y'
    assert func.__doc__ == 'y(self)'

    # Test when obj is not

# Generated at 2022-06-21 12:42:20.136941
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Setup
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    # Verify
    assert obj.y == 6


# Generated at 2022-06-21 12:42:24.053153
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    obj.x = 11
    assert obj.y == 6

# Generated at 2022-06-21 12:42:28.839902
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # unit test for __get__ of class cached_property
    class Foo:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    foo = Foo()
    assert foo.y == 6
    return


if __name__ == '__main__':
    import pytest

    pytest.main([__file__])

# Generated at 2022-06-21 12:42:40.176724
# Unit test for constructor of class cached_property
def test_cached_property():
    class A:
        def __init__(self):
            self._x = 0
            self._y = 0
            self._z = 0

        @cached_property
        def x(self):
            self._x += 1
            return self._x

        @cached_property
        def y(self):
            from asyncio import sleep
            from flutils.decorators import cached_property
            from flutils.decorators.async_utils import async_run_sync

            @cached_property
            @async_run_sync
            async def coro():
                await sleep(0.1)
                self._y += 1
                return self._y

            return coro()

    a = A()
    assert a.x == 1
    assert a.x == 1
    assert a.y == 1

# Generated at 2022-06-21 12:42:43.995708
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test cached_property constructor.

    .. todo:: The constructor tests are incomplete.

    """
    def test_func(arg):
        """Test function for cached property decorator."""
        return arg

    test_obj = cached_property(test_func)
    test_obj.__doc__
    test_obj.func
    test_obj.func.__doc__



# Generated at 2022-06-21 12:44:41.159666
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from io import StringIO

    class MyClass(object):

        def __init__(self):
            self.x = 'X'

        def __str__(self):
            return 'MyClass()'

        def __repr__(self):
            return '<MyClass()>'
        #
        @cached_property
        def y(self):
            return self.x + 'y'
    #
    # Test input/output
    #
    obj = MyClass()
    rv = obj.y
    assert 'X' == obj.x
    assert 'xy' == rv
    rv = obj.y
    assert 'xy' == rv
    rv = cache_property_equation(obj)
    assert 'xy' == rv
    #
    # Test repr and str
    #
    s