

# Generated at 2022-06-21 12:34:48.776446
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


# Generated at 2022-06-21 12:34:57.731769
# Unit test for constructor of class cached_property
def test_cached_property():
    class A:

        def __init__(self, x, y):
            self.x = x
            self.y = y

        @cached_property
        def xy(self):
            return self.x * self.y

        @cached_property
        def yx(self):
            return self.y * self.x

    a = A(3, 4)
    # testing correct multiplication
    assert a.xy == 12
    assert a.yx == 12
    # testing caching
    a.x = 7
    assert a.xy == 12
    assert a.yx == 12

# Generated at 2022-06-21 12:35:04.246788
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from types import MethodType
    from unittest.mock import patch

    # noinspection PyMissingTypeHints,PyUnusedLocal,PyPep8Naming
    class Class:
        def __init__(self):
            pass

        @cached_property
        def prop(self):
            return 5

    classInstance = Class()
    assert hasattr(classInstance, 'prop')

    propertyDescriptor = getattr(Class, 'prop')
    assert isinstance(propertyDescriptor, cached_property)
    propertyMethod = getattr(classInstance, 'prop')
    assert isinstance(propertyMethod, MethodType)

    assert propertyDescriptor.__get__(propertyMethod.__self__, Class) \
           is propertyMethod



# Generated at 2022-06-21 12:35:13.363955
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.cache = {}

        @cached_property
        def int(self):
            self.cache['int'] = self._int()
            return self.cache.get('int')

        def _int(self):
            return 1

        def delete_int(self):
            del self.int

        @cached_property
        def str(self):
            self.cache['str'] = self._str()
            return self.cache.get('str')

        def _str(self):
            return 'ab'

        def delete_str(self):
            del self.str

    obj = MyClass()
    # Second call to obj.int returns the cached value
    assert obj.int == obj.int
    obj.delete_int()
    # Second call to obj.

# Generated at 2022-06-21 12:35:26.268951
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test of the constructor of the cached_property class

    :return: None
    """
    import logging
    import sys
    import unittest

    from flutils.decorators import cached_property
    from flutils.logging import set_log_level

    set_log_level('error')
    logger = logging.getLogger(__name__)

    # noinspection PyUnusedLocal
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # noinspection PyUnusedLocal
    class MyClass2:

        def __init__(self):
            self.x = 5


# Generated at 2022-06-21 12:35:27.224047
# Unit test for constructor of class cached_property
def test_cached_property():
    help(cached_property.__init__)

# Generated at 2022-06-21 12:35:30.421457
# Unit test for constructor of class cached_property
def test_cached_property():
    pass


if __name__ == "__main__":

    # Run unit tests
    import unittest

    class Test_cached_property(unittest.TestCase):
        def test_nothing_yet(self):
            pass

    unittest.main()

# Generated at 2022-06-21 12:35:35.156359
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class _X:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = _X()
    assert obj.y == 6


if __name__ == '__main__':
    from pytest import main

    main(args=[__file__])

# Generated at 2022-06-21 12:35:41.801428
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class A:

        @cached_property
        def little_parent(self):
            return self.__class__.__name__

    a = A()
    assert a.little_parent == "A"
    assert a.__dict__ == {"little_parent": "A"}
    assert a.little_parent == "A"
    assert a.__dict__ == {"little_parent": "A"}



# Generated at 2022-06-21 12:35:46.785654
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Python 3.7 and earlier
    assert (callable(cached_property(lambda: None).__get__))

    # Python 3.8
    @cached_property  # type: ignore
    def f():
        pass

    assert (callable(f))
    assert (isinstance(f, cached_property))



# Generated at 2022-06-21 12:36:00.691341
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass1:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class MyClass2:
        pass

    class MyClass3:

        def __init__(self, val):
            self.val = val

        @cached_property
        def x(self):
            return self.val

    assert MyClass1.y.__doc__ == MyClass1().y.__doc__

    obj1 = MyClass1()
    assert obj1.y == obj1.y == 6

    del obj1.y
    assert obj1.y == obj1.y == 6

    obj2 = MyClass2()
    assert obj2.y is obj2.y

    obj3 = MyClass3(3)
   

# Generated at 2022-06-21 12:36:06.407624
# Unit test for constructor of class cached_property
def test_cached_property():

    class TestObj(object):

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestObj()
    assert obj.y == 6


if __name__ == '__main__':
    pass

# Generated at 2022-06-21 12:36:10.319525
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Klass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Klass()
    assert obj.y == 6

# Generated at 2022-06-21 12:36:13.648869
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class C:
        def __init__(self) -> None:
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    c = C()
    assert c.y == 6

# Generated at 2022-06-21 12:36:18.293142
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Object:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x ** 2

    obj = Object(5)
    assert obj.y == 25


# Generated at 2022-06-21 12:36:23.093047
# Unit test for constructor of class cached_property
def test_cached_property():
    class Foo(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Foo()
    assert obj.y == 6
    obj.x = 5
    assert obj.y == 6

# Generated at 2022-06-21 12:36:25.795818
# Unit test for constructor of class cached_property
def test_cached_property():
    with pytest.raises(TypeError):
        cached_property()  # should fail because missing positional parameter


# Unit tests for method cached_property.__get__

# Generated at 2022-06-21 12:36:28.605298
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class C:

        @cached_property
        def prop(self):
            return 1

    c = C()

    assert c.prop == 1
    assert C.prop.__get__(c) == 1



# Generated at 2022-06-21 12:36:41.766399
# Unit test for constructor of class cached_property
def test_cached_property():  # pragma: no cover

    from unittest import TestCase

    class CachedPropertyTestCase(TestCase):

        def test_updates_after_deletion(self):
            obj = MyClass()
            self.assertEqual(obj.y, 6)
            obj.x = 10
            self.assertEqual(obj.y, 11)  # Forced evaluation
            del obj.y
            self.assertEqual(obj.y, 11)  # Cached evaluation

        def test_does_not_update_on_subsequent_reads(self):
            obj = MyClass()
            self.assertEqual(obj.y, 6)
            obj.x = 20
            self.assertEqual(obj.y, 6)

        def test_multiple_subsequent_reads(self):
            obj = MyClass()
           

# Generated at 2022-06-21 12:36:49.093289
# Unit test for constructor of class cached_property
def test_cached_property():
    """Tests the constructor of :obj:`cached_property`.

    """
    def my_function():
        """This is added to ``__doc__``."""
        pass

    @cached_property
    def my_class():
        """This is added to ``__doc__``."""
        pass

    assert my_function.__doc__
    assert my_class.__doc__
    assert hasattr(my_class, '__get__')



# Generated at 2022-06-21 12:37:00.928171
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test for :func:`cached_property`.

    :return: No return, code coverage.

    """

    @cached_property
    def prop(self):
        return "test"

    class Test(object):
        def __init__(self):
            self._prop = prop

    obj = Test()
    assert isinstance(obj._prop, cached_property), "prop is not a cached_property."

    assert obj._prop == "test", "cached_property does not return original value."

    return


if __name__ == '__main__':
    test_cached_property___get__()

# Generated at 2022-06-21 12:37:05.322369
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():


    # noinspection PyPep8Naming
    class MyClass:
        @cached_property
        def x(self):
            return 'x'

    obj = MyClass()
    assert obj.x == 'x'



# Generated at 2022-06-21 12:37:16.517112
# Unit test for constructor of class cached_property
def test_cached_property():
    from inspect import iscoroutinefunction
    import functools
    import os

    # Test that caching happens on instance level
    class Cached(object):
        @cached_property
        def x(self):
            return 'x'

    assert Cached().x == 'x'
    assert Cached().x == 'x'
    c = Cached()
    c.x = 'y'
    assert c.x == 'y'

    # Test that property can be deleted
    class Cached(object):
        @cached_property
        def x(self):
            return 'x'

    c = Cached()
    assert c.x == 'x'
    del c.x
    assert 'x' not in c.__dict__
    assert c.x == 'x'

    # Test that property can be set

# Generated at 2022-06-21 12:37:25.937957
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method :meth:`cached_property.__get__` of class
    :class:`~flutils.decorators.cached_property`.

    Since :meth:`cached_property.__get__` is a descriptor, we need to
    instantiate an object and call it on an instance of class
    :class:`MyClass`.

    Test:

        * Call :meth:`cached_property.__get__` on an instance of
          :class:`~flutils.decorators.cached_property`.
        * :meth:`cached_property.__get__` should return a value.

    """

    class MyClass:
        """Class used for unit testing method
        :meth:`~flutils.decorators.cached_property.__get__`."""

# Generated at 2022-06-21 12:37:27.817069
# Unit test for constructor of class cached_property
def test_cached_property():
    import doctest

    doctest.testmod(flutils.decorators)

# Generated at 2022-06-21 12:37:37.641033
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property."""

    # pylint: disable=too-few-public-methods
    class Mock:
        """Mock class for cached_property."""

        def __init__(self):
            self.x = 3

        @cached_property
        def y(self):
            """Property y."""
            return self.x + 1

    class MockAsync:
        """Mock class for cached_property."""
        def __init__(self):
            self.x = 3

        @cached_property
        async def y(self):
            """Property y."""
            await asyncio.sleep(2)
            return self.x + 1

    mock = Mock()
    assert mock.y == 4

    mock = MockAsync()
    asyncio.get_event_loop().run

# Generated at 2022-06-21 12:37:47.646016
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test cached_property.__get__()"""
    import pytest

    class TestClass:
        def __init__(self):
            self.x = 5
            self.y = 5

        @cached_property
        def z(self):
            return self.x + 1

    obj = TestClass()
    assert obj.z == 6
    assert obj.__dict__['z'] == 6
    obj.x = 7
    assert obj.z == 6
    assert obj.__dict__['z'] == 6
    pytest.helpers.add_attr(obj, 'z', value=10)
    assert obj.z == 10
    assert obj.__dict__['z'] == 10
    del obj.z
    assert obj.z == 8
    assert obj.__dict__['z'] == 8



# Generated at 2022-06-21 12:37:59.646250
# Unit test for constructor of class cached_property
def test_cached_property():
    import pytest
    from flutils.decorators import cached_property

    class TestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1


    def test_wrapped_function():
        obj = TestClass()
        assert obj.y == 6



# Generated at 2022-06-21 12:38:12.187701
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import MagicMock
    from time import time

    class C:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    c = C(1)

    mock_slice = MagicMock(return_value=5)
    mock_time = MagicMock(side_effect=[1, 5, 5])

    with mock.patch('flutils.decorators.slice', mock_slice), \
            mock.patch('flutils.decorators.time', mock_time):

        # call y
        y = c.y

        # check y
        assert y == 2
        mock_slice.assert_called_once_with(1, 1, None)

        # call y

# Generated at 2022-06-21 12:38:16.328168
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property."""
    from typing import Any

    class A:
        def __init__(self):
            self.a = 1
        @cached_property
        def x(self):
            return self.a

    a = A()
    a.a = 2
    assert a.x == 1

# Generated at 2022-06-21 12:38:34.087898
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest

    @cached_property
    def foo():
        return 42

    class Foo:
        def __init__(self):
            self.y = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x + 1

    class Foo1:
        def __init__(self):
            self.y = 5

        @cached_property
        @asyncio.coroutine
        def y(self):
            yield from asyncio.sleep(0)
            return self.x + 1

        @cached_property
        @asyncio.coroutine
        def z(self):
            yield from asyncio.sleep(0)
            return self.x + 1


# Generated at 2022-06-21 12:38:44.764860
# Unit test for constructor of class cached_property
def test_cached_property():
    import os
    import time

    import pytest

    from flutils.decorators import cached_property
    from flutils.helpers import get_data_file

    class TestClass:

        @cached_property
        def test_func(self):
            return time.time()

        @cached_property
        def test_coro(self):
            return asyncio.sleep(5)

    @pytest.mark.asyncio
    async def test_coro_func():

        testobj = TestClass()
        testobj.test_func
        before = testobj.test_func
        time.sleep(0.5)
        testobj.test_func
        after = testobj.test_func
        assert before == after

        testobj.test_coro
        before = await testobj.test_coro


# Generated at 2022-06-21 12:38:47.908096
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property."""
    @cached_property
    def test_method():
        pass

    assert hasattr(test_method, 'func')
    assert test_method.func is None


# Generated at 2022-06-21 12:38:49.512508
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property.__doc__ is not None



# Generated at 2022-06-21 12:38:51.818904
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""
    import doctest

    results = doctest.testmod()
    assert results.failed == 0

# Generated at 2022-06-21 12:38:53.140131
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass


# Generated at 2022-06-21 12:38:57.953683
# Unit test for constructor of class cached_property
def test_cached_property():
    # Setup

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Exercise & Verify
    assert MyClass().y == 6


if __name__ == '__main__':
    sys.exit(pytest.main(__file__))

# Generated at 2022-06-21 12:39:05.150682
# Unit test for constructor of class cached_property
def test_cached_property():
    class A:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x ** 2

    a = A(5)
    assert a.y == 25
    a.x = 10
    assert a.y == 25
    delattr(A, 'y')
    assert a.y == 100


# Unit tests for the constructor of class cached_property_no_setter

# Generated at 2022-06-21 12:39:15.597500
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # We are running the test against Python 3.6 and 3.7.
    # So we dynamically load the Python 3.8 cached_property decorator and
    # use it as a baseline.

    if sys.version_info[:2] == (3, 8):
        has_cached_property = True
        import functools

    else:
        try:
            import functools
            has_cached_property = True

        except ImportError:
            has_cached_property = False

    if has_cached_property:

        class MyClass:
            def __init__(self):
                self.x = 5

            @functools.cached_property
            def y(self):
                return self.x + 1

        obj = MyClass()
        expected = 6
        actual = obj.y
        assert actual

# Generated at 2022-06-21 12:39:19.440543
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators.cached_property import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:39:41.616668
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class myClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def get_x(self):
            return self.x + 1

    assert myClass().get_x == 6



# Generated at 2022-06-21 12:39:47.458815
# Unit test for method __get__ of class cached_property

# Generated at 2022-06-21 12:39:57.914212
# Unit test for constructor of class cached_property
def test_cached_property():
    """ Unit test for cached_property class
    """
    import pytest
    from flutils.utils import classproperty
    from types import MethodType, FunctionType
    from functools import partial

    @classproperty
    def bar(cls):
        return 1

    @partial(cached_property, foo=1)
    def f():
        return "f"

    @cached_property
    def x():
        return "x"

    class C(object):
        @cached_property  # noqa: F811
        def y(self):
            return "y"

    def test_foo():
        assert f.foo == 1
        assert f() == "f"
        assert f.func.__name__ == "f"
        assert f.__class__ is cached_property


# Generated at 2022-06-21 12:40:02.494434
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """ Unit test for method __get__ of class cached_property.

    """
    import pytest
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyC

# Generated at 2022-06-21 12:40:05.598980
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    @cached_property
    def my_method(self):
        return self.x + 1

    class my_class:

        def __init__(self):
            self.x = 5

    obj = my_class()
    assert obj.my_method == 6



# Generated at 2022-06-21 12:40:09.759322
# Unit test for constructor of class cached_property
def test_cached_property():

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:40:10.716854
# Unit test for constructor of class cached_property
def test_cached_property():
    _ = cached_property


# Generated at 2022-06-21 12:40:20.703201
# Unit test for constructor of class cached_property
def test_cached_property():
    try:
        import asyncio
        from types import coroutine
    except ImportError:
        asyncio = None
        coroutine = None

    @cached_property
    def foo():
        return 'foo'

    assert foo.__doc__ == None
    assert foo.func is None
    assert foo.__class__ == cached_property

    class Class:

        @cached_property
        def bar():
            """The bar property."""
            return 'bar'

        @cached_property
        def baz():
            return 'baz'

        @cached_property
        def buz(self):
            return 'buz'

    assert Class.bar.__doc__ == 'The bar property.'
    assert Class.bar.func() == 'bar'
    assert Class.bar.__class__ == cached_property
   

# Generated at 2022-06-21 12:40:23.076277
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Unit test for constructor of class cached_property
    """
    assert cached_property(None).func is None



# Generated at 2022-06-21 12:40:30.812843
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property."""
    import pytest

    from flutils.decorators import cached_property

    # noinspection PyMissingConstructor
    class Example(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    @cached_property
    def y(self):
        return 10

    class Example2(object):
        @cached_property
        async def y(self):
            return 10

        @cached_property
        def z(self):
            return 15

    with pytest.raises(TypeError):
        # noinspection PyArgumentList
        Example2()

    example = Example()
    assert example.y == 6

    # noinspection PyStatementEffect

# Generated at 2022-06-21 12:41:19.542105
# Unit test for constructor of class cached_property
def test_cached_property():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    assert obj.y == 6



# Generated at 2022-06-21 12:41:25.591191
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""

    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    obj.x = 10
    assert obj.y == 6
    del obj.y
    assert obj.y == 11

    assert isinstance(obj, MyClass)
    assert isinstance(obj.y, int)
    assert not isinstance(obj.y, MyClass)

# Generated at 2022-06-21 12:41:31.941428
# Unit test for constructor of class cached_property
def test_cached_property():
    class C:
        def __init__(self):
            self.x = "X"

        @cached_property
        def y(self):
            return self.x + "Y"

    obj = C()
    assert obj.y == "XY"
    assert obj.y == "XY"
    assert obj.x == "X"
    assert obj.y == "XY"



# Generated at 2022-06-21 12:41:39.641492
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest
    import random

    class Class1:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class Class2:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class Class3:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + random.randint(2, 3)

    class Class4:
        def __init__(self):
            self.x = 5


# Generated at 2022-06-21 12:41:42.920750
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        @cached_property
        def my_prop(self):
            return "my_prop"

    obj = MyClass()
    assert obj.my_prop == "my_prop"

# Generated at 2022-06-21 12:41:47.601370
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


# Generated at 2022-06-21 12:41:51.934456
# Unit test for constructor of class cached_property
def test_cached_property():
    class Parent:
        def __init__(self):
            self.val = 5

        @cached_property
        def attrib(self):
            return self.val + 1

    obj = Parent()
    val = obj.attrib
    assert val == 6, 'Value should be 6'

# Generated at 2022-06-21 12:41:58.022467
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils._testing import run_tests

    # noinspection PyShadowingNames
    def test_1():
        class C:
            def __init__(self, x):
                self.x = x

            @cached_property
            def y(self):
                return "y of {}".format(self.x)

        c = C("foo")
        assert c.y == "y of foo"

        c = C("bar")
        assert c.y == "y of bar"

    run_tests()

# Generated at 2022-06-21 12:42:05.379432
# Unit test for constructor of class cached_property
def test_cached_property():
    # Test using methods.
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__["y"] == 6

    # Test using coroutines
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        async def y(self):
            await asyncio.sleep(0.2)
            return self.x + 1

    loop = asyncio.get_event_loop()
    loop.run_until_complete(asyncio.sleep(0.3))
    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__

# Generated at 2022-06-21 12:42:10.010580
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """

    """

    # noinspection PyPep8Naming
    class FooTest:

        def __init__(self):
            self._test = 3
            self._test2 = False

        @cached_property
        def my_func2(self):
            return self._test + 1

        @cached_property
        def my_func(self):
            self._test2 = True
            return self.my_func2

    foo = FooTest()
    assert foo.my_func == 4
    assert foo._test2
    foo._test = 4
    assert foo.my_func == 4



# Generated at 2022-06-21 12:43:57.924290
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # New instance is decorated method
    class Class:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert Class().y == 6

    # Delete method to reset as computed once per instance
    class Class:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Class()
    assert obj.y == 6
    del obj.y
    assert obj.y == 6

    # Classes with async functions decorator
    class Class:

        def __init__(self):
            self.x = 5

        @cached_property
        async def y(self):
            await asyncio.sleep(0)
            return

# Generated at 2022-06-21 12:44:05.319283
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class TestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.y == 6

    # noinspection PyProtectedMember
    obj._TestClass__dict__['y'] = 6

    assert obj.y == 6

# Generated at 2022-06-21 12:44:08.120503
# Unit test for constructor of class cached_property
def test_cached_property():
    class cls:
        # noinspection PyMissingConstructor
        def __init__(self):
            pass

    cp = cached_property(print)
    assert cp.__doc__ == print.__doc__
    assert cp.func is print

# Generated at 2022-06-21 12:44:19.266003
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method `__get__` of class `cached_property`

    *New in version 0.3.0*

    """
    from unittest.mock import MagicMock

    def foo(self):
        return self.x

    class Bar(object):
        pass

    bar = Bar()

    bar.x = 5

    cp = cached_property(foo)
    a = cp.__get__(bar, Bar)
    b = cp.__get__(bar, Bar)

    assert a == b

    bar.y = MagicMock(return_value=0)

    cp = cached_property(bar.y)
    a = cp.__get__(bar, Bar)
    b = cp.__get__(bar, Bar)

    assert a == b

    bar.y.assert_not_

# Generated at 2022-06-21 12:44:27.636626
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():  # noqa: D103
    class MyClass:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass(5)
    assert obj.y == 6
    assert obj.__dict__ == {'x': 5, 'y': 6}

    obj = MyClass(10)
    assert obj.y == 11
    assert obj.__dict__ == {'x': 10, 'y': 11}

    # noinspection PyProtectedMember
    assert MyClass.y.__doc__ == 'getter of y'



# Generated at 2022-06-21 12:44:38.739224
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class Foo:

        @cached_property
        def a(self):
            return 1

    f = Foo()
    assert f.a == 1

    class Bar:

        def __init__(self):
            self.a = 0

        @cached_property
        def a(self):
            return 1

    b = Bar()
    assert b.a == 0
    assert b.__dict__['a'] == 1

    class One:

        @cached_property
        def a(self):
            return 1

    class Two(One):

        @cached_property
        def a(self):
            return 2

    assert Two().a  == 2

    class Three(One):

        @property
        def a(self):
            return super().a

    assert Three().a == 1


# Generated at 2022-06-21 12:44:47.689123
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest import TestCase

    class TestClass(TestCase):
        @cached_property
        def a(self):
            return 'A'

        @cached_property
        async def b(self):
            await asyncio.sleep(3)
            return 'B'


    test_case = TestClass()

    assert hasattr(test_case, 'a')
    assert test_case.a == 'A'
    assert test_case.a == 'A'

    async def test_case_a():
        test_case.a = 'b'
        assert not hasattr(test_case, 'b')
        assert test_case.a == 'b'


    async def test_case_b():
        loop = asyncio.get_event_loop()
