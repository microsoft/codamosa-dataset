

# Generated at 2022-06-21 12:34:53.313589
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    from flutils import (
        await_coroutine,
        cached_property
    )

    from flutils.tests.helpers import (
        slow_coroutine,
    )

    @cached_property
    @asyncio.coroutine
    def slow_method(self):
        """Slow method."""
        yield from slow_coroutine(1)
        return 22

    class TestClass:
        """Test Class."""

        def __init__(self):
            self.foo = 1
            self.bar = 2

        @slow_method.setter
        @asyncio.coroutine
        def slow_method(self, value):
            """Set slow method."""
            yield from slow_coroutine(1)
            self._slow_method = value

        slow_method = cached_property(slow_method)

   

# Generated at 2022-06-21 12:34:56.601292
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import MagicMock

    class X:

        def __init__(self):
            self.a = 5

        @cached_property
        def b(self):
            return self.a + 1

    obj = X()
    assert hasattr(obj, 'b')
    assert obj.b == 6
    assert obj.__dict__ == {'a': 5, 'b': 6}

    del obj.b
    assert obj.__dict__ == {'a': 5}



# Generated at 2022-06-21 12:34:57.622886
# Unit test for constructor of class cached_property
def test_cached_property():
    # TODO: Add unit test
    pass

# Generated at 2022-06-21 12:35:07.151281
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        # use decorated method
        @cached_property
        def x(self):
            return 'x'

        # use decorated method
        @cached_property
        def y(self):
            return 'y'

    m = MyClass()
    assert m.x == 'x'
    assert m.y == 'y'

    # test that descriptor returns cached value
    m.x = 'a'
    assert m.x == 'a'
    m.y = 'b'
    assert m.y == 'b'

    # test that instance variable is set after calling cached_property
    # decorated method
    assert m.__dict__['x'] == 'a'
    assert m.__dict__['y'] == 'b'



# Generated at 2022-06-21 12:35:09.919318
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest import mock

    # noinspection PyUnusedLocal
    def func(self):
        return 1

    assert isinstance(cached_property(func), cached_property)



# Generated at 2022-06-21 12:35:12.147784
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        @cached_property
        def method(self):
            return "Hello World"

    m = MyClass()
    assert m.method == "Hello World"

# Generated at 2022-06-21 12:35:16.582892
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.y == 6


# Generated at 2022-06-21 12:35:23.649801
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method cached_property.__get__."""

    class Test:
        def __init__(self):
            self.x = 0

        @cached_property
        def y(self):
            return self.x + 1

    obj = Test()
    obj.x = 5
    assert obj.y == 6

    obj.x = 99
    assert obj.y == 6



# Generated at 2022-06-21 12:35:25.867511
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    obj = CachedProperty()



# Generated at 2022-06-21 12:35:29.392682
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert(obj.y == 6)



# Generated at 2022-06-21 12:35:40.698519
# Unit test for constructor of class cached_property
def test_cached_property():
    from functools import wraps
    from flutils.asynctools import AsyncioLock

    class MyClass:
        lock = AsyncioLock()

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        async def z(self):
            async with self.lock:
                return self.x + 2

    obj = MyClass()
    assert obj.y == 6
    assert obj.z == 7
    assert obj.__dict__ == {'x': 5, 'y': 6, 'z': asyncio.ensure_future(obj.z)}

# Generated at 2022-06-21 12:35:52.117489
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test that method __get__ of class cached_property works as expected.
    """

    import pytest

    class MyClass:
        """Class used for testing the cached_property descriptor.

        """

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """A cached property.

            Args:
                self (:obj:`~MyClass`): Instance of class MyClass.

            """
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    # Test that the cached property can be deleted.
    del obj.y
    assert obj.y == 6

    def test_class():
        """Test that class docstrings are used.
        """
        assert MyClass.y.__doc__ == obj.y.__

# Generated at 2022-06-21 12:35:56.095802
# Unit test for constructor of class cached_property
def test_cached_property():
    class A(object):

        @cached_property
        def x(self):
            return 'hello'

    a = A()

    x = a.x

    assert x == 'hello'

# Generated at 2022-06-21 12:36:04.501852
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""
    global my_obj

    class MyClass:  # pragma: no cover
        """Class for testing __get__ of class cached_property"""

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """My y"""
            return self.x + 1

    my_obj = MyClass()
    assert my_obj.y == 6

    assert my_obj.__dict__["y"] == 6

    my_obj.x = 10
    assert my_obj.y == 6

    # Delete my_obj.y
    del my_obj.y
    assert my_obj.y == 11


# Generated at 2022-06-21 12:36:15.018165
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property."""

    import sys
    import unittest
    import flutils

    class FlutilsTests(unittest.TestCase):
        """Unit tests for constructor of class cached_property."""

        def check_version(self):
            """Check version of flutils."""

            if sys.version_info[:2] < (3, 8):
                self.assertEqual(flutils.__version__, '0.2.0')
            else:
                self.assertEqual(flutils.__version__, '0.2.1')

        def test_flutils_cached_property(self):
            """Unit test for constructor of class cached_property."""

            self.check_version()
            from flutils.decorators import cached_property


# Generated at 2022-06-21 12:36:19.222665
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:36:23.671785
# Unit test for constructor of class cached_property
def test_cached_property():

    # Define class for testing cached_property constructor
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:36:25.935256
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import mock

    class MyClass:
        def __init__(self):
            pass

        @cached_property
        def y(self):
            return 1

    obj = MyClass()
    assert obj.y == 1
    obj.y = 3
    assert obj.y == 3
    del obj.y
    assert obj.y == 1



# Generated at 2022-06-21 12:36:29.950953
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Tests method cached_property.__get__"""

    # noinspection PyMissingOrEmptyDocstring
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    # noinspection PyMissingOrEmptyDocstring
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def __init__(self):
            return self.x + 1

    obj = MyClass()
    assert isinstance(obj, MyClass)

    # noinspection PyMissingOrEmptyDocstring
    class MyClass:

        def __init__(self):
            self.x = 5


# Generated at 2022-06-21 12:36:41.511621
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test :meth:`flutils.decorators.cached_property.__get__`. This
    test should run *only* if the cached_property.__get__ method is
    *not* using coroutines. Otherwise the test will fail.

    """
    # noinspection PyUnusedLocal
    class MyClass:
        def __init__(self):
            self.x = 5

        # noinspection PyUnusedLocal
        @cached_property
        def y(self):
            return 42

    obj = MyClass()
    assert obj.y == 42
    obj.x = 20
    assert obj.y == 42
# END test_cached_property___get__()


# Generated at 2022-06-21 12:36:47.330143
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj = object()
    assert cached_property(lambda self: self).__get__(obj, object) is obj



# Generated at 2022-06-21 12:36:51.831278
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """test_cached_property: Test method __get__."""
    cached_property

    import logging
    import unittest

    # noinspection PyMissingOrEmptyDocstring,PyPep8Naming,PyUnusedLocal,PyMethodMayBeStatic
    class TestClass(unittest.TestCase):
        # noinspection PyMissingOrEmptyDocstring
        @cached_property
        def val(self):
            """Test property."""
            return 1

    logging.debug(TestClass().val)

# Generated at 2022-06-21 12:36:58.546009
# Unit test for constructor of class cached_property
def test_cached_property():
    """Tests :obj:`~flutils.decorators.cached_property`."""

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:36:59.490376
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property(lambda self: self+1)

# Generated at 2022-06-21 12:37:04.367787
# Unit test for constructor of class cached_property
def test_cached_property():
    class Foo:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    foo = Foo(5)
    assert foo.y == 6

# Generated at 2022-06-21 12:37:10.114509
# Unit test for constructor of class cached_property
def test_cached_property():
    import time

    class TestClass(object):
        def __init__(self):
            self.init = time.time()

        @cached_property
        def test(self):
            time.sleep(1)
            return time.time()

    t = TestClass()
    assert t.init < t.test
    time.sleep(1)
    assert t.test == t.test
    del t.test
    assert t.init < t.test

# Generated at 2022-06-21 12:37:15.364472
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import Mock, patch

    with patch('flutils.decorators.cached_property._cached_property__get__'):
        obj = Mock()
        instance = cached_property(Mock())
        assert instance.__get__(obj, None) is None



# Generated at 2022-06-21 12:37:22.035771
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Foo:

        def __init__(self, x=5):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    foo = Foo()
    assert foo.y == 6
    del foo.y
    foo.__dict__.pop('y')
    foo.x = 10
    foo.__dict__.pop('y')
    assert foo.y == 11
    foo.__dict__.pop('y')

# Generated at 2022-06-21 12:37:24.148480
# Unit test for constructor of class cached_property
def test_cached_property():
    @cached_property
    def y(self):
        return self.x + 1



# Generated at 2022-06-21 12:37:28.445627
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        @cached_property
        def func(self):
            """Documentation for func"""
            return 1

    obj = MyClass()
    assert obj.func == 1
    assert obj.__doc__ == 'Documentation for func'


# Generated at 2022-06-21 12:37:46.446515
# Unit test for method __get__ of class cached_property

# Generated at 2022-06-21 12:37:51.793474
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from .utils import _x

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return _x + 1

    obj = MyClass()
    obj.y
    assert obj.__dict__ == {'x': 5, 'y': 6}, obj.__dict__
    obj = MyClass()
    assert obj.__dict__ == {'x': 5, 'y': 6}, obj.__dict__

# Generated at 2022-06-21 12:37:56.702327
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6

# Generated at 2022-06-21 12:37:59.697365
# Unit test for constructor of class cached_property
def test_cached_property():
    # Arrange
    @cached_property
    def test_func(self):
        return True

    # Act
    y = test_func(None)

    # Assert
    assert y is True

# Generated at 2022-06-21 12:38:07.611843
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class TestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # object
    assert TestClass.y.__doc__ == TestClass.y.func.__doc__

    # attribute
    obj = TestClass()
    assert obj.y == 6

    # reset
    del obj.y
    assert obj.y == 6


# Generated at 2022-06-21 12:38:08.639436
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property(2)



# Generated at 2022-06-21 12:38:13.188309
# Unit test for constructor of class cached_property
def test_cached_property():
    global cp

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    cp = obj.y
    assert cp == 6

# Generated at 2022-06-21 12:38:16.252822
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property"""
    # Setup
    obj = cached_property(obj)

    # Exercise & Verify
    assert hasattr(obj, '__init__')


# Generated at 2022-06-21 12:38:20.812058
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Test __get__ with no object argument
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert MyClass.y is MyClass.y



# Generated at 2022-06-21 12:38:25.725857
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test method __get__ of class `cached_property` for code coverage."""

    class TestClass:

        def __init__(self, val):
            self.val = val

        @cached_property
        def prop(self):
            return self.val

    tc = TestClass(1)
    assert tc.prop == 1
    assert tc.__dict__["prop"] == 1



# Generated at 2022-06-21 12:38:47.732860
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestCachedPropertyGet:
        def __init__(self):
            self.x = 0

        @cached_property
        def y(self):
            return self.x + 1

    assert TestCachedPropertyGet().y == 1

# Generated at 2022-06-21 12:38:50.751551
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property.

    This function tests the constructor of the :class:`cached_property`
    class.

    """

    # Test: normal
    assert cached_property



# Generated at 2022-06-21 12:38:57.248577
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import logging
    import inspect
    import asyncio
    from flutils.logging import set_name
    from flutils.decorators import cached_property


    class _Base:

        @cached_property
        def logger(self):
            return set_name(logging.getLogger(__name__), self.logger_name)

        def __init__(self):
            self.logger_name = inspect.currentframe().f_code.co_name

        @cached_property
        def current_frame(self):
            """
            Returns the frame object for the caller's stack frame.
            """
            return inspect.currentframe().f_back

        @property
        def _current_frame(self):
            """
            Returns the frame object for the caller's stack frame.
            """
            return inspect.currentframe

# Generated at 2022-06-21 12:39:03.173073
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import inspect
    import types

    class MyClass:
        @cached_property
        def prop(self):
            return self.get()

        def get(self):
            return "MyClass"

    obj = MyClass()
    assert isinstance(obj.__dict__["prop"], asyncio.Future)
    assert inspect.iscoroutine(obj.prop())

    class MyNewClass(MyClass):
        def get(self):
            return "MyNewClass"

    obj = MyNewClass()
    assert isinstance(obj.__dict__["prop"], asyncio.Future)
    assert inspect.iscoroutine(obj.prop())

    MyClass.get = lambda self: "MyClass"
    obj = MyClass()
    assert isinstance(obj.__dict__["prop"], str)

# Generated at 2022-06-21 12:39:06.562986
# Unit test for constructor of class cached_property
def test_cached_property():

    # noinspection PyUnusedLocal
    class MyClass:

        @cached_property
        def x(self):
            """A class property."""
            return 42

    assert MyClass.x.__doc__ == "A class property."

# Generated at 2022-06-21 12:39:10.528335
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5
        @cached_property
        def y(self):
            return self.x + 1
    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:39:17.491245
# Unit test for constructor of class cached_property
def test_cached_property():
    import pytest

    # noinspection PyUnresolvedReferences
    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    # Change x and see if cached_property changes
    obj.x = 6
    assert obj.y == 6

    # Delete cached_property and see if changes
    del obj.y
    assert obj.y == 7

##############################################################################
# END

# Generated at 2022-06-21 12:39:20.487594
# Unit test for constructor of class cached_property
def test_cached_property():
    @cached_property
    def some_prop(self):
        return 5
    assert some_prop.__doc__ is None
    assert some_prop.func.__doc__ is None



# Generated at 2022-06-21 12:39:29.204984
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property."""

    class ClassA:

        @cached_property
        def func_a(self):
            return "something"

        @cached_property
        def func_b(self):
            async def async_func():
                return "something"
            return async_func()

    ca = ClassA()
    assert ca.func_a == "something", "func_a returns something"
    assert isinstance(ca.func_b, asyncio.tasks.Task), \
        "func_b returns an asyncio Task"



# Generated at 2022-06-21 12:39:33.090056
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 5

    obj = MyClass()
    assert obj.y == 10



# Generated at 2022-06-21 12:40:22.925315
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import asyncio

    class MyClass(object):

        def __init__(self):
            self.a = 5

        @cached_property
        def y(self):
            return self.a + 1

        @cached_property
        def z(self):
            return self.a - 1

        @cached_property
        async def coro(self):
            return self.a + 1

    obj = MyClass()
    expected = {'a': 5, 'y': 6, 'z': 4}
    assert obj.__dict__ == expected

    expected['y'] = 6
    assert obj.y == 6
    assert obj.__dict__ == expected

    expected['z'] = 4
    assert obj.z == 4
    assert obj.__dict__ == expected

    expected['coro'] = 7

# Generated at 2022-06-21 12:40:26.411570
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest.mock import Mock

    obj = Mock()
    func = Mock()
    property_obj = cached_property(func)
    assert property_obj.__doc__ == func.__doc__
    assert property_obj.func == func


# Generated at 2022-06-21 12:40:31.277596
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6
    assert obj.__dict__ == {'x': 5, 'y': 6}



# Generated at 2022-06-21 12:40:35.356551
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:40:40.507631
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:40:44.946480
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class C(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    o = C()
    assert o.y == 6
    o.x = 6
    assert o.y == 6



# Generated at 2022-06-21 12:40:53.748861
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property.

    *New in version 0.2.0.post*

    """
    print(test_cached_property.__doc__)

    import time

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """Docstring for cached property y."""
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6
    obj.x = 6
    assert obj.y == 6
    del obj.y
    assert obj.y == 7
    assert obj.__dict__ == {'x': 6, 'y': 7}

# Generated at 2022-06-21 12:41:01.019203
# Unit test for constructor of class cached_property
def test_cached_property():
    import asyncio
    from unittest import mock


    def test_cached_property():

        class Foo:

            def __init__(self, x, y):
                self.x = x
                self.y = y
                self.mock = mock.Mock()

            @cached_property
            def foo(self):
                return self.mock(self.y)

        obj = Foo(x=5, y=6)
        obj.foo

        # Ensure cached property is assigned to instance dict
        assert obj.__dict__.get("foo") is not None

        # Ensure mock is not called again
        obj.foo
        obj.mock.assert_called_once_with(6)

        # Ensure resetting the property works
        del obj.__dict__["foo"]
        obj.foo

# Generated at 2022-06-21 12:41:02.688965
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property


    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


# Generated at 2022-06-21 12:41:09.783918
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    print(obj.y)
    print('====')
    print(obj.x)
    print('====')
    print(obj.y)
    print('====')
    print(obj.x)
    print('====')
    print(obj.y)
    print('====')



# Generated at 2022-06-21 12:42:37.710794
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """

    """

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:42:38.770956
# Unit test for constructor of class cached_property
def test_cached_property():
    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:42:40.494525
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    return cached_property(lambda: 2).__get__(None, None) == 2



# Generated at 2022-06-21 12:42:43.224952
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:42:53.346371
# Unit test for constructor of class cached_property
def test_cached_property():
    import unittest
    import inspect

    class TestClass:
        def test_method(self):
            pass

    class Test_cached_property(unittest.TestCase):
        def test_cached_property(self):
            obj = TestClass()
            expected = inspect.iscoroutinefunction(obj.test_method)
            self.assertEqual(cached_property(obj.test_method), expected)

    suite = unittest.TestLoader().loadTestsFromTestCase(Test_cached_property)
    unittest.TextTestRunner(verbosity=2).run(suite)


# Make the module executable.
if __name__ == "__main__":
    test_cached_property()

# Generated at 2022-06-21 12:43:00.005380
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property
    from functools import partial

    class Foo:
        def __init__(self, lol=None):
            self.lol = lol

        @cached_property
        def func(self):
            return partial(self.lol, self.lol)

    assert Foo().func() == ((), ())
    assert Foo(1).func() == (1, 1)
    assert Foo("a").func() == ("a", "a")
    assert Foo("test").func() == ("test", "test")



# Generated at 2022-06-21 12:43:07.897917
# Unit test for constructor of class cached_property
def test_cached_property():
    obj = cached_property(lambda: 1)
    assert obj.__doc__ == '<lambda>'
    assert obj.func(None) == 1
    assert obj.__get__(None, None) is obj
    assert obj.__get__(object, object).__class__.__name__ == 'wrapper_descriptor'
    assert obj.__get__(object, object)() == 1
    assert callable(obj.__get__(object, object))


if __name__ == '__main__':
    import pytest
    pytest.main(['-x', os.path.basename(__file__), '-v', '-rw'])

# Generated at 2022-06-21 12:43:12.180743
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property"""

    class TestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # pylint: disable=no-member
    obj = TestClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:43:17.486452
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    print(test_cached_property___get__.__doc__)

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
# END test_cached_property___get__

# Generated at 2022-06-21 12:43:20.407565
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__[obj.y] == 6