

# Generated at 2022-06-21 12:34:50.286372
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test method __get__ of class cached_property.

    This test only tests the `else` branch of the method. The `if` branch is
    tested in the unit test for method __get__ of class async_cached_property.

    """  # noqa

    # Arrange
    instance = cached_property(object())

    # Act
    value = instance.__get__(instance, cached_property)

    # Assert
    assert value is instance

# Generated at 2022-06-21 12:35:01.859677
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    # Test when decorated function is a coroutine
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        async def z(self):
            return self.x + 2

    obj = MyClass()

    loop = asyncio.get_event_loop()

    y_result = loop.run_until_complete(obj.y)
    assert y_result == 6


# Generated at 2022-06-21 12:35:04.339616
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class Foo:

        @cached_property
        def _uses_get(self):
            """This method uses __get__"""
            return "Hello"

    f = Foo()
    assert f._uses_get == "Hello"



# Generated at 2022-06-21 12:35:10.315074
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestCachedProperty:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x + 1

    obj = TestCachedProperty()
    assert 6 == obj.y
    assert 6 == obj.y
    assert 6 == obj.z
    assert 6 == obj.z



# Generated at 2022-06-21 12:35:19.021041
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():  # noqa: D103
    """
    Tests the __get__ method of class cached_property.

    *New in version 0.2.0*
    """

    # noinspection PyUnusedLocal
    class MyClass:
        """A simple class."""

        def __init__(self):
            """Initialize the class."""
            self.x = 5

        @cached_property
        def y(self):
            """Return the cached property value."""
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert hasattr(obj, 'y')



# Generated at 2022-06-21 12:35:25.419553
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""

    cp = cached_property(lambda: None)

    assert cp.__get__(None, 1) == cp
    assert callable(cp.__get__(123, None))

    # TODO: The following tests are commented out until such time
    # as this is properly implemented.

    # class MyClass:

    #     def __init__(self):
    #         self.x = 5

    #     @cached_property
    #     def y(self):
    #         return self.x + 1

    # obj = MyClass()
    # MyClass.y = cp.__get__(obj, None)
    # assert MyClass.__dict__['y'] == cp.__get__(obj, None)
    # assert obj.__dict__['y']

# Generated at 2022-06-21 12:35:26.745788
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # TODO: Add unit test for method __get__ of class cached_property
    pass

# Generated at 2022-06-21 12:35:30.563158
# Unit test for constructor of class cached_property
def test_cached_property():
    class Foo(object):
        def __init__(self):
            self._bar = False

        @cached_property
        def bar(self):
            return self._bar

    foo = Foo()
    assert foo.bar is False
    foo._bar = True
    assert foo.bar is True

# Generated at 2022-06-21 12:35:37.525660
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert 'y' in obj.__dict__
    assert obj.y == 6

    del obj.y
    assert 'y' not in obj.__dict__
    assert obj.y == 6
    assert 'y' in obj.__dict__


# Generated at 2022-06-21 12:35:42.920876
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class T:

        @cached_property
        def x(self):
            return 'test'

    t = T()
    assert t.x == 'test'

    # New in 0.2.0
    assert iscoroutinefunction(t.x) is False



# Generated at 2022-06-21 12:35:56.628099
# Unit test for constructor of class cached_property
def test_cached_property():
    import unittest
    from pytest import approx
    from flutils.helpers import create_tempfile

    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    tc = TestClass()
    assert tc.y == 6

    # repeated calls should return same value, not call method
    assert tc.y == 6
    assert tc.y == 6

    # deleting property should delete value and re-run
    del tc.y
    assert tc.y == 6

    # deleting underlying instance attribute should delete property
    del tc.x
    with unittest.mock.patch('warnings.warn') as mock_warnings:
        assert tc.y == 6

# Generated at 2022-06-21 12:36:02.425067
# Unit test for constructor of class cached_property
def test_cached_property():
    class Foo:
        def __init__(self, value):
            self.value = value

        @cached_property
        def complicated_property(self):
            return self.value * 10

    foo = Foo(5)
    assert foo.complicated_property == 50
    foo.value = 10
    assert foo.complicated_property == 50


if __name__ == '__main__':
    test_cached_property()

# Generated at 2022-06-21 12:36:03.848223
# Unit test for constructor of class cached_property
def test_cached_property():
    cached_property(lambda x: x)

# Generated at 2022-06-21 12:36:09.281753
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5
        @cached_property
        def y(self):
            return self.x + 1
    obj = MyClass()
    # for fun
    for i in range(1, 111):
        obj.x = i
        assert obj.y == i+1

# Generated at 2022-06-21 12:36:14.105045
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestClass:
        def __init__(self):
            self.x = 5
        @cached_property
        def y(self):
            return self.x + 1
    obj = TestClass()
    assert obj.y == 6
    obj.x = 1
    assert obj.y == 2
    del obj.y
    assert obj.y == 2


# Generated at 2022-06-21 12:36:16.740225
# Unit test for constructor of class cached_property
def test_cached_property():
    # Test for docstring.
    assert cached_property.__init__.__doc__ is not None

# Generated at 2022-06-21 12:36:27.392090
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property.
    """
    old_counter = cached_property.func.counter

# Generated at 2022-06-21 12:36:32.048437
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


# Generated at 2022-06-21 12:36:36.310278
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:36:43.258057
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property

    The following conditions are checked:
        - The ``__doc__`` is set.
        - The ``func`` is set.

    """

    def func():
        """The doc string."""
        return 'foo'

    cp = cached_property(func)
    assert cp.__doc__ == func.__doc__
    assert cp.func is func



# Generated at 2022-06-21 12:36:48.391809
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:36:52.234574
# Unit test for constructor of class cached_property
def test_cached_property():

    @cached_property
    def prop(instance):
        return "cached property"

    assert isinstance(prop, cached_property)
    assert prop.__doc__ == "cached property"
    assert prop.func.__doc__ == "cached property"



# Generated at 2022-06-21 12:37:02.375064
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property"""
    from datetime import datetime, date

    class MyClass():
        """Example class for testing the cached_property decorator"""

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """y attribute getter"""
            return self.x + 1

        @cached_property
        def foo(self):
            """foo attribute getter"""
            return datetime.utcnow()

        @cached_property
        def bar(self):
            """bar attribute getter"""
            return date.today()

    obj = MyClass()
    assert obj.y == 6
    assert isinstance(obj.y, int)
    assert isinstance(obj.foo, datetime)

# Generated at 2022-06-21 12:37:03.616259
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():  # noqa: D103
    pass

# Generated at 2022-06-21 12:37:14.781879
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.misc import EqualityMixin
    from flutils.misc import classproperty

    class MyClass(EqualityMixin):

        def __init__(self, arg1, arg2):
            self._arg1 = arg1
            self._arg2 = arg2

        @cached_property
        def y(self):
            """An example method."""
            return self._arg1 + self._arg2

    obj = MyClass(4, 2)
    assert obj.y == 6
    assert obj.y == 6

    class MyClass2(EqualityMixin):

        def __init__(self, arg1, arg2):
            self._arg1 = arg1
            self._arg2 = arg2

        @classproperty
        def y(cls):
            """An example method."""
            return cls._arg1

# Generated at 2022-06-21 12:37:24.039502
# Unit test for constructor of class cached_property
def test_cached_property():
    # unit-tests for __init__()

    # Test a function with a docstring
    def func():
        '''A test function for cached_property'''
        pass

    prop = cached_property(func)
    assert prop.__doc__ == '''A test function for cached_property'''

    # Test a function without a docstring
    def func():
        pass

    prop = cached_property(func)
    assert prop.__doc__ is None

    def func_with_args(a, b):
        pass

    # Test passing a function with parameters
    try:
        cached_property(func_with_args)
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-21 12:37:27.912474
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:37:31.675506
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:37:39.676823
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test __get__ of class cached_property"""

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Test cached_property where function is a coroutine
    # noinspection PyUnresolvedReferences
    obj = MyClass()
    assert asyncio.iscoroutinefunction(obj.y)
    # noinspection PyUnresolvedReferences
    assert not asyncio.iscoroutine(obj.y)
    # noinspection PyUnresolvedReferences
    assert not asyncio.isfuture(obj.y)
    assert obj.y.__name__ == 'wrapper'
    assert obj.y.__qualname__ == 'MyClass.y.wrapper'
    # noinspection PyUnresolvedReferences


# Generated at 2022-06-21 12:37:46.932969
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest import TestCase as TC

    class SampleClass:
        def __init__(self):
            self.data = 0

        @cached_property
        def data_property(self):
            return self.data + 1

    tc = TC()
    sc = SampleClass()
    tc.assertEqual(sc.data_property, 1)
    tc.assertEqual(sc.data_property, 1)


if __name__ == '__main__':
    import sys
    import doctest

    sys.exit(doctest.testmod(optionflags=doctest.ELLIPSIS)[0])

# Generated at 2022-06-21 12:37:56.656316
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import doctest

    # noinspection PyUnresolvedReferences
    from flutils.decorators import cached_property

    doctest.testmod(
        name='cached_property',
        optionflags=doctest.ELLIPSIS | doctest.NORMALIZE_WHITESPACE,
        verbose=True
    )

# Generated at 2022-06-21 12:38:07.347932
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest import TestCase
    from unittest.mock import Mock

    class Obj:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    obj = Obj(5)
    assert obj.y == 6

    class Obj:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    obj = Obj(5)
    assert obj.y == 6
    obj.x = -1
    assert obj.y == 6
    del obj.y
    assert obj.y == 0

# Generated at 2022-06-21 12:38:12.934841
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test for cached_property constructor.

    *New in version 0.2.0*

    """
    expected_property = cached_property(cached_property(cached_property))
    assert isinstance(expected_property, cached_property)
    assert expected_property.__doc__ == cached_property.__doc__
    assert expected_property.func is cached_property
    assert expected_property.func is cached_property



# Generated at 2022-06-21 12:38:17.281996
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit testing for method __get__ of class cached_property
    """

    class TestClass:
        """
        TestClass for testing cached_property
        """

        def __init__(self):
            self.x = 15

        @cached_property
        def y(self):
            return self.x + 1

    test_obj = TestClass()
    assert test_obj.y == 16

# Generated at 2022-06-21 12:38:24.302897
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property
    from flutils import load_yaml_config

    CONFIG_DATA = load_yaml_config(Path(__file__).parent / "test_data" / "config.yaml")

    class MyClass:

        def __init__(self, config):
            self.config = config

        @cached_property
        def y(self):
            return self.config['value']

    obj = MyClass(CONFIG_DATA)
    assert obj.y == 2


# Generated at 2022-06-21 12:38:32.693094
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for :obj:`~flutils.decorators.cached_property`."""
    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert MyClass().y == 6
    # No coverage for Python 3.8, which has it built-in.
    if sys.version_info[:2] < (3, 8):
        assert cached_property.__doc__


if __name__ == '__main__':  # pragma: no cover
    test_cached_property()

# Generated at 2022-06-21 12:38:33.779791
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property(lambda n: n)


# Generated at 2022-06-21 12:38:43.035078
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Foo(object):
        def __init__(self, x: int = 5):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    assert not hasattr(Foo, "y")
    assert Foo.y is Foo.y
    foo = Foo()
    assert not hasattr(foo, "y")
    assert foo.y == 6
    assert hasattr(foo, "y")
    foo.x = 2
    foo.__dict__.pop("y")
    assert foo.y == 3
    foo.x = 10
    foo.__dict__.pop("y", None)
    assert foo.y == 11



# Generated at 2022-06-21 12:38:49.169534
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test class cached_property."""
    import unittest

    class A:
        def __init__(self):
            self.x = 6

        @cached_property
        def y(self):
            return self.x + 1

    class TestCachedProperty(unittest.TestCase):
        def test_property(self):
            obj = A()
            self.assertEqual(obj.y, 7)

    unittest.main()



# Generated at 2022-06-21 12:38:58.918899
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import logging
    import sys
    import unittest
    from unittest.mock import patch

    from flutils.decorators import cached_property

    class _Constants(unittest.TestCase):
        """Private constants."""

        ATTR_Y = "y"
        CALL_COUNT = 3
        CLASS_NAME = "MyClass"
        CL_NAME = f"<class '{CLASS_NAME}'>"
        DOC_Y = (
            f"Get the value of attribute '{ATTR_Y}'.\n"
            f"\n"
            "Do the math.\n"
        )
        MSG_ATTR_Y = f"{CL_NAME}.{ATTR_Y}"
        MSG_ATTR_Y_WRAPPER = MSG_ATTR_Y + "._wrapper"

   

# Generated at 2022-06-21 12:39:12.654713
# Unit test for constructor of class cached_property
def test_cached_property():
    # noinspection PyUnusedLocal
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6

    assert "_y" not in obj.__dict__

    del obj.y
    assert "_y" not in obj.__dict__


if __name__ == '__main__':
    test_cached_property()

# Generated at 2022-06-21 12:39:20.300315
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    my_dict = {}

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    attribute = "y"
    assert getattr(obj, attribute) == 6
    assert my_dict == {attribute: 6}

    my_dict.clear()
    my_dict[attribute] = 6
    assert getattr(obj, attribute) == 6
    assert my_dict == {attribute: 6}

    del my_dict[attribute]
    my_dict.clear()
    my_dict[attribute] = 6
    assert getattr(obj, attribute) == 6
    assert my_dict == {attribute: 6}

    del my_dict[attribute]
    my_dict.clear()


# Generated at 2022-06-21 12:39:24.179443
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils_test.decorators_test.test_cached_property import \
        test_cached_property___get__ as _test_cached_property___get__
    _test_cached_property___get__()



# Generated at 2022-06-21 12:39:32.911988
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Tests that if the func argument to __get__ is a coroutine function, the
    # returned wrapper is a coroutine function and that the __dict__ attribute
    # of the calling object is set to the function name as a key and the
    # returned wrapper as the value.

    class MyClass:
        def __init__(self):
            pass

        @cached_property
        async def x(self):
            pass

    obj = MyClass()
    assert isinstance(obj.x, asyncio.coroutines.CoroWrapper)
    assert isinstance(obj.__dict__[obj.x.__name__], asyncio.futures.Future)

# Generated at 2022-06-21 12:39:36.525810
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-21 12:39:39.327735
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:39:44.722885
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method `__get__` of class `cached_property`."""

    class T:

        def __init__(self):
            self.a = 1

        @cached_property
        def x(self):
            return self.a

    o = T()
    assert o.x == 1
    o.a = 2
    # noinspection DuplicatedCode
    assert o.x == 1


# Generated at 2022-06-21 12:39:50.781496
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert 'y' in obj.__dict__
    assert obj.__dict__['y'] == 6


if __name__ == '__main__':
    exit(test_cached_property())

# Generated at 2022-06-21 12:39:53.906145
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test class"""
    newclass = cached_property(lambda x: print('hello'))
    assert newclass.__init__(lambda x: print('hello'))



# Generated at 2022-06-21 12:39:58.485684
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property
    """

    class TestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.y == 6

    # Cleanup
    del obj
    del TestClass



# Generated at 2022-06-21 12:40:26.051315
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class :class:`cached_property`
    """
    class ClassA:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = ClassA()
    assert obj.y == 6

    # Make sure the property can still be gotten after lookup
    # noinspection PyUnresolvedReferences
    obj.__dict__['x'] = 10
    assert obj.y == 11

    # Make sure the property works on subclasses
    class ClassB(ClassA):
        pass

    obj = ClassB()
    # noinspection PyUnresolvedReferences
    obj.__dict__['x'] = 20
    assert obj.y == 21

    # Make sure that subclasses don't share the

# Generated at 2022-06-21 12:40:30.187379
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Class(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Class()
    assert obj.y == 6



# Generated at 2022-06-21 12:40:39.565871
# Unit test for constructor of class cached_property
def test_cached_property():
    # 1. Create instance of class cached_property
    # 1.a. Use class attribute doc
    assert cached_property.__doc__ is None

    # 2. Create instance of class cached_property
    # 2.a. Use class attribute func
    assert cached_property.func is None

    # 3. Create instance of class cached_property
    # 3.a. Use class method __doc__
    assert cached_property.__doc__ is None

    # 4. Create instance of class cached_property
    # 4.a. Use class method __get__
    assert cached_property.__get__ is None

    # 5. Create instance of class cached_property
    # 5.a. Use class method _wrap_in_coroutine
    assert cached_property._wrap_in_coroutine is None

    # 6. Create instance of class cached_property
   

# Generated at 2022-06-21 12:40:50.715827
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit tests for ``cached_property.__get__`` method.

    **From:** `cached_property.__get__ <https://bit.ly/39Hn0nX>`_
    """
    class C1:
        def __init__(self, x):
            self.x = x

        @cached_property
        def prop(self):
            return self.x ** 2

    c = C1(2)
    assert c.prop == 4
    assert c.__dict__['prop'] == 4
    c.x = 3
    assert c.prop == 4

    del c.prop
    assert 'prop' not in c.__dict__
    assert c.prop == 9
    assert c.__dict__['prop'] == 9


# Generated at 2022-06-21 12:40:55.520038
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from threading import Lock
    from unittest import mock

    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert isinstance(obj.y, int)
    assert obj.y == 6

    # Test with a coroutine
    lock = Lock()

    @asyncio.coroutine
    def my_coroutine():
        with lock:
            obj.__dict__['y'] = 'my coroutine'

    # Patch the __init__ method so that y is a coroutine function
    func = mock.Mock()
    func.__name__ = 'y'

# Generated at 2022-06-21 12:40:58.865110
# Unit test for constructor of class cached_property
def test_cached_property():
    class Foo(object):

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Foo()
    assert obj.y == 6

# Generated at 2022-06-21 12:41:11.442207
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test method ``__get__`` of class ``cached_property``.
    """
    # ***********************************************************************
    # *                                                                     *
    # *           MOCKED OBJECT                                             *
    # *                                                                     *
    # ***********************************************************************
    class MockObj:
        def __init__(self, init_val):
            self.x = init_val

        @cached_property
        def y(self):
            self.z = 'z' + self.x
            return int(self.x) + 1

    # ***********************************************************************
    # *                                                                     *
    # *           TESTS                                                     *
    # *                                                                     *
    # ***********************************************************************

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # Initial tests
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Generated at 2022-06-21 12:41:21.390363
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            print('I am inside the y property', self.x)
            return self.x + 1

        @cached_property
        def z(self):
            print('I am inside the z property', self.x)
            return self.x + 2

    obj = MyClass(5)
    assert obj.y == 6
    assert obj.z == 7

    obj.x = 10
    assert obj.y == 6
    assert obj.z == 7


# Generated at 2022-06-21 12:41:24.765304
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


# Generated at 2022-06-21 12:41:30.513478
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Test with class
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    # Test with class as context manager
    with MyClass() as obj:
        assert obj.y == obj.y == 6

# Generated at 2022-06-21 12:42:17.732565
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def my_value(self):
            return self.x + 1

    obj = MyClass()
    assert obj.my_value == 6

# Generated at 2022-06-21 12:42:26.973995
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest

    from .cached_property import cached_property

    from .cached_property_test_data import CachedPropertyTestData

    obj = CachedPropertyTestData()

    # Test 1: ordinary cached property
    assert obj.y == 6
    assert obj.__dict__['y'] == 6

    # Test 2: cached property that is a coroutine
    future = asyncio.ensure_future(obj.y_coroutine)
    assert future == obj.__dict__['y_coroutine']
    assert future.done() is False
    loop = asyncio.get_event_loop()
    loop.run_until_complete(future)
    assert future.done() is True
    assert future.result() == 7
    assert obj.y_coroutine.result() == 7

    # Test 3: cached property that is a

# Generated at 2022-06-21 12:42:38.021919
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    source = """
    from flutils.decorators import cached_property


    class Test:

        def __init__(self):
            self.x = 0

        @cached_property
        def method(self):
            return self.x

        async def async_method(self):
            self.x += 1
            return self.x

        @cached_property
        def cached_async_method(self):
            return self.async_method()

    """

    import_test(source, 'Test')
    # Instantiate class
    obj = Test()
    # Call cached_property method
    assert obj.method == 0
    # Call cached_async_method
    loop = asyncio.get_event_loop()
    future = asyncio.ensure_future(obj.cached_async_method)


# Generated at 2022-06-21 12:42:41.909403
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property."""

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:42:44.760938
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-21 12:42:56.163415
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest.mock import patch

    test_class = type('__TestClass__', (), {})
    test_func = lambda x: 5

    assert not hasattr(test_class, 'x')
    cp = cached_property(test_func)
    assert cp.func is test_func

    test_class.x = cp
    co_consts = cp.func.__code__.co_consts
    assert len(co_consts) == 1
    assert not isinstance(co_consts[0], type(test_func))

    cp = cached_property(test_func)
    with patch.object(cp, 'func', create=True) as mocked_func:
        cp.func.__doc__ = 'test'
        cp_attr = cached_property(test_func)

# Generated at 2022-06-21 12:43:03.285538
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass(1)
    obj.y
    assert obj.__dict__['y'] == 2

    obj = MyClass(2)
    obj.y
    # 'y' in obj.__dict__  # Not implemented in unittest mock
    with pytest.raises(KeyError):
        _ = obj.__dict__['y']



# Generated at 2022-06-21 12:43:07.926256
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest

    def test():
        @cached_property
        def attribute():
            pass
        return attribute

    with pytest.raises(AttributeError):
        test.attribute

    test.attribute = [1, 2]

    assert test.attribute == [1, 2]

    del test.attribute

    test.attribute = [1, 2]

    assert test.attribute == [1, 2]


# Generated at 2022-06-21 12:43:09.261083
# Unit test for constructor of class cached_property
def test_cached_property():
    import functools

    assert cached_property.__doc__ == functools.cached_property.__doc__

# Generated at 2022-06-21 12:43:19.433394
# Unit test for constructor of class cached_property
def test_cached_property():
    import pytest
    # Test 1: Class with normal method
    class MyClass:

        def __init__(self, y):
            self.x = y

        @cached_property
        def y(self):
            """
            Perform a time consuming operation
            """
            import time
            time.sleep(1)
            return self.x

    obj = MyClass('abc')
    start = time.time()
    assert obj.y == 'abc'
    end = time.time()
    assert (end - start) >= 1
    start = time.time()
    assert obj.y == 'abc'
    end = time.time()
    assert (end - start) < 1

    # Test 2: Class with async method
    class MyClass2:

        def __init__(self, y):
            self.x = y