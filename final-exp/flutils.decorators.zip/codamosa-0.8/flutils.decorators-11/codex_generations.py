

# Generated at 2022-06-11 22:15:00.446333
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    result = obj.y
    assert result == 6



# Generated at 2022-06-11 22:15:05.233017
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    @cached_property
    def x(self):
        return self.y + 1

    class TestClass:
        def __init__(self):
            self.y = 5

    t = TestClass()
    x = t.x
    assert x == 6
    x = t.x
    assert x == 6



# Generated at 2022-06-11 22:15:16.500571
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():  # pragma: no cover
    """Unit test for method __get__ of class cached_property"""
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    print('Calling obj.y: {}'.format(obj.y))
    print('Calling obj.y: {}'.format(obj.y))
    print("Deleting attribute 'obj.y'")
    del obj.y
    print('Calling obj.y: {}'.format(obj.y))

if __name__ == '__main__':  # pragma: no cover
    test_cached_property___get__()

# Generated at 2022-06-11 22:15:18.829662
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # For class cached_property.__get__(self, obj, cls):
    assert cached_property.__get__ is cached_property.__get__


# Generated at 2022-06-11 22:15:31.139280
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property
    from collections import namedtuple

    class MyClass:

        def __init__(self, x=1):
            self._x = x

        @cached_property
        def y(self):
            return self._x

        @cached_property
        def z(self):
            return self._x + 1

    myobj = MyClass()

    assert myobj.y == myobj._x
    assert myobj.z == myobj._x + 1

    myobj = MyClass(x=2)
    assert myobj.y == myobj._x
    assert myobj.z == myobj._x + 1

    assert isinstance(myobj.y, int)
    assert isinstance(myobj.z, int)


# Generated at 2022-06-11 22:15:32.345802
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass


# Generated at 2022-06-11 22:15:39.339431
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    def my_coro():
        yield from asyncio.sleep(1)

        return True

    @cached_property
    def my_property(self):
        return True

    type('', (object,), {"my_property": my_property})
    type('', (object,), {"my_property": my_property, "my_coro": my_coro})

# Generated at 2022-06-11 22:15:44.016148
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    obj.x = 6
    assert obj.y == 6

    del obj.y
    assert obj.y == 7


# Generated at 2022-06-11 22:15:49.965308
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import sys

    if sys.version_info[:2] < (3, 8):
        # noinspection PyProtectedMember,PyUnresolvedReferences
        from flutils.decorators import cached_property, coroutine

        class MyClass:
            pass

        # noinspection PyShadowingBuiltins,PyUnusedLocal
        @cached_property
        def x(self):
            return 'x'

        m = MyClass()

        assert asyncio.iscoroutinefunction(x._func)
        assert not asyncio.iscoroutinefunction(x)

        assert x.__doc__ == 'x'

        assert x.__get__(m, MyClass) is m.__dict__[x.func.__name__]


# Unit  test for method _wrap_in_coroutine of class cached_property

# Generated at 2022-06-11 22:15:57.366234
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y # initial call to evaluate property
    assert obj.y == 6
    obj.x = 7 # don't change already calculated cached property
    assert obj.y == 6
    del obj.y # delete property
    assert not hasattr(obj, 'y')
    obj.y # recalculate
    assert obj.y == 8

# Generated at 2022-06-11 22:16:10.684650
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    import pytest

    # noinspection PyPep8Naming
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__['y'] == 6

    # Test when func is a coroutine function
    # noinspection PyPep8Naming
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        async def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert isinstance(obj.__dict__['y'], asyncio.Future) is True

# Generated at 2022-06-11 22:16:18.059878
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # noinspection PyUnusedLocal,PyUnresolvedReferences
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.y == 6



# Generated at 2022-06-11 22:16:22.745444
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Example from class doc string
    from asyncio import iscoroutinefunction

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert not iscoroutinefunction(obj.y)
    assert obj.y == 6



# Generated at 2022-06-11 22:16:31.255855
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest

    class Example(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x + 1

        @cached_property
        def a(self):
            return self.x + 1

    with pytest.raises(AttributeError):
        Example.y
        Example.z
        Example.a

    ex = Example()
    result = ex.y

    assert result == 6

    ex.x = 6
    result = ex.y

    assert result == 7

    with pytest.raises(AttributeError):
        ex.z
        ex.a

    with pytest.warns(DeprecationWarning):
        del ex

# Generated at 2022-06-11 22:16:35.908320
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cp = cached_property(lambda _: 1)

    class TestClass:
        pass

    test_inst = TestClass()
    ret = cp.__get__(test_inst)
    assert ret == 1
    assert test_inst.__dict__[cp.func.__name__] == ret

# Generated at 2022-06-11 22:16:40.796072
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    m = MyClass()
    assert m.y == 6
    m.x = 4
    assert m.y == 6

    assert "y" in repr(m.y)
    assert "cached_property" in repr(m.y)
    assert "staticmethod" in repr(m.y)

# Generated at 2022-06-11 22:16:53.102680
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    m = MyClass(5)

    # test cached_property with get
    assert m.y == 6

    # test cached_property with set
    m.y = -99
    assert m.y == -99

    # test cached_property with del
    del m.y
    assert m.y == 6

    # test cached_property with get
    m.y = -99  # cache results
    assert m.y == -99

    # test cached_property with del
    del m.y  # delete cached result
    assert m.y == 6

    # test cached_property with get
    assert m.y == 6

# Generated at 2022-06-11 22:16:56.956311
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method ``__get__`` of class ``cached_property``."""

    def _func(instance):
        return "foo"
    class _MyClass:
        value = cached_property(_func)

    instance = _MyClass()
    assert "foo" == instance.value

# Generated at 2022-06-11 22:17:05.780479
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # noinspection PyUnusedLocal
    def my_func(x):
        # noinspection PyUnusedLocal
        def my_func1(y):
            # noinspection PyUnusedLocal
            def my_func2(z):
                """This is my_func2."""

                return z

            return my_func2

        return my_func1

    assert cached_property(my_func)().__doc__ == "This is my_func2."

# Generated at 2022-06-11 22:17:13.523762
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property
    from flutils.async_utils import set_asyncio_event_loop_policy

    set_asyncio_event_loop_policy()

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-11 22:17:22.796460
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    # First access
    y1 = obj.y
    assert y1 == 6

    # Second access
    y2 = obj.y
    assert y2 == 6

    # Clear attribute
    del obj.y

    # Third access
    y3 = obj.y
    assert y3 == 6



# Generated at 2022-06-11 22:17:28.890616
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from copy import copy

    class Cache(object):

        @cached_property
        def one(self):
            return 'one'

        @cached_property
        def two(self):
            return 'two'

    cache = Cache()

    assert 'one' == cache.one
    assert 'two' == cache.two

    assert {'one', 'two'} == set(cache.__dict__)

    tmp = copy(cache)
    del cache.one
    assert {'two'} == set(cache.__dict__)

    cache = tmp
    del cache.two
    assert {'one'} == set(cache.__dict__)

    del cache.one
    assert {} == cache.__dict__

# Generated at 2022-06-11 22:17:33.957020
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyTest(object):

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    instances = {i: MyTest() for i in range(10)}
    for _ in range(10):
        for key, instance in instances.items():
            assert instance.y == 6



# Generated at 2022-06-11 22:17:45.283244
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Cached property getter.

    Test :obj:`flutils.decorators.cached_property`.

    """
    # noinspection PyPep8Naming
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x

    myobj = MyClass()
    assert myobj.y == 5
    assert 'y' in myobj.__dict__

    myobj.x = 6
    assert myobj.y == 5
    assert 'y' in myobj.__dict__

    del myobj.y
    assert 'x' in myobj.__dict__
    assert 'y' not in myobj.__dict__

    assert myobj.y == 6
    assert 'y' in myobj.__dict

# Generated at 2022-06-11 22:17:49.963798
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    x = 'foo'

    class MyClass:

        def __init__(self):
            self._x = x

        @cached_property
        def x(self):
            return self._x

    obj = MyClass()
    eq_(x, obj.x)
# Unit test: test_cached_property___get__()



# Generated at 2022-06-11 22:17:54.809648
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-11 22:18:04.845633
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Test case with value in cache (return value from cache)
    class TestReturnCache:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    test1 = TestReturnCache()
    assert test1.y == 6

    # Test case without value in cache (return value from func())
    class TestReturnFunc:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        def __del__(self):
            del self.y

    test2 = TestReturnFunc()
    assert test2.y == 6


# Generated at 2022-06-11 22:18:15.033401
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import datetime
    from flutils.decorators import cached_property
    from unittest import TestCase, main


    class MyClass(TestCase):

        def __init__(self):
            self.x = 5


        @cached_property
        def y(self):
            return self.x + 1


        @cached_property
        def z(self):
            return self.x + 2


    obj = MyClass()
    assert obj.y == 6
    assert obj.z == 7
    obj.x = 2
    assert obj.y == 3
    assert obj.z == 4
    assert obj.__dict__ == {'x': 2, 'y': 3, 'z': 4}



# Generated at 2022-06-11 22:18:22.314653
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""

    class TestClass:
        def __init__(self):
            self.x = 0

        @cached_property
        def double(self):
            self.x += 1
            return self.x * 2

    obj = TestClass()
    assert obj.x == 0
    assert obj.double == 2
    assert obj.x == 1
    assert obj.double == 2



# Generated at 2022-06-11 22:18:33.306253
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test method __get__ of class cached_property."""

    from unittest import mock
    from unittest import TestCase
    from flutils.decorators import cached_property

    cls = mock.Mock(name='cls')

    obj = mock.Mock(name='obj')
    obj.__dict__ = {}
    obj.__dict__[cached_property.func.__name__] = mock.Mock(name='value')
    obj.__dict__[cached_property.func.__name__].__dict__ = {}

    retval = cached_property.__get__(cached_property, obj, cls)

    TestCase.assertIs(TestCase, type(retval))
    TestCase.assertIs(cached_property.func.__name__, retval)

    retval

# Generated at 2022-06-11 22:18:50.135760
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property

    :return: None
    """
    import asyncio

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6
    assert obj.__dict__['y'] == 6

    assert MyClass.y == cached_property.__get__(MyClass.y, cls=MyClass)

    loop = asyncio.get_event_loop()

    # Now test a case with a coroutine
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return asyncio.ensure_future

# Generated at 2022-06-11 22:18:55.966425
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Foo:
        @cached_property
        def bar(self):
            return 5

    foo = Foo()
    print(foo.bar)
    print(foo.__dict__)
    print(foo.bar)


if __name__ == '__main__':
    test_cached_property___get__()

# Generated at 2022-06-11 22:19:06.217151
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""
    print(f"\n\n{'=' * 60}\n"
          f"Beginning unit test for method __get__ of class cached_property")
    TEST_SUCCESSFUL = True

    # Simple class for testing the @cached_property decorator
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Instantiate MyClass, set x and check y
    my_class = MyClass()
    assert my_class.y == 6

    # Set x and check y
    my_class.x = 3
    assert my_class.y == 4

    # Delete y and check y
    del my_class.y

# Generated at 2022-06-11 22:19:16.240764
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""
    import asyncio

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            async def f():
                return self.x + 1
            return f

    obj = MyClass()
    loop = asyncio.get_event_loop()
    assert loop.run_until_complete(obj.y()) == 6


# Generated at 2022-06-11 22:19:21.273693
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    x = MyClass()
    assert x.y == 6


# Generated at 2022-06-11 22:19:28.224398
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    from unittest.mock import patch
    from functools import partial

    c = partial(patch.object, cached_property)

    class _Dummy:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = _Dummy()
    y0 = obj.y
    y1 = obj.y
    assert y0 == y1 == 6

# Generated at 2022-06-11 22:19:34.880712
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # class C
    #     @cached_property
    #     def foo(self):
    #         'foo'
    class C(object):
        def __init__(self):
            self.y = 5

        @cached_property
        def foo(self):
            return self.y + 1

    c = C()
    assert c.foo == 6
    assert c.__dict__
    assert c.__dict__['foo'] == 6



# Generated at 2022-06-11 22:19:42.142482
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    y_first = obj.y
    assert y_first == 6
    obj.x = 6
    y_second = obj.y
    assert y_second == 6, y_second
    del obj.y
    y_third = obj.y
    assert y_third == 7



# Generated at 2022-06-11 22:19:50.445895
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test for the cached_property.__get__ method

    Args:
        None

    Returns:
        None

    """
    # pylint: disable=C0111,C0103

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


# Generated at 2022-06-11 22:19:58.018727
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    #
    # Setup
    #
    class Foo:
        def __init__(self):
            self.x = 5

        def y(self):
            return self.x + 1

    obj = Foo()
    #
    # Test
    #
    cp = cached_property(obj.y)
    assert isinstance(cp, cached_property)
    assert cp.__doc__ == obj.y.__doc__
    assert cp.func is obj.y
    assert cp.__get__(obj, Foo) == 6

# Generated at 2022-06-11 22:20:27.833031
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    obj.x = 100
    assert obj.y == 101

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        async def y(self):
            return self.x + 1

    obj = MyClass()
    assert asyncio.iscoroutinefunction(obj.y)
    obj.x = 100
    assert asyncio.iscoroutine(obj.y)


if __name__ == '__main__':
    test_cached_property___get__()

# Generated at 2022-06-11 22:20:38.524480
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class _Test:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = _Test()
    val = obj.y
    assert val == 6
    val = obj.y
    assert val == 6
    obj.x = 10
    val = obj.y
    assert val == 11
    del obj.y
    val = obj.y
    assert val == 11
    del obj.y
    obj.y = 15
    val = obj.y
    assert val == 15
    del obj.y
    obj.x = 20
    val = obj.y
    assert val == 21
    obj.y = 25
    val = obj.y
    assert val == 25
    obj.y = 25
    val = obj

# Generated at 2022-06-11 22:20:45.771057
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Run: python -m flutils.decorators test_cached_property___get__"""

    class MyClass:

        def __init__(self, x=None):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass(x=5)
    assert obj.y == 6
    assert obj.__dict__['y'] == 6
    assert obj.y == 6



# Generated at 2022-06-11 22:20:53.440904
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    result = "pass"

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    try:
        first_y = MyClass().y
        second_y = MyClass().y
        assert first_y == second_y
    except AssertionError:
        result = "fail"

    print(f"test_cached_property___get__: {result}")



# Generated at 2022-06-11 22:20:58.206882
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # noinspection PyUnusedLocal
    class Obj:

        def __init__(self):
            self.foo = 333

        @cached_property
        def bar(self):
            return self.foo + 7

    obj = Obj()
    # return the value of bar
    assert obj.bar == 340



# Generated at 2022-06-11 22:21:02.027356
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    delattr(obj, "y")
    assert obj.y == 6



# Generated at 2022-06-11 22:21:13.118837
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from types import FunctionType

    test_cached_property___get___class = create_class_and_instance()

    test_cached_property___get___instance = test_cached_property___get___class()

    test_cached_property___get___instance.y  # noqa
    test_cached_property___get___instance.y  # noqa

    assert isinstance(test_cached_property___get___instance.__dict__['y'], int)

    test_cached_property___get___instance.__dict__.pop('y')

    assert isinstance(test_cached_property___get___instance.__dict__['y'], int)

    assert isinstance(test_cached_property___get___class.__dict__['y'],
                      FunctionType)



# Generated at 2022-06-11 22:21:20.600512
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class _Test:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x + 2

    t = _Test()
    assert not hasattr(t, 'y')
    assert t.y == 6
    assert t.y == 6
    assert hasattr(t, 'y')

    del t.y
    assert not hasattr(t, 'y')
    assert t.y == 6
    assert t.y == 6
    assert hasattr(t, 'y')

    assert t.z == 7
    assert t.z == 7
    assert hasattr(t, 'z')

    del t.z

# Generated at 2022-06-11 22:21:25.581787
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test method __get__ of class cached_property."""

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__["y"] == obj.y



# Generated at 2022-06-11 22:21:31.063312
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Foo:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    foo = Foo()
    assert foo.y == 6
    assert foo.y == 6



# Generated at 2022-06-11 22:22:11.694229
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestCachedProperty:

        @cached_property
        def x(self):
            return 5

    assert TestCachedProperty().x == 5



# Generated at 2022-06-11 22:22:22.609776
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test the __get__ method of class cached_property

    """
    from pathlib import Path
    from shutil import rmtree
    from tempfile import gettempdir

    from flutils.decorators import cached_property
    from flutils.iterutils import batch
    from flutils.pathutils import PathPlus

    class MyClass:
        def __init__(self, path_):
            self.path_ = path_
            self.fpaths = []

        @cached_property
        def fpath(self):
            return self.path_.resolve()

        @cached_property
        def dpaths(self):
            return list(self.path_.iterdir())

        @cached_property
        async def data(self):
            data = await self.path_.glob('*.html')
            return

# Generated at 2022-06-11 22:22:31.957753
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test method __get__ of class cached_property"""

    from flutils.decorators import cached_property

    class DummyClass:

        @cached_property
        def regular_property(self):
            return 2

        @cached_property
        def async_property(self):
            return asyncio.Future()

    dummy = DummyClass()

    # The method __get__ should return a function if the function is a
    # coroutinefunction.
    assert callable(dummy.async_property)

    # The __doc__ attribute of the decorator should be the same as the
    # __doc__ attribute of the function decorated.
    assert dummy.regular_property.__doc__ == dummy.regular_property.__doc__

# Generated at 2022-06-11 22:22:40.002917
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import unittest
    import warnings

    class P:
        def __init__(self):
            self.x = 1

        @cached_property
        def y(self):
            return self.x + 1

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter('always')

        class TestCachedProperty(unittest.TestCase):
            def test_cached_property___get__(self):
                p = P()
                self.assertEqual(len(w), 0)
                self.assertEqual(p.y, 2)
                self.assertEqual(len(w), 1)

    unittest.main()


# Generated at 2022-06-11 22:22:51.569550
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestClass:
        @cached_property
        def cached_prop(self):
            return 3

        @cached_property
        def async_cached_prop(self):
            return asyncio.sleep(0.1, result=3)

    obj = TestClass()

    assert obj.cached_prop == 3
    assert 'cached_prop' not in TestClass.__dict__
    assert obj.__dict__['cached_prop'] == 3

    assert obj.cached_prop == 3
    assert obj.__dict__['cached_prop'] == 3
    assert 'cached_prop' not in TestClass.__dict__

    del obj.cached_prop
    assert 'cached_prop' not in obj.__dict__


# Generated at 2022-06-11 22:22:55.181548
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class Test(object):

        @cached_property
        def foo(self):
            return "foo"

    assert Test.foo == cached_property
    t = Test()
    assert t.foo == "foo"
    assert isinstance(t.foo, str)
    del t.foo
    assert isinstance(t.foo, str)



# Generated at 2022-06-11 22:23:04.858203
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest
    from pytest import raises
    import asyncio
    from flutils.decorators import cached_property
    from flutils.decorators import cached_property as c_p

    class MyClass:

        def __init__(self):
            self.x = 5
            self.c = 0
            self.fc = 0

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            self.c += 1
            return self.c

        @cached_property
        async def a(self):
            await asyncio.sleep(0.1)
            self.fc += 1
            return self.fc

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
   

# Generated at 2022-06-11 22:23:13.335445
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


if __name__ == '__main__':
    mycode = test_cached_property___get__.__code__
    mycode_co_code = mycode.co_code
    print('\n' * 3)
    print(mycode_co_code)
    print('\n' * 3)

# Generated at 2022-06-11 22:23:18.655306
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5
            self.y = 6

        @cached_property
        def sum(self):
            return self.x + self.y

    obj = MyClass()
    assert obj.sum == 11


# Generated at 2022-06-11 22:23:29.625833
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test class cached_property method __get__."""
    import pytest  # type: ignore
    from flutils.decorators import cached_property  # type: ignore

    class MyClass:
        # noinspection PyProtectedMember
        def __init__(self):
            self.x = 5
            self.y_computed = False

        @cached_property
        # noinspection PyUnusedLocal
        def y(self):
            self.y_computed = True
            return self.x + 1

    # Test

    # Test that a value is computed on first call
    obj = MyClass()
    y = obj.__dict__
    assert 'y' not in y
    assert obj.y == 6
    assert 'y' in y
    assert obj.y_computed is True

    # Test that a

# Generated at 2022-06-11 22:24:58.082867
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    f0 = cached_property(lambda x: 0)
    assert f0.__doc__ is None
    assert f0.func(None) == 0

    class V(object):
        @cached_property
        def f1(self):
            """Doc."""
            return 1

        @cached_property
        def f2(self):
            return 2

    v = V()
    assert v.f1 == 1
    assert 'f1' in v.__dict__
    assert v.f1 == 1
    assert 'f1' in v.__dict__
    assert V.f1 is V.f2
    assert 'f1' not in V.__dict__
    assert '__doc__' in V.f1.__dict__
    assert V.f1.__doc__ == "Doc."
    assert V