

# Generated at 2022-06-11 22:15:02.193369
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # noinspection PyPep8Naming
    class MyClass:
        def __init__(self):
            self.val = 5

        @cached_property
        def myproperty(self):
            return self.val + 1

    obj = MyClass()
    # noinspection PyUnresolvedReferences
    assert obj.myproperty == 6
    obj.val = 3
    # noinspection PyUnresolvedReferences
    assert obj.myproperty == 6


# Generated at 2022-06-11 22:15:14.140710
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    @cached_property
    def value(self):
        return self.x + 1

    class Test:
        def __init__(self, x):
            self.x = x

    test = Test(5)
    test.value
    assert test.value == 6
    assert test.__dict__['value'] == 6

    # noinspection PyUnresolvedReferences
    del test.value
    test.value
    assert test.value == 6
    assert test.__dict__['value'] == 6


async def test_cached_property_with_coroutinefunction___get__():

    @cached_property
    async def value(self):
        await asyncio.sleep(0.01)
        return self.x + 1


# Generated at 2022-06-11 22:15:22.660617
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import inspect

    def test_property(func):
        return inspect.iscoroutinefunction(func)

    class Object:

        @cached_property
        def prop(self):
            return 'prop'

        @cached_property
        def coro(self):
            yield from asyncio.sleep(0)

    loop = asyncio.get_event_loop()
    loop.run_until_complete(asyncio.ensure_future(test()))
    loop.close()

    assert hasattr(Object, 'prop')
    assert hasattr(Object, 'coro')
    assert isinstance(Object.prop, cached_property)  # test cached_property.__get__(None, cls)
    assert isinstance(Object.coro, cached_property)  # test cached_property.__get__(None, cls

# Generated at 2022-06-11 22:15:26.698119
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # This method is not tested as it is a derivative work of
    # `cached_property`.  See :obj:`~flutils.decorators.cached_property.__init__`
    pass

# Generated at 2022-06-11 22:15:30.876940
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import Mock

    @cached_property
    def mocked_func(obj):
        return obj.x + 1

    mocked_obj = Mock()
    mocked_obj.x = 5
    assert mocked_func.__get__(mocked_obj, None) == 6



# Generated at 2022-06-11 22:15:38.807908
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    print(f'{datetime.datetime.now()}: running {test_cached_property___get__.__name__}')
    c = cached_property
    o = object()
    f = lambda x: x
    obj = c(f)
    assert obj.__doc__ == f.__doc__
    assert obj.func == f
    assert obj.__get__(o, None) == f(o)



# Generated at 2022-06-11 22:15:47.280126
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # noinspection SpellCheckingInspection,PyUnusedLocal,PyUnusedLocal
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """This is the doc string of y"""
            if self.x == 5:
                raise RuntimeError('Expected self.x != 5')
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    try:
        obj.y
        raise AssertionError('Expected RuntimeError')
    except RuntimeError as e:
        assert str(e) == 'Expected self.x != 5'
    obj.x = 6
    assert obj.y == 7
    assert obj.y == 7

# Generated at 2022-06-11 22:15:54.140809
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""

    # Set up some test objects
    class A:
        @cached_property
        def x(self):
            return 7

    a = A()

    # Test the __get__ method of cached_property.
    assert a.x == 7
    assert a.__dict__['x'] == 7
    assert a.x == 7

# Generated at 2022-06-11 22:15:59.018621
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property.

    No return value. A failed assert will raise an
    AssertionError exception.

    *New in version 0.2.0*
    """

    class my_class:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    p = my_class()
    assert p.y == 6

# Generated at 2022-06-11 22:16:07.073536
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test the method ``__get__`` of class :func:`cached_property`.

    This test performs parametrized tests, by
    `pytest-cov <https://bit.ly/2HfKj8D>`_,
    of method ``__get__`` of class :func:`cached_property`.

    """
    from types import MethodType  # noqa: PyUnresolvedReferences
    from .fixtures.decorators import TestDecorators

    TestDecorators.test_cached_property___get__()



# Generated at 2022-06-11 22:16:12.605916
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class Test:

        def __init__(self):
            self._x = 5

        @cached_property
        def x(self):
            return self._x + 1

    # usage
    test = Test()
    assert isinstance(test.x, int)
    assert test.x == 6


# Generated at 2022-06-11 22:16:15.043849
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""
    #   TODO: todo
    pass


# Generated at 2022-06-11 22:16:20.136781
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-11 22:16:25.273613
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-11 22:16:32.898434
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest

    from flutils.decorators import cached_property

    class _TestClass:

        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    # Test the case where the property is evaluated
    _in_val = 5
    _ret_val = _TestClass(_in_val).y
    _exp_val = _in_val + 1
    assert _ret_val == _exp_val

    # Test the case where the property is accessed
    _in_val = 10
    _ret_val = _TestClass(_in_val).y
    _exp_val = _in_val + 1
    assert _ret_val == _exp_val

    # Test the case where the property is deleted and then accessed


# Generated at 2022-06-11 22:16:41.273472
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test method ``cached_property.__get__``.

    Test method ``cached_property.__get__``.

    *New in version 0.2.0*

    """
    import sys
    import unittest

    if sys.version_info[:2] < (3, 8):

        class MyTestClass(unittest.TestCase):
            class MyClass:

                def __init__(self):
                    self.x = 5

                @cached_property
                def y(self):
                    return self.x + 1

                def _get(self):
                    return self.__dict__.get("_TestClass__y")

            def testDecoratorReturnsSelf(self):
                self.assertIsInstance(self.MyClass.y, cached_property)


# Generated at 2022-06-11 22:16:53.694324
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import logging
    from flutils.logging import TrimmedLogger
    from flutils.objhelp import new_obj_kwargs
    from flutils.tests.pytestutils import run_tests
    from flutils.decorators import cached_property

    def _test_cached_property___get___for_regular_method():
        class Obj:

            def __init__(self):
                self.x = 5

            @cached_property
            def y(self):
                return self.x + 1

        obj = Obj()
        obj.y
        assert "y" in obj.__dict__
        assert 6 == obj.__dict__.get("y")
        del obj.y
        assert "y" not in obj.__dict__


# Generated at 2022-06-11 22:16:57.241311
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass


if __name__ == '__main__':
    import doctest

    # noinspection PyUnresolvedReferences
    doctest.testmod(verbose=True, report=True, optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-11 22:16:59.592171
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    print(__file__)
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 22:17:07.932355
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class A(object):
        def __init__(self, x):
            self.x = x

        @cached_property
        def prop1(self):
            """"""
            return self.x

        @cached_property
        def prop2(self):
            """"""
            return self.x

    obj = A(5)

    assert obj.prop1 == 5
    assert obj.prop1 == obj.prop1
    assert obj.prop1 is not obj.prop2
    assert obj.prop2 is obj.prop2



# Generated at 2022-06-11 22:17:22.846508
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    def test_method():
        return 5

    class TestClass:
        pass

    class TestChildClass(TestClass):
        pass

    class TestClass2:

        def __init__(self):
            self.test_method = test_method

        @cached_property
        def test_method(self):
            return test_method()

    cprop = cached_property(test_method)

    class TestClass3:

        def __init__(self):
            pass

        test_method = cprop

    assert cprop.__get__(None, TestClass) == cprop

    assert cprop.__get__(None, TestChildClass) == cprop

    assert cprop.__get__(TestClass2(), TestClass2) == 5


# Generated at 2022-06-11 22:17:31.103799
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""
    import functools
    import inspect
    import unittest

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert callable(MyClass.y)
    assert not inspect.iscoroutinefunction(MyClass.y)

    @functools.lru_cache()
    def cached_func():
        return 1

    assert callable(cached_func)
    assert not inspect.iscoroutinefunction(cached_func)

    class MyClass2:

        def __init__(self):
            self.x = 5

        @cached_property
        async def y(self):
            return self.x + 1



# Generated at 2022-06-11 22:17:35.120390
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class C:
        def __init__(self):
            self._x = None

        @cached_property
        def x(self):
            print("Into x")
            self._x = "foo"
            return self._x

    o = C()

    assert o.x == "foo"
    assert o.x == "foo"

# Generated at 2022-06-11 22:17:46.238732
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # noinspection PyUnresolvedReferences
    """Tests method `__get__` of class :class:`cached_property`

    This test is designed to ensure the correct behavior of
    :meth:`~cached_property.__get__` (i.e. :obj:`__get__`)

    Args:
        obj: The object being tested.
        cls: The class of the object being tested

    Returns:
        None: No return value is expected.

    Raises:
        AssertionError: If the return value is not `None`.

    """
    # Test instance not None
    obj = TestCachedProperty()
    obj.x = 5
    # Test cls is None
    cls = None
    # Test instance is None
    obj = None

# Generated at 2022-06-11 22:17:58.325502
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property
    """

    import unittest

    from flutils.decorators import cached_property

    class TestCachedProperty(unittest.TestCase):

        # noinspection PyUnusedLocal
        @cached_property
        def x(self):
            return 5

        @staticmethod
        def test_s_m_test_cached_property_x__expect_instance_attr_x_eq_value_returned_by_func():
            """
            Test cached_property x

            Test method __get__ of class cached_property

            Expected result:
                instance attribute x = value returned by function
            """
            tc = TestCachedProperty()
            self.assertEqual(tc.x, 5)


# Generated at 2022-06-11 22:18:07.697229
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    def func(obj):
        """func docstring."""
        return 1

    class MyClass:
        # Class-level docstring
        def __init__(self):
            self.x = 5

        f = cached_property(func)

    obj = MyClass()

    assert obj.x == 5
    assert obj.f == 1
    # Ensure f is removed from obj.__dict__
    assert 'f' not in obj.__dict__

    assert MyClass.f.__doc__ == "func docstring."
    # Method __doc__ for cached_property class
    assert cached_property.__get__.__doc__ is not None

    # Test for asyncio.iscoroutinefunction()
    async def func():
        return 1


# Generated at 2022-06-11 22:18:13.749518
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__['y'] == 6



# Generated at 2022-06-11 22:18:24.172741
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import asyncio
    from unittest.mock import Mock

    class MyClass:
        @cached_property
        def get_attr(self):
            return 'an_attr'

    obj = MyClass()
    attr_name = 'get_attr'
    obj.__dict__[attr_name] = 'original_attr'

    assert obj.get_attr == 'original_attr'

    @asyncio.coroutine
    def fake_coro():
        return 'an_attr'

    obj.get_attr = fake_coro
    assert asyncio.iscoroutinefunction(obj.get_attr)
    assert isinstance(obj.get_attr, Mock)

    # the following would be the right thing to do, but the mock cannot be
    # reset at this point
    # obj.__dict__[attr

# Generated at 2022-06-11 22:18:34.830114
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    __test_cached_property___get___func = lambda obj: True
    __test_cached_property___get__ = cached_property(__test_cached_property___get___func)
    assert __test_cached_property___get__.__doc__ == __test_cached_property___get___func.__doc__
    assert __test_cached_property___get__.func == __test_cached_property___get___func
    __test_cached_property___get___obj = object()
    __test_cached_property___get___cls = object()
    assert __test_cached_property___get__.__get__(__test_cached_property___get___obj, __test_cached_property___get___cls) == True
    __test_cached

# Generated at 2022-06-11 22:18:41.073754
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    obj.x = 19
    assert obj.y == 20



# Generated at 2022-06-11 22:18:52.655790
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6

# Generated at 2022-06-11 22:18:54.230164
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test method __get__ of class cached_property"""



# Generated at 2022-06-11 22:18:58.593755
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-11 22:19:04.472837
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property
    from flutils.decorators import test_cached_property___get__

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    test_cached_property___get__.assertEqual(obj.y, 6)

# Generated at 2022-06-11 22:19:08.666231
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass(5)
    assert obj.y == 6



# Generated at 2022-06-11 22:19:17.211790
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # test cached_property
    obj = MyClass()
    y_1 = obj.y
    y_2 = obj.y
    print(obj.__dict__)
    # {'x': 5, 'y': 6}

    assert y_1 == 6
    assert y_2 == 6
    assert y_1 is y_2



# Generated at 2022-06-11 22:19:21.791861
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.y == 6

# Generated at 2022-06-11 22:19:26.229387
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert MyClass().y == 6



# Generated at 2022-06-11 22:19:28.484248
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import Mock
    from time import time
    from time import sleep

    class MyClass:
        @cached_property
        def func(self):
            sleep(5)
            return time()

    obj = MyClass()
    assert obj.func == obj.func



# Generated at 2022-06-11 22:19:31.847167
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Setup
    class TestClass:
        pass

    @cached_property
    def func(self):
        return 'Test'

    test_obj = TestClass()

    # Exercise
    test_obj.func

    # Verify
    assert test_obj.__dict__[func.__name__] == 'Test'



# Generated at 2022-06-11 22:19:58.439273
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass_Test_1:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert MyClass_Test_1().y == 6

    class MyClass_Test_2:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert MyClass_Test_2().y == 6

# Generated at 2022-06-11 22:20:08.938836
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import mock

    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Test some of the attributes on both the instance and the class.
    assert MyClass().y == 6
    assert hasattr(MyClass.y, "__doc__")
    assert hasattr(MyClass.y, "__name__")

    my_class = MyClass()
    my_class.y
    assert my_class.y == 6

    # The function shouldn't be called again.
    with mock.patch.object(cached_property, "func", return_value=None) as mock_func:
        my_class.y

# Generated at 2022-06-11 22:20:19.395692
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # GIVEN a class with a cached property
    @cached_property
    def test(self):
        self._test_count += 1
        return '{} {}'.format(self.x, self._test_count)

    class Test:
        def __init__(self, x):
            self.x = x
            self._test_count = 0

        test = test

    # WHEN creating an instance of the class
    obj = Test('test')

    # THEN a cache is created
    assert obj.__dict__['test'] == 'test 1'
    assert obj._test_count == 1

    # WHEN accessing the cached property again
    assert obj.test == 'test 1'

    # THEN it still has the correct value and increments the counter
    assert obj.__dict__['test'] == 'test 1'
    assert obj._test

# Generated at 2022-06-11 22:20:29.500383
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""
    import asyncio
    from flutils.decorators import cached_property

    class Item:

        def __init__(self):
            self.y = 50

        @cached_property
        def x(self):
            self.y += 1
            return self.y

        @cached_property
        @asyncio.coroutine
        def z(self):
            raise NotImplementedError

    item = Item()
    item.x
    assert item.x == 51
    assert item.y == 51
    del item.y
    assert item.x == 52
    assert item.y == 52

    if sys.version_info >= (3, 7):
        with pytest.raises(NotImplementedError):
            item.z

# Generated at 2022-06-11 22:20:36.649168
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj = object.__new__(cached_property)
    assert obj.__get__(1.23) == 1.23

    obj = object.__new__(cached_property)
    assert obj.__get__(frozenset({1, 2})) == frozenset({1, 2})

    obj = object.__new__(cached_property)
    assert obj.__get__(({1, 2}, {3})) == ({1, 2}, {3})

# Generated at 2022-06-11 22:20:44.394694
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.y == 6

    assert "y" in obj.__dict__
    assert obj.__dict__["y"] == 6


if __name__ == "__main__":
    import pytest

    pytest.main([__file__])

# Generated at 2022-06-11 22:20:49.382406
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-11 22:20:54.684085
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-11 22:21:01.044345
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    loop = asyncio.get_event_loop()

    class MyClass:

        def __init__(self):
            self.x = 5
            self.y_is_cached = False

        @cached_property
        def y(self):
            self.__class__.y_is_cached = True
            return self.x + 1

    obj = MyClass()
    loop.run_until_complete(obj.y)
    assert obj.y == 6
    assert obj.y_is_cached is True


# Generated at 2022-06-11 22:21:06.565919
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class A:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    a = A()
    assert A.y is a.y, '%r is not %r' % (A.y, a.y)



# Generated at 2022-06-11 22:21:49.081593
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-11 22:21:54.985999
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test method __get__ of class cached_property.
    """

    class MyClass:
        @cached_property
        def x(self):
            return 42

    obj = MyClass()

    assert obj.x == 42
    assert obj.__dict__['x'] == 42
    assert obj.x == 42



# Generated at 2022-06-11 22:21:58.746005
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class A:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    a = A()
    assert a.y == 6



# Generated at 2022-06-11 22:22:05.280689
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property


    class A:
        def __init__(self):
            self.count = 0

        @cached_property
        def prop_no_args(self):
            self.count += 1
            return 1

        @cached_property
        def prop_1_arg(self, value):
            self.count += 1
            return value

    a = A()
    a.prop_no_args
    assert a.count == 1
    a.prop_no_args
    assert a.count == 1
    assert a.prop_no_args == 1

    a = A()
    a.prop_1_arg(1)
    assert a.count == 1
    a.prop_1_arg(2)
    assert a.count == 2
    assert a.prop_

# Generated at 2022-06-11 22:22:13.685989
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import functools
    import unittest
    import sys

    class TestCachedProperty(unittest.TestCase):

        def _cached_property_test(self, obj, property_value):
            self.assertEqual(property_value, obj.y)
            # Accessing 'y' a second time yields the cached value
            self.assertEqual(property_value, obj.y)

        def test_decorator_no_override(self):
            class TestNoOverride:
                # noinspection PyPep8Naming
                @functools.cached_property
                def y(self):
                    return 5

            obj = TestNoOverride()
            self._cached_property_test(obj, 5)


# Generated at 2022-06-11 22:22:17.146704
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        @cached_property
        def calc(self):
            return 5

    obj = MyClass()
    assert obj.calc == 5



# Generated at 2022-06-11 22:22:21.277469
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    assert obj.y == 6



# Generated at 2022-06-11 22:22:26.981011
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-11 22:22:30.505887
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-11 22:22:36.124519
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    import pytest

    class Obj:
        @cached_property
        def x(self):
            return "XYZ"

    @asyncio.coroutine
    def x_async(self):
        return "XYZ"

    class ObjAsync:
        @cached_property
        def x(self):
            return x_async(self)

    obj = Obj()
    obj_async = ObjAsync()

    # obj.x
    assert obj.x == "XYZ"
    assert obj.__dict__["x"] == "XYZ"

    # obj.x
    assert obj.x == "XYZ"
    assert obj.__dict__["x"] == "XYZ"

    # obj.x
    assert obj.x == "XYZ"

# Generated at 2022-06-11 22:24:02.778054
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    result = None

    class MyClass:

        def __init__(self, n):
            self.x = n

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass(n=5)

    result = obj.y

    assert result == 6

# Generated at 2022-06-11 22:24:07.131666
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    y = obj.y
    assert y == 6

# Generated at 2022-06-11 22:24:16.908296
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property.
    """
    import flutils.decorators
    test_value_from_instance = flutils.decorators.cached_property(
        lambda x: x * 2)
    instance = flutils.decorators.cached_property
    assert test_value_from_instance.__get__(instance,
                                            flutils.decorators.cached_property) is test_value_from_instance
    assert test_value_from_instance.__get__(None,
                                            flutils.decorators.cached_property) is test_value_from_instance



# Generated at 2022-06-11 22:24:21.089744
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self, x):
            self.__x = x

        @cached_property
        def y(self):
            return self.__x + 1

    assert MyClass(5).y == 6

# Generated at 2022-06-11 22:24:32.082433
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for `~flutils.decorators.cached_property`.

    *New in version 0.2.0*
    """

    import sys
    import unittest
    import warnings

    # noinspection PyProtectedMember
    from flutils.decorators import cached_property

    from flutils.compat import PY36, PY37

    PY36_AND_37 = PY36 and PY37

    class MyClass:
        """MyClass is used for testing."""

        def __init__(self, foo, bar=None):
            self.foo = foo
            self.bar = bar

        @cached_property
        def baz(self):
            return 5

        @cached_property
        def qux(self):
            return "qux"


# Generated at 2022-06-11 22:24:35.898951
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    del obj.y
    assert obj.y == 6

# Generated at 2022-06-11 22:24:46.757432
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # 1. No obj is passed in, so return the decorator
    # 2. Value does not exist, it is calculated and cached
    # 3. Value does exist, it is retrieved from cache
    # 4. Value does not exist, it is calculated and cached
    # 5. Value does exist, it is retrieved from cache
    # 6. Delete the cached value, which recreates the cached

    class MyClass:

        def __init__(self):
            self.x = 0

        @cached_property
        def y(self):
            """This is the docstring for y."""
            self.x += 1
            return self.x

    obj = MyClass()
    assert cached_property.__get__(None, MyClass) is cached_property
    assert obj.y == 1
    assert obj.y == 1
    assert obj.y

# Generated at 2022-06-11 22:24:57.051916
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import sys
    from unittest import TestCase, mock

    if sys.version_info.minor == 8:
        import functools
    else:
        import pytest
        from flutils.decorators import cached_property


    class Test(TestCase):

        def setUp(self) -> None:
            self.obj = Test
            self.func = mock.Mock()
            self.prop = cached_property.__get__(self.func, self.obj)
            if sys.version_info.minor == 8:
                self.prop = functools.cached_property(self.prop)
            self.f = asyncio.coroutine(self.func)

        def test_get(self):
            self.func.return_value = "bar"
            assert self.prop() == "bar"

