

# Generated at 2022-06-11 22:15:02.968798
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit tests for method ``__get__`` of class :obj:`cached_property`.

    This function tests the :obj:`cached_property` decorator.  It ensures
    that the method ``__get__`` of the class :obj:`cached_property`
    works as intended.

    *New in version 0.2.0*
    """
    # The following class is used to test the cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Test the cached_property
    m = MyClass()
    assert m.y == 6
    assert m.__dict__['y'] == 6

    # Test the cached_property function
    m.x = 10

# Generated at 2022-06-11 22:15:07.477615
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class _MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = _MyClass()
    obj.y
    obj.x = 2
    obj.y

# Generated at 2022-06-11 22:15:18.712286
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test for method __get__ of class cached_property()
    """

    import inspect
    import logging
    import asyncio

    async def get_y():
        obj = MyClass()
        # y = obj.y
        try:
            y = await obj.y
        except AttributeError:
            y = None
        # y = await obj.y
        try:
            logging.warning("obj.y: %s (%s)", obj.y, type(obj.y))
            logging.warning("obj.__dict__['y']: %s (%s)", obj.__dict__['y'], type(obj.__dict__['y']))
        except AttributeError:
            pass
        return y

    class MyClass:

        def __init__(self):
            self.x = 5


# Generated at 2022-06-11 22:15:24.587400
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """ Test cached_property """

    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()

    assert obj.y == 6
    assert obj.__dict__['y'] == 6

# Generated at 2022-06-11 22:15:30.969655
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Obj:
        def __init__(self):
            self.called = False

        @cached_property
        def prop(self):
            self.called = True
            return 42

    obj = Obj()
    assert obj.prop == 42
    assert obj.called is True
    obj.called = False
    assert obj.prop == 42
    assert obj.called is False



# Generated at 2022-06-11 22:15:43.125408
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    try:
        assert obj.__dict__['y'] == 6
    except AssertionError:
        print("AssertionError raised, as expected.")

    @asyncio.coroutine
    def coroutine():
        yield
        return 3

    obj2 = MyClass()
    asyncio.run(coroutine())
    try:
        assert obj2.__dict__['y'] == 3
    except AssertionError:
        print("AssertionError raised, as expected.")



# Generated at 2022-06-11 22:15:48.464068
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit tests"""

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @asyncio.coroutine
        @cached_property
        def y2(self):
            return self.x + 1

    my_class = MyClass()

    assert my_class.y == 6
    assert my_class.__dict__['y'] == 6

    assert asyncio.iscoroutine(my_class.y2)
    assert isinstance(my_class.__dict__['y2'], asyncio.Future)
    assert asyncio.iscoroutine(my_class.y2)

    return

# Generated at 2022-06-11 22:15:51.151632
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import flutils.testing.helpers as helpers

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert helpers.call(obj.y, num_args=0) == 6
    assert helpers.call(obj.y, num_args=0) == 6

    del obj.y
    assert helpers.call(obj.y, num_args=0) == 6



# Generated at 2022-06-11 22:15:56.381751
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property
    from nose.tools import assert_equal


    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert_equal(obj.y, 6)

# Generated at 2022-06-11 22:16:01.408119
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    retval = obj.y
    assert retval == 6
    assert obj.__dict__['y'] == 6


# Generated at 2022-06-11 22:16:10.933323
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from ..decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    # noinspection PyUnusedLocal
    def set_x(x):
        obj.x = x
        assert obj.y == x + 1

    for x in (1, 2, 3, 4, 100):
        set_x(x)



# Generated at 2022-06-11 22:16:18.868362
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Note: Python 3.8+ provides functools.cached_property which does not
    # require the use of the flutils.decorators.cached_property decorator.
    class Class1:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    instance = Class1()
    assert instance.y == 6



# Generated at 2022-06-11 22:16:22.126267
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    test_obj = TestClass()
    assert test_obj.y == 6

# Generated at 2022-06-11 22:16:27.209137
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.y == 6

# Generated at 2022-06-11 22:16:32.431076
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property
    """

    class MyClass(object):
        def __init__(self, name, value):
            self.name = name
            self.value = value

        @cached_property
        def x(self):
            """
            :return:
            """
            return self.value * 2

    thing1 = MyClass('thing1', 1000)
    thing2 = MyClass('thing2', 2000)

    assert thing1.x == 2000
    assert thing2.x == 4000

# Generated at 2022-06-11 22:16:39.642905
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test method __get__ of class cached_property.

    :return: True if ok
    """
    class TestClass:
        """ Test class """

        def __init__(self):
            """ Init method """
            self.cache = 0

        @cached_property
        def cache_property(self):
            """ cached property """
            self.cache += 1
            return self.cache

    obj = TestClass()

    assert 0 == obj.cache
    assert 1 == obj.cache_property
    assert 1 == obj.cache_property
    assert 1 == obj.cache


# Generated at 2022-06-11 22:16:45.990439
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class C:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    # Ensure that y was fetched correctly and is cached correctly
    c = C(5)
    assert c.y == 6
    c.x = 10
    assert c.y == 6
    del c.y
    assert c.y == 11



# Generated at 2022-06-11 22:16:52.115522
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-11 22:17:01.437567
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Test async
    async def get_value(obj):
        return obj.x

    @cached_property
    def y(self):
        return get_value(self)

    class MyClass:

        def __init__(self):
            self.x = 5

    obj = MyClass()
    assert (y.__get__(obj, None) == get_value(obj))
    assert (obj.__dict__[y.func.__name__] == y.__get__(obj, None))

    # Test normal
    @cached_property
    def z(self):
        return self.x

    class MyClass2:

        def __init__(self):
            self.x = 5

    obj2 = MyClass2()

# Generated at 2022-06-11 22:17:04.097423
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """ Function to test method __get__ of class cached_property

    """
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    result = MyClass.y

    assert result == cached_property


# Generated at 2022-06-11 22:17:06.932662
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass

# Generated at 2022-06-11 22:17:07.815538
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 22:17:18.453614
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    def _get_after(obj: object, name: str, attr: object):
        obj.__dict__.clear()
        obj.__dict__[name] = attr

    @cached_property
    def method1(self):
        return 1

    obj = object()
    assert method1.__get__(obj, None) == 1
    assert obj.__dict__['method1'] == 1

    _get_after(obj, 'method1', 10)
    assert method1.__get__(obj, None) == 10

    @cached_property
    def method2(self):
        return 1

    obj = object()
    _get_after(obj, 'method2', 10)


# Generated at 2022-06-11 22:17:26.862374
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property
    """

    #  Test 1
    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.y == 6

    #  Test 2
    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    del obj.y
    assert obj.y == 6

    #  Test 3
    class TestClass:
        def __init__(self):
            self.x = 5


# Generated at 2022-06-11 22:17:34.611797
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    MyClass.y.__set__(None, 3)
    obj = MyClass()
    obj.y
    assert obj.__dict__["y"] == 6

    obj = MyClass()
    class MySubClass:
        pass

    obj2 = MySubClass()
    obj2.y
    assert not hasattr(obj2, "y")


##############################################################################


# noinspection PyPep8Naming

# Generated at 2022-06-11 22:17:45.792918
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Tests for method __get__ of class cached_property."""
    from unittest.mock import Mock

    from flutils.decorators import cached_property

    class MyTestClass:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyTestClass(1)
    assert obj.y == 2

    obj = MyTestClass(2)
    assert obj.y == 3

    obj = MyTestClass(3)
    assert obj.y == 4

    class MyTestClass:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyTestClass(1)


# Generated at 2022-06-11 22:17:49.350141
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass():
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-11 22:17:56.887768
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""
    __tracebackhide__ = True

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


if __name__ == '__main__':
    import pytest

    pytest.main(args=['.', '-v', '-s'])

# Generated at 2022-06-11 22:18:07.213728
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for :meth:`~flutils.decorators.cached_property.__get__` of
    :class:`~flutils.decorators.cached_property`

    :return: ``None``
    :rtype: None
    """

    class Foo:
        count = 0

        @cached_property
        def bar(self):
            self.count += 1
            return self.count

    foo = Foo()
    assert foo.bar == 1
    assert foo.bar == 1

    foo2 = Foo()
    assert foo2.bar == 1
    assert foo2.bar == 1
    assert foo2.bar == 1
    assert foo.bar == 1
    assert foo.bar == 1
    assert foo2.bar == 1

    del foo
    assert foo2.bar == 1


# Generated at 2022-06-11 22:18:17.411382
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest
    from asynctest import MagicMock
    from flutils.decorators import cached_property

    class Test:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        @asyncio.coroutine
        def z(self):
            return self.x + 2

    test = Test()
    mock_future = MagicMock(spec=asyncio.Future)
    test.z = mock_future
    test.__dict__['z'] = mock_future
    with pytest.raises(AttributeError):
        test.a

    assert test.y == 6
    assert test.y == 6
    # Set y manually. Make sure it doesn't get overwritten
   

# Generated at 2022-06-11 22:18:27.802502
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class X:
        def __init__(self):
            self.test_get_calls = 0

        @cached_property
        def cached_attribute(self):
            self.test_get_calls += 1
            return 'Attribute value'

    obj_1 = X()
    obj_2 = X()

    assert obj_1.test_get_calls == 0
    assert obj_2.test_get_calls == 0

    assert obj_1.cached_attribute == 'Attribute value'
    assert obj_2.cached_attribute == 'Attribute value'

    assert obj_1.test_get_calls == 1
    assert obj_2.test_get_calls == 1

    assert obj_1.cached_attribute == 'Attribute value'
   

# Generated at 2022-06-11 22:18:33.048784
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyTestClass(object):
        def __init__(self):
            self.other = 5

        @cached_property
        def x(self):
            return self.other + 1

    obj = MyTestClass()

    assert obj.x == 6
    assert obj.__dict__['x'] == 6



# Generated at 2022-06-11 22:18:43.056181
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    if asyncio.iscoroutinefunction(test_cached_property___get__):
        pytest.skip("Skip unit test for coroutine function")

    class _TargetClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    target_class_instance = _TargetClass()
    target_class_instance.y

    assert "y" in target_class_instance.__dict__
    assert target_class_instance.__dict__["y"] == target_class_instance.x + 1



# Generated at 2022-06-11 22:18:47.169965
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class AClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = AClass()
    assert(obj.y == 6)

# Generated at 2022-06-11 22:18:56.012682
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Cache dict is empty
    obj = MyClass()
    assert obj.__dict__ == {}

    # First call to y populates the cache dict
    assert obj.y == 6

    # Second call uses the value from the cache dict
    assert obj.y == 6

    # Cache dict is a copy and therefore can be modified, but that won't affect
    # the result of subsequent calls
    obj.__dict__['y'] = 7
    assert obj.y == 6

    # If we delete the cached value, it will be recalculated
    del obj.__dict__['y']
    assert obj.y == 6



# Generated at 2022-06-11 22:19:06.216938
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    def _assert_func_called_once(instance):
        obj = MyClassTest()
        assert obj.z == 13
        assert obj.z == 13
        assert obj.z == 13
        assert MyClassTest.z.__doc__ == 'This is doc'
        assert type(obj.z) is int
        assert obj.z == 13

        obj.z = 5
        assert obj.z == 5

    def _assert_async_func_called_once(instance):
        async def _main():
            obj = MyClassTest()
            assert await obj.a == 13
            assert await obj.a == 13
            assert await obj.a == 13
            assert MyClassTest.a.__doc__ == 'This is doc'
            assert type(obj.a) is asyncio.Future
            assert await obj.a == 13

           

# Generated at 2022-06-11 22:19:13.200653
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from functools import partial

    class MyClass:

        @cached_property
        def y(self):
            return self.x + 1

        def __init__(self):
            self.x = 5

    obj = MyClass()
    assert obj.__dict__ == {'x': 5}
    z = obj.__get__(obj, partial(MyClass, y=1))

    assert z == 6
    assert obj.__dict__ == {'x': 5, 'y': 6}


# Generated at 2022-06-11 22:19:16.000533
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class SomeClass:
        @cached_property
        def some_property(self):
            return None

    obj = SomeClass()

    assert obj.some_property is None

# Generated at 2022-06-11 22:19:22.130250
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():  # noqa: D102
    class TestClass:

        def __init__(self, a):
            self.a = a

        @cached_property
        def b(self):
            return self.a + 1

    for i in range(1, 5):
        obj = TestClass(i)
        assert obj.b == i + 1



# Generated at 2022-06-11 22:19:32.286912
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import TestCase, main

    from flutils.decorators import cached_property

    class TestObj(object):

        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    # Test case 1
    test_obj = TestObj(1)
    assert test_obj.y == 2

    # Test case 2
    test_obj = TestObj(1)
    assert test_obj.y == 2

    # Test case 3
    test_obj = TestObj(1)
    assert test_obj.y == 2


if __name__ == "__main__":
    test_cached_property___get__()

# Generated at 2022-06-11 22:19:42.574249
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    _test_obj = Test_cached_property()
    assert _test_obj.my_prop == _test_obj.__dict__['my_prop']
    _test_obj.__dict__.pop('my_prop')
    assert _test_obj.my_prop != _test_obj.__dict__['my_prop']
    _test_obj.__dict__.pop('my_prop')
    assert _test_obj.my_prop == _test_obj.__dict__['my_prop']


# Generated at 2022-06-11 22:19:46.675572
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Foo:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Foo()
    assert obj.y == 6

# Generated at 2022-06-11 22:19:53.473891
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Test basic functionality
    obj = MyClass()
    assert 6 == obj.y

    # Test once calculated and cached
    obj.x = 4
    assert 6 == obj.y

    # Test resetting cache
    del obj.y
    assert 5 == obj.y



# Generated at 2022-06-11 22:20:01.492107
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1
    #
    # test cached_property
    #
    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__["y"] == 6
    #
    # test cached_property is only computed once per instance.
    #
    obj.x = 8
    assert obj.y == 6
    #
    # test deleting the attribute resets the property
    #
    del obj.y
    assert obj.y == 9


# Generated at 2022-06-11 22:20:13.697922
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import unittest

    class TestCachedPropertyGet(unittest.TestCase):

        @staticmethod
        def test_01():
            class obj:

                @cached_property
                def _foo(self):
                    return 1

            assert obj()._foo == 1

        @staticmethod
        async def async_foo():
            await asyncio.sleep(0.25)
            return 1

        @staticmethod
        def test_02():
            class obj:

                @cached_property
                def _bar(self):
                    return asyncio.get_event_loop().run_until_complete(
                        async_foo()
                    )

            assert obj()._bar == 1


# Generated at 2022-06-11 22:20:20.207233
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Foo:
        def __init__(self):
            self.x = 5
            self.foo_count = 0

        @cached_property
        def foo(self):
            self.foo_count += 1
            return self.x + 1

    obj = Foo()
    assert obj.foo == 6
    assert obj.x == 5
    assert obj.foo_count == 1

    del obj.foo
    assert obj.foo == 6
    assert obj.x == 5
    assert obj.foo_count == 2

    assert obj.foo
    assert obj.foo
    assert obj.x == 5
    assert obj.foo_count == 2



# Generated at 2022-06-11 22:20:29.799359
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class C:

        @cached_property
        def x(self):
            return 1

    c = C()
    # x should not be yet in the __dict__
    assert "x" not in c.__dict__

    # first call should compute, and cache the result
    assert c.x == 1
    assert "x" in c.__dict__
    assert isinstance(c.__dict__["x"], int)

    # second call should retrieve the cached value
    assert c.x == 1

    # delete 'x' property
    del c.x
    assert "x" not in c.__dict__  # not cached anymore

    # third call should recompute, and cache the result again
    assert c.x == 1
    assert "x" in c.__dict__

# Generated at 2022-06-11 22:20:37.476684
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x + 2

    obj = MyClass()
    assert obj.y == 6
    assert obj.z == 7
    obj.x = 10
    assert obj.y == 11
    assert obj.z == 12
# /Unit test for method __get__ of class cached_property



# Generated at 2022-06-11 22:20:42.602315
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


# Generated at 2022-06-11 22:20:49.751432
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Base(object):
        def __init__(self):
            self.value = 'base'

    class Derived(Base):
        @cached_property
        def cached_property(self):
            return 'derived'

    derived = Derived()
    assert derived.cached_property == 'derived'
    assert derived.__dict__ == {'cached_property': 'derived', 'value': 'base'}
    assert Base.cached_property == Derived.cached_property

    del derived.cached_property
    assert derived.__dict__ == {'value': 'base'}



# Generated at 2022-06-11 22:21:02.789630
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit tests for method __get__()

    This method is the getter for the cached_property class.

    Returns
    -------
    None

    """

    ###########################################################################
    #
    # Test 1:  Not an object.
    #
    ###########################################################################

    def method(obj):
        return obj.x + 1

    cp = cached_property(method)
    assert cp.__get__(None, object) == cp

    ###########################################################################
    #
    # Test 2:  Not a method.
    #
    ###########################################################################

    cp = cached_property()
    with pytest.raises(TypeError):
        cp.__get__(None, object)

    ###########################################################################
    #
    # Test 3:  Normal return value.
    #
   

# Generated at 2022-06-11 22:21:08.723939
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from types import FunctionType

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    assert obj.y == 6
    obj.x = 2
    assert obj.y == 6
    assert type(obj.__dict__['y']) == FunctionType

# Generated at 2022-06-11 22:21:12.659918
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-11 22:21:20.304649
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import asyncio

    class TestClass:
        pass

    def test_function(obj):
        return 5

    @cached_property
    def test_y(obj):
        return obj.x + 1

    obj = TestClass()
    obj.x = 5
    assert test_y.__get__(obj, obj) == 6

    @cached_property
    async def async_test(obj):
        return 5

    @asyncio.coroutine
    def go():
        obj.x2 = 3
        assert (await async_test.__get__(obj, obj)) == 5
        assert type(async_test.__get__(obj, obj)) is asyncio.Future
        assert obj.__dict__['async_test'] is async_test.__get__(obj, obj)


# Generated at 2022-06-11 22:21:28.817708
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import unittest.mock as mock

    mock_obj = mock.Mock()

    def foo():
        mock_obj()

    def bar():
        pass

    props = {
        "func": mock.Mock(return_value=1),
        "func2": mock.Mock(return_value=2),
        "func3": mock.Mock(return_value="bar"),
        "func4": mock.Mock(return_value="not bar"),
        "func5": mock.Mock(side_effect=AttributeError),
        "func6": mock.Mock(side_effect=[AttributeError, RuntimeError]),
        "func7": mock.Mock(side_effect=RuntimeError),
        "func8": mock.Mock(side_effect=lambda: 1),
    }


# Generated at 2022-06-11 22:21:36.458392
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import unittest
    from unittest import mock

    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class TestCachedProperty(unittest.TestCase):

        @mock.patch('flutils.decorators.logger')
        def test_cached_property_get_fails(self, mocked_logger):
            obj = MyClass()
            with self.assertRaises(Exception):
                obj._y
            self.assertTrue(mocked_logger.exception.called)

    unittest.main()


# Generated at 2022-06-11 22:21:47.598093
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    For most cached properties, __get__ returns the cached value. But if
    the cached property is a coroutine, __get__ returns a coroutine that
    sets the cached value.
    """

    class Cls:
        def __init__(self):
            self.x = 0
            self.y = 0
            self.z = 0

        @cached_property
        def prop(self):
            self.x += 1
            return self.x

        @cached_property
        def w(self):
            self.y += 1
            return self.y

        @cached_property
        async def q(self):
            await asyncio.sleep(0.1)
            self.z += 1
            return self.z

    cls = Cls()
    assert cls.prop == 1
    assert cls

# Generated at 2022-06-11 22:21:51.245993
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6
    assert isinstance(obj.y, int)



# Generated at 2022-06-11 22:22:01.727852
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import asyncio

    def add_one(obj):
        if asyncio.iscoroutinefunction(obj.x):
            return obj.x() + 1
        return obj.x + 1

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return add_one(self)

    assert add_one(MyClass()) == 6
    obj = MyClass()
    assert obj.y == obj.y
    assert obj.y == 6

    def add_two(obj):
        return obj.x + 2

    class MyClass2:
        def __init__(self):
            self.x = 6

        @cached_property
        def y(self):
            return add_two(self)


# Generated at 2022-06-11 22:22:10.814571
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            pass

        def __repr__(self):
            key = self.x.__name__
            return '{}(x={!r})'.format(self.__class__.__name__,
                                       getattr(self, key, None))

        @cached_property
        def x(self):
            print('x init')
            return 42

    obj = MyClass()
    assert obj.x == 42
    del obj.x
    assert not hasattr(obj, 'x')
    assert obj.x == 42
    assert repr(obj) == "MyClass(x=42)"



# Generated at 2022-06-11 22:22:37.046392
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import TestCase

    obj = object()

    class MyClass:

        @cached_property
        def y(self):
            return self.x + 1

    myclass = MyClass()
    myclass.x = 4
    assert myclass.y == 5

    cls = MyClass()
    cp = cached_property(cls.y)

    assert cp.__doc__ == cls.y.__doc__

    test_case = TestCase()

    with test_case.assertRaises(AttributeError):
        cp = cached_property(obj.y)

    test_case.assertIsNone(cp.__get__(obj, obj.__class__))

    import asyncio

    @asyncio.coroutine
    def dummy():
        return 'dummy'


# Generated at 2022-06-11 22:22:45.792616
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Test:
        def __init__(self, x):
            self.__x = x

        @cached_property
        def prop(self):
            return self.__x + 1

    obj = Test(0)
    assert obj.prop == 1
    assert obj.__dict__['prop'] == 1
    obj.__x = 1
    assert obj.prop == 1
    assert obj.__dict__['prop'] == 1
    del obj.prop
    assert obj.prop == 2
    assert obj.__dict__['prop'] == 2



# Generated at 2022-06-11 22:22:49.539461
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import asyncio

    class MyClass:
        @cached_property
        def y(self):
            return self.x

    obj = MyClass()

    assert obj.y == obj.y == obj.y == obj.y



# Generated at 2022-06-11 22:22:57.397677
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit testing for method __get__ of class cached_property
    """
    import asyncio
    import unittest.mock

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    @asyncio.coroutine
    def coro():
        return 2

    class MyClassCoro:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return coro()

    with unittest.mock.patch("asyncio.iscoroutinefunction") as m:
        m.return_value = False
        obj = MyClass()
        expected = 6

# Generated at 2022-06-11 22:23:03.010505
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Myclass:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    obj = Myclass(5)

    assert obj.y == 6
    assert obj.__dict__['y'] == 6

    obj.x = 10
    assert obj.y == 6
    assert obj.__dict__['y'] == 6

# Generated at 2022-06-11 22:23:06.758253
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-11 22:23:16.214563
# Unit test for method __get__ of class cached_property

# Generated at 2022-06-11 22:23:20.849940
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    def test_fixture(obj: MyClass) -> int:
        return obj.x + 1

    class MyClass:
        def __init__(self):
            self.x = 5

    obj = MyClass()
    assert cached_property(test_fixture).__get__(obj, MyClass) == 6


# Unit tests for method _wrap_in_coroutine of class cached_property

# Generated at 2022-06-11 22:23:22.388542
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():  # noqa: D102
    # No unit test to perform
    pass

# Generated at 2022-06-11 22:23:31.948247
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MockCachedProperty(cached_property):
        def __init__(cls, func):
            pass

    a = MockCachedProperty(lambda x: x+2)

    # obj is None
    assert a.__get__(None, list) is a

    class Obj:
        def __init__(self):
            self.x = 5

        @a
        def y(self):
            return self.x

    obj = Obj()

    assert obj.__dict__["y"] == 7


if __name__ == "__main__":
    print("Running doctests...")
    import doctest

    doctest.testmod()

# Generated at 2022-06-11 22:24:23.293055
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """ Unit test for method __get__ of class cached_property.
    """
    from .test_decorators import TestCase

    class TestClass(TestCase):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """Test docstr"""
            return self.x + 1

        @cached_property
        def z(self, a=1, b=2):
            return self.x + a + b

        @cached_property
        def w(self, test=True):
            """Test"""
            return self.x + 1

    test_obj = TestClass()
    assert test_obj.y == 6
    assert test_obj.__dict__["y"] == 6
    assert test_obj.__dict__["z"] == 8

# Generated at 2022-06-11 22:24:29.656096
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from uuid import uuid4

    class TestClass:
        @cached_property
        def y(self):
            return f"this is {uuid4()}"

    obj1 = TestClass()
    obj2 = TestClass()

    assert obj1.y != obj2.y

    del obj1.y
    del obj2.y

    assert obj1.y != obj2.y



# Generated at 2022-06-11 22:24:34.932890
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class Prop:

        def __init__(self, value: int):
            self.value = value

        @cached_property
        def x(self):
            return self.value

    obj = Prop(5)
    assert obj.x == 5
    assert obj.__dict__ == {'value': 5, 'x': 5}

    obj = Prop(10)
    assert obj.x == 10
    assert obj.__dict__ == {'value': 10, 'x': 10}



# Generated at 2022-06-11 22:24:40.950929
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from random import random
    from time import sleep, time
    from unittest import TestCase

    class A(TestCase):

        def __init__(self, *args, **kwargs):
            self.x = 0.123
            self.x_cached = None

        @cached_property
        def y(self):
            return self.x + 0.456

        @cached_property
        def z(self):
            return random()

    a = A()
    assert a.y == a.x + 0.456
    assert a.z >= 0 and a.z <= 1
    a.x = 0.789
    assert a.x_cached is None

    def _wait_for_prop_to_overwrite_itself(prop, prop_cached):
        now = time()

# Generated at 2022-06-11 22:24:44.560536
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class TestClass:
        class_attr = 1
        instance_attr = 2

        @cached_property
        def a_property(self):
            return self.instance_attr

    assert TestClass.a_property is cached_property
    assert TestClass().a_property == 2



# Generated at 2022-06-11 22:24:52.855613
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test method __get__ of class cached_property.
    """
    # Define a dummy class
    class MyObj:

        @cached_property
        def x(self):
            return 'value'

    # Create an object of MyObj
    obj = MyObj()
    # Test obj.x
    assert obj.x == 'value'
    # Delete the cached value
    del obj.x
    # Test the value again
    assert obj.x == 'value'
