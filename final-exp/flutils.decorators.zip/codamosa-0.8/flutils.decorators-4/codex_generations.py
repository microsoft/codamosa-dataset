

# Generated at 2022-06-11 22:15:07.383037
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """ Tests method __get__ of class cached_property.

    """
    @cached_property
    def foo(obj):
        return 'bar'

    obj = type('obj', (object,), {})()

    result = foo.__get__(obj, obj.__class__)
    assert(result == 'bar')
    assert(obj.foo == 'bar')
    assert(foo.__get__(obj, None) == foo)


# Generated at 2022-06-11 22:15:16.876536
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # noinspection PyPackageRequirements
    import pytest

    obj = MyClass()
    assert obj.y == 6
    obj.y = 7
    assert obj.y == 7
    assert obj.x == 5
    del obj.x
    assert obj.x == 5
    with pytest.raises(AttributeError):
        del obj.y


if __name__ == "__main__":
    test_cached_property___get__()

# Generated at 2022-06-11 22:15:17.475782
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass


# Generated at 2022-06-11 22:15:21.947591
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj = test_cached_property___get__  # type: cached_property
    obj.__dict__['func'] = obj

    def test_1():
        return obj

    def test_2():
        return obj

    obj.func = test_1
    assert obj.__get__(None, None) == obj
    obj.func = test_2
    assert obj.__get__(None, None) == obj



# Generated at 2022-06-11 22:15:32.778446
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from time import sleep
    from functools import wraps

    from unittest import mock

    from flutils import decorators

    def test_wrapper(f):
        """An example of a wrapper that would be used to wrap the
        :obj:`~flutils.decorators.cached_property` decorator.

        """
        @wraps(f)
        def wrapper(*args, **kwargs):
            t = 1
            sleep(t)
            return f(*args, **kwargs)

        return wrapper

    class test_class_cached_property__get__:
        class my_class:
            def __init__(self):
                self.x = 5

            @test_wrapper
            @decorators.cached_property
            def y(self):
                return self.x + 1


# Generated at 2022-06-11 22:15:41.286765
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    def func(obj):
        return "bar"

    decorator = cached_property(func)
    obj = object()
    result = decorator.__get__(obj, None)
    assert not isinstance(result, cached_property)
    assert result == "bar"
    assert obj.__dict__[func.__name__] == "bar"
    result = decorator.__get__(obj, None)
    assert result == "bar"

# Generated at 2022-06-11 22:15:48.632753
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class A:

        @cached_property
        def o(self):
            return 'o'

    class B:
        def __init__(self):
            self.a = A()

        @cached_property
        def o(self):
            return self.a.o

    class C:

        @cached_property
        async def o(self):
            await asyncio.sleep(.1)
            return 'o'

    class D:
        def __init__(self):
            self.c = C()

        @cached_property
        async def o(self):
            return await self.c.o

    def _test(obj):
        for n in range(10):
            assert hasattr(obj, 'o')
            assert obj.__dict__['o'] == 'o'
            assert deleteattr

# Generated at 2022-06-11 22:15:55.854304
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class flutils.cached_property"""

    def test_func():
        """Test function."""
        return 1

    test_value = 1
    obj = cached_property(test_func)
    assert obj.__doc__ == "Test function."
    assert obj.func == test_func
    assert obj.__get__(test_value, None) == test_value
    assert obj.__dict__["func"] == test_func


# Generated at 2022-06-11 22:16:03.789959
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Check that the property is not computed twice

    # Given
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """Return something"""
            self.x += 1
            return self.x

    obj = MyClass()

    # When
    y1 = obj.y
    y2 = obj.y

    # Then
    assert y1 == y2
    assert y2 == 6
    assert y1 == 6
    assert obj.__dict__['y'] == y2



# Generated at 2022-06-11 22:16:13.550836
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import asyncio
    from flutils.decorators import cached_property


    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    class MyClass2:

        def __init__(self):
            self.x = 5

        @cached_property
        async def y(self):
            return self.x + 1

    obj2 = MyClass2()
    loop = asyncio.get_event_loop()
    loop.run_until_complete(asyncio.ensure_future(obj2.y))
    assert obj2.y == 6




# Generated at 2022-06-11 22:16:20.598504
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-11 22:16:26.599838
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """This is the docstring for method y()."""
            return self.x

    obj = MyClass()
    assert obj.y == 5
    assert obj.y == 5
    obj.x = 10
    assert obj.y == 5



# Generated at 2022-06-11 22:16:33.586864
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    from unittest.mock import patch

    from flutils.decorators import cached_property


    class MyClass():

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1


    async def mock_coro(self):
        return "test_string"


    with patch.object(MyClass, "y", new_callable=cached_property):
        test_obj = MyClass()
        assert test_obj.y == 6
        test_obj.y = 2
        assert test_obj.y == 2
        assert "y" in test_obj.__dict__
        del test_obj.y
        assert "y" not in test_obj.__dict__

# Generated at 2022-06-11 22:16:41.543623
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import patch

    c = Object()
    assert not c.__dict__

    # __init__.__get__ of cached_property
    call = patch.object(cached_property, "__init__", return_value=None)
    with call:
        cp = cached_property.__get__(cached_property, None)
        assert cp is cached_property
    assert not c.__dict__

    # _cached_property__get__ of cached_property
    call = patch.object(cached_property, "__init__", return_value=None)
    with call:
        cp = cached_property.__get__(cached_property, c)
        assert cp is cached_property
    assert not c.__dict__

    # _cached_property__get__ when called with an

# Generated at 2022-06-11 22:16:53.973600
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    '''
    Unit test for method __get__ of class cached_property
    '''

    # Python version check
    import sys
    if sys.version_info < (3, 7, 0):
        return

    # Import flutils.decorators submodule
    import flutils.decorators as decorators

    # Create a class with a method decorated with cached_property
    class MyClass:

        '''
        A class with a method decorated with cached_property
        '''

        @decorators.cached_property
        def test_method(self):
            '''
            Method decorated with cached_property
            '''

            print("Test method")
            return "Test"

    # Instantiate MyClass
    obj = MyClass()

    # Call the test_method
    obj.test_method

    # Get the value from

# Generated at 2022-06-11 22:16:55.134446
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass



# Generated at 2022-06-11 22:17:03.154275
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """ Unit test for method __get__ of class cached_property.

    """

    class TestClass:
        def __init__(self):
            pass

        @cached_property
        def x(self):
            y = self.y
            return y

        @cached_property
        def y(self):
            return 5

    # Test for arbitrary __call__
    item = TestClass()
    assert item.x == 5
    assert item.y == 5
    assert 'x' in item.__dict__
    assert 'y' in item.__dict__

    # Test for __call__ when the attribute is already cached
    item.y = 7
    item.__dict__.pop('x')
    assert item.x == 7
    assert item.y == 7
    assert 'x' in item.__dict__

# Generated at 2022-06-11 22:17:07.124180
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property
    """
    class Foo:
        @cached_property
        def bar(self):
            return 'testing'

    obj = Foo()
    assert obj.bar == 'testing'
    assert not hasattr(obj, '__dict__')



# Generated at 2022-06-11 22:17:14.225705
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest

    class MyClass:
        @cached_property
        def method(self):
            return 'value'

    obj = MyClass()

    # Attribute has correct value
    assert obj.method == 'value'

    # Attribute is set in the object's dictionary and MyClass's
    #   dictionary
    assert obj.__dict__['method'] == 'value'
    assert MyClass.__dict__['method'].__isabstractmethod__



# Generated at 2022-06-11 22:17:20.522134
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class A:
        def __init__(self, value):
            self.value = value

        @cached_property
        def x(self):
            return self.value + 1

    a = A(5)
    a.x

    try:
        a.y # pylint: disable=pointless-statement
    except AttributeError:
        pass
    else:
        raise AssertionError("The attribute should not exist.")


# Generated at 2022-06-11 22:17:27.210060
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 1

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y

    assert hasattr(obj, 'y')



# Generated at 2022-06-11 22:17:37.275395
# Unit test for method __get__ of class cached_property

# Generated at 2022-06-11 22:17:45.711105
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property

    This test is run automatically using pytest, but this is how to run it
    manually:

        from flutils.decorators import cached_property
        class MyClass(object):
            @cached_property
            def the_property(self):
                return 'foo'
        my_instance = MyClass()
        print(my_instance.the_property)

    """
    raise NotImplementedError


if __name__ == "__main__":  # pragma: no cover
    test_cached_property___get__()

# Generated at 2022-06-11 22:17:51.703373
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class TestClass(object):

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return 24

    obj = TestClass()
    _ = obj.y
    assert obj.y == 6

    _ = obj.z
    assert obj.z == 24



# Generated at 2022-06-11 22:18:03.801897
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit tests for method `cached_property.__get__`

    Assert `__get__` exists with `MyClass` object.

    Example:

        Code::

            from flutils.decorators import cached_property

            class MyClass:
                def __init__(self):
                    self.x = 5

                @cached_property
                def y(self):
                    self._y = self.x + 1

            >>> obj = MyClass()
            >>> obj.y  # AttributeError: 'MyClass' object has no attribute '_y'

        Usage:

            >>> obj = MyClass()
            >>> obj.y  # 6

    """

    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5


# Generated at 2022-06-11 22:18:10.649629
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """To test method __get__ of class cached_property."""

    class _MyClass:

        def __init__(self):
            self.x = 5
            self.y = None

        @cached_property
        def add(self):
            self.y = self.x + 1
            return self.y

    obj = _MyClass()
    y = obj.add
    assert y == 6
    assert obj.y == 6

# Generated at 2022-06-11 22:18:14.504143
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-11 22:18:18.873424
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Test:

        # noinspection PyMissingConstructor
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Test()
    assert obj.y == 6


# Generated at 2022-06-11 22:18:25.478807
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    @cached_property
    def cached_property_method(obj):
        return 1

    class TestClass:
        pass

    obj = TestClass()

    try:
        assert cached_property_method.__doc__
    except AttributeError:
        pass

    assert cached_property_method.__get__(obj, TestClass)

    assert obj.cached_property_method == 1

    del obj.cached_property_method

    assert cached_property_method.__get__(obj, TestClass)

    assert obj.cached_property_method == 1



# Generated at 2022-06-11 22:18:29.836004
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert (
        obj.y
        == 6
    ), "Value should be 6"


# Generated at 2022-06-11 22:18:45.824118
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest

    from flutils.decorators import cached_property

    class A:

        def __init__(self):
            self.x = 5

    class B:

        def __init__(self):
            self.y = 6

        @cached_property
        def z(self):
            return self.y + 1

    @cached_property
    def func():
        return 'test'

    a = A()
    b = B()

    assert callable(a.x.__get__)
    assert callable(b.y.__get__)
    assert callable(b.z.__get__)
    assert callable(func.__get__)

    assert isinstance(a.x.__get__(a), property)

# Generated at 2022-06-11 22:18:47.994930
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""
    # todo: write test
    pass

# Generated at 2022-06-11 22:18:48.934866
# Unit test for method __get__ of class cached_property

# Generated at 2022-06-11 22:18:53.990395
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from .test_decorators import TestCachedProperty
    from .test_decorators import TestCachedPropertyNoExpando
    cp = TestCachedProperty()
    assert cp._value == 42
    assert cp.value == 42
    cp = TestCachedPropertyNoExpando()
    assert cp._value == 42
    assert cp.value == 42


# Generated at 2022-06-11 22:19:00.178624
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    
    class _MyClass:
        def __init__(self):
            self.x = 5
    
        @cached_property
        def y(self):
            return self.x + 1
    
    obj = _MyClass()
    assert obj.y == 6
    assert obj.__dict__.get('y') == 6
    assert obj.y == 6


# Generated at 2022-06-11 22:19:08.282855
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    from unittest.mock import patch

    from asynctest.mock import CoroutineMock

    from flutils.decorators import cached_property

    class SomeClass:

        def __init__(self, test_str):
            self.test_str = test_str

        @cached_property
        def y(self):
            return self.test_str + '_test'

    @patch('flutils.decorators.cached_property.asyncio', autospec=True)
    def test(mock_asyncio,):
        mock_asyncio.iscoroutinefunction.return_value = False

        obj = SomeClass('test')
        assert obj.__dict__ == {'test_str': 'test'}
        assert obj.y == 'test_test'
        assert obj.__dict

# Generated at 2022-06-11 22:19:12.336661
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-11 22:19:20.238479
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    log = logging.getLogger(__name__)
    log.addHandler(logging.NullHandler())
    log.setLevel(logging.DEBUG)

    class MyClass:
        def __init__(self):
            self._x = 5

        @cached_property
        def y(self):
            """y doc string."""
            return self._x + 1

        @cached_property
        async def t(self):
            return self._x + 1

    obj = MyClass()
 

# Generated at 2022-06-11 22:19:31.132707
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Test(object):
        def __init__(self):
            self.value = 0

        @cached_property
        def a_property(self):
            self.value += 1
            return self.value

    test = Test()
    assert test.value == 0
    assert test.a_property == 1
    assert test.value == 1
    assert hasattr(test, 'a_property')

    test.value = 0
    assert test.a_property == 1
    assert test.value == 1
    assert hasattr(test, 'a_property')

    del test.a_property
    assert not hasattr(test, 'a_property')
    assert test.value == 1
    assert test.a_property == 2
    assert test.value == 2

# Generated at 2022-06-11 22:19:35.804632
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 1

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == obj.y
    assert obj.y == 2
    obj.x += 1
    assert obj.y == 2 # y is cached



# Generated at 2022-06-11 22:20:01.458671
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    @cached_property
    def x(self):
        return 1

    class MyClass:
        def __init__(self):
            self.x = 5

        def y(self):
            return self.x + 1

        @cached_property
        def y_cached(self):
            return self.y()

    obj = MyClass()

    assert obj.x == x.__get__(obj, obj.__class__)

    assert x.__get__(obj, obj.__class__) == 1

    assert obj.y == 6

    assert obj.y_cached == 6

    assert obj.y_cached == obj.y_cached


if __name__ == '__main__':
    test_cached_property___get__()

# Generated at 2022-06-11 22:20:07.642823
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Test __get__ with obj is not None
    obj = MyClass()

    assert obj.y == 6
    assert obj.__dict__['y'] == 6

    # Test __get__ with obj is None
    assert MyClass.y == cached_property.y



# Generated at 2022-06-11 22:20:13.547488
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    obj.x -= 1
    assert obj.y == 6



# Generated at 2022-06-11 22:20:20.566003
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test method __get__ of class cached_property.

    This is a little awkward to test as the decorator does what it's
    supposed to do, i.e. remove itself from the class, and thus we are
    unable to access the method of what it was applied to.  This test
    is to ensure the __get__ is doing what it's supposed to do and
    returning what it's supposed to return."""

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    y = obj.y
    assert y == 6
    # Remove the decorator
    del obj.__class__.y



# Generated at 2022-06-11 22:20:25.976003
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class Obj(object):
        @cached_property
        def prop(self):
            return 42

    obj = Obj()

    # This is how we use a property, right? :-P
    assert obj.prop == 42

    assert cached_property.__get__(obj.prop, Obj)() == 42


# Generated at 2022-06-11 22:20:37.322585
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import ast
    import inspect
    import sys
    import unittest

    import mymodule

    class TestCachedProperty(unittest.TestCase):

        @staticmethod
        def get_body(func_as_str: str) -> str:
            """Return the body of a function from the function as a string.

            Args:

                :param str func_as_str: The function as a string

            Returns:

                :returns: The function body as a string
                :rtype: str

            """
            tree = ast.parse(func_as_str.strip())
            body = ast.get_docstring(tree)
            return body.strip()


# Generated at 2022-06-11 22:20:42.609940
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


# Generated at 2022-06-11 22:20:48.897535
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():  # noqa: D103
    @cached_property
    def test_function(obj):
        return 'value'
    MyClass = type('MyClass', (object,), {'func': test_function})

    obj = MyClass()
    obj.__dict__[test_function.__name__] = 'not value'
    result = obj.func
    assert 'not value' == result

    obj = MyClass()
    result = obj.func
    assert 'value' == result



# Generated at 2022-06-11 22:20:55.187462
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property.
    """
    class A:
        x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = A()
    assert obj.y == 6
    obj.x = 11
    assert obj.y == 6

# Generated at 2022-06-11 22:21:01.755771
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import Mock

    obj = Mock(spec=['__dict__', '__class__'])
    obj.__dict__ = {}
    obj.__class__ = Mock(spec=['__name__', '__name__'])
    obj.__class__.__name__ = 'obj.__class__'

    cp = cached_property(lambda self: self.__class__.__name__)
    assert cp.__get__(obj, None) == 'obj.__class__'
    assert obj.__dict__ == {'__name__': 'obj.__class__'}
    assert isinstance(obj.__dict__['__name__'], str)

# Generated at 2022-06-11 22:21:48.253269
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # noinspection PyMissingOrEmptyDocstring
    class MyClass:
        @cached_property
        def x(self):
            # noinspection PyUnresolvedReferences
            self.x = 2
            return 2

        @cached_property
        def y(self):
            self.y = 3
            return 3

    obj = MyClass()
    assert obj.x == 2
    assert obj.y == 3
    assert obj.__dict__ == {'x': 2, 'y': 3}


# Generated at 2022-06-11 22:21:51.466538
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestClass(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    test = TestClass()

    assert test.y == 6
    assert test.x == 5
    return


# Generated at 2022-06-11 22:22:00.046130
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""
    print('Testing cached_property.__get__')
    import unittest

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class Test(unittest.TestCase):
        def test(self):
            obj = MyClass()
            self.assertEqual(obj.y, 6)

    unittest.main(module='flutils.tests.test_decorators', exit=False)

# Generated at 2022-06-11 22:22:10.853169
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import TestCase
    from unittest.mock import patch, call

    class FakeCache(TestCase):
        def __init__(self, *, test_case: TestCase):
            self.test_case = test_case
            self.args = None
            self.kwargs = None

        def __getitem__(self, item):
            return self.test_case.assertEqual(self.args, item)

        def __setitem__(self, key, value):
            self.args = key
            self.kwargs = value

    class FakeClass:
        def __init__(self, *, test_case: TestCase):
            self.test_case = test_case
            self.__dict__ = FakeCache(test_case=test_case)


# Generated at 2022-06-11 22:22:13.558150
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test cached_property.__get__.
    """
    class MyClass:
        @cached_property
        def x(self):
            return 5

    obj = MyClass()
    assert obj.x == 5

# Generated at 2022-06-11 22:22:23.997914
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""

    class MyClass:
        """Mock class"""

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return [self.x + 1, self.x + 2]

    print(MyClass.__doc__)
    assert MyClass.__doc__ == 'Mock class'
    print(MyClass.__init__.__doc__)
    assert MyClass.__init__.__doc__.startswith('Initialize self.')
    assert MyClass.__init__.__doc__.endswith('Return None.')

# Generated at 2022-06-11 22:22:33.010446
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Obj1:
        @cached_property
        def prop1(self) -> str:
            return "prop1"

    obj1 = Obj1()
    print(vars(obj1))
    print(obj1.prop1)
    print(vars(obj1))

    class Obj2:
        @cached_property
        async def prop2(self) -> str:
            await asyncio.sleep(0.01)
            return "prop2"

    async def test_Obj2():
        obj2 = Obj2()
        print(vars(obj2))
        print(await obj2.prop2)
        print(vars(obj2))

    asyncio.run(test_Obj2())


if __name__ == '__main__':
    print("Running", __file__, end=' ')

# Generated at 2022-06-11 22:22:41.355668
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from io import StringIO
    from unittest.mock import patch

    class VarClass:

        def __init__(self):
            self.x = 1
            self.s = StringIO()

        @cached_property
        def y(self):
            self.s.write("xy")
            return self.x + 1

    vc = VarClass()

    # Evaluate the property attribute
    assert vc.y == 2
    assert vc.s.getvalue() == "xy"
    # Evaluate the property attribute again
    assert vc.y == 2
    assert vc.s.getvalue() == "xy"
    # Delete the attribute
    del vc.y
    # Evaluate the property attribute again
    assert vc.y == 2

# Generated at 2022-06-11 22:22:47.727857
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import MagicMock
    mock_client = MagicMock()
    mock_client.x = 5
    mock_client.__dict__ = {}

    mock_class = MagicMock()

    test_cached_property = cached_property(lambda x: x.x + 1)
    test_cached_property.__get__(mock_client, mock_class)

    assert mock_client.__dict__ == {'y': 6}



# Generated at 2022-06-11 22:22:58.137048
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test flutils.decorators.cached_property.__get__ behavior.

    Covers:

        - :obj:`flutils.decorators.cached_property.__get__`
        - :obj:`flutils.decorators.cached_property._wrap_in_coroutine`

    """

    obj = cached_property(lambda self: self)
    obj_2 = cached_property(lambda self: self)

    class MyClass:

        def __init__(self):
            self.test = 1

        @obj
        def method_test(self):
            return self.test

        @obj_2
        def method_test_2(self):
            return self.test

    test_obj = MyClass()

    # Covers obj.__get__, correct behavior is to return a descriptor
    #

# Generated at 2022-06-11 22:24:30.754818
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    '''

    Unit test for method __get__ of class cached_property

    Args:

    Returns:

    Raises:

    '''
    import time

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            time.sleep(5)
            return self.x + 1

    obj = MyClass()
    print(obj.y)
    print(obj.y)


if __name__ == '__main__':

    import sys
    import os
    import unittest


    def run_test_suite():
        '''

        run_test_suite

        Args:

        Returns:

        Raises:
        '''

# Generated at 2022-06-11 22:24:33.508048
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    o = MyClass(5)
    assert o.y == 6



# Generated at 2022-06-11 22:24:37.566845
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self, x: int = 2):
            self.x = x

        @cached_property
        def y(self):
            return self.x * 2

        @cached_property
        def z(self):
            return self.x * 3

    obj = MyClass(x=4)
    assert obj.y == 8
    assert obj.z == 12



# Generated at 2022-06-11 22:24:42.123310
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import doctest

    results = doctest.testmod(optionflags=doctest.ELLIPSIS)
    assert results.failed == 0

# Generated at 2022-06-11 22:24:48.928717
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from io import StringIO

    class Class:
        pass

    @cached_property
    def foo(obj):
        assert isinstance(obj, Class)
        return 42

    class Class:
        foo = foo

    obj = Class()
    assert obj.foo == 42
    obj.foo = 24
    assert obj.foo == 24

    @cached_property
    def foo(self):
        self.called += 1
        return 42

    class Class:
        def __init__(self):
            self.called = 0
            self.__dict__["foo"] = foo
            # we are sharing this between instance, this let us check that
            # we are actually calling the descriptor and not the value
            # stored in __dict__.

    obj = Class()

    assert obj.called == 0
    assert obj.foo == 42


# Generated at 2022-06-11 22:24:55.820339
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestClass:
        @cached_property
        def test_cached_method(self):
            return 'hello world'

    test = TestClass()
    assert test.test_cached_method == 'hello world'
    assert test.__dict__['test_cached_method'] == 'hello world'
    del test.test_cached_method
    test.test_cached_method
    assert test.__dict__['test_cached_method'] == 'hello world'

# Generated at 2022-06-11 22:25:05.205202
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.misc import Caller
    from flutils.decorators import cached_property

    class Yodawg(Caller):
        def __init__(self):
            super().__init__()
            self.x = "I heard you like tests so I put a test in your test so" \
                     "you can test while you test."

        @cached_property
        def nope(self):
            return self.x.upper()

        @property
        def nada(self):
            return self.x.upper()

        @cached_property
        def yep(self):
            return self.x.upper()

    y1 = Yodawg()
    assert y1.nope == y1.nope
    assert y1.yep == y1.yep
    assert y1.nada != y