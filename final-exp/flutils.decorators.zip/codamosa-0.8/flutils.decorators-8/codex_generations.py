

# Generated at 2022-06-11 22:15:02.713770
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for :meth:`~flutils.decorators.cached_property.__get__`"""

    # noinspection PyPep8Naming
    class C:
        @cached_property
        def x(self):
            return 5

    c = C()
    # noinspection PyProtectedMember
    assert c._C__x == 5
    # noinspection PyProtectedMember
    assert c.__dict__['x'] == 5
    c.y = c.x + 4
    assert c.__dict__['y'] == 9



# Generated at 2022-06-11 22:15:08.211626
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class Test:

        def __init__(self):
            self.x = 0

        @cached_property
        def c(self):
            self.x += 1
            return self.x

    o = Test()
    assert o.c == 1
    assert o.c == 1
    assert o.x == 1



# Generated at 2022-06-11 22:15:18.548041
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""
    class A:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = A()
    assert obj.y == 6  # noqa: E721
    assert obj.y == 6  # noqa: E721
    assert obj.y == 6  # noqa: E721

    obj.x = 7
    del obj.y
    assert obj.y == 8  # noqa: E721
    assert obj.y == 8  # noqa: E721
    assert obj.y == 8  # noqa: E721
    del obj.y

# Generated at 2022-06-11 22:15:23.729033
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from asyncio import Future

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-11 22:15:28.508986
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert(obj.y == 6)


# Generated at 2022-06-11 22:15:37.735911
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest
    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6

    with pytest.raises(AttributeError):
        obj.__dict__['y']



# Generated at 2022-06-11 22:15:46.660050
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class A:
        def __init__(self, x):
            self.x = x

        @functools.cached_property
        def doublex(self):
            return 2*self.x

    a = A(1)
    a.doublex == 2
    a.doublex == 2
    assert a.__dict__ == {'x': 1, 'doublex': 2}, a.__dict__
    a.x = 2
    a.doublex == 4
    a.doublex == 4
    assert a.__dict__ == {'x': 2, 'doublex': 4}, a.__dict__
    del a.doublex
    a.doublex == 8
    a.x = 3
    a.doublex == 6
    a.doublex == 6
    a.x = 4
    a.doublex

# Generated at 2022-06-11 22:15:57.634709
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Tests for method __get__ of the cached_property class.
    """

    print("\n***** cached_property.__get__ *****")

    print("\n------- cached_property.__get__: TEST 1 -------")
    class MyClass:

        def __init__(self):
            self.x = 7

        @cached_property
        def y(self):
            return self.x + 3

    obj = MyClass()
    print("obj.__class__:", obj.__class__)
    print("obj.y:", obj.y)
    print("obj.y:", obj.y)

    print("\n------- cached_property.__get__: TEST 2 -------")

    async def _async_func(obj):
        await asyncio.sleep(1)
        return obj.x + 3

# Generated at 2022-06-11 22:15:58.377903
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass

# Generated at 2022-06-11 22:16:10.297887
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import mock

    def func(the_self):
        return 'the result'

    cp = cached_property(func)
    obj = mock.MagicMock()
    obj.__dict__ = {}

    # None obj
    assert cp.__get__(None, None) is cp

    # obj with dict
    assert cp.__get__(obj, None).__doc__ == 'the result'
    assert obj.__dict__ == {'func': 'the result'}

    # cp function is coroutine function
    cp.func = mock.MagicMock(name='func', spec=asyncio.coroutines)
    cp.func.return_value = 'the result'
    cp._wrap_in_coroutine = mock.MagicMock(name='func', spec=asyncio.coroutines)
   

# Generated at 2022-06-11 22:16:21.346259
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """This function tests the method :py:meth:`~cached_property.__get__` of
    class :obj:`~flutils.decorators.cached_property` and involves one
    documented behavior:

    - :obj:`~cached_property.__get__` returns the the wrapped method if called
      on the class.

    """

    class MyClass:
        def __init__(self):
            self.foo = 123

        @cached_property
        def bar(self):
            return self.foo

    assert MyClass.bar == cached_property.func



# Generated at 2022-06-11 22:16:27.596432
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    '''
    Unit test for method __get__ of class cached_property
    '''

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

if __name__ == "__main__":

    test_cached_property___get__()

# Generated at 2022-06-11 22:16:28.443926
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass



# Generated at 2022-06-11 22:16:34.198537
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property
    """
    from unittest import TestCase, mock
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5
            self.__dict__['y'] = lambda self: None

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    with mock.patch.object(MyClass, '__dict__', new={'y': 'test'}):
        y = obj.y
        assert y == 'test'

    with mock.patch.object(MyClass, '__dict__', new={}):
        y = obj.y
        assert y == 6

# Generated at 2022-06-11 22:16:41.118072
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class A:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    a = A()
    assert a.y == 6
    assert a.__dict__ == {'x': 5, 'y': 6}

    a.x = 10
    with pytest.raises(RuntimeError):
        z = a.y

    assert a.__dict__ == {'x': 10, 'y': 6}


if __name__ == "__main__":
    # Unit tests executed when file is run as a script
    test_cached_property___get__()

# Generated at 2022-06-11 22:16:53.503858
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import asyncio
    from flutils.asynctools import is_coroutine

    def noop_func():
        pass

    def co_func():
        yield from []

    def co_func_with_exception():
        raise ValueError("ValueError")

    cp = cached_property(noop_func)
    assert cp.__get__(None, None) is cp
    assert cp.__get__('self') == cp
    del cp

    cp = cached_property(co_func)
    result = cp.__get__('self')
    assert is_coroutine(result)
    with trap_exceptions(ValueError):
        result = cp.__get__('self')
    assert isinstance(result, asyncio.Future)
    assert result.done()


# Generated at 2022-06-11 22:16:54.578466
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass  # For now, nothing here.

# Generated at 2022-06-11 22:17:01.228644
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import unittest

    class MyClass(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class TestCachedProperty(unittest.TestCase):
        def test_cached_propery(self):
            obj = MyClass()
            expected = 6
            self.assertIsInstance(obj.y, int)
            self.assertEqual(obj.y, expected)
            self.assertEqual(obj.y, expected)

    unittest.main()

# Generated at 2022-06-11 22:17:06.521786
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import unittest
    import types

    class cached_propertyTest(unittest.TestCase):

        def test_cached_property___get__(self):
            # Callable
            def my_func(self):
                pass

            obj = cached_property(my_func)
            returned_val = obj.__get__('foo', types.MethodType(my_func, 'foo'))
            expected_val = my_func
            self.assertEqual(returned_val, expected_val)

            # Property
            from datetime import timedelta

            class my_class:

                @property
                def foo(self):
                    return timedelta(days=1)

            obj = my_class()
            returned_val = obj.foo
            expected_val = timedelta(days=1)

# Generated at 2022-06-11 22:17:11.661718
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # noinspection PyUnusedLocal
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


# Generated at 2022-06-11 22:17:24.724399
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit tests for cached_property.__get__
    """
    class _BaseTest:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class _TestGet(unittest.TestCase):

        def test_returns_cached_property(self):
            # Arrange
            expected = _BaseTest().y

            # Act
            result = _BaseTest().y

            # Assert
            self.assertEqual(expected, result)

    @asyncio.coroutine
    def _coroutine():
        return 10


# Generated at 2022-06-11 22:17:25.175858
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass

# Generated at 2022-06-11 22:17:31.722608
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x + 5

    obj = MyClass()
    assert obj.y == 6
    assert obj.z == 10



# Generated at 2022-06-11 22:17:39.895946
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # noinspection PyUnusedLocal,PyShadowingBuiltins
    class MyClassOne:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # noinspection PyUnusedLocal,PyShadowingBuiltins
    class MyClassTwo:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            # noinspection PyProtectedMember
            return self._y

        @y.setter
        def y(self, y):
            # noinspection PyProtectedMember
            self._y = y

    obj = MyClassOne()
    assert obj.y == 6
    assert 'y' not in obj.__dict__

    obj = MyClassTwo()

# Generated at 2022-06-11 22:17:42.039541
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    with pytest.raises(TypeError):
        obj = cached_property(lambda self: self)
        obj(object())

# Generated at 2022-06-11 22:17:50.468640
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    from pathlib import Path

    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        async def z(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    obj.asyncio = asyncio
    obj.z
    obj.y
    obj.z

    assert obj.y == 6
    assert obj.z == future_wrapper(MyClass().z)

    del obj.y
    del obj.z
    assert not hasattr(obj, "y")
    assert not hasattr(obj, "z")

    obj2 = MyClass()


# Generated at 2022-06-11 22:17:54.919488
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Foo:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Foo()
    assert obj.y == 6

# Generated at 2022-06-11 22:18:05.578068
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import unittest

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class Test(unittest.TestCase):
        def test_call(self):
            obj = MyClass()
            self.assertEqual(obj.y, 6)

        def test_descriptor(self):
            obj = MyClass()
            self.assertEqual(obj.__dict__["y"], 6)

        def test_cache(self):
            obj = MyClass()
            self.assertEqual(obj.y, obj.y)
            obj.x = 6
            self.assertEqual(obj.y, 6)

        def test_del(self):
            obj = MyClass()

# Generated at 2022-06-11 22:18:16.349221
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import TestCase, mock
    from unittest.mock import call

    test_ = TestCase()

    class DummyClass:
        def __init__(self):
            self.mock = mock.Mock(return_value=5)

        @cached_property
        def mock_property(self):
            return self.mock()

    dummy_class = DummyClass()

    # Test exception raised
    # noinspection PyUnusedLocal
    def raise_exception_func(self):
        raise Exception

    with test_.assertRaisesRegex(AttributeError, "object has no attribute 'raise_exception_func'"):
        # noinspection PyUnusedLocal
        class DummyClass2:
            def __init__(self):
                self.raise_exception_func = mock.Mock

# Generated at 2022-06-11 22:18:20.839908
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-11 22:18:35.561993
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Coroutine function test
    class Foo:
        def __init__(self):
            self.x = 1

        @flutils.decorators.cached_property
        async def bar(self):
            return self.x + 1

    # Normal cached_property test
    class Foo:
        def __init__(self):
            self.x = 1

        @flutils.decorators.cached_property
        def bar(self):
            return self.x + 1

    foo = Foo()
    foo.bar()
    assert foo.bar == 2

# Generated at 2022-06-11 22:18:45.696691
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""

    # Test method __get__ of class cached_property with
    # function that returns 1
    class MyClass1:
        def __init__(self):
            pass
        @cached_property
        def x(self):
            return 1

    obj = MyClass1()
    obj.x
    assert obj.__dict__['x'] == 1

    # Test method __get__ of class cached_property with
    # function in a coroutine
    class MyClass2:
        def __init__(self):
            pass
        @cached_property
        async def x(self):
            return 1

    loop = asyncio.get_event_loop()
    loop.run_until_complete(obj.x)
    assert obj.__dict__['x'] == 1

# Generated at 2022-06-11 22:18:47.525986
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():  # noqa: D202
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-11 22:18:53.212470
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Unit test for __get___ for cached_property when obj is passed None

    class testObj(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    test_obj = testObj()
    assert test_obj.y == 6
    assert test_obj.__dict__['y'] == 6


# Generated at 2022-06-11 22:19:04.595893
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property
    """

    from math import pi
    from random import random

    from flutils.decorators import cached_property

    is_python_38 = sys.version_info[:2] >= (3, 8)

    # Define a dummy class to test method cached_property.__get__
    class MyClass:

        def __init__(self):
            self.x = pi

        @cached_property
        def y(self):
            return random()

        @cached_property
        def z(self):
            return [random(), random()]

        @cached_property
        def a(self):
            return {random()}

        @cached_property
        def b(self):
            return {random(): random()}


# Generated at 2022-06-11 22:19:07.250895
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class SomeClass:
        @cached_property
        def y(self):
            return

    assert SomeClass().y is None

# Generated at 2022-06-11 22:19:11.059067
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Test:
        def __init__(self):
            self.y = None

        @cached_property
        def x(self):
            return self.y + 1

    obj = Test()
    obj.y = 5

    assert obj.x == 6

# Generated at 2022-06-11 22:19:17.176089
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__["y"] == 6
    assert obj.y == 6
    assert obj.__dict__["y"] == 6


# Generated at 2022-06-11 22:19:28.441475
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import MagicMock

    class SomeClass:
        @cached_property
        def dummy(self):
            return 5

    obj = SomeClass()
    obj.__dict__ = {'dummy': None}
    # noinspection PyTypeChecker
    assert not cached_property.__get__(SomeClass.dummy, obj, SomeClass)
    assert SomeClass.dummy.__get__(None)

    obj.__dict__ = {}
    assert cached_property.__get__(SomeClass.dummy, obj, SomeClass) == 5

    obj.__dict__ = {'dummy': MagicMock()}
    # noinspection PyTypeChecker
    assert cached_property.__get__(SomeClass.dummy, obj, SomeClass)



# Generated at 2022-06-11 22:19:39.701074
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for cached_property __get__ method."""

    class Mock:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Mock()
    assert obj.y == 6
    obj = Mock()
    assert obj.y == 6
    assert len(obj.__dict__) == 2

    del obj.y
    assert len(obj.__dict__) == 1
    obj.y == 6
    assert len(obj.__dict__) == 2
    assert obj.y == 6
    obj = Mock()
    assert obj.y == 6
    getattr(obj, 'y')
    assert obj.y == 6



# Generated at 2022-06-11 22:20:05.674871
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method ``__get__`` of class ``cached_property``."""

    import pytest
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    result = obj.y
    assert result == 6
    assert obj.__dict__ == {'x': 5, 'y': 6}



# Generated at 2022-06-11 22:20:12.987033
# Unit test for method __get__ of class cached_property
def test_cached_property___get__(): # noqa: D001
    class TestClass:
        def __init__(self, value=5):
            self.value = value

        @cached_property
        def getvalue(self):
            return self.value

    testclass = TestClass()
    assert testclass.getvalue == testclass.value
    testclass.value = 10
    assert testclass.getvalue != testclass.value



# Generated at 2022-06-11 22:20:20.316483
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest

    class MyClass:
        def __init__(self, x: int = 5):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    def test_func():
        obj = MyClass()
        assert obj.y == 6

    def test_async_func():
        obj = MyClass()
        @asyncio.coroutine
        def async_func(value: int = None):
            return value or self.x + 1
        obj.y = async_func()
        assert obj.y == 6
        obj.y = async_func(value=1)
        assert obj.y == 2

    test_func()
    test_async_func()

# Generated at 2022-06-11 22:20:29.853059
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import mock
    from flutils.decorators import cached_property
    from asyncio import coroutine

    @cached_property
    @mock.patch.object(cached_property, '_wrap_in_coroutine', autospec=True)
    def _test(obj: Any,
              mock_wrap: mock.Mock,
              cls=mock.MagicMock,
              func: Any=mock.MagicMock,
              ) -> mock.Mock:
        value = obj.__dict__[func.__name__] = func(obj)
        return value

    obj = mock.Mock()
    func = mock.Mock()


# Generated at 2022-06-11 22:20:35.250045
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.y == 6



# Generated at 2022-06-11 22:20:45.260987
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import flutils

    assert flutils.__version__ == '0.3.13'
    assert flutils.decorators.cached_property.__doc__.startswith('A property decorator')

    from flutils.decorators import cached_property


    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1


    myclass_obj = MyClass()
    assert myclass_obj.y == 6

    myclass_obj.x = 6
    assert myclass_obj.y == 6



# Generated at 2022-06-11 22:20:49.060050
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y

    assert obj.y == 6

# Generated at 2022-06-11 22:20:49.889871
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass

# Generated at 2022-06-11 22:21:00.602824
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Setup
    class TestProps:
        def __init__(self):
            self.x = 10
            self.y = 5

        @cached_property
        def z(self):
            return self.x + self.y

    # Test
    obj = TestProps()
    # Verify that the property is cached
    assert getattr(obj, '__dict__', {}).get('z') is None
    assert obj.z == 15
    assert getattr(obj, '__dict__', {}).get('z') == 15

    # Test
    del obj.__dict__['z']
    assert getattr(obj, '__dict__', {}).get('z') is None
    assert obj.z == 15
    assert getattr(obj, '__dict__', {}).get('z') == 15

# Generated at 2022-06-11 22:21:05.154809
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-11 22:21:49.775501
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from .test_decorators import MyClass1, MyClass2, MyClass3

    obj1 = MyClass1()
    obj2 = MyClass2()
    obj3 = MyClass3()

    assert obj1.y == 6
    assert obj1.y == 6

    assert obj2.y == 7
    assert obj2.y == 7

    assert obj3.y == 8
    assert obj3.y == 8

# Generated at 2022-06-11 22:22:01.115026
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property

    Args:
        None

    Returns:
        None

    """
    # This is a really simple unit test because the logic of the method is
    # pretty simple.  As such we'll just test some odd variations here:

    class Foo:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    # Let's create a Foo object and give it a value of 5:
    foo = Foo(5)
    # Next we'll get the value of foo.y, which will be 5 + 1:
    y = foo.y
    # y should have a value of 6:
    assert y == 6
    # Now we'll delete the value of y, which will be

# Generated at 2022-06-11 22:22:08.296929
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Foo:
        @cached_property
        def bar(self):
            return 5

    foo = Foo()
    assert foo.bar == 5

    # Test value is stored in `obj.__dict__`
    assert 'bar' in foo.__dict__
    assert foo.__dict__['bar'] == 5

    # Test value is stored in `obj.__dict__`
    foo.__dict__.pop('bar', None)
    assert foo.bar == 5



# Generated at 2022-06-11 22:22:19.848457
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test cached_property.__get__"""

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """This is the property y."""
            return self.x + 1

    class AsyncClass:

        def __init__(self):
            self.x = 5

        @cached_property
        async def y(self):
            """This is the property y."""
            return await asyncio.sleep(0.1, result=self.x + 1)

    obj = MyClass()
    assert obj.y == obj.y
    assert obj.y == 6
    del obj.y
    assert obj.y == 6

    async_obj = AsyncClass()

# Generated at 2022-06-11 22:22:30.575513
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class A:
        def __init__(self):
            self._value = None

        @cached_property
        def f1(self):
            return self._value + 1

        @cached_property
        def f2(self):
            return self._value + 2

        @cached_property
        def f3(self):
            return self._value + 3

    class B(A):
        @cached_property
        def f4(self):
            return self._value + 4

        @cached_property
        def f5(self):
            return self._value + 5

    class C(B):
        @cached_property
        def f6(self):
            return self._value + 6

    a = A()
    assert a.f1 == a.f1
    assert a.f1 is a

# Generated at 2022-06-11 22:22:34.141022
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestClass:
        def __init__(self):
            self.x = 5

        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.y == 6


# Generated at 2022-06-11 22:22:38.571100
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test: class cached_property method __get__
    Given:
        A class with a cached property method
        An instance of the class
        A valid input
    Expected:
        The correct result is returned
    """
    from demo_class import DemoClass

    obj = DemoClass(5)
    assert obj.y_prop == 7



# Generated at 2022-06-11 22:22:43.052110
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-11 22:22:53.158002
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from datetime import datetime

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x + 1

    obj = MyClass()
    start = datetime.now()
    for i in range(0, 100000000):
        obj.y
    end = datetime.now()
    print(end - start)

    start = datetime.now()
    for i in range(0, 100000000):
        obj.z
    end = datetime.now()
    print(end - start)


if __name__ == "__main__":
    test_cached_property___get__()

# Generated at 2022-06-11 22:23:00.629953
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""

    class MyClass:
        def __init__(self, x: int):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass(5)
    assert obj.y == 6



# Generated at 2022-06-11 22:24:27.988326
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self, x: int):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass(5)
    assert obj.y == 6



# Generated at 2022-06-11 22:24:32.248788
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Tests method __get__ of class cached_property."""
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-11 22:24:38.956634
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from pytest import raises
    from unittest.mock import Mock

    def test_func(x):
        ...

    cached_property1 = cached_property(test_func)

    with raises(AttributeError):
        cached_property1.y

    test_obj = Mock(spec=['x', 'y'])
    test_obj.__dict__['x'] = 5
    cached_property1.func = lambda obj: obj.x + 1
    assert cached_property1.__get__(test_obj, None) == 6

    cached_property1.func = Mock(return_value=5)
    cached_property1.__get__(test_obj, None)
    assert test_obj.__dict__['y'] == 5

    cached_property1.func = lambda obj: obj.y + 1
    assert cached_

# Generated at 2022-06-11 22:24:41.602957
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """ Unit test for method __get__ of class :class:cached_property
    """

    import pytest

    @cached_property
    def get_property(self):
        """
        """
        return 1

    class GetProperty:

        get_property = cached_property(get_property)

    req = GetProperty()
    assert req.get_property == 1



# Generated at 2022-06-11 22:24:44.754284
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    @cached_property
    def my_property(self):
        return self.x + 1

    class MyClass:

        def __init__(self):
            self.x = 5

    obj = MyClass()
    assert obj.my_property == 6



# Generated at 2022-06-11 22:24:51.489402
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test case for the ``__get__`` method of class ``cached_property``.

    Do not use this method to write unit tests for the
    ``cached_property`` decorator.  Python's ``property`` decorator
    is not unit testable.

    """
    # Notes: This function is not tested since it is not unit testable.
    pass



# Generated at 2022-06-11 22:24:55.718669
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import asyncio

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6
    assert obj.__dict__ == {'x': 5, 'y': 6}

