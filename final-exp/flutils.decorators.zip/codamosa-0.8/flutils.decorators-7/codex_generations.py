

# Generated at 2022-06-11 22:15:12.351394
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test method `cached_property.__get__`

    """
    class _CachedProp:

        def _func(self):
            return True

        cached_prop = cached_property(_func)

    # Test with an object of type _CachedProp
    test_obj = _CachedProp()
    result = test_obj.cached_prop
    assert result

    # Test with None
    result = test_obj.cached_prop.__get__(None, _CachedProp)
    assert result

    # Test with a different object of type _CachedProp
    test_obj2 = _CachedProp()
    assert test_obj2.cached_prop == test_obj.cached_prop

    # Test whether the docstring is correct
    assert test_obj.cached_prop.__doc__ == test_obj

# Generated at 2022-06-11 22:15:19.556788
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    assert obj.__dict__['y'] == 6
    obj.x = 6
    assert obj.__dict__['y'] == 7
    del obj.y
    assert not hasattr(obj, 'y')
    obj.y
    assert obj.__dict__['y'] == 8



# Generated at 2022-06-11 22:15:24.384879
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    #
    def func(obj):
        return obj.x

    deco = cached_property(func)

    class Class:
        pass

    obj = Class()
    obj._x = 5
    assert deco.__get__(obj, Class) == 5



# Generated at 2022-06-11 22:15:34.467051
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of cached_property.

    The method __get__ of cached_property is tested.  This is done using
    ``pytest``.

    The test is performed first with a synchronous function and then with
    an asynchronous function.  The ``pytest.mark.asyncio`` decorator is
    used to perform the asynchronous test.

    """

    class SomeObject:
        """
        A class for testing of cached_property.

        This class consists of a single attribute, ``x``,
        and two properties, ``y_sync`` and ``y_async``.

        The ``y_sync`` property is a cached_property property
        and uses a synchronous function.

        The ``y_async`` property is a cached_property property and uses
        an asynchronous function.

        """


# Generated at 2022-06-11 22:15:39.435191
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    def foo():
        ...
    obj = cached_property(foo)
    assert obj.func == foo
    assert obj.__get__(cached_property, foo) is obj
    assert obj.__get__(foo, cached_property) is not obj

# Generated at 2022-06-11 22:15:44.097473
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import asyncio

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    # Reset
    del obj.y
    assert not hasattr(obj, 'y')



# Generated at 2022-06-11 22:15:47.106152
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6

# Generated at 2022-06-11 22:15:57.989427
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property
    from types import SimpleNamespace

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6
    assert isinstance(obj.y, int)

    obj.x = 7

    assert obj.y == 6
    assert isinstance(obj.y, int)

    del obj.y

    assert obj.y == 8
    assert isinstance(obj.y, int)

    # Test a class with no init method
    class ClassWithNoInit():
        @cached_property
        def y(self):
            return self.x + 1

    c = ClassWithNoInit()
    c.x = 5


# Generated at 2022-06-11 22:16:01.574497
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """

    """
    @cached_property
    def func(self):
        return self.x + 1


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 22:16:08.116641
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    # Cleanup
    del obj
    del MyClass
    del cached_property



# Generated at 2022-06-11 22:16:10.851921
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    return None


# Generated at 2022-06-11 22:16:15.679813
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Create class
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-11 22:16:21.502638
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    value = obj.y
    assert value == 6
    assert obj.__dict__[obj.y.__name__] == value



# Generated at 2022-06-11 22:16:29.238857
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import TestCase

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6
    assert obj.y == 6

    obj.x = 10

    assert obj.y == 11
    assert obj.y == 11

    obj.__dict__.pop('y', None)

    assert obj.y == 11
    assert obj.y == 11

#Unit test for method _wrap_in_coroutine of class cached_property

# Generated at 2022-06-11 22:16:33.767225
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """Return the value of x + 1."""
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    obj.x = 100
    assert obj.y == 101



# Generated at 2022-06-11 22:16:37.591002
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


# Generated at 2022-06-11 22:16:40.682262
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MockClass:
        def __init__(self):
            self.x = 5
        @cached_property
        def y(self):
            return self.x + 1
    obj = MockClass()
    assert obj.y == 6


# Generated at 2022-06-11 22:16:44.314837
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert MyClass().y == 6



# Generated at 2022-06-11 22:16:56.683770
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""

    # Create a class with a statically defined property
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Instantiate the class
    obj1 = MyClass()
    obj2 = MyClass()

    # Verify that the property value is correct
    assert obj1.y == 6

    # Verify that the property value is now stored in __dict__
    assert 'y' in obj1.__dict__

    # Verify that the property value is consistent across instances
    assert obj2.y == 6

    # Delete the property
    del obj1.y
    assert 'y' not in obj1.__dict__

    # Verify that the property will be recal

# Generated at 2022-06-11 22:17:03.800139
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__ == {'x': 5, 'y': 6}


# Generated at 2022-06-11 22:17:10.731900
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    obj.y
    assert obj.__dict__['y'] == 6


# Generated at 2022-06-11 22:17:20.232019
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import json
    from unittest.mock import Mock, call

    # test for docstring
    instance = cached_property(Mock())
    assert instance.__doc__ is None

    # test for function
    func = Mock()
    instance = cached_property(func)
    assert instance.func is func

    # test for proper __get__
    func = Mock(return_value=None, __name__='func')
    instance = cached_property(func)
    obj = Mock()
    assert instance.__get__(obj, None) == None
    assert obj.__dict__ == {'func': None}
    func.assert_called_once_with(obj)

    # test for proper __get__ for asyncio func
    async def do_nothing():
        pass


# Generated at 2022-06-11 22:17:28.194518
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import time

    # Create the caching object
    class MyClass:

        def __init__(self):
            self.x = 1

        @cached_property
        def y(self):
            time.sleep(1)
            return self.x + 1

    # Time how long it takes to access the cached property
    start = time.time()
    obj = MyClass()
    obj.y
    end = time.time()
    assert end - start >= 1

    # Verify the cached property is not re-computed
    start = time.time()
    obj.y
    end = time.time()
    assert end - start < 1

    # Verify the cache of the property is not re-computed
    # if we delete the property
    start = time.time()
    del obj.y
    obj.y

# Generated at 2022-06-11 22:17:32.621935
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Foo:
        @cached_property
        def bar(self):
            return self.x + 1

    f = Foo()
    f.x = 5
    f.bar
    assert f.__dict__['bar'] == 6


if __name__ == "__main__":
    import pytest as pt

    pt.main(args=[__file__])

# Generated at 2022-06-11 22:17:37.662908
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test method __get__ of class cached_property"""
    import pytest
    from .cached_property import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Test cached_property.__get__() function
    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-11 22:17:43.098434
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass():

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-11 22:17:47.741899
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    import pytest
    from flutils.decorators import cached_property


    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1


    obj = MyClass()
    assert obj.y == 6

    with pytest.raises(AttributeError):
        obj.y = 100

# Generated at 2022-06-11 22:17:52.408418
# Unit test for method __get__ of class cached_property

# Generated at 2022-06-11 22:17:59.024891
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """

    :return: None
    """

    class MyClass:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass(1)
    assert obj.y == 2
    assert obj.__dict__['y'] == 2



# Generated at 2022-06-11 22:18:03.527525
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class A:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = A()
    assert obj.y == 6
    obj.x = 8
    assert obj.y == 9

# Generated at 2022-06-11 22:18:10.099470
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert getattr(obj, 'y', None) == 6



# Generated at 2022-06-11 22:18:14.984199
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class X:
        @cached_property
        def f(self):
            return 5

    x = X()
    assert x.f == 5
    # Overwrite the value of attribute f
    x.f = 6
    assert x.f == 6
    # Delete the attribute f to reset the property x.f
    del x.f
    assert x.f == 5



# Generated at 2022-06-11 22:18:24.471123
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit tests for method __get__ of class cached_property."""
    def f(x):
        return x

    class A:
        def __init__(self, x):
            self.x = x
            self.called = False

        @cached_property
        def prop(self):
            self.called = True
            return self.x

    a = A(5)
    assert not a.called
    assert a.prop == 5
    assert a.called

    a.called = False
    assert not a.called
    assert a.prop == 5
    assert not a.called

    a = A(6)
    assert not a.called
    assert a.prop == 6
    assert a.called



# Generated at 2022-06-11 22:18:34.973839
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit tests for the class cached_property."""
    from unittest import TestCase
    import asyncio
    from unittest.mock import Mock

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class Test(TestCase):

        def setUp(self):
            self.obj = MyClass()

        def test_cached_property___get__(self):
            result = MyClass.y.__get__(self.obj, self.obj.__class__)
            self.assertEqual(result, 6)

        def test_cached_property___get__with_class(self):
            result = MyClass.y.__get__(None, self.obj.__class__)

# Generated at 2022-06-11 22:18:45.641825
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import mock
    from types import ClassType

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    my_class_dict = MyClass.__dict__

    # Test 1: No obj
    obj = None
    cls = ClassType
    attr = 'y'
    assert my_class_dict[attr] == cached_property.__get__(obj, cls)
    with mock.patch('flutils.decorators.cached_property.__get__') as mck:
        cached_property.__get__(obj, cls)
        assert mck.mock_calls == [mock.call(obj, cls)]

    # Test 2: With obj


# Generated at 2022-06-11 22:18:50.236549
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-11 22:19:00.465154
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from collections import deque

    class _MyClass:
        def __init__(self):
            self.methods_called = deque(maxlen=2)

        @cached_property
        def y(self):
            self.methods_called.append('y')
            return self.x + 1

    myclass = _MyClass()
    myclass.x = 5
    assert myclass.y == 6
    assert myclass.methods_called == deque(['y'])
    assert myclass.y == 6
    assert myclass.methods_called == deque(['y'])



# Generated at 2022-06-11 22:19:08.445156
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    :return: ``None``
    """
    value = 'value'
    obj = type('obj', (), {})()

    class test1(object):
        @cached_property
        def prop(self):
            return value

    assert value == test1().prop
    assert value == test1().prop

    class test2(object):
        @cached_property
        def prop(self):
            return self.value

        def __init__(self, value):
            self.value = value

    assert value == test2(value).prop
    assert value == test2(value).prop
    assert value != test2('').prop

    class test3(object):
        @cached_property
        def prop(self):
            return self

    assert test3() is test3().prop

# Generated at 2022-06-11 22:19:12.970498
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-11 22:19:24.587556
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import asyncio
    from functools import partial

    from .base import CoroutineLocal

    class MockClass:

        def __init__(self):
            self.x = 5
            self.call_count = 0

        def call(self):
            self.call_count += 1

        @cached_property
        def y(self):
            self.call()
            return self.x + 1

    class MockClass2:

        def __init__(self):
            self.x = 5
            self.call_count = 0

        def call(self):
            self.call_count += 1

        @cached_property
        async def y(self):
            self.call()
            return self.x + 1


# Generated at 2022-06-11 22:19:34.376866
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import sys
    import pytest
    import types
    from flutils.decorators import cached_property

    # Testing with a class

    class MyClass:

        def __init__(self, initval=None, name=None):
            self.val = initval
            self.name = name

        @cached_property
        def prop(self):
            return self.val

        @cached_property
        def x(self):
            return self.val

        @cached_property
        def xx(self):
            return self.val

        @cached_property
        def xxx(self):
            return self.val

        @cached_property
        def func(self):
            def _func():
                return self.val
            return _func


# Generated at 2022-06-11 22:19:42.310529
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    def test_method():
        return id(obj)

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.z = test_method
    id1 = obj.z()
    id2 = obj.z()
    assert id1 == id2

    id1 = obj.y
    id2 = obj.y
    assert id1 == id2



# Generated at 2022-06-11 22:19:51.303156
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import mock

    # Test if __get__ returns the function when obj is None
    def dummy_func(obj):
        return 42

    cp = cached_property(dummy_func)
    assert cp.func == dummy_func
    assert cp.__get__(None, None) == dummy_func

    cm = mock.Mock(spec=["x"])
    cm.x = 5
    cp = cached_property(dummy_func)
    assert cp.__get__(cm, None) == 42



# Generated at 2022-06-11 22:20:01.230423
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test the cached_property method __get__.
    """

    from os import path

    from flutils.decorators import cached_property

    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.y == 6
    assert obj.y == 6

    del obj.y
    assert obj.y == 6

    class TestClass:
        def __init__(self, obj_data):
            self.obj_data = obj_data

        @cached_property
        def dir_path(self):
            return path.dirname(self.obj_data)


# Generated at 2022-06-11 22:20:05.725124
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class myclass:

        def __init__(self):
            self.x = 10

        @cached_property
        def y(self):
            return self.x + 1

    obj = myclass()
    assert obj.y == 11


# Unit tests for method _get of class cached_property

# Generated at 2022-06-11 22:20:15.225435
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    def _call_fut(cls):
        return cls.__get__(cls, cls)

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert _call_fut(obj.y) == 6
    assert _call_fut(obj.y) == 6

    obj.x = 7
    assert _call_fut(obj.y) == 8



# Generated at 2022-06-11 22:20:16.539515
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass

# Generated at 2022-06-11 22:20:23.357512
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test method __get__ of class cached_property by running code contained
    in the docstring of cached_property.

    """
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-11 22:20:30.835379
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        async def z(self):
            return await asyncio.sleep(1, result=True)

    obj = MyClass()
    assert obj.y == MyClass.y.__get__(obj=obj, cls=MyClass)
    assert obj.__dict__['y'] == MyClass.y.__get__(obj=obj, cls=MyClass)

    @asyncio.coroutine
    def run():
        loop = asyncio.get_event_loop()
        await loop.run_until_complete(obj.z)
        assert obj.__dict__['z'] == MyClass.z.__get__

# Generated at 2022-06-11 22:20:33.810624
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    @cached_property
    def my_property(self):
        return "foo"

    class Test:
        my_property = my_property

# Generated at 2022-06-11 22:20:42.863255
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():  # noqa: D103
    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-11 22:20:51.232133
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import asyncio

    from flutils.decorators import cached_property


    class MyClass:

        @cached_property
        def y(self):
            return self.x + 1


    obj = MyClass()
    obj.x = 5
    assert obj.y == 6
    assert isinstance(obj.y, int)


    class AsyncClass:
        def __init__(self):
            self.x = 5


        @cached_property
        @asyncio.coroutine
        def y(self):
            yield
            return self.x + 1


    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    obj = AsyncClass()
    future = loop.run_until_complete(obj.y)

# Generated at 2022-06-11 22:20:56.643588
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y          # This should be the only place where obj.y is called
    assert obj.x == 5
    assert obj.y == 6



# Generated at 2022-06-11 22:21:02.911443
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test `flutils.decorators.cached_property.__get__`

    *New in version 0.2.0*

    """

    class MyClass:
        """Class under test"""
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """Property under test"""
            return self.x + 1

    # First call to __get__
    obj = MyClass()
    obj.y
    assert obj.__dict__['y'] == 6

    # Second call to __get__
    obj.y
    assert obj.__dict__['y'] == 6

# Generated at 2022-06-11 22:21:08.335327
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # This test is for method __get__ of class cached_property.
    # The following illustrates the expected output from the
    # method __get__.

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert MyClass().y == 6



# Generated at 2022-06-11 22:21:17.451023
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """This method tests the cached_property class, method __get__.
    """

    # Test basic function with a simple function.
    class Class_:
        @cached_property
        def prop(self):
            return 21

    obj = Class_()
    assert obj.prop == 21
    assert obj.__dict__['prop'] == 21

# Generated at 2022-06-11 22:21:20.716008
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-11 22:21:29.217823
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest
    from flutils.decorators import cached_property
    import asyncio

    class TestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()

    @asyncio.coroutine
    def func_coro(obj):
        num = yield from asyncio.sleep(0, obj.x)
        return num + 1

    # Testing the cache using __get__
    assert obj.y == 6
    assert isinstance(obj.__dict__['y'], int)
    assert obj.y == 6

    TestClass.y = cached_property(func_coro)
    assert isinstance(obj.__dict__['y'], asyncio.Future)
    assert pytest

# Generated at 2022-06-11 22:21:33.708514
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6
    assert obj.__dict__['y'] == 6

    assert isinstance(obj.__dict__['y'], int)



# Generated at 2022-06-11 22:21:38.647699
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # Arrange
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    expected = 6

    # Act
    actual = obj.y

    # Assert
    assert expected == actual


# Generated at 2022-06-11 22:21:46.885050
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass

# Generated at 2022-06-11 22:21:50.848002
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    obj = object()
    decorator = cached_property(object)
    assert decorator.__get__(obj) is decorator
    assert decorator.__get__(obj, object) is decorator

    class MyClass:

        @decorator
        def y(self):
            return 1

    myobj = MyClass()
    assert isinstance(myobj.y, int)
    assert myobj.y == 1



# Generated at 2022-06-11 22:21:58.699184
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Ensure that cached_property.__get__ returns a coroutine when the
    instance method is a coroutine.

    *New in version 0.2.0*
    """

    # noinspection PyUnusedLocal
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        @asyncio.coroutine
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert asyncio.iscoroutine(obj.y)



# Generated at 2022-06-11 22:22:02.386230
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


if __name__ == '__main__':
    test_cached_property___get__()

# Generated at 2022-06-11 22:22:12.318035
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import unittest

    class TestCachedProperty(unittest.TestCase):

        def test_cached_property(self):

            class MyClass:

                def __init__(self):
                    self.x = 5

                @cached_property
                def y(self):
                    return self.x + 1

            obj = MyClass()
            self.assertEqual(obj.y, 6)

        def test_cached_property_with_asyncio(self):

            class MyClass:

                def __init__(self):
                    self.x = 5

                @cached_property
                def y(self):
                    return asyncio.sleep(0, self.x + 1)

            obj = MyClass()
            self.assertEqual(asyncio.run(obj.y), 6)

    suite = un

# Generated at 2022-06-11 22:22:23.154554
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import unittest
    import asyncio
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y = cached_property(obj.y)
    assert obj.y == obj.y == 6

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        async def y(self):
            tmp = await asyncio.sleep(0.1)
            return self.x + 1

    obj = MyClass()

    loop = asyncio.get_event_loop()
    future = asyncio.ensure_future(obj.y)

# Generated at 2022-06-11 22:22:27.751008
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class TestClass:

        def __init__(self, value=0):
            self.x = value

        @cached_property
        def y(self):
            return self.x

    assert TestClass(value=2).y == 2
    assert TestClass(value=4).y == 4


# Generated at 2022-06-11 22:22:37.962004
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    def _test():
        # type: () -> None
        class Foo:
            def __init__(self):
                self.x = 5

            @cached_property
            def y(self):
                # type: () -> int
                return self.x + 1

        obj = Foo()
        # noinspection PyUnresolvedReferences
        assert obj.y == 6
        # noinspection PyUnresolvedReferences
        assert obj.y == 6

        def _test_async():
            # type: () -> None
            import asyncio

            class Foo:
                def __init__(self):
                    self.x = 5

                @cached_property
                def y(self):
                    # type: () -> int
                    return asyncio.sleep(1, 6)

            async def _test():
                obj = Foo()


# Generated at 2022-06-11 22:22:44.360356
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class _TestClass:

        def __init__(self):
            self.x = 10

        @cached_property
        def y(self):
            self.assert_(False)
            return self.x + 1

        @cached_property
        def z(self):
            return self.x + 2

    obj = _TestClass()
    assert obj.z == 12



# Generated at 2022-06-11 22:22:54.393112
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Test __get__ method of class cached_property with a regular method
    class Test:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    test_object = Test()

    assert test_object.y == 6

    # Test __get__ method of class cached_property with an async method
    class Test:

        def __init__(self):
            self.x = 5

        @cached_property
        @asyncio.coroutine
        def y(self):
            return self.x + 1

    test_object = Test()

    assert asyncio.run(test_object.y) == 6

    # Test __get__ method of class cached_property with a regular method
    # that is called twice

# Generated at 2022-06-11 22:23:19.183949
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Dummy class for testing
    class DummyClass:
        def __init__(self):
            self.prop = 5

        @cached_property
        def prop(self):
            return self.prop

    dummy_obj = DummyClass()
    assert dummy_obj.prop == 5



# Generated at 2022-06-11 22:23:23.871528
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    c = type('c', (), {})()
    c.__dict__['x'] = 5

    @cached_property
    def y(o):
        return o.x + 1

    # Unit test for method y.__get__ of class cached_property
    y.__get__(c, cached_property)



# Generated at 2022-06-11 22:23:31.199357
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Tests the method __get__ of class :obj:`~flutils.decorators.cached_property`

    """

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-11 22:23:34.248025
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-11 22:23:39.525952
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property.

    """

    class MyClass:

        def __init__(self) -> None:
            self.x = 5

        @cached_property
        def y(self) -> int:
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-11 22:23:42.322513
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-11 22:23:50.234781
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    def test_fnc(obj):
        return "test"

    cp = cached_property(test_fnc)

    class TestObj(object):
        """Test class for testing method __get__ of class cached_property"""

        def __init__(self):
            self.x = 0

        y = cp

    testobj = TestObj()
    testobj.y

    # Test that the property was cached
    assert testobj.__dict__["y"] == "test"

    # Test that the property can be accessed like a normal attribute
    assert testobj.y == "test"

    # Test that the cached property can be reset to None
    testobj.y = None
    assert testobj.y is None



# Generated at 2022-06-11 22:23:57.649792
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property
    import asyncio
    from flutils.times import sleepfor

    async def do_work(marker):
        await sleepfor(1)
        return str(marker) + '_finished'

    class TestClass:
        def __init__(self, marker):
            self.marker = marker

        @cached_property
        async def work(self):
            return await do_work(self.marker)

    async def main():
        t1 = TestClass('t1')
        t2 = TestClass('t2')
        r1 = t1.work
        r2 = t2.work
        print('started')
        assert r1.done() is False
        assert r2.done() is False
        r1 = await r1
        r2 = await r

# Generated at 2022-06-11 22:24:05.973570
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Test cached_property.__get__ on a class with a coroutine function
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        async def y(self):
            return self.x + 1

    obj = MyClass()
    assert isinstance(obj.y, asyncio.Task)

    # Test cached_property.__get__ on a class with an ordinary function
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-11 22:24:12.103488
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class Class:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Class()
    assert obj.y == 6

# Generated at 2022-06-11 22:24:55.939733
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-11 22:25:05.266632
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import unittest

    from flutils.decorators import cached_property

    class A:

        def __init__(self, x: int = 0, y: int = 0):
            self.x = x
            self.y = y

        @cached_property
        def z(self):
            return self.x + self.y

    class Test_cached_property___get___(unittest.TestCase):

        def test_cached_property___get___(self):

            a = A(0, 0)
            self.assertIsNone(a.__dict__.get("z"))
            self.assertEqual(a.z, 0)
            self.assertEqual(a.__dict__["z"], 0)

    unittest.main()
