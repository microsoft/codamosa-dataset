

# Generated at 2022-06-11 22:15:00.740467
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Foo:
        def __init__(self):
            self.x = 5

        @cached_property
        def square(self):
            return self.x ** 2

        @cached_property
        def cube(self):
            return self.x ** 3

    foo = Foo()
    assert foo.square == 25
    assert foo.cube == 125

# Generated at 2022-06-11 22:15:12.747078
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import logging
    import sys
    import unittest
    from unittest.mock import MagicMock

    from flutils.decorators import cached_property

    class _PropertyThrowsAnException(Exception):
        """Exception for testing of method :meth:`~cached_property.__get__`."""

    class Test:

        def __init__(self):
            self.counter = 0

        @cached_property
        def foo(self):
            self.counter += 1
            return self.counter

    class TestCachedProperty(unittest.TestCase):
        """Unit test for method :meth:`~cached_property.__get__`."""

        def setUp(self):
            logger = logging.getLogger()
            logger.handlers = []

# Generated at 2022-06-11 22:15:21.861367
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from inspect import signature
    from pathlib import Path

    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert 'y' in obj.__dict__
    assert 'x' in obj.__dict__

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return [i for i in range(self.x + 1)]

    obj = MyClass()
    assert obj.y == [0, 1, 2, 3, 4, 5]
    assert 'y' in obj.__dict__

# Generated at 2022-06-11 22:15:29.375441
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for  `cached_property.__get__` method

    :return: None
    """

    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    obj.y

    assert obj.y == 6
    obj.x += 1
    assert obj.y == 6

    del obj.y
    assert obj.y == 7


# Generated at 2022-06-11 22:15:34.882326
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    c = cached_property(lambda _: "result")
    assert c.__get__(None, None) is c
    assert c.__get__(object(), None) == "result"
    assert c.__get__(object(), None) == "result"
    assert c.__doc__ == c.func.__doc__

# Generated at 2022-06-11 22:15:45.728721
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import asyncio
    from typing import List
    from unittest import TestCase
    from unittest.mock import Mock, patch
    from contextlib import contextmanager

    class MyTestClass(TestCase):
        def __init__(self):
            TestCase.__init__(self)
            self.mock_future: asyncio.Future = Mock()
            self.mock_future.set_result.side_effect = None
            self.mock_future.set_result.return_value = None
            self.log: List[str] = []

        @cached_property
        def y(self):
            self.log.append('called-y')
            return self.x + 1

        @cached_property
        def z(self):
            self.log.append('called-z')

# Generated at 2022-06-11 22:15:56.123429
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from time import time

    class MyClass:

        def __init__(self):
            self.x = time()

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    # y should be computed from scratch
    y = obj.y
    print(y)
    assert y == obj.x + 1
    # y should be pulled from the cache
    y = obj.y
    print(y)
    assert y == obj.x + 1
    # Reset the cache
    del obj.y
    # y should be computed from scratch
    y = obj.y
    print(y)
    assert y == obj.x + 1

# Generated at 2022-06-11 22:16:03.642156
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    a = TestClass()
    value = a.y

    assert value == a.__dict__['y'] == 6
    assert cached_property.__get__(None, TestClass) is cached_property

    b = TestClass()
    assert b.y != a.y
    assert b.y == b.__dict__['y'] == 6



# Generated at 2022-06-11 22:16:13.713909
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    from unittest import mock

    class Test_cached_property_get():
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    test_obj = Test_cached_property_get()
    with mock.patch(
            "asyncio.iscoroutinefunction", return_value=True
    ) as mock_iscoroutinefunction, mock.patch(
            "asyncio.coroutine", return_value=True
    ) as mock_coroutine, mock.patch(
            "asyncio.ensure_future", return_value=True
    ) as mock_ensurefuture:
        test_obj.y
    mock_iscoroutinefunction.assert_called_once()
    mock_coroutine.assert_called_

# Generated at 2022-06-11 22:16:24.176016
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import TestCase

    class Test(TestCase):
        def test_cached_property___get__(self):
            # Setup
            class Foo:
                def __init__(self):
                    self.x = 5

                @cached_property
                def y(self):
                    return self.x + 1

            obj = Foo()
            # Exercise
            self.assertEqual(obj.y, 6)
            # Test that setting x doesn't change the cached value of y
            obj.x = 8
            self.assertEqual(obj.y, 6)
            # Test that resetting the cache of y causes it to be recomputed
            del obj.y
            self.assertEqual(obj.y, 9)

    test = Test()
    test.test_cached_property___get__()


#

# Generated at 2022-06-11 22:16:30.580841
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        """Test class for cached_property.__get__."""

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """Test property for cached_property.__get__."""
            return self.x + 1

    obj = MyClass()
    result = obj.y
    assert result == 6, "Expected: 6, got {}".format(result)



# Generated at 2022-06-11 22:16:37.473598
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test case for :meth:`~flutils.decorators.cached_property.__get__`

    | Unit test for method ``__get__`` of class :class:`cached_property`.

    Args:
        None.

    Returns:
        None.

    Raises:
        None.

    """

    class Test:
        # pylint: disable=unused-variable

        @cached_property
        def foo(self):
            return "bar"

    assert Test().foo == "bar"



# Generated at 2022-06-11 22:16:48.735661
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    import pytest

    async def _test_cached_property_get_1():

        class Foo:

            def __init__(self):
                self.x = 5

            @cached_property
            def y(self):
                return self.x + 1

        obj = Foo()
        assert obj.y == 6
        assert obj.__dict__ == {'x': 5, 'y': 6}

    # Test that an instance method returns the correct value
    async def _test_cached_property_get_2():

        class Foo:

            def __init__(self):
                self.x = 5

            @cached_property
            def y(self):
                return self.x + 1

        obj = Foo()
        assert obj.y == 6
        # Delete the attribute, resetting the property
        del obj.y

# Generated at 2022-06-11 22:16:59.263583
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import logging
    import asyncio
    from flutils.decorators import cached_property
    from flutils.timer import Timer

    async def async_timer_logger(delay, logger):

        """Test a simple async timer logger

        Args:
            delay (int): Delay in seconds
            logger (logging.Logger): Logger

        """
        await asyncio.sleep(delay)
        logger.debug('async_timer_logger ran')

    class Tester:
        logger = logging.getLogger(__name__)

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        def run(self):
            self.logger.debug('Tester.run')

# Generated at 2022-06-11 22:17:08.083215
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x + 2

    obj = MyClass()
    assert obj.__dict__ == {'x': 5}
    assert obj.y == 6
    assert obj.__dict__ == {'x': 5, 'y': 6}
    assert obj.z == 7
    assert obj.__dict__ == {'x': 5, 'y': 6, 'z': 7}

# Generated at 2022-06-11 22:17:09.819034
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test method __get__ of class cached_property

    """
    pass

# Generated at 2022-06-11 22:17:17.029309
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from tempfile import mkstemp
    from os import remove, close

    class Test:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Test()
    assert 6 == obj.y

    # Test that we call __get__ to get our test fixture
    fd, file_name = mkstemp()
    close(fd)
    remove(file_name)
    assert None is obj.y



# Generated at 2022-06-11 22:17:21.302146
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""

    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    test_obj = TestClass()
    result = test_obj.y
    assert result == 6



# Generated at 2022-06-11 22:17:26.268014
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of
    :obj:`~flutils.decorators.cached_property`

    """

    class MyClass:
        """Example class"""

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """Example property"""
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-11 22:17:36.875174
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Note the original copyright notice for cached_property is included at
    the top of this module.
    """

    import asyncio

    from pytest import mark, raises

    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    @mark.parametrize("attr", ["x", "y"])
    def test_delattr(attr):
        del obj.__dict__[attr]
        assert not hasattr(obj, attr)

    test_delattr("x")
    test_delattr("y")

    assert obj.y == 6


# Generated at 2022-06-11 22:17:44.762045
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestClass:
        """Not used"""

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.y == 6
    obj.x = 7
    assert obj.y == 6

# Generated at 2022-06-11 22:17:52.027789
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import mock

    # Set up fixture
    obj = mock.MagicMock()
    cls = mock.MagicMock()

    def func(obj):
        return mock.MagicMock()

    # Set up test object
    testobj = cached_property(func)

    # Execute test
    result = testobj.__get__(obj, cls)

    # Verify state
    assert func.call_count == 1
    assert obj.__dict__ == {func.__name__: func.return_value}
    assert isinstance(result, mock.MagicMock)

# Generated at 2022-06-11 22:17:58.614440
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # -- SETUP:
    class MyClass:
        @cached_property
        def x(self):
            return self.x

        x = 5

    # -- RUN:
    m = MyClass()
    x = MyClass.x

    # -- ASSERT:
    assert x is MyClass.x
    assert x is m.x



# Generated at 2022-06-11 22:18:02.339618
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test the method `cached_property.__get__`"""
    @cached_property
    def foo(obj):
        return obj

    obj = foo(1)
    assert obj.foo == 1, 'obj.foo is not 1.'

# Generated at 2022-06-11 22:18:05.738201
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():  # noqa: D103
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-11 22:18:12.171251
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.testing import AsyncTestCase

    class TestClass(AsyncTestCase):

        def __init__(self):
            self.x = 5

        def cb(self):
            return self.x + 1

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    self = obj
    assert self.y == 6



# Generated at 2022-06-11 22:18:17.134284
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from collections import namedtuple

    class TestClass:

        @cached_property
        def y(self):
            # This property will only be computed once
            return 5

    test_instance = TestClass()
    # The property y will be computed and set as a namedtuple member attribute.
    assert 5 == test_instance.y
    # The property y is no longer computed.
    assert 5 == test_instance.y



# Generated at 2022-06-11 22:18:23.046176
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""

    class X:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = X()
    assert obj.y == 6


if __name__ == "__main__":
    # Unit test code
    test_cached_property___get__()

# Generated at 2022-06-11 22:18:26.986308
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self, value):
            self.value = value

        @cached_property
        def y(self):
            return self.value + 1

    obj = MyClass(5)

    assert obj.y == 6



# Generated at 2022-06-11 22:18:35.081953
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test of class cached_property method __get__.

    """

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        async def y(self):
            await asyncio.sleep(1)
            return self.x + 1

    obj = MyClass()
    assert asyncio.iscoroutinefunction(obj.y)

# Generated at 2022-06-11 22:18:44.089352
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    @cached_property
    def f(obj):
        pass

    assert f(None) is f.func



# Generated at 2022-06-11 22:18:49.993581
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Docstring for test_cached_property___get__

    :rtype: None
    """
    class MyClass:
        """This is MyClass docstring"""

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


# Generated at 2022-06-11 22:18:55.774259
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""

    class Obj:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Obj()

    assert obj.y == 6



# Generated at 2022-06-11 22:19:06.182376
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test __get__ method of class cached_property."""
    import sys
    import unittest
    from unittest.mock import Mock

    class Tester(unittest.TestCase):

        def test_get(self):
            class Test:
                def __init__(self):
                    self.x = 5

                @cached_property
                def y(self):
                    return self.x + 1
            obj = Test()
            self.assertEqual(obj.y, 6)

        def test__get__(self):
            prop = cached_property(Mock())
            obj = object()
            self.assertIs(prop.__get__(obj, object()), prop)

        def test_no_docst(self):
            class Test:
                @property
                def foo(self):
                    pass


# Generated at 2022-06-11 22:19:17.117797
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for cached_property()

    Args:
        None

    Returns:
        None

    """
    from flutils.decorators import cached_property
    from flutils.misc import return_attrib

    class myclassobj:

        def __init__(self):
            self.myattrib = "attrib"

        @cached_property
        def mymethod(self):
            return return_attrib(self, "myattrib")

    class myclassobj_async_method:

        def __init__(self):
            self.myattrib = "attrib"

        @cached_property
        async def mymethod(self):
            return return_attrib(self, "myattrib")

    # Test the cached_property decorator on a method that is not
    # an asyncio cor

# Generated at 2022-06-11 22:19:28.410601
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""

    class MyClass:

        def __init__(self, value):
            self.value = value

        @cached_property
        def my_func(self):
            time.sleep(0.02)
            return self.value + 1

    def get_my_func(class_):

        start = time.time()
        value = class_.my_func
        elapsed_time = time.time() - start
        return elapsed_time, value

    # Test get_my_func()
    for _ in range(5):
        arg = random.randint(1, 100)
        obj = MyClass(arg)
        elapsed_time, value = get_my_func(obj)
        assert elapsed_time >= 0.02
        assert value == arg + 1

   

# Generated at 2022-06-11 22:19:32.195997
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property


    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6
    assert obj.__dict__['y'] == 6



# Generated at 2022-06-11 22:19:43.581015
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method ``__get__`` of class ``cached_property``

    Args:
        None

    Returns:
        None

    """
    from flutils.helpers import utils

    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    utils.pretty_print(obj.y)  # 6
    utils.pretty_print(obj.__dict__)  # {'x': 5, 'y': 6}

    # Deliberately kick out the cached_property `y` to force recomputation.
    del obj.__dict__['y']

    utils.pretty_print(obj.y)  # 6

# Generated at 2022-06-11 22:19:50.490326
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert type(MyClass.y) == cached_property
    assert type(obj.y) == int
    assert obj.y == 6



# Generated at 2022-06-11 22:19:57.682802
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class Tester:
        x = 1

        @cached_property
        def get_x(self):
            return self.x

    t = Tester()
    assert t.get_x == 1
    assert t.__dict__['get_x'] == 1
    t.x = 2
    assert t.get_x == 2
    assert t.__dict__['get_x'] == 2


# Unit tests for method _wrap_in_coroutine of class cached_property

# Generated at 2022-06-11 22:20:26.914340
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""
    from ..classes.objects import AutoHide

    class Foo(AutoHide):
        """Create a new instance of Foo."""

        def __init__(self):
            super().__init__()
            self._bar = None

        @cached_property
        def bar(self):
            """Get the value for bar."""
            return self._bar

        @bar.setter
        def bar(self, value):
            """Set the value for bar."""
            self._bar = value

    obj = Foo()
    assert obj.bar == obj._bar == None
    obj.bar = 1
    assert obj.bar == obj._bar == 1


# Generated at 2022-06-11 22:20:36.527604
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class C:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = C()
    assert obj.y == 6
    assert obj.__dict__ == {'x': 5, 'y': 6}
    obj.x = 1

    assert obj.y == 6  # cached value still 6

    del obj.y  # delete attribute 'y'

    assert obj.__dict__ == {'x': 1}  # 'y' removed from dict

    assert obj.y == 2  # recalculate and store new value



# Generated at 2022-06-11 22:20:40.802557
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Test:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Test()
    assert obj.y == 6



# Generated at 2022-06-11 22:20:47.371741
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        @cached_property
        def x(self):
            return 2

    obj = MyClass()
    assert obj.x == 2
    assert obj.__dict__ == {'x': 2}

    obj.__dict__['x'] = 3
    assert obj.x == 3
    assert obj.__dict__ == {'x': 3}

    del obj.x
    assert obj.__dict__ == {}
    assert obj.x == 2

# Generated at 2022-06-11 22:20:58.809022
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest

    from flutils import decorators
    from flutils.decorators import cached_property

    class Processor(object):

        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    @cached_property
    def _m(self):
        return 3 * self.x

    p = Processor(2)
    assert p.y == 3
    assert p.y == 3

    Processor.y = _m
    assert p.y == 6
    assert p.y == 6

    p.x = 7
    assert p.y == 21
    assert p.y == 21

    del p.y

    with pytest.raises(AttributeError):
        p.y

    # Test using decorator factory
   

# Generated at 2022-06-11 22:21:01.855328
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        func = cached_property(lambda x: x)
        def __init__(self, x):
            self.x = x
    obj = MyClass(2)
    assert obj.func == 2


# Generated at 2022-06-11 22:21:06.273061
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-11 22:21:10.445722
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-11 22:21:14.327603
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """ Test method __get__ of class cached_property

    """

    class Test:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    test = Test()
    assert test.y == 6



# Generated at 2022-06-11 22:21:17.634567
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestClass(object):
        count = 0

        @cached_property
        def cached_property(self):
            # type: () -> int
            self.count += 1
            return self.count

    for _ in range(10):
        assert TestClass().cached_property == 1



# Generated at 2022-06-11 22:22:04.807137
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import time

    # Create an instance of MyClass
    obj = MyClass()

    # Confirm method y() has not been called
    assert obj.call_count == 0

    # Confirm that y returns a value of 6
    assert obj.y == 6

    # Confirm method y() has been called once
    assert obj.call_count == 1

    # Confirm that y no longer returns a value of 6
    assert obj.y != 6

    # Confirm method y() has been called 2 times
    assert obj.call_count == 2

    # Confirm that the object has a cached_property_y attribute
    assert "cached_property_y" in dir(obj)

    # Confirm the cache property y is a coroutine
    assert asyncio.iscoroutine(obj.cached_property_y)

    # Confirm that the

# Generated at 2022-06-11 22:22:13.525469
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils import decorators

    def func1(self):
        return self

    def func2(self):
        return self

    assert decorators.cached_property.__get__(None, decorators.cached_property) is decorators.cached_property
    assert decorators.cached_property.__get__(decorators.cached_property, decorators.cached_property) is decorators.cached_property
    assert decorators.cached_property.__get__(None, func1) is decorators.cached_property
    assert decorators.cached_property.__get__(func1, func1) is decorators.cached_property
    obj = func2()
    result = decorators.cached_property.__get__(obj, func2)

# Generated at 2022-06-11 22:22:20.637284
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property.

    """
    class MyClass:

        @cached_property
        def func(self):
            return 42

    assert MyClass.__dict__['func'].__get__(None, MyClass) is MyClass.__dict__['func']

    obj = MyClass()
    assert isinstance(obj.func, int)

    assert obj.__dict__['func'] == 42

# Generated at 2022-06-11 22:22:31.652663
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        @cached_property
        def method(self):
            return "foo"

    obj = MyClass()

    assert obj.method == "foo"
    assert obj.method == "foo"
    assert obj.method == "foo"
    assert obj.__dict__["method"] == "foo"

    def test_cached_property___get__async():

        class MyClass:

            @cached_property
            async def method(self):
                return "foo"

        obj = MyClass()

        async def test():
            assert obj.method == "foo"
            await asyncio.sleep(0.1)
            assert obj.method == "foo"
            assert obj.method == "foo"
            assert obj.__dict__["method"] == "foo"

        loop = asyncio.get_event

# Generated at 2022-06-11 22:22:38.495495
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class _Holder:
        def __init__(self, i):
            self.i = i

        @cached_property
        def gen(self):
            yield self.i

    h = _Holder('j')
    assert list(h.gen) == ['j']
    assert h.__dict__ == {'i': 'j', 'gen': ['j']}

    h = _Holder('k')
    h.__dict__.update(gen=['l'])
    assert list(h.gen) == ['l']

# Generated at 2022-06-11 22:22:49.502747
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():  # noqa: D103
    import asyncio

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    obj.x = 6  # Otherwise property does not get called again
    assert obj.y == 7

    obj.x = 6
    assert obj.y == 7

    @property
    def prop(self):
        return self.x + 1

    MyClass.prop = prop
    assert obj.prop == 7

    obj.x = 7
    assert obj.prop == 8

    obj.x = 6  # Otherwise property does not get called again
    assert obj.y == 7


# Generated at 2022-06-11 22:22:53.120944
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Setup
    class TestClass:
        x = []

        @cached_property
        def method(self):
            return self.x

    # Exercise
    obj = TestClass()

    # Verify
    assert obj.method == []



# Generated at 2022-06-11 22:22:59.277497
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-11 22:23:03.206726
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1
    
    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-11 22:23:05.456620
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""
    pass


# Generated at 2022-06-11 22:24:36.346093
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import Mock, patch

    mock_obj = Mock(spec=cached_property)

    with patch("cached_property.func", autospec=True) as mock_func, patch(
        "cached_property.asyncio.iscoroutinefunction", autospec=True
    ) as mock_iscoroutinefunction, patch(
        "cached_property.asyncio.ensure_future", autospec=True
    ) as mock_ensure_future, patch(
        "cached_property.asyncio.coroutine", autospec=True
    ) as mock_coroutine:
        mock_obj.__dict__.__setitem__(
            cached_property.func.__name__, "mock_func_name"
        )

# Generated at 2022-06-11 22:24:44.560665
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit tests for method __get__ of class cached_property"""
    import types

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    myobj = MyClass()

    assert isinstance(myobj.y, types.CoroutineType)
    assert asyncio.iscoroutine(myobj.y)
    assert asyncio.iscoroutinefunction(MyClass.y)

# Generated at 2022-06-11 22:24:46.487459
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    with pytest.raises(TypeError, match=r"cached_property.*object"):
        cached_property.__get__(1, int)

# Generated at 2022-06-11 22:24:55.919570
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from io import StringIO
    from unittest.mock import patch

    from flutils import decorators

    def _doTest(cached_prop_func):
        class MyClass:
            def __init__(self):
                self.x = 5

            @cached_property_func
            def y(self):
                return self.x + 1

        obj = MyClass()

        assert obj.y == 6
        obj.x = 7
        assert obj.y == 8

    with patch('sys.stdout', new=StringIO()) as fakeOutput:
        _doTest(decorators.cached_property)

