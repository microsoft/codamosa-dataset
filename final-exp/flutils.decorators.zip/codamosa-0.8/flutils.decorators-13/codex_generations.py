

# Generated at 2022-06-11 22:15:12.746761
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test :meth:`flutils.decorators.cached_property.__get__`
    """

    # A 'cached_property' decorator that is only computed once per instance
    # and then replaces itself with an ordinary attribute.
    #
    # Deleting the attribute resets the property.
    #
    # This decorator is a derivative work of
    # `cached_property <https://bit.ly/2R9U3Qa>`__ and is:
    #
    # `Copyright © 2015 Daniel Greenfeld; All Rights Reserved
    # <https://bit.ly/2CwtJM1>`__
    #
    class TestClass:

        def __init__(self, value):
            self.x = value


# Generated at 2022-06-11 22:15:17.529304
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-11 22:15:22.666212
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    import unittest
    import sys
    import warnings

    if sys.version_info < (3, 8):
        from flutils.tests import helpers

        class CachedPropertyTests(helpers.TestCase):

            def test_cached_property(self):

                class Klass:

                    def __init__(self, x):
                        self.x = x

                    @cached_property
                    def y(self):
                        return self.x + 1

                obj = Klass(5)
                self.assertEqual(obj.y, 6)

            def test_cached_property_caches(self):

                class Klass:

                    def __init__(self, x):
                        self.x = x

                    @cached_property
                    def y(self):
                        return self.x + 1

                obj = Klass

# Generated at 2022-06-11 22:15:29.779683
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class foo:
        @cached_property
        def my_method(self):
            return "foo"
        @cached_property
        def my_coro(self):
            async def coro():
                return "foo"
            return coro()

    obj = foo()
    obj.my_method
    obj.my_coro
    assert obj.my_method == "foo"
    assert obj.my_coro.result() == "foo"


# Generated at 2022-06-11 22:15:42.350190
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Constructor test: ####################
    # Test 1: Return self (property's descriptor) when obj is None.
    def f():
        pass

    get_cached_property = cached_property(f).__get__(None, None)
    assert get_cached_property is not cached_property(f), (
        "cached_property.__get__ returned the wrong descriptor")
    assert get_cached_property.func is f, (
        "cached_property.__get__ returned the wrong descriptor")
    assert get_cached_property.__doc__ is f.__doc__, (
        "cached_property.__get__ returned the wrong descriptor")

    # Test 2: Return an object that calls the coroutine when obj is an object
    # and the property is coroutine.

# Generated at 2022-06-11 22:15:48.960509
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import unittest

    class A:

        @cached_property
        def x(self):
            return 1

    class B(A):

        @cached_property
        def x(self):
            return 2

    @cached_property
    def x():
        return 3

    class Test(unittest.TestCase):

        def test_cached_property___get__(self):
            self.assertEqual(A().x, 1)
            self.assertEqual(B().x, 2)
            self.assertEqual(x(), 3)

    unittest.TextTestRunner().run(unittest.TestLoader().loadTestsFromTestCase(Test))


if __name__ == '__main__':

    test_cached_property___get__()

# Generated at 2022-06-11 22:15:50.671887
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():  # noqa: D205
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-11 22:15:58.527126
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6


if __name__ == '__main__':
    import sys as _sys
    from flutils.decorators import cached_property
    from flutils.common import set_excepthook

    set_excepthook()

    locals().get('_test_%s' % _sys.argv[1], lambda: None)()

# Generated at 2022-06-11 22:16:10.435210
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest
    from flutils.decorators import cached_property

    # Set up test objects
    class MyClass:
        import asyncio

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        @asyncio.coroutine
        def z(self):
            return self.x + 2

    class MySubClass(MyClass):
        @cached_property
        def z(self):
            return self.y

    obj = MyClass()

    # Test cached_property class is defined
    assert hasattr(obj, "y")
    assert hasattr(obj, "z")

    # Testing cached_property descriptors work
    assert obj.__dict__["y"] == 6

# Generated at 2022-06-11 22:16:14.100111
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Foo:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    s = Foo()
    assert s.y == 6
    assert hasattr(s, 'y')
    del s.y
    assert not hasattr(s, 'y')
    assert s.y == 6

# Generated at 2022-06-11 22:16:20.598128
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    t = TestClass()

    assert t.__dict__['y'] == 6



# Generated at 2022-06-11 22:16:26.928589
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Test:
        def __init__(self):
            pass

        @cached_property
        def method(self):
            return None

    x = Test()
    assert not hasattr(x, 'method')

    retval = x.method
    assert retval == x.method
    assert hasattr(x, 'method')

    del x.method
    assert not hasattr(x, 'method')

    return


# Generated at 2022-06-11 22:16:30.946763
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Tests for cached_property class.

    Run with pytest.
    """
    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-11 22:16:38.159443
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from os import getpid

    class Test:
        def __init__(self):
            self.pid = getpid()

        @cached_property
        def pid_twice(self):
            assert getpid() == self.pid
            return self.pid

    obj = Test()
    pid1 = obj.pid_twice
    assert pid1 == obj.pid_twice
    obj.pid_twice = 23
    assert obj.pid_twice == 23

    del obj.pid_twice
    assert obj.pid_twice == obj.pid



# Generated at 2022-06-11 22:16:48.518868
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test method __get__ of class cached_property.
    """
    import pytest
    from flutils.decorators import cached_property

    class TestClass:

        @cached_property
        def prop(self):
            return 10

    testobj = TestClass()

    # Test: property is callable
    assert callable(testobj.prop)

    # Test: property is a coroutine
    assert asyncio.iscoroutine(testobj.prop())

    # Test: getattr from dict
    assert testobj.__dict__['prop'] == 10

    # Test: delete key from dict
    with pytest.raises(AttributeError):
        testobj.prop = 11



# Generated at 2022-06-11 22:16:54.578835
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class :class:`~cached_property`

    *New in version 0.2.2*
    """
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert MyClass().y == 6



# Generated at 2022-06-11 22:17:05.100346
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import sys
    import unittest.mock

    class MyClass:

        def __init__(self):
            self.x = None
            self.y = None

        @cached_property
        def z(self):
            return 'z'

    obj = MyClass()

    assert obj.z == 'z'
    assert obj.__dict__ == {'x': None, 'y': None, 'z': 'z'}

    def setUpModule():
        sys.modules['asyncio'] = unittest.mock.MagicMock()

    def tearDownModule():
        sys.modules.pop('asyncio', None)

    setUpModule()


# Generated at 2022-06-11 22:17:16.343319
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method ``__get__`` of class ``cached_property``.
    """

    import pytest
    from .tmpdirs import InTemporaryDirectory
    from .tmpdirs import TemporaryDirectory

    from flutils.decorators.cached_property import cached_property

    class Example:

        @cached_property
        def one(self):
            return 1

    @pytest.mark.asyncio
    async def test_cached_property_coroutines():
        class Example:

            @cached_property
            async def two(self):
                return 2

        ex = Example()
        assert ex.two == 2

    class Example:

        @cached_property
        async def two(self):
            return 2

    with pytest.raises(RuntimeError):
        Example().two

    ex

# Generated at 2022-06-11 22:17:25.223481
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # Delcaring class using decorator
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    # Test: verifying attribute `y` has correct value
    # and type is the future.
    assert obj.y == 6
    assert isinstance(obj.y, int)

    # Test: verifying that attribute `y` is set
    # on `__dict__` of instance `obj`.
    assert obj.__dict__['y'] == 6

    # Declaring a coroutine function
    @asyncio.coroutine
    def some_func(obj):
        return obj.x + 3

    # Declaring class using coroutine function

# Generated at 2022-06-11 22:17:32.149456
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self, data):
            self._data = data

        @cached_property
        def double(self):
            return self._data * 2

    obj = MyClass(data=5)
    assert obj.double == 10
    obj._data = 6
    assert obj.double != 12
    obj.__dict__.pop('double', None)
    assert obj.double == 12

# Generated at 2022-06-11 22:17:37.309974
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Test:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Test()
    assert obj.y == 6



# Generated at 2022-06-11 22:17:40.674717
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""
    import doctest

    doctest.testmod(verbose=True)

# Generated at 2022-06-11 22:17:48.042254
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """ Unit test for method __get__ of class cached_property """
    from flutils.decorators import cached_property

    class CachedPropertyTestClass:  # pylint: disable=too-few-public-methods
        """ For testing the cached_property decorator """

        def __init__(self):
            self.counter = 0

        @cached_property
        def _this_is_a_test(self):
            self.counter += 1
            return self.counter

    obj = CachedPropertyTestClass()
    assert obj._this_is_a_test == 1
    assert obj._this_is_a_test == 1



# Generated at 2022-06-11 22:17:54.972406
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit tests for method __get__ of class cached_property.
    """

    def property_func(obj):
        return obj.x + 1

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return property_func(self)

    obj = MyClass()
    result = obj.y
    assert result == 6



# Generated at 2022-06-11 22:17:55.980552
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass



# Generated at 2022-06-11 22:18:03.389283
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # first call
    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__ == {'x': 5, 'y': 6}

    # subsequent calls
    assert obj.y == 6
    assert obj.__dict__ == {'x': 5, 'y': 6}



# Generated at 2022-06-11 22:18:09.054943
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():  # noqa: (D202)
    class MyClass:
        # noinspection PyPep8Naming
        @cached_property
        def y(self):
            return self.x + 1

        def __init__(self):
            self.x = 5

    obj = MyClass()
    assert obj.y == 6

    # Test whether caching actually occurred
    obj.x = 7
    assert obj.y == 6

# Generated at 2022-06-11 22:18:18.357450
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    from unittest import mock


    class A:

        @cached_property
        def m(self):
            pass


    a = A()

    with mock.patch.object(a.__class__, 'm', side_effect=lambda self: None) as mock_m:
        assert a.m == None
        assert a.m == None
        mock_m.assert_called_once_with(a)


    class A:

        def __init__(self, x):
            self.x = x

        @cached_property
        def m(self):
            return self.x


    a = A(3)

    with mock.patch.object(a.__class__, 'm', side_effect=lambda self: self.x) as mock_m:
        assert a.m == 3

# Generated at 2022-06-11 22:18:23.008340
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-11 22:18:33.712651
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property
    """
    class MyClass(object):

        def __init__(self):
            self.x = 5
            self.y_ = None

        @cached_property
        def y(self):
            return self.x + 1

        def delete_y(self):
            """Delete y property
            """
            delattr(self, "y")

    obj = MyClass()
    assert obj.y == 6, "Test failed: property y not created"
    assert "y" not in obj.__dict__, "Test failed: instance variable y not deleted"
    obj.delete_y()
    assert "y" not in obj.__dict__, "Test failed: instance variable y not deleted"
    assert obj.y == 6, "Test failed: property y not created"


# Generated at 2022-06-11 22:18:45.672625
# Unit test for method __get__ of class cached_property

# Generated at 2022-06-11 22:18:51.704586
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6
    obj.x = 10
    assert obj.y == 6

    del obj.y
    assert obj.y == 11

# Generated at 2022-06-11 22:19:03.270400
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj1 = object()
    obj2 = object()
    obj3 = object()
    class MyClass(object):
        def __init__(self, obj):
            self.x = obj
        @cached_property
        def y(self):
            return self.x
    class MySubClass(MyClass):
        pass
    # test with instance of MyClass
    myinst = MyClass(obj1)
    assert myinst.y is obj1
    assert myinst.y is obj1
    myinst.x = obj2
    assert myinst.y is obj2
    myinst.x = obj3
    assert myinst.y is obj2
    del myinst.y
    assert myinst.y is obj3
    # test obtained value is stored in a private attribute

# Generated at 2022-06-11 22:19:09.954099
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from functools import partial
    from flutils.decorators import cached_property

    # Test for method __get__ of class cached_property for regular methods
    class Test(object):

        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    expected = Test(1)
    actual = Test(1)

    assert expected.x == actual.x
    assert expected.y == actual.y
    assert expected.y == 2
    assert actual.y == 2

    # Test for method __get__ of class cached_property for coroutines
    def coro(param):
        yield param

    @cached_property
    def z(self):
        return coro(1)

    # Using partial because of coroutine usage


# Generated at 2022-06-11 22:19:21.922127
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import asyncio
    from types import MethodType

    class A:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """A cached property"""
            return self.x + 1

    obj = A()
    cp = cached_property(obj.y)
    assert cp.__doc__ == A.y.__doc__
    assert cp.__doc__ == obj.y.__doc__

    result = cp.__get__(None)
    assert isinstance(result, cached_property)

    result = cp.__get__(obj)
    assert result == 6

    # Once cached, it's not a cached_property anymore
    result = cp.__get__(obj)
    assert isinstance(result, MethodType)


# Generated at 2022-06-11 22:19:30.013352
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

            # MyClass.x = 5
            # MyClass.y = MyClass.x + 1

    obj = MyClass()
    val = obj.y
    # After the first access of obj.y, the __get__ method will create an
    # attribute in obj.__dict__ and store the value computed by the
    # cached_property decorator (above), ie, obj.x + 1.
    # The object obj now looks like this:
    #   obj.x = 5
    #   obj.y = 6
    # Subsequent accesses of obj.y will return the stored value, ie 6. The

# Generated at 2022-06-11 22:19:38.578358
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import patch

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    # Test @cached_property decrator used on a coroutine
    p = patch.object(MyClass, "y", new_callable=cached_property)
    patched = p.start()
    patched.return_value = "hello"
    assert obj.y == "hello"

    # Test @cached_property decorator
    assert obj.y == obj.__dict__[obj.y.func.__name__]
    p.stop()

    # Test method
    p = patch.object(obj.y, "__get__")
    patched = p.start

# Generated at 2022-06-11 22:19:49.028408
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """ See: https://git.io/fjwDW """
    from flutils.flint.decorators import cached_property

    # Test property without docs
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert MyClass().y == 6

    # Test property with docs
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """My property."""
            return self.x + 1

    assert MyClass().y == 6
    assert cached_property.__doc__ == MyClass.y.__doc__



# Generated at 2022-06-11 22:19:56.328211
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest
    from collections.abc import Coroutine
    from typing import cast, Optional
    from asyncio import Future, run
    import inspect

    class MyClass:
        """MyClass"""

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x + 2

        @cached_property
        async def w(self):
            return self.x + 3

    obj = MyClass()
    future = asyncio.ensure_future(obj.w)
    if inspect.isawaitable(future):
        future = cast(Future, future)
        future.add_done_callback(lambda f: f.result())

# Generated at 2022-06-11 22:20:01.651693
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 1

        @cached_property
        def myprop(self):
            self.x += 1
            return self.x

    c = MyClass()
    assert c.x == 1
    assert c.myprop == 2
    assert c.x == 1
    assert c.myprop == 2



# Generated at 2022-06-11 22:20:09.908321
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        @cached_property
        def y(self):
            self.x = 5
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    # Prove the value is cached
    assert obj.y == 6



# Generated at 2022-06-11 22:20:18.058571
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    @cached_property
    def my_property(self):
        return self.x + self.y

    class MyClass:
        def __init__(self):
            self.x = 5
            self.y = 5

    obj = MyClass()
    assert my_property.__get__(obj, MyClass) == 10
    assert obj.my_property == 10
    assert my_property.__get__(None, MyClass) is my_property
    assert my_property.__doc__ == "A cached property."


if __name__ == '__main__':
    import pytest

    pytest.main(['-xrf'])
    pytest.main([__file__])

# Generated at 2022-06-11 22:20:24.986726
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit tests for the ``CachedProperty`` class."""

    from flutils.decorators import cached_property

    @cached_property
    def x(self):
        return 5

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    ok_(x(MyClass) == 5)

# Generated at 2022-06-11 22:20:26.067373
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():  # noqa
    assert True

# Generated at 2022-06-11 22:20:32.651433
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import sys

    if sys.version_info >= (3, 8):
        return

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    obj.x = 20
    assert obj.y == 6

# Generated at 2022-06-11 22:20:36.001298
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class obj:
        def __init__(self):
            self.x = 1

        @cached_property
        def y(self):
            return self.x + 1

    assert obj.y == 2, "method __get__ failed"

# Generated at 2022-06-11 22:20:43.523525
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Foo:
        @cached_property
        def foo(self):
            return 'this is foo'

    foo1 = Foo()
    foo2 = Foo()

    assert foo1.foo == 'this is foo'
    assert foo2.foo == 'this is foo'
    assert foo1.foo is foo2.foo
    foo1.foo = 'this is foo1'
    assert foo1.foo == 'this is foo1'
    assert foo2.foo == 'this is foo'

# Generated at 2022-06-11 22:20:50.421999
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Instance:
        def __init__(self, val):
            self.val = val

        @cached_property
        def x(self):
            return self.val + 1

    obj = Instance(5)
    assert obj.x == 6
    assert obj.x == 6
    assert "x" in obj.__dict__
    del obj.x
    assert "x" not in obj.__dict__
    assert obj.x == 6
    assert "x" in obj.__dict__
    assert obj.x == 6


if __name__ == "__main__":
    test_cached_property___get__()

# Generated at 2022-06-11 22:20:57.264639
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit testing for method __get__ of class cached_property in
    module flutils.decorators.
    """

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    expected = 6
    actual = obj.y
    assert expected == actual

# Generated at 2022-06-11 22:21:01.359966
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    This function tests the cached_property class.
    """

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    assert obj.__dict__.get('y') == 6



# Generated at 2022-06-11 22:21:18.532879
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """ Unit test for method __get__ of class cached_property. """

    import unittest
    import functools
    import math

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class MyClass2:

        def __init__(self):
            self.x = 5

        @functools.cached_property
        def y(self):
            return self.x + 1

    class MyClass3:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x + 2


# Generated at 2022-06-11 22:21:24.041220
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class _T:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    t = _T()
    assert t.y == 6


if __name__ == "__main__":
    # pragma: no cover
    from flutils.utils import run_doctest

    run_doctest(__file__)

# Generated at 2022-06-11 22:21:30.278527
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1
    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__['x'] == 5
    assert obj.__dict__['y'] == 6


# Generated at 2022-06-11 22:21:39.582887
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    ############################################################################
    #
    # Test cached_property
    #
    ############################################################################

    class TestCachedProperty:

        def __init__(self):
            pass

        def __getattr__(self, item):
            print(f'__getattr__: {item}')
            return getattr(self, item)

        @cached_property
        def x(self):
            return 'X'

        @cached_property
        def y(self):
            return 'Y'

        # noinspection PyPep8Naming
        @cached_property
        def ṻ(self):
            return 'ṻ'

    print('Testing cached_property')
    obj = TestCachedProperty()
    print(obj.x)
    print(obj.x)

# Generated at 2022-06-11 22:21:50.908868
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import logging
    import time
    import unittest
    from logging import NOTSET
    from unittest import TestCase

    from flutils.decorators import cached_property

    LOGGER = logging.getLogger(__name__)

    class TestClass:

        @cached_property
        def value(self):
            """This is a slow value."""
            LOGGER.debug('Value was not previously cached. Computing ...')
            time.sleep(0.5)
            return 'This is a slow value.'

    class Test__get__(TestCase):

        def test_basic(self):
            test_obj = TestClass()
            first_value = test_obj.value
            LOGGER.debug('First value is: %r', first_value)
            second_value = test_obj.value

# Generated at 2022-06-11 22:21:54.163127
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # Setup
    @cached_property
    def func(obj):
        return obj

    # Test
    expected_result = func.__get__(object(), object)
    assert expected_result is func


# Generated at 2022-06-11 22:22:01.576242
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test the method __get__ of class cached_property.

    """
    from .test_utils import BaseTestCase

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class Test(BaseTestCase):
        def test_cached_property___get__(self):
            obj = MyClass()
            self.assertEqual(obj.y, 6)

    test = Test()
    test.test_cached_property___get__()

# Generated at 2022-06-11 22:22:09.034246
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """

    Test case verifies cached property works as expected.

    """

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    assert "y" in obj.__dict__
    assert obj.y == 6

    del obj.y
    assert "y" not in obj.__dict__
    assert obj.y == 6



# Generated at 2022-06-11 22:22:10.621559
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # from flutils.decorators import cached_property
    pass


# Generated at 2022-06-11 22:22:17.981849
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Obj:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x + 2

    obj = Obj()
    assert obj.y == 6
    assert obj.z == 7
    obj.x = 10
    assert obj.y == 11  # value not reset
    assert obj.z == 12  # value recalculated



# Generated at 2022-06-11 22:22:37.486095
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.helpers import TimeHelper

    class MyTestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def _cached_property_with_leading_underscore(self):
            return self.x + 1

        @cached_property
        def cached_property_with_leading_underscore_(self):
            return self.x + 1

        @cached_property
        async def async_cached_property(self):
            await asyncio.sleep(1)
            return self.x + 1

    obj = MyTestClass()
    assert not hasattr(obj, "y")
    assert obj.y == 6
    assert hasattr(obj, "y")

# Generated at 2022-06-11 22:22:49.295418
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test method `cached_property.__get__`."""
    # noinspection PyPep8Naming
    class MyClass:
        """Test cached_property."""

        def __init__(self):
            self.x = 5

        @cached_property
        @asyncio.coroutine
        def y(self):
            """Some doc string."""
            return self.x + 1

        @cached_property
        def z(self):
            """Some doc string."""
            return self.x + 2

        @asyncio.coroutine
        def a(self) -> int:
            """Some doc string."""
            return self.x + 3

    obj = MyClass()
    assert obj.y.__class__.__name__ == 'ensure_future'
    assert obj.__dict__

# Generated at 2022-06-11 22:22:57.207711
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    global test_cached_property___get__

    import pytest

    # Test that the decorator is executed and the value of the
    # decorator is stored in the object's __dict__
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y  # executed decorator and stores value in __dict__
    assert obj.__dict__['y'] == 6

    # Test that when the value of the decorator is stored in the
    # object's __dict__ the decorator is not called
    class MyClass:

        def __init__(self):
            self.x = 7


# Generated at 2022-06-11 22:23:05.258489
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""
    import pytest
    import asyncio

    async def loop_func():
        await asyncio.sleep(1)
        return 'loop_func'

    loop = asyncio.get_event_loop()

    class AClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.loop_func()

        async def loop_func(self):
            return await self.x_func()

        @asyncio.coroutine
        def x_func(self):
            await asyncio.sleep(1)
            return 'x_func'

    obj = AClass()
    assert obj

# Generated at 2022-06-11 22:23:08.202847
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""
    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-11 22:23:13.965308
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    from flutils.misc import Awaitable

    class TestClass:
        def __init__(self, a_val=0):
            self.a_val = a_val

        @cached_property
        def async_a_val(self):
            return Awaitable(self.a_val)

    tc = TestClass(a_val=20)
    assert tc.async_a_val.val == 20


# Generated at 2022-06-11 22:23:18.016483
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-11 22:23:25.216711
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # ensure that getter is cached
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    obj.x = 7
    obj.__dict__.pop('y')
    assert obj.y == 8

    # ensure that method descriptor works
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.y == 6

# Generated at 2022-06-11 22:23:31.518076
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Test for case where obj is None
    obj = None
    cls = type('', (object,), {'b': 1})
    f = cached_property(lambda x: x.b)

    result = f.__get__(obj, cls)

    assert result is f



# Generated at 2022-06-11 22:23:37.548991
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():  # pragma: no cover

    from unittest import TestCase

    from .utils import test_blanks


    class MyClass(TestCase):

        def __init__(self):
            self.x = 5


        @cached_property
        def y(self):
            return self.x + 1


        @cached_property
        def z(self):
            return self.y + 1


        @cached_property
        @test_blanks
        async def a(self):
            await asyncio.sleep(0.01)
            return self.x + 1


        @cached_property
        @test_blanks
        async def b(self):
            await self.a
            return self.a + 1

    obj = MyClass()
    self = obj.y

# Generated at 2022-06-11 22:24:05.706264
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method ``cached_property.__get__``."""
    from unittest.mock import MagicMock

    obj = MagicMock()
    func = MagicMock()
    obj.__dict__ = {}
    cp = cached_property(func)
    cp.__get__(obj, None)
    func.assert_called_once_with(obj)
    assert func.return_value == obj.__dict__[func.__name__]

# Generated at 2022-06-11 22:24:11.711758
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Foo:
        def __init__(self):
            self.x = 5

        @cached_property
        def bar(self):
            return self.x + 1

    foo = Foo()

    assert foo.bar == 6



# Generated at 2022-06-11 22:24:18.037901
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from datetime import datetime

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def now(self):
            return datetime.now()

    obj = MyClass()
    assert obj.y == 6
    assert obj.y == 6
    obj.x += 1
    assert obj.y == 7
    assert obj.y == 7
    del obj.y
    assert obj.y == 8
    assert obj.now == obj.now


# Generated at 2022-06-11 22:24:22.813759
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest
    from unittest.mock import patch

    with patch('flutils.decorators.cached_property.self.func',
               create=True, new=lambda x: None):
        obj = cached_property('func')
        with pytest.raises(TypeError):
            obj.__get__(None, 'cls')



# Generated at 2022-06-11 22:24:32.577148
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import inspect

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert inspect.isroutine(obj.y)  # coroutine function
    obj.y  # unpack
    assert inspect.isroutine(obj.y) is False  # coroutine function
    assert obj.y == 6

    assert obj.__dict__.get('y', None) == 6
    assert obj.__dict__.get('y_async', None) == 6
    assert cached_property.__get__(obj, None) == 6



# Generated at 2022-06-11 22:24:39.123271
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""
    from unittest.mock import Mock

    # Test the case, case where:
    #  - obj is None
    # Expected:
    #  - Return the cached_property object
    obj = Mock()
    obj.__dict__ = {}

    cp = cached_property(None)
    assert cp.__get__(obj=None, cls=None) is cp

    # Test the case, case where:
    #  - obj is not None
    #  - self.func is not an asyncio coroutine function
    # Expected:
    #  - Return the value
    obj = Mock()
    obj.__dict__ = {}

    cp = cached_property(obj.some_func)
    cp.func = Mock(return_value=True)


# Generated at 2022-06-11 22:24:47.954519
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # noinspection PyUnresolvedReferences
    """
    test_cached_property___get__

    unit test to ensure the correct results for __get__ for both coroutine and
    non-coroutine functions
    """
    from lib2to3.fixes.fix_tuple_params import FixTupleParams

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # non-coroutine


    class MyClass:

        def __init__(self, x: int):
            self.x = x
            self.y = None
            self.z = None

        @cached_property
        def y(self):
            return self.x * 2

        @cached_property
        def z(self):
            return self.x * 3


    obj = MyClass(5)

    assert obj.y == 10

# Generated at 2022-06-11 22:24:54.167168
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest
    import unittest.mock


    # Setup
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1


    # Execute
    obj = MyClass()


    # Verify
    assert obj.y == 6



# Generated at 2022-06-11 22:24:57.764598
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        @cached_property
        def y(self):
            return self.x + 1

        def __init__(self):
            self.x = 5

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-11 22:25:03.563514
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # This function tests the functionality of method __get__ of
    # cached_property
    def return_two():
        return 2

    cp = cached_property(return_two)

    assert cp.__get__(None, None) is cp
    assert cp._wrap_in_coroutine(None) is not None

