

# Generated at 2022-06-11 22:15:00.101158
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y is 6

# Generated at 2022-06-11 22:15:12.489024
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest
    from types import FunctionType
    from types import MethodType
    from flutils.decorators import cached_property
    from flutils.decorators import cached_property as _cplib
    from flutils.decorators import cached_property as cplib

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    with pytest.raises(TypeError):
        cp = _cached_property(None)

    obj = MyClass()
    assert isinstance(obj.y, int)
    assert obj.y == 6

    func = obj.y
    assert isinstance(func, FunctionType)
    assert func.__name__ == "y"

    assert obj.__dict__

# Generated at 2022-06-11 22:15:20.874748
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from inspect import iscoroutinefunction

    class TestClass:
        def __init__(self):
            self.x = 1

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return asyncio.sleep(2, self.x + 1)

    t = TestClass()

    assert t.y == 2
    assert 'y' in t.__dict__
    assert iscoroutinefunction(t.z) is True
    assert 'z' not in t.__dict__

    ret = asyncio.run(t.z)

    assert ret == 2
    assert 'z' in t.__dict__

# Generated at 2022-06-11 22:15:23.412332
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # noinspection PyPep8Naming
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    obj.x = 10
    assert obj.y == 11



# Generated at 2022-06-11 22:15:33.819414
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    CHECK = [1]

    async def async_test():
        CHECK[0] += 1
        return CHECK[0]

    class TestCachedProperty:
        @cached_property
        def x(self):
            CHECK[0] += 1
            return CHECK[0]

    class AsyncTestCachedProperty:
        @cached_property
        async def x(self):
            CHECK[0] += 1
            return CHECK[0]

    TC1 = TestCachedProperty()
    TC1.x
    assert len(TC1.__dict__) == 1
    assert TC1.x == 2
    assert CHECK[0] == 2
    assert len(TC1.__dict__) == 1

    TC1.x
    assert len(TC1.__dict__) == 1

# Generated at 2022-06-11 22:15:38.475391
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        @cached_property
        def x(self):
            return 5

    obj = MyClass()
    assert obj.x == 5



# Generated at 2022-06-11 22:15:42.586644
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-11 22:15:46.795818
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from functools import lru_cache

    class C:
        def __init__(self, x):
            self.x = x

        @cached_property
        @lru_cache(10)
        def y(self):
            return self.x + 1

    c = C(5)
    assert c.y == 6
    assert c.__dict__['y'] == 6


# Generated at 2022-06-11 22:15:51.193512
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class A(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = A()
    assert obj.y == 6


# Generated at 2022-06-11 22:15:55.322411
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class Foo:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Foo()
    assert obj.y == 6

# Generated at 2022-06-11 22:16:08.980898
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # test a cached property using a regular function
    class TestObject:
        @cached_property
        def x(self):
            return 5

    obj = TestObject()
    assert obj.x == 5
    assert TestObject.x != 5
    assert isinstance(obj.x, int)
    assert isinstance(TestObject.x, cached_property)

    # test a cached property using a coroutine
    class TestObjectAsync:
        @cached_property
        async def x(self):
            await asyncio.sleep(0)
            return 5

    obj = TestObjectAsync()
    loop = asyncio.get_event_loop()
    loop.run_until_complete(obj.x)
    assert obj.x.result() == 5
    assert TestObjectAsync.x != 5

# Generated at 2022-06-11 22:16:12.814672
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property.
    """
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
# /def



# Generated at 2022-06-11 22:16:19.224529
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class C:
        def __init__(self):
            self.x = 5
        @cached_property
        def y(self):
            return self.x + 1

    obj = C()
    assert obj.x == obj.__dict__['x']
    assert obj.y == obj.__dict__['y']
    assert obj.y == 6


# Generated at 2022-06-11 22:16:24.032384
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""

    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    obj.x = 10
    assert obj.y == 6

# Generated at 2022-06-11 22:16:27.566928
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    from flutils.decorators import cached_property

    class Class:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Class()
    assert obj.y == 6

    # Verify that x was deleted
    assert 'x' not in obj.__dict__



# Generated at 2022-06-11 22:16:36.997460
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import Mock

    instance = Mock()
    instance.a = 10

    def ret_test(ob: Any):
        return ob.a + 16

    cp = cached_property(ret_test)
    assert cp.__doc__ is None
    cp = cp.__get__(instance, None)

    try:
        cp = asyncio.ensure_future(cp)
    except RuntimeError:
        pass

    assert isinstance(cp, asyncio.Future)
    assert isinstance(instance.__dict__[ret_test.__name__], asyncio.Future)

    assert isinstance(cp, asyncio.Future)
    cp.set_result(26)
    assert isinstance(instance.__dict__[ret_test.__name__], asyncio.Future)

# Generated at 2022-06-11 22:16:45.226999
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    #
    # Note:
    # Uncomment the lines below and re-run this test to confirm
    # that :func:`cached_property.__get__` works as expected.
    #

    # class A:
    #     def __init__(self, x):
    #         self.x = x
    #
    #     @cached_property
    #     def y(self):
    #         return self.x + 1
    #
    # obj = A(5)
    # assert obj.y == 6
    # assert isinstance(obj.y, int)
    # assert obj.y == obj.__dict__['y']
    pass



# Generated at 2022-06-11 22:16:54.579147
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Tests for method __get__ of class cached_property.

    Code::

        from flutils.decorators import cached_property

        class MyClass(object):

            def __init__(self):
                self.x = 5

            @cached_property
            def y(self):
                return self.x + 1

        obj = MyClass()
        prop_val = obj.y

    Usage::

        assert prop_val == 6
        obj.x = 2
        del obj.y
        prop_val = obj.y
        assert prop_val == 3

    """
    pass

# Generated at 2022-06-11 22:16:57.522340
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""
    from flutils.decorators import cached_property


    class MyClass:
        def __init__(self):
            self._x = 5

        @cached_property
        def y(self):
            return self._x + 1

    import pytest
    pytest.main([__file__])

# Generated at 2022-06-11 22:17:01.967450
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6
    assert obj.__dict__['y'] == 6
    assert obj.y == 6
    assert obj.__dict__['y'] == 6



# Generated at 2022-06-11 22:17:08.451581
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Setup
    class Foo:

        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    # Exercise
    obj = Foo(5)
    obj_bar = Foo(6)

    # Assert
    assert obj.y == 6
    assert obj_bar.y == 7


# Generated at 2022-06-11 22:17:18.494250
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from .helpers import dummy_func, dummy_func_gen
    from inspect import isfunction, isgeneratorfunction

    obj = CachedPropTest()

    assert isfunction(obj.y)
    assert isfunction(obj.z_function)
    assert isfunction(obj.z_async_function)
    assert not isfunction(obj.x)
    assert isgeneratorfunction(obj.z_generator)
    assert isgeneratorfunction(obj.z_async_generator)

    assert obj.y == 11
    assert obj.z_function == 12
    assert obj.x == 10

    assert list(obj.z_generator) == [10, 11, 12]
    # assert list(obj.z_async_generator) == [10, 11, 12]



# Generated at 2022-06-11 22:17:25.144462
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property
    from types import FunctionType

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert isinstance(obj.y, FunctionType)
    assert obj.y() == obj.x + 1
    assert not isinstance(obj.y, FunctionType)
    assert obj.y == obj.x + 1


if __name__ == "__main__":
    test_cached_property___get__()

# Generated at 2022-06-11 22:17:31.722590
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import os

    class Class:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            self.x += 1
            return self.x

    obj = Class()

    assert obj.y == 6
    assert obj.x == 6
    assert os.getenv("HOME") == "/Users/daniel"

# Generated at 2022-06-11 22:17:36.947373
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Foo:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    obj1 = Foo(1)
    obj2 = Foo(2)

    return (obj1.y, obj2.y) == (2, 3)



# Generated at 2022-06-11 22:17:47.673077
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Tests:
    #       __get__(obj: Any, cls)
    # ----------------------------------------------------------------------

    class MyClass:
        def __init__(self, value=0):
            self.x = value

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass(1)
    assert obj.y == 2
    assert obj.y == 2

    obj = MyClass(10)
    assert obj.y == 11
    assert obj.y == 11

    # Tasks
    # ----------------------------------------------------------------------

    loop = asyncio.get_event_loop()

    @asyncio.coroutine
    def set_x(inst: MyClass, val: int):
        for _ in range(2):
            yield from asyncio.sleep(0)
        inst.x = val

   

# Generated at 2022-06-11 22:17:59.563493
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Test 0:
    # No __init__() method, no instance attributes,
    # and no 'obj' parameter to .__get__()
    class MyClass:

        def __init__(self):
            pass

        @cached_property
        def y(self):
            return 0

    # This part of the statement will evaluate to the MyClass class
    assert MyClass.y == cached_property

    # Test 1:
    # No instance attributes and no 'obj' parameter to .__get__()
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return 0

    # This part of the statement will evaluate to the MyClass class
    assert MyClass.y == cached_property

    # Test 2:
    # Instance attributes and

# Generated at 2022-06-11 22:18:03.664734
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-11 22:18:07.541374
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # noinspection PyUnusedLocal
    @cached_property
    def x(self):
        return 5

    obj = type('', (), {'x': x})()

    # test that the x property's __get__ method is called
    assert obj.x == 5

# Generated at 2022-06-11 22:18:17.683826
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""

    import inspect

    import pytest

    from flutils.decorators import cached_property

    @cached_property
    def cls_function():
        return True

    class MyClass:

        def __init__(self):
            self.x = 5
            self.y = 10

        @cached_property
        def function(self):
            return self.x

        @property
        def prop(self):
            return self.y

    def test_func():
        """Test the cached_property decorator with a function."""

        function = cls_function.__get__(cls=None)
        assert inspect.isfunction(function)
        assert cls_function.__name__ == 'cls_function'

# Generated at 2022-06-11 22:18:32.384064
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        @property
        def y(self):
            """A class property."""
            return 5

    c = MyClass()

    print(c.y)
    print(c.__dict__)
    print(c.y)
    print(c.__dict__)

    assert c.y == c.y

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    c = MyClass()

    print(c.y)
    print(c.__dict__)
    print(c.y)
    print(c.__dict__)

    assert c.y == c.y


# Generated at 2022-06-11 22:18:44.630101
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__['y'] == 6

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 2

        @cached_property
        def z(self):
            return self.y + 1

    obj = MyClass()
    assert obj.y == 7
    assert obj.__dict__['y'] == 7

    assert obj.z == 8
    assert obj.__dict__['z'] == 8



# Generated at 2022-06-11 22:18:52.731668
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest

    @cached_property
    def my_cached_property(obj):
        return obj

    class MyClass:
        pass

    my_obj = MyClass()

    assert my_cached_property.__get__(my_obj, MyClass) == my_obj
    assert my_cached_property.__get__(MyClass, MyClass) == my_cached_property

    with pytest.raises(AttributeError):
        my_cached_property.__get__(None, MyClass)

# Generated at 2022-06-11 22:19:04.220248
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestClass:
        def __init__(self, x=5):
            self.x = x

        # Using __func__, rather than self.func, to avoid recursion.
        @cached_property
        def y(self):
            return self.__func__.__get__(self) + 1

    obj = TestClass()
    assert obj.y == 6
    assert obj.__dict__["y"] == 6
    assert obj.y == 6

    # Test the property is not computed when the instance attribute is updated
    obj.y = 7
    assert obj.y == 7
    assert obj.__dict__["y"] == 7

    # Test the property is recomputed when the instance attribute is deleted
    del obj.y
    assert obj.y == 6
    assert obj.__dict__["y"] == 6




# Generated at 2022-06-11 22:19:08.385624
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-11 22:19:20.151471
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    import pytest
    from unittest.mock import Mock, call


    @cached_property
    def test():
        return 42

    test.__get__ = Mock()

    MyClass = Mock()
    obj = MyClass()
    assert test.__get__.call_count == 0
    assert test.__get__.call_args_list == []
    test.__get__(obj)
    assert test.__get__.call_count == 1
    assert test.__get__.call_args_list == [call(obj)]

    del test
    pytest.gc.collect()

    @cached_property
    def test():
        return 42

    assert test.__get__.call_count == 0
    assert test.__get__.call_args_list == []

# Generated at 2022-06-11 22:19:29.429519
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    import pytest

    @cached_property
    def x(self):
        return 'x'

    @cached_property
    def y(self):
        return 'y'

    @cached_property
    def a(self):
        return asyncio.sleep(1)

    class Test:
        x = x
        y = y
        a = a

        def __init__(self):
            self.x = 'x'
            self.y = 'y'
            self.a = asyncio.sleep(1)

    with pytest.raises(AttributeError):
        Test()

    obj = Test()
    assert obj.x == 'x'
    assert obj.y == 'y'
    assert obj.a == 'x'
    assert obj.a == 'y'
    assert 'x' not in obj

# Generated at 2022-06-11 22:19:35.500588
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    @cached_property
    def test(obj):
        return obj.x
    class MyClass:
        def __init__(self, x):
            self.x = x
    obj = MyClass(5)
    assert obj.test == 5
    obj.x = 6
    assert obj.test == 5
    del obj.test
    assert obj.test == 6
    obj.x = 2
    assert obj.test == 2



# Generated at 2022-06-11 22:19:44.326342
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # 9 tests; 130 assertions

    import unittest

    from flutils.decorators import cached_property

    class CP(object):

        def __init__(self, *args):
            self.args = args

        @cached_property
        def prop(self):
            return self.args

    class CachedTest(unittest.TestCase):

        def test_type(self):
            cp = CP(1, 2, 3)
            self.assertIsInstance(cp.prop, tuple)

        def test_returned(self):
            cp = CP(1, 2, 3)
            self.assertEqual(cp.prop, (1, 2, 3))

        def test_attr(self):
            cp = CP(1, 2, 3)

# Generated at 2022-06-11 22:19:51.011452
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""

    class MyClass:
        @cached_property
        def val(self):
            return 5

    obj = MyClass()

    # First call should set the value of val
    assert obj.val == 5

    # Second call should return the value saved on first call
    assert obj.val == 5



# Generated at 2022-06-11 22:20:05.372387
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """ Unit test for method __get__ of class cached_property """

    class TestClass:
        @cached_property
        def x(self):
            return 5

    tc = TestClass()

    # first __get__
    assert tc.x == 5

    # second __get__
    assert tc.x == 5

    # third __get__
    assert tc.x == 5

    # now try to delete cached_property x from object tc
    del tc.x

    # __get__ should return cached func value again
    assert tc.x == 5

# Generated at 2022-06-11 22:20:14.894336
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """foo"""
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.y == 6
    obj.x = 6
    assert obj.y == 6
    del obj.y  # reset property
    assert obj.y == 7

    assert obj.y.__doc__ == "foo"



# Generated at 2022-06-11 22:20:27.596805
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    from unittest import mock
    from unittest.mock import Mock, patch

    # Mock class
    mock_class = mock.Mock()

    # Mock instance of class mock_class
    mock_instance = mock.Mock()
    mock_instance.__class__ = mock_class
    mock_instance.x = 5

    # Mock function
    mock_function = Mock(return_value=42)

    # Create class
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1


    # Create instance of class MyClass
    my_obj = MyClass()

    # Test when obj is None
    prop = cached_property(mock_function)

# Generated at 2022-06-11 22:20:38.380031
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Test:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    t1 = Test(1)
    try:
        assert t1.y == 2
    except AttributeError as ae:
        pytest.fail(
            f't1.y returns incorrect value.\n'
            f'Error: {ae!r}'
        )
    except Exception as e:
        pytest.fail(
            f'Unexpected exception raised when accessing t1.y.\n'
            f'Error: {e!r}'
        )

# Generated at 2022-06-11 22:20:42.388494
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Obj:
        @cached_property
        def func(self):
            return 'funcion called'
    obj = Obj()
    assert obj.func == 'funcion called'
    assert obj.func == 'funcion called'



# Generated at 2022-06-11 22:20:48.417152
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""

    class Foo:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Foo()
    assert obj.y == 6


if __name__ == "__main__":
    # Unit tests run when module is run directly, but not when imported
    test_cached_property___get__()

# Generated at 2022-06-11 22:20:54.638113
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property

    """

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert(obj.y == 6)



# Generated at 2022-06-11 22:20:59.278902
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass(object):

        def __init__(self):
            self.x = 1

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 2, f'obj.y == {obj.y}'
    assert obj.x == 1, f'obj.x == {obj.x}'

# Generated at 2022-06-11 22:21:05.922509
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test method __get__ of class cached_property.
    """

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Executing the following code should result in a cached_property object
    assert isinstance(MyClass.y, cached_property)
    # Executing the following code should result in a 6 value
    assert MyClass().y == 6

# Generated at 2022-06-11 22:21:15.898787
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # Test normal use
    class T(object):
        def __init__(self, x):
            self.x = x

        @cached_property
        def a(self):
            return self.x + 1

    t = T(5)
    assert t.a == 6
    assert isinstance(T.a, cached_property)

    # Test class-level use
    assert T.a == cached_property(t.a.func)

    # Test normal use w/coroutine
    class T(object):
        def __init__(self, x):
            self.x = x

        @cached_property
        @asyncio.coroutine
        def a(self):
            return self.x + 1

    t = T(5)
    assert isinstance(T.a, cached_property)

    # Test

# Generated at 2022-06-11 22:21:34.952311
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    myclass = MyClass()
    myclass.y
    assert myclass.__dict__['y'] == 6

# Generated at 2022-06-11 22:21:40.260248
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from functools import partial

    def the_function(self, a, b):
        return a + b

    class TheClass:
        pass

    TheClass.the_function = cached_property(partial(the_function, a=5))
    obj = TheClass()
    assert 5 == getattr(obj, 'the_function')(b=0)
    assert 6 == getattr(obj, 'the_function')(b=1)
    assert 5 == getattr(obj, 'the_function')(b=0)

# Generated at 2022-06-11 22:21:46.396792
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


if __name__ == "__main__":
    sys.exit(pytest.main(["-x", __file__]))

# Generated at 2022-06-11 22:21:49.342267
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-11 22:22:00.803113
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from collections import namedtuple
    from unittest import TestCase, main

    class Test(TestCase):
        """Unit testing for cached_property.__get__."""

        def setUp(self):
            self.obj = namedtuple('obj', ['x'], defaults=[10])()

        def test_cached_property___get__(self):
            """Verify that calls to cached_property are not re-iterated."""
            @cached_property
            def y(obj):
                """The property."""
                obj.y = 1
                return obj.y

            self.obj.x = 5
            self.assertEqual(repr(y), '<cached_property object at 0x0>')
            self.assertEqual(y, 1)
            self.assertEqual(y, 1)
           

# Generated at 2022-06-11 22:22:01.766806
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass



# Generated at 2022-06-11 22:22:11.416271
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    CLI Example:
    ::

        python -m flutils.decorators test_cached_property___get__
    """
    import random
    import time

    class Foo:
        """Just some class to use as a context manager."""

        def __init__(self, bar):
            self.bar = bar

        @cached_property
        def my_random_number(self):
            """Returns a random value."""
            return random.randint(1, 100)

    foo = Foo(1)
    start = time.time()
    for _ in range(5):
        print(foo.my_random_number)
    print(f"Time to complete: {time.time() - start}")



# Generated at 2022-06-11 22:22:11.904466
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass

# Generated at 2022-06-11 22:22:22.830084
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import MagicMock
    from unittest import TestCase

    class TestObj:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class TestCase1(TestCase):

        @staticmethod
        def test_cached_property___get__():
            obj = TestObj()
            assert obj.y == 6

    class TestCase2(TestCase):

        @staticmethod
        def test_cached_property___get__():
            TestObj.y = MagicMock(return_value=6)
            obj = TestObj()
            assert obj.y is TestObj.y.return_value

    TestCase1().test_cached_property___get__()
    TestCase2().test_

# Generated at 2022-06-11 22:22:29.673190
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import Mock

    @cached_property
    def func(obj):
        return 'value'

    obj = Mock()
    obj.__dict__[func.func.__name__] = None
    obj.__class__.func = func

    assert obj.func == 'value'
    assert obj.__dict__[func.func.__name__] == 'value'

    obj.func = 'new value'
    assert obj.func == 'new value'


# Generated at 2022-06-11 22:23:02.838275
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def x_squared(self):
            return self.x * self.x

    obj = MyClass()
    assert obj.x_squared == 25
    obj.x = 6
    assert obj.x_squared == 25

# Generated at 2022-06-11 22:23:07.160425
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    obj = MyClass()
    obj.y = 7
    assert obj.y == 7

# Generated at 2022-06-11 22:23:13.185550
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x * 2

    obj = MyClass()
    assert obj.y == 10
    assert obj.__dict__['y'] == 10

if __name__ == "__main__":
    test_cached_property___get__()

# Generated at 2022-06-11 22:23:20.816500
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property
    from flutils.testing import pytest_generate_tests

    class C(object):
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    test_data = [(C(5), 6)]
    ids = ["obj.y == 6"]

    def run_test(obj, expected):
        assert obj.y == expected

    pytest_generate_tests(locals())

# Generated at 2022-06-11 22:23:26.683017
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import unittest

    class Test(unittest.TestCase):

        def test_1(self):
            from flutils.decorators import cached_property

            class MyClass:

                def __init__(self, x):
                    self.x = x

                @cached_property
                def y(self):
                    return self.x + 1

            obj = MyClass(5)
            self.assertEqual(obj.y, 6)

        def test_2(self):
            from flutils.decorators import cached_property

            class MyClass:

                def __init__(self, x):
                    self.x = x

                @cached_property
                def y(self):
                    return self.x + 1

            obj = MyClass(5)
            obj.y

# Generated at 2022-06-11 22:23:32.665484
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import TestCase, mock
    from flutils.decorators import cached_property
    import asyncio
    from concurrent.futures import CancelledError

    class Test_cached_property__cached_property___get__(TestCase):
        # noinspection PyUnusedLocal
        @cached_property
        def prop(self):
            """A property"""
            return object()

        def test_get_property_regular(self):
            obj = self()
            self.assertEqual(obj.prop, object())

        def test_get_property_async(self):
            self.prop = cached_property(asyncio.coroutine(self.prop))
            loop = asyncio.get_event_loop()
            # noinspection PyUnresolvedReferences
            obj = self()

# Generated at 2022-06-11 22:23:34.863406
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():  # pragma: no cover
    pass



# Generated at 2022-06-11 22:23:43.511286
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestClass:
        def __init__(self):
            self.x = 5
            self.y = 10
            self.z = 20

        @cached_property
        def get_attr_x(self):
            return self.x

        @cached_property
        def get_attr_y(self):
            return self.y

        @cached_property
        def get_attr_z(self):
            return self.z

    obj = TestClass()
    assert obj.x == obj.get_attr_x
    assert obj.y == obj.get_attr_y
    assert obj.z == obj.get_attr_z



# Generated at 2022-06-11 22:23:47.820143
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 0

        @cached_property
        def y(self):
            self.x += 1
            return self.x

    obj = MyClass()
    obj.y
    obj.y
    assert obj.y == 1


# Generated at 2022-06-11 22:23:53.445686
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # noinspection PyUnusedLocal
    class TestClass:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 10

    obj = TestClass(5)
    assert obj.y == 15

