

# Generated at 2022-06-11 22:15:00.378560
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    obj.x += 1
    obj.__dict__.pop('y', None)
    assert obj.y == 7



# Generated at 2022-06-11 22:15:12.488895
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # Test attribute is set as expected when it is not in instance.__dict__
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__["y"] == 6

    # Test attribute is set as expected when it IS in instance.__dict__
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.__dict__["y"] = 10
    assert obj.y == 10
    assert obj.__dict__["y"] == 10

    # Test a class attribute

# Generated at 2022-06-11 22:15:21.709702
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import sys
    import types

    from . import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    # Verify the underlying property
    if sys.version_info >= (3, 8):
        # noinspection PyUnresolvedReferences
        assert isinstance(
            obj.__dict__["y"], functools.cached_property  # type: ignore
        )
    else:
        assert isinstance(obj.__dict__["y"], types.MethodType)
    # Verify that subsequent calls to y do not re-calculate the value
    obj.x = 6
    assert obj.y == 6

# Generated at 2022-06-11 22:15:32.613521
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClassA:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class MyClassB:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return asyncio.ensure_future(self.async_func())

        async def async_func(self):
            await asyncio.sleep(0.5)
            return self.x + 1

    obj_a = MyClassA()
    obj_b = MyClassB()

    assert obj_a.y == 6
    assert obj_b.y != 6

    loop = asyncio.get_event_loop()
    loop.run_until_complete(obj_b.y)



# Generated at 2022-06-11 22:15:44.420805
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import patch, Mock
    from ._util import check_instance_against_class_type_hint, type_hint_name
    # Use the same test plan as for class _cached_property and it's method __get__

    # Check the attribute __doc__
    assert cached_property.__doc__ == _cached_property.__doc__

    # Check the attribute __doc__ of the class @cached_property
    def test_docs():
        """Docstring"""
        class Cls:

            @cached_property
            def doc(self):
                return 'test'

        assert Cls.doc.__doc__ == 'Docstring'
        assert Cls.doc.__name__ == 'doc'

    # Check that the wrapped function is callable

# Generated at 2022-06-11 22:15:48.267060
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6



# Generated at 2022-06-11 22:15:52.437746
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from pytest import raises
    from flutils.decorators import cached_property
    from flutils.decorators import cached_property as builtin_cached_property

    class TestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Test __get__
    obj = TestClass()
    assert obj.y == 6
    assert isinstance(obj.y, int)
    assert obj.y == obj.__dict__['y']
    with raises(AttributeError):
        obj = TestClass()
        del obj.y
        obj.z

    # Test __get__ with builtin cached_property

# Generated at 2022-06-11 22:15:56.553605
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-11 22:15:58.859184
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property.
    """
    # This method is tested in test_decorators
    pass

# Generated at 2022-06-11 22:16:03.890134
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    assert obj.__dict__["y"] == 6



# Generated at 2022-06-11 22:16:10.527320
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    assert obj.__dict__ == {'x': 5, 'y': 6}

# Generated at 2022-06-11 22:16:22.861167
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property.
    """
    from unittest.mock import Mock, patch

    from flutils.decorators import cached_property

    # noinspection PyUnusedLocal
    class MyClass:
        @cached_property
        def y(self):
            return self._y

    obj = MyClass()

    with patch.object(obj, '_y', 'foo') as _mock_y:
        _mock_y.__get__ = Mock(return_value='foo')
        assert obj.y == _mock_y.__get__()

    obj.__dict__['_y'] = 'foo'
    assert obj.__dict__['_y'] == 'foo'

    assert obj.__dict__['y'] == 'foo'

# Generated at 2022-06-11 22:16:31.323267
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test cached_property.__get__
    """

    class MyClass:
        def __init__(self, x):
            self.x = x

    class MySubClass(MyClass):
        def __init__(self, x, y):
            MyClass.__init__(self, x)
            self.y = y

    class MyClass:
        def __init__(self, x, y):
            self.x = x
            self.y = y

    obj = MyClass(7, 8)
    obj2 = MySubClass(9, 10)
    obj3 = MySubClass(11, 12)

    @cached_property
    def z(self):
        return self.x + self.y

    z = z.__get__(obj3, MyClass)
    assert z == 23


# Generated at 2022-06-11 22:16:40.470511
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import TestCase, main

    class _CachedPropertyTestCase(TestCase):

        @cached_property
        def y(self):
            return self.x + 1

    class _CachedPropertyAsyncTestCase(TestCase):

        @cached_property
        def z(self):
            asyncio.sleep(1)
            return self.x + 2

    # Test for ordinary method
    test_case = _CachedPropertyTestCase()
    test_case.x = 5
    test_case.y
    self = test_case
    assert self.__dict__[self.y.func.__name__] == 6
    assert self.y == 6

    # Test for async method
    test_case = _CachedPropertyAsyncTestCase()
    test_case.x = 5
    asyncio.get_

# Generated at 2022-06-11 22:16:45.126552
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    import pytest

    class a:
        def __init__(self):
            self.x = 2
            self.y = 1

        @cached_property
        def z(self):
            return self.x + self.y

    obj = a()
    assert obj.z == 3



# Generated at 2022-06-11 22:16:50.750525
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__['y'] == 6


# Generated at 2022-06-11 22:17:00.638099
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    # noinspection PyMissingConstructor
    class MyClass:
        def __init__(self):
            self.x = 0

        @cached_property
        def y(self):
            self.x += 1
            return self.x

    obj = MyClass()
    assert obj.y == 1
    assert obj.y == 1

    # noinspection PyMissingConstructor
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.y == 6

    # noinspection PyMissingConstructor
    class MyClass:
        def __init__(self):
            self

# Generated at 2022-06-11 22:17:10.158413
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property

    """

    # Test that __get__ returns a cached_property object.
    def _test_get_cached_property_object(func):

        cached_property_object = cached_property(func)
        assert isinstance(cached_property_object, cached_property)
        # Test that __get__ returns func.__doc__
        assert cached_property_object.__doc__ == func.__doc__

    # Test when object is None
    _test_get_cached_property_object(None)

    # Test when object is not None
    def _func(object):
        pass

    _test_get_cached_property_object(_func)

    # Test that __get__ returns a cached_property object when object is not
    # None.

# Generated at 2022-06-11 22:17:14.413080
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Test:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Test()
    assert obj.y == 6

# Generated at 2022-06-11 22:17:24.564431
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method ``cached_property.__get__``."""

    # Establish the class we'll be testing
    class Foo(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            "This is a test"
            return self.x + 1

    # Create an instance
    foo = Foo()

    # Test that the instance has properly cached the computed value of the
    # instance variable
    assert foo.y == 6

    # Reassign the value of x and test that the instance returns the expected
    # value
    foo.x = 10
    assert foo.y == 11

    # Test that __doc__ is set as expected
    assert Foo.y.__doc__ == "This is a test"


# Unit tests for class cached_property


# Generated at 2022-06-11 22:17:31.467529
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class C(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = C()
    assert obj.y == 6

# Generated at 2022-06-11 22:17:37.522685
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property

    *New in version 0.2.0*

    """

    # Define a class with a cached property
    class Test:

        def __init__(self):
            self._x = 5

        @cached_property
        def y(self):
            return self._x + 1

    # Instantiate the class
    obj = Test()

    # Test the @cached_property.__get__
    assert obj.y == 6



# Generated at 2022-06-11 22:17:48.075589
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    def test_cached_property___get___coroutine(monkeypatch):
        class MyClass:

            def __init__(self):
                self.x = 5

            @cached_property
            async def y(self):
                return self.x + 1

        monkeypatch.setattr(
            asyncio,
            "iscoroutinefunction",
            lambda func: True,
        )

        obj = MyClass()
        x = asyncio.ensure_future(obj.y)
        assert asyncio.iscoroutine(x)

# Generated at 2022-06-11 22:17:59.950887
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method ``__get__`` of class :obj:`cached_property`."""
    from unittest import mock

    # Test with no obj or cls provided; and with a coroutine for the
    # property.
    prop_func = mock.MagicMock()
    prop_func.__doc__ = "doc string"
    mock_coro = mock.AsyncMock(name="coro")
    prop_func.__call__.return_value = mock_coro
    prop_func.__name__: str = "mock_coro"
    assert cached_property(prop_func).__get__(obj=None, cls=None)
    assert mock_coro.called is False

    # Test with no obj or cls provided; and with a coroutine for the
    # property.
    prop

# Generated at 2022-06-11 22:18:06.942055
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # noinspection PyMethodMayBeStatic
    class MyClass:
        _x = 5

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    assert isinstance(obj.y, int)
    assert isinstance(obj.z, int)
    assert not isinstance(obj._x, int)



# Generated at 2022-06-11 22:18:16.953442
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class CachedPropertyClass(object):

        @cached_property
        def x(self):
            return 1 + 1

    cpc = CachedPropertyClass()
    assert cpc.x == 2
    assert cpc.__dict__['x'] == 2
    assert hasattr(cpc, 'x'), True

    try:
        del CachedPropertyClass.x
    except AttributeError as e:
        assert "can't delete attribute" in str(e)
    else:
        pytest.fail('Expected AttributeError')

    try:
        del cpc.x
    except AttributeError as e:
        assert "can't delete attribute" in str(e)
    else:
        pytest.fail('Expected AttributeError')



# Generated at 2022-06-11 22:18:26.055403
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from math import pi
    from itertools import count

    class Circle:
        def __init__(self, radius):
            self.radius = radius

        @cached_property
        def area(self):
            return pi * self.radius ** 2

        @cached_property
        def perimeter(self):
            return 2 * pi * self.radius

        @cached_property
        def pi(self):
            print('Computing π')
            digits = count(3, 2)
            top = 4
            bottom = 3
            operation = 1

            while abs(top / bottom - pi) >= 1e-10:
                if operation == 1:
                    top += next(digits)
                    operation = -1
                else:
                    bottom += next(digits)
                    operation = 1
            return top / bottom

    import py

# Generated at 2022-06-11 22:18:27.869457
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property

    """

    import doctest
    doctest.testmod()

# Generated at 2022-06-11 22:18:30.876460
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property
    """

    # Test class definition
    class TestClass:

        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    # Test call
    test_obj = TestClass(5)
    assert test_obj.y == 6



# Generated at 2022-06-11 22:18:35.443712
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    obj = MyClass()
    assert obj.y == 6

    assert not hasattr(obj, 'x')

# Generated at 2022-06-11 22:18:42.077623
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    @cached_property
    def x(obj):
        return obj.y + 1

    class MyClass:
        def __init__(self):
            self.y = 5

    m = MyClass()
    assert m.x == 6
    assert m.__dict__ == {'y': 5, 'x': 6}


# Generated at 2022-06-11 22:18:49.256362
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self._x = 5

        @cached_property
        def y(self):
            """Returns x + 1"""
            return self._x + 1

    obj = MyClass()

    # test .__doc__
    assert obj.y.__doc__ == 'Returns x + 1'
    # test .__name__
    assert obj.y.__name__ == 'y'
    # test return value
    assert obj.y == 6



# Generated at 2022-06-11 22:18:53.100960
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-11 22:19:04.514414
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class A:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            ''' Docstring y method '''
            return self.x + 1

        @cached_property
        def z(self):  # pragma: no cover
            return self.y + 1

        @cached_property
        async def a(self):  # pragma: no cover
            await asyncio.sleep(0.1)
            return self.y + 1

    obj = A()
    assert obj.y == 6
    assert obj.__dict__['y'] == 6
    assert obj.y == 6
    assert obj.__dict__['y'] == 6
    del obj.y
    assert 'y' not in obj.__dict__
    assert obj.y == 6


# Generated at 2022-06-11 22:19:07.449995
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    @cached_property
    def my_property():
        return 5

    obj = MyClass()
    assert obj.my_property == 5



# Generated at 2022-06-11 22:19:18.375108
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    fname = __file__.rstrip('.py') + '.test_cached_property__get__.test'

    class Test:
        def __init__(self):
            self.a = 0
            self.x = 0

        @cached_property
        def y(self):
            self.a += 1
            return self.x + 1.0

        @cached_property
        def z(self):
            self.a += 1
            return self.x + 2.0

    obj = Test()
    assert obj.a == 0
    assert obj.y == 1.0
    assert obj.a == 1
    assert obj.z == 2.0
    assert obj.a == 2
    assert obj.y == 1.0
    assert obj.a == 2
    assert obj.z == 2.0

# Generated at 2022-06-11 22:19:24.356945
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x + 2

    obj = TestClass()
    assert obj.y == 6
    assert obj.z == 7



# Generated at 2022-06-11 22:19:34.697392
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Tests the method / function
    cached_property.__get__().

    These tests are intended to be run from the repository root using:

        python -m unittest tests.test_decorators.TestDecorators.test_cached_property___get__

    """
    # noinspection PyUnresolvedReferences
    from flutils.decorators import cached_property

    #########################################################################
    # test_cached_property___get___obj_None
    #########################################################################

    class TestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    t = TestClass()

    # First call to cached_property (obj is not None) should return value.
    assert t.y == 6

    # Second

# Generated at 2022-06-11 22:19:41.239521
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            print('in y')
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    obj.x = 10
    assert obj.y == 6
    del obj.y
    assert obj.y == 11


# Generated at 2022-06-11 22:19:45.190289
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-11 22:19:55.456534
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # This is the normal use case
    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__ == {'x': 5, 'y': 6}

    # This is the case where the property has been deleted
    delattr(obj, 'y')
    assert obj.__dict__ == {'x': 5}
    assert obj.y == 6
    assert obj.__dict__ == {'x': 5, 'y': 6}



# Generated at 2022-06-11 22:19:59.834670
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    import pytest

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-11 22:20:03.296684
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """test_cached_property___get__"""

    class MyClass:
        @cached_property
        def x(self):
            return 32

    obj = MyClass()
    assert obj.x == 32



# Generated at 2022-06-11 22:20:09.203569
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class S:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    s = S()
    assert s.__dict__ == {'x': 5}
    assert s.y == 6
    assert s.__dict__ == {'x': 5, 'y': 6}



# Generated at 2022-06-11 22:20:15.578192
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            pass

        @cached_property
        def y(self):
            return 5

    obj = MyClass()
    assert obj.y == 5

    obj.y = 6
    assert obj.y == 6

    del obj.y
    assert obj.y == 5

# Generated at 2022-06-11 22:20:27.943291
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import patch

    @patch('flutils.decorators.cached_property._wrap_in_coroutine')
    def test1(mock_wrap_in_coroutine, monkeypatch):
        from unittest import TestCase as tc
        from unittest.mock import Mock

        class Foo:
            x = 1

            @cached_property
            def y(self):
                return self.x + 2

        obj = Foo()
        obj_dict = {}
        monkeypatch.setattr(obj, '__dict__', obj_dict)

        # Test for non-coroutine/coroutine function
        prop = cached_property(Mock(wraps=lambda x: 3))
        obj_dict = {}
        monkeypatch.setattr(obj, '__dict__', obj_dict)
       

# Generated at 2022-06-11 22:20:32.652380
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property

    """
    import doctest

    doctest.testmod()

if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-11 22:20:41.065178
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.asyncutils import run_async_tests

    class TestClass(object):
        """Tests for class cached_property"""

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            raise RuntimeError("hey, there it was")

    tst = TestClass()
    assert tst.y == 6
    tst.z
    assert tst.z.exception()

    async def test1():
        assert await tst.z

    async def test2():
        assert await tst.z.exception()

    async def test3():
        assert await tst.z.exception()


# Generated at 2022-06-11 22:20:46.129617
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6

    with pytest.raises(KeyError):
        del obj.y

    assert obj.y == 6

# Generated at 2022-06-11 22:20:57.635973
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from concurrent.futures import ThreadPoolExecutor

    class TestCachedProperty:

        @cached_property
        def _y(self):
            return self._x + 1

        @cached_property
        def _z(self):
            return self._x + 2

        def __init__(self, x: int = 5):
            self._x = x

    loop = asyncio.new_event_loop()

    async def _test():
        obj = TestCachedProperty()
        assert obj._y == 6
        assert obj._y == 6
        assert obj._z == 7
        assert obj._z == 7

    with ThreadPoolExecutor() as pool:
        loop.set_default_executor(pool)
        loop.run_until_complete(_test())
        loop.close()



# Generated at 2022-06-11 22:21:16.852116
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    from functools import wraps
    from unittest.mock import Mock, MagicMock

    # Cached properties are evaluated only once.
    class Object:
        def __init__(self):
            self.attr = Mock(side_effect=lambda: object())
        @cached_property
        def prop(self):
            return self.attr()

    obj = Object()
    for _ in range(3):
        assert obj.prop is obj.prop

    assert obj.attr.call_count == 1

    # Deleting the property clears the cache.
    del obj.prop
    assert obj.attr.call_count == 2
    assert obj.prop is obj.prop

    # Properties work correctly for subclasses.
    class SubObject(Object):
        pass

    obj = SubObject()

# Generated at 2022-06-11 22:21:19.731177
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from time import time

    class MyClass:

        @cached_property
        def x(self):
            return time()

    obj = MyClass()
    assert obj.x == obj.x



# Generated at 2022-06-11 22:21:26.857339
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():  # noqa: D102
    """Unit test for method __get__ of class cached_property.

    """

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # test cached_property
    obj = MyClass()
    assert obj.y == 6

    # test cached_property
    obj = MyClass()
    assert obj.y == 6

    # test cached_property
    del obj.y
    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-11 22:21:35.672445
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method test_cached_property___get__

    *New in version 0.1.0*
    """
    from unittest.mock import Mock
    from unittest.mock import patch

    with patch('flutils.decorators.asyncio.iscoroutinefunction', return_value=False) as iscoroutinefunction:
        class MyClass:

            def __init__(self):
                self.x = 5

            @cached_property
            def y(self):
                return self.x + 1

        mock_self = Mock(__class__=MyClass, x=5)

        cached_property.__get__(mock_self, MyClass)

        assert mock_self.y == 6
        assert mock_self.__dict__['y'] == 6

# Generated at 2022-06-11 22:21:41.852526
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """ Unit test for method __get__ of class cached_property """
    from .logging_tools import Timer

    class cls:
        @cached_property
        def func(self):
            time.sleep(3)
            return 3

    x = cls()
    with Timer(detail=True):
        assert x.func == 3

    with Timer(detail=True):
        assert x.func == 3



# Generated at 2022-06-11 22:21:46.096868
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class DummyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = DummyClass()
    assert obj.y == 6

# Generated at 2022-06-11 22:21:50.155291
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.called = False

        @cached_property
        def y(self):
            if self.called:
                return "called"
            self.called = True
            return "not called"

    obj = MyClass()
    assert obj.y == "not called"
    assert obj.y == "called"



# Generated at 2022-06-11 22:21:51.169784
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass

# Generated at 2022-06-11 22:21:55.740535
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class _C:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    c = _C()
    assert c.y == 6



# Generated at 2022-06-11 22:22:02.354316
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property
    from .test_utils import ClassWithAsyncMethod

    an_obj = ClassWithAsyncMethod()
    assert an_obj.test_method_async_coro_4() == 4
    assert isinstance(an_obj.test_method_async_coro_4, cached_property)

    from flutils.misc import is_async_func

    assert is_async_func(an_obj.test_method_async_coro_4)
    assert not is_async_func(an_obj.test_method)

# Generated at 2022-06-11 22:22:32.511576
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property.

    """
    class TestClass:

        def __init__(self):
            self.x = 1

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.y == 2

    obj.x = 2
    assert obj.y == 2  # cached_property
    assert obj.__dict__['y'] == 2  # cached_property

    # cached_property is not reset to 1 after deleting obj.__dict_['y']
    del obj.__dict__['y']
    assert obj.y == 2  # cached_property

    # cached_property was reset to 1 after deleting obj.y
    del obj.y
    assert obj.y == 3  # cached_property

    # cached_

# Generated at 2022-06-11 22:22:41.126221
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 1

            self.y = cached_property(self._coro_func)

        @cached_property
        def c(self):
            return 1

        @asyncio.coroutine
        def _coro_func(self):
            return self.x

    # Test 1
    my_instance = MyClass()

    # Test 2
    assert my_instance.c == 1

    # Test 3
    assert asyncio.iscoroutine(my_instance.y)

    # Test 4
    assert asyncio.iscoroutinefunction(my_instance._coro_func)

    # Test 5
    assert not asyncio.iscoroutinefunction(my_instance.c)

    # Test 6

# Generated at 2022-06-11 22:22:52.116846
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Do the following:

    * Instantiate a :obj:`~flutils.decorators.cached_property.cached_property`
      instance.
    * Call it with no parameters.
    * Call it with valid values for the parameters.
    * Call it with invalid values for the parameters.

    Expected result:

    * Calling it with no parameters returns :any:`None`.
    * Calling it with valid values returns
      :obj:`~flutils.decorators.cached_property.cached_property` instance.
    * Calling it with invalid values raises a
      :obj:`~flutils.decorators.cached_property.AttributeError`.
    """
    import math

    class Example:
        """Example class"""

        def __init__(self):
            """

            """
            self.foo

# Generated at 2022-06-11 22:22:53.805252
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():  # noqa: D103
    """Test method __get__ of class cached_property.

    """

    pass



# Generated at 2022-06-11 22:23:01.258650
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x * self.x

    obj = MyClass()
    assert obj.y == 25  # eval
    assert obj.y == 25  # cached
    del obj.y
    assert obj.y == 25  # eval

# Generated at 2022-06-11 22:23:09.290599
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class First:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class Second:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.y + 2

    class Third:
        def __init__(self):
            self.x = 5

        @cached_property
        async def y(self):
            return self.x + 1

    first = First()
    assert first.y == 6
    assert first.y == 6
    second = Second()
    assert second.z == 8
    assert second.z == 8
    # For

# Generated at 2022-06-11 22:23:15.151809
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """test cached_property.__get__
    This function tests cached_property.__get__.
    """
    from types import FunctionType

    @cached_property
    def _func():
        return 'foo'

    assert isinstance(_func.__get__, FunctionType) is True
    assert _func.__get__() == 'foo'
    assert isinstance(_func.__get__(None), FunctionType) is True
    assert _func.__get__(None)() == 'foo'

# Generated at 2022-06-11 22:23:24.245654
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import time
    from timeit import default_timer as timer
    import unittest
    import unittest.mock as mock

    # noinspection PyUnresolvedReferences
    async def async_meth(srself):
        time.sleep(1)

    class TestCachedProperty:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class TestCachedProperty1(TestCachedProperty):
        """Testing for property decorator cached_property"""

        # noinspection PyUnresolvedReferences
        @cached_property
        def z(self):
            return async_meth(self)


# Generated at 2022-06-11 22:23:35.148345
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method ``__get__`` of class :obj:`cached_property`.
    """
    class TestClass:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.y + 1

    obj = TestClass(5)

    # Verify that the property has been computed
    assert obj.y == 6
    assert obj.z == 7

    # Verify that the property value is cached in the instance
    assert obj.__dict__['y'] == 6

    # Verify that the property value is cached in the class
    assert TestClass.y.__get__(obj, TestClass) == 6

    # Verify that the cached values are updated when an instance

# Generated at 2022-06-11 22:23:45.321680
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """ Unit test for method __get__ of class cached_property """
    # Completed: 2019-12-05T10:18:57.397765
    # Skipped: 2019-12-05T10:18:57.397977
    # The test is not yet implemented

    # Method: __get__
    # File: flutils/decorators.py
    # Type: classmethod
    # Test: <class 'flutils.decorators.cached_property'>
    # Line: 96
    from random import random

    class TestClass:

        def __init__(self):
            self.x = random()

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert (obj.y == obj.y)



# Generated at 2022-06-11 22:24:32.870649
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit testing for method __get__ of class cached_property
    """

    class Foo:

        @cached_property
        def bar(self):
            return "baz"

    obj = Foo()
    assert obj.bar == "baz"



# Generated at 2022-06-11 22:24:39.276008
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import unittest

    class Test(unittest.TestCase):
        def test__get__(self):
            class MyClass:

                def __init__(self):
                    self.x = 5

                @cached_property
                def y(self):
                    return self.x + 1

            obj = MyClass()
            self.assertEqual(obj.y, 6)
            class MyClass:

                def __init__(self):
                    self.x = 5

                @cached_property
                async def y(self):
                    return self.x + 1

            obj = MyClass()
            self.assertEqual(obj.y, 6)
            with self.assertRaises(AttributeError):
                del obj.y
            self.assertEqual(obj.y, 6)


# Generated at 2022-06-11 22:24:45.702676
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test for __get__ of class cached_property
    """

    class MyClass:
        # Define class variable
        # This should be in place of the @cached_property
        # decorator and allows unit testing
        __cached_property__ = cached_property

        def __init__(self):
            self.x = 5

        @__cached_property__
        def y(self):
            return self.x + 1

    m = MyClass()
    assert m.y == 6

# Generated at 2022-06-11 22:24:56.443578
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.misc import create_string
    from flutils.misc import Resource
    from flutils import get_ip_address

    same_ip = get_ip_address()

    class C(Resource):
        name = 'C'

        def __init__(self):
            self.x = 10
            self.ip = same_ip
            self.ip6 = same_ip
            self.ip_both = same_ip

        @cached_property
        def ip2(self):
            return get_ip_address()

        @cached_property
        def ip3(self):
            return get_ip_address(version=6)

        @cached_property
        def ip4(self):
            return get_ip_address(version=4)
