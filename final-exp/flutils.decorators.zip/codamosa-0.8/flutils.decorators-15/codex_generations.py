

# Generated at 2022-06-11 22:15:02.300780
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property
    """

    class A:

        def __init__(self, x):
            self.x = x

        @cached_property
        def prop(self):
            return self.x

    obj = A(5)
    assert obj.prop == 5
    assert obj.__dict__['prop'] == 5
    assert obj.prop == 5
    assert 'prop' in obj.__dict__

    del obj.prop
    assert 'prop' not in obj.__dict__


# Generated at 2022-06-11 22:15:06.163773
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-11 22:15:10.520173
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-11 22:15:20.539303
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import Mock

    obj = Mock(spec=cached_property)
    cls = Mock(spec=type)
    obj.__get__.return_value = 'This is a cached_property __get__ mock.'
    cls.__get__.return_value = 'This is a class __get__ mock.'

    assert cached_property.__get__(obj, cls) == 'This is a cached_property __get__ mock.'
    assert cached_property.__get__(obj, None) == 'This is a cached_property __get__ mock.'
    assert cached_property.__get__(None, cls) == 'This is a class __get__ mock.'

    assert obj.__get__.call_count == 2
    assert cls.__get__.call_count == 1

# Generated at 2022-06-11 22:15:32.362569
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test :meth:`~cached_property.__get__` of :class:`~cached_property`.

    """

    def test_function(obj):
        """
        Test function.

        See :class:`~cached_property` for more.

        """
        return 5

    # Test normal function
    test_cp = cached_property(test_function)
    assert test_cp.__get__(None, None) is test_cp
    assert test_cp.__name__ == test_function.__name__
    assert test_cp.__doc__ == test_function.__doc__

    obj = object()
    assert test_cp.__get__(obj, None) == test_function(obj)
    assert test_cp.__get__(obj, None) == test_function(obj)

# Generated at 2022-06-11 22:15:40.821053
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import Mock
    import pytest

    mockobj = Mock()
    mockfunc = Mock()

    for coro in (False, True):
        cp = cached_property(mockfunc)
        if coro:
            async def asyncfunc(*args, **kwargs):
                return mockfunc(*args, **kwargs)

            mockfunc.side_effect = asyncfunc
            cp.__get__(mockobj)()
        else:
            cp.__get__(mockobj)
      

# Generated at 2022-06-11 22:15:45.253610
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""

    # Set up the test data
    class Class:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Test the results
    obj = Class()
    assert obj.y == 6

# Generated at 2022-06-11 22:15:57.008348
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test cached_property__get__()"""
    import inspect
    import sys
    import unittest

    class c1(object):
        """Test class"""

        def __init__(self):
            self.x = 5
            self.y = None

        @cached_property
        def foo(self):
            self.y = self.x + 1
            return self.y

    class c2(c1):
        """Test class"""

    class c3(c2):
        """Test class"""

    class c4(c3):
        """Test class"""

    class c5(c4):
        """Test class"""

    class c6(c5):
        """Test class"""

        def __init__(self):
            self.x = 5
            self.y = None


# Generated at 2022-06-11 22:16:02.183145
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Power(object):
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            try:
                return self.x * 1
            except TypeError:
                return None

    power = Power(3)
    assert power.y == 3



# Generated at 2022-06-11 22:16:11.620848
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class C:
        def __init__(self, x=5):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    c1 = C()
    assert c1.y == 6
    c1.x = 10
    assert c1.y == 6
    del c1.y
    assert c1.y == 11

    # unit test for issue #2
    c2 = C(10)
    assert c2.y == 11
    c2.x = 5
    assert c2.y == 11
    del c2.y
    assert c2.y == 6



# Generated at 2022-06-11 22:16:23.973076
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        async def z(self):
            return self.x + 1

    obj = MyClass()

    # case 1: no obj, get class
    assert isinstance(MyClass.y, cached_property)

    # case 2: synchronous property
    assert isinstance(obj.y, int)
    assert obj.y == 6
    assert 'y' in obj.__dict__

    # case 3: asynchronous property
    # noinspection PyUnresolvedReferences
    if sys.version_info.minor >= 8:
        async def test():
            await obj.z


# Generated at 2022-06-11 22:16:27.973615
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    print("Test cached_property.__get__")
    class A:
        pass

    a = A()
    obj = cached_property(a)
    assert obj.__get__(1, 1) is obj
    obj.__get__()
    assert obj.__get__(1, 1) is obj



# Generated at 2022-06-11 22:16:37.436468
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method ``__get__`` of class ``cached_property``
    in the module ``flutils.decorators``. The decorator
    ``cached_property`` is tested.
    """
    import pytest

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    @cached_property
    def y():
        return MyClass().y

    class MyClassAsync:

        def __init__(self):
            self.x = 5

        @cached_property
        async def y(self):
            await asyncio.sleep(1)
            return self.x + 1

    @cached_property
    async def y2():
        await asyncio.sleep(1)


# Generated at 2022-06-11 22:16:48.680414
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import patch

    from flutils.decorators import cached_property

    # method __get__
    def test_1(mocker, monkeypatch):
        """cached_property.__get__() Called with a class obj.
        """

        # Setup
        class Test:
            @cached_property
            def x(self):
                return 5

        # Test
        monkeypatch.setattr(Test.x, '__get__', lambda _, o: o)
        assert Test.x is Test

    # method __get__
    def test_2(mocker, monkeypatch):
        """cached_property.__get__() Called with an instance obj.
        """

        # Setup
        class Test:
            @cached_property
            def x(self):
                return 5

        # Test

# Generated at 2022-06-11 22:16:52.723354
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 0

        @cached_property
        def y(self):
            self.x += 1
            return self.x

    obj = MyClass()
    assert obj.y is obj.y is 1

# Generated at 2022-06-11 22:17:01.793764
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property

    """
    from unittest.mock import patch

    class TestClass:
        def __init__(self, value):
            self._value = value

        @cached_property
        def my_property(self):
            return self._value

        @classmethod
        @cached_property
        def my_class_property(cls):
            return cls.__name__

    obj = TestClass(1)

    assert obj.my_property == 1
    assert obj.__dict__ == {'_value': 1, 'my_property': 1}

    assert TestClass.my_class_property == 'TestClass'

# Generated at 2022-06-11 22:17:04.395813
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert(obj.y == 6)


if __name__ == '__main__':
    test_cached_property___get__()

# Generated at 2022-06-11 22:17:05.470696
# Unit test for method __get__ of class cached_property

# Generated at 2022-06-11 22:17:17.030139
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import os
    import platform
    from pathlib import Path
    import pytest
    from flutils.decorators import cached_property

    class Demo:

        def __init__(self, value):
            self._value = value

        @cached_property
        def value(self):
            return self._value

    obj = Demo(5)
    value = getattr(obj, 'value')
    obj._value = 10
    assert value == 5
    assert obj.value == 10

    class WrongInput:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self, a):
            return self.x + a

    with pytest.raises(TypeError):
        WrongInput()


# Generated at 2022-06-11 22:17:25.797248
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method ``__get__`` of class ``cached_property``.

    *Added in version 0.2.0*

    """
    from unittest import TestCase
    from unittest.mock import patch, Mock

    class MyClass:

        @cached_property
        def y(self):
            return self.x + 1

    class TestCachedProperty(TestCase):

        def setUp(self):
            self.obj = MyClass()
            self.obj.x = 5

        def tearDown(self):
            self.obj = None

        def test_getattr(self):
            self.assertEqual(self.obj.y, 6)

        def test_get_from_dict(self):
            self.obj.__dict__["y"] = 7

# Generated at 2022-06-11 22:17:36.236829
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property
    from unittest.mock import Mock
    from unittest.mock import call

    func = Mock()

    func.__doc__ = sentinel_docstring = "a docstring"

    @cached_property
    def foo(self):
        return self.answer

    answer = 42
    self = Mock(answer=answer)

    assert foo.__get__(None, None) is foo

    result = foo.__get__(self, None)
    assert result == answer
    assert foo.__doc__ is sentinel_docstring
    self.assert_has_calls([call(self)])



# Generated at 2022-06-11 22:17:41.714900
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Test:
        def __init__(self):
            self.x = 0

        @cached_property
        def y(self):
            return self.x + 1

    obj = Test()
    assert obj.y == 1
    assert obj.__dict__['y'] == obj.y



# Generated at 2022-06-11 22:17:46.076398
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import asyncio
    from flutils.decorators import cached_property

    class C:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = C()
    assert obj.y == 6



# Generated at 2022-06-11 22:17:52.070644
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    print(obj.y)
    print(obj.y)
    print(obj.y)
    print(obj.y)
    # Delete the cached attribute
    del obj.y
    print(obj.y)


# Generated at 2022-06-11 22:17:59.076943
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class TestClass:
        def do_math(self):
            return 1 + 2

        @cached_property
        def test_property(self):
            return self.do_math()

    test_class = TestClass()

    assert test_class.test_property == 3

    # test that the property replaces itself with an attribute with the same name
    assert test_class.test_property == 3



# Generated at 2022-06-11 22:18:04.287184
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property


    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1


    obj = MyClass()
    val = obj.y
    assert val == 6
    assert obj.y == 6



# Generated at 2022-06-11 22:18:11.257465
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import MagicMock

    obj = MagicMock()
    obj.x = 5
    obj.__dict__.__setitem__ = MagicMock(return_value=42)

    # noinspection PyUnusedLocal
    class MyClass:
        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 42



# Generated at 2022-06-11 22:18:19.180631
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from collections.abc import Awaitable
    from unittest.mock import Mock
    from types import CoroutineType

    def test_function_called(mock_instance):
        mock_instance.__dict__ = {}
        property_ = cached_property(Mock(return_value=42))
        assert property_.func is property_.__get__(mock_instance, None)
        assert property_.func(mock_instance) == mock_instance.__dict__[
            property_.func.__name__
        ]
        assert (
            property_.func.__name__ in mock_instance.__dict__
        ), f"{property_.func.__name__} not in {mock_instance.__dict__}"

    test_function_called(Mock())


# Generated at 2022-06-11 22:18:22.791047
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class TestObject:
        @cached_property
        def property(self):
            if self.property == 5:
                return "cached"
            else:
                return 5

    obj = TestObject()
    obj.property


# Generated at 2022-06-11 22:18:31.664752
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """ This method tests the method __get__ of class cached_property

    """
    print(f'====> Starting {inspect.stack()[0][3]}')

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    expected = 6
    actual = obj.y
    assert actual == expected, f'expected: {expected}, ' \
        f'actual:   {actual}'

    print(f'====> Finished {inspect.stack()[0][3]}')


# Generated at 2022-06-11 22:18:45.324613
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property
    """

    import unittest
    from .test_constants import TEST_CONSTANTS

    class MyClass(object):

        def __init__(self, x=1):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    class MyClassAsync(object):

        def __init__(self, x=1):
            self.x = self.make_coro(x)

        def make_coro(self, x):
            return asyncio.coroutine(lambda: x)

        @cached_property
        def y(self):
            return self.x + 1


# Generated at 2022-06-11 22:18:54.709764
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        def y(self):
            return self.x
    my_obj = MyClass()
    obj = cached_property(my_obj.y)
    assert obj.__doc__ is None
    assert obj.func == my_obj.y
    actual = obj.__get__(my_obj, MyClass)
    assert actual == 5
    assert my_obj.__dict__ == {'x': 5, 'y': 5}
    actual = obj.__get__(None, MyClass)
    assert actual == obj
    assert my_obj.__dict__ == {'x': 5, 'y': 5}


# Generated at 2022-06-11 22:19:04.389812
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Test:
        def __init__(self):
            self.a = 10

        def _foo(self):
            return self.a * 2

        foo = cached_property(_foo)

    t = Test()
    assert t.foo == 20
    assert t.__dict__["foo"] == 20
    t.a = 20
    assert t.foo == 40
    assert t.__dict__["foo"] == 40
    t.foo = "bar"
    assert t.foo == "bar"
    assert t.__dict__["foo"] == "bar"


if __name__ == "__main__":
    test_cached_property___get__()

# Generated at 2022-06-11 22:19:15.571576
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from pathlib import Path
    import os
    import sys

    class test:
        @cached_property
        def x(self):
            return 2 + 2

        @cached_property
        def y(self):
            return 2 + 2

        @cached_property
        async def z(self):
            await asyncio.sleep(0.1)
            return 2 + 2

    obj = test()
    loop = asyncio.get_event_loop()
    future = asyncio.ensure_future(obj.z)
    assert future.done() is False
    loop.run_until_complete(future)
    assert future.done() is True
    assert obj.z == 4

    for dirname in ('examples', 'tests'):
        sys.path.append(Path.cwd().joinpath(dirname))


# Generated at 2022-06-11 22:19:17.441351
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass


if __name__ == "__main__":
    x = 5
    print(x)

# Generated at 2022-06-11 22:19:22.667031
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__['y'] == 6


# Generated at 2022-06-11 22:19:33.265528
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """This function tests method __get__ of class cached_property."""
    from datetime import datetime
    from pathlib import Path
    from os import remove
    from sys import stdout
    from tempfile import mkstemp
    from flutils.pathutils import PathPlus
    from flutils.stdoututils import TeeStdout
    from flutils.decorators import cached_property

    # Create the decorator
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Instance the class
    obj = MyClass()

    # Test functionality
    assert 6 == obj.y
    assert 6 == obj.y

    # =========================================================================
    # Test with stdout utils
    # =========================================================================

    #

# Generated at 2022-06-11 22:19:40.948301
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert 'y' in obj.__dict__
    del obj.y
    assert 'y' not in obj.__dict__
    assert obj.y == 6



# Generated at 2022-06-11 22:19:45.314324
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj = object()

    def func(obj_):
        assert obj_ is obj
        return obj

    prop = cached_property(func)
    assert prop.__get__(obj) is obj
    assert prop.__get__(None) is prop



# Generated at 2022-06-11 22:19:51.466115
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property.

    """
    import pytest

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6

# Generated at 2022-06-11 22:19:58.839131
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            self.x += 1
            return self.x

    obj = MyClass()
    assert obj.y == 6
    assert obj.y == 6



# Generated at 2022-06-11 22:20:09.251518
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property
    """

    msg_template = """
===========================
{}

Expected:   {}
Returned:   {}
Assertion:  {}
===========================

"""
    # Test case 1
    obj = MyClass()
    exp_value = 6
    ret_value = obj.y
    assert exp_value == ret_value, msg_template.format(
        'Method __get__ - Test case 1', exp_value, ret_value,
        'exp_value == ret_value'
    )

    # Test case 2
    obj = MyClass()
    exp_value = 6
    ret_value = obj.y

# Generated at 2022-06-11 22:20:19.567523
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Get the current value of the cached_property decorator.
    from flutils.decorators import cached_property
    from functools import cached_property as functools_cached_property

    # Set the value of the cached_property decorator to the built-in
    # functools_cached_property decorator.
    from unittest.mock import patch

    with patch("flutils.decorators.cached_property", functools_cached_property):

        # Class to be decorated.
        class MyClass:

            def __init__(self):
                self.x = 5

            @cached_property
            def y(self):
                return self.x + 1

        obj = MyClass()

        # Check that the decorated method is a functools_cached_property
        # object.
       

# Generated at 2022-06-11 22:20:29.529972
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from .io import get_logger

    logger = get_logger(__name__)

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    logger.debug(f"obj.y = {obj.y}")
    assert obj.y == 6
    logger.debug(f"obj.__dict__ = {obj.__dict__}")
    assert obj.__dict__['y'] == 6
    logger.debug(f"obj.x = {obj.x}")
    assert obj.x == 5

    obj.x = 25

    logger.debug(f"obj.x = {obj.x}")
    assert obj.x == 25


# Generated at 2022-06-11 22:20:35.715409
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Ctest:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    c = Ctest()
    assert c.y == 6
    assert c.y == 6
    c.x = 3
    assert c.y != 4
    del c.y



# Generated at 2022-06-11 22:20:47.249670
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import os
    import json
    import tempfile
    from collections import namedtuple

    # noinspection PyProtectedMember
    from flutils.decorators import cached_property

    test_dir = tempfile.TemporaryDirectory()

    class MyClass:

        def __init__(self):
            self._test_filename = os.path.join(test_dir.name, "test.txt")
            self._test_data = {"key": "value"}
            with open(self._test_filename, "w") as fh:
                json.dump(self._test_data, fh)

        @cached_property
        def test_data(self):
            with open(self._test_filename) as fh:
                return json.load(fh)

    obj = MyClass()

    assert os.path.isf

# Generated at 2022-06-11 22:20:51.018042
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert TestClass().y == 6



# Generated at 2022-06-11 22:21:00.736467
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # This is a basic test of the method __get__ of the class cached_property.
    # It tests the 'get' and 'set' functionality provided by the __get__
    # method.

    @cached_property
    def x(self):
        return 1

    class MyClass:
        pass

    obj = MyClass()
    assert hasattr(obj, 'x')
    assert not hasattr(obj, 'x')
    assert obj.__dict__['x'] == 1

    # Must be able to delete the attribute that is created by the cached
    # property.
    del obj.x
    assert not hasattr(obj, 'x')
    assert not hasattr(obj, 'x')
    assert 'x' not in obj.__dict__



# Generated at 2022-06-11 22:21:12.354413
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """ Test method __get__ of class cached_property.
    """

    # Setup
    class MyClass:

        def __init__(self):
            self.x = 0

        @cached_property
        def y(self):
            self.x += 1
            return self.x

    obj = MyClass()

    # Test
    output = obj.y
    assert output == 1
    assert obj.__dict__['y'] == 1
    assert obj.x == 1

    # Test
    output = obj.y
    assert output == 1
    assert obj.__dict__['y'] == 1
    assert obj.x == 1

    output = obj.y
    assert output == 1
    assert obj.__dict__['y'] == 1
    assert obj.x == 1



# Generated at 2022-06-11 22:21:20.121062
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest
    import asyncio
    import sys
    import os
    import types
    from contextlib import contextmanager

    # Mock out Python 3.8's functools.cached_property
    @contextmanager
    def mock_cached_property():
        cached_property_ = None
        if sys.version_info >= (3, 8):
            cached_property_ = types.SimpleNamespace(
                cached_property=functools.cached_property,
            )
            functools.cached_property = None

        try:
            yield cached_property_
        finally:
            if cached_property_:
                functools.cached_property = cached_property_.cached_property

    class MyClass:
        def __init__(self):
            self.x = 5


# Generated at 2022-06-11 22:21:30.865461
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def value(self):
            return self.x + 1

    obj = MyClass()
    obj.value
    assert obj.value == 6



# Generated at 2022-06-11 22:21:39.986775
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import TestCase, mock
    from functools import partial

    class MyClass:
        def __init__(self, testcase):
            self.testcase = testcase
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    testcase = TestCase()
    obj = MyClass(testcase)
    testcase.assertEqual(obj.y, 6)
    testcase.assertEqual(obj.y, 6)
    testcase.assertEqual(obj.__dict__['y'], 6)
    del obj.y
    testcase.assertEqual(obj.y, 6)
    testcase.assertEqual(obj.__dict__['y'], 6)


# Generated at 2022-06-11 22:21:46.395813
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import TestCase

    from flutils.decorators import cached_property


    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert isinstance(obj.y, int)



# Generated at 2022-06-11 22:21:48.336805
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    tests = [
        [1]
    ]

    for count, test in enumerate(tests, start=1):
        pass



# Generated at 2022-06-11 22:21:51.729183
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    x = MyClass()

    assert x.y == 6
    assert x.y == 6
    del x.y
    assert x.y == 6



# Generated at 2022-06-11 22:21:56.768830
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class GetTest:
        def __init__(self):
            self.x = 2

        @cached_property
        def y(self):
            return self.x + 1

    obj = GetTest()
    assert obj.y == 3
    assert obj.__dict__['y'] == 3


# Generated at 2022-06-11 22:22:04.087399
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test method __get__ of class cached_property."""

    # Test property is available
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y
    assert obj.y == 6

    # Test property is a coroutine
    class AsyncMyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        async def y(self):
            return self.x + 1

    aobj = AsyncMyClass()
    assert isinstance(aobj.y, Coroutine)
    assert aobj.y == 6

# Generated at 2022-06-11 22:22:05.658643
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    @cached_property
    def x():
        return 5

    assert x == 5

# Generated at 2022-06-11 22:22:09.113809
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-11 22:22:19.438939
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class A:
        def __init__(self, x):
            self.x = x

        # noinspection PyUnusedLocal
        @cached_property
        def y(self):
            import random
            return random.randint(0, 1000)

    a1 = A(1)
    a1.y  # this generates a random value
    assert a1.y == a1.y  # using @cached_property guarantees value is deterministic

    a2 = A(2)
    assert a2.y != a1.y  # a2 gets its own random value, different from a1.y

    del a1.y  # invalidate cached value so new random value is generated
    assert a1.y != a1.y

# Generated at 2022-06-11 22:22:37.842840
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class T:
        @cached_property
        def f(self):
            return 1
        @cached_property
        def g(self):
            return 2

    # pylint: disable=invalid-name
    # noinspection SpellCheckingInspection
    t = T()
    assert t.f == 1
    assert t.g == 2
    assert T.f.__doc__ == 'f'
    assert T.g.__doc__ == 'g'
    assert T.f.__get__(t, T) == 1
    assert t.__dict__ == {'f': 1, 'g': 2}



# Generated at 2022-06-11 22:22:47.670452
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # Test for property that is not a coroutine.
    class A:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = A()
    y = obj.y
    assert y == 6

    # Test for property that is a coroutine.
    async def async_func():
        return 6

    class B:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return async_func()

    obj = B()
    y = obj.y
    assert y == 6

# Generated at 2022-06-11 22:22:51.981023
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    '''
    Test method __get__ of class cached_propert.
    '''
    counter = 0

    class TestClass:

        @cached_property
        def some_var(self):
            nonlocal counter
            counter += 1
            return counter

    test_obj = TestClass()

    assert test_obj.some_var == 1
    assert test_obj.some_var == 1

if __name__ == '__main__':
    test_cached_property___get__()

# Generated at 2022-06-11 22:22:53.172115
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import doctest

    doctest.testmod(verbose=False)

# Generated at 2022-06-11 22:23:00.011600
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__["y"] == 6



# Generated at 2022-06-11 22:23:04.091284
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestClass(object):

        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    from types import FunctionType
    obj = TestClass(5)
    res = obj.y
    assert res == 6
    assert type(obj.__dict__['y']) == int


# Generated at 2022-06-11 22:23:06.794629
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Method not tested, because it's well tested by class Test_cached_property
    # Tests are in test file tst_decorators.py
    pass



# Generated at 2022-06-11 22:23:11.075783
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class C:

        @cached_property
        def x(self):
            return 1

    c = C()
    assert c.x == 1
    assert c.__dict__["x"] == 1



# Generated at 2022-06-11 22:23:14.746344
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from inspect import iscoroutinefunction

    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    i = TestClass()

    assert i.x == 5
    assert i.y == 6



# Generated at 2022-06-11 22:23:24.051438
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest
    from flutils import decorators

    class TestClass:
        @decorators.cached_property
        def test_cached_property(self):
            return 'test_cached_property'

        @asyncio.coroutine
        @decorators.cached_property
        def test_cached_coroutine_property(self):
            return 'test_cached_coroutine_property'

    test_obj = TestClass()
    assert test_obj.test_cached_property == 'test_cached_property'
    with pytest.raises(AttributeError, match=r"\btest_cached_property\b"):
        del test_obj.test_cached_property
    assert test_obj.test_cached_property == 'test_cached_property'

# Generated at 2022-06-11 22:23:49.320739
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""

    from datetime import datetime

    class MyClass:
        @cached_property
        def now(self):
            return datetime.utcnow()

    obj = MyClass()
    assert obj.now == obj.now

# Generated at 2022-06-11 22:23:57.555183
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    TEST_RESULT = 'TEST RESULT'
    TEST_RESULT_CORO = 'TEST RESULT CORO'
    TEST_ERR_CORO = 'TEST ERROR CORO'

    class MyClass:

        def __init__(self):
            self._x = 5

        @cached_property
        def test1(self):
            return self._x + 1

        @cached_property
        def test2(self):
            raise NotImplementedError

        @cached_property
        def test3(self):
            return self._x + 1

        @cached_property
        def test4(self):
            return self._x + 1

        @cached_property
        def test5(self):
            return self._x + 1


# Generated at 2022-06-11 22:24:02.732385
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Example:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Example()
    obj.y

    assert obj.y == 6
    assert obj.__dict__['y'] == 6



# Generated at 2022-06-11 22:24:09.070941
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Tests for method __get__ of class cached_property"""

    # -------------------------------------------------------------------------
    # Test for docstring
    # -------------------------------------------------------------------------
    obj = cached_property(lambda x: 0)

    assert obj.__doc__ is None

    # -------------------------------------------------------------------------
    # Test for class method __get__
    # -------------------------------------------------------------------------
    assert type(cached_property.__get__(obj, type)) is classmethod
    assert type(cached_property.__get__(None, type)) is classmethod

    # -------------------------------------------------------------------------
    # Test for instance method __get__
    # -------------------------------------------------------------------------
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self

# Generated at 2022-06-11 22:24:11.791899
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Setup
    c = MyClass()
    c.x = 10
    # Exercise
    # Verify
    assert c.y == c.x + c.y2
    assert c.y ==  c.x + c.y2
    assert c.y2 == c.y2
    assert c.y3 != c.y3
    assert c.y3 != c.y3

# Generated at 2022-06-11 22:24:20.228917
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test cached_property.__get__."""
    from flutils.decorators import cached_property as testee

    class MyClass:
        """A test class."""

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """The y property."""
            return self.x + 1

    # -------------------------------------------------------------------------
    # Non-existing property
    # -------------------------------------------------------------------------
    obj = MyClass()

    result = testee.__get__(obj, MyClass)
    assert isinstance(result, testee)

    # -------------------------------------------------------------------------
    # Existing property
    # -------------------------------------------------------------------------
    result = testee.__get__(obj, MyClass)
    assert isinstance(result, int)
    assert result == obj.y

# Generated at 2022-06-11 22:24:26.156897
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.miscutils import timeit

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    with timeit():
        assert obj.y == 6

    assert obj.y is 6



# Generated at 2022-06-11 22:24:35.121563
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test :func:`flutils.decorators.cached_property.cached_property.__get__`
    method

    """
    from unittest import mock

    class TestClass(object):
        """Class for testing cached_property.__get__"""

        def __init__(self, *args, **kwargs):
            """Init the class

            Sets x to 5

            """
            self.x = 5

        @cached_property
        def y(self, *args, **kwargs):
            """Returns x + 1

            """
            return self.x + 1

    obj = TestClass()
    assert isinstance(obj, TestClass)

    assert obj.y == 6
    assert obj.__dict__['y'] == 6


# Generated at 2022-06-11 22:24:36.121041
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass



# Generated at 2022-06-11 22:24:42.493229
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property


    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1


    obj = MyClass()
    assert obj.y == 6