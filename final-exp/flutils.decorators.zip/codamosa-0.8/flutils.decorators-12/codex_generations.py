

# Generated at 2022-06-11 22:15:04.566248
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import Mock

    class MyClass:

        def __init__(self):
            self.x = 5
            self.y = Mock()

        @cached_property
        def z(self):
            self.y(self.x)
            return self.x + 1

    return_value = MyClass().z
    assert return_value == 6
    assert MyClass.z.__doc__ == 'A property decorator that is only computed ' \
                                'once per instance and then replaces itself ' \
                                'with an ordinary attribute.\n\nDeleting the ' \
                                'attribute resets the property.\n\nNote:\n' \
                                '    In Python 3.8 the ' \
                                ':obj:`functools.cached_property` ' \
                               

# Generated at 2022-06-11 22:15:16.595683
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test for cached_property.__get__"""
    import unittest

    from unittest.mock import patch

    from flutils.decorators import cached_property

    class MockObj(object):
        """Mock object for testing property."""

        def __init__(self):
            self.prop_name = 'mock_property'

        @cached_property
        def mock_property(self):
            return self.prop_name

    class TestCachedProperty(unittest.TestCase):
        """Unit test for cached_property.__get__.

        *New in version 0.2.0*

        """

        def test_cached_property___get__(self):
            """Test for cached_property.__get__.

            *New in version 0.2.0*

            """

# Generated at 2022-06-11 22:15:23.480287
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for cached_property.

    """
    run_tests = False
    if run_tests:
        from unittest.mock import patch

        from flutils.decorators import cached_property

        class MyClass:
            @patch('__main__.MyClass.method1')
            def method1(self, mock_method1):
                mock_method1.return_value = 10
                return mock_method1.return_value

        MyClass.method1 = cached_property(MyClass.method1)

        obj = MyClass()

        assert obj.method1 == 10
        assert obj.__dict__['method1'] == 10
        assert obj.method1 == 10
        assert obj.__dict__['method1'] == 10



# Generated at 2022-06-11 22:15:33.826707
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    '''
    unit test:
        Using 3.8.2
    '''
    # self.func = func
    # self.__doc__ = getattr(func, "__doc__")

    def func(obj):
        print("function")
        return 6

    c = cached_property(func)
    # print(c.__dict__)
    assert isinstance(c, cached_property)
    assert c.__dict__["func"] == func
    assert c.__doc__ == func.__doc__

    # if obj is None:
    #     return self
    # if asyncio.iscoroutinefunction(self.func):
    #     return self._wrap_in_coroutine(obj)
    # value = obj.__dict__[self.func.__name__] = self.func(obj)
    #

# Generated at 2022-06-11 22:15:40.207932
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import AsyncMock, Mock, patch

    @patch('asyncio.ensure_future', new=AsyncMock())
    @patch('asyncio.iscoroutinefunction')
    class Test:

        def __init__(self):
            self.x = 123

        @cached_property
        def y(self):
            return self.x + 1

    test = Test()
    assert test.__dict__ == {}
    assert test.y
    y_asyncio_mock = AsyncMock()
    y_asyncio_mock.return_value = y_asyncio_mock

# Generated at 2022-06-11 22:15:48.096909
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import TestCase, mock

    class MyClass:

        def __init__(self):
            self.mock = mock.Mock()

        @cached_property
        def my_property(self):
            return self.mock()

    class Test_cached_property___get__(TestCase):
        def setUp(self):
            self.obj = MyClass()

        def test_first_time_property_is_accessed(self):
            self.assertEqual(self.obj.my_property, self.obj.mock.return_value)

        def test_second_time_property_is_accessed(self):
            self.obj.my_property
            self.obj.my_property

# Generated at 2022-06-11 22:15:54.940914
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from ..decorators import cached_property

    t = 0

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            nonlocal t
            t += 1
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert t == 1



# Generated at 2022-06-11 22:16:05.945451
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from .mocks.classes import Car  # pylint: disable=import-outside-toplevel

    car = Car(gas_level=10)

    assert car.get_gas_level == 10
    assert car.get_gas_level == 10
    assert car.get_gas_level == 10
    assert car.get_gas_level == 10
    assert car.get_gas_level == 10

    car.gas_level = 8
    assert car.get_gas_level == 8

    del car.get_gas_level
    assert car.get_gas_level == 8

    car.fill_up()
    assert car.get_gas_level == 10
    assert car.get_gas_level == 10
    assert car.get_gas_level == 10
    assert car.get_gas_level == 10
    assert car

# Generated at 2022-06-11 22:16:12.139844
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest

    from flutils.decorators import cached_property

    class Foo:

        @cached_property
        def x(self):
            return 1

    foo = Foo()

    assert foo.x == 1
    assert foo.__dict__ == {'x': 1}

    @cached_property
    def y():
        return 2

    pytest.raises(TypeError, y)



# Generated at 2022-06-11 22:16:18.470062
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test cached_property.__get__ method."""

    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-11 22:16:30.365996
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import sys
    import unittest
    from typing import Optional

    # noinspection PyPep8Naming
    class TestCachedProperty___Get__(unittest.TestCase):

        # noinspection PyPep8Naming
        @cached_property
        def y(self):
            return 5

    obj = TestCachedProperty___Get__()

    def run_tests(self, obj, expected):
        self.assertEqual(obj.y, expected)
        self.assertEqual(obj.__dict__['y'], expected)

    if sys.version_info >= (3, 6):
        from unittest.mock import patch
        from contextlib import contextmanager


# Generated at 2022-06-11 22:16:39.577229
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """ Unit test for the method cache_property.__get__ """

    # First test class with sync methods
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    # Now test class with async methods
    class Anotherclass:

        def __init__(self):
            self.x = 5

        @cached_property
        async def y(self):
            await asyncio.sleep(0.5)
            return self.x + 1

    obj2 = Anotherclass()
    loop = asyncio.get_event_loop()
    loop.run_until_complete(obj2.y)
    assert obj2.y == 6

    # Display test

# Generated at 2022-06-11 22:16:44.723451
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestCachedProperty___get__:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestCachedProperty___get__()
    assert obj.y == 6
    assert obj.__dict__['y'] == 6
    assert obj.y == 6



# Generated at 2022-06-11 22:16:51.010787
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import TestCase

    class TestObj(TestCase):
        def __init__(self):
            self.data = {}

        @cached_property
        def data(self):
            return {'foo': 'bar'}

    obj_data = TestObj().data
    assert obj_data['foo'] == 'bar'

# Generated at 2022-06-11 22:16:57.899443
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Test:
        @cached_property
        def y(self):
            return self.x + 1

        def __init__(self, x0):
            self.x = x0

    obj = Test(5)
    assert obj.y == 6
    assert obj.__dict__['y'] == 6
    assert obj.__dict__['y'] is obj.__dict__['y']
    obj.x = 6
    assert obj.y == 7
    assert obj.__dict__['y'] == 6

# Generated at 2022-06-11 22:17:09.068430
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property
    import asyncio

    class Test:

        def __init__(self):
            self.x = 5
            self.schema = 'test'

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        async def z(self):
            print(f'fetching {self.schema}')
            await asyncio.sleep(1)
            return f'test {self.schema}'

        @cached_property
        def __call__(self):
            return '__call__'

    obj = Test()
    assert obj.y == 6
    assert obj.__call__() == '__call__'

    loop = asyncio.get_event_loop()
    loop.run_until_complete

# Generated at 2022-06-11 22:17:15.790835
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class C:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    c = C()

    # First call
    assert c.y == 6

    # Second call(s)
    assert c.y == 6
    assert c.y == 6

    # Deleting resets the property
    del c.y
    assert c.y == 6

    return



# Generated at 2022-06-11 22:17:24.029966
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # Class with a cached_property function that returns a future
    class Foo:

        def __init__(self, value):
            self._value = value

        @cached_property
        def name(self):
            return self._value

    # Create a Foo instance
    foo = Foo('foo')

    # Assert that the property is a coroutine
    assert asyncio.iscoroutinefunction(foo.name)

    # Execute the coroutine
    future = asyncio.ensure_future(foo.name)

    # Get the value of the future
    assert 'foo' == future.result()

    # Assert that the property is a future
    assert isinstance(foo.name, asyncio.Future)

# Generated at 2022-06-11 22:17:28.884664
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


# Generated at 2022-06-11 22:17:39.491348
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5
            self._y = None

        @cached_property
        def y(self):
            self._y = self.x + 1
            return self._y

    obj = MyClass()
    assert obj.__dict__["_y"] is None
    assert obj.y == 6
    assert obj.__dict__["_y"] == 6
    assert "y" not in obj.__dict__
    del obj.__dict__["_y"]
    assert "y" not in obj.__dict__
    assert obj.__dict__["_y"] is None

    obj.__dict__["y"] = "monkey"
    assert "y" in obj.__dict__
    assert obj.y == "monkey"

# Generated at 2022-06-11 22:17:50.241618
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from functools import singledispatch, partial
    from operator import add
    from types import MethodType
    from unittest import mock

    @mocked_class
    @cached_property
    def class_behavior_mock(cls, func):
        if isinstance(func, MethodType):
            cls.func = func.__func__
        else:
            cls.func = None
        return func

    @mocked_class
    @cached_property
    def class_behavior_mock_async(cls, func):
        if isinstance(func, MethodType):
            cls.func = func.__func__
        else:
            cls.func = None
        return func


# Generated at 2022-06-11 22:18:01.798858
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import sys

    python_version = sys.version_info[:2]

    if python_version == (3, 8):
        from functools import cached_property as _cached_property

        def _test_cached_property(cls: Any):
            assert cls().y == 6

        _test_cached_property.cached_property = _cached_property

        return _test_cached_property

    else:
        class MyClass:

            def __init__(self):
                self.x = 5

            @cached_property
            def y(self):
                return self.x + 1

        def _test_cached_property(_):
            assert MyClass().y == 6

        return _test_cached_property



# Generated at 2022-06-11 22:18:08.396410
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 0

        @cached_property
        def y(self):
            self.x += 1
            return self.x

    obj = MyClass()

    assert obj.y == 1
    assert obj.y == 1
    assert obj.__dict__['y'] == 1

    del obj.y
    assert obj.y == 2



# Generated at 2022-06-11 22:18:12.746552
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-11 22:18:21.772814
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Cat:

        def __init__(self, name="Fluffy", age=3):
            self.name = name
            self.age = age

        @cached_property
        def miau(self):
            return f"{self.name} says: MIAUAAAAAAA!!!"

    tom = Cat("Tom")
    assert tom.miau == "Tom says: MIAUAAAAAAA!!!"
    assert isinstance(tom.miau, str)

    # Now delete the property and set it again
    del tom.miau
    assert tom.miau == "Tom says: MIAUAAAAAAA!!!"



# Generated at 2022-06-11 22:18:32.047014
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit tests for method ``__get__`` of class ``cached_property``

    Asserting following conditions:
        - self.__doc__ = getattr(func, "__doc__")
        - self.func = func
        - obj value set
    """

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    # Now test the docstring
    assert MyClass.y.__doc__ == 'Returns self.x + 1'

    # Now test that deleting the property works
    del obj.y
    assert obj.y == 6



# Generated at 2022-06-11 22:18:40.802231
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:
        @cached_property
        def x(self):
            return self.y

        @cached_property
        def y(self):
            return 2

    instance = MyClass()
    assert instance.x == 2

    with pytest.raises(RuntimeError):
        instance.x = 5

    with pytest.raises(KeyError):
        del instance.x


# Generated at 2022-06-11 22:18:44.089676
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Foo:
        x = 1

        @cached_property
        def x(self):
            return self.__class__.x + 1

    foo = Foo()
    assert foo.x == 2
    assert foo.x == 2
    assert foo.x == 2



# Generated at 2022-06-11 22:18:54.611917
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    from importlib import import_module

    from flutils.utils import ignore

    from . import cached_property

    from testutils import get_function_name

    from flutils.testutils import run_tests

    module = import_module(cached_property.__module__)

    module_name = get_function_name(module)

    with ignore(Exception):
        assert module_name == "flutils.decorators"

    with ignore(Exception):
        cp = cached_property.cached_property(lambda x: x)

    with ignore(Exception):
        assert hasattr(cp, '__doc__')

    with ignore(Exception):
        assert cp.__doc__ == getattr(lambda x: x, "__doc__")

    with ignore(Exception):
        assert cp.__doc__


# Generated at 2022-06-11 22:19:05.588798
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Tests cached_property when the property is a function, not a coroutine

    class TestObj:
        def __init__(self):
            self.x = 10

        @cached_property
        def y(self):
            return self.x + 1

    test_obj = TestObj()
    assert test_obj.y == 11
    assert test_obj.__dict__["y"] == 11


async def test_cached_property___get__coro():
    # Tests cached_property when the property is a coroutine

    class TestObj2:
        def __init__(self):
            self.x = 10

        @cached_property
        async def y(self):
            return self.x + 1

    test_obj2 = TestObj2()
    result = await test_obj2.y

# Generated at 2022-06-11 22:19:12.151478
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # pylint: disable=unused-argument,invalid-name

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-11 22:19:24.007136
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    from decimal import Decimal
    from pytest import mark
    from unittest.mock import Mock

    from flutils.decorators import cached_property

    @mark.asyncio
    async def test_cached_property_async_get():

        class MyClass:
            @cached_property
            async def my_async_property(self):
                return "my_async_property_value"

        my_obj = MyClass()
        assert (await my_obj.my_async_property) == "my_async_property_value"

    def test_cached_property_calls_mocked_method_once():
        my_obj = Mock()

        class MyClass:
            @cached_property
            def my_property(self):
                my_obj.my_method()
               

# Generated at 2022-06-11 22:19:28.300707
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass(object):
        @cached_property
        def y(self):
            return 'y'

    obj = MyClass()
    result = obj.y
    assert result == 'y'
    assert obj.y == 'y'
    assert obj.__dict__['y'] == 'y'



# Generated at 2022-06-11 22:19:31.332920
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert MyClass().y == 6, 'MyClass().y should be 6'


# Generated at 2022-06-11 22:19:39.268880
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():  # noqa: D103, D413
    import pytest

    from flutils.decorators import cached_property

    @cached_property
    def y(self):
        return self.x + 1

    class MyClass:
        def __init__(self):
            self.x = 5

    # Test regular function
    obj = MyClass()
    assert y.__get__(obj, obj) == 6

    # Test regular function
    obj = MyClass()
    assert y.__get__(obj, obj) == 6

    # Test regular function
    obj = MyClass()
    assert y.__get__(obj, obj) == 6

    # Test property
    obj = MyClass()
    assert obj.y == 6

    # Test property - no change
    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-11 22:19:44.382896
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test for class cached_property.

    Tests for method __get__ of class cached_property.
    """

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


# Generated at 2022-06-11 22:19:50.753116
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert isinstance(obj.y, int)
    assert obj.y == 6

# Generated at 2022-06-11 22:20:01.030542
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Python 3.5 and 3.6
    # noinspection PyProtectedMember
    if sys.version_info[:2] in [(3, 5), (3, 6)]:
        # Test attribute access
        obj = MyClass()
        # noinspection PyUnresolvedReferences
        assert obj._a is 0
        # noinspection PyUnresolvedReferences
        assert obj._b is None
        # noinspection PyUnresolvedReferences
        assert obj._c is None

        obj.a
        # noinspection PyUnresolvedReferences
        assert obj._a is 0
        # noinspection PyUnresolvedReferences
        assert obj._b is None
        # noinspection PyUnresolvedReferences
        assert obj._c is None

        # access a property, cached_property is called, value stored in obj.__dict__
       

# Generated at 2022-06-11 22:20:05.209803
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass1:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj1 = MyClass1()
    assert obj1.y == 6



# Generated at 2022-06-11 22:20:17.511891
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method ``__get__`` of class :obj:`~flutils.decorators.cached_property`."""

    from flutils.test import TestCase
    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class Test:
        def __init__(self):
            pass

    class TestCachedProperty(TestCase):

        def test_cached_property_class(self):
            self.assertEqual("y", MyClass.y.__name__)

        def test_cached_property_doc_string(self):
            """Test cached_property doc string."""

# Generated at 2022-06-11 22:20:26.307307
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property

    """

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-11 22:20:37.590976
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class _MyClass(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x + 1

    # Test with the class _MyClass with asyncio.iscoroutinefunction returning
    # False.
    obj = _MyClass()
    assert obj.y == 6
    del obj.y
    assert obj.y == 6
    assert obj.x == 5

    # Test with the class _MyClass with asyncio.iscoroutinefunction returning
    # True.
    obj.x = 7
    assert obj.z == 8
    del obj.z
    assert obj.z == 8
    assert obj.x == 7



# Generated at 2022-06-11 22:20:48.779469
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # Example from the documentation above
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    # Example of a coroutine
    class MyClass2:

        def __init__(self):
            self.x = 5

        @cached_property
        @asyncio.coroutine
        def y(self):
            return self.x + 1

    obj2 = MyClass2()
    obj2.y
    assert asyncio.iscoroutine(obj2.y)
    result = obj2.y.send(None)
    assert result == 6

    # Example where the function is not a coroutine

# Generated at 2022-06-11 22:20:53.503505
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestObject:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    t = TestObject()
    assert t.y == 6

# Generated at 2022-06-11 22:20:57.593006
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-11 22:21:02.417065
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from .ulid import ulid
    from .contexts import cached_property_test_context
    from .helpers import is_callable

    obj = cached_property_test_context()

    test = obj.__get__(obj, ulid)
    assert test.ulid == obj.ulid
    assert not is_callable(test)

    test = obj.__get__(None, ulid)
    assert test.ulid == obj.ulid
    assert is_callable(test)

# Generated at 2022-06-11 22:21:12.409086
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # pylint: disable=unused-import,redefined-outer-name,unused-variable
    import pytest
    import asyncio
    from flutils.decorators import cached_property

    class Obj:
        def __init__(self):
            self.x = 500

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return asyncio.sleep(.1, result=self.x + 1)

    obj = Obj()
    assert obj.y == 501
    assert obj.__dict__["y"] == 501
    assert type(obj.z) is asyncio.Future

    return True



# Generated at 2022-06-11 22:21:20.015028
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import TestCase

    class Testcached_property(TestCase):

        def setUp(self):

            class Foo:
                def __init__(self):
                    self.x = None

                @cached_property
                def y(self):
                    return self.x

            self.foo = Foo()

        def test_cached_property___get___attribute_deleted(self):
            self.foo.y
            del self.foo.y
            self.assertRaises(AttributeError, getattr, self.foo, 'y')
            assert 'y' not in self.foo.__dict__

        def test_cached_property___get___assignment(self):
            self.foo.x = 2
            y = self.foo.y
            self.assertEqual(y, 2)
            z = self

# Generated at 2022-06-11 22:21:24.360219
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6



# Generated at 2022-06-11 22:21:25.314665
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # unit tested in tests/test_decorators.py
    pass

# Generated at 2022-06-11 22:21:38.607668
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestC:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    tc = TestC()
    assert tc.y == 6



# Generated at 2022-06-11 22:21:50.044483
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """ Unit test for method __get__ of class cached_property """

    class Class:

        def func(self):
            return True

    instance = Class()

    # Test 1: No object
    value = cached_property.__get__(None, Class)
    assert inspect.isclass(value)
    assert isinstance(value, cached_property)

    # Test 2: Correct object, function is not a coroutine
    value = cached_property.__get__(instance, Class)
    assert callable(value)
    assert value()

    # Test 3: Correct object, function is a coroutine
    instance = Class()
    instance.func = asyncio.coroutine(lambda x: True)
    value = cached_property.__get__(instance, Class)
    assert callable(value)
    loop = asyncio.get_event_

# Generated at 2022-06-11 22:21:59.502129
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Obj:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x + 2

    o = Obj()
    assert o.y == 6
    assert o.z == 7

    # Verify that the cached result is used again if called a 2nd time
    o.x = 20
    assert o.y == 6
    assert o.z == 7

    # Verify that we get a new result if we delete the cached property
    del o.y
    assert o.y == 21

# Generated at 2022-06-11 22:22:08.076879
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        @cached_property
        def y(self):
            return self.x + 2

    a = MyClass()
    a.x = 5
    y = a.y

    del a.y

    a.x = 7
    y = a.y

    a.__dict__.clear()
    a.x = 9
    y = a.y

    assert y == 12
    assert a.y == 12


# TODO: Write test for method _wrap_in_coroutine of class cached_property



# Generated at 2022-06-11 22:22:11.729857
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestClass:
        @cached_property
        def x(self):
            self.y = 1
            return self.y

    tc = TestClass()
    assert tc.x == 1
    assert tc.y == 1



# Generated at 2022-06-11 22:22:22.335532
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Setup
    test_class1 = type('TestClass1', (object,), {})
    test_class2 = type('TestClass2', (object,), {})
    test_instance1 = test_class1()
    test_instance2 = test_class2()
    c_property1 = cached_property(lambda obj: 1)
    c_property2 = cached_property(lambda obj: 2)

    assert c_property1.__get__(test_instance1) == 1
    assert c_property2.__get__(test_instance2) == 2
    assert c_property1.__get__(None, test_instance1) is c_property1
    assert c_property2.__get__(None, test_instance2) is c_property2

# Generated at 2022-06-11 22:22:25.260041
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cp = cached_property(getattr)
    assert cp.__get__(None, None) == getattr



# Generated at 2022-06-11 22:22:30.498769
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    # Test attribute not created yet
    assert not hasattr(obj, 'y')

    # Test value is calculated and attribute created
    assert obj.y == 6
    assert hasattr(obj, 'y')



# Generated at 2022-06-11 22:22:34.594871
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass(object):
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return 5

    obj = MyClass(1)
    y = obj.y
    assert y == 5



# Generated at 2022-06-11 22:22:38.843553
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    print(MyClass.__dict__)
    print(MyClass.__dict__['y'].__get__(obj, MyClass))



# Generated at 2022-06-11 22:23:05.994533
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Tests for cached_property.__get__"""
    import pytest
    import asyncio
    import pprint

    # IF YOU CAN NOT SEE THE DIFFERENCE: THE FIRST CASE (NON ASYNC) IS
    # DIFFERENT - IN THE FIRST CASE THE SECOND CALL OF THE METHOD IS
    # NOT GOING THROUGH THE DESCRIPTOR, BECAUSE THE PROPERTY HAS BEEN
    # ADDED TO THE INSTANCE DICT

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return asyncio.sleep(2, result=self.x + 1)


# Generated at 2022-06-11 22:23:12.761608
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    expected_result = "abcd"

    class TestClass:

        def __init__(self, x: str) -> None:
            self.x = x

        @cached_property
        def test_method(self) -> str:
            return self.x

    obj = TestClass(x="abcd")
    result = obj.test_method
    assert result == expected_result



# Generated at 2022-06-11 22:23:22.873449
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5
            self.y = None
            self.y_count = 0

        @cached_property
        def y(self):
            self.y_count += 1
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.y_count == 1
    assert obj.y == 6
    assert obj.y_count == 1

    obj.x = 6
    assert obj.y == 6
    assert obj.y_count == 1

    obj.__dict__["x"] = 7
    assert obj.y == 7
    assert obj.y_count == 1

    obj.__dict__["y"] = 8
    assert obj.y == 8
    assert obj.y_count == 1


# Generated at 2022-06-11 22:23:29.547228
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class A:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = A()
    assert obj.y == 6
    assert obj.y == 6



# Generated at 2022-06-11 22:23:32.199587
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import patch

    obj = cached_property(lambda: 1)
    obj.func = None
    assert None == obj.__get__(obj, obj)



# Generated at 2022-06-11 22:23:44.441807
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import Mock
    from unittest.mock import patch

    # Setup - create mock property
    mock_obj = Mock()
    mock_func = Mock(spec=cached_property.func.__get__)
    mock_func.return_value = 5
    mock_prop = cached_property(mock_func)

    # Test - normal usage
    assert mock_prop.__get__(mock_obj) == 5
    mock_func.assert_called_once_with(mock_obj)

    # Test - get docstring
    assert mock_prop.__doc__ is None

    # Test - call with class
    mock_cls = Mock()
    mock_prop.__get__(mock_cls) is mock_prop

    # Test - call for coroutine
    mock_prop

# Generated at 2022-06-11 22:23:52.006162
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method ``__get__`` of class ``cached_property``."""

    # -------------------------
    # Test case #1
    # -------------------------
    class MyClass:

        def __init__(self):
            self.x = 1

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 2

    # -------------------------
    # Test case #2
    # -------------------------
    class MyClass:

        def __init__(self):
            self.x = 1

        @cached_property
        def y(self):
            return self.x + 2

    obj = MyClass()
    assert obj.y == 3

    # -------------------------
    # Test case #3
    # -------------------------

# Generated at 2022-06-11 22:23:56.741537
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    methods_attributes = (
        ('_normal_method', '_normal_method'),
        ('_coroutine_method', '_wrap_in_coroutine'),
    )
    test_str = "Test cached_property class got correct method: {0}."
    c = cached_property
    for method, expected in methods_attributes:
        obj = c(method)
        # noinspection PyProtectedMember
        assert obj.__get__(obj, c) == getattr(c, expected), test_str.format(method)

# Generated at 2022-06-11 22:24:00.244220
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class A:
        @cached_property
        def x(self):
            return 12

    a = A()
    assert a.x == 12
    del a.x
    assert a.x == 12



# Generated at 2022-06-11 22:24:04.392927
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    obj.x = 6
    assert obj.y == 6

# Generated at 2022-06-11 22:24:54.847921
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property

    This is just a basic test, not a comprehensive test of the
    functionality.

    """

    class A:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = A()

    assert obj.y == 6

    obj.x = 10

    assert obj.y == 11



# Generated at 2022-06-11 22:24:57.345649
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    print("Testing method __get__ of class cached_property:")
    obj = MyClass()
    print(obj.y)
    print("Completed test")

