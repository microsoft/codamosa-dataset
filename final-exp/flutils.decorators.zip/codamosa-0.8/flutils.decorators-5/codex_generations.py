

# Generated at 2022-06-11 22:14:58.860372
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        @cached_property
        def x(self):
            return 5

    obj = MyClass()
    assert obj.x == 5



# Generated at 2022-06-11 22:15:03.542890
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # noinspection PyUnusedLocal
    class MyClass:

        def __init__(self):
            self.x = 5

        # noinspection PyUnusedLocal
        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert asyncio.iscoroutinefunction(obj.y())
    assert asyncio.iscoroutine(obj.y())

    loop = asyncio.get_event_loop()
    result = loop.run_until_complete(obj.y())

    assert result == 6


test_cached_property___get__()

# Generated at 2022-06-11 22:15:07.681467
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class _:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = _()
    assert obj.y == 6

# Generated at 2022-06-11 22:15:17.860537
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method cached_property.__get__ of class cached_property.
    """
    import sys
    from flutils.decorators import cached_property

    if sys.version_info[:2] < (3, 8):
        class MockMe:
            count = 0

            def __init__(self):
                self.count = -1

            @cached_property
            def inc(self):
                self.count += 1
                return self.count

        mockme = MockMe()
        first = mockme.inc
        second = mockme.inc
        assert first == second
        del mockme.inc
        third = mockme.inc
        assert first == second
        assert first != third



# Generated at 2022-06-11 22:15:22.796136
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import TestCase

    class MyClass(TestCase):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-11 22:15:27.201116
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class Test:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Test()
    assert obj.y == 6

# Generated at 2022-06-11 22:15:31.305410
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class C:

        @cached_property
        def x(self):
            """doc string"""
            return 10

    assert C.x.__doc__ == 'doc string'
    c = C()
    assert c.x == 10
    c.x = 3
    assert c.x == 3


# Generated at 2022-06-11 22:15:34.718308
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    def __init__(self):
        self.x = 5

    def y(self):
        return self.x + 1

    def test_cached_property___get__(self):
        """Test case for cached_property method __get__
        """
        my_class = cached_property(y)
        assert my_class == 6

# Generated at 2022-06-11 22:15:41.542838
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import Mock, patch
    from flutils.decorators import cached_property

    obj = Mock()

    @cached_property
    def foo():
        return 'bar'

    obj.__getattribute__.side_effect = ['bar']

    assert foo.__get__(obj, Mock) == 'bar'
    obj.assert_called_once_with('foo')


# Generated at 2022-06-11 22:15:48.755365
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # Unit test for method __get__ of class cached_property with coroutine
    # function
    class MyCoroutineClass:
        def __init__(self):
            self.x = 5

        @cached_property
        @asyncio.coroutine
        def y(self):
            return self.x + 1

    # Test that MyCoroutineClass.y is a coroutine object
    obj = MyCoroutineClass()
    assert callable(obj.y)
    assert asyncio.iscoroutine(obj.y)

    # Test that MyCoroutineClass.y() returns a future
    assert isinstance(obj.y(), asyncio.Future)

    # Test that MyCoroutineClass.y() has a result
    assert asyncio.get_event_loop().run_until_complete(obj.y()) == 6

    # Unit test

# Generated at 2022-06-11 22:15:58.585463
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from datetime import datetime
    from flutils.decorators import cached_property

    def test_method(obj):
        return datetime.now()

    class TestClass:
        @cached_property
        def cached(self):
            return test_method(self)

        @property
        def uncached(self):
            return test_method(self)

    assert hasattr(TestClass.cached, '__isabstractmethod__')

    test = TestClass()
    x = test.uncached
    y = test.cached
    z = test.cached

    assert x != y
    assert y == z
    assert isinstance(y, datetime)



# Generated at 2022-06-11 22:16:06.832022
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Note: this is a lot of work for a couple of simple decorators...
    # Then again this is a testing framework!

    # pylint: disable=too-few-public-methods
    # pylint: disable=attribute-defined-outside-init
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    y = obj.y

    assert y == 6
    assert obj.y == 6



# Generated at 2022-06-11 22:16:15.523051
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest
    from ._utils import asynclib

    def test_seleted_func(self):
        return self.x + 1

    def test_seleted_coro_func(self):
        return (yield from self.x + 1)

    def some_func():
        pass

    class X:
        y = cached_property(test_seleted_func)

        def __init__(self, x):
            self.x = x

    class Y:
        if asynclib == 'trollius':
            y = cached_property(test_seleted_coro_func)
            y.__name__ = 'y'
        else:
            y = cached_property(test_seleted_coro_func)

        def __init__(self, x):
            self.x = x

   

# Generated at 2022-06-11 22:16:21.470475
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class :obj:`cached_property`.
    """

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


# Generated at 2022-06-11 22:16:25.516629
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y


# Generated at 2022-06-11 22:16:29.424899
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1


    obj = MyClass()
    assert obj.y == 6


if __name__ == '__main__':
    test_cached_property___get__()

# Generated at 2022-06-11 22:16:36.283177
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import unittest

    class TestCachedProperty(unittest.TestCase):
        def test_method___get__(self):
            class MyClass:
                def __init__(self):
                    self.x = 5
                    self.y = cached_property(self._compute_y)

                def _compute_y(self):
                    return self.x + 1

            obj = MyClass()
            self.assertIsInstance(obj.y, int)
            self.assertEqual(obj.y, 6)

    unittest.main()

# Generated at 2022-06-11 22:16:40.128038
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method :py:meth:`.cached_property.__get__` of class
    :py:class:`.cached_property`.

    """
    class C:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1



    assert C().y == 6

# Generated at 2022-06-11 22:16:41.756750
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from .test_decorators import test_cached_property___get__ as test

    test()

# Generated at 2022-06-11 22:16:49.322951
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test doc strings...
    """
    # noinspection SpellCheckingInspection
    class Foo:
        """Foo instance method"""

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """Foo return value"""
            return self.x + 1

    obj = Foo()
    assert obj.y == 6


# Generated at 2022-06-11 22:16:57.135590
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property """
    class Person:

        def __init__(self, name=None, age=None):
            self.name = name
            self.age = age

        @cached_property
        def full_name(self):
            return f'{self.name} {self.age}'

    person = Person(name='Zoe', age='Alive')

    assert person.full_name == 'Zoe Alive'

# Generated at 2022-06-11 22:17:09.011306
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from types import SimpleNamespace

    class MyClass:
        def __init__(self, m, n):
            self.m = m
            self.n = n

        @cached_property
        def p(self):
            return self.m * self.n

        def __eq__(self, other):
            return self.__dict__ == other.__dict__

    # Test with given example
    obj = MyClass(5, 6)
    assert obj.p == 30
    assert obj == MyClass(5, 6, {'p': 30})
    # del obj.p
    # assert obj == MyClass(5, 6, {})

    # Test with class that has no __dict__
    class MyClass2(SimpleNamespace):
        def __init__(self, m, n):
            self.m = m


# Generated at 2022-06-11 22:17:19.117358
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test method __get__ of class cached_property.

    """

    @cached_property
    def test_method(self):
        self.attrs['test_method'] += 1
        return self.attrs['test_method']

    class DummyClass:

        def __init__(self):
            self.attrs = {'test_method': 0}

        @cached_property
        def test_method(self):
            self.attrs['test_method'] += 1
            return self.attrs['test_method']

    def test():
        obj = DummyClass()
        assert obj.test_method == 1
        assert 'test_method' in obj.__dict__
        assert obj.test_method == 1
        assert obj.attrs['test_method'] == 1
        del obj.test_method


# Generated at 2022-06-11 22:17:27.402749
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit tests for class :obj:`~flutils.decorators.cached_property`.

    Tests method :meth:`~flutils.decorators.cached_property.__get__`.

    """
    import flutils.decorators as decos

    class MyClass:
        def __init__(self):
            self.x = 5

        @decos.cached_property
        def y(self):
            return self.x + 1

        @decos.cached_property
        async def z(self):
            return self.x + 1

    # test __get__ no obj
    my_obj = MyClass()
    assert isinstance(MyClass.y, decos.cached_property)
    assert isinstance(MyClass.z, decos.cached_property)

    # test __get

# Generated at 2022-06-11 22:17:35.120043
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    """
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        @asyncio.coroutine
        def z(self):
            yield

    obj = MyClass()
    assert obj.y == 6
    assert obj.z is None
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(obj.z)



# Generated at 2022-06-11 22:17:45.190676
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    # Check that the property is computed, and return the correct value
    v = obj.y
    assert v == 6, 'obj.y == %r; should be 6' % (v,)
    # Check that we can delete the property, thus clearing the cache
    del obj.y
    # Check that the property is computed again, and return the correct value
    v = obj.y
    assert v == 6, 'obj.y == %r; should be 6' % (v,)


# Generated at 2022-06-11 22:17:56.423094
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Needed for Python 3.6
    # noinspection PyCompatibility
    from functools import partial
    from unittest.mock import MagicMock

    def assert_false(val):
        assert not val

    def assert_true(val):
        assert val

    def assert_is_instance(val, class_):
        assert isinstance(val, class_)

    def assert_equal(val1, val2):
        assert val1 == val2

    def assert_is(val1, val2):
        assert val1 is val2

    def assert_is_not(val1, val2):
        assert val1 is not val2


# Generated at 2022-06-11 22:18:00.900205
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class TestCachedProperty:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestCachedProperty()
    assert obj.y == 6



# Generated at 2022-06-11 22:18:08.977653
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import unittest
    import unittest.mock
    from typing import Optional
    from flutils.decorators import cached_property

    class MyClass:

        @cached_property
        def cached_property(self):
            return 'cached_property'

        @cached_property
        def cached_property_with_default_value(self, default_value=None):
            return default_value

        @cached_property
        def cached_property_with_required_args(self, arg=None):
            return arg

        @cached_property
        def cached_property_with_kwargs(self, arg, kwarg=None):
            return f'{arg} + {kwarg}'


# Generated at 2022-06-11 22:18:18.358683
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.utils import compare_yaml
    from flutils.textutils import normalize_text


# Generated at 2022-06-11 22:18:27.900538
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""

    import unittest

    from flutils.decorators import cached_property


    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x + 2


    class TestCachedProperty(unittest.TestCase):
        """Testcase for class cached_property"""

        def test_x(self) -> None:
            obj = MyClass()
            self.assertEqual(obj.x, 5)

        def test_y(self) -> None:
            obj = MyClass()
            self.assertEqual(obj.y, 6)


# Generated at 2022-06-11 22:18:34.938965
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.set_val = 5

        @cached_property
        def val(self):
            return self.set_val

    m = MyClass()
    assert m.val == 5

    # Verify caching
    m.set_val = 8
    assert m.val == 5

    # Verify resetting
    del m.val
    assert m.val == 8

    # Verify getting the cache
    assert m.__dict__['val'] is m.val



# Generated at 2022-06-11 22:18:43.993575
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Testclass:
        def __init__(self, value):
            self.value = value

        @cached_property
        def test_value(self):
            return self.value

    instance = Testclass(1)
    assert isinstance(instance, Testclass)
    assert instance.test_value == 1
    try:
        instance.test_value = 2
    except Exception as e:
        pass
    assert instance.test_value == 1
    try:
        del instance.test_value
    except Exception as e:
        pass
    assert instance.test_value == 1



# Generated at 2022-06-11 22:18:50.512917
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self, val):
            self.val = val

        @cached_property
        def y(self):
            return self.val + 1

    obj = MyClass(5)
    assert obj.y == 6
    assert 'y' in obj.__dict__
    del obj.y
    assert 'y' not in obj.__dict__
    obj.val = 7
    assert obj.y == 8

# Generated at 2022-06-11 22:19:02.260817
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property
    from unittest import mock

    assert hasattr(cached_property, "__get__")
    assert callable(cached_property.__get__)

    class MockClass(object):

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    with mock.patch.object(MockClass, "x", 7):
        mock_obj = MockClass()
        assert mock_obj.y == 8
        mock_obj.x = 8
        assert mock_obj.y == 8
        # Clean-up
        del mock_obj.y
        mock_obj.x = 5


# Generated at 2022-06-11 22:19:06.618655
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.y == 6
    obj.x = 8
    assert obj.y == 6

# Generated at 2022-06-11 22:19:09.787598
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert MyClass().y == 6


# Generated at 2022-06-11 22:19:15.910210
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    del obj.y

    obj = MyClass()
    y = obj.y

    with pytest.raises(AttributeError):
        obj.y = 'foo'

# Generated at 2022-06-11 22:19:27.284422
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""

    class Myclass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """A cached property."""
            return self.x + 1

    obj = Myclass()
    # method __get__ of class cached_property must return the
    # value of the property
    assert obj.y == 6
    # method __get__ of class cached_property must replace itself
    # with a regular attribute
    assert obj.__dict__['y'] == 6
    # method __get__ of class cached_property must leave the doc
    # of the property untouched
    assert obj.y.__doc__ == 'A cached property.'



# Generated at 2022-06-11 22:19:36.811925
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    try:
        obj.y = 8
    except AttributeError:
        pytest.fail("Assignment should be possible")

    assert obj.y == 8

    MyClass.y = 1
    assert obj.y == 1

    del MyClass.y
    assert obj.y == 6

    del obj.y
    assert obj.y == 6

    try:
        del obj.y
    except AttributeError:
        pytest.fail("Deletion should be possible")

    assert obj.y == 6



# Generated at 2022-06-11 22:19:44.298199
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        @cached_property
        def y(self):
            return self.x + 1

        def __init__(self):
            self.x = 10

    obj = MyClass()
    assert obj.y == 11

# Generated at 2022-06-11 22:19:54.837299
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """ Unit test to test method __get__ of class cached_property """
    # Declare constants
    TEST_CLASS_NAME = "test"
    TEST_CLASS_BASE = object
    TEST_CLASS_DICT = {'x': 5}
    TEST_RESULT = 6

    # Create a class
    class TTestClass(TEST_CLASS_BASE):

        def __init__(self):
            self.x = TEST_CLASS_DICT['x']

        @cached_property
        def y(self):
            return self.x + 1

    # Get a set of properties for class
    _cp = cached_property(TTestClass.y)

    # Test __get__
    _test = TTestClass()
    assert _test.y == TEST_RESULT

# Generated at 2022-06-11 22:20:03.364574
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest

    class A:
        def __init__(self):
            self.x = 0

        def foo(self):
            return self.x + 42

        foo = cached_property(foo)

    @cached_property
    def bar(self):
        return self.x + 42

    class B:
        x = 0
        foo = A.foo
        bar = bar


# Generated at 2022-06-11 22:20:04.457383
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass



# Generated at 2022-06-11 22:20:10.720277
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit testing for method __get__ of class cached_property."""

    class TestClass(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()

    assert obj.y == 6
    assert hasattr(obj, "y")
    assert isinstance(obj.__dict__["y"], int)



# Generated at 2022-06-11 22:20:16.662990
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


if __name__ == '__main__':
    import pytest

    pytest.main([__file__])

# Generated at 2022-06-11 22:20:19.969482
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from .testcase import test_methods_and_classes

    test_methods_and_classes(cached_property)


# Generated at 2022-06-11 22:20:28.125798
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    del obj.y
    assert 'y' not in obj.__dict__
    obj.y
    assert obj.y == 6
    assert 'y' in obj.__dict__
    del obj.y
    assert 'y' not in obj.__dict__
    assert obj.y == 6
    assert 'y' in obj.__dict__


# Generated at 2022-06-11 22:20:35.715916
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # verify the decorator does not rely on the name of the instance
    class Temp:
        @cached_property
        def prop(self):
            return 42

    t1 = Temp()
    t2 = Temp()

    t1.prop
    t2.prop

    assert t1.prop == 42
    assert t1.__dict__["prop"] == 42
    assert t2.prop == 42
    assert t2.__dict__["prop"] == 42



# Generated at 2022-06-11 22:20:40.045058
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        @cached_property
        def english(self):
            return "one"

    obj = MyClass()
    assert obj.english == "one"
    del obj.english
    assert obj.english == "one"

# Generated at 2022-06-11 22:20:55.596894
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    y = obj.y
    assert y == 6
    assert obj.y is y

# Generated at 2022-06-11 22:20:59.007235
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    @cached_property
    def property1(self):
        return self.x + 1

    class MyClass:
        def __init__(self):
            self.x = 5

    obj = MyClass()
    assert obj.property1 == 6



# Generated at 2022-06-11 22:21:09.064136
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class Foo:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    foo = Foo(5)

    assert foo.y == 6
    assert foo.__dict__['y'] == 6
    # noinspection PyStatementEffect
    foo.y  # noqa
    assert foo.__dict__['y'] == 6
    del foo.__dict__['y']
    # noinspection PyStatementEffect
    foo.y  # noqa
    assert foo.__dict__['y'] == 7

# Test for method _wrap_in_coroutine of class cached_property

# Generated at 2022-06-11 22:21:17.994502
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property
    from unittest.mock import Mock

    # Test 1
    class SomeClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = SomeClass()
    assert obj.y == 6
    # Test 2
    y_prop = SomeClass.y
    assert y_prop.__get__(obj) == 6

    # Test 3
    obj.x = 10
    assert obj.y == 6
    # Test 4
    obj.__dict__.pop("y")
    assert obj.y == 11

    # Test 5
    obj = SomeClass()
    obj.__dict__.pop("y")
    assert obj.y == 11

    # Test 6

# Generated at 2022-06-11 22:21:22.192471
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """ Unit test for method __get__ of class cached_property
    """
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    assert obj.y == 6

# Generated at 2022-06-11 22:21:27.295233
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test cached_property.__get__

    This is mostly a smoke test.  That is, it just checks that the
    method can be called.  It doesn't check if the result returned is
    correct.

    """

    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.y == 6



# Generated at 2022-06-11 22:21:35.954357
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from types import MethodType
    from types import FunctionType

    class Obj:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.y + 1

        async def async_y(self):
            return self.x + 1

    obj = Obj()
    assert obj.y == 6
    assert isinstance(obj.y, int)
    assert isinstance(obj.y, type(obj.x))
    assert isinstance(obj.y, type(obj.z))
    assert obj.z == 7

    # Data property
    assert isinstance(obj.__dict__, dict)
    assert obj.__dict__['y'] == 6

# Generated at 2022-06-11 22:21:46.971633
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest
    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class MyClassAsync:
        def __init__(self):
            self.x = 5

        @cached_property
        async def y(self):
            return self.x + 1

    obj = MyClass()
    obj2 = MyClassAsync()

    assert "y" not in obj.__dict__
    assert obj.y == 6
    assert "y" in obj.__dict__
    assert isinstance(obj.__dict__["y"], int)

    assert "y" not in obj2.__dict__
    assert obj2.y == 6

# Generated at 2022-06-11 22:21:53.264262
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import TestCase, mock
    from unittest.mock import patch

    class t:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    with patch('flutils.decorators.cached_property.asyncio.iscoroutinefunction',
               new_callable=mock.MagicMock(return_value=False)):
        tc = t()
        tc.__dict__ = {}
        tc2 = t()
        tc2.__dict__ = {}

        res = tc.y
        res2 = tc2.y

        # this is the important test
        assert res == 6 and res2 == 6


# Generated at 2022-06-11 22:21:58.650680
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test method __get__ of class cached_property."""
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-11 22:22:23.878244
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""

    import pytest
    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-11 22:22:28.158734
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    _cls = cached_property(_func)
    assert '_cls' in globals()
    _obj = object()
    _val = _cls.__get__(_obj, None)
    assert '_val' in globals()
    assert _val == _obj



# Generated at 2022-06-11 22:22:32.800442
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    obj = {}

    @cached_property
    def func(o):
        return 'func'

    assert func.__get__(obj) == 'func'
    assert obj['func'] == 'func'
    assert func.__get__(obj) is obj['func']



# Generated at 2022-06-11 22:22:41.279799
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Runs the tests for :obj:`asyncio.iscoroutinefunction`.

    Example:

    .. code-block:: python

        >>> from flutils.decorators import cached_property
        >>> test_cached_property___get__()
        Test cached_property.__get__()
        Property not set yet
        Test cached_property.__get__()
        Coroutine property not set yet
        Test cached_property.__get__()
        Coroutine property not set yet
        Test cached_property.__get__()
        Property already set
        Test cached_property.__get__()
        Coroutine property already set
        Test cached_property.__get__()
        Coroutine property already set

    *New in version 0.2.0*
    """

# Generated at 2022-06-11 22:22:42.151808
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass



# Generated at 2022-06-11 22:22:52.933318
# Unit test for method __get__ of class cached_property

# Generated at 2022-06-11 22:22:58.984498
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


# Generated at 2022-06-11 22:23:03.480756
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test of the method __get__ of class cached_property
    """

    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.x == 5
    assert obj.y == 6



# Generated at 2022-06-11 22:23:14.002590
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import patch

    from .cached_property import cached_property

    class MyClass:

        def __init__(self):
            self.hello = 'Hello'
            self.world = 'World'

        @cached_property
        def hello_world(self):
            return '{} {}'.format(self.hello, self.world)

    # When:
    # A class instance is created.
    obj = MyClass()

    # Then:
    # The value of the property is returned.
    assert obj.hello_world == 'Hello World'
    # And:
    # The property is saved in the instance __dict__.
    assert obj.__dict__['hello_world'] == 'Hello World'

    # When:
    # The instance is patched to raise an Exception while
    # computing a property

# Generated at 2022-06-11 22:23:20.775698
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    print(f'obj.y == obj.__dict__["y"] is {obj.y == obj.__dict__["y"]}.')
    print(f'obj.y is {obj.y}.')



# Generated at 2022-06-11 22:24:17.732737
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit tests for cached_property.__get__().
    """

    import pytest

    from flutils.decorators import cached_property

    class TestClass(object):
        @cached_property
        def x(self):
            return 1

    # noinspection PyMissingOrEmptyDocstring
    class TestClass2(object):
        @cached_property
        def x(self):
            return 1

        @cached_property
        def y(self):
            return 2

    @pytest.mark.asyncio
    async def test_cached_property___get___coroutine():
        """Unit tests for cached_property.__get__() with coroutine.
        """

        import asyncio


# Generated at 2022-06-11 22:24:22.030068
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    @cached_property
    def prop(self):
        return self.x + 1

    class Obj:
        def __init__(self, x):
            self.x = x

    obj = Obj(5)
    assert obj.prop == 6



# Generated at 2022-06-11 22:24:27.179231
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert (obj.y == 6)
    assert (obj.y == 6)


# Generated at 2022-06-11 22:24:32.675177
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from types import FunctionType

    class c:
        def __init__(self):
            self.x = 1

        @cached_property
        def y(self):
            return self.x + 1

    o = c()

    assert o.y == o.__dict__['y']
    assert o.y == 2
    assert isinstance(o.__class__.__dict__['y'], FunctionType) is False



# Generated at 2022-06-11 22:24:37.189832
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of :class:`~flutils.decorators.cached_property`
    """

    class MyClass:
        """
        The class to test
        """

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-11 22:24:44.521948
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import patch

    class A:
        def __init__(self):
            self.x = 10

        @cached_property
        def y(self):
            return self.x - 5

    cls = A()
    assert cls.y == 5

    with patch.object(A, "y", new=20):
        assert cls.y == 20



# Generated at 2022-06-11 22:24:52.492402
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property.

    *New in version 0.2.0*
    """

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x

    obj = MyClass()

    assert obj.y == 5

    obj.x = 8

    assert obj.y == 5


# Generated at 2022-06-11 22:25:03.747084
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property

    Runs with pytest.
    """
    @cached_property
    def x():
        return 5

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x + 1

        # s = 5

        # @cached_property
        # def t(self):
        #     return self.s + 1

    class MyClassD:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1
