

# Generated at 2022-06-11 22:15:09.342367
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property.
    """

    # noinspection PyUnusedLocal,PyUnusedLocal
    class MyClass:

        def __init__(self, x: int):
            self.x = x

        def func(self):
            return self.x + 1


    obj = MyClass(5)
    cp = cached_property(obj.func)
    obj.y = cp
    try:
        cp.__get__(obj, cp)
        assert obj.y == 6
    except AttributeError:
        assert True



# Generated at 2022-06-11 22:15:14.225071
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    @cached_property
    def foo(self):
        return self.x + 1

    class Cls(object):
        def __init__(self):
            self.x = 5

    cls = Cls()
    assert cls.foo == 6
    assert cls.__dict__['foo'] == 6

# Generated at 2022-06-11 22:15:20.086305
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Obj:
        def __init__(self, x: int = None) -> None:
            self.x = x

        @cached_property
        def y(self) -> int:
            return self.x + 1

    obj = Obj(x=5)

    assert obj.y == 6
    assert obj.__dict__['y'] == 6

    obj.x = 10
    assert obj.y == 11
    assert obj.__dict__['y'] == 11



# Generated at 2022-06-11 22:15:27.765773
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property.

    :return:
    """
    class Obj(object):
        def __init__(self, x):
            self.__x = x

        @cached_property
        def x(self): return self.__x + 1

    obj = Obj(5)
    assert obj.x == 6
    obj.__x = 13
    assert obj.x == 6



# Generated at 2022-06-11 22:15:36.013197
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj_class = type(obj)
    assert obj_class.__name__ == "MyClass"

    # Test if __get__ returns self if obj is None
    assert MyClass.y is MyClass.y

    # Test if __get__ returns cached value if obj is not None
    assert obj.y == 6
    assert obj.y == 6

    # Test an async property by setting self.x = 6
    obj.x = 6

    # Test if async property coroutine is complete

# Generated at 2022-06-11 22:15:45.288502
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Region : Class definition ------------------------------------------
    class MyClass:
        def __init__(self):
            self.x = 1

        @cached_property
        def y(self):
            return self.x + 1
    # Endregion : Class definition ---------------------------------------

    obj = MyClass()
    x = obj.__dict__['x']
    func_name = obj.y.func.__name__
    assert not x == obj.y
    assert x + 1 == obj.y
    assert func_name == obj.__dict__[func_name].func.__name__
    assert x + 1 == obj.__dict__[func_name]
    assert func_name not in obj.__dict__



# Generated at 2022-06-11 22:15:56.427044
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.helpers import run_async

    class Foo:
        @cached_property
        def bar(self):
            return 'bar'

    @run_async
    async def test1():
        foo = Foo()
        assert foo.bar == 'bar'
        assert foo.__dict__['bar'] == 'bar'

    @run_async
    async def test2():
        class Foo:
            @cached_property
            async def bar(self):
                print("computing")
                return 'bar'

        foo = Foo()
        assert await foo.bar == 'bar'
        assert foo.__dict__['bar'] == 'bar'

    asyncio.run(test1())
    asyncio.run(test2())

# Generated at 2022-06-11 22:16:02.724000
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property.
    """

    from flutils.decorators import cached_property

    class MyClass:
        """A class for testing cached_property.
        """

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6


# Generated at 2022-06-11 22:16:09.668767
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    delattr(obj, 'y')
    obj.y
    assert obj.y == 6
    obj.x = 10
    delattr(obj, 'y')
    assert obj.y == 11

# Generated at 2022-06-11 22:16:12.462796
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Obj:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Obj()
    assert obj.y == 6


# Generated at 2022-06-11 22:16:23.167355
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():  # noqa: D103
    import asyncio
    import time

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    time.sleep(1)

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        async def y(self):
            return self.x + 1

    obj = MyClass()
    assert asyncio.run(obj.y) == 6



# Generated at 2022-06-11 22:16:31.590701
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    from logging import getLogger
    from typing import Dict
    import unittest.mock as mock

    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            with mock.patch.object(
                self.__class__, "__dict__", {}
            ) as mock__dict__:
                y = self.x + 1
            return y

    obj = MyClass()
    logger = getLogger(__name__)
    logger.debug("before: %r", obj.__dict__)
    logger.info("before: %s", obj.y)

    if sys.version_info >= (3, 7):
        # noinspection PyProtectedMember
        assert isinstance

# Generated at 2022-06-11 22:16:40.535055
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class A:
        pass

    @cached_property
    def x(self):
        return self.y

    @cached_property
    def y(self):
        return self.z

    @cached_property
    def z(self):
        return 42

    a = A()

    # cache value.
    a.x
    assert z.__get__(A(), A) is z
    assert z.__get__(None, A) is z
    assert y.__get__(a, A) == 42
    assert x.__get__(a, A) == 42

    # cache cleared.
    del a.y
    assert x.__get__(a, A) == 42

    # cache cleared on all properties.
    del a.x
    assert x.__get__(a, A) == 42

# Generated at 2022-06-11 22:16:42.438776
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators.testingimport import SlowToInitialize

    obj = SlowToInitialize()
    assert obj.y == 6



# Generated at 2022-06-11 22:16:54.994902
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test the method __get__ of class cached_property"""
    def test_func(obj):
        """Test function."""
        return 1

    obj = lambda: 0
    func_name = 'attr_name'
    test_func.__name__ = func_name
    wrapped_func = cached_property(test_func)
    assert isinstance(wrapped_func, cached_property)
    assert hasattr(wrapped_func, '__get__')
    test_obj = obj()
    assert wrapped_func.__get__(test_obj, obj) == 1
    assert test_func.__name__ == func_name
    assert test_obj.__dict__[func_name] == 1
    test_obj = obj()
    test_obj.__dict__[func_name] = 2

# Generated at 2022-06-11 22:16:56.348058
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    c = cached_property(lambda x: 1)
    assert c.__get__(None, int) == c


# Generated at 2022-06-11 22:17:02.472186
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # noinspection PyUnresolvedReferences
    assert TestClass.y.func is TestClass.y.__get__(None, TestClass)

    assert TestClass.y.func is TestClass.__dict__['y'].__get__(None, TestClass)

    # noinspection PyUnresolvedReferences
    assert TestClass.y.func.__doc__ == TestClass.y.__doc__



# Generated at 2022-06-11 22:17:03.112303
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    assert True

# Generated at 2022-06-11 22:17:10.618053
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__

    Args:
        None

    Returns:
        None

    """

    # *************************************************************************
    # Define a class with a cached_property attribute
    # *************************************************************************
    class TestClass:
        def __init__(self):
            self.save_val = 5

        @cached_property
        def save_val(self):
            return self.save_val + 1

    # *************************************************************************
    # Test cached_property attribute
    # *************************************************************************
    obj = TestClass()
    assert obj.save_val == 6
    obj.save_val = 7
    assert obj.save_val == 6
    del obj.__dict__['save_val']
    assert obj.save_val == 6

# Generated at 2022-06-11 22:17:15.114817
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method `cached_property.__get__`

    """

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-11 22:17:25.683382
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # This is a weird sequence of asserts because 'cached_property'
    # is a decorator and not a class

    def f(i):
        return i

    # No cache
    @cached_property
    def g(i):
        return i

    # Cache
    @cached_property
    def h(i):
        return i

    obj = object()
    assert f(obj) == obj
    assert g(obj) == obj
    assert h(obj) == obj
    assert f(obj) == obj
    assert g(obj) == obj
    assert h(obj) == obj

    # noinspection PyUnusedLocal
    @cached_property
    def func(obj):
        # type: (object) -> object
        """Cached property docstring."""
        return obj

    assert func.__doc__

# Generated at 2022-06-11 22:17:36.834985
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from asyncio import sleep, run
    from math import ceil

    # Create object for testing class cached_property
    class MyClass:
        # Class attribute
        attr = 1

        def __init__(self, value):
            self.value = value

        @cached_property
        def method(self):
            return self.value * 1.75

        @cached_property
        def method_raise(self):
            raise ValueError('This is to test exception handling.')

        @cached_property
        async def method_async(self):
            await sleep(1)
            return self.value * 1.25

        @property
        def prop(self):
            return self.value + 1

        @prop.setter
        def prop(self, value):
            self.value = value


# Generated at 2022-06-11 22:17:47.562469
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test cached_property.__get__."""

    import pytest
    import asyncio

    # Test when func is a synchronous function
    def gen_func():
        yield 1
        yield 2
        yield 3

    gen = gen_func()

    class MyClass1:

        @cached_property
        def prop(self):
            return next(gen)

    c = MyClass1()
    assert c.prop == 1
    assert c.prop == 1
    assert isinstance(c.__dict__['prop'], int)

    # Test when func is an asynchronous function
    @asyncio.coroutine
    def async_gen_func():
        yield 1
        yield 2
        yield 3

    gen = async_gen_func()


# Generated at 2022-06-11 22:17:54.081519
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property
    from flutils.decorators import test_cached_property___get__

    obj = test_cached_property___get__()

    expected = 6

    actual = obj.y

    try:
        assert actual == expected
    except AssertionError:
        raise AssertionError("actual: {} != expected: {}".format(actual, expected))

# Generated at 2022-06-11 22:17:58.869965
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property


    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1


    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-11 22:18:06.703547
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property
    from flutils.logger import Logger

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert isinstance(obj.y, int)
    assert obj.y == 6

    Logger.log.disable_logger()
    assert isinstance(obj.y, int)
    Logger.log.enable_logger()
    assert isinstance(obj.y, int)
    assert obj.y == 6



# Generated at 2022-06-11 22:18:10.649468
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class C:

        @cached_property
        def x(self):
            return 42

    c = C()
    assert c.x == 42
    assert c.__dict__ == {'x': 42}

# Generated at 2022-06-11 22:18:18.908303
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest
    # import functools

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def y_coro(self):
            async def _coro():
                await asyncio.sleep(1)
                return self.x + 1

            return _coro()

    def test_cached_property___get__():
        obj = MyClass()

        with pytest.raises(AttributeError) as context:
            assert obj.y == 6

        obj.y  # force y to be computed

        assert obj.y == 6

        with pytest.raises(AttributeError) as context:
            assert obj.y_coro == 6


# Generated at 2022-06-11 22:18:27.801607
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    from importlib import import_module

    from flutils.decorators import cached_property

    from .utils import BaseTestCase

    loaded = import_module('flutils.decorators')
    if loaded.__version__ >= '0.3.0':
        raise unittest.SkipTest(
            "cached_property.__get__(cls) is no longer supported as of "
            "flutils 0.3.0."
        )

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class Test_method___get__of_class_cached_property(BaseTestCase):

        def test_method___get__of_class_cached_property(self):
            obj = MyClass

# Generated at 2022-06-11 22:18:33.047909
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import asyncio

    class Obj:
        @cached_property
        def prp(self):
            return 'the value of prp'

    obj = Obj()
    assert obj.prp == 'the value of prp'
    assert obj.__dict__['prp'] == 'the value of prp'



# Generated at 2022-06-11 22:18:45.894681
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""

    import unittest


    class TestClass(unittest.TestCase):
        """Unit test for method __get__ of class cached_property"""

        def test_cached_property___get__(self):
            """Test for method __get__ of class cached_property"""
            import asyncio
            from time import time
            from functools import partial

            from flutils.decorators import cached_property


            class MyClass:
                """
                This class is used in the unit tests for the
                :obj:`~flutils.decorators.cached_property` class.
                """

                def __init__(self):
                    self.x = 5

                @cached_property
                def y(self):
                    return self.x + 1

           

# Generated at 2022-06-11 22:18:50.512698
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    def fn(obj):
        return obj

    fc = cached_property(fn)

    class C:
        @fc
        def a(self):
            return self

    inst = C()
    result = fc.__get__(inst, C)
    assert result is inst



# Generated at 2022-06-11 22:19:02.938381
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """ Unit test for method __get__ of class cached_property. """

    def helper(obj):
        return obj.x

    @cached_property
    def method1(self):  # pylint: disable=no-self-argument
        """ Method 1. """
        return helper(self)

    class MyClass:  # pylint: disable=too-few-public-methods
        """ MyClass. """

        def __init__(self):
            self.x = 5

    obj = MyClass()

    # Test with an instance of MyClass.
    obj.method1

    # Test with a type.
    assert method1.__get__(None, MyClass) is method1

    # Test with an instance of MyClass.
    assert obj.method1.__get__(obj, MyClass) is obj.method1

# Generated at 2022-06-11 22:19:09.836030
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test method __get__ of class cached_property."""
    import asyncio
    import unittest.mock as mock
    from flutils.decorators import cached_property

    class Test:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x

    obj = Test(5)
    assert obj.y == 5
    assert obj.__dict__['y'] == 5

    async def async_y(self):
        return self.x

    @asyncio.coroutine
    def coro_y(self):
        return self.x

    with mock.patch.object(Test, 'y', new_callable=cached_property):
        Test.y = async_y
        assert asyncio.iscoroutinefunction

# Generated at 2022-06-11 22:19:13.974215
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class A:

        def __init__(self):
            self.x = 0

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        async def z(self):
            await asyncio.sleep(1)
            return self.x + 1

    a = A()
    assert a.y == 1
    a.x = 1
    assert a.y == 1
    delattr(a, 'y')
    assert a.y == 2



# Generated at 2022-06-11 22:19:17.698546
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        @cached_property
        def y(self):
            return self.x + 1

    object_ = MyClass()
    object_.x = 2
    assert object_.y == 3



# Generated at 2022-06-11 22:19:28.708825
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property
    """

    class A:
        def __init__(self):
            self.x = 5

        @cached_property  # noqa: CCR001
        def y(self):
            return self.x + 1

    obj = A()
    assert obj.y == 6
    obj.x = 7
    assert obj.y == 8

    class B:
        def __init__(self):
            self.x = 5

        @cached_property  # noqa: CCR001
        async def y(self):
            return self.x + 1

    obj = B()
    assert asyncio.run(obj.y) == 6
    obj.x = 7
    assert asyncio.run(obj.y) == 8

# Generated at 2022-06-11 22:19:35.234408
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TstClass:
        def __init__(self):
            self.a = 5

        @cached_property
        def b(self):
            return self.a + 1

    obj = TstClass()
    assert obj.b == 6
    assert "b" in obj.__dict__
    obj.a = 7
    assert obj.b == 6

    del obj.b
    assert "b" not in obj.__dict__

    assert obj.b == 8



# Generated at 2022-06-11 22:19:41.967569
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():  # noqa: D202
    import pytest  # noqa: F401
    from flutils.decorators import cached_property

    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    test_obj = TestClass()
    assert type(test_obj).y.__get__(test_obj, type(TestClass)) == 6



# Generated at 2022-06-11 22:19:43.094840
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Test comment to show code coverage
    pass

# Generated at 2022-06-11 22:20:00.689556
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property
    """
    # noinspection PyUnusedLocal
    class TestClass:
        """
        Test class to use in unit tests.
        """

        # noinspection PyUnusedLocal
        def __init__(self, value):
            self.x = value

        @cached_property
        def y(self):
            """
            Test @cached_property decorator.

            :return: self.x + 1
            """
            return self.x + 1

    obj = TestClass(5)
    assert obj.y == 6
    assert obj.__dict__ == {'x': 5, 'y': 6}

# Generated at 2022-06-11 22:20:05.874528
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__ == {'x': 5, 'y': 6}



# Generated at 2022-06-11 22:20:09.670432
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        @cached_property
        def foo(self):
            return 'bar'

    obj = MyClass()
    assert obj.foo == 'bar'
    assert obj.foo == 'bar'



# Generated at 2022-06-11 22:20:18.411424
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import datetime

    class MyClass:

        @cached_property
        def date(self):
            return datetime.datetime.now()

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6
    assert obj.y == 6
    obj.x = 10
    assert obj.y == 11
    y = obj.y
    del obj.y
    assert obj.y == 12
    obj.x = 20
    assert obj.y == 21

    assert isinstance(obj.date, datetime.datetime)
    assert isinstance(obj.date, datetime.datetime)
    assert isinstance(obj.date, datetime.datetime)
    assert obj

# Generated at 2022-06-11 22:20:23.797066
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    assert obj.y == 6



# Generated at 2022-06-11 22:20:27.155862
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    with pytest.raises(TypeError, match="descriptor '__get__' of 'cached_property' object needs an argument"):
        # noinspection PyUnresolvedReferences
        cached_property.__get__()



# Generated at 2022-06-11 22:20:38.156546
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    def f(obj, cls):
        return cls, obj, True

    cached = cached_property(f)

    @asyncio.coroutine
    async def coro(obj, cls):
        return cls, obj, True

    coro_cached = cached_property(coro)

    assert cached.__get__(None, 'cls') == f
    assert coro_cached.__get__(None, 'cls') == coro

    class C:
        @cached_property
        def f(self):
            return 'f'

        @cached_property
        def coro(self):
            return asyncio.coroutine(lambda: 'coro')()

        @cached_property
        def g(self):
            raise Exception('FAIL')

    c = C()

# Generated at 2022-06-11 22:20:43.118826
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        # noinspection PyMethodParameters
        @cached_property
        def y(self):
            return self.x

    assert MyClass.y.__name__ == "y"
    assert MyClass().y == 5

# Generated at 2022-06-11 22:20:47.004685
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


# Generated at 2022-06-11 22:20:58.407706
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    import asyncio

    class MyClass:
        """This is MyClass"""

        def __init__(self):
            self.x = 5
            self.y = self.x + 1

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.y == 6
    assert isinstance(obj.y, int)
    assert type(obj.y) is int
    assert type(obj.__dict__["y"]) is int
    assert obj.__dict__["y"] == 6

    # test object.attribute.method()
    assert obj.y.__doc__ == MyClass.y.__doc__

    obj.x = 10
    assert obj.y == 11
    assert obj.__dict__["y"] == 11

# Generated at 2022-06-11 22:21:24.838170
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    def func():
        pass

    cp = cached_property(func)

    # test None
    assert cp.__get__(None, None) is cp

    # test instance
    class MyClass:
        def __init__(self):
            self._dict = {}

        @cp.setter
        def setter(self, new_value):
            self._dict['setter'] = new_value

    my_obj = MyClass()
    assert not my_obj._dict

    assert cp.__get__(my_obj, MyClass) is not my_obj
    assert my_obj._dict['setter'] is my_obj



# Generated at 2022-06-11 22:21:31.534738
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Cached(object):
        def __init__(self, i):
            self.i = i

        @cached_property
        def prop(self):
            return self.i

    c = Cached(1)
    assert 1 == c.prop
    assert 1 == c.prop
    assert isinstance(c.prop, int)



# Generated at 2022-06-11 22:21:38.458939
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from asyncio import get_event_loop

    class Obj:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Obj()
    assert obj.y == 6

    obj.x = 8
    assert obj.y == 6

    get_event_loop().run_until_complete(obj.y)
    assert obj.y == 6

    obj.x = 9
    get_event_loop().run_until_complete(obj.y)
    assert obj.y == 6

# Generated at 2022-06-11 22:21:45.378752
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property  # type: ignore
        def y(self):  # noqa
            return self.x + 1

    obj = MyClass()
    assert isinstance(obj.y, int) and obj.y == 6
    assert obj.__dict__['y'] == 6


# Generated at 2022-06-11 22:21:50.539833
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    @cached_property
    def x(self):
        return self.y

    @cached_property
    @asyncio.coroutine
    def y(self):
        return self.z

    @cached_property
    def z(self):
        return 1 + 2

    class MyClass:
        pass

    obj = MyClass()
    assert obj.x == 3

if __name__ == "__main__":
    test_cached_property___get__()

# Generated at 2022-06-11 22:21:58.049625
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""

    def get_test_obj():
        """Create a test class with a cache property."""

        class Test:
            def __init__(self):
                self.x = 5

            @cached_property
            def y(self):
                return self.x + 1

        return Test()

    test_obj = get_test_obj()
    assert test_obj.y == 6
    test_obj.x -= 2
    assert test_obj.y == 6

# Generated at 2022-06-11 22:22:02.215920
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class Foo:

        def __init__(self):
            self._cnt = 0

        @cached_property
        def cnt(self):
            self._cnt += 1
            return self._cnt

    in_ = Foo()
    assert in_.cnt == 1
    assert in_.cnt == 1



# Generated at 2022-06-11 22:22:08.831056
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from . import cached_property

    class MyClass:

        @cached_property
        def foobar(self):
            return 'foobar'

    my_class = MyClass()
    assert my_class.foobar == 'foobar'

    foo_bar = my_class.__dict__['foobar']
    assert foo_bar == 'foobar'
    assert foo_bar is my_class.foobar



# Generated at 2022-06-11 22:22:20.223128
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    This function is the unit test for method __get__ of class
    cached_property.

    It ensures that the ``__get__`` method sets the return value of
    the decorated method as values in an instance's dictionary.
    """

    # Define the class SimpleKlass
    class SimpleKlass:

        # Define the __init__ method
        def __init__(self, _id):
            self.id = _id

        # Define the get_id method
        @cached_property
        def get_id(self):
            return self.id

    # Define the instance obj
    obj = SimpleKlass('abc1234')

    # Define the string object
    s = "The 'get_id' property is set in "
    s += "the 'obj' dictionary: "

    # Check that the 'get

# Generated at 2022-06-11 22:22:25.441696
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Create fixture
    class _TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Exercise
    obj = _TestClass()

    # Verify
    assert obj.y == 6



# Generated at 2022-06-11 22:23:13.114331
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Foo:

        @cached_property
        def bar(self):
            return 42

    obj = Foo()
    assert obj.__dict__ == {}

    # With Python >= 3.8
    if hasattr(functools, 'cached_property'):
        assert isinstance(obj.bar, functools.cached_property)
    else:
        # With Python < 3.8
        assert obj.bar == 42
        assert obj.__dict__ == {'bar': 42}

    assert obj.bar == 42
    assert obj.bar == 42
    assert obj.__dict__ == {'bar': 42}



# Generated at 2022-06-11 22:23:23.117362
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from time import time

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    # Delete y. This will "reset" the @cached_property to its initial state
    del obj.y
    assert obj.y == 6

    # Define a "slow" function
    # noinspection PyUnusedLocal
    def slow_func(obj):
        time.sleep(2)
        return "Result"

    # The first call to slow_func() should take 2 seconds
    # noinspection PyUnusedLocal
    class SlowClass:

        def __init__(self):
            self.x = 0


# Generated at 2022-06-11 22:23:30.566354
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""

    class Foo:

        def __init__(self, bar=5):
            self.bar = bar

        @cached_property
        def bar_cached(self):
            return self.bar

    foo = Foo()
    x = foo.bar_cached
    assert foo.bar_cached == 5
    assert foo.bar_cached == x

# Generated at 2022-06-11 22:23:34.246632
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """A property"""
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert MyClass.y.__doc__ == "A property"



# Generated at 2022-06-11 22:23:45.069983
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""
    import inspect
    import pytest
    from flutils.decorators import cached_property


    class ClassA:

        def __init__(self, x):
            self.x = x

        @cached_property
        def xyzzy(self):
            return self.x + 5

    class ClassB:

        def __init__(self, x):
            self.x = x

        @cached_property
        async def xyzzy(self):
            await asyncio.sleep(0.5)
            return self.x + 5

    class ClassC:

        def __init__(self, x):
            self.x = x

        @cached_property
        def xyzzy(self):
            return self.x + 5


# Generated at 2022-06-11 22:23:52.161547
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property.
    """
    logger.debug("Started unit test for method __get__ of class cached_property")
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # logging.getLogger(__name__).setLevel("DEBUG")
    obj = MyClass()
    assert obj.y == 6
    obj.x = 7
    assert obj.y == 6
    del obj.y
    assert obj.y == 8
    # logging.getLogger(__name__).setLevel("INFO")
    logger.debug("Completed unit test for method __get__ of class cached_property")


# Generated at 2022-06-11 22:23:58.473699
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Method __get__ of class cached_property."""

    import unittest
    import collections

    class DataClass:

        def __init__(self, _x):
            self._x = _x

    class TestCachedProperty(unittest.TestCase):
        """Just to test if the cached_property works."""

        def test_cached_property(self):
            data = [
                DataClass('foo'),
                DataClass('bar'),
                DataClass('baz'),
            ]

            # Create a cached_property callable
            @cached_property
            def x(self):
                """Hello?"""
                return self._x

            # Set the x attribute on the class
            DataClass.x = x

            # Loop over instance of the class

# Generated at 2022-06-11 22:24:07.463467
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import unittest

    class cached_property_class:

        def __init__(self):
            self.x = 10

        @cached_property
        def y(self):
            return self.x + 1

    class TestCachedProperty(unittest.TestCase):

        def test_cached_property(self):
            obj = cached_property_class()
            self.assertEqual(obj.y, 11)
            self.assertEqual(obj.y, 11)
            self.assertEqual(obj.__dict__['y'], 11)

        def test_cached_property_del(self):
            obj = cached_property_class()
            self.assertEqual(obj.y, 11)
            del obj.y
            self.assertFalse('y' in obj.__dict__)

    un

# Generated at 2022-06-11 22:24:16.944800
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class A:

        def __init__(self, flag=False):
            self.flag = flag

        @cached_property
        def x(self):
            return self.flag

    a = A()
    assert a.__dict__ == {}
    assert not a.x
    assert a.__dict__ == {'x': False}

    a = A(True)
    assert a.__dict__ == {}
    assert a.x
    assert a.__dict__ == {'x': True}

    a = A(1)
    assert a.__dict__ == {}
    assert a.x
    assert a.__dict__ == {'x': True}



# Generated at 2022-06-11 22:24:25.724695
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import MagicMock
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5
            self.__dict__[ "cached_property" ] = None

        @cached_property
        def cached_property(self):
            return self.x + 1

        @cached_property
        async def cached_property_async(self):
            return await asyncio.sleep(1, "foo")

        @cached_property
        def cached_property_undoc(self):
            return "undoc"


    obj = MyClass()

    assert obj.cached_property == 6
    assert obj.cached_property == 6
    assert "cached_property" in obj.__dict__
    del obj.c