

# Generated at 2022-06-23 17:55:44.895623
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import Mock

    with Mock() as mock:
        cached_property.__get__(mock, Mock())

# Generated at 2022-06-23 17:55:47.636620
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    import pytest

    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()

    assert obj.y == 6

    obj.x = 10
    assert obj.y == 6



# Generated at 2022-06-23 17:55:58.745863
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest.mock import Mock

    def test_func(self):
        pass

    # noinspection PyCallByClass
    wrapper = cached_property.__call__(test_func)
    # noinspection PyTypeChecker
    type(wrapper)()
    wrapper.__class__
    wrapper.__dict__
    wrapper.__format__
    wrapper.__dir__
    wrapper.__init__
    wrapper.__repr__
    wrapper.__doc__
    wrapper.__get__(Mock(spec=None), Mock)


if __name__ == '__main__':
    # noinspection PyShadowingNames
    from flutils.decorators.unittest import TestDecorators

    TestDecorators(globals()).test_all()

# Generated at 2022-06-23 17:56:03.165457
# Unit test for constructor of class cached_property
def test_cached_property():
    class Foo(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Foo()
    assert obj.y == 6

# Generated at 2022-06-23 17:56:07.388670
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 17:56:17.768412
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    obj.x = 10
    assert obj.y == 6
    del obj.y
    assert obj.y == 11
    obj.x = -1
    assert obj.y == 0

    class MyClass2:

        def __init__(self):
            self.x = 5

        @cached_property
        async def y(self):
            return self.x + 1

    obj = MyClass2()
    with pytest.raises(TypeError) as exc:
        obj.y
    assert exc

# Generated at 2022-06-23 17:56:19.017787
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test cached_property constructor.
    """
    assert cached_property.__init__

# Generated at 2022-06-23 17:56:21.795866
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    result = obj.y
    assert result == 6



# Generated at 2022-06-23 17:56:25.389925
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test constructor of class cached_property"""
    from flutils.tests.helpers import StdoutCapture
    with StdoutCapture() as c:
        c.assert_outputs(test_cached_property)

# Generated at 2022-06-23 17:56:33.303777
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.y == 6
    assert obj.y is not None
    assert obj.z is not None
    assert obj.y == obj.z


if __name__ == "__main__":
    test_cached_property___get__()

# Generated at 2022-06-23 17:56:36.752201
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Example:

        cached_prop = cached_property(lambda x: 5)

    assert Example.cached_prop == cached_property(lambda x: 5)
    # End



# Generated at 2022-06-23 17:56:46.669577
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""

    # pylint: disable=no-member

    class AClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.y + 1

    the_class = AClass()
    the_instance = AClass()
    the_instance.y
    the_instance.z

    assert type(AClass.y) == cached_property
    assert the_class.y == 6
    assert the_instance.y == 6
    assert the_instance.z == 7
    assert 'y' in the_instance.__dict__
    assert 'z' in the_instance.__dict__



# Generated at 2022-06-23 17:56:57.012612
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # noinspection PyPropertyDefinition
    class TestCachedProperty:

        def __init__(self, f):
            self.f = f

        @cached_property
        def test(self):
            return self.f(self)

    def f(self):
        self.i += 1
        return self.i

    test = TestCachedProperty(f)
    test.i = 0

    # Calling test() should call f() and return 1
    assert test.test == 1

    # Calling test() again should return the cached value (1)
    assert test.test == 1

    # Calling test() again should increment the cached value (1 to 2)
    assert test.test == 2


if __name__ == '__main__':
    import timeit
    from functools import lru_cache

    # Obtain a speed

# Generated at 2022-06-23 17:57:04.191508
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property.

    See:
        - :obj:`test_cached_property___get__`
    """

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    assert obj.__dict__['y'] == 6



# Generated at 2022-06-23 17:57:13.550075
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            async def _z():
                return self.x + 2

            return _z()

    obj = MyClass()
    assert obj.y == 6
    assert obj.y == 6
    assert obj.y == 6
    assert obj.y == 6



# Generated at 2022-06-23 17:57:17.443486
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Foo:

        def bar(self):
            return "bar"

        @cached_property
        def baz(self):
            return self.bar()

    foo = Foo()
    assert foo.baz == "bar"
    assert Foo.baz is not Foo.baz


# Generated at 2022-06-23 17:57:19.661591
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property.__doc__ is not None



# Generated at 2022-06-23 17:57:30.145636
# Unit test for constructor of class cached_property
def test_cached_property():
    from .. logging import get_module_logger

    logger = get_module_logger(__name__)

    # init class containing cached_property
    class A:
        def __init__(self):
            self.x = 0

        @cached_property
        def y(self):
            self.x += 1
            logger.debug(f"self.y called with x={self.x}")
            return self.x

    # test instance
    a = A()
    assert a.x == 0
    assert a.y == 1
    assert a.y == 1
    assert a.x == 1  # class A() should have incremented self.x before setting self.y

    # reset cached_property
    a.y.__delete__(a)
    assert a.x == 1
    assert a.y == 2



# Generated at 2022-06-23 17:57:39.169360
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Test cases
    class Test:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class TestAsync:

        def __init__(self, loop):
            self.loop = loop  # type: ignore
            self.x = 5

        @cached_property
        @asyncio.coroutine
        def y(self) -> Any:
            return self.x + 1  # type: ignore

    # Tests
    obj = Test()
    obj.y
    assert obj.y == 6

    obj = TestAsync(asyncio.get_event_loop())  # type: ignore
    asyncio.get_event_loop().run_until_complete(obj.y)  # type: ignore
    assert obj.y

# Generated at 2022-06-23 17:57:43.462375
# Unit test for constructor of class cached_property
def test_cached_property():

    class Dummy(object):

        @cached_property
        def value(self):
            return 'hello'

    dummy = Dummy()
    # Property job
    assert dummy.value == 'hello'
    # From cache
    assert dummy.value == 'hello'
    del dummy.value
    assert not hasattr(dummy, 'value')


# Generated at 2022-06-23 17:57:55.371859
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest
    from flutils.decorators import cached_property

    class J(object):

        @cached_property
        def x(self):
            return 1

    def t():
        j = J()
        j.x
        x = j.x
        return x

    assert t() == 1

    class C(object):

        @cached_property
        def x(self):
            return 1

    def t():
        c = C()
        x = c.x
        return x

    assert t() == 1

    class C(object):

        @cached_property
        def x(self):
            return 1

        def __repr__(self):
            return '<C x:%r>' % self.x

    def t():
        c = C()
        return c


# Generated at 2022-06-23 17:58:07.970001
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import inspect

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    # The property y is in the class
    assert 'y' in MyClass.__dict__

    # The property y is NOT in the instance
    assert 'y' not in obj.__dict__

    # Retrieving the property y will call the function (and cache the result)
    assert obj.y == 6

    # The property y is now in the instance
    assert 'y' in obj.__dict__

    # Retrieving the property y will NOT call the function (it is cached)
    assert obj.y == 6

    # Assert various things about simple_cached_property

# Generated at 2022-06-23 17:58:19.499751
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest import TestCase as UnitTestCase
    from unittest.mock import patch

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class Testcached_property(UnitTestCase):
        def test_cached_property(self):
            obj = MyClass()
            with patch('flutils.decorators.cached_property.func',
                       return_value=6) as mock_func:
                self.assertEqual(obj.y, 6)
                mock_func.assert_called_once_with(obj)
                delattr(obj, 'y')

# Generated at 2022-06-23 17:58:20.493530
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property.__doc__ is not None

# Generated at 2022-06-23 17:58:26.196197
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    @cached_property
    def foo(self):
        return 'bar'

    class Bar:
        def __init__(self, foo):
            self._foo = foo

        @cached_property
        def x(self):
            return self._foo + '_baz'

    b = Bar('foo')
    assert b.x == 'foo_baz'



# Generated at 2022-06-23 17:58:28.624537
# Unit test for constructor of class cached_property
def test_cached_property():
    class C:
        @cached_property
        def x(self):
            return 3

    assert C().x == 3
    assert C().x == 3

# Generated at 2022-06-23 17:58:32.708680
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6
    obj.x = 8

    assert obj.y == 6
    obj.x = 9


# Generated at 2022-06-23 17:58:36.161066
# Unit test for constructor of class cached_property
def test_cached_property():

    class TestClass:
        def __init__(self):
            self.x = 0

        @cached_property
        def y(self):
            self.y = self.x + 1
            return self.x

    obj = TestClass()
    obj.x = 5
    assert obj.y == 5

# Generated at 2022-06-23 17:58:43.605561
# Unit test for constructor of class cached_property
def test_cached_property():

    @cached_property
    def my_cached_property():

        return None

    class TestObject(object):
        pass

    obj = TestObject()

    assert my_cached_property.__doc__ is None
    assert obj.my_cached_property is None
    assert obj.__dict__['my_cached_property'] is None

    @cached_property
    def my_cached_property():
        """My cached property."""
        return None

    assert my_cached_property.__doc__ == 'My cached property.'


# Generated at 2022-06-23 17:58:50.340660
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.helpers import Timer

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            with Timer() as t:
                retval = self.x + 1
            print(t.interval)
            return retval

    obj = MyClass()

    assert obj.y == 6
    assert obj.y == 6
    assert obj.y == 6



# Generated at 2022-06-23 17:58:58.004844
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Foo:
        def __init__(self, value=0):
            self.value = value

        def __str__(self):
            return str(self.value)

        @cached_property
        def blah(self):
            return self.value + 1

    f = Foo(0)
    assert f.value == 0
    assert f.blah == 1
    assert f.__dict__ == {'value': 0, 'blah': 1}



# Generated at 2022-06-23 17:59:00.878861
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Initialize key variables
    _expected_value = 6

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Test
    my_class = MyClass()
    result = my_class.y

    # Verify
    assert result == _expected_value

# Generated at 2022-06-23 17:59:02.607357
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property(test_cached_property) is not None

# Generated at 2022-06-23 17:59:07.540308
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 17:59:09.139773
# Unit test for constructor of class cached_property
def test_cached_property():
    cp = cached_property(lambda: None)
    assert cp.func == (lambda: None)

# Generated at 2022-06-23 17:59:12.698485
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class cls:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Instantiate class
    obj = cls()

    # Test that y property was created with value 6
    assert obj.y == 6


# Generated at 2022-06-23 17:59:17.555633
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Test the constructor of :class:`flutils.decorators.cached_property`.
    """

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 17:59:20.521778
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property"""
    obj = cached_property(lambda x: 'foo')
    obj.__name__ = 'bar'
    assert obj.__name__ == 'bar'


# Generated at 2022-06-23 17:59:23.698911
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 17:59:33.536429
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test method __get__ of class cached_property
    """

    from unittest import TestCase, main

    class C(object):
        def __init__(self, val=0):
            self._val = val

        @cached_property
        def value(self):
            self._val += 1
            return self._val

    class Test_cached_property___get__(TestCase):
        def test_cached_property___get__(self):
            c = C()
            self.assertEqual(c.value, 1)
            self.assertEqual(c.value, 1)
            self.assertEqual(c._val, 1)

    main()

# Generated at 2022-06-23 17:59:37.146153
# Unit test for constructor of class cached_property
def test_cached_property():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 17:59:40.242764
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test the method __get__ of class :class:`cached_property`
    """
    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 17:59:42.934257
# Unit test for constructor of class cached_property
def test_cached_property():
    obj = cached_property(lambda self: self.x + 1)
    assert isinstance(obj, cached_property)


# Generated at 2022-06-23 17:59:54.091988
# Unit test for constructor of class cached_property
def test_cached_property():
    # Test that the docstring is preserved
    @cached_property
    def example_prop():
        'Example Docstring'
    assert example_prop.__doc__ == 'Example Docstring'
    # Test that the cached_property decorator is applied to the method
    class TestClass:
        @cached_property
        def example_prop(self):
            return 5
    obj = TestClass()
    assert isinstance(obj.__class__.example_prop, cached_property)
    # Test that running the method assigns the attribute
    obj.example_prop
    assert hasattr(obj, 'example_prop')
    # Test that the attribute stores the return value
    assert obj.example_prop == 5
    # Test that the attribute is accessible
    assert obj.__dict__['example_prop'] == 5
    # Test that deleting the attribute

# Generated at 2022-06-23 18:00:05.667779
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import asyncio

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Check that property cached_property.y, when accessed, sets the value.
    assert MyClass.y is None
    obj = MyClass()
    obj.x = 10
    assert obj.y == 11
    # Check that cached_property.y only executes once, after which
    # it sets the value; even if we reset the attribute.
    obj.x = 20
    assert obj.y == 11
    del obj.y
    obj.x = 30
    assert obj.y == 31
    # Check the asyncio.iscoroutinefunction() case.
    del obj.y


# Generated at 2022-06-23 18:00:07.372558
# Unit test for constructor of class cached_property
def test_cached_property():
    cp = cached_property(test_cached_property)
    assert cp.__doc__ == test_cached_property.__doc__



# Generated at 2022-06-23 18:00:10.655838
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    def func(obj):
        obj.y = 6
        return obj.y

    cp = cached_property(func)
    obj = object()
    obj.y = None
    assert cp.__get__(obj, None) == 6



# Generated at 2022-06-23 18:00:17.300766
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    myobj = MyClass()
    myobj.y
    assert hasattr(myobj, 'y')
    assert myobj.y == 6


# Generated at 2022-06-23 18:00:18.603670
# Unit test for constructor of class cached_property
def test_cached_property():
    # assert cached_property is functools.cached_property
    pass

# Generated at 2022-06-23 18:00:19.861693
# Unit test for constructor of class cached_property
def test_cached_property():
    # Constructor of class cached_property passes
    assert cached_property

# Generated at 2022-06-23 18:00:25.219131
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y

# Generated at 2022-06-23 18:00:27.358718
# Unit test for constructor of class cached_property
def test_cached_property():
    class X:
        @cached_property
        def u(self):
            return 1729

    x = X()
    x.u
    assert x.u == 1729

# Generated at 2022-06-23 18:00:30.311963
# Unit test for constructor of class cached_property
def test_cached_property():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    myobject = MyClass()

    assert myobject.y == 6

# Generated at 2022-06-23 18:00:34.931059
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert 'y' in obj.__dict__

# Generated at 2022-06-23 18:00:37.220836
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class TestClass:
        def __init__(self):
            self.x = 17

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.y == 18


# Generated at 2022-06-23 18:00:38.604464
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    return True



# Generated at 2022-06-23 18:00:45.151597
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    # test for the exception
    obj.x = 'hse'
    with pytest.raises(TypeError):
        obj.y



# Generated at 2022-06-23 18:00:48.716617
# Unit test for constructor of class cached_property
def test_cached_property():
    class Faux:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert Faux().y == 6
    assert hasattr(Faux().y, '__call__') is False

# Generated at 2022-06-23 18:00:54.951682
# Unit test for constructor of class cached_property
def test_cached_property():
    # Create a dummy class
    class DummyClass:
        def f(self):
            return 'Function call'

    # Create instance of the dummy class
    a = DummyClass()

    # Check that the cached_property behaves like a regular
    # method when called directly - that is, the function is
    # actually invoked
    assert a.f() == 'Function call'

    # Now cache the result of the function using cached_property
    # but only call the function once
    class CachedClass:
        @cached_property
        def f(self):
            return 'Function call'

    b = CachedClass()
    b.f

    # Check that the actual function was NOT called again
    assert b.f == 'Function call'

# Generated at 2022-06-23 18:00:59.623178
# Unit test for constructor of class cached_property
def test_cached_property():
    class Test:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Test()
    assert obj.y == 6
    obj.x = 10
    assert obj.y == 11
    del obj.y
    assert obj.y == 11

# Generated at 2022-06-23 18:01:04.397609
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:01:14.561587
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test constructor of class cached_property"""
    from nose.tools import assert_in, assert_true, assert_false

    class Test(object):

        def __init__(self):
            self.x = 1
            self.calls = 0

        @cached_property
        def prop(self):
            self.calls += 1
            return self.x

    tt = Test()
    assert_in('prop', tt.__dict__)
    assert_true(hasattr(tt, 'prop'))
    assert_false(hasattr(Test, 'prop'))
    assert_in('prop', Test.__dict__)
    assert_false(hasattr(Test, 'prop'))
    assert_false(hasattr(tt, 'prop'))
    assert_true(tt.prop == 1)
    assert_

# Generated at 2022-06-23 18:01:23.841729
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from .helpers import AsyncMock, AsyncMockPool

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        async def z(self):
            return self.x + 2

        @cached_property
        def a(self):
            return myfunc(self.x)

        @cached_property
        def b(self):
            return myfunc(self.x)

        @cached_property
        async def c(self):
            return await myasyncfunc(self.x)

        @cached_property
        async def d(self):
            return await myasyncfunc(self.x)


# Generated at 2022-06-23 18:01:31.454243
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from . import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def add_1(self):
            return self.x + 1

    obj = MyClass()
    assert obj.add_1 == 6
    obj.x = 10
    assert obj.add_1 == 6


if __name__ == '__main__':

    def func():
        import sys
        import doctest

        sys.exit(doctest.testmod()[0])


    func()

# Generated at 2022-06-23 18:01:36.953152
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @flutils.decorators.cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    # The following will fail if @cached_property doesn't replace itself.
    assert obj.y == 6  # nosec



# Generated at 2022-06-23 18:01:42.799434
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert 'y' in obj.__dict__
    assert obj.__dict__['y'] == 6


# Unit tests for method __init__ of class cached_property

# Generated at 2022-06-23 18:01:47.842087
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__["y"] == 6



# Generated at 2022-06-23 18:01:49.100118
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property


# Unit Test for content of class cached_property

# Generated at 2022-06-23 18:01:49.973307
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property  # use your breakpoint

# Generated at 2022-06-23 18:01:59.662870
# Unit test for constructor of class cached_property
def test_cached_property():
    from functools import partial
    from inspect import Parameter
    from unittest import TestCase
    from unittest.mock import patch

    from more_properties import cached_property

    class C:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class DecoratorArgs(TestCase):
        @patch.object(C.y, "__init__")
        def test_args(self, mock):
            assert len(mock.call_args[1]) == 2

            (args, kwargs) = mock.call_args

            # Validate args
            self.assertEqual(args[0], C.y)
            self.assertIsInstance(args[1], Parameter)
            self.assertE

# Generated at 2022-06-23 18:02:02.388344
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test cached_property constructor

    :rtype: None
    """

    class TestClass1:
        @cached_property
        def test1(self):
            return 1

    assert TestClass1().test1 == 1



# Generated at 2022-06-23 18:02:14.264827
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit tests for method :meth:`~flutils.decorators.cached_property.__get__` for class :class:`~flutils.decorators.cached_property`.

    """

    _result = True

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj1 = MyClass()
    obj2 = MyClass()
    obj1.y = 2
    obj2.y = 2

    if obj1.y != 2:
        _result = False

    if obj2.y != 2:
        _result = False

    if not _result:
        raise AssertionError("Unit test for method __get__ of class cached_property has failed.")


# Unit test

# Generated at 2022-06-23 18:02:23.974089
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""
    from unittest.mock import patch, PropertyMock
    from unittest import TestCase

    # patch asyncio.iscoroutinefunction for this test
    mock_iscoroutinefunction = patch('flutils.decorators.asyncio.iscoroutinefunction').start()
    mock_iscoroutinefunction.return_value = False
    # patch asyncio.ensure_future for this test
    mock_ensure_future = patch('flutils.decorators.asyncio.ensure_future').start()
    mock_ensure_future.return_value = True
    # patch asyncio.iscoroutine for this test
    mock_iscoroutine = patch('flutils.decorators.asyncio.iscoroutine').start()
    mock_isc

# Generated at 2022-06-23 18:02:29.251021
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property.

    """
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    obj.x = 6
    assert obj.y == 7



# Generated at 2022-06-23 18:02:40.051831
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    '''
    Test for method __get__ of class cached_property.
    '''

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    assert obj.__dict__['y'] == 6
    assert obj.y == 6

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            async def do_something():
                await asyncio.sleep(1)
                return self.x + 1

            return do_something()

    loop = asyncio.get_event_loop()
    obj = MyClass()
    fut = obj.y
    loop.run

# Generated at 2022-06-23 18:02:45.880153
# Unit test for constructor of class cached_property
def test_cached_property():
    # Test the proper docstring is generated
    class Class:
        @cached_property
        def simple_property(self):
            "Simple Property"

        @cached_property
        def no_docstring(self):
            pass

    assert Class.simple_property.__doc__ == "Simple Property"
    assert Class.no_docstring.__doc__ is None



# Generated at 2022-06-23 18:02:56.977234
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Test:
        def __init__(self, init_val):
            self.init_val = init_val

        @cached_property
        def square(self):
            return self.init_val ** 2

    test_obj = Test(100)
    assert test_obj.init_val == test_obj.init_val  # noqa: PYL-E1136
    assert test_obj.init_val != test_obj.square  # noqa: PYL-E1136
    assert (test_obj.init_val ** 2) == test_obj.square
    assert (test_obj.init_val ** 3) != test_obj.square  # noqa: PYL-E1136
    assert test_obj.init_val != test_obj.square  # noqa: PYL-E1136

# Generated at 2022-06-23 18:03:05.616642
# Unit test for constructor of class cached_property
def test_cached_property():
    class Foo:

        def __init__(self, a, b=2, c=3):
            self.a = a
            self.b = b
            self.c = c

        @cached_property
        def g(self):
            return self.f()

        @cached_property
        def m(self):
            return self.n

        @cached_property
        def x(self):
            return self.y + 1

        def f(self):
            return self.a + self.b + self.c

        @cached_property
        def h(self):
            return self.a

        @cached_property
        def n(self):
            return self.b

        @cached_property
        def y(self):
            return self.c


# Generated at 2022-06-23 18:03:09.423380
# Unit test for constructor of class cached_property
def test_cached_property():
    # Setup
    class MyClass:
        @cached_property
        def x(self):
            return 5

    # Exercise
    obj = MyClass()

    # Verify
    assert obj.x == 5

    # Cleanup - none necessary


# Generated at 2022-06-23 18:03:11.862413
# Unit test for constructor of class cached_property
def test_cached_property():
    """ Unit test for constructor of class cached_property."""
    # noinspection PyUnusedLocal
    obj = cached_property(
        lambda x: "ribs"
    )  # pylint: disable=unused-variable
    assert True



# Generated at 2022-06-23 18:03:13.682253
# Unit test for constructor of class cached_property
def test_cached_property():
    pass



# Generated at 2022-06-23 18:03:22.324587
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test for method flutils.decorators.cached_property.__get__()
    """

    class MyClass:
        """
        Test class for cached_property.__get__()
        """

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """
            Test method for cached_property.__get__()
            """
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__['y'].result() == 6



# Generated at 2022-06-23 18:03:25.375048
# Unit test for constructor of class cached_property
def test_cached_property():
    class A:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert A().y == 6

# Generated at 2022-06-23 18:03:34.031235
# Unit test for constructor of class cached_property
def test_cached_property():
    # First make sure they are not made the same way
    def foo(self):
        return "foo"

    def bar(self):
        return "bar"

    assert foo != bar

    # Make sure that bar is a cached_property of foo
    foo = cached_property(foo)
    assert foo.func == bar
    assert foo.__doc__ == bar.__doc__
    assert foo.__doc__ == "foo"

    # Make sure that the helper function in cached_property works
    assert foo._wrap_in_coroutine('a') == bar('a')

# Generated at 2022-06-23 18:03:37.224294
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:03:48.156188
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test method for :py:class:`cached_property` in the
    :py:mod:`flutils.decorators` module.
    """
    # Setup
    class TestClass:

        def __init__(self):
            self.x = 10

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()

    # Test __get__
    assert obj.y == 11

    # Test __get__ returning cached value
    obj.x = 15
    assert obj.y == 11

    # Test __delete__
    del obj.y
    assert hasattr(obj, 'y')
    assert obj.y == 16

    # Test __get__ with coroutine
    obj.x = 20

# Generated at 2022-06-23 18:03:53.970793
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class ClassA:
        def __init__(self):
            self.x = 5
            self.y = self.x + 1

        @cached_property
        def y(self):
            return self.x + 1

    obj = ClassA()
    assert obj.y == 6



# Generated at 2022-06-23 18:04:03.492201
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestClass:
        def __init__(self):
            self.x = 5
            self.y = None
            self.z = None

        @cached_property
        def w(self):
            return self.x + 1

        @cached_property
        def y(self):
            return self.x + 2

        async def _z(self):
            return await asyncio.sleep(0.01) + self.x + 3

        @cached_property
        def z(self):
            return self._z()

    obj = TestClass()
    assert obj.w == 6
    with pytest.raises(AttributeError):
        obj.w = 1
    assert obj.y == 7
    with pytest.raises(AttributeError):
        obj.y = 2

    loop = asyncio.get_event

# Generated at 2022-06-23 18:04:09.664347
# Unit test for constructor of class cached_property
def test_cached_property():
    @cached_property
    def sum_num(self):
        return self.x + self.y

    class MyClass:
        def __init__(self):
            self.x = 5
            self.y = 10

    obj = MyClass()
    assert sum_num.__get__(obj, obj) == 15



# Generated at 2022-06-23 18:04:20.993210
# Unit test for constructor of class cached_property
def test_cached_property():
    from .testing import flutils_test_context
    from .testing import LogCapture

    logger_name = 'flutils.decorators.cached_property'
    with flutils_test_context(logger_name=logger_name) as cm:

        with LogCapture() as cm:
            obj = MyClass()
            cm.check(('flutils.decorators.cached_property', 'DEBUG', 'foo'),)
            assert obj.myprop == 42

            obj2 = MyClass()
            cm.check(('flutils.decorators.cached_property', 'DEBUG', 'foo'),)
            assert obj.myprop == obj2.myprop

    with LogCapture() as cm:
        # The second time through, the property shouldn't be called
        # (because the value is cached).
        obj2 = MyClass

# Generated at 2022-06-23 18:04:22.398483
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass

# Generated at 2022-06-23 18:04:29.640041
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property()."""
    import platform

    from flutils.docs.utils import get_test_functions

    results = get_test_functions('../../flutils/decorators.py',
                                 class_name='cached_property')
    assert len(results) == 1
    assert isinstance(results[0], cached_property)

    if platform.python_version() >= '3.8':
        assert (
            "functools.cached_property"
            in cached_property.__doc__
        )


# Generated at 2022-06-23 18:04:39.535376
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit tests for flutils.decorators.cached_property
    """
    import pytest as pt
    from pytest import warns

    # noinspection PyUnusedLocal
    class ClassABC:

        def __init__(self):
            self.x = 5

        # noinspection PyUnusedLocal
        @cached_property
        def y(self):
            return self.x + 1

    # noinspection PyUnusedLocal
    class ClassXYZ:

        def __init__(self):
            self.x = 5

        @pt.mark.asyncio
        async def asyncf(self):
            await asyncio.sleep(0)
            return self.x

        @cached_property
        def xyz(self):
            return self.asyncf()

    obj = ClassABC()

   

# Generated at 2022-06-23 18:04:42.845216
# Unit test for constructor of class cached_property
def test_cached_property():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

# Generated at 2022-06-23 18:04:44.281582
# Unit test for constructor of class cached_property
def test_cached_property():
    assert not hasattr(cached_property, '__get__')

# Generated at 2022-06-23 18:04:52.582155
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property"""

    from unittest.mock import MagicMock

    class MyClass:
        """MyClass Test Class."""

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y = MagicMock(return_value=9)

    # Mock is an attribute
    assert isinstance(obj.y, MagicMock)
    # Cached value of y is 6
    assert obj.y == 6

# Generated at 2022-06-23 18:05:04.843091
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class :obj:`~flutils.decorators.cached_property`.

    Asserts that the :obj:`~flutils.decorators.cached_property` decorator
    creates a lazy-loading property, which is only computed the first time the
    property is accessed.

    Also asserts that the property can be re-computed by deleting the property
    before accessing it again.

    :return: ``None``

    :rtype: None

    """
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    instance = MyClass()

    # Make sure the correct value is returned
    assert instance.y == 6

    # Make sure the value is cached

# Generated at 2022-06-23 18:05:11.204713
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property"""

    from unittest.mock import MagicMock, patch
    from inspect import signature

    # setup
    mock_instance = MagicMock()
    mock_func = MagicMock()

    # test
    decorator = cached_property(mock_func)

    assert decorator.func == mock_func
    assert decorator.__doc__
    assert isinstance(decorator, cached_property)
    assert getattr(decorator, "__qualname__", None)

    assert decorator.__init__.__qualname__ == 'cached_property.__init__'
    assert decorator.__get__.__qualname__ == "cached_property.__get__"

# Generated at 2022-06-23 18:05:13.923009
# Unit test for constructor of class cached_property
def test_cached_property():
    @cached_property
    def x(self):
        return 1

    assert x.__doc__ is None
    assert x.func.__doc__ is None

# Generated at 2022-06-23 18:05:21.590818
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__['y'] == 6



# Generated at 2022-06-23 18:05:25.004168
# Unit test for constructor of class cached_property
def test_cached_property():
    assert hasattr(cached_property, '__doc__')
    assert hasattr(cached_property, '__init__')
    assert callable(cached_property)
    assert callable(cached_property.__init__)



# Generated at 2022-06-23 18:05:28.237414
# Unit test for constructor of class cached_property
def test_cached_property():
    class CachedProperty(object):
        def __init__(self):
            self.a = 5

        @cached_property
        def b(self):
            """b -> a + 1"""
            return self.a + 1

    c = CachedProperty()
    c.b



# Generated at 2022-06-23 18:05:37.216724
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property

    """
    class MyClass:

        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass(5)
    value = obj.y
    assert value == 6
    assert obj.y == 6

    obj.x = 100
    assert obj.y == 6

    del obj.y
    assert obj.y == 101

if __name__ == '__main__':
    import pytest

    pytest.main(["--capture=sys", __file__])

# Generated at 2022-06-23 18:05:42.233597
# Unit test for constructor of class cached_property
def test_cached_property():
    print("Test cached_property")

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    del obj.y
    assert "y" not in obj.__dict__
    assert obj.y == 6



# Generated at 2022-06-23 18:05:43.134489
# Unit test for constructor of class cached_property
def test_cached_property():
    pass



# Generated at 2022-06-23 18:05:48.958845
# Unit test for constructor of class cached_property
def test_cached_property():
    class Test:
        def __init__(self):
            self.x = 0

        @cached_property
        def prop(self):
            self.x += 1
            return self.x

    test = Test()
    for i in range(5):
        assert test.prop == 1
    assert test.x == 1
    del test.prop
    assert test.prop == 2
    # noinspection PyProtectedMember
    assert test.__dict__["prop"] == 2
    assert test.x == 2
    del test.prop
    assert test.prop == 3
    assert test.x == 3