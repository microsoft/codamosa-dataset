

# Generated at 2022-06-23 17:55:47.435158
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    y = obj.y
    assert y == 6



# Generated at 2022-06-23 17:55:49.935947
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5


# Generated at 2022-06-23 17:55:56.731600
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:
        """Class definition for the test method __get__

        Note:
            This class is meant to be used with the decorator
            :obj:`~flutils.decorators.cached_property`.
        """

        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass(5)

    assert obj.y == 6

# Generated at 2022-06-23 17:56:08.078429
# Unit test for constructor of class cached_property
def test_cached_property():
    from functools import cached_property as functools_cached_property
    from flutils.decorators import cached_property as flutils_cached_property

    class M:
        _del_count = 0

        @functools_cached_property
        def functools(self):
            return self

        @flutils_cached_property
        def flutils(self):
            return self

    m = M()
    assert type(m.functools) == type(m.flutils) == M
    m.functools = m.flutils = None
    M._del_count = 0
    del m.functools
    assert M._del_count == 0
    del m.flutils
    assert M._del_count == 1

# Generated at 2022-06-23 17:56:11.100491
# Unit test for constructor of class cached_property
def test_cached_property():
    class Obj:
        x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Obj()
    assert obj.y == 6
    obj.x = 13
    assert obj.y == 6

# Generated at 2022-06-23 17:56:16.146665
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test the cached_property constructor.
    """
    class A (object):
        @cached_property
        def b(self):
            return 5
    my_test_obj = A()
    assert my_test_obj.b == 5


# Generated at 2022-06-23 17:56:23.438056
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    from unittest import TestCase, mock

    from flutils.decorators import cached_property

    class D(object):

        def foo(self):
            return 1

    class T(TestCase):

        def setUp(self):
            self.mock_foo = mock.Mock()
            self.mock_foo.return_value = 2
            self.d = D()
            self.d.foo = self.mock_foo

        def test_foo_cached_property_notset(self):
            cp = cached_property(self.d.foo)
            value = cp.__get__(self.d, type(self.d))
            assert value == 2
            assert self.mock_foo.call_count == 1


# Generated at 2022-06-23 17:56:29.348361
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Foo(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Foo()
    assert obj.y == 6
    obj.y = 'foo'
    assert obj.y == 'foo'
    del obj.y
    assert obj.y == 6



# Generated at 2022-06-23 17:56:32.988292
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Test:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    t = Test()
    cached_property.__get__(t.y, t)

# Generated at 2022-06-23 17:56:33.907394
# Unit test for constructor of class cached_property
def test_cached_property():
    pass

# Generated at 2022-06-23 17:56:38.324541
# Unit test for constructor of class cached_property
def test_cached_property():
    class Test:
        def __init__(self):
            self.__x = 5

        @cached_property
        def y(self):
            return self.__x + 1

    obj = Test()
    assert obj.y == 6


# Generated at 2022-06-23 17:56:44.495198
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class Foo:
        def __init__(self):
            self.calls = 0

        @cached_property
        def bar(self):
            assert self.calls == 0  # Should only get called once.
            self.calls += 1
            return 42

    f = Foo()
    # Note that the code below is *not* equivalent to f.bar()
    f.__dict__["bar"]
    f.__dict__["bar"]
    assert f.calls == 1

# Generated at 2022-06-23 17:56:47.816772
# Unit test for constructor of class cached_property
def test_cached_property():
    # noinspection PyShadowingNames
    class foo:
        a = cached_property(lambda x: x+1)

    obj = foo()

    assert hasattr(obj, 'a')
    assert isinstance(obj.a, cached_property)

    assert obj.a == 2



# Generated at 2022-06-23 17:56:58.087505
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property
    """
    import os
    import unittest

    from . import common
    from .common import _test_decorator

    class MyClass(object):

        def __init__(self, x=5):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    def get_cached_property():
        obj = MyClass(x=5)
        return obj.y

    class Test_cached_property(unittest.TestCase):
        """
        Unit test for method __get__ of class cached_property
        """

        def setUp(self):
            pass

        def tearDown(self):
            pass


# Generated at 2022-06-23 17:57:00.790240
# Unit test for constructor of class cached_property
def test_cached_property():
    a = cached_property(int)
    assert(a.__doc__ == int.__doc__)
    assert(a.func == int)

# Generated at 2022-06-23 17:57:12.982072
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import mock
    from unittest.mock import call
    import random

    import flutils
    from flutils.decorators import cached_property

    class TestClass:

        @cached_property
        def create_random_integer(self):
            """A random integer"""
            return random.randint(0, 100)

    test_instance = TestClass()

    with mock.patch.object(random, "randint") as mock_randint:
        mock_randint.return_value = 42
        # This should call the method that generates the random value
        assert test_instance.create_random_integer == 42
        assert mock_randint.call_count == 1
        # This should _not_ call the method that generates the random value
        assert test_instance.create_random_integer == 42
        # This

# Generated at 2022-06-23 17:57:15.710628
# Unit test for constructor of class cached_property
def test_cached_property():
    assert hasattr(cached_property, '__init__')
    assert callable(cached_property.__init__)


# Generated at 2022-06-23 17:57:27.595922
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        # noinspection PyUnusedLocal
        def __init__(self, x):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1
            # noinspection PyUnresolvedReferences
    obj = MyClass(5)
    # noinspection PyUnresolvedReferences
    # noinspection PyTypeChecker
    assert obj.x == 5
    # noinspection PyUnresolvedReferences
    # noinspection PyTypeChecker
    assert obj.y == 6
    # noinspection PyUnresolvedReferences
    # noinspection PyTypeChecker
    assert obj.__dict__['y'] == 6
    #
    # Test that x is not cached
    # noinspection PyUnresolvedReferences
    obj.x = 10
   

# Generated at 2022-06-23 17:57:36.850813
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():  # noqa: D103 ; flake8: noqa
    import pytest
    import asyncio
    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    @cached_property
    def z(x):
        return x + 1

    class MyAsyncClass:
        def __init__(self):
            self.x = 5

        @cached_property
        @asyncio.coroutine
        def y(self):
            return self.x + 1

    @cached_property
    @asyncio.coroutine
    def w(x):
        return x + 1

    obj = MyClass()
    assert obj.y == 6


# Generated at 2022-06-23 17:57:45.518626
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Cls:
        @cached_property
        def prop(self):
            return 'value'

        @cached_property
        async def asyn_prop(self):
            return 'async value'

    cls = Cls()

    print(cls.prop)
    print(cls.prop)
    print(cls.prop)
    print()

    print(cls.asyn_prop)
    print(cls.asyn_prop)
    print(cls.asyn_prop)
    print()

    loop = asyncio.get_event_loop()
    loop.run_until_complete(cls.asyn_prop)
    loop.run_until_complete(cls.asyn_prop)
    loop.run_until_complete(cls.asyn_prop)



# Generated at 2022-06-23 17:57:52.806715
# Unit test for constructor of class cached_property
def test_cached_property():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    # Now reset the cached value
    del obj.y
    assert obj.y == 6

    # Re-set the cached value to a new value
    obj.x = 8
    assert obj.y == 9

# Generated at 2022-06-23 17:57:55.578834
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class Foo:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Foo()
    assert obj.y == 6

# Generated at 2022-06-23 17:58:00.348331
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    return obj.y

# Generated at 2022-06-23 17:58:06.312547
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class DemoClass:
        # noinspection PyPep8Naming
        @cached_property
        def square_of_x(self):
            return self.x * self.x

        def __init__(self, x):
            self.x = x

    demo = DemoClass(5)
    assert demo.square_of_x == 25



# Generated at 2022-06-23 17:58:10.601072
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property.
    """
    import pytest
    from .fauxcached_property import FauxCachedProperty

    with pytest.raises(AttributeError):
        FauxCachedProperty().__get__()

    assert FauxCachedProperty().__get__(FauxCachedProperty(), None) is None

# Generated at 2022-06-23 17:58:16.809418
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y ==  6
    assert obj.y ==  6
    assert obj.y ==  6

# Generated at 2022-06-23 17:58:20.400417
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property."""

    class Bar:
        @cached_property
        def foo(self):
            return 'baz'

    assert Bar().foo == 'baz'

# Generated at 2022-06-23 17:58:28.336691
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    import pytest
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    obj.x = 7
    assert obj.y == 6

    with pytest.raises(TypeError):
        obj = MyClass()
        obj.y()  # pragma: no cover


# Generated at 2022-06-23 17:58:32.496208
# Unit test for constructor of class cached_property
def test_cached_property():
    class A(object):

        @cached_property
        def a(self):
            return 'aaa'

        @a.setter
        def a(self, value):
            raise RuntimeError

        @a.deleter
        def a(self):
            del self.a

    obj = A()
    assert obj.a == 'aaa'

# Generated at 2022-06-23 17:58:42.838583
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from . import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return asyncio.sleep(2)


    class MySubClass(MyClass):

        def __init__(self):
            self.x = 5

    # Test __doc__
    assert MyClass.y.__doc__ == "A property decorator that is only computed " \
                                "once per instance and then replaces itself " \
                                "with an ordinary attribute.\n\nDeleting " \
                                "the attribute resets the property.\n\nNote:\n" \
                                "    In Python 3.8 the " \
                               

# Generated at 2022-06-23 17:58:46.533795
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert isinstance(obj.y, int)
    assert obj.y == 6


# Generated at 2022-06-23 17:58:54.663292
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pprint
    from unittest import mock

    class MyClass:
        @cached_property
        def y(self):
            return 42

    obj = MyClass()
    attr = getattr(obj, 'y')
    assert attr == 42
    assert obj.__dict__['y'] == 42

    with mock.patch('asyncio.iscoroutinefunction', return_value=True):

        @asyncio.coroutine
        def func_(obj):
            obj.x = 1
            return 42

        cached_property.func = func_
        assert obj.__dict__['y'] == 42
        assert obj.x == 1

    pprint.pprint("  Module %s passed !" % __name__)

# Generated at 2022-06-23 17:58:56.884770
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property.__doc__
    d = cached_property(lambda x: x)
    assert d.__doc__
    assert d.func

# Generated at 2022-06-23 17:59:05.232976
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    def create_mock_self(mock_x):
        class MockSelf:
            def __init__(self):
                self.x = mock_x

            @cached_property
            def y(self):
                return self.x + 1

        return MockSelf()

    # Create mock obj.
    mock_obj = create_mock_self(5)
    assert not hasattr(mock_obj, 'y')

    # Test read-only.
    assert mock_obj.y == 6
    assert hasattr(mock_obj, 'y')
    assert mock_obj.y == 6
    mock_obj.y = 2
    assert mock_obj.y == 6

    # Test cls.
    assert cached_property.__get__(None, None) == cached_property

    # Test exception.
    mock

# Generated at 2022-06-23 17:59:08.424816
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    o = MyClass()
    assert o.y == 6



# Generated at 2022-06-23 17:59:12.131366
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    @cached_property
    def myfunc():
        return "hello"

    assert myfunc.__get__(None, str) == myfunc
    assert myfunc.__get__({}, str) == "hello"
    assert myfunc.__get__({}, str) == "hello"

# Generated at 2022-06-23 17:59:15.358037
# Unit test for constructor of class cached_property
def test_cached_property():
    class A:
        def __init__(self):
            self.x = 1

        @cached_property
        def foo(self):
            return self.x + 1

    cls = A()
    assert cls.foo == 2
# EOF

# Generated at 2022-06-23 17:59:21.103673
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Unit test for constructor of class cached_property.

    *New in version 0.2.0*
    """

    # Create a class
    class MyClass:

        # Create a constructor
        def __init__(self):
            self.x = 5

        # Apply the cached_property decorator
        @cached_property
        def y(self):
            return self.x + 1

    # Create an object
    _obj = MyClass()

    # Test the results
    assert _obj.y == 6



# Generated at 2022-06-23 17:59:30.600969
# Unit test for constructor of class cached_property
def test_cached_property():
    import pytest

    from flutils.decorators import cached_property

    # noinspection PyPep8Naming
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    with pytest.raises(AttributeError):
        del obj.y

    assert obj.y == 6
    assert obj.y == 6  # Fixes https://bit.ly/2Qf8Wx3

    with pytest.raises(AttributeError):
        del obj.y

    assert obj.y == 6



# Generated at 2022-06-23 17:59:34.441720
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x

    obj = MyClass()
    assert obj.y == obj.y

# Generated at 2022-06-23 17:59:40.024484
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for cached_property."""

    class MyClass:
        """Class for cached_property test."""

        def __init__(self):
            """Initialize MyClass."""
            self.x = 5

        @cached_property
        def y(self):
            """Define foo."""
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 17:59:42.041669
# Unit test for constructor of class cached_property
def test_cached_property():
    assert hasattr(cached_property, "__doc__")



# Generated at 2022-06-23 17:59:44.213313
# Unit test for constructor of class cached_property
def test_cached_property():
    testobj = cached_property(lambda x: x + 1)
    assert testobj.func(1) == 2

# Generated at 2022-06-23 17:59:48.296939
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 17:59:52.720977
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 17:59:58.659705
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import asyncio

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    val = obj.y
    assert val == 6



# Generated at 2022-06-23 18:00:03.341964
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 18:00:08.526685
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class C:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = C()
    assert obj.y == 6



# Generated at 2022-06-23 18:00:17.502073
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    """
    import unittest
    import unittest.mock
    import flutils.decorators

    class MyTest(unittest.TestCase):
        """Unit test for
        """

        class MyClass:
            """
            """

            def __init__(self):
                self.x = 5

            @flutils.decorators.cached_property
            def y(self):
                return self.x + 1

    MyTest.MyClass.__init__.__dict__['__name__'] = '__init__'
    MyTest.MyClass.y.__dict__['__name__'] = 'y'

    MyTest.MyClass.__dict__['__name__'] = 'MyClass'

    obj = MyTest.MyClass()


# Generated at 2022-06-23 18:00:20.625690
# Unit test for constructor of class cached_property
def test_cached_property():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:00:31.259789
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""
    import pytest

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    obj.x = 6
    assert obj.y == 6

    def test(obj, cls):
        func = obj.y
        value = obj.__dict__[func.__name__]
        return func, value

    # noinspection PyTypeChecker
    func, value = test(obj, None)
    assert func is obj.__class__.y
    assert value == 6



# Generated at 2022-06-23 18:00:43.423475
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import asyncio

    class C:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = C()
    assert obj.y == 6

    # Combining `@cached_property` with asyncio

    class C:
        def __init__(self):
            self.x = 5

        @cached_property
        async def y(self):
            await asyncio.sleep(1)
            return self.x + 1

    obj = C()
    assert asyncio.iscoroutinefunction(obj.y)
    assert not asyncio.iscoroutine(obj.y)
    f = asyncio.ensure_future(obj.y)
    assert asyncio.iscoroutine(f)


# Generated at 2022-06-23 18:00:48.077939
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 18:00:56.586884
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property.

    .. versionadded:: 0.2.0
    """
    import unittest
    import sys
    import string

    # noinspection PyPep8Naming
    class TestCachedProperty(unittest.TestCase):
        """Unit tests for class ``cached_property``.

        .. versionadded:: 0.2.0

        """

        def test_simple(self):
            from flutils.decorators import cached_property

            class ExampleClass:
                def __init__(self):
                    self.x = 5

                @cached_property
                def y(self):
                    return self.x + 1

            self.assertEqual(ExampleClass().y, 6)

        def test_delete(self):
            from flutils.decorators import cached_property



# Generated at 2022-06-23 18:01:04.438571
# Unit test for constructor of class cached_property
def test_cached_property():
    # make sure the docstring gets copied over
    class Foo:
        @cached_property
        def prop(self):
            """A prop docstring"""
            return None

    # make sure __doc__ is set
    assert Foo().prop.__doc__ == "A prop docstring"

    # make sure the property is cached
    class Foo:
        def _get_prop(self):
            "A prop docstring"

        prop = cached_property(_get_prop)

    assert Foo().prop.__doc__ == "A prop docstring"

    # make sure the property is deletable
    class Foo:
        @cached_property
        def prop(self):
            "A prop docstring"

    obj = Foo()
    obj.prop
    del obj.prop
    assert not hasattr(obj, "prop")



# Generated at 2022-06-23 18:01:12.714191
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest import TestCase
    from unittest.mock import patch

    tc = TestCase()

    def func(obj):
        return obj.x + 1

    with patch.object(cached_property, 'func', func):
        assert cached_property.func == func

        obj = MyClass()
        result = obj.y
        tc.assertEqual(result, 6)

        obj = MyClass()
        result = obj.y
        tc.assertEqual(result, 6)

        obj.x = 10
        result = obj.y
        tc.assertEqual(result, 6)

    return

# Generated at 2022-06-23 18:01:22.802666
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test method __get__ of class cached_property"""
    from functools import partial

    class TestCachedProperty:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    t = TestCachedProperty()
    func1 = partial(TestCachedProperty.y.__get__, t)

    assert t.y == 6
    assert func1() == 6

    assert t.__dict__ == {'x': 5, 'y': 6}

    assert t.y == 6
    assert func1() == 6

    del t.y
    assert TestCachedProperty.y.__get__(t) == 6



# Generated at 2022-06-23 18:01:32.869861
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    global __test_cached_property___get___x

    __test_cached_property___get___x = 5

    class MyClass:
        @cached_property
        def y(self):
            return __test_cached_property___get___x + 1

    assert MyClass.y is cached_property  # If outside of MyClass, it's the cached_property function
    assert MyClass().y == 6  # If inside of MyClass, it's the cached_property value
    __test_cached_property___get___x = 10
    assert MyClass().y == 6  # The cached_property value is not recomputed, even though the value of __test_cached_property___get___x changed


# Generated at 2022-06-23 18:01:34.790035
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils import decorators

    class Foo:
        @decorators.cached_property
        def bar(self):
            "The bar"

    assert Foo.bar.__doc__ == "The bar"



# Generated at 2022-06-23 18:01:44.330395
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.common import set_asyncio_event_loop, teardown_asyncio_event_loop
    assert set_asyncio_event_loop()
    from typing import Dict
    import types

    class MyClass:
        """An example class for testing this decorator."""

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    def test_async_func(obj):
        return asyncio.sleep(0.1)

    obj = MyClass()
    assert isinstance(obj.y, int)
    assert obj.y == 6
    assert isinstance(obj.y, int)
    del (obj.y)
    assert not hasattr(obj, 'y')

# Generated at 2022-06-23 18:01:47.499767
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Testing the constructor for class cached_property

    Unit test for constructor of class cached_property
    """
    test_msg = "Test cached_property docstring"
    assert cached_property.__doc__ == test_msg

# Generated at 2022-06-23 18:01:54.804852
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.__dict__['y'] == 6

    obj = MyClass()
    assert obj.__dict__['y'] == 6


# Generated at 2022-06-23 18:02:03.236652
# Unit test for constructor of class cached_property
def test_cached_property():
    """ Unit test for constructor of class cached_property
    """
    from flutils.decorators import cached_property
    import asyncio
    import pytest

    async def make_y(self):
        """ Make y value

        :param self: object
        :return: y
        """
        return self.x + 1

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        async def y2(self):
            return await make_y(self)

    obj = MyClass()
    assert obj.y.__doc__ == make_y.__doc__
    assert obj.y == 6
    assert obj.__dict__["y"] == 6
    assert obj.y

# Generated at 2022-06-23 18:02:14.650543
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    print('\n' * 2)

    from flutils.decorators import cached_property

    class AClass:
        called = 0

        def __init__(self, status):
            self._status = status

        @cached_property
        def status(self):
            """status of this class"""
            self.called += 1
            return self._status

    a = AClass("good")
    assert a.status == "good"
    assert a.called == 1
    assert a.status == "good"
    assert a.called == 1
    del a.status
    assert a.status == "good"
    assert a.called == 2
    print("\n", "-" * 79, "\n")


if __name__ == '__main__':
    test_cached_property___get__()

# Generated at 2022-06-23 18:02:18.844346
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import Mock, patch
    from concurrent.futures import Future
    from flutils.decorators import cached_property


    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1


    # No obj, should return the instance of cached_property
    assert MyClass.y is MyClass.y


    # With obj, should return the value of the cached_property
    obj = MyClass()
    assert isinstance(MyClass.y.__get__(obj, MyClass), Future) is False
    assert obj.y == obj.y


    # With obj, coroutine function.  Should return the value of the
    # cached_property

# Generated at 2022-06-23 18:02:26.899312
# Unit test for method __get__ of class cached_property

# Generated at 2022-06-23 18:02:38.536301
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for the method __get__ of the class cached_property.

    Args:
        None

    Returns:
        None

    """
    # pylint: disable=protected-access
    # pylint: disable=unexpected-keyword-arg
    # pylint: disable=too-few-public-methods
    # pylint: disable=no-member
    # pylint: disable=too-many-instance-attributes

    class TestClass:
        """
        The test class.

        """

        @cached_property
        def test(self):
            """
            Test method.

            """
            return 1

    test = TestClass()
    assert not hasattr(test, 'test')
    assert test.test == 1
    assert test.test == 1
    assert test.__

# Generated at 2022-06-23 18:02:45.322271
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """This function tests method __get__ of class cached_property

    Args:
        None

    Returns:
        None

    Functionality:
        * tests :meth:`cached_property.__get__` of class
          :class:`cached_property`
        * tests :meth:`cached_property.__get__` of class
          :class:`cached_property` for async
    """
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    assert obj.y == 6
    obj.x += 1
    obj.y
    assert obj.y == 7

    async def myfunc():
        await asyncio.sleep

# Generated at 2022-06-23 18:02:51.504671
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:
        def __init__(self):
            self._y = 5

        @cached_property
        def y(self):
            return self._y + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__['y'] == 6
    assert obj.y == 6



# Generated at 2022-06-23 18:02:56.044059
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class AClass:
        def __init__(self, x):
            self.x = x

        @cached_property
        def b(self):
            return self.x + 1

    obj = AClass(3)
    assert obj.b == 4
    obj.__dict__['b'] = 5
    assert obj.b == 5



# Generated at 2022-06-23 18:02:59.489143
# Unit test for constructor of class cached_property
def test_cached_property():
    class Foo:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    foo = Foo(7)
    assert foo.y == 8
    assert foo.__dict__['y'] == 8

# Generated at 2022-06-23 18:03:02.485309
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test
    """
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    return obj.y


# Generated at 2022-06-23 18:03:08.132420
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property
    from unittest import TestCase

    class MyClass(TestCase):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6, "Cached Property not set correctly"


# Unit test to confirm _wrap_in_coroutine() is triggered

# Generated at 2022-06-23 18:03:11.108170
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:03:23.018353
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        """Test class of cached_property"""

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    assert obj.y == 6

    # Test for Python 3.6 and 3.7
    assert obj.y == 6

    # Test for Python 3.8
    try:
        from functools import cached_property
    except ImportError:
        pass
    else:
        class MyClass:
            """Test class of cached_property"""

            def __init__(self):
                self.x = 5

            @cached_property
            def y(self):
                return self.x + 1

        obj = MyClass()
        obj.y

# Generated at 2022-06-23 18:03:26.526524
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import Mock

    class C:
        @cached_property
        def mock(self):
            return Mock()

    c = C()
    c.mock
    assert c.__dict__['mock'].called



# Generated at 2022-06-23 18:03:31.290886
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        class_name = "MyClass"

    prop = cached_property(str)

    assert prop.__doc__ == "str(object='')"
    assert prop.func == str

    assert prop.__get__(MyClass, MyClass.__class__) == "MyClass"

# Generated at 2022-06-23 18:03:35.782101
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    '''
    test_cached_property___get__

    Call __get__ of class cached_property
    '''

    class A:
        @cached_property
        def get_y(self):
            return self.x + 1

    a = A()
    a.x = 5

    assert a.get_y == 6



# Generated at 2022-06-23 18:03:36.650589
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    assert cached_property


# Generated at 2022-06-23 18:03:41.026221
# Unit test for constructor of class cached_property
def test_cached_property():
    """ Unit test for the class cached_property
    """
    import flutils.decorators as decorators

    # Create a class to test
    class MyClass:
        def __init__(self):
            self.x = 5

        @decorators.cached_property
        def y(self):
            return self.x + 1

    # Create instance of class
    obj = MyClass()

    # Test
    assert obj.y == 6



# Generated at 2022-06-23 18:03:42.746861
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from .testing import run_test_module

    run_test_module(name=__name__)

# Generated at 2022-06-23 18:03:49.605016
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class TestClass:

        def __init__(self):
            self.x = 0

        @cached_property
        def name(self):
            return "Marcel"

        @cached_property
        def y(self):
            self.x += 1
            return self.x + 1

    cls = TestClass()

    assert cls.name == "Marcel"
    assert cls.name == "Marcel"

    assert cls.y == 2
    assert cls.y == 2

    del cls.y

    assert cls.y == 2
    assert cls.x == 1

# Generated at 2022-06-23 18:03:54.544269
# Unit test for constructor of class cached_property
def test_cached_property():

    @cached_property
    def y(self):
        return self.x+1

    class MyClass:
        def __init__(self):
            self.x = 5

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 18:04:03.832362
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property


    class MyClass(object):

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1


    class MyClass2(object):

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x + 1

    assert issubclass(MyClass, object)

    mc1 = MyClass()
    assert isinstance(mc1, MyClass)
    assert hasattr(mc1, 'y')
    assert hasattr(mc1, 'x')

# Generated at 2022-06-23 18:04:13.046767
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from .cached_property import cached_property

    class T(object):

        def __init__(self):
            """Initialize class"""
            self._count = 0

        @cached_property
        def nc(self):
            """Non-cached property"""
            return self._count

        @cached_property
        def cp(self):
            """Cached property"""
            self._count += 1
            return self._count

    t = T()

    assert t.nc == 0
    assert t.nc == 0

    assert t.cp == 1
    assert t.cp == 1
    t._count = 50
    assert t.cp == 1


# Generated at 2022-06-23 18:04:23.392662
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class TestClass:

        def __init__(self, value):
            self.__value = value
            self.__set_false_initially = False

        @cached_property
        def property(self):
            return self.__value

        @cached_property
        def bool_property(self):
            return self.__set_false_initially

        def flip_bool_property(self):
            self.__set_false_initially = not self.__set_false_initially

    obj = TestClass(42)
    assert obj.property == 42
    assert obj.property == 42
    assert obj.property == 42
    assert obj.property == 42

    obj.flip_bool_property()
    assert not obj.bool_property
    assert not obj.bool_property
    assert not obj.bool_property


# Generated at 2022-06-23 18:04:27.259931
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


# Generated at 2022-06-23 18:04:35.620245
# Unit test for constructor of class cached_property
def test_cached_property():
    class Classy:
        @cached_property
        def did_it_work(self):
            return 'yes!'

    class SubClassy(Classy):
        @cached_property
        def oh_yeah(self):
            return 'damn right!'

    obj = SubClassy()
    assert getattr(obj, 'did_it_work', None) == 'yes!'
    assert getattr(obj, 'oh_yeah', None) == 'damn right!'


if __name__ == '__main__':
    test_cached_property()

# Generated at 2022-06-23 18:04:41.335885
# Unit test for constructor of class cached_property
def test_cached_property():
    import pytest
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    with pytest.raises(AttributeError):
        y = MyClass().y
        y = MyClass().y

# Generated at 2022-06-23 18:04:46.093813
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test cached_property decorator

    *New in version 0.2.0*
    """

    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.y == 6



# Generated at 2022-06-23 18:04:50.405977
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit tests for method ``__get__`` of class ``cached_property``
    """

    def test():
        raise NotImplementedError

    class MyClass:
        @cached_property
        def test(self):
            return test()

    obj = MyClass()

    assert obj.test is test
    assert obj.__dict__['test'] is test


# Generated at 2022-06-23 18:04:57.588479
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import TestCase

    class A:
        @cached_property
        def b(self):
            return 1

    class C(TestCase):
        def test_cached_property___get__(self):
            self.assertEqual(A().b, 1)

    C().test_cached_property___get__()

# Generated at 2022-06-23 18:05:01.931621
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__['y'] == 6



# Generated at 2022-06-23 18:05:09.675603
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import MagicMock

    class Obj:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Obj()

    # Test the method __get__ when the object is None
    assert isinstance(Obj.y, cached_property)

    # Test the method __get__ when the object is not None
    assert obj.y == 6

    # Test the method __get__ when the function is a coroutine
    with MagicMock() as func:
        func.return_value = "coroutine"

        @cached_property
        @asyncio.coroutine
        def z(self):
            return (yield from asyncio.sleep(0.01, result="coroutine"))

        Obj.z

# Generated at 2022-06-23 18:05:18.172985
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest import TestCase, mock

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.x = 6
    # Assert property was attached
    assert hasattr(obj, 'y')
    # Assert property is attached to class
    assert MyClass.y is not None
    # Assert the value is returned
    assert obj.y == 7
    # Assert the value of the property
    assert obj.__dict__['y'] == 7
    # Assert the value is cached
    assert obj.y == 7


# Generated at 2022-06-23 18:05:26.408749
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Test cached_property

    Test the constructor of the cached_property class.

    :return: None
    """

    class MyClass:

        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    obj1 = MyClass(5)
    assert obj1.y == 6, 'Parameter not cached'

    # Added for test coverage
    del obj1.y
    assert obj1.y == 6, 'Cached property not deleted'

# Test code for cached_property

# Generated at 2022-06-23 18:05:28.429825
# Unit test for constructor of class cached_property
def test_cached_property():
    obj = cached_property(str.lower)
    assert obj


# Unit test to check function is a coroutine function

# Generated at 2022-06-23 18:05:38.326548
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from functools import partial

    from flutils.decorators import cached_property

    class CachedPropertyTest:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = CachedPropertyTest()
    value = obj.y
    assert value == 6
    assert isinstance(value, partial) is False
    assert obj.__dict__['y'] == 6

    class CachedCoroutinePropertyTest:

        def __init__(self):
            self.x = 5

        @cached_property
        async def y(self):
            return self.x + 1

    obj = CachedCoroutinePropertyTest()
    value = asyncio.run(obj.y)
    assert value == 6

# Generated at 2022-06-23 18:05:45.687874
# Unit test for constructor of class cached_property
def test_cached_property():
    class Foo:

        def __init__(self):
            self.x = ['foo']

        @cached_property
        def prop(self):
            """I'm the prop property."""
            return self.x

    f = Foo()
    p = f.prop
    q = f.prop
    assert p is q

    f.x.append('bar')
    p1 = f.prop
    assert p1 is not p
    assert p1 != p

    del f.prop
    p2 = f.prop
    assert p2 != p1
    assert p2 == ['foo', 'bar']

    assert Foo.prop.__doc__ == "I'm the prop property."