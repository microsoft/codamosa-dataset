

# Generated at 2022-06-23 17:55:45.451776
# Unit test for constructor of class cached_property
def test_cached_property():
    class A:
        def __init__(self, n):
            self.n = n

        @cached_property
        def foo(self):
            return self.n ** 2

    a = A(2)
    assert a.foo == (2 ** 2)

# Generated at 2022-06-23 17:55:57.647221
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import time

    class Test(object):

        def __init__(self):
            self.a = False

        @cached_property
        def slow_property(self):
            time.sleep(1)
            return 1

        @cached_property
        def wicked_slow_property(self):
            time.sleep(5)
            return 1

    test_obj = Test()

    # Running the method will take 1 second
    start = time.time()
    test_obj.slow_property
    assert (time.time() - start) < 1

    # The second time should be instant
    start = time.time()
    test_obj.slow_property
    assert (time.time() - start) < 0.1

    # A different instance should run at full speed
    test_obj2 = Test()

# Generated at 2022-06-23 17:56:09.295514
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest
    from unittest.mock import MagicMock

    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    test_obj = TestClass()

    assert test_obj.y == 6
    assert test_obj.y == 6
    assert test_obj.__dict__['y'] == 6

    test_obj.__dict__.update(y=None)
    assert test_obj.y == 6

    del test_obj.y
    assert test_obj.y == 6

    with pytest.raises(TypeError):
        test_obj.y.result()

    with pytest.raises(AttributeError):
        test_obj.y.set_result(2)




# Generated at 2022-06-23 17:56:10.220151
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    return



# Generated at 2022-06-23 17:56:15.813935
# Unit test for constructor of class cached_property
def test_cached_property():

    # pylint: disable=no-self-use
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 17:56:19.368084
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """ Test for method __get__ of class cached_property """

    # mock object
    class Obj:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Obj()
    assert obj.y == 6

# Generated at 2022-06-23 17:56:25.708441
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # noinspection PyTypeChecker,PyUnresolvedReferences,PyUnusedLocal
    class Class:
        def __init__(self, value):
            self.value = value

        @cached_property
        def property(self):
            return self.value * 2

    x = Class(10)
    assert x.property == 20
    assert isinstance(x.__dict__['property'], int)



# Generated at 2022-06-23 17:56:27.845431
# Unit test for constructor of class cached_property
def test_cached_property():
    obj = cached_property(5)
    assert obj is not None


# Generated at 2022-06-23 17:56:36.338486
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    @asyncio.coroutine
    def async_test_function():
        return 5

    class AsyncClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return async_test_function()

    obj = MyClass()
    obj.y
    assert obj.__dict__['y'] == 6
    assert obj.y == 6

    obj2 = AsyncClass()
    assert isinstance(obj2.y, asyncio.Future)
    assert isinstance(obj2.__dict__['y'], asyncio.Future)

# Generated at 2022-06-23 17:56:42.023776
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1
    
    obj = MyClass()
    
    assert obj.y == 6
    assert hasattr(MyClass, 'x')
    assert hasattr(obj, 'y')
    assert not hasattr(MyClass, 'y')


# Generated at 2022-06-23 17:56:48.330299
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test that method __get__ of class cached_property works
    :return:
    """

    import sys

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    if sys.version_info[0] > 3 or (sys.version_info[0] == 3 and sys.version_info[1] >= 8):
        assert obj.y == 6
    else:  # pragma: no cover
        assert obj.y() == 6

# Generated at 2022-06-23 17:56:51.608048
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Coverage test."""

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 17:57:00.515005
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():  # noqa: D103
    from flutils.objects import Base

    class MyClass(Base):

        def __init__(self, value: int):
            self._value = value

        @cached_property
        def cached_property_value(self):
            return self._value + 1

    obj = MyClass(5)
    assert obj.cached_property_value == 6
    assert 'cached_property_value' in obj.__dict__
    assert obj.__dict__['cached_property_value'] == 6
    assert obj.cached_property_value == 6
    assert obj._value == 5

    del obj.cached_property_value
    assert 'cached_property_value' not in obj.__dict__


# Generated at 2022-06-23 17:57:09.519197
# Unit test for constructor of class cached_property
def test_cached_property():
    x = 5

    class MyClass:

        @cached_property
        def y(self):
            return x + 1

    class MyClass2:
        @cached_property
        async def y(self):
            return x + 1

    obj = MyClass()
    obj2 = MyClass2()

    assert obj.y == 6
    assert isinstance(obj.__dict__.get('y'), int)
    assert obj.y == 6
    assert asyncio.iscoroutinefunction(obj2.y)
    assert asyncio.iscoroutine(obj2.y)

# Generated at 2022-06-23 17:57:19.464964
# Unit test for constructor of class cached_property
def test_cached_property():
    from functools import wraps

    class Noop(object):

        def __init__(self, func):
            wraps(func)(self)
            self.called = 0

        def __call__(self, *args, **kwargs):
            self.called += 1
            return self.__wrapped__(*args, **kwargs)

    class Test(object):

        def __init__(self, foo):
            self.foo = foo

        @Noop
        @cached_property
        def bar(self):
            return self.foo + 1

        @Noop
        @cached_property
        def gazonk(self):
            return self.foo * 2

    t = Test(42)
    assert t.bar == 43
    assert t.__dict__['bar'] == 43
    assert t.bar == 43


# Generated at 2022-06-23 17:57:23.735237
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class Calc(object):

        def __init__(self):
            self.x = 5

        @cached_property
        def result(self):
            return self.x * 5

    obj = Calc()
    assert obj.result == 25



# Generated at 2022-06-23 17:57:33.631105
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    @cached_property
    def my_cachedr_property(self):
        return "my value"

    class MyClass:
        def __init__(
            self,
            use_cached_property=False,
            use_coroutine_function=False,
            my_cached_property=None,
        ):
            self.use_cached_property = use_cached_property
            self.use_coroutine_function = use_coroutine_function
            self.my_cached_property = my_cached_property

    obj = MyClass()

    # When use_cached_property is False
    obj.use_cached_property = False
    assert my_cached_property.__get__(obj, None) == "my value"

# Generated at 2022-06-23 17:57:38.452291
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property.
    """
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 17:57:45.489789
# Unit test for constructor of class cached_property
def test_cached_property():
    """ Unit test for constructor of class cached_property

    :return:
    """
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """A property decorated with cached_property

            :return:
            """
            return self.x + 1

    assert hasattr(cached_property, '__doc__')
    assert hasattr(cached_property, '__init__')

    obj = MyClass()
    assert obj.y == 6
    assert obj.y == 6
    assert obj.y == 6



# Generated at 2022-06-23 17:57:51.591387
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    This function is a unit test for method __get__ of class cached_property.

    It will run the unit test without coverage.

    """
    import unittest
    from flutils.tests.decorators import DecoratorsTests as TestSuite

    TestSuite.test_cached_property___get__()



# Generated at 2022-06-23 17:57:52.981122
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import doctest
    doctest.testmod(raise_on_error=True)

# Generated at 2022-06-23 17:57:54.619262
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property.__doc__ is not None
    assert isinstance(cached_property.__doc__, str)


# noinspection PyPep8Naming

# Generated at 2022-06-23 17:58:04.700199
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest import TestCase, main

    class DummyTestCase(TestCase):
        def setUp(self):
            class DummyClass:
                def __init__(self):
                    self.x = 5

                @cached_property
                def y(self):
                    return self.x + 1

            self.obj = DummyClass()

        def test_cached_property(self):
            self.assertEqual(self.obj.y, 6, 'test 1')
            self.obj.x = 10
            self.assertEqual(self.obj.y, 6, 'test 2')

    main()

# Generated at 2022-06-23 17:58:10.722270
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Verify that the method __get__ works as expected.
    """
    # Create instance
    obj = _Base()
    # Verify that obj._foo() is not in the dictionary
    assert obj.__dict__.get('_foo') is None
    # Verify obj.foo is 42
    assert obj.foo == 42
    # Verify that obj._foo() is now in the dictionary
    assert obj.__dict__.get('_foo') == asyncio.Future()
    return

# Generated at 2022-06-23 17:58:14.728305
# Unit test for constructor of class cached_property
def test_cached_property():
    class my:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = my()
    assert obj.y == 6

# Generated at 2022-06-23 17:58:21.435426
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""
    class C:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = C()
    assert obj.y == 6

    # Test that the method is only called once
    obj.x = 6
    assert obj.y == 6



# Generated at 2022-06-23 17:58:23.955100
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""

    # NOTE: this unit test is valid for Python 3.6 and up

    # noinspection PyUnusedLocal
    class C:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = C()
    assert obj.y == 6, 'object obj.y == 6 failed'


# Generated at 2022-06-23 17:58:30.280516
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test method __get__ of class cached_property
    """

    class TestClass:
        def __init__(self, value):
            self.value = value

        @cached_property
        def prop(self):
            return self.value

    obj = TestClass(1)
    assert obj.prop == 1
    obj.prop = 2
    assert obj.prop == 2
    del obj.prop
    assert obj.prop == 1



# Generated at 2022-06-23 17:58:35.858712
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""
    def func(obj: object) -> int:
        if obj.x == 5:
            return 6

        return 5
    
    class MyClass:
        def __init__(self):
            self.x = 5
        
        @cached_property
        def y(self):
            return func(self)

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__["y"] == 6


# Generated at 2022-06-23 17:58:45.700315
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""

    class TestClass:
        def __init__(self, value: int) -> None:
            self.value = value

        @cached_property
        def test_property(self) -> int:
            return self.value + 1

    test_instance = TestClass(5)
    assert test_instance.test_property == 6
    assert test_instance.__dict__ == {'value': 5, 'test_property': 6}
    test_instance.value = 8
    assert test_instance.test_property == 6
    assert test_instance.__dict__ == {'value': 8, 'test_property': 6}
    del test_instance.test_property
    assert test_instance.test_property == 9

# Generated at 2022-06-23 17:58:52.466000
# Unit test for constructor of class cached_property
def test_cached_property():

    import unittest

    class Test(unittest.TestCase):

        def test_cached_property_constructor(self):
            import flutils.decorators
            self.assertTrue(hasattr(flutils.decorators.cached_property, '__init__'))
            self.assertTrue(callable(flutils.decorators.cached_property.__init__))

    tests = Test()
    suite = unittest.TestLoader().loadTestsFromModule(tests)
    unittest.TextTestRunner().run(suite)



# Generated at 2022-06-23 17:58:55.825758
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6


# Generated at 2022-06-23 17:59:04.656593
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import TestCase, mock

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def func(self):
            return self.x + 1

    class test_cached_property___get__(TestCase):
        def setUp(self):
            self.obj = MyClass()
            self.myprop = cached_property(object())

        def test_instance_returns_func(self):
            self.assertEqual(self.obj.func, 6)

        def test_obj_dict_contains_func_return(self):
            # noinspection PyUnresolvedReferences
            self.assertIn('func', self.obj.__dict__)


# Generated at 2022-06-23 17:59:15.229995
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import types

    # With synchronous function
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6
    assert type(obj.y) == int
    assert type(obj.y) is not types.FunctionType

    # With asynchronous function
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            async def coro():
                await asyncio.sleep(.1)
                return self.x + 1

            return coro()

    obj = MyClass()

    import asyncio
    async def main():
        y = await obj.y
        assert y

# Generated at 2022-06-23 17:59:25.821412
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import mock

    my_class = mock.Mock(__dict__={})
    my_class.__name__ = 'Mock'
    my_class.__module__ = 'Mock'
    func = mock.Mock(__dict__={})
    func.__name__ = 'func'
    func.__module__ = 'Mock'
    inst = cached_property(func)
    assert inst.__get__(my_class) is func
    assert inst.__get__(my_class) is func
    assert inst.__get__(my_class, my_class) is func
    my_class2 = mock.Mock(__dict__={})
    my_class2.__name__ = 'Mock'
    my_class2.__module__ = 'Mock'

# Generated at 2022-06-23 17:59:34.606874
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    class MyClass2:
        def __init__(self, x):
            self.x = x

        @cached_property
        async def y(self):
            await asyncio.sleep(1)
            return self.x + 1


    obj = MyClass(5)
    obj2 = MyClass2(5)

    assert obj.y == 6
    assert obj.y == 6
    assert obj.y == 6

    loop = asyncio.get_event_loop()
    x = loop.run_until_complete(obj2.y)
    assert x == 6
    assert x == 6
    assert x == 6

# Generated at 2022-06-23 17:59:35.997735
# Unit test for constructor of class cached_property
def test_cached_property():
    assert callable(cached_property(lambda self: None))

# Generated at 2022-06-23 17:59:38.075126
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 17:59:50.141396
# Unit test for constructor of class cached_property
def test_cached_property():
    import pytest

    class C(object):
        def __init__(self):
            self._x = None

        def getx(self):
            return self._x

        def setx(self, value):
            self._x = value

        def delx(self):
            del self._x

        x = property(getx, setx, delx, "I'm the 'x' property.")

    class D(C):
        @cached_property
        def x(self):
            return super(D, self).x

    def test():
        d = D()
        d.x = "foo"
        with pytest.warns(DeprecationWarning):
            assert d.x == "foo"
            d.x = "bar"
            assert d.x == "foo"

    test()

# Generated at 2022-06-23 17:59:52.398853
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """number"""
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert MyClass.y.__doc__ == "number"

# Generated at 2022-06-23 18:00:04.535917
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test cached_property.__get__."""
    class Cached:

        def __init__(self):
            self.x = 3

        @cached_property
        def y(self):
            return self.x + 1

    # First access gets from __init__
    assert Cached().y == 4

    # But subsequent accesses get from the replacement
    assert Cached().y == 4

    # Replaces itself in the instance dict with an ordinary attribute
    assert "y" in Cached.__dict__
    assert "y" not in Cached().__dict__

    # Deletion reset the property
    c = Cached()
    del c.y
    assert "y" not in Cached.__dict__
    assert c.y == 4

# Generated at 2022-06-23 18:00:08.847822
# Unit test for constructor of class cached_property
def test_cached_property():
    class Test:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Test()
    assert obj.y == 6

# Generated at 2022-06-23 18:00:17.463441
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import asyncio
    import pytest

    # noinspection PyUnusedLocal
    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    @pytest.mark.asyncio
    async def test():
        loop = asyncio.get_event_loop()
        obj = TestClass()
        tasks = [obj.y, obj.y]
        return await asyncio.gather(*tasks)

    (y1, y2) = loop.run_until_complete(test())
    assert y1 == y2 == 6


# Run tests
if __name__ == '__main__':
    import pytest

    pytest.main([__file__])

# Generated at 2022-06-23 18:00:21.591693
# Unit test for constructor of class cached_property
def test_cached_property():
    import flutils.decorators.cached_property as cp

    class myClass:

        def __init__(self):
            self.x = 5

        @cp.cached_property
        def y(self):
            return self.x + 1

    my_obj = myClass()
    y = my_obj.y
    assert y == 6

# Generated at 2022-06-23 18:00:26.439318
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 18:00:37.056353
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():  # noqa: D103
    from unittest import mock

    class TestObj(object):
        def __init__(self):
            self.x = 5

        # noinspection PyUnusedLocal
        @cached_property
        def y(self):
            return self.x + 1

    # Test instance
    with mock.patch.dict(TestObj.__dict__, {'__module__': 'mock_module'}):
        obj = TestObj()
        # Check expected inheritance
        assert obj.__class__.__name__ == 'TestObj'
        assert obj.__class__.__module__ == 'mock_module'
        assert obj.x == 5
        assert obj.__dict__ == {'x': 5}
        assert obj.y == 6

# Generated at 2022-06-23 18:00:41.535775
# Unit test for constructor of class cached_property
def test_cached_property():
    from types import FunctionType
    from flutils.decorators import cached_property

    x = cached_property(lambda x: x)
    assert isinstance(x, cached_property)
    assert isinstance(x.func, FunctionType)



# Generated at 2022-06-23 18:00:51.327484
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property

    **Tested:**

    - Object instantiation
    - Calling a method decorated as :obj:`cached_property`
    - Calling a coroutine method decorated as :obj:`cached_property`

    """

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        async def z(self):
            # noinspection PyUnusedLocal
            await asyncio.sleep(0)
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.y == 6

    # This is a coroutine method

# Generated at 2022-06-23 18:00:55.491371
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:01:03.903240
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        @cached_property
        def x(self):
            return 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert isinstance(obj.x, int)
    assert isinstance(obj.y, int)
    assert obj.x == 5
    assert obj.y == 6
    del obj.x
    obj.x
    assert isinstance(obj.x, int)
    assert isinstance(obj.y, int)
    assert obj.x == 5
    assert obj.y == 6
    del obj.y
    obj.y
    assert isinstance(obj.x, int)
    assert isinstance(obj.y, int)
    assert obj.x == 5
    assert obj.y == 6

# Generated at 2022-06-23 18:01:13.280182
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from random import randint
    from timeit import timeit

    from flutils.decorators import cached_property

    class Test1:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return randint(1, 10 ** 6)

    myobj = Test1()
    myobj.y

    print(timeit("myobj.y", number=1000, globals=globals()))

    # Method __get__() of class cached_property very fast
    #   0.0013487099999998874
    #   0.001333229999999998
    #   0.001314429999998887


# Generated at 2022-06-23 18:01:23.346158
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class obj_class:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = obj_class()
    # obj.y
    assert obj.y == 6
    # obj.y
    assert obj.y == 6
    # delete obj.y
    del obj.y
    # obj.y
    assert obj.y == 6

if __name__ == '__main__':
    # Run all the tests with the following
    # command line: pytest -vvs test_cached_property.py
    #
    # Run this test alone with the following
    # command line: pytest -vvs test_cached_property.py -k 'test_cached_property___get__'
    test_cached

# Generated at 2022-06-23 18:01:28.032342
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:01:34.918207
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""

    @cached_property
    def prop(inst):
        return [1, 2, 3]

    class TestObj:
        def __init__(self):
            self.a = 1
            self.b = 5
            self.c = 10

    obj = TestObj()
    obj.prop
    obj.prop
    obj.prop

    assert len(obj.prop) == 3
    assert obj.prop[1] == 2
    assert obj.prop[2] == 3
    assert obj.__dict__["prop"] == [1, 2, 3]



# Generated at 2022-06-23 18:01:40.225037
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Unit test for :obj:`~flutils.decorators.cached_property`

    *New in version 0.2.0*
    """
    def test():
        obj = MyClass()
        if sys.version_info < (3, 8):
            assert obj.y == 6
            obj.__dict__.pop('y')
            assert obj.y == 6
        else:
            assert obj.y == 7
            obj.__dict__.pop('y')
            assert obj.y == 7

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """
            The y property
            """
            return self.x + 1

    test()



# Generated at 2022-06-23 18:01:41.866449
# Unit test for constructor of class cached_property
def test_cached_property():
    class TestClass:

        def __init__(self):
            self.x = 5


# Generated at 2022-06-23 18:01:47.339853
# Unit test for constructor of class cached_property
def test_cached_property():
    import pytest

    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:01:48.580313
# Unit test for constructor of class cached_property
def test_cached_property():
    pass
    # obj = cached_property
    # assert obj.

# Generated at 2022-06-23 18:01:51.493901
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:01:55.874694
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 18:01:59.818266
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # noinspection PyUnusedLocal
    class MyClass:
        def __init__(self):
            self.x = 5

        # noinspection PyMethodMayBeStatic
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:02:05.789140
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property
    """

    import asyncio
    from functools import partial

    # noinspection PyPep8Naming
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x - 1

        @cached_property
        def a(self):
            return self.x * 2

        @cached_property
        def b(self):
            return self.x / 2

        @cached_property
        def c(self):
            return self.x ** 2

        @cached_property
        def d(self):
            return self.x // 2



# Generated at 2022-06-23 18:02:11.755120
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test cached_property class.

    *New in version 0.2.0*

    .. versionadded:: 0.2.0

    """

    class Example:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Example()
    assert obj.y == 6

# Generated at 2022-06-23 18:02:22.859379
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test the method __get__ of class cached_property
    """

    from flutils.decorators import cached_property
    from flutils.datastructures import CaseInsensitiveDict

    class TestClass:

        def __init__(self, x=0):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return ''.join(['z'] * self.x)

    class AsyncTestClass:

        def __init__(self, x=0):
            self.x = x

        @cached_property
        async def y(self):
            return self.x + 1


# Generated at 2022-06-23 18:02:24.407771
# Unit test for constructor of class cached_property
def test_cached_property():
    import inspect
    assert inspect.isclass(cached_property)

# Generated at 2022-06-23 18:02:28.371370
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y


if __name__ == '__main__':
    test_cached_property___get__()

# Generated at 2022-06-23 18:02:33.796287
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 18:02:41.793917
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import Mock

    obj = Mock()
    func = Mock()
    func.__name__ = 'func'
    obj.__dict__.update({func.__name__: 42})
    cp_func = cached_property(func)

    result = cp_func.__get__(obj, None)
    assert result == 42
    obj.assert_not_called()
    func.assert_not_called()

    obj.reset_mock()
    obj.__dict__ = {}

    result = cp_func.__get__(obj, None)
    assert result == func()
    obj.assert_called_once_with()
    func.assert_called_once_with(obj)

# Generated at 2022-06-23 18:02:45.153823
# Unit test for constructor of class cached_property
def test_cached_property():
    class Example:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert Example().y == 6

# Generated at 2022-06-23 18:02:56.287140
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import TestCase, mock
    import unittest.mock

    class _Mock:
        pass

    mock_ = _Mock()
    mock_.__dict__ = dict()
    mock_cls = _Mock()
    mock_cls.__name__ = 'MyClass'
    mock_prop = unittest.mock.create_autospec(cached_property)
    mock_prop_obj = unittest.mock.create_autospec(cached_property)
    mock_prop_func = unittest.mock.create_autospec(cached_property)
    mock_prop_func.__name__ = 'func'
    mock_prop_func.__doc__ = 'Test docstring'


# Generated at 2022-06-23 18:03:04.974707
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from .testing import capture_logging

    def get_msg(method, expected_msg):
        with capture_logging(level=logging.DEBUG) as cm:
            assert method() == expected_msg

        assert cm.output == [expected_msg]

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            logging.debug('y')
            return self.x + 1

        @cached_property
        def z(self):
            logging.debug('z')
            return self.x + 2

    obj = MyClass()

    # Test first call
    get_msg(obj.y, 'y')
    get_msg(obj.z, 'z')

    # Test second call

# Generated at 2022-06-23 18:03:08.885121
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyObj:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyObj()
    assert obj.y == 6
    assert obj.__dict__['y'] == 6



# Generated at 2022-06-23 18:03:14.690815
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    @cached_property
    def prop_func(obj):
        """

        :param obj:
        :return:
        """
        return obj.prop_attr

    class PropClass:

        def __init__(self, prop_val):
            self.prop_attr = prop_val

    # Create an instance of PropClass
    prop_obj = PropClass(100)

    # Ensure we get 100 from prop_obj.prop_func
    assert prop_obj.prop_func == 100

    # Set prop_attr to 200
    prop_obj.prop_attr = 200

    # Ensure we get 100 from prop_obj.prop_func;
    # because it should be cached
    assert prop_obj.prop_func == 100

    # Ensure we get 200 from prop_obj.prop_attr

# Generated at 2022-06-23 18:03:20.410693
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Unit test for cached_property()
    """
    c = ClassTest()
    assert c.not_cached is None
    assert c.val == 12
    assert c.not_cached == 12
    assert c.val == 12
    assert c.not_cached == 12
    c.not_cached = None
    assert c.not_cached is None



# Generated at 2022-06-23 18:03:22.017762
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test method to test method __get__ of class cached_property"""



# Generated at 2022-06-23 18:03:27.568155
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    _my_obj = MyClass()
    assert hasattr(_my_obj, 'x') and _my_obj.x == 5
    assert hasattr(_my_obj, 'y') and _my_obj.y == 6
    assert _my_obj.__dict__['y'] == 6

# Generated at 2022-06-23 18:03:32.471244
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:03:37.745206
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    try:
        obj = MyClass()
        obj.y
    except Exception:
        raise AssertionError("Failed to call cached_property.__get__()")
    else:
        print("cached_property.__get__() called without exception.")

# Generated at 2022-06-23 18:03:42.447946
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Object:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Object()
    assert obj.y == 6



# Generated at 2022-06-23 18:03:50.910377
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property
    """
    from textwrap import dedent

    import pytest

    from flutils.decorators import cached_property

    class MyClass1:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj1 = MyClass1()

    assert obj1.y == 6

    class MyClass2:
        def __init__(self):
            self.x = 5

        @cached_property
        @asyncio.coroutine
        def y(self):
            yield
            return self.x + 1

    obj2 = MyClass2()

    loop = asyncio.get_event_loop()

# Generated at 2022-06-23 18:04:01.672947
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test cached_property decorator.

       Tests the :obj:`flutils.decorators.cached_property` decorator.
    """

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    class MyClassA:
        def __init__(self):
            self.x = 5

        @cached_property
        async def y(self):
            await asyncio.sleep(0.5)
            return self.x + 1

    loop = asyncio.get_event_loop()
    obj = MyClassA()
    loop.run_until_complete(obj.y)
    assert obj.y.result() == 6

# Generated at 2022-06-23 18:04:04.158666
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    def f(self): return 1
    p = cached_property(f)
    class A(): pass
    a = A()
    a.p = p
    for i in range(20):
        assert a.p == 1


# Generated at 2022-06-23 18:04:05.612009
# Unit test for constructor of class cached_property
def test_cached_property():
    assert __init__(cached_property) == None

# Generated at 2022-06-23 18:04:11.134111
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # Set up fixture
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    # Test
    assert obj.y == 6

    # Clean-up
    del obj.y



# Generated at 2022-06-23 18:04:18.836546
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    @cached_property
    def test_property(instance):
        return instance + 1

    class TestClass:

        def __init__(self, x):
            self.x = x

    TestClass.test_property = test_property
    a = TestClass(1)
    b = TestClass(2)

    assert TestClass.test_property is test_property
    assert a.test_property == 2
    assert b.test_property == 3



# Generated at 2022-06-23 18:04:26.694589
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class :obj:`~cached_property`

    *New in version 0.2.0*

    """

    class C:

        def __init__(self):
            self.x = 7

        @cached_property
        def foo(self):
            print("Computing foo")
            return self.x + 1

    obj = C()
    # We must access the property for it to compute.
    obj.foo
    # The object's __dict__ doesn't have an 'foo' at this point.
    assert 'foo' not in obj.__dict__
    # properties are read-only by default.  Therefore, we can't set
    # obj.foo to anything other than its first computed value.
    try:
        obj.foo = 5
    except Exception:
        pass

# Generated at 2022-06-23 18:04:28.338530
# Unit test for constructor of class cached_property
def test_cached_property():
    class Foo:
        @cached_property
        def bar(self):
            return 'baz'

    foo = Foo()
    for i in range(1000):
        assert foo.bar == 'baz'

# Generated at 2022-06-23 18:04:32.875988
# Unit test for constructor of class cached_property
def test_cached_property():
    class A:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = A()
    assert obj.y == 6
    assert obj.y == 6

# Generated at 2022-06-23 18:04:38.184018
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from inspect import iscoroutinefunction

    class TestClass:
        x = 1
        y = cached_property(lambda self: self.x + 1)

    test_obj = TestClass()

    assert not iscoroutinefunction(test_obj.y)
    assert test_obj.y == 2
    assert test_obj.y == 2

    test_obj.x = 5
    assert test_obj.y == 6



# Generated at 2022-06-23 18:04:41.678782
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class Foo:

        @cached_property
        def bar(self):
            return 'the bar property'

    f = Foo()
    assert f.bar == 'the bar property'
    del f.bar
    assert f.bar == 'the bar property'

# Generated at 2022-06-23 18:04:46.608188
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            self.y = 5
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.y == 6

    obj = MyClass()
    assert obj.y == 6
    assert obj.y == 6


# Generated at 2022-06-23 18:04:53.336713
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    def _test_function(self):
        return 'test_function'

    obj = type('TestObject', (), {})()

    def _test_async_function(self):
        return 'async_test_function'

    async def _async_test_function(self):
        return 'async_test_function'

    cp = cached_property(_test_function)
    cp.__get__(obj, type(obj))
    assert obj.test_function == 'test_function'

    cp = cached_property(_async_test_function)
    try:
        cp.__get__(obj, type(obj))
    except AttributeError:
        pass
    else:
        raise AssertionError

    cp = cached_property(_test_async_function)

# Generated at 2022-06-23 18:05:05.187762
# Unit test for method __get__ of class cached_property

# Generated at 2022-06-23 18:05:12.160654
# Unit test for constructor of class cached_property
def test_cached_property():
    """Tests :obj:`~flutils.decorators.cached_property` with an attribute."""
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 18:05:17.722691
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""

    # noinspection PyUnusedLocal
    def _test_cached_property___get__():

        class MyClass:

            def __init__(self):
                self.x = 5

            @cached_property
            def y(self):
                return self.x + 1

        obj = MyClass()
        return obj.y

    y = _test_cached_property___get__()
    assert y == 6
    return



# Generated at 2022-06-23 18:05:22.200076
# Unit test for constructor of class cached_property
def test_cached_property():
    class A:
        foo = cached_property(lambda self: 'foo')

    a = A()
    assert a.foo == 'foo'
    assert a.foo == 'foo'

# Generated at 2022-06-23 18:05:26.928105
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:05:37.637158
# Unit test for constructor of class cached_property
def test_cached_property():
    """ Unit tests for `flutils.decorators.cached_property`

    *New in version 0.2.0*

    """
    import pytest

    # Test basic functionality of the class
    class TestClass:
        def __init__(self):
            self.x = 0

        @cached_property
        def y(self):
            self.x = 1
            return self.x

    obj = TestClass()
    assert obj.x == 0
    assert obj.y == 1
    assert obj.x == 1

    # Test the delete property
    class TestClass:
        def __init__(self):
            self.x = 0

        @cached_property
        def y(self):
            self.x = 1
            return self.x

    obj = TestClass()
    assert obj.x == 0


# Generated at 2022-06-23 18:05:41.417872
# Unit test for constructor of class cached_property
def test_cached_property():
    # test for constructor of class cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 18:05:49.190970
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Test that the constructor of cached_property works
    """
    from flutils.decorators import cached_property

    class Klass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Klass()
    obj.y
    assert obj.__dict__['y'] == 6

    # add parallel function
    class Klass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x + 2

    obj = Klass()
    obj.y
    assert obj.__dict__['y'] == 6