

# Generated at 2022-06-23 17:55:52.001754
# Unit test for constructor of class cached_property
def test_cached_property():
    """Verify constructor of class cached_property."""

    @cached_property
    def my_prop(self):
        """The description of this property."""
        return "My property value"

    assert my_prop.__doc__ == "The description of this property."



# Generated at 2022-06-23 17:56:01.578713
# Unit test for constructor of class cached_property
def test_cached_property():
    from types import MethodType, FunctionType

    # noinspection PyMethodMayBeStatic
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert isinstance(MyClass.y, cached_property)
    assert isinstance(MyClass.y.func, FunctionType)
    assert MyClass.y.func.__name__ == 'y'

    obj = MyClass()
    assert isinstance(obj.y, MethodType)
    assert obj.y.__self__ is obj
    assert obj.y.__func__.__name__ == 'y'

    obj1 = MyClass()
    assert obj1.y() == 6

    obj2 = MyClass()
    assert obj2.y() == 6



# Generated at 2022-06-23 17:56:08.261447
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from datetime import datetime

    class Foo:

        def __init__(self):
            self.foo = datetime(2018, 1, 1, 0, 0)

        @cached_property
        def bar(self):
            return self.foo

    foo = Foo()
    assert foo.bar == datetime(2018, 1, 1, 0, 0)

    foo.foo = datetime(2018, 1, 3, 0, 0)
    assert foo.bar == datetime(2018, 1, 1, 0, 0)

# Generated at 2022-06-23 17:56:12.211545
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 17:56:16.400494
# Unit test for constructor of class cached_property
def test_cached_property():
    instances = [cached_property(lambda: None), cached_property(lambda: 0),
                 cached_property(lambda: 1)]
    for instance in instances:
        assert isinstance(instance, cached_property)



# Generated at 2022-06-23 17:56:22.755305
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    @cached_property
    def square_of(x):
        return x ** 2

    @cached_property
    def cube_of(x):
        return x ** 3

    class TestClass:
        def __init__(self, x):
            self.x = x

    obj1 = TestClass(5)
    assert square_of.__get__(obj1, None) == 25
    assert cube_of.__get__(obj1, None) == 125
    obj2 = TestClass(10)
    assert square_of.__get__(obj2, None) == 100
    assert cube_of.__get__(obj2, None) == 1000

# Generated at 2022-06-23 17:56:33.573134
# Unit test for constructor of class cached_property
def test_cached_property():

    from types import coroutine

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj2 = MyClass()

    # noinspection PyUnresolvedReferences
    assert obj.y == 6
    # noinspection PyUnresolvedReferences
    assert obj2.y == 6
    obj.x = 4
    # noinspection PyUnresolvedReferences
    assert obj.y == 6
    # noinspection PyUnresolvedReferences
    assert obj2.y == 6

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        async def y(self):
            return self.x + 1


# Generated at 2022-06-23 17:56:37.461910
# Unit test for constructor of class cached_property
def test_cached_property():
    class Test:
        def __init__(self):
            self.x = 1

        @cached_property
        def y(self):
            return self.x + 1

    t = Test()

    assert t.y == 2

# Generated at 2022-06-23 17:56:40.675703
# Unit test for constructor of class cached_property
def test_cached_property():
    class Foo:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Foo()
    assert obj.y == 6

# Generated at 2022-06-23 17:56:45.958803
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import os

    class TestClass(object):
        def __init__(self):
            self.y = []

        @cached_property
        def x(self):
            self.y.append(1)
            return 1

    obj = TestClass()
    assert obj.x == 1
    assert obj.x == 1
    obj.y.append(2)
    assert os.path.isfile(__file__)

# Generated at 2022-06-23 17:56:49.523846
# Unit test for constructor of class cached_property
def test_cached_property():
    # noinspection PyUnusedLocal
    class A:
        def __init__(self):
            pass

        # noinspection PyMethodMayBeStatic
        @cached_property
        def test_cached_property(self):
            pass

    A()

# Generated at 2022-06-23 17:56:53.662857
# Unit test for constructor of class cached_property
def test_cached_property():
    cp = cached_property("hello")
    assert str(cp) == "<cached_property object at 0x%x>" % id(cp)
    assert cp.__doc__ is None



# Generated at 2022-06-23 17:56:57.116509
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Obj:
        @cached_property
        def prop(self):
            return 5

    obj = Obj()
    assert obj.prop == 5
    assert Obj.prop is Obj.prop
    assert isinstance(Obj.prop, cached_property)


# Generated at 2022-06-23 17:57:04.290376
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property.
    """
    class MyClass:
        def __init__(self, y):
            self.y = y

        @cached_property
        def x(self):
            return self.y + 1

    obj = MyClass(5)
    assert isinstance(obj.x, int)
    assert obj.x == 6
    assert obj.x == 6
    assert obj.x == 6


# Generated at 2022-06-23 17:57:08.757975
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class X:

        @cached_property
        def y(self):
            return self.x + 1

    instance_of_X = X()
    instance_of_X.x = 5
    assert instance_of_X.y == 6



# Generated at 2022-06-23 17:57:14.770732
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property
    from unittest.mock import Mock

    dummy = Mock()
    expected_value = 1

    @cached_property
    def foo():
        return expected_value

    dummy.foo = foo
    foo_result = dummy.foo
    assert foo_result == expected_value



# Generated at 2022-06-23 17:57:17.368174
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test method __get__ of class cached_property.

    This method is tested in the tests for
    :obj:`~flutils.decorators.cached_property`
    """
    pass

# Generated at 2022-06-23 17:57:24.427722
# Unit test for constructor of class cached_property
def test_cached_property():

    # These are only needed to type this.
    from flutils.decorators import cached_property

    # noinspection PyUnusedLocal
    @cached_property
    def test_1(self):
        return 1

    # noinspection PyUnusedLocal
    @cached_property
    def test_2(self):
        return 2


if __name__ == "__main__":
    test_cached_property()

# Generated at 2022-06-23 17:57:31.363467
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class Foo:

        @cached_property
        def bar(self):
            return self.x + 1

    foo = Foo()
    foo.x = 5
    assert foo.bar == 6
    foo.x = 10
    assert foo.bar == 6

    # del foo.bar
    # assert foo.bar == 11
    # foo.x = 10
    # assert foo.bar == 11

    # del foo.bar
    # assert foo.bar == 11
    # foo.x = 5
    # assert foo.bar == 6



# Generated at 2022-06-23 17:57:31.959821
# Unit test for constructor of class cached_property
def test_cached_property():
    pass

# Generated at 2022-06-23 17:57:38.995169
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""

    def test(x):
        return x

    def test2(x):
        return x + 1

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return test(self.x)

        @cached_property
        def z(self):
            return test2(self.x)

    obj = MyClass()
    y = obj.y
    assert y == 5
    assert obj.y == y

    z = obj.z
    assert z == 6
    assert obj.z == z


# Generated at 2022-06-23 17:57:46.567292
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method `cached_property.__get__`
    """
    # Run basic test with and without coroutines
    class Foo:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class FooCoro:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return asyncio.coroutine(self._y)

        def _y(self):
            return self.x + 1

    obj = Foo()

    assert obj.y == 6
    assert obj.__dict__['y'] == 6

    obj = FooCoro()

    assert asyncio.run(obj.y) == 6
    assert obj.__dict__

# Generated at 2022-06-23 17:57:56.882699
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test cached_property.__get__()."""
    # noinspection PyProtectedMember

    class A:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    a = A(1)
    b = A(2)
    assert a.y == 2
    assert b.y == 3
    assert a.y == 2
    assert b.y == 3

    # noinspection PyProtectedMember
    assert a.__dict__['y'] == 2
    # noinspection PyProtectedMember
    assert b.__dict__['y'] == 3
    # noinspection PyProtectedMember
    assert a.__dict__['y'] == 2
    # noinspection PyProtectedMember
    assert b

# Generated at 2022-06-23 17:58:04.241949
# Unit test for constructor of class cached_property
def test_cached_property():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


if __name__ == "__main__":
    import pytest

    pytest.main(args=["-s", "-x", "--pdb", "--pdbcls=IPython.terminal.debugger:Pdb"])

# Generated at 2022-06-23 17:58:13.536739
# Unit test for constructor of class cached_property

# Generated at 2022-06-23 17:58:25.710584
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    A property decorator that is only computed once per instance and then
    replaces itself with an ordinary attribute.

    Deleting the attribute resets the property.

    This decorator is a derivative work of
    `cached_property <https://bit.ly/2R9U3Qa>`__ and is:

    `Copyright © 2015 Daniel Greenfeld; All Rights Reserved
    <https://bit.ly/2CwtJM1>`__

    Also this decorator is a derivative work of
    `cached_property  <https://bit.ly/2JbYB5L>`__ and is:

    `Copyright © 2011 Marcel Hellkamp <https://bit.ly/2ECEO0M>`__

    """


# Generated at 2022-06-23 17:58:29.608621
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test the constructor of class cached_property

    :return: None
    """

    class MyClass:
        pass

    assert not hasattr(MyClass, "__dict__")


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-23 17:58:30.903474
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property(lambda: None).func() == None



# Generated at 2022-06-23 17:58:34.485915
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self, x=0):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass(x=5)
    assert obj.y == 6



# Generated at 2022-06-23 17:58:44.757684
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    @cached_property
    def x(self):
        return 5

    # noinspection PyUnresolvedReferences
    class MyClass:
        x = x

    # noinspection PyUnresolvedReferences
    assert isinstance(MyClass.x, cached_property)

    obj = MyClass()
    # noinspection PyUnresolvedReferences
    assert obj.x == 5
    # noinspection PyUnresolvedReferences
    assert obj.__dict__ == {"x": 5}

    # noinspection PyUnresolvedReferences
    assert obj.x == 5
    # noinspection PyUnresolvedReferences
    assert obj.__dict__ == {"x": 5}

    # noinspection PyUnresolvedReferences
    del obj.x
    # noinspection PyUnresolvedReferences
    assert obj.x == 5
    #

# Generated at 2022-06-23 17:58:45.657919
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property



# Generated at 2022-06-23 17:58:50.824847
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class TestClass:

        def __init__(self):
            self.x = 1
            self.iter = 0

        @cached_property
        def y(self):
            self.iter += 1
            return self.x + 1

    t = TestClass()
    assert t.y == 2
    assert t.iter == 1
    assert t.y == 2
    assert t.iter == 1
    t.x = 5
    assert t.y == 6
    assert t.iter == 2


# Unit test Cache property with a coroutine

# Generated at 2022-06-23 17:58:55.341182
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass(object):

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1
    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 17:58:58.828381
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6

# Generated at 2022-06-23 17:59:09.226667
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from .testingutils import mock_coro

    class A:
        @cached_property
        def x(self):
            return 5

        @cached_property
        async def y(self):
            return mock_coro() + 5

    a = A()
    assert a.x == 5
    assert a.__dict__['x'] == 5
    a.x = 10
    assert a.x == 10

    f = a.y
    assert asyncio.iscoroutine(f)
    assert asyncio.iscoroutinefunction(f)
    assert a.__dict__['y'] is f
    assert a.y.done() is False

# Generated at 2022-06-23 17:59:14.935000
# Unit test for constructor of class cached_property
def test_cached_property():
    class foo:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1
            # Note that this is the __doc__ string of the cached_property object
            # self.__doc__ = 'This is the doc string of foo'
        # note that function y has no equivalent __doc__ attr
        # print(y.__doc__)

    o = foo()
    o.y
    o.y
    o.x = 6
    o.y
    del o.y
    o.y

if __name__ == '__main__':
    # print(__doc__)
    test_cached_property()

# Generated at 2022-06-23 17:59:20.135016
# Unit test for constructor of class cached_property
def test_cached_property():
    import functools

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    obj.y = 7

    assert obj.y == 7
    assert obj.__dict__["y"] == 7

    del obj.__dict__["y"]
    assert obj.y == 6

# Generated at 2022-06-23 17:59:24.327498
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property
    from flutils.decorators import cached_property as cached_property_uut
    from flutils.decorators import cached_property as cached_property_orig

    assert cached_property is not cached_property_uut
    assert cached_property is cached_property_orig

# Generated at 2022-06-23 17:59:26.176465
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    return



# Generated at 2022-06-23 17:59:34.592565
# Unit test for constructor of class cached_property
def test_cached_property():
    from .cached_property import cached_property
    test_pass = True

    @cached_property
    def myprop(x):
        return 2 * x

    class TestObj(object):
        myprop = myprop

    t = TestObj()
    t.x = 2
    r1 = t.myprop
    r2 = t.myprop
    del t.myprop
    del t.x
    try:
        r3 = t.myprop
        test_pass = False
    except AttributeError:
        pass

    assert test_pass
    assert r1 == 4
    assert r2 == 4

# Generated at 2022-06-23 17:59:46.180912
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test for method __get__ of class cached_property
    """
    # This is really more of an integration test than a unit test.
    # The goal is to test __get__() to ensure it's returning expected
    # results.  However there is no real way to test the internals of
    # @cached_property; so, this test must suffice.

    # Test caching a function
    class TestOne:
        def __init__(self):
            self.called = False

        @cached_property
        def func(self):
            self.called = True
            return True

    obj_one = TestOne()
    assert not obj_one.called
    assert obj_one.func is True
    assert obj_one.called
    assert obj_one.func is True
    assert obj_one.called

    # Test caching

# Generated at 2022-06-23 17:59:49.588262
# Unit test for constructor of class cached_property
def test_cached_property():
    def f(obj):
        return 'value of f'

    cp = cached_property(f)
    assert cp.__doc__ == f.__doc__
    assert cp.func is f


# Generated at 2022-06-23 17:59:57.866393
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from collections import namedtuple
    from datetime import date
    import asyncio

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            """A cached property."""
            return self.y + 1

    obj = MyClass()
    assert obj.z == 8
    assert obj.z.__doc__ == "A cached property."


# Generated at 2022-06-23 18:00:07.746227
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from .funcs import time_func, time_func_async

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert(obj.y == 6)

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        async def y(self):
            return self.x + 1

    obj = MyClass()
    assert((await obj.y) == 6)
    assert(obj.y.done())

    class MyClass:
        def __init__(self):
            self.x = 5


# Generated at 2022-06-23 18:00:14.236480
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj, obj.__dict__
    obj.y

    from sys import version_info, getsizeof

    assert version_info >= (3, 2)
    assert getsizeof(obj) == 72

    # Issue #99
    # assert not hasattr(obj, 'y')
    assert hasattr(obj, 'y')

# Generated at 2022-06-23 18:00:22.733008
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class C:
        def __init__(self, x):
            self.x = x
            self.y = None

        @cached_property
        def z(self):
            return self.y + 1

    obj = C(5)
    obj.y = 6
    assert obj.z == 7
    assert obj.__dict__["z"] == 7
    assert obj.__dict__["y"] == 6
    assert obj.y == 6
    obj2 = C(10)
    with pytest.raises(KeyError):
        obj2.z


# Generated at 2022-06-23 18:00:29.985108
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    test_cached_property___get__
    """

    import time
    import timeit

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            time.sleep(1)
            return self.x + 1

    b = timeit.default_timer()
    obj = MyClass()
    obj.y
    obj.y
    obj.y
    e = timeit.default_timer()
    assert e - b < 2.5



# Generated at 2022-06-23 18:00:40.058282
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for :func:`~flutils.decorators.cached_property`"""

    class C:
        def __init__(self, x):
            self.x = x

        @cached_property
        def foo(self):
            return self.x + 1

    obj = C(5)
    assert obj.foo == 6

    # Check that it is read-only
    with pytest.raises(AttributeError):
        obj.foo = 1

    # Check that the function is not called a second time
    obj = C(6)
    assert obj.foo == 7
    obj.foo = 1
    assert obj.__dict__['foo'] == 1

# Generated at 2022-06-23 18:00:46.143119
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property

    """
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    assert obj.__dict__['y'] == 6


# Generated at 2022-06-23 18:00:47.464429
# Unit test for constructor of class cached_property

# Generated at 2022-06-23 18:00:53.607337
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from types import MethodType
    from flutils.decorators import cached_property

    class Test(object):

        @cached_property
        def x(self):
            return range(10)

    obj = Test()
    assert isinstance(obj.x, MethodType)
    # Test method __get__ with a coroutine
    @asyncio.coroutine
    def coro():
        return range(10)

    class Test(object):

        @cached_property
        def x(self):
            return coro()

    obj = Test()
    assert isinstance(obj.x, asyncio.futures.Future)

# Generated at 2022-06-23 18:00:55.043025
# Unit test for constructor of class cached_property
def test_cached_property():
    c = CachedProperty(5)
    assert c.x == 5



# Generated at 2022-06-23 18:00:58.849732
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test method __get__ of class cached_property.

    """
    def dummy(obj):
        return 42

    decorator = cached_property(dummy)
    obj = object()

    assert decorator.__get__(obj) == 42



# Generated at 2022-06-23 18:01:02.808423
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:01:07.781846
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:01:11.397816
# Unit test for constructor of class cached_property
def test_cached_property():
    def test_func():
        return 'test'

    obj1 = cached_property(test_func)
    assert obj1.func == test_func
    assert obj1.__doc__ == test_func.__doc__

# Generated at 2022-06-23 18:01:19.888700
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from .._py3_compat import TYPE_CHECKING

    # noinspection PyUnresolvedReferences
    from . import decorators

    if TYPE_CHECKING:
        class MyClass(object):
            @decorators.cached_property
            def y(self):
                return self.x + 1

        obj = MyClass()
        obj.x = 5

        assert obj.y == 6



# Generated at 2022-06-23 18:01:24.119085
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test method __get__ when property is an async method."""
    import unittest
    from unittest.mock import MagicMock
    from flutils.decorators import cached_property

    class Test(object):
        def __init__(self):
            self.x = MagicMock(return_value=True)

        @cached_property
        async def y(self):
            return self.x

    # Test 1
    test = Test()
    assert test.x == test.y



# Generated at 2022-06-23 18:01:28.032741
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Foo:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    foo = Foo()
    assert foo.y == 6



# Generated at 2022-06-23 18:01:34.551100
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # GIVEN: a class with a cached property, 'x'
    class MyClass:
        # noinspection PyAttributeOutsideInit
        def __init__(self):
            self.val_x = 5

        @cached_property
        def x(self):
            return self.val_x + 1

    # WHEN: we access the value of 'x'
    obj = MyClass()
    ret_val = obj.x

    # THEN: the value is computed, stored, and returned
    assert ret_val == 6
    assert obj.__dict__['x'] == 6

# Generated at 2022-06-23 18:01:40.817602
# Unit test for constructor of class cached_property
def test_cached_property():

    class TestClass(object):
        def __init__(self):
            self.x = None

        @cached_property
        def y(self):
            self.x = 5
            return 'Y'

    test = TestClass()
    assert test.x == None
    assert test.y == 'Y'
    assert test.x == 5

    # clean up
    del test.y
    assert test.x is None
    assert test.y == 'Y'

# Generated at 2022-06-23 18:01:45.256069
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property"""

# Non-standard test for constructor of class cached_property

# Generated at 2022-06-23 18:01:51.249456
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import sys
    from flutils.decorators import cached_property

    if sys.version_info.major != 3 and sys.version_info.minor != 6:
        return None

    class NoAsyncio:
        @cached_property
        def x(self):
            return 5

    class SyncFunc:

        def __init__(self):
            self.x = 0

        @cached_property
        def y(self):
            self.x += 1
            return self.x

    class AsyncFunc:

        def __init__(self):
            self.x = 0

        @cached_property
        async def y(self):
            self.x += 1
            return self.x

    class AsyncFunc2:

        def __init__(self):
            self.x = 0


# Generated at 2022-06-23 18:01:56.737447
# Unit test for constructor of class cached_property
def test_cached_property():

    class A:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """test"""
            return self.x + 1

    a = A()
    assert a.y == 6


if __name__ == '__main__':
    test_cached_property()
    print("All tests for cached_property passed.")

# Generated at 2022-06-23 18:02:02.395786
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    #   1.  Instantiate a class with a cached property
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    #   2.  Instantiate an object of the class
    obj = MyClass()

    assert obj.y == 6

    #   3.  Delete the cached property
    del obj.y

    #   4.  Set the cached property again
    assert obj.y == 6

# Generated at 2022-06-23 18:02:13.958751
# Unit test for constructor of class cached_property
def test_cached_property():
    from pytest import raises, warns
    from flutils import decorators

    def test_py38():
        with warns(ImportWarning):
            import asyncio
            asyncio.iscoroutinefunction = lambda x: False

            @decorators.cached_property
            def x(self):
                return self

            class Test(object):
                x = decorators.cached_property(x)

    test_py38()

    @decorators.cached_property
    def x(self):
        return self

    class Test(object):
        x = decorators.cached_property(x)

    t = Test()

    assert t.__class__.__dict__['x']
    assert t.x is t
    assert t.__dict__ == {'x': t}

# Generated at 2022-06-23 18:02:22.816890
# Unit test for constructor of class cached_property
def test_cached_property():
    import unittest

    class CachedPropertyTestCase(unittest.TestCase):

        def test_cached_property(self):

            class TestClass(object):

                def __init__(self, x):
                    self.x = x

                # noinspection PyUnusedLocal
                @cached_property
                def y(self):
                    return self.x + 1

            func = TestClass(5).y
            self.assertEqual(6, func)

    unittest.main(argv=["first-arg-is-ignored"], exit=False)


if __name__ == '__main__':
    test_cached_property()

# Generated at 2022-06-23 18:02:25.895020
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class A(object):
        @cached_property
        def foo(self):
            return "foo"

    a = A()
    assert a.foo == "foo"

    # The second time, the cached valu

# Generated at 2022-06-23 18:02:30.482125
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils import decorators

    class TestClass:
        def __init__(self):
            self.x = 5

        @decorators.cached_property
        def y(self):
            return self.x + 1

    tt = TestClass()
    tt.y
    assert tt.y == 6
    tt.x = 10
    assert tt.y == 6

# Generated at 2022-06-23 18:02:40.204522
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Test for constructor of class cached_property.

    This decorator is a derivative work of
    `cached_property <https://bit.ly/2R9U3Qa>`__ and is:

    `Copyright © 2015 Daniel Greenfeld; All Rights Reserved
    <https://bit.ly/2CwtJM1>`__

    Also this decorator is a derivative work of
    `cached_property  <https://bit.ly/2JbYB5L>`__ and is:

    `Copyright © 2011 Marcel Hellkamp <https://bit.ly/2ECEO0M>`__

    """

    # TODO: Make this a unit test
    import doctest

    doctest.testmod(verbose=True)



# Generated at 2022-06-23 18:02:40.799444
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property

# Generated at 2022-06-23 18:02:44.774247
# Unit test for constructor of class cached_property
def test_cached_property():

    def f(a):
        return a

    the_property = cached_property(f)
    assert isinstance(the_property, cached_property)
    assert the_property.func == f



# Generated at 2022-06-23 18:02:54.761894
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Foo:
        def __init__(self, val):
            self.val = val

        @cached_property
        def add_one(self):
            return self.val + 1

    foo = Foo(2)

    # invoke __get__ the first time
    x = foo.add_one
    assert x == 3
    assert foo.add_one == 3

    # invoke __get__ a second time
    foo.add_one = 5
    assert foo.add_one == 5

    # invoke __get__ on a new instance
    bar = Foo(3)
    assert bar.add_one == 4
    assert bar.add_one == 4



# Generated at 2022-06-23 18:03:04.941868
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from copy import copy
    from inspect import signature

    from flutils.decorators import cached_property

    class MyClass:
        x = 1

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    def check(obj, cls):
        obj2 = copy(obj)
        value = obj2.__dict__[obj2.y.__name__] = obj2.y.__get__(obj2, cls)()
        assert value == 2
        assert obj2.__dict__[obj2.y.__name__] == value
        assert len(signature(obj2.y.__get__(obj2, cls)).parameters) == 1
        assert obj2.y.__doc__ is None


# Generated at 2022-06-23 18:03:11.948152
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for the function test_cached_property"""

    obj = object()
    obj2 = object()

    class DummyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x + 2

    dummy_class_obj = DummyClass()
    assert dummy_class_obj.y == 6
    assert dummy_class_obj.z == 7
    dummy_class_obj.x = 7
    assert dummy_class_obj.y == 8
    assert dummy_class_obj.z == 9
    del dummy_class_obj.y
    assert dummy_class_obj.y == 8
    dummy_class_obj.x = 9


# Generated at 2022-06-23 18:03:22.579123
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class TestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        @asyncio.coroutine
        def z(self):
            return self.x + 2

    obj = TestClass()

    # Test None type
    assert TestClass.y is cached_property

    # Test integer
    expected = 6
    actual = obj.y
    assert expected == actual

    # Test coroutine
    # noinspection PyTypeChecker
    with pytest.raises(RuntimeError):
        obj.z.send(None)

# Generated at 2022-06-23 18:03:33.091464
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test class cached_property."""
    import unittest

    class CachedPropertyTest(unittest.TestCase):
        """Test class cached_property."""
        class MyClass:
            """Example class."""
            def __init__(self):
                self.x = 5

            @cached_property
            def y(self):
                """Example cached_property."""
                return self.x + 1

        def test_cached_property(self):
            """Test self.y."""
            obj = self.MyClass()
            self.assertEqual(obj.y, 6)
            self.assertEqual(obj.__dict__["y"], 6)
            self.assertEqual(type(obj.__dict__["y"]), int)

    unittest.main()

# Generated at 2022-06-23 18:03:38.871762
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    obj.x = 2
    assert obj.y == 6  # cached

    del obj.y
    assert obj.y == 3  # Not cached

    obj.y = 4
    assert obj.y == 4  # overwrite

# Generated at 2022-06-23 18:03:42.745475
# Unit test for constructor of class cached_property
def test_cached_property():
    class Test(object):

        @cached_property
        def test_val(self):
            return "value"

    assert Test.test_val == "value"

# Generated at 2022-06-23 18:03:48.078319
# Unit test for constructor of class cached_property
def test_cached_property():
    """Tests for the cached_property decorator.  To run this test, execute the
    following:

        python -m flutils.tests.test_decorators
    """

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 18:04:00.258573
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test method __get__ of cached_property class."""

    # =========================================================================
    # Test case:
    # =========================================================================

    # Define class
    class MyClass:

        def __init__(self):
            self.x = 1

        @cached_property
        def y(self):
            return self.x + 1.0

    # Create class instance
    obj = MyClass()

    # Check value
    assert obj.y == 2.0
    assert obj.__dict__['y'] == 2.0

    # =========================================================================
    # Test case:
    # =========================================================================

    # Define class
    class MyClass:

        def __init__(self):
            self.x = 1

        @cached_property
        def y(self):
            return self.x + 1.0

    # Create class instance

# Generated at 2022-06-23 18:04:06.063475
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import asyncio

    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.y == 6

    class TestClass2:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass2()
    assert asyncio.run(obj.y) == 6


if __name__ == '__main__':
    test_cached_property___get__()

# Generated at 2022-06-23 18:04:11.335391
# Unit test for constructor of class cached_property
def test_cached_property():
    # noinspection PyUnusedLocal
    def dummy_function(obj):
        pass

    dummy_tuple = (None, None)

    with pytest.raises(TypeError):
        cached_property(dummy_tuple)

    with pytest.raises(TypeError):
        cached_property(dummy_function)

# Generated at 2022-06-23 18:04:16.676289
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:
        def __init__(self, val):
            self.val = val

        @cached_property
        def x(self):
            return self.val*2

    o = MyClass(2)
    assert o.x == 4


# Generated at 2022-06-23 18:04:25.262486
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""

    from .cached_property import cached_property

    # Test get attribute on instance that does not contain the attribute

    class TestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def foo(self):
            return self.x + 1

    obj = TestClass()
    assert obj.foo == 6

    # Test get attribute on instance that contains the attribute

    obj.foo = 7
    assert obj.foo == 7

    # Test get attribute on instance that contains the attribute, but
    # which is not the same attribute

    obj.foo = 6
    assert obj.foo == 6

    # Test get attribute on instance that contains the attribute
    # after a class reset

    del obj.foo
    assert obj.foo == 6

# Generated at 2022-06-23 18:04:28.264775
# Unit test for constructor of class cached_property
def test_cached_property():
    @cached_property
    def foo(x):
        return x + 1

    assert foo(1) == 2
    assert foo.__doc__ == test_cached_property.__doc__
    assert foo.__name__ == 'foo'

# Generated at 2022-06-23 18:04:37.402784
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class Test:

        @cached_property
        def y(self):
            return self.x + 1

        def __init__(self, x: int):
            self.x = x

    obj = Test(5)
    assert obj.__dict__ == {'x': 5}
    assert obj.y == 6
    assert obj.__dict__ == {'x': 5, 'y': 6}

    obj = Test(6)
    assert obj.__dict__ == {'x': 6}
    assert obj.y == 7
    assert obj.__dict__ == {'x': 6, 'y': 7}


# Generated at 2022-06-23 18:04:41.678933
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Foo(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    foo = Foo()
    assert foo.y == 6
    assert foo.__dict__['y'] == foo.y


# Generated at 2022-06-23 18:04:46.039909
# Unit test for constructor of class cached_property
def test_cached_property():
    """This function tests the cached_property constructor of the
    decorators module.

    """

    @cached_property
    def y(self):
        return self.x + 1

    class MyClass:

        def __init__(self):
            self.x = 5

    obj = MyClass()
    assert y.__doc__ is None
    assert obj.y == 6



# Generated at 2022-06-23 18:04:55.277751
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property.

    Test for bug where instance variable, not class variable,
    is returned after calling a method that uses cached_property.

    *New in version 0.2.0*

    """
    class TestClass:
        def __init__(self):
            self._n = 2

        @cached_property
        def get_n(self):
            """
            Return the value of instance variable n.
            """
            return self._n

    t1 = TestClass()
    assert t1._n == t1.get_n

    t2 = TestClass()
    assert t2._n == t2.get_n

    # Test for bug where instance variable, not class variable,
    # is returned after calling a method that uses cached_property

# Generated at 2022-06-23 18:04:56.892621
# Unit test for constructor of class cached_property
def test_cached_property():
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 18:05:06.364584
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    count = 0

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            nonlocal count
            count += 1
            return self.x + 1

    obj1 = MyClass()

    # noinspection PyStatementEffect
    obj1.y  # pylint: disable=pointless-statement
    assert count == 1

    # noinspection PyStatementEffect
    obj1.y  # pylint: disable=pointless-statement
    assert count == 1

    del obj1.y

    # noinspection PyStatementEffect
    obj1.y  # pylint: disable=pointless-statement
    assert count == 2

    # noinspection PyStatementEffect
    obj1.y  # pylint: disable=pointless-statement

# Generated at 2022-06-23 18:05:11.290946
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert callable(obj.y)
    assert obj.y == 6

# Generated at 2022-06-23 18:05:15.681731
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    obj.x = 10
    assert obj.y == 6

# Generated at 2022-06-23 18:05:25.716172
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestClass:

        def __init__(self, val=0):
            self.value = val

        @cached_property
        def prop(self):
            self.value += 1
            return self.value

    instance = TestClass()
    assert instance.value == 0
    assert instance.prop == 1
    assert instance.value == 1
    assert instance.prop == 1
    assert instance.value == 1

    instance.prop = 10
    assert instance.value == 10
    assert instance.prop == 1    # cached property
    assert instance.value == 10

    del instance.prop
    assert instance.value == 10  # deletes the value, not the cached value
    assert instance.prop == 11

    instance = TestClass(val=5)
    assert instance.value == 5
    assert instance.prop == 6

# Generated at 2022-06-23 18:05:36.101015
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""

    ###########################################################################
    # properties
    ###########################################################################
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6
    assert obj.__dict__['y'] == 6

    ###########################################################################
    # coroutines
    ###########################################################################
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return asyncio.coroutine(self._coro)()

        async def _coro(self):
            return self.x + 1

    obj = My

# Generated at 2022-06-23 18:05:43.669993
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    obj = object()
    coro = asyncio.coroutine(lambda: None)
    func = lambda: None

    cp = cached_property(func)

    assert cp.__get__(obj, cp) is func(obj)
    assert cached_property(coro).__get__(obj, cp)() is coro()(obj)
    assert cached_property(coro).__get__(obj, cp).__await__() is coro()(obj).__await__()

# Generated at 2022-06-23 18:05:47.271785
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y

    assert 'y' in obj.__dict__
    assert obj.__dict__['y'] == 6
    assert obj.y == 6

