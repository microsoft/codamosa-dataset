

# Generated at 2022-06-23 17:55:49.966523
# Unit test for constructor of class cached_property

# Generated at 2022-06-23 17:55:58.747381
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property
    from flutils import flutils

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    obj.x = 0
    assert obj.y == 1
    del obj.y
    obj.x = 10
    assert obj.y == 11
    assert flutils.FLUTILS_VERSION == '0.3.0'


if __name__ == '__main__':
    test_cached_property()

# Generated at 2022-06-23 17:56:09.835887
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import TestCase

    class MyTest(TestCase):

        def setUp(self):
            class MyClass:
                def __init__(self):
                    self.x = 5

            self.cls = MyClass

        def test_get_property_descriptor(self):
            @cached_property
            def y(self):
                return self.x + 1

            self.cls.y = y

            self.assertIsNot(self.cls.y, cached_property)
            self.assertTrue(hasattr(self.cls.y, '__get__'))

        def test_get_property_descriptor_from_instance(self):
            @cached_property
            def y(self):
                return self.x + 1

            self.cls.y = y
            instance

# Generated at 2022-06-23 17:56:14.206546
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass:

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    obj.x = 5
    assert obj.y == 6

# Generated at 2022-06-23 17:56:15.826417
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property



# Generated at 2022-06-23 17:56:19.715816
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1
    # create an instance of MyClass
    obj = MyClass()
    # y property value is 6
    assert obj.y == 6


# Generated at 2022-06-23 17:56:24.820023
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class foo:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = foo()
    assert obj.y == 6
    del obj.y
    assert obj.y == 6


# Generated at 2022-06-23 17:56:34.796702
# Unit test for constructor of class cached_property
def test_cached_property():
    class Test1:
        def __init__(self, count):
            self.count = count
    
        @cached_property
        def x(self):
            return self.count + 1

    class Test2(Test1):
        @cached_property
        def y(self):
            return self.x + 1

    def test1():
        t1 = Test1(5)
        assert t1.x == 6
        assert t1.__dict__['x'] == 6
        assert 'x' in t1.__dict__

        del t1.x
        assert 'x' not in t1.__dict__

    def test2():
        t2 = Test2(5)
        assert t2.x == 6
        assert t2.y == 7
        assert t2.__dict__['x'] == 6

# Generated at 2022-06-23 17:56:41.940807
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class A:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = A()
    assert 'y' not in obj.__dict__

    y = obj.y  # returns cached_property.__get__(obj)
    assert 'y' in obj.__dict__
    assert obj.y == 6

    obj.x = 15
    assert y == 6


# Generated at 2022-06-23 17:56:45.002416
# Unit test for constructor of class cached_property
def test_cached_property():

    class Class:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Class()
    assert obj.y == 6


# Generated at 2022-06-23 17:56:47.679687
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    in_obj = None
    in_cls = None
    result = cached_property.__get__(in_obj, in_cls)
    assert result is not None
    assert result is not Ellipsis


# Generated at 2022-06-23 17:56:54.420636
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # _cached_property.__get__ works with a Class instance
    class Foo(object):
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x * 2

    # No exception should be raised when calling uncached_property
    foo = Foo(5)

    assert foo.y == 10

    # Validate that foo.__dict__ contains the value passed in from
    # the property and that it is not a function.
    assert foo.__dict__['y'] == 10
    assert callable(foo.y) is not True

# Generated at 2022-06-23 17:57:00.616261
# Unit test for constructor of class cached_property
def test_cached_property():
    import pytest

    class TestClass(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def foo(self):
            return self.x + 1

    tc = TestClass()
    assert tc.foo == 6

    with pytest.raises(AttributeError):
        del tc.foo



# Generated at 2022-06-23 17:57:05.188255
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Setup
    class MyClass:
        @cached_property
        def y(self):
            return 1
    obj = MyClass()

    # Exercise
    actual = type(obj.y)
    expected = int
    # Verify
    assert actual == expected

# Generated at 2022-06-23 17:57:14.309726
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property."""

    def myfunc(obj):
        return 123

    prop = cached_property(myfunc)
    assert isinstance(prop, cached_property)
    assert prop.__doc__ == myfunc.__doc__
    assert prop.func is myfunc
    assert prop.__name__ == "cached_property"

    assert myfunc.__name__ not in __builtins__
    assert hasattr(cached_property, "__get__")
    assert hasattr(cached_property, "_wrap_in_coroutine")



# Generated at 2022-06-23 17:57:21.816862
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest import TestCase

    class MyClass:
        def __init__(self) -> None:
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # noinspection PyUnresolvedReferences
    assert isinstance(MyClass.y, cached_property)
    assert MyClass.y.__doc__ is None
    assert MyClass.y.func is MyClass.__dict__['y'].__func__

    my_cls = MyClass()
    assert my_cls.y == 6
    my_cls.x = 10
    assert my_cls.y == 6

    class MyOtherClass:
        def __init__(self):
            self.x = 5


# Generated at 2022-06-23 17:57:26.872772
# Unit test for constructor of class cached_property
def test_cached_property():
    """ Execute unit test for constructor of class cached_property """
    def dummy_func(obj):
        return "dummy_func"

    test_obj = cached_property(dummy_func)
    assert test_obj.__doc__ == getattr(dummy_func, "__doc__")
    assert test_obj.func == dummy_func


# Generated at 2022-06-23 17:57:27.966658
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    _test_cached_property___get__()

# Generated at 2022-06-23 17:57:30.391314
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert MyClass().y == 6



# Generated at 2022-06-23 17:57:32.142189
# Unit test for constructor of class cached_property
def test_cached_property():
    obj = cached_property('y')
    assert obj.__doc__ == 'y'
    assert obj.func == 'y'



# Generated at 2022-06-23 17:57:35.481190
# Unit test for constructor of class cached_property
def test_cached_property():
    class Foo:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    foo = Foo(5)
    assert foo.y == 6


# Generated at 2022-06-23 17:57:40.090101
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    my_class = CachedProperty()
    assert hasattr(my_class, 'y')
    assert hasattr(my_class, 'x')
    assert my_class.y.__name__ == 'y'
    assert my_class.x.__name__ == 'x'

    my_class = CachedProperty()
    assert my_class.y == 6
    assert my_class.y != my_class.x



# Generated at 2022-06-23 17:57:42.899131
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        @property
        def test_prop(self):
            print('hi')
            return 'hi'

    a = MyClass()
    print(a.test_prop)
    print(a.test_prop)



# Generated at 2022-06-23 17:57:54.877128
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import TestCase, main

    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class TestCachedProperty(TestCase):
        """ Unit tests for `cached_property` """

        def test_class_attribute(self):
            """ Test the attribute from a class. """

# Generated at 2022-06-23 17:57:59.602119
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for :func:`~flutils.decorators.cached_property`

    *New in version 0.2.0*
    """
    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 17:58:01.994273
# Unit test for constructor of class cached_property
def test_cached_property():
    assert isinstance(cached_property(lambda: 1), cached_property)



# Generated at 2022-06-23 17:58:03.905074
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property


if __name__ == '__main__':
    test_cached_property()

# Generated at 2022-06-23 17:58:06.934287
# Unit test for constructor of class cached_property
def test_cached_property():
    # xdoctest: +ELLIPSIS
    x = cached_property(lambda x: 1)
    assert x.func(1) == 1



# Generated at 2022-06-23 17:58:10.517584
# Unit test for constructor of class cached_property
def test_cached_property():

    @cached_property
    def x(self):
        return 1

    x.__doc__ = "I am the doc"
    assert x.__doc__ == "I am the doc"
    assert x.__name__ == "x"


# Generated at 2022-06-23 17:58:15.633626
# Unit test for constructor of class cached_property
def test_cached_property():
    class Test(object):

        def __init__(self):
            self.x = 50

        @cached_property
        def y(self):
            return self.x * 10

    test = Test()

    assert test.y == 500
    assert test.__dict__['y'] == 500

    test.x = 10
    assert test.y == 500

# Generated at 2022-06-23 17:58:25.811268
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    :return: No return.
    :rtype: None
    """
    class TestCachedProperty:
        """A class to test the cached_property decorator"""

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """A method decorated with cached_property"""
            return self.x + 1

    # Create a TestCachedProperty object
    obj = TestCachedProperty()
    # Call the method decorated with cached_property
    obj.y
    # Verify the method was actually cached
    assert obj.__dict__['y'] == 6


# Generated at 2022-06-23 17:58:35.203131
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from io import StringIO
    from datetime import datetime
    from .backport_cached_property import cached_property as cp

    class TestClass:

        @cp
        def time(self):
            return datetime.now().isoformat()

        @cp
        def value(self):
            return 'x' * 5

    x = TestClass()

    t1 = x.time
    v1 = x.value

    time.sleep(1)

    t2 = x.time
    v2 = x.value

    assert t1 == t2
    assert v1 == v2

    time.sleep(1)

    t3 = x.time
    v3 = x.value

    assert t1 != t3
    assert v1 == v3

    # Test that __get__ works with a coroutine, too.
   

# Generated at 2022-06-23 17:58:38.513946
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert MyClass.y.__doc__ == cached_property.__init__.__doc__

# Generated at 2022-06-23 17:58:40.279460
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass



# Generated at 2022-06-23 17:58:44.099115
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test for method ``cached_property.__get__()``."""

    class Foo:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Foo()
    assert obj.y == 6

# Generated at 2022-06-23 17:58:46.368708
# Unit test for constructor of class cached_property
def test_cached_property():
    c = cached_property(lambda x: x)
    assert c.__doc__ is None
    assert c.func  # noqa: WPS421



# Generated at 2022-06-23 17:58:55.054664
# Unit test for constructor of class cached_property
def test_cached_property():
    import unittest
    # delete module namespace so that class is loaded at each test
    del sys.modules['flutils.decorators']
    del sys.modules['flutils.decorators.cached_property']
    from flutils.decorators import cached_property
    import functools
    unittest.TestCase().assertEqual(cached_property.__name__, 'cached_property')
    unittest.TestCase().assertEqual(cached_property.__doc__, functools.cached_property.__doc__)
    # reload modules
    import flutils.decorators
    import flutils.decorators.cached_property
    unittest.TestCase().assertEqual(cached_property.__name__, 'cached_property')

# Generated at 2022-06-23 17:58:58.527618
# Unit test for constructor of class cached_property
def test_cached_property():
    """ Test cached_property constructor
    """
    @cached_property
    def mocked_cached_property():
        return "mocked_cached_property"

    assert mocked_cached_property.__doc__ is None


# Generated at 2022-06-23 17:59:10.641943
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test cached_property class when calling __get__ method."""

    class TestClass:
        pass


    obj = TestClass()

    assert not hasattr(obj, '_future_value')

    def get_data():
        return 'value'


    obj.get_data = cached_property(get_data)

    assert isinstance(obj.get_data, asyncio.Future)
    assert not obj.get_data.done()

    asyncio.get_event_loop().run_until_complete(obj.get_data)

    assert obj.get_data.done()
    assert obj.get_data.result() == 'value'
    assert not isinstance(obj.get_data, asyncio.Future)
    assert obj.get_data == 'value'
    assert obj._future_value == 'value'




# Generated at 2022-06-23 17:59:18.241491
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.objects import FlDict

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    test = FlDict(
        funcName=cached_property.__name__,
        init=MyClass().__dict__,
        values=MyClass().y,
        equal=6,
    )

    assert test.funcName == cached_property.__name__
    assert test.init == {}
    assert test.values == 6
    assert test.equal == 6

# Generated at 2022-06-23 17:59:21.135173
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.y == 6

# Generated at 2022-06-23 17:59:25.284588
# Unit test for constructor of class cached_property
def test_cached_property():

    class _Test:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    test = _Test()
    assert test.y == 6

# Generated at 2022-06-23 17:59:28.760829
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Example:
        def __init__(self):
            self.x = 5
        @cached_property
        def y(self):
            return self.x + 1
    obj = Example()
    assert obj.y == 6

# Generated at 2022-06-23 17:59:34.179142
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test cached_property decorator"""

    class MyClass:
        """Test class for cached_property decorator"""

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """Test function for cached_property decorator"""
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


if __name__ == '__main__':
    test_cached_property()

# Generated at 2022-06-23 17:59:35.997547
# Unit test for constructor of class cached_property
def test_cached_property():
    with pytest.raises(TypeError):
        assert cached_property()



# Generated at 2022-06-23 17:59:39.221257
# Unit test for constructor of class cached_property
def test_cached_property():
    def test_func():
        return 1

    # Test the decorator
    assert cached_property(test_func).func == test_func
    assert cached_property(test_func).__doc__ == ''



# Generated at 2022-06-23 17:59:47.501157
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass(5)
    with pytest.raises(AttributeError):
        _ = obj.x
    assert obj.__dict__['y'] == 6
    assert obj.y == 6


if __name__ == "__main__":
    import doctest

    doctest.testmod(globs=globals())

# Generated at 2022-06-23 17:59:51.092542
# Unit test for constructor of class cached_property
def test_cached_property():
    """Tests for cached_property"""

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 17:59:54.827742
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Obj:
        def __init__(self):
            self.name = 'AH'
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Obj()
    assert obj.y == 6

# Generated at 2022-06-23 18:00:06.272497
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test method __get__ of class cached_property"""

    class MyClass:

        def __init__(self, x: int):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return "something"

    obj = MyClass(5)
    assert obj.y == 6
    assert obj.z == "something"

    # Dict should have 2 items
    assert len(obj.__dict__) == 2

    # Test if decorator deletes when attribute is deleted
    del obj.y
    assert obj.y == 6
    assert len(obj.__dict__) == 3

    # Test if decorator deletes when attribute is deleted
    del obj.z
    assert obj.z == "something"

# Generated at 2022-06-23 18:00:10.034674
# Unit test for constructor of class cached_property
def test_cached_property():
    class A:
        @cached_property
        def c(self):
            return 1

    a = A()
    assert a.c == 1


if __name__ == "__main__":
    test_cached_property()

# Generated at 2022-06-23 18:00:12.556293
# Unit test for constructor of class cached_property
def test_cached_property():
    class Foo:
        @cached_property
        def foo(self):
            return None

    assert Foo.foo is not None
    foo = Foo()
    assert foo.foo is None

# Generated at 2022-06-23 18:00:20.081241
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test class cached_property

    *New in version 0.2.0*

    """
    import unittest
    import types
    from .decorators import cached_property

    class TestProperty(unittest.TestCase):
        """Tests for class :obj:`cached_property`"""

        class TestClassDecorator:
            """Test class for :obj:`cached_property`"""
            def __init__(self):
                self.x = 5

            @cached_property
            def y(self):
                """Test property."""
                return self.x + 1

        def test_decorator(self):
            """Test :obj:`cached_property`"""
            tc = TestProperty.TestClassDecorator()

# Generated at 2022-06-23 18:00:25.783323
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property."""

    # noinspection PyMissingOrEmptyDocstring,PyUnusedLocal
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert hasattr(MyClass, 'y')

# Generated at 2022-06-23 18:00:30.608125
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    with pytest.raises(AttributeError):
        obj.y = 20

# Generated at 2022-06-23 18:00:37.854884
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property.__doc__.strip(' ') == cached_property.__doc__.strip(' ')
    assert cached_property.__init__.__doc__.strip(' ') == cached_property.__init__.__doc__.strip(' ')
    assert cached_property.__get__.__doc__.strip(' ') == cached_property.__get__.__doc__.strip(' ')


# Generated at 2022-06-23 18:00:43.153029
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest
    from unittest.mock import patch

    obj = cached_property(None)
    with patch.object(obj, '__get__') as patched_get:
        obj.__get__(None, None)
        patched_get.assert_called_once_with(None, None)



# Generated at 2022-06-23 18:00:44.562710
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property



# Generated at 2022-06-23 18:00:50.555607
# Unit test for constructor of class cached_property
def test_cached_property():
    class Obj:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

        @property
        def z(self):
            return self.x + 1

    obj = Obj(5)
    assert obj.y == 6
    assert obj.y == 6

    obj.x = 11
    assert obj.y != 12
    assert obj.y == 6
    assert obj.y != 12



# Generated at 2022-06-23 18:00:52.985532
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:00:57.480291
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class Example:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert hasattr(Example, "y")



# Generated at 2022-06-23 18:01:00.690491
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y



# Generated at 2022-06-23 18:01:03.653651
# Unit test for constructor of class cached_property
def test_cached_property():

    import sys
    import flutils

    version_info = sys.version_info
    if version_info < (3, 8):
        assert flutils.decorators.cached_property
    else:
        assert flutils.decorators.cached_property == cached_property
# Unit test



# Generated at 2022-06-23 18:01:07.172863
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test of :meth:`~flutils.decorators.cached_property.__init__`.
    """
    assert cached_property.__doc__ is not None



# Generated at 2022-06-23 18:01:15.809997
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method `cached_property.__get__`

    *New in version 0.2.2*

    """
    import inspect
    import pytest

    from flutils.decorators import cached_property

    def test_func():
        return 'foo'

    class TestClass:

        @cached_property
        def test_prop(self):
            return test_func()

    obj = TestClass()

    assert isinstance(obj.test_prop, str)
    assert obj.test_prop == test_func()

    # The following does not work
    with pytest.raises(KeyError):
        assert obj.__dict__[TestClass.test_prop.__name__] == test_func()

    if inspect.iscoroutinefunction(TestClass.test_prop):
        asyncio.get

# Generated at 2022-06-23 18:01:24.156156
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import Mock

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__['y'] == 6
    assert obj.x == 5
    obj.x = 10
    assert obj.y == 12
    assert obj.__dict__['y'] == 12
    assert obj.x == 10

    func = Mock()

    @cached_property
    def z(self):
        return func()

    assert z.__get__(obj, obj) == func()
    assert z.__get__(None, None) == z
    assert z.__get__(None, None) is z




# Generated at 2022-06-23 18:01:26.835862
# Unit test for constructor of class cached_property
def test_cached_property():

    @cached_property
    def test_property():
        return 1

    assert(test_property == 1)
    assert(test_property == 1)

# Generated at 2022-06-23 18:01:30.636244
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:01:35.283761
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 18:01:41.305077
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test method __get__ of class cached_property"""

    # Use class cached_property.
    class MyClass:

        def __init__(self):
            # Value is changed to test caching.
            self.x = 5

        @cached_property
        def y(self):
            """Test cached property"""
            return self.x + 1

    # Test
    obj = MyClass()
    assert obj.y == 6

    obj.x = 15
    assert obj.y == 6

# Generated at 2022-06-23 18:01:52.579257
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import asyncio
    import pytest

    class TestCachedProperty:

        def __init__(self):
            self.x = 0

        @cached_property
        def y(self):
            return self.x + 1

    tc = TestCachedProperty()
    assert tc.y == 1

    loop = asyncio.get_event_loop()
    i = 0

    async def test_y():
        nonlocal i
        i = 1
        await asyncio.sleep(0.3)
        i = 2
        return i

    tc.y = test_y()
    loop.run_until_complete(tc.y)
    assert i == 2

    assert tc.y == 2

    # print('\n')
    # print(dir(TestCachedProperty.y))
    # print(dir(tc.y

# Generated at 2022-06-23 18:01:59.831287
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    @cached_property
    def x(obj):
        return obj

    class MyClass:
        pass

    obj = MyClass()
    obj.x = MyClass()

    assert obj.x is obj
    assert x.__get__(obj, obj.__class__) is obj
    assert x.__get__(None, obj.__class__) is x
    assert obj.__dict__ == {'x': obj}

    del obj.x
    assert obj.x is obj
    assert 'x' in obj.__dict__



# Generated at 2022-06-23 18:02:05.938152
# Unit test for constructor of class cached_property
def test_cached_property():
    class A:
        @cached_property
        def x(self):
            return 5

    obj = A()
    assert obj.__dict__.get('x') is None
    assert obj.x == 5
    assert obj.__dict__['x'] == 5
    print('Test PASSED')

# Generated at 2022-06-23 18:02:12.505971
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Test(object):
        @cached_property
        def foo(self):
            return "bar"

    instance = Test()
    assert instance.foo == "bar"

    class Test(object):
        @cached_property
        def foo(self):
            return self.bar

        @cached_property
        def bar(self):
            return "bar"

    instance = Test()
    assert instance.foo == "bar"



# Generated at 2022-06-23 18:02:19.196392
# Unit test for constructor of class cached_property
def test_cached_property():
    class A:
        _x = 5

        @cached_property
        def x(self):
            if self._x:
                return self._x
            return None

        def __init__(self):
            self._x += 1

    a = A()
    assert a.x == 6
    assert a._x == 6


if __name__ == '__main__':
    import pytest

    pytest.main(['-xrs', __file__])

# Generated at 2022-06-23 18:02:23.506750
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Ob(object):
        def __init__(self, x, y):
            self.x = x
            self.y = y

        @cached_property
        def z(self):
            return self.x + self.y

    inst = Ob(1, 2)
    assert inst.z == 3


# Generated at 2022-06-23 18:02:31.966271
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test for method __get__ of class cached_property

    See Also:
        * :meth:`flutils.decorators.cached_property`
    """
    from flutils.miscutils import ObjectProxy

    class OtherClass:

        def __init__(self, in_data, in_str_data=None):
            self._data = in_data
            self.str_data = in_str_data

        @cached_property
        def data(self):
            return self._data

        @data.setter
        def data(self, value):
            self._data = value
            return self._data

        @cached_property
        def str_data(self):
            return self._str_data

        @str_data.setter
        def str_data(self, value):
            self

# Generated at 2022-06-23 18:02:36.666292
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__ == {'x': 5, 'y': 6}

# Generated at 2022-06-23 18:02:40.265335
# Unit test for constructor of class cached_property
def test_cached_property():
    class Class:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Class()
    assert obj.y == 6

# Generated at 2022-06-23 18:02:47.517391
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test the function :obj:`~flutils.decorators.cached_property`."""

    class Test:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @property
        def z(self):
            return self.x + 2

    test = Test()
    assert test.y == 6
    assert test.z == 7

    test.x = 10
    assert test.y == 6
    assert test.z == 12

# Generated at 2022-06-23 18:02:48.264945
# Unit test for constructor of class cached_property

# Generated at 2022-06-23 18:02:53.956301
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import Mock

    _mock = Mock()
    _mock.x = 5

    def _gen_y(_mock):
        return _mock.x + 1

    @cached_property
    def y(_mock):
        return _gen_y(_mock)

    _y = y.__get__(_mock, None)
    assert _y == 6

# Generated at 2022-06-23 18:03:00.513467
# Unit test for constructor of class cached_property
def test_cached_property():
    # pylint: disable=no-member, missing-function-docstring
    class Class:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            "property"
            return self.x + 1

    obj = Class()
    obj.y

    assert obj.y == 6
    assert obj.__dict__['y'] == 6
    assert obj.y.__doc__ == "property"

# Generated at 2022-06-23 18:03:03.646224
# Unit test for constructor of class cached_property
def test_cached_property():
    result = cached_property(lambda x: x)
    assert result.__doc__ is None
    assert result.func(None) is None


if __name__ == '__main__':
    import pytest

    pytest.main([__file__])

# Generated at 2022-06-23 18:03:07.272278
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 18:03:13.557317
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class Test:

        def __init__(self, val):
            self.val = val

        def _foo(self):
            return self.val

    t = Test(1)

    with pytest.raises(KeyError, match=r".*'_foo'.*"):
        t._foo

    t.__dict__["_foo"] = 2

    with pytest.raises(KeyError, match=r".*'_foo'.*"):
        t._foo

    t.__dict__["_foo"] = 3

    assert t._foo == 3

    class Test:

        def __init__(self, val):
            self.val = val

        @cached_property
        def foo(self):
            return self.val

    t = Test(1)

    assert t.foo == 1


# Generated at 2022-06-23 18:03:14.449098
# Unit test for constructor of class cached_property
def test_cached_property():
    cached_property(lambda x: ())

# Generated at 2022-06-23 18:03:15.784632
# Unit test for constructor of class cached_property
def test_cached_property():
    assert callable(cached_property(lambda x: x))

# Generated at 2022-06-23 18:03:21.864640
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    loop = asyncio.get_event_loop()

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    loop.run_until_complete(obj.y)


## END

# Generated at 2022-06-23 18:03:30.003219
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import io
    from contextlib import redirect_stdout
    from flutils.decorators import cached_property
    import sys

    _orig_stdout = sys.stdout


# Generated at 2022-06-23 18:03:33.982925
# Unit test for constructor of class cached_property
def test_cached_property():
    class Foo:
        def __init__(self, bar):
            self.bar = bar

        @cached_property
        def baz(self):
            return self.bar + "baz"

    assert Foo("bar").baz == "barbaz"

# Generated at 2022-06-23 18:03:41.805438
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import call, Mock

    class MyMock(Mock):
        @cached_property
        def prop(self):
            return self.call()

    obj = MyMock()
    _ = obj.prop
    #: obj.prop() was called
    assert obj.method_calls == [call.prop()]
    #: The value of obj.prop is cached
    assert obj.prop == obj.prop
    #: obj.prop() was called only once
    assert obj.method_calls == [call.prop()]
    del obj.prop
    #: obj.prop() should be called again
    assert obj.prop == obj.prop
    #: obj.prop() was called again
    assert obj.method_calls == [call.prop(), call.prop()]
    #: Clean up

# Generated at 2022-06-23 18:03:50.497938
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit tests for method __get__ of class cached_property"""
    import functools
    import inspect
    import sys

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    # Test 1 - The property value should be cached and returned from
    # the instance dict
    assert obj.__dict__[obj.y.__name__] == obj.y == 6

    # Test 2 - The cached property should not be expanded when the instance
    # dict is cleared
    obj.__dict__.clear()

    # Test 3 - Test the cached property retrieval again
    assert obj.__dict__[obj.y.__name__] == obj.y == 6

    # Test 4 - If a

# Generated at 2022-06-23 18:04:01.605389
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class Person:
        def __init__(self, name):
            self.name = name
            self.calls = 0

        @cached_property
        def first_name(self):
            """Test of first name."""
            self.calls += 1
            return self.name.split(" ")[0]

        @cached_property
        async def async_first_name(self):
            """Test of async first name."""
            self.calls += 1
            return (await self.first_name) + "Async"

    p = Person("Rene Descartes")

    assert p.first_name == "Rene"
    assert p.first_name == "Rene"
    assert p.calls == 1
    del p.first_name
   

# Generated at 2022-06-23 18:04:09.039739
# Unit test for constructor of class cached_property
def test_cached_property():
    """ Unit Testing for caching of the property """

    class MyClass:

        def __init__(self):
            self.i = 0

        @cached_property
        def incr(self):
            """ Increments the value of i """
            self.i += 1
            return self.i

    obj = MyClass()
    assert obj.incr == 1
    assert obj.incr == 1
    assert obj.incr == 1

# Generated at 2022-06-23 18:04:09.763752
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    assert True

# Generated at 2022-06-23 18:04:20.981682
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import sys
    import unittest

    PY_36 = sys.version_info[:2] == (3, 6)

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        async def z(self):
            return self.x + 1

    class TestCachedProperty___get__(unittest.TestCase):
        def setUp(self):
            self.obj = MyClass()

        def test_cached_property_get___default(self):
            self.assertEqual(self.obj.y, 6)


# Generated at 2022-06-23 18:04:25.968495
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class TestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.y == 6
    obj = TestClass()
    assert obj.y == 6


# Generated at 2022-06-23 18:04:27.735446
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for class :obj:`cached_property`."""
    assert cached_property



# Generated at 2022-06-23 18:04:31.508605
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:04:37.091916
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.val = 3

        @cached_property
        def prop(self):
            return self.val

    obj = MyClass()
    assert obj.prop == 3
    obj.val = 7
    assert obj.prop == 7
    del obj.prop
    assert obj.prop == 7


# Generated at 2022-06-23 18:04:45.833676
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    def __test_get(test_func):

        class TestClass:
            @cached_property
            def test(self):
                return test_func()

        test_obj = TestClass()

        assert test_obj.test == test_func()
        assert test_obj.test == test_func()

    # Test with function
    @asyncio.coroutine
    def _test_func():
        return True

    __test_get(_test_func)

    # Test with async function
    @asyncio.coroutine
    def _test_async_func():
        return True

    __test_get(_test_async_func)

# Generated at 2022-06-23 18:04:51.486873
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest

    # cached_property.__get__() returns a coroutine
    class MyClass:

        @cached_property
        def y(self):
            self.y = 5
            return self.y

    obj = MyClass()
    assert obj.y == 5



# Generated at 2022-06-23 18:04:57.848168
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.testing import AsyncMock

    class Foo:
        def __init__(self):
            self._x = 5

        @cached_property
        def x(self):
            return self._x
            # return obj

    f = Foo()
    assert f.x == 5



# Generated at 2022-06-23 18:05:03.238322
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test cached_property.__get__
    """
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    # y attribute is set with it's computed value
    assert hasattr(obj, 'y')
    assert obj.y == 6



# Generated at 2022-06-23 18:05:08.097206
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """ Test cached_property.__get__.

    """
    def calc(obj):
        obj.__dict__['x'] = obj.__dict__['x'] * 2
        return obj.__dict__['x']

    # noinspection PyTypeChecker
    class TestClass:
        y = cached_property(calc)

    x = TestClass()
    x.x = 2
    assert x.x == 2
    y = x.y
    assert y == 4
    assert x.x == 4
    assert x.x is x.y



# Generated at 2022-06-23 18:05:09.227507
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    assert True

# Generated at 2022-06-23 18:05:18.674431
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import time
    import timeit

    class TestClass:

        def __init__(self, a, b):
            self.a = a
            self.b = b

        @cached_property
        def y(self):
            return self.b - self.a

        @cached_property
        async def c(self):
            for i in range(1, 11):
                print("sleep {}".format(i))
                # Sleep for 1 second
                await asyncio.sleep(1)
                print("sleep {} completed".format(i))

    test_obj = TestClass(5, 11)
    assert test_obj.y == 6
    assert test_obj.y == 6
    assert "y" in test_obj.__dict__

    # Test for the case when the property is computed asynchronously
    asyncio.run

# Generated at 2022-06-23 18:05:25.212473
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""
    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    assert obj.__dict__ == {'x': 5, 'y': 6}

# Generated at 2022-06-23 18:05:28.402695
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property
    import asyncio

    def test():
        @cached_property
        def my_method(self):
            return self.x + 1

        class MyClass:
            def __init__(self):
                self.x = 5

    test()



# Generated at 2022-06-23 18:05:31.534367
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.tests import UnitTester
    tester = UnitTester()
    tester.test_class(cached_property)


# Generated at 2022-06-23 18:05:42.277935
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest import TestCase

    class Test(TestCase):
        def test_two(self):
            obj = MyClass()
            self.assertEqual(obj.y, 6)
            del obj.y
            self.assertEqual(obj.y, 6)

    # noinspection PyProtectedMember
    obj = cached_property(lambda x: 5)
    obj2 = cached_property(lambda x: 6)
    assert obj.__doc__ is None
    assert obj2.__doc__ is None
    assert obj.func(None) == 5
    assert obj2.func(None) == 6

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()


# Generated at 2022-06-23 18:05:44.529635
# Unit test for constructor of class cached_property
def test_cached_property():
    # noinspection PyPep8Naming
    class _TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return 5

    _TestClass().y