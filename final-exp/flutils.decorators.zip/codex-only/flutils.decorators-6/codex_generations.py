

# Generated at 2022-06-23 17:55:48.964279
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Unit test for cached_property decorator.

    Usage:

        $ python flutils/decorators.py

    ..  versionadded:: 0.2.0

    """
    import unittest

    class test_cached_property(unittest.TestCase):
        def test_1(self):
            def _f():
                pass
            cp = cached_property(_f)
            self.assertEqual(cp.__doc__, None)
            self.assertEqual(cp.func, _f)
            self.assertIsInstance(
                cp.__get__(None, object),
                cached_property
                )
            self.assertIsInstance(
                cp.__get__(object(), object),
                _f
                )

# Generated at 2022-06-23 17:56:00.275209
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Unit test for :obj:`~flutils.decorators.cached_property`
    """
    import unittest
    from unittest.mock import patch

    from flutils.decorators import cached_property

    class Test(object):
        pass

    class TestAsClass(object):
        @classmethod
        def __init__(cls):
            pass

        @classmethod
        def __get__(cls, obj, owner):
            if obj is None:
                return cls

            return "class_method"

    class TestAsFunction(object):
        def __init__(self):
            pass

        def __call__(self):
            return "function"

    class TestAsFunctionAsClass(object):
        @classmethod
        def __init__(cls):
            pass



# Generated at 2022-06-23 17:56:05.550274
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test cached_property.__get__."""

    class ClassWithCachedProperty:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = ClassWithCachedProperty()
    assert obj.y == 6



# Generated at 2022-06-23 17:56:08.715512
# Unit test for constructor of class cached_property
def test_cached_property():
    import pickle
    obj = cached_property(lambda x: 5)
    assert obj.__name__ == '<lambda>'
    assert pickle.loads(pickle.dumps(obj)).__name__ == '<lambda>'

# Generated at 2022-06-23 17:56:12.286592
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Mock:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Mock()
    assert obj.y == 6
    obj.x = 10
    assert obj.y == 6


# Generated at 2022-06-23 17:56:20.057690
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from .dictutils import DotDict

    class TestClass:
        def __init__(self):
            self._val = 5

    tc = TestClass()

    @cached_property
    def x(self):
        return self._val + 1

    tc.x = cached_property(x)
    result = tc.x
    assert result.result() == 6

    # Default value
    obj = DotDict(val=5)
    result = obj.val
    assert result == 5

    # Set value
    obj.val = 10
    result = obj.val
    assert result == 10


# Generated at 2022-06-23 17:56:31.775145
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""

    import unittest
    import inspect
    import sys

    class TestClass(object):

        # noinspection SpellCheckingInspection,PyUnusedLocal
        @cached_property
        def foo(self):
            return 'bar'

    try:
        import unittest.mock as mock
    except ImportError:
        import mock

    class TestCachedProperty(unittest.TestCase):
        """Unit tests for cached_property."""

        def setUp(self):  # noqa: D102
            self.obj = TestClass()

        # noinspection PyPep8Naming
        def test___init___(self):  # noqa: D102
            """Test method __init__."""
            func = mock.MagicMock()


# Generated at 2022-06-23 17:56:41.688380
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    def _create_class():
        class MyDecoratorClass:
            def __init__(self):
                self.x = 5

            @cached_property
            def y(self):
                return self.x + 1

            @cached_property
            def z(self):
                return self.x + 2

        return MyDecoratorClass

    obj = _create_class()()
    y = obj.y
    assert y == 6
    assert obj.y == 6

    z = obj.z
    assert z == 7
    assert obj.z == 7

    obj.x = 10
    assert obj.y == 6
    assert obj.z == 7

# Generated at 2022-06-23 17:56:49.433509
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property
    """
    import asyncio

    @cached_property
    def x(self):
        return 5

    class MyClass:
        y = x

    m = MyClass()
    d = m.__dict__
    assert "y" not in d
    assert hasattr(m, "y")
    assert m.y == 5
    assert d["y"] == 5

    @cached_property
    async def a(self):
        return await asyncio.sleep(1)

    class MyClass2:
        a = a

    a = AsyncMock()
    with patch.object(asyncio, "ensure_future", a):
        m2 = MyClass2()
    d2 = m2.__dict__
    assert d2 == {}
   

# Generated at 2022-06-23 17:56:55.327612
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Object(object):

        def __init__(self, name: str, value: int) -> None:
            self.name = name
            self.value = value

        @cached_property
        def result(self):
            return self.value + 5

    obj = Object('test_obj', 2)
    obj.result
    assert obj.result == 7



# Generated at 2022-06-23 17:56:59.431304
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test cached_property constructor

    Raises:
        AssertionError: Unit tests fail

    See Also:
        :obj:`flutils.decorators.test.test_decorators`

    """
    assert hasattr(cached_property, "func")
    assert hasattr(cached_property, "__doc__")
    assert isinstance(cached_property.__doc__, str)

# Generated at 2022-06-23 17:57:11.644698
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test cached_property.__get__().
    """
    class A:
        def __init__(self, x):
            self.x = x

        # Note: Putting @cached_property outside of class doesn't work.
        #       Has to be inside.
        @cached_property
        def y(self):
            return self.x + 1

    a = A(6)
    print(a.y)
    print(a.y)
    print(a.y)

    print('-' * 80)

    b = A(6)
    print(b.y)
    print(b.y)
    print(b.y)

    print('-' * 80)

    # Change object property.
    b.x = 7
    print(b.y)
    print(b.y)
    print

# Generated at 2022-06-23 17:57:16.129971
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.y == 6



# Generated at 2022-06-23 17:57:18.466520
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test the constructor of class cached_property.

    """

    assert cached_property.__doc__.startswith("A property decorator that")

# Generated at 2022-06-23 17:57:24.529794
# Unit test for constructor of class cached_property
def test_cached_property():
    """ Unit test for constructor of class cached_property."""
    import os.path
    from flutils.decorators import cached_property

    class Test:
        """For testing constructor of class cached_property."""

        @cached_property
        def test(self):
            return True

    path = os.path.dirname(__file__)
    if hasattr(path, "decode"):
        path = path.decode(sys.getfilesystemencoding())

    assert hasattr(cached_property, "__init__")
    assert callable(cached_property.__init__)

    obj = Test()
    assert hasattr(obj, "test")
    assert obj.test is True
    del obj.test
    assert not hasattr(obj, "test")

    t = cached_property(lambda: True)

# Generated at 2022-06-23 17:57:30.917994
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test the cached_property decorator

    Test that value is cached, along with testing that
    the return value is reference and not a copy.

    """

    class TestClass:
        def __init__(self, x):
            self.x = x

        @cached_property
        def mycache(self):
            return self.x

    test_obj = TestClass(3)
    test_obj.mycache
    n = 4
    test_obj.x = n
    assert test_obj.mycache is n

# Generated at 2022-06-23 17:57:39.362803
# Unit test for constructor of class cached_property
def test_cached_property():
    import unittest
    import asyncio

    class TestCachedProperty(unittest.TestCase):

        def test_basic(self):
            class Foo:
                @cached_property
                def foo(self):
                    return 'bar'

            f = Foo()
            self.assertEqual(f.foo, 'bar')

        def test_cache_deletion(self):
            class Foo:
                @cached_property
                def foo(self):
                    return 'bar'

            f = Foo()
            self.assertEqual(f.foo, 'bar')
            del f.foo
            self.assertEqual(f.__dict__, {})

        def test_async_function(self):
            @asyncio.coroutine
            def wait_a_sec():
                yield from asyncio.sleep

# Generated at 2022-06-23 17:57:41.374964
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self, x: int):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass(5)

    assert hasattr(obj, 'y')
    assert obj.y == 6

# Generated at 2022-06-23 17:57:47.837635
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class MyAsyncClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return asyncio.sleep(0.001, self.x + 1)

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__['y'] == 6
    obj2 = MyClass()
    assert obj2.y == 6
    assert obj2.__dict__['y'] == 6
    assert obj.y == 6
    assert obj.__dict__['y'] == 6


# Generated at 2022-06-23 17:57:53.020193
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 17:58:01.730478
# Unit test for constructor of class cached_property
def test_cached_property():
    from inspect import iscoroutinefunction
    import asyncio

    class Example:

        @cached_property
        def async_property(self):
            yield from asyncio.sleep(1)
            return self.async_property

        @asyncio.coroutine
        def foo(self):
            yield from asyncio.sleep(1)
            return self.foo

        @property
        def prop(self):
            return self.prop

    ex = Example()
    assert iscoroutinefunction(Example.async_property)
    assert iscoroutinefunction(Example.foo)
    assert not iscoroutinefunction(Example.prop)

# Generated at 2022-06-23 17:58:11.788890
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Tests for cached_property
    """
    from .helpers import mk_tmp_dir, rm_tmp_dir

    temp_dir = mk_tmp_dir()

# Generated at 2022-06-23 17:58:20.698142
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 1
            self.y = 1

        @cached_property
        def foo(self):
            return self.x + self.y

        @cached_property
        def bar(self):
            return self.x * self.y

    obj = MyClass()
    assert obj.foo == 2
    assert obj.bar == 1
    obj.x = 2
    assert obj.foo == 2
    assert obj.bar == 1

# Generated at 2022-06-23 17:58:26.907290
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Tests for :meth:`~flutils.decorators.cached_property.__get__`"""
    class A:
        pass

    a = A()
    assert cached_property.__get__(None, a) is None
    assert cached_property.__get__(None, None) is None


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-23 17:58:35.984683
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    from unittest import mock
    from unittest import TestCase


    class Class1:

        def __init__(self):
            self._method_call_count = 0
            self._method_result = 99

        @cached_property
        def method(self):
            self._method_call_count += 1
            return self._method_result


    class Class2(Class1):

        @mock.patch.object(Class1, 'method')
        def test_method_call_count(self, mock_method):
            # If the decorated method is called twice:
            self.method
            self.method
            # The method should only be called once:
            self.assertEqual(mock_method.call_count, 1)



# Generated at 2022-06-23 17:58:42.665247
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Test for class property
    assert MyClass.y.__doc__ == "A property decorator that is only computed"
    " once per instance and then replaces itself with an ordinary attribute."

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 17:58:46.368784
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test class cached_property.

    Raises:
        AssertionError -- If test fails

    Returns:
        None

    """
    # noinspection PyStatementEffect,PyUnresolvedReferences
    with pytest.raises(AttributeError):
        x = cached_property(y)

# Generated at 2022-06-23 17:58:50.368701
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Foo:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Foo()
    res = obj.y
    assert res == 6

    obj2 = Foo()
    obj2.x = 6
    res = obj2.y
    assert res == 7



# Generated at 2022-06-23 17:58:55.896125
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Foo:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert 4 == Foo.y
    assert 6 == Foo().y
    assert 6 == Foo().y



# Generated at 2022-06-23 17:59:00.154172
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 17:59:03.971858
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class test_cached_property___get__:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """
            :rtype: int
            """
            return self.x + 1

    obj = test_cached_property___get__()
    assert obj.y == 6



# Generated at 2022-06-23 17:59:10.688333
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property
    from flutils.toolbox import Object
    import asyncio

    class MyClass(Object):

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    def test():
        assert obj.y == 6

    loop = asyncio.get_event_loop()
    loop.run_until_complete(test())
    loop.close()

# Generated at 2022-06-23 17:59:13.124544
# Unit test for constructor of class cached_property
def test_cached_property():
    a = cached_property(lambda x: x+1)
    assert a.__doc__ is None


# Generated at 2022-06-23 17:59:16.668494
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property.

    This ensures that the proper doc string is returned.
    """
    def f():
        return

    c = cached_property(f)
    assert c.__doc__ == f.__doc__

# Generated at 2022-06-23 17:59:26.327505
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5
            self.y = None

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x + 2

    assert MyClass.y.__doc__ is None
    assert MyClass.y.func(None) is None
    assert MyClass.z.__doc__ is None
    assert MyClass.z.func(None) is None

    obj = MyClass()
    assert obj.x == 5
    assert obj.y == 6
    assert obj.z == 7

# Generated at 2022-06-23 17:59:29.872663
# Unit test for constructor of class cached_property
def test_cached_property():

    class Foo:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    foo = Foo()
    foo.y = 10
    assert foo.y == 10



# Generated at 2022-06-23 17:59:41.201351
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import patch, call
    from flutils.helpers import AttrDict
    from flutils.decorators import cached_property

    # Test: GET attribute with __get__ method
    @cached_property
    def expected__get__(self):
        self.__dict__.setdefault("_called__get__", []).append(expected__get__.__name__)
        return "EXPECTED: __get__"

    @patch(target="{}.expected__get__()".format(__name__), new=expected__get__)
    def test():
        # Test: GET attribute
        obj = AttrDict(x=5)
        obj.__dict__.setdefault("_called__get__", []).append(obj.x)


# Generated at 2022-06-23 17:59:47.370800
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class Cls:

        def __init__(self):
            self.x = 5

    # noinspection PyUnusedLocal
    @cached_property
    def z(self):
        return self.x + 1

    obj = Cls()
    result = z.__get__(obj, obj.__class__)
    assert result == 6



# Generated at 2022-06-23 17:59:53.757012
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.__dict__ == {"x": 5}
    # noinspection PyUnusedLocal
    y = obj.y
    assert obj.__dict__ == {"x": 5, "y": 6}
    assert obj.y == obj.__dict__["y"]
    assert obj.y == 6
    obj.x = 1
    assert obj.y == 6
    del obj.y
    assert obj.__dict__ == {"x": 1}
    obj.y
    assert obj.__dict__ == {"x": 1, "y": 2}
    assert obj.__dict__["y"] == obj.y

# Generated at 2022-06-23 18:00:00.497532
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from pytest import raises

    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    with raises(AttributeError):
        assert obj.y()



# Generated at 2022-06-23 18:00:04.797391
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Foo:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    foo = Foo()
    assert foo.y == 6
    assert foo.y == 6



# Generated at 2022-06-23 18:00:13.852701
# Unit test for constructor of class cached_property
def test_cached_property():
    from copy import copy

    # Test property is cached in __dict__.
    class Foo(object):
        def __init__(self, val):
            self.val = val

        @cached_property
        def computed_val(self):
            print("calling computed_val")
            return self.val * 4

    foo1 = Foo(5)
    foo2 = Foo(3)
    assert foo1.computed_val == 20
    assert 'computed_val' in foo1.__dict__
    assert 'computed_val' not in foo2.__dict__
    assert 'val' in foo1.__dict__
    assert 'val' in foo2.__dict__
    foo2.val = 4
    # Test property is _not_ cached in __dict__.

# Generated at 2022-06-23 18:00:19.862995
# Unit test for constructor of class cached_property
def test_cached_property():
    # GitHub issue #3
    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.y == 6
    assert hasattr(obj.__class__, 'y') is False

# Generated at 2022-06-23 18:00:27.069608
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import Mock
    import unittest

    obj = Mock()
    cp = cached_property(object())
    cp.__get__(obj, object())

    @cached_property
    def property_func(mock):
        return object()

    cp2 = property_func
    unittest.TestCase().assertEqual(cp2, property_func)

# Generated at 2022-06-23 18:00:27.908071
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property


# Generated at 2022-06-23 18:00:37.907720
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest.mock import Mock

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    patch('flutils.decorators.cached_property.__get__', Mock(return_value=4)).start()
    patch('flutils.decorators.cached_property.__set__', Mock()).start()

    from flutils.decorators import cached_property
    # Test function.
    @cached_property
    def a_property():
        return 2 * 3

    # Get the property.
    ap = a_property.__get__()

    # Assert that the value of the property is the expected value.
    assert ap == 6

# Generated at 2022-06-23 18:00:40.630576
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        @cached_property
        def y(self):
            return 1

    assert MyClass().y == 1



# Generated at 2022-06-23 18:00:48.464654
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:
        y = None
        @cached_property
        def y(self):
            return 1

    obj = MyClass()

    # first call
    assert obj.y == 1
    assert isinstance(obj.y, Future)

    # second call
    assert obj.y == 1
    assert isinstance(obj.y, Future)

    # setting attribute
    obj.y = 3
    assert obj.y == 3

    # resetting attribute
    del(obj.y)
    assert obj.y == 1
    assert isinstance(obj.y, Future)

# Generated at 2022-06-23 18:00:53.345962
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # noinspection SpellCheckingInspection
    """Unit test for method __get__ of class cached_property."""

    # Arrange
    class MyClass:

        @cached_property
        def my_property(self):
            return "I am a docstring."

    obj = MyClass()

    # Act - Assert
    assert obj.my_property == "I am a docstring."
    assert obj.__dict__["my_property"] == "I am a docstring."



# Generated at 2022-06-23 18:00:58.958721
# Unit test for constructor of class cached_property
def test_cached_property():
    # class MyClass:
    #     def __init__(self):
    #         self.x = 5

    #     @cached_property
    #     def y(self):
    #         return self.x + 1
    # obj = MyClass()
    # print(obj.y)
    pass


if __name__ == '__main__':
    test_cached_property()

# Generated at 2022-06-23 18:01:06.717746
# Unit test for constructor of class cached_property
def test_cached_property():
    # import unittest
    # from typing import Any

    class Class():
        def __init__(self, num_runs: int = 0):
            self.num_runs = 0

        @cached_property
        def test_property(self):
            self.num_runs = self.num_runs + 1 if self.num_runs else 1
            return self.num_runs

    obj = Class()
    obj.test_property
    assert obj.test_property == 1



# Generated at 2022-06-23 18:01:12.673125
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        @asyncio.coroutine
        def y(self):
            yield from asyncio.sleep(1)
            return self.x + 1

    obj = MyClass()
    assert asyncio.iscoroutinefunction(obj.y)
    obj.y()
    assert asyncio.iscoroutine(obj.y)

# Generated at 2022-06-23 18:01:17.013597
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test constructor for class cached_property.

    *New in version 0.2.0*
    """

    import flutils.decorators

    assert flutils.decorators.cached_property is cached_property

del Any, cached_property

# Generated at 2022-06-23 18:01:22.436868
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():  # noqa: D103

    from flutils.decorators import cached_property
    from functools import partial

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    obj.y
    # check that the property is just a plain int
    assert type(obj.y) == int


# Generated at 2022-06-23 18:01:29.966659
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():  # noqa: D101
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert 'y' in obj.__dict__
    assert obj.__dict__['y'] == obj.y



# Generated at 2022-06-23 18:01:33.667540
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property.__doc__ is not None
    assert cached_property.__init__(cached_property)
    assert cached_property.__get__(cached_property.__init__)

# Generated at 2022-06-23 18:01:37.521426
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestObj(object):

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestObj()
    assert obj.y == 6


# Generated at 2022-06-23 18:01:46.373408
# Unit test for constructor of class cached_property
def test_cached_property():
    from collections.abc import Hashable
    from flutils.decorators import cached_property
    """
    Test cached_property
    """

    class A:
        """
        A is a class
        """

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return [1, 2, 3]

        @cached_property
        def foo(self):
            return 'bar'

        @property
        def bar(self):
            return 'foo'

    expect = {1, 2, 3}
    actual = set(A().z)
    assert actual == expect

    assert A().y == 6

    a = A()
    assert a.x == 5


# Generated at 2022-06-23 18:01:49.012425
# Unit test for constructor of class cached_property
def test_cached_property():
    class X:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert X().y == 6

# Generated at 2022-06-23 18:01:53.250252
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test function for cached_property constructor.

    *New in version 0.2.0*
    """

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert MyClass().y == 6



# Generated at 2022-06-23 18:01:57.624268
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.y == 6



# Generated at 2022-06-23 18:02:04.667331
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property.

    Raises
    ------
    AssertionError
        If test fails.

    *New in version 0.2.0*

    """
    from unittest import TestCase

    from flutils.textutils import wrap_text

    class TestClass0:

        def __init__(self):
            self.x = 5

        @cached_property
        def property(self):
            return self.x + 1

    class TestClass1:

        def __init__(self):
            self.x = 5

        @cached_property
        @asyncio.coroutine
        def property(self):
            yield from asyncio.sleep(0.01)
            return self.x + 1


# Generated at 2022-06-23 18:02:14.616105
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    '''Unit test for method __get__ of class cached_property.'''
    def _test_cached_property___get__(obj):
        '''
        Test if the property value is cached and
        the property is deleted.
        '''
        # Test property is cached
        assert obj.x == 10
        # Test property is deleted
        obj.__dict__[Test__get__.x.func.__name__] = 15
        assert obj.x == 15

    class Test__get__:
        def __init__(self):
            self.x = 5

        @cached_property
        def x(self):
            return self.x + 5

    _test_cached_property___get__(Test__get__())



# Generated at 2022-06-23 18:02:19.642197
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of :func:`flutils.decorators.cached_property`.
    """

    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1



# Generated at 2022-06-23 18:02:29.805055
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test the __get__ method of the cached_property decorator.

    *New in version 0.2.0*

    """

    import unittest

    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class TestCachedProperty(unittest.TestCase):
        """Unit test for method __get__ of class cached_property."""

        def setUp(self):
            self.obj = MyClass()
            self.expected = 6

        def test_cached_property___get__(self):
            self.assertEqual(self.obj.y, self.expected)

    suite = unittest.TestSuite()

# Generated at 2022-06-23 18:02:34.931860
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 18:02:38.952893
# Unit test for constructor of class cached_property
def test_cached_property():

    from flutils.decorators import cached_property

    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:02:43.514216
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test the cached_property decorator.

    """
    # Code
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Test 1
    obj = MyClass()
    assert obj.y == 6

    # Test 2
    obj = MyClass()
    assert obj.y == 6
    assert 'y' in obj.__dict__
    assert obj.__dict__['y'] == 6

# Generated at 2022-06-23 18:02:44.679866
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property.__doc__

# Generated at 2022-06-23 18:02:51.050100
# Unit test for constructor of class cached_property
def test_cached_property():  # pragma: no cover
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    print(obj.y)
    print(obj.y)
    print(obj.y)


if __name__ == "__main__":  # pragma: no cover
    try:
        import sys

        print("Python {}.{}".format(sys.version_info.major, sys.version_info.minor))
        print("flutils {}".format(flutils.__version__))
        print("")

        test_cached_property()
    except ImportError:
        print("Flutils not installed. Try: pip install flutils")

# Generated at 2022-06-23 18:03:02.258297
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """ Unit test for method __get__ of class cached_property.

        Tests the cached_property class by creating a simple class with a
        cached_property that is a coroutine.  A test method is executed to
        verify that the method will only be executed once.
    """

    class MyClass:
        """ A simple class to test the cached_property decorator with. """

        def __init__(self):
            self._calls_to_x = 0

        @cached_property
        async def x(self):
            self._calls_to_x += 1
            await asyncio.sleep(0.01)
            return self._calls_to_x

    def _test_cached_property(obj):

        assert not hasattr(obj, '_calls_to_x')

# Generated at 2022-06-23 18:03:08.267413
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import TestCase, mock

    class Test(TestCase):
        @cached_property
        def foo(self):
            return mock.Mock()

    with mock.patch.object(Test, 'foo', new_callable=mock.PropertyMock) as mock_foo:
        o = Test()
        o.foo
        mock_foo.assert_called_once_with()
        o.foo
        mock_foo.assert_called_once_with()



# Generated at 2022-06-23 18:03:14.835878
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method ``__get__`` of class :obj:`cached_property`."""
    import pytest
    # Mark as no coverage
    assert pytest.config.getoption('cov', None) is None
    # No coverage reporting
    assert pytest.config.getoption('no-cov-on-fail', None) is None

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 18:03:16.172435
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # TODO: create unit test for method __get__ of class cached_property
    pass

# Generated at 2022-06-23 18:03:21.338426
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:03:29.233671
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # noinspection PyPep8Naming
    class test():

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return asyncio.ensure_future(self.x + 2)

    instance = test()
    assert 6 == instance.y
    assert 6 == instance.y
    assert 6 == instance.y
    # noinspection PyProtectedMember
    assert instance.__dict__ == {'x': 5, 'y': 6}
    try:
        assert 6 == instance.z
        pytest.fail('should not reach this line')
    except AssertionError:
        pass

# Generated at 2022-06-23 18:03:35.697972
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__['y'] == 6
    del obj.y
    assert obj.__dict__.get('y', None) is None
    assert obj.y == 6

# Generated at 2022-06-23 18:03:36.241693
# Unit test for constructor of class cached_property
def test_cached_property():
    assert False

# Generated at 2022-06-23 18:03:43.303818
# Unit test for method __get__ of class cached_property

# Generated at 2022-06-23 18:03:51.440639
# Unit test for constructor of class cached_property
def test_cached_property():
    class Obj:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Obj()

# Generated at 2022-06-23 18:04:01.604754
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    ################################################################################
    # Test cached_property.__get__
    ################################################################################

    class CacheTest:
        def __init__(self):
            self.x = 5

        @cached_property
        def foo(self):
            return self.x + 1

    assert CacheTest.__dict__["foo"].__doc__ == CacheTest.foo.__doc__
    assert CacheTest.__dict__["foo"].func == CacheTest.foo.func
    assert CacheTest.__dict__["foo"].__get__ == CacheTest.foo.__get__

    obj = CacheTest()

    assert isinstance(obj.__dict__["foo"], int)
    assert obj.__dict__["foo"] == obj.foo



# Generated at 2022-06-23 18:04:03.620032
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # noinspection PyPep8Naming
    class Example:
        def __init__(self, *args, **kwargs):
            sel

# Generated at 2022-06-23 18:04:14.359387
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest
    from unittest import mock

    print('Testing flutils.decorators.cached_property.cached_property.__get__()')

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    with pytest.raises(AttributeError):
        print(obj.z)

    obj.__dict__ = {}

    with pytest.raises(AttributeError):
        print(obj.z)

    obj.__dict__ = {'q': 100}

    with pytest.raises(AttributeError):
        print(obj.z)

    obj.__dict__ = {'x': 100}

    assert obj.y == 101


# Generated at 2022-06-23 18:04:20.942074
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test method __get__ of class cached_property"""
    class Foo:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Foo()
    assert obj.y == 6
    obj.x = 8
    assert obj.y == 6
    del obj.y
    assert obj.y == 9
    obj.y = 10
    assert obj.y == 10


# Generated at 2022-06-23 18:04:26.882221
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import Mock

    class MyClass:
        def __init__(self):
            self._prop = 0

        @cached_property
        def prop(self):
            self._prop += 1
            return self._prop

    m = MyClass()

    assert isinstance(m.prop, int)
    assert m._prop == 1
    assert m.prop == 1



# Generated at 2022-06-23 18:04:27.902743
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property
    
    assert hasattr(cached_property, "__doc__")

# Generated at 2022-06-23 18:04:30.884326
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Klass(object):
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    klass = Klass(5)
    assert klass.y == 6
    assert isinstance(klass.y, int)


# Generated at 2022-06-23 18:04:36.683719
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__['y'] == 6



# Generated at 2022-06-23 18:04:46.317672
# Unit test for constructor of class cached_property
def test_cached_property():
    def do_nothing(self):
        return None

    # Instantiate class
    cp = cached_property(do_nothing)

    # Get docstring
    assert cp.__doc__ == do_nothing.__doc__

    # Access class decorator
    cp.func = do_nothing

    # Create a property
    class Dummy:
        y = cached_property(do_nothing)

    # Create an instance with a cached property
    obj = Dummy()
    assert 'y' not in obj.__dict__
    assert obj.y is None
    assert 'y' in obj.__dict__
    assert obj.__dict__['y'] is None

# Generated at 2022-06-23 18:04:48.700604
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Test when obj is None
    cp = cached_property(lambda: 0)
    assert cp.__get__(None, None) is cp



# Generated at 2022-06-23 18:04:52.340087
# Unit test for constructor of class cached_property
def test_cached_property():
    my_obj = MyClass()
    my_obj.y
    assert my_obj.y == 6



# Generated at 2022-06-23 18:04:59.372373
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Test:
        x = 5

        @cached_property
        def y(self):
            return self.x + 1

    o = Test()
    o.y
    o.__dict__['y'] = 9
    assert o.y == 9
    del o.__dict__['y']
    assert o.y == 6



# Generated at 2022-06-23 18:05:03.867133
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    value = obj.__dict__["y"] = obj.y
    assert value is 6



# Generated at 2022-06-23 18:05:05.675049
# Unit test for constructor of class cached_property
def test_cached_property():

    class Example:

        @cached_property
        def bar(self):
            return 1234

    assert Example().bar == 1234



# Generated at 2022-06-23 18:05:09.769620
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class TestClass:

        def __init__(self):
            self.x = 1

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x + 2

        @cached_property
        def w(self):
            return self.x + 3

    test_obj = TestClass()

    assert test_obj.y == 2
    assert test_obj.z == 3
    assert test_obj.w == 4

    # Test that cached_property returned by class TestClass
    assert isinstance(TestClass.y, cached_property)



# Generated at 2022-06-23 18:05:15.199879
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # noinspection PyPep8Naming,PyMissingOrEmptyDocstring,PyUnusedLocal
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 18:05:20.902975
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


# Generated at 2022-06-23 18:05:26.192259
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Unit test for constructor of class cached_property

    :return: Nothing
    """

    class MyClass(object):

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    obj.x = 8
    assert obj.y == 9



# Generated at 2022-06-23 18:05:31.489151
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test if method __get__ of class cached_property works correctly."""

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:05:42.277913
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import unittest
    import contextlib
    try:
        from io import StringIO
    except ImportError:
        from io import StringIO

    import sys
    import asyncio

    class UnitTest(unittest.TestCase):
        # Python 2.7 compatibility
        __str__ = unittest.TestCase.__str__

        # noinspection PyPep8Naming
        @contextlib.contextmanager
        def stdoutIO(self, stdout=None):
            old = sys.stdout
            if stdout is None:
                stdout = StringIO()
            sys.stdout = stdout
            yield stdout
            sys.stdout = old

        def test_no_obj(self):
            class MyClass:
                @cached_property
                def y(self):
                    return self.x + 1

# Generated at 2022-06-23 18:05:48.591396
# Unit test for constructor of class cached_property
def test_cached_property():
    class Foo(object):
        def __init__(self):
            self.counter = 0

        @cached_property
        def xtime(self):
            self.counter += 1
            return "xtime"

    foo = Foo()
    assert foo.xtime == "xtime"
    assert foo.xtime == "xtime"
    assert foo.xtime == "xtime"
    assert foo.counter == 1
    del foo.xtime
    assert foo.xtime == "xtime"
    assert foo.xtime == "xtime"
    assert foo.xtime == "xtime"
    assert foo.counter == 2