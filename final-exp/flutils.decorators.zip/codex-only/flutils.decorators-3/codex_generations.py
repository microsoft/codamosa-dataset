

# Generated at 2022-06-23 17:55:53.279291
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    obj.x = 100
    assert obj.y == 6
    del obj.y
    assert obj.y == 101



# Generated at 2022-06-23 17:55:56.213446
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property"""

    from sys import version_info

    assert version_info[0] == 3
    assert version_info[1] >= 6

# Generated at 2022-06-23 17:56:07.662398
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test the method __get__ of class cached_property.

    *New in version 0.2.0*

    """
    import pytest
    # noinspection PyUnresolvedReferences
    import flutils.decorators

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    obj.x = 10
    assert obj.y == 11
    assert obj.__dict__['y'] == 11
    obj.__dict__['y'] = 15
    assert obj.y == 15
    del obj.y
    assert obj.__dict__.get('y') is None
    assert obj.y == 16

# Generated at 2022-06-23 17:56:15.451765
# Unit test for constructor of class cached_property
def test_cached_property():
    # Test with Python 3.6
    import sys
    this_ver = sys.version_info.major
    if this_ver == 3:
        that_ver = sys.version_info.minor
        if that_ver == 6:
            from flutils.decorators import cached_property
            class TestClass:
                """
                Test property decorator.
                """
                def __init__(self):
                    self._x = 0
                    self._y = 1

                @cached_property
                def x(self):
                    return self._x

                @cached_property
                def y(self):
                    return self._y
            # Setup data
            x = TestClass()
            # getter
            assert x.x == 0
            # setter
            x.x = 1
            # getter

# Generated at 2022-06-23 17:56:19.982830
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test the constructor for the cached_property class."""

    @cached_property
    def some_method(obj: object) -> object:
        """This is some method."""
        return obj

    assert some_method.__doc__ == "This is some method."
    assert some_method.func(object).__class__ == object
    assert some_method.__class__ == cached_property
    return



# Generated at 2022-06-23 17:56:31.775217
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Tests for :func:`cached_property.__get__`

    """
    import asyncio

    @cached_property
    def x(self):
        self.x = 1
        return self.x

    @cached_property
    async def y(self):
        self.y = 2
        return self.y

    class MyClass:
        def __init__(self):
            self.x = None
            self.y = None

        def __get__(self, obj, objtype):
            if obj is None:
                return self

        @property
        def property(self):
            self.property = 3
            return self.property

        @cached_property
        def cached_property(self):
            self.cached_property = 4
            return self.cached_property


# Generated at 2022-06-23 17:56:38.195603
# Unit test for constructor of class cached_property
def test_cached_property():
    # pylint: disable=too-few-public-methods
    # pylint: disable=too-many-instance-attributes
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 17:56:40.940226
# Unit test for constructor of class cached_property
def test_cached_property():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    MyClass()

# Generated at 2022-06-23 17:56:45.838536
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""

    class Object:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Object()
    assert callable(obj.y), 'Expected obj.y to be callable'


# Generated at 2022-06-23 17:56:51.530650
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1
    obj = MyClass()
    assert obj.x == 5
    result = obj.y
    assert result == 6
    # Reset the cached property by deleting it
    del obj.y
    assert obj.x == 5
    result = obj.y
    assert result == 6



# Generated at 2022-06-23 17:56:55.509713
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 17:57:00.569966
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 17:57:03.501262
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    def my_return_value(obj):
        return obj.x + 1

    class MyClass:

        def __init__(self):
            self.x = 5

    myobj = MyClass()
    myobj.my_property = cached_property(my_return_value)
    assert myobj.my_property == 6
    assert myobj.__dict__['my_property'] == 6

# Generated at 2022-06-23 17:57:06.009543
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass # test disabled


if __name__ == '__main__':
    test_cached_property___get__()

# Generated at 2022-06-23 17:57:17.519662
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    def test_fnc(self):
        return 5

    test = cached_property(test_fnc)

    # Using cached_property as a decorator
    class TestClass:
        @test
        def test_mtd(self):
            return 5

        @test_fnc
        def test_mtd(self):
            return 5

    obj = TestClass()

    # all values are cached
    assert obj.test_mtd == obj.test_mtd == 5

    # The original, un-cached method returns 5
    assert TestClass.test_mtd(obj) == 5

    obj.test_mtd = 6
    assert obj.test_mtd == 6

    obj.__dict__.pop('test_mtd')
    assert obj.test_mtd == 5

    # Using cached_property as a function

# Generated at 2022-06-23 17:57:19.337240
# Unit test for constructor of class cached_property
def test_cached_property():
    from doctest import testmod
    testmod()

# Generated at 2022-06-23 17:57:23.252475
# Unit test for constructor of class cached_property
def test_cached_property():
    class Test:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Test()
    assert obj.y == 6

# Generated at 2022-06-23 17:57:28.155597
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property
    from flutils.tests.helpers import Helper

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 17:57:37.262347
# Unit test for constructor of class cached_property
def test_cached_property():
    class Foo(object):
        def __init__(self, value):
            self._value = value

        @cached_property
        def value(self):
            return self._value

    foo = Foo(1)
    assert foo.value == 1
    foo.value = 2
    assert foo.value == 1  # FAILS
    assert foo._value == 2  # PASSES
    # deleting a cached_property restores property behavior
    del foo.value
    foo.value = 3  # fails because value is still cached
    assert foo.value == 3  # FAILS
    assert foo._value == 3  # PASSES
    foo = Foo(1)
    assert foo.value == 1  # PASSES
    assert foo._value == 1  # PASSES
    foo.value = 2
    assert foo.value == 2  # PASSES


# Generated at 2022-06-23 17:57:45.772614
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property
    """

    from unittest import TestCase, mock

    from flutils.decorators import cached_property

    class MyClass:
        @cached_property
        def my_property(self, value: int) -> int:
            return value

    class TestCachedPropertyClass(TestCase):

        def setUp(self) -> None:
            self.obj = MyClass()
            self.obj.__dict__['my_property'] = 101


# Generated at 2022-06-23 17:57:56.586447
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""
    class CachedPropertyTest:

        def __init__(self, prop):
            self._cached_property_test_prop = prop

        @cached_property
        def cached_property_test_prop(self):
            return self._cached_property_test_prop

    obj = CachedPropertyTest(5)

    # No value cached
    assert obj.__dict__ == {'_cached_property_test_prop': 5}

    # 1st time fetching cached property
    assert obj.cached_property_test_prop == 5
    assert obj.__dict__ == {'_cached_property_test_prop': 5,
                            'cached_property_test_prop': 5}

    # 2nd time fetching cached property - this time it's

# Generated at 2022-06-23 17:58:02.934113
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest.mock import Mock
    from unittest import TestCase

    class MyTestClass(TestCase):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyTestClass()
    obj.assertEqual(obj.y, 6)

# Generated at 2022-06-23 17:58:09.738822
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestClass:
        def __init__(self):
            self.x = 1

        @cached_property
        def p(self):
            return self.x + 1

    o = TestClass()
    assert o.p == 2
    assert o.p == o.p

    o.x = 5
    assert o.p == 6
    assert o.p == o.p

    del o.p
    assert o.p == 6
    assert o.p == o.p

    assert isinstance(o.p, int)



# Generated at 2022-06-23 17:58:19.594869
# Unit test for constructor of class cached_property
def test_cached_property():
    from functools import partial
    from flutils.decorators import cached_property

    @cached_property
    def a(obj):
        return {"a"}

    class Test:
        def __init__(self, val):
            self.val = val

        @cached_property
        def b(self):
            return self.val

    t = Test({"b"})
    f = partial(Test, {"b"})

    r = hasattr(a, "__get__")
    assert r

    r = t.b
    assert r == {"b"}

    r = f().b
    assert r == {"b"}

# Generated at 2022-06-23 17:58:20.982502
# Unit test for constructor of class cached_property
def test_cached_property():
    assert isinstance(cached_property, type)


# Generated at 2022-06-23 17:58:31.730979
# Unit test for constructor of class cached_property
def test_cached_property():
    from pprint import pprint as pp

    class SomeTestClass:
        @cached_property
        def y(self):
            return self.x + 1

        def __init__(self, x=0):
            self.x = x

    class SomeOtherTestClass:
        @cached_property
        def y(self):
            return self.x + 1

        def __init__(self, x=0):
            self.x = x

        def __repr__(self):
            return f"{type(self).__name__}({self.x})"

    class YetAnotherTestClass:
        @cached_property
        async def y(self):
            return self.x + 1

        def __init__(self, x=0):
            self.x = x


# Generated at 2022-06-23 17:58:39.391051
# Unit test for constructor of class cached_property
def test_cached_property():
    # test simple cached_property
    class M:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    m = M(5)
    # assert y is not a cached_property (yet)
    assert isinstance(m.y, cached_property)
    # but once we access it, it's stored as an int
    assert isinstance(m.__dict__['y'], int)
    # and if we access it again, we still get the same int
    assert m.__dict__['y'] == m.y

    # test cached_property with asyncio
    class A:
        def __init__(self, x):
            self.x = x


# Generated at 2022-06-23 17:58:41.744858
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Test:
        @cached_property
        def p(self):
            return 2
    assert Test().p

# Generated at 2022-06-23 17:58:47.004236
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property."""
    class C:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = C()
    assert obj.y == 6

# Generated at 2022-06-23 17:58:53.891353
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # noinspection PyPep8Naming
    class Test:

        def __init__(self):
            self.x = False

        # noinspection PyMissingOrEmptyDocstring
        @cached_property
        def test(self):
            self.x = True
            return 'test'

    test = Test()
    assert 'test' == test.test
    assert test.x
    assert 'test' == test.test
    assert test.x
    del test.test
    # noinspection PyUnresolvedReferences
    assert 'test' == test.test
    assert test.x



# Generated at 2022-06-23 17:59:03.143741
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class MyClass2:
        def __init__(self):
            self.x = 5

        @cached_property
        @asyncio.coroutine
        def y(self):
            yield from asyncio.sleep(1)
            return self.x + 1

    obj2 = MyClass2()
    assert isinstance(obj2.y, asyncio.Future)
    aioloop = asyncio.get_event_loop()
    result = aioloop.run_until_complete(obj2.y)
    assert result == 6
    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 17:59:07.682223
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestClass:
        @cached_property
        def y(self):
            return self.x + 1

        def __init__(self):
            self.x = 5

    obj = TestClass()
    assert obj.y == 6

# Generated at 2022-06-23 17:59:14.693179
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest.mock import patch
    from unittest.mock import Mock

    # noinspection PyPep8Naming
    @cached_property
    def test_func():
        return

    # noinspection PyPep8Naming
    class cached_property_test:

        def __init__(self):
            self.func = test_func
            self.test_func = test_func

        @test_func.getter
        def test_func(self):
            pass

    mock_patch = patch('flutils.decorators.cached_property.__get__')
    mock_get = mock_patch.start()
    mock_get.return_value = {}
    mock_get.reset_mock()


# Generated at 2022-06-23 17:59:18.320858
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property


    class MyClass(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 17:59:24.877659
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import asyncio
    import pytest

    class Foo:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    @pytest.mark.asyncio
    async def test_cached_property__wrap_in_coroutine():
        async def async_func(obj):
            return obj.x + 1

        class Foo:
            def __init__(self):
                self.x = 5

            @cached_property
            def y(self):
                return async_func(self)

        foo = Foo()
        result = await foo.y
        assert result == 6
        result = await foo.y
        assert result == 6

    class Bar:
        def __init__(self):
            self.x = 5



# Generated at 2022-06-23 17:59:34.361803
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # noinspection PyPep8Naming
    class cached_property_TEST:

        def __init__(self):
            self.cache1 = 0
            self.cache2 = 0
            self.cache3 = 0

        @cached_property
        def cache1(self):
            """
            :return:
            """
            return self.cache1

        @cached_property
        def cache2(self):
            """
            :return:
            """
            return self.cache2

        @cached_property
        def cache3(self):
            """
            :return:
            """
            return self.cache3

    obj = cached_property_TEST()
    assert isinstance(obj.cache1, int)
    assert isinstance(obj.cache2, int)

# Generated at 2022-06-23 17:59:34.995340
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass

# Generated at 2022-06-23 17:59:46.626398
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for ``cached_property``.
    """

    def test_obj_init(self):
        self.x = 5

    def test_obj_y(self):
        return self.x + 1

    @cached_property
    def test_obj_cached(self):
        return self.x + 1

    @cached_property
    @asyncio.coroutine
    def test_obj_cached_coroutine(_):
        yield from asyncio.sleep(0.1)
        return "result"

    # Test class
    class TestObj:
        __init__ = test_obj_init
        y = test_obj_y
        cached = test_obj_cached
        cached_coroutine = test_obj_cached_coroutine

    # Create object that traps an asyncio loop exception
   

# Generated at 2022-06-23 17:59:54.943947
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test class cached_property.

        >>> test_cached_property()

    """

    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x + 2

    obj = TestClass()
    assert obj.y == 6

    obj.x = 100

    # noinspection PyProtectedMember
    assert obj.__dict__[obj.y.__name__] == 6

    assert obj.y == 6
    assert obj.z == 7

# Generated at 2022-06-23 18:00:00.755348
# Unit test for constructor of class cached_property
def test_cached_property():
    from operator import eq

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert isinstance(obj.y, int)
    assert eq(obj.y, 6)

# Generated at 2022-06-23 18:00:04.686736
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class cachedTestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    c = cachedTestClass()

    assert c.y == 6

# Generated at 2022-06-23 18:00:09.988769
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


if __name__ == '__main__':
    test_cached_property()

# Generated at 2022-06-23 18:00:18.580972
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property.
    """
    class TestClass:

        def __init__(self):
            self._x = 5

        @cached_property
        def my_cached_property(self):
            return True

        @cached_property
        def my_cached_coro(self):
            return asyncio.sleep(1)

    obj = TestClass()
    assert obj.my_cached_property is True
    assert obj.my_cached_coro is not None
    assert asyncio.iscoroutinefunction(obj.my_cached_coro)


#
#  Copyright © 2015 Daniel Greenfeld
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#

# Generated at 2022-06-23 18:00:20.201903
# Unit test for constructor of class cached_property
def test_cached_property():
    from functools import cached_property as fcached_property
    assert cached_property == fcached_property

# Generated at 2022-06-23 18:00:26.922755
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Class:
        def __init__(self, x=0):
            self.x = x

        @cached_property
        def y(self):
            """A property to be cached."""
            return self.x + 1

    obj = Class()
    assert obj.y == 1
    del obj.y
    assert obj.y == 1

    # Error handling
    class ErrorHandler:
        def __init__(self, x='first'):
            self.x = x

        @cached_property
        def y(self):
            """A property to be cached."""
            return self.x[4]

    obj = ErrorHandler()
    with pytest.raises(IndexError):
        obj.y

# Generated at 2022-06-23 18:00:35.038273
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property
    """

    # Assign to a variable.
    #
    # The decorator does not change the method signature of the decorated
    # method, which should still be `self, obj, cls`.
    #
    # However, the decorator does change the method signature of the method
    # that it returns, which should still be `self`.
    @cached_property
    def get__(self, obj, cls):
        return self

    obj = get__(1, 2, 3)
    assert obj == 1


# Generated at 2022-06-23 18:00:35.729715
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    m = MyClass()
    assert m.y == 6

# Generated at 2022-06-23 18:00:47.593597
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import TestCase, main
    from unittest.mock import patch


    # noinspection PyMissingOrEmptyDocstring,PyPep8Naming
    class Test(TestCase):

        def __init__(self, *args, **kwargs):
            super(Test, self).__init__(*args, **kwargs)
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    with patch('functools.iscoroutinefunction',
               side_effect=[True, True]):
        obj = Test()
        self.assertEqual(obj.y, obj.y)

    # noinspection PyMissingOrEmptyDocstring
    @cached_property
    def get_and_incre(self):
        self.x += 1
        return

# Generated at 2022-06-23 18:00:49.526905
# Unit test for constructor of class cached_property
def test_cached_property():
    class Foo(object):
        @cached_property
        def foo(self):
            return 'bar'



# Generated at 2022-06-23 18:00:55.683135
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property
    import pytest

    class Person:

        # @cached_property
        def age(self):
            return 40

    p = Person()
    assert p.age == 40

    p.age = 35
    assert p.age == 35

    with pytest.raises(AttributeError):
        del p.age
    assert p.age == 35

    # Unit test for method __get__ of class cached_property
    def test_cached_property___get__():
        from flutils.decorators import cached_property
        import pytest

        class Person:

            @cached_property
            def age(self):
                return 40

        p = Person()
        assert p.age == 40

        p.age = 35
        assert p.age == 35


# Generated at 2022-06-23 18:00:59.749107
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestClass(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.y == 6
    assert obj.__dict__['y'] == 6



# Generated at 2022-06-23 18:01:08.259391
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    testclass = type('testclass', (object,), {})

    # Test with function that returns a value
    @cached_property
    def fcn1(self):
        return 123

    testclass.fcn1 = fcn1
    obj1 = testclass()
    assert obj1.fcn1 == 123 and isinstance(obj1.fcn1, int)
    obj1.fcn1 = 543
    assert obj1.fcn1 == 543 and isinstance(obj1.fcn1, int)

    # Test with function that returns a coroutine
    async def fcn2(self):
        return 123

    @cached_property
    def fcn2x(self):
        return fcn2(self)

    testclass.fcn2x = fcn2x
    obj2 = testclass()


# Generated at 2022-06-23 18:01:12.165886
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test the constructor of class :obj:`cached_property`

    """

    class MyClass:

        @cached_property
        def x(self):
            return 1

    obj = MyClass()
    assert obj.x == 1


# Generated at 2022-06-23 18:01:19.930370
# Unit test for constructor of class cached_property
def test_cached_property():
    # noinspection PyTypeChecker
    x = cached_property(5)
    assert x.func == 5
    assert x.__doc__ is None

    def f():
        pass
    f.__doc__ = 'test'

    # noinspection PyTypeChecker
    y = cached_property(f)
    assert y.func == f
    assert y.__doc__ == 'test'



# Generated at 2022-06-23 18:01:26.885855
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest
    from flutils.decorators import cached_property

    class Foo:

        def __init__(self):
            self.count = 0

        @cached_property
        def prop(self):
            self.count += 1
            return self.count

    foo = Foo()

    counts = [foo.prop for _ in range(10)]

    assert counts == [1 for _ in range(10)]



# Generated at 2022-06-23 18:01:35.360644
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property.

    Method __get__ returns either:

    * :obj:`None` if `obj` is **None** and **self** is an instance of
    :class:`~flutils.decorators.cached_property` (the usual case).

    * **self** if `obj` is **None** and **self** is not an instance of
    :class:`~flutils.decorators.cached_property`.

    * A property (either :obj:`functools.partial` or
    :class:`asyncio.Future`) if `obj` is not **None**.

    """
    from flutils.decorators import cached_property


# Generated at 2022-06-23 18:01:40.996604
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test the cached_property decorator."""

    def test_init_func(func):
        """Test the cached_property decorator's constructor."""
        assert isinstance(func, cached_property)
        assert func.func == square

    class TestClass:
        @cached_property
        def square(self):
            return 5*5

    test_obj = TestClass()
    test_init_func(test_obj.square)

# Generated at 2022-06-23 18:01:46.099637
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property.

    """  # flake8: noqa

    class C:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    c = C()
    assert c.y == 6


if __name__ == "__main__":
    print('Testing')
    # test_cached_property___get__()

# Generated at 2022-06-23 18:01:55.442981
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from tempfile import TemporaryDirectory
    from json import load
    from types import MethodType
    from flutils.flfileutils import ensure_dir_exists
    from flutils.fldecorators import cached_property

    CACHE_DIR = TemporaryDirectory()
    JSON_FILE = CACHE_DIR.name + '/test_cached_property___get__.json'

    class Test(object):

        def __init__(self):
            self.x = 5
            self.cache_dir = CACHE_DIR.name

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.go()

        def go(self):
            return self.x + 2


# Generated at 2022-06-23 18:02:03.425454
# Unit test for constructor of class cached_property
def test_cached_property():
    class ClassUnderTest:
        pass

    attrname = "attrname"
    doc = "doc"
    func = lambda obj: 7

    # Parameter: attrname
    # ------------------------
    cut = ClassUnderTest()
    assert not hasattr(cut, attrname)

    setattr(cut, attrname, cached_property(func))

    assert hasattr(cut, attrname)

    # Parameter: func
    # ------------------------
    cut = ClassUnderTest()
    assert not hasattr(cut, attrname)

    setattr(cut, attrname, cached_property(func))

    assert hasattr(cut, attrname)

    assert cut.attrname == 7
    assert cut.attrname == 7
    assert cut.attrname == 7

# Generated at 2022-06-23 18:02:11.127712
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import Mock

    @cached_property
    def test_func(x):
        y = x + 1
        return y

    obj_ = Mock()
    obj_.__dict__ = {}
    assert test_func.__get__(obj_, type(obj_)) == 2
    assert obj_.test_func == 2
    assert 'test_func' in obj_.__dict__



# Generated at 2022-06-23 18:02:16.368569
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 18:02:27.700438
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:
        @cached_property
        def x(self):
            print("x being calculated")
            return self.a + self.b + 1

        def __init__(self, a, b):
            self.a = a
            self.b = b

    x1 = MyClass(1, 2)
    assert x1.x == 4
    assert x1.x == 4
    assert x1.x == 4
    # noinspection PyUnresolvedReferences
    assert x1._MyClass__dict__['x'] == 4

    x2 = MyClass(2, 3)
    assert x2.x == 6
    assert x2.x == 6
    assert x2.x == 6
    # noinspection PyUnresolvedReferences
    assert x2._MyClass__dict__['x'] == 6



# Generated at 2022-06-23 18:02:32.646630
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # new instance of cached_property
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 18:02:38.168788
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """This method tests the functionality of `cached_property.__get__`

    """

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__ == {'x': 5, 'y': 6}

# Generated at 2022-06-23 18:02:43.602583
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test does property decorator override computed value, in case of
    coroutine function.
    """
    # noinspection PyPep8Naming
    class MyClass:
        def __init__(self):
            self.x = 0

        @cached_property
        async def y(self):
            self.x += 1
            return self.x

    test_obj = MyClass()
    loop = asyncio.get_event_loop()
    result = loop.run_until_complete(test_obj.y)
    assert result == 1

# Generated at 2022-06-23 18:02:45.532359
# Unit test for constructor of class cached_property
def test_cached_property():
    obj = MyClass()
    assert obj.y == 6


test_cached_property()

# Generated at 2022-06-23 18:02:53.257936
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyCacheProp:
        count = 0

        @cached_property
        def prop(self):
            self.__class__.count += 1
            return self.__class__.count

    obj = MyCacheProp()
    assert obj.prop == 1
    assert obj.prop == 1
    assert obj.prop == 1
    assert MyCacheProp.count == 1


if __name__ == '__main__':
    test_cached_property()

# Generated at 2022-06-23 18:02:56.558518
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property
    """
    class ExampleClass:
        @cached_property
        def x(self):
            return 1

    assert ExampleClass().x == 1



# Generated at 2022-06-23 18:02:58.120305
# Unit test for constructor of class cached_property
def test_cached_property():
    _obj = cached_property('hello')
    assert _obj.func == 'hello'


# Generated at 2022-06-23 18:03:06.732646
# Unit test for constructor of class cached_property
def test_cached_property():
    from ddt import data, ddt
    from functools import partial
    from hypothesis import given
    from hypothesis.strategies import booleans

    import unittest

    @ddt
    class TestCachedProperty(unittest.TestCase):
        """Unit tests for cached_property"""

        @data(True, False)
        @given(booleans())
        def test_cached_property_constructor(self, _, asyncify):
            @cached_property
            def _test_cached_property(self):
                return self

            if asyncify:
                _test_cached_property.func = _test_cached_property.func()

            test_cached_property = partial(
                _test_cached_property, self=self
            )
            test_cached_property.__doc

# Generated at 2022-06-23 18:03:12.165759
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test the constructor of class `cached_property`.

    :return: True if successful, False otherwise
    :rtype: bool

    """
    try:
        assert cached_property.__doc__
        assert cached_property.__init__.__doc__
        assert cached_property.__get__.__doc__
        assert cached_property._wrap_in_coroutine.__doc__
        return True
    except AssertionError:
        return False


# Generated at 2022-06-23 18:03:23.777193
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test that checks if the __get__ method of class cached_property
    works with and without coroutines.

    """
    from flutils.decorators import cached_property

    class Foo(object):
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return asyncio.ensure_future(self.do_work())

        @asyncio.coroutine
        def do_work(self):
            yield from asyncio.sleep(1)
            return self.x + 1

    # Test without coroutines
    f = Foo(5)
    assert f.y == 6
    assert f.y == 6
    del f.y


# Generated at 2022-06-23 18:03:29.016891
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # class _TestClass:
    #
    #     def __init__(self):
    #         self.x = 5
    #
    #     @cached_property
    #     def y(self):
    #         return self.x + 1
    #
    # obj = _TestClass()
    # print(obj.y)
    # del obj.y
    # print(obj.y)
    pass


if __name__ == "__main__":

    test_cached_property___get__()

# Generated at 2022-06-23 18:03:38.497570
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property
    """
    import random

    random.seed(0)

    class CachedProperty:
        """Test class for constructor of class cached_property
        """
        def __init__(self):
            self.x = 0

        @cached_property
        def y(self):
            self.x += 1
            return random.randint(0, 100)

    assert CachedProperty.y is not None
    cp = CachedProperty()
    assert cp.__dict__ == {'x': 0}
    assert cp.y == 51
    assert cp.__dict__ == {'x': 1, 'y': 51}
    assert cp.y == 51
    cp2 = CachedProperty()
    assert cp2.__dict__ == {'x': 0}
    assert cp2.y

# Generated at 2022-06-23 18:03:48.781688
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property
    """

    class MyClass(object):
        def __init__(self):
            self.x = 0

        @cached_property
        def y(self):
            self.x += 1
            return self.x

    my_obj = MyClass()
    assert my_obj.x == 0
    assert my_obj.y == 1
    assert my_obj.x == 1
    assert my_obj.y == 1
    assert my_obj.x == 1

    # Do it again just to be sure
    assert my_obj.y == 1
    assert my_obj.x == 1
    assert my_obj.y == 1
    assert my_obj.x == 1

# Generated at 2022-06-23 18:04:00.507374
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import time

    class TestClass:

        def __init__(self):
            self.x = 2

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x + 2

    obj = TestClass()
    assert obj.y == 3
    assert obj.z == 4

    obj.z = 7  # noinspection PyAttributeOutsideInit
    del obj.z

    assert obj.z == 4
    assert obj.y == 3

    del obj.y
    obj.x = 6
    assert obj.y == 7
    assert obj.y == 7

    def __get__(self, obj, cls):
        if obj is None:
            return self


# Generated at 2022-06-23 18:04:11.789801
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestClass:
        @cached_property
        def y(self):
            return self.x + 1

        def __init__(self):
            self.x = 5

    def test_with_attribute(obj, value):
        obj.y = value
        assert obj.y == value

    def test_with_method(obj):
        assert obj.__dict__['y'] == obj.y

    # test cached_property decorator
    obj = TestClass()
    test_with_method(obj)
    test_with_attribute(obj, 'value')

    # test del
    del obj.y
    del obj.__dict__['y']
    test_with_method(obj)
    test_with_attribute(obj, 10)

# Generated at 2022-06-23 18:04:17.936453
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest.mock import Mock
    from unittest import TestCase

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    TestCase.assertEqual(obj.y, 6)

# Generated at 2022-06-23 18:04:20.571327
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:04:24.762781
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:04:29.180241
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import logging
    from unittest.mock import patch

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    with patch.object(logging, 'warning') as mock_warn:
        obj = MyClass()
        # This should print a warning that the instance variable y is being
        # accessed before it has been defined.
        obj.y

    assert mock_warn.call_count == 1

    assert obj.y == 6

# Generated at 2022-06-23 18:04:34.210277
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test to verify constructor of cached_property class."""
    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def test_method(self):
            return self.x + 1

    t = TestClass()
    assert t.test_method == 6

# Generated at 2022-06-23 18:04:41.788743
# Unit test for constructor of class cached_property
def test_cached_property():

    # trivial example
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    # now for the real test
    @cached_property
    def foo(cls):
        return 5

    class MyClass:
        @cached_property
        def foo(self):
            return 5

    class MyClassNew(MyClass):
        pass

    obj = MyClass()
    assert obj.foo == 5
    assert MyClass.foo == 5
    obj.foo = 10
    assert obj.foo == 10
    del obj.foo
    assert obj.foo == 5

    obj = MyClassNew()
    assert obj.foo == 5

# Generated at 2022-06-23 18:04:46.776119
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Successful property retrieval
    class A:
        @cached_property
        def x(self):
            return 5

    a = A()
    x = a.x
    assert x == 5

    # Deletion (success)
    del a.x
    x = a.x
    assert x == 5


if __name__ == '__main__':
    # Unit test of method __get__ of class cached_property
    test_cached_property___get__()

# Generated at 2022-06-23 18:04:47.732976
# Unit test for constructor of class cached_property
def test_cached_property():
    return cached_property

# Generated at 2022-06-23 18:04:53.035623
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property

    Returns:
        None

    """
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


# Generated at 2022-06-23 18:05:05.118199
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # noinspection PyUnusedLocal
    class C:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x + 1

    # noinspection PyUnusedLocal
    class D:
        def __init__(self):
            self.x = 5

        @cached_property
        async def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x + 1

    assert C().y == 6
    assert "y" in C().__dict__

    assert C().y == C().__dict__["y"] == 6

    assert "y" in C().__dict__

# Generated at 2022-06-23 18:05:08.032810
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    obj.__dict__['y'] = 10
    assert obj.y == 10
    del obj.__dict__['y']
    assert obj.y == 6


# Generated at 2022-06-23 18:05:14.520921
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    logger = logging.getLogger(__name__)
    logger.setLevel(flutils.logging.INFO)


    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1


    obj = MyClass()
    obj.y
    del obj.y
    obj.y

# Generated at 2022-06-23 18:05:21.768321
# Unit test for constructor of class cached_property
def test_cached_property():
    @cached_property
    def x(self):
        return self.y + 1

    class MyClass:
        def __init__(self):
            self.y = 5

    obj = MyClass()
    assert obj.x == 6
    assert obj.y == 5

    obj.x = 7
    assert obj.x == 7
    assert obj.y == 5



# Generated at 2022-06-23 18:05:26.143074
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__ == {'x': 5, 'y': 6}
    del obj.y
    assert obj.__dict__ == {'x': 5}


# Generated at 2022-06-23 18:05:32.159779
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    assert cached_property.__get__ is not cached_property.__dict__['_cached_property__get__']
    _cached_property___get__ = cached_property.__get__

    assert isinstance(cached_property.__get__, cached_property)
    assert cached_property.__get__.func is _cached_property___get__



# Generated at 2022-06-23 18:05:39.176009
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


if __name__ == "__main__":
    print("Running unit tests for cached_property")
    test_cached_property___get__()
    print("Done...")

# EOF

# Generated at 2022-06-23 18:05:47.576589
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from pytest import mark
    from .test_utils import is_async_func, is_async_coro

    @mark.asyncio
    async def _test_cached_property___get__(obj, cls):
        obj.__dict__ = {'x': 5}
        obj.x = 5

        def _get__(obj, cls):
            return {'self': obj, 'cls': cls}

        decorator = cached_property(_get__)

        # cls is None
        # obj is not None
        result = decorator.__get__(obj, cls)
        assert is_async_coro(result)
        assert result.__self__ is obj
        assert cls is result.__func__
        assert obj.__dict__ == {'x': 5}

        #