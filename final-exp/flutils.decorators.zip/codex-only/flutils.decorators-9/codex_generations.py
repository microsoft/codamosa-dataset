

# Generated at 2022-06-23 17:55:49.647610
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    instance_attribute = 5

    @cached_property
    def instance_method():
        return instance_attribute

    assert isinstance(instance_method, cached_property)
    assert instance_method.func is instance_method

    class CachedPropertyClass:
        # noinspection PyPep8Naming
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        def z(self):
            return self.x + 1

    assert issubclass(CachedPropertyClass, object)

    instance = CachedPropertyClass()
    assert isinstance(instance, CachedPropertyClass)

    assert CachedPropertyClass.z(instance) == 6

# Generated at 2022-06-23 17:56:00.303610
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from functools import partial

    class Foo:
        def __init__(self):
            self.x = 5
            self.y = 8
            self.a = 3
            self.b = 4

        @cached_property
        def my_add(self):
            return self.x + self.y

        @cached_property
        def my_sub(self):
            return self.a - self.b

    foo = Foo()
    assert foo.my_add == 13
    assert foo.my_sub == -1
    foo.x = 15
    foo.y = -1
    assert foo.my_add == 14
    assert foo.my_sub == -1

    @cached_property
    def add(x, y):
        return x + y


# Generated at 2022-06-23 17:56:05.112134
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    my_obj = MyClass()
    assert asyncio.iscoroutinefunction(MyClass.y.__get__(my_obj))

    val = MyClass.y.__get__(my_obj)
    assert asyncio.iscoroutine(val)

    val = val()
    assert isinstance(val, asyncio.futures.Future)
    assert val.result() == 6


# Generated at 2022-06-23 17:56:07.207788
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Testing class cached_property
    """
    assert cached_property.__doc__ == \
        cached_property.__init__.__doc__

# Generated at 2022-06-23 17:56:08.896628
# Unit test for constructor of class cached_property
def test_cached_property():
    try:
        from flutils.decorators import cached_property
    except ImportError:
        pass



# Generated at 2022-06-23 17:56:12.721709
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Instantiate class
    class TestClass:
        # Define method
        @cached_property
        def my_method(self):
            return True

    # Create instance of class
    obj = TestClass()
    # Call method
    result = obj.my_method
    # Check to see if method works
    assert result is True


# Generated at 2022-06-23 17:56:16.857230
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    return obj.y

# Generated at 2022-06-23 17:56:17.826969
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property.__doc__.strip()

# Generated at 2022-06-23 17:56:18.687361
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass

if __name__ == "__main__":
    pass

# Generated at 2022-06-23 17:56:21.553497
# Unit test for constructor of class cached_property
def test_cached_property():
    class TestCachedProperty(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestCachedProperty()
    assert obj.y == 6

# Generated at 2022-06-23 17:56:26.146723
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property


    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1


    assert MyClass().y == 6

# Generated at 2022-06-23 17:56:33.541444
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass():

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.y + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.z == 7

    try:
        obj.y = 'something'
    except AttributeError as e:
        assert str(e).startswith("can't set attribute")


# Generated at 2022-06-23 17:56:38.668579
# Unit test for constructor of class cached_property
def test_cached_property():
    # pylint: disable=invalid-name
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 17:56:48.502880
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class x:
        __doc__ = 'I am x'

        def __init__(self, value):
            self._value = value

        @cached_property
        def value(self):
            return self._value

    class y:
        def __init__(self, value):
            self._value = value

        @cached_property
        def value(self):
            return self._value

        @cached_property
        def value_squared(self):
            return self._value * self._value

    a = x(5)
    assert a.value == 5
    assert a.value == a.__dict__['value']
    assert a.__dict__['value'] == 5

    b = x(10)
    assert b.value == 10
    assert b.value == b.__dict__['value']


# Generated at 2022-06-23 17:56:50.154574
# Unit test for constructor of class cached_property
def test_cached_property():
    p = cached_property(lambda x: x)
    assert p.__doc__ == "<lambda>"

# Generated at 2022-06-23 17:56:55.743467
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Basic test of cached_property.__get__.
    """

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__['y'] == 6
    assert obj.y == 6



# Generated at 2022-06-23 17:57:00.346065
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 17:57:12.627293
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import sys
    from flutils._testing import run_until_complete
    from unittest import mock

    if sys.version_info.minor > 7:
        return pytest.skip('Test is not applicable to Python 3.8 and up.')

    # Check that cached_property is called
    # and it is used as a decorator
    with mock.patch.object(cached_property, '__init__') as cp_init_mock:
        with mock.patch.object(cached_property, '__get__') as cp_get_mock:

            class MockClass:
                @cached_property
                def my_method(self):
                    pass

            cp_init_mock.assert_called_once_with(MockClass.my_method)
            cp_get_mock.assert_called_once()

# Generated at 2022-06-23 17:57:17.368711
# Unit test for constructor of class cached_property
def test_cached_property():
    # pylint: disable=missing-docstring, no-self-use

    class TestClass:

        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass(5)
    assert obj.y == 6



# Generated at 2022-06-23 17:57:21.932683
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Class:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Class()
    assert obj.y == 6



# Generated at 2022-06-23 17:57:25.440136
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class TestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.y == 6



# Generated at 2022-06-23 17:57:28.438413
# Unit test for constructor of class cached_property
def test_cached_property():
    # Verify that the constructor of the cached_property class returns the
    # value that is expected.
    expected = 'y'
    actual = cached_property(lambda x: expected).func.__name__
    assert actual == expected

# Generated at 2022-06-23 17:57:29.059224
# Unit test for constructor of class cached_property
def test_cached_property():
    pass

# Generated at 2022-06-23 17:57:34.150552
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():  # noqa: N802
    """Method __get__ of class cached_property.

    Method __get__ of class cached_property.

    """
    from flutils.decorators import cached_property

    class Example:

        @cached_property
        def y(self):
            return self.x

    example = Example()
    example.x = 1
    assert example.y == 1



# Generated at 2022-06-23 17:57:43.691589
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import Mock
    from unittest import TestCase

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class TestCachedPropertyGet(TestCase):

        def test__cached_property___get__(self):
            obj = MyClass()
            self.assertEqual(obj.y, 6)

        def test__cached_property___get___returns_coroutine(self):
            obj = MyClass()

            async def my_coroutine():
                return self.x * 2

            obj.y = my_coroutine
            self.assertTrue(asyncio.iscoroutinefunction(obj.y))

            obj.x = 2

# Generated at 2022-06-23 17:57:49.772676
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    print(obj.y)

# Generated at 2022-06-23 17:57:54.125239
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class Foo:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Foo()
    assert obj.y == 6



# Generated at 2022-06-23 17:57:59.975207
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit tests for method __get__ of class cached_property.

    For coverage.

    :return: No return

    """

    # noinspection PyPep8Naming
    class MyClass:
        """Bogus class for testing."""

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """Bogus method of bogus class for testing."""
            return self.x + 1

    # Test coverage of _wrap_in_coroutine
    @asyncio.coroutine
    def cached_property_test_func():
        """Bogus coroutine method of bogus class for testing."""
        yield

    # noinspection PyPep8Naming
    class MyClass2:
        """Bogus class for testing."""


# Generated at 2022-06-23 17:58:05.450752
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    result = obj.y
    assert result == 6
    result = obj.y
    assert result == 6


# Generated at 2022-06-23 17:58:14.064908
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    This unit test is more of an integration test.   I'm actually testing my
    implementation of the Python 3.8 :func:`functools.cached_property` decorator
    since the class containing this property instantiates this decorator in the
    constructor.  There was no easy way to test this method; I was getting
    coverage of the entire method but not the asynchronous part.
    """
    from flutils.decorators.cached_property import cached_property  # noqa

    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        async def y_coro(self):
            await asyncio.sleep(0.5)
            return self.x + 1

   

# Generated at 2022-06-23 17:58:20.002906
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    try:
        obj = MyClass()
        assert obj.y == 6
    except Exception as e:
        raise e

# Generated at 2022-06-23 17:58:24.442023
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 17:58:29.966021
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestClass:
        def __init__(self):
            self.x = None

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    obj.x = 5
    assert obj.y == 6
    assert obj.x == 5

    obj.x = 6
    assert obj.y == 6
    assert obj.x == 6



# Generated at 2022-06-23 17:58:32.958081
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Obj:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Obj()

    assert obj.y == 6



# Generated at 2022-06-23 17:58:38.324477
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""
    # Case when obj is None
    d = cached_property(lambda x: x)
    actual = d.__get__(None, object)
    assert d == actual

    # Regular case
    class Foo:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    f = Foo()
    actual = f.y
    assert 6 == actual



# Generated at 2022-06-23 17:58:47.390706
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test that calling cached_property.__get__ with:

    :param None:
    :param None:
    :return:
    """
    # Create an object to use as the context for the example class
    class ContextObject:
        def __init__(self):
            self.x = 5

    # Create an example class that uses the cached_property decorator
    class ExampleClass:
        @cached_property
        def y(self):
            return self.x + 1

    # Create the object
    obj = ExampleClass()
    # Set the context
    obj.__dict__['x'] = ContextObject()
    # Call the decorator
    result = ExampleClass.y.__get__(obj)

    assert result == 6

# Generated at 2022-06-23 17:58:52.534532
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test :class:`~flutils.decorators.cached_property.cached_property`."""

    # patch __get__
    def mock_get(obj: Any, cls):
        return cls

    with patch('flutils.decorators.cached_property.cached_property.__get__', mock_get):
        assert cached_property(lambda x: x).__get__ is mock_get



# Generated at 2022-06-23 17:58:55.909066
# Unit test for constructor of class cached_property
def test_cached_property():
    import pytest
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 17:59:02.516303
# Unit test for constructor of class cached_property
def test_cached_property():
    # Make sure it requires one argument
    with pytest.raises(TypeError):
        cached_property()

    # Make sure it requires one argument
    with pytest.raises(TypeError):
        cached_property(1, 2)

    # Make sure it accepts a one-argument callable
    cached_property(len)

    # Make sure it does not accept anything else
    with pytest.raises(TypeError):
        cached_property (1)
    with pytest.raises(TypeError):
        cached_property ("x")


# Generated at 2022-06-23 17:59:05.863793
# Unit test for constructor of class cached_property
def test_cached_property():
    class Class:

        @cached_property
        def x(self):
            return 5

    obj = Class()
    assert obj.x == 5
    assert 'x' in obj.__dict__


# Generated at 2022-06-23 17:59:09.851152
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert MyClass().y == 6


# Generated at 2022-06-23 17:59:15.882916
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.x = 6
    assert obj.y == 7
    assert obj.__dict__ == {
        'x': 6,
        'y': 7
    }



# Generated at 2022-06-23 17:59:22.671251
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    assert obj.y == 6
    obj.x = 6
    assert obj.y == 6
    del obj.y
    assert obj.y == 7
    assert obj.y == 7


if __name__ == '__main__':
    # Unit tests
    test_cached_property___get__()

# Generated at 2022-06-23 17:59:33.488994
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """This property is cached."""
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.y == 6

# Generated at 2022-06-23 17:59:38.781767
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for ``cached_property``.
    """

    class A:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    a = A()
    assert (a.y == 6)
    assert (a.__dict__['y'] == 6)


# Generated at 2022-06-23 17:59:44.431574
# Unit test for constructor of class cached_property
def test_cached_property():
    class Foo:
        def __init__(self):
            self.a = 5

        @cached_property
        def y(self):
            """This is the cached property y."""
            return self.a + 1

    foo = Foo()
    assert foo.y == 6
    assert foo.y == 6



# Generated at 2022-06-23 17:59:48.892648
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


# Generated at 2022-06-23 17:59:55.684413
# Unit test for constructor of class cached_property
def test_cached_property():

    class MyClass:
        """Stub class for testing cached_property decorator."""

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """Stub method for testing cached_property decorator."""
            return self.x + 1

    # Test class
    obj = MyClass()
    assert obj.y == 6

    # Test object
    obj.x = 10
    assert obj.y == 11

    # Test deletion
    del obj.y
    assert not hasattr(obj, "y")

# Generated at 2022-06-23 18:00:06.840812
# Unit test for constructor of class cached_property
def test_cached_property():
    from .decorator_tools import check_decorator

    # check_decorator(cached_property,
    #                 ['__init__', '__get__', '__doc__', 'func', ],
    #                 {'__init__': 0, '__get__': 2, '__doc__': None, 'func':
    #                     <function cached_property.__init__.<locals>.func at
    #                     0x10c2a4040>, })
    check_decorator(cached_property,
                    ['__init__', '__get__', '__doc__', 'func', ],
                    {'__init__': 0, '__get__': 2, '__doc__': None, 'func':
                        eval('cached_property.__init__.<locals>.func'), })


# Unit testing


# Generated at 2022-06-23 18:00:12.188219
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # noinspection PyTypeChecker
    class TestClass():

        def __init__(self):
            self.x = 15

        @cached_property
        def y(self):
            return self.x + 15

    assert TestClass().y == 30
    assert 'y' not in TestClass.__dict__
    assert TestClass.__dict__['y'].__get__(TestClass()) == 30
    return None

# Generated at 2022-06-23 18:00:18.268258
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for :class:`cached_property <flutils.decorators.cached_property>`"""
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """I am the y property"""
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


# Make the unit test executable
if __name__ == "__main__":
    test_cached_property()

# Generated at 2022-06-23 18:00:20.968000
# Unit test for constructor of class cached_property
def test_cached_property():
    # noinspection PyStatementEffect
    """Unit test for constructor of class :class:`cached_property
    <flutils.decorators.cached_property.cached_property>`

    """

    return

# Generated at 2022-06-23 18:00:27.736731
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x * 10

        @cached_property
        def z(self):
            return self.y * 10

    obj = MyClass(1)

    assert obj.y == 10
    assert obj.z == 100
    assert obj.y == 10

# Generated at 2022-06-23 18:00:34.277633
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test cached_property.__get__."""

    class TestClass:
        """Test class."""

        def __init__(self):
            """Test init."""
            self._x = 5

        @cached_property
        def y(self):
            """Test cached property."""
            return self._x + 1

    obj = TestClass()

    retval = obj.y
    assert retval == 6
    assert obj.__dict__['y'] == 6



# Generated at 2022-06-23 18:00:43.374799
# Unit test for constructor of class cached_property
def test_cached_property():
    import unittest

    class Test(unittest.TestCase):
        def setUp(self):
            class MyClass:
                def __init__(self):
                    self.x = 5

                @cached_property
                def y(self):
                    return self.x + 1

            self.test_class = MyClass()

        def tearDown(self):
            pass

        def test_cached_property(self):
            self.assertEqual(self.test_class.y, 6)

    unittest.main()

if __name__ == '__main__':
    test_cached_property()

# Generated at 2022-06-23 18:00:48.394393
# Unit test for constructor of class cached_property
def test_cached_property():
    class C:
        def __init__(self, value):
            self.value = value

        @cached_property
        def square(self):
            return self.value ** 2

    c = C(3)
    assert c.square == 9
    c.value = 4
    assert c.square == 9



# Generated at 2022-06-23 18:00:51.397360
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Tests if cached_property gets and sets obj to the defined name
    my_obj = MyClass()
    assert my_obj.y == 6
    assert "y" in my_obj.__dict__
    assert my_obj.__dict__["y"] == 6



# Generated at 2022-06-23 18:01:01.746251
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""
    def run_test_cached_property___get__():
        """Unit test for method __get__ of class cached_property"""
        print("Method cached_property.__get__ started.")
        from flutils.decorators import cached_property

        class MyClass:
            """Example class for testing cached_property.__get__"""

            def __init__(self):
                self.x = 5

            @cached_property
            def y(self):
                """Example cached property"""
                return self.x + 1

        obj = MyClass()
        assert obj.y == 6
        assert obj.y == 6
        print('Method cached_property.__get__ passed the unit test.')


# Generated at 2022-06-23 18:01:09.043104
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property
    from flutils.tests.helpers import get_adict

    class MyClass:

        def __init__(self):
            self.x = 'hello'

        @cached_property
        def y(self):
            return self.x + ' world'

    assert get_adict(MyClass()) == {
        'x': 'hello', 'y': 'hello world'
    }



# Generated at 2022-06-23 18:01:12.465823
# Unit test for constructor of class cached_property
def test_cached_property():
    class Foo:
        bar = 'BAR'

        @cached_property
        def baz(self):
            return self.bar

    foo = Foo()
    assert foo.baz == 'BAR'



# Generated at 2022-06-23 18:01:16.677704
# Unit test for constructor of class cached_property
def test_cached_property():
    class C:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = C()
    assert obj.y == 6

# Generated at 2022-06-23 18:01:24.422052
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """ Unit test for method __get__ of class cached_property """
    from unittest.mock import patch, PropertyMock
    from pathlib import Path
    from unittest.mock import Mock
    from flutils.decorators import cached_property


    class CachedPropertyClass:

        def __init__(self):
            self.file = Mock(spec=Path)
            self.file.parent.name = "foo"
            self.file.name.return_value = "bar"

        @cached_property
        def name(self):
            return self.file.parent.name

        @cached_property
        def path(self):
            return self.file.name


    class NewCachedPropertyClass:
        """ Test class: NewCachedPropertyClass """

        def __init__(self):
            self

# Generated at 2022-06-23 18:01:31.657090
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import AsyncMock

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            coro = AsyncMock(return_value=self.x + 1)
            return coro()

    obj = MyClass()

    with pytest.raises(TypeError) as excinfo:
        obj.y()

    assert "is not a coroutine function" in str(excinfo.value)

# Generated at 2022-06-23 18:01:36.420804
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property"""
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:01:40.907849
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 18:01:46.162324
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass(object):
        @cached_property
        def x(self):
            return 5

    obj = MyClass()
    assert obj.x == 5

# Generated at 2022-06-23 18:01:48.095875
# Unit test for constructor of class cached_property
def test_cached_property():
    c = cached_property("value")
    assert c.func == "value"
    assert c.__doc__ == "value"


# Generated at 2022-06-23 18:01:57.883052
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for cached_property class method __get__."""

    def _call_method_under_test(obj, cls):
        return obj.cached_property___get__(cls)

    class Cls:
        @cached_property
        def cached_property___get__(self):
            pass

    clsobj = Cls()

    # Test 1
    _calculated = clsobj.cached_property___get__(None)
    _expected = Cls.cached_property___get__

    assert _calculated == _expected

    # Test 3
    @asyncio.coroutine
    def _calculated():
        pass

    _expected = asyncio.coroutine(clsobj.cached_property___get__)(None)


# Generated at 2022-06-23 18:02:03.460938
# Unit test for constructor of class cached_property
def test_cached_property():
    import unittest.mock

    with unittest.mock.patch.object(cached_property, '__init__', return_value=None):
        x = cached_property('')
    with unittest.mock.patch.object(cached_property, '__init__', return_value=None):
        y = cached_property('')
    with unittest.mock.patch.object(cached_property, '__init__', return_value=None):
        z = cached_property('')

    assert x == y == z


# Generated at 2022-06-23 18:02:11.594729
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property"""
    from os import path
    from sys import modules
    from time import time
    from unittest import TestCase

    class MockClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    mock = MockClass()
    assert mock.y == 6


# noinspection PyPep8Naming

# Generated at 2022-06-23 18:02:22.783907
# Unit test for constructor of class cached_property
def test_cached_property():


    class Example:

        def __init__(self, x=0):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            self.x = 7
            return self.x + 1

        @cached_property
        async def d(self):
            return self.x + 1

        @cached_property
        async def e(self):
            await asyncio.sleep(1)
            return self.x + 1

    obj = Example()
    assert obj.y == 1
    assert obj.x == 0  # test for not mutating x

    del obj.x
    assert obj.y == 1  # the value is cached, despite obj.x being deleted

# Generated at 2022-06-23 18:02:24.780206
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property

    :rtype: None
    """
    pass

# Generated at 2022-06-23 18:02:29.655426
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Doctest for cached_property.
    """
    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 18:02:33.796781
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Foo:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    foo = Foo()
    assert foo.y == 6

# Generated at 2022-06-23 18:02:37.942921
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6
    assert obj.y == 6



# Generated at 2022-06-23 18:02:42.462050
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""
    from flutils.decorators import cached_property


    class MyClass:
        """Class to test cached_property"""

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 18:02:44.579886
# Unit test for constructor of class cached_property
def test_cached_property():
    class Test:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Test()
    assert obj.y == 6

# Generated at 2022-06-23 18:02:45.156495
# Unit test for constructor of class cached_property
def test_cached_property():
    pass

# Generated at 2022-06-23 18:02:55.257604
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils._testing.benchmarks import run_benchmarks
    from flutils._testing.benchmarks.tests import BaseTestClass

    class TestCachedProperty(BaseTestClass):

        def __init__(self, *args, **kwargs):
            super(TestCachedProperty, self).__init__(*args, **kwargs)
            self.class_inst = self._set_prop()

        @cached_property
        def property(self):
            return 'nothing yet'

        def _values(self):
            return [self.property]

        def _set_prop(self):
            return self._set_class_inst(property='something')

    run_benchmarks(TestCachedProperty, __file__)

# Generated at 2022-06-23 18:03:03.381769
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class flutils.decorators.cached_property

    """
    from test.common import capture_stdout

    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    print(MyClass.y.__doc__)
    with capture_stdout() as (output, _):
        print(obj.y.__doc__)



# Generated at 2022-06-23 18:03:04.662200
# Unit test for constructor of class cached_property
def test_cached_property():
    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 18:03:09.501540
# Unit test for constructor of class cached_property
def test_cached_property():
    import unittest

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class TestCachedProperty(unittest.TestCase):

        def test_cached_property(self):
            obj = MyClass()
            self.assertEqual(obj.y, 6)

    unittest.main()


if __name__ == '__main__':
    test_cached_property()

# Generated at 2022-06-23 18:03:15.513311
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    obj.x = 10
    assert obj.y == 6
    del obj.y # remove the cached property
    assert obj.y == 11

# Generated at 2022-06-23 18:03:20.596121
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # setup
    class A:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # test
    obj = A()
    obj.y
    assert obj.y == 6


# Generated at 2022-06-23 18:03:25.044176
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Cache miss
    @cached_property
    def method(self):
        return "my_property"

    # Check for cache miss
    assert (method.__get__(object, object) == "my_property")

    # Cache hit
    assert (method.__get__(object, object) == "my_property")

# Generated at 2022-06-23 18:03:33.694809
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # """Unit test for method __get__ of class cached_property.
    # """
    #     # given
    #     class MyClass:
    #         def __init__(self):
    #             self.x = 5
    #
    #         @cached_property
    #         def y(self):
    #             return self.x + 1
    #     obj = MyClass()
    #
    #     # then
    #     assert obj.y == 6
    pass


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-23 18:03:36.987376
# Unit test for constructor of class cached_property
def test_cached_property():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 18:03:40.466706
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # noinspection PyProtectedMember
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert 6 == obj.y  # noqa: WPS421



# Generated at 2022-06-23 18:03:42.534607
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property.
    """
    # noinspection PyPep8Naming
    class MyClass:
        @cached_property
        def a_property(self):
            """This is a property"""
            return "a property"
    obj = MyClass()
    assert obj.a_property == "a property"
    assert MyClass.a_property.__doc__ == "This is a property"

# Generated at 2022-06-23 18:03:46.457643
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 18:03:52.951758
# Unit test for constructor of class cached_property
def test_cached_property():
    class A:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1
    obj = A()
    assert obj.y == 6

    obj.y = 99  # should not be possible
    assert obj.y == 6
    assert obj.x == 5

# Generated at 2022-06-23 18:03:57.305825
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:04:02.309153
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:04:12.243751
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest import TestCase

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class TestCachedProperty(TestCase):

        def test_init_cached_property(self):
            obj = MyClass()
            obj.y
            self.assertEqual(obj.y, 6)

    # Run unittests
    # noinspection PyPackageRequirements
    from pytest import main

    main([__file__, "-v", "-s"])


if __name__ == "__main__":
    test_cached_property()  # pragma: no cover

# Generated at 2022-06-23 18:04:23.139109
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from os import getcwd
    from sys import version_info

    cached_property_ = cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property_
        def y(self):
            """The cached property."""
            return self.x + 1

        @cached_property_
        def z(self):
            """An async cached property."""
            loop = asyncio.get_event_loop()
            return loop.run_in_executor(None, getcwd)

    def test_without_async():
        obj = MyClass()
        assert obj.y == 6
        assert obj.y == 6

        # When the property is cached and the key exists in the objects
        # __dict__, it will not return the value of the key but the

# Generated at 2022-06-23 18:04:23.717727
# Unit test for constructor of class cached_property
def test_cached_property():
    pass

# Generated at 2022-06-23 18:04:28.480595
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""

    class Class:

        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    c = Class(5)
    assert c.y == 6
    c.x = 10
    assert c.y == 11

# Generated at 2022-06-23 18:04:34.099828
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 18:04:41.769337
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    def pass_through(self):
        return self.x

    func = pass_through
    cp = cached_property(func)
    assert cp.func == func
    assert cp.__doc__ == func.__doc__

    class A:
        def __init__(self, x):
            self.x = x

        @cp
        def get_x(self):
            return self.x

    a = A(5)
    assert a.get_x() == a.x == 5

    # get cache-value again
    assert a.get_x() == a.x == 5

    # noinspection PyProtectedMember
    assert a.__dict__["get_x"] == 5

    # invalidate cache
    del a.get_x

    # noinspection PyProtectedMember

# Generated at 2022-06-23 18:04:45.903432
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property"""

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__ == {'x': 5, 'y': 6}



# Generated at 2022-06-23 18:04:53.982525
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # No attribute set.
    obj = MyClass()
    assert not hasattr(obj, "y")

    # Attribute set.
    assert obj.y == 6
    assert obj.y == 6

    # Delete the attribute and check the value is re-computed.
    del obj.y
    assert obj.y == 6
    assert obj.y == 6

# Generated at 2022-06-23 18:05:02.434199
# Unit test for constructor of class cached_property
def test_cached_property():
    # noinspection PyUnusedLocal
    class C:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    c = C()
    assert c.y == 6
    del c.y
    assert c.y == 6
    del c.y
    assert c.y == 6
    c.y = 9
    assert c.y == 9
    c.x = 7
    assert c.y == 9
    c.y = 10
    assert c.y == 10

# Generated at 2022-06-23 18:05:04.121234
# Unit test for constructor of class cached_property
def test_cached_property():
    property = cached_property(lambda x: x + 1)
    assert property.func(2) == 3



# Generated at 2022-06-23 18:05:10.861552
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property.

    """
    from unittest import mock

    test_func = mock.MagicMock()
    test_obj = mock.MagicMock()
    test_cls = mock.MagicMock()

    cp = cached_property(test_func)

    assert cp.__doc__ is None
    assert cp.func is test_func
    assert test_func.call_count == 0
    assert cp.__get__(test_obj, test_cls) is test_func.return_value
    assert test_func.call_count == 1
    assert test_obj.__dict__[test_func.__name__] is test_func.return_value
    assert test_obj.__dict__[test_func.__name__] is test_func.return_value

# Generated at 2022-06-23 18:05:14.695880
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


# Generated at 2022-06-23 18:05:20.341882
# Unit test for constructor of class cached_property
def test_cached_property():
    class Foo:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Foo()
    assert obj.y == 6



# Generated at 2022-06-23 18:05:25.665722
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test the cached_property class constructor."""
    from flutils.decorators import cached_property

    # noinspection PyUnusedLocal
    def func(self):
        pass

    _ = cached_property(func)


if __name__ == "__main__":
    # pragma: no cover
    import flutils.decorators.cached_property

    # Run tests against this module
    test_cached_property()

# Generated at 2022-06-23 18:05:36.101088
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    _NAME = 'MyClass'
    _INSTANCE = object()

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__class__.y.__name__ == 'y'

    assert obj.__dict__['y'] == 6
    assert obj.__class__.y.__name__ == 'y'

    assert repr(obj.__class__.y).startswith('<cached_property')
    assert obj.__class__.y.__class__.__name__ == 'cached_property'

# Generated at 2022-06-23 18:05:46.523077
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Obj:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x + 1

    obj = Obj(x=6)
    assert obj.y == 7
    assert obj.z == 7
    obj.x = 9
    assert obj.y == 7
    assert obj.z == 7
    del obj.y
    assert obj.y == 10
    del obj.z
    assert obj.z == 10
    class Cls:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1
