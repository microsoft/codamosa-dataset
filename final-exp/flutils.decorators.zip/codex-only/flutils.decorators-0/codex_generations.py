

# Generated at 2022-06-23 17:55:48.666571
# Unit test for constructor of class cached_property
def test_cached_property():
    _ = cached_property

# Generated at 2022-06-23 17:55:54.316160
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass(5)
    assert obj.y == 6
    obj.x = 10
    assert obj.y == 6


# Generated at 2022-06-23 17:55:55.349079
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property.__doc__

# Generated at 2022-06-23 17:56:01.171456
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    loop = asyncio.get_event_loop()

    class SomeClass:
        @cached_property
        def x(self):
            return 5

        @cached_property
        def y(self):
            async def async_y():
                return 6

            return loop.run_until_complete(async_y())

    some_class = SomeClass()

    assert some_class.x == 5
    assert some_class.y == 6



# Generated at 2022-06-23 17:56:07.841557
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import Mock, call

    func = Mock()
    cached_prop = cached_property(func)

    # First call
    obj = Mock()
    value = cached_prop.__get__(obj, None)

    assert func.call_args == call(obj)
    assert obj.__dict__ == {func.__name__: value}

    # Second call
    cached_prop.__get__(obj, None)

    assert func.call_count == 1



# Generated at 2022-06-23 17:56:11.545378
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    obj.x = 10
    assert obj.y == 11


# Generated at 2022-06-23 17:56:16.856616
# Unit test for constructor of class cached_property
def test_cached_property():
    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def test(self):
            return self.x + 1

    obj = TestClass()
    assert obj.test == 6
    obj.x += 1
    assert obj.test == 7



# Generated at 2022-06-23 17:56:19.716174
# Unit test for constructor of class cached_property
def test_cached_property():
    c = cached_property(lambda x: x + 1)
    assert c.__doc__ is None
    assert c.func(5) == 6


# noinspection PyPep8Naming,PyPep8Naming

# Generated at 2022-06-23 17:56:24.820512
# Unit test for constructor of class cached_property
def test_cached_property():
    class TestClass(object):
        def __init__(self):
            self.value = 0

        @cached_property
        def counter(self):
            self.value += 1
            return self.value
    t = TestClass()
    for i in range(0, 3):
        assert t.counter == i + 1

# Generated at 2022-06-23 17:56:29.219947
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 17:56:33.897328
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6, 'Should be 6'
    assert obj.__dict__ == {'x': 5, 'y': 6}



# Generated at 2022-06-23 17:56:39.432515
# Unit test for constructor of class cached_property
def test_cached_property():
    def no_doc():
        pass

    def has_doc():
        """test docstring"""

    # Test no docstring
    cp = cached_property(no_doc)
    assert cp.__doc__ is None

    # Test with docstring
    cp = cached_property(has_doc)
    assert cp.__doc__ == "test docstring"



# Generated at 2022-06-23 17:56:42.602209
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 17:56:45.699932
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 17:56:46.544528
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass


# Generated at 2022-06-23 17:56:56.906865
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from time import time
    import random

    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def value(self):
            try:
                yield
            except GeneratorExit:
                raise ValueError("Raised a value error.")

    obj = TestClass()
    value = obj.value
    assert value == 5
    assert obj.x == 5

    obj.x = 10
    new_value = obj.value
    assert new_value == 10
    assert value == 5  # Hasn't changed

    obj.__dict__['value'] = 'abc'
    assert obj.value == 'abc'

    # Now test the coroutine version.
    class TestCoroClass:
        def __init__(self):
            self.x = 5


# Generated at 2022-06-23 17:57:08.760179
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import unittest
    import logging

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        async def z(self):
            return self.x + 1

    class Test_cached_property___get__(unittest.TestCase):
        def test_1(self):
            obj = MyClass()
            self.assertEqual(obj.y, 6)

        def test_2(self):
            obj = MyClass()
            self.assertTrue(asyncio.iscoroutinefunction(obj.z))

    unittest.main()

# Generated at 2022-06-23 17:57:13.034774
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 17:57:14.477968
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Test when called with obj is None:
        # Test when called with obj is not None:
            # Test where func is not coroutine function
                # Test where func is coroutine function
    pass

# Generated at 2022-06-23 17:57:20.331972
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            if self.x != 5:
                raise ValueError
            return self.x + 1

        @cached_property
        def z(self):
            if self.x != 5:
                raise ValueError
            return self.x + 2

    obj = MyClass()
    assert obj.y == 6
    assert obj.z == 7

    obj.x = 10
    assert obj.y == 6
    assert obj.z == 7



# Generated at 2022-06-23 17:57:21.627489
# Unit test for constructor of class cached_property
def test_cached_property():
    assert callable(cached_property)

# Generated at 2022-06-23 17:57:27.056493
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    # Tests that calling the method returns the expected result
    assert obj.y == 6
    # Tests that the method has been replaced with the result of calling it
    assert obj.__dict__["y"] == 6



# Generated at 2022-06-23 17:57:36.416256
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Test normal case
    class MyClass1:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass1()
    assert obj.y == 6
    # Test case where obj is None
    assert isinstance(cached_property.__get__(None, MyClass1),
                      cached_property)
    # Test case when functools.cached_property is installed
    if 'functools' in sys.modules:
        # Test normal case
        class MyClass2:
            def __init__(self):
                self.x = 5

            @functools.cached_property
            def y(self):
                return self.x + 1

        obj = MyClass2()

# Generated at 2022-06-23 17:57:41.895402
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert hasattr(obj, 'y')
    assert obj.y == 6
    obj.x = 10
    assert obj.y == 6
    del obj.y
    assert not hasattr(obj, 'y')
    assert obj.y == 11

# Generated at 2022-06-23 17:57:45.801282
# Unit test for constructor of class cached_property
def test_cached_property():
    class Foo:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Foo()

    assert(obj.y == 6)
    assert(obj.x + 1 == 6)
    assert(obj.y == 6)
    obj.x = 8
    assert(obj.y == 9)

# Generated at 2022-06-23 17:57:53.020228
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest
    from flutils.decorators import cached_property


    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    y = obj.y
    assert y == 6
    assert isinstance(y, int)



# Generated at 2022-06-23 17:58:04.245840
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property
    from flutils import get_logger
    from unittest.mock import MagicMock
    from types import FunctionType
    from typing import Any

    logger = get_logger(__name__)
    obj = MagicMock()

    def func1(self):
        logger.debug("Calculating something.")
        return 5

    # noinspection PyUnusedLocal
    def func2(self):
        logger.debug("Calculating something else.")
        return 7

    def func3(self):
        logger.debug("Yet another function.")
        return 9

    class TM:

        @cached_property
        def f1(self):
            return func1(self)

        @cached_property
        def f2(self):
            return func2(self)

# Generated at 2022-06-23 17:58:13.534990
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import sys
    from unittest import mock


    class A(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            "The y property."
            return self.x + 1


    def test_y_docstring():
        assert A.y.__doc__ == "The y property."

    with mock.patch.object(sys, 'version_info', (3, 8, 0)):

        def test_cached_property():
            # noinspection PyPep8Naming
            from functools import cached_property

            class A(object):
                def __init__(self):
                    self.x = 5

                @cached_property
                def y(self):
                    "The y property."
                    return self.x + 1

# Generated at 2022-06-23 17:58:20.198222
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y
    assert obj.y == 6

    # Test that second time it just uses the cached value no matter what
    obj.x = 10
    assert obj.y == 6



# Generated at 2022-06-23 17:58:31.078511
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass(object):
        _cached = False

        @cached_property
        def foo(self):
            return 'bar'

    obj = MyClass()

    # First, call foo
    obj.foo

    # Make sure _cached is False
    assert obj._cached is False

    # Asyncio coroutine test
    @asyncio.coroutine
    def coro(a):
        yield from asyncio.sleep(0.01)
        return a

    class MyClass1(object):
        _cached = False

        @cached_property
        def foo(self):
            return coro('bar')

    obj1 = MyClass1()

    # First, call foo
    loop = asyncio.get_event_loop()
    loop.run_until_complete(obj1.foo)

   

# Generated at 2022-06-23 17:58:33.661520
# Unit test for constructor of class cached_property
def test_cached_property():
    class A:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Test that code compiles
    A()

# Generated at 2022-06-23 17:58:40.354444
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class `cached_property`

    Test Cases:

        *   object is None; returns itself

        *   object is not None; value is coroutine function; decorates
            object with coroutine function; returns coroutine function

        *   object is not None; value is not coroutine function; decorates
            object with value; returns value

    *New in version 0.2.0*

    """
    @cached_property
    def _test_cached_property_non_coroutine_func(obj):
        return 'value'

    @cached_property
    def _test_cached_property_coroutine_func(obj):
        return 'value'

    class TestClass:

        def __init__(self):
            self.x = 5

    obj = TestClass()

    # object

# Generated at 2022-06-23 17:58:49.030112
# Unit test for constructor of class cached_property
def test_cached_property():
    # Test cached_property decorator.
    class TestClass:
        def __init__(self):
            # Test non-callable attribute
            self.z = 5

        @cached_property
        def x(self):
            # Test callable attribute
            return self.z + 1

    # Test caching of callable attribute
    testobj = TestClass()
    assert testobj.x == 6
    testobj.z = 2
    assert testobj.x == 6

    # Test deletion of callable attribute
    del testobj.x
    assert "x" not in testobj.__dict__
    assert testobj.x == 3

    # Test caching with callable attribute
    assert testobj.x == 3
    testobj.z = 2
    assert testobj.x == 3

    # Test caching of non-callable attribute
   

# Generated at 2022-06-23 17:58:51.930060
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 17:58:56.008552
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for class :class:`~flutils.decorators.cached_property`"""

    from flutils.decorators import cached_property
    from flutils.tests import no_warnings, suppress_warnings

    class cls(object):
        pass

    with no_warnings(DeprecationWarning):
        cls.property = cached_property(lambda self: 5)

    assert cls.property == 5

if __name__ == '__main__':
    test_cached_property()

# Generated at 2022-06-23 17:59:02.296477
# Unit test for constructor of class cached_property
def test_cached_property():
    import pytest

    def func(obj):
        return obj.x + 1

    @cached_property
    def func2(obj):
        return func(obj)

    class Obj(object):
        def __init__(self, x):
            self.x = x

    obj = Obj(5)
    assert (obj.func2 == 6)

    # This should fail with an expected AttributeError (item not found)
    with pytest.raises(AttributeError):
        obj.func



# Generated at 2022-06-23 17:59:07.257778
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 17:59:10.299125
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 17:59:14.527145
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class TestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.y == 6



# Generated at 2022-06-23 17:59:16.132401
# Unit test for constructor of class cached_property
def test_cached_property():
    # Tests are found in test_decorators.py
    pass



# Generated at 2022-06-23 17:59:18.623700
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property."""
    f = cached_property(lambda x: 0)

    assert f.__doc__ is None
    assert f.func(0) == 0

# Generated at 2022-06-23 17:59:29.745407
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():  # noqa: D103
    from unittest import TestCase, mock

    class Test:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class TestClass(TestCase):

        def test_cached_property(self):
            obj = Test()
            self.assertEqual(obj.y, 6)

    class TestClass2(TestCase):

        @mock.patch("flutils.decorators.cached_property.asyncio")
        def test_is_coroutine_function(self, mocked_asyncio):
            mocked_asyncio.iscoroutinefunction.return_value = True
            test = Test()
            self.assertEqual(test.y(), None)


# Generated at 2022-06-23 17:59:30.818077
# Unit test for constructor of class cached_property
def test_cached_property():
    return __init__(cached_property())

# Generated at 2022-06-23 17:59:37.446234
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test for method ``__get__`` of class ``cached_property``.
    """
    # Test for case when obj is None
    func = lambda x: x ** 2
    prop = cached_property(func)
    assert isinstance(prop.__get__(None, None), cached_property)

    # Test for case when obj is not None
    obj = 3
    prop = cached_property(func)
    assert prop.__get__(obj, None) == 9

# Generated at 2022-06-23 17:59:37.897011
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass

# Generated at 2022-06-23 17:59:49.961587
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test constructor of class cached_property.

    This function was originally part of the `cached_property
    <https://bit.ly/2R9U3Qa>`__ decorator by `Daniel Greenfeld;
    All Rights Reserved
    <https://bit.ly/2CwtJM1>`__.

    It was modified for use with the :obj:`cached_property` decorator from
    :obj:`flutils` by `Jay Laura; All Rights Reserved
    <https://bit.ly/2Yb4wYm>`__.
    """

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Test
    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 17:59:55.396873
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    global obj_y, __test_cached_property___get__

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj_y = obj.y
    assert obj_y == 6
    __test_cached_property___get__ = True


# Generated at 2022-06-23 18:00:06.767183
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class X:

        def __init__(self, x=0):
            self.x = x

        @cached_property
        def p(self):
            return self.x

    a = X(4)
    b = X(5)
    assert a.p == 4
    assert a.p == 4
    assert b.p == 5
    assert b.p == 5
    a.x = 6
    assert a.p == 4
    assert a.p == 4
    b.x = 7
    assert b.p == 7
    assert b.p == 7
try:
    import asyncio
except ImportError:
    pass

# Generated at 2022-06-23 18:00:10.700953
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        # noinspection PyAttributeOutsideInit
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:00:17.345109
# Unit test for constructor of class cached_property
def test_cached_property():
    class Foo(object):

        def __init__(self, n=1):
            self.n = n

        @cached_property
        def square(self):
            return self.n ** 2

    f = Foo()
    assert f.square == 1
    f.n = 9
    assert f.square == 9



# Generated at 2022-06-23 18:00:17.947355
# Unit test for constructor of class cached_property
def test_cached_property():
    pass

# Generated at 2022-06-23 18:00:22.967292
# Unit test for constructor of class cached_property
def test_cached_property():
    class CachedPropertyTestClass:
        def __init__(self, x: int):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    obj = CachedPropertyTestClass(5)

    # Test that cached_property is working as expected
    assert obj.y == 6
    # Test that the property has been cached
    assert not hasattr(obj, 'x')


# Generated at 2022-06-23 18:00:29.023937
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method :meth:`~cached_property.__get__` of
    class :class:`~cached_property`.

    The test for the :obj:`asyncio` functionality is located in
    :mod:`test_decorators`.

    """

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    obj.x = 10
    assert obj.y == 6
    obj = MyClass()
    assert hasattr(obj, '_y') is False
    assert obj.y == 6

# Generated at 2022-06-23 18:00:33.588434
# Unit test for constructor of class cached_property
def test_cached_property():

    # noinspection PyUnusedLocal
    class MyClass:

        def __init__(self):
            self._x = 5

        # noinspection PyAttributeOutsideInit
        @cached_property
        def y(self):
            return self._x + 1

    assert MyClass().y == 6

# Generated at 2022-06-23 18:00:37.681559
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:00:46.722021
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Unit test for constructor of class cached_property
    """

    from flutils.decorators import cached_property

    class TestClass(object):
        def __init__(self, arg):
            self.arg = arg

        @cached_property
        def some_property(self):
            "some property doc"
            return self.arg

    t = TestClass('junk')
    assert t.some_property == 'junk'
    assert t.some_property == 'junk'
    del t.some_property
    assert t.some_property == 'junk'



# Generated at 2022-06-23 18:00:50.628720
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    del obj.y
    assert obj.y == 6


# Generated at 2022-06-23 18:00:54.896118
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import asyncio
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    @cached_property
    def x(self):
        return None

    obj = MyClass()
    assert obj.x is None
    assert obj.y == 6



# Generated at 2022-06-23 18:01:02.974321
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # noinspection PyGlobalUndefined
    global func_was_called

    def func(self):
        # noinspection PyGlobalUndefined
        global func_was_called
        func_was_called += 1
        return "foo"

    class Foo:
        @cached_property
        def bar(self):
            return func(self)

        def __init__(self):
            pass

    result1 = Foo().bar
    assert result1 == "foo"

    # noinspection PyGlobalUndefined
    global func_was_called
    func_was_called = 0

    result2 = Foo().bar
    result3 = Foo().bar
    assert result2 == "foo"
    assert result3 == "foo"
    assert func_was_called == 1


##############################################################################


# Generated at 2022-06-23 18:01:07.927941
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
# _cached_property.py ends here

# Generated at 2022-06-23 18:01:11.904497
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass():
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


# Generated at 2022-06-23 18:01:23.286735
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import unittest
    from flutils.decorators import cached_property

    obj = type("obj", (), {})()

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class TestCachedProperty(unittest.TestCase):
        # Unit test for method __get__ of class cached_property
        def test_cached_property___get__(self):
            obj = MyClass()
            self.assertTrue(hasattr(obj.y, "__call__"))

        # Unit test for method __get__ of class cached_property
        def test_cached_property___get__2(self):
            obj = MyClass()

# Generated at 2022-06-23 18:01:29.755964
# Unit test for constructor of class cached_property
def test_cached_property():

    from flutils.decorators import cached_property
    class TestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert TestClass().y == 6

if __name__ == '__main__':
    # Run a test.
    test_cached_property()
    print("Finished test.")

# Generated at 2022-06-23 18:01:34.074393
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 18:01:38.427778
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class :obj:`cached_property`
    """
    @cached_property
    def test_func():
        """Test docstring"""
        pass

    assert test_func.__doc__ == "Test docstring"
    assert test_func.func.__name__ == "test_func"

# Generated at 2022-06-23 18:01:45.841335
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Example 1: noinspection PyPep8
    class Example1:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Example 2: noinspection PyPep8
    class Example2:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj1 = Example1()
    obj2 = Example1()
    assert obj1.y == obj2.y
    assert obj2.y == 6
    assert obj1.__dict__ == obj2.__dict__

# Generated at 2022-06-23 18:01:51.493775
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Example:
        This example shows the usage of the class :obj:`cached_property`

        Create a simple class::

            from flutils.decorators import cached_property

            class MyClass:

                def __init__(self):
                    self.x = 5

                @cached_property
                def y(self):
                    return self.x + 1

        Create an instance of the class::

            >>> obj = MyClass()
            >>> obj.y
            6

    """
    pass

# Generated at 2022-06-23 18:01:58.808076
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    with pytest.raises(AttributeError):
        obj.y.close()
    obj.y

    del obj.y
    obj.y
    with pytest.raises(AttributeError):
        obj.y.close()



# Generated at 2022-06-23 18:02:03.123876
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        """Test class"""

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """Test cached property"""
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__['y'] == 6
    assert obj.y == 6
    assert obj.__dict__['y'] == 6



# Generated at 2022-06-23 18:02:07.711339
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class A:
        @cached_property
        def x(self):
            return 27

    a = A()

    a.x
    assert 27 == a.x
    a.x = 12
    assert 12 == a.x



# Generated at 2022-06-23 18:02:16.423377
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class A:
        @cached_property
        def a(self):
            return 5

    a = A()
    b = A()

    assert a.a == 5
    assert b.a == 5
    assert a.a == 5
    assert b.a == 5
    assert not asyncio.iscoroutinefunction(a.a)
    assert a.a is b.a

    class B:
        @cached_property
        async def a(self):
            return 5

    a = B()
    b = B()

    assert asyncio.iscoroutine(a.a)
    assert asyncio.iscoroutine(b.a)
    assert asyncio.iscoroutinefunction(a.a)
    assert asyncio.iscoroutinefunction(b.a)

# Generated at 2022-06-23 18:02:21.404970
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.y == 6

    obj.x = 50
    assert obj.y == 51
    assert obj.y == 51


# Generated at 2022-06-23 18:02:29.609435
# Unit test for constructor of class cached_property
def test_cached_property():
    import functools as ft

    # test __init__
    @cached_property
    def func():
        pass

    assert isinstance(func, cached_property)
    assert func.__doc__ is None

    # test
    @ft.lru_cache()
    def func():
        """docstring"""
        pass

    @cached_property
    def func2():
        """docstring"""
        pass

    assert func.__doc__ == func2.__doc__ == 'docstring'
    assert isinstance(func, ft.lru_cache)
    assert isinstance(func2, cached_property)



# Generated at 2022-06-23 18:02:32.307622
# Unit test for constructor of class cached_property
def test_cached_property():
    assert ("cached_property" == cached_property.__name__), \
        "cached_property.__init__() failed"

# Generated at 2022-06-23 18:02:35.404271
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Unit test to cover :meth:`flutils.decorators.cached_property.__init__`

    """
    assert cached_property.__init__

# Generated at 2022-06-23 18:02:38.621569
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class Foo:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1


    obj = Foo()
    assert obj.y == 6



# Generated at 2022-06-23 18:02:40.106242
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Method to test the cached_property.__get__ method"""
    pass

# Generated at 2022-06-23 18:02:48.613725
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit tests for method cached_property.__get__."""

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Ensure it runs at least once
    obj = MyClass()
    y = obj.y
    assert y == 6

    # Ensure it doesn't run more than once
    y = obj.y
    assert y == 6

    # Ensure it's not a function call
    assert isinstance(obj.__dict__['y'], int)

    # Ensure it still runs if the attribute is deleted
    del obj.y
    assert obj.y == 6



# Generated at 2022-06-23 18:02:58.281058
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self, test_val=None):
            self._test_val = test_val
            self.reset = True
            self._test_func_called = False

        @cached_property
        def test_func(self):
            """

            :return:
            """
            self._test_func_called = True
            if self.reset:
                raise RuntimeError('Reset was not set to False')
            return self._test_val

    obj = MyClass('test')

    res = obj.test_func
    assert res == 'test'
    assert obj._test_func_called

    # Repeat. Since the test_func is cached and not computed again the
    # _test_func_called should still be False
    res = obj.test_func
    assert res == 'test'

# Generated at 2022-06-23 18:03:06.693701
# Unit test for constructor of class cached_property
def test_cached_property():
    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """A property."""
            return self.x + 1

    t = TestClass()

    assert isinstance(t.y, int)
    assert t.y == 6
    assert hasattr(TestClass, "y")
    assert hasattr(t, "y")
    assert isinstance(t.y, int)
    assert t.y == 6

    class SubTestClass(TestClass):
        pass

    s = SubTestClass()
    assert s.y == 6

    del s.y
    assert hasattr(s, "y")
    assert s.y == 6



# Generated at 2022-06-23 18:03:13.685466
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for the constructor of class cached_property.

    *New in version 0.2.0*

    Notes:
        * See `cached_property <https://bit.ly/2yCyiCj>`__ for additional
          information.

    """

    def _f(obj):
        return obj + 1

    c = cached_property(_f)
    assert c.__doc__ is _f.__doc__
    assert c.func is _f
    assert isinstance(c, cached_property)


cached_property.__test__ = False  # type: ignore

# Generated at 2022-06-23 18:03:16.863055
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    obj.y

# Generated at 2022-06-23 18:03:27.533079
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method "cached_property.__get__()"

    Test for:

        * :obj:`~flutils.decorators.cached_property`, and

        * :obj:`~flutils.decorators.cached_property` and
          :obj:`asyncio.iscoroutinefunction`.
    """

    class MyClass:
        """This is a class."""

        def __init__(self):
            """This is the constructor."""

        @cached_property
        def y(self):
            """This is a property."""
            return 5

        @cached_property
        def a(self):
            """This is an asynchronous property."""
            return asyncio.coroutine(lambda: 5)()

    obj = MyClass()

    # Test for:
    #


# Generated at 2022-06-23 18:03:31.702342
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:03:35.014130
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert MyClass().y == 6



# Generated at 2022-06-23 18:03:38.502524
# Unit test for constructor of class cached_property
def test_cached_property():
    class TestCachedProperty(object):
        pass

    obj = TestCachedProperty()
    obj.__dict__['func'] = 'func'
    obj.__dict__['__doc__'] = 'doc'

    assert obj.__doc__ == 'doc'
    assert obj.func == 'func'



# Generated at 2022-06-23 18:03:44.105085
# Unit test for constructor of class cached_property
def test_cached_property():
    # Get reference to constructor of class cached_property
    _cached_property = cached_property.__init__
    # Create instance of class cached_property and verify that __init__
    # is called
    cached_property_instance = cached_property(lambda x: x)
    assert cached_property_instance.func is not None

# Generated at 2022-06-23 18:03:47.876109
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest
    from .helpers import run_test_coroutine

    @asyncio.coroutine
    def test_coro(x):
        return x

    class TestClass:
        @cached_property
        def cp(self):
            return test_coro(10)

    obj = TestClass()

    # Test 1: obj, cls is None:
    assert isinstance(obj.cp, asyncio.Future)

    # Test 2: obj, cls is not None:
    future = obj.cp
    assert obj.cp == future

    # Test 1, 2: Coroutine result:
    assert run_test_coroutine(future) == 10

    with pytest.raises(RuntimeError):
        # Test 1, 2: Coroutine result, was retrieved:
        run_test_coroutine(future)

# Generated at 2022-06-23 18:04:00.086602
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for :obj:`flutils.decorators.cached_property`.

    Tests the following:

        - Initialization
        - Calling the object
        - Calling the object with a class object
        - Calling the object with a coroutine
    """

    # initialize
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert isinstance(MyClass.y, cached_property)
    assert MyClass.y.__doc__ is None
    assert MyClass.y.func is MyClass.y.__get__(None, MyClass)

    # calling the object
    obj = MyClass()
    assert obj.y == 6

    # calling the object with a class object
    assert MyClass.y

# Generated at 2022-06-23 18:04:07.363874
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    obj.x = 1
    assert obj.y == 6
    del obj.y
    assert obj.y == 2



# Generated at 2022-06-23 18:04:10.717540
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.flunits import flunits

    @flunits.cached_property
    def get_prop(self):
        return self.x + 1

    assert 'cached_property' == get_prop.__class__.__name__

# Generated at 2022-06-23 18:04:22.416993
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest

    # Scenario:
    #   empty cached_property called
    def test_empty_cached_property_called():

        class TestEmpty:
            def __init__(self):
                self.x = 1

            @cached_property
            def property(self):
                return self.x

        t = TestEmpty()
        assert t.property == 1
        assert t.__dict__['property'] == 1

    test_empty_cached_property_called()

    # Scenario:
    #   empty cached_property called on class
    def test_empty_cached_property_called_on_class():

        class TestEmptyClass:
            def __init__(self):
                self.x = 1

            @cached_property
            def property(self):
                return self.x

        assert TestEmpty

# Generated at 2022-06-23 18:04:33.067724
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Coverage test for the method ``__get__`` of class
    :class:`~flutils.decorators.cached_property`
    """
    import pytest

    def get_method(obj, cls):
        return obj, cls

    get_method = cached_property(get_method)

    class MyClass:
        pass

    obj = MyClass()

    obj_cls_result = get_method.__get__(obj, None)
    assert obj_cls_result == (obj, MyClass)
    obj_cls_result = get_method.__get__(None, MyClass)
    assert obj_cls_result == get_method

    class MyClassAsync:
        @staticmethod
        @asyncio.coroutine
        def get_method():
            pass

    obj = My

# Generated at 2022-06-23 18:04:36.806948
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:04:46.488801
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method `__get__` of class `cached_property`.
    """
    def test_func_one(cls_var: Any) -> int:
        """Define a test function.

        Args:
            cls_var (Any): The class variable.

        Returns:
            int: The class variable incremented by one.

        """
        return cls_var + 1

    class TestClass:
        """Define a test class.
        """
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return test_func_one(self.x)

    obj = TestClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:04:53.263922
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import patch

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    with patch.object(MyClass, 'y', new_callable=cached_property) as m:
        m.__get__(MyClass())

# Generated at 2022-06-23 18:05:00.693969
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def x(self):
            return self.x + 1

    obj = MyClass()
    obj.x
    assert obj.x == 6
    assert 'x' in obj.__dict__
    del obj.x
    assert 'x' not in obj.__dict__



# Generated at 2022-06-23 18:05:01.255506
# Unit test for constructor of class cached_property
def test_cached_property():
    pass

# Generated at 2022-06-23 18:05:02.455470
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property.
    """
    assert True

# Generated at 2022-06-23 18:05:06.061461
# Unit test for constructor of class cached_property
def test_cached_property():
    """ Unit test for constructor of class cached_property
    """

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:05:07.638275
# Unit test for constructor of class cached_property
def test_cached_property():
    y = cached_property(None)
    assert(y)

# Generated at 2022-06-23 18:05:11.688066
# Unit test for constructor of class cached_property
def test_cached_property():
    @cached_property
    def x():
        return x

    assert callable(x)
    assert x.__doc__ is None
    assert x.func is x
    assert x.__name__ == 'x'

# Generated at 2022-06-23 18:05:16.379381
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""

    import inspect
    import pytest

    from flutils.funcutils import get_func_name

    @cached_property
    def x():
        """Y."""
        return 3

    assert inspect.isclass(cached_property)
    assert hasattr(cached_property, '__get__')
    assert hasattr(cached_property, '__init__')
    assert x == 3
    assert x.__doc__ == "Y."
    assert get_func_name(x) == "x"

    # New in version 0.3.0
    class C:

        @cached_property
        def x(self):
            """Y."""
            return 3

    o = C()
    assert o.x == 3

# Generated at 2022-06-23 18:05:26.126534
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Tests for cached_property method __get__

    def test_cached_property___get__1():
        # Tests for method __get__ of class cached_property
        class MyClass:

            def __init__(self):
                self.x = 5

            @cached_property
            def y(self):
                """Docstring for y."""
                return self.x + 1

        obj = MyClass()
        obj.y

        assert obj.__dict__ == {'x': 5, 'y': 6}

        obj.y
        assert obj.__dict__ == {'x': 5, 'y': 6}

        del obj.y
        assert obj.__dict__ == {'x': 5}

        obj.y
        assert obj.__dict__ == {'x': 5, 'y': 6}


# Generated at 2022-06-23 18:05:35.867779
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    def check_get_property():
        assert four == obj.cached_property_func
        assert 'cached_property_func' not in obj.__dict__

    def check_get_property_after_delete():
        del obj.cached_property_func
        assert five == obj.cached_property_func
        assert 'cached_property_func' not in obj.__dict__

    class Test:

        four = 4

        @cached_property
        def cached_property_func(self):
            return self.four

    five = 5
    obj = Test()
    obj.four = five
    four = 4
    check_get_property()
    check_get_property_after_delete()



# Generated at 2022-06-23 18:05:45.051252
# Unit test for constructor of class cached_property
def test_cached_property():
    class Foo:

        @cached_property
        def foo(self):
            return 42

    # Ensure key is not in the attribute dictionary
    assert not hasattr(Foo, 'foo')

    f = Foo()

    # Put it there
    x = f.foo
    assert x == 42

    # Ensure the key is now in the attribute dictionary
    assert hasattr(Foo, 'foo')
    assert 'foo' in f.__dict__

    # Ensure it can be deleted
    del f.foo

    # Ensure the key is no longer in the attribute dictionary
    assert not hasattr(Foo, 'foo')
    assert 'foo' not in f.__dict__

    # Ensure that the property can be set
    f.foo = 'bar'
    assert f.__dict__['foo'] == 'bar'


# Unit test

# Generated at 2022-06-23 18:05:49.834763
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils import Empty, EmptyError

    class CP(object):

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1
    cp = CP()
    assert cp.y == 6
    cp.y = None
    assert cp.y == 6
    cp.x = 10
    assert cp.y == 11
