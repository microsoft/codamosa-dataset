

# Generated at 2022-06-23 17:55:57.606503
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    from flutils.decorators import cached_property

    import pytest

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    # test for class cached_property, property y
    y = obj.y

    assert y == 6
    assert isinstance(y, int)
    assert y is obj.__dict__['y']

    # test for class cached_property, property y
    y = obj.y

    assert y == 6
    assert isinstance(y, int)
    assert y is obj.__dict__['y']


# Generated at 2022-06-23 17:56:05.551089
# Unit test for constructor of class cached_property
def test_cached_property():
    class Foo1:
        def __init__(self):
            self.x = 5

        def bar(self):
            return self.x + 1

    class Foo2:
        def __init__(self):
            self.x = 5

        @cached_property
        def bar(self):
            return self.x + 1

    assert Foo1().bar() == Foo2().bar


if __name__ == "__main__":
    test_cached_property()

# Generated at 2022-06-23 17:56:07.362390
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test method __get__ of class cached_property"""

    # noinspection PyMissingOrEmptyDocstring
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


if __name__ == '__main__':
    pass

# Generated at 2022-06-23 17:56:15.257502
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method _get_ of class cached_property
    """
    from functools import partial
    from flutils.decorators import cached_property
    from flutils.commonutils import get_func_desc

    @cached_property
    def x(obj):
        return 5

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert x == cached_property.__get__(x, None), 'Expected:  5  Got:  {}'.format(get_func_desc(x))

# Generated at 2022-06-23 17:56:21.033679
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    $ python -m doctest -v flutils/decorators.py

    $ python -m doctest -v flutils/decorators.py -v
    Trying:
        test_cached_property()
    Expecting:
        <class '__main__.MyClass'>
    ok
    1 items had no tests:
        flutils.decorators
    1 items passed all tests:
       1 tests in flutils.decorators.test_cached_property
    1 tests in 2 items.
    1 passed and 0 failed.
    Test passed.
    """
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    res

# Generated at 2022-06-23 17:56:32.703418
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class MyAsyncClass:

        def __init__(self):
            self.x = 5

        @cached_property
        @asyncio.coroutine
        def y(self):
            yield
            return self.x + 1

    obj = MyClass()
    assert obj.y is obj.y
    assert obj.__dict__['y'] == 6
    assert obj.y == 6

    obj = MyAsyncClass()
    assert isinstance(obj.y, asyncio.Future)
    assert obj.y is obj.y
    assert obj.__dict__['y'] == obj.y

# Generated at 2022-06-23 17:56:35.113167
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Unit testing for the constructor of the cached_property class
    """
    assert cached_property.__init__.__doc__ is not None

# Generated at 2022-06-23 17:56:39.925263
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 17:56:48.674868
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test Cache Property class."""
    import math

    class TestClass:
        """Define a class to ensure the decorator works."""

        def __init__(self, x: int):
            """Initialize the class."""
            self.x = x

        @cached_property
        def y(self):
            """Determine Y."""
            return math.factorial(self.x)

    tests = [TestClass(0), TestClass(1), TestClass(2), TestClass(3)]

    assert tests[0].y == 1
    assert tests[1].y == 1
    assert tests[2].y == 2
    assert tests[3].y == 6



# Generated at 2022-06-23 17:56:59.150574
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from pytest import raises

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            raise RuntimeError('calculation failed')

    obj = MyClass()

    #  x is an attribute of MyClass, not a cached_property
    with raises(AttributeError, match='^x$'):
        obj.x.unwrap()

    #  y is a cached_property so it should return the result of the calculation
    assert obj.y == 6

    #  y is a cached_property so it should return the result of the calculation
    with raises(RuntimeError, match='^calculation failed$'):
        obj.z


# Generated at 2022-06-23 17:57:01.655348
# Unit test for constructor of class cached_property
def test_cached_property():
    """Run doctests for the class cached_property."""

    import doctest

    doctest.testmod(verbose=True)

# Generated at 2022-06-23 17:57:14.158116
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import TestCase

    class _TestCase(TestCase):
        def test_1(self):
            from flutils.decorators import cached_property

            class _ForTest:

                def __init__(self):
                    self.x = 5

                @cached_property
                def y(self):
                    return self.x + 1

            obj = _ForTest()
            obj.y

            self.assertTrue('y' in obj.__dict__)
            self.assertEqual(obj.__dict__['y'], 6)

        def test_2(self):
            from flutils.decorators import cached_property

            class _ForTest:

                def __init__(self):
                    self.x = 5


# Generated at 2022-06-23 17:57:21.705466
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class myClass:
        @cached_property
        def y(self):
            self.x = 5
            return self.x

    @asyncio.coroutine
    def coro(obj):
        obj.x = 5
        return obj.x

    class aiothonClass:
        @cached_property
        def y(self):
            return coro(self)

    @aiothonClass.y.setter
    def y(self, value):
        self.x = value
        return self.x

    obj = aiothonClass()
    assert obj.__dict__ == {}
    assert not obj.__dict__.get('y')
    assert isinstance(obj.y, asyncio.Future)
    assert obj.x == 5
    assert isinstance(obj.y, asyncio.Future)

# Generated at 2022-06-23 17:57:31.912092
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """ Test method __get__ of class cached_property.

        Test suite to verify that the ``cached_property`` decorator
        performs as expected.

    """
    import pytest
    import os

    @cached_property
    def y(obj):
        return obj.x + 1

    class TestClass:
        def __init__(self, x=None, y=None):
            self.x = x or 5
            self.y = y or 5

    test_obj = TestClass()
    os.environ['PYTHONASYNCIODEBUG'] = '1'

    assert test_obj.y == 6
    test_obj.x = 10
    assert test_obj.y == 6  # This fails because the cached property is not reset.

    # Try again with cached_property

# Generated at 2022-06-23 17:57:40.028423
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property.

    """

    def test_1():
        class MyClass:

            def __init__(self):
                self.x = 5

            @cached_property
            def y(self):
                return self.x + 1

        obj = MyClass()
        assert obj.y == 6
        obj.x = 6
        assert obj.y == 6

    def test_2():
        class MyClass:

            def __init__(self):
                self.x = 5

            @cached_property
            def y(self):
                return self.x + 1

        obj = MyClass()
        assert obj.y == 6
        obj.x = 6
        assert obj.y == 6


# Generated at 2022-06-23 17:57:43.147951
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    import asyncio

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6



# Generated at 2022-06-23 17:57:55.207485
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():  # noqa: D102
    from flutils.decorators import cached_property

    class _MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert hasattr(_MyClass, 'y')
    assert not hasattr(_MyClass(), 'y')
    myclass = _MyClass()
    assert hasattr(myclass, 'y')
    assert hasattr(myclass, 'x')
    assert hasattr(myclass.__dict__, 'x')
    assert not hasattr(myclass.__dict__, 'y')
    assert hasattr(myclass, '__dict__')
    assert hasattr(myclass, '__dict__')
    y = myclass.y

# Generated at 2022-06-23 17:57:59.890499
# Unit test for constructor of class cached_property
def test_cached_property():
    obj = cached_property(test_cached_property)
    func = obj.func
    doc = obj.__doc__

    assert func == test_cached_property
    assert doc == test_cached_property.__doc__


# Generated at 2022-06-23 17:58:02.207545
# Unit test for constructor of class cached_property
def test_cached_property():
    # Assert that this doesn't throw exception
    cached_property(lambda x: None)
    return

# Generated at 2022-06-23 17:58:06.469122
# Unit test for method __get__ of class cached_property
def test_cached_property___get__(): #noqa: D103
    from .helpers import StaticClass
    from .helpers import check_decorated_method_with_signature

    assert check_decorated_method_with_signature(cached_property,
                                                 '__get__',
                                                 StaticClass)

# Generated at 2022-06-23 17:58:13.401588
# Unit test for constructor of class cached_property
def test_cached_property():
    "Unit test for cached property decorator"
    # pylint: disable=unused-variable

    class Foo:

        # pylint: disable=no-self-use

        @cached_property
        def x(self):
            return 5

    # Check attribute name
    assert 'x' in Foo().__dict__
    # Check None
    assert Foo().__dict__['x'] is None

    class Foo:

        # pylint: disable=no-self-use

        @cached_property
        def x(self):
            return 5

    # Check value
    assert Foo().__dict__['x'] == 5


# Generated at 2022-06-23 17:58:20.005796
# Unit test for constructor of class cached_property
def test_cached_property():
    class FakeLogger:
        def __init__(self, level):
            self.level = level

        @cached_property
        def logger(self):
            logger = logging.getLogger(self.__class__.__name__)
            logger.setLevel(self.level)
            return logger

    logger = FakeLogger(logging.INFO)
    assert logger.logger is logger.logger

# Generated at 2022-06-23 17:58:24.032988
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit testing for class ``cached_property``."""

    from flutils.misc import noop

    the_property = cached_property(noop)
    assert isinstance(the_property, cached_property)



# Generated at 2022-06-23 17:58:29.249189
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    This module has no doctests. Instead, run::

        from flutils.decorators.cached_property import test_cached_property
        test_cached_property()

    """
    import doctest
    doctest.testmod(verbose=True)


if __name__ == "__main__":
    test_cached_property()

# Generated at 2022-06-23 17:58:31.603728
# Unit test for constructor of class cached_property
def test_cached_property():
    @cached_property
    def fun(obj):
        return obj

    assert fun.__doc__ is None
    assert fun.func(obj='') == ''



# Generated at 2022-06-23 17:58:35.780944
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    from flutils.decorators import cached_property

    class A:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    a = A()
    assert a.y == 6
    assert a.__dict__['y'] == 6



# Generated at 2022-06-23 17:58:41.377931
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    import flutils
    assert flutils.__version__ == '0.2.0'

    assert not isinstance(obj, MyClass)
    assert isinstance(obj, object)

    assert obj.y == 6

# Generated at 2022-06-23 17:58:45.985913
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 17:58:50.621950
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    First unit test
    """
    class Foo:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    foo = Foo()
    # Test the decorator
    assert foo.y == 6



# Generated at 2022-06-23 17:58:56.313708
# Unit test for constructor of class cached_property
def test_cached_property():
    class TempClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TempClass()
    assert obj.y == 6


if __name__ == '__main__':
    test_cached_property()

# Generated at 2022-06-23 17:59:01.289884
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Test construction
    obj = MyClass()
    assert obj.y == 6
    assert obj.y == 6  # Make sure that the second access is cached

# Generated at 2022-06-23 17:59:04.054244
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest

    # test = cached_property()
    # result = test.__get__(None, None)
    # print(result)



# Generated at 2022-06-23 17:59:04.752837
# Unit test for constructor of class cached_property
def test_cached_property():
    pass

# Generated at 2022-06-23 17:59:10.870640
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test method __get__ of class cached_property"""
    from flutils.decorators import cached_property

    class MyClass:
        cnt = 0

        @cached_property
        def y(self):
            self.cnt += 1
            return self.cnt

    obj = MyClass()
    assert obj.y == 1
    assert obj.y == 1
    assert obj.y == 1


# Generated at 2022-06-23 17:59:14.608067
# Unit test for constructor of class cached_property
def test_cached_property():

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    temp = MyClass()
    assert temp.y == 6

# Generated at 2022-06-23 17:59:21.513272
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import functools
    import sys
    if sys.version_info >= (3, 8):
        assert functools.cached_property == cached_property
    else:
        class A:
            def __init__(self, x):
                self.x = x

            @cached_property
            def y(self):
                return self.x + 1

            @cached_property
            def z(self):
                return self.x + 1

        a = A(5)
        assert A.y == cached_property
        assert a.y == a.z

# Generated at 2022-06-23 17:59:28.542589
# Unit test for constructor of class cached_property
def test_cached_property():
    """Tests :class:`cached_property <flutils.decorators.cached_property>`

    This function is called automatically by :mod:`unittest <unittest>`

    """
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 17:59:31.599194
# Unit test for constructor of class cached_property
def test_cached_property():
    class C(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = C()

    assert obj.y == 6

# Generated at 2022-06-23 17:59:37.488247
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.__dict__ == {'x': 5}
    assert obj.y == 6
    assert obj.__dict__ == {'x': 5, 'y': 6}
    assert obj.y == 6


# Generated at 2022-06-23 17:59:42.094458
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    assert obj.y == 6

# Generated at 2022-06-23 17:59:47.806348
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class :obj:`cached_property`"""

    # Example
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 17:59:48.398255
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass

# Generated at 2022-06-23 17:59:54.403761
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Method to test `cached_property._cached_property__get__`.

    This method is covered by tests
    `test_cached_property_using_non_coroutine_function <https://bit.ly/2q3dA9c>`__
    and
    `test_cached_property_using_coroutine_function <https://bit.ly/2NXOI06>`__

    """
    return True


# Generated at 2022-06-23 18:00:02.149022
# Unit test for constructor of class cached_property
def test_cached_property():
    @cached_property
    def test_prop(self):
        return True

    def test_func(self):
        return True

    try:
        # Check that the cached_property decorator correctly wraps a function
        # that is not a coroutine
        test_prop(None)
    except (AttributeError, TypeError):
        pass
    test_prop.__doc__ = test_func.__doc__



# Generated at 2022-06-23 18:00:06.177941
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test constructor of class cached_property."""
    import string

    cp = cached_property(string.capwords)

    assert cp.func == string.capwords
    assert cp.__doc__ == string.capwords.__doc__

# Generated at 2022-06-23 18:00:11.528431
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property

    Returns:
        None

    """
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6

# Generated at 2022-06-23 18:00:17.771467
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest
    from flutils.decorators import cached_property
    class _Class:
        def __init__(self):
            self.x = 5
        @cached_property
        def y(self):
            return self.x + 1
    obj = _Class()
    assert obj.y == 6


# Generated at 2022-06-23 18:00:25.662050
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import call

    import pytest

    from flutils.decorators import cached_property

    class MockObj:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    def test_inst_attr(obj):
        assert set(obj.__dict__.keys()) == {"x", "y"}
        assert obj.__dict__["y"] == 6

    obj = MockObj()
    test_inst_attr(obj)

    # Re-assign the obj.y attribute and test
    obj.y = 4
    assert set(obj.__dict__.keys()) == {"x", "y"}
    assert obj.__dict__["y"] == 4

    # Delete the obj.y attribute and test


# Generated at 2022-06-23 18:00:30.318685
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test cached_property"""

    # pylint: disable=missing-function-docstring
    class Test:
        """Test class"""

        def __init__(self):
            """Initialize the Test object"""
            self.value = 0

        @cached_property
        def value(self):
            return self.value

    obj = Test()
    expected_value = 0

    actual_value = obj.value

    assert actual_value == expected_value

# Generated at 2022-06-23 18:00:35.857898
# Unit test for constructor of class cached_property
def test_cached_property():
    # pylint: disable=R0903
    # pylint: disable=C0111
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    return obj

# Generated at 2022-06-23 18:00:43.241364
# Unit test for constructor of class cached_property
def test_cached_property():
    """Run unittests for class cached_property."""
    import unittest

    class TestCachedProperty(unittest.TestCase):
        def test_cached_property(self):
            class foo:
                def __init__(self):
                    self.x = 5

                @cached_property
                def y(self):
                    return self.x + 1

            obj = foo()
            self.assertEqual(obj.y, 6)

    unittest.main()

# Generated at 2022-06-23 18:00:45.632330
# Unit test for constructor of class cached_property
def test_cached_property():
    test = cached_property(lambda x: x)
    assert callable(test)



# Generated at 2022-06-23 18:00:49.110747
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property"""

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert MyClass().y == 6

# Generated at 2022-06-23 18:00:55.489035
# Unit test for constructor of class cached_property

# Generated at 2022-06-23 18:00:57.296787
# Unit test for constructor of class cached_property
def test_cached_property():
    pass


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-23 18:01:01.185819
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    assert obj.__dict__ == {'x': 5, 'y': 6}

# Generated at 2022-06-23 18:01:09.141817
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for class cached_property.

    This unit test is run by typing::

        python -m flutils.decorators

    """

    class TestClass:

        def __init__(self, x=None):
            self._x = x

        @cached_property
        def x(self):
            return self._x

    obj = TestClass(3)
    actual = obj.x
    expected = 3
    assert actual == expected


if __name__ == "__main__":
    test_cached_property___get__()

# Generated at 2022-06-23 18:01:14.183989
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass(object):
        def __init__(self):
            self.y = None

        @cached_property
        def x(self):
            self.y = 2
            return 2
    obj = MyClass()
    assert obj.x == 2
    assert obj.y == 2
    del obj.x
    assert obj.y is None


if __name__ == '__main__':
    test_cached_property()

# Generated at 2022-06-23 18:01:23.190289
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """ Unit test for method __get__ of class cached_property
    """

    from io import StringIO

    from flutils.decorators import cached_property

    class Widget:

        def __init__(self, file: StringIO):
            self._file = file

        @cached_property
        def file(self) -> str:
            return self._file.readline()

    file = StringIO(u"one two three four five")

    w = Widget(file)
    assert w.file == "one two three four five"
    assert w.file == "one two three four five"

    file.seek(0)

    w._file = file
    assert w.file == "one two three four five"



# Generated at 2022-06-23 18:01:32.314163
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import TestCase

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class Test_cached_property___get__(TestCase):

        def test_cached_property___get__(self):
            self.assertEqual(MyClass.y, cached_property)
            obj = MyClass()
            self.assertEqual(obj.y, 6)
            obj.x = 7
            self.assertEqual(obj.y, 6)

    Test_cached_property___get__().test_cached_property___get__()

# Generated at 2022-06-23 18:01:36.948440
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class C:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    c = C(5)

    assert c.y == 6
    assert c.__dict__["y"] == 6


# Generated at 2022-06-23 18:01:40.663686
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # noinspection PyPep8Naming
    class Cls:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Cls()
    assert obj.y == 6

# Generated at 2022-06-23 18:01:45.494526
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import Mock

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert 6 == obj.y
    assert 6 == obj.y
    assert 6 == obj.y

    assert {'y': 6} == obj.__dict__


# Generated at 2022-06-23 18:01:51.210579
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.objects import Wrapper
    from flutils.decorators import cached_property
    class Test:
        pass
    obj = Test()
    assert not hasattr(obj, '_wrapped')
    @cached_property
    def x(obj):
        return Wrapper(1)
    assert not hasattr(obj, '_wrapped')
    assert x is x
    assert hasattr(obj, '_wrapped')
    assert obj._wrapped.value == 1


# Generated at 2022-06-23 18:01:56.873453
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Tests constructor of `flutils.decorators.cached_property`
    """
    import pytest
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 18:02:00.345950
# Unit test for constructor of class cached_property
def test_cached_property():
    obj = MyClass()
    y = cached_property(obj.func)
    y.__get__(obj, cls=MyClass)


# Generated at 2022-06-23 18:02:03.300998
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Unit test for constructor of class cached_property
    """
    class MyClass(object):

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    my_object = MyClass()
    assert(my_object.y == 6)



# Generated at 2022-06-23 18:02:14.444280
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    def func(self):
        return self.x + 1

    func.__name__ = 'func'
    decorator = cached_property(func)

    # Test with obj = None
    assert decorator.__get__(None, None) is decorator

    # Test with obj defined
    obj = object()
    obj.x = 3
    assert decorator.__get__(obj, None) == 4

    # Test that func is called only once
    obj.x = 4
    assert decorator.__get__(obj, None) == 4

    # Test that func is called again if key is deleted from instance dictionary
    del obj.__dict__['func']
    obj.x = 5
    assert decorator.__get__(obj, None) == 6



# Generated at 2022-06-23 18:02:17.076760
# Unit test for constructor of class cached_property
def test_cached_property():

    @cached_property
    def y():
        """Function for testing cached_property."""
        return 6

    assert y.__doc__ == 'Function for testing cached_property.'

# Generated at 2022-06-23 18:02:23.468586
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    try:
        attribute_error_raised = False
        class TestClass:
            @cached_property
            def x(self):
                return 1
        obj = TestClass()
        assert obj.x == 1
        del obj.x
        assert obj.x == 1
        del obj.x
        # This should raise an AttributeError.
        _ = obj.x
    except AttributeError:
        attribute_error_raised = True
        pass
    assert attribute_error_raised



# Generated at 2022-06-23 18:02:29.490265
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test the method `cached_property.__get__` of class `cached_property`.
    """

    @cached_property
    def foo(self):
        """The foo property."""
        return self

    @cached_property
    def bar(self):
        """The bar property."""
        return 'bar'

    assert foo.bar == 'bar'

    foo.__dict__['bar'] = 'baz'
    assert foo.bar == 'baz'




# Generated at 2022-06-23 18:02:37.350267
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Self:
        def __init__(self):
            self._x = -1

        # The cached property is set to a future
        @cached_property
        def x(self):
            """The x property."""
            return self._x

    self = Self()
    result = self.x
    assert result == -1

    self._x = 101
    result = self.x
    assert result == -1

    assert self.x.__doc__ == "The x property."


# noinspection PyPep8Naming

# Generated at 2022-06-23 18:02:38.158990
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property



# Generated at 2022-06-23 18:02:44.115742
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from contextlib import suppress

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    # noinspection PyUnresolvedReferences
    assert obj.__dict__['y'] == 6

    with suppress(AttributeError):
        # noinspection PyUnresolvedReferences
        del obj.y

    assert obj.y == 6
    # noinspection PyUnresolvedReferences
    assert obj.__dict__['y'] == 6


# EOF

# Generated at 2022-06-23 18:02:48.552231
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Method to unit test the :meth:`cached_property.__get__` method.
    """

    class MyClass:
        """MyClass Class
        """

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y = 20
    assert obj.__dict__['y'] == 20

# Generated at 2022-06-23 18:02:53.913684
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit tests for :class:`~flutils.decorators.cached_property`.

    """

    class ContrivedClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = ContrivedClass()
    assert obj.y == 6
    assert obj.y == 6

# Generated at 2022-06-23 18:03:02.294517
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Test :class:`~flutils.decorators.cached_property` works as expected

    # Date: 2019-12-07
    # Version: 0.2.2
    """

    from collections import namedtuple
    TestClass = namedtuple('TestClass', ['x'])

    class TestObj(TestClass):

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestObj(1)
    assert hasattr(TestObj.y, '__doc__')
    assert obj.y == 2

    obj = TestObj(2)
    assert obj.y == 3

# ==================== EOF =========================================================

# Generated at 2022-06-23 18:03:11.359838
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test that cached_property behaves as expected
    """

    # Suppress "Access to a protected member _sentinel of a client class"
    # pylint: disable=W0212

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    for _ in range(4):
        assert obj.y == 6

    assert obj.__dict__['y']._sentinel is obj.__dict__['y']
    del obj.y
    assert obj.__dict__['y']._sentinel is obj.__dict__['y']

    assert obj.y == 6

    # Suppress "__init__ method from base class 'object' is not called"
    # pyl

# Generated at 2022-06-23 18:03:14.984821
# Unit test for constructor of class cached_property
def test_cached_property():
    @cached_property
    def x():
        return 5
    assert x.__doc__ is None
    assert x.func.__name__ == 'x'
    assert x.__name__ == 'x'

# Generated at 2022-06-23 18:03:26.057631
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Unit test for the cached_property decorator

    """

    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert type(obj.y) == int
    assert issubclass(type(obj.y), int)
    assert issubclass(type(obj.y), object)
    assert type(obj.y) is int
    assert type(obj.y) is not object
    assert obj.y is not None
    assert obj.y is None
    assert obj.y is not False
    assert obj.y is False
    assert obj.y is not True
    assert obj

# Generated at 2022-06-23 18:03:35.314141
# Unit test for constructor of class cached_property
def test_cached_property():

    class TestClass:

        @cached_property
        def cached_property_item(self):
            return 'This is from cached property'

    test_obj = TestClass()

    # Test if the values of cached property are equal
    assert test_obj.cached_property_item == test_obj.cached_property_item

    # Test if the value of cached property is deleted
    del test_obj.cached_property_item
    assert hasattr(test_obj, 'cached_property_item') is False

    # Test if cached property is set again
    assert test_obj.cached_property_item == test_obj.cached_property_item

test_cached_property()

# Generated at 2022-06-23 18:03:42.689993
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method cached_property.__get__"""

    # noinspection PyMissingOrEmptyDocstring,PyMissingTypeHints
    class Foo:
        def __init__(self, x):
            self.__x = x

        @cached_property
        def get_x(self):
            return self.__x

    # noinspection PyUnusedLocal
    def assert_property(obj, x):
        assert obj.get_x == x

    f = Foo
    for x in range(10):
        obj = f(x)
        assert_property(obj, x)
        # noinspection PyStatementEffect
        obj.get_x
        assert_property(obj, x)
        del obj.get_x
        assert_property(obj, x)


# Generated at 2022-06-23 18:03:44.341728
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils import decorators

    assert decorators.cached_property.__doc__ is not None



# Generated at 2022-06-23 18:03:47.586540
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:03:52.449463
# Unit test for constructor of class cached_property
def test_cached_property():

    class Foo:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    foo = Foo() # noqa


# Generated at 2022-06-23 18:03:56.450839
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Test:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Test()
    assert obj.y == 6



# Generated at 2022-06-23 18:04:04.706192
# Unit test for constructor of class cached_property
def test_cached_property():
    """ Unit test for constructor of class cached_property
    """

    @cached_property
    def get_max():
        return max([1, 2, 3])

    assert get_max == 3

    class MyTestClass:

        def __init__(self):
            self._cached_property_initialized = False

        @cached_property
        def cache_me(self):
            self._cached_property_initialized = True
            return 'initial value'

    inst = MyTestClass()
    assert not inst._cached_property_initialized
    assert inst.cache_me == 'initial value'
    assert inst._cached_property_initialized

    del inst.cache_me
    inst._cached_property_initialized = False
    assert not inst._cached_property_initialized
    assert inst.cache_me == 'initial value'

# Generated at 2022-06-23 18:04:11.573398
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import patch

    @cached_property
    def dummy():
        pass

    with patch.object(dummy, 'func') as mocked_func:
        mocked_func.return_value = 'val'
        val = dummy.__get__(None, None)
        assert val == 'val'

        mocked_func.assert_called_once_with(None)
        mocked_func.assert_called()


# Generated at 2022-06-23 18:04:20.739211
# Unit test for constructor of class cached_property
def test_cached_property():
    """

    """

    from flutils.flutils_testing import BaseTestCase, runmodule

    class TestCase(BaseTestCase):

        def _call_fut(self, *args, **kwargs):
            return cached_property(*args, **kwargs)

        def test_decorator(self):
            @self._call_fut
            def xxx(self):
                return 5

            self.assertEqual(xxx.__doc__, None)
            self.assertEqual(xxx.func, xxx.__wrapped__)

    runmodule(TestCase)

# Unit test code for class cached_property

# Generated at 2022-06-23 18:04:31.897436
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # With argument 'cls' being None
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    assert MyClass.y

    # With argument 'cls'
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert isinstance(obj.__class__.y, cached_property)

    # With argument 'obj' being None
    class MyClass:

        def __init__(self):
            self.x = 5


# Generated at 2022-06-23 18:04:40.982614
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import unittest
    from unittest.mock import patch

    class Example:

        def __init__(self, value):
            self.value = value

        @cached_property
        def inc(self):
            return self.value + 1

        @cached_property
        def dec(self):
            return self.value - 1

    class TestCachedProperty(unittest.TestCase):

        def setUp(self):
            self.example = Example(3)

        def test_dec(self):
            # Test plain cached value
            self.assertEqual(self.example.dec, 2)
            self.example.value = 4
            # Test reset of cached value
            self.assertEqual(self.example.dec, 2)
            self.example.__dict__.pop("dec")
            # Test

# Generated at 2022-06-23 18:04:45.570068
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property


    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6

# Generated at 2022-06-23 18:04:55.054750
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import sys

    # noinspection PyUnresolvedReferences
    async def async_y(obj):
        await asyncio.sleep(0)
        return obj.x + 1

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        async def async_y(self):
            return await async_y(self)

        @cached_property
        def non_callable(self):
            pass

    if sys.version_info >= (3, 8):
        from functools import cached_property

        class MyClass:
            def __init__(self):
                self.x = 5

            @cached_property
            def y(self):
                return self.x

# Generated at 2022-06-23 18:05:03.582479
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Obj:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x + 1

        @cached_property
        def v(self):
            return "foo"

    o = Obj()
    o.y
    o.z
    o.v
    assert o.__dict__["y"] == o.y
    assert o.__dict__["z"] == o.z
    assert o.__dict__["v"] == o.v

# Generated at 2022-06-23 18:05:06.329372
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyTestClass:
        def __init__(self):
            self._x = 5

        @cached_property
        def x(self):
            return self._x + 1

    mc = MyTestClass()
    assert mc.x == 6

# Generated at 2022-06-23 18:05:13.374139
# Unit test for constructor of class cached_property
def test_cached_property():
    def get_hash(input_string):
        from hashlib import sha256
        return sha256(input_string.encode()).hexdigest()

    class SomeClass:
        @cached_property
        def some_attribute(self):
            return get_hash('This will only be hashed once.')

    first_hash = SomeClass().some_attribute
    second_hash = SomeClass().some_attribute

    assert first_hash == second_hash

# Generated at 2022-06-23 18:05:21.360364
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import unittest as ut

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class test_cached_property___get__(ut.TestCase):
        @classmethod
        def setUpClass(cls):
            cls.obj = MyClass()

        def test_second_access_returns_attribute(self):
            self.assertEqual(self.obj.y, 6)
            self.assertEqual(self.obj.__dict__['y'], 6)

        def test_messing_with_value_not_reset(self):
            self.obj.y = 2
            self.assertEqual(self.obj.y, 2)


# Generated at 2022-06-23 18:05:29.587145
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # noinspection PyStatementEffect,PyUnresolvedReferences
    """This is a unit test for method __get__ of class cached_property.
    It checks that:
        1. When given a class, the decorator returns self
        2. When given an instance, the decorator returns a function

    """
    from sys import version_info
    from unittest import TestCase

    # Create a mock class
    class MockClass:

        def test_function(self):
            return "OK"

        @cached_property
        def test_property(self):
            return "OK"

    # Check that property decorator returns self when given a class
    assert isinstance(MockClass.test_property, cached_property)

    # Check that property decorator returns a function when given an instance
    assert version_info < (3, 8)
   

# Generated at 2022-06-23 18:05:33.954059
# Unit test for constructor of class cached_property
def test_cached_property():
    """ Unit test for cached_property()

    :return:
    """

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:05:43.006724
# Unit test for constructor of class cached_property
def test_cached_property():
    import asyncio

    @cached_property
    def func_no_coroutine(obj):
        return "no coroutine"

    @cached_property
    def func_coroutine(obj):
        return "yes coroutine"

    obj = object()

    @asyncio.coroutine
    def test_coroutine():
        yield from asyncio.sleep(0)
        assert obj.func_no_coroutine == "no coroutine"
        assert (
            yield from obj.func_coroutine == "yes coroutine"
        )  # yield from should work

    asyncio.get_event_loop().run_until_complete(test_coroutine())


if __name__ == '__main__':
    test_cached_property()

# Generated at 2022-06-23 18:05:44.713840
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    def test_func():
        pass
    prop = cached_property(test_func)
    assert prop.__doc__ == 'test_func'
    assert prop.func is test_func

# Generated at 2022-06-23 18:05:51.469747
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from pprint import pprint
    from flutils.decorators import cached_property

    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Test standard __get__ method
    obj = TestClass()
    pprint(obj.__dict__)
    pprint(vars(obj))
    assert isinstance(obj.y, int)
    assert obj.y == 6
    pprint(obj.__dict__)
    pprint(vars(obj))
    del obj.y
    pprint(obj.__dict__)
    pprint(vars(obj))

    # Test async __get__ method
    obj = TestClass()
    pprint(obj.__dict__)
    p