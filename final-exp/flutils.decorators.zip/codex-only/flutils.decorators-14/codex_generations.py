

# Generated at 2022-06-23 17:55:51.232986
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property(lambda x: x)
    assert cached_property(lambda x: x).__get__
    assert cached_property(lambda x: x).func

# Generated at 2022-06-23 17:55:55.492439
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y

# Generated at 2022-06-23 17:55:59.088093
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property.

    Args:

        None.

    Returns:

        None.

    """
    # pylint: disable=protected-access
    obj1 = cached_property(object())
    assert obj1
    del obj1


# Generated at 2022-06-23 17:56:03.867048
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1


    obj = MyClass()
    assert obj.y == 6
    assert obj.y == 6

# Generated at 2022-06-23 17:56:07.889203
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 17:56:18.324825
# Unit test for constructor of class cached_property
def test_cached_property():
    import functools
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert functools.lru_cache.cache_info().currsize == 0

    obj = MyClass()
    assert obj.y == 6
    assert functools.lru_cache.cache_info().currsize == 0

    obj.x = 10
    assert obj.y == 6
    assert functools.lru_cache.cache_info().currsize == 0

    obj.x = 15
    assert obj.y == 6
    assert functools.lru_cache.cache_info().currsize == 0

    del obj.y
    assert obj.y == 16

# Generated at 2022-06-23 17:56:19.724773
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property.__doc__ is not None
    assert cached_property.__init__.__doc__ is not None



# Generated at 2022-06-23 17:56:25.208885
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y


# Run unit tests
if __name__ == "__main__":
    test_cached_property___get__()

# Generated at 2022-06-23 17:56:31.443724
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Unit test for class cached_property
    :return:
    """

    class Obj:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Obj()
    assert obj.y == 6
    obj.x = 10
    assert obj.y == 11


# Generated at 2022-06-23 17:56:33.897367
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert MyClass().y == 6

# Generated at 2022-06-23 17:56:44.144671
# Unit test for constructor of class cached_property
def test_cached_property():
    # Test for docstring
    with pytest.raises(TypeError):
        cached_property()

    # Test for initialization
    assert cached_property(1).__doc__ == "1"
    assert cached_property(
        lambda: 1).__doc__ == "<lambda>".__doc__
    assert cached_property(lambda x: x).__doc__ == "<lambda>".__doc__

    # Test for docstring
    class X:
        @cached_property
        def y(self):
            return 1

    x = X()
    y_decorator = cached_property(x.y)
    assert y_decorator.func == x.y
    assert y_decorator.__doc__ == x.y.__doc__
    assert y_decorator.__get__(x) == 1

    #

# Generated at 2022-06-23 17:56:47.538032
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class TestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.y == 6

# Generated at 2022-06-23 17:56:53.707932
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Unit test for constructor of class cached_property

    :return:
    """
    class MyClass(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.y == 6

# Generated at 2022-06-23 17:56:55.255138
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    with pytest.raises(NotImplementedError):
        cached_property.__get__()

# Generated at 2022-06-23 17:57:05.712578
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class TestCachedProperty:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestCachedProperty()
    assert obj.y == 6

    with pytest.raises(AttributeError):
        del obj.y

    assert obj.y == 6
    obj.x = 10
    assert obj.y == 6

    del obj.y

    assert obj.y == 11



# Generated at 2022-06-23 17:57:07.818578
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__ == {'x': 5, 'y': 6}



# Generated at 2022-06-23 17:57:12.786775
# Unit test for constructor of class cached_property
def test_cached_property():
    my_func = lambda x: sum(x)
    my_obj = cached_property(my_func)
    assert isinstance(my_obj, cached_property)
    assert my_obj.__doc__ == my_func.__doc__
    assert my_obj.func == my_func

# Generated at 2022-06-23 17:57:16.872545
# Unit test for constructor of class cached_property
def test_cached_property():
    @cached_property
    def foo():
        return 5 * 5

    assert foo.__doc__ == 'foo() -> cached_property object'
    assert foo.func == foo
    assert foo.func.__doc__ == 'foo() -> cached_property object'


# Generated at 2022-06-23 17:57:27.056144
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Unit test for cached_property.
    """
    # noinspection PyProtectedMember
    assert 'cached_property' in flutils.decorators.__all__
    assert callable(flutils.decorators.cached_property)

    # noinspection PyPep8Naming
    class MyClass:

        def __init__(self):
            self.x = 5

        @flutils.decorators.cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    # noinspection PyProtectedMember
    assert '__obj' not in obj.y.__dict__



# Generated at 2022-06-23 17:57:34.775732
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property

    Returns:
        None
    """
    from unittest import mock

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == obj.x + 1
    with mock.patch.object(obj, 'y', async_coro=True, new_callable=mock.NonCallableMock) as mock_y:
        obj.y
        mock_y.assert_awaited_once()

# Generated at 2022-06-23 17:57:40.057532
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import TestCase, mock
    from unittest.mock import MagicMock

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class Test_cached_property___get__(TestCase):
        def setUp(self):
            self.cls = MyClass()

        def test_something(self):
            self.assertEqual(self.cls.y, 6)

# Generated at 2022-06-23 17:57:41.440205
# Unit test for constructor of class cached_property
def test_cached_property():
    # Setup
    obj = MyClass()
    # Exercise
    # Verify
    assert obj.y == 6
    assert obj.z == 42


# Generated at 2022-06-23 17:57:44.703605
# Unit test for constructor of class cached_property
def test_cached_property():
    import types
    import pytest

    @cached_property
    def func(x):
        return x + 1

    assert isinstance(func, types.FunctionType)
    assert func.__name__ == "func"

    with pytest.raises(TypeError):
        _ = cached_property(1)

# Generated at 2022-06-23 17:57:50.167073
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property
    """
    class TestClass:
        @cached_property
        def y(self):
            self.x = 7

    obj = TestClass()
    obj.y
    obj.x
    assert obj.x == 7

# Generated at 2022-06-23 17:57:58.390425
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """My y property."""
            return self.x + 1

    obj = MyClass()

    assert 'y' not in obj.__dict__
    assert obj.y == 6
    assert obj.y is obj.__dict__['y']
    assert obj.__dict__['y'] == 6
    assert obj.__dict__['y'] is obj.y
    assert getattr(obj, 'y') == 6
    assert getattr(obj, 'y') is obj.y
    assert getattr(obj, 'y') is obj.__dict__['y']
    assert obj.y is getattr(obj, 'y')
    assert obj.__dict__['y'] is getattr

# Generated at 2022-06-23 17:58:02.881827
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Test:

        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    res = Test(5)
    assert res.y == 6


# Generated at 2022-06-23 17:58:12.628058
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import mock

    property_name = 'other_property'
    property_doc = 'A property.'

    class TestClass:
        pass

    test_method = mock.MagicMock()
    test_method.__name__ = property_name
    test_method.__doc__ = property_doc

    property_owner = TestClass()

    property_owner.test_method = test_method

    @cached_property
    def method_under_test():
        pass

    #
    # With no owner
    #
    method_under_test.__get__(None, property_owner)

    #
    # With owner
    #
    method_under_test.__get__(property_owner, property_owner)
    method_under_test.__get__(property_owner, property_owner)




# Generated at 2022-06-23 17:58:17.294532
# Unit test for constructor of class cached_property
def test_cached_property():
    class Test:
        def __init__(self, x):
            self.x = x

        @cached_property
        def test_prop(self):
            return self.x + 1

    test = Test(3)
    assert test.test_prop == 4



# Generated at 2022-06-23 17:58:22.045016
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property


    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1


    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 17:58:30.948415
# Unit test for constructor of class cached_property
def test_cached_property():
    # noinspection PyUnusedLocal
    @cached_property
    def my_cached_property(self):
        """This is an example of a cached property."""
        return True
    assert my_cached_property.__doc__ == "This is an example of a cached property."
    # noinspection PyUnusedLocal
    @cached_property
    def my_cached_property_coroutine(self):
        """This is an example of a cached property."""
        return asyncio.sleep(2)
    assert my_cached_property_coroutine.__doc__ == "This is an example of a cached property."


# EOF

# Generated at 2022-06-23 17:58:37.298903
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test method __get__ of class cached_property
    """

    # Cached property class
    class CachedProperty:
        """
        Test case for cached_property
        """

        count = 0

        # Test property
        @cached_property
        def prop(self):
            self.count += 1
            return self.count

    # Test class instance
    inst = CachedProperty()

    # Test getting the property
    assert inst.prop == 1
    assert inst.prop == 1

    # Test deleting the property
    del inst.prop
    assert inst.prop == 2


"""Disabled Content
"""

# Generated at 2022-06-23 17:58:42.231966
# Unit test for constructor of class cached_property
def test_cached_property():
    # Test the class constructor and __get__ method
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6, 'Expected cached property to be 6'



# Generated at 2022-06-23 17:58:46.285392
# Unit test for constructor of class cached_property
def test_cached_property():

    @cached_property
    def my_property(self):
        return "return value from my_property"

    assert my_property.__doc__ is None

    # noinspection PyPep8Naming
    class MyClass:
        pass

    assert isinstance(MyClass.my_property, cached_property)



# Generated at 2022-06-23 17:58:50.301813
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test case verifies that method __get__ of class cached_property behaves
    as expected.
    """

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    assert obj.__dict__['y'] == 6



# Generated at 2022-06-23 17:58:59.182163
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property"""

    class MyClass:
        """MyClass"""

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """y"""

            return self.x + 1

    obj = MyClass()
    result = obj.y
    assert result == 6
    # Test get from cache
    result = obj.y
    assert result == 6
    # Verify deletion works
    del obj.y
    result = obj.y
    assert result == 6



# Generated at 2022-06-23 17:59:02.516222
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    assert obj.__dict__['y'] == 6

# Generated at 2022-06-23 17:59:12.607392
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    glob_list = []
    loc_list = []

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):  # type: () -> int
            glob_list.append('hit')
            return self.x + 1

        @property
        def z(self):  # type: () -> int
            loc_list.append('hit')
            return self.x + 3

    obj = MyClass()
    assert obj.y == 6
    assert obj.z == 8

    glob_list.clear()
    loc_list.clear()
    assert obj.y == 6
    assert obj.z == 8
    assert glob_list == []
    assert loc_list == ['hit']

    # Test for pytest
    # assert glob_list == ['

# Generated at 2022-06-23 17:59:19.315221
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import patch

    obj = cached_property(lambda: None)
    cls = object()

    # Case 1: obj is None.
    assert obj.__get__(None, cls) is obj

    # Case 2: obj is not None.
    with patch.object(obj, '_wrap_in_coroutine') as mock_wrap_in_coroutine:
        assert obj.__get__(cls, cls) is mock_wrap_in_coroutine.return_value
        mock_wrap_in_coroutine.assert_called_once_with(cls)

# Generated at 2022-06-23 17:59:27.663098
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert isinstance(MyClass.y, cached_property)
    assert not isinstance(obj.y, cached_property)

    assert obj.y == 6

    with pytest.raises(AttributeError):
        del obj.y
    del obj.__dict__['y']
    assert not hasattr(obj, 'y')

# Generated at 2022-06-23 17:59:33.198129
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """Return the value of the cached property."""
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__ == {'x': 5, 'y': 6}
    assert obj.y == 6



# Generated at 2022-06-23 17:59:37.188588
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 17:59:40.728347
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass(object):

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    obj.x = 7
    assert obj.y == 8

    del obj.y
    assert obj.y == 8

test_cached_property___get__()



# Generated at 2022-06-23 17:59:43.082129
# Unit test for constructor of class cached_property
def test_cached_property():
    def mocker():
        pass

    cp = cached_property(mocker)
    assert cp.func == mocker
    assert cp.__doc__ is None

# Generated at 2022-06-23 17:59:44.907085
# Unit test for constructor of class cached_property
def test_cached_property():
    assert isinstance(cached_property(lambda x: x), cached_property)

# Generated at 2022-06-23 17:59:48.941257
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class A:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = A()
    assert obj.y == 6

# Generated at 2022-06-23 17:59:55.432738
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from .misc import NamedObj
    from .misc import create_obj_from_name

    def dummy(obj):
        return obj.i + 1

    self = create_obj_from_name(NamedObj("o"))

    self.d = cached_property(dummy)(self)
    self.__dict__['d'] = 1
    self.d
    self.d
    assert self.__dict__['d'] is 1

    del self.d
    self.d
    assert self.__dict__['d'] is 2

# Generated at 2022-06-23 18:00:03.999427
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import TestCase, main

    class MyClass:

        def __init__(self):
            self.foo = 'bar'

        @cached_property
        def y(self):
            return self.foo

    class Test_cached_property___get__(TestCase):
        def test_return_value(self):
            obj = MyClass()
            self.assertEqual(obj.y, 'bar')
            self.assertIn('y', obj.__dict__)

    main()

# Generated at 2022-06-23 18:00:09.075520
# Unit test for constructor of class cached_property
def test_cached_property():
    # When an object is created of class cached_property, it should have
    # attributes doc and func
    attribute_list = dir(cached_property('test_func'))
    assert '__doc__' in attribute_list
    assert 'func' in attribute_list


# Generated at 2022-06-23 18:00:15.800364
# Unit test for constructor of class cached_property
def test_cached_property():
    from parameterized import parameterized
    import pytest

    @parameterized([
        (6,),
        (7,),
        (8,),
        (9,),
        (10,),
        (11,),
        (12,)
    ])
    def test_getter(n):  # noqa
        class MyClass:

            def __init__(self):
                self.x = 5

            @cached_property
            def y(self):
                return self.x + n

        obj = MyClass()
        assert obj.y == n + 5

# Generated at 2022-06-23 18:00:18.397437
# Unit test for constructor of class cached_property
def test_cached_property():
    def my_function(self):
        return 1

    cp = cached_property(my_function)

    assert cp.func is my_function
    assert cp.__doc__ == my_function.__doc__



# Generated at 2022-06-23 18:00:29.638582
# Unit test for constructor of class cached_property
def test_cached_property():
    from .common import read_only_property


    class Foo:
        def __init__(self):
            self.a = 5

        @cached_property
        def b(self):
            return self.a + 1

        @read_only_property
        def c(self):
            return self.a + 1

        @read_only_property
        async def d(self):
            return self.a + 1

        @read_only_property
        async def e(self):
            return await self.d

    # Create object of type Foo
    f = Foo()
    # test cached_property
    assert f.b == 6
    # test read_only_property
    assert f.c == 6
    from flutils.common import async_property


    assert f.d == 6
    assert f.e == 6


# Generated at 2022-06-23 18:00:40.058670
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for flutils.decorators.cached_property.cached_property.__get__

    """
    class MyClass:
        def __init__(self):
            self.x = 2

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 3

    # And...now it's in the cache
    assert obj.__dict__["y"] == 3

    # Delete the cached value
    del obj.y
    # And now it's gone
    assert obj.__dict__ == {"x": 2}
    # And now it'll be recomputed
    assert obj.y == 3



# Generated at 2022-06-23 18:00:43.563833
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.anyutils import iscoroutinefunction, iscoroutine

    assert not iscoroutinefunction(cached_property)
    assert not iscoroutine(cached_property)



# Generated at 2022-06-23 18:00:47.855827
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class TestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.y == 6



# Generated at 2022-06-23 18:00:48.758721
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass



# Generated at 2022-06-23 18:00:54.199927
# Unit test for constructor of class cached_property
def test_cached_property():
    # Use a non-callable and check for exception
    with pytest.raises(TypeError):
        cached_property(5)

    # Use a callable and check for no exception
    cached_property(lambda: None)

    # Use a callable that is a context manager and check for no exception
    class CtxMgr:
        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            pass

        def __call__(self):
            return self

    cached_property(CtxMgr())



# Generated at 2022-06-23 18:00:55.490604
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property



# Generated at 2022-06-23 18:01:03.904398
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test cached property.

    From output of :py:func:`inspect.getargspec` on initializer of
    :py:class:`flutils.decorators.cached_property.cached_property`

    :return:
    """

    # noinspection PyUnresolvedReferences
    @cached_property
    def x(self):
        """A cached property.

        :rtype: str
        """
        return "Hello"

    class MyClass:
        """Example class for unit testing"""

        def __init__(self):
            self.x = "Bye"

        def __repr__(self):
            return f"MyClass(x={self.x!r})"


# Generated at 2022-06-23 18:01:08.260854
# Unit test for constructor of class cached_property
def test_cached_property():
    def get_func():
        return "Not implemented"

    prop = cached_property(get_func)
    obj = prop.__get__(None, dict())
    assert obj.__doc__ == get_func.__doc__


# Unit Test for function __get__

# Generated at 2022-06-23 18:01:13.138223
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method :obj:`cached_property.__get__` of
    class :obj:`cached_property`"""

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6

# Generated at 2022-06-23 18:01:18.853991
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__ == {'x': 5, 'y': 6}

# Generated at 2022-06-23 18:01:22.291949
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test constructor of class cached_property

    :return: True if test passes, False if test fails
    :rtype: bool
    """

    def ctor_cached_property():
        return cached_property(lambda: 0)

    assert str(ctor_cached_property()) == '<cached_property object at 0x'
    return True

# Generated at 2022-06-23 18:01:33.798234
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import patch
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    # Patch function y
    with patch.object(MyClass, 'y', create=True) as mock_y:
        # Patch to confirm that cached_property was used
        with patch.object(cached_property,
                          '__get__') as mock_cached_property:
            # Test that y is returned upon access
            MyClass.y
            # Test that cached_property was used
            mock_cached_property.assert_called_once_with(obj)
            # Test that y was not called
            mock

# Generated at 2022-06-23 18:01:36.517133
# Unit test for constructor of class cached_property
def test_cached_property():
    decorator = cached_property(getattr)
    assert decorator.__doc__ == getattr.__doc__
    assert decorator.func == getattr


# Generated at 2022-06-23 18:01:41.737822
# Unit test for constructor of class cached_property
def test_cached_property(): 
    from functools import cached_property as ft_cached_property
    class MyClass:

        def __init__(self):
            self.x = 5

        @ft_cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.__dict__ == {'x': 5}
    assert obj.y == 6
    
    


# Generated at 2022-06-23 18:01:44.369230
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property is not None

# Generated at 2022-06-23 18:01:47.118240
# Unit test for constructor of class cached_property
def test_cached_property():
    class A:

        def __init__(self):
            self.x = 0

        @cached_property
        def y(self):
            self.x += 1
            return self.x

    obj = A()
    assert obj.x == 0
    assert obj.y == 1
    assert obj.x == 1
    del obj.y
    assert obj.y == 2



# Generated at 2022-06-23 18:01:50.748020
# Unit test for constructor of class cached_property
def test_cached_property():

    class Foo:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    foo = Foo()
    assert foo.y == 6

    foo.x = 12
    assert foo.y == 6

# Generated at 2022-06-23 18:01:59.095834
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class A:

        def __init__(self, call_count):
            self.call_count = call_count

        @cached_property
        def x(self):
            self.call_count += 1
            return self.call_count

    a = A(0)
    assert a.x == 1
    assert a.x == 1
    assert a.call_count == 1

    a = A(0)
    assert (a.x, a.call_count) == (1, 1)



# Generated at 2022-06-23 18:02:05.473248
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest

    class MyClass:

        def __init__(self):
            self.x = 5
            self.y = 2
            self.z = 3

        @cached_property
        def get_xy(self):
            return self.x + self.y

        @cached_property
        def get_xz(self):
            return self.x + self.z


    m = MyClass()

    expected_get_xy = m.x + m.y
    expected_get_xz = m.x + m.z

    assert m.get_xy == expected_get_xy
    assert m.get_xz == expected_get_xz

    m.x = 6
    m.y = 4
    m.z = 7

    expected_get_xy = m.x + m.y


# Generated at 2022-06-23 18:02:13.596784
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # __get__ tests
    class A:
        count = 0

        @cached_property
        def method(self):
            self.__class__.count += 1
            return False

    b = A()
    assert not b.method, "got cached property"
    assert b.method is False, "got cached property"

    c = A()
    assert c.count == 0, "c.count should be 0"
    assert c.method is False, "c.method should be False"
    assert c.count == 1, "c.count should be 1"



# Generated at 2022-06-23 18:02:20.261400
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import asyncio
    from flutils.decorators import cached_property

    class A:

        def __init__(self):
             self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return 10

    a = A()
    assert a.y == 6
    assert asyncio.iscoroutinefunction(a._y)
    assert not asyncio.iscoroutinefunction(a._z)

# Generated at 2022-06-23 18:02:30.270639
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class TestClass(object):
        def __init__(self):
            self.x = None

        @cached_property
        def get_x(self):
            return self.x

        @cached_property
        def get_async_x(self):
            return self.async_x()

        async def async_x(self):
            return self.x

    a = TestClass()
    assert a.get_x is None
    b = TestClass()
    assert b.get_x is None
    a.x = 0
    b.x = 1
    assert a.get_x == 0
    assert a.get_x == 0
    assert b.get_x == 1
    assert b.get_x == 1
    a.x = 2


# Generated at 2022-06-23 18:02:35.877191
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property
    from unittest import mock

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    cl = MyClass()
    assert cl.y == 6



# Generated at 2022-06-23 18:02:40.911251
# Unit test for constructor of class cached_property
def test_cached_property():
    with pytest.raises(RuntimeError):
        cached_property('test')

    class Test:
        @cached_property
        def test(self):
            pass

    assert hasattr(Test, 'test')
    assert not hasattr(Test, '__test__')


# Generated at 2022-06-23 18:02:43.631335
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class A(object):
        @cached_property
        def a(self):
            return 4

    # A.a.func is the cached property function.
    assert A.a.func(A()) == 4

    # A().a is the cached property function value.
    assert A().a == 4

# Generated at 2022-06-23 18:02:47.394624
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest import TestCase
    t = TestCase()
    from unittest.mock import Mock

    @cached_property
    def f():
        return 1

    t.assertEqual(f, cached_property(f))
    t.assertEqual(f.func, f)



# Generated at 2022-06-23 18:02:56.690527
# Unit test for constructor of class cached_property
def test_cached_property():  # pragma: no cover
    from flutils.decorators import cached_property
    import sys

    # noinspection PyPep8Naming
    class TestClass:

        def __init__(self):
            self.x = 5
            self.y = None

        # noinspection PyUnusedLocal
        @cached_property
        def a_cached_property(self):
            """This is a cached property"""
            return self.x + 1

    obj = TestClass()
    assert obj.a_cached_property == 6
    assert obj.__dict__ == {'a_cached_property': 6, 'x': 5, 'y': None}
    assert sys.version_info < (3, 8)



# Generated at 2022-06-23 18:02:59.781058
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 18:03:06.257727
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test for method __get__ of class cached_property."""
    import flutils.decorators
    test_cases = (
        dict(func=flutils.decorators.cached_property, obj=None),
    )

    for test_case in test_cases:
        decorator = test_case["func"]
        obj = test_case["obj"]
        d = decorator(lambda: None)  # noqa: E731
        return_value = d.__get__(obj, str)
        assert return_value == decorator



# Generated at 2022-06-23 18:03:11.801483
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property."""

    class MyClass:

        def __init__(self, x=5):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.y + 10

    obj = MyClass()
    assert obj.x == 5
    assert obj.y == 6
    assert obj.z == 16

# Generated at 2022-06-23 18:03:13.598651
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass



# Generated at 2022-06-23 18:03:23.440304
# Unit test for constructor of class cached_property
def test_cached_property():
    import io
    import unittest.mock as mock
    from flutils.miscutils import run_tests as rt

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    tsb = io.StringIO()

    with mock.patch('sys.stdout', new=tsb):
        rt.run_tests([test_cached_property], verbosity=10)

    results = tsb.getvalue().strip()

    assert results == ("""
----------------------------------------------------------------------
Ran 1 test in 0.000s

OK
    """.lstrip('\n'))

# Generated at 2022-06-23 18:03:30.192402
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property

    """

    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    def test_object():
        obj = MyClass()
        assert obj.y == 6

    def test_class():
        assert MyClass.y.__doc__ == "A property decorator that is only " \
                                    "computed once per instance and then " \
                                    "replaces itself with an ordinary " \
                                    "attribute."

    test_object()
    test_class()



# Generated at 2022-06-23 18:03:33.791668
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:03:37.785207
# Unit test for constructor of class cached_property
def test_cached_property():
    class Test(object):

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Test()
    y = obj.y
    assert y == 6
    obj.x = 10
    y = obj.y
    assert y == 6

# Generated at 2022-06-23 18:03:47.582140
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Foo:
        def __init__(self, val):
            self.val = val

        @cached_property
        def foo(self):
            return self.val + 1

        @cached_property
        async def bar(self):
            await asyncio.sleep(0.25)
            return self.val + 1

    foo = Foo(5)
    assert foo.foo == 6
    assert foo.__dict__['foo'] == 6

    loop = asyncio.get_event_loop()
    bar = loop.run_until_complete(foo.bar)
    assert bar == 6


if __name__ == '__main__':
    import pytest

    pytest.main([__file__])

# Generated at 2022-06-23 18:03:54.220150
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test to ensure that method __get__ of class cached_property behaves
    as expected.
    """

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 18:03:55.972472
# Unit test for constructor of class cached_property
def test_cached_property():
    assert hasattr(cached_property, '__init__')


# Generated at 2022-06-23 18:04:03.524696
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    def test_instance_returns_value(obj, test_val):
        obj.x = test_val
        assert test_val == obj.y

    @cached_property
    def y(self):
        return self.x + 1

    obj = type('test', (), {})
    obj.y = y
    test_instance_returns_value(obj, 1)
    test_instance_returns_value(obj, 2)
    test_instance_returns_value(obj, 3)

    # Calling y should return the same value every time.
    val = obj.y
    obj.x += 1000
    assert val == obj.y



# Generated at 2022-06-23 18:04:09.660107
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Class:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Class()
    assert obj.y
    # deleting the attribute resets the property
    del obj.y
    assert obj.y



# Generated at 2022-06-23 18:04:16.206186
# Unit test for constructor of class cached_property
def test_cached_property():
    class T:
        def __init__(self, val):
            self._val = val

        @cached_property
        def val(self):
            return self._val + 1

    t = T(5)
    assert t.val == 6
    del t.val
    assert 'val' not in t.__dict__
    assert t.val == 6

# Generated at 2022-06-23 18:04:22.966948
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import unittest.mock as mock

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # set up mock to create a new object
    with mock.patch('flutils.decorators.cached_property.MyClass') as mock_class:
        mock_instance = mock_class.return_value
        mock_instance.x = 1

        obj = MyClass()

    assert obj.y == 2

# Generated at 2022-06-23 18:04:24.511692
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property(lambda x: x.field_name)


# Generated at 2022-06-23 18:04:25.746159
# Unit test for constructor of class cached_property
def test_cached_property():
    from .my_class import MyClass

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 18:04:27.930700
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Foo:

        @cached_property
        def foo(self):
            print('called')
            return 1

    f = Foo()
    assert f.foo == 1
    assert f.foo == 1



# Generated at 2022-06-23 18:04:34.266758
# Unit test for constructor of class cached_property
def test_cached_property():
    class Foo:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    foo = Foo()
    assert isinstance(foo, Foo)
    assert foo.x == 5
    assert foo.y == 6

    # Use cached value second time
    assert foo.y == 6


# Generated at 2022-06-23 18:04:37.480083
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

        class MyClass:

                def __init__(self):
                        self.x = 5

                @cached_property
                def y(self):
                        return self.x + 1

        obj = MyClass()
        assert obj.y == obj.x + 1

# Generated at 2022-06-23 18:04:48.519726
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    import functools

    class TestClass:

        def __init__(self):
            self.x = 0

        @cached_property
        def y(self):
            """Docstring for y."""
            self.x += 1
            return self.x

    test_obj_1 = TestClass()
    test_obj_2 = TestClass()

    # Test the return value is correct
    assert test_obj_1.y == 1
    assert test_obj_2.y == 1

    # Test the property replaces itself with an ordinary attribute
    assert "y" in test_obj_1.__dict__
    assert "y" not in test_obj_1.__class__.__dict__

    # Test the return value is correct
    assert test_obj_1.y == 1

# Generated at 2022-06-23 18:04:55.776526
# Unit test for constructor of class cached_property
def test_cached_property():
    class Foo:
        def __init__(self):
            self._x = None

        @cached_property
        def x(self):
            return 'x'

        @cached_property
        def y(self):
            return 'y'

    # Test for a regular attribute
    assert not hasattr(Foo, 'x')
    assert not hasattr(Foo(), 'x')
    assert Foo.__dict__['x'].__doc__ is None

    # Test for a cached property
    assert not hasattr(Foo, 'y')
    assert not hasattr(Foo(), 'y')
    assert Foo.__dict__['y'].__doc__ is None

    # Test that an attribute has been created on the instance
    assert Foo()._x is None



# Generated at 2022-06-23 18:05:01.001990
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6

# Generated at 2022-06-23 18:05:09.051925
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest.mock import patch
    from unittest import TestCase


    # setup for test
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    attr_name = 'x'
    cp = cached_property(obj.y)

    # test cached_property.__init__
    assert cp._cached_property__doc__ == MyClass.y.__doc__
    assert cp.func == MyClass.y

    # test cached_property.__get__

# Generated at 2022-06-23 18:05:13.517301
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils import cached_property
    class Test:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Test()
    assert obj.y == 6

# Generated at 2022-06-23 18:05:18.944853
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass(object):

        @cached_property
        def foo(self):
            """A test doc string."""
            return "foo"

    assert hasattr(MyClass, 'foo')
    assert hasattr(MyClass.foo, '__get__')
    assert not hasattr(MyClass.foo, '__set__')
    assert not hasattr(MyClass.foo, '__delete__')
    assert hasattr(MyClass.foo, '__doc__')
    assert hasattr(MyClass.foo, '__name__')



# Generated at 2022-06-23 18:05:28.237787
# Unit test for constructor of class cached_property
def test_cached_property():

    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


if __name__ == "__main__":
    import sys

    try:
        func_name = sys.argv[1]
    except IndexError:
        print(f"Usage:  python -m {__package__}.{__name__} function-name")
        sys.exit(1)

    if func_name == "test_cached_property":
        test_cached_property()
    else:
        print(f"{func_name} not found")

# Generated at 2022-06-23 18:05:32.116217
# Unit test for constructor of class cached_property
def test_cached_property():
    @cached_property
    def test_me(self):
        return 5 + 6

    assert test_me.__doc__ == None
    assert isinstance(test_me.func, types.FunctionType)

# Generated at 2022-06-23 18:05:41.979573
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest import TestCase
    from flutils.tests.mixins import UnitTest

    class Test(UnitTest, TestCase):
        def test(self):
            from functools import update_wrapper

            def func(self):
                return None

            self.assertIsNone(func(self))
            cp = cached_property(func)
            self.assertEqual(func.__doc__, cp.__doc__)

            cp = cached_property(func)
            # Because we want the actual __doc__ attribute, not properties.
            self.assertIsNotNone(cp.__doc__)
            self.assertTrue(update_wrapper(cp, func))
            self.assertIsNotNone(cp.__doc__)

    Test.run_tests()



# Generated at 2022-06-23 18:05:47.578356
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import unittest

    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class Test(unittest.TestCase):

        test_obj = MyClass()

        def test_set_y(self):
            Test.test_obj.y = 7
            self.assertEqual(Test.test_obj.y, 7)

    return Test

# Generated at 2022-06-23 18:05:54.737407
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Create class with cached_property decorator for the method 'a'
    class A:
        def __init__(self):
            self.x = 5

        @cached_property
        def a(self):
            return self.x + 1

    obj = A()
    obj.a
    # Changing attribute on which cached_property is dependent
    obj.x = 10
    assert obj.a != A().a
    del obj.a
    # Changing attribute on which cached_property is dependent
    obj.x = 15
    assert obj.a == A().a.result()
    # Forcing garbage collection
    del obj, A

