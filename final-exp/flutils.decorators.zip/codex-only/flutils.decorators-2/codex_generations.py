

# Generated at 2022-06-23 17:55:58.747907
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""

    class Foo:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @staticmethod
        def z():
            return "Hello world"

    foo = Foo()
    assert foo.y == 6

    foo.x = 10  # noinspection PyAttributeOutsideInit
    assert foo.y == 6

    del foo.y
    assert foo.y == 11

    assert Foo.z() == "Hello world"

    with pytest.raises(AttributeError):
        Foo.y

# Generated at 2022-06-23 17:56:03.165068
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Class:
        def __init__(self, *args, **kwargs):
            pass
        @cached_property
        def prop(self):
            return 5
    obj = Class()
    assert asyncio.iscoroutinefunction(obj.prop)

# Generated at 2022-06-23 17:56:05.813013
# Unit test for constructor of class cached_property
def test_cached_property():
    class A:

        def __init__(self):
            self.x = 5

        def __get__(self, obj, cls):
            if obj is None:
                return self

        @cached_property
        def y(self):
            return self.x + 10

    obj = A()
    assert obj.y == 15

# Generated at 2022-06-23 17:56:10.389576
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    '''
    Test caching a property that is not a coroutine
    '''
    class Test(object):
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    obj = Test(5)
    assert obj.y == 6



# Generated at 2022-06-23 17:56:16.014746
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 17:56:21.587879
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test the constructor of class cached_property"""

    class Foo(object):
        """Class Foo"""

        def __init__(self, x):
            """Create a new Foo"""
            self.x = x

        @cached_property
        def y(self):
            """Docstring for y"""
            return self.x ** 2

    foo = Foo(5)
    assert foo.y == 25
    assert foo.__doc__ == 'Class Foo'
    assert Foo.__dict__['y'].__doc__ == 'Docstring for y'

# Generated at 2022-06-23 17:56:29.173424
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property.

    :return: True if successful.
    :rtype: bool
    """
    # noinspection PyPep8Naming
    class TestCachedProperty:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestCachedProperty()
    assert obj.y == 6
    return True



# Generated at 2022-06-23 17:56:37.480939
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from typing import Generator

    class MyClass:
        count: int = 0

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            self.count += 1
            return self.count

        @cached_property
        def z(self):
            self.count += 1
            return self.count

    obj = MyClass()
    assert obj.x == 5
    assert obj.y == 1
    assert obj.z == 2
    assert obj.y == 1
    assert obj.z == 2
    assert obj.count == 2

    # Delete
    del obj.y
    assert obj.y == 3
    assert obj.count == 3

    # Ensure the descriptor returns the proper class
    assert cached_property.__get__(None, MyClass) is cached_property

# Generated at 2022-06-23 17:56:47.223879
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import sys
    import os
    import pkg_resources

    os.chdir(pkg_resources.resource_filename(__name__, ''))
    sys.path.append('..')
    from utils import make_doctest, get_args
    argv = get_args()

# Generated at 2022-06-23 17:56:53.012236
# Unit test for constructor of class cached_property
def test_cached_property():
    class Obj:
        __slots__ = ('__dict__',)
        __dict__ = {'_property': cached_property(lambda self: self._property)}

        def __init__(self):
            self._property = 'test'

    obj = Obj()
    assert obj._property == 'test'
    obj._property = 'override'
    assert obj._property == 'override'
    del obj._property
    assert obj._property == 'test'


# Generated at 2022-06-23 17:56:55.107058
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property."""
    with pytest.raises(TypeError):
        cached_property()

# Generated at 2022-06-23 17:56:58.822401
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    def test_y():
        obj = MyClass()
        return obj.y

    assert test_y() == 6

# Generated at 2022-06-23 17:57:10.998305
# Unit test for constructor of class cached_property
def test_cached_property():  # pragma: no cover
    from unittest import TestCase
    from copy import copy

    class MyClass(TestCase):

        @cached_property
        def x(self):
            return "foo"

        @cached_property
        @property
        def y(self):
            return "bar"

        def z(self):
            return "baz"

        z = cached_property(z)

    o = MyClass()
    self = o
    assert o.x == "foo"
    assert o.x == "foo"
    assert o.y == "bar"
    assert o.y == "bar"
    assert o.z == "baz"
    assert o.z == "baz"
    assert "x" in o.__dict__
    assert "y" in o.__dict__

# Generated at 2022-06-23 17:57:18.086782
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method ``__get__`` of class :class:`cached_property`."""
    def fn():
        return 5

    cp = cached_property(fn)

    class MyClass:
        pass

    obj = MyClass()

    # obj is not None
    assert cp.__get__(obj, MyClass) == 5
    # obj is None
    assert cp.__get__(None, MyClass) == cp
    # obj is not None
    assert cp.__get__(obj, MyClass) == 5

# Generated at 2022-06-23 17:57:23.151444
# Unit test for constructor of class cached_property
def test_cached_property():

    # noinspection PyUnusedLocal
    class MyClass:

        def __init__(self):
            self.x = 5

        _y = cached_property(lambda self: self.x + 1)

    obj = MyClass()
    assert obj._y == 6



# Generated at 2022-06-23 17:57:26.825144
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 17:57:30.918622
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    def func(obj):
        return "FlUtils"

    obj = object()
    property = cached_property(func)
    assert property.__doc__ == func.__doc__
    assert isinstance(property.__get__(obj), str)


test_cached_property___get__()

# Generated at 2022-06-23 17:57:34.520194
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class TestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    testClass = TestClass()
    testClass.x = 8
    testClass.y
    assert testClass.x == 8
    assert testClass.y == 9

# Generated at 2022-06-23 17:57:38.092051
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 17:57:40.739552
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property
    """
    import doctest

    results = doctest.testmod()
    assert results.failed == 0

# Generated at 2022-06-23 17:57:45.425614
# Unit test for constructor of class cached_property
def test_cached_property():

    class TestClass:
        def __init__(self, x=0):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    t = TestClass()
    assert t.y == 1

    t = TestClass(10)
    assert t.y == 11

    assert t.__dict__['y'] == 11

    del t.y
    assert 'y' not in t.__dict__



# Generated at 2022-06-23 17:57:50.360539
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6



# Generated at 2022-06-23 17:57:58.512955
# Unit test for constructor of class cached_property
def test_cached_property():
    obj = TestClass()

    assert TestClass.cached_property_cached is TestClass.cached_property
    assert TestClass.cached_property_not_cached is TestClass.cached_property_not_cached
    assert TestClass.cached_property_coroutine is TestClass.cached_property_coroutine
    assert TestClass.cached_property_coroutine_not_cached is TestClass.cached_property_coroutine_not_cached

    # Check that the function was called
    assert obj.cached_property > 1
    assert not hasattr(obj, 'cached_property_not_cached')
    assert not hasattr(obj, 'cached_property_coroutine')
    assert not hasattr(obj, 'cached_property_coroutine_not_cached')


# Unit test

# Generated at 2022-06-23 17:58:02.572359
# Unit test for constructor of class cached_property
def test_cached_property():
    class Foo:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    foo = Foo()
    assert foo.y == 6



# Generated at 2022-06-23 17:58:07.256236
# Unit test for constructor of class cached_property
def test_cached_property():
    """ Unit test for constructor of class cached_property.
    """

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 17:58:17.995144
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from inspect import isfunction, isasyncfunction, iscoroutinefunction

    class TestClass:

        def __init__(self):
            self.x = 5

            # noinspection PyUnusedLocal
        @cached_property
        def y(self):
            pass

        @cached_property
        async def z(self):
            pass

    obj = TestClass()

    # y is a property
    assert not isfunction(obj.y)
    assert not isasyncfunction(obj.y)
    assert not iscoroutinefunction(obj.y)

    # z is a coroutine
    assert not isfunction(obj.z)
    assert not isasyncfunction(obj.z)
    assert iscoroutinefunction(obj.z)

# Generated at 2022-06-23 17:58:18.598395
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass

# Generated at 2022-06-23 17:58:21.895896
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property."""
    assert hasattr(cached_property, '__doc__')
    assert cached_property.__doc__ is not None



# Generated at 2022-06-23 17:58:26.907679
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class A:
        def __init__(self, cls=None):
            if cls is None:
                cls = 1
            self.cls = cls

        @cached_property
        def inc(self):
            return self.cls + 2

    obj = A(7)
    assert obj.inc == 9


# Generated at 2022-06-23 17:58:35.984735
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""

    # Create object to test with
    class TestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Get a test object
    obj = TestClass()

    # Verify that iscoroutinefunction is False when func does not coroutine
    # function
    cached_property_instance = obj.y
    assert not asyncio.iscoroutinefunction(cached_property_instance.func)

    # Create a coroutine function
    async def test_coroutine():
        pass

    # Create a class with a cached_property that is a coroutine function
    class CoroutineTestClass:

        def __init__(self):
            self.x = 5


# Generated at 2022-06-23 17:58:38.591982
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest

    obj_istype_CachedPropertyClass = CachedPropertyClass()

    assert isinstance(obj_istype_CachedPropertyClass.__get__, cached_property)



# Generated at 2022-06-23 17:58:44.273107
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from datetime import datetime
    from flutils.decorators import cached_property


    class TestClass:

        @cached_property
        def get_datetime(self):
            return datetime.now()


    test_obj = TestClass()
    assert test_obj.get_datetime == datetime.now()
    assert TestClass.get_datetime == TestClass.get_datetime



# Generated at 2022-06-23 17:58:47.190911
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6

# Generated at 2022-06-23 17:58:51.259537
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 17:58:57.500219
# Unit test for constructor of class cached_property
def test_cached_property():
    # -------------------------------------------------------------------------
    # Arrange
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    # Act
    y = obj.y

    # Assert
    assert y == 6


# Generated at 2022-06-23 17:59:00.752872
# Unit test for constructor of class cached_property
def test_cached_property():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 17:59:08.795342
# Unit test for constructor of class cached_property
def test_cached_property():
    #
    # class CachedPropertyTestClass(object):
    #     def __init__(self, x):
    #         self.x = x
    #
    #     @cached_property
    #     def y(self):
    #         return self.x + 1
    #
    # obj = CachedPropertyTestClass(5)
    # assert obj.y == 6
    # obj.x = 10
    # assert obj.y == 6  # cached value not updated
    assert True


# Generated at 2022-06-23 17:59:12.173652
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class Foo:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Foo()
    obj.y
    assert obj.__dict__ == {'x': 5, 'y': 6}



# Generated at 2022-06-23 17:59:15.401958
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.y == 6



# Generated at 2022-06-23 17:59:19.428686
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property


    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1


    obj = MyClass()
    assert obj.y == 6


if __name__ == '__main__':
    test_cached_property()

# Generated at 2022-06-23 17:59:21.884631
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Tests constructor of the class ``cached_property``.
    """

    obj = object()
    prop = cached_property(obj)
    assert prop.func == obj
    assert prop.__doc__ is None



# Generated at 2022-06-23 17:59:28.323924
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():  # noqa: D103
    import doctest  # noqa: D401
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.y == 6



# Generated at 2022-06-23 17:59:35.797454
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""
    import unittest
    import sys

    class TestCachedProperty___get__(unittest.TestCase):
        """Unit test class for method __get__ of class cached_property."""

        @staticmethod
        def test_with_sync_method():
            """Tests execution with a synchronous method."""

            class MyClass:
                """A test class for testing the method __get__ of class
                cached_property."""

                def __init__(self):
                    self.x = 5

                @cached_property
                def y(self):
                    """A test method for testing the method __get__ of
                    class cached_property."""
                    return self.x + 1

            obj = MyClass()

# Generated at 2022-06-23 17:59:47.904178
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():  # noqa: D103
    import pytest  # noqa: F401

    class TestCacheProperty:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestCacheProperty()
    obj.y
    assert obj.x == 5  # check that we have the original x value
    assert obj.y == 6  # check that we have the original y value

    @cached_property
    def z():
        return 42

    # caching the result
    assert z == 42  # check that we get the original result
    del z
    z
    z = 99  # noqa: F841
    assert z == 99  # check that we get the modified result
    del z
    z = 99  # noqa: F

# Generated at 2022-06-23 17:59:50.048822
# Unit test for constructor of class cached_property
def test_cached_property():
    cprop = cached_property(lambda x: x * 2)
    assert cprop.func(5) == 10



# Generated at 2022-06-23 17:59:53.604659
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class ExampleClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert ExampleClass().y == 6


# Generated at 2022-06-23 18:00:05.409064
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test :obj:`~flutils.decorators.cached_property`"""
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6
    assert hasattr(obj, 'y')
    assert obj.y == 6
    assert hasattr(obj, 'y')
    del obj.y
    assert not hasattr(obj, 'y')

    obj2 = MyClass()

    assert not hasattr(obj2, 'y')
    assert obj2.y == 6
    assert hasattr(obj2, 'y')
    assert obj2.y == 6
    assert hasattr(obj2, 'y')
    del obj2.y


# Generated at 2022-06-23 18:00:14.094725
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Test that that `self.func` is only called once, and is called with the
    # right `self` instance when expected
    inner_args = []
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            inner_args.append(self)
            return self.x + 1

    obj = MyClass()
    obj.y
    assert inner_args == [obj] and obj.y == 6  # noqa

    obj2 = MyClass()
    obj2.y
    assert inner_args == [obj, obj2] and obj2.y == 6  # noqa



# Generated at 2022-06-23 18:00:17.685211
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property
    assert cached_property.__doc__


# Generated at 2022-06-23 18:00:25.638072
# Unit test for constructor of class cached_property
def test_cached_property():
    from types import MethodType
    from functools import partial
    from unittest import mock

    class _Parent:
        def __init__(self):
            self.parent_attr = 1

        def _parent_method(self):
            return self.parent_attr + 1

        @property
        def _parent_property(self):
            return self.parent_attr + 2

    class _Test:
        def __init__(self):
            self.parent = _Parent()
            self.attr = 2
            self.method = mock.MagicMock()
            self.property = mock.MagicMock(spec=property)

        def _descriptor(self):
            return self.attr + 3

        def _partial(self):
            return partial(lambda x: x, self.attr + 4)


# Generated at 2022-06-23 18:00:30.610555
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Tests :meth:`cached_property.__get__`."""

    class TheClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TheClass()
    assert obj.y == 6
    obj.x = 100
    assert obj.y == 6
    del obj.y
    assert obj.y == 101



# Generated at 2022-06-23 18:00:38.257406
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    print('test_cached_property___get__')

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    # noinspection PyUnresolvedReferences
    assert obj.y == 6
    del obj.y
    # noinspection PyUnresolvedReferences
    assert obj.y == 6



# Generated at 2022-06-23 18:00:44.304167
# Unit test for constructor of class cached_property
def test_cached_property():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert not hasattr(obj, 'y')
    r = obj.y
    assert obj.__dict__['y'] == r
    assert obj.y == r

# Generated at 2022-06-23 18:00:49.811878
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    async def coro():
        return 5

    # test get from class
    assert cached_property.__get__(None, object) == cached_property
    # test non-coro get from instance
    assert cached_property.__get__(MyClass(), type) == 5
    # test coro get from instance
    assert asyncio.iscoroutinefunction(
        cached_property.__get__(MyClass(), type)
    )



# Generated at 2022-06-23 18:00:59.537935
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # noinspection PyPackageRequirements
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6
    assert isinstance(obj.y, int)

    obj.__dict__["y"] = 5
    assert obj.y == 5

    # Deleting the attribute resets the property
    del obj.__dict__["y"]
    assert obj.y == 6



# Generated at 2022-06-23 18:01:00.141199
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property

# Generated at 2022-06-23 18:01:11.995626
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    async def async_method(obj):
        await asyncio.sleep(1.5)

    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return 1

        @cached_property
        def coroutine(self):
            return async_method(self)

        @cached_property
        def coroutine_property(self):
            return 1

    obj = TestClass()

    assert obj.y == 6
    assert obj.z == 1

    # Check behavior of deletion
    del obj.y
    assert obj.y == 6

    assert not asyncio.iscoroutine(obj.coroutine)

# Generated at 2022-06-23 18:01:20.211254
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):

            self.x = 5

        @cached_property
        def y(self):

            return self.x + 1

    obj = MyClass()
    a = obj.y
    b = obj.y
    assert a == b
    assert a == 6
    assert isinstance(a, int)
    assert isinstance(b, int)

# Generated at 2022-06-23 18:01:25.030539
# Unit test for constructor of class cached_property
def test_cached_property():
    class A:
        def __init__(self, f):
            self.f = f

        @cached_property
        def foo(self): return self.f

        bar = cached_property(lambda self: self.f)

    a = A(5)
    assert a.foo == 5
    assert a.bar == 5

    # test cache refresh
    a.foo = 7
    a.bar = 8
    assert a.foo == 7
    assert a.bar == 8

    del a.foo
    del a.bar
    assert a.foo == 5
    assert a.bar == 5


test_cached_property()

# Generated at 2022-06-23 18:01:29.653125
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 18:01:32.749097
# Unit test for constructor of class cached_property
def test_cached_property():
    with pytest.raises(RuntimeError):
        class TestClass_3:
            def test_func():
                raise RuntimeError("TestException")
            t = cached_property(test_func)
    assert True

# Generated at 2022-06-23 18:01:41.264215
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """This unit test covers the case that value is the future returned by
    the method coroutine.

    Also covers the case that the future has not completed.

    """

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return asyncio.ensure_future(self._coroutine())

        async def _coroutine(self):
            return self.x + 1

    obj = MyClass()
    future = obj.y

    if sys.version_info >= (3, 7):
        assert future is obj.y
    else:
        assert future == obj.y

# Generated at 2022-06-23 18:01:46.900363
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 18:01:51.852952
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property.
    """

    class TestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.y == 6
    assert obj.x == 5

    obj.x = 7
    assert obj.x == 7
    assert obj.y == 6

# Generated at 2022-06-23 18:01:55.598968
# Unit test for constructor of class cached_property
def test_cached_property():
    def test_func(self):
        return 1

    attr = cached_property(test_func)
    assert attr.__doc__ == test_func.__doc__
    assert attr.func is test_func



# Generated at 2022-06-23 18:01:59.898379
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    # noinspection PyPep8Naming
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:02:02.928159
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # TODO: Create unit test for method __get__ of class cached_property
    raise Exception('Not implemented')



# Generated at 2022-06-23 18:02:11.802028
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Test the constructor of cached_property.
    """

    async def my_property(obj):
        await asyncio.sleep(0.01)
        return 5

    class Test():

        @cached_property
        def prop(self):
            return 5

        @cached_property
        async def async_prop(self):
            return await my_property(self)

    test = Test()
    assert test.prop == 5
    assert asyncio.iscoroutine(test.async_prop)


# Generated at 2022-06-23 18:02:16.172367
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 18:02:25.415341
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test for cached_property.__get__."""

    class MyClass:
        pass

    my_obj = MyClass()
    my_obj.y = False

    class MyClass:

        def __init__(self, y=False):
            self.y = y

        def _y(self):
            return self.y

        @cached_property
        def y(self):
            return self._y()

    my_obj = MyClass()
    assert isinstance(my_obj.y, bool)
    assert my_obj.y is False

    my_obj = MyClass(y=True)
    assert isinstance(my_obj.y, bool)
    assert my_obj.y is True

    my_obj.y = False



# Generated at 2022-06-23 18:02:31.562586
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property.
    """

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    print(obj.y)


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-23 18:02:41.280597
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import unittest
    from unittest import mock

    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    test_class = MyClass()

    class Test_cached_property___get__(unittest.TestCase):

        @mock.patch('builtins.print')
        def test_with_obj(self, mock_print):
            test_class.y
            self.assertFalse(mock_print.called)
            self.assertEqual(test_class.y, 6)

        def test_without_obj(self):
            self.assertTrue(isinstance(MyClass.y, cached_property))

    return None



# Generated at 2022-06-23 18:02:47.326324
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Unit test for constructor of class cached_property.

    :return: None
    :rtype: None
    """
    # noinspection PyUnusedLocal
    class myclass:
        def __init__(self):
            self.a = 5

        @cached_property
        def b(self):
            return self.a + 1

    obj = myclass()
    assert obj.b == 6, "Nope."

# Generated at 2022-06-23 18:02:56.003241
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class CachedPropertyClass:
        # noinspection PyUnusedLocal
        def __init__(self):
            # Set by __get__ method
            self.called = False

        @cached_property
        def cached_property(self):
            self.called = True
            return None

    # Call method __get__ once
    obj = CachedPropertyClass()
    assert not obj.called
    assert obj.cached_property is None
    assert obj.called

    # Call method __get__ again
    obj = CachedPropertyClass()
    assert not obj.called
    assert obj.cached_property is None
    assert not obj.called


# Generated at 2022-06-23 18:03:04.704525
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from io import StringIO
    from unittest import mock

    from flutils.decorators import cached_property

    class AClass:
        def __init__(self, value: str):
            self.value = value

        @cached_property
        def fget(self):
            return self.value

    class ASubClass(AClass):
        pass

    class AClassWithMagic:
        def __init__(self, value: str):
            self.value = value

        def __get__(self, obj: Any, cls):
            return self.value

    class AClassWithClassMeth:
        def __init__(self, value: str):
            self.value = value

        @classmethod
        def fget(cls):
            return 'Class method was called'


# Generated at 2022-06-23 18:03:13.882396
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method cached_property.__get__

    Args:
        None

    Returns:
        None

    """
    import unittest

    class Class(object):

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            print("evaluating...")
            return self.x + 2

    class TestCachedProperty(unittest.TestCase):

        def test__get__(self):
            instance = Class()
            assert instance.y == 6
            assert hasattr(instance, "y")
            assert "y" in instance.__dict__
            assert instance.y == 6
            assert isinstance(instance.y, int)

# Generated at 2022-06-23 18:03:25.006678
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Test Python 3.8+
    if not hasattr(functools, 'cached_property'):
        return

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    assert obj.__dict__ == {'x': 5, 'y': 6}

    # Test Python 3.6 and 3.7
    if hasattr(functools, 'cached_property'):
        del(functools.cached_property)
        if hasattr(functools, 'cached_property'):
            raise RuntimeError("functools.cached_property not deleted.")

    class MyClass:

        def __init__(self):
            self

# Generated at 2022-06-23 18:03:36.168374
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import call, patch

    from .decorators import cached_property

    # Test __get__ for async function. This was an issue on Python 3.6.
    # Minimal, Complete, and Verifiable Example
    # https://stackoverflow.com/questions/54877299

    class TestCase:
        def __init__(self):
            self.x = 5

        @cached_property
        @asyncio.coroutine
        def y(self):
            return self.x + 1

    with patch("flutils.decorators.asyncio.ensure_future") as mock_ensure_future:
        obj = TestCase()
        obj.y
        assert mock_ensure_future.mock_calls == [
            call(obj.y)
        ]

# Generated at 2022-06-23 18:03:43.249239
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """ Test the __get__ method of cached_property class. Unit test """

    from unittest.mock import patch
    # noinspection PyunusedLocal
    from flutils import misc

    class Coro:

        def __init__(self):
            self.x = 0

        @cached_property
        async def y(self):
            return self.x + 1

    with patch('flutils.decorators.asyncio.iscoroutinefunction', return_value=False):
        coro = Coro()
        assert coro.y == 1
        coro.x = 1
        assert coro.y == 1

    with patch('flutils.decorators.asyncio.iscoroutinefunction', return_value=True):
        coro = Coro()
        assert coro.y == 1
        coro

# Generated at 2022-06-23 18:03:51.416721
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import asyncio
    import inspect

    # Create cached_property class
    class cached_property_test:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Create object of cached_property class
    obj = cached_property_test()

    # Test __get__ of class cached_property
    # Instantiate async
    async def instantiate_async():
        return cached_property(lambda: None).__get__(obj, type(obj))

    # Await instantiate
    assert inspect.iscoroutine(instantiate_async())
    assert await instantiate_async() is None
    assert isinstance(instantiate_async(), asyncio.futures.Future)

    # Test __get__ of class cached

# Generated at 2022-06-23 18:04:01.886032
# Unit test for constructor of class cached_property
def test_cached_property():
    import sys
    import asyncio
    import functools
    import unittest

    from flutils.decorators import cached_property

    MajorVersion = sys.version_info[0]
    MinorVersion = sys.version_info[1]
    if MajorVersion >= 3:
        if MinorVersion >= 8:
            has_cached_property = True
        else:
            has_cached_property = False
    else:
        has_cached_property = False

    @cached_property
    def _cached_property_class_cached_property():
        return 'cached_property'

    def _cached_property_async_cached_property():
        async def _get_value(obj):
            value = await asyncio.sleep(1)
            return value

        return _get_value


# Generated at 2022-06-23 18:04:04.450715
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test method __get__ of cached_property"""
    import pytest

    # noinspection PyProtectedMember
    with pytest.raises(AttributeError):
        # noinspection PyProtectedMember
        cached_property.__get__(None, object)



# Generated at 2022-06-23 18:04:10.503328
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 18:04:21.992611
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    def run_test(x):
        # type: (Any) -> Any
        return x

    c = cached_property(run_test)
    assert c.__get__(123, None) == 123

    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.y == 6

    def run_test_async(x):
        # type: (Any) -> Any
        yield from asyncio.sleep(0)
        return x

    c = cached_property(run_test_async)
    assert asyncio.iscoroutinefunction(c.__get__(123, None)) is True


# Generated at 2022-06-23 18:04:23.843048
# Unit test for constructor of class cached_property
def test_cached_property():
    myobj = MyClass2()
    assert myobj.z == 8
    assert myobj.z == 8



# Generated at 2022-06-23 18:04:28.136838
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    def test_regular_function(obj):
        return obj.x + 1

    class MyClass:
        def __init__(self):
            self.x = 5

    obj = MyClass()
    test = cached_property(test_regular_function)
    assert test.__get__(obj, MyClass) == 6



# Generated at 2022-06-23 18:04:30.151570
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property
    
    :return:
    
    """
    assert cached_property

# Generated at 2022-06-23 18:04:35.429592
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property

    """
    class TestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:04:46.621093
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class NoTypeHints:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class TypeHints:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self) -> int:
            return self.x + 1

    for cls in ('NoTypeHints', 'TypeHints'):
        cls = locals()[cls]
        obj = cls()
        assert obj.y == 6
        assert isinstance(obj.__dict__[cls.y.func.__name__], int)
        assert obj.y == 6

    obj.__dict__.pop(cls.y.func.__name__)
    assert obj.y == 6

# Generated at 2022-06-23 18:04:50.140284
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6



# Generated at 2022-06-23 18:04:56.668672
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class Foo:

        @cached_property
        def test(self):
            return 1
    foo = Foo()

    try:
        assert foo.test == 1
    except Exception as exc:
        pytest.fail(f'Unexpected exception {exc}')



# Generated at 2022-06-23 18:05:06.253543
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest import TestCase
    from pprint import pprint
    from timeit import timeit

    class cp:
        def __init__(self):
            self.data1 = 'd1'
            self.data2 = 'd2'

        @cached_property
        def big_data(self):
            return 'data0'*500

        @cached_property
        def prop1(self):
            return self.data1 + self.data2

        @cached_property
        def prop2(self):
            return self.data2

    o = cp()
    # noinspection PyPep8Naming
    C = TestCase('__init__')
    # noinspection PyPep8Naming
    C.assertEqual(o._cp__doc__, 'None')
    C.assertE

# Generated at 2022-06-23 18:05:09.189418
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method ``__get__`` of class ``cached_property``."""
    class Foo:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Foo()
    assert obj.y == 6

# Generated at 2022-06-23 18:05:16.970265
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test cached_property.__get__"""
    import pytest

    class MyClass:
        """MyClass"""

        def __init__(self):
            """__init__"""
            self.x = 5

        @cached_property
        def y(self):
            """y"""
            return self.x + 1

    obj = MyClass()

    with pytest.raises(AttributeError) as e:
        obj.z

    assert e.value.args[0] == "'MyClass' object has no attribute 'z'"

    assert obj.y == 6

    assert obj.y == 6



# Generated at 2022-06-23 18:05:19.040749
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass

# Generated at 2022-06-23 18:05:24.881599
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Setup for test
    from flutils.decorators import cached_property

    class MyClass:

        @cached_property
        def myprop(self):
            return 'a string'

    # Execute the test
    myinst = MyClass()
    myinst.myprop

    # Verify the results
    assert myinst.myprop == 'a string', 'Value is wrong'



# Generated at 2022-06-23 18:05:33.757611
# Unit test for constructor of class cached_property
def test_cached_property():
    from copy import copy
    from functools import partial

    from flutils.decorators import cached_property

    def _raise_del_attr_error(self):
        raise AttributeError

    def _collect_called_func_names(called_func_names):
        def _collect(func):
            called_func_names.append(func.__name__)
            return func

        return _collect

    class _BaseClass:
        def __init__(self) -> None:
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class _SubClass(_BaseClass):
        def __init__(self) -> None:
            super(_SubClass, self).__init__()


# Generated at 2022-06-23 18:05:43.515342
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test Class :py:class:`flutils.decorators.cached_property`.

    Test setup:

    - Create instance of Class :py:class:`flutils.decorators.cached_property`.

    - Test object type is instance of Class
      :py:class:`flutils.decorators.cached_property`.

    Test asserts:

    - Assert object is instance of Class
      :py:class:`flutils.decorators.cached_property`.

    :return: No return.
    :rtype: None

    .. note::
        Refer to :ref:`Tests <tests>` section of documentation for information
        on how to run unit tests.

    """
    def func(obj):
        obj.__doc__

    object = cached_property(func)


# Generated at 2022-06-23 18:05:46.562395
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class TestClass:

        def __init__(self):
            self.x = 0

        @cached_property
        def y(self):
            return self.x + 1

    i = TestClass()
    assert i.y == 1
    i.x = 5
    assert i.y == 1

# Generated at 2022-06-23 18:05:53.890253
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property

    """
    class MyClass:

        def __init__(self):
            self.x = 5

        # noinspection PyUnusedLocal
        @cached_property
        def y(self):
            """Documentation string"""

            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__doc__ == "Documentation string"
    assert obj.__dict__["y"] == 6

