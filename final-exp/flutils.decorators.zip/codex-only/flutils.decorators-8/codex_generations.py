

# Generated at 2022-06-23 17:55:47.258670
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass



# Generated at 2022-06-23 17:55:53.280093
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    obj.x = 10
    assert obj.y == 6


# Generated at 2022-06-23 17:55:58.580820
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:
        """MyClass"""

        def __init__(self):
            """Initialise"""
            self.x = 5

        @cached_property
        def y(self):
            """Get y"""
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6

# Generated at 2022-06-23 17:56:09.747148
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Simple get test
    class Foo:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x

    foo = Foo(5)
    assert foo.y == 5

    # Ensure future gets set properly for async
    class Foo:
        def __init__(self, x):
            self.x = x

        @cached_property
        async def y(self):
            return self.x

    foo = Foo(5)
    assert foo.y.result() == 5

    # Ensure future gets set properly for coroutine
    class Foo:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            yield self.x

    foo = Foo(5)

# Generated at 2022-06-23 17:56:15.813354
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit tests for :obj:`cached_property`."""

    # Unit test for constructor of class cached_property.
    class Sample:

        def method(self):
            return 1

    s = Sample()
    cp = cached_property(s.method)
    assert type(cp) is cached_property, f"Type is {type(cp)}"



# Generated at 2022-06-23 17:56:19.368372
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 17:56:24.148793
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    assert cached_property.__get__(None) == cached_property

    assert cached_property.__get__(None, object) == cached_property

    class Obj:
        """Blank object"""

    obj = Obj()

    def func():
        """A simple test function"""
        return 5

    func_cached_prop = cached_property(func)
    result = func_cached_prop.__get__(obj)
    assert isinstance(result, int)
    assert result == 5
    assert func_cached_prop.__doc__ == "A simple test function"



# Generated at 2022-06-23 17:56:34.384824
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property

    """
    import unittest

    class TestCachedProperty(unittest.TestCase):

        class MyClass:

            def __init__(self):
                self.x = 5

            @cached_property
            def y(self):
                return self.x + 1

        def test_return_value(self):
            """Test cached_property return value

            """
            obj = self.MyClass()
            self.assertEqual(obj.y, 6)

    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(TestCachedProperty))
    return suite


if __name__ == '__main__':
    import unittest

    suite = test_cached_property___get__()
    un

# Generated at 2022-06-23 17:56:41.029964
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestClass:
        def __init__(self, value):
            self._value = value

        @cached_property
        def value(self):
            return self._value

    obj = TestClass(1)

    assert obj.value == 1
    assert obj.value == 1
    obj._value = 2
    assert obj.value == 2
    assert obj.value == 2
    obj.value = 3
    assert obj.value == 3
    assert obj.value == 3

# Generated at 2022-06-23 17:56:45.783666
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""

    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self, txt: str):
            self.x = txt

        @cached_property
        def y(self):
            return self.x + ' bar'

    obj = MyClass('foo')
    print(obj.y)



# Generated at 2022-06-23 17:56:55.758441
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    try:
        import uvloop
    except ImportError:
        pass
    else:
        asyncio.set_event_loop_policy(uvloop.EventLoopPolicy())

    import pytest

    class MyClass:
        def __init__(self, value):
            self.value = value

        def __repr__(self):
            return f"{self.__class__.__name__}({self.value!r})"

        @cached_property
        def twice(self):
            return self.value * 2

        @cached_property
        async def async_twice(self):
            await asyncio.sleep(0)
            return self.value * 2

    def test_get_cached_property():
        obj = MyClass(5)
        assert "twice" not in obj.__dict__


# Generated at 2022-06-23 17:57:02.212886
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import TestCase, mock

    def func(self):
        return 42

    class Test(TestCase):
        pass

    obj = mock.Mock()
    obj.__dict__ = {'obj': obj}
    obj.__class__ = Test

    assert cached_property(func).__get__(obj) == 42
    assert obj.obj.__dict__['func'] == 42



# Generated at 2022-06-23 17:57:03.211032
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    assert isinstance


# Generated at 2022-06-23 17:57:10.126082
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Unit test for the constructor of the class ``cached_property``.

    :return: ``None``.
    """
    from flutils.decorators import cached_property

    def func():
        pass

    cp = cached_property(func)
    assert isinstance(cp, cached_property)
    assert func.__doc__ == cp.__doc__
    assert func == cp.func


# Generated at 2022-06-23 17:57:14.361877
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 17:57:16.525337
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    _cached_property = cached_property(lambda self: self + 1)
    assert _cached_property.__get__(1, None) == 2

# Generated at 2022-06-23 17:57:27.596316
# Unit test for constructor of class cached_property
def test_cached_property():
    from asyncio import coroutine, Task

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        @coroutine
        def y(self):
            assert isinstance(asyncio.ensure_future(self.z()), Task)
            return self.x + 1

        @coroutine
        def z(self):
            return self.x + 2

    obj = MyClass()
    assert obj.y == 7
    assert obj.z() == 7

# Generated at 2022-06-23 17:57:36.847457
# Unit test for constructor of class cached_property
def test_cached_property():
    # _CtorTest is a simple class that has a few cached properties,
    # and a method that can delete those properties.
    class _CtorTest:
        # pylint: disable=too-few-public-methods

        def __init__(self):
            self._x = None
            self._y = None
            self._z = None

        @cached_property
        def x(self):
            return 17

        @cached_property
        def y(self):
            return 23

        @cached_property
        def z(self):
            return 42

        def del_x(self):
            del self.x

        def del_y(self):
            del self.y

        def del_z(self):
            del self.z

    # test standalone usage
    x = _CtorTest.x

# Generated at 2022-06-23 17:57:41.343254
# Unit test for constructor of class cached_property
def test_cached_property():  # pragma: nocover
    """Unit test for class :obj:`cached_property`."""
    from flutils.decorators import cached_property

    class TestClass:

        @cached_property
        def y(self):
            return self.x + 1

    test_object = TestClass()
    assert test_object.y == 6

# Generated at 2022-06-23 17:57:45.631583
# Unit test for constructor of class cached_property
def test_cached_property():

    # noinspection PyShadowingNames
    class Test:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert Test.y is cached_property

    obj = Test()
    assert isinstance(obj.y, int)
    assert obj.y == 6

    obj.x = 100
    assert obj.y == 6



# Generated at 2022-06-23 17:57:53.576875
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    def _do_test(obj, cls):
        if obj is None:
            assert cls is None
            assert isinstance(cls, cached_property)

    class _MyClass:
        @cached_property
        def x(self):
            return 1

    tests = [
        (_MyClass().x, None),
        (_MyClass(), _MyClass),
    ]

    for obj, cls in tests:
        _do_test(obj, cls)



# Generated at 2022-06-23 17:57:58.414494
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property
    """
    import pytest

    class MyClass:

        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass(5)
    assert obj.y == 6

    obj = MyClass(5)
    assert obj.y == 6

    with pytest.raises(KeyError):
        obj.__dict__.pop('y')
        obj.y

# Generated at 2022-06-23 17:58:02.467224
# Unit test for constructor of class cached_property
def test_cached_property():
    class Obj(object):
        def to_upper(self):
            return 's'

        uppercase = cached_property(to_upper)
        lowercase = cached_property(to_upper)

    assert Obj.uppercase is not Obj.lowercase

# Generated at 2022-06-23 17:58:07.118531
# Unit test for constructor of class cached_property
def test_cached_property():
    import pytest

    # noinspection PyPep8Naming
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 17:58:14.922928
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import mock

    def _mock_coro(*args, **kwargs):
        yield from args

    func = mock.Mock(spec=_mock_coro)
    obj = mock.Mock()
    cls = mock.Mock()
    cp = cached_property(func)
    cp.__doc__ = cp.func.__doc__ = 'test_cached_property___get__'

    # 1st call, get value via @cached_property._wrap_in_coroutine
    cp.__get__(obj, cls)
    assert set(obj.__dict__) == {func.__name__}
    assert obj.__dict__[func.__name__].__class__.__name__ == 'Future'
    assert obj.__dict__[func.__name__]._state

# Generated at 2022-06-23 17:58:20.443731
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class Foo:

        def __init__(self):
            self.x = 'xyz'

        @cached_property
        def y(self):
            return self.x + 'bar'

    obj = Foo()
    val = obj.y
    assert val == 'xyzbar'



# Generated at 2022-06-23 17:58:28.722814
# Unit test for constructor of class cached_property
def test_cached_property():
    from datetime import datetime
    from . import utils

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def now(self):
            return datetime.now()

    obj = MyClass()
    assert obj.y == 6
    time_now = obj.now
    assert time_now == utils.convert_utc_to_local(utils.now_utc())



# Generated at 2022-06-23 17:58:29.700227
# Unit test for constructor of class cached_property
def test_cached_property():
    assert callable(cached_property)

# Generated at 2022-06-23 17:58:37.997560
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest
    from sys import version_info
    from types import FunctionType
    from unittest.mock import MagicMock

    func = MagicMock(name='func', __doc__="test")
    # Instantiate cached_property
    decorator = cached_property(func)
    # Test __init__
    assert decorator.__doc__ == "test"
    assert decorator.func == func
    # Test __get__
    # Test __get__ with obj = None
    assert decorator.__get__(None, None) == decorator
    # Test __get__ with obj not None
    obj = MagicMock(name='obj', __dict__={})
    assert decorator.__get__(obj, None) == obj.__dict__[func.__name__]

# Generated at 2022-06-23 17:58:42.623893
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Foo:
        @cached_property
        def a(self):
            print("a")
            return "a"
    obj = Foo()
    assert obj.a == "a"
    assert obj.a == "a"
    obj.__dict__.pop("a")
    assert obj.a == "a"

# Generated at 2022-06-23 17:58:50.681514
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property
    from flutils.typelib import get_class_doc
    from flutils.misc import nop
    from types import MethodType

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    val = obj.y
    assert isinstance(val, int)
    assert val == 6

    # __doc__
    assert MyClass.y.__doc__ == ''

    # Make sure it is a method and not a property
    assert isinstance(MyClass.y, MethodType)

    # Make sure the cached property is a nop
    assert MyClass.y(obj) is obj.__dict__['y']

    # Make

# Generated at 2022-06-23 17:59:01.794148
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():  # TODO: abstract out test logic
    import unittest
    import gc
    import types

    class Test(object):
        """
        Tests the implementation of :obj:`cached_property` in class `Test`.
        """

        def __init__(self):
            self.lst = []
            self.foo_cnt = 0
            self.bar_cnt = 0
            self.baz_cnt = 0

        def calc_foo(self):
            self.lst.append("foo")
            self.foo_cnt += 1
            return self.foo_cnt

        def calc_bar(self):
            self.lst.append("bar")
            self.bar_cnt += 1
            return self.bar_cnt


# Generated at 2022-06-23 17:59:07.207104
# Unit test for constructor of class cached_property
def test_cached_property():
    class A:
        def __init__(self, value):
            self.value = value

        @cached_property
        def add(self):
            return self.value + '_added'

    a = A('value')
    assert a.add == 'value_added'



# Generated at 2022-06-23 17:59:10.253524
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Does the method __get__ of class cached_property work as expected?"""

    import asyncio
    import unittest
    from unittest.mock import Mock

    from flutils.decorators import cached_property



# Generated at 2022-06-23 17:59:14.155894
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1
    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 17:59:19.353811
# Unit test for constructor of class cached_property
def test_cached_property():  # pragma: no cover
    def test(a):
        return a * 2

    class Test:
        def __init__(self):
            self.a = 1

        @cached_property
        def b(self):
            return test(self.a)

    tt = Test()
    print(tt.b)
    print(tt.b)


if __name__ == "__main__":  # pragma: no cover
    test_cached_property()

# Generated at 2022-06-23 17:59:30.553445
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest
    from unittest import mock
    from .testutils import TestClass
    # Test parametrized fixtures
    from .testutils import class_decorator_parametrized_testcases
    # Define test input
    class_decorator_parametrized_testcases['get1'] = dict()
    class_decorator_parametrized_testcases['get1']['input'] = dict()

# Generated at 2022-06-23 17:59:37.909886
# Unit test for constructor of class cached_property
def test_cached_property():
    import pickle

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    assert obj.y == 6
    obj.x = 6
    assert obj.y == 6
    obj.y = 5
    assert obj.y != 6
    pickled = pickle.dumps(obj)
    new = pickle.loads(pickled)
    assert new.y == 6

# Generated at 2022-06-23 17:59:44.156008
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        # noinspection PyUnusedLocal
        def __init__(self):
            self.x = 5

        def s(self):
            return self.x

        @cached_property
        def c(self):
            return self.x

    myclass = MyClass()
    assert myclass.s() == myclass.c == 5

# Generated at 2022-06-23 17:59:50.139464
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Tests for `~flutils.decorators.cached_property`."""

    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 17:59:55.540904
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    # noinspection PyProtectedMember
    assert obj.__dict__['y'] == 6
    obj.x = 10
    assert obj.y == 6

# Generated at 2022-06-23 18:00:06.804381
# Unit test for constructor of class cached_property
def test_cached_property():

    # pylint: disable=too-few-public-methods
    class Test:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # pylint: disable=invalid-name
    obj = Test()
    assert obj.y == 6
    assert obj.__dict__['y'] == obj.y
    assert asyncio.iscoroutinefunction(obj.y) is False

    del obj.__dict__['y']
    assert 'y' not in obj.__dict__
    assert obj.y == 6
    assert obj.__dict__['y'] == obj.y

    # pylint: enable=too-few-public-methods
    # pylint: enable=invalid-name



# Generated at 2022-06-23 18:00:09.909421
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property


    class SomeClass(object):

        @cached_property
        def value(self):
            return 42

    assert SomeClass().value == 42



# Generated at 2022-06-23 18:00:13.137835
# Unit test for constructor of class cached_property
def test_cached_property():
    class Foo:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Foo()
    assert obj.y == 6

# Generated at 2022-06-23 18:00:17.300091
# Unit test for constructor of class cached_property
def test_cached_property():
    # noinspection PyUnusedLocal
    @cached_property
    def x(obj):
        return 'foo'



# Generated at 2022-06-23 18:00:21.095029
# Unit test for constructor of class cached_property
def test_cached_property():
    class A:
        def __init__(self, x=1):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 2

    a = A()
    assert a.y == 3
    a.x = 10
    assert a.y == 3

# Generated at 2022-06-23 18:00:25.901736
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    def g(obj):
        return 5

    c = cached_property(g)
    assert c.__get__({}, object) is c
    c2 = c.__get__({}, object)
    assert c2 is c



# Generated at 2022-06-23 18:00:29.394230
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class Class:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Class()
    assert obj.y == 6


test_cached_property___get__()

# Generated at 2022-06-23 18:00:32.075905
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property"""

    @cached_property
    def x():
        return 5

    assert x == 5

# Generated at 2022-06-23 18:00:34.143812
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property."""

    from flutils.decorators import cached_property

    @cached_property
    def x():
        return 5



# Generated at 2022-06-23 18:00:46.244783
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from random import random
    from asyncio import gather

    class Foo:

        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x

        @cached_property
        async def z(self):
            await asyncio.sleep(random())
            return self.x

    # Test property y (non-async)
    foo = Foo(5)
    x = foo.y
    y = foo.y
    assert x == 5
    assert y == 5
    assert foo.y == 5
    # Test property z (async)
    foo = Foo(5)
    x = foo.z
    y = foo.z
    assert x == foo.z
    assert y == foo.z
    assert foo.z == 5

# Generated at 2022-06-23 18:00:47.204191
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property.__init__

# Generated at 2022-06-23 18:00:50.649585
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            pass
    # _asyncio.Task object at 0x10a1a5c88
    cp = cached_property(MyClass().x)
    print(cp)


if __name__ == "__main__":
    test_cached_property()

# Generated at 2022-06-23 18:00:54.148451
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for cached_property"""

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    del obj.y
    assert not hasattr(obj, 'y')

# Generated at 2022-06-23 18:01:00.392430
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test class cached_property.

    Class cached_property is tested using a class.

    """

    # __get__(obj, cls)
    class TestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.y == 6
    assert obj.__class__.y is not None



# Generated at 2022-06-23 18:01:11.996180
# Unit test for constructor of class cached_property
def test_cached_property():
    from decimal import Decimal
    from unittest import TestCase
    from unittest.mock import Mock

    from flutils.decorators import cached_property
    from flutils.decorators import test_cached_property

    test_cached_property.__cached__ = None

    # noinspection PyPep8Naming
    class MyClass:
        def __init__(self, value):
            self.value = value

        @cached_property
        def cached_property(self):
            return self.value

    class TestCachedProperty(TestCase):
        def setUp(self):
            self.obj = MyClass(Decimal('1.1'))

        def test_cached_property_get(self):
            expected = Decimal('1.1')
            result = self.obj.cached

# Generated at 2022-06-23 18:01:19.550232
# Unit test for constructor of class cached_property
def test_cached_property():
    # noinspection PyUnusedLocal
    class Test(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    t = Test()
    assert t.y == 6


if __name__ == "__main__":
    test_cached_property()

# Generated at 2022-06-23 18:01:21.538227
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Instantiate the class
    obj = MyClass()

    # Call the method
    value = obj.y

    # Verify the value
    assert value == 6



# Generated at 2022-06-23 18:01:27.982293
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for `cached_property` class constructor.
    """

    @cached_property
    def x(self):
        """I am the docstring."""

    assert x.__doc__ == 'I am the docstring.'
    assert x.__name__ == 'x'


if __name__ == '__main__':
    print(test_cached_property())

# Generated at 2022-06-23 18:01:33.647186
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # Create the class for testing
    class TestClass:

        def __init__(self, x: int = 5):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    # Test the class
    obj = TestClass()
    assert obj.y == 6

if __name__ == '__main__':
    test_cached_property___get__()  # pragma: no cover

# Generated at 2022-06-23 18:01:37.474164
# Unit test for constructor of class cached_property
def test_cached_property():

    from .testing import MyClass

    obj = MyClass()

    assert obj.y == 6
    assert obj.y == 6

    # Delete the attribute
    del obj.y

    assert obj.y == 6
    assert obj.y == 6


# Generated at 2022-06-23 18:01:46.371595
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Basic test
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    # Basic test using asyncio
    class MyClass2:

        def __init__(self):
            self.x = 5

        @cached_property
        async def y(self):
            await asyncio.sleep(1)
            return self.x + 1

    event_loop = asyncio.get_event_loop()
    obj = MyClass2()
    assert event_loop.run_until_complete(obj.y) == 6
    assert event_loop.run_until_complete(obj.y) == 6

    # Test when return value is not a cor

# Generated at 2022-06-23 18:01:51.043507
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """This is a test docstring."""
            return self.x + 1
    obj = MyClass()
    assert obj.y == 6
    assert obj.__doc__ == None
    assert obj.y.__doc__ == "This is a test docstring."

# Generated at 2022-06-23 18:01:53.901182
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property.__doc__ is not None



# Generated at 2022-06-23 18:02:01.741765
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Test that a cached property is only executed once
    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """A cached property"""
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    # Test that a cached property is only executed once
    # Test that the __doc__ of the original function is used
    assert obj.y.__doc__ == MyClass.y.__func__.__doc__


if __name__ == '__main__':
    pytest.main([__file__])

# Generated at 2022-06-23 18:02:07.873594
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:02:14.479140
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self, x):
            self.x = x

        @cached_property
        def x2(self):
            return self.x * 2

    x = MyClass(5)
    assert x.x2 == 10
    x.x = 7
    assert x.x2 == 10


if __name__ == '__main__':
    import sys
    import pytest

    pytest.main([__file__] + sys.argv[1:])


# EOF

# Generated at 2022-06-23 18:02:24.138817
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    from sys import version_info
    from unittest import TestCase, main

    class TestObj:
        x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @asyncio.coroutine
        def z(self):
            yield from asyncio.sleep(1.0)
            return self.x + 2

        @cached_property
        def w(self):
            return self.x + 3

    obj = TestObj()

    class Test_cached_property___get__(TestCase):

        def test__cached_property___get__(self: Any) -> None:
            self.assertEqual(obj.y, 6)
            self.assertEqual(obj.__dict__['y'], 6)
            obj.x = 25
            self.assertE

# Generated at 2022-06-23 18:02:27.016231
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class Foo:

        @cached_property
        def f(self):
            return 5

    foo = Foo()
    assert foo.f == 5
    assert foo.__dict__['f'] == 5



# Generated at 2022-06-23 18:02:31.910175
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 18:02:36.568121
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:02:40.266598
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class Foo:

        @cached_property
        def foo(self):
            return 'FOO'

    foo = Foo()
    assert foo.foo == 'FOO'

# Generated at 2022-06-23 18:02:43.102112
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property.
    """

    class MClass:
        """
        """

        def __init__(self):
            pass

        @cached_property
        def prop(self):
            return 1

    obj = MClass()
    assert obj.prop == 1

# Generated at 2022-06-23 18:02:47.222819
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    def test_func():
        pass

    c = cached_property(test_func)
    assert c.func == test_func  # noqa: S101
    assert c.__doc__ == getattr(test_func, "__doc__")  # noqa: S101

# Generated at 2022-06-23 18:02:54.255391
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class A:
        def __init__(self):
            self.x = 0

        @cached_property
        def f(self):
            self.x += 1
            return self.x

    a = A()
    assert isinstance(a.f, int), 'f is not int'
    assert isinstance(a.f, int), 'f is not int'
    assert a.x == 1
    assert a.f == 1
    assert a.x == 1
    assert a.f == 1



# Generated at 2022-06-23 18:03:04.471179
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""

    class TestProperty:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x + 2

    obj = TestProperty()

    assert obj.y == 6
    assert obj.z == 7
    assert obj.__dict__["y"] == 6
    assert obj.__dict__["z"] == 7

    obj.x = 10
    assert obj.y == 11
    assert obj.z == 12
    assert obj.__dict__["y"] == 11
    assert obj.__dict__["z"] == 12

    delattr(obj, "y")

# Generated at 2022-06-23 18:03:09.005036
# Unit test for constructor of class cached_property
def test_cached_property(): # noqa
    import flutils
    cp = flutils.cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cp
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.x == 5

# EOF

# Generated at 2022-06-23 18:03:15.633904
# Unit test for constructor of class cached_property
def test_cached_property():
    # noinspection PyUnresolvedReferences
    """Unit test for constructor of class cached_property."""

    from unittest import TestCase, main

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class TestCachedPropertyConstructor(TestCase):

        def setUp(self):
            self.obj = MyClass()

        def test_cached_property_constructor(self):
            self.assertTrue(hasattr(self.obj, 'y'))
            self.assertIsNotNone(self.obj.y)

    main()



# Generated at 2022-06-23 18:03:20.706000
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property"""

    # Set up

    # Exercise and verify
    instance = cached_property("not a function")
    assert instance

    # Clean up

    # Return
    return


if __name__ == "__main__":
    test_cached_property()

# Generated at 2022-06-23 18:03:29.413905
# Unit test for constructor of class cached_property
def test_cached_property():

    # Test against a standard property
    class Test1:

        def __init__(self, a):
            self.a = a

        @property
        def val(self):
            """ A property """
            return self.a

    # Test with a cached property
    class Test2:

        def __init__(self, a):
            self.a = a

        @cached_property
        def val(self):
            """ A cached property """
            return self.a

    # Create objects
    t1 = Test1(1)
    t2 = Test2(2)

    # Test the attributes of the objects
    assert t1.a == 1
    assert t1.val == 1
    assert t2.a == 2
    assert t2.val == 2

    # Test the doc strings of the properties

# Generated at 2022-06-23 18:03:38.497633
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for cached_property.__get__"""

    class A:
        @cached_property
        def my_property(self):
            return 'success'

    # Test case: obj is None
    assert isinstance(A.my_property, cached_property)

    # Test case: obj is not None
    a1 = A()
    assert a1.my_property == 'success'
    a2 = A()
    assert a2.my_property == 'success'

    # Test case: obj is not None and an instance of
    # AsyncRunnerContext
    a1.my_property = 'changed'
    a2.my_property = 'changed'
    assert a1.my_property == 'changed'
    assert a2.my_property == 'changed'

# Generated at 2022-06-23 18:03:43.047145
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test cache_property constructor"""
    def func(self):
        return 5

    cache_prop = cached_property(func)
    assert cache_prop.__doc__ == func.__doc__



# Generated at 2022-06-23 18:03:51.294562
# Unit test for constructor of class cached_property
def test_cached_property():
    import pytest

    @cached_property
    def foo(self):
        return "foo"

    class A:
        foo = foo

    with pytest.raises(TypeError):
        foo(A(), "extra argument")

# Generated at 2022-06-23 18:04:01.817055
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Test the :obj:`flutils.decorators.cached_property` decorator.

    """

    class TestClass:
        @cached_property
        def normal_func(self):
            return 2

        @cached_property
        def coro_func(self):
            return asyncio.sleep(1)

    tc = TestClass()

    @asyncio.coroutine
    def run_tests():
        assert tc.normal_func == 2
        assert tc.normal_func == 2

        assert isinstance(tc.coro_func, asyncio.Future)
        yield from tc.coro_func
        assert isinstance(tc.coro_func, asyncio.Future)

    loop = asyncio.get_event_loop()
    loop.run_until_complete(run_tests())

# Generated at 2022-06-23 18:04:07.331954
# Unit test for constructor of class cached_property
def test_cached_property():
    class A:
        def __init__(self):
            self._x = 1

        @cached_property
        def x(self):
            return self._x

    a = A()
    assert a.x == 1  # Use __get__
    assert a.__dict__['x'] == 1  # Verify a.__dict__
    a._x = 2
    assert a.x == 2  # Use __get__
    assert a.__dict__['x'] == 2  # Verify a.__dict__


if __name__ == "__main__":
    # test_cached_property()
    pass

# Generated at 2022-06-23 18:04:13.737853
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest import TestCase, main
    from flutils.decorators import cached_property

    class MyClass(TestCase):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    mc = MyClass()
    result = mc.y
    expected = 6
    assert result == expected
    assert mc.__dict__['y'] == expected

if __name__ == "__main__":
    main()  # pragma: no cover

# Generated at 2022-06-23 18:04:19.861972
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Test:
        count = 0
        calls = 0

        def __init__(self):
            self.count += 1

        @cached_property
        def spam(self):
            self.calls += 1
            return self.count

    t1 = Test()
    assert t1.spam == 1
    assert t1.calls == 1
    assert t1.spam == 1
    assert t1.calls == 1



# Generated at 2022-06-23 18:04:23.893567
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test cached_property

    *New in version 1.2.0*

    """
    class TestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1
    # end def

    obj = TestClass()

    assert obj.y == 6

# Generated at 2022-06-23 18:04:28.590132
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import TestCase, mock

    class Test(TestCase):
        def test_with_object(self):
            with mock.patch.object(cached_property, '__get__',
                                   return_value='bar') as mock_method:
                obj = cached_property('foo')
                obj.__get__('instance', 'owner')
                mock_method.assert_called_once_with(obj, 'instance', 'owner')
            obj = cached_property('foo')
            obj.__get__('instance', 'owner')



# Generated at 2022-06-23 18:04:39.051484
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import mock

    # ============test for method __get__ no obj, no cls===============

    def testfunc():
        pass

    cached = cached_property(testfunc)

    assert cached._cached_property__doc__ == testfunc.__doc__
    assert cached.func is testfunc

    # test for method __get__ no obj, no cls
    assert cached.__get__(None, None) is cached

    # ============test for method __get__ ok, no cls===============

    class Foo:
        def testfunc(self):
            pass

    foo = Foo()
    cached = cached_property(foo.testfunc)

    assert (cached._cached_property__doc__ ==
            foo.testfunc.__doc__)
    assert cached.func is foo.testfunc

    #

# Generated at 2022-06-23 18:04:43.956641
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:04:54.128433
# Unit test for constructor of class cached_property
def test_cached_property():
    import pytest
    from textwrap import dedent

    try:
        import pytest_mock
    except ImportError:
        pytest_mock = None

    if pytest_mock is not None:
        mocker = pytest.mock.MockerFixture()

    class MyClass:

        def __init__(self):
            self.x = 5
            self.y_value = None

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def y_future(self):
            return self.x + 1

        @y_future.setter
        def set_y_future(self, value):
            self.y_value = value


# Generated at 2022-06-23 18:05:02.438208
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import Mock
    from unittest import TestCase

    class D:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    d = D()

    assert d.y == 6
    d.x = 6
    assert d.y == 6

    with TestCase() as t:
        d._y = Mock(side_effect=AttributeError())
        with t.assertRaises(AttributeError):
            print(d.y)


# Generated at 2022-06-23 18:05:06.924575
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property

    *New in version 0.3.0*
    """
    assert cached_property
    print("\n" + "\n".join(["Testing {}()".format(cached_property.__name__),
                            "test_cached_property() passed"]))


if __name__ == "__main__":
    test_cached_property()

# Generated at 2022-06-23 18:05:13.092450
# Unit test for constructor of class cached_property
def test_cached_property():
    class Obj:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Obj()
    assert obj.y == 6
    assert asyncio.iscoroutinefunction(obj.y) is False
    assert obj.y == 6
    assert obj.x == 5


# Generated at 2022-06-23 18:05:17.008184
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test cached_property.

    Tests the cached_property decorator.

    """
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:05:24.061172
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property"""

    class TestClass:
        """Test class"""

        def __init__(self):
            """Initializer"""
            self.x = 5

        @cached_property
        def y(self):
            """Test cached property"""
            return self.x + 1

    x = TestClass()
    assert x.y == 6
    assert x.__dict__['y'] == 6

# Generated at 2022-06-23 18:05:28.499451
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Test class for method __get__ of class cached_property
    class TestClass:

        @cached_property  # @cached_property
        def test_method(self):
            return 5 * 3

    obj = TestClass()
    # the first time, returns the value
    assert obj.test_method == 15
    # the second time, returns the attribute
    assert obj.test_method == 15



# Generated at 2022-06-23 18:05:30.040767
# Unit test for constructor of class cached_property
def test_cached_property():
    obj = cached_property(lambda self: self.x)

# Generated at 2022-06-23 18:05:35.690410
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.__dict__['y'] == 6, 'Test Failed'


# Generated at 2022-06-23 18:05:36.694967
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils import cached_property



# Generated at 2022-06-23 18:05:42.024192
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from collections import namedtuple

    Test = namedtuple("Test", "x, y")

    class TestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    result = Test(x=TestClass().x, y=TestClass().y)
    expected = Test(x=5, y=6)
    assert result == expected

# Generated at 2022-06-23 18:05:49.656882
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import patch
    from .tools import aio_run_for_test

    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.y == 6

    obj.x = 10
    assert obj.y == 11

    # Test the coroutine wrapped method
    with patch.object(obj, "__dict__", {"y": asyncio.Future()}):
        aio_run_for_test(obj.y)

    # Test the coroutine on first call
    obj.x = 15