

# Generated at 2022-06-23 17:55:44.995758
# Unit test for constructor of class cached_property
def test_cached_property():
    """ Unit test for constructor of class :class:`cached_property` """


if __name__ == '__main__':
    print('Running doctest.')
    import doctest

    doctest.testmod()

# Generated at 2022-06-23 17:55:50.155907
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        @cached_property
        def y(self):
            return 10

    obj = MyClass()

    assert hasattr(obj, 'y')
    assert obj.y == 10

    if sys.version_info >= (3, 8):
        assert not isinstance(obj.y, asyncio.Future)
        assert isinstance(obj.y, int)
    else:
        assert isinstance(obj.y, asyncio.Future)
        assert not isinstance(obj.y.result(), asyncio.Future)
        assert isinstance(obj.y.result(), int)

    obj.y = 100
    assert obj.y == 100

    del obj.y
    assert not hasattr(obj, 'y')
    assert obj.y == 10



# Generated at 2022-06-23 17:55:52.705421
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property."""

    # This is deliberately empty as all code has 100% test coverage
    #
    pass

# Generated at 2022-06-23 17:55:57.364961
# Unit test for constructor of class cached_property
def test_cached_property():

    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.y == 6
    obj.y = None
    assert obj.y == 6



# Generated at 2022-06-23 17:56:06.343088
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """ Unit test for method cached_property.__get__

    """

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    obj2 = MyClass()
    assert obj2.y == 6

    obj.x = 10
    assert obj.y == 11

    assert obj2.y == 6

    del obj2.y
    assert obj2.y == 6

# Generated at 2022-06-23 17:56:13.853549
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """Example function."""
            return self.x + 1

    obj = MyClass()

    # Test cached_property.__get__ with calling cached_property.__init__ with
    # MyClass.y
    # noinspection PyUnresolvedReferences
    assert MyClass.y == cached_property(MyClass.y)
    assert MyClass.y.__doc__ == "Example function."

    # Test cached_property.__get__ with calling cached_property.__init__ with
    # obj.y
    assert obj.y == 6
    assert obj.y == 6

# Generated at 2022-06-23 17:56:20.683982
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property
    """
    class TestClass(object):

        def __init__(self, value):
            self.value = value

        @cached_property
        def value_plus_one(self):
            """Add one to value
            """
            return self.value + 1

    obj = TestClass(10)
    assert obj.value_plus_one == 11
    obj.value = 15
    assert obj.value_plus_one == 11
    del obj.value_plus_one
    assert obj.value_plus_one == 16



# Generated at 2022-06-23 17:56:30.493873
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    cached_property.__get__()

    Test the method ``__get__`` of class :class:`~flutils.decorators.cached_property`.

    :return: ``None``
    """
    # noinspection PyUnresolvedReferences,PyUnusedLocal
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    obj.__dict__.pop('y')
    obj.x = 10
    assert obj.y == 11

    return None

# Generated at 2022-06-23 17:56:38.714573
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method `flutils.decorators.cached_property.__get__`.
    """
    # Import builtins module
    import builtins

    # Import sys module
    import sys

    # Import unittest module
    import unittest

    # Get the Python version
    py_version = tuple(sys.version_info[:2])

    # Compute the Python version
    major, minor = py_version

    # Define the class to be tested
    class MyClass:

        # Define the getter
        @cached_property
        def y(self):
            return self.x + 1

        def __init__(self):
            self.x = 5

    # Define an instance of the class to be tested
    obj = MyClass()

    # Define the expected result

# Generated at 2022-06-23 17:56:43.743591
# Unit test for constructor of class cached_property
def test_cached_property():
    class Foo(object):
        def __init__(self):
            self._bar = 'baz'

        @cached_property
        def bar(self):
            """The bar property."""
            return self._bar

    foo = Foo()
    assert foo.bar == 'baz'
    assert Foo.bar.__doc__ == 'The bar property.'
    del foo.bar
    assert not hasattr(foo, 'bar')

# Generated at 2022-06-23 17:56:50.808428
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    def test():
        i = c()
        r = i.m
        assert r == 5
        i.d = {}
        r = i.m
        assert r is None
        i.d = {'m': 6}
        r = i.m
        assert r == 6

    c = MyClass
    setattr(c, 'm', cached_property(f))
    test()

    c = type('MyClass', (), {})
    setattr(c, 'm', cached_property(f))
    test()



# Generated at 2022-06-23 17:56:56.626141
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from math import factorial
    from flutils.decorators import cached_property

    class Factorial:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return factorial(self.x)

    obj = Factorial()
    assert obj.y == 120
    obj.x = 6
    assert obj.y == 120
    del obj.y
    assert obj.y == 720

# Generated at 2022-06-23 17:57:03.494540
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import patch
    from flutils import decorators

    class MyClass:
        @decorators.cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.x = 5
    assert obj.y == 6
    assert obj.__dict__['y'] == 6
    obj.x = 1
    assert obj.y == 6
    assert obj.__dict__['y'] == 6



# Generated at 2022-06-23 17:57:16.131376
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    import pytest

    @cached_property
    def property_to_be_cached(obj):
        return obj.x + 1

    class MyClass:

        def __init__(self, x):
            self.x = x

    class MyClassWithFuture:

        def __init__(self, x):
            self.x = x

        @property
        def property_to_be_cached(self):
            return asyncio.Future()

    # Test when obj is None
    obj = MyClass(5)
    assert property_to_be_cached.__get__(None, obj) is property_to_be_cached

    # Test when obj is not None
    assert property_to_be_cached.__get__(obj, obj) == 6
    assert property_to_be_cached.__

# Generated at 2022-06-23 17:57:20.437205
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    x = MyClass()
    assert x.y == 6

# Generated at 2022-06-23 17:57:30.831972
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property

    """
    import tempfile
    import os

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            raise ValueError('Test')

    obj = MyClass()

    assert obj.y == 6
    assert obj.__dict__ == {'x': 5, 'y': 6}

    obj.x = 10

    assert obj.y == 6
    assert obj.__dict__ == {'x': 10, 'y': 6}

    del obj.y

    assert obj.y == 11
    assert obj.__dict__ == {'x': 10, 'y': 11}

    #

# Generated at 2022-06-23 17:57:38.815413
# Unit test for constructor of class cached_property
def test_cached_property():
    from types import FunctionType

    class A:

        pass

    a = A()

    # test if it's a method
    def func_prop(other):
        pass

    a.func_prop = func_prop

    # test if it's a function
    a.func_func = func_prop

    assert isinstance(a.func_prop, MethodType)
    assert isinstance(a.func_func, FunctionType)

    # test re_wrapping
    a.func_prop = cached_property(a.func_prop)
    assert isinstance(a.func_prop, cached_property)

    a.func_prop = cached_property(a.func_func)
    assert isinstance(a.func_prop, cached_property)

# Generated at 2022-06-23 17:57:40.968490
# Unit test for constructor of class cached_property
def test_cached_property():
    @cached_property
    def y(self):
        return self.x + 1

    assert y.__name__ == 'y'
    assert y.__doc__ is None
    assert y.__module__ == '__main__'

# Generated at 2022-06-23 17:57:46.041972
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Returns
    -------
    None.

    """

    class MyClass:

        def __init__(self):
            self.x = 1

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.__dict__ == {'x': 1}
    assert obj.y == 2
    assert obj.__dict__ == {'x': 1, 'y': 2}
    del obj.y
    assert obj.__dict__ == {'x': 1}



# Generated at 2022-06-23 17:57:52.573168
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # From https://bit.ly/2R9U3Qa
    class _TestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = _TestClass()
    y = obj.y
    assert y == 6



# Generated at 2022-06-23 17:58:03.705349
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from itertools import repeat, count
    from types import FunctionType

    class MyClass:
        def __init__(self, x):
            self.x = x

        @cached_property
        def some_property(self):
            return repeat(self.x + 1, 3)

    obj = MyClass(5)
    assert hasattr(obj, 'some_property')
    assert type(obj.some_property) is FunctionType
    assert obj.some_property() is not None
    assert list(obj.some_property()) == list(obj.some_property())

    class MyClass:
        def __init__(self, x):
            self.x = x

        @cached_property
        def some_property(self):
            return repeat(self.x + 1, 3)

    obj = MyClass(5)

# Generated at 2022-06-23 17:58:04.920760
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property



# Generated at 2022-06-23 17:58:13.775405
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestCachedProperty___get__(object):

        __instanceCount = 0

        def __init__(self):
            self.x = 5
            TestCachedProperty___get__.__instanceCount += 1

        @cached_property
        def y(self):
            return self.x + 1

    class TestCachedProperty___get__Async:

        __instanceCount = 0

        def __init__(self):
            self.x = 5
            TestCachedProperty___get__.__instanceCount += 1

        @cached_property
        async def y(self):
            await asyncio.sleep(0.1)
            return self.x + 1

    import asyncio

    # Test cached_property

    obj = TestCachedProperty___get__()

    assert obj.y == 6

# Generated at 2022-06-23 17:58:19.642863
# Unit test for constructor of class cached_property
def test_cached_property():
    """ Unit test for constructor of class cached_property
    """

    # Initialization of a class
    class Class1:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Class1()

    # Testing constructor
    assert obj.y == 6

# Generated at 2022-06-23 17:58:23.320672
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Demo:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1
    obj = Demo()
    assert obj.y == 6, obj.y

# Generated at 2022-06-23 17:58:28.093400
# Unit test for constructor of class cached_property
def test_cached_property():
    class Foo:

        def __init__(self):
            self.x = 5

        @cached_property
        def my_property(self):
            return self.x + 1

    obj = Foo()
    assert obj.my_property == 6
    del obj.my_property
    assert obj.my_property == 6

# Generated at 2022-06-23 17:58:31.255292
# Unit test for constructor of class cached_property
def test_cached_property():
    class A():
        def __init__(self):
            self.x=5

        @cached_property
        def y(self):
            return self.x + 1
    a = A()
    assert a.y == 6

# Generated at 2022-06-23 17:58:34.156543
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1
    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 17:58:38.695597
# Unit test for constructor of class cached_property
def test_cached_property():
    "Test case for cached_property"

    class SampleClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = SampleClass()
    assert obj.y == 6
    assert 'y' in obj.__dict__
    assert obj.__dict__['y'] == 6


if __name__ == '__main__':
    test_cached_property()

# Generated at 2022-06-23 17:58:46.327421
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for :class:`flutils.decorators.cached_property`"""

    # Setup code
    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Exercise code
    obj = MyClass()
    assert obj.y == 6


# Execute `test_cached_property()` when this file is run via Python
if __name__ == '__main__':
    test_cached_property()

# Generated at 2022-06-23 17:58:51.111266
# Unit test for constructor of class cached_property
def test_cached_property():

    # noinspection PyPep8Naming
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6, 'Expected value 6, got {}'.format(obj.y)



# Generated at 2022-06-23 17:58:55.623409
# Unit test for constructor of class cached_property
def test_cached_property():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 17:59:04.111828
# Unit test for constructor of class cached_property
def test_cached_property():
    class Object(object):
        def __init__(self):
            self.x = 5
            self.x = 7

        @cached_property
        def foo(self):
            """The foo property."""
            return self.x

    obj = Object()
    obj.x = 11  # should not effect the cached foo value
    assert 11 == obj.x
    assert 7 == obj.foo

    del obj.foo
    assert obj.foo == 7

    obj = Object()
    assert obj.foo == 7
    obj.x = 42
    assert obj.foo == 7

    del obj.foo
    obj.x = 42
    assert obj.foo == 42

    # Test docstring
    assert Object.foo.__doc__ == 'The foo property.'



# Generated at 2022-06-23 17:59:12.240408
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test unit to method __get__ of class cached_property."""

    class Test:
        """Test class to test unit to method __get__ of class cached_property."""

        def __init__(self, value):
            """Test class initializer to test unit to method __get__ of class cached_property."""
            self._value = value

        @cached_property
        def value(self):
            """Test property to test unit to method __get__ of class cached_property."""
            return self._value

    test = Test(5)
    assert test.value == 5
    test._value = 10
    assert test.value == 5

# Generated at 2022-06-23 17:59:17.134255
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Unit test for constructor of class cached_property
    """

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Test cached_property
    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__ == {'x': 5, 'y': 6}

# Generated at 2022-06-23 17:59:21.215818
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestClass:
        y = 1
        def __init__(self):
            self.x = 5
        @cached_property
        def y(self):
            return self.x + 1

    test_class = TestClass()
    assert test_class.y == 6



# Generated at 2022-06-23 17:59:29.704183
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test that cached_property.__get__ returns a future or a synchronous value
    for async and sync functions respectively.
    """

    class A:
        @cached_property
        def x(self):
            return 2

        @cached_property
        def y(self):
            return asyncio.sleep(1, result="future")

    a = A()
    assert a.x == 2
    assert isinstance(a.y, asyncio.Future)
    assert a.__dict__["x"] == 2
    assert a.__dict__["y"] == a.y


# Generated at 2022-06-23 17:59:33.849356
# Unit test for constructor of class cached_property
def test_cached_property():
    prop_name = "prop"

    def func():
        pass

    prop = cached_property(func)
    assert prop.func is func
    assert prop.__doc__ is func.__doc__
    assert prop.__name__ == prop_name

# Generated at 2022-06-23 17:59:38.112746
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 17:59:50.185881
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property

    Test case 1:
    Test whether the descriptor function is triggered and the result is
    cached

    Test case 2:
    Test whether the descriptor function is not triggered and the result is
    returned from the cached value

    Test case 3:
    Test whether the descriptor function is triggered when called as a class
    method

    Test case 4:
    Test whether the descriptor function is triggered when called as a class
    method and the result is cached

    *New in version 0.2.0*
    """
    import pytest

    @cached_property
    def add_one(obj):
        obj.x += 1
        return obj.x

    @cached_property
    def add_one_for_class(cls):
        cls.x += 1
        return cls.x

# Generated at 2022-06-23 18:00:00.131625
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():  # pragma: no cover
    from flutils.decorators import cached_property
    from flutils.decorators import cached_property_sync

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property_sync
        def y_sync(self):
            return self.x + 1

    obj = MyClass()
    obj.y  # noinspection PyStatementEffect
    obj.y_sync  # noinspection PyStatementEffect
    assert 'y' in obj.__dict__
    assert 'y_sync' in obj.__dict__


# Generated at 2022-06-23 18:00:03.919048
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.x = 5
    assert obj.y == 6


# Generated at 2022-06-23 18:00:10.656594
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # noinspection PyMissingOrEmptyDocstring
    class Test:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x + 1

    c = Test()
    assert c.y == 6


# Generated at 2022-06-23 18:00:21.550713
# Unit test for constructor of class cached_property
def test_cached_property():
    import sys
    import unittest

    class TestCachedProperty(unittest.TestCase):
        def test_cached_property(self):
            # noinspection PyPep8Naming
            class MyClass:
                def __init__(self):
                    self.x = 5

                @cached_property
                def y(self):
                    return self.x + 1

            obj = MyClass()
            self.assertEqual(obj.y, 6)
            self.assertEqual(obj.__dict__['y'], 6)

    if __name__ == '__main__':
        if sys.version_info.minor == 6:
            unittest.main(exit=False)
        else:
            unittest.main()

# Generated at 2022-06-23 18:00:32.458243
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # Test cached_property from flutils.decorators
    from flutils.decorators import cached_property

    class Foo:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Foo()
    assert obj.y == 6

    # Test cached_property from functools
    try:
        from functools import cached_property as functools_cached_property
    except ImportError:
        # Skip test
        return

    class Bar:
        def __init__(self):
            self.x = 5

        @functools_cached_property
        def y(self):
            return self.x + 1

    obj = Bar()
    assert obj.y == 6



# Generated at 2022-06-23 18:00:38.609644
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Method __get__ of class cached_property

    Attributes:
        log_level (str): Level of logging
        logger (logging.Logger): Logger object

    Returns:
        None
    """

    import logging

    logging.basicConfig(level=logging.INFO, format='%(levelname)s %(message)s')
    logger = logging.getLogger(__name__)
    log_level = logging.getLevelName(logger.getEffectiveLevel())

    logger.info("Unit test for method __get__ of class cached_property")

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    print("Test of instance attribute y:")
   

# Generated at 2022-06-23 18:00:43.278295
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest import TestCase, mock
    from flutils import decorators

    class MyClass(TestCase):

        def __init__(self):
            self.x = 5

        @decorators.cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert isinstance(obj.y, int)
    assert obj.y == 6

    # Now make sure that it is cached
    obj.x = 10
    # noinspection PyUnresolvedReferences
    with mock.patch.object(obj, 'y', new_callable=mock.PropertyMock) as mock_property:
        # Check that property is not called
        obj.y
        mock_property.assert_not_called()



# Generated at 2022-06-23 18:00:46.042726
# Unit test for constructor of class cached_property
def test_cached_property():
    c = cached_property(lambda x: 1)
    assert c.__doc__ is None
    assert c.func(1) == 1

# Generated at 2022-06-23 18:00:47.721619
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Unit test for constructor of class cached_property
    """
    assert cached_property(lambda: True)

# Generated at 2022-06-23 18:00:50.712174
# Unit test for constructor of class cached_property
def test_cached_property():
    class Dummy:
        def x(self):
            """X is for X-Ray."""
            return 42

        y = cached_property(x)

    assert Dummy.x.__doc__ == Dummy.y.__doc__ == "X is for X-Ray."

# Generated at 2022-06-23 18:00:53.777235
# Unit test for constructor of class cached_property
def test_cached_property():

    # noinspection PyPep8Naming,PyUnusedLocal
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    assert obj.y == 6



# Generated at 2022-06-23 18:01:03.045369
# Unit test for constructor of class cached_property
def test_cached_property():  # pragma: no cover
    class foo:
        x = 5

        @cached_property
        def bar(self, value=5):
            return self.x + value

    obj = foo()

    print("Cached property: ", obj.bar)
    print("Cached property: ", obj.bar)
    del obj.bar
    print("Cached property: ", obj.bar)
    print("Cached property: ", obj.bar)
    obj.x = 10
    print("Cached property: ", obj.bar)
    print("Cached property: ", obj.bar)
    del obj.bar
    obj.bar = 10
    print("Cached property: ", obj.bar)
    print("Cached property: ", obj.bar)

    print("Test complete!")



# Generated at 2022-06-23 18:01:13.653582
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    from unittest import TestCase, mock

    class Dummy(TestCase):
        def __init__(self, parent):
            self.parent = parent
            self.called = False

        def fn(self):
            self.called = True
            return mock.sentinel._result  # nosec

    def test_cached_property(self):
        """Test cached_property methods"""
        d = Dummy(parent=mock.sentinel._parent)
        assert isinstance(d, TestCase)

        cp = cached_property(fn)
        # First call, should be present in the dict
        res1 = cp.__get__(d, Dummy)
        assert res1 == mock.sentinel._result
        assert d.called
        assert isinstance(d.__dict__[fn.__name__], asyncio.Future)

# Generated at 2022-06-23 18:01:14.603551
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property.__doc__ is not None

# Generated at 2022-06-23 18:01:16.073117
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj = MyClass()
    obj.y
    assert obj.y == 6



# Generated at 2022-06-23 18:01:20.575119
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:01:23.055632
# Unit test for constructor of class cached_property
def test_cached_property():

    class C:

        def __init__(self, x):
            self.x = x

        @cached_property
        def c(self):
            return self.x * self.x

    c = C(5)
    assert c.c == 25



# Generated at 2022-06-23 18:01:24.259511
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property



# Generated at 2022-06-23 18:01:27.775328
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Cls:
        @cached_property
        def prop(self):
            return None

    obj = Cls()
    assert isinstance(obj.prop, cached_property)



# Generated at 2022-06-23 18:01:32.012337
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""

    class TestClass(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    tc = TestClass()
    assert tc.y == 6

# Generated at 2022-06-23 18:01:39.466714
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    test_cached_property unit test

    Performs sanity checks on the constructor of the
    :obj:`~flutils.decorators.cached_property` class.

    """
    from types import FunctionType

    class MyClass:

        @cached_property
        def x(self):
            return 5

    x = MyClass().x
    assert x == 5
    assert isinstance(MyClass.x, cached_property)
    assert isinstance(MyClass.x.func, FunctionType)



# Generated at 2022-06-23 18:01:40.817179
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""
    pass

# Generated at 2022-06-23 18:01:45.955862
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    @cached_property
    def a(self):
        return 1

    assert a.__name__ == 'a'
    assert a.__doc__ is None
    assert a.func.__name__ == 'a'

    class Test:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Test()
    assert obj.y == 6


# Generated at 2022-06-23 18:01:49.610273
# Unit test for constructor of class cached_property
def test_cached_property():
    """Tests the class cached_property constructor"""
    from flutils.decorators import cached_property
    from flutils.decorators import cached_property as cp

    assert cached_property.__doc__ == cp.__doc__
    assert cached_property.__name__ == cp.__name__

# Generated at 2022-06-23 18:02:01.185933
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.tests import get_test_data

    class Object:

        def __init__(self, x):
            self.x = x

        @cached_property
        def cached_value(self):
            return self.x + 1

    # Test successful attribute caching.
    obj = Object(5)
    assert obj.cached_value == 6
    assert obj.cached_value == 6

    # Test attribute fetching when attribute is not cached.
    delattr(obj, 'cached_value')
    assert obj.cached_value == 6
    assert obj.cached_value == 6

    # Test attribute caching when the cached_value is a coroutine.
    obj = Object(5)

    @asyncio.coroutine
    def coroutine_val():
        return obj.x + 1

    obj.c

# Generated at 2022-06-23 18:02:08.967319
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # TEST: method is coroutine
    class MyClass:
        def __init__(self, x_val=5):
            self.x = x_val

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    assert hasattr(obj.__dict__['y'], '__await__') is True



# Generated at 2022-06-23 18:02:16.765500
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property."""
    from unittest import TestCase
    import time
    from unittest.mock import patch

    class MyClass:
        def __init__(self, sleep_time=0.5):
            self._sleep_time = sleep_time

        @cached_property
        def prop(self):
            time.sleep(self._sleep_time)
            return "hi"

    class cTestCachedProperty(TestCase):
        @patch("time.sleep")
        def test_cached_property(self, mock_sleep):
            inst = MyClass()
            self.assertEqual(inst.prop, "hi")
            self.assertEqual(inst.prop, "hi")
            mock_sleep.assert_called_once_with(0.5)


# Generated at 2022-06-23 18:02:23.420884
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        y = 0

        @cached_property
        def x(self):
            self.y += 1
            return self.y

    obj = MyClass()
    obj.x
    obj.x
    assert obj.y == 1, "cached_property __get__() method failed to cache"

    obj = MyClass()
    obj.x
    obj.x



# Generated at 2022-06-23 18:02:25.940469
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    def answer(self):
        return 42

    class One:
        self.answer = cached_property(answer)

    one = One()
    assert one.answer == 42



# Generated at 2022-06-23 18:02:26.552650
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass

# Generated at 2022-06-23 18:02:27.879150
# Unit test for constructor of class cached_property
def test_cached_property():
    pytest.skip('Function under construction.')


# Generated at 2022-06-23 18:02:32.107774
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from inspect import signature

    class C:
        @cached_property
        def a(self):
            return 5

    assert len(signature(C().a).parameters) == 0
    assert C().a == 5


# Generated at 2022-06-23 18:02:35.979805
# Unit test for constructor of class cached_property
def test_cached_property():
    cp = cached_property(lambda: None)
    assert isinstance(cp, cached_property)
    assert cp.func() is None
    assert cp.__doc__ is None
    assert cp.__get__(None, None) is cp



# Generated at 2022-06-23 18:02:39.184216
# Unit test for constructor of class cached_property
def test_cached_property():
    prop = cached_property(lambda self: type(self))
    assert prop.__doc__ is None
    assert 'lambda' in str(prop.func)

# Generated at 2022-06-23 18:02:47.693479
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert "y" in obj.__dict__
    try:
        # noinspection PyStatementEffect
        obj.y
    except BaseException:
        pytest.fail("'y' should be a cached property.")
    assert MyClass.y is cached_property.__get__(MyClass.y, None, MyClass)
    assert not hasattr(obj, "y")


# noinspection PyPep8Naming

# Generated at 2022-06-23 18:02:53.520808
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x + 2

    obj = MyClass()
    obj.y
    obj.z



# Generated at 2022-06-23 18:03:00.317174
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""
    print("Cached_property __get__ method")

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    assert "y" in obj.__dict__
    assert obj.__dict__["y"] == obj.y



# Generated at 2022-06-23 18:03:04.626339
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test the constructor of class :obj:`cached_property`.

    :return: True if test passes; otherwise False
    :rtype: bool
    """

    @cached_property
    def prop(obj):
        """A prop."""
        return None

    assert prop.__doc__ == 'A prop.'

    return True



# Generated at 2022-06-23 18:03:08.102806
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        # noinspection PyPep8Naming
        @cached_property
        def y(self):
            return self.x + 1

        def __init__(self):
            self.x = 5

    obj = MyClass()
    assert obj.__dict__['y'] == 6



# Generated at 2022-06-23 18:03:11.357979
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest import mock

    decorator = cached_property(mock.sentinel.func)
    assert decorator.__doc__ == mock.sentinel.func.__doc__
    assert decorator.func == mock.sentinel.func


# Generated at 2022-06-23 18:03:21.022922
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """A description"""
            return self.x + 1

    obj = MyClass()

    # Test the cached property and it's doc string
    assert obj.y == 6
    assert obj.y == 6
    assert obj.y.__doc__ == 'A description'

    # Now delete the property and make sure it returns the correct value
    del obj.y
    assert obj.y == 6

    # Make sure we can access the decorator's doc string
    assert MyClass.y.__doc__ == 'A description'

# Generated at 2022-06-23 18:03:24.693410
# Unit test for constructor of class cached_property
def test_cached_property():
    def test_func():
        return "test"
    decorator = cached_property(test_func)
    assert decorator.func is test_func
    assert decorator.__doc__ is test_func.__doc__

# Generated at 2022-06-23 18:03:30.300339
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from pprint import pprint

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.y == 6



# Generated at 2022-06-23 18:03:31.336106
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property



# Generated at 2022-06-23 18:03:40.116806
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass

    # Usage as a decorator
    # class MyClass:
    #
    #     def __init__(self):
    #         self.x = 5
    #
    #     @cached_property
    #     def y(self):
    #         return self.x + 1
    #
    # obj = MyClass()
    # obj.y
    # obj.y
    # del obj.y
    # obj.y

    # class MyClass:
    #     __slots__ = ('x', 'y')
    #
    #     def __init__(self):
    #         self.x = 5
    #
    #     @cached_property
    #     def y(self):
    #         return self.x + 1
    #
    # obj = MyClass()
    # obj.

# Generated at 2022-06-23 18:03:47.748008
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # test for standard case
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    obj.y

    # test for async case
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        async def y(self):
            return self.x + 1

    obj = MyClass()

    loop = asyncio.get_event_loop()
    loop.run_until_complete(obj.y)

# Generated at 2022-06-23 18:03:55.518281
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class :obj:`~flutils.decorators.cached_property`.

    :return: (bool) indicating whether or not the unit test passed
    """

    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    return True


# Generated at 2022-06-23 18:03:59.082955
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:04:11.535555
# Unit test for constructor of class cached_property
def test_cached_property():
    from .python_types import _stringify

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        async def z(self):
            return self.x + 1

        @classmethod
        def assert_str(cls, obj, val):
            assert isinstance(obj, MyClass)
            assert isinstance(val, str)

        @cached_property
        def stringify(self):
            return _stringify(self)

    obj = MyClass()

    assert obj.y == 6
    assert obj.y == 6
    assert obj.y == 6

    assert obj.stringify == "MyClass(x=5)"

    loop = asyncio.get_event_

# Generated at 2022-06-23 18:04:19.049658
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test the constructor."""
    import unittest.mock
    import flutils.decorators

    obj = flutils.decorators.cached_property(lambda x: 5)
    assert isinstance(obj, flutils.decorators.cached_property)

    def func():
        pass

    func.__doc__ = "hello"
    obj = flutils.decorators.cached_property(func)
    assert obj.__doc__ == "hello"



# Generated at 2022-06-23 18:04:24.298049
# Unit test for constructor of class cached_property
def test_cached_property():
    class ObjectUnderTest:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """The cached property."""
            return self.x + 1

    obj = ObjectUnderTest()
    assert obj.y == 6, 'Cached property was not initialized properly'



# Generated at 2022-06-23 18:04:26.818511
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 6

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 7


# Generated at 2022-06-23 18:04:29.407709
# Unit test for constructor of class cached_property
def test_cached_property():

    from inspect import signature, Parameter

    assert len(signature(cached_property).parameters) == 1
    assert (
        signature(cached_property).parameters.get('func') ==
        Parameter('func', Parameter.POSITIONAL_OR_KEYWORD)
    )



# Generated at 2022-06-23 18:04:39.417743
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    ###############################
    # non-coroutine function
    ###############################
    class TestClass:

        def __init__(self, x):
            self._x = x

        @cached_property
        def get_x(self):
            return self._x

    obj = TestClass(5)
    assert obj.get_x == 5

    # Test for issue #16
    assert TestClass.get_x is TestClass._TestClass__get_x

    # If a descriptor would not exist, the function would be called again
    # leading to 2 * `x`
    assert obj.get_x == 5

    class TestClass:

        def __init__(self, x):
            self._x = x

        @cached_property
        def get_x(self):
            return self._x


# Generated at 2022-06-23 18:04:51.566614
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from sys import version_info
    from unittest import TestCase
    import asyncio

    class TestClass:

        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x + 2

    class TestCachedProperty(TestCase):

        def test_cached_property(self):
            from inspect import iscoroutinefunction

            obj = TestClass(5)
            self.assertEqual(obj.x, 5)

            self.assertEqual(obj.y, 6)
            self.assertEqual(obj.__dict__['y'], 6)

            self.assertEqual(obj.z, 7)

# Generated at 2022-06-23 18:04:57.952957
# Unit test for constructor of class cached_property
def test_cached_property():
    """(Unit Test) """

    @cached_property
    def y(self):
        return self.x+1

    class MyClass:

        def __init__(self):
            self.x = 5

        y = cached_property(y)

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:05:06.894220
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils import decorators
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        async def z(self):
            await asyncio.sleep(1)
            return self.x - 1

    obj = MyClass()
    assert obj.y == 6

    # The following is only supported with Python 3.7+
    import sys
    if sys.version_info.minor > 6:
        assert asyncio.iscoroutine(obj.z) is False
        assert isinstance(obj.z, asyncio.Future) is True
        loop = asyncio.get_event_loop()
        loop.run_until_complete

# Generated at 2022-06-23 18:05:11.737222
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # setup
    class TestCls:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestCls()
    assert obj.y == 6



# Generated at 2022-06-23 18:05:16.971553
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for the cached_property decorator.

    This function raises no exception if the unit test passes.
    """
    # noinspection PyPep8Naming
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 18:05:25.657172
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """ Test case for method __get__ of class
        cached_property
    """

    class CachedPropertyTestClass:
        """ Dummy class for testing """
        # noinspection PyUnusedLocal
        @cached_property
        def my_cached_property(self):
            """ a docstring """
            return 1

    obj = CachedPropertyTestClass()

    assert obj.my_cached_property == 1
    assert obj.my_cached_property == 1

    del obj.my_cached_property

    assert obj.my_cached_property == 1

    assert obj.__class__.my_cached_property.__doc__ == 'a docstring'

# Generated at 2022-06-23 18:05:30.813603
# Unit test for constructor of class cached_property
def test_cached_property():
    from functools import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:05:38.999359
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    import pytest
    from unittest.mock import Mock, patch

    class MyClass:
        x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6
    assert obj.y == 6

    with patch('flutils.decorators.cached_property.__get__', Mock(return_value=666)):
        with pytest.raises(TypeError):
            obj.y


# Generated at 2022-06-23 18:05:44.686773
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    # noinspection PyUnresolvedReferences
    class MyClass:

        @cached_property
        @asyncio.coroutine
        def an_async_coroutine(self):
            """This is a coroutine"""
            return 42

    obj = MyClass()
    result = obj.an_async_coroutine
    print(result)
    print(result)
    print(result)
    assert isinstance(result, asyncio.Future)
    return obj