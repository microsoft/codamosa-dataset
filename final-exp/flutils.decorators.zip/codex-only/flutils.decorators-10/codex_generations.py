

# Generated at 2022-06-23 17:55:45.521257
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass  # For now, see test "test_decorators.py"



# Generated at 2022-06-23 17:55:50.717163
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property.

    Purpose:
        Unit test the constructor of class cached_property.
    """

    @cached_property
    def y(self):
        return self.x + 1

    assert y.__doc__ is None



# Generated at 2022-06-23 17:55:56.166307
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test for cached_property.__get__
    """
    class TestClass:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    test = TestClass(5)
    actual = test.y
    expected = 6
    assert actual == expected


# Generated at 2022-06-23 17:56:00.913682
# Unit test for constructor of class cached_property
def test_cached_property():
  """ Unit tests for :meth:`flutils.decorators.cached_property`
  """

  from flutils.decorators import cached_property

  class MyClass:

    def __init__(self):
      self.x = 5

    @cached_property
    def y(self):
      return self.x + 1

  obj = MyClass()
  assert obj.y == 6

# Generated at 2022-06-23 17:56:10.854863
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import unittest

    class MyClass:

        def __init__(self):
            self.x = 5
            self.y = cached_property(self._y)
            self._y_called = 0

        def _y(self):
            self._y_called += 1
            return self.x + 1

    class MyTestCase(unittest.TestCase):

        def test_cached_property___get__(self):
            obj = MyClass()
            self.assertEqual(obj.y, 6)
            self.assertEqual(obj._y_called, 1)
            self.assertEqual(obj.y, 6)
            self.assertEqual(obj._y_called, 1)

    # noinspection PyUnresolvedReferences
    suite = unittest.TestLoader().loadTestsFromTestCase

# Generated at 2022-06-23 17:56:15.937893
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    @cached_property
    def x(self):
        return self.y + 1

    class MyClass:
        def __init__(self):
            self.y = 5

    obj = MyClass()
    assert obj.x == 6
    assert obj.x == 6

# Generated at 2022-06-23 17:56:18.537085
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest.mock import patch

    with patch('flutils.decorators.cached_property.asyncio.iscoroutinefunction'):
        cached_property(lambda: None)

# Generated at 2022-06-23 17:56:19.890862
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test class :obj:`~flutils.decorators.cached_property`"""
    assert cached_property



# Generated at 2022-06-23 17:56:27.599618
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for class cached_property."""

    from flutils.decorators import cached_property
    from logzero import logger

    class Foo:
        def __init__(self):
            logger.info("init")
            self.x = 5

        @cached_property
        def y(self):
            logger.info("y")
            return self.x + 1

    obj = Foo()
    assert(obj.y == 6)



# Generated at 2022-06-23 17:56:36.176938
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Now(object):
        @cached_property
        def now(self):
            from datetime import datetime
            return datetime.utcnow()

    now = Now()

    # Instance now has a now attribute
    assert hasattr(now, "now")

    # and now.now is a datetime
    assert isinstance(now.now, datetime)

    # Ensure that repeated calls to now.now return the same object
    assert now.now is now.now

    # Ensure that the first call to now.now returns a datetime object
    assert isinstance(now.now, datetime)

    # Ensure that the first call to now.now returns a datetime object
    assert isinstance(now.now, datetime)

    del now.now
    assert not hasattr(now, "now")

# Generated at 2022-06-23 17:56:39.251243
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # noinspection PyShadowingNames
    class myClass:

        def __init__(self, value):
            self.value = value


# Generated at 2022-06-23 17:56:49.067958
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from copy import copy
    from unittest.mock import patch

    import asyncio
    from asyncio.coroutines import _is_coroutine

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    # Test that property is not cached if not accessed
    assert obj.x == 5
    assert obj.__dict__ == {'x': 5}

    # Test that property is cached
    assert obj.y == 6
    assert obj.__dict__ == {'x': 5, 'y': 6}

    # Test that property is not cached if method is overriden
    obj.y = 7
    assert obj.y == 7

# Generated at 2022-06-23 17:56:51.738253
# Unit test for constructor of class cached_property
def test_cached_property():
    obj = MyClass()

    assert obj.y == 6



# Generated at 2022-06-23 17:56:55.108047
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class Test:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Test()
    assert obj.y == 6



# Generated at 2022-06-23 17:57:07.315192
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    # noinspection PyUnusedLocal
    class MyClass:

        def __init__(self):
            self.x = 5

        # noinspection PyMethodMayBeStatic
        @cached_property
        def __non_cached_property_y(self):
            return self.x + 1

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            # noinspection PyMethodMayBeStatic,PyUnresolvedReferences
            async def _coroutine():
                return self.x + 1

            return _coroutine()

    obj = MyClass()
    assert obj.__non_cached_property_y == 6  # no cached_property decorator
    assert obj.__non

# Generated at 2022-06-23 17:57:14.309200
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test method __get__() of class cached_property
    """

    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 17:57:17.704566
# Unit test for constructor of class cached_property
def test_cached_property():

    class MyClass:

        def __init__(self):
            self.x = 0

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 1



# Generated at 2022-06-23 17:57:29.105401
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """ Unit test for method __get__ of class cached_property.
    """
    def testFuncOne(int_val):
        """ A dummy function for testing.
        """
        return int_val

    # Test for a typical get
    obj = cached_property(testFuncOne)
    obj(5)
    assert obj.__get__(obj, obj.__class__) == 5

    # Test for a get when a property has already been computed
    obj(10)
    assert obj.__get__(obj, obj.__class__) == 5

    # Test for method __get__ when an object is passed to it
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1


    obj = My

# Generated at 2022-06-23 17:57:29.700319
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass



# Generated at 2022-06-23 17:57:38.489448
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property"""
    import pytest
    import inspect
    from flutils.decorators import cached_property
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__[obj.y] == 6
    assert hasattr(obj, 'x')
    assert isinstance(obj, MyClass)
    assert obj.y == 6
    assert obj.y == obj.__dict__[obj.y]
    assert inspect.isclass(MyClass)
    assert inspect.ismethod(obj.y)
    assert inspect.ismethod(obj.__init__)

# Generated at 2022-06-23 17:57:41.658482
# Unit test for constructor of class cached_property
def test_cached_property():
    class A:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    a = A()
    assert a.y == 6

# Generated at 2022-06-23 17:57:44.602655
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property."""

    class Obj:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Obj()
    assert obj.y == 6

# Generated at 2022-06-23 17:57:49.668345
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    my_obj = MyClass()
    assert my_obj.y == 6



# Generated at 2022-06-23 17:57:53.704549
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    assert obj.__dict__['y'] == 6

# Generated at 2022-06-23 17:57:57.006400
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        # noinspection PyMissingConstructor
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


# Generated at 2022-06-23 17:57:58.970499
# Unit test for constructor of class cached_property
def test_cached_property():

    class Obj:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Obj()
    obj.y
    assert obj.y == 6



# Generated at 2022-06-23 17:58:03.038763
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 17:58:10.884492
# Unit test for constructor of class cached_property
def test_cached_property():
    from functools import cached_property as fcached_property

    @fcached_property
    def prop1(self):
        return 5

    def prop2(self):
        return 6

    prop2 = cached_property(prop2)

    class MyClass:
        prop1 = cached_property(prop1)
        prop2 = prop2

    assert MyClass(
    ).prop1 == MyClass(
    ).prop1 == MyClass(
    ).prop1 == 5 == MyClass(
    ).prop2 == MyClass(
    ).prop2 == 6


# Unit test with asyncio

# Generated at 2022-06-23 17:58:23.273860
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test cached_property.__get__
    """
    import inspect

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        async def z(self):
            return self.x + 1

    #########################################################################
    # Test obj.cached_property with a non coroutine function
    #########################################################################
    obj = MyClass()

    # Check y is a non coroutine function
    assert not inspect.iscoroutinefunction(obj.y)
    # Call it
    assert obj.y == 6

    #########################################################################
    # Test obj.cached_property with a coroutine function
    #########################################################################
    loop = asyncio.get_event_loop()


# Generated at 2022-06-23 17:58:33.415700
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit tests for class cached_property.
    """

    from copy import copy
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Setup -------------------------------------------

    # Exercise ------------------------------------------

    obj = MyClass()

    # Verify -------------------------------------------

    assert obj.y == 6

    obj.x = 10

    assert obj.y == 6

    # Cleanup ------------------------------------------

    del obj

    # Setup -------------------------------------------

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1


# Generated at 2022-06-23 17:58:40.232607
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property.
    """

    from cached_property import cached_property
    from types import FunctionType
    from flutils.decorators import cached_property as old_cached_property

    assert (cached_property.__name__ == old_cached_property.__name__)
    assert (cached_property.__module__ == old_cached_property.__module__)
    assert (cached_property.__doc__ == old_cached_property.__doc__)
    assert isinstance(cached_property, type)
    assert isinstance(cached_property.__dict__['__init__'], FunctionType)
    assert isinstance(cached_property.__dict__['__get__'], FunctionType)

# Generated at 2022-06-23 17:58:42.274626
# Unit test for constructor of class cached_property
def test_cached_property():
    assert hasattr(cached_property, '__doc__') is True
    assert cached_property.__doc__ is not None



# Generated at 2022-06-23 17:58:46.327280
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    # assert obj.y.__class__.__name__ == 'coroutine'
    assert obj.y == 6



# Generated at 2022-06-23 17:58:53.319905
# Unit test for constructor of class cached_property
def test_cached_property():
    from .decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    t = MyClass()
    assert t.x == 5
    assert t.y == 6
    assert t.__dict__['y'] == 6


#     def test_cached_property_missing(self):
#         from .decorators import cached_property
#
#         class MyClass(object):
#
#             def __init__(self):
#                 self.x = 5
#
#             @cached_property
#             def y(self):
#                 return self.x + 1
#
#         t = MyClass()
#         t.__dict__.pop('y',

# Generated at 2022-06-23 17:58:58.928632
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def calc(self):
            return self.x + 1

    test_obj = TestClass()

    # Test __get__ on cached property
    assert test_obj.calc == 6

    # Test __get__ on original attribute
    assert test_obj.x == 5



# Generated at 2022-06-23 17:59:06.234177
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property
    from flutils import coroutil
    import asyncio
    import pytest

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        @coroutil.acoroutine
        def z(self):
            yield from asyncio.sleep(1)
            return self.x * 2

    def test_cached_property___get___with_sync_method():
        obj = MyClass()
        y = obj.y
        assert y == 6
        assert obj.y == 6
        assert 'y' in obj.__dict__


# Generated at 2022-06-23 17:59:10.212787
# Unit test for constructor of class cached_property
def test_cached_property():
    # Create a class
    class Foo:
        def __init__(self):
            self.x = 5

        @cached_property
        def bar(self):
            return self.x + 1
    # Validate
    obj = Foo()
    assert obj.bar == 6

# Generated at 2022-06-23 17:59:17.580499
# Unit test for constructor of class cached_property
def test_cached_property():
    from functools import wraps
    from unittest.mock import MagicMock

    obj = MagicMock()
    func = MagicMock()
    # First time __get__ is called on cached_property object
    # First time __get__ is called on cached_property object
    cp = cached_property(func)
    cp.func = wraps(func)(cp.func)
    cp.__get__(obj, None)
    func.assert_called_once_with(obj)
    cp.func.assert_called_once_with(obj)



# Generated at 2022-06-23 17:59:22.804985
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test cached_property functionality.
    """

    class MyClass(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.x == 5
    assert obj.y == 6
    assert obj.__dict__['y'] == 6
    assert obj.__dict__['x'] == 5



# Generated at 2022-06-23 17:59:28.795175
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test the constructor of class cached_property
    """

    @cached_property
    def _test(obj):
        return 'test'

    class Test:
        def __init__(self):
            self._test = _test

    a = Test()
    assert a._test == 'test'
    assert a._test == 'test'


# Generated at 2022-06-23 17:59:36.003772
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Verify default functionality of cached_property__get__
    class MyClass(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    # Verify cached_property__get__ is idempotent
    assert obj.y == 6
    assert obj.y == 6

    # Verify cached_property__get__ works as a class instance property
    assert MyClass.y

    # Verify cached_property__get__ works with plain functions
    class MyClass(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

# Generated at 2022-06-23 17:59:44.265006
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property
    """

    def test_func():
        """
        Test function.
        """
        pass

    cached_prop = cached_property(test_func)
    assert test_func == cached_prop.func
    assert test_func.__doc__ == cached_prop.__doc__
    assert isinstance(cached_prop.__get__({}, {}), cached_property)
    assert isinstance(cached_prop.__get__({}, None), cached_property)



# Generated at 2022-06-23 17:59:50.188524
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for cached_property"""
    from unittest.mock import Mock
    import asyncio

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    obj = MyClass()
    assert obj.y == 6

    class MyClass:
        # noinspection PyUnusedLocal
        async def async_y(self, x):
            return self.x + 1

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.async_y(1)

    obj = MyClass()
    assert type(obj.y) is asyncio.Future


# Generated at 2022-06-23 17:59:53.673412
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test constructor of class cached_property"""

    # noinspection PyUnresolvedReferences,PyMissingOrEmptyDocstring
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 18:00:05.487875
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for class cached_property"""
    from unittest import TestCase
    from pytest import raises

    class TC(TestCase):

        def test_init(self):
            with raises(TypeError):
                cached_property()
            with raises(TypeError):
                cached_property(1)
            with raises(TypeError):
                cached_property(lambda: None)
            with raises(TypeError):
                cached_property('a')
            with raises(TypeError):
                cached_property(1.0)
            with raises(TypeError):
                cached_property(('a',))
            with raises(TypeError):
                cached_property(['a'])
            with raises(TypeError):
                cached_property({'a': 1})
            with raises(TypeError):
                cached_property({1})

# Generated at 2022-06-23 18:00:09.295566
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:00:18.097723
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    This is a unit test for the constructor of class cached_property.

    The :obj:`unittest.TestCase` instance
    :obj:`TestCachedProperty.test_cached_property` will automatically
    detect and call this function.
    """

    # noinspection PyUnusedLocal
    @cached_property
    def foo(self):
        return self.x + 1

    # noinspection PyUnusedLocal
    @cached_property
    def bar(self):
        return self.y + 1

    # noinspection PyUnusedLocal
    class Test1:

        def __init__(self):
            self.x = 5

    # noinspection PyUnusedLocal
    class Test2:

        def __init__(self):
            self.x = 5
            self.y = 6

# Generated at 2022-06-23 18:00:29.393312
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Unit test for the constructor of class :obj:`cached_property`.

    Since the the decorator is cached, the test method is deleted after the
    first time it is run. This prevents it from being run a second time by
    nose.

    """
    import functools
    import sys

    from flutils.miscutils import get_object_methods

    @cached_property
    def test_method(self):
        """
        A test method for cached_property.

        """
        return 5

    # Test that test_method is in the __dict__
    assert 'test_method' in get_object_methods(sys.modules[__name__],
                                               only_public=False)

    # Test that test_method is the same as functools.cached_property
    assert test_method == fun

# Generated at 2022-06-23 18:00:34.832554
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Unit test for constructor of class cached_property.
    """
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """A property decorator that is only computed once per instance and then
            replaces itself with an ordinary attribute.
            """
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    obj.x = 8
    assert obj.y == 9

    del obj.y
    obj.x = 1
    assert obj.y == 2

# Generated at 2022-06-23 18:00:35.473656
# Unit test for constructor of class cached_property
def test_cached_property():
    pass

# Generated at 2022-06-23 18:00:43.658375
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property"""

    def test():
        """Inner test method"""

        class TestCachedPropertyClass:
            """Inner test class"""
            y = cached_property(lambda self: self.x + 1)

            def __init__(self, x):
                self.x = x
        test_obj = TestCachedPropertyClass(5)
        print(test_obj.y)
        test_obj.x = 10
        print(test_obj.y)

    test()


# Generated at 2022-06-23 18:00:46.785642
# Unit test for constructor of class cached_property
def test_cached_property():
    class Test:
        # noinspection PyPep8Naming
        @cached_property
        def x(self):
            return 1729

    test = Test()
    assert test.x == 1729

# Generated at 2022-06-23 18:00:51.855026
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert isinstance(obj.y, coroutine) == False
    assert obj.y == 6
    return


if __name__ == '__main__':
    import pytest
    pytest.main(args=["-vv", "--durations=10", __file__])

# Generated at 2022-06-23 18:01:01.886081
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property

    """

    got_error = False

# Generated at 2022-06-23 18:01:12.379215
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property
    from flutils.misc import get_var_from_object
    from unittest.mock import patch

    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    obj.y
    assert get_var_from_object(obj, "y") == 6
    del obj.y
    obj2 = TestClass()
    obj2.y

    assert get_var_from_object(obj2, "y") == 6


if __name__ == "__main__":
    import pytest

    pytest.main([__file__])

# Generated at 2022-06-23 18:01:15.996214
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test cached_property class constructor."""
    def func(obj):
        return obj

    assert cached_property() == cached_property
    assert cached_property(func) != cached_property

# Generated at 2022-06-23 18:01:19.315474
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        @cached_property
        def x(self):
            return 5

    obj = MyClass()
    assert obj.x == 5



# Generated at 2022-06-23 18:01:22.134111
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property.
    """

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert MyClass().y == 6

# Generated at 2022-06-23 18:01:33.798062
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # Test 1 - Test __get__ of class cached_property with a coroutine function
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        async def y(self):
            await asyncio.sleep(0, loop=self.loop)
            return self.x + 1

    obj = MyClass()
    obj.loop = asyncio.get_event_loop()
    obj.loop.run_until_complete(obj.y)

    assert obj.y == 6
    assert isinstance(obj.__dict__['y'], asyncio.Future)

    # Test 2 - Test __get__ of class cached_property with a non-coroutine function
    class MyClass:

        def __init__(self):
            self.x = 5


# Generated at 2022-06-23 18:01:39.326789
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    import pytest
    import asyncio

    @cached_property
    def a_property(obj):
        return obj.x + 1

    class TestClass:
        x = 4

    def test_cached_property_1():
        non_cached_value = 5
        obj = TestClass()
        obj.x = non_cached_value
        assert a_property.__get__(obj, TestClass) == non_cached_value + 1

    def test_cached_property_2():
        obj = TestClass()
        obj.x = 5
        first_value = a_property.__get__(obj, TestClass)
        second_value = a_property.__get__(obj, TestClass)
        third_value = a_property.__get__(obj, TestClass)
        assert second_value

# Generated at 2022-06-23 18:01:47.474942
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    import pytest
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Test docstring is set
    assert MyClass.y.__doc__ == MyClass().y.__doc__

    # Test cached_property is returned
    assert isinstance(MyClass.y, cached_property)

    # Test cached_property.func is set
    assert callable(MyClass.y.func)

    # Test cached_property.func docstring is set
    assert MyClass.y.func.__doc__ == MyClass.y.__doc__

    # Test cached_property.func is y

# Generated at 2022-06-23 18:01:54.155303
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6
    assert obj.__dict__ == {'x': 5, 'y': 6}

# Generated at 2022-06-23 18:02:02.984004
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit tests for constructor of class :class:`~flutils.decorators.cached_property`"""

    def test1(obj):
        return obj.x + 2

    def test2(obj):
        pass

    class A:
        pass

    a = A()

    # test1 is function
    a.x = 5

# Generated at 2022-06-23 18:02:10.754003
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    try:
        from . import decorators as dec

        class _Test:
            def __init__(self, x=5):
                self.x = x

            @dec.cached_property
            def y(self):
                return self.x + 1

        obj = _Test()
        assert obj.y == 6

    except Exception as e:
        msg = "Test failed: {}".format(e)
        raise Exception(msg) from e

# Generated at 2022-06-23 18:02:16.322885
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # noinspection PyUnusedLocal
    class TestClass:

        @cached_property
        def test_cached_property(self):
            return "Test string"

    inst = TestClass()
    assert inst.test_cached_property == "Test string"

# Generated at 2022-06-23 18:02:23.760547
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # noinspection PyUnusedLocal
    def test():
        return "test"

    # noinspection PyProtectedMember
    assert cached_property(test)._cached_property__get__ is cached_property.__get__
    # noinspection PyProtectedMember
    assert cached_property(test)._cached_property__get__ is getattr(
        cached_property(test), '_cached_property__get__')
    # noinspection PyProtectedMember
    assert cached_property(test)._cached_property__get__ is getattr(
        cached_property(test), '__get__')

# Generated at 2022-06-23 18:02:32.149526
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:
        # noinspection PyMissingOrEmptyDocstring,PyMethodParameters
        @cached_property
        def my_cached_property(self):

            # noinspection PyUnusedLocal
            def my_function():
                return 'foo'

            return my_function()

    class MyClassWrapped:

        # noinspection PyMissingOrEmptyDocstring,PyMethodParameters
        @cached_property
        async def my_cached_property_wrapped(self):
            return 'bar'

    class MyClassUncached:
        # noinspection PyMissingOrEmptyDocstring,PyMethodParameters
        def my_uncached_property(self):

            # noinspection PyUnusedLocal
            def my_function():
                return 'foo'

            return

# Generated at 2022-06-23 18:02:38.621449
# Unit test for constructor of class cached_property
def test_cached_property():

    class Cache:

        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x + 2

    instance = Cache(5)
    assert instance.y == 6
    assert instance.z == 7


if __name__ == "__main__":
    test_cached_property()

# Generated at 2022-06-23 18:02:46.045181
# Unit test for constructor of class cached_property
def test_cached_property():

    from unittest import TestCase

    test = TestCase()

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    test.assertEqual(obj.y, 6)
    obj.y = 7
    test.assertEqual(obj.y, 7)

    import collections

    test.assertIsInstance(obj.y, collections.abc.Coroutine)

# Generated at 2022-06-23 18:02:51.748922
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y


if __name__ == "__main__":
    test_cached_property()

# Generated at 2022-06-23 18:02:57.225977
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import asyncio

    class Object:
        def __init__(self):
            self._counter = 0

        @cached_property
        def count(self):
            self._counter += 1
            return self._counter

    obj = Object()
    for _ in range(1000):
        assert obj.count == 1



# Generated at 2022-06-23 18:02:58.714383
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test cached_property"""
    assert hasattr(cached_property, '__init__')

# Generated at 2022-06-23 18:03:03.624006
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    assert "cached_property" in repr(obj.y)
    assert "MyClass.y" in repr(obj.y)

# Generated at 2022-06-23 18:03:08.625083
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    from flutils.decorators import cached_property
    from flutils.funcutils import identity

    class MyClass:
        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return identity(self.x)

    obj = MyClass(5)
    print(obj.y)
    print(obj.__dict__)

# Generated at 2022-06-23 18:03:16.077162
# Unit test for constructor of class cached_property
def test_cached_property():
    cnt = 0

    class CachedPropertyTests:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """doc"""
            nonlocal cnt
            cnt += 1
            return self.x * 2

        @cached_property
        def z(self):
            """doc"""
            nonlocal cnt
            cnt += 1
            return self.x * 3

        @cached_property
        def coroutine(self):
            """doc"""
            nonlocal cnt
            cnt += 1
            async def coro():
                return self.x * 4
            return coro()

    obj = CachedPropertyTests()
    # Test that the docstring is copied from the original function.
    assert CachedPropertyTests.y.__doc

# Generated at 2022-06-23 18:03:26.948672
# Unit test for constructor of class cached_property
def test_cached_property():
    import functools
    import inspect

    from flutils.decorators import cached_property

    obj = MyClass()
    assert callable(obj.y)
    assert inspect.iscoroutinefunction(obj.y)
    assert obj.y.__name__ == 'y'
    assert obj.y.__doc__ == 'My docstring'
    assert isinstance(obj.y, functools.partial)
    assert obj.y.func == MyClass.y

    obj = MyClass()
    assert callable(obj.z)
    assert inspect.iscoroutinefunction(obj.z)
    assert obj.z.__name__ == 'z'
    assert obj.z.__doc__ == 'My docstring'
    assert isinstance(obj.z, functools.partial)
    assert obj.z.func == My

# Generated at 2022-06-23 18:03:35.357664
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.y + 1

    obj = MyClass()
    assert obj.y == 6
    obj.x = 6
    assert obj.y == 6
    assert obj.z == 7
    del obj.y
    assert obj.y == 7
    obj.y = 8
    assert obj.y == 8
    assert obj.z == 9



# Generated at 2022-06-23 18:03:36.494276
# Unit test for constructor of class cached_property
def test_cached_property():
    # Check that class exists
    assert cached_property



# Generated at 2022-06-23 18:03:43.746708
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """ Tests method __get__ of class cached_property """

    import pytest

    from flutils.decorators import cached_property

    @cached_property
    def y(self):
        return self.x + 1

    def test_get_cached_property():
        obj = y()
        y.__get__(obj, y)
        return True

    assert test_get_cached_property()
    with pytest.raises(AttributeError):
        assert test_get_cached_property()

# Generated at 2022-06-23 18:03:51.660147
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Create dummy class
    class DummyClass:
        pass

    # Create dummy obj
    obj = DummyClass()

    # Set a property
    obj.new_prop = 5

    # Set property to a call to cached_property
    obj.new_prop_cached = cached_property(lambda x: 5)

    # Verify property set normally
    assert obj.new_prop == 5

    # Verify property set via cached_property
    assert obj.new_prop_cached == 5

    # Delete property set normally
    del obj.new_prop

    # Verify property deleted normally
    with pytest.raises(AttributeError):
        obj.new_prop

    # Set deleted property again
    obj.new_prop = 5

    # Verify property set normally again
    assert obj.new_prop == 5

    # Delete property set via cached

# Generated at 2022-06-23 18:04:01.673447
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test cached property
    """
    class Foo:

        @cached_property
        def bar(self):
            """Help"""
            return 'baz'

    foo = Foo()
    assert foo.bar == 'baz'
    assert isinstance(foo.bar, str)
    assert foo.__dict__['bar'] == 'baz'
    foo.bar = 'not_baz'
    assert foo.__dict__['bar'] == 'not_baz'
    del foo.bar
    assert foo.bar == 'baz'
    assert isinstance(foo.bar, str)
    assert foo.__dict__['bar'] == 'baz'
    assert repr(cached_property(lambda self: 'foo')) == '<cached_property object at 0x0>'

# Generated at 2022-06-23 18:04:06.651157
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        @cached_property
        def myfunc(self):
            return "meow"

        def __init__(self):
            pass

    obj = MyClass()
    assert obj.myfunc == "meow"



# Generated at 2022-06-23 18:04:11.174597
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest.mock import MagicMock

    obj = MagicMock(name='obj')

    @cached_property
    def my_property(self):
        pass

    assert my_property.func is not None
    assert callable(my_property.func)



# Generated at 2022-06-23 18:04:18.958619
# Unit test for constructor of class cached_property
def test_cached_property():
    """Run the unit test for constructor of class cached_property
    """
    from flutils.decorators import cached_property

    def test_decorator():
        """Sample function for decorator test
        """
        class MyClass:
            def __init__(self):
                self.x = 5
            @cached_property
            def y(self):
                return self.x + 1
        obj = MyClass()
        assert obj.y == 6

    test_decorator()

# Generated at 2022-06-23 18:04:19.867202
# Unit test for constructor of class cached_property
def test_cached_property():
    return cached_property



# Generated at 2022-06-23 18:04:24.758843
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    # del obj.y
    # assert obj.y == 6

# Generated at 2022-06-23 18:04:33.948264
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for class :obj:`~flutils.decorators.cached_property`."""

    class MyClass:
        """Class for testing :obj:`~flutils.decorators.cached_property`."""

        def __init__(self):
            """Construct the class."""
            self.x = 5

        @cached_property
        def y(self):
            """Test cached property."""
            return self.x + 1

    obj = MyClass()
    obj.y
    obj.y
    assert obj.y == 6


if __name__ == "__main__":
    test_cached_property()

# Generated at 2022-06-23 18:04:37.323253
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:04:39.057982
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import doctest
    doctest.testmod(verbose=True)
    return True


# Generated at 2022-06-23 18:04:43.953205
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class Dummy:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    d = Dummy()
    assert d.y == 6


# Generated at 2022-06-23 18:04:49.794252
# Unit test for constructor of class cached_property
def test_cached_property():
    """[Summary]

    Returns:
        [type]: [description]
    """
    class Example:
        """[Summary]

        Returns:
            [type]: [description]
        """
        def __init__(self):
            pass

        @cached_property
        def foo(self):
            """[Summary]

            Returns:
                [type]: [description]
            """
            print('running')
            return 'bar'

    example = Example()
    foo = example.foo
    assert foo == 'bar'

# Generated at 2022-06-23 18:04:56.193255
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Foo:
        @cached_property
        def foo(self):
            return "foo"

        @cached_property
        def foo_coro(self):
            return asyncio.coroutine(lambda: "foo_coro")()

    foo = Foo()

    assert foo.foo == "foo"
    assert foo.__dict__ == {"foo": "foo"}
    assert foo.foo == "foo"
    assert foo.__dict__ == {"foo": "foo"}
    del foo.foo
    assert foo.foo == "foo"

    assert foo.foo_coro == "foo_coro"
    assert foo.__dict__ == {"foo_coro": "foo_coro"}
    assert foo.foo_coro == "foo_coro"

# Generated at 2022-06-23 18:05:05.648258
# Unit test for constructor of class cached_property
def test_cached_property():
    """ Tests for the constructor of the
    :obj:`~flutils.decorators.cached_property` class.

    """
    from flutils.decorators import cached_property

    class MyClass(object):

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6
    assert obj.__dict__['y'] == 6

    obj.x = 6
    assert obj.y == 7
    assert obj.__dict__['y'] == 7

    del obj.y
    assert 'y' not in obj.__dict__
    assert obj.y == 8



# Generated at 2022-06-23 18:05:08.757083
# Unit test for constructor of class cached_property
def test_cached_property():
    class Test(object):
        def __init__(self, value):
            self.value = value

        @cached_property
        def x(self):
            return len(self.value)

    obj = Test('flutils is awesome')
    assert obj.x == 17



# Generated at 2022-06-23 18:05:11.343418
# Unit test for constructor of class cached_property
def test_cached_property():
    import sys

# Generated at 2022-06-23 18:05:16.664822
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Set up test data
    ###

    # Test isolated cached_property.__get__ method
    ###
    # Set up test data
    class Obj:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Obj()
    obj.y

    assert obj.y == 6
    #
    ###



# Generated at 2022-06-23 18:05:19.844991
# Unit test for constructor of class cached_property
def test_cached_property():
    class Test:
        @cached_property
        def x(self):
            return 5

    Test.x

# Generated at 2022-06-23 18:05:23.305510
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class A:

        def __init__(self):
            self.x = 5

        @cached_property
        def prop(self):
            return self.x + 1

    a = A()
    assert a.prop == 6



# Generated at 2022-06-23 18:05:34.554632
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__."""

    import pytest

    from flutils import decorators
    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class MyClass_2:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_property
        def z(self):
            return self.x + 1

    obj = MyClass()
    obj_2 = MyClass_2()

    assert obj.y == 6

    class MyClass_3:
        def __init__(self):
            self.x = 5

# Generated at 2022-06-23 18:05:36.570266
# Unit test for constructor of class cached_property
def test_cached_property():
    obj = cached_property(test_cached_property)  # type: ignore
    assert obj.func == test_cached_property

# Generated at 2022-06-23 18:05:37.597216
# Unit test for constructor of class cached_property
def test_cached_property():
    assert cached_property.__doc__ is not None

# Generated at 2022-06-23 18:05:42.024217
# Unit test for constructor of class cached_property
def test_cached_property():
    class Foo:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    foo = Foo()
    assert foo.y == 6



# Generated at 2022-06-23 18:05:49.657132
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import unittest
    import numbers
    import inspect
    import asyncio

    class MyClass:

        @cached_property
        def x(self):
            return 5

    class MySubClass(MyClass):

        @cached_property
        def y(self):
            return 3

        @cached_property
        async def z(self):
            return await asyncio.sleep(5, result=7)

    class MyClassTest(unittest.TestCase):

        def test_get_class(self):
            self.assertEqual(MyClass.x, cached_property)

        def test_get_object(self):
            self.assertIsInstance(MyClass().x, numbers.Number)
