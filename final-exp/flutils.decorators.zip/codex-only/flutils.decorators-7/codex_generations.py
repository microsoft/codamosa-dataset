

# Generated at 2022-06-23 17:55:55.588844
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    assert obj.y == 6
    obj.x = 7
    assert obj.y == 8
    del obj.y
    assert obj.y == 10
    del obj.y
    assert obj.y == 10

    obj.__dict__.pop('y')
    assert obj.y == 10



# Generated at 2022-06-23 17:56:03.552908
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class my_class:
        @cached_property
        def x(self):
            return 1

        @cached_property
        def y(self):
            return 2

        @cached_property
        def z(self):
            return 3

    obj = my_class()
    assert obj.x
    assert obj.y
    assert obj.z
    assert obj.x == obj.y
    assert obj.x == obj.z
    assert 'x' in obj.__dict__
    assert 'y' in obj.__dict__
    assert 'z' in obj.__dict__
    assert obj.__dict__['x'] == 1
    assert obj.__dict__['y'] == 1
    assert obj.__dict__['z'] == 1



# Generated at 2022-06-23 17:56:04.167547
# Unit test for constructor of class cached_property
def test_cached_property():
    assert True

# Generated at 2022-06-23 17:56:07.508766
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property."""
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__ == {'x': 5, 'y': 6}

# Generated at 2022-06-23 17:56:15.342967
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test cached_property.__get__

    """
    from unittest.mock import sentinel

    # Test with func not coroutine
    # noinspection PyUnusedLocal
    class TestClass:
        def __init__(self):
            self.__dict__['val'] = sentinel.val

        @cached_property
        def func(self):
            return self.__dict__['val']

    obj = TestClass()
    assert obj.func == sentinel.val

    # Test with func is coroutine
    # noinspection PyUnusedLocal
    class TestClass2:
        def __init__(self):
            self.__dict__['val'] = sentinel.val

        @cached_property
        async def func(self):
            return self.__dict__['val']


# Generated at 2022-06-23 17:56:19.834632
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test the constructor of class cached_property"""

    # instantiate class and call constructor
    obj = cached_property(lambda x: x + 1)

    # assert that the assigned func is a lambda expression
    assert obj.func == (lambda x: x + 1), (
        f'Expected {obj.func} to be '
        f'{(lambda x: x + 1)}'
    )

    # assert that the assigned __doc__ is None
    assert obj.__doc__ is None, (
        f'Expected {obj.__doc__} to be {None}'
    )


# Generated at 2022-06-23 17:56:28.366278
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property


    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1


    obj = MyClass()
    assert obj.y == 6
    assert obj.y == 6
    obj.x = 6
    assert obj.y == 7
    assert obj.y == 7
    del obj.y
    assert obj.y == 7
    assert obj.y == 7



# Generated at 2022-06-23 17:56:33.543734
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""
    class Test:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):  # noqa: D205,D400
            """Test y."""
            return self.x + 1

    obj = Test()
    obj.y
    del obj.y
    obj.y

# Generated at 2022-06-23 17:56:38.669662
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property."""

    @cached_property
    def y(self):
        return self.x + 1

    class MyClass:

        def __init__(self):
            self.x = 5

    obj = MyClass()
    assert obj.y == 6, 'Unit test for cached_property fails!'

# Generated at 2022-06-23 17:56:47.881806
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest

    class TestClass:
        """Example class for testing cached_property"""
        def __init__(self):
            self.x = 0

        @cached_property
        def get_x(self):
            return self.x + 1

    test = TestClass()
    assert test.get_x == 1
    test.x = 5
    assert test.get_x == 1

    class TestClassAsync:
        """Example class for testing cached_property with async"""
        def __init__(self):
            self.x = 0

        @cached_property
        async def get_x(self):
            return self.x + 1

    with pytest.raises(TypeError, match='not an async'):
        # noinspection PyTypeChecker
        test_async = TestClassAsync()
        test

# Generated at 2022-06-23 17:56:51.829956
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():  # noqa: D103
    from flutils.decorators import cached_property

    class C:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = C()
    assert obj.y == 6

# Generated at 2022-06-23 17:56:55.473378
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 17:57:07.467090
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from collections import namedtuple
    from flutils.decorators import cached_property
    TestParam = namedtuple('TestParam', ['obj', 'cls', 'expected'])
    TestParam.__new__.__defaults__ = (None,)
    params = (
        TestParam(obj=None, expected=(cached_property, None)),
        TestParam(obj=object(), expected=(object(), None)),
        TestParam(obj=cached_property(lambda: None), expected=(int, 1)),
        TestParam(obj=cached_property(lambda: True), expected=(bool, True)),
        TestParam(obj=cached_property(lambda: False), expected=(bool, False)),
        TestParam(
            obj=cached_property(lambda: 1),
            expected=(int, 1),
        ),
    )

# Generated at 2022-06-23 17:57:15.795848
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert callable(obj.__dict__['y']) is False
    obj.x = 7
    assert obj.y == 6
    del obj.y
    assert obj.y == 8
    assert callable(obj.__dict__['y']) is False


# Generated at 2022-06-23 17:57:20.770319
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 17:57:25.303466
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property.
    """

    class A:

        def __init__(self):
            """Constructor for A.
            """
            self.x = 5

        @cached_property
        def y(self):
            """ Property method for y.
            """
            return self.x + 1

    a = A()
    assert a.y == 6
    a.x = 10
    assert a.y == 11
    # Test if property y is cached
    a.x = 15
    assert a.y == 11

# Generated at 2022-06-23 17:57:28.879134
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Arrange
    from flutils.decorators import cached_property
    from flutils.decorators import _test_decorators

    # Act
    @cached_property
    def foo():
        return "foo"

    obj = _test_decorators.A()
    result = obj.foo

    # Assert
    assert result == "foo"
    assert obj.__dict__["foo"] == result



# Generated at 2022-06-23 17:57:32.224040
# Unit test for constructor of class cached_property
def test_cached_property():
    class A:
        def __init__(self, a):
            self.a = a

        @cached_property
        def y(self):
            return self.a * 2

    a = A(2)
    assert a.y == 4

# Generated at 2022-06-23 17:57:40.240132
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""
    import pytest
    from flutils.decorators import cached_property

    class TestClass(object):

        def __init__(self, value):
            self.value = value

        @cached_property
        def add_one(self):
            return self.value + 1

    # test 1: not a TestClass
    with pytest.raises(AttributeError) as err:
        cached_property.__get__(None, object)

    assert "object has no attribute '__dict__'" in str(err.value)

    # test 2: TestClass not cached
    obj = TestClass(value=4)
    assert obj.__dict__ == {'value': 4}
    assert obj.add_one == 5

# Generated at 2022-06-23 17:57:45.036232
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    import pytest
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    obj.y = 7

    with pytest.raises(AttributeError):
        obj.y

    del obj.y

    assert obj.y == 6

# Generated at 2022-06-23 17:57:50.359028
# Unit test for constructor of class cached_property
def test_cached_property():

    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert isinstance(MyClass.y, cached_property)

# Generated at 2022-06-23 17:57:51.781483
# Unit test for constructor of class cached_property
def test_cached_property():
    return True


# Generated at 2022-06-23 17:57:54.839128
# Unit test for constructor of class cached_property
def test_cached_property():
    """Test the constructor of class cached_property
    """

    # Check attributes of class cached_property
    @cached_property
    def foo(self):
        pass

    assert foo.__doc__ is None



# Generated at 2022-06-23 17:58:07.635161
# Unit test for constructor of class cached_property
def test_cached_property():

    from unittest import mock, TestCase
    from asyncio import ensure_future

    class MyClass(object):
        def __init__(self):
            pass

        @cached_property
        def foo(self):
            return 'bar'

        @cached_property
        async def bar(self):
            return 'foo'

    class TestCachedProperty(TestCase):
        def test_attribute(self):
            obj = MyClass()
            assert obj.foo == 'bar'
            with self.assertRaises(AttributeError):
                obj.__dict__['foo']
            with self.assertRaises(KeyError):
                obj.__dict__.pop('foo')
            assert obj.foo == 'bar'

        def test_async_attribute(self):
            obj = MyClass()
            future = ensure_future

# Generated at 2022-06-23 17:58:10.483578
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    t = cached_property(lambda x: "test")
    assert t.__get__(None, None) is t
    obj = type("", (), {})()
    assert t.__get__(obj, None) == "test"



# Generated at 2022-06-23 17:58:22.045658
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for class cached_property"""

    from unittest import TestCase

    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class TestCachedProperty(TestCase):

        def setUp(self):
            self.obj = MyClass()

        def test_value(self):
            """Test value."""
            expected = self.obj.y
            actual = 6
            msg = f"\nexpected: {expected}\nactual: {actual}"
            self.assertEqual(expected, actual, msg)

    unittest.main(verbosity=2)

# Generated at 2022-06-23 17:58:23.818169
# Unit test for constructor of class cached_property
def test_cached_property():

    from flutils.decorators import cached_property

    class MyClass:
        """Test class."""

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 17:58:28.286458
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method `cached_property.__get__`
    """
    class TestClass:
        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    obj.x = 5
    assert obj.y == 6

# Generated at 2022-06-23 17:58:36.901589
# Unit test for constructor of class cached_property
def test_cached_property():

    from unittest import TestCase

    class TestCached_property(TestCase):

        def test_doc_string_inherited(self):
            class ClassX:
                @cached_property
                def x(self):
                    "doc string for x"
                    return 0

            class ClassY:
                @cached_property
                def y(self):  # pragma: no cover
                    "doc string for y"
                    return 0

            for Class in [ClassX, ClassY]:
                # noinspection PyUnresolvedReferences
                c = Class.x
                # noinspection PyUnresolvedReferences
                self.assertEqual(c.__doc__, "doc string for x")

                # noinspection PyUnresolvedReferences
                c = Class.y
                # noinspection PyUnresolvedReferences
                self

# Generated at 2022-06-23 17:58:40.005634
# Unit test for constructor of class cached_property
def test_cached_property():

    class Foo:

        @cached_property
        def process(self):
            return "test"

    foo = Foo()
    assert foo.process == "test"

# Generated at 2022-06-23 17:58:45.236044
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for :func:`flutils.decorators.cached_property`."""
    from flutils.decorators import cached_property

    class CachedPropertyTest:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj: CachedPropertyTest = CachedPropertyTest()
    assert obj.y == 6

# Generated at 2022-06-23 17:58:51.660404
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test method cached_property.__get__
    """

    @cached_property
    def x(obj):
        return 5 + 1

    class MyClass:
        def __init__(self):
            self.x = 5

    obj = MyClass()
    # Property has not been evaluated yet.
    assert "x" not in obj.__dict__
    assert x.__get__(obj) == 6
    # Property has been evaluated
    assert "x" in obj.__dict__



# Generated at 2022-06-23 17:58:58.730664
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """ Unit testing of method __get__ of class cached_property
        using the example from:
        `cached_property <https://bit.ly/2R9U3Qa>`__.
    """
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 17:59:01.832343
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 17:59:12.169214
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property.

    Not referenced by other code.

    """

    import inspect
    import sys

    def func(x, y, z=3):
        pass

    cp = cached_property(func)
    assert inspect.iscoroutinefunction(cp.func) is False

    if sys.version_info >= (3, 8):
        import functools
        cp = cached_property(functools.cached_property)
        assert inspect.iscoroutinefunction(cp.func) is False
    else:
        import functools
        cp = cached_property(functools.cached_property)
        assert inspect.iscoroutinefunction(cp.func) is False

    if sys.version_info >= (3, 8):
        import functools

# Generated at 2022-06-23 17:59:18.629676
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators.tests._common import Common

    class C(Common):

        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    obj_c1 = C(5)
    assert obj_c1.y == 6
    assert obj_c1._test_y(5) == 6
    obj_c1.x = 6
    assert obj_c1.y == 6
    assert obj_c1._test_y(6) == 6



# Generated at 2022-06-23 17:59:25.091795
# Unit test for constructor of class cached_property
def test_cached_property():
    from .helpers import assert_equal, raise_error
    from .types_ import Object

    class CachedPropertyTest(Object):

        # noinspection PyPep8Naming
        def __init__(self):
            # noinspection PyPep8Naming
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert_equal(CachedPropertyTest().y, 6)

    class CachedPropertyDocTest(Object):

        # noinspection PyPep8Naming
        def __init__(self):
            # noinspection PyPep8Naming
            self.x = 5

        @cached_property
        def y(self):
            """Return y."""
            return self.x + 1


# Generated at 2022-06-23 17:59:30.967272
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def func(self):
            """I am a function"""
            return self.x + 1

    obj = MyClass()
    print(obj.func)
    print(obj.func)
    print(obj.__dict__)
    assert obj.func == 6


# Generated at 2022-06-23 17:59:33.179674
# Unit test for constructor of class cached_property
def test_cached_property():
    cp = cached_property(None)
    cp.func
    cp.__doc__



# Generated at 2022-06-23 17:59:37.145787
# Unit test for constructor of class cached_property
def test_cached_property():
    class A:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    a_instance = A()
    y = a_instance.y
    assert y == 6

# Generated at 2022-06-23 17:59:42.498131
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest.mock import MagicMock

    obj = MagicMock()
    cp = cached_property(1)
    assert cp.func == 1
    assert cp.__doc__ is None

    cp = cached_property(lambda x: x)
    assert cp.__doc__ == 'lambda x: x'



# Generated at 2022-06-23 17:59:48.548363
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    def method(a):
        return a + 1

    test_obj = cached_property(method)
    assert test_obj.__get__(0, 0) == 1


if __name__ == "__main__":
    import pytest

    pytest.main([str(__file__.replace("\\", "/")), "-vv", "--pdb"])

# Generated at 2022-06-23 17:59:51.665244
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    m = MyClass()
    assert m.y == 6

# Generated at 2022-06-23 17:59:55.613319
# Unit test for constructor of class cached_property
def test_cached_property():
    try:
        from functools import cached_property
    except ImportError:
        print("Using flutils cached property.")
    else:
        print("Using Python 3.8+ default cached property.")


if __name__ == '__main__':
    import sys
    sys.exit(test_cached_property())

# Generated at 2022-06-23 17:59:58.857373
# Unit test for constructor of class cached_property
def test_cached_property():
    obj = cached_property(lambda x: x)
    assert isinstance(obj, cached_property) and len(obj.__dict__) == 2

# Generated at 2022-06-23 18:00:04.760506
# Unit test for constructor of class cached_property
def test_cached_property():
    from pytest import raises

    @cached_property
    def add_me(self):
        return self.x + 1

    class TestClass:

        x = 5

    test_obj = TestClass()
    assert add_me.__get__(test_obj, TestClass) == 6
    with raises(AttributeError):
        add_me.__get__(test_obj, None)



# Generated at 2022-06-23 18:00:15.065617
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():  # pylint: disable=invalid-name
    """Test :func:`~flutils.decorators.cached_property.__get__` method of
    :class:`~flutils.decorators.cached_property` class.

    """

    from flutils.decorators import cached_property

    class DummyClass:  # pylint: disable=missing-class-docstring
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = DummyClass()
    assert obj.y == 6


if __name__ == "__main__":
    import sys
    import doctest

    doctest.testmod()
    sys.exit(doctest.testmod()[0])

# Generated at 2022-06-23 18:00:16.986270
# Unit test for constructor of class cached_property
def test_cached_property():
    pass

# Generated at 2022-06-23 18:00:20.797224
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            self.x += 1
            return self.x

    obj = MyClass()
    assert obj.y == 6
    assert obj.y == 6



# Generated at 2022-06-23 18:00:32.296732
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test the cached_property __get__ method
    
    """
    # Unit test for the cached_property method __get__
    #
    # Creates a class with an attribute that is a cached_property
    class CachedPropTest:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    print('Unit test for cached_property.__get__')
    # Create an instance of CachedPropTest
    cpt = CachedPropTest()
    # Look at what is stored in the instance __dict__ for 'y'
    # before accessing the cached_property
    #
    print(f"\nInstance dict before getting cached_property: {cpt.__dict__}")
    # Access the cached_property and then look

# Generated at 2022-06-23 18:00:39.789827
# Unit test for constructor of class cached_property
def test_cached_property():
    class TestCachedProperty:
        calls = 0

        @cached_property
        def x(self):
            self.calls += 1
            return "foo"

    t = TestCachedProperty()
    assert t.x == "foo"
    assert t.x == "foo"
    assert t.calls == 1

    del t.x
    assert t.x == "foo"
    assert t.x == "foo"
    assert t.calls == 2

# Generated at 2022-06-23 18:00:43.805632
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 18:00:52.696388
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import os
    import pathlib
    from tempfile import TemporaryDirectory

    class MockedFileSystem:
        """Mocked file system class."""

        def get_stat(self):
            return os.stat(self._path)

        def get_files(self):
            return os.listdir(self._path)

        def __init__(self, path):
            if not os.path.exists(path):
                self._path = TemporaryDirectory().name
            else:
                self._path = path

        @cached_property
        def stat(self):
            return self.get_stat()

        @cached_property
        def files(self):
            return self.get_files()

    # Test 1
    obj = MockedFileSystem(pathlib.Path.home())

# Generated at 2022-06-23 18:00:58.769862
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property."""

    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    # Verify the property value is cached
    assert isinstance(obj.y, int)

# Generated at 2022-06-23 18:01:01.745892
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:01:11.588777
# Unit test for constructor of class cached_property
def test_cached_property():
    from functools import partial
    from collections import namedtuple

    cls = namedtuple('cached_property', 'func')
    instance_dict = {}

    for func in (
        partial(lambda x: x + 1, 5),
        partial(lambda x: x - 1, 5),
        partial(lambda x, y: x + y, 5, 10)
    ):
        cp = cls(func)
        doc = getattr(func, '__doc__')
        assert cp.__doc__ == doc
        assert cp.func is func
        assert cp.__get__(instance_dict, cls) == func(instance_dict)



# Generated at 2022-06-23 18:01:20.826411
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestClass:

        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return id(self)

    @cached_property
    def y2(self):
        return id(self)

    y_val = y2(TestClass(5))
    obj = TestClass(5)

    assert y_val == obj.y
    assert obj.__dict__['y'] == obj.__dict__['y']


# Generated at 2022-06-23 18:01:27.326692
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for the constructor of class cached_property"""

    # pylint: disable=unused-variable,unused-argument

    class TestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:01:33.505523
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.calls = 0

        @cached_property
        def x(self):
            self.calls += 1
            return self.calls

    obj = MyClass()
    for i in range(3):
        assert obj.x == 1
    assert obj.calls == 1

    del obj.x
    for i in range(3):
        assert obj.x == 2
    assert obj.calls == 2

# Generated at 2022-06-23 18:01:43.251025
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import inspect
    import sys
    import unittest
    from flutils.decorators import cached_property


    # noinspection PyAttributeOutsideInit
    class PythonTest(unittest.TestCase):

        # noinspection PyAttributeOutsideInit
        class _MyClass:

            def __init__(self):
                self.x = 5

            @cached_property
            def y(self):
                return self.x + 1

            @cached_property
            def z(self):
                self.x += 1
                return self.x + 1

        def test_001(self):
            # Test a normal cached_property hits the __get__ method
            obj = PythonTest._MyClass()
            y = obj.y
            self.assertEqual(y, 6)

# Generated at 2022-06-23 18:01:53.286819
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import pytest
    import asyncio
    from unittest.mock import Mock

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    cp = cached_property(Mock(spec_set=['__get__']))
    cp.func.__get__ = Mock(
        return_value='something',
        spec_set=['return_value']
    )
    result = cp.__get__(obj, None)
    assert result == 'something'
    assert cp.func.__get__.called_with(obj, None)


# Generated at 2022-06-23 18:02:01.216541
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import unittest
    import inspect

    expected = 6

    class TestObj(object):

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class TestCachedProperty(unittest.TestCase):

        def test_cached__property_on_object(self):
            test_obj = TestObj()
            self.assertEqual(test_obj.y, expected)

        def test_cached_property_on_class(self):
            self.assertTrue(
                inspect.iscoroutinefunction(TestObj().y)
            )

    unittest.main()

# Generated at 2022-06-23 18:02:09.788705
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class _Test:

        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    obj = _Test(5)
    obj.y
    obj.__dict__['y'] = 10
    assert obj.__dict__['y'] == 10
    obj.__dict__['y'] = 10
    obj.x = 0
    assert obj.__dict__['y'] == 10

# Generated at 2022-06-23 18:02:17.091758
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    def _get__():
        class MyClass:
            def __init__(self, name):
                self.name = name

            @cached_property
            def name_upper(self):
                return self.name.upper()

        class MyClassAsync:
            def __init__(self, name):
                self.name = name

            @cached_property
            async def name_upper(self):
                await asyncio.sleep(1)
                return self.name.upper()

        _name = 'abc'
        _name_upper = 'ABC'
        my_class = MyClass(_name)
        assert my_class.name_upper == _name_upper

        my_class_async = MyClassAsync(_name)
        assert my_class_async.name_upper == _name_upper

    _get__()

# Generated at 2022-06-23 18:02:27.968861
# Unit test for method __get__ of class cached_property

# Generated at 2022-06-23 18:02:33.641207
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    print(obj.y)

    assert obj.y == 6
    assert obj.__dict__['y'] == 6



# Generated at 2022-06-23 18:02:38.662739
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert isinstance(obj.y, int)
    assert obj.y == obj.__dict__['y']


# Generated at 2022-06-23 18:02:44.967853
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # noinspection PyPep8Naming
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    assert obj.__dict__ == {'x': 5, 'y': 6}



# Generated at 2022-06-23 18:02:56.168089
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Function named after the Class.Method to test.

    This function will be removed by the setup.py clean command.
    """

    def m1(self):
        return 'm1'

    def m2(self):
        return 'm2'

    class C:
        @cached_property
        def f(self):
            return m1(self)

        @f.setter
        def f(self, val):
            pass

        @f.deleter
        def f(self):
            pass

        @cached_property
        def g(self):
            return m2(self)

        @g.setter
        def g(self, val):
            pass

        @g.deleter
        def g(self):
            pass

    c1 = C()
    assert c1.f

# Generated at 2022-06-23 18:03:01.055558
# Unit test for constructor of class cached_property
def test_cached_property():
    class C:
        def __init__(self, value):
            self.x = 5
            self.value = value

        @cached_property
        def y(self):
            return self.x + self.value

    c = C(10)
    c.y
    assert(c.y == 15)

    c.x = 6
    assert(c.y == 15)

# vim: set fileencoding=utf-8 ts=4 sw=4 tw=0 et :

# Generated at 2022-06-23 18:03:06.055734
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test :meth:`cached_property.__get__` method.
    """

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # This example is inlined from the source.
    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 18:03:14.941357
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """ Unit test for method __get__ of class cached_property """
    from unittest.mock import patch

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            """ Return x plus 1 """
            return self.x + 1

    obj = MyClass()

    expected = 6
    patch.object(MyClass, 'x', expected).start()
    result = obj.y
    assert result == expected

    assert 'y' in obj.__dict__
    assert isinstance(obj.__dict__['y'], int)
    assert obj.__dict__['y'] == expected

    assert obj.y == expected

    MyClass.x = 10
    actual = obj.__dict__['y']
    assert actual == expected


# Generated at 2022-06-23 18:03:18.704626
# Unit test for constructor of class cached_property
def test_cached_property():

    class MyClass:

        def __init__(self):
            self.x = 7

        @cached_property
        def y(self):
            return self.x + 1

    assert isinstance(MyClass.y, cached_property)



# Generated at 2022-06-23 18:03:22.775444
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class A:
        @cached_property
        def prop(self):
            return 0

    a = A()

    assert a.prop == 0
    a.__dict__['prop'] = 1
    assert a.prop == 1



# Generated at 2022-06-23 18:03:25.393907
# Unit test for constructor of class cached_property
def test_cached_property():

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:03:35.443703
# Unit test for constructor of class cached_property
def test_cached_property():
    # parameterized test parameters
    param = [
        # test case 1
        {
            'doc': 'test',
            'prop_val': 'test'
        },
        # test case 2
        {
            'doc': None,
            'prop_val': 'test'
        }
    ]
    # perform tests
    for par in param:
        # test case 1
        @cached_property
        def my_prop(x):
            return par['prop_val']

        # run test
        obj = my_prop('test')
        assert obj.func.__doc__ == par['doc']
        assert obj.func('test') == par['prop_val']



# Generated at 2022-06-23 18:03:38.612510
# Unit test for constructor of class cached_property
def test_cached_property():
    class ATestClass(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    assert ATestClass().y == 6, 'Cached property is behaving strangely'

# Generated at 2022-06-23 18:03:41.640201
# Unit test for constructor of class cached_property
def test_cached_property():
    obj = MyClass()
    assert obj.y == 6


# Generated at 2022-06-23 18:03:49.315265
# Unit test for constructor of class cached_property
def test_cached_property():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    test_obj = MyClass()

    # get returns value
    assert test_obj.y == 6

    # setting value overwrites cached value
    test_obj.y = 7

    # set returns a value
    assert test_obj.y == 7

    # getting value returns raw data
    assert test_obj.__dict__['y'] == 7

    # delete cached value
    del test_obj.__dict__['y']

    # get new value
    assert test_obj.y == 6

# Generated at 2022-06-23 18:03:52.449997
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # TODO: (_cached_property__get___test) [2020-05-30]
    assert True, "Not yet implemented"


# Generated at 2022-06-23 18:04:02.589121
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import asyncio
    import pytest
    import sys

    @cached_property
    def cached_coro(self):
        return 'x'

    class Foo:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

        @cached_coro
        async def coro(self):
            return 'x'

    if sys.version_info < (3, 5):
        pytest.skip('asyncio is not supported for current python version')
    else:
        f = Foo()
        loop = asyncio.get_event_loop()
        assert f.x == 5
        assert f.__dict__.get('y') is None
        assert f.__dict__.get('coro') is None

# Generated at 2022-06-23 18:04:13.339952
# Unit test for constructor of class cached_property
def test_cached_property():
    """
    Unit test for constructor of class :obj:`flutils.decorators.cached_property`

    Args:
        None

    Returns:
        None

    """
    from inspect import isfunction
    from flutils.decorators import cached_property
    from flutils.funcutils import function_friendly_name

    @cached_property
    def getter():
        pass

    assert (
        repr(getter) == "<cached_property: getter>"
    ), f"Repr mismatch, got: {repr(getter)}"
    assert (
        function_friendly_name(getter) == "getter"
    ), f"Friendly name mismatch, got: {function_friendly_name(getter)}"

# Generated at 2022-06-23 18:04:18.074078
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    assert obj.__dict__ == {'x': 5, 'y': 6}

# Generated at 2022-06-23 18:04:27.976867
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # create a special object class
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # assert initial state
    my_object = MyClass()
    assert MyClass.__dict__['y'] is not None
    assert MyClass.y is not None
    assert my_object.__dict__['y'] is None
    assert my_object.y == 6

    # assert it does not change values
    my_object.x = 5
    assert my_object.y == 6
    my_object.x = 10
    assert my_object.y == 6

    # delete property
    del my_object.y
    assert my_object.__dict__['y'] is None
    assert my_object.y

# Generated at 2022-06-23 18:04:35.429888
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class Foo:

        def __init__(self):
            self.x = 1

        @cached_property
        def y(self):
            return self.x + 1

    foo1 = Foo()

    assert foo1.y == 2
    assert foo1.y == 2
    assert foo1.y == 2

    foo1.x = 2

    assert foo1.y == 3

    foo2 = Foo()

    assert foo2.y == 2


##

# Generated at 2022-06-23 18:04:40.652634
# Unit test for constructor of class cached_property
def test_cached_property():

    class MyClass:
        def __init__(self):
            self.x = 5

        # noinspection PyPep8Naming
        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


# noinspection PyPep8Naming

# Generated at 2022-06-23 18:04:52.472823
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method :meth:`~flutils.decorators.cached_property.cached_property.__get__`"""
    from io import StringIO
    from unittest import mock
    from flutils.decorators import cached_property


    class TestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.y == 6
    obj.x = 6
    assert obj.y == 6

    class TestClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1


# Generated at 2022-06-23 18:04:59.808145
# Unit test for constructor of class cached_property
def test_cached_property():
    """Unit test for constructor of class cached_property"""
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:05:08.594037
# Unit test for constructor of class cached_property
def test_cached_property():
    from unittest.mock import MagicMock
    from unittest.mock import patch
    from flutils.utils import FlUtilsDeprecationWarning
    from flutils.decorators import cached_property
    import warnings

    warnings.simplefilter('ignore', FlUtilsDeprecationWarning)

    props = {'calls': 0}

    class _Class:
        @cached_property
        def _cached_property(self):
            props['calls'] += 1
            return 'value'

    class _ClassDeprecation:
        @cached_property  # type: ignore
        def _cached_property(self):
            props['calls'] += 1
            return 'value'

    c = _Class()
    assert c._cached_property == 'value'
    assert props['calls'] == 1

# Generated at 2022-06-23 18:05:18.521551
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    del obj.y
    assert obj.y == 6
    assert 'y' in obj.__dict__

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            yield from asyncio.sleep(0.01)
            return self.x + 1

    loop = asyncio.get_event_loop()
    obj = MyClass()
    assert loop.run_until_complete(obj.y) == 6
    assert isinstance(obj.__dict__['y'], asyncio.Future)


# Generated at 2022-06-23 18:05:20.756188
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass



# Generated at 2022-06-23 18:05:29.129057
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property.

    """
    import sys
    import unittest

    # noinspection PyPropertyAccess
    class Obj:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Obj()
    # noinspection PyPropertyAccess
    assert obj.y == 6
    assert obj.y is obj.y

    # noinspection PyPropertyAccess
    class Obj2:

        def __init__(self):
            self.x = 5

        @cached_property
        async def y(self):
            return self.x + 1


# Generated at 2022-06-23 18:05:33.797680
# Unit test for constructor of class cached_property
def test_cached_property():
    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-23 18:05:43.557410
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test the cached_property descriptor's __get__ method.
    """

    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5
            self.y = 10

        @cached_property
        def z(self):
            return self.y + 1

    c = MyClass()

    # Test the property's __get__ method
    assert c.__dict__['z'] == c.z
    assert c.z == 11

    # Test that the cached property is actually cached
    c.y = 15
    assert c.__dict__['z'] == 11
    assert c.z == 11

    # Test that we get the same value when asking for c.z again
    assert c.__dict__['z'] == c.z
    assert c.z

# Generated at 2022-06-23 18:05:46.258873
# Unit test for constructor of class cached_property
def test_cached_property():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-23 18:05:50.811829
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import unittest

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x

    obj = MyClass()
    setattr(obj, 'y', 6)

    class Test(unittest.TestCase):
        def test(self):
            self.assertEqual(obj.y, 6)

    if __name__ == '__main__':
        unittest.main()