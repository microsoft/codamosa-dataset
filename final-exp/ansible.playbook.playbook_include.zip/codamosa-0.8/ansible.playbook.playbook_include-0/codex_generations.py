

# Generated at 2022-06-11 10:28:51.083909
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # Mock a playbook
    from ansible.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.parsing.yaml.loader import AnsibleLoader

    playbook = Playbook()

    playbook._entries.append(Task().load({'name': 'task1'}, variable_manager=None, loader=AnsibleLoader))

# Generated at 2022-06-11 10:29:02.845937
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    pl = PlaybookInclude()

    # vars can be a dict
    ds = dict(vars=dict(foo='bar'))
    new_ds = pl.preprocess_data(ds)
    assert new_ds['vars'] == dict(foo='bar')

    # vars can be a list of k=v pairs
    ds = dict(vars=[('foo', 'bar'), ('baz', 'boo')])
    new_ds = pl.preprocess_data(ds)
    assert new_ds['vars'] == dict(foo='bar', baz='boo')

    # vars can be a list of k=v pairs str
    ds = dict(vars=['foo=bar', 'baz=boo'])
    new_ds = pl.preprocess_data(ds)

# Generated at 2022-06-11 10:29:04.321082
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-11 10:29:13.907894
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import sys
    import os
    import pytest
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Test with empty input
    datastructure = {}
    expect_datastructure = {}
    pbi = PlaybookInclude()
    pbi.preprocess_data(datastructure)
    assert datastructure == expect_datastructure

    # Test with single key-value input
    datastructure = {'foo': 'bar'}
    expect_datastructure = {'foo': 'bar'}
    pbi = PlaybookInclude()
    pbi.preprocess_data(datastructure)
    assert datastructure == expect_datastructure

    # Test

# Generated at 2022-06-11 10:29:25.293634
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    a = PlaybookInclude()
    ds = dict(import_playbook='/my/playbook.yml', vars=dict(var1='a'))
    basedir = '/'
    variable_manager = VariableManager()
    loader = DataLoader()

    pb = a.load_data(ds=ds, basedir=basedir, variable_manager=variable_manager, loader=loader)

    # Just check that load_data has returned a Playbook object
    assert isinstance(pb, Playbook)

# Generated at 2022-06-11 10:29:36.933205
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook = """
- fail: msg="test"
"""

    # Create a temporary file
    import tempfile
    tmpfile = tempfile.NamedTemporaryFile(mode='w+t', delete=False, dir='.')
    tmpfile.write(playbook)
    tmpfile.close()

    # Create a temporary directory
    import tempfile
    d = tempfile.mkdtemp()

    # Create a fake playbook's path
    import os
    fake_pb = os.path.join(d, 'fake_pb.yml')

    # Write the real playbook into our fake playbook
    import shutil
    shutil.copy(tmpfile.name, fake_pb)

    # Remove the temporary file
    os.remove(tmpfile.name)

    # Test if method load_data fails when path of playbook to import is incorrect
   

# Generated at 2022-06-11 10:29:47.627293
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # noinspection PyPep8Naming,PyUnusedLocal
    class MockParams:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    # noinspection PyPep8Naming,PyUnusedLocal
    class MockPlay:
        def __init__(self, **kwargs):
            self._attributes = {}
            self.__dict__.update(kwargs)

    # noinspection PyPep8Naming,PyUnusedLocal
    class MockBase(Base):
        def _get_task_entries(self, *args, **kwargs):
            return []

        def load_data(self, ds, variable_manager, loader):
            return self

    # noinspection PyPep8Naming,PyUnusedLocal

# Generated at 2022-06-11 10:30:00.030927
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task import Task
    from ansible.playbook.task.include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    ds = {}
    ds["import_playbook"] = "./test.yaml"
    ds["vars"] = {"var1": "value1", "var2": "value2"}
    ds["tags"] = ["tag1", "tag2"]
    ds["when"] = "some condition"

    templar = Templar(loader=None)

    display.deprecated("The current approach of importing playbooks is deprecated.")

# Generated at 2022-06-11 10:30:00.742798
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:30:01.476412
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:30:16.535953
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    test_host = 'hostname'
    data = {'hosts': test_host, 'vars': {'test_var': 'test_val'}, 'tasks': [{'name': 'test_name', 'debug': {'msg': 'test_msg'}}]}
    basedir = os.getcwd()
    """
    Following code block is to test the scenario where the provided
    import_playbook file is an absolute file path
    """
    # Generate dummy file with the playbook data
    playbook_file_abspath = 'test_PlaybookInclude_load_data.yml'
    playbook_file_abspath = os.path.abspath(to_bytes(playbook_file_abspath, errors='surrogate_or_strict'))

# Generated at 2022-06-11 10:30:20.273130
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    class TestPlaybookInclude1(PlaybookInclude):
        def __init__(self):
            self.import_playbook = 'test.yml'

    p = TestPlaybookInclude1()
    assert p is not None



# Generated at 2022-06-11 10:30:30.616236
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    import ansible.playbook.playbook_include as PlaybookInclude
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    from ansible.template import Templar

    data = """
---
- import_playbook: slb-delete.yml
  vars:
    name: remove
    b: 2
"""
    expected_data = AnsibleMapping()
    expected_data["import_playbook"] = "slb-delete.yml"
    expected_vars = AnsibleMapping()
    expected_vars["name"] = "remove"
    expected_vars["b"] = 2
    expected_data["vars"] = expected_vars

    ds = PlaybookInclude.PlaybookInclude.load(data, "/")

# Generated at 2022-06-11 10:30:40.398740
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import unittest
    import runpy
    test_data = runpy.run_path('test/units/parsing/yaml/fixtures/playbook_include_01.yml')

    variable_manager = None
    loader = None

    include = PlaybookInclude.load(data=test_data['include_data'], basedir='/tmp', variable_manager=variable_manager, loader=loader)

    assert include.vars['test_var'] == 'test_value'
    assert include.vars['test_var2'] == 'test_value2'

    assert len(include) == 4

    # Check each of the plays
    for play in include.get_plays():
        if play.name == "test_play_01":
            assert play.vars['test_var'] == 'test_value'
           

# Generated at 2022-06-11 10:30:51.678563
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # All playbooks should be loaded via PlaybookInclude if there is a when condition
    # so that loader can set the playbook _included_conditional attribute correctly

    import os
    from ansible.playbook import Playbook

    test_script_dir = os.path.dirname(os.path.realpath(__file__))

    playbook = PlaybookInclude.load(
        {'import_playbook': 'import.yml'},
        basedir=test_script_dir,
    )

    assert isinstance(playbook, Playbook)

    playbook = PlaybookInclude.load(
        {'when': 'ansible_facts["distribution"] == "Debian"', 'import_playbook': 'import.yml'},
        basedir=test_script_dir,
    )


# Generated at 2022-06-11 10:31:01.609544
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    print("\n---- test class PlaybookInclude, method load_data")
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    # declared path under tests/
    test_path = 'data/playbooks/playbook_include/playbook1.yml'
    # create the object we want to test
    playbook = PlaybookInclude.load(test_path, '/home/ansible/')
    # check the loaded object
    assert playbook.__class__ == Playbook
    assert len(playbook._entries) == 2
    assert playbook._entries[0].__class__ == Play
    assert playbook._entries[1].__class__ == Play


# Generated at 2022-06-11 10:31:12.865068
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.module_utils._text import to_text
    from ansible.parsing.dataloader import DataLoader

    b_test_base_dir = to_bytes(os.path.dirname(__file__))
    t_test_base_dir = to_text(b_test_base_dir, errors='surrogate_or_strict')

    loader = DataLoader()
    playbook_include = PlaybookInclude()

    t_path = u"test_playbook_include"
    b_path = to_bytes(t_path, errors='surrogate_or_strict')
    b_parent_path = os.path.join(b_test_base_dir, b'../', b_path)

# Generated at 2022-06-11 10:31:24.714956
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include = PlaybookInclude()

    # Test import with tags, vars and extra params
    ds1 = AnsibleMapping()
    ds1['import_playbook'] = 'myplaybook'
    ds1['tags'] = 'imported'
    ds1['vars'] = {'key1': 'value1', 'key2': 'value2'}
    ds1['param1'] = 'value1'
    ds1['param2'] = 'value2'
    new_ds1 = AnsibleMapping()
    new_ds1['import_playbook'] = 'myplaybook'
    new_ds1['tags'] = 'imported'
    new_ds1['vars'] = {'key1': 'value1', 'key2': 'value2'}
    new_ds1

# Generated at 2022-06-11 10:31:34.718042
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = AnsibleLoader(None, variable_manager=variable_manager)
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager)

    # Test that with a simple import file, only the file name is correctly parsed
    test_data = '''
    - import_playbook: include.yml
    '''
    test_data = yaml.load(test_data, Loader=AnsibleLoader)
    PlaybookInclude.load(test_data, inventory, variable_manager, loader=loader)

    # Test that with a file and parameters, everything is correctly parsed

# Generated at 2022-06-11 10:31:46.908685
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    '''
    Creates a mock_ds of the data structure (dict) of a PlaybookInclude.
    Passes the data structure to the method preprocess_data of class
    PlaybookInclude and compares the resulting data structure with an
    expected data structure.
    '''

    # make mock data structure
    mock_ds = dict(
        import_playbook = "../../somewhere/over/the/rainbow.yaml",
        vars = dict(
            color = "blue",
            answer = 42,
        ),
        tags = ['unicorn', 'rainbow', 'irish'],
    )

    # construct object to test
    pbi_to_test = PlaybookInclude()

    # call method to test
    results = pbi_to_test.preprocess_data(mock_ds)

    #

# Generated at 2022-06-11 10:32:02.838181
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    """ This unit test tries to exercise method preprocess_data of class PlaybookInclude
    """
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.template import Templar

    loader = AnsibleLoader(None, True)

    # Test 1:
    # import_playbook: test.yml
    data = """
- hosts: localhost
  tasks:
  - import_playbook: test.yml
    vars:
      var_task: test
"""

    new_ds = PlaybookInclude.load(data, '/tmp/', loader=loader).serialize()
    new_ds_expected = [{'tasks': [{'vars': {'var_task': 'test'}, 'import_playbook': 'test.yml'}], 'hosts': 'localhost'}]

# Generated at 2022-06-11 10:32:13.429573
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    def check_preprocess_data(input_string, expected_result):
        import yaml

        ds = yaml.safe_load(input_string)
        obj = PlaybookInclude()
        result = obj.preprocess_data(ds)
        assert result == expected_result, "preprocess_data: Input '%s' Expected '%s' Got '%s'" % \
                                          (input_string, expected_result, result)

    def check_preprocess_data_fail(input_string, expected_result):
        import yaml

        ds = yaml.safe_load(input_string)
        obj = PlaybookInclude()

# Generated at 2022-06-11 10:32:21.128322
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook

    display = Display()
    display.verbosity = 0

    ######################################################################
    #    Test PlaybookInclude.load_data with a loadable PlaybookInclude  #
    ######################################################################
    # Test 1: A PlaybookInclude which comes from a file
    # The vars key should be read as a dictionary
    # The int_hosts key should not be recognized
    # The import_playbook key should be read
    # it should read its hosts from the included playbook
    # the pre_tasks, role, and post_tasks of the included playbook should be added to this one
    # The include playbook should have its vars read

# Generated at 2022-06-11 10:32:33.762109
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    d = {"import_playbook": "./test.yml", "vars": {"myvar": "myval"}}
    p = PlaybookInclude()
    pds = p.preprocess_data(d)
    assert pds.get('import_playbook') == "./test.yml"
    assert pds.get('vars').get('myvar') == "myval"

    d = {"import_playbook": "./test.yml tags=mytag,yourtag", "vars": {"myvar": "myval"}}
    p = PlaybookInclude()
    pds = p.preprocess_data(d)
    assert pds.get('import_playbook') == "./test.yml"
    assert pds.get('vars').get('tags') == "mytag,yourtag"


# Generated at 2022-06-11 10:32:39.633902
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook

    # Add a dummy playbook to the lookup path
    # The dummy playbook has a simple task and a play
    playbook_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../test/unit/module_utils/ansible_test_mocks/TestPlaybookCollection/playbooks/dummy_playbook.yaml'))
    AnsibleCollectionConfig.playbook_paths.append(os.path.dirname(playbook_path))

    # Test case when the playbook is included with a variable
    ds = '''
        - import_playbook: dummy_playbook.yaml
          tags: tags_for_playbook
          vars:
            var1: value1
            var2: value2
        '''
   

# Generated at 2022-06-11 10:32:46.396646
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''
    Test load_data with a non-allowed item in the map.
    '''
    from ansible.parsing.yaml.objects import AnsibleMapping
    # create an instance of PlaybookInclude
    p = PlaybookInclude()
    # create an AnsibleMapping with a bad item in it
    d = AnsibleMapping()
    d["extra_attr"] = "extra"

    try:
        # call load_data with the generated map
        p.load_data(d)
        # fail if there was no exception
        assert False
    except:
        # success if we caught an exception
        assert True

# Generated at 2022-06-11 10:32:58.903310
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager

    import_playbook = {
        'import_playbook': 'example.yml',
        'vars': {
            'k': 'v'
        }
    }

    fake_loader = None

    playbook_include = PlaybookInclude.load(import_playbook, '.', variable_manager=VariableManager(), loader=fake_loader)
    assert isinstance(playbook_include, Playbook)
    assert len(playbook_include.filters()) == 0
    assert len(playbook_include._entries) == 1

# Generated at 2022-06-11 10:33:08.669443
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # import here to avoid a dependency loop
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    pb_inc = PlaybookInclude()

    # define a simple playbook to be included
    playbook_dict = {'hosts': 'all'}
    pb = pb_inc.load_data(ds=playbook_dict, basedir='', variable_manager=None, loader=None)
    assert isinstance(pb, Playbook)
    assert len(pb._entries) == 1
    assert isinstance(pb._entries[0], Play)
    assert pb._entries[0].hosts == 'all'

    # Check that the import path is set to the current directory
    assert pb._entries[0]._included_path == os.getcwd()

    #

# Generated at 2022-06-11 10:33:19.542428
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include = PlaybookInclude()

    def test_normal_playbook_include(ds_input, ds_output):
        actual_output = playbook_include.preprocess_data(ds_input)
        assert actual_output == ds_output

    # test with normal dict
    ds_input = dict(import_playbook="foo.yml", with_items=["one", "two", "three"])
    ds_output = dict(import_playbook="foo.yml", vars={"items": ["one", "two", "three"]})
    test_normal_playbook_include(ds_input, ds_output)

    # test with AnsibleMapping

# Generated at 2022-06-11 10:33:30.308170
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play

    playbook_include = PlaybookInclude()
    data = dict(
        import_playbook = '../../library/subversion.yml',
        vars = dict(
            repo='http://svn.example.org/project',
        )
    )
    playbook = playbook_include.load_data(
        data=data,
        basedir=os.path.join(os.path.dirname(__file__), os.path.pardir, os.path.pardir),
    )
    assert isinstance(playbook, Playbook)
    assert playbook.entries
    assert isinstance(playbook.entries[0], Play)
    assert playbook.entries[0].vars['repo'] == 'http://svn.example.org/project'

# Generated at 2022-06-11 10:33:51.497372
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.playbook.play import Play

    from ansible.parsing.dataloader import DataLoader

    from ansible.playbook.playbook import Playbook

    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    from ansible.inventory.group import Group
    from ansible.inventory.host import Host

    from ansible.vars.manager import VariableManager

    from ansible.inventory.manager import InventoryManager

    ds_list1 = dict(
        import_playbook="../../common.yml",
        when="ansible_os_family == 'RedHat'",
        tags="always")


# Generated at 2022-06-11 10:33:59.486077
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    # Create a playbook instance
    pb = PlaybookInclude()
    # Create AnsibleBaseYAMLObject instance
    ds = ''
    # Create AnsibleBaseYAMLObject instance
    basedir = ''
    # Create a variable_manager instance
    vm = ''
    # Create a loader instance
    loader = ''
    # Test load_data with arguments ds and basedir
    result = pb.load_data(ds, basedir, vm, loader)
    for entry in pb._entries:
        assert isinstance(entry, Play)

# Generated at 2022-06-11 10:34:09.976988
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os
    import ansible.playbook
    import ansible.playbook.play
    import ansible.playbook.tasks
    import ansible.playbook.role
    import ansible.playbook.task_include
    import ansible.playbook.block
    from ansible.template import Templar

# Generated at 2022-06-11 10:34:21.621321
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader

    # Check correct load
    display.verbosity = 3
    loader = DataLoader()
    ds = {'import_playbook': "test.yml", "vars": {"a": "b"}}
    result = PlaybookInclude.load(ds, '.', loader=loader)
    assert result.__class__.__name__ == "Playbook"

    # Check not correct load
    ds = "test.yml"
    with pytest.raises(AnsibleAssertionError):
        PlaybookInclude.load(ds, '.', loader=loader)

    ds = {'import_playbook': 1, "vars": {"a": "b"}}
    with pytest.raises(AnsibleParserError):
        Play

# Generated at 2022-06-11 10:34:22.664323
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-11 10:34:23.748512
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    assert False, "Unit test not implemented"

# Generated at 2022-06-11 10:34:31.865437
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play

    yaml_str = """
- import_playbook: foo.yml
- include_tasks:
    file: include_role.yml
    static: yes
"""
    yaml_str = yaml_str.replace('\n','\r\n')

    result = PlaybookInclude.load(data=yaml_str, basedir='/home/user/playbooks')

    assert isinstance(result, Play)
    assert hasattr(result, '_included_playbook')
    assert hasattr(result, '_included_path')
    assert result._included_path == '/home/user/playbooks'
    assert hasattr(result, '_included_conditional')

# Generated at 2022-06-11 10:34:43.616003
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    """
        PlaybookInclude: Test the load_data method
    """
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    # Instantiate the playbook class with valid path
    playbook_path = './test/units/playbook_include/playbook_include.yml'

    playbook = PlaybookInclude.load(
        data=playbook_path,
        basedir='./test/units/playbook_include')

    assert isinstance(playbook, Playbook)
    assert len(playbook._entries) == 2
    assert isinstance(playbook._entries[0], Play)
    assert isinstance(playbook._entries[1], Task)


# Generated at 2022-06-11 10:34:54.447735
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''
    This is test for `load_data` method of `PlaybookInclude` class.
    '''
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.template import Templar

    basedir, templar = './test_dir', Templar(loader=None)

    # 1. `ds` is not a dict
    try:
        PlaybookInclude.load(None, basedir)
    except AnsibleAssertionError as e:
        assert "should be a dict but was a %s" % type(None) == str(e), \
                "error message is different"

# Generated at 2022-06-11 10:35:04.815475
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    import random
    import string

    # generate a random name to avoid collision
    # in case the test is executed multiple times at once
    import_playbook = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(6))
    basedir = os.getcwd()
    playbook = os.path.join(basedir, import_playbook)

    # create the playbook
    with open(playbook, "w") as f:
        f.write("- hosts: localhost\n  tasks:\n    - debug: msg=\"test\"")

    # load the playbook using PlaybookInclude

# Generated at 2022-06-11 10:35:23.621147
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import sys
    import tempfile
    import shutil

    if sys.version_info[0] > 2:
        from io import StringIO
    else:
        from io import BytesIO as StringIO

    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    temp_dir = tempfile.mkdtemp(prefix='ansible_test_PlaybookInclude')
    coll_dir = tempfile.mkdtemp(prefix='ansible_foo', dir=temp_dir)
    awx_dir = tempfile.mkdtemp(prefix='ansible_awx', dir=temp_dir)
    coll_file = tempfile.NamedTemporaryFile(mode='w+t', dir=coll_dir, suffix='.yml')

# Generated at 2022-06-11 10:35:26.402668
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.playbook_include import PlaybookInclude
    playbook = PlaybookInclude()
    assert playbook.load_data(dict(import_playbook='test'), '.') is not None

# Generated at 2022-06-11 10:35:39.053587
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.vault import VaultSecret
    from ansible.utils.path import unfrackpath
    import os
    import random
    import string
    import tempfile
    import textwrap

    # Ensure that the load_data method works as expected

    # A constant string to act as our playbook filename
    PLAYBOOK_FILENAME = 'test_playbook_include.yml'

    # A constant string to act as our playbook content
    PLAYBOOK_CONTENT = """
- hosts: test_hosts
  tasks:
  - name: test_task
    debug:
      msg: test_msg
"""

    # A constant string to act as a fake collection

# Generated at 2022-06-11 10:35:47.443884
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os

    import tempfile

    from ansible.playbook.play import Play
    from ansible.playbook.playbook_include import PlaybookInclude

    from ansible.module_utils.common._collections_compat import Mapping

    from ansible.module_utils.common.collections import ImmutableDict

    ##############################################################################
    # Setup
    ##############################################################################

    temp_dir = tempfile.gettempdir()
    file_name = 'playbook_include_test.yml'
    file_path = os.path.join(temp_dir, file_name)

    ##############################################################################
    # test playbook_include.load_data
    ##############################################################################


# Generated at 2022-06-11 10:35:50.081904
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    # TODO: implement tests
    pass


# Generated at 2022-06-11 10:35:50.912177
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:36:02.836801
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from collections import namedtuple
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.objects import AnsibleSequence
    ds_PlaybookInclude = AnsibleMapping(
        {'import_playbook': './relative/path/to/play_not_in_collection',
         'vars': {'var1': 'value1',
                          'var2': 'value2'}})
    ds_playbook = AnsibleMapping(
        {'block': AnsibleMapping({})})

# Generated at 2022-06-11 10:36:03.491394
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:36:06.340471
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    module = AnsibleModule(argument_spec=dict(
                            playbook=dict(type='str', required=True)
    ))
    module.exit_json(changed=False)



# Generated at 2022-06-11 10:36:13.199522
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    basedir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'playbook_include_files')
    loader = DataLoader()
    tqm = None
    collection_playbook = os.path.join(basedir, 'test_collection', 'playbooks', 'playbook.yml')

# Generated at 2022-06-11 10:36:43.304616
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.tasks import Task

    pb_obj = PlaybookInclude.load(data={'import_playbook': 'some_file.yml'}, basedir='/usr/share/some_dir', variable_manager=None, loader=None)
    assert isinstance(pb_obj, Playbook)

    pb_obj = PlaybookInclude.load(data={'import_playbook': 'some_file.yml', 'vars': {'foo': 'bar', 'baz': 'qux'}}, basedir='/usr/share/some_dir', variable_manager=None, loader=None)
    assert isinstance(pb_obj, Playbook)
    pb_entries = pb_obj

# Generated at 2022-06-11 10:36:54.155478
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import unittest
    import tempfile
    import shutil

    collection_dir = os.path.join(tempfile.mkdtemp(), 'playbook.yml')
    with open(collection_dir, 'w') as f:
        f.write('''
        - hosts: localhost
          name: test play
          tasks:
            - name: testing include_tasks
              ping:
              when: not skip_ping
        ''')

    include_playbook = '''
    - include_playbook: playbook.yml
    '''
    #TODO: fix tests to work with collection path
    playbook = '''
    - import_playbook: playbook.yml
    '''

    class PlaybookIncludeTest(unittest.TestCase):
        def setUp(self):
            self.basedir

# Generated at 2022-06-11 10:37:02.994859
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.module_utils.six import BytesIO

    playbook = '''
---
- hosts: localhost

  tasks:
    - meta: import_playbook="./playbook.yml"
    - debug: msg="we are done"

'''

    playbook_import = '''
---
- hosts: localhost
  vars:
    data:
      key1: value1
      key2: value2
  tasks:
    - debug: msg="output"
'''
    file_vars = dict()
    file_vars['playbook'] = BytesIO(to_bytes(playbook))
    file_vars['playbook.yml'] = BytesIO(to_bytes(playbook_import))
    from ansible.parsing.vault import VaultLib

# Generated at 2022-06-11 10:37:11.746036
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Play
    from ansible.playbook.play import Playbook

    playbook = PlaybookInclude()

    ds = {}
    basedir = 'mock_path'
    variable_manager=None
    loader=None

    #assert playbook.load_data(ds, basedir, variable_manager, loader) is None

    ds = {'import_playbook': '/path/to/playbook'}
    basedir = 'mock_path'
    variable_manager=None
    loader=None
    assert isinstance(playbook.load_data(ds, basedir, variable_manager, loader), Playbook)

# Generated at 2022-06-11 10:37:12.842825
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-11 10:37:23.759892
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader

    ds = dict(
        import_playbook='/path/to/playbook/import_playbook.yml',
        vars=dict(
            var1='var1',
            var2='var2',
        ),
    )
    playbookinclude = PlaybookInclude()
    pb = playbookinclude.load_data(ds, "/path/to/playbook")

    assert isinstance(pb, Playbook)
    assert pb._file_name == '/path/to/playbook/import_playbook.yml'
    assert pb._loader is not None
    assert isinstance(pb._entries[0], Play)
    assert pb._ent

# Generated at 2022-06-11 10:37:32.924871
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import ansible.playbook.play
    from ansible.constants import DEFAULT_DEBUG

    import mock, pytest

    from ansible.utils.collection_loader import AnsibleCollectionConfig, _get_collection_playbook_path

    mock_loader = mock.MagicMock()
    mock_loader.load_related_file.return_value = {'foo': 'bar'}
    test_variable_manager = mock.MagicMock()
    test_variable_manager.extra_vars = {'test_extra_var': 'test_extra_var_value'}

    test_playbook_import_name = 'test_playbook_import_name'

# Generated at 2022-06-11 10:37:43.528847
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Test 1
    # Test scenario: import a playbook from filesystem
    # Tested scenario: import normal playbook
    # Expected result:

    from ansible.playbook import Playbook

    import os
    import sys
    import types

    from ansible.errors import AnsibleParserError, AnsibleAssertionError
    from ansible.playbook import PlaybookInclude

    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    playbook_include = PlaybookInclude()
    playbook_include.basedir = os.getcwd()
    playbooks_path = os.path.abspath("test_res/include_playbook/test_include_playbook.yml")


# Generated at 2022-06-11 10:37:50.350648
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include = PlaybookInclude()
    playbook_include.load_data(
        ds={
            'import_playbook': 'test_play.yml'
        },
        basedir='/test/path'
    )
    assert playbook_include._import_playbook == 'test_play.yml'


# Generated at 2022-06-11 10:38:01.222587
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.collection_loader import AnsibleCollectionLoader

    context = {}
    collection_loader = AnsibleCollectionLoader(None)
    templar = Templar(loader=collection_loader, variables=context)

    parent_pb = Playbook()
    parent_pb._entries = [{'name': 'ParentPlay'}]

    pbi = PlaybookInclude()
    pbi._entries = parent_pb._entries

    file_name = 'child.yml'
    child_pb = Playbook()
    child_pb._entries = [{'name': 'ChildPlay'}]
    child_pb.vars

# Generated at 2022-06-11 10:38:17.312653
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-11 10:38:27.760038
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    dir_path, file_name = os.path.split(os.path.realpath(__file__))
    # Create an instance of PlaybookInclude class
    playbook_include = PlaybookInclude()
    # Create a dictionary
    ds = {'import_playbook': "playbook.yml", 'vars': {'user_name': 'xyz'}}
    # Call load_data method
    pb = playbook_include.load_data(ds, dir_path)

    # Verify the result
    assert isinstance(pb, ansible.playbook.Playbook)
    assert len(pb._entries) == 1
    assert pb._entries[0].vars == {'user_name': 'xyz'}

# Generated at 2022-06-11 10:38:28.365701
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:38:36.310531
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    loader = DataLoader()

    # playbook is not a playbook
    ds = "test playbook"
    result = PlaybookInclude.load(ds, "base_dir", variable_manager=variable_manager, loader=loader)
    assert result is None

    # file_name not a string
    ds = {"import_playbook": 123}
    result = PlaybookInclude.load(ds, "base_dir", variable_manager=variable_manager, loader=loader)
    assert result is None

    # file_name is an empty string
    ds = {"import_playbook": ""}