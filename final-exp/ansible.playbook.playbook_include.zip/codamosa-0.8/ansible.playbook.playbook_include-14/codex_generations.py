

# Generated at 2022-06-11 10:28:50.888810
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    from ansible.parsing.yaml.objects import AnsibleMapping

    # test case 1: the normal case
    ds = AnsibleMapping()
    ds['import_playbook'] = './somewhere/somename.yml'
    ds['vars'] = dict(var1='value1')
    ds2 = PlaybookInclude.preprocess_data(ds)
    assert isinstance(ds2, AnsibleMapping)
    assert ds2['vars'] == dict(var1='value1')

    # test case 2: single value in the import_playbook
    ds = AnsibleMapping()
    ds['import_playbook'] = './somewhere/somename.yml'
    ds2 = PlaybookInclude.preprocess_data(ds)
   

# Generated at 2022-06-11 10:29:02.492218
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

    # Prepare test Playbooks
    test_playbook_0 = '''
- hosts: all
  tasks:
    - debug:
        msg: test_playbook_0
    - include: test_playbook_1.yml
'''

    test_playbook_1 = '''
- hosts: all
  tasks:
    - debug:
        msg: test_playbook_1
'''

    test_playbook_2 = '''
- hosts: all
  tasks:
    - debug:
        msg: test_playbook_0
    - include: test_playbook_1.yml
    - include: test_playbook_2.yml
'''



# Generated at 2022-06-11 10:29:12.324323
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''
    Testing load_data method of class PlaybookInclude
    '''
    # data to be fed in while calling load_data method of PlaybookInclude class
    ds = {}
    basedir = ""
    variable_manager = None
    loader = None

    # creating an object of PlaybookInclude class
    obj = PlaybookInclude()

    # test if the load_data method of PlaybookInclude class raises an exception for all fields
    # not present in data
    with pytest.raises(AnsibleParserError) as excinfo:
        obj.load_data(ds,basedir,variable_manager,loader)
    assert excinfo.value.message == "the field 'tasks' is required but was not set"

# Generated at 2022-06-11 10:29:24.985622
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # test __init__ of the PlaybookInclude class

    # initialize input for the tested method
    basedir = '.'
    data = {'import_playbook': 'test.yml',
            'vars': {'key1': 'value1'}}

    # initialize expected result
    expected_result = 'ansible.parsing.yaml.objects.AnsibleMapping'

    # execute the tested method
    result = PlaybookInclude().load_data(ds=data, basedir=basedir)

    # test whether the expected result is in the result
    assert expected_result in repr(result.__class__)

    # initialize input for the tested method
    basedir = '.'
    data = {'include': 'test.yml',
            'vars': {'key1': 'value1'}}

    #

# Generated at 2022-06-11 10:29:28.570742
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Unit test for this method will be included in future, based on feedback
    # from implementing unit tests for playbook.py, playbook_include.py,
    # play.py, etc.
    pass

# Generated at 2022-06-11 10:29:38.854454
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import sys
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role

    # We prepare a basic playbook with all kind of entries.
    ds = AnsibleMapping()
    ds.ansible_pos = (1,1)
    ds['hosts'] = 'all'
    ds['pre_tasks'] = AnsibleSequence()
    ds['pre_tasks'].ansible_pos = (2,2)

# Generated at 2022-06-11 10:29:51.686023
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.dumper import AnsibleDumper


# Generated at 2022-06-11 10:30:03.204646
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    playbook_include = PlaybookInclude()

    ds = dict(import_playbook='foo.yml', tags='tag1,tag2')
    playbook_inc_ds = playbook_include.load_data(ds=ds, basedir='/path/to/playbook/dir')
    assert isinstance(playbook_inc_ds, Playbook)
    assert playbook_inc_ds._entries[0].tags == ['tag1', 'tag2']
    assert playbook_inc_ds._entries[0].vars == dict()

    ds = dict(import_playbook='foo.yml', vars=dict(bar='baz', foo='bar'))

# Generated at 2022-06-11 10:30:10.594612
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import ansible.playbook.play as play
    class TestPlaybookInclude(PlaybookInclude):
        def __init__(self):
            self.playbook = "playbook.yml"
            self.include_playbook = None
            self.import_playbook = None
            self.vars = None
            self.tags = None
            self.when = None
            self.async_seconds = None
            self.async_poll_interval = None
            self._blocks = []
            self._attributes = {}
            self._included_path = None
            self._included_conditional = None
            self.post_validate_data_fail = False
            self.play = play.Play()

    t = TestPlaybookInclude()

# Generated at 2022-06-11 10:30:21.023701
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import os
    import tempfile

    from ansible.playbook.playbook_include import PlaybookInclude

    test_playbook = '''
- import_playbook: playbook.yml var1=foo var2=bar tags=tag1,tag2 vars:
    x: y
'''
    with tempfile.NamedTemporaryFile(mode='wb', delete=False) as f:
        f.write(to_bytes(test_playbook))
    pb_include = PlaybookInclude.load(test_playbook, os.path.dirname(f.name))

    # Check that preprocess_data generates a AnsibleMapping
    assert isinstance(pb_include.preprocess_data(pb_include._ds), AnsibleMapping)
    # Check that the import_playbook is set to the file name
   

# Generated at 2022-06-11 10:30:36.474805
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play

    from ansible.template import Templar
    from ansible.vars import VariableManager

    ds = {"import_playbook": "../../../../t/integration/targets/import_playbook/import_playbook.yml", "vars": {"a": 1}}
    basedir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))) + "/t/integration/targets/import_playbook/"

    variable_manager = VariableManager()

    playbook_include = PlaybookInclude.load(ds, basedir, variable_manager, None)
    # check if is a Playbook

# Generated at 2022-06-11 10:30:47.253967
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    testFileName = 'test_PlaybookInclude_load_data'
    testDir = 'test_dir'
    testAbsPath = os.path.abspath(os.path.join(testDir, testFileName))
    playbook_data = '{import_playbook: test_PlaybookInclude_load_data}'
    playbook_name = 'test_playbook.yaml'
    playbook_data_encrypted = AnsibleVaultEncryptedUnicode(playbook_data)
    basedir = os.path.abspath(os.path.join(testDir, os.pardir))


# Generated at 2022-06-11 10:30:59.129734
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible import context
    from ansible.playbook import Playbook

    basedir = os.getcwd()
    variable_manager = context.VariableManager()
    loader = context.Loader()

    #####################################################################
    # PlaybookInclude load_data unit test 1
    test_data_1 = dict(
        import_playbook = 'playbooks/playbook.yml',
        vars = dict(
            a = '1',
            b = '2'
        ),
        when = dict(
            c = '3'
        ),
        tags = 'tag1,tag2',
    )

    include_data = PlaybookInclude().load_data(ds=test_data_1, basedir=basedir, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-11 10:31:08.066947
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook

    TEST_PLAYBOOK_PATH = os.path.join(os.path.dirname(os.path.realpath(__file__)), '..', 'test', 'test_playbooks', 'include')
    TEST_INCLUDE_PATH = os.path.join(TEST_PLAYBOOK_PATH, 'include')

    loader = C.construct_loader()
    variable_manager = C.VariableManager()

    # load playbook with includes
    playbook = Playbook.load(os.path.join(TEST_INCLUDE_PATH, 'playbook.yml'), variable_manager, loader)

    # ensure include tasks were loaded
    assert playbook.entries[0].name == 'Included tasks'

    # ensure included file tasks were loaded

# Generated at 2022-06-11 10:31:20.883391
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    import ansible.constants as C
    import os
    import sys

    class PlaybookPlayIncludeObject(TaskInclude):
        # Each method is overriden to avoid using AnsibleAPI
        @staticmethod
        def load(data, variable_manager=None, loader=None):
            return PlaybookPlayIncludeObject(loader=loader).load_data(ds=data, variable_manager=variable_manager, loader=loader)

        def __init__(self, loader=None):
            super(PlaybookPlayIncludeObject, self).__init__(loader=loader)

# Generated at 2022-06-11 10:31:29.300943
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.play_context import PlayContext

    play_include_data = """
    - import_playbook: test-playbook.yml
      when: test_result
      tags: tags
      vars:
        a: 1
        b: 2
    """
    play_include_obj = AnsibleLoader(None, False, False).load(play_include_data)[0]

    playbook = """
    - hosts: all
      tasks:
      - debug: msg="test"
      pre_tasks:
      - debug: msg="test"
      post_tasks:
      - debug: msg="test"
      roles:
      - role1
    """
    playbook_file = '/tmp/test-playbook.yml'

# Generated at 2022-06-11 10:31:42.204655
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import ansible.playbook.play_context.tag
    import ansible.playbook.play
    import ansible.playbook.conditional
    import ansible.playbook.helpers
    import ansible.playbook.attribute
    import ansible.playbook.playbook
    obj1 = ansible.playbook.play_context.tag.Tag('vars', dict())
    obj1.tags = ['testTag1', 'testTag2']
    obj1.when = [{'tags': ['testTag1']}]
    obj2 = ansible.playbook.play.Play('hosts', 'vars', list(), [obj1], [obj1])
    obj2.tags = ['testTag3']
    obj2.when = [{'tags': ['playTestTag1']}]
    obj3 = ansible.play

# Generated at 2022-06-11 10:31:50.853959
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    class _loader(object):
        def __init__(self, base_datadir):
            self.base_datadir = base_datadir
            self.path_copied = set()

        def path_dwim_relative(self, basedir, given, follow=True):
            return self.base_datadir

    base_datadir = os.path.join(os.path.dirname(__file__), 'vars')
    example_playbook = os.path.join(os.path.dirname(__file__), 'playbook_include_test_playbook.yml')

    # Load the playbook and parse its data.
    loader = _loader(base_datadir)

# Generated at 2022-06-11 10:31:59.269829
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader

    dl = DataLoader()
    include_path = os.path.join(os.path.dirname(__file__), 'import_playbook_test.yml')
    data = dl.load_from_file(include_path)

    variable_manager = None

    pb = PlaybookInclude().load_data(data, include_path, variable_manager, loader=dl)

    assert type(pb) == Play


# Generated at 2022-06-11 10:32:10.488911
# Unit test for method load_data of class PlaybookInclude

# Generated at 2022-06-11 10:32:29.319022
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # Prepare test data
    class test_loader(object):
        pass

    loader = test_loader()
    loader.load_from_file = lambda *args, **kwargs: { "key": "value" }
    loader._is_collection_path = lambda *args: False

    # Prepare test object
    obj = PlaybookInclude()

    # Test loading PlaybookInclude with vars
    ds = { "import_playbook": "play.yml", "vars": { "key": "value" } }
    obj.load_data(ds, basedir=".", loader=loader)
    assert obj.vars["key"] == "value"

    # Test loading PlaybookInclude from FQCN
    ds = { "import_playbook": "namespace.collection.play.yml" }
    obj.load_

# Generated at 2022-06-11 10:32:40.395943
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    import ansible.playbook.role.include as role_include
    import ansible.inventory
    import ansible.parsing.yaml.loader

    inv_data = dict(
        all = dict(
            hosts = dict(
                localhost = dict(
                    ansible_connection = 'local'
                )
            )
        )
    )
    inv = ansible.inventory.Inventory(inv_data)
    vars_mgr = ansible.vars.VariableManager(inv)

# Generated at 2022-06-11 10:32:49.969529
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os

    # create a dummy playbook
    pb = PlaybookInclude()
    pb.import_playbook = 'tests/support/my-playbook.yml'
    pb_data = pb.load_data(ds={}, basedir='tests/support/')
    assert isinstance(pb_data, Playbook)
    assert pb_data.hosts == ['all']
    assert pb_data._entries[0].hosts == ['all']
    assert pb_data._entries[0].vars == {}
    assert pb_data._entries[0]._included_path == os.path.dirname(os.path.abspath('tests/support/my-playbook.yml'))
    assert pb_data._entries[0].vars == {}
    assert p

# Generated at 2022-06-11 10:32:50.773833
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:33:03.060336
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    print('Testing method load_data')
    v = PlaybookInclude()
    pi = v.load_data({}, None)
    assert(pi == None)
    pi = v.load_data({'import_playbook': 'foo.yml'}, None)
    assert(isinstance(pi, Play))
    assert(pi.get_vars() == {})
    pi = v.load_data({'import_playbook': 'foo.yml', 'vars': {'foo': 'bar'}}, None)
    assert(isinstance(pi, Play))
    assert(pi.get_vars() == {'foo': 'bar'})

# Generated at 2022-06-11 10:33:05.263506
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pb = PlaybookInclude()
    pb._load_playbook_data()
    assert pb._entries == None

# Generated at 2022-06-11 10:33:06.230932
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-11 10:33:15.790026
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.template import Templar
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    AnsibleCollectionConfig.clear_all_defaults()
    pbi = PlaybookInclude()

    data = {
        u'import_playbook': u'inv2.yml',
        u'vars': {
            u'name': u'John',
            u'user': u'jdoe',
            u'uid': 99,
        },
    }

    basedir = u'/home/user/ansible/playbooks'
    template = Templar(loader=None)
    templated_result = template.template(u'{{ import_playbook }}', data['vars'], data, basedir)
    data['import_playbook'] = templated_result

# Generated at 2022-06-11 10:33:22.797960
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include = PlaybookInclude()
    result = playbook_include.load_data(
        ds=dict(
            a='/tmp/a.yaml',
            b='/tmp/b.yaml'
        ),
        basedir='/tmp',
        variable_manager=None,
        loader=None
    )

    print(result)

if __name__ == '__main__':
    test_PlaybookInclude_load_data()

# Generated at 2022-06-11 10:33:33.262005
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.playbook import Playbook

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])

    display.verbosity = 3

    # Test if no vars defined
    filename = 'my-playbook-include.yml'
    print("The test_PlaybookInclude_load_data() method is starting its tests with no vars")
    data = """
    - name: my_play
      hosts: all
      gather_facts: false

      tasks:

      - name: my_task
        import_playbook: %s
    """ % filename

    pb_i = Play

# Generated at 2022-06-11 10:33:57.086967
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    playbook_include = PlaybookInclude()
    ds = dict(
        import_playbook='/home/foo/bar.yml',
    )
    playbook_include.load_data(ds, '/home/foo/')
    assert playbook_include.import_playbook == '/home/foo/bar.yml'
    ds = dict(
        import_playbook='/foo/bar.yml',
    )
    playbook_include.load_data(ds, '/home/foo/')
    assert playbook_include.import_playbook == '/foo/bar.yml'

    ds = dict(
        import_playbook='bar.yml',
    )
    playbook_include.load_data

# Generated at 2022-06-11 10:34:06.932596
# Unit test for method load_data of class PlaybookInclude

# Generated at 2022-06-11 10:34:08.077209
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-11 10:34:12.286845
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    import ansible.playbook.play

    data = {'playbook': '/tmp/play.yml'}
    pb = PlaybookInclude.load(data=data, basedir='/tmp')
    assert isinstance(pb, ansible.playbook.play.Playbook)

# Generated at 2022-06-11 10:34:13.687492
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # TODO
    pass

# Generated at 2022-06-11 10:34:24.954234
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook

    input_data = [
        {
            'import_playbook': 'test_playbook',
            'tags': 'included'
        },
        {
            'import_playbook': 'test_playbook',
            'vars': {
                'test_var': 'val'
            }
        },
        {
            'import_playbook': 'test_playbook',
            'other_var': 'val',
            'tags': 'included'
        }
    ]

    for test_data in input_data:
        loaded_data = PlaybookInclude.load(data=test_data, basedir='.', variable_manager=None, loader=None)
        assert isinstance(loaded_data, Playbook)



# Generated at 2022-06-11 10:34:27.322727
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # check conditional includes on a playbook need a marker to skip gathering
    # ansible-playbook -i inventory -e '@vars.yml' test-include.yml
    pass

# Generated at 2022-06-11 10:34:28.546365
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    playbook_include = PlaybookInclude()
    # playbook_include.load_data()

# Generated at 2022-06-11 10:34:31.865638
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    #Test Load_data of PlaybookInclude class

    # import here to avoid a dependency loop
    from ansible.playbook import Playbook

    data = PlaybookInclude.load('data', basedir='basedir', variable_manager='variable_manager', loader='loader')

    assert isinstance(data, Playbook)

# Generated at 2022-06-11 10:34:43.616312
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Create a mock load method to control the values returned by load method
    class MockVarManager(object):

        def get_vars(self):
            return {'foo': 'bar'}

    class MockLoader(object):

        def get_basedir(self):
            return '.'

    class MockTemplar(object):

        def __init__(self, loader, variables):
            pass

        def template(self, data):
            return data

    variable_manager = MockVarManager()
    loader = MockLoader()
    templar = MockTemplar(loader, variable_manager)
    PlaybookInclude._load = lambda x: templar
    PlaybookInclude.reload = lambda x: x

    # Test for when the import_playbook is not valid yaml

# Generated at 2022-06-11 10:35:19.620021
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-11 10:35:29.371558
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import sys
    import json
    #we need to set the PYTHONPATH (sys.path) to the proper location so we can import ansible.playbook.play
    #and ansible.playbook.task_include
    sys.path.append(os.path.join(os.path.dirname(__file__),'..','..'))
    sys.path.append(os.path.join(os.path.dirname(__file__),'..','..','..','lib'))
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.dataloader import DataLoader



# Generated at 2022-06-11 10:35:41.075019
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os
    import yaml
    from ansible.playbook.play import Play

    # Create playbook structure

# Generated at 2022-06-11 10:35:41.688282
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:35:48.657751
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # make sure that the load_data method of PlaybookInclude properly
    # handles (and properly converts) PlaybookInclude objects
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    pi = dict(
        import_playbook = 'test.yml',
        tags = ['foo', 'bar'],
        vars = dict(
            foo = 'bar',
            baz = 'zab',
        ),
    )

    obj = PlaybookInclude.load(pi, '/nonexistent/path')
    assert isinstance(obj, Playbook), "A Playbook object was not returned"
    assert len(obj._entries) == 1, "There should only be one play in the playbook"

# Generated at 2022-06-11 10:35:50.427639
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-11 10:35:51.115912
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:36:03.030390
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    """
    (unitest.loader.ModuleImportFailure) ImportError: Failed to import test module: test_PlaybookInclude_load_data
    Traceback (most recent call last):
      File "/usr/lib/python2.7/unittest/loader.py", line 254, in _find_tests
        module = self._get_module_from_name(name)
      File "/usr/lib/python2.7/unittest/loader.py", line 232, in _get_module_from_name
        __import__(name)
      File "/home/nondev/git/ansible-dev/lib/ansible/playbook/__init__.py", line 45
        assert len(entries[2]._entries) == 1
                      ^
    SyntaxError: invalid syntax
    """
    pass

# Generated at 2022-06-11 10:36:11.820339
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import json
    import yaml

    yaml_str = """
    - name: Deploy
      hosts: localhost
      import_playbook:
        - test_import.yml
        - test_import2.yml
    """

    import_yaml_str = """
    - name: Deploy
      hosts: localhost
      tasks:
        - debug:
            msg: test
    """

    import_yaml_str2 = """
    - name: Deploy
      hosts: localhost
      tasks:
        - debug:
            msg: test
    """

    assert isinstance(yaml.load(yaml_str), list)
    assert isinstance(yaml.load(import_yaml_str), list)
    assert isinstance(yaml.load(import_yaml_str2), list)


# Generated at 2022-06-11 10:36:24.286128
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pb_include = PlaybookInclude()
    pb_data = {'import_playbook': 'test_playbook.yml',
               'vars': {'a': 1}}
    pb = pb_include.load_data(ds=pb_data, basedir='/')
    assert len(pb.entries) == 1
    assert isinstance(pb.entries[0], PlaybookInclude)
    assert pb.entries[0].import_playbook == 'test_playbook.yml'
    assert pb.entries[0].vars['a'] == 1
    pb_data = {'import_playbook': 'test_playbook.yml',
               'vars': {'a': 1},
               'tags': ['a', 'b']}
    pb = pb_

# Generated at 2022-06-11 10:38:11.398183
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext

    var_manager = PlayContext()

    data = AnsibleLoader(None).load_from_file('test/unit/playbook_include_test.yml')
    include = PlaybookInclude("test/unit/")
    include_playbook = Playbook("test/unit/")

    host_name = "test_host"
    include_playbook._entries = include.load_data(data, "test/unit/", var_manager, loader=None)._entries
    for entry in include_playbook._entries:
        if isinstance(entry, Play):
            entry = entry.get

# Generated at 2022-06-11 10:38:12.231140
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:38:12.892564
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:38:22.392873
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    pbi = PlaybookInclude()
    data = {'import_playbook': '../../../test/integration/targets/test_collections/test_file.yml'}

    playbook = pbi.load_data(ds=data, basedir='/tmp', variable_manager=None, loader=None)
    assert isinstance(playbook, Playbook)
    assert len(playbook._entries) == 1
    assert playbook._entries[0].name == 'Test play'
    assert isinstance(playbook._entries[0], Play)

# Generated at 2022-06-11 10:38:32.373122
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    """Test if load_data works as expected"""
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude

    basedir = os.path.join(os.path.dirname(__file__), 'playbook_files')

    # test if load_data works with file name only
    data = AnsibleMapping()
    data['import_playbook'] = 'playbook.yml'
    pbi = PlaybookInclude().load_data(data, basedir)

    assert len(pbi._entries) == 1
    entry = pbi._entries[0]
    assert isinstance(entry, Play)
    assert entry.name == 'play'

    assert len(entry.task_blocks) == 1