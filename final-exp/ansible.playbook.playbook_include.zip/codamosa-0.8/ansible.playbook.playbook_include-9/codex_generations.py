

# Generated at 2022-06-11 10:29:05.785111
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    import tempfile
    import os
    import shutil

    pb_include = PlaybookInclude()

    basedir = tempfile.mkdtemp()
    print(basedir)

    # test when a playbook file exists
    test_playbook_file = os.path.join(basedir, "test_playbook_included.yml")
    ansible_vars = dict(A="alpha", B="bravo")
    ansible_vars_str = ""
    for key, value in iteritems(ansible_vars):
        ansible_vars_str += "%s: %s\n" % (key, value)

# Generated at 2022-06-11 10:29:14.668288
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # Import needed to stub the PlaybookInclude class
    # pylint: disable=import-error, unused-import, redefined-builtin
    from ansible.playbook.play_include import PlaybookInclude

    # Declare a dictionary that represents a PlaybookInclude
    playbook_include_dict = {
        "import_playbook": "test_import.yml",
        "vars": {
            "var1": "value1",
        },
    }

    # Obj is a PlaybookInclude
    obj = PlaybookInclude()
    obj.preprocess_data(playbook_include_dict)

    # Asserts
    assert obj.import_playbook == "test_import.yml"
    assert obj.vars == {'var1': 'value1'}



# Generated at 2022-06-11 10:29:27.779740
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    import copy
    import tempfile
    from ansible.playbook.play import Playbook
    from ansible.playbook.play_context import PlayContext

    pm = Playbook()

    playbook_path = tempfile.NamedTemporaryFile(delete=False)
    playbook_data = """
    - hosts: all
      vars:
        x: y
      tasks:
        - name: task1
          shell: echo "hello"
          when: x==y
        - name: task2
          shell: echo "goodbye"
    """
    playbook_path.write(to_bytes(playbook_data))
    playbook_path.close()

    playbook_include_data = """
    - import_playbook: {0}
    """.format(playbook_path.name)


# Generated at 2022-06-11 10:29:38.490024
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    import_playbook = 'test_playbook.yml'
    vars = {
        'foo': 1,
        'bar': 2
    }
    tags = ['foo', 'bar']

    playbook_include = PlaybookInclude()
    playbook_include.import_playbook = import_playbook
    playbook_include.tags = tags
    playbook_include.vars = vars

    play = Play()
    play.hosts = ['testhost']
    play.name = 'test play'
    play.tasks = [
        Task(name='test task', action='test_module')
    ]

   

# Generated at 2022-06-11 10:29:42.217094
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    display.deprecated( "The module 'test_PlaybookInclude_load_data' is deprecated.Please use 'test/units/modules/utils/test_module_utils.py' instead", version='2.13')
    pass

# Generated at 2022-06-11 10:29:55.152663
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.module_utils._text import to_text
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = dict(
        import_playbook='test.yml',
        vars=dict(a=1)
    )
    ds = data.copy()
    ds = PlaybookInclude.load(ds, None)
    assert PlaybookInclude.preprocess_data(ds) == data

    data = dict(
        import_playbook='test.yml',
        tags=['test'],
    )
    ds = data.copy()
    ds = PlaybookInclude.load(ds, None)
    assert PlaybookInclude.preprocess_data(ds) == data

    data = dict(
        import_playbook='test.yml',
    )


# Generated at 2022-06-11 10:29:56.416076
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-11 10:30:06.349286
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    test_string1 = """
    - include:
        import_playbook: test1
        tags: test_tag
        other_var: other_value
        vars:
            var1: value1
            var2: value2
    """
    test_string2 = """
    - include:
        import_playbook: test1
        tags: test_tag
        vars:
            var1: value1
            var2: value2
    """
    test_string3 = """
    - include:
        import_playbook: test1
        tags: test_tag
        vars:
            var1: value1
            var2: value2
        other_var: other_value
    """

# Generated at 2022-06-11 10:30:16.348591
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from copy import deepcopy
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    import_playbook_playbook = PlaybookInclude()
    ds = { 'import_playbook': '../common_tasks.yml', 'tags': 'always'}
    ds2 = { 'import_playbook': '../common_tasks.yml', 'vars': {'a_var': 'a_value'}}
    ds3 = { 'import_playbook': '../common_tasks.yml', 'tags': 'always', 'vars': {'a_var': 'a_value'}}


# Generated at 2022-06-11 10:30:26.868533
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Play
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.utils.vars import load_extra_vars

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)
    variable_manager.set_extra_vars(load_extra_vars(loader=loader, options=None))

    #########################################
    # test valid playbook
    #########################################

# Generated at 2022-06-11 10:30:44.514449
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.loader import AnsibleLoader

    host_var = {'host_var_key': 'host_var_value'}
    import_var = {'import_var_key': 'import_var_value'}
    manager = None
    loader = AnsibleLoader(None, None)

    # test case 1, a simple playbook include
    playbook_v1 = """
        - hosts: test_host
          tasks:
            - debug: msg="playbook_v1"
              vars:
                task_key: task_value
              tags: playbook_v1
        """
    pb_v1 = Playbook.load(playbook_v1, '<string>', loader=loader)
    entry_v1 = pb_v1

# Generated at 2022-06-11 10:30:53.260873
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    orig = {'include': './roles/otherrole/tasks/main.yml',
            'vars': {
                'var1': False
            }
    }
    dobj = PlaybookInclude.load(orig, basedir='.', loader=loader)

    expected = {'import_playbook': u'./roles/otherrole/tasks/main.yml',
                'vars': {
                    'var1': False
                }
    }
    assert expected == dobj.get_ds()

# Generated at 2022-06-11 10:31:03.504314
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.yaml.data import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.collection_loader import set_collection_playbook_paths

    # register collection paths for tests
    set_collection_playbook_paths()

    task_include_str = """
    - name: Test
      import_playbook: tasks/test_playbook.yml
      vars:
        c: d
    """

    data = DataLoader().load(task_include_str)
    ds = data[0]
    basedir = "/tmp"
    variable_manager = VariableManager()

# Generated at 2022-06-11 10:31:15.574101
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible import __path__ as ansible_path
    from ansible.errors import AnsibleParserError, AnsibleAssertionError
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    import ansible.constants as C
    import json
    import re
    import os
    import os.path

    def str_data_from_file(file_name):
        with open(file_name, 'r') as f:
            return f.read()

    # Set defaults to avoid user config issues when running tests
    C.DEFAULT_DEBUG = False

# Generated at 2022-06-11 10:31:26.545407
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os
    import tempfile
    import yaml

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    db = {}
    ds = {}
    basedir = "/tmp/"

    file_path = os.path.join(basedir, "test_file")


# Generated at 2022-06-11 10:31:39.255503
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # import self-written test_utils library
    import test_utils

    # create a test instance of AnsibleOptions
    options = test_utils.AnsibleOptions(connection='local', forks=10, become=None,
                                        become_method=None, become_user=None, check=False, diff=False)
    options = options.parse()[0]

    # create a test instance of AnsibleRunner
    runner = test_utils.AnsibleRunner(options)

    # create a test instance of PlaybookInclude
    play_include = PlaybookInclude()

    # test the load_data method

# Generated at 2022-06-11 10:31:44.294682
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook

    pbi = PlaybookInclude()
    ppd_vars = {
        'playbook1': 'include1.yml',
        'playbook2': 'include2.yml',
        'vars': {
            'host': 'localhost'
        }
    }

    result = pbi.load_data(ppd_vars, basedir='/tmp', loader=None)

    assert isinstance(result, Playbook), 'The result of load_data is not of type Playbook'
    assert len(result._entries) == 2, 'The result of load_data was not parsed correctly'
    assert isinstance(result._entries[0], Play), 'The result of load_data was not parsed correctly'
    assert isinstance

# Generated at 2022-06-11 10:31:49.547528
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Test with conditional include
    ds = dict(
        import_playbook='pb.yml',
        vars=dict(
            key1='value1',
            key2=dict(
                subkey1='value2',
            ),
        ),
        tags=['tag1', 'tag2'],
        when=[
            dict(var1='value1'),
        ]
    )
    pbi = PlaybookInclude.load(ds, basedir=".")
    assert type(pbi) == PlaybookInclude
    assert pbi.import_playbook == ds['import_playbook']
    assert pbi.tags == ds['tags']
    assert pbi.vars == ds['vars']
    assert pbi.when == ds['when']

    # Test with non-conditional include
    d

# Generated at 2022-06-11 10:32:00.594119
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # This is a test with a non-existent playbook path
    new_obj = PlaybookInclude()
    new_obj.import_playbook = "/tmp/dummy.yml"
    pb = new_obj.load_data(new_obj, basedir="/tmp")
    assert pb is not None
    assert len(pb._entries) == 0

    # This is a test with a playbook path that contains a vars entry
    new_obj = PlaybookInclude()
    new_obj.import_playbook = "../../test/playbook/import.yml"
    pb = new_obj.load_data(new_obj, basedir="../../test/playbook")

    assert type(pb).__name__ is 'Playbook'
    assert len(pb._entries) == 5


# Generated at 2022-06-11 10:32:05.150364
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    pb = PlaybookInclude.load(dict(import_playbook='../library/test.yml'), './library')
    print(pb)
    assert isinstance(pb, Playbook)

test_PlaybookInclude_load_data()

# Generated at 2022-06-11 10:32:16.763194
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''
    Unit test for method load_data of class PlaybookInclude
    '''
    import sys

    imp_playbook = 'playbooks/playbooks/test_playbook.yml'
    file_arg = 'vars=test.yml'

    sys.modules['__main__'].__file__ = imp_playbook
    import_data = dict(import_playbook=file_arg)

    playbook = PlaybookInclude.load(data=import_data, basedir=".")
    assert playbook.__class__.__name__ == "Playbook"

# Generated at 2022-06-11 10:32:22.795172
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    file_name = "test.yml"
    playbook = "test.yml"
    basedir = "."
    data = {}
    path = os.path.join(basedir, playbook)
    data['import_playbook'] = path
    playbook_include = PlaybookInclude.load(data, basedir)
    assert playbook_include.import_playbook == file_name
    assert playbook_include.path == basedir



# Generated at 2022-06-11 10:32:24.303949
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    """
    Ansible playbook include object test, load data
    """

    assert True

# Generated at 2022-06-11 10:32:36.508756
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task

    yaml_obj = PlaybookInclude(import_playbook='playbooks/foobar.yml', vars={'foo': 'bar'})
    yaml_obj.postprocess_data(None)
    pb = yaml_obj.load_data({'import_playbook': 'playbooks/foobar.yml', 'vars': {'foo': 'bar'}}, C.DEFAULT_LOCALHOST, variable_manager={}, loader=C.DEFAULT_LOADER_CLASS)

    assert isinstance(pb, Playbook)
    assert len(pb.get_plays()) == 1
    p = pb.get_plays()[0]


# Generated at 2022-06-11 10:32:42.980333
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    """
    Test the load_data method of the PlaybookInclude class

    Test that the load_data method imports a playbook correctly.
    """
    import unittest
    import io
    import yaml

    # workaround for Python3...
    try:
      from StringIO import StringIO
    except:
      from io import StringIO

    # Example playbook include
    input_string = StringIO(
"""
- import_playbook: test_include.yml
  vars:
    myvar: "test variable"
""")

    # Example test playbook
    test_playbook = StringIO(
"""
- hosts: localhost
  connection: local
  tasks:
    - name: Debug output
      debug:
        msg: In included playbook
""")

    # Create a fake playbook instance

# Generated at 2022-06-11 10:32:54.430707
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.module_utils.six import PY3
    import sys
    import os
    import stat
    import json
    import copy
    import tempfile

    if PY3:
        # The unittest module got a significant overhaul
        # in Python 3.2, reportedly due to the fact that
        # the unittest integration with the buildbot broke
        # with Python 3.1:
        # http://bugs.python.org/issue10158
        import unittest
        from unittest import TestLoader
        from unittest.runner import TextTestRunner
        TestCase = unittest.TestCase
    else:
        import unittest2 as unittest
        from unittest2 import TestLoader
        from unittest2.runner import TextTestRunner
        TestCase = unittest.TestCase

    #

# Generated at 2022-06-11 10:33:06.064945
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.helpers import load_list_of_blocks
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude

    from ansible.playbook.playbook_include import _get_collection_playbook_path
    from ansible.playbook.playbook_include import _get_collection_name_from_path

    playbook = PlaybookInclude.load({'import_playbook': '../data/playbooks/test_import_playbook.yml'}, '/home/ansible/roles')

    assert isinstance(playbook, Playbook)
    assert len(playbook._entries) == 3

   

# Generated at 2022-06-11 10:33:06.607943
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:33:10.923567
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    temp_filename = 'sample_hosts'
    temp_file = open(temp_filename, 'w+')
    temp_file.write("""
localhost  ansible_connection=local
    """)
    temp_file.close()

    results = PlaybookInclude.load(ds={"include": "sample_hosts"}, basedir=".")
    assert(isinstance(results, Playbook))
    os.remove(temp_filename)
    # No problem


# Generated at 2022-06-11 10:33:22.386790
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play

    # Test with file path
    c_PlaybookInclude = PlaybookInclude()
    c_PlaybookInclude.load_data(ds={"import_playbook": "./path/file.yml"},
                                basedir="./rel/path/")

    # Test with FQCN
    c_PlaybookInclude = PlaybookInclude()
    pb = c_PlaybookInclude.load_data(ds={"import_playbook": "namespace.collection.playbook_name"},
                                basedir="./rel/path/")

    # Test with mixed FQCN and path
    c_PlaybookInclude = PlaybookInclude()

# Generated at 2022-06-11 10:33:29.313793
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # FIXME: what is the testcase for this method?
    pass

# Generated at 2022-06-11 10:33:38.699892
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # import here to avoid a dependency loop
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    PlaybookInclude.load_data({'import_playbook': 'include.yml', 'vars': {'key1': 'value1', 'key2': 'value2'}}, '.')

    assert PlaybookInclude.load_data({'import_playbook': 'include.yml', 'vars': {'key1': 'value1', 'key2': 'value2'}}, '.')._entries[0].vars == {'key1': 'value1', 'key2': 'value2'}

# Generated at 2022-06-11 10:33:51.313676
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    fixed_ds = {
        'import_playbook': 'myplaybook.yml',
        'tags': ['TESTING_TAG'],
        'vars': {'var1': 'value1', 'var2': 'value2'}
    }

    # Test a few variations of use of the deprecated k=v syntax

    play = Play.load(
        dict(
            import_playbook='myplaybook.yml tags=TESTING_TAG',
            vars=dict(var1='value1', var2='value2')
        )
    )
    play.preprocess_data()
   

# Generated at 2022-06-11 10:34:01.190024
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # this class stubs out the loader methods

    class LoaderModule(object):
        def get_basedir(self, path):
            if not os.path.exists(path):
                raise AnsibleFileNotFound("the role '%s' was not found" % path)
            return os.path.dirname(path)

    loader = LoaderModule()
    variable_manager = VariableManager()
    play_context = PlayContext()

# Generated at 2022-06-11 10:34:12.286476
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    class PlaybookDummy():
        def __init__(self):
            self.data = dict(
                import_playbook='/tmp/test.yml',
                vars=dict(
                    var1='var1',
                    var2=12
                ),
                tags=['tag1', 'tag2'],
                when=['when1', 'when2']
            )

    class PlaybookIncludeDummy(PlaybookInclude):
        def __init__(self):
            pass


# Generated at 2022-06-11 10:34:23.832938
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import ansible.playbook
    import os

    current_directory = os.path.dirname(ansible.__file__) + '/modules/'

    # test_PlaybookInclude_load_data_1
    x = PlaybookInclude.load(data={'import_playbook': current_directory + 'cloud/amazon/ec2_vpc_subnet_facts.py'},
                        basedir=current_directory)
    assert x.playbook == current_directory + 'cloud/amazon/ec2_vpc_subnet_facts.py'

    # test_PlaybookInclude_load_data_2
    x = PlaybookInclude.load(data={'import_playbook': current_directory + 'cloud/amazon/ec2_vpc_subnet_facts.py'},
                        basedir=current_directory)


# Generated at 2022-06-11 10:34:32.357802
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os
    import yaml
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    # Set up some test data
    test_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    test_data_dir = os.path.join(test_dir, "test", "units", "parsing", "yaml", "data")
    test_playbook_include = """
    - import_playbook: test_playbook.yml
      vars:
        test_var: true
        test_var_override: false
    """
    test_play

# Generated at 2022-06-11 10:34:44.555539
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.plugins.loader import add_all_plugin_dirs, find_plugin

    # Create a new variable manager
    variable_manager = VariableManager()

    # Create a new loader to set the variable manager
    loader = find_plugin('loader')
    loader._set_variable_manager(variable_manager)

    playbook = 'test_include.yaml'
    playbook_included = 'test_included.yaml'
    playbook_include = 'test_include.yaml'
    task = 'test_included_task.yaml'
    # Create a new

# Generated at 2022-06-11 10:34:52.389644
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook = """---
- hosts: all
  tasks:
    - debug: msg='test'
"""
    import tempfile
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    FILE = tempfile.NamedTemporaryFile(mode='w')
    FILE.write(playbook)
    FILE.flush()
    loader = DataLoader()
    variable_manager = VariableManager()
    PlaybookInclude.load_data("- import_playbook: '"+FILE.name+"'",'/tmp',variable_manager)

# Generated at 2022-06-11 10:34:53.809419
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # TODO: Add valid test case
    pass


# Generated at 2022-06-11 10:35:14.227737
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    ds = "tasks/main.yml"
    new_ds = AnsibleMapping()
    new_ds["import_playbook"] = ds

    assert PlaybookInclude._preprocess_import("test", new_ds, "import_playbook", ds) == ds


    ds = "tasks/main.yml role=test"
    new_ds = AnsibleMapping()
    new_ds["import_playbook"] = "tasks/main.yml"
    new_ds["vars"] = {"role": "test"}

    assert PlaybookInclude._preprocess_import("test", new_ds, "import_playbook", ds) == ds


    ds = "another.yml tags=foo,bar"
    new_ds = AnsibleMapping()
    new_ds

# Generated at 2022-06-11 10:35:23.272844
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''
    This tests the method load_data of the class PlaybookInclude.
    '''

    # initialize a class object of PlaybookInclude class
    pb_include = PlaybookInclude()

    # initialize a dict that meets the ansible-playbook
    # yaml file structure
    ds = {}
    ds['include'] = 'included_playbook.yml'
    ds['vars'] = {}
    ds['vars']['var1'] = 'value1'
    ds['vars']['var2'] = 'value2'

    # call load_data() of PlaybookInclude class
    # and pass the above initialized dict
    new_pb = pb_include.load_data(ds=ds, basedir='/tmp')

    # check if the returned obj is of type

# Generated at 2022-06-11 10:35:35.389366
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.plugins.loader import collection_loader

    p1 = PlaybookInclude()
    p1.vars = {"var1": "value1"}
    p1.tags = ["tag1"]
    p1.when = ["when1"]
    p1._import_playbook = "playbook.yaml"
    p1.loader = collection_loader._create_content_loader(paths=['/path/to/nonexistent'], collection_list=['nonexistent.namespace.role'])
    pb = p1.load_data({}, basedir="/path/to/nonexistent")
    assert len(pb._entries) == 2
    assert isinstance(pb._entries[0], Play)

# Generated at 2022-06-11 10:35:36.804627
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
     pass


# Generated at 2022-06-11 10:35:37.408163
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:35:46.373835
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    test_pb = PlaybookInclude()
    test_pb.import_playbook = 'test_pb.yml'
    test_pb.vars = {'test_var': True}
    test_pb.tags.append('test_tag')
    test_pb.when.append('test_when')

    test_play = Play()
    test_play.vars = {'play_var': True}
    test_play.tags.append('play_tag')
    test_play.when.append('play_when')
    test_play._included_path = None

    test_pb._entries = [test_play]


# Generated at 2022-06-11 10:35:58.477864
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    pbi = PlaybookInclude()
    pbi_loaded = pbi.load_data(
        [{'import_playbook': 'play.yml'}],
        basedir='tests/playbooks/',
        variable_manager=variable_manager,
        loader=loader)

    assert pbi_loaded.__class__.__name__ == "Playbook"
    assert len(pbi_loaded._entries) == 1

# Generated at 2022-06-11 10:36:08.992302
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # Load PlaybookInclude for include_tasks
    data = {
        'include_tasks': {
            'file': 'test_playbook',
            'vars': {
                'var_1': 'test',
                'tags': 'test'
            },
            'tags': 'test'
        }
    }
    basedir = '/tmp/'
    pb = PlaybookInclude.load(data, basedir)
    assert pb is not None
    # Check tags, tags are union of tags in vars and tags in include_tasks
    assert pb._entries[0].tags == ['test', 'test']
    assert pb._entries[0].vars == {'var_1': 'test'}

    # Load PlaybookInclude for include

# Generated at 2022-06-11 10:36:16.151029
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Create test objects
    data = { 'import_playbook': 'test_playbook.yml' }
    basedir = './test/loader'
    variable_manager = None  # TODO: VariableManager()
    loader = None  # TODO: DataLoader()

    result = PlaybookInclude.load(data, basedir, variable_manager=variable_manager, loader=loader)
    assert isinstance(result, ansible.playbook.Play.Play)

# Generated at 2022-06-11 10:36:27.895064
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play

    import_data = {'import_playbook': 'another_play.yml'}
    include = PlaybookInclude()
    include.load_data(ds=import_data, basedir='.')
    assert include._import_playbook == 'another_play.yml'
    assert include._entries is not None
    assert len(include._entries) == 1
    assert isinstance(include._entries[0], Play)
    assert include._entries[0].vars == {}
    assert include._entries[0].name == 'another_play'


# Generated at 2022-06-11 10:36:45.224817
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:36:45.820910
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:36:56.807122
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    ds = {}
    # create PlaybookInclude object
    pi = PlaybookInclude()
    # create Play object with tasks
    play = Play().load(dict(name="test", hosts="localhost", tasks=[dict(action=dict(module="shell", args="ls"))]))
    # create PlayContext object
    pc = PlayContext()
    pc.CLIARGS = dict(tags="")
    assert isinstance(pi.load_data(ds, "/tmp", variable_manager=None, loader=AnsibleLoader), TaskInclude)
    # create playbooks/test.

# Generated at 2022-06-11 10:37:04.328629
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.playbook import Playbook, Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.playbook.play_context import PlayContext

    # Ansible playbook

# Generated at 2022-06-11 10:37:15.321949
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # create a mock loader object
    mock_loader = AnsibleLoader(None)

    # create a mock variable manager
    mock_variable_manager = VariableManager()

    # create a mock templar
    mock_templar = Templar(loader=mock_loader, variables=mock_variable_manager.get_vars())

    # create an instance of PlaybookInclude
    playbook_include = PlaybookInclude()

    # create a mock load data

# Generated at 2022-06-11 10:37:26.018095
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    import ansible.parsing.dataloader
    import ansible.playbook.play
    import ansible.playbook.playbook

    test_playbook_include_obj = ansible.parsing.yaml.objects.AnsibleMapping()
    test_playbook_include_obj.update({'import_playbook': 'test/playbook.yaml'})

    test_play_obj = ansible.parsing.yaml.objects.AnsibleMapping()
    test_play_obj.update({'name': 'Test Play', 'hosts': 'localhost'})

    test_loader = ansible.parsing.dataloader.DataLoader()
    test_variable_manager = ansible.vars.manager.VariableManager()


# Generated at 2022-06-11 10:37:35.994250
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import copy
    import sys
    import unittest
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler_task import HandlerTask
    from ansible.playbook.conditional import Conditional
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-11 10:37:48.813023
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook

    pb = PlaybookInclude(
        import_playbook='/path/to/include.yml',
        tags=['tag1', 'tag2'],
        vars={'foo': 'bar'},
        when=False,
    )

    with open('/tmp/test.yml', 'w') as f:
        f.write('\n'.join([
            '- hosts: all',
            '  tasks:',
            '    - debug: msg="test1"',
            '- hosts: other',
            '  tasks:',
            '    - debug: msg="test2"',
        ]))

    result = pb.load_data(ds=pb.get_data(), basedir='/tmp')

    assert isinstance(result, Playbook)
   

# Generated at 2022-06-11 10:37:49.459120
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:38:00.554322
# Unit test for method load_data of class PlaybookInclude

# Generated at 2022-06-11 10:38:19.067481
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:38:29.811997
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import json
    import tempfile
    from copy import copy
    from ansible.module_utils.six import PY2

    from ansible.template import Templar
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.playbook.play import Play

    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.task import Task
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars import VariableManager

    # Load empty PlaybookInclude
    playbook_include = PlaybookInclude()
    # Load empty PlaybookInclude with empty data

# Generated at 2022-06-11 10:38:37.584737
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.playbook.play import Play

    import_playbook_data = {
        'import_playbook': 'test_playbook.yml',
        'vars': {
            'abc': 'def',
            'ghi': 'jkl'
        },
        'when': 'False'
    }

    pb_include = PlaybookInclude(**import_playbook_data)
    playbook = pb_include.load_data(import_playbook_data, None)

    assert playbook.entries[0].vars['abc'] == 'def'
    assert playbook.entries[0].vars['ghi'] == 'jkl'
    assert playbook.entries[0].tags == []
    assert playbook.entries[0].vars['tags'] == 'abc,def'