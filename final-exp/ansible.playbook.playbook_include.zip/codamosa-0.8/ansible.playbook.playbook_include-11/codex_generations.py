

# Generated at 2022-06-11 10:28:52.392316
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    ds = """
- import_playbook: roles/common/tasks/createusers.yml
  tags:
    - createusers

  vars:
    username: mr. x
    password: foo

- import_playbook: roles/common/tasks/createusers.yml name=admin password=bad
    """
    dl = DataLoader()
    vm = VariableManager()

    playbook_include = PlaybookInclude.load(ds, '', vm, dl)
    assert playbook_include.import_playbook == "roles/common/tasks/createusers.yml"
    assert playbook_include.tags == ["createusers"]

# Generated at 2022-06-11 10:29:05.113330
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import sys
    import os
    import pytest
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.errors import AnsibleParserError, AnsibleInternalError

    # create a fake class to test with
    class FakeOptions(object):
        @property
        def connection(self):
            return ''

# Generated at 2022-06-11 10:29:14.348323
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''
    This tests the method load_data of class PlaybookInclude,
    as well as the method load of class Playbook.
    '''
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.play import Play

    # Test 1:
    # Test if load_data parses the data correctly.
    # We are testing the following regex with regexp_test_test.yml as example data.
    # (?:([^=\s]+)\s*=)?\s*(?(1)(?:[\s\S]*?[^\s\\]))(?(1)[[\s\S]*?[^\s\\]]|[\s\S]*?[^

# Generated at 2022-06-11 10:29:27.250012
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    '''
    Method preprocess_data of class PlaybookInclude
    '''
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.parsing.yaml.objects import AnsibleMapping
    test_object = PlaybookInclude()
    test_object.vars = {'one': '1', 'two': '2'}
    test_object.tags = ['xyz']
    test_object.when = ['', '', '', '']
    test_object.notify = []
    test_object.handlers = []

    # test 1: no arguments
    test_ds = AnsibleMapping()
    test_ds.ansible_pos = (1, 1)
    test_result = test_object.preprocess_data(test_ds)

# Generated at 2022-06-11 10:29:38.282977
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    # create a simple playbook instance
    p = PlaybookInclude.load(dict(import_playbook='/etc/ansible/roles/role1.yml', tags=['tag1', 'tag2']), '.')
    assert isinstance(p, Playbook)
    # verify that the first item has the correct tags and conditional set
    assert isinstance(p._entries[0], Play)
    assert len(p._entries[0].tags) == 2
    assert p._entries[0].tags[0] == 'tag1'
    assert p._entries[0].tags[1] == 'tag2'
    assert p._entries[0]._included_conditional is None



# Generated at 2022-06-11 10:29:50.701909
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os
    from ansible.errors import AnsibleParserError
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Playbook
    from ansible.vars.manager import VariableManager

    p = PlaybookInclude()
    ds = { 'import_playbook': 'playbook.yml' }
    basedir = os.path.join(os.path.dirname(__file__), 'playbooks')

    # Removed due to use of AnsibleCollectionConfig
    # Playbook path is the only required positional argument
    # with self.assertRaises(TypeError):
    #     p.load_data()

    # ds cannot be None or empty

# Generated at 2022-06-11 10:29:52.662463
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''
    Stub test.
    '''
    pass

# Generated at 2022-06-11 10:30:03.938057
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    ds = []
    #import_playbook statements must specify the file name to import
    test = PlaybookInclude()
    try:
        test.preprocess_data(ds)
        assert False
    except AnsibleParserError:
        assert True

    #playbook import parameter is missing
    ds = dict(import_playbook=None)
    test = PlaybookInclude()
    try:
        test.preprocess_data(ds)
        assert False
    except AnsibleParserError:
        assert True

    #playbook import parameter must be a string indicating a file path, got
    ds = dict(import_playbook=1)
    test = PlaybookInclude()
    try:
        test.preprocess_data(ds)
        assert False
    except AnsibleParserError:
        assert True

    #import_

# Generated at 2022-06-11 10:30:13.054261
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task

    temp_playbook = Playbook()

    temp_playbook._entries.append(Play.load({
        'name': 'test_play_1',
        'hosts': 'host1',
        'tasks': [
            {
                'name': 'test_task_1',
                'debug': {'msg': "{{ test_var }}"}
            }
        ]
    }))


# Generated at 2022-06-11 10:30:23.807762
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play

    # test with a string
    ds = 'foobar.yml'
    new_ds = PlaybookInclude.preprocess_data(ds)
    assert dict(new_ds) == dict(import_playbook = 'foobar.yml')

    # test with a list
    ds = ['foobar.yml']
    new_ds = PlaybookInclude.preprocess_data(ds)
    assert dict(new_ds) == dict(import_playbook = 'foobar.yml')

    # test with a dict
    ds = dict(import_playbook = 'foobar.yml')
    new_ds = PlaybookInclude.preprocess_data(ds)

# Generated at 2022-06-11 10:30:38.292932
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    template = Templar(loader=loader, variables=variable_manager.get_vars())

    mock_args = {
        'import_playbook': 'all.yml',
        'tags': 'tag1,tag2,tag3',
        'vars': {'var': 'value'}
    }

    playbook_include_obj = PlaybookInclude()
    playbook_include_obj.load_data(mock_args, basedir='/', variable_manager=variable_manager, loader=loader)
    result = playbook_include_obj.preprocess_data(mock_args)

    assert playbook

# Generated at 2022-06-11 10:30:48.324585
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook

    class TestVM(object):
        def __init__(self, variable_manager, loader, basedir, inventory=None):
            self.variable_manager = variable_manager
            self.loader = loader
            self.basedir = basedir
            self.inventory = inventory

    test_vm = TestVM(variable_manager='fake-vm', loader='fake-loader', basedir='fake-basedir', inventory='fake-inventory')

    test_playbook = PlaybookInclude()
    loaded_playbook = test_playbook.load_data(ds='fake-ds', basedir='fake-basedir', variable_manager='fake-vm', loader='fake-loader')

    assert isinstance(loaded_playbook, Playbook)

# Generated at 2022-06-11 10:31:00.255940
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.dataloader import DataLoader
    import os

    basedir = os.getcwd()
    loader = DataLoader()
    ds = {'import_playbook': './test_playbook_include.yaml'}
    pb_inc = PlaybookInclude()
    playbooks = pb_inc.load_data(ds, basedir, loader=loader)

    # check pre_tasks

# Generated at 2022-06-11 10:31:10.497111
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    import ansible.parsing.yaml.objects

    # TEST PlaybookInclude.preprocess_data - Dict as ds with 'import_playbook' as key and string as value
    # (This case is one of the valid cases for the method, it should return a dict with the key being 'import_playbook', and with the same value)
    ds = {'import_playbook': 'import_playbook_test'}
    assert isinstance(PlaybookInclude().preprocess_data(ds), dict)
    assert 'import_playbook' in PlaybookInclude().preprocess_data(ds)

# Generated at 2022-06-11 10:31:23.033139
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # create a PyYaml object representing an include statement
    yaml_obj = { '- import_playbook': 'test.yaml' }
    # set up the required objects
    basedir = '.'
    variable_manager = None
    loader = None
    pbi = PlaybookInclude.load(yaml_obj, basedir, variable_manager, loader)
    # make sure the returned object is a Playbook() object
    assert pbi.__module__ == 'ansible.playbook'
    assert pbi.__class__.__name__ == 'Playbook'
    # make sure that the loaded playbook has the expected number of entries
    assert len(pbi._entries) == 1
    # make sure that the imported playbook has the expected filename

# Generated at 2022-06-11 10:31:23.448000
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:31:31.980814
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'], vault_password='secret', host_list=[])
    # pylint: disable=unused-variable
    playbook = PlaybookInclude.load(dict(import_playbook='test_playbook.yml', tags=['tag1'], vars=dict(var1=1, var2=2)), basedir='/mydir', variable_manager=VariableManager(loader=loader, inventory=inventory), loader=loader)
    assert playbook._entries[0].tags == ['tag1']

# Generated at 2022-06-11 10:31:44.697579
# Unit test for method preprocess_data of class PlaybookInclude

# Generated at 2022-06-11 10:31:50.273021
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    '''
    Unit test for method preprocess_data of class PlaybookInclude
    '''
    import ansible.parsing.yaml.objects
    import ansible.parsing.yaml.loader

# Generated at 2022-06-11 10:31:59.885273
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    # AnsibleMapping doesn't have vars attribute
    data1 = {"import_playbook": "/path/to/file"}

    # Create a PlaybookInclude object and perform the preprocess_data test
    pbi = PlaybookInclude()
    pbi.variable_manager = PlayContext()
    preprocess_result = pbi.preprocess_data(data1)

    # Check to see if the vars attribute is set after preprocessing
    assert 'vars' in preprocess_result

    # Check to make sure vars attribute is a dictionary
    assert isinstance(preprocess_result['vars'], dict)

# Generated at 2022-06-11 10:32:17.987983
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play


# Generated at 2022-06-11 10:32:18.568380
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:32:30.793062
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook = PlaybookInclude()
    ds = playbook.preprocess_data(
        {
            "import_playbook": "playbook1.yml",
        }
    )
    print(ds.__dict__)
    assert ds.__dict__ == {'_ansible_pos': None, 'import_playbook': 'playbook1.yml', 'tags': [], 'vars': {}}

    ds = playbook.preprocess_data(
        {
            "import_playbook": "playbook1.yml",
            "vars": {
                "foo": "bar",
                "test": "{{test_var}}",
            },
            "tags": "test"
        }
    )
    print(ds.__dict__)

# Generated at 2022-06-11 10:32:41.329587
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # from ansible.playbook.playbook_include import PlaybookInclude
    # Create test objects
    import_playbook = 'test_playbook.yml'
    vars = {'color': 'red'}
    basedir = '.'
    variable_manager = None
    loader = None

    # Instantiate test object
    pbi_test = PlaybookInclude()

    # Create and test the data structure that the method load_data will load
    ds = AnsibleMapping()
    ds['import_playbook'] = import_playbook
    ds['vars'] = vars

    # Call the method load_data
    pbi_test.load_data(ds, basedir, variable_manager, loader)

    # If the test passed, there are no asserts to run.
    # If it fails, the method

# Generated at 2022-06-11 10:32:52.207603
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.errors import AnsibleParserError
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import TaskDatastructure
    from ansible.playbook.task_include import TaskInclude

    file_name = 'test.yml'
    basedir = '/home/mdehaan/ansible/lib/ansible/playbook/playbook_include'
    file_path = os.path.abspath(os.path.join(basedir, file_name))

# Generated at 2022-06-11 10:33:04.221488
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''
    Test: load_data of class PlaybookInclude
    '''
    from ansible.playbook import Playbook

    file_name = 'tests/unit/playbooks/playbook_include_load.yml'
    variable_manager = None
    loader = None

    pi = PlaybookInclude.load(file_name, '.', variable_manager, loader)
    assert isinstance(pi, Playbook)

    pb_vars = pi[0].vars
    assert pb_vars
    assert pb_vars['playbook_include_vars']
    assert pb_vars['playbook_vars']
    assert pb_vars['include_vars']

    pb_tags = pi[0].tags
    assert pb_tags

# Generated at 2022-06-11 10:33:12.122649
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import ansible.playbook.play
    import ansible.playbook.playbook
    from ansible.playbook import PlaybookInclude
    from ansible.template import Templar
    from ansible.utils.collection_loader._collection_finder import _get_collection_name_from_path, _get_collection_playbook_path
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    import os

    fake_collection = "ANSIBLE_MODULES_I_SHOULD_NEVER_USE"
    AnsibleCollectionConfig.playbook_paths = [
        os.path.join(os.path.abspath(os.path.dirname(__file__)), 'data', 'collections', fake_collection),
    ]

# Generated at 2022-06-11 10:33:15.260241
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Can return a Playbook when called with basedir, variable_manager and loader
    PlaybookInclude().load_data(ds=dict(), basedir=None, variable_manager=None, loader=None)

# Generated at 2022-06-11 10:33:26.260939
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    entry = PlaybookInclude.load(data="include: play.yml", basedir="", variable_manager=None, loader=None)
    assert isinstance(entry, Play)
    assert entry.name == 'include: play.yml'

    entry = PlaybookInclude.load(data=dict(import_playbook='play.yml'), basedir="", variable_manager=None, loader=None)
    assert isinstance(entry, Play)
    assert entry.name == 'play.yml'


# Generated at 2022-06-11 10:33:26.936532
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:33:36.308041
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # TODO: Add unit test
    pass


# Generated at 2022-06-11 10:33:47.267863
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    playbook_include = PlaybookInclude()
    basedir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
    playbook_content = """
- hosts: localhost
  tasks:
    - name: debug
      debug:
        var: test_var
    - include: sub_playbook.yml
      when: test_var == "YES"
"""
    import_playbook = "sub_playbook.yml"
    test_var = {"test_var": "YES"}
    playbook_include.import_playbook = import_playbook
   

# Generated at 2022-06-11 10:33:58.999242
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.playbook import Playbook, PlaybookInclude
    from ansible.playbook.play import Play

    # create a playbook include object, load data in it, and execute method load_data
    playbook_include, playbooks = PlaybookInclude(), []
    playbook_include.vars = {'new_var': 'new_var_value', 'ansible_playbook': 'playbook_filename'}
    playbook_include.import_playbook = "include_playbook_filename"
    playbook_include.tags = ['tag1', 'tag2']
    playbook_include.when = ['when1', 'when2']
    playbook_include.load_data(ds = {}, basedir = "/basedir")

    # check that the playbook include has not changed

# Generated at 2022-06-11 10:34:09.456045
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader

    # create data loader and variable manager
    loader = DataLoader()
    variable_manager = VariableManager()

    # create playbook and set its base directory
    playbook = Playbook.load(yaml_data='''
    - import_playbook: test.yml
      vars:
        var1: 1
        var2: 2
      when: True
      tags: tag1,tag2
    ''', loader=loader)

    # create PlaybookInclude object and set its base directory

# Generated at 2022-06-11 10:34:13.841057
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Make sure that that we get a Playbook object, not a PlaybookInclude object
    PlaybookInclude.load_data(
        ds=dict(import_playbook='../../../tests/test_include_playbook.yml'),
        basedir='/tmp'
    )

# Generated at 2022-06-11 10:34:25.115447
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager

    pbivar1 = dict(a="1", b="2", c="3")
    pbi = PlaybookInclude.load(
        data=dict(
            import_playbook='test_play_include.yml',
            vars=pbivar1
        ),
        basedir='.'
    )

    pb = Playbook(loader=None)
    pbi.load_data(
        ds=pbi,
        basedir='.',
        variable_manager=VariableManager()
    )

    assert isinstance(pb, Playbook)
    assert len(pb._entries) == 1
    assert isinstance(pb._entries[0], Play)

    p

# Generated at 2022-06-11 10:34:28.841375
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Ansible 2.5 doesn't allow importing a task_list, so if this test fails, it is likely due to that missing feature
    # This test is not affected by any other settings in ansible.cfg, such a ssh connection parameters, so it is
    # not advisable to test it with something that is not local
    pass

# Generated at 2022-06-11 10:34:39.157002
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    playbook_include_object = PlaybookInclude()
    playbook_include_object.load_data(data={ "import_playbook": "../tasks/main.yml" }, basedir="")
    playbook_object = playbook_include_object._load_playbook_data(
        file_name="../tasks/main.yml", variable_manager=None, vars={ "user":"test" }
    )
    assert_true(isinstance(playbook_object, Playbook))
    assert_equals(playbook_object.get_plays(), [])
    assert_equals(playbook_object.get_roles(), [])
    assert_equals(playbook_object.get_handlers(), [])


# Generated at 2022-06-11 10:34:39.789175
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:34:49.894423
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    # When included files are set in PlaybookInclude object, load_data() should return a Playbook object
    included_files = ['test_file_1.yml']
    playbook_include = PlaybookInclude()
    playbook = playbook_include.load_data(included_files, '.')
    assert playbook is not None
    assert isinstance(playbook, Playbook)
    assert len(playbook._entries) == 1
    assert isinstance(playbook._entries[0], Play)
    assert playbook._entries[0].file_name == 'test_file_1.yml'

# Generated at 2022-06-11 10:35:11.263684
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Play

    # Create a new PlaybookInclude object
    playbook_include = PlaybookInclude()

    # Create a variable manager
    variable_manager = None

    # Create a loader object
    loader = None

    # Create a Playbook object
    playbook = PlaybookInclude.load({'playbook': 'playbook.yaml'}, basedir='/path/to/file', variable_manager=variable_manager, loader=loader)

    # Check if playbook is an instance of Playbook
    assert(isinstance(playbook, Playbook))

    # Check if the first entry is an instance of Play
    assert(isinstance(playbook._entries[0], Play))

    # Check if the variable manager is correct
    assert(playbook._variable_manager is variable_manager)

    # Check if the loader is correct

# Generated at 2022-06-11 10:35:21.556109
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Load a simple playbook to include (without roles)
    playbook = PlaybookInclude.load_data({'import_playbook': 'include_playbook.yml'}, '.')
    hosts = playbook.get_hosts()
    assert len(hosts) == 1
    for host in hosts:
        assert host == 'foobar'
        roles = playbook.get_roles_for_host(host)
        assert len(roles) == 0

    # Load a playbook with roles
    playbook = PlaybookInclude.load_data({'import_playbook': 'include_playbook.yml', 'vars': {'a_var': 'a_value', 'b_var': {'b_key': 'b_value'}}}, '.')
    hosts = playbook.get_hosts()
    assert len(hosts)

# Generated at 2022-06-11 10:35:32.567240
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Unit test for
    # method load_data of class PlaybookInclude
    import pytest
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager.get_vars())
    new_obj = PlaybookInclude.load({"import_playbook": "../../../galaxy/example/pb.yml"}, "../../../galaxy/example/", variable_manager=variable_manager, loader=loader)
    assert isinstance(new_obj, PlaybookInclude)

# Generated at 2022-06-11 10:35:43.301364
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    """
    Test the load_data method of the PlaybookInclude class
    """

    # Test a simple playbook import
    playbook_include = PlaybookInclude()

    data = { 'import_playbook': '../../library/copy.yml' }
    playbook_include.load_data(ds=data, basedir=os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'library')))

    assert playbook_include._import_playbook == '../../library/copy.yml'
    assert playbook_include._vars == {}
    assert playbook_include._tasks == []

    # Test a playbook import with params
    playbook_include = PlaybookInclude()

# Generated at 2022-06-11 10:35:43.879609
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:35:45.045675
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    assert False, "No tests for PlaybookInclude.load_data"


# Generated at 2022-06-11 10:35:57.125833
# Unit test for method load_data of class PlaybookInclude

# Generated at 2022-06-11 10:35:57.925741
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:36:08.705062
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os
    import shutil
    import tempfile
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    local_temp_dir = tempfile.mkdtemp()
    atexit.register(shutil.rmtree, local_temp_dir)

    variable_manager = VariableManager()
    loader = DataLoader()

    p1 = os.path.join(local_temp_dir, 'play1.yml')
    p2 = os.path.join(local_temp_dir, 'play2.yml')


# Generated at 2022-06-11 10:36:20.457027
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    import_data = {'import_playbook': "./foo/bar.yml", 'vars': {'foo': 'bar'}}
    include_data = PlaybookInclude()
    assert include_data.load_data(import_data, basedir='/tmp') is None, "Should not return any Playbook"
    assert include_data.load_data(import_data, basedir='./foo') is None, "Should not return any Playbook"

    # create a playbook with a play
    playbook = Playbook()
    playbook._entries.append(Play())

    # import under 'foo'

# Generated at 2022-06-11 10:36:41.231193
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import tempfile
    import os
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleSequence, AnsibleMapping
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmp_file1 = tempfile.mkstemp(dir=tmp_dir)
    os.close(fd)

# Generated at 2022-06-11 10:36:50.897061
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext

    from units.mock.path import mock_unfrackpath_noop

    mock_loader, playbook_path = mock_unfrackpath_noop()

    pbi = PlaybookInclude()
    pbi._entries = []

# Generated at 2022-06-11 10:37:01.476024
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import tempfile
    import os.path
    import os
    import shutil

    my_playbook = 'play.yml'
    my_play = "foo.yml"
    my_play_block = "bar.yml:12"
    my_playbook_dir = tempfile.mkdtemp()

    # create a temporary copy of the playbook
    test_playbook_dir = tempfile.mkdtemp()

    # create a temporary copy of the play
    test_play_dir = tempfile.mkdtemp()


# Generated at 2022-06-11 10:37:11.848167
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.errors import AnsibleParserError
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    # Test the object can be created
    # ---------------------------
    playbook_include = PlaybookInclude()

    # Test load_data
    # ---------------
    # Testing the import of a playbook
    playbook_include.load_data(ds={'import_playbook':'../../ansible/test/unit/data/test_import_playbook/import_playbook.yml', 'vars':{'var1': 'val1'}}, basedir='/etc/ansible')
    assert playbook_include.import_playbook == '../../ansible/test/unit/data/test_import_playbook/import_playbook.yml'

# Generated at 2022-06-11 10:37:20.472495
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    file_name="../../../../lib/ansible/playbooks/rax.py"
    playbook_name="../../../../lib/ansible/playbooks/rax.py"
    basedir="/Users/lix/GitHub/ansible/lib/ansible/playbooks"
    pb = PlaybookInclude.load(file_name,basedir,None)
    assert isinstance(pb, Playbook)
    assert len(pb._entries) == 1
    print("Pass test_PlaybookInclude_load_data")


# Generated at 2022-06-11 10:37:29.553039
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    p = PlaybookInclude()
    p.load_data({'import_playbook': 'import.yml'}, os.getcwd())
    assert isinstance(p, PlaybookInclude)

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'a': 1, 'b': 2} # dict()
    inventory_manager = InventoryManager(loader=loader, sources=['localhost'])

    p = PlaybookInclude()

# Generated at 2022-06-11 10:37:39.961529
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    display.verbosity = 3
    fake_loader, inventory, variable_manager = \
            _init_global_environment()

    # PlaybookInclude with conditional
    data1 = dict(
        name='First play',
        hosts='all',
        import_playbook='test/test_playbook_include/pb1.yml',
        vars=dict(test_var='test1'),
        when=dict(test_var='test2')
    )
    pi = PlaybookInclude.load(data1,
                              variable_manager=variable_manager,
                              loader=fake_loader)
    assert isinstance(pi, Playbook)
    assert len(pi._entries) == 1

# Generated at 2022-06-11 10:37:40.589613
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
   pass

# Generated at 2022-06-11 10:37:54.238876
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import ansible.playbook.playbook_include
    import ansible.playbook.play

    playbook_include_object = ansible.playbook.playbook_include.PlaybookInclude()
    playbook_include_object.vars = {}
    playbook_include_object.when = []
    playbook_include_object.tags = []


# Generated at 2022-06-11 10:37:59.560082
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''
    Unit test for method load_data of class PlaybookInclude.
    '''
    playbook_include = PlaybookInclude()

    # Trying to load a playbook using a non-existent path
    with pytest.raises(IOError):
        playbook_include.load_data(ds='/tmp/non-existent-path/non-existent-file', basedir=None)



# Generated at 2022-06-11 10:38:23.675847
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.splitter import parse_kv

    templar = Templar(loader=None)
    ds = AnsibleLoader(None, list()).load("test.yml")[0]
    pb = PlaybookInclude()
    pb.load_data(ds, templar, None)

# Generated at 2022-06-11 10:38:33.196624
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    import six
    import io
    import ansible.constants as C
    from ansible.module_utils.six import iteritems, string_types
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    # 1. Test PlaybookInclude load_data method with yaml
    # 1.1. Test import a playbook from collections
    # actual playbook:
    #
    # - hosts: all
    #   gather_facts: True
    #   tasks:
    #   - name: Test task
    #     debug: msg='Test task'

    test_data = {'import_playbook': 'my.collection.hello_world'}


# Generated at 2022-06-11 10:38:34.750342
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # PlaybookInclude.load_data() is called internally, it is not expected to be
    # called directly by users. In other words, it's not a public method.
    pass
