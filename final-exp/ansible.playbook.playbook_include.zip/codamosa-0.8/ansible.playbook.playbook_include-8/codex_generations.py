

# Generated at 2022-06-11 10:28:54.149683
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # pylint: disable=redefined-outer-name, unused-argument
    # Mocking allows us to run this unit test in isolation, even though the
    # method load_data is calling another class method load_data
    # mock_Playbook_load_data.return_value is the return value of
    # Playbook.load_data method.
    from ansible.playbook import Playbook
    mock_Playbook_load_data = Mock(spec=Playbook.load_data, return_value=dict(foo='bar'))
    with patch.object(Playbook, 'load_data', mock_Playbook_load_data):
        playbook_include = PlaybookInclude()

# Generated at 2022-06-11 10:28:55.836022
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    PlaybookInclude.preprocess_data(None)


# Generated at 2022-06-11 10:29:08.306105
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    # Since the PlaybookInclude.load_data() method returns a Playbook() object,
    # the test for it is in test_Playbook_load_data()

    playbook = PlaybookInclude()
    playbook.import_playbook = 'test_included_playbook'
    playbook.vars = {'test_include_var': 'test_include_value'}

    test_playbook = Playbook()

# Generated at 2022-06-11 10:29:18.363461
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include = PlaybookInclude()

    ds = {
        'import_playbook': 'playbook.yml',
        'vars': {'key1': 'val1', 'key2': 'val2'}
    }
    expected = [
        {'import_playbook': 'playbook.yml', 'vars': {'key1': 'val1', 'key2': 'val2'}}
    ]
    actual = playbook_include.preprocess_data(ds)
    assert actual == expected

    ds = {
        'import_playbook': 'playbook.yml',
        'tags': 'tag1,tag2',
        'vars': {'key1': 'val1', 'key2': 'val2'}
    }

# Generated at 2022-06-11 10:29:19.105500
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:29:28.976140
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.vars.manager import VariableManager
    pb = PlaybookInclude.load_data(
        dict(import_playbook='playbook.yml'),
        basedir='/tmp',
        variable_manager=VariableManager(),
    )
    assert isinstance(pb, Playbook)
    assert len(pb._entries) == 2
    assert isinstance(pb._entries[0], Play)
    assert isinstance(pb._entries[1], Play)


# Generated at 2022-06-11 10:29:39.069730
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # pylint: disable=redefined-outer-name
    # pylint: disable=too-many-locals

    # when we have full support for python 3.6, we can make this a bit more
    # readable, but for now we need to use the version which works on py35
    # and py36
    # py36:
    #   from unittest.mock import call
    #   from unittest.mock import Mock
    #   from unittest.mock import patch
    #   from unittest.mock import sentinel
    #   from unittest.mock import create_autospec

    from ansible.module_utils.six.moves import mock
    import sys
    if sys.version_info[0] == 2:
        from mock import call, create_autospec, Mock

# Generated at 2022-06-11 10:29:51.936587
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import ansible.playbook.playbook_include
    from ansible.playbook.playbook_include import PlaybookInclude
    import ansible.playbook.play
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.parsing.yaml.objects import AnsibleMapping
    import ansible.template.template
    from ansible.template.template import Templar
    ds = AnsibleMapping()
    ds["import_playbook"] = "hello.yaml"
    ds["tags"] = "TAG,TAG2"
    ds["vars"] = {}
    #new_obj = PlaybookInclude()
    #pb = PlaybookInclude.load(ds, "/home", None, None)


# Generated at 2022-06-11 10:30:03.463068
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import sys
    import unittest
    import collections

    class TestInclude(unittest.TestCase):
        '''
        Test the load_data() method of the PlaybookInclude class
        '''
        def test_load_data_without_basedir(self):
            import_playbook = 'sample_include.yml'
            # Fake the data
            ds = AnsibleMapping()
            ds['import_playbook'] = import_playbook
            ds['vars'] = {'var1': 'var1_value'}

            # Fake the loader
            class FakeLoader:
                def _get_file_contents(file_path):
                    return "---\n- hosts: test_host\n"

            variable_manager = None
            # This is to fake the basedir which is required by Ans

# Generated at 2022-06-11 10:30:10.735488
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play

    basedir = '/some/dir/'
    fake_loader = None
    fake_variable_manager = None
    fake_playbook_entry = 'fake_playbook_entry'
    fake_playbook_entry_obj = Play()

    fake_playbook_entry_obj.vars = {'fake_vars': 'fake_value'}
    fake_playbook_entry_obj.tags = ['fake_tags']
    fake_playbook_entry_obj._included_path = 'fake_included_path'

    fake_playbook = PlaybookInclude()
    fake_playbook._entries = [fake_playbook_entry_obj,]

    fake_playbook.import_playbook = fake_playbook_entry


# Generated at 2022-06-11 10:30:27.051359
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook

    playbook_include = PlaybookInclude()
    # Test 1: empty playbook data and base directory
    try:
        playbook_include.load_data(dict(), '.')
    except Exception as e:
        if not isinstance(e, AnsibleAssertionError):
            raise
    # Test 2: empty playbook data
    try:
        playbook_include.load_data(dict(), '.')
    except Exception as e:
        if not isinstance(e, AnsibleAssertionError):
            raise
    # Test 3: valid playbook data

# Generated at 2022-06-11 10:30:36.981093
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    # Testing playbook loading
    playbook_include = PlaybookInclude()
    playbook_include.load_data(dict(import_playbook='playbook.yml'), '.')
    assert isinstance(playbook_include.loaded_data, Playbook)
    assert playbook_include.loaded_data._entries is not None
    # Contains 2 plays
    assert len(playbook_include.loaded_data._entries) == 2

    # Testing multiple levels of playbook loading
    p1 = Playbook()

# Generated at 2022-06-11 10:30:47.802767
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext

    loader = MockLoader()

    contents_pb_1 = '''
    - hosts: foo
      tasks:
      - shell: /bin/foo -x
    '''

    contents_pb_2 = '''
    - include: pb1.yml
         vars:
         - var1: value1
         - var2: value2

    - include: pb1.yml
         tags: tag1,tag2
         vars:
         - var3: value3
    '''

    pb_

# Generated at 2022-06-11 10:30:49.093513
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Needs to be implemented
    assert True

# Generated at 2022-06-11 10:31:00.678521
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import ansible.playbook.play as play
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.tasks.include_tasks import IncludeTask
    from ansible.template import Templar
    import ansible.vars.manager as vm
    import ansible.vars.hostvars as hostvars

    vars_manager = vm.VarsManager()
    vars_manager._fact_cache = hostvars.HostVars(dict(), False)
    var_manager = vm.VariableManager()
    var_manager._fact_cache = hostvars.HostVars(dict(), False)

    temp = Templar(loader=None, variables=dict())
    basedir = os.path.join(C.DEFAULT_LOCAL_TMP, 'playbook_include_load_data')


# Generated at 2022-06-11 10:31:02.582493
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    raise Exception("PlaybookInclude:load_data expects a 'Loader' that doesn't exist in the test environment")


# Generated at 2022-06-11 10:31:14.198115
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude

    test_file = 'test_import.yml'
    test_file_path = os.path.join(os.path.dirname(__file__), test_file)
    test_import_playbook_content = open(test_file_path, 'r').read()
    test_import_playbook_content = test_import_playbook_content.format(test_file=test_file)
    ds = yaml.load(test_import_playbook_content)
    test_base_dir = os.path.dirname(test_file_path)

    # Scenarios:
    # 1. When with parameters; when without parameters; empty when; vars
    # 2. Empty vars; v

# Generated at 2022-06-11 10:31:25.598899
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    ###########################
    # Imported playbooks (file or FQCN)
    ###########################
    from ansible.playbook import Playbook
    # _load_playbook_data is tested in test_Playbook.test_load_playbook_data
    pb = PlaybookInclude.load(
        data={
            "import_playbook": "/tmp/role1/tests/test_integration/test_playbook_include_load_data/test_include_import_1.yml"
        },
        basedir='/tmp/',
        variable_manager=None,
        loader=None
    )
    assert isinstance(pb, Playbook)
    assert len(pb._entries) == 1

# Generated at 2022-06-11 10:31:36.248956
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.template import Templar

    c = PlaybookInclude()
    c.load_data({'import_playbook': 'test/support/yaml/import_playbook.yml', 'vars': {'foo': 'bar'}, 'tags': ['tag1', 'tag2']}, basedir='test/support/yaml')

    assert isinstance(c, PlaybookInclude)
    assert isinstance(c.import_playbook, string_types)
    assert c.import_playbook == 'test/support/yaml/import_playbook.yml'

    assert isinstance

# Generated at 2022-06-11 10:31:47.908205
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    display = Display()
    display.verbosity = 3
    options = Mock()
    b_vars = dict(foo='bar')
    b_loader = DictDataLoader({
        u'src/test/test_playbook_include.yml': u'''
- hosts: test_playbook_include
  gather_facts: True
  roles:
  - role: test_role'''
    })
    b_variable_manager = VariableManager()
    b_variable_manager._extra_vars = b_vars

    yaml_data = u'''
- import_playbook: src/test/test_playbook_include.yml
- hosts: test_playbook_include_2
  gather_facts: True
  roles:
  - role: test_role'''

# Generated at 2022-06-11 10:32:03.334011
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Only 1 test could be written:
    #   - test_PlaybookInclude_load_data_with_parameters
    #   - test_PlaybookInclude_load_data_without_parameters

    # import fakes
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject, AnsibleMapping
    from ansible.template import Templar

    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
   

# Generated at 2022-06-11 10:32:13.884515
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    pb = PlaybookInclude.load({'import_playbook':'../files/include_playbook.yml'}, '.')
    assert isinstance(pb, Playbook)
    assert pb.get_plays()[0].get_name() == 'Include Play Example 1'
    assert pb.get_plays()[0]._included_path == os.path.dirname(os.path.abspath(to_bytes('../files/include_playbook.yml', errors='surrogate_or_strict')))
    assert isinstance(pb.get_plays()[1], Role)
    assert pb.get_plays()[1]._role_name == 'include_role_b'

# Generated at 2022-06-11 10:32:21.339887
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.errors import AnsibleParserError
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.template import Templar

    loader = DataLoader()

    # Create an PlaybookInclude instance, add the import_playbook line
    # and load the data
    playbook_include = PlaybookInclude()
    playbook_include_ds = dict()
    playbook_include_ds['import_playbook'] = 'import.yml'
    playbook_include._load_data(data=playbook_include_ds, basedir=None, variable_manager=None, loader=loader)

    # Create a Play() object, set the name and add a task


# Generated at 2022-06-11 10:32:33.980438
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    import_name = 'test-play-name'
    basedir = '/test/test-dir'
    playbook_file = '/test/test-dir/test-play-name.yaml'

    # set up instance
    playbook_include_instance = PlaybookInclude()

    # create the playbook
    playbook = Playbook()
    play_instance = Play()
    play_instance._included_path = basedir
    playbook._entries = [play_instance]

    # mock load_data method
    def load_data_function(ds, basedir, variable_manager=None, loader=None):
        return None

    def template_function(data):
        return playbook_file

    # mock the load method to return the created playbook
   

# Generated at 2022-06-11 10:32:43.311578
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os
    import sys
    import tempfile
    from ansible.module_utils.six import StringIO
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader

    sys.path.append(os.path.join(os.path.dirname(__file__), '../../test/'))
    from units.mock.loader import DictDataLoader

    # Create playbook include object
    pbi = PlaybookInclude()
    pbi.basedir = tempfile.gettempdir()

    # Create playbook include data structure

# Generated at 2022-06-11 10:32:44.433890
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-11 10:32:55.824750
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import sys
    import os
    import unittest
    import runpy
    import tempfile

    sys.path.append(os.path.realpath(os.path.dirname(__file__)))

    # Create a temporary directory.
    test_dir = tempfile.mkdtemp()

    # Create a temporary file.
    test_file_fd, test_file_name = tempfile.mkstemp(dir=test_dir)

    # Write a playbook to the temporary file using a python list.

# Generated at 2022-06-11 10:33:07.040683
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    import sys
    import unittest2 as unittest
    if sys.version_info[0] >= 3 and sys.version_info[1] >= 2:
        from unittest.mock import patch
    else:
        from mock import patch

    with patch('ansible.playbook.include.PlaybookInclude.load_data') as \
            mock_PlaybookInclude_load_data:
        with patch('ansible.playbook.include.PlaybookInclude.preprocess_data') as \
                mock_PlaybookInclude_preprocess_data:
            PlaybookInclude.load_data(None, None)
            mock_PlaybookInclude_load_data.assert_called_once_with(None, None)

# Generated at 2022-06-11 10:33:17.238870
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import tempfile
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.parsing.dataloader import DataLoader

    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    display = Display()
    display.verbosity = 4

    path = tempfile.mkdtemp()
    #populate the path with some fake plugin directories
    print("Fake plugin directories are: %s" % str(add_all_plugin_dirs(path)))

    # create a temporary directory
    tmp_dir = tempfile.mkdtemp()


# Generated at 2022-06-11 10:33:17.913242
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:33:35.411236
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.plays import Plays
    from ansible.playbook.accelerate import Accelerator
    from ansible.plugins import module_loader
    import adhoc
    import collections
    import json

    results = []

    # The PlaybookInclude class can store an import_playbook attribute,
    # but when this attribute is set to an Include directive, the load_data
    # method will be called. This test checks that load_data method.

    # The following playbooks were created with ansible-playbook --diff

# Generated at 2022-06-11 10:33:38.882687
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook

    pb = PlaybookInclude.load({'playbook': 'import_playbook.yml', 'vars': {'var_value': 123}}, 'basedir', variable_manager=None, loader=None)
    assert isinstance(pb, Playbook)


# Generated at 2022-06-11 10:33:51.504483
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook, Play
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    playbook = PlaybookInclude()
    pb = playbook.load_data(ds={
        'import_playbook': '/home/ansible/collection/ansible_collections/namespace/collection/playbook.yml',
        'tags': ['create', 'destroy'],
        'vars': {
            'var1': 'value1',
            'var2': 'value2',
        },
    }, basedir='/home/ansible')

    assert isinstance(pb, Playbook)
    assert len(pb._entries) == 1
    assert isinstance(pb._entries[0], Play)
    assert pb._entries[0].name is None

# Generated at 2022-06-11 10:34:01.314159
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Play
    from ansible.playbook.play import Role
    from ansible.playbook.play import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.reserved import Reserved

    import ansible.constants as C
    import os

    basedir = "."


# Generated at 2022-06-11 10:34:12.438852
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # create an initial test object
    play = PlaybookInclude()

    # create a test playbook
    playbook = "test_playbook"
    # create a collection_config
    collection = "test_collection"
    # create the initial loader
    loader = 1

    # create a test conditional
    when = ["test_when"]

    # create a test object to return
    new_obj = "test_new_obj"

    # create a list of test tags
    tags_one = ["tag_one", "tag_two"]
    tags_two = ["tag_three", "tag_four"]

    # create test variables
    variables_one = {"test_var_one": 1, "test_var_two": 2}
    variables_two = {"test_var_three": 3, "test_var_four": 4}

    # create

# Generated at 2022-06-11 10:34:24.021797
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # check 1st case -> Import playbook is a relative path
    # setup
    import ansible.playbook.play
    pb = ansible.playbook.play.Play()
    import ansible.playbook.task
    task = ansible.playbook.task.Task()
    task.action = 'meta'
    import ansible.playbook.block
    block = ansible.playbook.block.Block()
    block._setup_task_blocks(play=pb)
    block.block = [task]
    pb._setup_handlers()
    pb._handlers._list.append(block)
    import ansible.playbook.role
    role = ansible.playbook.role.Role()
    import ansible.playbook.role.task
    roletask = ansible.playbook.role.task.Task()

# Generated at 2022-06-11 10:34:32.428566
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    """
    Unit test for method load_data of class PlaybookInclude
    """
    from ansible.playbook import Playbook

    import_playbook = "hosts: all\ntasks:\n- name: ping all hosts\n  ping:\n    data: 'hello world'\n"
    tempfile_path = ansible_mock.create_tempfile(import_playbook)
    import_playbook_path = tempfile_path

    basedir = os.getcwd()
    pbinclude = PlaybookInclude.load({'import_playbook': import_playbook_path}, basedir, loader=None)

    assert isinstance(pbinclude, Playbook)

    for p in pbinclude.get_plays():
        for task in p.get_tasks():
            assert task.action == 'ping'


# Generated at 2022-06-11 10:34:33.068342
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:34:45.364714
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # test data
    data = {
            'import_playbook': './test.pb',
            'tags': 'test-tag',
            'vars': {
                'test-var': 'test-var-val',
            }
    }

    # test variables
    class TestVariableManager:
        def get_vars(self):
            return {'test-vm-var': 'test-vm-var-val'}

    t_vm = TestVariableManager()

    # test loader
    class DummyConfig:
        pass

    class DummyInventory:
        def __init__(self):
            self.config = DummyConfig()

    class DummyLoader:
        def __init__(self):
            self._basedir = 'test-basedir'
            self._search_path = ['test-basedir2']

# Generated at 2022-06-11 10:34:55.190694
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # test load_data method with an empty PlaybookInclude object
    empty_ds = AnsibleMapping()
    empty_ds.ansible_pos = "foo.yaml:1"
    pb = PlaybookInclude()
    pb2 = pb.load_data(ds=empty_ds, basedir="tmp/ansible_test", variable_manager=None, loader=None)
    assert isinstance(pb2, PlaybookInclude)

    # test load_data method with a non-empty PlaybookInclude object
    ds = AnsibleMapping()
    ds.ansible_pos = "foo.yaml:1"
    ds['import_playbook'] = "playbook1.yaml"

# Generated at 2022-06-11 10:35:16.488259
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Create a test PlaybookInclude object
    obj = PlaybookInclude()

    # Create test data
    playbook_path = "test_playbook.yml"
    basedir = "."
    variable_manager = None
    loader = None

    # Prepare sample data
    ds = {'import_playbook': playbook_path}

    # Load test data
    pb = obj.load_data(ds, basedir, variable_manager, loader)

    # Test that the playbook return is a valid Playbook object
    from ansible.playbook import Playbook
    assert( isinstance(pb, Playbook) )


# Generated at 2022-06-11 10:35:17.103375
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:35:24.580971
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # import here to avoid a dependency loop
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.playbook.included_file import IncludedFile
    from collections import namedtuple
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.loader import AnsibleLoader

    # given
    task_ds = """
    - debug:
        msg: t1
    """

    task_res = [{'debug': {'msg': 't1'}}]

    play_ds = """
    hosts: all
    tasks:
    {}
    """.format(task_ds)

    play_res = {'hosts': 'all', 'tasks': task_res}


# Generated at 2022-06-11 10:35:37.262939
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    # test with a regular (non collection) playbook
    pb1 = PlaybookInclude.load(data="../../../library/import.yml", basedir="../../../library")
    assert type(pb1) is Playbook
    for entry in pb1._entries:
        assert type(entry) is Play
    assert pb1._included_path == '../../../library'

    # test with a collection playbook
    pb2 = PlaybookInclude.load(data="ansible_collections.test.test_file.test_playbook", basedir="../../../library")
    assert type(pb2) is Playbook
    for entry in pb2._entries:
        assert type(entry) is Play
   

# Generated at 2022-06-11 10:35:46.273556
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.playbook import Playbook

    # a playbook including another playbook
    pb = PlaybookInclude.load({'import_playbook': 'a_playbook.yml'}, '/path/to/basedir', variable_manager=None, loader=None)
    assert isinstance(pb, Playbook)
    pb = PlaybookInclude.load({'import_playbook': 'a_playbook.yml', 'tags': 'a_tag'}, '/path/to/basedir', variable_manager=None, loader=None)
    assert isinstance(pb, Playbook)
    pb = PlaybookInclude.load({'import_playbook': 'a_playbook.yml', 'vars': {'a': 1}}, '/path/to/basedir', variable_manager=None, loader=None)

# Generated at 2022-06-11 10:35:56.120476
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Loading a dictionary
    ds = {'import_playbook': 'test.yml'}
    basedir = os.path.dirname(__file__)
    pb = PlaybookInclude().load_data(ds=ds, basedir=basedir)
    assert isinstance(pb, Playbook)

    # Loading a string
    ds = 'import_playbook: test.yml'
    basedir = os.path.dirname(__file__)
    pb = PlaybookInclude().load_data(ds=ds, basedir=basedir)
    assert isinstance(pb, Playbook)


# Generated at 2022-06-11 10:36:07.553144
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os
    import ansible.playbook.playbook_include as playbook_include
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader,
                                 sources='localhost,')
    variable_manager.set_inventory(inventory)

    basedir = os.path.dirname(os.path.dirname(playbook_include.__file__))

    # Load a playbook from test directory
    filename = 'import_playbook_test.yml'
    test_dir = os.path.dirname(os.path.dirname(playbook_include.__file__))
   

# Generated at 2022-06-11 10:36:09.369803
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    """
    Unit test for method load_data of class PlaybookInclude

    :param ds:
    :param basedir:
    :param variable_manager:
    :param loader:
    :return:
    """
    pass

# Generated at 2022-06-11 10:36:21.867408
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.become import Become
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager

    data = '''- import_playbook: test.yaml
      vars:
        test: {{ this_var }}
      tags:
        - test
      when: test
- import_playbook: test.yaml
  vars:
    test: {{ this_var_2 }}
    foo: bar
  when: test
'''


# Generated at 2022-06-11 10:36:32.258099
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    pbi = PlaybookInclude()

    # test for invalid data structure for load_data
    # with empty data structure
    ds = {}
    # basedir is not required to evaluate playbook
    basedir = None
    # variable_manager is not required to evaluate playbook
    variable_manager = None
    # loader is not required to evaluate playbook
    loader = None
    # try to load data with pbi
    with pytest.raises(AnsibleAssertionError):
        pbi.load_data(ds, basedir, variable_manager, loader)

    # with invalid data structure
    ds = ['invalid', 'data', 'structure']
    # try to load data with pbi

# Generated at 2022-06-11 10:36:47.344036
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-11 10:36:58.185291
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import tempfile
    import shutil
    import pdb
    import ansible.playbook.playbook_include
    import ansible.playbook.play

    # Create temp directory to store some playbooks
    temp_dir_path = tempfile.mkdtemp()

    # Create play1
    play1_file_path = os.path.join(temp_dir_path, "play1.yml")
    play1_file = open(play1_file_path, "w")
    play1_file.write("""---
- hosts: all
  tasks:
    - fail:
        msg: in play1""")
    play1_file.close()

    # Create play2
    play2_file_path = os.path.join(temp_dir_path, "play2.yml")
    play2_file

# Generated at 2022-06-11 10:37:02.868476
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    variable_manager = None
    basedir = "."
    ds = { 'import_playbook': 'dummy.yml' }
    instance = PlaybookInclude()
    result = instance.load_data(ds, basedir, variable_manager, loader)
    assert result.__class__.__name__ == 'Playbook'

# Generated at 2022-06-11 10:37:04.684099
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    assert PlaybookInclude.load_data({'import_playbook': 'file_name'}, None)


# Generated at 2022-06-11 10:37:15.421120
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook, Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    pb = PlaybookInclude().load_data(
            ds = [dict(import_playbook = 'test/data/test_playbook.yml', vars = dict(var1 = 'value1'))],
            basedir = 'test/data/',
    )
    # check that the right object is returned
    assert isinstance(pb, Playbook)
    # check that the number of entries is correct
    assert len(pb._entries) == 1
    # check that the entry is a Play
    assert isinstance(pb._entries[0], Play)
    # check that the conditions of the include have been propagated
    assert pb._entries[0]._

# Generated at 2022-06-11 10:37:18.134918
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pc = PlaybookInclude()
    assert pc.load_data({'import_playbook': 'foo', 'vars': {'a': 'b'}}, 'foo')

# Generated at 2022-06-11 10:37:28.158240
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultLib

    import os

    playbook_include = PlaybookInclude()
    yaml_data = {'import_playbook': './playbooks/base.yml'}
    playbook_data = playbook_include.load_data(yaml_data, os.getcwd() + '/test/sanity/playbooks/')
    assert isinstance(playbook_data, Playbook)

    yaml_data = {'import_playbook': './playbooks/base.yml', 'tags': ['test']}
    playbook_data = playbook_include.load_data(yaml_data, os.getcwd() + '/test/sanity/playbooks/')

# Generated at 2022-06-11 10:37:35.344289
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()

    data = {'import_playbook': 'install.yml'}

    playbook_include = PlaybookInclude()
    playbook_load_data = playbook_include.load_data(data, basedir='/tmp', variable_manager=variable_manager, loader=loader)

    assert playbook_load_data._entries == []
    assert playbook_load_data.filename == 'install.yml'

# Generated at 2022-06-11 10:37:48.251387
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.loader import AnsibleLoader

    ###################
    # Check for basic playbook import
    ###################
    ds = AnsibleMapping()
    import_playbook_path = 'test_playbook.yml'
    ds['import_playbook'] = import_playbook_path
    pb = PlaybookInclude.load(ds, '/tmp', variable_manager=None, loader=AnsibleLoader)
    assert isinstance(pb, Playbook)
    assert len(pb.get_plays()) == 1
    assert pb.get_plays()[0].name == 'play0'

    ###################
    # Check for

# Generated at 2022-06-11 10:37:59.140304
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # Create a dummy datastructure
    ds = { 'import_playbook': 'mybook.yml', 'vars': { 'var1': 'val1' } }
    basedir = '.'
    variable_manager = None
    loader = None

    # Create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # Load data into the playbook_include object using the method
    playbook_include.load_data(ds, basedir, variable_manager, loader)

    # Check if the import_playbook attribute is properly set
    assert playbook_include.import_playbook == 'mybook.yml'

    # Check if the vars attribute is properly set
    assert playbook_include.vars['var1'] == 'val1'



# Generated at 2022-06-11 10:38:35.541807
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    pb_include = PlaybookInclude()
    yaml_ds = dict(
        import_playbook = "test_playbook.yaml",
        vars = dict(
            var1 = "value1",
            var2 = "value2"
        )
    )
    pb_include.load_data(yaml_ds, ".", variable_manager, loader)
    assert pb_include.import_playbook == "test_playbook.yaml"
    assert pb_include.vars["var1"] == "value1"
    assert pb_include.v