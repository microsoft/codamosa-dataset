

# Generated at 2022-06-11 10:28:50.607097
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.template import Templar
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    loader = DataLoader()

    original_playbook = Playbook()
    original_playbook._entries = [
        dict(
            import_playbook='test_playbook.yml',
            vars=dict(
                tags='test_playbook_tags',
                var_1='value_1',
            )
        ),
        dict(
            import_playbook='test_playbook.yml',
            when='(1 == 2)',
            vars=dict(
                var_1='value_2',
                var_2='value_3',
            )
        ),
    ]
    original_playbook._loader = loader
    original_

# Generated at 2022-06-11 10:29:01.851529
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    if os.environ.get('ANSIBLE_LIBRARY'):
        return True

    # We're going to skip this test if the only site location we
    # could find was the FHS location.
    skip = True
    ds = dict(import_playbook='test1.yaml')
    for path in C.DEFAULT_MODULE_PATH:
        if os.path.isabs(path) and os.path.isdir(path) and os.access(path, os.R_OK):
            skip = False
            break
    if skip:
        return True

    # import here to avoid a dependency loop
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    DbInstance = PlaybookInclude()

# Generated at 2022-06-11 10:29:12.484662
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # first test: ds is a string, should raise an assertion error
    import pytest
    with pytest.raises(AnsibleAssertionError):
        PlaybookInclude().preprocess_data("ds")

    # second test: ds is a dict, but not a string
    with pytest.raises(AnsibleParserError):
        PlaybookInclude().preprocess_data({"import_playbook": True})

    # third test: ds is a dict, but the playbook path doesn't exist
    with pytest.raises(AnsibleParserError):
        PlaybookInclude().preprocess_data({"import_playbook": "/some/non-existing/file"})

    # fourth test: ds is a dict, playbook path exists, but has parameters
    #              as a list instead of a dict

# Generated at 2022-06-11 10:29:14.958536
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Note: this test is located in the playbooks tests directory
    # This will be executed when ansible-test is used on the playbooks target
    pass

# Generated at 2022-06-11 10:29:28.090661
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    module_utils = ['ansible.module_utils.basic']
    module_utils.append('ansible.module_utils.facts')
    module_utils.append('ansible.module_utils.splitter')
    module_utils.append('ansible.module_utils.urls')
    module_utils.append('ansible.module_utils.crypto')
    module_utils.append('ansible.module_utils.six')
    module_utils.append('ansible.module_utils.ec2')
    module_utils.append('ansible.module_utils.network')
    module_utils.append('ansible.module_utils.cloud')
    module_utils.append('ansible.module_utils.database')
    module_utils.append('ansible.module_utils.firewall')

# Generated at 2022-06-11 10:29:38.599387
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.module_utils._text import to_text
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.play import Play

    # I need a loader, but that may not actually be needed
    # so am not testing it

    # Test a basic load of a playbook, ignoring the loader and
    # variable_manager args
    test_playbook_include = PlaybookInclude()
    test_playbook_include.load_data({'import_playbook': '../../../../test/integration/targets/import_playbook/passthrough.yml'},
                                    basedir='../../../../test/integration/targets/import_host_vars/')
    assert isinstance(test_playbook_include._entries[0], Play)

# Generated at 2022-06-11 10:29:39.588323
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # TODO
    pass

# Generated at 2022-06-11 10:29:52.603582
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import json
    from ansible.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-11 10:30:03.895175
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    basedir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test_data/test_PlaybookInclude_load_data')
    playbook = os.path.join(basedir, 'main.yaml')
    subplaybook = os.path.join(basedir, 'subplaybook.yaml')

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = inventory.get_vars(host=None)

    # call load_data to get a Playbook object instead of a PlaybookInclude object

# Generated at 2022-06-11 10:30:12.953002
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import io
    ds = io.StringIO("""
- import_playbook: foo.yml
- import_playbook: bar.yml
- import_playbook: baz.yml
  vars:
    key: value
    key2: value2
    tags: always
    foo: bar
- import_playbook: foobar.yml
  vars:
    key: value
- import_playbook: foobaz.yml
  vars:
    key: value
  tags: foo
""")
    pbi = PlaybookInclude.load(ds, ".")
    expected = AnsibleMapping({
        'import_playbook': 'foo.yml',
    })

    assert(pbi._entries[0].dump() == expected.dump())


# Generated at 2022-06-11 10:30:20.745957
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    PlaybookInclude.load()

# Generated at 2022-06-11 10:30:31.187470
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.base import Base
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.playbook_include import PlaybookInclude

    # Load a PlaybookInclude from a dict and test that it is correctly loaded
    data = dict(
        import_playbook="../../../examples/ansible-guide-detailed-example.yml",
        tags=["foo","bar"],
        vars=dict(
            baz="foobar")
    )
    pbi = PlaybookInclude.load(data, None, None)
    assert isinstance(pbi, Playbook)
    assert len(pbi._entries) == 3
    assert pbi._entries[0].tags == ["foo", "bar"]
    assert p

# Generated at 2022-06-11 10:30:40.939196
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # Testing the preprocess_data method with valid import paths.
    class TestValidImportPath(object):
        def __init__(self, input_path, output_path):
            self.input_path = input_path
            self.output_path = output_path

    t1 = TestValidImportPath('file_name.yml', 'file_name.yml')
    t2 = TestValidImportPath('./file_name.yml', './file_name.yml')
    t3 = TestValidImportPath('/the/absolute/path/to/file_name.yml', '/the/absolute/path/to/file_name.yml')

# Generated at 2022-06-11 10:30:52.237898
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    # Unnecessary to test additional behavior of parent function
    # PlaybookInclude.preprocess_data(ds)

    # Case 1: test with some valid data
    data = AnsibleMapping(dict(import_playbook="test", vars={"test": "val"}, tags="a, b"))
    result = PlaybookInclude().preprocess_data(data)
    assert isinstance(result, dict)
    assert result == dict(import_playbook="test", vars={"test": "val"}, tags="a, b")

    # Case 2: test with non-dict data
    data = 1
    error = None
    try:
        PlaybookInclude().preprocess_data(data)
    except AnsibleAssertionError as e:
        error

# Generated at 2022-06-11 10:31:02.908689
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    import ansible.parsing.yaml.objects

    ##############
    # loading tasks

    # basic
    playbook = """
- import_playbook: import_test.yml
    """

    ds = ansible.parsing.yaml.objects.AnsibleMapping.load(playbook)

    pb = PlaybookInclude(loader=None)
    pb = pb.load_data(ds[0], "/tmp")

    # we expect pb to be a Playbook object now...
    assert isinstance(pb, Playbook)

# Generated at 2022-06-11 10:31:05.963293
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    obj=PlaybookInclude()
    obj._load_data({'import_playbook':'file_name'})
    assert(isinstance(obj,PlaybookInclude))


# Generated at 2022-06-11 10:31:18.634064
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping

    pb = PlaybookInclude()
    # Test single import_playbook
    pb_incl = AnsibleMapping({'import_playbook': 'import_playbook.yml'})
    pb.preprocess_data(pb_incl)
    assert pb.import_playbook == 'import_playbook.yml'
    assert pb.vars == {}

    # Test import_playbook with params
    pb_incl = AnsibleMapping({'import_playbook': 'import_playbook.yml vars=val1'})
    pb.preprocess_data(pb_incl)
    assert pb.import_playbook == 'import_playbook.yml'

# Generated at 2022-06-11 10:31:28.241408
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # try without playbook_paths (default collection)
    AnsibleCollectionConfig.playbook_paths = []
    AnsibleCollectionConfig.default_collection = 'my.collection.name'

    class TestPlay:
        def __init__(self):
            self.vars = dict(a=3)

        def __repr__(self):
            return "TestPlay"

    import_playbook = './some/playbook.yaml'
    include_obj = PlaybookInclude()
    include_obj.import_playbook = import_playbook
    pb = include_obj.load(include_obj.import_playbook, '/base/dir', None)

    assert isinstance(pb, Playbook)
    assert len(pb._entries) == 1
    assert isinstance(pb._entries[0], Play)
   

# Generated at 2022-06-11 10:31:41.150119
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    playbook_include = PlaybookInclude()
    class MockClass():
        pass
    mock_variable_manager = MockClass()
    mock_variable_manager.get_vars = lambda : dict()
    mock_loader = MockClass()
    mock_loader.get_basedir = lambda: 'test_PlaybookInclude_load_data_basedir'
    mock_loader.path_dwim = lambda: 'test_PlaybookInclude_load_data_basedir'
    mock_loader.path_dwim_relative = lambda: 'test_PlaybookInclude_load_data_basedir'
    mock_loader.list_directory = lambda: ['test_PlaybookInclude_load_data_playbook_name']


# Generated at 2022-06-11 10:31:50.236065
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import_playbook = PlaybookInclude()
    data = {'import_playbook': 'playbook.yaml'}
    data_2 = {'import_playbook': 'playbook.yaml', 'vars': {'var_2': 'val_2'}}
    data_3 = {'import_playbook': 'playbook.yaml var_3=val_3'}
    data_4 = {'import_playbook': 'playbook.yaml', 'vars': {'var_2': 'val_2'}, 'tags': 'tag1,tag2'}
    data_5 = {'import_playbook': 'playbook.yaml', 'vars': {'var_2': 'val_2'}, 'tags': 'tag1,tag2'}


# Generated at 2022-06-11 10:32:11.891808
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    import ansible.parsing.dataloader
    import os

    basedir = os.path.dirname(__file__)
    variable_manager = VariableManager()

    ds = dict(
        import_playbook=dict(
            filename=dict(
                name='test_playbook.yml'
            )
        ),
        vars=dict(
            archivedir="/var/archives"
        ),
        tags=[
            'foo'
        ]
    )

# Generated at 2022-06-11 10:32:20.203860
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    v_mgr = MockVariableManager("/home/test")
    loader = MockLoader("/home/test")
    ds = dict(
        import_playbook='test.yml',
        vars={
            'var1': 'val1',
            'var2': 'val2'
        },
        tags=['test']
    )
    obj = PlaybookInclude.load(data=ds, basedir="/home/test", variable_manager=v_mgr, loader=loader)

    assert isinstance(obj, Playbook)
    assert len(obj._entries) == 1
    assert isinstance(obj._entries[0], Play)


# Generated at 2022-06-11 10:32:30.454129
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    ds = dict(import_playbook='main.yml', vars=dict(a=3))
    print(PlaybookInclude.load(ds, basedir='.', variable_manager=None, loader=None))
    # expected output:
    # Playbook(...)

    ds = dict(import_playbook='main.yml', tags='tag1,tag2', vars=dict(a=3))
    print(PlaybookInclude.load(ds, basedir='.', variable_manager=None, loader=None))
    # expected output:
    # Playbook(...)

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 10:32:41.077760
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task_include import TaskInclude

    # Test playbook load
    yaml_data = '''
    - include: playbook.yml
    '''
    data = TaskInclude.load(yaml_data, '', None, None)
    data = data[0]
    result = PlaybookInclude.load_data(data, '', None, None)
    assert isinstance(result, Playbook)
    assert len(result._entries) == 1
    assert isinstance(result._entries[0], Play)
    assert result._entries[0].name == "play.yml"

    # Test playbook load with conditionals

# Generated at 2022-06-11 10:32:49.324973
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.role import Role
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    loader = AnsibleLoader(None, variable_manager=variable_manager)
    templar = Templar(loader=loader)

    assert PlaybookInclude.load(
        data=dict(import_playbook='test_import.yml'),
        basedir='/etc/ansible',
        variable_manager=variable_manager,
        loader=loader).entries[0].entries[0].name == 'test role'



# Generated at 2022-06-11 10:32:51.779155
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''
    Unit test for method load_data of class PlaybookInclude
    '''
    pass # TODO

# Generated at 2022-06-11 10:33:03.894904
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    pb = PlaybookInclude.load(
        dict(file='foo'),
        '/tmp',
        variable_manager={'a':'b'}
    )
    assert isinstance(pb, Playbook)
    assert pb._entries[0].path == '/tmp/foo'
    assert pb._entries[0].vars == {'a':'b'}
    assert isinstance(pb._entries[0], Play)

    # check for correct handling of conditional include
    pb = PlaybookInclude.load(
        dict(file='foo', when='a==b'),
        '/tmp',
        variable_manager={'a':'b'}
    )
    assert isinstance(pb, Playbook)
   

# Generated at 2022-06-11 10:33:11.393651
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    # import here to avoid a dependency loop
    from ansible.playbook import Playbook

    # Create a fake datastructure and a fake context
    ds = {}
    ds['import_playbook'] = 'play.yml'
    context = PlayContext()
    context.basedir = './'
    context.defaults = {}
    context._attributes = ds
    context.variable_manager = None
    context._loader = None

    # Create a fake playbook
    pb = PlaybookInclude()
    pb._load_data = PlaybookIn

# Generated at 2022-06-11 10:33:22.705837
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play

    class FakePlaybookEntry(Play):
        _attributes = {
            'vars': FieldAttribute(isa='dict', default=dict),
        }
        vars = dict()
        
        def __init__(self, data, variable_manager, loader):
            super(FakePlaybookEntry, self).__init__()
            self._load_data(data, variable_manager, loader)


    class FakePlaybook(object):
        _entries = list()


# Generated at 2022-06-11 10:33:33.156170
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.utils.collection_loader import AnsibleCollectionRef

    # if the import is inside a collection
    collection = 'namespace.collection'
    # and the playbook import is inside the same collection
    playbook_inside = 'playbook.yaml'
    # or the playbook import is imported from another collection
    playbook_outside_collection = AnsibleCollectionRef('collection.another')
    playbook_outside_collection_name = playbook_outside_collection.get_collection_name()
    playbook_outside = playbook_outside_collection.file_name

    # the answers should be:
    playbook_inside_result = fqcn(collection, playbook_inside)
    playbook_outside_result = fqcn(playbook_outside_collection_name, playbook_outside)

    # if the import is NOT inside a collection
    no_collection = None
    # and

# Generated at 2022-06-11 10:34:02.247289
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    # create the ds variable
    ds = AnsibleMapping()
    ds['import_playbook'] = 'file_name.yml'

    # create a mock variable manager and loader
    vm = MockVariableManager()
    loader = MockDataLoader()
    ds.ansible_pos = (1, 1)

    # create a PlaybookInclude object and call preprocess_data
    pbi = PlaybookInclude()
    pb = pbi.load(ds, '.', vm, loader)

    # create expected result
    expected_result = Playbook(loader=loader)
    expected_result.add_entry(Play().load({'name': 'file_name.yml'}, '.', vm))

    # assert

# Generated at 2022-06-11 10:34:13.740110
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    import yaml

    yaml_obj = yaml.safe_load("""
    - import_playbook: test.yml create=yes name=test
    - import_playbook: test.yml
      vars:
        create: yes
        name: test
        tags: tag1,tag2
        test: value
    """)

    expected_real_ds = [
        AnsibleMapping(dict(import_playbook='test.yml', vars=dict(create='yes', name='test'))),
        AnsibleMapping(dict(import_playbook='test.yml', vars=dict(create='yes', name='test', test='value'),
                            tags=['tag1','tag2']))
    ]

    playbook_include = Play

# Generated at 2022-06-11 10:34:25.020403
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # import here to avoid a dependency loop
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    playbook_include = PlaybookInclude()
    playbook_include.vars = dict(ip="192.168.0.1")
    playbook_include.import_playbook = './include.yml'

    resource = _get_collection_playbook_path(playbook_include.import_playbook)
    if resource is not None:
        playbook = resource
    else:
        playbook = playbook_include.import_playbook

    playbook = Playbook()
    playbook._load_playbook_data(file_name=playbook, variable_manager={}, vars=dict(ip="192.168.2.2"))


# Generated at 2022-06-11 10:34:26.004320
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-11 10:34:33.210694
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play
    data = dict()
    data['hosts'] = 'host1,host2'
    data['import_playbook'] = './test_import.yml,  vars="a=1 b=2"'
    new_data = PlaybookInclude.load_data(data, basedir=None, variable_manager=None, loader=None)
    #print("new_data: {}".format(new_data))
    assert len(new_data._entries) == 1
    assert isinstance(new_data._entries[0], Play)
    assert new_data._entries[0].tasks[0]["name"] == "task1"
    assert new_data._entries[0].tasks[0]["hosts"] == "host1,host2"

# Generated at 2022-06-11 10:34:45.527346
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # This data has the same format as the YAML structure used in Ansible playbooks
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.utils.collection_loader._collection_finder import _get_collection_name_from_path
    from ansible.template import Templar

    variable_manager = None
    loader = None

    # Positive tests
    ds = AnsibleMapping()
    ds['import_playbook'] = 'tests/string'
    input_ds = ds.copy()
    result = PlaybookInclude(loader=loader).preprocess_data(input_ds)
    # The result has the same format as the YAML structure used in Ansible playbooks
    expected_result = AnsibleMapping()
    expected_result['import_playbook'] = 'tests/string'

# Generated at 2022-06-11 10:34:55.277359
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    test_data = {
        'import_playbook': 'parent.yml',
        'hosts': 'local',
        'vars': {
            'foo': 'bar',
            'xyz': 'abc',
        }
    }

    result = PlaybookInclude.load(test_data, 'basedir', variable_manager=None, loader=None).data
    assert result['_import_playbook'] == 'parent.yml'
    assert result['vars'] == test_data['vars']
    assert result['hosts'] == 'local'
    assert result['tags'] == []
    assert result['when'] == []

    test_data['import_playbook'] = 'subdir/subdir.yml'

# Generated at 2022-06-11 10:34:58.663893
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    basedir = "/home/ansible/playbooks"
    playbook_include = PlaybookInclude()
    data = {
        'import_playbook': 'test.yml',
    }
    playbook_include.load_data(data, basedir)

# Generated at 2022-06-11 10:35:09.733991
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Play
    from ansible.playbook.play import Playbook

    role_path = os.path.join(C.DEFAULT_ROLES_PATH, 'role_1', 'tasks')
    role_path_2 = os.path.join(C.DEFAULT_ROLES_PATH, 'role_1', 'handlers')

    playbook_include = PlaybookInclude()

    # test with basic data structure
    data = {"import_playbook": "../tests/test_playbooks/import_playbook.yml", "tags": "foo,bar"}
    new_obj = playbook_include.load_data(data, variable_manager=None, loader=None)
    assert isinstance(new_obj, Playbook)
    assert isinstance(new_obj._entries[0], Play)


# Generated at 2022-06-11 10:35:20.720581
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    import textwrap

    module_name = 'os'
    module_path = os.path.dirname(os.path.dirname(__file__))
    test_playbook_path = os.path.join(module_path, 'playbook-include-test-playbook.yml')
    test_playbook_path2 = os.path.join(module_path, 'playbook-include-test-playbook2.yml')


# Generated at 2022-06-11 10:35:52.386115
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.dataloader import DataLoader

    ds_ok = '''
    - import_playbook: importthis.yml
      tags:
        - foo
        - bar
      vars:
        vname1: value1
        vname2: value2
    '''
    # Import parameter not a string
    ds_not_a_string = '''
    - import_playbook:
      - foo
      - bar
    '''
    # Specify filename to import as a parameter to import_playbook
    ds_specify_filename_to_import = '''
    - import_playbook:
      - importthis.yml
      - tags:
        - foo
        - bar
      vars:
        vname1: value1
    '''
    # Import parameter

# Generated at 2022-06-11 10:36:04.139820
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_object = PlaybookInclude()
    # All parameters
    test_data = {"import_playbook": "../tests/playbooks/include_playbook.yml", "vars": {"var1": "yes", "var2": "no", "var3": "yes"}}
    new_ds = playbook_include_object.preprocess_data(test_data)
    assert new_ds['import_playbook'] == "../tests/playbooks/include_playbook.yml"
    assert new_ds['vars'] == {"var1": "yes", "var2": "no", "var3": "yes"}
    # No vars
    test_data = {"import_playbook": "../tests/playbooks/include_playbook.yml"}
    new_ds = playbook_include_object.preprocess_

# Generated at 2022-06-11 10:36:12.336660
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.playbook.play import Play

    data = dict(
        import_playbook="my_file.yml",
        vars=dict(
            foo="bar"
        ),
        tags=["foo", "bar"]
    )

    pbi = PlaybookInclude(loader=None)

    try:
        pbi.load_data(data, basedir="/tmp")
    except AnsibleParserError:
        pass

    del data["import_playbook"]
    try:
        pbi.load_data(data, basedir="/tmp")
    except AnsibleParserError:
        pass

    data = dict(
        import_playbook="my_file.yml",
        vars=dict(
            foo="bar"
        ),
        tags=["foo", "bar"]
    )


# Generated at 2022-06-11 10:36:21.147267
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    ds = {'import_playbook': {'tasks/foo.yml': {'var1': 'value1'} }}
    pbi = PlaybookInclude()
    result = pbi.load_data(ds, '/tmp')
    assert (result.entries[0]._included_vars == {'var1': 'value1'})
    assert (result.entries[0].path == 'tasks/foo.yml')
    assert (result.entries[0]._parent_path == '/tmp')

# Generated at 2022-06-11 10:36:28.752789
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    data='test.yml'
    basedir='/rpath/to'
    try:
        result=PlaybookInclude.load(data, basedir)
    except Exception as err:
        print('test_PlaybookInclude_load_data failed with error: %s' % err)
    else:
        if not isinstance(result, Playbook):
            print('test_PlaybookInclude_load_data failed, incorrect type returned: %s' % type(result))


# Generated at 2022-06-11 10:36:30.126680
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # TODO write some tests
    return



# Generated at 2022-06-11 10:36:39.576205
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import json
    import os
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_text
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars import VariableManager
    from ansible.inventory.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-11 10:36:49.403599
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # pylint: disable=missing-docstring
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Check that load_data works on empty ds
    ds = AnsibleMapping()
    pbi = PlaybookInclude()
    actual_ds = pbi.load_data(ds, './')
    expected_ds = AnsibleMapping()
    assert_ds_equal(actual_ds, expected_ds)

    # Check that load_data works on a simple ds
    ds = AnsibleMapping()
    ds['import_playbook'] = 'example.yml'
    ds['vars'] = AnsibleMapping()

# Generated at 2022-06-11 10:37:00.183882
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    text = """
    - import_playbook: test_playbook.yml
    """
    loader = AnsibleLoader(None, dict(), variable_manager=VariableManager())
    result = loader.load(text)

    assert isinstance(result, AnsibleSequence)
    play_include = PlaybookInclude.load(data=result[0], basedir="test_playbook_dir", variable_manager=VariableManager(), loader=loader)
    assert isinstance(play_include, PlaybookInclude)
    assert play_include.import_playbook == "test_playbook.yml"

# Generated at 2022-06-11 10:37:09.886293
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import os
    from ansible.playbook import PlaybookInclude

    # test with valid input data as yaml string
    data = '''
- import_playbook: test.yaml
  vars:
    test_var: test_value
    test_var2: test_value2
'''
    data_as_dict = {'import_playbook': 'test.yaml', 'vars': {'test_var': 'test_value', 'test_var2': 'test_value2'}}
    data = to_bytes(data, errors='surrogate_or_strict')

# Generated at 2022-06-11 10:37:31.043540
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Test imports a playbook and forwards variables and tags
    pass

# Generated at 2022-06-11 10:37:41.391032
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import ansible.parsing.yaml.objects

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.template import Templar

    dataloader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=dataloader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    ds = ansible.parsing.yaml.objects.AnsibleMapping()

# Generated at 2022-06-11 10:37:55.111464
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Test PlaybookInclude with valid paramters
    test_ds1 = dict(import_playbook='test.yml')
    test_ds2 = dict(import_playbook='test.yml', tags=['tag1', 'tag2'])
    test_ds3 = dict(import_playbook='test.yml', vars={'test': 'var'})
    test_ds4 = dict(import_playbook='test.yml', test_param='test_value')
    test_ds5 = dict(import_playbook='test.yml', tags=['tag1', 'tag2'], vars={'test': 'var'}, test_param='test_value')

    import_playbook = PlaybookInclude()
    import_playbook.preprocess_data(test_ds1)
    import_playbook

# Generated at 2022-06-11 10:37:56.246566
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # test successful import playbook
    pass

# Generated at 2022-06-11 10:37:56.861027
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:38:04.802538
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.template import Templar

    variable_manager = MockVariableManager()
    loader = MockDataLoader()
    variable_manager.set_available_variables(hostvars={},
                                             groupvars={})
    variable_manager._extra_vars = {'extra_var_1': 'value_1',
                                    'extra_var_2': 'value_2'}


# Generated at 2022-06-11 10:38:15.798002
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    # import here to avoid a dependency loop
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    pb = PlaybookInclude.load({},'')
    sample_data = '''
    - hosts: all
      name: test
      gather_facts: no

    - hosts: all
      name: test2
      gather_facts: yes
    '''
    pb._load_playbook_data(file_name = "test.yml", variable_manager = None, vars = {})
    assert type(pb) is Playbook
    assert type(pb._entries[0]) is Play
    assert pb._entries[0].name == 'test'
    assert pb._ent

# Generated at 2022-06-11 10:38:27.391318
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # Create test imported_playbook_name
    import_playbook_name = "test_playbook_include/import_playbook/test_import_playbook_1.yml"

    # Create test ds with correct format
    ds = {"import_playbook": import_playbook_name}

    # Create PlaybookInclude object
    playbook_include = PlaybookInclude()

    # Call preprocess_data
    ret = playbook_include.preprocess_data(ds)

    # Check if preprocess_data return value is a dict
    assert isinstance(ret, dict) is True

    # Check if return value contains a key "import_playbook"
    assert "import_playbook" in ret.keys()

    # Check if return value has a value for "import_playbook"

# Generated at 2022-06-11 10:38:31.341969
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader

    basedir = 'some_path/some_sub_path'
    loader = DataLoader()
    playbook = PlaybookInclude()

    # Test data for testing load_data method
    data = dict(import_playbook='some_playbook.yml')

    # Expected data after loading the test data
    expected_entries = [Play().load(
        data=dict(name='some_playbook.yml'),
        basedir=basedir,
        variable_manager=None,
        loader=loader)]
    expected_playbook = Playbook()
    expected_playbook._entries = expected_entries

    # Test load_data and assert the result
   