

# Generated at 2022-06-11 10:28:52.273711
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # lets create a PlaybookInclude object and call the method
    pbi = PlaybookInclude()
    # now lets create a datastructure to process with the include data
    ds = AnsibleMapping()
    ds.update({u'a': u'b'})
    ds.update({u'c': u'd'})
    ds.update({u'import_playbook': u'sample.yml'})
    # the method preprocess_data returns the new datastructure
    new_ds = pbi.preprocess_data(ds)
    # the dictionary new_ds should look like this:
    # {u'import_playbook': u'sample.yml', u'vars': {u'a': u'b', u'c': u'd'}}

# Generated at 2022-06-11 10:29:02.794905
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include = PlaybookInclude()
    playbook_include.data = PlaybookInclude.load(
        data=dict(import_playbook='/path/to/playbook.yml'),
        basedir=os.getcwd()
    )

    test_dict = {'pre_tasks': [], 'roles': [], 'tasks': [
        {'debug': {'var': 'hostname'}}], 'hosts': 'all', 'post_tasks': []}

    assert isinstance(playbook_include.data._entries[0], Play)
    assert playbook_include.data._entries[0].serialize() == test_dict



# Generated at 2022-06-11 10:29:13.190685
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook import Playbook
    from ansible.vars.manager import VariableManager

    vm = VariableManager()
    ds = dict(import_playbook='my-playbook.yml')
    my_playbook_yml = Playbook().load(ds, None, vm)
    assert(len(my_playbook_yml.get_plays()) == 1)
    ds = dict(import_playbook='my-playbook.yml', connection=dict(user='kohsuke'))
    my_playbook_yml = Playbook().load(ds, None, vm)

# Generated at 2022-06-11 10:29:25.843361
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    ds1 = AnsibleMapping({'vars': {'var': 'value'}, 'import_playbook': 'somefile'})
    ds2 = AnsibleMapping({'vars': {'var': 'value'}, 'import_playbook': 'somefile tags=t1,t2'})
    ds3 = AnsibleMapping({'vars': {'var': 'value'}, 'import_playbook': 'somefile var=value tags=t1,t2'})
    ds4 = AnsibleMapping({'import_playbook': 'somefile'})
    ds5 = AnsibleMapping({'import_playbook': 'somefile var=value'})
    ds6 = AnsibleMapping({'import_playbook': 'somefile tags=t1,t2'})
    ds7

# Generated at 2022-06-11 10:29:37.382444
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # we need the loader to get the player template
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    loader = AnsibleLoader(None, variable_manager=None)
    templar = Templar(loader=loader)

    # create a sample playbook
    playbook_content = """
- hosts: localhost
  tasks:
      - include_playbook: test.yml
      - include_playbook: test2.yml vars: {'var1': 1}
      - include_playbook: test3.yml var1: 1

- hosts: localhost
  tasks:
      - include_playbook: test4.yml vars: {'var1': 1, 'var2': 2}
"""

# Generated at 2022-06-11 10:29:48.911425
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    #import json

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    ds = {
        'import_playbook': '/path/to/playbook.yml',
        'tags': 'a,b,c',
        'vars': {
            'user': 'root'
        }
    }

    # expected_ds = json.dumps(ds, sort_keys=True, indent=4, separators=(',', ': '))

    pi = PlaybookInclude()
    pi.preprocess_data(ds)

    # loaded_ds = json.dumps(pi.ds, sort_keys=True, indent=4, separators=(',', ': '))

    assert pi.import_playbook == '/path/to/playbook.yml'
    assert pi

# Generated at 2022-06-11 10:30:01.142184
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import ansible
    ansible.__file__ = '/usr/lib/python2.7/site-packages/ansible/__init__.py'
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.include import PlaybookInclude


    playbooks_path = '/usr/share/ansible/'
    basedir = playbooks_path + 'test_include'
    loader = '??? (type)'
    variable_manager = '??? (type)'

    ds = dict(
        import_playbook=dict(
            file=playbooks_path + 'test_include/test_include_playbook.yml',
            vars=dict(X=1),
        ),
    )

    playbooks_path = '/usr/share/ansible/'

# Generated at 2022-06-11 10:30:09.242687
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext

    test_pb_import = """
        - import_playbook: 'tests/test_import.yml'
        """
    with open('./tests/test_import.yml', 'r') as p:
        playbook_data = p.read()

    pb = Playbook.load(test_pb_import, variable_manager=None, loader=None)
    assert len(pb._entries) == 1
    assert isinstance(pb._entries[0], PlaybookInclude)
    assert pb._entries[0].import_playbook == "tests/test_import.yml"

    # Test for pre-corrected import_playbook string

# Generated at 2022-06-11 10:30:19.675754
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play

    # The method load_data is highly tested in the integration test of the same name
    # test here specific error conditions unique to this method

    # load_data requires a valid data structure with import_playbook attribute
    pbi = PlaybookInclude()

    # invalid content type
    data = 'x'
    basedir = 'xyz'
    variable_manager = {}
    loader = {}
    try:
        pbi.load_data(data, basedir, variable_manager, loader)
        raise AssertionError('Expected AnsibleAssertionError')
    except AnsibleAssertionError:
        pass

    # missing mandatory attribute import_playbook
    data = {}
    basedir = 'xyz'
    variable_manager = {}
    loader = {}

# Generated at 2022-06-11 10:30:29.964410
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list=['localhost'])
    play_context = PlayContext()

    filename = 'include.yml'
    playbook = Playbook.load(filename, variable_manager=VariableManager(), loader=loader)
    play_context.variable_manager.extra_vars = playbook.vars
    print(play_context.variable_manager)
    # play_context.variable_manager.extra_vars = playbook.vars

    return playbook

# Generated at 2022-06-11 10:30:47.906083
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook

    # register the correct class for Playbook
    Playbook.load = Playbook.load_data

    # test simple load
    ds = dict(import_playbook='imports/play.yml', tags=['tag1', 'tag2'], vars=dict(var1=1, var2=2, var3=3))
    pb = PlaybookInclude.load(ds, basedir='test/test_playbook')
    assert isinstance(pb, Playbook)
    assert len(pb.get_plays()) == 1
    play = pb.get_plays()[0]
    assert play.tags == ['tag1', 'tag2']
    assert play.vars == dict(var1=1, var2=2, var3=3)
    assert play._included

# Generated at 2022-06-11 10:30:59.940037
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.parsing.vault import VaultLib
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # the class PlaybookInclude is itself tested

    # create the test fixture
    playbook = PlaybookInclude.load(
        data={"import_playbook": "./test/test_playbook.yml"},
        basedir="",
        variable_manager=VariableManager(),
        loader=Templar()
    )

    # assert that the playbook has 2 entries
    assert len(playbook._entries) == 2

    # assert that the first entry is a Task
    assert isinstance(playbook._entries[0], Task)

    # assert the first task has a state of "present"

# Generated at 2022-06-11 10:31:09.820702
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.playbook.play import Play

    pi = PlaybookInclude()

    # import playbook without any vars or tags
    ds = dict(
        import_playbook="../../../../path/to/playbook"
    )

    pb = pi.load_data(ds, "/tmp", None)
    assert pb is not None
    assert len(pb._entries) == 0

    # import playbook with vars and tags included in a dict
    ds = dict(
        import_playbook="../../../../path/to/playbook",
        vars=dict(
            key1="value1",
            key2="value2"
        ),
        tags=["tag1", "tag2", "tag3"]
    )

    pb = pi.load_data(ds, "/tmp", None)

# Generated at 2022-06-11 10:31:11.143145
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-11 10:31:23.510155
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    """
    Test function for PlaybookInclude.load_data
    """
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.template import Templar
    class Playbook:
        """
        Playbook class
        """
        def __init__(self):
            self._entries = []

        def _load_playbook_data(self, file_name=None, variable_manager=None, vars=None):
            """
            Load playlist data
            """
            if variable_manager:
                variable_manager.set_available_variables(vars)

            self._load_playbook_from_file(file_name, variable_manager=variable_manager)


# Generated at 2022-06-11 10:31:24.296874
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # TODO: Improve this unit test
    pass


# Generated at 2022-06-11 10:31:28.623826
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    pb = Playbook()
    pi = PlaybookInclude("included.yml")
    pb._entries = Playbook.load(pi.load_data("included.yml",None, None), None, None, None)
    assert pb._entries[0].hosts == "host1"

# Generated at 2022-06-11 10:31:29.325430
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    assert True

# Generated at 2022-06-11 10:31:42.250420
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    """
    Unit test for method load_data of class PlaybookInclude
    """
    sample_playbook_content = """
- hosts: webservers
  vars:
    var_in_playbook: someval
  tasks:
    - name: show playbook var
      debug:
        msg: 'var_in_playbook is {{ var_in_playbook }}'
"""

    # Define import_playbook to include playbook which has tasks
    sample_import_playbook_content = """
---
- import_playbook: sample_playbook.yml
    tags:
        - include
    vars:
      var_in_import_playbook: val_in_import_playbook
"""

    from ansible.parsing.yaml.objects import AnsibleMapping
    import filecmp
    import sys
   

# Generated at 2022-06-11 10:31:50.884033
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    #Remove after Ansible 2.9 release candidates have shipped
    display.WARNINGS = []
    yaml_ds1 = '''
    - import_playbook: ../../sample3.yml
      vars:
          myvar: myvalue
      tags:
          - sample3_tag
    '''
    yaml_ds2 ="""
      - import_playbook:
          - ../../sample1.yml
          - ../../sample2.yml
    """
    yaml_ds3 ="""
    - import_playbook: ../../sample1.yml
      vars:
          var1: val1
          var2: val2
    """

# Generated at 2022-06-11 10:31:56.355033
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-11 10:32:08.227387
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task_include import TaskInclude

    loader = DataLoader()
    variable_manager = VariableManager()
    mock_ds = "test_PlaybookInclude_load_data.yml"
    mock_basedir = "/tmp/"
    pb_inc = PlaybookInclude()
    pb_inc.vars = dict()
    pb_inc.tags = list()
    pb_inc.when = list()
    pb_inc.import_playbook = "mock_pb.yml"
    p = Play()
    p.vars = dict

# Generated at 2022-06-11 10:32:11.635816
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''
    Unit test for the load_data method of the PlaybookInclude class
    '''
    import ansible.parsing.yaml.objects
    # TODO: test me


# Generated at 2022-06-11 10:32:12.642188
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass



# Generated at 2022-06-11 10:32:20.674296
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.module_utils.six import StringIO

    # Load test case 1

# Generated at 2022-06-11 10:32:33.296207
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import collections

    from ansible.module_utils._text import to_bytes
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.template import Templar

    test_data = collections.namedtuple('test_data', 'test_data exp_res')

# Generated at 2022-06-11 10:32:42.855912
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    class MyDs(object):
        def __init__(self, a):
            self.a = a

    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.utils.display import Display
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    # vars
    all_vars = dict(
        foo='bar',
        baz='qux'
    )

    # create the variable manager and set some variables
    variable_manager = VariableManager()
    variable_manager.extra_vars = all_vars

    # create the display, which will be needed for the templating
    display = Display()



# Generated at 2022-06-11 10:32:54.276465
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    import_playbook_path = 'import_playbook_path'
    vars = {'var1': 'var1'}
    tags = ['tag1', 'tag2']
    when = ['when1', 'when2']
    basedir = 'basedir'
    variable_manager = None
    loader = None

    # test with no when
    pb_include = PlaybookInclude()
    pb_include.import_playbook = import_playbook_path
    pb_include.vars = vars
    pb_include.tags = tags

    pb = pb_include.load_data(pb_include, basedir, variable_manager, loader)

    assert isinstance(pb, Playbook)

# Generated at 2022-06-11 10:33:02.755110
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    """Unit test for method test_load_data of class PlaybookInclude"""

    data = {'tasks': [{'name': 'task1'}], 'hosts': ['host1', 'host2'], 'vars': {'foo': 1, 'bar': 2}}
    basedir = 'test/basedir'
    variable_manager = 'test/variable_manager'
    loader = 'test/loader'

    result = PlaybookInclude.load(data, basedir, variable_manager, loader)

    assert result


# Generated at 2022-06-11 10:33:03.193214
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:33:22.523846
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os
    import sys
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager
    from ansible.utils import context_objects as co
    script_path = os.path.dirname(os.path.realpath(__file__))
    test_data_path = os.path.join(script_path,'../../test_data/')
    with co.set_adhoc_context():
        variable_manager = VariableManager()
        loader = DataLoader()

        ds = loader.load_from_file(test_data_path + 'playbook_include_defaults.yml')
        pi = PlaybookInclude()

# Generated at 2022-06-11 10:33:29.263744
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    loader = 'Loader'
    variable_manager = 'VariableManager'
    new_obj = PlaybookInclude()
    playbook_entries = [{'hosts': 'all', 'gather_facts': 'no', 'tasks': [{'name': 'test'}]}]
    basedir = './'
    new_obj.load_data(playbook_entries, basedir, variable_manager, loader)
    assert isinstance(new_obj, Playbook)

# Generated at 2022-06-11 10:33:38.702536
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook


    pb = PlaybookInclude.load(data={"import_playbook": "import_me.yml", "vars": {"foo": "bar"}}, basedir=".")
    assert isinstance(pb, Playbook)

    # verify loaded data
    assert pb.entries[0].included_path == os.path.abspath(".")
    assert pb.entries[0].vars == {'foo': 'bar'}

    pb = PlaybookInclude.load(data={"import_playbook": "import_me.yml", "tags": ["one", "two"]}, basedir=".")
    assert isinstance(pb, Playbook)

    # verify imported data

# Generated at 2022-06-11 10:33:51.315282
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    ds = dict(import_playbook='tests/yaml/playbook/import.yaml', tags='TAGS_IMPORT_PLAYBOOK_1')
    ds['vars'] = dict(VAR='VAR_VALUE', VAR2='VAR2_VALUE')

    basedir = os.path.dirname(os.path.abspath(__file__))

    pb = PlaybookInclude.load(ds, basedir)
    assert isinstance(pb, Playbook)
    assert len(pb._entries) == 2
    first = pb._entries[0]
    assert isinstance(first, Play)
    second = pb._entries[1]
    assert isinstance(second, Play)

   

# Generated at 2022-06-11 10:33:57.340792
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include = PlaybookInclude()

    assert playbook_include.load_data('/home/ansible/playbooks/web.yml', '/home/ansible/playbooks') is not None
    assert playbook_include.load_data('/home/ansible/playbooks/web.yml', '/home/ansible/playbooks', variable_manager=None, loader=None) is not None


# Generated at 2022-06-11 10:34:07.464234
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    filename = 'tests/fixtures/playbooks/PlaybookInclude.yml'

    # No simplification
    loader, inventory, variable_manager = _init_loader(filename)
    ds = loader.load_from_file(filename)

    # Run preprocess_data
    pb = PlaybookInclude()
    ds = pb.preprocess_data(ds)

    # Run load_data
    pb = PlaybookInclude()
    pb = pb.load_data(ds, variable_manager=variable_manager, loader=loader)

    # Check results
    assert pb._entries[0].hosts == ['hosta']
    assert pb._entries[0].vars == dict(var1='a', var3='c')
    assert pb._entries[0].get_vars()

# Generated at 2022-06-11 10:34:18.938597
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    """
    this method is used to test the load_data method of class PlaybookInclude
    """
    # import here to avoid a dependency loop
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    # create a playbook object
    playbook = Playbook()
    # create a PlaybookInclude object
    playbook_include = PlaybookInclude()
    playbook.basedir = './testdata/'

# Generated at 2022-06-11 10:34:29.133722
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.plugins.loader import task_loader

    playbook = Playbook()
    playbook.loader = task_loader
    playbook._entries = []

    playbook.load()

    block = Block()

    role = Role()
    role.name = 'role_name'
    role.block = block

    task = Task()
    task.action = 'some_action'
    task.block = block
    task.task_loader = task_loader

    play = Play()
    play.hosts = 'all'
    play.roles = [role]

# Generated at 2022-06-11 10:34:39.520317
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.base import Base
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    from ansible.module_utils.six import PY3

    vm = VariableManager()
    vm.extra_vars = {'foo': 'bar'}
    loader = DictDataLoader({})
    loader._basedir = os.getcwd()


# Generated at 2022-06-11 10:34:51.486333
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    import yaml
    from ansible.playbook.play import Play
    from ansible.playbook.playbook_include import PlaybookInclude

    yaml_data="""
---
- hosts: localhost
  tasks:
  - debug:
      msg: hello
"""
    yaml_data1="""
---
- include: test.yml
  vars:
    foo: bar
"""
    with open('test.yml', 'w') as f:
        f.write(yaml_data)

    ret = yaml.load(yaml_data1)
    assert isinstance(ret, list), type(ret)
    assert len(ret) == 1, len(ret)
    assert isinstance(ret[0], dict), type(ret[0])

# Generated at 2022-06-11 10:35:16.688075
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    temp = Templar(loader=loader)
    inc = PlaybookInclude()
    pb = inc.load_data({'import_playbook': '../test_playbook.yml'}, '/path/to', templar=temp)
    assert isinstance(pb, Play)
    assert pb.name == 'test_playbook'
    assert pb.hosts == ['test_host']


# Generated at 2022-06-11 10:35:24.397967
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import tempfile

    # Create temp directories
    temp_module_path = tempfile.mkdtemp()
    temp_role_path = tempfile.mkdtemp()
    temp_playbook_path = tempfile.mkdtemp()

    # Create temp files
    temp_module = tempfile.NamedTemporaryFile(dir=temp_module_path, mode='w', delete=False)
    temp_playbook_1 = tempfile.NamedTemporaryFile(dir=temp_playbook_path, mode='w', delete=False)
    temp_playbook_2 = tempfile.NamedTemporaryFile(dir=temp_playbook_path, mode='w', delete=False)
    temp_playbook_3 = tempfile.NamedTemporaryFile(dir=temp_playbook_path, mode='w', delete=False)



# Generated at 2022-06-11 10:35:32.962059
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext

    ds = { "import_playbook": "foo.yml" }
    basedir = "/tmp/test"
    variable_manager = VariableManager()
    context = PlayContext()
    variable_manager.set_play_context(context)
    playbook_include = PlaybookInclude()
    result = playbook_include.load_data(ds, basedir, variable_manager)

    assert result.__class__.__name__ == "Playbook"

# Generated at 2022-06-11 10:35:36.909413
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''
    This is a unit test for the method load_data 
    of the class PlaybookInclude.
    '''
    import pudb; pudb.set_trace()
    pass

# Generated at 2022-06-11 10:35:45.991442
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play

    loader = DictDataLoader({
        'test_playbook.yml': '''
- hosts: all
  include_playbook:
    import_playbook: test_include.yml
    var1: value1
    var2: value2
    tags: tag1, tag2
''',
        'test_include.yml': '''
- hosts: all
  tasks:
    - debug:
        msg: test
'''
    })

    basedir = os.getcwd()

# Generated at 2022-06-11 10:35:58.536208
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    #
    # Test for import_playbook parameters
    #
    data = '''
- import_playbook: playbook.yml x=1 y=2
'''

    parent = PlaybookInclude().load(data=data, loader=None)

    assert parent.import_playbook == 'playbook.yml'
    assert parent.vars['x'] == '1'
    assert parent.vars['y'] == '2'

    #
    # Test for include_tasks parameters
    #
    data = '''
- import_playbook: playbook.yml x=1 y=2
  vars:
    a: b
    c: d
'''

    parent = PlaybookInclude().load(data=data, loader=None)

    assert parent.import_playbook == 'playbook.yml'


# Generated at 2022-06-11 10:36:09.032135
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.playbook.play import Play

    # we need some fake data structure to represent the play we're trying to
    # load. A dict will do
    from ansible.parsing.yaml.loader import AnsibleLoader
    yaml_data = dict(
            import_playbook = 'playbook.yml',
            when = ['a_condition']
    )

    # we can use a temp file for the included playbook
    test_dir = '/tmp'
    test_file = 'test_include.yml'
    test_path = test_dir + '/' + test_file

    file_content = """
    - hosts: localhost
      gather_facts: no
      tasks:
      - name: do something
        debug:
          msg: "something"
    """

# Generated at 2022-06-11 10:36:21.084697
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook

    playbook_include = PlaybookInclude()
    playbook = Playbook(loader=None)
    playbook_include.load_data(ds=dict(import_playbook='filename.yml'), basedir='./ansible/playbooks', variable_manager=None, loader=None)
    playbook_include.load_data(ds=dict(import_playbook='filename.yml', vars={'key': 'value'}), basedir='./ansible/playbooks', variable_manager=None, loader=None)

# Generated at 2022-06-11 10:36:31.726236
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # Testing the PlaybookInclude.__init__() method
    class MockPlaybook(object):
        def __init__(self, data):
            self._entries = []
            for d in data:
                self._entries.append(MockPlay(d))

    class MockPlay(object):
        def __init__(self, data):
            self._attributes = {}
            for k,v in data.items():
                self._attributes[k] = v
            self.vars = {}
            self.tags = []

    class MockTemplar:
        def __init__(self, loader=None, variables=None):
            self._loader = loader
            self._variables = variables

        def template(self, value, **kwargs):
            return value


# Generated at 2022-06-11 10:36:40.764592
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
   from ansible.playbook.playbook import Playbook
   from ansible.playbook.role.definition import RoleDefinition
   from ansible.plugins.loader import role_loader
   from ansible.template import Templar
   from ansible.utils.vars import combine_vars

   pb = Playbook.load('tests/fixtures/playbook-include.yml', variable_manager=None, loader=None)
   assert not pb._included_files
   pb._load_included_file('tests/fixtures/playbook-include.yml', variable_manager=None)
   assert pb._included_files == ['tests/fixtures/playbook-include.yml']

   assert isinstance(pb._entries[0], RoleDefinition)
   assert pb._entries[0].name == 'web'
  

# Generated at 2022-06-11 10:37:59.429987
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import_playbook = "include.yml"

    test_ds = AnsibleMapping(import_playbook=import_playbook)
    test_pb = PlaybookInclude.load(test_ds, basedir=os.path.dirname(os.path.abspath(__file__)), variable_manager=None, loader=None)
    assert isinstance(test_pb, PlaybookInclude)

    ds1 = AnsibleMapping(import_playbook=import_playbook, tags=['tag1','tag2'])
    test_pb1 = PlaybookInclude.load(ds1, basedir=os.path.dirname(os.path.abspath(__file__)), variable_manager=None, loader=None)
    assert isinstance(test_pb1, PlaybookInclude)
    assert test_pb

# Generated at 2022-06-11 10:38:00.339938
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # TODO
    pass


# Generated at 2022-06-11 10:38:11.993788
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    # Create DataLoader
    dl = DataLoader()

    # Create variable manager
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}

    # Create loader
    loader = ds = dl.load_from_file('tests/fixtures/playbook-include.yml')

    # Create PlaybookInclude
    playbook_include = PlaybookInclude()

    # Create basedir
    basedir = 'tests/fixtures'

    playbook = playbook_include.load_data(ds, basedir, variable_manager, loader)

   

# Generated at 2022-06-11 10:38:23.723151
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    all_vars = {'a': 'b'}

    class MockTemplar():

        def __init__(self):
            self._loader = C.DEFAULT_LOADER_NAME
            self._available_variables = all_vars

        def template(self, filename):
            if filename == 'playbook_to_import.yml':
                return 'import_playbook.yml'
            else:
                return filename

    class MockVariableManager():

        def get_vars(self):
            return all_vars

    class MockLoader():
        def __init__(self, ansible_basedir='.'):
            self.basedir = ansible_basedir

        def set_basedir(self, basedir):
            self.basedir = basedir


# Generated at 2022-06-11 10:38:25.281548
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    obj = PlaybookInclude()
    assert obj is not None

# Generated at 2022-06-11 10:38:34.249518
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import ansible.playbook.play

    mock_args = []

    PATHS = dict(
        root='/ansible',
        collection='/ansible/collections/ansible_collections/test/test_playbook_include.py',
        playbook='/ansible/playbooks/test_playbook_include.yml',
    )

    def get_resource_path(*parts):
        return os.path.join(PATHS['root'], *parts)

    def get_collection_playbook_path(*parts):
        return os.path.join(PATHS['collection'], *parts)
