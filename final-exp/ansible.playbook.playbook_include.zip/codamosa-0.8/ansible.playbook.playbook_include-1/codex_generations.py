

# Generated at 2022-06-11 10:28:51.156333
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.parsing.dataloader import DataLoader

    # instanciate a fake loader to test load_data() method
    loader = DataLoader()

    # test with a playbook include with no parameter - should return a Playbook object
    data = dict(
        import_playbook = "foo.yml"
    )
    obj = PlaybookInclude.load(data, basedir=".", loader=loader)
    assert isinstance(obj, Playbook)

    # test with a playbook include with tags parameter - should return a Playbook object
    data = dict(
        import_playbook = "tags=foo,bar,baz foo.yml"
    )

# Generated at 2022-06-11 10:29:02.994089
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    pc = PlayContext()
    var_mgr = VariableManager()
    import_playbook = '/user/directory/test.yml'
    playbook = PlaybookInclude.load(data={'import_playbook': import_playbook}, basedir='/user/directory', variable_manager=var_mgr)
    # Check that playbook is an instance of Playbook
    assert isinstance(playbook, Playbook)
    # Check that data is loaded properly
    assert playbook._entries[0]._entries[0]._entries[0].action == 'test'
    assert playbook._entries[0]._entries[0]._entries[0].args

# Generated at 2022-06-11 10:29:13.307725
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    
    PLAYBOOKS_PATH = os.path.join(os.path.dirname(__file__), "../../test_data/test_playbooks")
    playbook = os.path.join(PLAYBOOKS_PATH, 'test.include.yml')
    
    base = Base()
    base.basedir = PLAYBOOKS_PATH
    base.extra_vars = { "variable" : "value", "var_with_facts" : "facts.some_fact" }
    base.module_vars = { "some_fact" : "some_value" }
    base.variable_manager = VariableManager()
    
    p = PlaybookInclude()
    p.import_playbook = playbook
    p.playbook = Playbook()

# Generated at 2022-06-11 10:29:20.677835
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    pb_include = PlaybookInclude()
    pb = pb_include.load_data(ds='/tmp/foo.yml', basedir='/tmp', variable_manager=None, loader=None)
    assert isinstance(pb, Playbook)
    play = pb._entries[0]
    assert isinstance(play, Play)


# Generated at 2022-06-11 10:29:29.157535
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    p = PlaybookInclude()
    ds = dict(import_playbook=dict(file="name", tags="all", vars=dict(name="value"), verbosity="vvv"))
    new_ds = p.preprocess_data(ds)
    assert type(new_ds) is dict
    assert new_ds['import_playbook'] == 'name'
    assert new_ds['tags'] == 'all'
    assert new_ds['vars'] == dict(name="value", verbosity="vvv")

# Generated at 2022-06-11 10:29:30.357298
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    data_structure = {
        'import_playbook': 'playbook.yaml'
    }

    playbook_include = PlaybookInclude.load(data_structure, '/home/user')



# Generated at 2022-06-11 10:29:36.618710
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    ds = {'import_playbook': 'nested.yml', 'vars': {'nested_var': 'value'}, 'tags': ['a', 'b']}
    data_structure_object = PlaybookInclude()
    assert data_structure_object.preprocess_data(ds) == {'import_playbook': 'nested.yml', 'vars': {'nested_var': 'value'}, 'tags': ['a', 'b']}

# Generated at 2022-06-11 10:29:46.674321
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.parsing import vault
    import os
    print("testing PlaybookInclude.load_data")
    ds = {'include': 'test_include_simple.yml'}

    basedir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..', 'lib', 'ansible', 'playbook'))
    # TODO: make a test useful set of files to include
    res = PlaybookInclude.load(ds, basedir)
    assert(isinstance(res, Playbook))
    assert(len(res._entries) == 1)
    assert(isinstance(res._entries[0], Play))

# Generated at 2022-06-11 10:29:59.189546
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''
    This test checks method load_data of class PlaybookInclude
    '''
    import os
    import tempfile
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-11 10:30:08.186195
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vars import combine_vars


# Generated at 2022-06-11 10:30:18.395275
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:30:19.010530
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:30:29.319656
# Unit test for method load_data of class PlaybookInclude

# Generated at 2022-06-11 10:30:30.031914
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    return


# Generated at 2022-06-11 10:30:39.832455
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    import os
    import tempfile
    import tempfile
    tempdir = tempfile.mkdtemp()
    test_playbook = 'test_include_play.yaml'
    test_playbook_path = os.path.join(tempdir, test_playbook)
    fd, test_playbook_file = tempfile.mkstemp()

# Generated at 2022-06-11 10:30:40.572303
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:30:51.919574
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.playbook.role._role import Role

    # Create an empty Playbook
    pb = Playbook()

    # Create a fake PlaybookInclude
    pi = PlaybookInclude()
    pi.import_playbook = 'test_vars.yml'
    pi.vars = {'TEST_VAR': 'test var'}
    pi.tags = ['pi_tag']

    # Create a fake Playbook
    # The fake playbook has 2 plays
    # One of them has vars and tags already
    # The other has no vars and no tags
    pb._load_playbook_data('')
    p1 = Play()

# Generated at 2022-06-11 10:31:02.688957
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.role.include import RoleInclude

    # test load_data without condition
    ds = dict(
        import_playbook='test_play.yml',
        tags=['tag1', 'tag2'],
        vars={
            'var1': 1,
            'var2': 2
        }
    )
    playbook_include = PlaybookInclude.load(ds=ds, basedir='/data')
    assert playbook_include._entries[0]._included_path == '/data'
    assert playbook_include._entries[0].tags == ['tag1', 'tag2']
    assert playbook_include._entries[0].vars['var1'] == 1


# Generated at 2022-06-11 10:31:14.388465
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play

    basedir = "/Users/danielm/Playbooks/test"

# Generated at 2022-06-11 10:31:25.724449
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

  from ansible.playbook.play import Play

  # Case1: Create a playbook import with a tag, a var and a when
  # Create the playbook import
  playbook_include = PlaybookInclude()

  # Create a dictionary of data to simulate the playbook given to the class
  data = { 'import_playbook': 'test_playbook.yml','tags': 'test_tag','vars':'var1=test1','when': '1==1'}

  # Create a playbook
  playbook = Playbook()

  # Create a play
  play = Play()
  play.tags = ['test_tags']

  # Add the play to the playbook
  playbook._entries=[play]

  # Set when for the play
  play._attributes['when'] = ['1==1']

  # Set vars for the play

# Generated at 2022-06-11 10:31:46.653915
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import tempfile
    p = PlaybookInclude()
    p.import_playbook = '/usr/local/test.yml'
    p.vars = {'test1': 'value1', 'test2': 'value2'}

# Generated at 2022-06-11 10:31:54.919265
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # first test with no parameters in the playbook include line
    ds = dict(
        import_playbook = 'path/to/playbook.yml'
    )
    obj = PlaybookInclude()
    obj.load_data(ds, basedir='/the/basedir/')
    assert obj.import_playbook == 'path/to/playbook.yml'
    assert obj.vars == {}

    # now test with params (no vars) specified in the playbook include line
    ds = dict(
        import_playbook = 'path/to/playbook.yml some_var1=value1 some_var2=value2'
    )
    obj = PlaybookInclude()
    obj.load_data(ds, basedir='/the/basedir/')

# Generated at 2022-06-11 10:31:55.577796
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:32:06.232498
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # some basic args for the PlaybookInclude to consume
    import_ds = dict(
        import_playbook = "TESTPLAYBOOK.yml"
    )
    from ansible.playbook import Playbook
    # create a test Playbook
    pb = Playbook.load("", variable_manager=None, loader=None)
    # test method PlaybookInclude.load_data of class PlaybookInclude
    pbi = PlaybookInclude.load(import_ds, "", variable_manager=None, loader=None)
    # Test loading is successful
    assert isinstance(pbi, Playbook)

if __name__ == '__main__':
    test_PlaybookInclude_load_data()

# Generated at 2022-06-11 10:32:16.480608
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    test_data_1 = {
        'import_playbook': 'playbook.yml',
        'role': 'foobar'
    }

    test_data_2 = {
        'import_playbook': 'playbook.yml',
        'tags': 'foobar'
    }

    test_data_3 = {
        'import_playbook': 'playbook.yml',
        'vars': {
            'a': '1',
            'b': '2'
        }
    }

    test_data_4 = {
        'import_playbook': 'playbook.yml',
        'vars': {
            'a': '1',
            'b': '2'
        },
        'tags': 'foobar'
    }


# Generated at 2022-06-11 10:32:18.701157
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    display.deprecated("The module 'test_PlaybookInclude_load_data' is deprecated. Use 'test_import_playbook' module instead", version='2.14')



# Generated at 2022-06-11 10:32:30.848497
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Setup
    context = {}

    # Exercise functionality
    variable_manager = ansible.vars.VariableManager()
    loader = ansible.parsing.dataloader.DataLoader()
    variable_manager.set_loader(loader)
    variable_manager.set_inventory(ansible.vars.Inventory(loader=loader, variable_manager=variable_manager, host_list=['localhost']))

    # import here to avoid a dependency loop
    from ansible.playbook_include import PlaybookInclude

    include = 'tasks:include1.yml'

    # Check success
    assert isinstance(PlaybookInclude.load(include, '/etc', variable_manager=variable_manager, loader=loader), ansible.playbook.Playbook)

    # Check failure

# Generated at 2022-06-11 10:32:41.414899
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Test the load_data function of class PlaybookInclude
    # Test case 1: a datastructure that is in playbook format
    playbook = dict(hosts='localhost',
                    roles=['myrole', 'yourrole'])
    playbook_include = PlaybookInclude()
    playbook_new = playbook_include.load_data(ds=playbook, variable_manager = None, loader = None)
    # The new playbook loaded from the original playbook should be the same
    assert playbook_new.hosts == playbook['hosts']
    assert playbook_new.roles[0].name == playbook['roles'][0]
    assert playbook_new.roles[1].name == playbook['roles'][1]

    # Test case 2: a datastructure that is in playbook include format

# Generated at 2022-06-11 10:32:52.385719
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    pbi = PlaybookInclude()

    # @777 = different datastructure
    data = [
        {
            'import_playbook': './test/ansible/playbooks/test_import_playbook.yml',
        }
    ]

# Generated at 2022-06-11 10:33:04.371701
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.playbook_include import PlaybookInclude

    # Test case 1 - check that playbook_include.load_data returns a Playbook object

    # create a PlaybookInclude object
    import_playbook = PlaybookInclude(import_playbook="test_data/test_playbook_include.yaml",
                                      tags=["myTag"], vars={"var1": "value1"})

    # load template engine and populate variables
    templar = Templar(loader=None, variables=import_playbook.vars)

    # check that load_data returns a Playbook object
    result = import_playbook.load_data(ds=None, basedir=".", variable_manager=None, loader=None)


# Generated at 2022-06-11 10:33:23.618391
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence

    ds = AnsibleMapping()
    ds.update({'import_playbook': './playbook.yml'})
    basedir = './playbook'
    context = PlayContext()
    context._vars = {}
    v = VariableManager(loader=None, host_vars={}, group_vars={}, play_vars={}, defaults={})

    result = PlaybookInclude.load_data(ds, basedir, v, AnsibleLoader)
    assert isinstance(result, AnsibleSequence)
    assert len(result) == 0
   

# Generated at 2022-06-11 10:33:34.111812
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    from ansible.template.vars import VariableManager
    from ansible.vars.manager import VariableManager
    from ansible.vars import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager(loader, play_context=PlayContext())
    templar = Templar(loader=loader, variable_manager=variable_manager)

    obj = dict()
    obj['import_playbook'] = "{{ a }}"
    obj['a'] = 'a.yml'
    obj['b'] = 'b.yml'

    pi = PlaybookInclude()
    pb = pi.load_data(obj, '.', templar, loader=loader)
    print(pb._entries)
    pi.v

# Generated at 2022-06-11 10:33:41.150532
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    playbook_include_str = """
    ---
    #include
    - import_playbook: test/import_playbook/lower_playbook.yml
      tags: ltag_1,ltag_2
    - import_playbook: test/import_playbook/upper_playbook.yml
      vars:
        uvar1: uvalue1
        uvar2: uvalue2
      tags: utag_1,utag_2
    """

    dataset = AnsibleLoader(playbook_include_str).get_single_data()

    variable_manager = None
    basedir = "test/import_playbook"

   

# Generated at 2022-06-11 10:33:54.387519
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include = PlaybookInclude()
    playbook_include.vars = dict()
    playbook_include.tags = list()

    with pytest.raises(AnsibleAssertionError) as excinfo:
        playbook_include.preprocess_data([])
    assert 'should be a dict but was a' in str(excinfo.value)

    with pytest.raises(AnsibleParserError) as excinfo:
        playbook_include.preprocess_data({'import_playbook': None})
    assert 'playbook import parameter is missing' in str(excinfo.value)

    with pytest.raises(AnsibleParserError) as excinfo:
        playbook_include.preprocess_data({'import_playbook': 1})

# Generated at 2022-06-11 10:34:02.444678
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.playbook.play import Play

    class Loader:
        def __init__(self):
            self.path = 'path'

    class VarManager:
        def get_vars(self):
            return dict()

    class Play1(Base):
        _base_attributes = dict(vars=dict(a=1, b=2, c=3), tags=['tag1', 'tag2'])

    class Play2(Base):
        _base_attributes = dict(vars=dict(d=4, e=5, f=6), tags=['tag3', 'tag4'])

    class Play3(Base):
        _base_attributes = dict(vars=dict(g=7, h=8, i=9), tags=['tag5', 'tag6'])


# Generated at 2022-06-11 10:34:13.949209
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.plugins.loader import find_plugin
    plugin_loader = find_plugin('callback')
    plugin_loader.load()
    callback_plugin = plugin_loader.get('minimal')
    basedir = os.path.dirname(os.path.dirname(__file__))
    variable_manager = None
    loader = None
    pi = PlaybookInclude()
    ds = {'import_playbook':'../../../test/integration/import_playbook/import_playbook.yml', 'tags':'tag2', 'vars':{'bar':'BAR', 'foo':'FOO'}}
    pb = pi.load_data(ds, basedir, variable_manager, loader)
   

# Generated at 2022-06-11 10:34:25.269526
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from io import StringIO
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    # PlaybookInclude.load() wraps PlaybookInclude.load_data(). Because
    # load_data() is what is actually tested, it is easier to only provide
    # dummy data to load() and then test the results of load_data().

    # A simplified playbook list to test against.
    yaml_data = StringIO('''
- hosts: all
  tasks:
    - debug:
        msg: "This is the outer playbook."
''')

    # A simplified include file to test against.
    include_yaml_data = StringIO('''
- hosts: all
  tasks:
    - debug:
        msg: "This is the include playbook."
''')

    # Create a PlaybookIn

# Generated at 2022-06-11 10:34:32.656296
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os
    import ansible.plugins.loader
    yaml_obj = {
        'import_playbook': '../../../../../../../../etc/ansible/roles/test/tasks/main.yml',
    }
    playbook_include = PlaybookInclude.load(yaml_obj, '/home/test/.ansible/collections/ansible_collections/test/test/')
    assert playbook_include.import_playbook == '../../../../../../../../etc/ansible/roles/test/tasks/main.yml'
    assert playbook_include.vars == {}

    yaml_obj = {
        'import_playbook': 'test/test/test.yml',
        'vars': {'test_key': 'test_value'},
    }
    playbook_

# Generated at 2022-06-11 10:34:41.029069
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook

    # Instantiate a PlaybookInclude object
    test_play = PlaybookInclude()
    # create a dictionary ds with the info for a fake playbook include object
    ds = {'import_playbook': 'myplaybook.yml', 'tags': 'mytags', 'vars': {'myvars': 'myvalue'}}
    # load the fake playbook and check that it returns a Playbook object
    test_pb = test_play.load_data(ds, '', None, None)
    assert isinstance(test_pb, Playbook)

# Generated at 2022-06-11 10:34:52.600918
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # import here to avoid ansible import dependency loop
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.template import Templar
    from ansible.vars import VariableManager


# Generated at 2022-06-11 10:35:00.590158
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass #TODO

# Generated at 2022-06-11 10:35:12.117338
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

    loader = DictDataLoader({
        "_meta": {
            "hostvars": {
                "hostname": {"key1": "value1"},
            }
        }
    })

    variable_manager = VariableManager(loader=loader)

    # Test playbook with a single play
    with open('test/units/test_playbook_include/play.yml') as f:
        play = Play.load(f, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-11 10:35:13.339238
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''
    Test PlaybookInclude.load_data(ds=data, basedir=basedir, variable_manager=variable_manager, loader=loader)
    :return:
    '''
    # FIXME
    pass

# Generated at 2022-06-11 10:35:19.724589
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.playbook.play_context import PlayContext

    # TODO: set up a mock play context and mock loader, then construct
    # a playbook include object and call the method of interest

    # TODO: test that the return value is an instance of Playbook,
    # and that it was created in the correct way based on the input
    # parameters
    return

if __name__ == '__main__':
    test_PlaybookInclude_load_data()

# Generated at 2022-06-11 10:35:28.266642
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    playbook_file = './unit_tests/include.yml'
    summary_file = './unit_tests/summary.yml'
    ds = AnsibleMapping()
    ds['import_playbook'] = 'include2.yml'
    loader = DataLoader()
    variable_manager = VariableManager()
    basedir = './unit_tests'
    PlaybookInclude().load_data(ds, basedir, variable_manager, loader)
    assert playbook_file == os.path.abspath(variable_manager._playbook)
    assert summary_file == os.path.abspath(variable_manager._summary)

# Generated at 2022-06-11 10:35:40.478859
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.task_include import TaskIncludeLoader
    from ansible.playbook.block import Block
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    # create variables
    loader = None
    variable_manager = None
    # create an object PlaybookInclude
    test_playbookinclude = PlaybookInclude()
    # create a dictionary of data
    data = {'impor': 'test_playbook.yml'}
    # create an object Block
    test_block = Block()
    test_block._parent = Play()
    test_block._role = ""
    test_block.vars = {'test': 'test_variable'}
    test_

# Generated at 2022-06-11 10:35:48.130520
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # test with relative path (not collection)
    pb = PlaybookInclude()
    assert pb.load_data("import_playbook: relative/file.yml", None) != None

    # test with full path (not collection)
    pb = PlaybookInclude()
    assert pb.load_data("import_playbook: /absolute/path/to/file.yml", None) != None

    # test with relative path (collection)
    pb = PlaybookInclude()
    assert pb.load_data("import_playbook: collection/namespace.name/relative/file.yml", None) != None

    # test with full path (collection)
    pb = PlaybookInclude()

# Generated at 2022-06-11 10:36:00.841020
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    # define the Play we're going to test, we're going to embed PlaybookIncludes in it
    plays = []
    play = Play()
    play.load(
        dict(
            name="Test play",
            hosts='all',
            gather_facts=False,
            pre_tasks=[dict(action='debug', msg='pre_task_1'), dict(action='debug', msg='pre_task_2')],
        )
    )
    plays.append(play)

    # now define the task we're going to embed (as a pre_task on the main play defined above)
    task = Task()

# Generated at 2022-06-11 10:36:10.575346
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.six import string_types

    # create a fake Playbook
    play = Play()
    playBook = Playbook()
    playBook.set_loader(loader=None)
    playBook._entries = [play,]
    playBook._loader = None
    playBook._variable_manager = None
    # empty play 
    assert play.vars == {}
    assert play.tags == []

    # create a fake PlaybookInclude
    play_include = PlaybookInclude()
    play_include.import_playbook = "../test.yml"

# Generated at 2022-06-11 10:36:12.371063
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # TODO: write test
    pass


# Generated at 2022-06-11 10:36:38.303101
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    pb = PlaybookInclude.load(
        dict(
            import_playbook="../foo.yml"
        ),
        basedir=os.path.join(os.path.dirname(os.path.realpath(__file__)), '..', '..', 'test', 'playbooks')
    )
    assert len(pb._entries) == 1
    play = pb._entries[0]
    assert isinstance(play, Play)
    assert len(play.vars.keys()) == 0
    assert len(play.tags) == 0
    assert play.name == 'test'
    assert play.gather_facts is True
    assert play.hosts == ['all']
    assert len(play.tasks) == 1
    task = play.tasks

# Generated at 2022-06-11 10:36:38.926099
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:36:45.811008
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import ansible.playbook
    from ansible.playbook.block import Block

    # Initializes class objects
    playbook_include_obj = PlaybookInclude()
    playbook_obj = ansible.playbook.Playbook()
    playbook_include_obj.import_playbook = os.path.realpath(__file__)

    # Test the return type of method load_data of class PlaybookInclude
    assert isinstance(playbook_include_obj.load_data(1, 1, 1, 1), ansible.playbook.Playbook)

# Generated at 2022-06-11 10:36:56.763895
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import sys
    sys.modules['ansible'] = None
    sys.modules['ansible.parsing.yaml.loader'] = None
    import ansible.parsing.yaml.loader
    sys.modules['ansible.errors'] = None
    import ansible.errors
    sys.modules['ansible.playbook'] = None
    import ansible.playbook
    sys.modules['ansible.playbook.play'] = None
    import ansible.playbook.play
    sys.modules['ansible.utils.collection_loader'] = None
    import ansible.utils.collection_loader
    sys.modules['ansible.plugins.loader'] = None
    import ansible.plugins.loader
    sys.modules['ansible.playbook.play_context'] = None
    import ansible.playbook.play_context


# Generated at 2022-06-11 10:37:02.056990
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include = PlaybookInclude()
    playbook_include.import_playbook = 'filename'
    playbook_include.vars = {}
    playbook_include.tags = ['tag', 'tag2']
    playbook_include.when = ['when', 'when2']
    basedir = 'basedir'
    variable_manager = {}
    loader = {}

    pb = playbook_include.load_data({}, basedir, variable_manager, loader)



# Generated at 2022-06-11 10:37:12.583284
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    playbook_obj = PlaybookInclude.load(dict(import_playbook="test/unit/utils/test.yml"), "test/unit")
    assert isinstance(playbook_obj, Playbook), playbook_obj
    assert len(playbook_obj._entries) == 1, playbook_obj._entries

    included_play = playbook_obj._entries[0]
    assert isinstance(included_play, Play), included_play

    task = included_play.get_tasks()[0]
    assert isinstance(task, Task), task
    assert task.action == 'debug', task.action

    assert included_play._included_path == "test/unit", included_

# Generated at 2022-06-11 10:37:14.071968
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''
    TODO
    '''
    pass


# Generated at 2022-06-11 10:37:24.916806
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play_context import PlayContext

    import json
    import pytest
    from ansible.parsing.vault import VaultLib

    schema = 'test/data/playbook_include_schema.json'
    with open(schema) as schema_file:
        jsonschema = json.load(schema_file)

    playbook_include = """
    ---
    - import_playbook: /tmp/test/test-playbook.yaml
      vars:
        variable1: test1
        variable2: test2
    """
    base_dir = '/tmp/test/'
    data = playbook_include
    variable_manager = None
    loader = None
    pb = PlaybookInclude().load(data, base_dir, variable_manager, loader)
    print(pb)

# Generated at 2022-06-11 10:37:34.789973
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import ansible.playbook
    import ansible.playbook.play
    #/home/ansible/ansible/lib/ansible/plugins/loader/collection_loader.py
    from ansible.collections.collection_loader import _get_collection_name_from_path
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    # make sure we have the current collection paths in the list
    AnsibleCollectionConfig.playbook_paths.append('/home/ansible/ansible/lib/ansible/collections')

    # import here to avoid a dependency loop
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    # first, we use the original parent method to correctly load the object
    # via the load_data/preprocess_data system we normally use for other
    #

# Generated at 2022-06-11 10:37:47.403618
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook import Playbook
    import ansible.playbook.play

    ds = {'import_playbook': 'test', 'vars': { 'test1': 'test2'}, 'tags': ['test3'],
            'when': {'test4': 'test5'}}
    basedir = 'basedir'
    variable_manager = 'variable_manager'
    loader = 'loader'

    # test load
    pbi = PlaybookInclude.load(ds, basedir, variable_manager, loader)
    assert isinstance(pbi, Playbook)

    # test load_data
    pbi = PlaybookInclude()
    pbi.load_data(ds, basedir, variable_manager, loader)
    assert isinstance