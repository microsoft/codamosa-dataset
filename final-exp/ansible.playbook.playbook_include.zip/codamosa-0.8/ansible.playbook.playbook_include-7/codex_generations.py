

# Generated at 2022-06-11 10:28:58.589456
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Load data
    data = {'playbook': 'playbook.yml', 'vars': {'a': 1}}
    basedir = '.'
    variable_manager = None
    loader = None
    PlaybookInclude.load(data, basedir, variable_manager, loader)

    # Load data from AnsibleBaseYAMLObject
    data = {'playbook': 'playbook.yml', 'vars': {'a': 1}}
    obj = AnsibleBaseYAMLObject(data)
    basedir = '.'
    variable_manager = None
    loader = None
    PlaybookInclude.load(data, basedir, variable_manager, loader)

# Generated at 2022-06-11 10:29:10.689002
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os
    import sys
    import tempfile
    import unittest
    import yaml

    from ansible import constants as C
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import PY3
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.objects import AnsibleSequence

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.taggable import Taggable

    from ansible.template import Templar

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    from ansible.playbook.play_context import PlayContext


# Generated at 2022-06-11 10:29:23.255493
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook, PlaybookInclude
    from ansible.vars import VariableManager

    loader = AnsibleLoader(None, None)
    variable_manager = VariableManager()
    pb = PlaybookInclude()

    # 1. Test a basic include with parameters
    # ds = {'import_playbook': 'test.yml force=true'}

    ds = loader.load('import_playbook: test.yml force=true')
    data = pb.load_data(ds, basedir='.', variable_manager=variable_manager)
    assert isinstance(data, Playbook)
    assert len(data._entries) == 1

# Generated at 2022-06-11 10:29:35.305256
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    ds = dict(name='test-import-playbook', import_playbook='test-playbook.yml', tags=['import-test'], vars=dict(test_var=1))
    new_ds = PlaybookInclude().preprocess_data(ds)
    assert isinstance(new_ds, dict)
    assert 'name' in new_ds
    assert new_ds['name'] == 'test-import-playbook'
    assert new_ds['tags'] == ['import-test']
    assert new_ds['vars']['test_var'] == 1
    assert 'import_playbook' in new_ds
    assert new_ds['import_playbook'] == 'test-playbook.yml'

# Generated at 2022-06-11 10:29:42.219081
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    import tempfile
    data = {}
    data['import_playbook'] = 'i_dont_exist'
    basedir = '/tmp'
    pb = PlaybookInclude.load(data, basedir)
    assert isinstance(pb, Playbook)
    assert len(pb._entries) == 0

    # specify a non-existent playbook file
    data = {}
    data['import_playbook'] = 'i_dont_exist'
    basedir = '/tmp'
    try:
        PlaybookInclude.load(data, basedir)
        assert False
    except AnsibleParserError:
        assert True

    # specify a fake playbook file with a 'pre_tasks' key
    data = {}

# Generated at 2022-06-11 10:29:55.151326
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include = PlaybookInclude()
    playbook_include.vars = {}
    ds = AnsibleMapping()
    ds.ansible_pos = (0, 0)
    ds['import_playbook'] = 'import1'
    ds['vars'] = {'k1': 'v1'}
    playbook_include.preprocess_data(ds)
    assert playbook_include.vars == {'k1': 'v1'}
    assert playbook_include.import_playbook == 'import1'
    ds = AnsibleMapping()
    ds.ansible_pos = (0, 0)
    ds['import_playbook'] = 'import2'
    ds['tags'] = ['t1', 't2']
    playbook_include.preprocess_data(ds)
   

# Generated at 2022-06-11 10:30:04.874777
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import yaml
    yaml_data = yaml.safe_load("""
- include: ../../../common_tasks/main.yml
      tags:
          - foo
      vars:
          bar: baz
      when:
          - test1
          - test2
""")
    expected_result = {'import_playbook': '../../../common_tasks/main.yml', 'tags': 'foo', 'vars': {'bar': 'baz'}, 'when': ['test1', 'test2']}
    playbook_include = PlaybookInclude()
    for ds in yaml_data:
        result = playbook_include.preprocess_data(ds)
        assert result == expected_result

# Generated at 2022-06-11 10:30:14.430384
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    class MockPlaybookInclude(PlaybookInclude):
        pass

    data_structure = {
        'import_playbook': 'other.yml',
        'tags': 'test_tag',
        'vars': {
            'key1': 'value1',
            'key2': 'value2'
        }
    }

    playbook = MockPlaybookInclude()
    assert playbook.preprocess_data(data_structure) == data_structure

    data_structure = {'import_playbook': 'other.yml'}
    result = playbook.preprocess_data(data_structure)
    assert result.get('import_playbook', None) == 'other.yml'
    assert 'vars' not in result
    assert 'tags' not in result


# Generated at 2022-06-11 10:30:25.253584
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.role_include import RoleInclude
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    basedir = '.'
    ds = dict(
        include="test_include.yml",
        roles="some_role,some_other_role",
        tasks="some_task,some_other_task",
        vars=dict(
            key1=dict(
                some="nested",
                dict="var"
            ),
            dict2={
                "key": "value"
            },
            list=["val1", "val2"],
        ),
    )

# Generated at 2022-06-11 10:30:35.156579
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    class Options(object):
        def __init__(self, verbose=None, extra_vars=None):
            self.verbose = verbose  # int
            self.extra_vars = extra_vars or list()

    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    p = dict(
        ANSIBLE_VERBOSITY=0,
        ANSIBLE_LOAD_CALLBACK_PLUGINS=False,
        ANSIBLE_INTERNAL_TEMPLATE_ENGINE=False,
        ANSIBLE_STRIP_JUNK_HEADERS=False,
        ANSIBLE_DISTRIBUTION='TEST'
    )
    options = Options(verbose=4, extra_vars=p)
    pb = PlaybookInclude()

# Generated at 2022-06-11 10:30:50.149743
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    class MockLoader:
        def get_basedir(self):
            return 'basedir'
    class MockVariableManager:
        def get_vars(self):
            return dict()

    filename = 'filename'
    playbook = 'playbook'

    playbook_include = PlaybookInclude()
    playbook_include._load_playbook_data = Mock(return_value=None)
    playbook_include.load_data(ds={}, basedir=None, variable_manager=MockVariableManager(), loader=MockLoader())
    playbook_include.load_data()

    playbook_include._load_playbook_data.assert_called_with(file_name=filename, variable_manager=None, vars=dict())

# Generated at 2022-06-11 10:30:50.827534
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:30:51.580931
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:31:02.461298
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_str1 = '- import_playbook: playbook1.yml'
    playbook_str2 = '- import_playbook: playbook1.yml other_param: value'
    playbook_str3 = '- import_playbook: playbook1.yml other_param: value\n'
    playbook_str4 = '- import_playbook: playbook1.yml vars:\n    a: 1'
    playbook_str5 = '- import_playbook: playbook1.yml vars:\n    a: 1\n'
    playbook_str6 = '- import_playbook: playbook1.yml vars:\n    a: 1\n  tags: import_tag'

# Generated at 2022-06-11 10:31:06.294001
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # import here to avoid a dependency loop
    from ansible.playbook import Playbook

    pb = PlaybookInclude.load(data={'import_playbook': 'test.yml'}, basedir='/')

    assert isinstance(pb, Playbook)


# Generated at 2022-06-11 10:31:07.370896
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    raise NotImplementedError

# Generated at 2022-06-11 10:31:20.097467
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os
    from ansible.module_utils.basic import AnsibleModule
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.common.json import AnsibleJSONEncoder
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    from ansible.template import Templar
    from ansible.utils.collection_loader.collection_finder import _get_collection_name_from_path
    from ansible.utils.collection_loader._collection_finder import _get_collection_playbook_path


# Generated at 2022-06-11 10:31:28.953557
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    a1 = "import_playbook: bar.yml"
    a2 = "import_playbook: bar.yml biz=baz"
    a3 = "import_playbook: bar.yml biz=baz tags=foo,foo2"
    b1 = "import_playbook: bar.yml vars: biz=baz"
    b2 = "import_playbook: bar.yml vars: biz=baz tags=foo,foo2"
    b3 = "import_playbook: bar.yml vars: biz=baz tags=foo,foo2 superdude=awesomepants"
    c1 = "import_playbook: bar.yml vars:"
    c2 = "import_playbook: bar.yml vars: foo=bar"

# Generated at 2022-06-11 10:31:41.917455
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Test with empty ds parameter
    ds = dict()
    role_include = PlaybookInclude()
    new_ds = role_include.preprocess_data(ds)
    assert new_ds == {}

    # Test with a basic playbook include ds parameter
    ds = dict(
        import_playbook='test_play.yml',
        vars=dict(
            foo='bar',
            bar='baz',
        ),
        tags=['test'],
    )
    role_include = PlaybookInclude()
    new_ds = role_include.preprocess_data(ds)

# Generated at 2022-06-11 10:31:50.675577
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    import io
    import unittest.mock

    loader_patcher = unittest.mock.patch('ansible.playbook.include.ansible.parsing.loader.load_from_file')
    loader_patcher.start()
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.utils.display import Display
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.parsing.splitter import parse_kv, split_args
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.errors import AnsibleParserError
    from ansible.module_utils._text import to_bytes

   

# Generated at 2022-06-11 10:32:10.045795
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    class MockVariableManager():
        def __init__(self):
            self.vars = dict({'var1' : 'value1', 'var2' : 'value2'})

        def get_vars(self):
            return self.vars

    class MockLoader():
        def __init__(self):
            self.basedir = 'basedir'

    class MockPlaybook():
        def __init__(self):
            self._entries = []
            self._included_files = []

        def _load_playbook_data(self, file_name, variable_manager, vars):
            self._included_files.append(file_name)

    class MockPlay():
        def __init__(self):
            self.vars = dict()
            self.tags = []

# Generated at 2022-06-11 10:32:10.760511
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:32:19.531498
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    """
    This unit tests the load_data method of class PlaybookInclude.
    """

    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.template import Templar

    # Test
    pb = PlaybookInclude()

    # Test
    ds = AnsibleMapping()
    ds["import_playbook"] = "test_PlaybookInclude_load_data.yaml"
    pb = pb.load_data(ds, ".")
    playbook = pb._entries[0]
    assert isinstance(playbook, Play)
    assert playbook.name == "test play name"
    assert playbook.roles == []

    # Test
    ds = AnsibleM

# Generated at 2022-06-11 10:32:31.813835
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    class TestPlaybookInclude(PlaybookInclude):
        def __init__(self):
            self._entries = []


    p = TestPlaybookInclude()
    p.import_playbook = None
    p.vars = {}

    # single param
    ds = {'import_playbook': 'file1.yml'}
    p.import_playbook = None
    p.vars = {}
    p.preprocess_data(ds)
    assert p.import_playbook == 'file1.yml'

    # single param with extra colons
    ds = {'import_playbook': ':file2.yml:'}
    p.import_playbook = None
    p.vars = {}
    p.preprocess_data(ds)

# Generated at 2022-06-11 10:32:41.860626
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import os
    import sys
    import tempfile
    import yaml
    from ansible.playbook.playbook_include import PlaybookInclude

    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    # create a temporary directory and a temporary file for testing
    tmpdir = tempfile.mkdtemp()
    tmpfile_name = os.path.join(tmpdir, 'test_PlaybookInclude_preprocess_data.yaml')
    tmpfile = open(tmpfile_name, 'w')

    # create a dictionary representing the playbook
    # the keys are the playbook commands
    # the values are the parameters required by the playbook commands
    playbook = {}
    playbook['playbook'] = 'test_playbook.yaml'
    playbook['vars'] = {}

# Generated at 2022-06-11 10:32:53.091687
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.playbook.play import Play

    # Object for play
    play = Play()
    play._included_path = '/home/ansible/playbooks'

    # Object for playbook
    from ansible.playbook import Playbook
    playbook = Playbook()
    playbook._entries = [play]
    playbook._included_files = []
    playbook._basedir = '/home/ansible/playbooks'
    playbook._loader = None
    playbook._variable_manager = None

    # Object for import
    ip = PlaybookInclude()
    ip.import_playbook = '../file.yml'
    ip.tags = ['all']
    ip.vars = {'var': 'value'}

    # Actual test

# Generated at 2022-06-11 10:32:54.586862
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Create object PlaybookInclude
    PlaybookInclude.load()

# Generated at 2022-06-11 10:33:06.189625
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    _PlaybookInclude = PlaybookInclude()

    # This is not a data test, only a syntax test
    #    - We use the load_data method because the syntax of the
    #      method is best illustrated this way.
    _data = {
        'import_playbook': 'pb_file.yml'
    }

    _basedir = "."
    _variable_manager = None
    _loader = None

    try:
        _pb = _PlaybookInclude.load_data(ds=_data, basedir=_basedir, variable_manager=_variable_manager, loader=_loader)
    except Exception as e:
        assert False, 'Syntax error in the load method of PlaybookInclude'

    # This is not a data test, only a syntax test
    #    - We use the load_data method because

# Generated at 2022-06-11 10:33:12.430916
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    def test_load_data(obj):
        raise AssertionError('should not use this method')

    def test_load_data_ds(obj, ds, basedir, variable_manager, loader):
        raise AssertionError('should not use this method')

    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.template import Templar

    display = Display()
    variable_manager = VariableManager()
    loader = 'dummy'
    templar = Templar(loader='dummy', variables={})
    # ds is a string because this is what load_data calls preprocess_data on
    # and that

# Generated at 2022-06-11 10:33:16.926240
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # init class
    playbook_include = PlaybookInclude()

    # import here to avoid a dependency loop
    from ansible.playbook import Playbook

    # tests
    assert isinstance(playbook_include.load_data(ds={"import_playbook": "file"}, basedir="."), Playbook)

# Generated at 2022-06-11 10:33:28.861704
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
  pass

# Generated at 2022-06-11 10:33:29.900712
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # TODO: implement unit test
    pass

# Generated at 2022-06-11 10:33:31.306425
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # TODO: Decide whether to test this function or not.
    pass

# Generated at 2022-06-11 10:33:39.899425
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import yaml

    # This is the baseline data structure to be parsed
    data_structure = dict(
        import_playbook=dict(
            include='awesome-playbook.yml',
            vars=dict(
                foo='foo parameter',
                bar='bar parameter',
                zar='zar parameter',
            ),
            tags=['one', 'two', 'three'],
        ),
    )
    data = yaml.dump(data_structure, Dumper=AnsibleDumper)

    playbook_include = PlaybookInclude.load(data, basedir=None)
    playbook_include.preprocess_data(playbook_include._ds)



# Generated at 2022-06-11 10:33:52.642321
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    # Create variable_manager to be used by load_data
    from ansible.vars import VariableManager
    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory=None)

    # Create data to pass to load_data
    ds = dict(import_playbook="playbooks/abcd.yml", tags=['efgh'], vars=dict(a_var='value'))

    # Load data
    pi = PlaybookInclude()
    pb = pi.load_data(ds, '/home/jdoe/playbooks', variable_manager)

    # Verify that resultant data is correct
    assert isinstance(pb, Playbook)
    assert len(pb._entries) == 1
    assert isinstance

# Generated at 2022-06-11 10:34:01.401303
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    playbook_include = PlaybookInclude()

    ds = {
        'import_playbook': 'playbook.yml',
    }

    playbook = Playbook()
    playbook.loader = True

    pb = playbook_include.load_data(ds, basedir=None, variable_manager=None, loader=None)
    assert type(pb) is Playbook
    assert len(pb._entries) == 1
    assert type(pb._entries[0]) is Play
    assert pb._entries[0].name == 'playbook.yml'
    assert pb._entries[0]._included_path is None



# Generated at 2022-06-11 10:34:12.543358
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    ds = {
        'import_playbook': './playbook.yml'
    }
    new_ds = {
        'import_playbook': './playbook.yml'
    }
    new_object = PlaybookInclude()
    assert new_object._preprocess_import(ds, new_ds, 'import_playbook', './playbook.yml') == {
        'import_playbook': './playbook.yml'
    }

    ds = {
        'import_playbook': './playbook.yml',
        'vars': {
            'variable': 'value'
        }
    }

# Generated at 2022-06-11 10:34:13.515726
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:34:24.790644
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    import tempfile

    import ansible.plugins
    from ansible.parsing.dataloader import DataLoader

    # Create a temp directory to store the playbook
    cur_dir = os.getcwd()
    temp_dir = tempfile.mkdtemp()
    os.chdir(temp_dir)

    # Create a test playbook
    file_name = "test_playbook.yml"
    with open(file_name, "w") as f:
        f.write("""
- hosts: all
  tasks:
    - debug:
        msg: "Hello from included playbook 1"
    - debug:
        msg: "Hello from included playbook 2"
""")

    # Create an object of class PlaybookInclude
    pi = PlaybookInclude()
    pi.import_playbook = file_name

    #

# Generated at 2022-06-11 10:34:32.738708
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    '''
    The test data is used to test the preprocess_data method of class PlaybookInclude.
    To pass the test, the preprocess_data method needs to return a dict with 
    - 'import_playbook' as the playbook to import
    - 'tags' as a list of tags specified in the playbook import line
    - 'vars' as a list of variables specified in the playbook import line
    '''

# Generated at 2022-06-11 10:34:54.267925
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:35:04.654200
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook, Play
    pb = PlaybookInclude().load_data(ds="playbook.yml", basedir=".")
    assert isinstance(pb, Playbook)

    pb = PlaybookInclude().load_data(ds="playbook.yml:tag", basedir=".")
    assert isinstance(pb, Playbook)

    pb = PlaybookInclude().load_data(ds="playbook.yml:tag vars=a:1,b:2", basedir=".")
    assert isinstance(pb, Playbook)

    pb = PlaybookInclude().load_data(ds="playbook.yml:tag vars=a:1,b:2", basedir=".", variable_manager=None, loader=None)
    assert isinstance(pb, Playbook)

    p

# Generated at 2022-06-11 10:35:16.827735
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include = PlaybookInclude()

    # Test data source is an AnsibleBaseYAMLObject
    data_source = {'import_playbook': 'test_playbook.yml', 'tags': 'tag1'}
    expected_result = {'import_playbook': 'test_playbook.yml', 'tags': 'tag1'}
    actual_result = playbook_include.preprocess_data(data_source)
    assert actual_result == expected_result

    # Test data source is a dictionnary
    data_source = {'import_playbook': 'test_playbook.yml', 'vars': {'var1': 'var1', 'var2': 'var2'}}

# Generated at 2022-06-11 10:35:22.887758
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    def check_preprocess_data(ds, expect_import_playbook):
        new_ds = AnsibleMapping()
        new_ds.preprocess_data(ds)
        assert (expect_import_playbook == new_ds['import_playbook'])

    # First test: no space between - name: and the playbook file

# Generated at 2022-06-11 10:35:34.670858
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    test_filename = 'test_file.yml'
    test_params = 'a=1 b=2 c=3'
    test_params_dict = {'a': 1, 'b': 2, 'c': 3}

    # Test for input string without params and without vars
    ds_obj = AnsibleMapping({'import_playbook': test_filename})
    ds_obj.ansible_pos = (1, 0)
    ds = ds_obj

    test_obj = PlaybookInclude()
    new_ds = test_obj.preprocess_data(ds)

    assert isinstance(new_ds, dict)
    assert len(new_ds) == 1
    assert new_ds['import_playbook'] == test_

# Generated at 2022-06-11 10:35:44.701033
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    data = {'import_playbook': 'imported_playbook'}
    basedir = './'
    class FooVariableManager(object):
        def get_vars(self):
            return {'a':'b'}

    class FooLoader(object):
        def __init__(self):
            self.file_name = 'imported_playbook'
            self.name = 'imported_playbook'
            self.is_playbook = True

        def load_from_file(self, file_name, class_name, cache=True):
            return 'foo'

    def test_templar(template):
        return template


# Generated at 2022-06-11 10:35:56.468261
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # import_playbook: some_name.yml
    obj = {}
    obj['import_playbook'] = 'some_name.yml'
    obj['vars'] = {}

    pbi = PlaybookInclude()
    new_ds = pbi.load_data(ds=obj, basedir='.')

    assert new_ds.filename is None
    assert len(new_ds._entries) == 1

    obj = {}
    obj['import_playbook'] = 'some_name.yml'
    obj['vars'] = {
        'foo': 'bar',
        'hello': 'world'
    }

    pbi = PlaybookInclude()
    new_ds = pbi.load_data(ds=obj, basedir='.')

    assert new_ds.filename is None

# Generated at 2022-06-11 10:36:07.725961
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play_context import PlayContext

    import os
    import tempfile

    # assert test_PlaybookInclude_load_data()
    basedir = os.path.dirname(__file__)

    create_content = """
    - import_playbook: test_playbook.yml
      tags: test_tag
      when: True
    - import_playbook: test_playbook2.yml
      vars:
        var1: test_var1
    """
    play_var = {
        'var1': 'test_var1'
    }

    def _create_playbook_file(content):
        fd, fname = tempfile.mkstemp(prefix='ansible_test_PlaybookInclude_load_data_')

# Generated at 2022-06-11 10:36:18.186606
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    import os.path

    basedir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..', '..'))

    playbook_path = os.path.join(basedir, 'lib', 'ansible', 'modules', 'system')
    playbook_path2 = os.path.join(basedir, 'lib', 'ansible', 'modules', 'devel')

    p1 = PlaybookInclude.load(
        {'import_playbook': ansible_playbook_dir},
        basedir,
        variable_manager=None,
        loader=None
    )

    assert isinstance(p1, Playbook)

# Generated at 2022-06-11 10:36:29.357805
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude

    pb_include = PlaybookInclude()

    playbook_data = {
        u'hosts': u'all',
        u'vars': {
            u'test': [1, 2, 3],
            u'var2': u'blah',
        },
        u'import_playbook': u'./foo.yml',
    }

    pb = pb_include.load_data(playbook_data, './', None, None)

    assert isinstance(pb, Play)

# Generated at 2022-06-11 10:37:28.638315
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''
    Unit test for method load_data of class PlaybookInclude
    '''

    # Base class load_data method test
    def load_data_dummy(self, ds, basedir, variable_manager=None, loader=None):
        return ds

    PlaybookInclude.load_data = load_data_dummy

    ds = dict(z=10,y=20)
    basedir = 'dummy_basedir'
    variable_manager = 'dummy_variable_manager'
    loader = 'dummy_loader'
    ret = PlaybookInclude().load_data(ds, basedir, variable_manager, loader)
    assert ret == ds
    del PlaybookInclude.load_data

    # play_hosts test

# Generated at 2022-06-11 10:37:39.082904
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    filename = os.path.dirname(__file__) + '/../../lib/ansible/test/test_include.yml'
    data = loader.load_from_file(filename)

    # Verify load_data() creates a Playbook object
    playbook = PlaybookInclude.load(data, loader=loader, variable_manager=variable_manager)
    assert isinstance(playbook, PlaybookInclude)

    # Verify load_data() creates a configured Playbook object with the
    # correct data
    playbook = PlaybookInclude.load(data, loader=loader, variable_manager=variable_manager)

# Generated at 2022-06-11 10:37:52.247474
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role

    test_object_one = PlaybookInclude()
    test_playbook_one = Playbook.load(dict(
        name="Test Playbook One",
        hosts="all",
        gather_facts="no",
        roles=["test_role"]
    ), variable_manager=None, loader=None)
    assert isinstance(test_object_one.load_data(test_playbook_one, basedir=".", variable_manager=None, loader=None),
                      Playbook)

    test_object_two

# Generated at 2022-06-11 10:38:02.439415
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play
    from copy import deepcopy
    ds_playbook_import_playbook_1 = '''
    - import_playbook: test.yml extra_var="some val" extra_var2=some_var
    '''
    ds_playbook_import_playbook_2 = '''
    - import_playbook: test.yml
    '''
    ds_playbook_import_playbook_3 = '''
    - import_playbook: test.yml vars:
        extra_var: "some val"
        extra_var2: some_var
      tags:
        - tag1
    '''

# Generated at 2022-06-11 10:38:10.982900
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.parsing.yaml.objects import AnsibleSequence

    # create sequence object
    obj = AnsibleSequence()
    # create dictionary object
    dict_obj = AnsibleMapping()
    dict_obj['vars'] = dict()
    dict_obj['vars'] = {'foo': 'bar'}
    obj.append(dict_obj)

    # create instance of class PlaybookInclude
    playbook_include = PlaybookInclude()
    # call method load_data
    playbook = playbook_include.load_data( obj, '/usr/bin' )

    assert playbook

# Generated at 2022-06-11 10:38:23.033208
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''
    PlaybookInclude.load_data
    '''

    from ansible.playbook import Playbook

    class TPlaybookInclude(PlaybookInclude):
        pass

    class TPlaybook(Playbook):
        pass

    # Setup test objects
    p = TPlaybook()
    p._load_playbook_data = lambda file_name, variable_manager, vars: TPlaybook()._load_playbook()

    playbook_include = TPlaybookInclude()
    playbook_include.import_playbook = 'myfile.yml'
    playbook_include.vars = dict(key1='value1')

    # Test first code path
    result = playbook_include.load_data(ds=None, basedir=None, variable_manager=None, loader=None)

    # Alternatively, result being None would

# Generated at 2022-06-11 10:38:32.857222
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import ansible.playbook.base as base
    import ansible.playbook.play as play

    # Create a PlaybookInclude object
    my_PlaybookInclude = playbookinclude.PlaybookInclude()

    # Create a mock data structure to use for this unit test
    my_data = dict(
            import_playbook="foo.yml",
        )

    # Create a mock loader which we can use for this unit test
    import ansible.parsing.dataloader
    from ansible.parsing.yaml.objects import AnsibleMapping
    class MockLoader:
        def get_basedir(self, x):
            return("./foo")

    # Create a mock variable_manager which we can use for this unit test
    class MockVariableManager:
        def get_vars(self):
            return dict

# Generated at 2022-06-11 10:38:37.882574
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    ds = {'include': './test_include_playbook.yml'}
    parent_basedir = os.path.dirname(os.path.realpath(__file__)) + "/test_vars_files"
    pb = PlaybookInclude().load(ds=ds, basedir=parent_basedir)
    assert isinstance(pb, PlaybookInclude)
    pb = pb.load_data(ds=ds, basedir=parent_basedir)
    assert isinstance(pb, PlaybookInclude)