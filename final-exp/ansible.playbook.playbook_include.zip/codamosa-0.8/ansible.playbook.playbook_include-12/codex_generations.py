

# Generated at 2022-06-11 10:28:51.880822
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    with open(os.path.join(os.path.dirname(__file__), 'pb_include_test.yml')) as f:
        data = f.read()

    result = PlaybookInclude.load(data, ".")
    assert result.import_playbook == './test_playbook.yml'
    assert result.vars['diff'].__class__.__name__ == 'bool'
    assert result.vars['diff'] == True
    assert result.tags[0] == 'tag1'
    assert result.tags[1] == 'tag2'
    assert result.tags[2] == 'tag3'
    assert result.when == ['test_var == "test"']

# Generated at 2022-06-11 10:28:56.743976
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include = PlaybookInclude().load_data({'import_playbook': 'playbook_included_sample'}, None, None, None)
    assert playbook_include.vars == {'value': 'value_defined'}
    assert playbook_include.import_playbook == 'playbook_included_sample'

# Generated at 2022-06-11 10:29:09.186276
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext

    pm = PlaybookInclude()
    pm.import_playbook = '../../../data/playbook_include.yml'
    basedir = os.path.dirname(os.path.abspath(__file__))
    pm.load_data(ds={}, basedir=basedir)

    assert len(pm._entries) == 1
    assert isinstance(pm._entries[0], Play)
    assert pm._entries[0].name == 'name1'
    assert pm._entries[0]._included_path == os.path.join(basedir, '../../../data')
    assert isinstance(pm._entries[0]._play_context, PlayContext)
    assert pm._entries

# Generated at 2022-06-11 10:29:16.181794
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Simple test with one parameter
    pb_include = PlaybookInclude()
    ds = AnsibleMapping({'import_playbook': '../my_playbook.yml'})
    pb_include.preprocess_data(ds)
    for k in ['import_playbook']:
        assert k in pb_include._attributes, "%s missing" % k

    # Test with a full path
    pb_include = PlaybookInclude()
    ds = AnsibleMapping({'import_playbook': 'file:///path/to/my_playbook.yml'})
    pb_include.preprocess_data(ds)
    for k in ['import_playbook']:
        assert k in pb_include._attributes, "%s missing" % k

    # Test with multiple parameters
    p

# Generated at 2022-06-11 10:29:29.903404
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook

    playbook = Playbook()
    play     = Play()
    playbook._entries.append(play)
    playbook._variable_manager = None
    playbook._loader           = None
    playbook._basedir          = None

    # Test standard usage of playbook import
    display.verbosity = False
    playbook_include = playbook.load('import_playbook: imported.yml tags=tag_include,tag2_include')
    assert playbook_include._entries[0]._included_path is None
    assert playbook_include._entries[0].tags == [u'tag_include', u'tag2_include']
    assert playbook_include._entries[0].vars == {}

    # Test standard usage with additional parameters

# Generated at 2022-06-11 10:29:39.474196
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''
    This function tests load_data method of class PlaybookInclude
    '''
    import mock
    from collections import namedtuple
    from ansible.playbook.playbook_include import PlaybookInclude
    # Create mocks
    basedir = '/home/user/'
    variable_manager = mock.MagicMock()
    loader = mock.MagicMock()
    # Create Variables
    templar = namedtuple('templar', ['template'])
    file_name = templar('import_playbook')
    resource = namedtuple('resource', ['pb', 'col'])
    playbook = resource(file_name, True)
    playbook.pb = file_name
    playbook.col = True
    playbook_collection = resource('/home/user/tests/import_playbook', True)
   

# Generated at 2022-06-11 10:29:41.112761
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-11 10:29:54.056987
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    cur_dir = os.path.dirname(os.path.realpath(__file__))

    ds = {'vars': {}}
    ds['import_playbook'] = 'include_playbook'
    ds['_import_playbook'] = 'include_playbook'
    basedir = "./"

    # the new, cleaned datastructure, which will have legacy
    # items reduced to a standard structure
    new_ds = AnsibleMapping()
    ds['_import_playbook'] = 'include_playbook'
    ds['import_playbook'] = 'include_playbook'

    pbi = PlaybookInclude()
    vars_data = dict()

    # test for normal case
    variable_manager = MagicMock(get_vars=vars_data)
    new_ds

# Generated at 2022-06-11 10:30:04.709219
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader

    # Create a DataLoader
    loader = DataLoader()

    # Create a playbook inclusion
    playbook_inclusion = {
        "tasks": [
            {
                "include_tasks": "tasks.yaml"
            }
        ],
        "vars": {
            "foo": "bar",
            "boo": "baz"
        }
    }

    # Load it
    playbook_inclusion = AnsibleLoader(playbook_inclusion, loader).get_single_data()

    # Pre-process it
    playbook_inclusion = PlaybookInclude().preprocess_data(playbook_inclusion)

    # Check that the pre-processed playbook inclusion matches what

# Generated at 2022-06-11 10:30:05.252787
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:30:11.476534
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data(): pass

# Generated at 2022-06-11 10:30:22.152995
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    import ansible.playbook.play
    import ansible.playbook

    ansible.constants.DEFAULT_PLAYBOOK_PATH = os.path.join(os.getcwd(), 'test_data')
    playbook_include = PlaybookInclude()

    # Test case 1: Try to load the include playbook with 'when' parameter
    playbook_include.vars = {'test_var': 'foo'}
    playbook_include.import_playbook = 'test_include_playbook.yml'
    playbook_include.when = ['foo == true']
    playbook = playbook_include.load_data(ds=None, basedir='.', loader=None)

    # Assert the number of entry in the playbook after loading the playbook for include statement
    assert len(playbook._entries) == 1

    # Assert the entry type loaded

# Generated at 2022-06-11 10:30:32.386671
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    class AttrDict(dict):
        def __init__(self, *args, **kwargs):
            super(AttrDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    input = AttrDict(dict(
        import_playbook = 'test/test_playbook_include.yml',
        vars = dict(b = 'test/test_playbook_include2.yml'),
        cond = dict(a = 'test/test_playbook_include3.yml')))

    pbi = PlaybookInclude().load(input, basedir='/')
    assert isinstance(pbi, Play)

# Generated at 2022-06-11 10:30:35.862756
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Create input data
    import os
    data = '---\nimport_playbook: test_file.yml\n'
    playbook_include = PlaybookInclude()

    # Run test
    playbook_include.load_data(data, 'test_dir', None)

    # Verify result
    assert playbook_include.import_playbook == 'test_file.yml'

# Generated at 2022-06-11 10:30:46.519359
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.parsing.dataloader import DataLoader

    # Prepare a dataloader object
    mock_loader_obj = DataLoader()

    # Initialize a Playbook object with dataloader object
    pb = Playbook.load(ds=None, variable_manager=None, loader=mock_loader_obj)

    # Load data into Playbook object
    pb_include = PlaybookInclude.load(data={"import_playbook": "./../hello.yml"}, basedir="", variable_manager=None, loader=mock_loader_obj)

    # Assert that the

# Generated at 2022-06-11 10:30:58.286092
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude

    test_task_include = TaskInclude()
    test_task_include.name = "test-task-include"
    test_task_include.tags = ["test-task-include-tags"]

    test_play = Play()
    test_play.name = "test-play"
    test_play.tasks = [test_task_include]
    test_play.tags = ["test-play-tags"]

    test_playbook = Playbook()
    test_playbook.entries = [test_play]
    test_playbook.tags = ["test-playbook-tags"]
    test_playbook.handlers = []

    test_playbook_include = PlaybookInclude()
    test_play

# Generated at 2022-06-11 10:31:05.694240
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    class_import = PlaybookInclude()
    # Testing the case that is not a dict
    ds = 'test'
    result = class_import.preprocess_data(ds)
    assert result is None

    # Testing the case that import_playbook is missing
    ds = dict(
        playbook='/test/test.yml',
        vars=dict(
            A='A',
            B='B',
            C='C'
        ),
        connection='local',
        remote_user='root',
        when='',
        tags=['test_tag']
    )
    result = class_import.preprocess_data(ds)

# Generated at 2022-06-11 10:31:17.934480
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    print()
    print('TEST - function load_data of class PlaybookInclude')
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.handler
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.module_utils.six import string_types

    # Add the plugins directory to the python path
    add_all_plugin_dirs()

    # Create the loader object
    loader = DataLoader()

    #templar
    variable_manager = VariableManager()

# Generated at 2022-06-11 10:31:28.106821
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os
    import sys
    import unittest

    class TestPlaybookIncludeLoadData(unittest.TestCase):
        @classmethod
        def setUpClass(cls):
            cls.test_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), 'test_data'))
            sys.path.append(cls.test_dir)

        def setUp(self):
            from ansible.module_utils.common._collections_compat import MockLoader
            self.loader = MockLoader()

        def test_load_data(self):
            from ansible.module_utils.common._collections_compat import MockVariableManager
            from ansible.vars.manager import VariableManager

            # ansible/ansible#76020 - test that import_

# Generated at 2022-06-11 10:31:41.006624
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.template import Templar
    from ansible.utils.collection_loader._collection_finder import _get_collection_name_from_path, _get_collection_playbook_path
    from ansible.module_utils._text import to_text

    templar = Templar(loader=None, variables={})

    # check collection playbook
    file_name = "ansible.builtin.copy"
    resource = _get_collection_playbook_path(file_name)
    playbook = resource[1]
    playbook_collection = resource[2]

# Generated at 2022-06-11 10:31:47.236768
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:31:56.306342
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include = PlaybookInclude()

    # Test case #1: Preprocess_data with vars
    ds = {'import_playbook': 'playbook.yml', 'vars': {'a':'1', 'b':'2'}}
    new_ds = {'import_playbook': 'playbook.yml', 'vars': {'a':'1', 'b':'2'}}
    assert playbook_include.preprocess_data(ds) == new_ds

    # Test case #2: Preprocess_data without vars
    ds = {'import_playbook': 'playbook.yml', 'a': '1', 'b': '2'}

# Generated at 2022-06-11 10:31:56.900359
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:32:07.959924
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import ansible.playbook.playbook_include as playbook_include
    import ansible.playbook.playbook as playbook_main

    test_object = playbook_include.PlaybookInclude()
    test_object.load_data(ds="this is not a dict", basedir="this is not a dict", variable_manager="this is not a dict", loader="this is not a dict")

    # call test method
    # We are just testing that the method can run successfully. We are not checking for correctness.
    res = test_object.load_data(ds={}, basedir="this is not a dict", variable_manager="this is not a dict", loader="this is not a dict")
    assert isinstance(res, playbook_main.Playbook)



# Generated at 2022-06-11 10:32:16.562602
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # FIXME: this is not a great unit test, it's not even asserting anything.
    # It's just here to prevent zillion of warning on the console.
    # We need to test the following:
    # * test if it returns a Playbook object.
    # * test with and without basedir, with absolute and relative path
    # * test that all vars are correctly passed to the new playbook
    data = dict(import_playbook='/tmp/test.yml')
    basedir = '/tmp'
    variable_manager = None
    loader = None

    pb_include = PlaybookInclude()
    pb_include.load_data(data, basedir, variable_manager, loader)

# Generated at 2022-06-11 10:32:17.051370
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:32:24.096062
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play_context import PlayContext

    pb_include = PlaybookInclude.load(dict(import_playbook="test_import.yml", vars=dict(var1="x1"), tags=["tag1"]), "/tmp", PlayContext())
    assert pb_include._import_playbook == "test_import.yml"
    assert pb_include._vars == dict(var1="x1")
    assert pb_include.tags == ["tag1"]


# Generated at 2022-06-11 10:32:36.358669
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.module_utils._text import to_text
    from ansible.parsing.yaml import safe_load, safe_dump
    from ansible.template import Templar
    from ansible.vars import VariableManager

    def test_import_from_path(basedir, when_conditional_expr, ds, playbook_vars, expected_result):

        # playbooks to be imported
        playbook_dir = os.path.dirname(__file__)
        playbook_path = os.path.join(playbook_dir, 'playbook_include_playbooks')

        # variables required to test PlaybookInclude.load_data
        loader = None
        variable_manager = VariableManager()
        variable_manager.set_inventory(loader.inventory)
        variable_manager.extra_vars = playbook_vars
        tem

# Generated at 2022-06-11 10:32:42.660029
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import ansible
    from ansible import constants as C
    file_name = "./test/ansible/playbook/test_playbook_include.yaml"
    pb_include = PlaybookInclude.load(load_from_file=file_name, variable_manager=None, loader=None)
    assert pb_include != None
    assert len(pb_include._entries) == 1
    assert hasattr(pb_include._entries[0],'name')
    assert pb_include._entries[0].name == 'Include me'

# Generated at 2022-06-11 10:32:43.811060
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-11 10:33:03.232843
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook

    playbook_include = PlaybookInclude()

    data = dict(
        import_playbook = "test/test_playbooks/playbook_include_test1.yml"
    )

    basedir = "."

    playbook = playbook_include.load_data(data, basedir)

    assert isinstance(playbook, Playbook)
    assert len(playbook._entries) == 1
    assert playbook._entries[0].get_name() == "test1"
    assert playbook._entries[0].vars == {'local_var': 'local value'}


# Generated at 2022-06-11 10:33:10.137827
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    print("Test PlaybookInclude.load_data()")
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Test case 1:
    # Test that when there is only pre_tasks and tasks, the loaded
    # playbook has 1 pre_task and 2 tasks, and that they are of the
    # correct type.
    #p = PlaybookInclude()
    d = dict()
    d['import_playbook'] = "play1.yml"
    d['vars'] = {'a': 'b'}
    p = PlaybookInclude

# Generated at 2022-06-11 10:33:21.535619
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Test to see if a conditional Playbook is constructed correctly

    class PlaybookIncludeLoadData(PlaybookInclude):
        pass

    # Test whether yaml-object is correctly converted to a PlaybookIncludeLoadData
    test_object = PlaybookIncludeLoadData.load(dict(import_playbook="playbook.yml"), basedir='')
    assert isinstance(test_object, PlaybookIncludeLoadData)
    assert test_object._import_playbook == 'playbook.yml'

    class PlaybookIncludeLoadData(PlaybookInclude):
        _import_playbook = FieldAttribute(isa='string')
        _tags = FieldAttribute(isa='string')
        _vars = FieldAttribute(isa='dict', default=dict)
        _when = FieldAttribute(isa='list', default=[])

    # Test whether

# Generated at 2022-06-11 10:33:31.893884
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import yaml
    # Setup fake playbook data to use in tests
    playbook1_data = yaml.safe_load('''
        - import_playbook: ../test.yml
    ''')

    playbook2_data = yaml.safe_load('''
        - import_playbook: /test.yml
    ''')

    playbook3_data = yaml.safe_load('''
        - import_playbook: test.yml
    ''')

    playbook4_data = yaml.safe_load('''
        - import_playbook: ../test.yml
    ''')


# Generated at 2022-06-11 10:33:40.180262
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    """ unit testing for PlaybookInclude.load_data """

    # just try to get an instance of the object in order to call load_data
    import ansible.playbook.playbook_include
    import ansible.playbook.play
    import ansible.playbook.playbook

    test_variable_manager = dict()
    test_loader = dict()
    test_playbook = ansible.playbook.playbook.Playbook()
    test_playbook._load_playbook_data = lambda filename, variable_manager, vars=None, loader=None: None

    test_PlaybookInclude = ansible.playbook.playbook_include.PlaybookInclude()
    test_PlaybookInclude.load_data(ds=dict(), basedir='', variable_manager=test_variable_manager, loader=test_loader)

# Generated at 2022-06-11 10:33:41.236481
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    assert False, "not implemented"

# Generated at 2022-06-11 10:33:54.441630
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    ds = dict(import_playbook='/file/name.yml', tags=['tag'], vars=dict(key='value'))
    pb = PlaybookInclude().load_data(ds, 'basedir')
    assert isinstance(pb, Playbook)
    entry = pb._entries[0]
    assert isinstance(entry, Play)
    assert entry._included_path == 'basedir'
    assert entry._included_conditional == []
    assert entry.vars == dict(key='value')
    assert entry.tags == ['tag']


# Generated at 2022-06-11 10:34:01.367469
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    class Object(object):
        pass
    basedir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', 'playbook_include')
    playbook_file = os.path.join(basedir, 'import_file.yml')
    import_file = os.path.join(basedir, 'include_file.yml')
    PlaybookInclude.load(data={'import_playbook': import_file, 'vars': {'bar': 'baz'}}, basedir=basedir)
    vars = {'bar': 'baz', 'foo': 'foo'}
    # Make sure that the 'basedir' is set correctly
    class Loader(object):
        def get_basedir(self, path=None):
            self.basedir = based

# Generated at 2022-06-11 10:34:12.490779
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # This is the original YAML text definition
    # of a PlaybookInclude
    yaml_str = '''
        import_playbook: test_playbook_include1.yml
        vars:
          var1: abc
          var2: xyz
        tags:
          - test
        when:
          - '1 == 1'
        '''

    # This is the expected output after conversion
    # to a Python dictionary using preprocess_data

# Generated at 2022-06-11 10:34:24.102278
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    basic_playbook_include_data = '''
    - import_playbook: xml_playbook.yml
      tags: [ basic ]
    '''
    yaml_obj = AnsibleBaseYAMLObject.load(basic_playbook_include_data)
    playbook_include = PlaybookInclude.load(yaml_obj[0], '../test/test_collections/ansible_collections/testns/testcoll/')
    assert playbook_include._import_playbook == 'xml_playbook.yml'
    assert playbook_include._vars == {}

    vars_playbook_include_data = '''
    - import_playbook: xml_playbook.yml
      vars:
        some_var: some_value
      tags: [ basic ]
    '''

# Generated at 2022-06-11 10:34:35.142674
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-11 10:34:47.664844
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    basedir = os.path.join(os.getcwd(), "test")
    inventory = InventoryManager(loader=loader, sources=["test_inventory"])

    variable_manager = VariableManager(loader=loader, inventory=inventory)
    display.verbosity = 3

# Generated at 2022-06-11 10:34:56.284963
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    def get_variable_manager(ds={}):
        from ansible.vars.manager import VariableManager
        from ansible.inventory.manager import InventoryManager
        from ansible.playbook.play_context import PlayContext
        variable_manager = VariableManager()
        variable_manager.extra_vars = ds
        variable_manager.set_inventory(InventoryManager(['localhost']))
        variable_manager.set_play_context(PlayContext())
        return variable_manager

    pbi = PlaybookInclude()
    ds = dict(import_playbook='/tmp/test-playbook.yml')
    assert pbi.load_data(ds, '/tmp', variable_manager=get_variable_manager()) == None

    ds = dict(vars=dict(var1='value1', var2='value2'))


# Generated at 2022-06-11 10:35:06.962070
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os
    import sys
    import unittest

    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.template import Templar
    from ansible.plugins.loader import collection_loader

    playbookTest = "[playbook]\nplays:\n  - name: Play 1\n    hosts: localhost\n    vars:\n     - name: key1\n       value: value1\n    tasks:\n      - name: Task1\n        ping:\n  - name: Play 2\n    hosts: localhost\n    vars:\n     - name: key2\n       value: value2\n    tasks:\n      - name: Task2\n        ping:\n"

    playbook = Playbook

# Generated at 2022-06-11 10:35:18.627816
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    # set mocked config
    C.config.set_config_file('')
    C.DEFAULT_TRANSPORT = 'local'
    C.HOST_KEY_CHECKING = False
    C.DEFAULT_REMOTE_USER = 'root'
    C.INTERNAL_POLL_INTERVAL = 1
    C.DEFAULT_LOG_PATH = 'ansible.log'
    play_basedir = C.DEFAULT_LOCAL_TMP
    loader = None
    variable_manager = VariableManager()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager.get_vars())
    play_context

# Generated at 2022-06-11 10:35:27.015638
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import sys
    import yaml
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

    test_string = """
        - import_playbook: test_play.yml
    """
    test_playbook = yaml.safe_load(test_string)
    test_import = PlaybookInclude.load(test_playbook, u'.', variable_manager=variable_manager, loader=DataLoader())

    assert isinstance(test_import, Playbook)


# Generated at 2022-06-11 10:35:39.497903
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.playbook.play import Play

    # We use a mock-up of import_playbook, vars and playbook_path to simulate
    # the actual input we are getting
    playbook = dict(import_playbook='test.yml', vars=dict(var1='value1', var2='value2'),
                    playbook='/home/user/test.yml')

    # We use a mock-up of Playbook class, as the Playbook class inherits
    # from Base, so we need a separate class to simulate the actual object.
    # The result is a dictionary where keys are the actual imported plays
    # and the values are the vars for those plays

# Generated at 2022-06-11 10:35:47.331624
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import ansible.playbook.playbook_include as playbook_include
    obj = playbook_include.PlaybookInclude()

    # Create a valid ds
    ds = {
        'hosts': 'hostname',
        'tasks': [
            {
                'name': 'Task 1',
                'action': 'shell',
                'args': 'echo "1"'
            },
            {
                'name': 'Task 2',
                'action': 'shell',
                'args': 'echo "2"'
            }
        ]
    }
    # Create a valid basedir
    basedir = "/some/dir"

    # Create a valid variable_manager (empty)
    variable_manager = "/the/variable/manager"

    # Create loader object
    import ansible.parsing.dataloader as dataload

# Generated at 2022-06-11 10:35:59.969365
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    import tempfile

    # Create temporary file
    fd, temp_path = tempfile.mkstemp(text=True)
    with os.fdopen(fd, 'wb') as temp_file:
        temp_file.write("""
- hosts: app
  tasks:
  - name: task1
    debug: msg="task1"
  - name: task2
    debug: msg="task2"
    when: false
- hosts: db
  tasks:
  - name: task1
    debug: msg="task1"
  - name: task2
    debug: msg="task2"
    when: false
""")

# Generated at 2022-06-11 10:36:10.100448
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    ds = dict(
        import_playbook = '../test_import.yml',
        tags  = 'tag1,tag2',
        vars  = dict(
            key1 = 'value1',
            key2 = 'value2',
        )
    )
    pbi = PlaybookInclude()
    pb = pbi.load_data(ds, basedir='.')

    assert isinstance(pb, Playbook)
    assert pb
    assert pb.file_name
    assert pb.file_name == '../test_import.yml'


# Generated at 2022-06-11 10:36:29.760313
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:36:39.280086
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pbi = PlaybookInclude()
    playbook_path = "/tmp/playbook"
    playbook_path_2 = "/tmp/playbook_2"
    playbook_file_1 = "include.yml"
    playbook_file_2 = "include_2.yml"
    playbook_1 = playbook_path + "/" + playbook_file_1
    playbook_2 = playbook_path_2 + "/" + playbook_file_2
    data_1 = {'import_playbook': playbook_1}
    data_2 = {'import_playbook': playbook_2}
    var_manager = None
    loader = None
    assert pbi.load_data(data_1, playbook_path, variable_manager, loader) == pbi.load_data(data_2, playbook_path, variable_manager, loader)




# Generated at 2022-06-11 10:36:49.187846
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.errors import AnsibleParserError
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    def _load_data(ds, basedir, variable_manager=None, loader=None):
        return PlaybookInclude().load_data(ds=ds, basedir=basedir, variable_manager=variable_manager, loader=loader)

    # Check that we raise if ds is not a dict

# Generated at 2022-06-11 10:36:50.102737
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # TODO
    pass


# Generated at 2022-06-11 10:36:54.491699
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    pb = PlaybookInclude()

    new_obj = pb.load_data("/foo/bar.yml", "/fake/path")
    assert isinstance(new_obj, Playbook)

# Generated at 2022-06-11 10:36:58.143097
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Create a simple playbook include and check that it loads correctly
    test_include = PlaybookInclude()

    test_include.load_data(ds="external_playbook.yml", basedir=".")

    assert isinstance(test_include, PlaybookInclude)

# Generated at 2022-06-11 10:37:04.997006
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.errors import AnsibleParserError
    from ansible.playbook.playbook import Playbook
    from ansible.parsing.dataloader import DataLoader

    data = "---\n- import_playbook: other_playbook.yml"

    # test creation of Playbook
    import tempfile
    with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8') as f:
        f.write(data)
        f.flush()
        p = PlaybookInclude.load(f.name, '.', loader=DataLoader())
        assert isinstance(p, Playbook)

    # test error handling for missing import_playbook
    data = "---\n- import_playbook: "

# Generated at 2022-06-11 10:37:06.945780
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    #TODO Add a unit test for method load_data of class PlaybookInclude
    pass

# Generated at 2022-06-11 10:37:17.300790
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.base import Base
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory import Inventory
    # mocks
    class MockPlaybook(Base):
        def __init__(self, loader=None):
            self._entries = []
            self.loader = loader
        def _load_playbook_data(self, file_name=None, variable_manager=None, **kwargs):
            if self.loader is None:
                self.loader = DataLoader()
            result = self.loader.load_from_file(file_name)
            self._entries = [Play.load(result, variable_manager=variable_manager)]
    # mocks end
   

# Generated at 2022-06-11 10:37:26.976897
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    loader = DictDataLoader({})
    pb = PlaybookInclude.load({'include_playbook': 'my_playbook.yaml vars=my_var=a'}, basedir='.', loader=loader)

    assert isinstance(pb, Playbook)
    assert len(pb.get_plays()) == 1

    play = pb.get_plays()[0]
    assert play.vars == {'my_var': 'a'}
    assert play._included_path == os.path.abspath('.')
    assert play._included_file == os.path.abspath('my_playbook.yaml')

# Generated at 2022-06-11 10:37:57.575844
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    import os
    import sys
    import tempfile

    #import_playbook = os.path.join(tempfile.gettempdir(), 'playbook.yml')
    import_playbook = tempfile.mkdtemp()

    # create playbook
    playbook_path = os.path.join(tempfile.mkdtemp(), 'playbook.yml')
    with open(playbook_path, 'w') as pb:
        pb.write('''- hosts: all
  tasks:
    - name: test
      ping:''')

    playbook = os.path.join(tempfile.mkdtemp(), 'playbook.yml')
    playbook_dir = os.path.dirname(playbook)


# Generated at 2022-06-11 10:38:07.258936
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play_context import PlayContext

    from ansible.playbook.play_context import PlayContext
    # test included playbook with variables (external vars)
    pc = PlayContext()
    pc.extra_vars = dict(x=42)
    p = PlaybookInclude()
    p.load_data(dict(import_playbook='test.yml'), basedir='/tmp', variable_manager=pc)
    assert p.vars == dict(x=42)

    # test included playbook with variables (params)
    pc = PlayContext()
    pc.extra_vars = dict(x=42)
    p = PlaybookInclude()
    p.load_data(dict(import_playbook='test.yml vars=foo=bar'), basedir='/tmp', variable_manager=pc)

# Generated at 2022-06-11 10:38:18.528130
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.module_utils._text import to_bytes
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.parsing.yaml.loader import AnsibleLoader

    lines = b'''
- import_playbook: ./foo.yml
  tags:
    - always
'''
    playbookinclude = PlaybookInclude.load(AnsibleLoader(None, list(), list()).load(lines)[0], None)
    playbookinclude.preprocess_data(playbookinclude.ds)
    assert 'import_playbook' in playbookinclude._ds
    assert 'tags' in playbookinclude._ds
    assert playbookinclude._ds['import_playbook'] == './foo.yml'
    assert playbookinclude._ds['tags'] == ['always']


# Generated at 2022-06-11 10:38:29.421173
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook

    # setup the test
    from ansible.playbook import Play
    from ansible.playbook.task import Task
    from ansible.inventory.manager import InventoryManager

    loader, inventory, variable_manager = MockLoader.mock_loader()

    pb = Playbook()
    pb.set_loader(loader)

    p = Play()
    t = Task()
    p.add_task(t)
    pb.add_play(p)

    # make sure that the PlaybookInclude.load_data method returns a
    # Playbook object when an include is present in the datastructure
    data = dict(
        include='playbook.yml'
    )
    pi = PlaybookInclude.load(data, os.getcwd(), variable_manager, loader)


# Generated at 2022-06-11 10:38:37.301720
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    import ansible.playbook.block as block

    ds = dict(
        import_playbook='foo/bar/baz.yml',
        tags=['tag1', 'tag2'],
        vars=dict(
            test=True,
        ),
    )

    ds_block = dict(
        block=dict(
            import_playbook='foo/bar/baz.yml',
            tags=['tag1', 'tag2'],
            vars=dict(
                test=True,
            ),
        ),
    )

    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    # test import a playbook with a single play
    # this is to ensure