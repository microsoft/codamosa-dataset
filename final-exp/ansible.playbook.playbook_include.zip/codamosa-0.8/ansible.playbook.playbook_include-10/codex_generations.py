

# Generated at 2022-06-11 10:28:52.657732
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext

    from ansible.playbook.play import Play
    from ansible.playbook.block import Block

    p = Play().load({
        'name': 'test play',
        'hosts': 'all',
        'user': 'root',
        'tasks': [
            {'action': {'module': 'debug', 'args': 'var=v1'}},
            {'block': {
                'name': 'test block',
                'block': [
                    {'action': {'module': 'debug', 'args': 'var=v3'}},
                    {'action': {'module': 'debug', 'args': 'var=v4'}},
                ]}},
        ]
    })

    v = p.get_vars()

# Generated at 2022-06-11 10:28:53.964534
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    raise NotImplementedError

# Generated at 2022-06-11 10:29:05.844786
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    ds = {'import_playbook': 'some_playbook.yml',
          'tags': 'tag_one,tag_two',
          'vars': {'a': 'b',
                   'c': 'd'}}
    new_ds = PlaybookInclude().preprocess_data(ds)
    assert 'import_playbook' in new_ds
    assert 'tags' in new_ds
    assert 'vars' in new_ds
    assert new_ds['import_playbook'] == 'some_playbook.yml'
    assert new_ds['tags'] == 'tag_one,tag_two'
    assert new_ds['vars']['a'] == 'b'
    assert new_ds['vars']['c'] == 'd'


# Generated at 2022-06-11 10:29:14.706162
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    playbook = '''
    - import_playbook: playbook_one.yml
      tags:
        - always
        - test_tag
    '''
    ds = AnsibleLoader(playbook, '', '', True).get_single_data()
    new_ds = PlaybookInclude.load(ds, '').preprocess_data(ds)
    assert isinstance(new_ds, AnsibleMapping)
    assert new_ds['import_playbook'] == 'playbook_one.yml'
    assert new_ds['tags'] == ['always', 'test_tag']
    assert 'vars' not in new_ds
    assert 'when' not in new_

# Generated at 2022-06-11 10:29:27.837675
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # first, we test the normal usage of playbook_include, which is to specify
    # the playbook to import and any parameters such as tags or vars
    ds = { 'import_playbook': 'other.yml', 'tags': 'foo,bar', 'vars': { 'var1': 'foo', 'var2': 'bar' } }
    ds_obj = PlaybookInclude.load(ds, None)
    assert 'import_playbook' in ds_obj._ds
    assert 'tags' in ds_obj._ds
    assert 'vars' in ds_obj._ds
    assert ds_obj.import_playbook == 'other.yml'
    assert ds_obj.tags == ['foo', 'bar']

# Generated at 2022-06-11 10:29:38.519563
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = '''
    - include_role:
        name: include_role_base_test
        tasks_from: import_playbook_base_test
    '''
    yaml_data = AnsibleLoader(data, file_name='includes-test').get_single_data()

    pbi = PlaybookInclude()
    pbi.load_data(yaml_data[0]['include_role'], basedir='/tmp')

    pb = PlaybookInclude.load(yaml_data[0]['include_role'], '/tmp')
    assert pb != None

    play = pb.get_plays()[0]
    assert play != None

    # Create a

# Generated at 2022-06-11 10:29:51.246748
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Check we can handle the case where we have a relative playbook
    # location and a variable set in include_tasks.
    # Note the key here is that both relative and absolute playbook
    # paths are valid and we want to ensure that the include_tasks
    # variable is set.
    var_manager = 'foo'
    basedir = '/etc/ansible'
    loader = 'bar'
    data = AnsibleMapping()
    data['import_playbook'] = 'simple_play.yml'
    data['vars'] = dict(include_tasks='/tmp/roles/test_role/tasks/main.yml')
    include_task = PlaybookInclude()
    pb = include_task.load_data(data=data, basedir=basedir, variable_manager=var_manager, loader=loader)

# Generated at 2022-06-11 10:30:02.853778
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    def data(string):
        return dict(args=dict(string=PlaybookInclude.load(string, basedir='.', variable_manager=VariableManager(), loader=DataLoader())))

    assert data('imported.yml') == dict(args=dict(string=dict(import_playbook='imported.yml')))
    assert data('imported.yml with_foo=bar') == dict(args=dict(string=dict(import_playbook='imported.yml', vars=dict(with_foo='bar'))))

# Generated at 2022-06-11 10:30:10.419901
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    data = '''
    - include: testinc.yml
      when:
        - result.rc == 0
    '''
    from ansible.playbook.play import Play
    test_play = Play()
    test_play.vars = {}
    test_play.tags = []
    playbook_include = PlaybookInclude.load(data, '/test/a/basedir/', variable_manager=None, loader=None)
    # check that we have the right length
    assert len(playbook_include._entries) == 1
    # check that we have the right includable
    assert isinstance(playbook_include._entries[0], Play)
    # check that we have the right name
    assert playbook_include._entries[0].name == 'testinc.yml'
    # check that we have the right path

# Generated at 2022-06-11 10:30:20.933812
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler

    pbi = PlaybookInclude()

    playbookObject = pbi.load(
        ds=[
            dict(
                import_playbook="playbook.yml"
            ),
        ],
        basedir=".",
        variable_manager=None,
        loader=None
    )

    assert isinstance(playbookObject, Playbook)

    assert len(playbookObject._entries) == 1
    assert playbookObject._entries[0].file_name == "playbook.yml"


# Generated at 2022-06-11 10:30:33.037692
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    mock_loader = {}
    mock_variable_manager = {}

    mock_playbook = PlaybookInclude()
    mock_playbook.load_data(ds={
        'import_playbook': './other/import-playbook.yml'
    }, basedir='/path/to', variable_manager=mock_variable_manager, loader=mock_loader)

    assert mock_playbook.import_playbook == './other/import-playbook.yml'
    assert mock_playbook.tags == []
    assert mock_playbook.vars == {}

# Generated at 2022-06-11 10:30:38.457070
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''
    This method tests the load_data method of the class PlaybookInclude
    '''

    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.template import Templar

    loader = AnsibleLoader(None, {})

# Generated at 2022-06-11 10:30:49.563810
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    include_not_dict = { "invalid": "value"}
    include_dict_not_str = { "vars": {"var1": "value1", "var2": "value2"}, "import_playbook": {"playbook": "pb.yml"}}
    include_dict_str_no_filename = { "vars": {"var1": "value1", "var2": "value2"}, "import_playbook": " "}
    include_dict_str_filename = { "vars": {"var1": "value1", "var2": "value2"}, "import_playbook": "pb.yml"}

# Generated at 2022-06-11 10:31:01.046579
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import mock
    import ansible.parsing.yaml.objects
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    mock_conditionals = mock.Mock(spec=[])
    mock_str = 'playbook'
    mock_data = mock.MagicMock(spec=ansible.parsing.yaml.objects.AnsibleBaseYAMLObject)
    mock_data_1 = 'data1'
    mock_data_2 = 'data2'
    mock_data_3 = 'data3'
    mock_data_4 = 'data4'
    mock_data_5 = 'data5'
    mock_key_1 = 'key1'
    mock_key_2 = 'key2'
    mock_key_3 = 'key3'

# Generated at 2022-06-11 10:31:09.297607
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Setup
    from ansible.playbook.base import Base
    from ansible.playbook.task.base import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    Base._variable_manager = VariableManager()
    Base._loader = DataLoader()
    Task._loader = Base._loader
    Task._variable_manager = Base._variable_manager
    playbook_include = PlaybookInclude()
    playbook_include.load_data("", u"/path/to/ansible_module/molecule/default/playbooks")
    # Teardown



# Generated at 2022-06-11 10:31:22.025923
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.play import Play

    data = AnsibleUnicode('../test/testdata/playbooks/included_playbook.yml')
    basedir = '../test/testdata/playbooks'

    result = PlaybookInclude.load(data, basedir)

    assert len(result._entries) == 1

    result2 = result._entries[0]

    assert isinstance(result2, Play)
    assert result2.name == 'Included Playbook'
    assert result2.hosts == 'all'
    assert result2.vars['key'] == 'value'
    assert result2.tasks[0].action == 'debug'

# Generated at 2022-06-11 10:31:29.816588
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.splitter import parse_kv

    data = AnsibleLoader(None, None).load('''
    - import_playbook: foo.yml foo=bar bar=true baz=1
    ''')

    playbook_include = PlaybookInclude()
    playbook_include.load_data(data[0], None)

    data = AnsibleLoader(None, None).load('''
    - import_playbook: foo.yml
      vars:
        foo: bar
        bar: true
        baz: 1
    ''')

    playbook_include = PlaybookInclude()
    playbook_include.load_data(data[0], None)


# Generated at 2022-06-11 10:31:42.783388
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)
    import_playbook = "test_import.yml"
    ds = {'import_playbook': import_playbook}
    basedir = os.path.dirname(os.path.realpath(__file__))
    actual_result = PlaybookInclude.load(data=ds, basedir=basedir, variable_manager=variable_manager, loader=loader)
    expected_result = "playbook1"
    assert actual_result._entries[0].name

# Generated at 2022-06-11 10:31:51.146622
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.role import Role
    from ansible.collection_loader import AnsibleCollectionLoader

    loader = AnsibleCollectionLoader()
    variable_manager = None
    basedir = os.path.dirname(__file__)
    ds = {'import_playbook': 'test_playbook.yml'}

    pb = PlaybookInclude.load(ds, basedir, variable_manager, loader)
    assert pb._entries[0]._included_path == basedir
    assert pb._entries[1]._included_path == basedir
    assert pb._entries[1]._included_conditional == ['test_condition']
    assert pb._entries[2] == Role._load('test_role', loader, basedir, variable_manager=variable_manager)

# Generated at 2022-06-11 10:32:03.084331
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
  class VarManager(object):
    def __init__(self, vars):
      self.vars = vars
    def get_vars(self, **kwargs):
      return self.vars
  vars = {
    'key1': 'val1',
    'key2': 'val2',
    'key3': 'val3',
    'key4': 'val4',
  }
  varManager = VarManager(vars)
  loader = None


# Generated at 2022-06-11 10:32:17.724749
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play

    basedir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    test_dir = os.path.join(basedir, 'test', 'units', 'test_data')
    # create a playbook with entry
    playbook = os.path.join(test_dir, 'import_playbook_test.yml')
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.executor.task_queue_manager import TaskQueueManager

    variable_manager = VariableManager()

# Generated at 2022-06-11 10:32:29.485431
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # import here to avoid a dependency loop
    from ansible.playbook import Playbook

    # Check whether load will return a Playbook object when import_playbook is set
    # and the file exists
    #
    # This is a very rough test and more cases should be added.
    playbook_include = PlaybookInclude()
    playbook_include.load_data({'import_playbook': '../../test/playbooks/include.yml'}, basedir='../../test/playbooks/')
    assert isinstance(playbook_include, Playbook)

    assert playbook_include.vars['var1'] == 'value1'
    assert playbook_include.vars['var2'] == 'value2'
    assert playbook_include.tags == ['tag1', 'tag2']

# Generated at 2022-06-11 10:32:40.524712
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    import ansible.constants as C
    import ansible.playbook.play_context as play_context

    loader = DataLoader()
    variable_manager = VariableManager()
    display = Display()

    play_context = play_context.PlayContext(loader=loader, variable_manager=variable_manager, passwords={})

    # TODO: This test is largely redundant with the test of the Playbook class
    playbook_data = '''- hosts: localhost
  tasks:
    - debug: var=hostvars["localhost"]["ansible_facts"]["distribution"]
'''
    display.verbosity = 5
    C.DEFAULT_LOAD_CALLBACK_PLUGINS = True

# Generated at 2022-06-11 10:32:50.411190
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode

    data = AnsibleMapping({
        "import_playbook": AnsibleUnicode("helloworld.yaml"),
        "tags": AnsibleUnicode("hello")
    })

    data_loader = DataLoader()
    variable_manager = None
    basedir = "."
    loader = "."

    # Test the normal case
    pbi = PlaybookInclude()
    result = pbi.load_data(data, basedir, variable_manager, data_loader)
    assert isinstance(result, Play)
    assert result.tags == ["hello"]

    # Test empty tags

# Generated at 2022-06-11 10:32:51.204108
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:33:00.412684
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    fake_loader = object()
    playbook_include = PlaybookInclude()
    playbook = playbook_include.load_data(
        ds="""
        - import_playbook: rpcs.yml
        """,
        basedir=(os.path.join(os.path.dirname(__file__), 'fixtures', 'playbook_include')),
        loader=fake_loader,
    )
    # asserts the type
    assert isinstance(playbook, object)
    # asserts the expected number of included playbooks
    assert len(playbook._entries) == 1

# Generated at 2022-06-11 10:33:09.555352
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    import os
    import json

    # sample code that may be used in a unit test
    basedir = os.path.dirname(__file__)
    # Replace 'load_playbook_path()' with 'open()'
    # and remove the line that does a json.load()
    with open(os.path.join(basedir, 'test_include.yaml'), 'r') as f:
        data = f.read()

    # the main method under test
    include = PlaybookInclude.load(data, basedir, variable_manager=VariableManager())
    assert include._entries[0].get_name() == 'test'

# Generated at 2022-06-11 10:33:20.528714
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # import needed to get PlaybookInclude class
    from ansible.playbook.playbook_include import PlaybookInclude
    # Vars to be used in the test
    test_ds ={u'import_playbook': '1.yml', u'vars': {'var1': 'value1', 'var2': 'value2'}, u'tags': 'tag1,tag2,tag3'}
    test_basedir = os.path.expanduser('~/.ansible/collections/ansible_collections/test/test_playbook_include.collection/')
    # Test call
    pb_include = PlaybookInclude.load(test_ds, basedir=test_basedir)
    # Test assertion
    assert pb_include
    # Import needed to get "assert_equal" function

# Generated at 2022-06-11 10:33:31.192024
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    # Create a sample play
    play_data = dict(
        name='Ansible Playbook Include',
        hosts='localhost',
        vars=dict(
            test_var='test_value'
        ),
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='{{ test_var }}')))
        ]
    )

    # Dump the play data to a file
    # First create a temporary directory
    temp_dir = tempfile.mkdtemp(prefix='ansible_test_playbook_include')
    play_file = os.path.join(temp_dir, "play.yaml")
    with open(play_file, 'w') as f:
        yaml.safe_dump

# Generated at 2022-06-11 10:33:39.840796
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode

    TEST_PLAYBOOK = '''
---
'''

    TEST_PLAYBOOK_ENTRY = '''
- debug:
    msg: "{{inventory_hostname}}: {{ hostvars[inventory_hostname]['ansible_facts']['distribution'] }}"
'''

    ds = AnsibleSequence()
    ds.append(TEST_PLAYBOOK_ENTRY)

    playbook_include = PlaybookInclude.load(TEST_PLAYBOOK, '.')

# Generated at 2022-06-11 10:33:56.425845
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import ansible.playbook
    import ansible.playbook.play


# Generated at 2022-06-11 10:33:57.137118
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    print('test_PlaybookInclude_load_data')

# Generated at 2022-06-11 10:34:02.608657
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # first, we use the original parent method to correctly load the object
    # via the load_data/preprocess_data system we normally use for other
    # playbook objects
    new_obj = PlaybookInclude()
    assert new_obj.preprocess_data({"import_playbook": "playbook.yml"}) == {'import_playbook': 'playbook.yml'}

    # then we use the object to load a Playbook
    # pb = Playbook()

# Generated at 2022-06-11 10:34:14.158948
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    context = PlayContext()
    variable_manager = VariableManager(loader=None, inventory=InventoryManager(loader=None, sources=['localhost,']))

    definition = "import_playbook: playbooks/foo.yml"
    ds = {"import_playbook": "playbooks/foo.yml"}

    pbinclude = PlaybookInclude()
    return_value, include_paths = pbinclude.load_data(definition, context, variable_manager)

    assert(return_value.__class__.__name__ == 'Playbook')
    assert(return_value._entries == [])  # return_value.tasks == []

    pbin

# Generated at 2022-06-11 10:34:24.149368
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_dir = os.path.dirname(os.path.dirname(__file__))
    playbook_include_file = os.path.join(playbook_dir, 'examples', 'import_playbook.yml')
    playbook_include_data = open(os.path.join(playbook_dir, 'examples', 'import_playbook.yml')).read()

    loader = None
    variable_manager = None

    playbook_include = PlaybookInclude.load(playbook_include_data, basedir=playbook_include_file, variable_manager=variable_manager, loader=loader)

    assert playbook_include is not None
    assert len(playbook_include._entries) == 1

# Generated at 2022-06-11 10:34:27.364904
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    fi = PlaybookInclude()
    f = fi.load_data("""
    ---
    import_playbook: test.yml
    vars:
       a: 2
     """)
    print(f)


# Generated at 2022-06-11 10:34:28.008127
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-11 10:34:37.896391
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import tempfile
    import os
    import shutil
    from ansible.playbook.play import Play
    # Create temporary directory to store test files
    temp_dir_path = tempfile.mkdtemp()
    test_yaml_file_path = tempfile.mkstemp(prefix='test_import_playbook_1', suffix='.yaml', dir=temp_dir_path)
    test_yaml_file = os.fdopen(test_yaml_file_path[0], "w")
    test_yaml_file.write(
        '- import_playbook: test_import_playbook_2.yaml'
    )
    test_yaml_file.close()

# Generated at 2022-06-11 10:34:50.164306
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar

    ds = dict(
        import_playbook = '../tests/test_data/playbooks/test_include.yml',
        vars = dict(
            x = 1
        )
    )

    playbook = Playbook()
    playbook._loader = None
    playbook._variable_manager = None

    pbi = PlaybookInclude()
    pbi.load_data(ds, '../tests/test_data/playbooks', variable_manager=None, loader=None)

# Generated at 2022-06-11 10:34:57.547973
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    #import here to avoid a dependency loop
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    class MockVariableManager(object):
        def get_vars(self):
            return {'testkey': 'testvalue', 'testkey2': 'testvalue2'}

    basedir = 'test_basedir_'
    playbook_data = {'import_playbook': 'test_playbook.yml'}
    pb_include = PlaybookInclude()
    pb_include.load_data(playbook_data, basedir=basedir, variable_manager=MockVariableManager())

    assert pb_include.import_playbook == 'test_playbook.yml'

# Generated at 2022-06-11 10:35:18.579733
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.module_utils._text import to_text
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block


    class FakePlaybook:
        def __init__(self):
            self._entries = []

        def add_entry(self, entry):
            self._entries.append(entry)

        def __str__(self):
            return "FakePlaybook(%s)" % (",".join(str(e) for e in self._entries))

    class FakeAnsibleError:
        def __init__(self, msg):
            self.msg = msg

    #def display.deprecated(msg, version=None, removed=False):
    #    print("deprecated: %s" % (msg))

   

# Generated at 2022-06-11 10:35:26.760977
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    # Test 1 :
    # Test to see if a playbook can get imported using PlaybookInclude.load_data()
    # we use a simple playbook (dummy.yml) and pass it to load_data()
    # it imports a file from the same directory
    data = AnsibleMapping({u'import_playbook': u'dummy.yml'})
    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory=None)
    results = PlaybookInclude.load(data, basedir="../../lib/ansible/playbook", variable_manager=variable_manager)


# Generated at 2022-06-11 10:35:39.419403
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import mock
    import os
    import sys
    import tempfile
    mock_open = mock.mock_open()
    with tempfile.NamedTemporaryFile() as f:
        f.write(b"---\n")
        f.write(b"import_playbook: resource.yml\n")
        f.flush()
        with mock.patch('ansible.playbook.include.open', mock_open(read_data=f.read())):
            with mock.patch('ansible.playbook.include.os.path.exists', return_value=True):
                PlaybookInclude.load(data=None, basedir=os.getcwd(), variable_manager=None, loader=None)
                mock_open.assert_called_with(os.getcwd() + "/resource.yml")

# Generated at 2022-06-11 10:35:47.154580
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible import context
    from ansible.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    # Prepare a PlaybookInclude object to test.
    yaml_obj = AnsibleMapping({
        'import_playbook': 'foo.yml',
        'vars': {
            'foo': 'bar',
            'bar': 'baz'
        },
        'tags': 'quux'
    })
    # Any regular old PlaybookInclude object won't have `_entries` defined, so
    # we need to load it up with a YAML object to go through the preprocess
    # steps.
    pbi = Playbook

# Generated at 2022-06-11 10:35:57.368335
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play

    import_playbook = 'import_playbook_data'
    basedir = 'basedir_data'
    variable_manager = 'variable_manager_data'
    loader = 'loader_data'

    playbookInclude = PlaybookInclude()
    assert playbookInclude._import_playbook == None

    playbook = playbookInclude.load_data(import_playbook, basedir, variable_manager, loader)

    assert playbookInclude._import_playbook == import_playbook
    assert playbook.loader == loader
    assert playbook._entries[0]._included_path == basedir


# Generated at 2022-06-11 10:36:00.384234
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''
    This is a unit test for load_data method of PlaybookInclude class.
    It is not intended to be ran.
    '''
    raise NotImplemented

# Generated at 2022-06-11 10:36:10.431085
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import sys
    import json # pylint: disable=unused-import

    # Create a AnsibleMapping data structure
    ds = AnsibleMapping()

    # Add entries to it
    ds['import_playbook'] = "playbooks/playbook.yml"
    ds['vars'] = {'var' : 'value'}

    # Here we would get an error
    #ds['import_playbook'] = "/playbooks/playbook.yml"
    #ds['vars'] = {'var' : 'value'}

    # Instantiate a PlaybookInclude object with the data structure
    obj = PlaybookInclude()

    # Call method load_data with the data structure
    pb = obj.load_data(ds=ds, basedir="./tests")

    #
    # Check the

# Generated at 2022-06-11 10:36:11.828672
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    assert False, "TODO"

# Generated at 2022-06-11 10:36:24.290182
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # import here to avoid a dependency loop
    from ansible.playbook import Playbook

    # test PlaybookInclude.load_data()
    pbo = PlaybookInclude()

    # test playbook file path within playbook directory
    playbook_path = "my_playbook.yml"
    basedir = "/home/user/ansible/playbooks"
    expected_file_name = "/home/user/ansible/playbooks/my_playbook.yml"
    pbo.import_playbook = playbook_path
    pbps = pbo.load_data(ds=None, basedir=basedir, variable_manager=None, loader=None)
    assert isinstance(pbps, Playbook), "Loaded playbook is not of type Playbook"

# Generated at 2022-06-11 10:36:34.686154
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import ansible.playbook.playbook_include as playbook_include
    import ansible.playbook.playbook as playbook
    import ansible.inventory.host as host
    import ansible.inventory.group as group
    import ansible.inventory.inventory as inventory
    import ansible.vars.manager as manager
    import ansible.vars.variable_manager as variable_manager
    import ansible.parsing.dataloader as dataloader
    import ansible.utils.vars as vars_module
    from collections import namedtuple

    Options = namedtuple('Options', ['connection', 'module_path', 'forks', 'become', 'become_method', 'become_user', 'check', 'diff', 'listhosts', 'listtasks', 'listtags', 'syntax'])

# Generated at 2022-06-11 10:37:02.805537
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude

    from ansible.parsing.yaml.objects import AnsibleUnicode

    import os
    import shutil
    import tempfile

    ####################
    # create temp directory structure
    #
    # ../temp
    # ../temp/roles
    # ../temp/roles/foo
    # ../temp/roles/foo/tasks
    # ../temp/roles/foo/tasks/main.yml
    # ../

# Generated at 2022-06-11 10:37:03.657221
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-11 10:37:14.571631
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''
    Test case for method load_data of class PlaybookInclude.
    :return:
    '''

    print('Test case for method load_data of class PlaybookInclude')

    # load_data method takes parameters as follows
    #   ds: The data structure object to load
    #   basedir: The directory from which the playbook path is relative to, if the playbook is not an absolute path
    #   variable_manager: The variable manager object for variables substitution
    #   loader: The data loader to resolve templates, if any
    #   **kwargs: Extra parameters to initialize the object, such as import_playbook and tags.

    # Simple test to load data from a file, without parameters

    # Test 1:
    # load_data method takes ds as an absolute path
    # ds: Absolute path
    # basedir: Absolute

# Generated at 2022-06-11 10:37:25.442196
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook

    # import here to avoid a dependency loop
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader

    # First test where the playbook is in a collection installed
    # in the file system
    loader = DataLoader()
    test_file  = os.path.normpath('/etc/ansible/my_collection/docs/my_playbook.yml')
    new_obj = PlaybookInclude.load({'import_playbook': test_file}, None, loader=loader)
    assert isinstance(new_obj, Playbook)
    assert len(new_obj._entries) > 0

# Generated at 2022-06-11 10:37:26.433448
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-11 10:37:36.511908
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.template import Templar

    # Test PlaybookInclude.load_data
    #
    # Note: the method load_data of class PlaybookInclude calls the method
    # load_data of class Base, that method assigns the values of the input
    # data to the attributes of the object. The attributes of the object are
    # mapped to the elements of the input data by their names.
    #
    # The method load_data of class PlaybookInclude calls the method
    # load_data of class Base, that method assigns the

# Generated at 2022-06-11 10:37:37.269601
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:37:49.992327
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    import sys
    import os
    import yaml
    yaml.warnings({'YAMLLoadWarning': False})

    # In order to test the method load_data of class PlaybookInclude, we
    # need to write a sample playbook file, to read and execute it.
    TEST_DATA = '''
    - import_playbook: sample_playbook.yml
    '''

    # Create a sample playbook file
    playbook_path = os.path.join('/tmp', 'test_PlaybookInclude_load_data.yml')
    with open(playbook_path, 'w') as f:
        f.write(TEST_DATA)

    # get an instance of PlaybookInclude
    from ansible.playbook.include import PlaybookInclude
    pi = PlaybookInclude()
    pb = pi

# Generated at 2022-06-11 10:38:00.922163
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os
    import pytest
    import tempfile

    import ansible.collection.collection_finder
    from ansible.playbook.playbook_include import PlaybookInclude

    # reset the playbook path
    playbook_path = tempfile.mkdtemp(prefix='ansible-playbook-include')
    ansible.collection.collection_finder.ANSIBLE_COLLECTIONS_PATH = playbook_path

# Generated at 2022-06-11 10:38:12.663972
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.playbook.play_context import PlayContext
    import os

    loader = AnsibleLoader(None, None)

    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # load the playbook file
    playbook_path = 'test_playbook.yaml'

    with open(playbook_path) as f:
        in_data = f.read()
        f.close()

    playbook = loader.load(in_data)
    playbook = playbook.get_data()

   