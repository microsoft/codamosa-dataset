

# Generated at 2022-06-11 10:28:51.561500
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import ast
    import sys
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy

    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
    from lib import ansible_test_util

    test_dir = os.path.dirname(ansible_test_util.__file__)
    test_dir = os.path.join(test_dir, '../../test/units/module_utils/test_collection_config')

    class TestPlayContext(PlayContext):
        def __init__(self, variable_manager, loader):
            self._variable_manager = variable_manager


# Generated at 2022-06-11 10:29:03.904324
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader

    obj1 = PlaybookInclude.load({
        'import_playbook': 'foo.yml'
        })
    assert isinstance(obj1, PlaybookInclude)
    assert obj1.import_playbook == 'foo.yml'
    assert obj1.vars == {}

    obj2 = PlaybookInclude.load({
        'import_playbook': 'foo.yml',
        'vars': {'key1': 'value1', 'key2': 'value2'}
        })
    assert isinstance(obj2, PlaybookInclude)

# Generated at 2022-06-11 10:29:13.706503
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.play import Play
    from ansible.template import Templar

    file_name = '/path/to/import/playbook.yml'
    data = {'import_playbook': file_name}
    templar = Templar(loader=None, variables={})

    AnsibleCollectionConfig.default_collection = 'test_collection'
    AnsibleCollectionConfig.playbook_paths = ['/a/b/c/d', '/e/f/g/h']
    result_playbook_load_data = PlaybookInclude.load(data=data, basedir='/path/to/basedir/', variable_manager=None, loader=None)
    assert isinstance(result_playbook_load_data, Play)

# Generated at 2022-06-11 10:29:26.391314
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    from ansible.playbook.play import Play
    from ansible.playbook.plays import PlayIterator
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.taggable import Tag
    from ansible.playbook.handler import Handler
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # AnsibleMapping does not have a copy method in Ansible 2.10
    # AnsibleMapping._data is read-only in Ansible 2.10
    def copyAnsibleMapping(d):
        return AnsibleMapping(data = d._data.copy())


# Generated at 2022-06-11 10:29:37.792594
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    import_playbook = "play.yml"
    play = AnsibleMapping()
    play["import_playbook"] = import_playbook
    playbook = PlaybookInclude()
    playbook.preprocess_data(play)
    assert playbook.import_playbook == import_playbook
    assert playbook.vars == dict()
    assert playbook.tags == []

    playbook = AnsibleMapping()
    playbook["import_playbook"] = import_playbook
    playbook["tags"] = "tag1,tag2"
    playbook["vars"] = dict(one=1, other="other")
    playbook_include = PlaybookInclude()
    playbook_include.preprocess_data(playbook)
    assert playbook_include.import_playbook == import_playbook

# Generated at 2022-06-11 10:29:49.845673
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    class MockVariableManager(object):

        def get_vars(self):
            return {'mock_var_1': 'mock_value_1',
                    'mock_var_2': 'mock_value_2'}

    class MockPlaybook(Playbook):

        def __init__(self):
            self._entries = [Play('test_play_1'),
                             Play('test_play_2')]

    class MockInclude(PlaybookInclude):

        def __init__(self, task_vars):
            self.vars = task_vars
            self.import_playbook = 'test_mock_playbook.yml'


# Generated at 2022-06-11 10:30:01.971934
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    ds = AnsibleMapping()
    ds['import_playbook'] = 'a.yml'
    ds['vars'] = {'x': 'y', 'a': 'b'}
    ds['tags'] = 'tag1,tag2'
    ds['when'] = '1==1'
    obj = PlaybookInclude()
    new_ds = obj.preprocess_data(ds)
    if 'import_playbook' not in new_ds:
        assert False, 'import_playbook not in new_ds'
    if 'vars' not in new_ds:
        assert False, 'vars not in new_ds'
    if 'tags' not in new_ds:
        assert False, 'tags not in new_ds'

# Generated at 2022-06-11 10:30:09.898711
# Unit test for method preprocess_data of class PlaybookInclude

# Generated at 2022-06-11 10:30:10.460944
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:30:20.978524
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # test for empty string for import_playbook parameter
    obj1 = AnsibleMapping()
    obj1['import_playbook'] = None
    obj1['tags'] = 'mytag'
    obj1['vars'] = AnsibleMapping()
    obj1['vars']['var1'] = 'val1'
    try:
        PlaybookInclude.load(obj1, '.')
    except AnsibleParserError as pe:
        pass
    else:
        raise AssertionError('A PlaybookInclude with an empty string for import_playbook parameter should raise an error.')

    # test with invalid value for import_playbook parameter
    obj2 = AnsibleMapping()
    obj2['import_playbook'] = 2
    obj2['vars'] = AnsibleMapping()

# Generated at 2022-06-11 10:30:35.760284
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    class DataLoader(object):
        def get_basedir(self, host):
            return "."

    class Options(object):
        def __init__(self):
            self.connection = 'local'
            self.module_path = None
            self.forks = 10
            self.become = None
            self.become_method = None
            self.become_user = None
            self.remote_user = 'root'
            self.private_key_file = None
            self.ssh_common_args = None
            self.ssh_extra_args = None
            self.sftp_extra_args = None
            self.scp_extra_args = None
            self.verbosity = 0

# Generated at 2022-06-11 10:30:39.445798
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook

    p = PlaybookInclude()
    data = dict(import_playbook='test.yml')
    r = p.load_data(data, '', None, None)
    assert isinstance(r, Playbook)

# Generated at 2022-06-11 10:30:50.670772
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    module_ut_helper = AnsibleModuleTestHelper()
    module_ut_helper.add_module_defaults_fix(fix_name='fix_dict_type_ansible_pos',
                                             ansible_pos_fix_type=AnsibleBaseYAMLObject)
    module_ut_helper.add_module_defaults_fix(fix_name='fix_dict_type_ansible_pos_action',
                                             ansible_pos_fix_type=AnsibleBaseYAMLObject)
    module_ut_helper.add_module_defaults_fix(fix_name='fix_dict_type_ansible_pos_task',
                                             ansible_pos_fix_type=AnsibleBaseYAMLObject)
    module_ut_helper.add_module_defaults_

# Generated at 2022-06-11 10:31:01.924779
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # test the load_data method of class PlaybookInclude
    # we will create a datastructure and validate that it loads correctly
    # and that we get back the expected type of object from load_data
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    data = dict(
        import_playbook='plabook.yml',
        vars=dict(
            testvar='test'
        )
    )

    # if we are loading from a file, this would be basedir set to the
    # directory name of the file.  For this test, we'll just set it to
    # './'
    basedir = os.path.dirname(os.path.abspath(__file__))

    pbi = PlaybookInclude()
    pb = pbi.load_

# Generated at 2022-06-11 10:31:12.085593
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.playbook_include import PlaybookInclude
    import sys
    import io

    # test input data
    test_data = '''
    - hosts: localhost
      import_playbook: test_playbook
      gather_facts: no
    '''

    # expected output
    expected_data = {
        'import_playbook': 'test_playbook',
        'gather_facts': 'no',
    }

    # test preprocess (mocked to avoid writing on disk)
    sys.stdin = io.StringIO(test_data)
    debug_playbook = PlaybookInclude()
    debug_playbook.preprocess(sys.stdin)
    assert expected_data == debug_playbook.data

# Generated at 2022-06-11 10:31:24.095041
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    b_dumper = AnsibleDumper
    b_templar = Templar(variables={})
    b_vm = VariableManager()

    ds = AnsibleMapping()
    ds['import_playbook'] = 'xyz.yml'
    ds['tags'] = 'all'
    ds['with_items'] = 'foo'

    new_ds = AnsibleMapping()
    new_ds['import_playbook'] = 'xyz.yml'
    new_ds['tags'] = 'all'

# Generated at 2022-06-11 10:31:30.696183
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play_context import PlayContext

    class TestAnsibleOptions:
        def __init__(self, tags=None, skip_tags=None, verbosity=None):
            self.tags = tags
            self.skip_tags = skip_tags
            self.verbosity = verbosity

    class TestVariableManager:
        def __init__(self, hosts=None, extra_vars=None):
            self.hosts = hosts
            self.extra_vars = extra_vars
            self.vars_cache = {}

        def get_vars(self, play=None, host=None, task=None):
            return self.extra_vars

    class TestInventory:
        def __init__(self, hosts=None):
            self.hosts = hosts


# Generated at 2022-06-11 10:31:43.534135
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.playbook import Playbook
    from ansible.template import Templar

    pass_data = {
        'import_playbook': 'rabbitmq_install.yml',
        'tags': 'rabbit_mq_install',
        'vars': {
            'rabbit_mq_port': 5672,
            'rabbit_mq_user': 'rabbitmq',
            'rabbit_mq_passwd': 'rabbitmq'
        }
    }

# Generated at 2022-06-11 10:31:51.574681
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play

    # test empty dict
    ds = dict()
    new_ds = PlaybookInclude().preprocess_data(ds)
    assert isinstance(new_ds, AnsibleMapping)
    assert new_ds == dict()

    # test dict with string value
    ds = dict(import_playbook='test.yml')
    new_ds = PlaybookInclude().preprocess_data(ds)
    assert isinstance(new_ds, AnsibleMapping)
    assert new_ds == dict()

    # test dict with dict
    ds = dict(import_playbook=dict())
    new_ds = PlaybookInclude().preprocess_data(ds)
    assert isinstance(new_ds, AnsibleMapping)
    assert new_ds == dict()

    #

# Generated at 2022-06-11 10:32:03.580560
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play import Play
    import sys, os
    import json
    import tempfile
    
    
    # Read YAML file
    TEST_PLAYBOOK_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '../test_playbooks'))
    f = open(os.path.join(TEST_PLAYBOOK_DIR, 'import_playbook.yaml'), 'r')
    ds = f.read()
    
    # Convert YAML file to Python object
    ds = yaml.safe_load(ds)
    
    # Create PlaybookInclude object
    pib = Play

# Generated at 2022-06-11 10:32:21.052929
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import tempfile
    import io
    import yaml
    import os

    def _get_my_data(content):
        return AnsibleMapping(ansible_pos=content.index('my_playbook'))

    def _get_play(content):
        # Create a temp file with content
        fd, path = tempfile.mkstemp()
        with io.open(fd, 'w', encoding='utf-8') as tmp:
            tmp.write(content)

        # Create a conditional include entry and load it
        temp_ds = AnsibleMapping(ansible_pos=content.index('- import_playbook'),
                                 import_playbook="my_playbook.yml")
        my_object = PlaybookInclude.load(temp_ds, os.path.dirname(path))

        # Delete the temp

# Generated at 2022-06-11 10:32:33.703312
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import ansible.constants as C
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    yaml_obj = {
        'import_playbook': 'playbook.yml',
        'vars': {
            'a': 1,
            'b': 2
        },
        'tags': [ 't1', 't2' ],
        'when': 'True'
    }
    play_context = PlayContext()
    variable_manager = VariableManager()
    templar = Templar(loader=None, variables=variable_manager.get_vars())

    pi = PlaybookInclude()

# Generated at 2022-06-11 10:32:43.103339
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    # Setup for test 1
    yaml_data = dict(
        import_playbook="test.yml",
        vars=dict(
            var1="foo",
            var2=42,
        ),
        tags=["fantasy"],
        when="ansible_os_family = 'Debian'"
    )
    variable_manager = None
    loader = None

    pbi = PlaybookInclude()
    pbi.load_data(yaml_data, basedir='.', variable_manager=variable_manager, loader=loader)

    # Verification of test 1
    pb = pbi

# Generated at 2022-06-11 10:32:44.302304
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-11 10:32:44.951099
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:32:53.380101
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''
    Test definition for method load_data of class PlaybookInclude
    '''
    # Unit test for method load_data of class PlaybookInclude
    # ###########################################################################################
    # Unit Tests for PlaybookInclude.load_data()
    #
    # Note that this method is not unit-testable, because it relies on
    # very large amounts of other code and data structures
    #
    ###########################################################################################

    # TODO:  Write unit tests for PlaybookInclude.load_data()
    #        This method is not currently tested.
    pass

# Generated at 2022-06-11 10:33:02.697247
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''
    Unit test for method load_data of class PlaybookInclude
    '''
    import ansible.playbook.playbook_include

    # Create test PlaybookInclude object
    pbi = ansible.playbook.playbook_include.PlaybookInclude()

    # Load test data as playbook
    # playbook = pbi.load_data({"import_playbook": "test.yml", "tags": "test_tag"}, ".", None)

    # TODO: PlaybookInclude.load_data() is deprecated.
    # These tests need to be updated for the new implementation.
    pass

# Generated at 2022-06-11 10:33:10.847000
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.playbook_include import PlaybookInclude

    yaml_text = '''
- name: playbook_include test
  hosts: all
  gather_facts: true
  import_playbook: test.yml param1=value1 param2=value2
'''

    data = AnsibleLoader(yaml_text, file_name='playbook_include_preprocess_data').get_single_data()
    assert len(data)==1
    new_ds = PlaybookInclude().preprocess_data(data[0])
    assert 'import_playbook' in new_ds.keys()
    assert new_ds['import_playbook']=='test.yml'
    assert 'vars' in new_ds.keys()

# Generated at 2022-06-11 10:33:11.692322
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:33:12.801835
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    PlaybookInclude()



# Generated at 2022-06-11 10:33:40.368760
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    import ansible.parsing.yaml.objects

    # Create a new PlaybookInclude object
    objPlaybookInclude = PlaybookInclude()

    # Create data structure for testing
    data = {}
    data['import_playbook'] = '/path/impo/playbook.yml'
    data['vars'] = {'the_var': 'the_val'}

    # Test preprocess_data
    objPlaybookInclude_preprocessed = objPlaybookInclude.preprocess_data(data)
    assert objPlaybookInclude_preprocessed['import_playbook'] == data['import_playbook']
    assert objPlaybookInclude_preprocessed['vars'] == data['vars']

    # Test preprocess_data with invalid data

# Generated at 2022-06-11 10:33:53.103871
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = None
    play_context = PlayContext()
    basedir = '.'
    playbook = 'foo.yml'

    ds = {'import_playbook': playbook}
    pi = PlaybookInclude().load_data(ds, basedir, variable_manager, loader)
    assert pi.playbook == playbook

    ds = {'import_playbook': playbook, 'tags': 'tag1,tag2'}
    pi = PlaybookInclude().load_data(ds, basedir, variable_manager, loader)
    assert pi.playbook == playbook
    assert pi.tags == ['tag1', 'tag2']


# Generated at 2022-06-11 10:34:02.066522
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    # init variable
    ds = AnsibleMapping()

    # init variable
    new_ds = AnsibleMapping()

    # init variable
    k = "import_playbook"
    # init variable
    v = "test.yml"

    # init variable
    ds[k] = v
    # init variable
    new_ds["import_playbook"] = "test.yml"

    # init variable
    k = "vars"
    # init variable
    v = {"key1": "val1", "key2": 2}

    # init variable
    ds[k] = v
    # init variable
    new_ds["vars"] = {"key1": "val1", "key2": 2}

    # init

# Generated at 2022-06-11 10:34:03.027932
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-11 10:34:14.646922
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Test with a single include syntax
    ds = {
        'import_playbook': 'base.yml',
        'vars': {
            'user': 'test',
        },
    }
    pbi = PlaybookInclude()
    ds = pbi.preprocess_data(ds)
    assert ds['import_playbook'] == 'base.yml', "import_playbook field should be base.yml but is %s" % ds['import_playbook']
    assert ds['vars']['user'] == 'test', "vars.user should be test but is %s" % ds['vars']['user']
    assert 'tags' not in ds, "tags should not be in ds which is %s" % ds

    # Test with multiple include syntax

# Generated at 2022-06-11 10:34:15.687072
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # TODO: Unit test this method
    pass

# Generated at 2022-06-11 10:34:26.692262
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext

    collectionpath = os.path.join(os.getcwd(), 'test/fixtures/test_collections/ansible_namespace/collection1/')

    # A basic playbook
    simple_playbook = '''
- hosts: all
  tasks:
    - import_playbook: 'test/fixtures/import_playbook/simple_playbook.yml'
    - import_playbook: 'test/fixtures/import_playbook/complex_vars.yml'
'''
    # The playbook the previous one import
    simple_playbook_imported = '''
- hosts: all
  tasks:
    - debug:
        var: imported_playbook_was_loaded
'''

    # A basic playbook with

# Generated at 2022-06-11 10:34:35.302864
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import pytest
    from ansible.errors import AnsibleParserError
    from ansible.utils.collection_loader._collection_finder import AnsibleCollectionRef

    # test1
    ent = PlaybookInclude()

# Generated at 2022-06-11 10:34:47.821253
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    import_playbook_data = AnsibleMapping()
    dict_data = dict(import_playbook='file1.yaml var1=value1 var2=value2 tags=tag1,tag2')
    PlaybookInclude.preprocess_data(import_playbook_data, dict_data)
    assert import_playbook_data.get('import_playbook') == 'file1.yaml'
    assert import_playbook_data.get('vars')['var1'] == 'value1'
    assert import_playbook_data.get('vars')['var2'] == 'value2'
    assert import_playbook_data.get('tags') == 'tag1,tag2'



# Generated at 2022-06-11 10:34:48.852755
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    #TODO: Write a Test!
    pass

# Generated at 2022-06-11 10:35:38.394051
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.parsing.yaml.objects import AnsibleMapping

    # data supplied by user
    data = dict(
        import_playbook='test.yml'
    )
    # data preprocessed by method load_data
    preprocessed_data = dict(
        import_playbook='test.yml',
    )

    ansible_playbook = PlaybookInclude()
    ansible_playbook.load_data(data, loader=None, variable_manager=None, basedir='/tmp')
    # data member of object must be equal to preprocessed data
    assert ansible_playbook.data == preprocessed_data
    # object must be an instance of AnsibleMapping

# Generated at 2022-06-11 10:35:39.407074
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-11 10:35:47.637399
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''
    Tests to check that import_playbook statements are parsed correctly
    '''

    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = None
    basedir = os.path.dirname(os.path.abspath(__file__))

    # Check that import_playbook is parsed correctly when stated alone
    playbook = """
    - import_playbook: test_include_play.yml
    """

    playbook_obj = PlaybookInclude.load(playbook, basedir, variable_manager, loader)

    assert playbook_obj._entries[0]._included_path is not None

# Generated at 2022-06-11 10:36:00.282767
# Unit test for method load_data of class PlaybookInclude

# Generated at 2022-06-11 10:36:10.322895
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    import ansible.playbook.playbook as playbook
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.vars.manager import VariableManager
    data = {'import_playbook': 'play.yaml', 'vars': {'test': 'test'}, 'when': 'test == 2', 'tags': ['test']}
    yaml_obj = AnsibleBaseYAMLObject(data)
    data = yaml_obj.get_data()
    base = playbook.Playbook._load_playbook_data(file_name='play.yaml', variable_manager=VariableManager(loader=None), loader=None)
    # Test constructor
    pbi = PlaybookInclude()
   

# Generated at 2022-06-11 10:36:20.456883
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # data structure that will feed PlaybookInclude
    ds = AnsibleMapping()
    ds['import_playbook'] = 'playbook.yml'
    ds['tags'] = ''
    ds['vars'] = {'var':'value'}
    # call load_data
    pbi = PlaybookInclude.load(data=ds, basedir="/some/folder")
    # validate outcome
    assert isinstance(pbi, PlaybookInclude), "PlaybookInclude_load_data returned an instance of %s instead of PlaybookInclude" % type(pbi)


# Generated at 2022-06-11 10:36:31.190669
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    data = dict(import_playbook='playbook.yml')
    data1 = dict(import_playbook='playbook.yml', tags='tag1,tag2')
    data2 = dict(import_playbook='playbook.yml', vars=dict(param1='val1'))
    data3 = dict(import_playbook='playbook.yml', param1='val1')
    data4 = dict(import_playbook='playbook.yml', param1='val1', param2='val2')
    p = PlaybookInclude()
    p.load_data(data, '.')
    p.load_data(data1, '.')
    p.load_data(data2, '.')
    p.load_data(data3, '.')

# Generated at 2022-06-11 10:36:31.778596
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:36:40.797530
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.playbook.block import Block

    filename = '/path/to/playbooks/test.yaml'
    basedir = '/path/to/playbooks'
    playbook = Playbook(loader=DictDataLoader())
    data = AnsibleMapping()
    data.variable_manager = DictDataManager()

    pre_tasks = AnsibleMapping(dict(name='pre_task_1'))
    roles = AnsibleMapping(dict(name='role_1'))
    tasks = AnsibleMapping(dict(name='task_1'))
    post_tasks = AnsibleMapping(dict(name='post_task_1'))


# Generated at 2022-06-11 10:36:50.446769
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    playbook_include = PlaybookInclude.load('import_playbook: test.yml')
    assert playbook_include.import_playbook == 'test.yml'
    assert playbook_include.vars == {}

    playbook_include = PlaybookInclude.load('import_playbook: test.yml vars: var=a')
    assert playbook_include.import_playbook == 'test.yml'
    assert playbook_include.vars == {'var': 'a'}

    playbook_include = PlaybookInclude.load

# Generated at 2022-06-11 10:37:43.296562
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook._play_include import PlayInclude
    import ansible.playbook

    # stub the PlaybookInclude.load() method
    original_load = PlaybookInclude.load
    PlaybookInclude.load = lambda *args, **kwargs: PlaybookInclude().load_data(*args, **kwargs)

    # also stub out PlayInclude.load() as we don't want to parse a real file
    original_playinclude_load = PlayInclude.load
    PlayInclude.load = lambda x, y, z: PlayInclude().load_data(x, y, z)

    # test with a normal include
    ds = {"import_playbook": "../../../../lib/ansible/modules/network/data/system_info.retry"}

# Generated at 2022-06-11 10:37:56.897563
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    yaml_ds = {
        'include': 'test_include.yml',
        'vars': {'TEST_VAR': 'test value'},
        'tags': 'always'
    }
    pb = PlaybookInclude.load(yaml_ds, basedir=os.path.dirname(__file__))
    assert isinstance(pb, Playbook)
    assert pb.__class__.__name__ == 'Playbook'
    assert len(pb._entries) == 1
    assert isinstance(pb._entries[0], Play)
    assert pb._entries[0].__class__.__name__ == 'Play'

# Generated at 2022-06-11 10:38:04.829941
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    # Import example playbook
    # at path: ansible/test/playbooks/playbook_include.yml
    play_ds = { 'include_playbook': 'playbook_test.yml' }
    basedir = './ansible/test/playbooks'
    # Load the example playbook
    play = PlaybookInclude.load(play_ds, basedir)
    # Assert that the example playbook was loaded
    assert isinstance(play, Playbook)
    # Assert that the first Play loaded has some tasks
    assert len(play._entries[0].tasks) > 0
    # Assert that the last Play loaded has some tasks
    assert len(play._entries[-1].tasks) > 0
    # Ass

# Generated at 2022-06-11 10:38:15.797177
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os
    import unittest
    import tempfile
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.module_utils.six import text_type
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import TaskInclude
    from ansible.playbook.base import Base
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    global display
    display = Display()

# Generated at 2022-06-11 10:38:27.390939
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import pdb
    import sys
    import unittest
    sys.path.insert(0, '../../lib')

    # pdb.set_trace()
    test_PlaybookInclude_load_data.test_instance = PlaybookInclude()
    test_PlaybookInclude_args = {}
    test_PlaybookInclude_args['ds'] = {}
    test_PlaybookInclude_args['basedir'] = '../../lib/ansible/tests'
    test_PlaybookInclude_args['variable_manager'] = 'test'
    test_PlaybookInclude_args['loader'] = 'test'

    class FakeVars:
        def get_vars(self):
            return {}

    from ansible.playbook.play_context import PlayContext
    context = PlayContext()
    context.CLIAR

# Generated at 2022-06-11 10:38:34.020397
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import_playbook_path = os.path.join('tests', 'test_play_data', 'playbook_include_data', 'playbook_include.yml')
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.parsing.splitter import parse_yaml_from_file
    data = parse_yaml_from_file(import_playbook_path)
    play_include = PlaybookInclude.load(data,
                                        basedir=os.path.dirname(import_playbook_path))
    assert len(play_include.get_plays()) == 1