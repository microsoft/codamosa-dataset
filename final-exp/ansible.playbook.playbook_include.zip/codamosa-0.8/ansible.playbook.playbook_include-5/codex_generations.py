

# Generated at 2022-06-11 10:28:50.941196
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    import yaml
    yaml_str = """
    - import_playbook: test.yml
      when: 1
      tags:
        - foo
      vars:
        var_name: var_value
    """
    ds = yaml.safe_load(yaml_str)
    pb = PlaybookInclude.load(data=ds, basedir='.', variable_manager=VariableManager(), loader=DataLoader())
    assert isinstance(pb, PlaybookInclude)
    assert pb.import_playbook == "test.yml"
    assert pb.when == [{'when': '1'}]
    assert pb

# Generated at 2022-06-11 10:29:02.586875
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Can't run unit tests in windows
    if os.name == 'nt':
        return
    def _mock_load_data(ds, basedir, variable_manager=None, loader=None):
        return ds
    from ansible.playbook import Playbook
    p = PlaybookInclude(loader=None)
    p.load_data = _mock_load_data
    val = """
        - include_playbook:
            playbook: /usr/local/ansible/playbooks/foo.yml
            vars:
                foo: bar
            tags:
                - always_run
            extra_vars:
                - baz: baz
            variables:
                - bar: bar
    """
    new_ds = p.preprocess_data(val)
    assert 'vars' not in new_ds

# Generated at 2022-06-11 10:29:04.946681
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # load_data(self, ds, basedir, variable_manager=None, loader=None):
    pass

# Generated at 2022-06-11 10:29:14.214351
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import sys
    import os
    import tempfile
    import shutil
    import yaml
    sys.path.append(os.path.dirname(os.path.dirname(__file__)))
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.parsing.splitter import split_args
    from ansible.template import Templar

    test_dir = os.path.dirname(os.path.dirname(__file__)) + "/test_data"
    pl_file = test_dir + "/test_playbook_include.yaml"
    t_file = test_dir + "/test_playbook_include_target.yaml"

    PlaybookInclude.load(pl_file, os.path.dirname(pl_file))


# Unit test

# Generated at 2022-06-11 10:29:27.132673
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.common._collections_compat import Mapping
    import os
    import unittest

    class PlaybookIncludeTest(unittest.TestCase): 

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_load_data(self):
            # see if we can load a real include yaml file
            test_file = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'include_vars.yml')

            data = {}

# Generated at 2022-06-11 10:29:38.202466
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # Make sure the import playbook value is not none
    ds_1 = dict(import_playbook=None)
    ds_2 = dict(import_playbook='')
    for ds in (ds_1, ds_2):
        try:
            PlaybookInclude().preprocess_data(ds)
        except AnsibleParserError:
            pass
        else:
            raise AssertionError('PlaybookInclude.preprocess_data() failed to detect invalid import playbook')

    # Make sure the import path is a string
    ds = dict(import_playbook=dict())
    try:
        PlaybookInclude().preprocess_data(ds)
    except AnsibleParserError:
        pass

# Generated at 2022-06-11 10:29:50.532206
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import ast
    ds = {u'action': {u'import_playbook': u'test.yml', u'vars': {u'b': u'bbb', u'a': u'aaa'}}}

    ansible_pos = {
        'col_offset': 0,
        'end_column': 10,
        'end_line': 2,
        'filename': 'test.yml',
        'line': 1,
        'path': '/root/test.yml'
    }
    ds = AnsibleBaseYAMLObject(ds, ansible_pos, 'test.yml')

    obj = PlaybookInclude()
    new_ds = obj.preprocess_data(ds)

    print(new_ds)
    print(type(new_ds))

# Generated at 2022-06-11 10:30:02.460937
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    '''
    tests for preprocess_data method of class PlaybookInclude
    '''
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.parsing.yaml.loader import AnsibleLoader

    # init the context
    loader = AnsibleLoader(None, {})
    add_all_plugin_dirs()
    context = PlayContext()

    # create the object to test
    obj = PlaybookInclude()

    # first test, test with a simple include statement
    test_data = {
        'include': 'some_file'
    }
    expected_result = {
        'import_playbook': 'some_file'
    }
    result = obj.preprocess_data(test_data)

# Generated at 2022-06-11 10:30:10.211713
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    import ansible.playbook.play as play

    class TestPlaybookInclude(PlaybookInclude):
        def load_data(self, ds, basedir, variable_manager=None, loader=None):
            return {'basedir': basedir}, play.Play()

    pbi = TestPlaybookInclude()

    # Test variables
    ds = {"var1": "test1", "var2": "test2"}
    basedir = "basedir"
    pb = {'basedir': basedir}, play.Play()
    variable_manager = None
    loader = None

    # Test PlaybookInclude.load(ds, basedir)
    result = PlaybookInclude.load(ds, basedir)
    assert isinstance(result, play.Playbook)
    assert result._entries == [play.Play()]

# Generated at 2022-06-11 10:30:20.699477
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Mock imports
    import yaml
    yaml.load = lambda stream, Loader=yaml.BaseLoader: {
        "_import_playbook": "a_playbook.yml",
        "vars": {
            "a_var": {
                "a_key": "a_value",
                "another_key": "another_value"
            },
            "another_var": {
                "a_key": "a_value"
            }
        },
        "tags": "a_tag,another_tag"
    }

    import ansible.playbook

# Generated at 2022-06-11 10:30:35.158025
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    """Unit test for method load_data of class PlaybookInclude."""
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    # TODO:
    # Test logic changes in Ansible 2.9.
    # Remove the try/except block once Ansible <= 2.8 drops support.
    try:
        from ansible.playbook.task_include import TaskInclude
    except ImportError:
        # Ansible 2.8 and earlier:
        # TaskInclude wasn't added until Ansible 2.9
        # Fake the TaskInclude class:
        class TaskInclude(object):
            def __init__(self, include):
                self.include = include
    # TODO: Fix this once the method is implemented.
    raise NotIm

# Generated at 2022-06-11 10:30:45.669491
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook_include import PlaybookInclude

    # The variable with the name is defined in anon_vars
    ds1 = { 'import_playbook': 'test_import.yml', 'tags': 'tag1,tag2', 'vars': { 'var1': 'value1', 'var2': 'value2' } }
    data = PlaybookInclude.preprocess_data(ds1)
    assert data.get('import_playbook') == 'test_import.yml'
    assert data.get('vars') == { 'var1': 'value1', 'var2': 'value2' }
    assert data.get('tags') == 'tag1,tag2'

    # The variable with the name is defined in vars

# Generated at 2022-06-11 10:30:57.409580
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    playbook_inc = PlaybookInclude()

    # test playbook include with only 'import_playbook' role
    data = dict(import_playbook='test_playbook1.yml')
    res = playbook_inc.preprocess_data(data)
    assert res == dict(
        import_playbook='test_playbook1.yml',
        vars={},
        tags=[],
    )

    # test playbook include with 'import_playbook' and 'vars'
    data = dict(import_playbook='test_playbook1.yml', vars={})
    res = playbook_inc.preprocess_data(data)

# Generated at 2022-06-11 10:31:05.355231
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play import Play

    # Just enough code to make sure that the load_data method exists and to make sure that
    # the code runs without raising errors.
    import_playbook = 'import_playbook.yml'
    test_basedir = 'test_basedir'
    test_vars = {'test_var': 'test_value'}

    test_obj = PlaybookInclude()
    test_obj._import_playbook = import_playbook
    test_obj._vars = test_vars

    # Mocking Playbook(loader=loader)
    test_loader = 'test_loader'
    test_pb = Playbook()
    test_pb._load_playbook_data = lambda x, y, z: x, y,

# Generated at 2022-06-11 10:31:06.595227
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-11 10:31:19.218082
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    import os
    import shutil

    mock_ds_path = os.path.join(os.path.dirname(__file__), 'mock_data')

    # Setup

# Generated at 2022-06-11 10:31:24.093564
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    #from ansible.parsing.dataloader import DataLoader
    #loader = DataLoader()
    #playbook_include = PlaybookInclude.load(dict(import_playbook="./test.yml", vars=dict(a=1)), basedir='.', loader=loader)
    #print(playbook_include)
    pass

# Generated at 2022-06-11 10:31:27.616150
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    import ansible.playbook
    import ansible.constants

    p = PlaybookInclude()
    pb = p.load_data(ds={}, basedir='/some/path')
    assert isinstance(pb,ansible.playbook.Playbook)


# Generated at 2022-06-11 10:31:40.396961
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    import sys
    # TODO: update for Ansible > 2.9
    sys.modules['ansible.modules.source_control.mercurial'] = type('Mercurial', (object,), {'ANSIBLE_METADATA': {'status': 'preview'}})

    data = '''
        - name: test playbook
          hosts: localhost
          gather_facts: false
          any_errors_fatal: true
          serial: 1
          roles:
            - { role: fail, fail_msg: 'bad bad bad' }
          tasks:
            - name: first task
              debug:
                msg: this is a test
        '''

# Generated at 2022-06-11 10:31:49.698640
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    import datetime
    class AnsibleBaseYAMLObject(object):
        yaml_loader = None
        yaml_dumper = None
        __metaclass__ = AnsibleBaseYAMLObjectMetaclass
        def __init__(self, data):
            self.data = data
        @classmethod
        def to_yaml(cls, representer, node):
            return representer.represent_data(node.data)
        @classmethod
        def from_yaml(cls, constructor, node):
            return cls(constructor.construct_data(node))

# Generated at 2022-06-11 10:31:59.749163
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook

    playbook_import = PlaybookInclude.load({
        "import_playbook": "../common_tasks.yml",
        "vars": {
            "foo": "bar"
        },
        "tags": "always"
    }, "/")

    assert isinstance(playbook_import, Playbook)

# Generated at 2022-06-11 10:32:10.852048
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    class FakeAnsibleModule:
        def __init__(self):
            self.params = dict()
        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            self.failed = True

    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.module_utils._text import to_text

    assert PlaybookInclude
    assert Playbook
    assert Play
    assert to_text

    # create, setup and initialize a fake module object
    fake_module = FakeAnsibleModule()

    # create, setup and initialize a PlaybookInclude object
    test_include = PlaybookInclude()
    test_include._DUMP_REPR_INDENT = 4

    fake_v

# Generated at 2022-06-11 10:32:19.594674
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude
    from ansible.template import Templar

    yamlobj = PlaybookInclude()
    yamlobj.load_data({'import_playbook': './playbooks/included_playbook.yml',
                       'vars': {'config_param': 'hostname'}})

    assert yamlobj.import_playbook == './playbooks/included_playbook.yml'
    assert yamlobj.vars == dict(config_param='hostname')


# Generated at 2022-06-11 10:32:20.640423
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-11 10:32:33.235910
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.plugins.loader import load_plugin_terms
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.handler import Handler
    import os
    import yaml

    # Prepare directory
    # Create temp directory
    import tempfile
    import shutil

    temp_dir = tempfile.mkdtemp()
    # Create temp directory Structure
    temp_dir_collection = os.path.join(temp_dir, 'test_plugin_loader')
    temp_dir_roles = os.path.join(temp_dir_collection, 'roles')
   

# Generated at 2022-06-11 10:32:42.820052
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.role_include import RoleInclude
    pbi = PlaybookInclude()
    ds = AnsibleMapping(dict(import_playbook="import_playbook", when="when", vars="vars"))
    pbi._load_playbook_data(ds, None)
    assert 'import_playbook' in pbi.__dict__
    assert 'when' in pbi.__dict__
    assert 'vars' in pbi.__dict__
    assert pbi.__dict__.get('vars') == "vars"
    assert pbi.__dict__.get('import_playbook') == "import_playbook"
    assert pbi.__dict__.get('when') == "when"
    assert pbi.__dict__.get('variable_manager') is None

# Generated at 2022-06-11 10:32:54.224475
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.module_utils.six.moves import builtins
    import ansible.errors
    import ansible.playbook.play_context

    play_context = ansible.playbook.play_context.PlayContext()
    loader = DictDataLoader({})
    variable_manager = ansible.playbook.play_context.VariableManager()
    display = DictDisplay()
    inventory = ansible.inventory.manager.InventoryManager(loader=loader, sources='localhost,')

    # Test that an exception is raised if ds is not a dict
    test_obj = PlaybookInclude()
    test_obj.loader = loader
    test_obj.vars = dict()
    test_obj.display = display
    with pytest.raises(AnsibleAssertionError) as e:
        test_obj._load_

# Generated at 2022-06-11 10:33:03.112127
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars import VariableManager

    # TODO: replace ansible.vars.VariableManager with a mocker
    # TODO: replace ansible.template.Templar with a mocker

    playbook_include = PlaybookInclude()
    playbook = Playbook()
    playbook_include.load_data("example.yml")

    assert isinstance(playbook, Playbook)
    assert isinstance(playbook, Playbook)



# Generated at 2022-06-11 10:33:09.883761
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler

    # Test case 1
    # Test playbook with pre_tasks and handlers
    data = dict(
        import_playbook = 'test.yml',
        vars = dict(
            a = 'b',
            c = 'd'
        ),
        when = 'test == true',
        tags = ['test1', 'test2']
    )
    basedir = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
    playbook = PlaybookInclude.load(data, basedir)

# Generated at 2022-06-11 10:33:18.399270
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.playbook.play import Play

    playbook_include = PlaybookInclude()
    playbook_include.load_data(dict(import_playbook='sample_data.yml', vars=dict(foo='bar')), '.')
    assert playbook_include._import_playbook == 'sample_data.yml'
    assert playbook_include._vars == dict(foo='bar')

    playbook = playbook_include.load(dict(import_playbook='sample_data.yml', vars=dict(foo='bar')), '.')
    assert isinstance(playbook, Play)


# Generated at 2022-06-11 10:33:33.670216
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # import mock
    import unittest.mock as mock

    # test 1
    playbook_entry = '''
    - hosts: all
      vars:
        a: 1
      roles:
        - role1
    '''
    playbook = '\n'.join([
        '# Include a task list',
        '- include_tasks: somefile.yml',
        '# Import a play directly into the current one',
        '- import_playbook: %s' % playbook_entry,
        '# Include a role',
        '- include_role:',
        '    name: role2',
    ])

    # fake loader
    loader = mock.MagicMock()
    # fake data
    ds = {}
    # fake basedir
    basedir = './tests/playbook_include/'
   

# Generated at 2022-06-11 10:33:40.989376
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable

    import ansible.playbook.playbook_include as playbook_include
    import ansible.playbook.playbook_include as playbook_include

    PLAYBOOK_INCLUDE = """
    - import_playbook: foo.yml
    """

    pb_include = playbook_include.PlaybookInclude()
    pb_include.load_data(datastructure=PLAYBOOK_INCLUDE)
    pb = pb_include.load_data(datastructure=PLAYBOOK_INCLUDE)
    assert isinstance(pb,Playbook)



# Generated at 2022-06-11 10:33:54.232975
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pbi = PlaybookInclude()
    # fake a playbook object
    pb = object
    pb._entries = []
    pb.basedir = '.'
    # fake a Play object
    p = object
    p._included_path = None
    p._included_conditional = None
    p.vars = {}
    p.tags = []
    p.post_tasks = []
    p.tasks = []
    p.roles = []
    p.pre_tasks = []
    # fake a loader object
    l = object
    l.get_basedir = lambda x: os.path.abspath('.')
    # fake a variable manager
    vm = object
    vm.get_vars = lambda: {}

# Generated at 2022-06-11 10:34:02.372256
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    playbook_include = PlaybookInclude()
    # Below we test that the method preprocess_data raises an AnsibleAssertionError
    # when the input ds is not of type dict
    try:
        playbook_include.preprocess_data('ds')
    except AnsibleAssertionError:
        pass
    else:
        raise AssertionError("AnsibleAssertionError was not raised")

    # Below we test that the method preprocess_data raises an AnsibleParserError
    # when the input ds is of type dict but does not contain an entry for the
    # import_playbook attribute
    ds = dict()
    try:
        playbook_include.preprocess_data(ds)
    except AnsibleParserError:
        pass

# Generated at 2022-06-11 10:34:13.896907
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Load method is called inside PlaybookInclude.preprocess_data
    # We want to test only preprocess_data method
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    pbi = PlaybookInclude()

    # Test data set 1:
    # Check if the method is raising ParserError
    # when import_playbook parameter is not specified
    with pytest.raises(AnsibleParserError):
        ds = dict(
            name='test_ds',
            serial=1,
            user='user1',
        )
        pbi.preprocess_data(ds)

    # Test data set 2:
    # Check if the method is raising ParserError
    # when import_playbook parameter is
    # specified

# Generated at 2022-06-11 10:34:25.166961
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # load_data() method is required to load ansible.playbook.play.Play
    # and ansible.playbook.playbook.Playbook which will be imported later.
    # So to avoid circular dependency between modules, unit testing of
    # load_data() method is done here.

    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    import_dir = os.path.dirname(os.path.realpath(__file__))

    # Create a PlaybookInclude object
    pbi = PlaybookInclude()

    # Create a Playbook object with the child of 'tasks' as Play object
    # dir - import_dir/test_PlaybookInclude_load_data_include.yml
    pb = Playbook()

# Generated at 2022-06-11 10:34:32.406355
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    playbook_text = '''
- import_playbook: path/to/playbook_collection/playbook.yml

- import_playbook: path/to/playbook.yml
    vars:
      param1: value1
'''
    from ansible.parsing.yaml.loader import AnsibleLoader
    loader = AnsibleLoader(playbook_text)
    play = next(loader.get_single_data_from_text(playbook_text))
    assert isinstance(play, dict)
    assert play['import_playbook'] == 'path/to/playbook_collection/playbook.yml'

    play = next(loader.get_single_data_from_text(playbook_text))
    assert isinstance(play, dict)

# Generated at 2022-06-11 10:34:42.932027
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.tasks.include_tasks import IncludeTasks
    pb = PlaybookInclude.load(
        {'import_playbook': '../imported.yml', 'tags': 'import'}, basedir='./')
    assert isinstance(pb, Playbook)
    for entry in pb._entries:
        assert isinstance(entry, Play)
        assert '../imported.yml' in entry._entries
        assert isinstance(entry._entries['../imported.yml'], IncludeTasks)
        assert entry._included_path == './'
    assert pb._entries[0].tags == 'import'

# Generated at 2022-06-11 10:34:43.626172
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:34:47.975722
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pb = PlaybookInclude()
    test_data = {u'import_playbook': u'test_playbook.yml'}
    assert pb.load_data(test_data, u'test_dir', None, None)

# Generated at 2022-06-11 10:35:01.027103
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play_context import PlayContext

    import_playbook = PlaybookInclude()
    import_playbook.import_playbook = "test.yaml"
    context = PlayContext()
    collection = None
    loader = None
    playbook = import_playbook.load_data(import_playbook, "basedir", context.variable_manager)

    assert playbook is not None
    assert playbook.playbook_basedir == "basedir"
    assert len(playbook._entries) == 1
    assert playbook._entries[0]._included_path == "basedir"
    assert playbook._entries[0]._included_conditional == []

# Generated at 2022-06-11 10:35:12.677650
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import tempfile
    import ansible.constants as C
    from ansible.playbook.taggable import Tag
    from ansible.parsing.dataloader import DataLoader

    # Create temporary files
    tmp_file1 = tempfile.NamedTemporaryFile(delete=False)

    # Write data to temporary files
    tmp_file1.write(b"---" + b"\n" + b"- hosts: all" + b"\n" + b"  remote_user: root" + b"\n" + b"  tasks:" + b"\n" + b"- debug: msg='hello world'")
    tmp_file1.close()

    # Ensure that the temp files still exist
    assert os.path.isfile(tmp_file1.name) is True

    # Create the base object to be tested


# Generated at 2022-06-11 10:35:22.440584
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    basedir = 'test-path'
    playbook = PlaybookInclude()
    playbook._load_data({'import_playbook': 'test-play.yaml'}, basedir, None)
    assert playbook.import_playbook == 'test-play.yaml'
    playbook._load_data({'import_playbook': 'test-play.yaml', 'vars': {'a': 'b'}}, basedir, None)
    assert playbook.vars == {'a': 'b'}
    playbook._load_data({'import_playbook': 'test-play.yaml', 'tags': 'tag1,tag2'}, basedir, None)
    assert playbook.tags == ['tag1', 'tag2']

    expect

# Generated at 2022-06-11 10:35:33.715918
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play

    collection_paths = [os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', 'test', 'data', 'collections', 'ansible_collections')]

    # Make sure that the collection we are testing is found
    AnsibleCollectionConfig.playbook_paths = collection_paths

    # Test for a normal playbook
    playbook = os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', 'test', 'data', 'playbooks', 'include_complex.yml')
    pb = PlaybookInclude().load(playbook, '.')
    # Check that the playbook included 4 plays
    assert len(pb._entries) == 4

    # Test

# Generated at 2022-06-11 10:35:44.303467
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''
    Unit test for method load_data of class PlaybookInclude.
    '''

    # Set up test data.
    basedir = '/tmp/foo'
    playbook_text = '''
- hosts: server1
  tasks:
    - name: sample task 1
      debug:
        msg: task1
- hosts: server2
  tasks:
    - name: sample task 2
      debug:
        msg: task2
'''
    playbook_name = '/tmp/foo/playbook_name.yml'
    os.makedirs(basedir)
    f = open(playbook_name, 'w')
    f.write(playbook_text)
    f.close()

    # Set test data for test PlaybookInclude object.
    import_playbook = playbook_name
    vars = {}

# Generated at 2022-06-11 10:35:49.191171
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    #assert PlaybookInclude.load_data("test data", "test basedir") == False
    assert PlaybookInclude.load_data(None, "test basedir") == None
    #assert PlaybookInclude.load_data("test_PlaybookInclude_load_data", "test_PlaybookInclude_load_data") == False



# Generated at 2022-06-11 10:36:01.545283
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play

    pb = PlaybookInclude().load({'import_playbook': 'importrrrr.yml'}, basedir='/some/dir')
    assert pb._entries[0]._included_path == '/some/dir'

    pb = PlaybookInclude().load({'import_playbook': 'importrrrr.yml'}, basedir='/some/dir', variable_manager=variable_manager, loader=loader)
    assert pb._entries[0]._included_path == '/some/dir'
    assert isinstance(pb._entries[0], Play)
    assert pb._entries[0].name == 'playbook include'
    assert pb._entries[0].connection == 'local'
    assert pb._entries[0]._in

# Generated at 2022-06-11 10:36:11.003218
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()

    # First test when there is a collection
    # mock the collection playbook path
    playbook = {
        'import_playbook': 'namespace.collection.playbook.yml'
    }
    pi = PlaybookInclude()
    pb = pi.load_data(playbook, '/noroot', variable_manager, loader)

    assert pb._playbook is not None, "playbook must be loaded"
    assert pb._playbook.__class__.__name__ == 'Playbook', "playbook must be of class: 'Playbook'"

# Generated at 2022-06-11 10:36:16.201607
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # Loads a test playbook
    p = PlaybookInclude()
    p.load_data(
        {'import_playbook': 'temp1.yml'},
        './',
    )

    # Check if the filename is correct
    assert p.import_playbook == 'temp1.yml'

# Generated at 2022-06-11 10:36:27.946295
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    import sys
    import unittest
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class TestPlaybookInclude(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def _test(self, a, b):
            self.maxDiff = None
            if a != b:
                print('-', file=sys.stderr)
                print(a, file=sys.stderr)
                print('+', file=sys.stderr)
                print(b, file=sys.stderr)

# Generated at 2022-06-11 10:36:42.561530
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import_playbook_ds = {'import_playbook': 'test.yml'}
    vars_ds = {'vars': {'key1': 'value1', 'key2': 'value2'}}
    tags_ds = {'import_playbook': 'test.yml', 'tags': 'tag1,tag2'}
    params_ds = {'import_playbook': 'test.yml key1=value1 key2="value with spaces" key3=True key4=False key5=empty'}
    params_ds2 = {'import_playbook': 'test.yml key1=value1', 'vars': {'key2': 'value2'}}

# Generated at 2022-06-11 10:36:52.328536
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import os
    import re

    # Load vars into the variable manager
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'test1': 'testvalue1', 'test2': 'testvalue2'}

    # Load test playbook
    loader = DataLoader()

# Generated at 2022-06-11 10:36:53.862779
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:36:59.263504
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''
    Unit test for method load_data of class PlaybookInclude
    '''

    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.task_include import TaskInclude

    # PlaybookInclude load_data content (method PlaybookInclude.load_data, class PlaybookInclude)
    #
    # # 1 - Importing another playbook
    # - import_playbook: other.yml
    #
    # # 2 - Import playbook without tags or vars
    # - import_playbook: other.yml tags=other
    #
    # # 3 - Import playbook with vars
    # - import_playbook: other.yml vars:
    #    

# Generated at 2022-06-11 10:37:05.463049
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

    import_playbook_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'import_playbook.yml')

    data = {
        'import_playbook': import_playbook_path
    }

    obj = PlaybookInclude()
    result = obj.load_data(data, os.getcwd())

    assert isinstance(result, Playbook)
    assert len(result._entries) == 2

    entry = result._entries[0]
    assert isinstance(entry, Play)

# Generated at 2022-06-11 10:37:15.964377
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import mock

    import_dict = dict(
        import_playbook='playbook.yml',
        vars={'b':2},
        when=[
            dict(
                test='a == 1',
                when=[
                    dict(
                        test='b == 2',
                        when=[
                            dict(
                                test='c == 3',
                                when=[
                                    dict(
                                        test='d == 4',
                                        when=[
                                            dict(
                                                test='e == 5',
                                                when=None,
                                            )
                                        ]
                                    )
                                ]
                            )
                        ]
                    )
                ]
            )
        ]
    )

    imp = PlaybookInclude()
    imp.load_data(import_dict, '/tmp/')

# Generated at 2022-06-11 10:37:26.541154
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play

    # Default use case
    ds = { 'import_playbook': '/tmp/include.yml' }
    new_obj = PlaybookInclude.load(ds, '/tmp')
    assert(new_obj.import_playbook == os.path.join('/tmp', ds['import_playbook']))

    # With variables
    ds = { 'import_playbook': '/tmp/include.yml', 'vars': { 'user': 'joe', 'password': 'secret'} }
    new_obj = PlaybookInclude.load(ds, '/tmp')
    assert(new_obj.import_playbook == os.path.join('/tmp', ds['import_playbook']))
    assert(new_obj.vars['user'] == 'joe')

# Generated at 2022-06-11 10:37:36.628680
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.utils import context_objects as co
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.playbook.play import Play
    import os

    c = PlayContext()
    c._play_context = c
    c.CLIARGS = {}

    co.GlobalVars.set_var('PLAY_CONTEXT', c)

    class FakeLoader(object):
        def load_from_file(self, path, play):
            return AnsibleMapping({'tasks': []})


# Generated at 2022-06-11 10:37:49.358180
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    assert PlaybookInclude.preprocess_data(dict({"import_playbook": "b.yml", "a": "b"})) == {"import_playbook": "b.yml", "vars": {}, "a": "b"}
    assert PlaybookInclude.preprocess_data(dict({"import_playbook": "b.yml foo=bar", "a": "b"})) == {"import_playbook": "b.yml", "vars": {"foo": "bar"}, "a": "b"}
    assert PlaybookInclude.preprocess_data(dict({"import_playbook": "b.yml foo=bar=baz", "a": "b"})) == {"import_playbook": "b.yml", "vars": {"foo": "bar=baz"}, "a": "b"}

# Generated at 2022-06-11 10:37:53.628662
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.playbook import Playbook, PlaybookEntry
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.handler import Handler
    from ansible.playbook.helpers import load_list_of_blocks
    from ansible.template import Templar
    from ansible.module_utils.six import string_types

    p = PlaybookInclude()

    basedir = '/etc/ansible'

    templar = Templar(loader=None, variables={})

    # Test if a playbook object is returned
    o = p.load_data("playbook.yml", basedir)
    assert type(o) == Playbook

# Generated at 2022-06-11 10:38:25.026326
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    import yaml
    yaml_str = """
    - import_playbook: include1.yml
      tags:
         - sre
      vars:
         env: stage
         subnet: '{{ private_subnet }}'
    - import_playbook: include2.yml
      when: ansible_distribution == 'CentOS'
    """
    ds = yaml.safe_load(yaml_str)
    playbook_include = PlaybookInclude()
    playbook_include.load_data(ds=ds, basedir="")
    assert isinstance(playbook_include, Playbook)
    assert playbook_include._entries[0].tags == ['sre']

# Generated at 2022-06-11 10:38:34.055680
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    loader = None
    variable_manager = None
    load_tags = None
    pb = PlaybookInclude(loader=loader, variable_manager=variable_manager, load_tags=load_tags)
    ds = {'a': 1, 'tags': 'tag1, tag2', 'vars': {'var1': 'val1', 'var3': 'val3'}, 'connection': 'local', 'when': 'a==1'}
    new_ds = pb.preprocess_data(ds)
    assert new_ds == {'a': 1, 'import_playbook': 'a', 'tags': 'tag1, tag2', 'vars': {'var1': 'val1', 'var3': 'val3'}, 'connection': 'local', 'when': 'a==1'}