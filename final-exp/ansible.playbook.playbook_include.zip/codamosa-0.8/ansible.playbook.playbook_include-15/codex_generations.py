

# Generated at 2022-06-11 10:28:49.535273
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # import here to avoid dependency loop
    from ansible.playbook import Playbook

    # playbook include with only playbook
    data = {'import_playbook': '../test1.yml'}
    ds = PlaybookInclude.load({'test': data}, '/some/path/to/playbook.yml').data
    assert ds['test']['import_playbook'] == '../test1.yml'
    assert ds['test']['vars'] == dict()

    # playbook include with playbook and tags
    data = {'import_playbook': '../test1.yml tags=abc,def,ghj'}
    ds = PlaybookInclude.load({'test': data}, '/some/path/to/playbook.yml').data

# Generated at 2022-06-11 10:28:49.928427
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:29:00.305533
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import ansible.playbook
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.task import Task
    from ansible.executor.playbook_executor import PlaybookExecutor

    mock_loader = DataLoader()
    mock_loader.set_basedir('/home/username')

    mock_variable_manager = VariableManager()



# Generated at 2022-06-11 10:29:01.103594
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass # TODO

# Generated at 2022-06-11 10:29:01.802379
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    pass

# Generated at 2022-06-11 10:29:12.496782
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import ansible.playbook.play as play
    import ansible.playbook.playbook as playbook
    import ansible.template as template
    import ansible.vars.manager as var_manager

    # We need a fake loader

# Generated at 2022-06-11 10:29:25.165287
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    def _get_ds(data):
        from ansible.parsing.yaml.loader import AnsibleLoader
        from ansible.parsing.yaml.objects import AnsibleMapping
        from ansible.utils.collection_loader._yaml_loader import AnsibleLoaderYAML

        ds = AnsibleMapping()
        if isinstance(data, string_types):
            txt = str(data)
            loader = AnsibleLoaderYAML(txt, file_name=None)
            ds = loader.get_single_data()
        elif isinstance(data, dict):
            ds = AnsibleLoader(data, file_name=None).get_single_data()
        return ds

    # Basic functionality test
    ds = _get_ds("import_playbook: test")
    pi = Play

# Generated at 2022-06-11 10:29:25.852365
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:29:37.372212
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    assert PlaybookInclude._preprocess_import_playbook_line("tests/test.pb") == ("tests/test.pb", {})
    assert PlaybookInclude._preprocess_import_playbook_line("tests/test.pb tags=test_tag1,test_tag2") == ("tests/test.pb", dict(tags="test_tag1,test_tag2"))
    assert PlaybookInclude._preprocess_import_playbook_line("tests/test.pb var1=test1 var2=test2 var3=test3") == ("tests/test.pb", dict(var1="test1", var2="test2", var3="test3"))

# Generated at 2022-06-11 10:29:48.860014
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    """Check PlaybookInclude.preprocess_data()"""

    # Test with a regular import syntax
    import_playbook = PlaybookInclude.load(
        ds={
            'import_playbook': 'test.yml'
        },
        basedir='/test'
    )
    assert import_playbook._import_playbook == 'test.yml'
    assert import_playbook._vars == {}

    # Test with all syntax possible
    import_playbook = PlaybookInclude.load(
        ds={
            'import_playbook': 'test.yml',
            'tags': 'foo',
            'vars': {'bar': 'baz'}
        },
        basedir='/test'
    )
    assert import_playbook._import_playbook == 'test.yml'


# Generated at 2022-06-11 10:30:06.318225
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    #import ansible.module_utils.facts

    basedir = os.path.join(os.path.dirname(__file__), 'test_vars', "import_playbook")
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    vars_manager = VariableManager(loader=loader, inventory=inventory)
    playcontext = PlayContext(inventory=inventory)
    playcontext.variable_manager = vars_manager

    # create the playbook
    pi = PlaybookInclude()

# Generated at 2022-06-11 10:30:16.297418
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    from ansible.plugins.loader import add_all_plugin_dirs, find_plugin

    ds = dict(
        import_playbook='../common/main.yml',
        tags=['test_tag'],
        vars=dict(
            var_test='test_var',
            var_test2=['test_var2'],
            var_test3=dict(var_test_a=1, var_test_b=2)
        )
    )

    # Change current working directory to test/unit/plugins/action
    cwd = os.getcwd()
    os.chdir(os.path.join(cwd, 'test/unit/plugins/action'))

    # Load test plugins
   

# Generated at 2022-06-11 10:30:17.992441
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Pending to write test case
    return


# Generated at 2022-06-11 10:30:28.260257
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include = PlaybookInclude()

    # Test with a good playbook
    ds = {'import_playbook': 'test.yml'}
    result = playbook_include.preprocess_data(ds)
    assert result == ds

    # Test with a bad playbook
    ds = {'import_playbook': 'test.yml', 'vars': 'foo'}
    try:
        playbook_include.preprocess_data(ds)
    except AnsibleParserError:
        assert True

    # Test with import_playbook deprecated format
    ds = {'import_playbook': 'test.yml foo=bar tags=tag1,tag2'}
    result = playbook_include.preprocess_data(ds)

# Generated at 2022-06-11 10:30:28.932345
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:30:38.719085
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.playbook import Playbook
    from io import StringIO
    from ansible.parsing.dataloader import DataLoader

    variable_manager = None
    loader = DataLoader()
    basedir = ""
    pb_include = PlaybookInclude()
    pb_ds = """
---
- import_playbook: other.yml
  tags: [ 't1' ]
  vars:
    k1: 'v1'
    k2: 'v2'
"""
    pb_obj = pb_include.load_data(StringIO(pb_ds), basedir, variable_manager, loader)
    assert isinstance(pb_obj, Playbook)
    assert pb_obj._entries
    assert len(pb_obj._entries) == 1
    assert pb

# Generated at 2022-06-11 10:30:42.313373
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import ansible.playbook.playbook_include
    playbook_include = ansible.playbook.playbook_include.PlaybookInclude()
    playbook_include.load(basedir='../ansible/playbook/tasks')

# Generated at 2022-06-11 10:30:53.722878
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader, variable_manager)

    pb = PlaybookInclude.load('test_playbook.yml', '.', variable_manager=variable_manager)
    assert pb._import_playbook == 'test_playbook.yml'

    pb = PlaybookInclude.load('test_playbook.yml, a=b, c=3', '.', variable_manager=variable_manager)
    assert pb._import_playbook == 'test_playbook.yml'
    assert pb.vars == dict(a='b', c=3)

   

# Generated at 2022-06-11 10:31:03.757790
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Test that this is correctly set
    def _test_import_playbook(from_ds, expected_import_playbook):
        play = PlaybookInclude()
        play.preprocess_data(from_ds)
        assert play.import_playbook == expected_import_playbook

    # Test that this is correctly set
    def _test_vars(from_ds, expected_vars):
        play = PlaybookInclude()
        play.preprocess_data(from_ds)
        assert play.vars == expected_vars

    # Test that this is correctly set
    def _test_tags(from_ds, expected_tags):
        play = PlaybookInclude()
        play.preprocess_data(from_ds)
        assert play.tags == expected_tags

    # Test that this is correctly set

# Generated at 2022-06-11 10:31:15.951334
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    """
    Test preprocess_data() of class PlaybookInclude
    """

    yaml_obj = dict(
        import_playbook='/path/to/playbook.yaml',
        tags='tag1,tag2',
        when='ansible_hello == true',
    )

    playbook_include = PlaybookInclude()
    new_ds = playbook_include.preprocess_data(yaml_obj)

    assert isinstance(new_ds, AnsibleMapping)
    assert isinstance(new_ds['import_playbook'], string_types)
    assert isinstance(new_ds['tags'], string_types)
    assert isinstance(new_ds['when'], list)

    # check for error conditions
    #     invalid 'vars' type

# Generated at 2022-06-11 10:31:28.770644
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.six import PY2
    from ansible.template import Templar
    import json
    import os
    import six

    class MockLoader(object):
        pass

    loader = MockLoader()

    test_dir = os.path.dirname(os.path.realpath(__file__))
    test_data_dir = os.path.join(test_dir, '../../test_data')

    # set the file name to be imported

# Generated at 2022-06-11 10:31:39.205330
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    """
    This is a test function.
    """

    # create a playbook_include object

    obj = PlaybookInclude()
    obj.import_playbook = "playbook.yml"
    obj.vars = {"var1" : "val1", "var2" : "val2"}

    # create an object of class Playbook

    pb = obj.load_data(ds = "playbook.yml, var1=val1, var2=val2", basedir = "/home/user/ansible/plays")

    assert(pb.get_entries() is not None)



# Generated at 2022-06-11 10:31:45.514493
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import_vars = dict(a=1, b=2)
    import_playbook = "playbook.yaml"

    playbook_include = PlaybookInclude(import_playbook=import_playbook, vars=import_vars)

    ret_val = playbook_include.load_data(ds=None, basedir=None, variable_manager=None, loader=None)

    assert ret_val is not playbook_include
    assert ret_val.tasks == []

# Generated at 2022-06-11 10:31:52.598010
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Test1: When file is a collection playbook
    module = PlaybookInclude.load(data={'include': 'namespace.collection.file'}, basedir=None)
    assert module[0].tasks[0].action == 'debug'

    # Test2: When file is not collection playbook
    module = PlaybookInclude.load(data={'include': 'playbook'}, basedir=None)
    assert module[0].hosts == ['localhost']
    assert module[0].tasks[0].name == 'debug'
    assert module[0].tasks[0].action == 'debug'

    # Test3: When file is not exists
    module = PlaybookInclude.load(data={'include': 'not exist'}, basedir=None)
    assert module[0].hosts == []
    assert module[0].t

# Generated at 2022-06-11 10:32:04.708271
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Test PlaybookInclude.preprocess_data when the first argument is an empty AnsibleMapping object
    ds = AnsibleMapping()
    ds.ansible_pos = None
    new_ds = AnsibleMapping()
    new_ds.ansible_pos = None
    target = PlaybookInclude()
    result = target._PlaybookInclude__preprocess_import(ds, new_ds, 'import_playbook', 'import_playbook_file')
    expected_result = AnsibleMapping()
    expected_result.ansible_pos = None
    expected_result['import_playbook'] = 'import_playbook_file'
    assert result == expected_result.copy()
    # Test PlaybookInclude.preprocess_data when the first argument is an AnsibleMapping object with 'import_playbook' element

# Generated at 2022-06-11 10:32:15.202261
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from collections import namedtuple
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.reserved import RESERVED_VARS

    # Create a fake Play object for testing
    PlayObject = namedtuple('PlayObject', ('vars',))
    play = Play()
    play.vars = dict(foo=42, bar=dict(baz=84))
    play.tags = ['tag1', 'tag2']

    # Create a fake InventoryManager object for testing
    host = Host(name='localhost')
    host.set_variable('inventory_hostname', 'localhost')

# Generated at 2022-06-11 10:32:24.859253
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook import Playbook

    # create an example PlaybookInclude object
    pb = PlaybookInclude(
        import_playbook = "tasks/main.yml",
        vars = dict(
            var1 = 1,
            var2 = 2
        ),
        tags = [ "tag1", "tag2" ]
    )

    # create an example playbook

# Generated at 2022-06-11 10:32:36.962087
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    ds = AnsibleMapping()
    new_ds = AnsibleMapping()

    new_ds['import_playbook'] = 'test.yml'
    new_ds['vars'] = dict(foo='bar')
    assert PlaybookInclude._preprocess_import(ds, new_ds, 'import_playbook', 'test.yml foo=bar') == new_ds

    new_ds['import_playbook'] = 'test.yml'
    new_ds['vars'] = dict()
    assert PlaybookInclude._preprocess_import(ds, new_ds, 'import_playbook', 'test.yml') == new_ds

    new_ds['import_playbook'] = 'test.yml'
    new_ds['tags'] = 'foo,bar'

# Generated at 2022-06-11 10:32:40.907562
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.base import Base

    basedir = "/home/user/ansible/playbooks"
    data = '---\n- import_playbook: setup.yml'
    data = Base.load_data(data,basedir)
    assert(isinstance(data,list))


# Generated at 2022-06-11 10:32:45.507125
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    ds = {
        'import_playbook': 'test_playbook.yaml',
        'vars': {
            'var_1': 'value_1',
            'var_2': 'value_2'
        }
    }

    test = PlaybookInclude()
    result = test.load_data(ds, '.')

    assert type(result) is Playbook

# Generated at 2022-06-11 10:33:02.047193
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook

    class DummyVariableManager:
        def get_vars(self):
            return {'vars': {'a': 'va', 'b': 'vb'}}
    variable_manager = DummyVariableManager()

    playbook = PlaybookInclude()

    # tests for 'test.yml'
    playbook.import_playbook = 'test.yml'
    data = {
        'import_playbook': 'test.yml',
        'c': 'vc',
        'd': 'vd'
    }
    pb = playbook.load_data(data, '/', variable_manager)
    assert isinstance(pb, Playbook)
    assert isinstance(pb._entries[0], Play)
    assert pb._ent

# Generated at 2022-06-11 10:33:02.706539
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:33:09.047459
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # create an object
    my_obj = PlaybookInclude()

    # creating loading a dataset with no items
    # should return a empty Playbook object
    my_ds = {}
    my_pb = my_obj.load_data(my_ds, '', None, None)
    assert my_pb.run_handlers_on_included_files == False
    assert my_pb.runs_cleanup_plays == False
    assert my_pb.run_tasks == True
    assert my_pb.run_handlers == True
    assert my_pb._filter_plugin_loaders == []
    assert my_pb.vars == {}
    assert my_pb._entries == []
    assert my_pb._included_files == []
    assert my_pb._handlers == []

# Generated at 2022-06-11 10:33:16.430971
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='')

    pb = PlaybookInclude.load(ds=dict(), basedir='/home/user', variable_manager=variable_manager, loader=loader)
    # Assert playbook object is returned
    assert isinstance(pb, PlaybookInclude)

# Generated at 2022-06-11 10:33:27.423447
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    import sys
    import os
    test_dir = os.path.dirname(os.path.realpath(__file__))
    pb = PlaybookInclude.load({u'include': u'not_valid_playbook.yml'},
                              os.path.join(test_dir, "playbooks"),
                              None,
                              None)
    assert isinstance(pb, Playbook)
    assert len(pb._entries) == 1
    assert isinstance(pb._entries[0], Play)
    assert pb._entries[0].name == 'not_valid_playbook.yml'

# Generated at 2022-06-11 10:33:37.304200
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # unit test prepare
    ds_yaml_string='''---
- import_playbook: test_import_playbook.yml
    vars:
      var1: 123
- import_playbook: test_import_playbook.yml
    var1: 456
    tags:
      - test
'''
    basedir = './'
    variable_manager = VariableManager()
    loader = None
    playbook_vars = {}
    playbook_vars['test'] = 'test'
    variable_manager.set_nonpersistent_facts(playbook_vars)

# Generated at 2022-06-11 10:33:49.298262
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''
    Takes a YAML data structure and validates that the load_data function of the
    class PlaybookInclude correctly transforms it into a proper playbook object
    suitable for the rest of the codebase to work with
    '''

    # import here to avoid a dependency loop
    from ansible.playbook import Playbook

    # data to be tested
    pb_incl_ds = dict(
       import_playbook = 'test_play.yml',
    )
    # expected result
    pb_incl_ds_result = Playbook()

    # test playbook
    pb_incl_obj = PlaybookInclude()
    pb_incl_obj.load_data(pb_incl_ds, '/example/path/')

    # verify results
    assert pb_incl_obj == pb_

# Generated at 2022-06-11 10:34:00.001577
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    # Create objects for instanciation
    loader = DataLoader()
    variable_manager = VariableManager()
    test_file = os.path.abspath("./lib/ansible/test/unittests/test_playbook_include.yml")
    basedir = "./lib/ansible/test/unittests"
    # Create object and call method
    pbi = PlaybookInclude()
    pbi.load_data(loader.load_from_file(test_file), basedir, variable_manager)
    # Check if the returned value is a Playbook object
    s = isinstance(pbi, Playbook)

# Generated at 2022-06-11 10:34:10.543093
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.plugins.loader import dynamic_plugins

    temp_dir = tempfile.mkdtemp()
    temp_dir_alt = tempfile.mkdtemp()

    fd, test_file = tempfile.mkstemp(dir=temp_dir)
    os.close(fd)
    fd, test_file_alt = tempfile.mkstemp(dir=temp_dir)
    os.close(fd)

    playbook_paths = [temp_dir, temp_dir_alt]

    # define playbook contents

# Generated at 2022-06-11 10:34:22.193781
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role_include import RoleInclude

    import os
    import tempfile
    import shutil

    class PlaybookModule:
        def __init__(self):
            self.tags = ['test_tag']
            self.vars = {'test_var': 'test_var_value'}
            self.when = ['test_when']
            self.import_playbook = 'test_playbook_included'
            self.path = './path/to/test_playbook'


# Generated at 2022-06-11 10:34:42.751802
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import ansible.playbook
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.handler
    from ansible.playbook.role.metadata import RoleMetadata

    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    ipb = PlaybookInclude()
    pb = PlaybookInclude.load("import_role: name=r1", "/tmp")

    # The returned object should be a Playbook instance
    assert isinstance(pb, ansible.playbook.Playbook)
    assert pb.basedir == "/tmp"
    assert pb.filename is None
    # Should define a list of roles
    assert len(pb.roles) == 1
    # The first role should be valid

# Generated at 2022-06-11 10:34:53.892580
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    display = Display()
    old_display = display.verbosity
    display.verbosity = 3

    import ansible.utils.collection_loader as collection_loader
    collection_loader.all_collections.add('foo.bar')
    b = collection_loader.CollectionFinder()
    b.add_collection_path(collection_loader.test_collection_path)
    b._load_collections(['foo.bar'])
    b.reload()
    assert b.collections['foo.bar']
    b.update_cache()

    from ansible.utils.collection_loader import _get_collection_name_from_path
    from ansible.parsing.plugin_docs import read_docstring

    from ansible.playbook import Playbook

    from ansible.playbook.play import Play

# Generated at 2022-06-11 10:34:54.522605
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    pass

# Generated at 2022-06-11 10:34:55.616919
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    display.debug('Test PlaybookInclude load_data')

# Generated at 2022-06-11 10:35:06.124477
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import ansible.plugins.loader
    import ansible.plugins.callback
    import ansible.plugins.connection
    import ansible.plugins.action
    import ansible.plugins.lookup
    import ansible.plugins.shell
    import ansible.plugins.strategy
    import ansible.plugins.cache
    import ansible.plugins.vars
    import ansible.plugins.filter
    import ansible.plugins.test
    import ansible.plugins.logger
    import ansible.plugins.inventory
    import ansible.plugins.test.test_include_role
    import ansible.plugins.test.test_include_tasks
    import ansible.plugins.test.test_include

    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

# Generated at 2022-06-11 10:35:07.377779
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-11 10:35:18.992672
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook

    fake_loader = DictDataLoader({
        '/tmp/main.yml': '''
        - name: Play 1
          hosts: localhost
          tasks:
          - debug:
              var: foo
        - include: /tmp/other.yml
        - include: /tmp/other.yml foo=bar
        - include: /tmp/other.yml vars:
            foo: bar
        ''',
        '/tmp/other.yml': '''
        - name: Play 2
          hosts: localhost
          tasks:
          - debug:
              var: foo
        ''',
    })
    fake_variable_manager = None

# Generated at 2022-06-11 10:35:28.037644
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import ansible.playbook.play
    import ansible.playbook.playbook
    import ansible.playbook.handler
    import ansible.playbook.block
    import ansible.playbook.task

    ds = AnsibleMapping(dict(import_playbook='tasks.yml', tags='t1,t2'))
    obj = PlaybookInclude().load_data(ds, None)
    assert(obj is not None)
    assert(isinstance(obj, ansible.playbook.playbook.Playbook))
    assert(len(obj._entries) == 1)
    assert(isinstance(obj._entries[0], ansible.playbook.play.Play))
    assert(len(obj._entries[0].handlers) == 1)

# Generated at 2022-06-11 10:35:40.297887
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    import random

    # test PlaybookInclude
    pi = PlaybookInclude()
    ds = dict()

    # test no import_playbook key
    new_ds = pi.load_data(ds=ds, basedir=None, variable_manager=None, loader=None)
    assert new_ds is None

    # test no playbook_paths
    fp = 'test_PlaybookInclude_load_data.yml'
    AnsibleCollectionConfig.playbook_paths = []
    ds = dict(import_playbook=fp)
    new_ds = pi.load_data(ds=ds, basedir=None, variable_manager=None, loader=None)
    assert new_ds is None

    # test

# Generated at 2022-06-11 10:35:46.468182
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    pb_include = PlaybookInclude()
    basedir = "some_basedir"
    filename = "some_filename"
    p = Playbook()
    p._load_playbook_data = lambda file_name, variable_manager, vars: p._entries.append(Play())

    pb = pb_include.load_data({"import_playbook": filename}, basedir, p)

    assert isinstance(pb, Playbook)



# Generated at 2022-06-11 10:36:23.263226
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    import ansible.playbook
    from ansible.playbook.play_context import PlayContext
    import ansible.template
    from ansible.template import Templar

    basedir = '/tmp/ansible_include_test'
    os.makedirs(os.path.join(basedir, 'group_vars'))
    os.makedirs(os.path.join(basedir, 'host_vars'))
    os.makedirs(os.path.join(basedir, 'library'))
    os.makedirs(os.path.join(basedir, 'modules'))
    os.makedirs(os.path.join(basedir, 'roles'))
    os.makedirs(os.path.join(basedir, 'filter_plugins'))



# Generated at 2022-06-11 10:36:29.306131
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C
    dl = DataLoader()
    playbook = dl.load_from_file(C.DEFAULT_PLAYBOOK)
    pbi = PlaybookInclude(import_playbook = 'field.yml')
    entry = pbi.load_data(playbook, './')
    assert entry.__class__.__name__ == 'Playbook'

# Generated at 2022-06-11 10:36:38.884798
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # This is a test to make sure that load_data() of PlaybookInclude
    # returns the correct object (Playbook in this case)
    from ansible.playbook import Playbook
    from unit.mock.loader import DictDataLoader
    from unit.mock.path import mock_unfrackpath_noop

    pb_include = PlaybookInclude()
    loader = DictDataLoader({})
    pb = pb_include.load_data({'import_playbook': 'test.yml'},
                              basedir='/path/to/includes',
                              loader=loader)

    assert isinstance(pb, Playbook)
    assert pb.basedir == '/path/to/includes'
    assert pb._basedir == '/path/to/includes'
    mock_unfrackpath_no

# Generated at 2022-06-11 10:36:48.879896
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import tempfile
    import ansible.parsing.yaml.objects

    playbook = PlaybookInclude.load(
                    data=dict(import_playbook='../../../../../../../../../../../tmp'),
                    basedir='.')

    assert playbook is not None
    assert playbook._load_name == '/tmp'

    playbook = PlaybookInclude.load(
        data=dict(import_playbook='../../../../../../../../../../../tmp', tags="game, high"),
        basedir='.')

    assert playbook is not None
    assert playbook._load_name == '/tmp'
    assert playbook.tags == ['game', 'high']

    # test relative path
    playbook = PlaybookInclude.load(
        data=dict(import_playbook='../tmp'),
        basedir='/tmp')



# Generated at 2022-06-11 10:36:49.451498
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:37:00.224866
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    try:
        ds = dict(
            import_playbook="example",
            when=['var_name'],
            tags=['tag_name'],
            vars=dict(user='user_name')
        )
        import_playbook = PlaybookInclude.load(
            data=ds,
            basedir='.',
        )
        assert import_playbook.import_playbook == "example"
        assert import_playbook.vars['user'] == 'user_name'
        assert len(import_playbook.when) == 1
        assert import_playbook.when[0] == 'var_name'
        assert len(import_playbook.tags) == 1
        assert import_playbook.tags[0] == 'tag_name'

    except Exception as e:
        raise e

# Unit

# Generated at 2022-06-11 10:37:09.978955
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook

    PlaybookInclude.load(data=dict(import_playbook='included_playbook.yaml'), basedir='/tmp')

    new_obj = PlaybookInclude()
    new_obj.import_playbook = 'included_playbook.yaml'
    new_obj.vars = {'var1': 'baz'}
    variable_manager = None

    pb = Playbook(loader=None)
    pb.set_variable_manager(variable_manager)
    pb._load_playbook_data(file_name='included_playbook.yaml', variable_manager=variable_manager, vars={'var1': 'baz'})

# Generated at 2022-06-11 10:37:11.113371
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    raise NotImplementedError

# Generated at 2022-06-11 10:37:22.097165
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook, Play
    from ansible.parsing.plugin_docs import read_docstring

    real_loader = PlaybookInclude.load
    # a mock loader to avoid dependency loop
    def mock_load(self, ds, basedir, variable_manager=None, loader=None):
        '''
        Overrides the original load() method to create a Playbook
        with same content as the one returned by test method
        '''

        pb = Playbook()
        pb.playbook = ['test_playbook.yml']

        # create a play and attach it to the playbook
        play1 = Play().load(ds=['test_play.yml'], variable_manager=variable_manager, loader=loader)
        pb._entries.append(play1)

        # create a

# Generated at 2022-06-11 10:37:30.233874
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # import here to avoid a dependency loop
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    # init PlaybookInclude
    playbk_inc = PlaybookInclude()
    # init Playbook
    pb = Playbook()
    # load data into Playbook
    pb._load_playbook_data(file_name="../../../../test/playbooks/playbook_include/playbook_include1.yml")

    # check that the data loaded correctly into pb._entries:
    # 4 plays loaded including the last which is conditional
    # (1)
    # - name: conditional play
    #   hosts: localhost
    #   tasks:
    #     - debug: msg="true"
    #       when: "'foo' in groups"
    # - name:

# Generated at 2022-06-11 10:38:13.736597
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # The tests for this method only exists in test/unit/test_ansible_module.py
    pass

# Generated at 2022-06-11 10:38:25.559553
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.groupvars import GroupVars
    hosts = [
        Host(name="host1", port=22),
        Host(name="host2", port=22)
    ]
    groups = [Group("example", hosts=hosts)]
    inventory = InventoryManager(hosts=hosts, groups=groups)
    variable_manager = VariableManager(loader=None, inventory=inventory)
    

# Generated at 2022-06-11 10:38:32.041260
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Test normal cases
    data = {'import_playbook': '../path/to/import.yml'}
    include = PlaybookInclude.load(data, '/path/to')
    assert include._entries[0]._included_path == '/path/to/../path/to'

    # Test include using FQCN
    data = {'import_playbook': 'namespace.collection_name.playbook_name'}
    include = PlaybookInclude.load(data, '/path/to')

