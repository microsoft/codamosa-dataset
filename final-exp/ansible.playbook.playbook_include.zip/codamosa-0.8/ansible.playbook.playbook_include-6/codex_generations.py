

# Generated at 2022-06-11 10:29:02.740750
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    #imported_playbook variable is added
    ds = {'imported_playbook': 'test.yml'}
    new_ds = PlaybookInclude().preprocess_data(ds)
    assert new_ds['imported_playbook'] == 'test.yml'
    assert 'imported_playbook' in new_ds

    ds = {'import_playbook': 'test.yml'}
    new_ds = PlaybookInclude().preprocess_data(ds)
    assert new_ds['import_playbook'] == 'test.yml'
    assert 'import_playbook' in new_ds

    # import_tasks variable is deprecated
    ds = {'import_tasks': 'test.yml'}
    new_ds = PlaybookInclude().preprocess_data(ds)


# Generated at 2022-06-11 10:29:13.155544
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
  from ansible.playbook.play import Play
  from ansible.playbook.task import Task
  from ansible.playbook.task_include import TaskInclude

  import os

  ansible_base_dir = os.path.dirname(__file__)
  init_data = dict(
    import_playbook='../../../../lib/ansible/plugins/base_data/test/test_play.yml',
  )
  init_playbook_include = PlaybookInclude()
  init_playbook_include.load_data(init_data, ansible_base_dir)
  assert init_playbook_include.load_data(init_data, ansible_base_dir) is not None

# Generated at 2022-06-11 10:29:13.810819
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:29:26.475189
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.base import Base
    from ansible.parsing.yaml.data import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    basedir = '.'

    # No variables
    data = PlaybookInclude.load({'import_playbook': 'dummy.yml'}, basedir, variable_manager, loader)
    assert [type(x) for x in data.filtered_plays()] == [Base]

    # Using 'vars'
    data = PlaybookInclude.load({'import_playbook': 'dummy.yml', 'vars': {'a': 1}}, basedir, variable_manager, loader)
    assert data.fil

# Generated at 2022-06-11 10:29:37.876372
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.module_utils.six import string_types
    from ansible.config.manager import ConfigManager
    from collections import namedtuple

    ConfigManager.initialize()

    FakeDS = namedtuple("FakeDS", ("keys", "values", "get"))

    #Test a valid imput
    ansible_pos = None
    ds = FakeDS([], [], None)
    p = PlaybookInclude()
    p.preprocess_data(ds)

    # Test when the ds is not a dict
    ds = "abc"
    with p.assertRaises("ds (%s) should be a dict but was a %s" % (ds, type(ds))):
        p.preprocess_data(ds)

    # Test when k is not a valid option
    ansible_pos = None

# Generated at 2022-06-11 10:29:50.086259
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    vars = dict(a='a', b='2', c=3)
    entries = [dict(playbook_import="playbook1.yml"),
               dict(playbook_import="playbook2.yml tags=tag1,tag2"),
               dict(playbook_import="playbook3.yml vars=a=a,b=2,c=3"),
               dict(playbook_import="playbook4.yml a=a b=2 c=3"),
               dict(playbook_import="playbook5.yml tags=tag1 a=a b=2 c=3")]
    basedir = "my_basedir"
    loader = "my_loader"
    variable_manager = "my_variable_manager"

# Generated at 2022-06-11 10:30:02.112374
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    pbi = PlaybookInclude()
    pbi.import_playbook = "/path/to/playbook"
    pbi.vars = {"var1": "value1", "var2": "value2"}
    pbi.tags = ["tag1", "tag2"]
    pbi.when = ["true"]
    playbook = pbi.load_data(ds={}, basedir="/basedir", variable_manager=None, loader=None)

    assert isinstance(playbook, Playbook)
    assert isinstance(playbook._entries[0], Play)
    assert playbook._entries[0].vars["var1"] == "value1"
    assert playbook._entries[0].vars["var2"] == "value2"

# Generated at 2022-06-11 10:30:03.461969
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # TODO: Unit test for method load_data of class PlaybookInclude
    pass

# Generated at 2022-06-11 10:30:12.205816
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.conditional import Conditional
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from collections import namedtuple

    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactory

    module_loader = namedtuple('module_loader', ['all', 'find_plugin'])

# Generated at 2022-06-11 10:30:12.871696
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    pass

# Generated at 2022-06-11 10:30:18.055027
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:30:28.363689
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    import tempfile
    import os
    from ansible.parsing.yaml.loader import AnsibleLoader

    template_1 = '- import_playbook: test_play.yml'
    template_1_playbook = """
    - hosts: all
      tasks:
      - debug: 
          msg: Just a test
    """

    with tempfile.NamedTemporaryFile(suffix='.yml') as test_include:
        test_include.write(template_1.encode('utf-8'))
        test_include.flush()
        test_include_name = os.path.basename(test_include.name)


# Generated at 2022-06-11 10:30:35.013383
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    ds = dict(foo=dict(bar='baz'), import_playbook='playbook.yml', vars=dict(x=1))
    obj = PlaybookInclude()
    obj.load_data(ds=ds, basedir=os.getcwd())
    assert len(obj.vars) == 1
    assert obj.vars['x'] == 1
    assert len(obj.tags) == 0
    assert obj.import_playbook == 'playbook.yml'

    ds = dict(import_playbook='playbook.yml tags=bar', vars=dict(x=1))
    obj = PlaybookInclude()
    obj.load_data(ds=ds, basedir=os.getcwd())
    assert len(obj.vars) == 1
    assert obj.vars['x']

# Generated at 2022-06-11 10:30:45.444087
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    from ansible.vars.manager import VariableManager
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'var': 'val'}

    class MockPlay(Base):
        pass

    # STUB: make a fake 'playbook' that we can verify data is loaded onto
    pb = Base()
    pb._entries = [MockPlay()]

    # STUB: setup a fake collection to test playbook_collection
    # TODO: this is a dirty hack, make a real mock collection
    import json
    import os
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.collection_loader import find_collections

# Generated at 2022-06-11 10:30:57.168308
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    import sys
    # The module being tested is PlaybookInclude in anisble/playbook/playbook_include.py
    # We have to work with Play to extract the result
    # Also we will try to catch some errors to make sure our method is working
    ######

    # TEST CASE1
    # Without using preprocess_data to test method load_data, the name of entry should be what we assigned
    # The default constructor of PlaybookInclude let the fields None
    # Then we set attributes in our test case
    
    # Create a new Play object
    test_play1 = Play()
    # Create a new playbook_include
    test_pi1 = PlaybookIn

# Generated at 2022-06-11 10:31:05.261440
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.task_include import TaskInclude

    # The following cases are tested in this unit test
    # - import_playbook statement with positional (non-key) parameters
    # - import_playbook statement with key parameters
    # - import_playbook statement with positional parameters and vars

    # import_playbook statement with positional (non-key) parameters
    # Both ansible-playbook and import_tasks/include_tasks/import_role/include_role will issue a warning
    ds = {'import_playbook': 'pb1.yml tag'}
    results = PlaybookInclude().preprocess_data(ds)

# Generated at 2022-06-11 10:31:17.568894
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    class PlaybookIncludeMock(PlaybookInclude):
        ''' We use this mock to test load_data method of class PlaybookInclude.

            We need to override the methods load and load_data to bypass
            the preprocess_data and during the load_data method we will test
            the content of the datastructure to make sure it's correct.
        '''
        def __init__(self):
            self._ds = None

        def preprocess_data(self, ds):
            assert ds is None
            return self._ds

        def load(self, data, basedir, variable_manager=None, loader=None):
            return self.load_data(data, basedir, variable_manager, loader)

        def load_data(self, ds, basedir, variable_manager=None, loader=None):
            self

# Generated at 2022-06-11 10:31:27.854313
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook import Playbook
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-11 10:31:33.183692
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook

    playbook_include = PlaybookInclude()
    playbook_include.import_playbook = "playbook.yml"
    playbook_include.vars = dict(v="value")
    playbook = playbook_include.load_data(None, None, None)
    assert isinstance(playbook, Playbook)


# Generated at 2022-06-11 10:31:45.738922
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)

    inventory_dir = os.path.dirname(os.path.dirname(__file__))
    host_file = os.path.join(inventory_dir, "inventory/hosts")
    playbook_path = os.path.join(inventory_dir, "playbook.yaml")
    playbook_include_path = os.path.join(inventory_dir, "playbook_include.yaml")

    ds

# Generated at 2022-06-11 10:32:02.738151
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Testing load_data method of class PlaybookInclude
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    import ansible.playbook.playbook_include
    import ansible.utils.collection_loader._collection_finder


    # Make sure that load_data returns Playbook
    playbook_include = ansible.playbook.playbook_include.PlaybookInclude()
    playbook = playbook_include.load_data(ds = {'import_playbook': 'test_include.yml'}, basedir = 'tests/lib/ansible/modules/')
    assert isinstance(playbook, Playbook)
    assert isinstance(playbook._entries[0], Play)

    # Make sure that load_data returns Playbook with 2 Plays
    playbook_include = ansible.playbook.play

# Generated at 2022-06-11 10:32:13.337762
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    basedir = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'data')

    test_base = [{'import_playbook': 'play.yml'}, {'import_playbook': 'play.yml'}]
    test_base[0]['vars'] = {'key': 'value'}
    test_base[1]['vars'] = {'key': 'value', 'something': 'else'}


# Generated at 2022-06-11 10:32:21.078242
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block

    import ansible.utils.vars as vars_m
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager

    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    loader.set_basedir(os.path.join(os.path.dirname(__file__), '..', '..', '..', 'test', 'unit', 'parser', 'yaml', 'v2_playbooks'))

# Generated at 2022-06-11 10:32:33.702634
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.module_utils.six import PY2
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    def _compare_statements(expected, actual):
        def _compare(e, a):
            if isinstance(e, (dict, AnsibleMapping)) and (a is None or 'vars' not in a):
                assert len(e) == len(a)
                for key in e:
                    _compare(e[key], a[key])
            elif isinstance(e, list):
                assert len(e) == len(a)
                for i in range(len(e)):
                    _compare(e[i], a[i])
            else:
                assert e == a


# Generated at 2022-06-11 10:32:39.514842
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    """
    Unit test for method load_data of class PlaybookInclude
    """
    # Test playbook import with simple playbook name
    playbook_include = PlaybookInclude()
    playbook_include.file_name = "test"
    playbook_include.load_data(
        ds="import_playbook: test_playbook.yaml",
        basedir="../tests",
    )

    # Test playbook import with playbook name and extra args
    playbook_include = PlaybookInclude()
    playbook_include.file_name = "test"
    playbook_include.load_data(
        ds="import_playbook: test_playbook.yaml command=foo",
        basedir="../tests",
    )

    # Test playbook import with variable
    playbook_include = PlaybookInclude()
    playbook_include.file_name

# Generated at 2022-06-11 10:32:40.380741
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Not much to test
    assert True


# Generated at 2022-06-11 10:32:40.816624
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:32:46.832966
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    def _find_playbook_entry(playbook, name):
        for entry in playbook._entries:
            if name == entry._entries[0]._attributes['name']:
                return entry
        return None

    def _check_playbook_entry(playbook, name):
        entry = _find_playbook_entry(playbook, name)
        assert entry, 'entry not found: %s' % name
        return entry

    # import here to avoid a dependency loop
    from ansible.playbook.play import Play

    # play
    ds = {'import_playbook': 'test.yml', 'vars': {'foo': 'fuu'}, 'tags': ['a', 'b'], 'when': 'b == "bbb"'}
    basedir = './'


# Generated at 2022-06-11 10:32:59.374387
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''
    a test to make sure the method load_data of class PlaybookInclude.
    '''
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    example_data = '''
    - import_playbook: playbook_to_include.yml
      vars:
        var_a: a
        var_b: b
    '''
    temp_playbook_file = 'playbook_to_include.yml'
    temp_playbook_str = '---\n- hosts: localhost\n  tasks:\n    - debug: var=var_a\n...\n'
    file_name = 'test_PlaybookInclude_load_data.yml'

    temp_playbook = open(temp_playbook_file,'w')
    temp_play

# Generated at 2022-06-11 10:33:08.948608
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    loader, config_data, vault_secrets = C.get_config_loader()
    variable_manager = VariableManager(loader=loader)

    # test_PlaybookInclude_preprocess_data
    test_content = '''
    - import_playbook: test1
    - import_playbook: test2
      vars:
        a: 1
        b: two
    '''
    # test1
    test_ds = AnsibleMapping.load("test1")
    assert test_ds.get('import_playbook') == 'test1'
    assert test_ds.get('vars') == {}

    # test2
    test_ds = AnsibleMapping.load("test2")
    expected_vars = {'a': 1, 'b': 'two'}

# Generated at 2022-06-11 10:33:14.789894
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:33:25.790252
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager

    playbook_include = PlaybookInclude()
    assert playbook_include.task == None
    assert playbook_include._import_playbook == None
    assert playbook_include._parent == None

    playbook_include.load_data({ 'import_playbook': 'tests/data/playbook.yml' }, 'tests/data')
    assert playbook_include.task == 'include'
    assert playbook_include._import_playbook == 'tests/data/playbook.yml'
    assert playbook_include._parent == None

    variable_manager = VariableManager()

# Generated at 2022-06-11 10:33:36.099358
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    # Simulate variable_manager and loader
    variable_manager = VariableManager()

# Generated at 2022-06-11 10:33:42.070028
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    basedir = os.getcwd()
    playbook = PlaybookInclude.load(ds=dict(import_playbook="playbook.yml"), basedir=basedir, variable_manager=variable_manager, loader=loader)
    assert type(playbook) is not PlaybookInclude

# Generated at 2022-06-11 10:33:42.826855
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:33:43.908568
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # TODO: write unit test
    pass

# Generated at 2022-06-11 10:33:52.642556
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.playbook import Playbook

    playbook = PlaybookInclude.load(
        {
            "import_playbook": 'foo.yml',
            "vars": {
                "bar": 'baz'
            }
        },
        '/tmp/foo.yml',
    )
    assert playbook.__class__ == Playbook
    assert playbook.vars == {
        'bar': 'baz',
    }
    assert playbook._entries[0].name == 'foo'

# Generated at 2022-06-11 10:34:01.879470
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os

    import pytest
    from ansible.errors import AnsibleParserError, AnsibleAssertionError
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    # Test case data
    data1 = {'import_playbook': 'sample_include_playbook'}
    data2 = {'import_playbook': 'sample_include_playbook', 'vars': {'test1': 'test1'}}
    data3 = {'import_playbook': 'sample_include_playbook', 'tags': 'test2'}
    data4 = {'import_playbook': 'sample_include_playbook', 'vars': {'test1': 'test1'}, 'tags': 'test2'}

# Generated at 2022-06-11 10:34:07.463443
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os

    # first, we use the original parent method to correctly load the object
    # via the load_data/preprocess_data system we normally use for other
    # playbook objects
    parent = PlaybookInclude()
    result = parent.load_data(ds="a=b", basedir="c", variable_manager=None, loader=None)
    assert result is not None

# Generated at 2022-06-11 10:34:18.939041
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.utils.collection_loader._collection_finder import _get_collection_playbook_path
    from ansible.utils.collection_loader._get_collection_repo import _get_collection_repo
    from ansible.utils.collection_loader.collections_loader import _get_collection_name, _get_role_name

    # This test is to test the method load_data of class PlaybookInclude
    # created by the factory method load().
    # This method will apply the argument, basedir in _get_collection_playbook_path().
    # So we need to set the adjacant-paths in AnsibleCollectionConfig.playbook_paths
    # and the default-collection in AnsibleCollectionConfig.default_collection
    playbook_path = '/ansible-base/modules'

# Generated at 2022-06-11 10:34:31.896325
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os
    import sys
    import tempfile
    # TODO: write unit test for PlaybookInclude.load_data
    #import ansible.playbook
    #import ansible.playbook.play
    #import ansible.parsing.yaml.loader
    #import ansible.parsing.splitter
    #import ansible.template
    #import ansible.utils.display
    #import ansible.utils.vars
    # Here are some example testing values
    #ds = None
    #basedir = None
    #variable_manager = None
    #loader = None
    #try:
    #    pb_include = ansible.playbook.PlaybookInclude()
    #    pb = pb_include.load_data(ds=ds, basedir=basedir, variable_manager=variable

# Generated at 2022-06-11 10:34:43.664590
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os

    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    import pytest

    data = dict(
        import_playbook = 'test.yml'
    )

    playbook_dir = os.path.dirname(os.path.realpath(__file__))
    project_dir = os.path.dirname(playbook_dir)
    basedir = os.path.join(project_dir, 'test/playbooks')

    # first we create a playbook object
    playbook = PlaybookInclude.load(data, basedir)

    # then we test for the expected object contents
    assert playbook is not None
    assert isinstance(playbook, Playbook)
    assert len(playbook._entries) == 1

# Generated at 2022-06-11 10:34:53.563333
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.playbook import Playbook
    yaml_data = b'''
- import_playbook: test_playbook_include.yml
    name: test_playbook_include
    vars:
        test_var: test var value
    tags: test_tag
'''
    playbook_include = PlaybookInclude.load(data=yaml_data, basedir='test/test_playbook_include/', variable_manager=None, loader=AnsibleLoader(None, 'test/test_playbook_include'))
    assert playbook_include.__class__.__name__ == 'Playbook'

# Generated at 2022-06-11 10:34:55.357825
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    """Unit test for method load_data of class PlaybookInclude"""
    pass


# Generated at 2022-06-11 10:34:55.970444
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:35:06.517559
# Unit test for method load_data of class PlaybookInclude

# Generated at 2022-06-11 10:35:07.693293
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # TODO
    pass

# Generated at 2022-06-11 10:35:13.883233
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Test with playbook import using variable expansion
    line = "import_playbook: \"{{ my_playbook }}\""
    line_ds = {"import_playbook": "{{ my_playbook }}"}
    pbi = PlaybookInclude()
    processed_ds = pbi.preprocess_data(line_ds)
    assert processed_ds == line_ds


# Generated at 2022-06-11 10:35:23.061633
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    playbook_include = PlaybookInclude()

    # find a valid playbook in test/integration/playbooks
    playbook_dir_path = os.path.dirname(os.path.abspath(__file__))
    playbook_dir_path = os.path.dirname(playbook_dir_path)
    playbook_dir_path = os.path.dirname(playbook_dir_path)
    playbook_dir_path = os.path.join(playbook_dir_path, 'integration', 'playbooks')
    test_playbook_path = os.path.join(playbook_dir_path, 'test_include.yml')
    assert os.path.exists(test_playbook_path)

    # create

# Generated at 2022-06-11 10:35:35.031833
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    ds = '''
- name: import playbook
  import_playbook: test_play
  tags:
    - test_import
  vars:
    test_arg: "test_value"
    test_arg2: "test_value2"
'''
    basedir = 'tests/support/import_include'
    variable_manager = None
    loader = None
    play_book = PlaybookInclude.load(data=ds, basedir=basedir, variable_manager=variable_manager, loader=loader)
    assert len(play_book.entries) >= 1
    assert play_book.entries[0].get_name() == 'test play'
    assert play_book.entries[0].tags == ['test_import']

# Generated at 2022-06-11 10:35:47.765304
# Unit test for method load_data of class PlaybookInclude

# Generated at 2022-06-11 10:35:49.314334
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass # TODO: write this

# Generated at 2022-06-11 10:36:01.596084
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader

    # It's hard to test this method because it loads a playbook from a file.
    # Instead, we will test that the entry returned by this method is a
    # dictionary that contains the filename.
    mocker.patch("ansible.parsing.plugin_docs.PARSED_DOCS", return_value={})
    basedir = "/home/ansible/playbooks"
    variable_manager = mocker.Mock()

    loader = DataLoader()

    # The import_playbook is a relative path
    ds = dict(
        import_playbook=dict(
            playbook="../roles/common/tasks/main.yml",
            vars=dict(a=1, b=2),
            when=["condition"]
        )
    )



# Generated at 2022-06-11 10:36:11.034070
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    test_yaml = """
- import_playbook: test.yml
  vars:
    A: "B"
    C: "D"
    E: "F"
    G: "H"
  tags:
    - "A tag"
    - "Another tag"
    - "A third tag"
  when:
    - A == "B"
- import_playbook: test2.yml
  vars:
    C: "Something else"
  tags:
    - "Another tag"
  when:
    - B == "C"
    - D != "E"
- import_playbook: test3.yml
- import_playbook: test4.yml
  when:
    - B != "C"
    - D == "E"
    - F != "G"
"""

# Generated at 2022-06-11 10:36:23.156473
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    ds = dict(
        playbook_include=dict(
            playbook="playbook.yml",
            foo="bar",
            vars=dict(
                my_var="my_value",
            ),
        ),
    )
    ds_processed = dict(
        playbook_include=dict(
            import_playbook="playbook.yml",
            foo="bar",
            vars=dict(
                my_var="my_value",
            ),
        ),
    )
    obj = PlaybookInclude()
    ds_return = obj.preprocess_data(ds['playbook_include'])
    assert isinstance(ds_return, dict)
    assert ds_return == ds_processed['playbook_include']


# Generated at 2022-06-11 10:36:31.055474
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # introduce a fake loader, just to get the method to run
    from ansible.parsing.loader import DataLoader
    from ansible.vars import VariableManager

    class FakeLoader(DataLoader):
        def get_basedir(self, path):
            return 'something'

    loader = FakeLoader()
    play_book_include = PlaybookInclude()
    data = {'import_playbook': 'example.yml'}

    playbook_include_data = play_book_include.load_data(data, 'something', VariableManager(), loader)
    playbook_include_data._tasks



# Generated at 2022-06-11 10:36:31.644622
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:36:38.005648
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    ds = dict(
        import_playbook="relative_path.yml",
        vars=dict(
            foo='bar'
        )
    )

    expected_ds = dict(
        import_playbook="relative_path.yml",
        vars=dict(
            foo='bar'
        )
    )

    pbi = PlaybookInclude()
    processed_ds = pbi.preprocess_data(ds)
    assert expected_ds == processed_ds



# Generated at 2022-06-11 10:36:38.563487
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:36:48.479106
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader

    data = {'import_playbook': 'import_playbook.yml',
            'vars': {
                'host': 'localhost',
                'var': '$foo',
                'tags': 'tag1,tag2',
                'other': 'value'
                }
            }
    data['vars']['bar'] = '$var'


# Generated at 2022-06-11 10:37:29.152367
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    loader = """
    - include_tasks: foo.yml
    """

    # create a fake playbook included
    pb = PlaybookInclude()
    pb._load_playbook_data(file_name=loader, variable_manager=None, loader=None)
    play = pb._entries[0]

    assert isinstance(play, Play)
    assert len(play.tasks) == 1
    assert isinstance(play.tasks[0], Task)
    assert isinstance(play.tasks[0].block, TaskInclude)
    assert play.tasks[0].block._load_name == 'foo.yml'

# Generated at 2022-06-11 10:37:29.788959
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:37:40.188892
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.facts import DefaultDataLoader

    print("--- test PlaybookInclude.load_data ---")

    # initialize needed objects

    class PlaybookInclude_test(PlaybookInclude):

        def preprocess_data(self, ds):
            return super(PlaybookInclude_test, self).preprocess_data(ds)

    display = Display()
    loader = DataLoader()
    variable_manager = VariableManager()

    # create a playbook from a YAML file

    playbook_file = 'test_playbook_include_load_data.yml'
    playbook_file = os.path.join

# Generated at 2022-06-11 10:37:53.444109
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    # init test
    test_ds = AnsibleMapping()
    test_ds['import_playbook'] = 'test_playbook.yml'
    test_ds['tags'] = 'tagtest'
    test_ds['vars'] = {'test_k': 'test_v'}

    # run test
    test_obj = PlaybookInclude()
    result_obj = test_obj.load_data(test_ds, basedir='/test/')
    assert isinstance(result_obj, Playbook)
    assert result_obj.host_pattern is None
    assert result_obj._entries == [Play().load({'name': 'test_playbook.yml'}, basedir='/test/')]

# Generated at 2022-06-11 10:37:59.410171
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # This is just to prevent the monkey patch of _get_collection_name_from_path
    import ansible.constants as C
    C.COLLECTIONS_PATHS.pop()

    # Monkey patch _get_collection_name_from_path to simulate collection path
    def _get_collection_name_from_path_mock(path):
        return "namespace.collection"
    import ansible.utils.collection_loader._collection_finder
    ansible.utils.collection_loader._collection_finder._get_collection_name_from_path = _get_collection_name_from_path_mock

    # Monkey patch _get_collection_playbook_path to simulate collection path

# Generated at 2022-06-11 10:38:06.196895
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook

    # test that with conditional include we get a conditional marker in the play
    with_when = PlaybookInclude.load({'include': 'testdata/include.yml', 'when': 'value1 > 99'}, '.')
    assert isinstance(with_when, Playbook)
    assert len(with_when._entries) == 1
    assert isinstance(with_when._entries[0], Play)
    assert with_when._entries[0]._included_conditional == ['value1 > 99']
    assert len(with_when._entries[0].tasks) == 1

    # test that with no conditional include we get a conditional marker in the play

# Generated at 2022-06-11 10:38:17.193956
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Create an playbook_include object
    playbook_include = PlaybookInclude()

    # Create a playbook_include data structure (ds)
    # The ds is a dictionary that contains the following keys: 'import_playbook', 'vars', 'tags' and 'when'
    ds = dict(import_playbook = 'playbook.yml',
              vars = dict(a = '1', b = '2', tags = 'tag1,tag2'),
              tags = ['tag3','tag4'],
              when = 'a == b')

    # Create a variable_manager object
    variable_manager = dict(a = '2', b = '1')

    # Call the load_data method of the playbook_include object
    # with the ds, variable_manager
    # The load_data method will create a playbook object
    playbook

# Generated at 2022-06-11 10:38:17.843052
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:38:21.834166
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    assert PlaybookInclude.load({
        'import_playbook': '../other.yml',
        'vars': {'foo': 'bar'}
    }, '/path/to/file.yml')


# Generated at 2022-06-11 10:38:31.958084
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''
    Test the load_data method of class PlaybookInclude
    '''
    import sys
    import StringIO
    from ansible.parsing.yaml.loader import AnsibleLoader
    # Create the test object
    pbi = PlaybookInclude()
    # Load a YAML stream
    yaml_stream = '''
    import_playbook: ./include.yml
    '''
    data = AnsibleLoader(StringIO.StringIO(yaml_stream)).get_single_data()
    # Override the current working directory
    sys.argv = [sys.argv[0], '--connection=local']
    basedir = os.path.dirname(os.path.dirname(__file__))
    # Load the test data
    pbi.load_data(data, basedir)