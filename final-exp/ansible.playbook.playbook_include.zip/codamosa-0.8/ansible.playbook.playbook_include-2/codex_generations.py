

# Generated at 2022-06-11 10:28:52.788674
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    import ansible.playbook.play as play
    from ansible.playbook.playbook import Playbook

    from ansible.playbook.play_context import PlayContext

    from ansible.executor.task_queue_manager import TaskQueueManager

    entry = PlaybookInclude()
    entry.import_playbook = 'dummy_playbook'
    entry.vars = dict(key1='value1', key2='value2')

    playbook = Playbook.load(
        dict(name='test playbook',
             hosts='all',
             gather_facts='no',
             roles=entry),
        loader=None,
    )

    play_context = PlayContext()

# Generated at 2022-06-11 10:29:05.428157
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    valid_dicts = {
        '- import_playbook': dict(
            import_playbook='hello.yml',
        ),
        '- import_playbook: hello.yml': dict(
            import_playbook='hello.yml',
        ),
        '- import_playbook: hello.yml with_items: "{{ list }}"': dict(
            import_playbook='hello.yml',
            with_items="{{ list }}",
        ),
        '- import_playbook: hello.yml vars: a: 1': dict(
            import_playbook='hello.yml',
            vars=dict(
                a=1,
            ),
        ),
    }


# Generated at 2022-06-11 10:29:11.311840
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Checking with playbook file for import
    pb = PlaybookInclude.load(data = dict(import_playbook='playbook.yml'), basedir = '.')
    assert isinstance(pb, Playbook)
    pb = PlaybookInclude.load(data = dict(import_playbook='playbook.yml'), basedir = '.', variable_manager=None)
    assert isinstance(pb, Playbook)


# Generated at 2022-06-11 10:29:20.066396
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook

    # create a PlaybookInclude object
    pb_include = PlaybookInclude()

    # use the _load_data method to load a Playbook
    pb = pb_include.load_data(ds=dict(import_playbook="hosts"), basedir="/path/to")
    assert isinstance(pb, Playbook)
    assert len(pb._entries) > 0
    assert isinstance(pb._entries[0], Play)

# Generated at 2022-06-11 10:29:32.822434
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook

    def new_Playbook():
        return Playbook.load({"hosts": "all", "gather_facts": "no", "tasks": [{"debug": {"var": "item"}}, {"debug": {"var": "a_var"}}]}, basedir='/home/user/ansible')

    # Original file:
    # ---
    # - include_tasks: /home/user/ansible/tests/lib/t_import_playbook.yaml
    #   when: a_var
    #   tags: include_tasks_tags
    #   vars:
    #     item: value
    #     tags: vars_include_tasks_tags


# Generated at 2022-06-11 10:29:40.848336
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    #########################################################################
    #   test_PlaybookInclude_preprocess_data - Verify the preprocess_data
    #   method works correctly
    #########################################################################

    from ansible.module_utils.six.moves import StringIO
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    p = Play().load(dict(
        name = "test play",
        hosts = 'test-host',
        vars = dict(
            hello = 'world',
        ),
        tasks = [ dict(), dict() ]
    ))


# Generated at 2022-06-11 10:29:53.753228
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    import os
    import ansible.constants as C

    loader = None
    variable_manager = None

    # test simple playbook load
    playbook = PlaybookInclude()
    playbook.vars = dict(role_name='role_name')
    playbook.import_playbook = '/roles/test_role_name/test_playbook.yml'

    basedir = os.path.join(C.DEFAULT_LOCAL_TMP, 'test_PlaybookInclude_load_data')
    pb = playbook.load_data(dict(), basedir, variable_manager, loader)

    assert isinstance(pb, Playbook)
    assert len(pb._entries) == 2

# Generated at 2022-06-11 10:29:54.457002
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:30:01.664504
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.playbook_include import PlaybookInclude

    # Create the data structure for PlaybookInclude
    ds = {}
    ds["import_playbook"] = './test.yml'

    # Create a PlaybookInclude object
    obj = PlaybookInclude()

    # Execute the preprocess_data method
    result = obj.preprocess_data(ds)

    # Check the result
    assert(result['import_playbook'] == './test.yml')



# Generated at 2022-06-11 10:30:09.641906
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    test_pass = True
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager

    # loading multiple playbook files; both playbooks not needing a role

    test_pass = True
    host_list = ["testhost"]
    inventory = InventoryManager(loader=None, sources=host_list)
    variable_manager = VariableManager(loader=None, inventory=inventory)
    loader = 'test'
    pb1 = Playbook(loader=loader, variable_manager=variable_manager)
    pb1._entries = []

# Generated at 2022-06-11 10:30:25.927150
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_include import HandlerInclude
    from ansible.playbook.task_include import TaskInclude

    pb = PlaybookInclude()
    data = { "import_playbook": "../common/tasks.yml", "tags": ["here"] }
    preprocessed_data = pb.preprocess_data(data)
    assert preprocessed_data == data

    data = { "import_playbook": "../common/tasks.yml", "only_tags": ["here"] }
    preprocessed_data = pb.preprocess_data(data)
    assert preprocessed_data == data


# Generated at 2022-06-11 10:30:35.858669
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vars import combine_vars

    # with open("/home/jeremy/git/ansible/test/unit/data/playbook/playbook_include.yaml") as f:
    #     test_playbook_include = AnsibleLoader(f, vault_secrets=[], basedir="test/unit/data/playbook").get_single_data()

# Generated at 2022-06-11 10:30:46.519050
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    import ansible.parsing.yaml.objects
    import ansible.template

    class MyTemplate(ansible.template.Templar):
        def __init__(self, loader=None, variables=None):
            self._data = {}
            self._data = variables

        def template(self, data):
            template = ansible.parsing.yaml.objects.AnsibleVaultEncryptedUnicode(data, 'fake_file', 0, 0)
            return template.decrypt(self._data)

    class MyVariableManager(object):
        def __init__(self, loader=None, inventory=None):
            self._vars_cache = dict()

        def get_vars(self, loader=None, play=None, host=None, task=None):
            return self._vars_cache

   

# Generated at 2022-06-11 10:30:58.296995
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    vm = AnsibleVariableManager()
    loader = DataLoader()
    ds = dict(
        import_playbook = "./ex1-inventory.yml",
        vars=dict(a='a', b='b'),
        tags='a'
    )
    p = PlaybookInclude.load(ds, "/tmp", vm, loader)
    assert isinstance(p, Playbook)
    assert len(p._entries) == 3
    assert isinstance(p._entries[0], Play)
    assert p._entries[0].name == "Configure Apache"
    assert len(p._entries[0].tasks) == 3

# Generated at 2022-06-11 10:31:06.020255
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,',)
    variable_manager.set_inventory(inventory)

    b_ds = b'include_tasks: test.yaml\n'
    ds = PlaybookInclude.load(b_ds, basedir=b_basedir, loader=loader)
    assert(type(ds).__name__ == 'Playbook')
    assert(len(ds.playbook) == 1)
    assert(type(ds.playbook[0]).__name__ == 'Play')

# Generated at 2022-06-11 10:31:18.634160
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os
    import tempfile
    import pytest
    from ansible.collection_loader._collection_finder import _get_collection_name_from_path
    from ansible.parsing.dataloader import DataLoader

    # create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # create fake collection
    collection_path = os.path.join(tmp_dir, 'test_collections/test_ns.test_coll')
    os.makedirs(collection_path)
    os.makedirs(os.path.join(collection_path, 'playbooks'))

    # setup fixture playbooks
    test_playbook_path = os.path.join(collection_path, 'playbooks', 'main.yml')

# Generated at 2022-06-11 10:31:28.274527
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os
    import sys
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    class Options(object):
        playbook_path = None
        verbosity = 1

    basedir = os.path.dirname(__file__) + os.sep + '../playbooks' + os.sep
    file_name = 'import_playbook.yml'

    obj = PlaybookInclude.load(file_name, basedir=basedir)
    assert obj.name is None
    assert obj.tasks == []
    assert obj.roles == []
    assert obj.vars == {}


# Generated at 2022-06-11 10:31:41.150150
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    pbi = PlaybookInclude()

    # Test with empty dict
    ds = {}
    new_ds = pbi.preprocess_data(ds)
    assert new_ds == {}

    # Test that we correctly detect errors
    ds = dict(vars='test')
    try:
        new_ds = pbi.preprocess_data(ds)
        assert False
    except AnsibleParserError:
        assert True

    # Test that we correctly detect errors
    ds = dict(import_playbook=None)
    try:
        new_ds = pbi.preprocess_data(ds)
        assert False
    except AnsibleParserError:
        assert True

    # Test that we correctly detect errors
    ds = dict(import_playbook=123)

# Generated at 2022-06-11 10:31:45.377598
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include = PlaybookInclude({'import_playbook': 'file_name.yaml'})
    ds = playbook_include.load_data(ds = {'import_playbook': 'file_name.yaml'}, basedir = '.' )
    assert isinstance(ds, Playbook)

# Generated at 2022-06-11 10:31:52.532163
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()


# Generated at 2022-06-11 10:32:14.311625
# Unit test for method load_data of class PlaybookInclude

# Generated at 2022-06-11 10:32:21.557739
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    """
    PlaybookInclude: Test for preprocess_data
    """
    import pprint
    from ansible.parsing.yaml.loader import AnsibleLoader

    ploader = AnsibleLoader(None, None, None)
    ds = '''
        - import_playbook: common.yml
          vars:
            foo: 1
            bar: 2
        '''

    result = ploader.load(ds)
    pi = PlaybookInclude()
    actual = pi.preprocess_data(result[0])

    expected = {
        'import_playbook': 'common.yml',
        'vars': {
            'foo': 1,
            'bar': 2,
        }
    }

# Generated at 2022-06-11 10:32:34.199465
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook

    playbook_include = PlaybookInclude()
    playbook_include.import_playbook = "dummy_file.yml"
    playbook_include.vars = {"a":1}

    playbook = Playbook()

    playbook_include_load = PlaybookInclude.load(playbook_include, ".")
    if isinstance(playbook_include_load, Playbook):
        assert True
    else:
        assert False

    playbook_include.import_playbook = "test/test_collections/namespace1/ns_1_coll1/test_collections/namespace2/ns_2_coll1/ns_1_coll1_playbook.yml"
    playbook_include.vars = {"a":1}

    playbook_include_load_fqcn = Playbook

# Generated at 2022-06-11 10:32:43.412521
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_include import HandlerInclude
    from ansible.playbook.role import Role
    from ansible.playbook.role.task import Task
    from ansible.playbook.role.include import RoleInclude
    ds = {'hosts':'myhosts', 'import_playbook': 'myimport.yml'}

    # Play(ds) and PlaybookInclude(ds) are just two different ways to load the data ds.
    # This function will load ds into the Play() object and the PlaybookInclude()
    # object and compare the returned objects.
    def load(ds):
        import tempfile
        # host

# Generated at 2022-06-11 10:32:54.642193
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    class VarMgr:
        def __init__(self, vars):
            self._vars = vars

        def get_vars(self):
            return self._vars

    class Loader:
        pass

    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude

    playbooks = ['test_playbook.yml']
    playbook_tasks = ['tasks']

# Generated at 2022-06-11 10:33:06.230489
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import sys
    sys.path.append("/Users/shabaz/projects/ansible/ansible")
    from ansible.playbook import PlaybookInclude

    obj = PlaybookInclude.load(data={"import_playbook": "test_file.yml", "vars": {"my_var": "test_value"}},
                               basedir="/Users/shabaz/projects/ansible/ansible")
    assert obj.get_vars() == {"my_var": "test_value"}

    obj = PlaybookInclude.load(data={"import_playbook": "test_file.yml tags=test_tag,tag2"},
                               basedir="/Users/shabaz/projects/ansible/ansible")

# Generated at 2022-06-11 10:33:12.853287
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook

    basedir = os.getcwd()
    data = dict(
        __ansible_module__='include',
        import_playbook='include_playbook.yml',
        var1='value1',
        var2='value2'
    )

    playbook_include = PlaybookInclude()
    playbook = playbook_include.load_data(
        ds=data,
        basedir=basedir
    )
    assert isinstance(playbook, Playbook) is True
    assert playbook._entries is not None

# Generated at 2022-06-11 10:33:20.910532
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from .fixtures import load_fixture_file
    from ansible.parsing.dataloader import DataLoader

    dataloader = DataLoader()
    text = load_fixture_file('playbook_include.yml')
    data = dataloader.load(text)
    import_playbook = data['include']
    playbook_include = PlaybookInclude()
    playbook = playbook_include.load_data(ds=import_playbook, basedir=None, variable_manager=None, loader=None)
    assert playbook.is_valid()

# Generated at 2022-06-11 10:33:31.476481
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible import context
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    context.CLIARGS = {}
    loader = DataLoader()
    variable_manager = VariableManager()

    playbook = "tests/test_playbookinclude_load_data.yml"
    base = os.path.dirname(os.path.abspath(to_bytes(playbook, errors='surrogate_or_strict')))
    pb = PlaybookInclude.load(data=loader.load_from_file(os.path.basename(playbook)), basedir=base, variable_manager=variable_manager)
    assert len(pb._entries) == 2
    assert len(pb._entries[0].tasks) == 1
    assert pb

# Generated at 2022-06-11 10:33:39.984692
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''Test for method load_data of class PlaybookInclude'''
    from ansible.playbook import Playbook
    import os
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    #First let's create a PlaybookInclude object
    data = u'include: test.yml'
    basedir = './'
    variable_manager = VariableManager()
    loader = DataLoader()
    PlaybookInclude.load(data, basedir, variable_manager, loader)
    #Then let's create a Playbook object
    pb = Playbook(loader = loader)
    file_name = 'test.yml'

# Generated at 2022-06-11 10:33:59.244497
# Unit test for method load_data of class PlaybookInclude

# Generated at 2022-06-11 10:33:59.852290
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    pass

# Generated at 2022-06-11 10:34:10.438706
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.loader import AnsibleLoader
    import ansible.playbook.playbook as c_playbook
    import ansible.playbook.play_context as c_play_context

    loader = AnsibleLoader(None, None)
    basedir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'play')
    playbook_include = PlaybookInclude.load(dict(import_playbook="tasks/main.yaml", tags=["first"]), basedir, None, loader)
    assert isinstance(playbook_include, c_playbook.Playbook)
    assert len(playbook_include._entries) == 1

# Generated at 2022-06-11 10:34:22.089158
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    # create some tasks
    tasks = [Task() for i in range(0, 5)]

    # add some data to the tasks
    tasks[0].name = "task1_name"
    tasks[0].action = "task1_action"
    tasks[1].name = "task2_name"
    tasks[1].action = "task2_action"
    tasks[2].name = "task3_name"
    tasks[2].action = "task3_action"
    tasks[3].name = "task4_name"
    tasks[3].action = "task4_action"
    tasks[4].name

# Generated at 2022-06-11 10:34:31.311806
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os
    import sys
    import pprint
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task.include import Include
    from ansible.plugins import module_loader
    from ansible.parsing.loader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.errors import AnsibleAssertionError
    from ansible.utils.display import Display
    from ansible.template import Templar
    pp = pprint.PrettyPrinter(indent=4)


# Generated at 2022-06-11 10:34:42.930419
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task

    playbook = Playbook()
    playbook._loader, playbook._find_plugin = \
        playbook._load_plugins_from_dir('/usr/share/ansible/plugins')

    pb = PlaybookInclude()
    ds = {
        'import_playbook': 'playbook1.yml',
        'vars': {'var1': 'val1', 'var2': 'val2'},
        'tags': 'tag1,tag2'
    }
    pb.load_data(ds, '')
    new_ds = pb.preprocess_data(ds)

# Generated at 2022-06-11 10:34:54.009375
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.errors import AnsibleError
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.plugins.loader import find_plugin_loader

    # Find collection for testing
    test_collection = find_plugin_loader('ansible_collections.ansible.testns.test_collection')
    if test_collection is None:
        raise AnsibleError("Missing test collection")

    # Initialize PlaybookInclude
    pi = PlaybookInclude()

    # Create data structure
    ds = dict(import_playbook="/inc.yml", tags="T1,T2")

    # Create basic loader
    loader = CollectionLoader()
    loader.set_basedir(test_collection.path)

    # Load a playbook

# Generated at 2022-06-11 10:35:04.373104
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    test_v1 = PlaybookInclude.load({
        u"include": u"test"
    })
    assert test_v1.import_playbook == "test"

    test_v2 = PlaybookInclude.load({
        u"include": u"test vars=var1"
    })
    assert test_v2.vars == {"var1": True}

    test_v3 = PlaybookInclude.load({
        u"include": u"test vars=var1,var2=val2"
    })
    assert test_v3.vars == {"var1": True, "var2": "val2"}

    test_v4 = PlaybookInclude.load({
        u"import_playbook": u"test vars=var1,var2=val2"
    })
    assert test

# Generated at 2022-06-11 10:35:16.591284
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Valid case 1: import playbook with a single argument
    data = "test.yml"
    new_ds = PlaybookInclude.load({'import_playbook': data}, basedir='/').preprocess_data({'import_playbook': data})
    assert new_ds['import_playbook'] == data

    # Valid case 2: import playbook with multiple arguments
    data = "../playbooks/test.yml"
    new_ds = PlaybookInclude.load({'import_playbook': data}, basedir='/playbooks').preprocess_data({'import_playbook': data})
    assert new_ds['import_playbook'] == data

    # Valid case 3: import playbook with additional parameters
    data = "test.yml name=test"

# Generated at 2022-06-11 10:35:24.349852
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # test case : load_data method of PlaybookInclude class
    FileNotFoundError = __import__('builtins').FileNotFoundError

# Generated at 2022-06-11 10:35:43.934728
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    vars = dict(
        ansible_hosts = 'hosts',
        path = 'path',
        playbook = 'test.yml',
    )

    # first use a dict which is expected to work with load_data
    data = dict(
        import_playbook = '{{ path }}/{{ playbook }}',
        vars = dict(
            other_var = 'value',
        )
    )
    result = PlaybookInclude.load(data, basedir='.', variable_manager=None, loader=None)
    assert isinstance(result, Playbook)

    # now use a dict with additional parameters, which is deprecated
    # and should be removed when the function update_playbook_entries
    # is merged into load_data

# Generated at 2022-06-11 10:35:44.447893
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    pass

# Generated at 2022-06-11 10:35:56.024300
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    import ansible.constants as C
    from ansible.template import Templar
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.hashing import md5s

    # first, test a normal playbook import
    playbook_include = PlaybookInclude()
    display.vvvv = True

    data_set = dict(
        import_playbooK = 'import.yml',
    )

    playbook_include.load_data(data_set, './')

    pb = Playbook(loader=None)
    pb._load_playbook_data(playbook_include.import_playbook, variable_manager=None, vars=playbook_include.vars)



# Generated at 2022-06-11 10:36:07.464272
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    variable_manager = None
    loader = None

    # from playbook_include.yml in tests/data
    playbook_include_dict = {
        '- hosts': 'localhost',
        '  import_playbook': 'include_playbook.yml',
        '  vars': {
            'value': 1,
        }
    }

    # from include_playbook.yml in tests/data
    playbook_dict = {
        '- hosts': 'localhost',
        '  tasks': [
            {'name': 'debug', 'msg': 'PlaybookInclude did override vars'},
        ],
        '  vars': {
            'value': 'replaced',
        },
    }

    include = PlaybookIn

# Generated at 2022-06-11 10:36:07.803786
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-11 10:36:18.311620
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(loader=loader, variable_manager=variable_manager, host_list='tests/inventory'))
    playbooks = []
    playbooks.append({"import_playbook": "./test/include1.yaml"})
    playbooks.append({"import_playbook": "./test/include2.yaml", "tags": "tag1,tag2", "vars": {"var1": "val1", "var2": "val2"}})


# Generated at 2022-06-11 10:36:20.877191
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''
    Test method load_data of class PlaybookInclude.
    '''

    # TODO: Add unit test
    pass



# Generated at 2022-06-11 10:36:31.505099
# Unit test for method load_data of class PlaybookInclude

# Generated at 2022-06-11 10:36:33.361031
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''
    Test load_data method of class PlaybookInclude.
    '''
    pass


# Generated at 2022-06-11 10:36:36.700154
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    file_name = "./test_playbook_include.yml"
    return_data = PlaybookInclude.load("../test_playbook_include.yml", ".", None, None)
    assert return_data is not None

# Generated at 2022-06-11 10:37:02.709260
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''
    This test method is used to test if method load_data of class
    PlaybookInclude works as expected.
    '''
    from ansible.playbook.play import Play
    pb = PlaybookInclude()
    basedir = os.path.dirname(os.path.realpath(__file__))
    playbook = 'playbook_include.yml'
    variable_manager = None
    loader = None
    data = {'import_playbook': '../../../examples/' + playbook}
    playbook = pb.load_data(ds=data, basedir=basedir, variable_manager=variable_manager, loader=loader)
    assert isinstance(playbook, Play)

# Generated at 2022-06-11 10:37:13.454293
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    import sys
    import os
    import ansible.playbook.playbook_include as PlaybookInclude
    import ansible.playbook.play as Play
    import ansible.playbook.block as Block
    import ansible.template as Templar
    import ansible.vars.manager as VariableManager

    # Stash original modules
    original_templar = Templar.Templar
    original_variable_manager = VariableManager.VariableManager

    # Stash original method
    original_import_playbook_load_data = PlaybookInclude.PlaybookInclude.load_data

    # Stash original play class
    original_play = Play.Play


# Generated at 2022-06-11 10:37:18.239124
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook

    playbook_include = PlaybookInclude()
    # create data structure
    ds = dict(
        import_playbook = 'playbook.yml'
    )
    pb = playbook_include.load_data(ds, '.')
    assert(isinstance(pb, Playbook))

# Generated at 2022-06-11 10:37:28.233403
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.playbook import Playbook
    from ansible.errors import AnsibleParserError
    from ansible.parsing.yaml.data import DataLoader

    with open('./test/test_playbook_include_non_existent.yml', 'r') as test_pb_yml:
        try:
            pb = PlaybookInclude.load(DataLoader().load(test_pb_yml), ".", variable_manager=None, loader=None)
            assert False, "Expecting AnsibleParserError"
        except AnsibleParserError as e:
            pass


# Generated at 2022-06-11 10:37:38.588149
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import PlaybookInclude
    from ansible.playbook.play import Play

    playbook_str = u'''
- hosts: localhost
  tasks:
    - import_playbook: test_import_1.yml
    - import_playbook: test_import_2.yml
    - import_playbook: test_import_3.yml vars:
        key1: val1
        key2: val2
    - import_playbook: test_import_4.yml vars:
        key3: val3
        key4: val4
        tags: tag2, tag3, tag4
  '''

    compiled_playbook = PlaybookInclude.load(playbook_str, None)

    assert len(compiled_playbook._entries) == 4
    assert isinstance

# Generated at 2022-06-11 10:37:49.259581
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook = PlaybookInclude.load([dict(import_playbook='/my/playbook.yml', vars=dict(a=1, b=2, c=3))], '/mydir')
    assert playbook._entries
    assert len(playbook._entries) == 1
    play = playbook._entries[0]
    assert play.vars == dict(a=1, b=2, c=3)
    assert play._included_path == '/mydir'
    assert play._playbook._basedir == '/mydir'
    assert play._playbook._file_name == '/mydir/playbook.yml'

# Generated at 2022-06-11 10:37:50.349922
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # TODO: do it
    assert True

# Generated at 2022-06-11 10:38:00.553860
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play

    pbi = PlaybookInclude()
    p = pbi.load_data({ 'import_playbook': 'my.yml' }, '.', None)
    assert isinstance(p, PlaybookInclude)
    p = pbi.load_data({ 'import_playbook': 'my.yml', 'vars': { 'foo': 'bar' } }, '.', None)
    assert isinstance(p, PlaybookInclude)
    p = pbi.load_data({ 'import_playbook': 'my.yml', 'tags': ['foo', 'bar'], 'vars': { 'foo': 'bar' } }, '.', None)
    assert isinstance(p, PlaybookInclude)

# Generated at 2022-06-11 10:38:01.564965
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # TODO: write unit tests
    pass

# Generated at 2022-06-11 10:38:13.289550
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    import pytest
    import ansible.constants as C
    import os

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_loader(loader)
    templar = Templar(loader=loader, variables=variable_manager.get_vars())
    basedir = os.path.dirname(__file__)

    playbook_data = dict()
    playbook_data[C.IMPORT_PLAYBOOK] = "test_playbook_for_import.yml"