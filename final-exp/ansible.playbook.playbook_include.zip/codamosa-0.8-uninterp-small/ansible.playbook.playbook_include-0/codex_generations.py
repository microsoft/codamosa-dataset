

# Generated at 2022-06-25 05:34:46.888189
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    playbook_include = PlaybookInclude()
    playbook_include.import_playbook = "test.yml"

    playbook = Playbook()
    playbook._entries = [Play().load({'hosts': 'all'})]
    playbook._entries[0]._included_path = "/path/to/playbook"

    #import_playbook attribute does not have a 'path' attribute
    assert(playbook_include.load_data(None, "/path", None) == playbook)

if __name__ == '__main__':
    import sys, pytest
    pytest.main(sys.argv)

# Generated at 2022-06-25 05:34:58.906469
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Test with valid, dict input, and valid basedir and variable_manager
    test_data = {'import_playbook': '/a/b/c/d.yml'}
    playbook_include_1 = PlaybookInclude()
    playbook_include_1.load_data(test_data, '/a/b', None, None)
    assert playbook_include_1._import_playbook == '/a/b/c/d.yml'
    assert playbook_include_1._vars == dict()

    # Test with valid, non-dict input, and valid basedir and variable_manager
    test_data = 'import_playbook: /a/b/c/d.yml'
    playbook_include_2 = PlaybookInclude()

# Generated at 2022-06-25 05:35:03.782303
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude().load_data(ds={'import_playbook': 'test_import_playbook.yml'}, basedir='/tmp', variable_manager=None, loader=None)
    playbook_include_2 = PlaybookInclude().load_data(ds={'import_playbook': 'test_import_playbook1.yml', 'vars': {'test1': 'test0'}}, basedir='/tmp', variable_manager=None, loader=None)


# Generated at 2022-06-25 05:35:08.369620
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.load_data(ds=None, basedir='/Users/cdi/ansible-src/test/units/modules/misc/test_playbook_include.py', variable_manager=None, loader=None)



# Generated at 2022-06-25 05:35:12.770851
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    ds = {"import_playbook": "playbook_include_test.yml"}
    basedir = "./"
    playbook_include_1.load_data(ds=ds, basedir = basedir)
    assert playbook_include_1.import_playbook == "playbook_include_test.yml"


# Generated at 2022-06-25 05:35:18.060869
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    data = {"key": "value"}
    basedir = "."
    variable_manager = "variable_manager"
    loader = "loader"
    playbook_include_0._load_data(data, basedir, variable_manager, loader)



# Generated at 2022-06-25 05:35:22.432398
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_1 = PlaybookInclude()
    try:
        playbook_include_1.preprocess_data(1)
    except AnsibleAssertionError as ae:
        assert ae.args[0] == 'ds (1) should be a dict but was a <class \'int\'>'
        return True


# Generated at 2022-06-25 05:35:27.909765
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include = PlaybookInclude()
    data = ""
    basedir = ""
    variable_manager = ""
    loader = ""
    playbook_include_instance = playbook_include.load_data(data=data, basedir=basedir, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-25 05:35:32.980674
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    data = {}
    basedir = "./tests/utils/"
    variable_manager = None
    loader = None

    res = playbook_include_0.load_data(ds=data, basedir=basedir, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-25 05:35:43.243835
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    def do_test(ds, expected_ds):
        playbook_include_0 = PlaybookInclude()
        ds_actual = playbook_include_0.preprocess_data(ds)
        assert ds_actual == expected_ds, "Expected {0}, got {1}".format(expected_ds, ds_actual)


# Generated at 2022-06-25 05:35:59.807929
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {}
    path_0 = '/home/keith/src/ansible/test/units/modules/foo.yml'
    int_0 = -9357
    var_0 = playbook_include_0.load_data(dict_0, path_0, int_0)
    path_0 = '/home/keith/src/ansible/test/units/modules/foo.yml'
    int_0 = -9357
    var_0 = playbook_include_0.load_data(dict_0, path_0, int_0)
    path_0 = '/home/keith/src/ansible/test/units/modules/foo.yml'
    int_0 = -9357
    var_0 = playbook_include_0.load

# Generated at 2022-06-25 05:36:09.700438
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    template_data_0 = AnsibleMapping()
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()
    bool_10 = bool()
    bool_11 = bool()
    bool_12 = bool()
    bool_13 = bool()
    bool_14 = bool()
    bool_15 = bool()
    bool_16 = bool()
    bool_17 = bool()
    bool_18 = bool()
    bool_19 = bool()
    bool_20 = bool()

# Generated at 2022-06-25 05:36:17.919481
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    dict_1 = {}
    str_1 = '1.5.11'
    str_2 = '1.4.3'
    str_3 = '1.9.2'
    str_4 = '1.7.0'
    str_5 = '1.11.0'
    str_6 = '1.6.0'
    str_7 = '1.10.2'
    str_8 = '1.1.0'
    str_9 = '1.8.0'
    str_10 = '1.0.0'

# Generated at 2022-06-25 05:36:23.983009
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {}
    int_0 = -425
    dict_1 = {u'ansible_pos': (u'foo', 1, 2)}
    dict_0[u'ansible_pos'] = dict_1
    var_0 = playbook_include_0.load_data(dict_0, int_0)


# Generated at 2022-06-25 05:36:25.815941
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {}
    int_0 = -4212
    playbook_include_0.load_data(dict_0, int_0)


# Generated at 2022-06-25 05:36:29.797353
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    int_0 = 1617
    str_0 = 'post_tasks'
    dict_0 = {str_0: int_0}
    int_1 = -4
    str_1 = 'roles'
    var_0 = playbook_include_0.load_data(dict_0, int_1)


# Generated at 2022-06-25 05:36:36.460924
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {}
    int_0 = -25183
    # ValueError: not a directory: './'
    # ValueError: not a directory: './'
    # Python 2.7.11.
    # Ansible 2.9.9
    #exception_0 = playbook_include_0.load_data(dict_0, int_0)


# Generated at 2022-06-25 05:36:38.979941
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    inc = PlaybookInclude()
    ds = dict(import_playbook='/tmp/foo')
    inc.load_data(ds, '/foo')


# Generated at 2022-06-25 05:36:45.695890
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # instantiate PlaybookInclude class object
    playbook_include_obj = PlaybookInclude()

    # call load_data method on PlaybookInclude class object
    # TODO: create test case
    try:
        playbook_include_obj.load_data(ds=[], basedir=0)
    except NotImplementedError:
        pass


# Generated at 2022-06-25 05:36:53.186301
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {}
    int_0 = -4212
    # Test using a positional argument
    var_0 = playbook_include_0.load_data(ds=dict_0, basedir=int_0)
    # Test using a named argument

# Generated at 2022-06-25 05:37:02.171537
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    obj_0 = object()
    str_0 = ""
    res = playbook_include_0.load_data(obj_0, str_0)
    eq_(type(res), Playbook)


# Generated at 2022-06-25 05:37:06.905690
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {}
    int_0 = -4212
    variable_manager_0 = VariableManager()
    playbook_0 = playbook_include_0.load_data(dict_0, int_0, variable_manager_0)


# Generated at 2022-06-25 05:37:10.134164
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {}
    int_0 = -4212
    var_0 = playbook_include_0.load_data(dict_0, int_0)

# Generated at 2022-06-25 05:37:14.750087
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    dict_1 = {}
    int_1 = -4212
    ds = AnsibleMapping()
    ds.update(dict_1)
    str_0 = "foo.yml"
    ds['import_playbook'] = str_0
    int_0 = -4212
    playbook_include_1.load_data(ds, int_0)


# Generated at 2022-06-25 05:37:19.040480
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {}
    int_0 = -4212
    var_0 = playbook_include_0.load_data(dict_0, int_0)


# Generated at 2022-06-25 05:37:27.152622
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    AnsibleMapping_0 = AnsibleMapping()
    int_0 = -2684
    VariableManager_0 = VariableManager
    int_1 = 138
    #  VariableManager_0 = VariableManager()
    #  assert VariableManager_0 == VariableManager_0
    str_0 = "yv"
    str_1 = "P"
    setattr(AnsibleMapping_0, str_0, str_1)
    var_0 = playbook_include_0.load_data(AnsibleMapping_0, int_0, VariableManager_0, int_1)


# Generated at 2022-06-25 05:37:28.808892
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {}
    int_0 = -13111
    int_1 = 9015
    raise NotImplementedError()


# Generated at 2022-06-25 05:37:32.899068
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    dict_1 = {}
    str_1 = ""
    int_1 = -17900
    playbook_include_1.load_data(dict_1, str_1, int_1)


# Generated at 2022-06-25 05:37:36.648178
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {}
    int_0 = -4212
    var_0 = playbook_include_0.load_data(dict_0, int_0)


# Generated at 2022-06-25 05:37:39.725517
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {}
    int_0 = -1394
    var_0 = playbook_include_0.load_data(dict_0, int_0)


# Generated at 2022-06-25 05:37:53.939844
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    list_0 = ['monitor-description=monitoring']
    list_1 = ['pulse.conf']
    str_0 = "/tmp/ansible_h1KjHd/pulse.conf"
    str_1 = "${cfg['pulse']['conf_path']}"
    dict_0 = {str_0: list_0, list_1: str_1}
    dict_1 = {'pulse.conf': ['/tmp/ansible_h1KjHd/pulse.conf', 'monitor-description=monitoring']}
    str_2 = "/home/user/ansible/includes"

# Generated at 2022-06-25 05:37:56.502954
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    dict_3 = {}
    int_3 = -4212
    playbook_include_1.load_data(dict_3, int_3)


# Generated at 2022-06-25 05:38:01.259032
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    dict_1 = {}
    int_1 = -4212
    var_1 = playbook_include_1.load_data(dict_1, int_1)


# Generated at 2022-06-25 05:38:13.126004
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = dict()
    dict_0['path'] = 'path'
    dict_0['tags'] = 'tags'
    dict_0['vars'] = dict()
    int_0 = -4212
    playbook_include_0 = PlaybookInclude()
    dict_1 = dict()
    dict_1['path'] = 'path'
    dict_1['tags'] = 'tags'
    dict_1['vars'] = dict()
    int_1 = 4212
    var_0 = playbook_include_0.load_data(dict_1, int_1, int_0)
    dict_2 = dict()
    dict_2['path'] = 'path'
    dict_2['tags'] = 'tags'
    dict_2['vars'] = dict()
    int_2 = -4212


# Generated at 2022-06-25 05:38:18.581516
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {}
    int_2 = -4212
    dict_1 = playbook_include_0.load_data(dict_0, int_2)


# Generated at 2022-06-25 05:38:22.486774
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {}
    int_0 = 714
    variable_manager_0 = VariableManager()
    loader_0 = DataLoader()
    var_0 = playbook_include_0.load_data(dict_0, int_0, variable_manager_0, loader_0)



# Generated at 2022-06-25 05:38:27.996782
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {}
    int_0 = -4212
    var_0 = int_0
    var_1 = playbook_include_0.load_data(dict_0, var_0)


# Generated at 2022-06-25 05:38:31.724708
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {}
    int_0 = -4212
    var_0 = playbook_include_0.load_data(dict_0, int_0)


# Generated at 2022-06-25 05:38:40.545266
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # Input data
    data = ''
    basedir = None
    variable_manager = None
    loader = False

    # Expected output
    expected_0 = False
    expected_1 = None
    expected_2 = None

    # Using argparse to retrieve command line options
    parser = argparse.ArgumentParser(description='Unit test for Ansible module ansible.module_utils.playbook_include')
    parser.add_argument('--basedir', help='Base directory for playbook includes')
    parser.add_argument('--variable_manager', help='Variable manager for playbook includes')
    parser.add_argument('--loader', help='Loader for playbook includes')

    # Retrieving command line options
    options = parser.parse_args()

    # Assigning command line options to local variables
    basedir = options.basedir

# Generated at 2022-06-25 05:38:44.442801
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {}
    int_0 = -4212
    var_0 = playbook_include_0.load_data(dict_0, int_0)


# Generated at 2022-06-25 05:38:48.890943
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # FIXME: need test for PlaybookInclude.load_data
    pass


# Generated at 2022-06-25 05:38:55.493593
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Instantiate object
    playbook_include_1 = PlaybookInclude()

    # AssertionError when ds contains invalid value
    # with self.assertRaises(AssertionError):
    #     playbook_include_1.load_data()

    # AssertionError when basedir contains invalid value
    # with self.assertRaises(AssertionError):
    #     playbook_include_1.load_data()
    pass


# Generated at 2022-06-25 05:38:58.445320
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    any_0 = None
    str_0 = ''
    str_1 = ''
    str_2 = ''
    var_1 = playbook_include_0.load_data(any_0, str_0, str_1, str_2)

# Generated at 2022-06-25 05:39:01.285567
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    dict_1 = {}
    int_1 = -21
    variable_manager_1 = variable_manager
    loader_1 = loader
    var_1 = playbook_include_1.load_data(dict_1, int_1, variable_manager=variable_manager_1, loader=loader_1)


# Generated at 2022-06-25 05:39:07.469893
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {}
    int_0 = -4212
    str_0 = playbook_include_0.load_data(dict_0, int_0)


# Generated at 2022-06-25 05:39:10.025099
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    dict_0 = {}
    int_0 = -4212
    var_0 = playbook_include_1.load_data(dict_0, int_0)


# Generated at 2022-06-25 05:39:15.028165
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {}
    int_0 = -4229
    dict_1 = {}
    playbook_include_0.load_data(dict_0, int_0, dict_1)



# Generated at 2022-06-25 05:39:21.808354
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    (obj_0, dict_0, dict_1, int_0) = (PlaybookInclude(), {}, {}, -93425224)
    (yaql_0, int_1, dict_2) = (obj_0.load_data(dict_0, int_0), -58777020, {})
    var_0 = obj_0.load_data(dict_1, int_1, dict_2)


# Generated at 2022-06-25 05:39:26.908140
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {}
    str_0 = 'string'
    int_0 = -3656
    var_0 = playbook_include_0.load_data(dict_0, str_0, int_0)



# Generated at 2022-06-25 05:39:29.685921
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    dict_1 = {}
    int_1 = -4212
    var_1 = playbook_include_1.load_data(dict_1, int_1)


# Generated at 2022-06-25 05:39:36.741976
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    playbook_include_0 = PlaybookInclude()
    dict_0 = {'import_playbook' : 'test.yml'}
    str_0 = 'playbook.yml'
    var_0 = playbook_include_0.load_data(dict_0, str_0)
    assert isinstance(var_0, Playbook)



# Generated at 2022-06-25 05:39:38.163970
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    pass


# Generated at 2022-06-25 05:39:43.972638
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {}
    int_0 = -8992
    dict_1 = {}
    var_0 = playbook_include_0.load_data(dict_0, int_0, dict_1)


# Generated at 2022-06-25 05:39:51.853588
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {}
    int_0 = 0
    dict_1 = {}
    ansible_mapping_0 = AnsibleMapping()
    ansible_mapping_0['import_playbook'] = 'var_0'
    dict_2 = {}
    dict_2['vars'] = dict_1
    dict_3 = {}
    dict_3['vars'] = dict_1
    dict_4 = {}
    dict_4['import_playbook'] = 'var_0'
    dict_5 = {}
    dict_5['vars'] = dict_1
    dict_6 = {}
    dict_6['vars'] = dict_1
    dict_7 = {}
    dict_7['import_playbook'] = 'var_0'
   

# Generated at 2022-06-25 05:39:55.273552
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {}
    int_0 = -2898
    var_0 = playbook_include_0.load_data(dict_0, int_0)


# Generated at 2022-06-25 05:39:58.492533
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    dict_0 = {}
    int_0 = -4212
    dict_1 = playbook_include_1.load_data(dict_0, int_0)



# Generated at 2022-06-25 05:40:01.708303
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    dict_1 = {}
    int_1 = -4212
    var_1 = playbook_include_1.load_data(dict_1, int_1)


# Generated at 2022-06-25 05:40:06.140030
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    dict_0 = {}
    int_0 = -4212
    var_0 = playbook_include_1.load_data(dict_0, int_0)


# Generated at 2022-06-25 05:40:08.848225
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {}
    int_0 = -4212
    playbook_include_0.load_data(dict_0, int_0)


# Generated at 2022-06-25 05:40:14.165805
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    PlaybookInclude_instance_0 = PlaybookInclude()
    ds_0 = dict()
    basedir_0 = -14676
    variable_manager_0 = None
    loader_0 = None
    PlaybookInclude_instance_0.load_data(ds_0, basedir_0, variable_manager_0, loader_0)


# Generated at 2022-06-25 05:40:24.706200
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # import here to avoid a dependency loop
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    # first, we use the original parent method to correctly load the object
    # via the load_data/preprocess_data system we normally use for other
    # playbook objects
    new_obj = super(PlaybookInclude, self).load_data(ds, variable_manager, loader)

    all_vars = self.vars.copy()
    if variable_manager:
        all_vars.update(variable_manager.get_vars())

    templar = Templar(loader=loader, variables=all_vars)

    # then we use the object to load a Playbook
    pb = Playbook(loader=loader)


# Generated at 2022-06-25 05:40:32.561219
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {}
    dict_1 = {'ansible_pos': 37, 'vars': {'role_name': 'test', 'role_path': '/path/to/role'}}
    int_0 = -8754
    bool_0 = playbook_include_0.load_data(dict_0, int_0)
    bool_1 = playbook_include_0.load_data(dict_1, int_0)


# Generated at 2022-06-25 05:40:36.109350
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()

    # Test with error: 'str' object has no attribute 'get'
    dict_0 = 'str'
    int_1 = -5772
    try:
        playbook_include_0.load_data(dict_0, int_1)
        assert False
    except AttributeError:
        pass


# Generated at 2022-06-25 05:40:38.800618
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    playbook_include_1.load(dict_0, int_0)


# Generated at 2022-06-25 05:40:41.503000
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    obj = PlaybookInclude.load_data(ds=None, basedir=None, variable_manager=None, loader=None)
    assert obj is not None


# Generated at 2022-06-25 05:40:45.890432
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    ds_0 = {}
    basedir_0 = ""
    variable_manager_0 = None
    loader_0 = None
    new_obj_0 = playbook_include_0.load_data(ds_0, basedir_0, variable_manager_0, loader_0)


# Generated at 2022-06-25 05:40:48.958615
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    dict_1 = {}
    str_1 = 'foo'
    int_1 = -7522
    playbook_include_1.load_data(dict_1, str_1, int_1)


# Generated at 2022-06-25 05:40:51.127253
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    test_case_0()

# Generated at 2022-06-25 05:41:01.742922
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()

# Generated at 2022-06-25 05:41:06.799481
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    dict_1 = {}
    int_1 = -4212
    variable_manager = None
    loader = None
    var_1 = playbook_include_1.load_data(dict_1, int_1, variable_manager, loader)
    assert var_1 is not None
    assert var_1 == []


# Generated at 2022-06-25 05:41:25.329078
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    dict_1 = {}
    str_0 = '../test/test_playbook_includes/main.yaml'
    var_1 = playbook_include_1.load_data(dict_1, str_0)


# Generated at 2022-06-25 05:41:29.149184
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {}
    int_0 = -4212
    var_0 = playbook_include_0.load_data(dict_0, int_0)


# Generated at 2022-06-25 05:41:36.965837
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    str_0 = 'playbook_import_0'
    dict_1[str_0] = dict_2
    dict_3['stdout_callback'] = 'debug'
    dict_0['ANSIBLE_STDOUT_CALLBACK'] = dict_3
    dict_4 = {}
    dict_4['playbook_import_0'] = None
    dict_0[str_0] = dict_4
    int_0 = 3
    var_0 = playbook_include_0.load_data(dict_1, int_0)


# Generated at 2022-06-25 05:41:44.160175
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    print("")
    print("Test for PlaybookInclude::load_data()")
    print("=====================================")

    try:
        print("")
        print("Test for PlaybookInclude::load_data()", "Test #1: Base case")
        print("-------------------------------------------------------------")
        ds = {'a': 'b'}
        playbook_include_0 = PlaybookInclude()
        int_0 = 5239
        var_0 = playbook_include_0.load_data(ds, int_0)
        assert(var_0 == playbook_include_0)
    except AssertionError as e:
        print("Execution test of PlaybookInclude::load_data()", "Test #1: Base case failed")
        print("AssertionError:", e)
        return


# Generated at 2022-06-25 05:41:51.586388
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    ds_1 = {}
    basedir_1 = -1
    # TODO: This method does not exist
    #variable_manager_1 = None
    #loader_1 = None
    # TODO: This method does not exist
    # expected_1 = None
    # actual_1 = playbook_include_1.load_data(ds_1, basedir_1, variable_manager_1, loader_1)
    # assert actual_1 == expected_1


# Generated at 2022-06-25 05:41:55.871034
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {}
    str_0 = "test.yml"
    var_0 = playbook_include_0.load_data(dict_0, str_0)


# Generated at 2022-06-25 05:42:02.868515
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    dict_1 = {}
    int_8 = -1488
    dict_2 = {"vars": {}}
    all_vars = dict_2["vars"]
    all_vars.update(all_vars.copy())
    templar = Templar(all_vars=all_vars)
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    pb = Playbook()
    file_name = templar.template(playbook_include_1.import_playbook)
    playbook_collection = _get_collection_name_from_path(file_name)
    if playbook_collection:
        AnsibleCollectionConfig.default_collection = playbook_collection
    else:
        AnsibleCollectionConfig.playbook_

# Generated at 2022-06-25 05:42:08.148066
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    str_1 = 'xyz'
    int_0 = -4212
    dict_1 = {}
    int_1 = -4212
    var_1 = playbook_include_1.load_data(str_1, int_0, dict_1)


# Generated at 2022-06-25 05:42:12.042955
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    dict_0 = {}
    int_0 = -4212
    variable_manager = VariableManager()
    loader = DataLoader()
    var_0 = playbook_include_1.load_data(dict_0, int_0, variable_manager, loader)
    assert var_0


# Generated at 2022-06-25 05:42:16.181464
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    playbook_include_1 = PlaybookInclude()
    dict_0 = {'import_playbook': 'test_value_2', 'vars': dict()}
    int_0 = -6115
    var_0 = playbook_include_1.load_data(ds=dict_0, basedir=int_0)
    assert type(var_0) == Playbook



# Generated at 2022-06-25 05:42:33.813243
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {}
    int_0 = -51005
    invalid_object_0 = playbook_include_0.load_data(ds=dict_0, basedir=int_0, variable_manager=object, loader=object)


# Generated at 2022-06-25 05:42:35.532834
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {}
    int_0 = -4212
    var_0 = playbook_include_0.load(dict_0, int_0)



# Generated at 2022-06-25 05:42:37.456866
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    str_0 = "foobar"
    int_0 = 4210
    int_1 = -4212
    playbook_include_0.load_data(str_0, int_0, int_1)


# Generated at 2022-06-25 05:42:41.098330
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    data = {}
    basedir = -4212
    variable_manager = None
    loader = None
    obj = PlaybookInclude.load(data, basedir, variable_manager, loader)
    assert obj is not None


# Generated at 2022-06-25 05:42:45.728619
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {"when": "{{ csr_log_level == 'debug' }}", "import_playbook": "csr_debug.yml", "tags": ["debug"]}
    int_0 = -7954
    var_0 = playbook_include_0.load_data(dict_0, int_0)


# Generated at 2022-06-25 05:42:48.609072
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Initial setup
    playbook_include_1 = PlaybookInclude()
    str_0 = 'LM'
    int_0 = -4212
    dict_0 = {}
    var_0 = playbook_include_1.load_data(str_0, int_0, dict_0)
    # Final pass



# Generated at 2022-06-25 05:42:53.206274
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Load a tasks file.
    pb = PlaybookInclude.load(dict_0, int_0)
    # Test if the tasks loaded is equal to the original file
    assert pb == dict_0


# Generated at 2022-06-25 05:42:55.718458
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {}
    int_0 = -4212
    playbook_include_0.load(dict_0, int_0)


# Generated at 2022-06-25 05:42:58.654569
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    test_case_0()


# Generated at 2022-06-25 05:43:04.556376
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_0._import_playbook = "amaze"
    dict_0 = {}
    int_0 = 0
    # exception raised
    try:
        playbook_include_0.load_data(dict_0, int_0)
    except AnsibleParserError as exception_0:
        assert exception_0.args[0] is "import_playbook statements must specify the file name to import"
        assert exception_0.args[1] is dict_0
    else:
        assert False, "AnsibleParserError not raised"


# Generated at 2022-06-25 05:43:17.110020
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {}
    int_0 = -4212
    dict_1 = {}
    var_0 = playbook_include_0.load_data(dict_0, int_0, dict_1)
    print(var_0)


# Generated at 2022-06-25 05:43:27.408162
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # @debug
    print('Testing PlaybookInclude.load_data()')

    # Test signals:
    #    - TypeError
    #    - LoaderError
    #    - AssertionError

    # Case: 0
    try:
        playbook_include_0 = PlaybookInclude()
        dict_0 = {}
        int_0 = -4212
        playbook_include_0.load_data(dict_0, int_0)
    except Exception as exception_0:
        # @debug
        print('PlaybookInclude.load_data() raised {0} ({0.__class__.__name__}).'.format(exception_0))
    else:
        assert False, "PlaybookInclude.load_data() didn't raise an exception"
    # Case: 1

# Generated at 2022-06-25 05:43:37.659782
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pbi = PlaybookInclude()
    playbook_include_0 = pbi
    dict_0 = {}
    int_0 = -10929
    dict_1 = {}
    dict_1['foo'] = 'bar'
    dict_2 = {}
    dict_2['foo'] = 'bar'
    dict_2['bar'] = 'baz'
    dict_1['baz'] = dict_2
    dict_3 = {}
    dict_3['foo'] = 'bar'
    dict_3['bar'] = 'baz'
    dict_2['biz'] = dict_3
    dict_1['baz'] = dict_2
    dict_3['foo'] = 'bar'
    dict_3['bar'] = 'baz'
    dict_2['baz'] = dict_3
    dict_1

# Generated at 2022-06-25 05:43:42.973378
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {}
    int_0 = -4212
    playbook_include_0.load_data(dict_0, int_0)


# Generated at 2022-06-25 05:43:44.623472
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data(): 
    pass

# Generated at 2022-06-25 05:43:49.910288
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {}
    int_0 = -4212
    dict_1 = {}
    int_1 = -4212
    dict_0 = playbook_include_0.load_data(dict_1, int_0, dict_0)


# Generated at 2022-06-25 05:43:52.520980
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    data = 'foo'
    basedir = 'bar'
    variable_manager = 'baz'
    loader = 'quux'
    var_1 = playbook_include_1.load_data(data, basedir, variable_manager, loader)


# Generated at 2022-06-25 05:43:59.145715
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pbi = PlaybookInclude()
    ds = dict()
    basedir = None
    variable_manager = None
    loader = None
    output = pbi.load_data(ds, basedir=basedir, variable_manager=variable_manager, loader=loader)
    assert output == None


# Generated at 2022-06-25 05:44:03.101496
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    dict_1 = {}
    int_1 = -4212
    dict_1 = playbook_include_1.preprocess_data(dict_1)
    var_1 = playbook_include_1.load_data(dict_1, int_1)


# Generated at 2022-06-25 05:44:07.264805
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    obj = PlaybookInclude(import_playbook=True, vars=True)
    ds = True
    basedir = True
    # No exception raised for missing arg.
    obj.load_data(ds, basedir)


# Generated at 2022-06-25 05:44:20.398808
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # Test case with assert_equal from ansible.module_utils._text import to_bytes
    # as output

    # Testcase with a dictionary as input
    test_case_0()

if __name__ == "__main__":

    # Execute unit tests
    test_PlaybookInclude_load_data()

# Generated at 2022-06-25 05:44:23.117983
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {}
    int_0 = -4212
    var_0 = playbook_include_0.load_data(dict_0, int_0)
