

# Generated at 2022-06-25 05:34:37.686800
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # import here to avoid a dependency loop
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = playbook_include_0.load_data(ds="import.yml", basedir='/etc', variable_manager=None, loader=None)

    assert playbook_include_1.__class__.__name__ == 'Playbook'

    playbook_include_2 = playbook_include_0.load_data(ds="import.yml", basedir='/etc', variable_manager=None, loader=None)

    assert playbook_include_2.__class__.__name__ == 'Playbook'



# Generated at 2022-06-25 05:34:42.728543
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.load_data()

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 05:34:52.922219
# Unit test for method preprocess_data of class PlaybookInclude

# Generated at 2022-06-25 05:34:56.957398
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    assert playbook_include_1.load_data() is None


# Generated at 2022-06-25 05:34:57.845106
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # TODO
    assert False


# Generated at 2022-06-25 05:35:03.122068
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.load_data(ds={},basedir='../../../examples/enable_mode.yml',variable_manager=None,loader=None)


# Generated at 2022-06-25 05:35:04.593868
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()

# Generated at 2022-06-25 05:35:07.448768
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.import_playbook = "file0"
    playbook_include_0.vars = dict()


# Generated at 2022-06-25 05:35:18.748041
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Create obj
    playbook_include_1 = PlaybookInclude()

    # Create dict
    dict_2 = dict()

    # Assign value to dict
    dict_2['ansible_position'] = [None, 'task', None]
    dict_2['import_playbook'] = 'Playbook_3.yml'

    # Create dict
    dict_3 = dict()

    # Assign value to dict
    dict_3['test'] = 'Test_5'

    # Assign value to dict
    dict_2['vars'] = dict_3

    # Call method
    result = playbook_include_1.preprocess_data(dict_2)

    # Check result
    assert result.get('ansible_pos') == [None, 'task', None], 'Result does not match'

# Generated at 2022-06-25 05:35:30.310785
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # simple import case
    data = {'import_playbook': '../test/test.x.yml'}  # expected
    assert PlaybookInclude.load(data, '')._ds == data

    # simple import case with tags
    data = {'import_playbook': 'include.yml tags="foo,bar"', 'tags': ['not', 'a', 'real', 'play']}  # expected
    assert PlaybookInclude.load(data, '')._ds == {'import_playbook': 'include.yml', 'tags': ['foo', 'bar']}

    # simple import case with tags and vars

# Generated at 2022-06-25 05:35:43.326713
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
  str_0 = 'h1wkC2'
  str_1 = 'second'
  playbook_include_0 = PlaybookInclude()
  playbook_include_0.load_data(str_0, str_1)


# Generated at 2022-06-25 05:35:45.548879
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = 'oJ'
    str_1 = 'second'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(str_0, str_1)


# Generated at 2022-06-25 05:35:48.275685
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = 'oJ'
    str_1 = 'second'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(str_0, str_1)


# Generated at 2022-06-25 05:35:50.197686
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    pass



# Generated at 2022-06-25 05:35:52.798089
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    ds_0 = dict()
    playbook_include_0 = PlaybookInclude()
    ansible_mapping_0 = playbook_include_0.preprocess_data(ds_0)


# Generated at 2022-06-25 05:35:56.037953
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    print("Testing preprocess_data() of class PlaybookInclude")
    assert isinstance(PlaybookInclude.preprocess_data, Callable)


# Generated at 2022-06-25 05:36:07.608917
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    str_0 = 'oJ'
    str_1 = 'second'
    playbook_include_0 = PlaybookInclude()
    dict_0 = dict()
    dict_0['import_playbook'] = 'file1.yml'
    dict_0['vars'] = dict()
    dict_0['vars']['a'] = 'b'
    dict_0['vars']['c'] = 'd'
    dict_0['tags'] = 'one'
    dict_0['when'] = 'second'
    dict_0['register'] = 'first'
    dict_0['ignore_errors'] = 'false'
    dict_0['changed_when'] = 'true'
    dict_0['failed_when'] = 'true'
    dict_0['succeed'] = True
    dict_0

# Generated at 2022-06-25 05:36:12.508159
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = 'oJ'
    str_1 = 'second'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load(str_0, str_1)



# Generated at 2022-06-25 05:36:14.427793
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = 'oJ'
    str_1 = 'second'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(str_0, str_1)


# Generated at 2022-06-25 05:36:20.519253
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    """
    load_data test cases
    Load the information from a string that defines the playbook import

    """
    str_0 = 'pv'
    str_1 = 'second'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load(str_0, str_1)

# Generated at 2022-06-25 05:36:29.709873
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    ds_0 = 'r:r:r'
    basedir_0 = 'lZh'
    playbook_include_0 = PlaybookInclude()
    playbook_0 = playbook_include_0.load_data(ds_0, basedir_0)

if __name__ == '__main__':
    # test_case_0()
    # test_PlaybookInclude_load_data()
    pass

# Generated at 2022-06-25 05:36:36.313990
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    str_0 = 'second'
    str_1 = 'oJ'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.preprocess_data(str_0)
    playbook_include_0.preprocess_data(str_1)
    var_1 = var_0
    if var_0 != var_1:
        raise Exception('AssertionError')


# Generated at 2022-06-25 05:36:37.556268
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Test the method load_data of class PlaybookInclude
    pass


# Generated at 2022-06-25 05:36:40.750592
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = 'second'
    str_1 = 'oJ'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(str_0, str_1)


# Generated at 2022-06-25 05:36:46.387902
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
  print('Testing load_data')
  str_0 = 'first'
  str_1 = 'second'
  playbook_include_0 = PlaybookInclude()
  playbook_include_0.load_data(str_0, str_1)


# Generated at 2022-06-25 05:36:49.145260
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = 'oJ'
    str_1 = 'second'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load(str_0, str_1)



# Generated at 2022-06-25 05:36:53.655689
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_1 = 'second'
    str_0 = 'oJ'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load(str_0, str_1)


# Generated at 2022-06-25 05:36:58.384376
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = 'v+'
    str_1 = '''mail_web_users'''
    playbook_include_0 = PlaybookInclude()
    # Call method load_data of playbook_include_0
    var_0 = playbook_include_0.load_data(str_0, str_1)


# Generated at 2022-06-25 05:37:04.324546
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    str_0 = 'oJ'
    str_1 = 'second'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load(str_0, str_1)
    var_1 = playbook_include_0.preprocess_data(str_0)


# Generated at 2022-06-25 05:37:13.003324
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    
    playbook_include_0 = PlaybookInclude()
    str_0 = 'i'
    str_1 = '1'
    str_2 = '_'
    str_3 = 'y'
    str_4 = 'f'
    str_5 = 'Y'
    str_6 = 't'
    str_7 = '.'
    str_8 = 'l'
    str_9 = '^'
    str_10 = '>'
    str_11 = 'g'
    str_12 = '}'
    str_13 = 'b'
    str_14 = '_'
    str_15 = 'o'
    str_16 = 'G'
    str_17 = '1'
    str_18 = '<'
    str_19 = 'z'

# Generated at 2022-06-25 05:37:26.129045
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    basedir = '.'
    data = {}
    playbook_include_1 = PlaybookInclude()
    PlaybookInclude.load_data(playbook_include_1, data, basedir)
    # Use __str__ only if you want to debug.
    print(playbook_include_1)


# Generated at 2022-06-25 05:37:31.501447
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    str_0 = 'oJ'
    str_1 = 'second'
    str_2 = 'name'
    str_3 = 'Ansible'
    playbook_include_0.vars[str_2] = str_3
    assert playbook_include_0.preprocess_data(playbook_include_0.load_data(str_0, str_1)) == {'import_playbook': 'oJ',
                                                                                               'vars': {'name': 'Ansible'}}

# Generated at 2022-06-25 05:37:39.556488
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    str_0 = 'first'
    str_1 = 'second'
    playbook_include_0 = PlaybookInclude()
    data = AnsibleMapping()
    str_2 = 'vars'
    data[str_2] = AnsibleMapping()
    data[str_2] = 'a'
    str_3 = 'key'
    data[str_3] = AnsibleMapping()
    str_4 = 'value'
    data[str_3][str_4] = 'a'
    res_0 = playbook_include_0.preprocess_data(data)


# Generated at 2022-06-25 05:37:42.471356
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = 'oJ'
    str_1 = 'second'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(str_0, str_1)


# Generated at 2022-06-25 05:37:43.545790
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # TODO: add test for this method
    pass


# Generated at 2022-06-25 05:37:49.158984
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    str_0 = 'W'
    str_1 = 'C'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.preprocess_data(str_0, str_1)


# Generated at 2022-06-25 05:37:59.561463
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os

    str_0 = 'C:\\work\\ansible\\ansible-2.2.1\\lib\\ansible\\playbook\\playbook_include.py'
    str_1 = 'ansible.parsing.yaml.objects.AnsibleMapping'
    str_2 = 'ansible.parsing.yaml.objects.AnsibleBaseYAMLObject'
    str_3 = 'second'
    str_4 = 'C:\\work\\ansible\\ansible-2.2.1\\lib\\ansible\\utils\\sentinel.py'
    obj_0 = PlaybookInclude()
    obj_0.load = MagicMock(return_value = 'string')
    obj_0.load_data = MagicMock()

# Generated at 2022-06-25 05:38:04.886148
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = 'oJ'
    str_1 = 'second'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(str_0, str_1)


# Generated at 2022-06-25 05:38:06.232509
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()
    str_0 = '0'
    str_1 = 'first'
    playbook_include_0.preprocess_data(str_0)


# Generated at 2022-06-25 05:38:16.628843
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    str_0 = 'oJ'
    str_1 = 'second'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load(str_0, str_1)
    str_2 = 'oJ'
    str_3 = 'second'
    playbook_include_1 = PlaybookInclude()
    var_1 = playbook_include_1.load(str_2, str_3)
    str_4 = 'oJ'
    str_5 = 'second'
    playbook_include_2 = PlaybookInclude()
    var_2 = playbook_include_2.load(str_4, str_5)
    str_6 = 'oJ'
    str_7 = 'second'
    playbook_include_3 = PlaybookInclude()

# Generated at 2022-06-25 05:38:29.851805
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = 'o@'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(str_0, str_0)


# Generated at 2022-06-25 05:38:34.214531
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    str_0 = 'second'
    str_1 = 'oJ'
    playbook_include_0 = PlaybookInclude()
    ansible_mapping_0 = playbook_include_0.preprocess_data(str_0)
    print(ansible_mapping_0)


# Generated at 2022-06-25 05:38:35.671946
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    str_0 = 'oJ'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.preprocess_data(str_0)


# Generated at 2022-06-25 05:38:38.407409
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = {'a': 'b'}
    playbook_include_1 = playbook_include_0.preprocess_data(var_0)


# Generated at 2022-06-25 05:38:40.797895
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    str_0 = 'oJ'
    str_1 = 'second'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load(str_0, str_1)

# Generated at 2022-06-25 05:38:45.118180
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    print('')
    # This is a sample test method for unit testing of class PlaybookInclude.
    # You may remove or add test methods here as required.
    str_0 = 'oJ'
    str_1 = 'second'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load(str_0, str_1)
    # Add your test method calls here
    # Unit test for method load_data of class PlaybookInclude

# Generated at 2022-06-25 05:38:49.458798
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = 'oJ'
    str_1 = 'second'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(str_0, str_1)

# Generated at 2022-06-25 05:38:51.082022
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    obj = PlaybookInclude()
    obj.data = {}
    assert obj.data == {}



# Generated at 2022-06-25 05:38:54.476939
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = 'i'
    str_1 = 'test'
    try:
        playbook_include_0 = PlaybookInclude()
        var_0 = playbook_include_0.load_data(str_0, str_1)
    except AssertionError:
        pass


# Generated at 2022-06-25 05:38:56.754741
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = 'oJ'
    str_1 = 'second'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(str_0, str_1)


# Generated at 2022-06-25 05:39:09.371424
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = 'oJ'
    str_1 = 'second'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(str_0, str_1)


# Generated at 2022-06-25 05:39:12.796248
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    str_0 = 'oJ'
    str_1 = 'second'
    playbook_include_0.load_data(str_0, str_1)

# Generated at 2022-06-25 05:39:23.894009
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Prerequisite test case for method preprocess_data of class PlaybookInclude

    # Assumption: _preprocess_import is not really a unit test as it does a lot.
    #   It will be tested visually.
    # Prerequisite test case for method _preprocess_import of class PlaybookInclude
    playbook_include_0 = PlaybookInclude()
    str_0 = 'a'
    str_1 = 'b'
    dict_0 = dict()
    dict_1 = dict()
    dict_1['a'] = dict()
    dict_1['b'] = dict()
    dict_0['a'] = dict_1['a']
    dict_0['b'] = dict_1['b']
    dict_2 = dict()
    dict_2['a'] = dict_1['a']

# Generated at 2022-06-25 05:39:26.948566
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    c = PlaybookInclude()
    try:
        c.load_data
    except AttributeError:
        pass
    else:
        raise AssertionError(
            "Expected AttributeError"
        )


# Generated at 2022-06-25 05:39:29.723188
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = 'vA'
    str_1 = 'first'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(str_0, str_1)


# Generated at 2022-06-25 05:39:34.442267
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    print(PlaybookInclude.load_data.__doc__)



# Generated at 2022-06-25 05:39:39.524814
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_2 = 'second'
    playbook_include_1 = PlaybookInclude()
    var_1 = playbook_include_1.load_data(None, str_2)
    # Test log message of class PlaybookInclude
    assert playbook_include_1._log_messages == []


# Generated at 2022-06-25 05:39:44.978997
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    str_0 = 'oJ'
    str_1 = 'second'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.preprocess_data(str_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 05:39:51.123595
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # Create an instance of PlaybookInclude and invoke preprocess_data() method
    playbook_include_0 = PlaybookInclude()
    str_2 = 'abc'
    ds_0 = playbook_include_0.load(str_2)
    new_ds_0 = playbook_include_0.preprocess_data(ds_0)

# Generated at 2022-06-25 05:39:54.004635
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = 'eY'
    str_1 = 'second'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(str_0, str_1)


# Generated at 2022-06-25 05:40:07.672178
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = 'oJ'
    str_1 = 'second'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(str_0, str_1)


# Generated at 2022-06-25 05:40:16.295137
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
  playbook_include = PlaybookInclude()
  str_0 = 'test1'
  str_1 = 'test2'
  str_2 = 'test3'
  dict_0 = dict()
  dict_0[str_0] = str_1
  dict_0[str_2] = dict_0
  obj = AnsibleMapping()
  obj.ansible_pos = dict_0
  dict_1 = dict()
  dict_1[str_2] = dict_0
  dict_1[str_0] = str_1
  dict_0[str_2] = dict_0
  dict_1[str_2] = dict_0
  dict_0[str_2] = dict_0
  dict_1[str_2] = dict_0
  dict_0[str_2]

# Generated at 2022-06-25 05:40:21.152195
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = 'oJ'
    str_1 = 'second'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load(str_0, str_1)


# Generated at 2022-06-25 05:40:23.216774
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = 'oJ'
    str_1 = 'second'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(str_0, str_1)


# Generated at 2022-06-25 05:40:26.581106
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    str = 'oJ'
    playbook_include = PlaybookInclude()
    ret = playbook_include.preprocess_data(str)
    assert ret is None

# Generated at 2022-06-25 05:40:30.113800
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = 'oJ'
    str_1 = 'second'
    playbook_include_0 = PlaybookInclude()
    assert playbook_include_0.load_data(str_0, str_1) == None


# Generated at 2022-06-25 05:40:35.065359
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = '*j_H'
    str_1 = '\x03\x1f'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(str_0, str_1)


# Generated at 2022-06-25 05:40:38.649870
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    data = 'oJ'
    basedir = 'second'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(data, basedir)


# Generated at 2022-06-25 05:40:42.425108
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = '/'
    str_1 = 'second'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(str_0, str_1)


# Generated at 2022-06-25 05:40:45.517268
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = 'oJ'
    str_1 = 'second'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(str_0, str_1)



# Generated at 2022-06-25 05:41:08.677921
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-25 05:41:11.177413
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Data
    ds = "'oJ'"
    playbook_include_0 = PlaybookInclude()
    # Action
    new_ds = playbook_include_0.preprocess_data(ds)
    # Test
    assert new_ds == "oJ"

# Generated at 2022-06-25 05:41:15.758088
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    '''
    Unit test for method preprocess_data of class PlaybookInclude
    '''
    playbook_include_0 = PlaybookInclude()
    assert playbook_include_0.preprocess_data(self=playbook_include_0) == None



# Generated at 2022-06-25 05:41:20.151061
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = 'oJ'
    str_1 = 'second'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(str_0, str_1)


# Generated at 2022-06-25 05:41:21.820828
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    print("test_PlaybookInclude_preprocess_data")
    str_0 = ''
    playbook_include_0 = PlaybookInclude()
    dict_0 = {}
    ansible_pos_0 = Ansi

# Generated at 2022-06-25 05:41:23.777650
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = '6h'
    str_1 = 'second'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(str_0, str_1)


# Generated at 2022-06-25 05:41:32.992348
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    str_0 = 'YQ'
    str_1 = 'P\x06\x07\x03\x1f\x1b\x1c\x1e'
    variable_manager_0 = VariableManager()

# Generated at 2022-06-25 05:41:35.765626
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    str_0 = 'oJ'
    str_1 = 'second'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.preprocess_data(str_0)

# Generated at 2022-06-25 05:41:42.844946
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()
    str_0 = 'simple_playbook.yml'
    dict_0 = dict()
    dict_0['import_playbook'] = str_0
    dict_0['vars'] = dict()
    dict_0['vars']['var_0'] = '0'
    dict_0['vars']['var_1'] = '1'
    dict_0['vars']['var_2'] = '2'
    dict_0['vars']['var_3'] = '3'
    dict_0['tags'] = 'tag_0'
    dict_0['tags'] = 'tag_1'
    playbook_include_0.preprocess_data(dict_0)


# Generated at 2022-06-25 05:41:48.375398
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = 'oJ'
    str_1 = 'second'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load(str_0, str_1)



# Generated at 2022-06-25 05:42:35.299187
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    assert 1 == 1

# Generated at 2022-06-25 05:42:40.861129
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = 'oJ'
    str_1 = 'second'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(str_0, str_1)



# Generated at 2022-06-25 05:42:45.790311
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()
    int_0 = 1
    str_0 = 'vars'
    dict_0 = dict()
    dict_0[str_0] = int_0
    dict_1 = dict()
    dict_2 = dict()
    dict_2[str_0] = dict_0
    result = playbook_include_0.preprocess_data(dict_2)
    assert result == dict_1

# Generated at 2022-06-25 05:42:47.219423
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = 'oJ'
    str_1 = 'second'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load(str_0, str_1)


# Generated at 2022-06-25 05:42:57.523972
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_7 = os.path.join('..', '..')
    str_5 = 'file_1.yml'
    str_6 = 'file_2.yml'
    str_3 = 'first'
    str_4 = 'second'
    with open(str_5, 'w') as file_0:
        file_0.write('---\n')
        file_0.write('- debug:\n')
        file_0.write("    msg: '{{key}}'\n")
        file_0.write("\n")
    with open(str_6, 'w') as file_0:
        file_0.write('---\n')
        file_0.write('- debug:\n')
        file_0.write("    msg: '{{key}}'\n")
        file_

# Generated at 2022-06-25 05:43:00.557615
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = 'j'
    str_1 = 'test'
    playbook_include_0 = PlaybookInclude()
    pb_0 = playbook_include_0.load_data(str_0, str_1)
    #assert type(pb_0) is Playbook


# Generated at 2022-06-25 05:43:03.483894
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = 'oJ'
    str_1 = 'second'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(str_0, str_1)


# Generated at 2022-06-25 05:43:09.391929
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = '1'
    str_1 = 'second'
    basedir_0 = 'third'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(str_0, str_1)
    var_1 = playbook_include_0.load_data(str_0, str_1, variable_manager='fourth')
    var_2 = playbook_include_0.load_data(str_0, str_1, variable_manager='fourth', loader='fifth')
    var_3 = playbook_include_0.load_data(str_0, basedir_0)
    var_4 = playbook_include_0.load_data(str_0, basedir_0, variable_manager='fourth')
    var_5 = playbook_include_0.load_data

# Generated at 2022-06-25 05:43:18.157596
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = 'oJ'
    str_1 = 'second'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load(str_0, str_1)
    str_2 = 'third                  '
    dict_0 = dict()
    dict_0['second'] = 'third'
    dict_0['first'] = 'oJ'
    var_1 = playbook_include_0.load_data(str_0, str_1, variable_manager=dict_0, loader=str_2)
    var_2 = playbook_include_0.load(str_0, str_1)


# Generated at 2022-06-25 05:43:24.512676
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    str_0 = 'lz'
    str_1 = 'oZN'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.preprocess_data(str_0, str_1)
    assert var_0 == (str_0, str_1) == (str_0, str_1), 'Expected assertions to be equal'
