

# Generated at 2022-06-25 05:34:30.056326
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # initialize the object
    in_obj = PlaybookInclude()
    in_obj.vars = {'key': 'value'}
    in_obj.tags = ['tag1']
    # test
    out_obj = in_obj.preprocess_data({'key':'value'})
    assert out_obj['vars']['key'] == 'value'
    assert out_obj['tags'] == ['tag1']


# Generated at 2022-06-25 05:34:36.811124
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_1 = PlaybookInclude()

    ds = { "vars": { "foo": "bar" }, "import_playbook": "test_file"}
    playbook_include_1.preprocess_data(ds)
    assert playbook_include_1.vars["foo"] == "bar"
    assert playbook_include_1.import_playbook == "test_file"

# Generated at 2022-06-25 05:34:39.557258
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()


# Generated at 2022-06-25 05:34:45.183740
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    from ansible.utils.display import Display
    from ansible.utils.collection_loader._collection_finder import _get_collection_name_from_path, _get_collection_playbook_path

    yaml_data = {'include': 'matts_playbook.yml', 'vars': {'var1': 'value1'}}
    playbook_include_obj = PlaybookInclude()

    playbook_include_obj._load_data(yaml_data)
    playbook_include_obj.preprocess_data(yaml_data)

    assert playbook_include_obj._import_playbook == 'matts_playbook.yml'
    assert playbook_include_obj._vars == {'var1': 'value1'}


# Generated at 2022-06-25 05:34:53.078443
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_1 = PlaybookInclude()
    ds = '''\
          - role: some role
            foo: bar
            include:
              - include_me_0.yml
              - include_me_1.yml
              - include_me_2.yml
            foo: bar
            bam: baz
            foo: bar
        '''
    new_ds = AnsibleMapping()
    if isinstance(ds, AnsibleBaseYAMLObject):
        new_ds.ansible_pos = ds.ansible_pos
    new_ds['foo'] = 'bar'
    new_ds['bam'] = 'baz'
    new_ds['import_playbook'] = 'include_me_0.yml'
    if not isinstance(ds, dict):
        raise Ansible

# Generated at 2022-06-25 05:34:59.208848
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()
    ds_0 = {}
    ds_0['import_playbook'] = 'common.yml'
    try:
        playbook_include_0.preprocess_data(ds_0)
    except AnsibleParserError as e:
        assert(False)


# Generated at 2022-06-25 05:35:06.043301
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    ds = ''
    basedir = ''
    result_PlaybookInclude_load_data = playbook_include_0.load_data(ds, basedir)
    assert result_PlaybookInclude_load_data == None


# Generated at 2022-06-25 05:35:07.790141
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    t_PlaybookInclude = PlaybookInclude()
    t_result = t_PlaybookInclude.load_data()
    assert False

# Generated at 2022-06-25 05:35:19.337501
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.splitter import parse_yaml_from_bytes
    playbook_include_1 = PlaybookInclude()
    # Load a playbook
    # Load yaml data
    data = """
- name: Include a playbook
  hosts: all
  gather_facts: no
  import_playbook: test.yaml
"""
    yaml_data = dict(parse_yaml_from_bytes(data.encode(), AnsibleMapping, loader=None))
    # Create a variable manager
    variable_manager = {'hostvars': {}}


# Generated at 2022-06-25 05:35:27.468770
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    playbook_include_2 = PlaybookInclude()
    playbook_include_2.load_data(ds={'import_playbook': '/tmp/playbook.yml'}, basedir='/tmp')
    playbook_include_3 = PlaybookInclude()
    playbook_include_3.load_data(ds={'import_playbook': '/tmp/playbook.yml', 'vars': {'test': '{{test}}'}}, basedir='/tmp')

# Generated at 2022-06-25 05:35:36.347261
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()


# Generated at 2022-06-25 05:35:41.613803
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()

    # Test case #1:
    # PlaybookInclude.load_data called with value of None / no value provided
    # Expectation: AnsibleAssertionError should be thrown
    try:
        playbook_include_0.load_data(None)
    except AnsibleAssertionError as e:
        print("Expected exception: " + repr(e))
    except Exception as e:
        print("Unexpected exception: " + repr(e))
    else:
        print("Didn't raise any exception")

    # Test case #2:
    # PlaybookInclude.load_data called with value of something other than a dict
    # Expectation: AnsibleAssertionError should be thrown

# Generated at 2022-06-25 05:35:48.442693
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include = PlaybookInclude()
    ds = {}
    # Test with a valid ds
    playbook_include.load_data(ds, None)
    try:
        # Test with an invalid ds
        playbook_include.load_data(ds, None, False)
    except AnsibleParserError as e:
        print('Expected AnsibleParserError raised')


# Generated at 2022-06-25 05:35:57.131611
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    with pytest.raises(AnsibleAssertionError) as excinfo:
        playbook_include_1 = PlaybookInclude.load('{"import_playbook": "test_name.YAML"}', 'basedir', variable_manager='variable_manager', loader='loader')
    assert 'ds (import_playbook: test_name.YAML) should be a dict but was a unicode' in str(excinfo.value)

    playbook_include_2 = PlaybookInclude.load('{"import_playbook": "test_name.YAML"}', 'basedir', variable_manager='variable_manager', loader='loader')


# Generated at 2022-06-25 05:36:07.769022
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()

    # Try calling load_data method with ds that is an instance of AnsibleMapping, basedir that is an instance of string_types, variable_manager that is an instance of VariableManager and loader that is an instance of DataLoader
    # Should raise an instance of TypeError
    try:
        playbook_include_0.load_data(ds=AnsibleMapping(), basedir=str(), variable_manager=VariableManager(), loader=DataLoader())
    except TypeError:
        pass

    # Try calling load_data method with ds that is an instance of AnsibleBaseYAMLObject, basedir that is an instance of string_types, variable_manager that is an instance of VariableManager and loader that is an instance of DataLoader
    # Should raise an instance of TypeError

# Generated at 2022-06-25 05:36:16.419603
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    """
    Test case for load_data of class PlaybookInclude.

    """
    # load_data() is not a static method so we will create a test class object
    test_obj_PlaybookInclude = PlaybookInclude()
    # load_data has multiple parameter so we will create a dictionary
    # and can be used for passing to the method load_data().
    number_of_parameters = ['ds', 'basedir', 'variable_manager', 'loader']
    value_of_parameters = [None, None, None, None]
    parameters = dict(zip(number_of_parameters, value_of_parameters))
    # this method is called with the above parameters
    # and test the output.

# Generated at 2022-06-25 05:36:20.180611
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-25 05:36:25.043983
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    """
    Test case for method load_data of class PlaybookInclude
    """
    playbook_include_1 = PlaybookInclude()
    playbook_include_1.load_data(ds={u'import_playbook': u'../../../../../../../../../../../../../../../../etc/hosts'},
                                 basedir=u'/tmp/',
                                 variable_manager={u'include_vars': '/', u'terms': [u'localhost']},
                                 loader={'_basedir': '/tmp/'})

# Generated at 2022-06-25 05:36:26.398187
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    x=PlaybookInclude()
    x.load_data({"name": "test"},'/path/to/sample')


# Generated at 2022-06-25 05:36:33.696325
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # test positive case 1
    playbook_include_1 = PlaybookInclude()
    playbook_include_1.load_data("test_playbook.yml", ".", "", "")
    assert playbook_include_1 != None

    # test positive case 2
    playbook_include_2 = PlaybookInclude()
    playbook_include_2.load_data("playbook including other playbooks", ".", "", "")
    assert playbook_include_2.import_playbook != None

    # test negative case 1
    playbook_include_3 = PlaybookInclude()
    try:
        playbook_include_3.load_data("test_playbook.yml", ".", "", "")
        assert not "An exception should have been raised"
    except AnsibleParserError:
        pass


# Generated at 2022-06-25 05:36:48.753259
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # test_case_0
    playbook_include_0 = PlaybookInclude()
    ds = dict()
    ds['vars'] = {}
    ds['import_playbook'] = 'test'
    basedir = 'test'
    variable_manager = None
    loader = None
    playbook_include_1 = playbook_include_0.load_data(ds, basedir, variable_manager, loader)

# Generated at 2022-06-25 05:37:00.282528
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    m0 = dict()
    m1 = dict()
    v0 = 'foo'
    m0['bar'] = v0
    m1['var'] = m0
    v1 = dict()
    v1['var'] = dict()
    v1['var']['bar'] = v0
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(m1, None)
    #assert playbook_include_0.vars == v1
    #assert playbook_include_0.import_playbook == v0
    #assert playbook_include_0.tags == list()
    playbook_include_1 = PlaybookInclude()
    var_1 = playbook_include_1.load_data(dict(), None)
    #assert playbook_include_1.vars == dict

# Generated at 2022-06-25 05:37:05.296235
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(playbook_include_1)
    assert(isinstance(var_0, AnsibleParserError))


# Generated at 2022-06-25 05:37:08.692008
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    basedir_0 = './list'
    var_0 = playbook_include_0.load_data(playbook_include_0, basedir_0)


# Generated at 2022-06-25 05:37:12.228314
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    ds = {}
    basedir = {}
    variable_manager = {}
    loader = {}
    var_0 = playbook_include_0.load_data(ds, basedir, variable_manager, loader)
    assert var_0 == playbook_include_0


# Generated at 2022-06-25 05:37:15.009929
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude()
    var_0 = playbook_include_1.load_data(playbook_include_0, playbook_include_0)


# Generated at 2022-06-25 05:37:19.266316
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude()
    var_0 = playbook_include_1.load_data(playbook_include_0, playbook_include_0)


# Generated at 2022-06-25 05:37:22.355437
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    test_case_0()

# Generated at 2022-06-25 05:37:27.638120
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()


# Generated at 2022-06-25 05:37:29.401386
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.preprocess_data(playbook_include_0)

# Generated at 2022-06-25 05:37:39.906679
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    print('Testing load_data')

    test_case_0()


# Generated at 2022-06-25 05:37:43.339598
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    print('First test:')
    print('First test:')
    var_0 = playbook_include_0.load_data(None, None)
    var_1 = playbook_include_0.load_data(None, None)


# Generated at 2022-06-25 05:37:45.135851
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(ds, basedir, variable_manager, loader)


# Generated at 2022-06-25 05:37:47.115930
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude()
    var_0 = playbook_include_1.load_data(playbook_include_0, playbook_include_0)


# Generated at 2022-06-25 05:37:53.790317
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude()
    res = playbook_include_1.load_data(playbook_include_0, playbook_include_0)
    assert res is not None


# Generated at 2022-06-25 05:37:57.076145
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    fake_ds = { }
    fake_ds['import_playbook'] = 'foo'
    fake_ds['vars'] = { 'bar': 'baz' }
    obj = PlaybookInclude()
    obj.load_data(ds=fake_ds)

# Generated at 2022-06-25 05:37:58.466057
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include = PlaybookInclude()
    playbook_include.load_data(None, None)
    assert "Import" == "Replace this with a meaningful test"


# Generated at 2022-06-25 05:38:05.262808
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude()

    playbooks = [
        playbook_include_0,
        playbook_include_1
    ]


# Generated at 2022-06-25 05:38:06.373963
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    assert True


# Generated at 2022-06-25 05:38:10.664036
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_obj_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude()
    var_0 = playbook_include_1.load_data(playbook_include_obj_0, playbook_include_obj_0)


# Generated at 2022-06-25 05:38:28.264127
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude()
    var_0 = playbook_include_1.load_data(playbook_include_0, playbook_include_0)


# Generated at 2022-06-25 05:38:32.016999
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include = PlaybookInclude()
    try:
        playbook_include.load_data(playbook_include, playbook_include)
    except:
        pass
    else:
        assert False, "Failed to raise error"


# Generated at 2022-06-25 05:38:35.963479
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    yml_str = '''
        - name: test
          import_playbook: test.yml
    '''

    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.vars.manager import VariableManager

    ds = AnsibleLoader(yml_str, None, True).get_single_data()
    playbook_include = PlaybookInclude()
    playbook_include.load_data(ds, '.', variable_manager=VariableManager())
    assert playbook_include.import_playbook == 'test.yml'
    playbook_include_2 = PlaybookInclude()
    playbook_include_2.load_data(ds, '.', variable_manager=VariableManager())
    assert playbook_include_

# Generated at 2022-06-25 05:38:44.058189
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = PlaybookInclude()
    var_1 = PlaybookInclude()
    var_2 = str()
    var_3 = list()
    var_4 = dict()

    # Run test
    var_0.load_data(var_1, var_2, var_3, var_4)



# Generated at 2022-06-25 05:38:50.028108
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude()
    var_0 = playbook_include_1.load_data(playbook_include_0, playbook_include_0)
    assert var_0 is not None
    assert var_0._loader is not None
    assert var_0._entries is not None

# Generated at 2022-06-25 05:38:58.103570
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    # Test with invalid argument
    try:
        var_0 = playbook_include_0.load_data("test_String", "test_String", "test_String")
    except SystemExit as exception:
        var_0 = None
        assert exception.code == 1
    else:
        assert False

    # Test with invalid argument
    # Failure expected because wrong arguments are passed, method should be skipped
    try:
        var_0 = playbook_include_0.load_data("test_String", "test_String", "test_String", "test_String")
    except SystemExit as exception:
        var_0 = None
        assert exception.code == 1
    else:
        assert False


# Generated at 2022-06-25 05:39:02.297507
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # test case 0:
    test_case_0()


if __name__ == "__main__":
    print("This test file will test each method in class PlaybookInclude")
    print("Method load_data will be tested in test_PlaybookInclude_load_data")
    test_PlaybookInclude_load_data()

# Generated at 2022-06-25 05:39:03.694867
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude()
    var_0 = playbook_include_1.load_data(playbook_include_0, playbook_include_0)

# Generated at 2022-06-25 05:39:07.021180
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_2 = PlaybookInclude()
    var_0 = playbook_include_2.load_data(playbook_include_2, playbook_include_2)


# Generated at 2022-06-25 05:39:13.115820
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude()
    playbook_include_2 = PlaybookInclude()
    playbook_include_3 = PlaybookInclude()
    
    playbook_include_3.vars = {}
    playbook_include_3.tags = []
    playbook_include_3._import_playbook = 'playbook.yml'
    
    var_0 = playbook_include_1.load_data(playbook_include_0, playbook_include_0)
    var_1 = playbook_include_2.load_data({'vars': {'ansible_ssh_pass': 'password'}, 'import_playbook': 'playbook.yml'}, playbook_include_0)

# Generated at 2022-06-25 05:39:58.327448
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    text_0 = ""
    str_0 = ""
    playbook_include_0 = PlaybookInclude()
    text_1 = ""
    playbook_include_1 = PlaybookInclude()
    str_1 = ""
    var_0 = playbook_include_1.load_data(text_1, playlist_include_1, playbook_include_0)

# Generated at 2022-06-25 05:40:01.127884
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_load = PlaybookInclude()
    assert playbook_include_load.load_data("file", "/tmp/test")

# Generated at 2022-06-25 05:40:11.664324
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    playbook_include_1 = PlaybookInclude()
    playbook_include_2 = PlaybookInclude()
    playbook_include_3 = PlaybookInclude()
    playbook_include_4 = PlaybookInclude()
    var_1 = playbook_include_1.load_data(playbook_include_2, playbook_include_3)
    var_2 = playbook_include_1.load_data(playbook_include_3, playbook_include_2)
    var_3 = playbook_include_1.load_data(playbook_include_3, playbook_include_3)
    var_4 = playbook_include_1.load_data(playbook_include_4, playbook_include_4)


# Generated at 2022-06-25 05:40:16.735360
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude()
    var_0 = playbook_include_1.load_data(playbook_include_0, playbook_include_0)


# Generated at 2022-06-25 05:40:18.563846
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(playbook_include_0, playbook_include_0)


# Generated at 2022-06-25 05:40:22.673187
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude()

    # Call method load_data of PlaybookInclude
    try:
        var_0 = PlaybookInclude.load_data(playbook_include_0, playbook_include_0)
    except AnsibleAssertionError as var_1:
        assert False


# Generated at 2022-06-25 05:40:24.612103
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # Run test_case_0()
    test_case_0()


# Generated at 2022-06-25 05:40:26.681684
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    result = PlaybookInclude.load_data()
    assert Falsy(result)


# Generated at 2022-06-25 05:40:38.755548
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os
    import tempfile
    import shutil
    os.environ['HOME'] = '/tmp'
    var_0 = tempfile.mkdtemp()
    temp_dir_0 = tempfile.mkdtemp()
    temp_file_0 = tempfile.mkstemp()
    temp_file_1 = tempfile.mkstemp()
    os.close(temp_file_0[0])
    os.close(temp_file_1[0])
    var_1 = '#!/usr/bin/python'
    var_2 = '# -*- coding: utf-8 -*-'
    var_3 = '# (c) 2012, Michael DeHaan <michael.dehaan@gmail.com>'

# Generated at 2022-06-25 05:40:41.444185
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_2 = PlaybookInclude()
    var_1 = playbook_include_2.load_data(playbook_include_2, playbook_include_2)


# Generated at 2022-06-25 05:41:44.465571
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude()
    var_0 = playbook_include_1.load_data(playbook_include_0, playbook_include_0)


# Generated at 2022-06-25 05:41:50.581969
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    data = "something"
    basedir = None
    variable_manager = None
    loader = None

    try:
        obj = PlaybookInclude()
        obj.load_data(data, basedir, variable_manager, loader)
    except Exception as e:
        if e.message == "playbook import parameter is missing":
            pass
        else:
            raise e


# Generated at 2022-06-25 05:41:56.113254
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include = PlaybookInclude()
    ds = {'_ignore_tags': ['password'], 'extra_settings': {'host_key_checking': False}, 'import_playbook': 'dependent-playbook.yml'}
    basedir = 'test_value_2'
    playbook_include.load_data(ds, basedir)


# Generated at 2022-06-25 05:41:58.126182
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    assert playbook_include_1.load_data(playbook_include_0, playbook_include_0)


# Generated at 2022-06-25 05:41:59.394309
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include = PlaybookInclude()
    var_0 = playbook_include.load_data(playbook_include, playbook_include)


# Generated at 2022-06-25 05:42:02.234636
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    assert playbook_include_0.load_data(playbook_include_0, playbook_include_0) == playbook_include_0.load_data(playbook_include_0, playbook_include_0)


# Generated at 2022-06-25 05:42:08.961810
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    data_0 = AnsibleMapping()
    data_1 = AnsibleMapping()
    basedir_0 = '/var/lib/awx'
    var_0 = playbook_include_0.load_data(data_0, basedir_0)
    # AssertionError: ds () should be a dict but was a <class 'ansible.parsing.yaml.objects.AnsibleMapping'>


# Generated at 2022-06-25 05:42:10.518335
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include = PlaybookInclude()
    assert playbook_include.load_data() == None

# Generated at 2022-06-25 05:42:14.702959
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    (playbook_include_0, playbook_include_1) = playbook_include_0.load_data(playbook_include_0, playbook_include_0)
    (playbook_include_0, playbook_include_1) = playbook_include_0.load_data(playbook_include_1, playbook_include_0)


# Generated at 2022-06-25 05:42:19.767549
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude()
    var_0 = playbook_include_1.load_data(playbook_include_0, playbook_include_0)