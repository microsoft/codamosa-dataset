

# Generated at 2022-06-25 05:34:37.361112
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.load_data()


# Generated at 2022-06-25 05:34:47.148672
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_1 = PlaybookInclude()
    playbook_include_1.preprocess_data('~ ~/ ~')
    playbook_include_2 = PlaybookInclude()
    playbook_include_2.preprocess_data('/path/to/file /path/to/file /path/to/file')
    playbook_include_3 = PlaybookInclude()
    playbook_include_3.preprocess_data('0 1 2 3 4 5 6 7 8')
    playbook_include_4 = PlaybookInclude()
    playbook_include_4.preprocess_data('0 1 2 3 4 5 6 7 8')
    playbook_include_5 = PlaybookInclude()
    playbook_include_5.preprocess_data('0 1 2 3 4 5 6 7 8')
    playbook_include_6 = PlaybookInclude()
    playbook_

# Generated at 2022-06-25 05:34:58.983064
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import_playbook = "../../playbook.yml"
    # vars is not required
    vars = {}

    playbook_include_0 = PlaybookInclude()
    playbook_include_0.vars = {}
    playbook_include_0.import_playbook = import_playbook

    data = {}
    data["vars"] = vars
    data[C._ACTION_IMPORT_PLAYBOOK] = import_playbook

    # basedir is not required
    basedir = "."
    variable_manager = None
    loader = None
    pb = playbook_include_0.load_data(data, basedir, variable_manager, loader)
    assert isinstance(pb, object)

    # TODO: compare file_name and playbook
    # print(file_name)
    # print(playbook)




# Generated at 2022-06-25 05:35:07.050108
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()
    # Preprocess playbook include data
    playbook_include_0.preprocess_data({"import_playbook": "./test.yml", "tags": "set_tags"})
    # Assert the playbook import name
    assert playbook_include_0.import_playbook == "./test.yml"
    # Assert the playbook tags
    assert playbook_include_0.tags == ['set_tags']
    # Assert the playbook variables
    assert playbook_include_0.vars == {}



# Generated at 2022-06-25 05:35:09.609096
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    """
        PlaybookInclude.load_data(ds = None, basedir = None, variable_manager =  None, loader = None)
    """


# Generated at 2022-06-25 05:35:10.188464
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-25 05:35:18.654117
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    testcase = dict(
        import_playbook=0,
        vars=dict(
            a=1,
            b=2,
        ),
    )

    pbi = PlaybookInclude()
    actual = pbi.preprocess_data(testcase)
    expected = dict(
        import_playbook=0,
        vars=dict(
            a=1,
            b=2,
        ),
        when=None,
    )
    assert actual == expected


# Generated at 2022-06-25 05:35:28.981693
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # Test with a string as input
    playbook_include_0 = PlaybookInclude()
    result = playbook_include_0.preprocess_data(ds=None, basedir=None)

    # Test with a string as input
    playbook_include_1 = PlaybookInclude()
    result = playbook_include_1.preprocess_data(ds="", basedir=None)

    # Test with a list as input
    playbook_include_2 = PlaybookInclude()
    result = playbook_include_2.preprocess_data(ds=[], basedir=None)

    # Test with a dictionary as input
    playbook_include_3 = PlaybookInclude()
    result = playbook_include_3.preprocess_data(ds={}, basedir=None)

    # Test with an integer as input
    playbook_include_4 = Playbook

# Generated at 2022-06-25 05:35:31.924771
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    playbook_include_1.load_data("", "")


# Generated at 2022-06-25 05:35:36.946463
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Test playbook_include with empty dict
    playbook_include_1 = PlaybookInclude()
    result_1 = playbook_include_1.preprocess_data({})
    assert result_1 == {}

    # Test playbook_include with dict
    playbook_include_2 = PlaybookInclude()
    result_2 = playbook_include_2.preprocess_data({'import_playbook': 'test/test_playbook.yml'})
    assert result_2 == {'import_playbook': 'test/test_playbook.yml'}


# Generated at 2022-06-25 05:35:44.950617
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()
    list_0 = []
    playbook_include_0.preprocess_data(list_0)


# Generated at 2022-06-25 05:35:47.219336
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = AnsibleMapping()
    playbook_include_0.preprocess_data(var_0)


# Generated at 2022-06-25 05:35:52.798891
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    try:
        playbook_include_0.load_data(None, None)
        assert False  # expected exception
    except AnsibleAssertionError:
        assert True
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-25 05:35:55.812332
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Test PlaybookInclude.preprocess_data() with a simple yaml string
    test_preprocess_data_0()

    # Test PlaybookInclude.preprocess_data() with a complicated yaml string
    test_preprocess_data_1()


# Generated at 2022-06-25 05:36:04.082253
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    var_1 = dict()
    var_1['a'] = 'bad'
    var_1['b'] = 'good'
    list_1 = []
    var_2 = playbook_include_1.load_data(var_1, var_2)
    assert var_2[0].vars['a'] == 'bad'
    assert var_2[0].vars['b'] == 'good'


# Generated at 2022-06-25 05:36:11.295832
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_1 = PlaybookInclude()
    var_1 = {('import_playbook', 'a'): 'b', 'k': 'v'}
    var_1 = playbook_include_1.preprocess_data(var_1)


# Generated at 2022-06-25 05:36:12.289160
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    test_case_0()

# Generated at 2022-06-25 05:36:14.402477
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # set up objects and methods
    playbook_include_0 = PlaybookInclude()
    dictionary_0 = {}

    # testing
    var_0 = playbook_include_0.preprocess_data(dictionary_0)
    assert var_0 is None


# Generated at 2022-06-25 05:36:17.570705
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {}
    dict_1 = playbook_include_0.preprocess_data(dict_0)
    var_0 = isinstance(dict_1, AnsibleBaseYAMLObject)
    assert var_0 == True


# Generated at 2022-06-25 05:36:19.286135
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    list_0 = []
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(list_0, list_0)

# Generated at 2022-06-25 05:36:25.538853
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.preprocess_data(list_0)


# Generated at 2022-06-25 05:36:28.691311
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # Arguments for the method
    list_0 = []
    list_1 = []

    # Instantiate the object
    playbook_include_0 = PlaybookInclude()

    # Call the method
    var_0 = playbook_include_0.load_data(list_0, list_1)

    # Test the result
    assert var_0 is None




# Generated at 2022-06-25 05:36:35.431741
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    list_0 = []
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(list_0, list_0)
    test_PlaybookInclude_load_data_0()
    test_PlaybookInclude_load_data_1()
    test_PlaybookInclude_load_data_2()


# Generated at 2022-06-25 05:36:41.206843
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    obj = PlaybookInclude()
    list_0 = []
    basedir_0 = list_0
    variable_manager = None
    loader = None
    var_0 = obj.load_data(list_0, basedir_0, variable_manager, loader)
    # Check that the return type is a Playbook instance
    assert isinstance(var_0, Playbook)


# Generated at 2022-06-25 05:36:47.371555
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    ds = [u'my_hosts.yml', u'my_hosts.yml']
    ds_0 = [u'my_hosts.yml']
    ds_1 = []
    ds_2 = []
    basedir = [u'my_hosts.yml']
    variable_manager = [u'my_hosts.yml']
    loader = []
    playbook_include_0 = PlaybookInclude()
    playbook_include_0._load_playbook_data = lambda ds=ds, variable_manager=variable_manager, vars=ds_0: None
    playbook_include_1 = PlaybookInclude()
    var_0 = playbook_include_1.load_data(ds_1, basedir, variable_manager=variable_manager, loader=loader)
    playbook_

# Generated at 2022-06-25 05:36:54.053599
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    list_0 = []
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(list_0, list_0)


if __name__ == '__main__':
    test_case_0()
    test_PlaybookInclude_load_data()

# Generated at 2022-06-25 05:36:57.921283
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    list_0 = []
    playbook_include_1 = PlaybookInclude()
    var_1 = playbook_include_1.load_data(list_0, list_0)
    print()
    # variable_manager=self.variable_manager, loader=self.loader


# Generated at 2022-06-25 05:36:58.977288
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    pass


# Generated at 2022-06-25 05:37:03.058772
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    assert isinstance(playbook_include_0.load_data([], []), Base)


# Generated at 2022-06-25 05:37:06.392766
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_obj = PlaybookInclude()
    ds = {}
    ds_preprocess_data = playbook_include_obj.preprocess_data(ds)
    assert ds_preprocess_data is not None


# Generated at 2022-06-25 05:37:14.783607
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    try:
        assert playbook_include_0.load_data() != None
    except Exception as exception:
        print(exception)


# Generated at 2022-06-25 05:37:19.910318
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
  playbook_include_0 = PlaybookInclude()
  ds = []
  basedir = []
  variable_manager = None
  loader = None
  var_0 = playbook_include_0.load_data(ds,basedir,variable_manager,loader)
  assert var_0 == None


# Generated at 2022-06-25 05:37:21.791233
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    print("test_PlaybookInclude_load_data:")

    test_case_0()


# Generated at 2022-06-25 05:37:24.438185
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    list_0 = []
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(list_0, list_0)

# Generated at 2022-06-25 05:37:29.439940
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import tempfile
    with tempfile.TemporaryDirectory() as dirname:
        f = tempfile.NamedTemporaryFile(dir=dirname, delete=False)
        f.write(b'- hosts: localhost')
        f.flush()
        import_playbook = f.name
        playbook_include_1 = PlaybookInclude()
        var_1 = playbook_include_1.load_data([import_playbook], dirname)

# Generated at 2022-06-25 05:37:36.061839
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    importConfig = {
        'import_playbook': 'test.yml',
        'vars': {'test': 'test'},
    }
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(importConfig, ['test.yml', 'test.yml'])
    assert var_0._file_name == 'test.yml'

# Generated at 2022-06-25 05:37:42.546083
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = dict()
    dict_1 = dict(a=(3 * 2))
    dict_2 = dict(a=(2 * 3))
    dict_1['b'] = dict_2
    dict_3 = dict()
    dict_3['c'] = dict_1
    dict_4 = dict()
    dict_4['d'] = dict_3
    list_0 = []
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(dict_4, list_0)


# Generated at 2022-06-25 05:37:51.148560
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    ds = '/tmp/test'
    basedir = '/tmp/test'
    var_0 = playbook_include_0.load_data(ds, basedir)
    # expected output 
    # {"failed": true, "msg": "An error occurred while loading the playbook"}
    if var_0 is not None:
        print('var_0 is NOT None')
        print(var_0)
    else:
        print('No output')


# Generated at 2022-06-25 05:37:56.212979
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = AnsibleBaseYAMLObject(None, None)
    var_0.ansible_pos = None
    var_0['import_playbook'] = 'test_value'
    var_0['vars'] = {}
    var_1 = playbook_include_0.preprocess_data(var_0)


# Generated at 2022-06-25 05:37:59.296764
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    test_case_0()

# Generated at 2022-06-25 05:38:07.261276
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    list_0 = []
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(list_0, list_0)


# Generated at 2022-06-25 05:38:17.280507
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    list_0 = []
    dict_0 = dict()
    dict_0['ansible_pos'] = (1,1)
    dict_0['_ansible_no_log'] = (False, False)
    dict_0['_ansible_verbosity'] = (0, 0)
    dict_0['_ansible_version'] = (2, 7)
    dict_0['import_playbook'] = 'tasks'
    dict_0['vars'] = dict()
    dict_0['vars']['ansible_pos'] = (0, 0)
    dict_0['vars']['_ansible_no_log'] = (False, False)
    dict_0['vars']['_ansible_verbosity'] = (0, 0)

# Generated at 2022-06-25 05:38:18.009783
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    test_case_0()


# Generated at 2022-06-25 05:38:22.023979
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = dict()
    dict_0['playbook import'] = 'playbook.yml'
    dict_0['playbook import']['tags'] = 'tag1,tag2,tag3'
    dict_0['playbook import']['vars'] = dict()
    dict_0['playbook import']['vars']['var1'] = 'value1'
    dict_0['playbook import']['vars']['var2'] = 'value2'
    dict_0['playbook import']['vars']['var3'] = 'value3'
    dict_0['playbook import']['vars']['var4'] = dict()

# Generated at 2022-06-25 05:38:26.453181
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    list_0 = []
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(list_0, list_0)
    print(var_0)


# Generated at 2022-06-25 05:38:32.016402
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # For example:
    list_0 = []
    playbook_include_0 = PlaybookInclude()
    print('assert playbook_include_0.load_data(list_0, list_0) == None')
    assert playbook_include_0.load_data(list_0, list_0) == None


# Generated at 2022-06-25 05:38:35.886361
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    list_0 = []
    list_1 = ['import_playbook', 'path/to/file']
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(list_1, list_0)


# Generated at 2022-06-25 05:38:40.128237
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    playbook_include_0 = PlaybookInclude()
    playbook_0 = Playbook()
    var_0 = playbook_include_0.load_data(playbook_0, 'basedir', 'variable_manager', 'loader')

    assert type(var_0) == Playbook


# Generated at 2022-06-25 05:38:43.319577
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(list(), list())
    assert var_0 == None, "Did not return the right value"


# Generated at 2022-06-25 05:38:45.942293
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    list_0 = []
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(list_0, list_0)

# Generated at 2022-06-25 05:38:57.947029
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    try:
        list_1 = []
        playbook_include_1 = PlaybookInclude()
        var_1 = playbook_include_1.load_data(list_1, list_1)
        assert var_1 == None
    except:
        print('Failed to test method load_data of class PlaybookInclude')


# Generated at 2022-06-25 05:39:00.048748
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # create object
    obj = PlaybookInclude()
    # check load_data function
    try:
        obj.load_data()
    except Exception as e:
        assert str(e) == 'Not implemented'



# Generated at 2022-06-25 05:39:01.441495
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    list_0 = []
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(list_0, list_0)

# Generated at 2022-06-25 05:39:07.499491
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    list_0 = []
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(list_0, list_0)
    # assert playbook_include_0.should_run


# Generated at 2022-06-25 05:39:11.082812
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    list_0 = []
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(list_0, list_0)


# Generated at 2022-06-25 05:39:13.729821
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    test_case_0()


# Generated at 2022-06-25 05:39:18.428138
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    list_0 = []
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(list_0, list_0)
    assert var_0 == list_0
    

# Generated at 2022-06-25 05:39:20.338965
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    assert playbook_include_0.load_data(list_0, list_0)


# Generated at 2022-06-25 05:39:26.023015
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    list_0 = [1, 2, 3]
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.load_data(list_0, list_0)


# Generated at 2022-06-25 05:39:28.552531
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    list_0 = []
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(list_0, list_0)

# Generated at 2022-06-25 05:39:42.422138
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    ds_0 = list()
    basedir_0 = list()
    variable_manager_0 = None
    loader_0 = None
    try:
        var_0 = playbook_include_0.load_data(ds_0, basedir_0, variable_manager_0, loader_0)
    except Exception as err:
        var_0 = str(err)
        assert "PlaybookInclude expects a dictionary for its ds argument" in var_0

# Generated at 2022-06-25 05:39:46.178752
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    list_0 = []
    list_1 = []
    var_0 = playbook_include_0.load_data(list_0, list_1)
    assert var_0 == playbook_include_0


# Generated at 2022-06-25 05:39:49.195462
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    list_0 = []
    playbook_include_0 = PlaybookInclude()
    list_1 = [1, 2, 3]
    list_2 = [7, 4, 5]
    var_1 = playbook_include_0.load_data(list_1, list_2)

# Generated at 2022-06-25 05:39:53.350830
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    try:
        test_case_0()
    except AnsibleParserError as e:
        assert repr(e) == repr(('', 'This module requires key=value arguments ([""])', '', ''))
    except AssertionError as e:
        assert False


# Generated at 2022-06-25 05:39:57.392883
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    """
    load and pre-process data for PlaybookInclude
    """
    list_0 = []
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(list_0, list_0)


test_case_0()

# Generated at 2022-06-25 05:39:59.890520
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    list_0 = []
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(list_0, list_0)


# Generated at 2022-06-25 05:40:02.999602
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    test_case_0()


# Generated at 2022-06-25 05:40:07.451777
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    list_0 = []
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(list_0, list_0)
    var_0 = playbook_include_0.load_data(list_0, list_0)


# Generated at 2022-06-25 05:40:13.216135
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # Setup
    list_0 = []
    playbook_include_0 = PlaybookInclude()

    # Invoke
    var_0 = playbook_include_0.load_data(list_0, list_0)


# Generated at 2022-06-25 05:40:15.938572
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    ds_0 = ""
    basedir_0 = ""
    var_0 = playbook_include_0.load_data(ds_0, basedir_0)


# Generated at 2022-06-25 05:40:41.221652
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    list_0 = []
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(list_0, list_0)
    assert var_0.__class__.__name__ == 'list'


# Generated at 2022-06-25 05:40:45.428026
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    list_0 = ['abc', '0']
    list_1 = ['a', 'b']
    var_0 = playbook_include_0.load_data(list_0, list_1)
    # Should not raise error
    return var_0

# Generated at 2022-06-25 05:40:51.996384
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    loader = AnsibleLoader(None)
    playbook_include = PlaybookInclude()
    ds = dict(
        import_playbook=None,
        tags=None
    )
    assert playbook_include.load_data(ds, None, loader) is None



# Generated at 2022-06-25 05:40:57.402172
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    # [0] is the test case data
    # [1] is the expected return value
    test_cases = [
        ([], playbook_include_0),
        ([0], playbook_include_0)
    ]
    for test_case in test_cases:
        assert playbook_include_0.load_data(test_case[0][0], test_case[0][1]) == test_case[1]


# Generated at 2022-06-25 05:41:07.120779
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    data = dict()
    data['import_playbook'] = "test/integration/targets/import/play.yml"
    data['vars'] = {'foo': "bar"}

    playbook_include = PlaybookInclude()
    result = playbook_include.load_data(data, '.') #TODO add variable_manager
    assert result.__class__.__name__ == 'Play'
    assert result._playbook_path == "test/integration/targets/import/play.yml"
    assert result._included_path == "test/integration/targets/"
    assert result.vars == {'foo': "bar"}


# Generated at 2022-06-25 05:41:09.445098
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include = PlaybookInclude()
    data = {
        'import_playbook': 'playbook.yml'
    }
    basedir = '/'
    playbook_inc = playbook_include.load_data(data, basedir)
    # Make sure we get a Playbook back
    assert playbook_inc is not None

# Generated at 2022-06-25 05:41:15.020466
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    list_0 = []
    list_1 = []
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(list_0, list_1)


# Generated at 2022-06-25 05:41:20.099814
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    list_0 = []
    var_0 = playbook_include_0.load_data(list_0, list_0)

# testing load_data for an error, TypeError

# Generated at 2022-06-25 05:41:26.841971
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Create a new PlaybookInclude object
    playbook_include_0 = PlaybookInclude()
    # Create a new Playbook object
    playbook_0 = playbook_include_0.load_data(([({'value': 'test_value'}), ({'_import_playbook': 'test_value'})]), ([({'value': 'test_value'}), ({'_import_playbook': 'test_value'})]))


# Generated at 2022-06-25 05:41:30.115740
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
	list_0 = []
	playbook_include_0 = PlaybookInclude()
	var_0 = playbook_include_0.load_data(list_0, list_0)


# Generated at 2022-06-25 05:41:56.194969
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    list_0 = []
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(list_0, list_0)


# Generated at 2022-06-25 05:41:58.629139
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    list_0 = []
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(list_0, list_0)


# Generated at 2022-06-25 05:42:01.260751
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Setup
    list_0 = []
    playbook_include_0 = PlaybookInclude()

    # Invocation
    var_0 = playbook_include_0.load_data(list_0, list_0)

    # Assertions
    assert var_0 is None


# Generated at 2022-06-25 05:42:11.120699
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
  playbook_include = PlaybookInclude()

  # Test with valid arguments
  test_case_0()
  # Test with invalid arguments
  try:
    playbook_include.load_data()
    assert False
  except TypeError:
    pass
  try:
    playbook_include.load_data(None)
    assert False
  except TypeError:
    pass
  try:
    playbook_include.load_data(None, None)
    assert False
  except TypeError:
    pass
  try:
    playbook_include.load_data(None, None, None)
    assert False
  except TypeError:
    pass
  try:
    playbook_include.load_data(None, None, None, None)
    assert False
  except TypeError:
    pass

# Generated at 2022-06-25 05:42:13.588296
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    list_0 = []
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(list_0, list_0)



# Generated at 2022-06-25 05:42:20.314605
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    list_0 = []
    playbook_include_0 = PlaybookInclude()
    # State the expected type of an object returned by load_data
    var_0 = isinstance(playbook_include_0.load_data(list_0, list_0), Playbook)
    assert var_0 == True

# Generated at 2022-06-25 05:42:28.808218
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
  import tempfile, shutil

  temp_dir = tempfile.mkdtemp()
  playbook = '''
  - import_playbook: test.yml
  '''
  with open(os.path.join(temp_dir, 'test.yml'), 'w') as f:
    f.write(playbook)
  pb = PlaybookInclude()
  pb = pb.load([playbook], temp_dir)
  assert os.path.exists(pb.playbook)
  shutil.rmtree(temp_dir)

# Generated at 2022-06-25 05:42:32.778950
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = dict()
    str_0 = str()
    var_0 = playbook_include_0.load_data(dict_0, str_0)


# Generated at 2022-06-25 05:42:35.099385
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    print("USING TEST0")
    test_case_0()

if __name__ == '__main__':
    test_PlaybookInclude_load_data()

# Generated at 2022-06-25 05:42:41.009752
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Create object
    list_0 = []
    dict_0 = {}
    # Call load_data
    assert_raises(AnsibleAssertionError, PlaybookInclude.load_data, list_0, dict_0, list_0, dict_0)


# Generated at 2022-06-25 05:43:20.856090
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    list_0 = []
    dict_0 = dict()
    dict_1 = dict()
    dict_0["collections_paths"] = dict_1
    dict_1["ansible_collections"] = list_0
    dict_2 = dict()
    dict_0["inventory"] = dict_2
    dict_2["hosts"] = list_0
    dict_3 = dict()
    dict_0["module_utils"] = dict_3
    dict_3["_args"] = list_0
    dict_4 = dict()
    dict_0["vault"] = dict_4
    dict_4["password"] = list_0
    dict_5 = dict()
    dict_0["stdout_callback"] = dict_5
    dict_5["default"] = list_0
    dict_6 = dict()


# Generated at 2022-06-25 05:43:22.406492
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()



# Generated at 2022-06-25 05:43:24.194962
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    list_0 = []
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(list_0, list_0)


# Generated at 2022-06-25 05:43:29.120476
# Unit test for method load_data of class PlaybookInclude

# Generated at 2022-06-25 05:43:38.276826
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    list_0 = []
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(list_0, list_0)

# Test to load a playbook

# Generated at 2022-06-25 05:43:43.497784
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    list_0 = [u'playbook.yml', u'foo=bar', u'baz=baz']
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(list_0, list_0)


# Generated at 2022-06-25 05:43:48.279279
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    list_0 = []
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(list_0, list_0)
    pass

if __name__ == '__main__':
    test_PlaybookInclude_load_data()

# Generated at 2022-06-25 05:43:56.922562
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    data_0 = PlaybookInclude.load("test_data/test_playbook_include.yml", None)
    assert data_0.import_playbook == "test_data/test_playbook_include_2.yml"
    assert len(data_0.tasks) == 2 and data_0.tasks[0].action != None and data_0.tasks[1].action != None
    assert len(data_0._entries) == 2 and data_0._entries[0].action != None and data_0._entries[1].action != None
    assert data_0.tasks[0].action == "debug"
    assert data_0.tasks[0].args["msg"] == "Hello world!"
    assert data_0.tasks[1].action == "debug"

# Generated at 2022-06-25 05:44:02.374467
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(list_0_0, list_0_0)

if __name__ == '__main__':
    test_PlaybookInclude_load_data()

# Generated at 2022-06-25 05:44:07.453002
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    ds = dict()
    basedir = list()
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.load_data(ds, basedir)
    assert type(playbook_include_0) == PlaybookInclude
