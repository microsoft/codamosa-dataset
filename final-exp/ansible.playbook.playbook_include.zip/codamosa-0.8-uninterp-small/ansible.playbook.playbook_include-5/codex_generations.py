

# Generated at 2022-06-25 05:34:35.304910
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-25 05:34:45.438390
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()
    data_0 = dict(a=1, b=2)
    assert playbook_include_0.preprocess_data(ds=data_0) == dict(a=1, b=2)

    playbook_include_1 = PlaybookInclude()
    argument_1 = dict(a=1, b=2)
    argument_1['a'] = 1
    argument_1['b'] = 2
    argument_1_copy = argument_1.copy()
    playbook_include_1.preprocess_data(ds=argument_1_copy)
    assert argument_1 == argument_1_copy

    playbook_include_2 = PlaybookInclude()
    data_2 = dict(a=1, b=2)
    data_2['a'] = 1
    data_2

# Generated at 2022-06-25 05:34:47.489315
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pb = PlaybookInclude()
    playbook_include_load_data_0 = pb.load_data()


# Generated at 2022-06-25 05:34:49.011671
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()


# Generated at 2022-06-25 05:35:00.393682
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    print()
    print("###########################################################################")
    print("############### test_PlaybookInclude_load_data ###########################")
    print()
    playbook_include_0 = PlaybookInclude()
    print(playbook_include_0)
    ds = {'import_playbook': 'test2.yaml', 'vars': {'var_2': '2', 'var_1': '1'}, 'tags': ['tag_1', 'tag_3', 'tag_2']}
    print(ds)
    basedir = '.'
    variable_manager = None
    loader = None
    playbook_include_0.load_data(ds, basedir, variable_manager, loader)
    print(playbook_include_0)


# Generated at 2022-06-25 05:35:06.853150
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # A test case for tasks
    file_name = "test/data/playbook_include_data/playbook_include_1.yaml"
    ds = dict()

    # Generate a fake valid playbook for testing
    playbook_include_1 = PlaybookInclude.load(ds=ds, basedir=".", variable_manager=None, loader=None)
    return playbook_include_1

# Generated at 2022-06-25 05:35:13.388990
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_entry_0 = PlaybookInclude()
    d = {}
    ds = {'type': 'import_playbook', 'import_playbook': 'main.yml', 'vars': {}}
    expected = {'import_playbook': 'main.yml', 'vars': {}}
    playbook_include_entry_0.preprocess_data(ds=ds)
    assert d == ds
    assert expected == playbook_include_entry_0.serialize()


# Generated at 2022-06-25 05:35:24.911851
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_1 = PlaybookInclude()
    result_1 = playbook_include_1.preprocess_data({}, [])
    assert result_1 == {}
    result_2 = playbook_include_1.preprocess_data({'a':1}, [])
    assert result_2 == {'a':1}
    result_3 = playbook_include_1.preprocess_data({'a':1,'import_playbook':'b'}, [])
    assert result_3 == {'import_playbook':'b', 'a':1}
    result_4 = playbook_include_1.preprocess_data({'import_playbook':'b','a':1}, [])
    assert result_4 == {'import_playbook':'b', 'a':1}
    result_5 = playbook_include_1.pre

# Generated at 2022-06-25 05:35:36.268765
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    try:
        playbook_include_0 = PlaybookInclude()
        playbook_include_0.preprocess_data([])
        assert False
    except AnsibleAssertionError:
        assert True

    try:
        playbook_include_0 = PlaybookInclude()
        playbook_include_0.preprocess_data('123')
        assert False
    except AnsibleAssertionError:
        assert True

    try:
        playbook_include_0 = PlaybookInclude()
        playbook_include_0.preprocess_data('123')
        assert False
    except AnsibleAssertionError:
        assert True

    try:
        playbook_include_0 = PlaybookInclude()
        playbook_include_0.preprocess_data('123')
        assert False
    except AnsibleAssertionError:
        assert True



# Generated at 2022-06-25 05:35:37.433520
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-25 05:35:45.459152
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-25 05:35:47.653185
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.preprocess_data(dict_0)



# Generated at 2022-06-25 05:35:50.759547
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    print('Running unit test for PlaybookInclude.preprocess_data')
    test_case_0()


# Generated at 2022-06-25 05:35:57.708751
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include = PlaybookInclude()
    basedir = os.path.join(os.path.dirname(__file__), 'ansible.cfg')
    ansible_config = os.path.join(os.path.dirname(__file__), 'ansible.cfg')
    playbook_include.load_data(ds={}, basedir=basedir, ansible_config=ansible_config)


# Generated at 2022-06-25 05:36:00.730597
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {}
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude.load(dict_0)

test_case_0()

# Generated at 2022-06-25 05:36:03.842523
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.load()


# Generated at 2022-06-25 05:36:11.190275
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    with pytest.raises(Exception):
        dict_0 = {}
        playbook_include_0 = PlaybookInclude()
        var_0 = playbook_include_0.load_data(ds=dict_0)


# Generated at 2022-06-25 05:36:13.481377
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(dict_0)


# Generated at 2022-06-25 05:36:19.970940
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    dict_0 = {}
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.load_data(ds=dict_0, basedir='/home/vagrant/ansible/lib/ansible/modules', variable_manager=None, loader=None)
    playbook_include_0.load_data(ds=dict_0, basedir='/home/vagrant/ansible/lib/ansible/modules', variable_manager=None, loader=None)


# Generated at 2022-06-25 05:36:25.642492
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    # case 1
    file_name_str_0 = 'playbook.yaml'
    playbook_include_1 = PlaybookInclude()
    playbook_0 = Playbook()
    entries_mapping_0 = playbook_0._entries
    playbook_include_1.tags.append(entries_mapping_0)
    playbook_include_1.vars.append(entries_mapping_0)
    playbook_return = playbook_include_1.load_data(0, '.', None, None)
    assert playbook_return is None
    # Verify we got a Playbook
    assert isinstance(playbook_return, Playbook)
    # Verify we got an array

# Generated at 2022-06-25 05:36:38.985500
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {}
    basedir = '.'
    variable_manager = None
    loader = None

    # Instantiate a PlaybookInclude object to test the load_data method
    playbook_include_0 = PlaybookInclude()

    # Check the return type of the load_data method
    assert isinstance(playbook_include_0.load_data(dict_0, basedir, variable_manager, loader), Playbook)


# Generated at 2022-06-25 05:36:44.350993
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    parser = PlaybookInclude()
    Display().deprecated = Mock(wraps=lambda *args, **kwargs: parser.Display().deprecated(*args, **kwargs))
    playbook_include_0 = PlaybookInclude()
    ds = dict()
    basedir = ansible.constants.DEFAULT_MODULE_PATH
    variable_manager = dict()
    loader = dict()
    ret = playbook_include_0.load_data(ds, basedir, variable_manager, loader)
    assert isinstance(ret, ansible.playbook.play.Play) is True


# Generated at 2022-06-25 05:36:52.934750
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    list_0 = []
    dict_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(list_0, dict_0)
    dict_1 = {}
    dict_2 = {}
    playbook_include_1 = PlaybookInclude()
    var_1 = playbook_include_1.load_data(list_0, dict_2)
    dict_3 = {}
    playbook_include_2 = PlaybookInclude()
    var_2 = playbook_include_2.load_data(list_0, dict_3)
    dict_4 = {}
    playbook_include_3 = PlaybookInclude()
    var_3 = playbook_include_3.load_data(list_0, dict_4)
    dict_5 = {}
    playbook

# Generated at 2022-06-25 05:37:04.499280
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Inject dependency of the the PlaybookInclude class, os.path is included for a different dependency
    # monkey patching os.path is probably not the best choice here, but it does fix the problem
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import string_types
    os.path.isabs = lambda x: isinstance(x, string_types)

    import_playbook_0 = "test/test.yml"
    basedir_0 = "temp"
    playbook_include_0 = PlaybookInclude()
    data_0 = AnsibleMapping({"import_playbook": "test/test.yml"
    })
    print(data_0)
    var_0 = playbook_include_0.load_data(data_0, basedir_0)


# Generated at 2022-06-25 05:37:08.451731
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {
        'key_0': 'value_0',
    }
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.preprocess_data(dict_0)
    # TODO: Need tests for this method


# Generated at 2022-06-25 05:37:12.731596
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    try:
        playbook_include_0.load_data(
            ds = {},
            basedir = "s/s/s/s"
        )
    except Exception as exc:
        display.error("Failed to run load_data on PlaybookInclude: %s" % to_text(exc))


# Generated at 2022-06-25 05:37:19.299909
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {}
    basedir_0 = '''{'true': ['ansible.vars.hostvars.HostVarsVars', 'ansible.vars.hostvars.HostVarsVars.true'], 'false': ['ansible.vars.hostvars.HostVarsVars', 'ansible.vars.hostvars.HostVarsVars.false'], 'skip_ansible_lint': ['ansible.vars.hostvars.HostVarsVars', 'ansible.vars.hostvars.HostVarsVars.skip_ansible_lint']}'''

# Generated at 2022-06-25 05:37:28.959231
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # From /usr/lib/python3.7/site-packages/ansible/playbook/__init__.py:1315
    # Test case 1
    dict_0 = {}
    str_0 = "test"
    str_1 = "test"
    str_2 = "test"
    str_3 = "test"
    str_4 = "test"
    list_0 = [str_1, str_2, str_3, str_4]
    ansible_mapping_0 = AnsibleMapping({str_0 : list_0})
    ansible_mapping_0.ansible_pos = 8
    # str_5 = "test"
    # str_6 = "test"
    # str_7 = "test"
    # str_8 = "test"
    # str_9 = "

# Generated at 2022-06-25 05:37:32.263865
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include = PlaybookInclude()
    playbook_include.load_data(ds='ds_1', variable_manager='variable_manager_1', loader='loader_1')


# Generated at 2022-06-25 05:37:36.244570
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude()
    assert playbook_include_0.load_data('data_0') == playbook_include_1.load_data('data_1')



# Generated at 2022-06-25 05:37:44.964481
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import unittest

    # Loader needs to be mocked to test
    from ansible.parsing.dataloader import DataLoader

    # Tests for method load_data of class PlaybookInclude
    class TestPlaybookIncludeLoadData(object):
        def test_load_data(self):
            # Set up mock objects
            dict_0 = {}
            dict_1 = {}
            dict_2 = {}
            dict_3 = {}
            dict_4 = {}
            dict_5 = {}

            # The following test case checks whether the method raises expected exceptions
            try:
                # Now do the actual call using mocked data
                dict_0 = PlaybookInclude.load_data(dict_0, dict_1, dict_2, dict_3)
            except KeyError as exception_0:
                pass

# Generated at 2022-06-25 05:37:45.395535
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-25 05:37:52.063700
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {}
    playbook_include_0 = PlaybookInclude()
    playbook_0 = playbook_include_0.load_data(ds=dict_0, basedir='/etc', variable_manager='/etc/ansible/hosts', loader='/etc')


if __name__ == "__main__":
    test_case_0()
    test_PlaybookInclude_load_data()

# Generated at 2022-06-25 05:37:56.995800
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    # The argument is the absolute path of a file
    file_name = "/usr/local/file1.yml"
    variable_manager = {}
    loader = {}
    actual_return = playbook_include_1.load_data(file_name, variable_manager, loader)
    expected_return = None
    assert actual_return == expected_return


# Generated at 2022-06-25 05:38:01.329311
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {}
    playbook_include_0 = PlaybookInclude()
    basedir = 'examples/'
    var_0 = playbook_include_0.load_data(dict_0, basedir)



# Generated at 2022-06-25 05:38:08.849671
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # test_case_0
    dict_0 = {}
    basedir_0 = "/etc/ansible/roles/bsstahl.gitconfig/files/gitconfig"
    variable_manager_0 = None
    loader_0 = None
    playbook_include_0 = PlaybookInclude()
    var_1 = playbook_include_0.load_data(dict_0, basedir_0, variable_manager_0, loader_0)
    assert var_1 == None, 'unit test failed'


# Generated at 2022-06-25 05:38:18.582808
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    if not isinstance(playbook_include_1, Base):
        raise AssertionError()

    if not isinstance(playbook_include_1, Conditional):
        raise AssertionError()

    if not isinstance(playbook_include_1, Taggable):
        raise AssertionError()

    _vars_0 = {}

    import_playbook_0 = 'a/path/to/a/file.yml'

    _vars_0['import_playbook'] = import_playbook_0

    playbook_include_1.preprocess_data(_vars_0)

    if not isinstance(playbook_include_1, Base):
        raise AssertionError()


# Generated at 2022-06-25 05:38:21.388474
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {}
    basedir_0 = 'basedir'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(dict_0, basedir_0)

# Generated at 2022-06-25 05:38:25.919784
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include = PlaybookInclude()
    assert playbook_include.load_data(ds={}, basedir='/etc/ansible/hosts', variable_manager={}, loader={}) == None


# Generated at 2022-06-25 05:38:28.468224
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    playbook_include_1.load_data()



# Generated at 2022-06-25 05:38:33.859925
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Currently this method is not tested
    pass


# Generated at 2022-06-25 05:38:42.869918
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # create an instance of the PlaybookInclude class with the
    # required arguments
    playbook_include_0 = PlaybookInclude()

    # create a mock object
    ds_0 = AnsibleMapping()

    # create a mock object
    loader_0 = MagicMock()

    # create a mock object
    basedir_0 = {"key": "value"}

    # create a mock object
    new_obj_0 = MagicMock()
    new_obj_0.vars = {"key": "value"}

    # create a mock object
    temp_vars_0 = {"key": "value"}
    param_tags_0 = "param_tags_0"

    # create a mock object
    vars_0 = {"key": "value"}

    # create a mock object

# Generated at 2022-06-25 05:38:45.270861
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pbi = PlaybookInclude()
    pbi.load_data({'import_playbook': 'playbook.yaml'}, '.')

# Generated at 2022-06-25 05:38:48.996739
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.preprocess_data(dict_0)


# Generated at 2022-06-25 05:38:57.230391
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # The following call to load_data of an object of PlaybookInclude Class raises AnsibleParserError due to invalid input.
    # The 'playbook' and 'variable_manager' arguments are not provided to load_data function.
    playbook_include = PlaybookInclude()
    try:
        playbook_include.load_data(ds={}, basedir='', variable_manager=None, loader='AnsibleCollectionConfig')
    except AnsibleParserError:
        pass
    else:
        raise Exception('AnsibleParserError not raised for invalid input given to load_data function')


test_case_0()
test_PlaybookInclude_load_data()

# Generated at 2022-06-25 05:39:02.223850
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    print("Testing load_data of class PlaybookInclude")
    data = None
    basedir = None
    variable_manager = None
    loader = None
    test_playbook_include = PlaybookInclude()
    test_playbook_include.load_data(data, basedir, variable_manager, loader)


# Generated at 2022-06-25 05:39:08.554473
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    display.vvvvv(u'')
    pb_include = PlaybookInclude() 
    basedir = u'test/fixtures/'
    dict_0 = {}
    x = pb_include.load_data(dict_0, basedir)
    y = pb_include.load_data(dict_0, basedir)


# Generated at 2022-06-25 05:39:15.433292
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    ds = {'import_playbook': 'test_value'}
    pb = PlaybookInclude.load(ds, '')
    assert pb == None
    assert False


if __name__ == "__main__":
    import __main__
    print(('Unit test of: ' + __main__.__file__))
    test_case_0()
    test_PlaybookInclude_load_data()
    print('End Unit Test')

# Generated at 2022-06-25 05:39:23.537522
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {
        'import_playbook': 'file_name',
        'vars': {
            'key_1': 'value_1',
            'key_2': 'value_2'
        }
    }
    basedir = 'string'
    variable_manager = object
    loader = object
    # pb = object

    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(dict_0, basedir, variable_manager, loader)
    # var_0 is a Playbook() object


# Generated at 2022-06-25 05:39:27.400640
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    param0 = None
    param1 = None
    param2 = None
    param3 = None
    param4 = None
    playbook_0 = playbook_include_0.load_data(param0, param1, param2, param3, param4)



# Generated at 2022-06-25 05:39:36.731203
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {}
    basedir_0 = './'
    variable_manager_0 = None
    loader_0 = None
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(dict_0, basedir_0, variable_manager_0, loader_0)


# Generated at 2022-06-25 05:39:40.028334
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {}
    playbook_include_0.load_data(dict_0, 'basedir')


# Generated at 2022-06-25 05:39:49.673929
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    ds = {}
    basedir = './test/testdata/a_folder'
    variable_manager = {}
    loader = {}
    try:
        playbook_include_1.load_data(ds, basedir, variable_manager, loader)
    except:
        assert False, "Creation of PlaybookInclude() object failed"
    assert playbook_include_1.__dict__ == {'_attributes': {}, '_import_playbook': None, '_parent': None, '_ds': {}, '_included_path': None}, "Unexpected attribute(s) for PlaybookInclude() object"
    assert playbook_include_1._ds == {}, "Unexpected value for playbook_include_1._ds"
    assert playbook_include_1._included_path

# Generated at 2022-06-25 05:39:56.676568
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    # Test setting a value, and one attribute is set.
    playbook_include_0.__dict__ = {'_import_playbook':'test/test/test', '_vars':{}}
    assert playbook_include_0.__dict__ == {'_import_playbook':'test/test/test', '_vars':{}}
    playbook_include_0.load_data('test/test/test', 'test/test/test')


# Generated at 2022-06-25 05:39:57.545527
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-25 05:40:04.331475
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook, Play
    # PlaybookInclude.load_data() can be called with args, kwargs as well
    # but we are providing empty args, kwargs to keep the test simple here.
    ansible_config = AnsibleCollectionConfig()
    # The following call will throw an assertion error, if load_data() expects args and kwargs.
    playbook = PlaybookInclude.load(None, None)
    assert playbook is not None

    playbook = PlaybookInclude.load(None, None, ansible_config)
    assert playbook is not None

    playbook_include_0 = PlaybookInclude()
    playbook = playbook_include_0.load_data(None, None, None, None)
    assert playbook is not None

# Generated at 2022-06-25 05:40:07.450828
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Iterate over possible inputs and expected outputs and call load_data
    # with them to make sure it's working as expected.

    # TODO(jayme-github) expand this test suite.
    return



# Generated at 2022-06-25 05:40:14.267670
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    ds_0 = None
    basedir_0 = None
    variable_manager_0 = None
    loader_0 = None
    try:
        var_0 = playbook_include_0.load_data(ds_0, basedir_0, variable_manager_0, loader_0)
    except Exception as exp:
        var_0 = exp


# Generated at 2022-06-25 05:40:18.453647
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(dict_0, None)


# Generated at 2022-06-25 05:40:23.400740
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Check that calling load_data with args (ds, basedir, variable_manager=None, loader=None) returns None
    # Calling function with args
    # ds=dict_0, basedir=var_1, variable_manager=None, loader=None

    dict_0 = {}
    str_0 = 'var_1'
    playbook_include_0 = PlaybookInclude()
    result = playbook_include_0.load_data(dict_0, str_0)
    assert result is None


# Generated at 2022-06-25 05:40:39.418732
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    #Testing with invalid datastructure ds.
    #Expected : Raises AnsibleAssertionError

    dict_0 = dict()
    dict_0['key_0'] = "value_0"
    dict_0['key_1'] = "value_1"
    dict_0['key_2'] = "value_2"
    dict_0['key_3'] = "value_3"
    dict_0['key_4'] = "value_4"
    dict_0['key_5'] = "value_5"
    dict_0['key_6'] = "value_6"
    dict_0['key_7'] = "value_7"
    dict_0['key_8'] = "value_8"
    dict_0['key_9'] = "value_9"

# Generated at 2022-06-25 05:40:44.586573
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {}
    playbook_include_0 = PlaybookInclude()
    basedir_0 = "/home/vagrant/ansible/lib/ansible/playbook"
    variable_manager_0 = ""
    loader_0 = ""
    var_0 = playbook_include_0.load_data(dict_0, basedir_0, variable_manager_0, loader_0)

# Generated at 2022-06-25 05:40:51.256106
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_1 = {}
    playbook_include_1 = PlaybookInclude()
    var_1 = playbook_include_1.load_data(ds=dict_1, basedir="test_basedir", variable_manager="test_variable_manager", loader="test_loader")


# Generated at 2022-06-25 05:40:53.123753
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-25 05:40:57.713809
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {}
    playbook_include_0 = PlaybookInclude()
    try:
        var_0 = playbook_include_0.load_data(dict_0, '', '', '')
    except Exception as e:
        print('Exception message:%s' % e)
        assert False, 'Failed to create PlaybookInclude object'
        return

    assert True, 'Successfully created PlaybookInclude object'


# Generated at 2022-06-25 05:41:01.684051
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {}
    basedir_0 = ''
    variable_manager_0 = ''
    loader_0 = ''
    playbook_0 = playbook_include_0.load_data(dict_0, basedir_0, variable_manager_0, loader_0)


# Generated at 2022-06-25 05:41:07.464999
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    dict_0 = dict(import_playbook='/var/foo/bar.yml', tags='baz')
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = playbook_include_0.load_data(ds=dict_0, basedir='/var/foo/bar.yml', variable_manager=None, loader=None)
    assert playbook_include_1.vars == dict()
    assert playbook_include_1.import_playbook == '/var/foo/bar.yml'
    assert playbook_include_1.tags == ['baz']

# Generated at 2022-06-25 05:41:11.393494
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {}
    playbook_include_0 = PlaybookInclude()
    basedir_0 = "&<1-kdRB8^3q=#:7V+b!#u!zVfYr{^[gxTf>G.hZkH|&0:`Xt`)2s?dJtYs[KP>|R"
    variable_manager_0 = VariableManager()
    loader_0 = DataLoader()
    new_obj = playbook_include_0.load_data(dict_0, basedir_0, variable_manager_0, loader_0)


# Generated at 2022-06-25 05:41:13.986346
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-25 05:41:19.230239
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(dict_0)


# Generated at 2022-06-25 05:41:30.546139
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    basedir_0 = 'blocker'
    var_0 = {}
    ds_0 = {}
    var_1 = {}
    playbook_include_0 = PlaybookInclude()
    var_2 = playbook_include_0.load_data(ds_0, basedir_0, var_0)
# End of test for method load_data of class PlaybookInclude


# Generated at 2022-06-25 05:41:38.810993
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    # basedir should be str
    with pytest.raises(AnsibleParserError) as excinfo:
        playbook_include_0.load_data(None, None, None, None)
    assert 'basedir should be str' in str(excinfo.value)
    # basedir should be str
    with pytest.raises(AnsibleParserError) as excinfo:
        playbook_include_0.load_data(None, None, None, None)
    assert 'basedir should be str' in str(excinfo.value)
    # basedir should be str
    with pytest.raises(AnsibleParserError) as excinfo:
        playbook_include_0.load_data(None, None, None, None)
    assert 'basedir should be str'

# Generated at 2022-06-25 05:41:42.688341
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {}
    basedir = ''
    variable_manager = None
    loader = None
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = playbook_include_0.load_data(data=dict_0, basedir=basedir, variable_manager=variable_manager, loader=loader)
    assert playbook_include_1 is not None


# Generated at 2022-06-25 05:41:49.113691
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook = PlaybookInclude.load(
        "{'import_playbook': 'hello.yml', 'vars': {'tasks': 'tasks'}}"
    )
    assert playbook.import_playbook == "hello.yml"
    assert playbook.vars == {'tasks': 'tasks'}


# Generated at 2022-06-25 05:41:49.903150
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass



# Generated at 2022-06-25 05:41:58.739292
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # AnsibleVariableManager has a clever constructor that doesn't need args
    variable_manager = AnsibleVariableManager()

    # AnsibleLoader has a clever constructor that doesn't need args
    loader = AnsibleLoader()

    # AnsibleCollectionConfig has a clever constructor that doesn't need args
    collection_config = AnsibleCollectionConfig()

    # PlaybookInclude.load_data has a clever constructor that doesn't need args
    playbook_include = PlaybookInclude.load_data()

    # Check to see if the object is a dictionary
    if isinstance(playbook_include, dict):
        display.display('Pass - It is a dictionary')
    else:
        display.display('Fail - It is not a dictionary')


# Generated at 2022-06-25 05:42:00.401218
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Test when basedir is given as input argument
    var_0 = load_data('/etc/ansible/playbooks/ansible-playbook.yml')


# Generated at 2022-06-25 05:42:04.350648
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {'import_playbook': "playbooks/test.yml"}
    playbook_include_0 = PlaybookInclude()
    dict_1 = playbook_include_0.preprocess_data(dict_0)
    var_0 = playbook_include_0.load_data(ds=dict_1, basedir="playbooks/test.yml")
    var_1 = playbook_include_0.load_file(file_name="playbooks/test.yml", basedir="playbooks/test.yml")

# Generated at 2022-06-25 05:42:05.564221
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()

    # test with no arguments
    playbook_include_0.load_data()


# Generated at 2022-06-25 05:42:07.327382
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {}
    playbook_include_0 = PlaybookInclude()
    playbook_0 = playbook_include_0.load_data(ds=dict_0, basedir=dict_0, variable_manager=dict_0, loader=dict_0)


# Generated at 2022-06-25 05:42:21.297262
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_2 = {}
    playbook_include_1 = PlaybookInclude()
    var_3 = playbook_include_1.load_data(var_2, var_2, var_2, var_2)
    var_4 = {}
    var_4[0] = 'import_playbook'
    var_4[1] = '/home/ansible/playbook.yml'
    var_4[3] = 'tags=import'
    var_4[4] = 'vars={import_var_1=import_value_1}'
    var_4[5] = 'this is a comment'
    playbook_include_2 = PlaybookInclude()
    var_3 = playbook_include_2.load_data(var_4, var_2, var_2, var_2)

# Unit test

# Generated at 2022-06-25 05:42:31.397347
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # Tests preprocess_data exceptions
    playbook_include_0 = PlaybookInclude()
    var_2 = "abc"
    try:
        var_1 = playbook_include_0.preprocess_data(var_2)
    except AnsibleAssertionError as e:
        var_1 = e
    assert isinstance(var_1, AnsibleAssertionError)

    # Tests preprocess_data exceptions
    playbook_include_1 = PlaybookInclude()
    var_5 = {}
    var_6 = "import_playbook"
    var_7 = None
    var_5[var_6] = var_7
    try:
        var_4 = playbook_include_1.preprocess_data(var_5)
    except AnsibleParserError as e:
        var_4 = e

# Generated at 2022-06-25 05:42:34.335161
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_1 = {}
    playbook_include_0 = PlaybookInclude()
    var_2 = playbook_include_0.load_data(var_1, var_1, var_1, var_1)


# Generated at 2022-06-25 05:42:42.308759
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_1 = {'forks': '5', 'log_path': '/home/vagrant/ansible/logs'}
    var_2 = {'import_playbook': 'test.yml'}
    var_3 = {'tags': 'junk,test'}
    playbook_include_1 = PlaybookInclude()
    playbook_include_1.load_data(var_1, var_2, var_3, var_2)


# Generated at 2022-06-25 05:42:45.789404
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_2 = {}
    var_2 = {}
    var_2 = {}
    var_2 = {}
    playbook_include_1 = PlaybookInclude()
    playbook_include_1.load_data(var_2, var_2, var_2, var_2)


# Generated at 2022-06-25 05:42:47.959581
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0, var_0)


# Generated at 2022-06-25 05:42:50.079750
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    assert PlaybookInclude().load_data(None, None, None, None) is not None


# Generated at 2022-06-25 05:42:54.060604
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0, var_0)


# Generated at 2022-06-25 05:42:56.742372
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_3 = {}
    playbook_include_1 = PlaybookInclude()
    var_4 = playbook_include_1.load_data(var_3, var_3, var_3, var_3)


# Generated at 2022-06-25 05:43:01.838729
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    print("Testing load_data")
    var_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0, var_0)


# Generated at 2022-06-25 05:43:15.286388
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import_playbook = ['']
    vars = {}
    obj = PlaybookInclude()
    result = obj.load_data(import_playbook, vars)


# Generated at 2022-06-25 05:43:18.010755
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0, var_0)
    del var_1
    del var_0


# Generated at 2022-06-25 05:43:22.840406
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0, var_0)


test_case_0()

# Generated at 2022-06-25 05:43:25.447521
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0, var_0)


# Generated at 2022-06-25 05:43:30.846356
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = {
        'role': 'common',
        'import_playbook': 'common.yaml',
        'name': 'common'
    }
    playbook_include_0 = PlaybookInclude()
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0, var_0)


# Generated at 2022-06-25 05:43:39.159945
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    base_0 = {"import_playbook": "tests/test_playbook_includes/unsupported.yml"}
    base_1 = "tests/test_playbook_includes"
    try:
        playbook_include_0.load_data(base_0, base_1)
        failed = False
    except AssertionError:
        failed = True
    assert failed == False

    base_0 = "tests/test_playbook_includes/test_import_as_vars.yml"
    base_1 = "tests/test_playbook_includes"
    # try:
    #     playbook_include_0.load_data(base_0, base_1)
    #     failed = False
    # except AssertionError:
    #     failed = True


# Generated at 2022-06-25 05:43:47.396369
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = {}
    var_0 = {'import_playbook': 'foo'}
    playbook_include_0 = PlaybookInclude()
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0, var_0)


if __name__ == '__main__':

    print('\n### START START START START START START START START START START START START START')

    test_case_0()

    print('### END END END END END END END END END END END END END')

# Generated at 2022-06-25 05:43:51.128536
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = {}
    var_1 = {}
    var_2 = {}
    var_3 = {}
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.load_data(var_0, var_1, var_2, var_3)



# Generated at 2022-06-25 05:43:51.715373
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    test_case_0()


# Generated at 2022-06-25 05:43:55.168020
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # TODO: Add tests for `PlaybookInclude.load_data`
    pass


# Generated at 2022-06-25 05:44:20.359616
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_obj = PlaybookInclude()
    var_0 = {}
    var_1 = {}
    var_2 = {}
    var_3 = {}
    pass

