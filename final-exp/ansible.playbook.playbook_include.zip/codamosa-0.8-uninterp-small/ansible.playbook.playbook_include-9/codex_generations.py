

# Generated at 2022-06-25 05:34:42.332989
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    try:
        # NOTE(retr0h):  This test is just a stub, this function is not rendered in the
        # template but instead is a custom logic function.
        pass
    except Exception as e:
        print(e)


# Generated at 2022-06-25 05:34:48.785618
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include = PlaybookInclude()
    test_ds = AnsibleMapping()
    test_ds['import_playbook'] = "test_playbook.yml"
    test_ds['tags'] = "test_tag"
    test_ds['vars'] = {"test_key": "test_value"}
    
    preprocessed_result = playbook_include.preprocess_data(test_ds)
    assert playbook_include._import_playbook == "test_playbook.yml"
    assert playbook_include.tags == ["test_tag"]
    assert playbook_include.vars == {"test_key": "test_value"}
    assert preprocessed_result == test_ds

if __name__ == "__main__":
    test_case_0()
    # Unit test for method preprocess_data of class

# Generated at 2022-06-25 05:34:52.848167
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()
    known_ds = dict(a=1, b=2)
    out_ds = playbook_include_0.preprocess_data(known_ds)
    assert out_ds == known_ds, "%r != %r" % (out_ds, known_ds)

# Generated at 2022-06-25 05:34:55.970328
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.load_data(ds='ds_0', basedir='basedir_0', variable_manager='variable_manager_0', loader='loader_0')

# Generated at 2022-06-25 05:35:02.364850
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()
    ds = dict()
    ds['import_playbook'] = 'tasks.yml'
    ds['vars'] = dict()
    ansible_pos = {}
    ds = AnsibleMapping(ds, ansible_pos=ansible_pos)
    playbook_include_0.preprocess_data(ds)


if __name__ == "__main__":
    # load_data_test()
    pass

# Generated at 2022-06-25 05:35:05.979171
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Expecting no exceptions raised after running function
    playbook_include = PlaybookInclude()
    playbook_include.load_data({}, basedir=None, variable_manager=None)


# Generated at 2022-06-25 05:35:07.450342
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
# Not working


# Generated at 2022-06-25 05:35:18.236597
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude()
    data = ''' 
    - include: foo.yml
    - hostgroup: host-group
    '''
    basedir = '/'
    variable_manager= None
    loader = None
    expected = ''' 
    - include: foo.yml
    - hostgroup: host-group
    '''
    actual = playbook_include_0.load_data(data, basedir, variable_manager, loader)
    assert actual == expected, "actual='%s' expected='%s' actual='%s' expected='%s'" % (playbook_include_1, data, playbook_include_0, expected)


# Generated at 2022-06-25 05:35:23.404714
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # TEST 0
    # Check for correct handling of bad data type
    data = {
        'vars': 'bad'
    }

    try:
        playbook_include_0 = PlaybookInclude(data, None)
    except AnsibleParserError as e:
        if 'must be specified as' in str(e):
            pass
        else:
            raise
    else:
        raise


# Generated at 2022-06-25 05:35:28.045376
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    assert playbook_include_1.load_data(ds={}, basedir='/etc/ansible/roles', variable_manager={}, loader={}) == None


# Generated at 2022-06-25 05:35:41.175280
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    mock_ds = {}
    playbook_include_0 = PlaybookInclude()
    try:
        playbook_include_0.load_data(ds = mock_ds,
                                     basedir = "ansible/test/units/module_utils",
                                     variable_manager = None,
                                     loader = None
                                     )
    except AnsibleAssertionError:
        pass
    except Exception:
        raise



# Generated at 2022-06-25 05:35:47.369846
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''
    - test case 0
    - test case 1
    '''
    try:
        # test case 0
        test_case_0()
    except Exception as e:
        print (e)


# Generated at 2022-06-25 05:35:57.056372
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    playbook_include_1 = PlaybookInclude()
    ds_1 = {}
    assert playbook_include_1.preprocess_data(ds=ds_1) == {}, \
        "preprocess_data() fails, expected: {}, actual: {}".format({}, playbook_include_1.preprocess_data(ds=ds_1))

    playbook_include_2 = PlaybookInclude()
    ds_2 = { 'tags': 'a_tag'}
    assert playbook_include_2.preprocess_data(ds=ds_2) == {}, \
        "preprocess_data() fails, expected: {}, actual: {}".format({}, playbook_include_2.preprocess_data(ds=ds_2))

    playbook_include_3 = PlaybookInclude()

# Generated at 2022-06-25 05:36:05.995492
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Load a de-serialized object
    playbook_include_1 = PlaybookInclude()
    playbook_include_1.load_data(ds={'import_playbook': 'sub.yml'}, basedir='/home/user/ansible/')
    assert playbook_include_1 != None
    # Load a serialized object
    playbook_include_2 = PlaybookInclude()
    playbook_include_2.load_data(ds='''
      import_playbook:
        sub.yml
    ''', basedir='/home/user/ansible/')
    assert playbook_include_2 != None


# Generated at 2022-06-25 05:36:11.353565
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.load_data(ds='ds', basedir='basedir', variable_manager='variable_manager', loader='loader')


# Generated at 2022-06-25 05:36:12.677072
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include.load_data()


# Test load from data

# Generated at 2022-06-25 05:36:21.756145
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_0._load_data = load_data = load_data = load_data = load_data = load_data = load_data = load_data = load_data = load_data = load_data = load_data = load_data = load_data = load_data = load_data = load_data = load_data = load_data = load_data = load_data = load_data = load_data = load_data = load_data = load_data = load_data = load_data = load_data = load_data = load_data = load_data = load_data = load_data = load_data = load_data = load_data = load_data = load_data = load_data = load_data = load_data = load_data = load_data = load_data

# Generated at 2022-06-25 05:36:28.920902
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    playbook_include_load_data = PlaybookInclude()
    playbook = Playbook.load('test.yml','basedir','variable_manager','loader')
    assert playbook_include_load_data.load_data(playbook,'basedir','variable_manager','loader')==playbook


# Generated at 2022-06-25 05:36:33.373952
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    data = playbook_include_1.load_data({'import_playbook': 'import_playbook'}, 'basedir')
    assert data is not None

# Generated at 2022-06-25 05:36:42.957069
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # These tests simply exercise the code and paths, no attempt is made
    # at testing the correctness of playbook parsing

    playbook_include = PlaybookInclude(loader=None, variable_manager=None)

    ds = dict(import_playbook='../foo.yml')
    try:
        res = playbook_include.load_data(data=ds, variable_manager=None, loader=None)
        assert False, "Failed to raise AnsibleParserError"
    except AnsibleParserError:
        pass

    ds = dict(import_playbook='../foo.yml', tags="foo")
    try:
        res = playbook_include.load_data(data=ds, variable_manager=None, loader=None)
        assert False, "Failed to raise AnsibleParserError"
    except AnsibleParserError:
        pass

# Generated at 2022-06-25 05:36:51.118722
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()


# Generated at 2022-06-25 05:36:53.872469
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.loader = None
    playbook_include_0.vars = dict()
    playbook_include_0.tags = list()
    playbook_include_0.conditional = None

    yield (playbook_include_0)

# Generated at 2022-06-25 05:36:56.751658
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    """
    Test for load_data of PlaybookInclude
    """
    data = dict(import_playbook="Data.yaml")
    basedir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    playbook_include_obj = PlaybookInclude()
    playbook_include_obj.load_data(data, basedir)

# Generated at 2022-06-25 05:37:03.059491
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    play_1 = PlaybookInclude.load(data='include.yml', basedir='./test/unit/fixtures/playbook_include/test_PlaybookInclude_load_data', variable_manager=None, loader=None)
    assert False


# Generated at 2022-06-25 05:37:07.827335
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    load_data_args = {'ds': {'name': 'foo', 'import_playbook': 'example.yml'}, 'basedir': '.',
                      'variable_manager': None, 'loader': None}
    playbook_include_1 = PlaybookInclude()
    playbook_include_1.load_data(**load_data_args)
    assert playbook_include_1.import_playbook == 'example.yml'



# Generated at 2022-06-25 05:37:15.974300
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    yaml = """
- import_playbook:
    include_test
- import_playbook:
    include_test
  vars:
    testvar: testvalue
- import_playbook:
    include_test
  vars:
    testvar1: testvalue1
    testvar2: testvalue2
- import_playbook:
    include_test
    param1: test
    param2: another=test
- import_playbook: include_test
- import_playbook: include_test
  tags: tag1, tag2
- import_playbook: include_test
  vars:
    tags: tag3, tag4
- import_playbook: include_test
  vars:
    tags: tag5, tag6
  tags: tag7, tag8
    """

    test_playbook_include

# Generated at 2022-06-25 05:37:16.845189
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    pass



# Generated at 2022-06-25 05:37:27.428872
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_1 = PlaybookInclude()
    playbook_include_1.preprocess_data(ds={'import_playbook': 'foobar.yml'})
    playbook_include_1.preprocess_data(ds={'import_playbook': 'foobar.yml', 'vars': {'foo': 'bar'}})
    playbook_include_1.preprocess_data(ds={'import_playbook': 'foobar.yml', 'vars': {'foo': 'bar'}, 'tags': 'baz'})
    playbook_include_1.preprocess_data(ds={'import_playbook': 'foobar.yml', 'vars': {'foo': 'bar'}, 'tags': 'baz', 'other': 'stuff'})

# Generated at 2022-06-25 05:37:30.532649
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    data = dict()
    basedir = None
    variable_manager = None
    loader = None
    temp = playbook_include_1.load_data(ds=data, basedir=basedir, variable_manager=variable_manager, loader=loader)



# Generated at 2022-06-25 05:37:38.572319
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude()
    playbook_include_2 = PlaybookInclude()
    playbook_include_3 = PlaybookInclude()
    playbook_include_4 = PlaybookInclude()
    playbook_include_5 = PlaybookInclude()
    playbook_include_6 = PlaybookInclude()
    playbook_include_7 = PlaybookInclude()
    playbook_include_8 = PlaybookInclude()
    playbook_include_9 = PlaybookInclude()
    playbook_include_10 = PlaybookInclude()



# Generated at 2022-06-25 05:37:58.615871
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    playbook_include_0 = PlaybookInclude()
    var_0 = "./test/test-data/tasks/conditional.yml"
    var_1 = {}
    var_2 = ""
    var_3 = playbook_include_0.load_data(var_0, var_1, var_2)
    var_1 = open_file("./test/test-data/tasks/conditional.yml", True)
    var_2 = get_chained_dict(var_1)
    assert var_3 == var_2
    assert (var_3["vars"] == {})
    assert (var_3["when"] == [])



# Generated at 2022-06-25 05:38:03.899028
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = {}
    var_1 = playbook_include_0.preprocess_data(var_0)
    assert var_1 == var_0


# Generated at 2022-06-25 05:38:09.923302
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    basedir_0 = './test/testdata/'
    ds_0 = {}
    variable_manager_0 = {}
    loader_0 = {}
    playbook_include_0.load_data(ds_0, basedir_0, variable_manager_0, loader_0)


# Generated at 2022-06-25 05:38:13.856980
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = {}
    playbook_include_0.load_data(var_0, var_0, var_0)

## Unit Test for preprocess_data of class PlaybookInclude

# Generated at 2022-06-25 05:38:23.520796
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
   # Load data for a simple playbook include
   var_0 = {'include': 'foo.yaml'}
   var_1 = {'import_playbook': 'foo.yaml'}
   var_2 = {}
   var_3 = {}
   var_4 = {}
   var_5 = PlaybookInclude()
   var_6 = var_5.load_data(var_0, var_1, var_2, var_3)
   var_7 = var_6.hosts
   var_7 = var_6.roles
   var_7 = var_6.tasks
   var_7 = var_6.vars
   var_7 = var_6.post_tasks
   var_7 = var_6.pre_tasks

   # Load data for a complex playbook include
   var_8

# Generated at 2022-06-25 05:38:30.936356
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = {}
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0)
    if not isinstance(var_1, Playbook):
        raise AssertionError("Expected play-0 to be an instance of <class 'ansible.playbook.base.Playbook'>, got <class 'ansible.playbook.base.Playbook'> instead.")

# Generated at 2022-06-25 05:38:31.876171
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-25 05:38:37.223798
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_1 = {}
    var_2 = None
    var_3 = playbook_include_0.load_data(var_1, var_1, var_2)
    var_1 = {}
    var_2 = None
    var_3 = playbook_include_0.load_data(var_1, var_1, var_2)


# Generated at 2022-06-25 05:38:40.050610
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    var_2 = {}
    var_3 = {}
    var_4 = {}
    var_5 = playbook_include_1.load_data(var_2, var_3, var_4)

# Generated at 2022-06-25 05:38:42.305324
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_2 = PlaybookInclude()
    var_3 = {}
    var_4 = var_2.load_data(var_3, var_3, var_3)


# Generated at 2022-06-25 05:39:04.800296
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # If a value is of type AnsibleMapping and the value of key named 'import_playbook' is of type string,
    # the value of 'import_playbook' should be put into the new_ds.
    ds = AnsibleMapping()
    ds['import_playbook'] = ''

    pbi = PlaybookInclude()
    new_ds = pbi.preprocess_data(ds)
    assert 'import_playbook' in new_ds
    assert str(type(new_ds['import_playbook'])) == "<class 'ansible.parsing.yaml.objects.AnsibleUnicode'>"

    # If a value is of type AnsibleMapping and the value of key named 'vars' is of type dict,
    # the value of 'vars' should be put into the new_ds.

# Generated at 2022-06-25 05:39:06.542184
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Basic parameter test
    playbook_include_0 = PlaybookInclude()
    var_0 = {}
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0)




# Generated at 2022-06-25 05:39:09.533861
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = {}
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0)



# Generated at 2022-06-25 05:39:13.628941
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = {}
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0)

# Generated at 2022-06-25 05:39:24.073004
# Unit test for method load_data of class PlaybookInclude

# Generated at 2022-06-25 05:39:29.697392
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = {}
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0)
    # in real life, we'd want to detect the error and raise a more helpful
    # error than this, but we check here to make sure it raises an exception
    # on invalid data
    playbook_include_0.preprocess_data(var_1)

# test load of a playbook with an include statement

# Generated at 2022-06-25 05:39:34.125594
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    test_case_0()

# Generated at 2022-06-25 05:39:38.348006
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    var_2 = {}
    var_3 = playbook_include_1.load_data(var_2, var_2, var_2)


# Generated at 2022-06-25 05:39:44.823848
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = {'import_tasks': 'tasks.yml'}
    var_1 = playbook_include_0.preprocess_data(var_0)
    assert var_1 == {'import_playbook': 'tasks.yml'}


# Generated at 2022-06-25 05:39:49.109243
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    var_2 = {}
    var_3 = {}
    var_1 = playbook_include_1.load_data(var_2, var_2, var_2)
    var_1 = playbook_include_1.load_data(var_3, var_3)
    # removing duplicates
    # removing duplicates


# Generated at 2022-06-25 05:40:07.926649
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    try:
        test_case_0()
    except AnsibleParserError:
        pass


# Generated at 2022-06-25 05:40:11.366058
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = {}
    var_1 = PlaybookInclude()
    var_2 = {}
    var_3 = {}
    var_4 = {}
    var_5 = var_1.load_data(var_2, var_3, var_4)
    test_case_0()



# Generated at 2022-06-25 05:40:15.462508
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    assert playbook_include_0.load_data(None, None, None) is None


# Generated at 2022-06-25 05:40:17.489574
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include = PlaybookInclude()
    ds = {}
    new_ds = playbook_include.preprocess_data(ds)
    assert(new_ds == ds)

# Generated at 2022-06-25 05:40:23.165766
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    Var0 = {}
    Var1 = {}
    Var2 = {}
    Var3 = {}
    Var4 = {}
    Var5 = {}
    Var6 = {}
    Var7 = {}
    Var8 = {}
    Var9 = {}
    # Set up parameter values
    data = None
    basedir = None
    variable_manager = None
    loader = None
    Var10 = PlaybookInclude()
    Var10.load_data(data, basedir, variable_manager, loader)


# Generated at 2022-06-25 05:40:34.537211
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
  import tempfile
  __pychecker__='no-argsused'
  fh, path = tempfile.mkstemp(prefix='ansible_test_playbook_include_')
  os.close(fh)

  playbook_include_0 = PlaybookInclude()

  # Create a new class instance.
  var_0 = {}
  var_1 = playbook_include_0.load_data(var_0, var_0, var_0)
  assert var_1 is not None, "Cannot find a valid 'assert' statement for the line following 'var_1 = playbook_include_0.load_data(var_0, var_0, var_0)'"

  # Cleanup
  os.unlink(path)



# Generated at 2022-06-25 05:40:44.278508
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    var_2 = {}
    var_3 = {}
    playbook_include_1.load_data(var_2, var_2, var_3, var_2)
    playbook_include_2 = PlaybookInclude()
    var_4 = {}
    var_5 = {}
    playbook_include_2.load_data(var_4, var_5, var_5, var_5)
    playbook_include_3 = PlaybookInclude()
    var_6 = {}
    var_7 = {}
    playbook_include_3.load_data(var_6, var_7, var_7, var_7)


# Generated at 2022-06-25 05:40:44.867259
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    assert True

# Generated at 2022-06-25 05:40:47.055558
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include = PlaybookInclude()
    var = {}
    playbook_include_load_data = playbook_include.load_data(var, var, var, var)


# Generated at 2022-06-25 05:40:55.345328
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import yaml

    yaml_str = '''
    - import_playbook: test.yml
      tags: test_tag
      vars:
        first: one
        second: two
      when: test
    '''

    yaml_data = yaml.safe_load(yaml_str)

    playbook_include_obj = PlaybookInclude()
    playbook_obj = playbook_include_obj.load_data(yaml_data[0], './test', None)

    assert playbook_obj._entries[0].tags == ['test_tag']
    assert playbook_obj._entries[0].vars['first'] == 'one'
    assert playbook_obj._entries[0].vars['second'] == 'two'
    assert playbook_obj._entries[0].when == ['test']

# Unit

# Generated at 2022-06-25 05:41:57.375784
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = {}
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0)
    return var_1

# Generated at 2022-06-25 05:42:02.812224
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    args = dict(
        ds='ds_value',  # string
        basedir='basedir_value',  # string
        variable_manager='variable_manager_value',  # string
        loader='loader_value'  # string
    )

    # pylint: disable=redefined-variable-type
    if True:
        args['ds'] = 'ds_value'
        args['basedir'] = 'basedir_value'
        args['variable_manager'] = 'variable_manager_value'
        args['loader'] = 'loader_value'
        result = PlaybookInclude.load_data(**args)



# Generated at 2022-06-25 05:42:12.813012
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    text_0 = '''#
# Ansible managed
#
---

#
# Ansible managed
#
{
    #
    # This playbook is kept in sync by ansible-pull
    #
    "import_playbook": "~/ansible/pull_post_install.yml",
    "vars": {
        "host_key_checking": false
    },
    "tags": [
        "post_install"
    ]
}
'''
    # test_case_0()
    template_result_0 = PlaybookInclude.load(text_0, text_0, text_0)

# Generated at 2022-06-25 05:42:14.902882
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    item_0 = PlaybookInclude()
    dict_0 = {}
    dict_1 = item_0.preprocess_data(dict_0)


# Generated at 2022-06-25 05:42:19.355180
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Dummy imports
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    # Test object init
    playbook_include_0 = PlaybookInclude()
    var_0 = {}
    var_1 = DataLoader()
    var_2 = AnsibleCollectionConfig()
    var_3 = VariableManager()
    var_4 = playbook_include_0.load_data(var_0, var_0, var_1, var_2) == playbook_include_0.load_data(var_0, var_0, var_3, var_2)


# Generated at 2022-06-25 05:42:23.179140
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    ## set defaults for the test
    ##
    ## TODO: update this to a minimal test
    ##

    # test the execute_playbook method
    test_case_0()


# Generated at 2022-06-25 05:42:27.867697
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = {}
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0)


# Generated at 2022-06-25 05:42:32.381693
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = {}
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0)


# Generated at 2022-06-25 05:42:43.675669
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import pytest
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.template import Templar
    import ansible.playbook.playbook_include

    with pytest.raises(AnsibleAssertionError) as excinfo:
        playbook_include_0 = PlaybookInclude()
        var_0 = {}
        playbook_include_2 = playbook_include_0.load_data(var_0, var_0, var_0)
    excinfo.match(r'^ds \(%r\) should be a dict but was a <class \'set\'>$' % var_0)

    with pytest.raises(AnsibleAssertionError) as excinfo:
        playbook_include_0 = PlaybookInclude()
        var_0 = {}
        playbook_include_2

# Generated at 2022-06-25 05:42:48.877676
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = {}
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0)
