

# Generated at 2022-06-25 05:34:42.216182
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    StartTestCase("run_PlaybookInclude_load_data")

    playbook_include_0 = PlaybookInclude()

    ds = {u'import_playbook': u''}
    basedir = ''
    variable_manager = ''
    loader = ''
    result_playbook_include_0 = playbook_include_0.load_data(ds, basedir, variable_manager, loader)
    eq_(result_playbook_include_0, None, "Testing if result_playbook_include_0 == None")

    EndTestCase()


# Generated at 2022-06-25 05:34:42.737378
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-25 05:34:49.033557
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_1 = PlaybookInclude()
    playbook_include_1._valid_attrs = {'import_playbook': None, 'tags': None, 'vars': None }
    ds = ["test_import.yml"]
    new_ds =  playbook_include_1.preprocess_data(ds)
    assert type(new_ds) == AnsibleMapping
    assert new_ds.get('import_playbook') == "test_import.yml"

    ds = "test_import.yml"
    new_ds =  playbook_include_1.preprocess_data(ds)
    assert type(new_ds) == AnsibleMapping
    assert new_ds.get('import_playbook') == "test_import.yml"


# Generated at 2022-06-25 05:35:00.680756
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    playbook_include_1 = PlaybookInclude()
    playbook_include_2 = PlaybookInclude()

    try:
        # Test playbook_include_1
        # Test ds = {'import_playbook': '../tasks/apt_get_update.yml'}
        ds1 = {'import_playbook': '../tasks/apt_get_update.yml'}
        playbook_include_1.preprocess_data(ds1)
        assert playbook_include_1.import_playbook == '../tasks/apt_get_update.yml'
        assert playbook_include_1.tags == []
        assert playbook_include_1.vars == {}
    except AnsibleParserError:
        pass


# Generated at 2022-06-25 05:35:11.658508
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # create a playbook_include object
    playbook_include_1 = PlaybookInclude(loader=None, variable_manager=None)
    # load PlaybookInclude data
    playbook_include_1.load_data(ds={"import_playbook":"/tmp/test.yml"}, basedir="/home", variable_manager=None, loader=None)
    # get the value of field import_playbook
    import_playbook = playbook_include_1.get_import_playbook()
    # make assertions on the import_playbook value
    assert import_playbook == "/tmp/test.yml"
    # get the value of field vars
    vars = playbook_include_1.get_vars()
    # make assertions on the vars value
    assert vars == {}


# Generated at 2022-06-25 05:35:18.645816
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    ds_1 = "{'import_playbook': 'import_playbook.yaml'}"
    basedir_1 = "basedir"
    variable_manager_1 = "variable_manager"
    loader_1 = "loader"
    playbook_include_1.load_data(ds=ds_1, basedir=basedir_1, variable_manager=variable_manager_1, loader=loader_1)


# Generated at 2022-06-25 05:35:24.436569
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    test_PlaybookInclude = PlaybookInclude()
    assert test_PlaybookInclude.load_data(ds='ds', basedir='basedir') == None




# Generated at 2022-06-25 05:35:25.920485
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = test_case_0()

# Generated at 2022-06-25 05:35:36.071657
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    data = dict()
    basedir = '/home/travis/build/ansible/ansible/test/units/lib/ansible/playbook'
    variable_manager = dict()
    loader = dict()

    display.deprecated(msg='Use of "from ansible.parsing.dataloader import DataLoader" is deprecated', version='2.5')
    loader = DataLoader()
    variable_manager = VariableManager()

    playbook_include_0.load_data(ds=data, basedir=basedir, variable_manager=variable_manager, loader=loader)
    assert playbook_include_0._import_playbook == ''
    assert playbook_include_0.vars == {}


# Generated at 2022-06-25 05:35:38.305084
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include = PlaybookInclude()
    ds = {'import_playbook': 'a.yml'}
    playbook_include.preprocess_data(ds)
    assert playbook_include.import_playbook == 'a.yml'


# Generated at 2022-06-25 05:35:52.552711
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(ds=dict_0, basedir=dict_0, variable_manager=dict_0, loader=dict_0)


# Generated at 2022-06-25 05:35:55.644291
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    try:
        test_case_0()
    except AssertionError as e:
        raise AssertionError(e)


# Generated at 2022-06-25 05:36:00.980041
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {}
    playbook_include_0 = PlaybookInclude()
    assert playbook_include_0.load_data(ds=dict_0, basedir="", variable_manager="", loader="") == playbook_include_0


# Generated at 2022-06-25 05:36:02.272145
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_load_data_exposer()
    pass


# Generated at 2022-06-25 05:36:05.543008
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {}
    playbook_include_0 = PlaybookInclude()
    playbook_0 = playbook_include_0.load_data(dict_0, None, None, None)


# Generated at 2022-06-25 05:36:14.504363
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_1 = playbook_include_0.preprocess_data(dict_0)
    # Test case snippet from ansible.builtin.test
    # FIXME
    # ansible.builtin.test.raw = True
    # Test case snippet from ansible.builtin.test
    # FIXME
    # ansible.builtin.test.raw = False
    # Test case snippet from ansible.builtin.test
    # FIXME
    # ansible.builtin.test.section = 'test'
    # Test case snippet from ansible.builtin.test
    # FIXME
    # ansible.builtin.test.section = 'stage'
    # Test case snippet from ansible.builtin.test
    # FIXME
    # ans

# Generated at 2022-06-25 05:36:18.473025
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {}

    # Test case:  Absolute path and no variable substitution
    playbook_include_0.load_data(ds=dict_0, basedir='/', variable_manager=None, loader=None)

    # Test case:  Empty path and variable substitution
    playbook_include_0.load_data(ds=dict_0, basedir='/', variable_manager=None, loader=None)

    # Test case:  Relative path and no variable substitution
    playbook_include_0.load_data(ds=dict_0, basedir='/', variable_manager=None, loader=None)

    # Test case:  Relative path and variable substitution

# Generated at 2022-06-25 05:36:22.611002
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()
    assert playbook_include_0.preprocess_data({}) is None
    assert playbook_include_0.preprocess_data({'test'}) is None


# Generated at 2022-06-25 05:36:29.442732
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = dict()
    basedir_0 = "./tests/test_playbook_include.py"
    variable_manager_0 = VariableManager()
    loader_0 = DataLoader()
    playbook_0 = playbook_include_0.load_data(dict_0, basedir_0, variable_manager_0, loader_0)

# Generated at 2022-06-25 05:36:32.513865
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    method = getattr(PlaybookInclude, 'preprocess_data', None)
    assert method
    assert callable(method)
    method = getattr(PlaybookInclude, '_preprocess_import', None)
    assert method
    assert callable(method)


# Generated at 2022-06-25 05:36:39.470069
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = {}
    var_0_0 = {}
    var_0_1 = playbook_include_0.load_data(var_0_0, var_0, var_0, var_0)


# Generated at 2022-06-25 05:36:49.090976
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = {}
    var_1 = {}

    # Test with correct arguments
    try:
        playbook_include_0 = PlaybookInclude()
        var_2 = playbook_include_0.load_data(var_0, var_0, var_0, var_0)
    except Exception as e:
        print(e)
        assert False

    # Test with incorrect arguments
    try:
        playbook_include_1 = PlaybookInclude()
        var_3 = playbook_include_1.load_data(var_1, var_1, var_1, var_1)
        assert False
    except Exception as e:
        print(e)
        assert True



# Generated at 2022-06-25 05:36:52.830783
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    var_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_1 = playbook_include_0.preprocess_data(var_0)


# Generated at 2022-06-25 05:36:56.148391
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0, var_0)


# Generated at 2022-06-25 05:37:02.736898
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0, var_0)
    # assert playbook_include_0.load_data(var_0, var_0, var_0, var_0) == var_1


# Generated at 2022-06-25 05:37:09.110298
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    play_data = {}

    var_0 = {}
    var_1 = PlaybookInclude.load(None, None, None, None)
    assert var_1 is not None
    assert var_1._entries is not None
    assert var_1._entries == []

    var_2 = PlaybookInclude.load(var_1, var_0, None, None)
    assert var_2._entries == []

    var_3 = PlaybookInclude.load(var_0, var_0, None, None)
    assert var_3._entries == []


# Generated at 2022-06-25 05:37:11.622880
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    for _ in range(0, 10):
        playbook_include_0.load_data()



# Generated at 2022-06-25 05:37:13.910673
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0, var_0)


# Generated at 2022-06-25 05:37:20.216916
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = {}
    var_1 = "for i in range(0,3): print(i)"
    var_2 = {}
    var_3 = {}
    var_4 = {}
    playbook_include_0 = PlaybookInclude()
    var_5 = playbook_include_0.load_data(var_4, var_1, var_0, var_0)


# Generated at 2022-06-25 05:37:23.136431
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    var_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_1 = playbook_include_0.preprocess_data(var_0)


# Generated at 2022-06-25 05:37:35.529476
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0, var_0)
    print(var_1)



# Generated at 2022-06-25 05:37:38.278041
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0, var_0)

# Generated at 2022-06-25 05:37:42.018432
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    var_0 = {}
    yaml_0 = AnsibleMapping(var_0)
    yaml_0.ansible_pos = None
    playbook_include_0 = PlaybookInclude()
    var_1 = playbook_include_0.preprocess_data(yaml_0)


# Generated at 2022-06-25 05:37:47.210070
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    new_dict = {}
    new_dict = PlaybookInclude().load_data(ds=new_dict, ds={})


# Generated at 2022-06-25 05:37:49.986499
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(var_0, var_0, var_0, var_0)


# Generated at 2022-06-25 05:37:54.451970
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_2 = {}
    playbook_include_1 = PlaybookInclude()
    var_3 = playbook_include_1.load_data(var_2, var_2, var_2, var_2)


# Generated at 2022-06-25 05:37:57.034564
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = {}
    var_1 = {}
    var_0 = playbook_include_0.load_data(var_0, var_1, var_0, var_0)


# Generated at 2022-06-25 05:37:58.609493
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # vars need to be defined as a dict

    var_1 = {}

    var_2 = PlaybookInclude()
    var_3 = var_2.preprocess_data(var_1)


# Generated at 2022-06-25 05:38:01.962417
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    print('test_PlaybookInclude_preprocess_data...')
    playbook_include_0 = PlaybookInclude()
    var_0 = {}
    playbook_include_1 = playbook_include_0.load_data(var_0, var_0, var_0, var_0)


# Generated at 2022-06-25 05:38:05.113630
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    yaml_0 = {}
    playbook_include_0 = PlaybookInclude()
    result = playbook_include_0.preprocess_data(yaml_0)
    assert result is None

# Generated at 2022-06-25 05:38:17.969378
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    var_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.preprocess_data(var_0)


# Generated at 2022-06-25 05:38:21.924547
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0, var_0)
    assert playbook_include_0.load_data(var_0, var_0, var_0, var_0) == var_1


# Generated at 2022-06-25 05:38:27.892056
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = 'play.yml'
    playbook_include_0 = PlaybookInclude()
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0, var_0)
    assert isinstance(var_1, Playbook)


# Generated at 2022-06-25 05:38:38.157506
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    var_0 = {}
    var_1 = {}
    var_2 = {}
    var_3 = {}
    var_4 = {}
    var_5 = {}
    var_6 = {}
    var_7 = {}
    var_8 = {}
    var_9 = {}
    var_10 = {}
    var_11 = {}
    var_12 = {}
    var_13 = {}
    var_14 = {}
    var_15 = {}
    var_16 = {}
    var_17 = {}
    var_18 = {}
    var_19 = {}
    var_20 = {}
    var_21 = {}
    var_22 = {}
    var_23 = {}
    var_24 = {}
    var_25 = {}
    var_26 = {}
    var_27 = {}
    var_

# Generated at 2022-06-25 05:38:43.627450
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = {}
    var_1 = {}
    var_1['import_playbook'] = 'test_data/integration/targets/all/import_playbook.yml'
    var_1['tags'] = 'tag1'
    var_2 = {'test-var': 'test-val'}
    var_3 = playbook_include_0.load_data(var_1, var_2, var_2, var_2)

test_PlaybookInclude_load_data()

# Generated at 2022-06-25 05:38:49.974716
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = {}
    var_1 = var_0
    var_2 = var_0
    var_3 = var_0
    var_4 = PlaybookInclude()
    var_5 = var_4.load_data(var_0, var_1, var_2, var_3)



# Generated at 2022-06-25 05:38:55.266899
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    with pytest.raises(AnsibleParserError) as exception_info:
        var_0 = {}
        playbook_include_0 = PlaybookInclude()
        var_1 = playbook_include_0.load_data(var_0, var_0, var_0, var_0)
    assert str(exception_info.value) == "import_playbook parameter is missing"


# Generated at 2022-06-25 05:38:58.011939
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = {}
    var_1 = []
    playbook_include_0 = PlaybookInclude()
    var_2 = playbook_include_0.load_data(var_0, var_0, var_0, var_0)


# Generated at 2022-06-25 05:39:04.745122
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # Test with a simple unstructured string.
    var_0 = {"test_var": "test_value"}
    playbook_include_0 = PlaybookInclude()
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0, var_0)
    assert var_1 == None

    # Test with a structured string.
    var_2 = {"test_var": "test_value"}
    playbook_include_1 = PlaybookInclude()
    var_3 = playbook_include_1.load_data(var_2, var_2, var_2, var_2)
    assert var_3 == None

    # Test with a structured string.
    var_4 = {"test_var": "test_value"}
    playbook_include_2 = PlaybookInclude()
    var

# Generated at 2022-06-25 05:39:07.120196
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
  var_0 = {}
  obj_0 = PlaybookInclude()
  var_1 = obj_0.load_data(var_0, var_0, var_0, var_0)
  assert obj_0.vars == var_0
  assert obj_0.tags == []
  assert obj_0.when == []


# Generated at 2022-06-25 05:39:19.650722
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_7 = {}
    playbook_include_1 = PlaybookInclude()
    var_8 = playbook_include_1.load_data(var_7, var_7, var_7, var_7)


# Generated at 2022-06-25 05:39:21.807354
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    try:
        assert(test_case_0() == None)
    except Exception as e:
        raise e
    else:
        None


# Generated at 2022-06-25 05:39:31.725681
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_2 = PlaybookInclude()
    var_2 = {}
    var_3 = {}
    var_4 = {}
    var_5 = {}
    var_6 = playbook_include_2.load_data(var_2, var_3, var_4, var_5)

    playbook_include_3 = PlaybookInclude()
    var_7 = {}
    var_8 = {}
    var_9 = {}
    var_10 = {}
    var_11 = playbook_include_3.load_data(var_7, var_8, var_9, var_10)

    playbook_include_4 = PlaybookInclude()
    var_12 = {}
    var_13 = {}
    var_14 = {}
    var_15 = {}
    var_16 = playbook_include_4.load

# Generated at 2022-06-25 05:39:38.316932
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # import here to avoid a dependency loop
    from ansible.playbook import Playbook

    playbook_include_0 = PlaybookInclude()
    ds = {}
    var_1 = playbook_include_0.preprocess_data(ds)


# Generated at 2022-06-25 05:39:46.426353
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # Setup test case
    var_0 = {}
    playbook_include_0 = PlaybookInclude()

    # Method load_data of class PlaybookInclude with arguments var_0, var_0, var_0, var_0
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0, var_0)

    # Test case cleanup
    playbook_include_0 = None

    # Test assertions
    assert(isinstance(var_1, dict))


# Generated at 2022-06-25 05:39:49.397111
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0, var_0)
    assert var_1 == {}



# Generated at 2022-06-25 05:39:51.539909
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0, var_0)


# Generated at 2022-06-25 05:39:54.819027
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook = '''
    - import_playbook:
    '''
    # Test playbook syntax
    playbook_include = PlaybookInclude()
    playbook_include.preprocess_data(dict(playbook))


# Generated at 2022-06-25 05:39:57.338209
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    var_0 = {}
    playbook_include_0 = PlaybookInclude()
    assert playbook_include_0.preprocess_data(var_0) == None

# Generated at 2022-06-25 05:40:00.744199
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = {}
    var_1 = {}
    var_2 = {}
    var_3 = {}
    playbook_include_0 = PlaybookInclude()
    var_4 = playbook_include_0.load_data(var_1, var_2, var_3, var_0)


# Generated at 2022-06-25 05:40:18.286036
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    var_0 = {}
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.preprocess_data(var_0)

# Generated at 2022-06-25 05:40:22.481642
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pbi = PlaybookInclude()
    try:
        var_1 = pbi.load_data(None, None, None, None)
    except Exception as e:
        var_2 = str(e)
        var_3 = "ds (None) should be a dict but was a <class 'NoneType'>"
        assert var_2 == var_3


# Generated at 2022-06-25 05:40:28.684916
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = {}
    var_0['import_playbook'] = 'any string'
    var_0['tags'] = 'any string'
    var_0['vars'] = 'any string'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(var_0, var_0, var_0, var_0)



# Generated at 2022-06-25 05:40:40.797902
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_1 = {"import_playbook": "var_1"}
    var_2 = {"vars": "var_2"}
    playbook_include_1 = PlaybookInclude()
    var_3 = playbook_include_1.preprocess_data(var_1)
    var_4 = playbook_include_1.preprocess_data(var_2)
    playbook_include_2 = PlaybookInclude()
    var_5 = playbook_include_2._preprocess_import(var_1, var_1, "var_1", "var_1")
    playbook_include_3 = PlaybookInclude()
    var_6 = playbook_include_3._load_data(var_2, var_0, var_0, var_0)
    playbook_include_4 = PlaybookInclude()
    var_7 = playbook

# Generated at 2022-06-25 05:40:46.651750
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    var_0 = AnsibleMapping()
    var_1 = AnsibleMapping()
    var_2 = AnsibleMapping()
    var_2["vars"] = var_1
    playbook_include_0 = PlaybookInclude()
    var_3 = playbook_include_0.preprocess_data(var_2)
    assert var_3["vars"] == {}, "expected {} but got %s" % repr(var_3["vars"])


# Generated at 2022-06-25 05:40:53.582589
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    data = {}
    variable_manager = {}
    ds = type('obj',(object,), {})
    playbook_include_0 = PlaybookInclude()
    # test for bad data type
    with pytest.raises(AnsibleAssertionError):
        playbook_include_0.preprocess_data(ds)
    # test for non-dict value
    with pytest.raises(AnsibleAssertionError):
        playbook_include_0.preprocess_data('string')
    # test for matching k=v argument
    with pytest.raises(AnsibleParserError):
        data['vars'] = {'value': 'value'}
        data['var'] = 'value'
        playbook_include_0.preprocess_data(data)
    # test for name of playbook not a string
   

# Generated at 2022-06-25 05:41:05.434112
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    import pytest

    # Test for error
    with pytest.raises(AnsibleAssertionError) as excinfo:
        var_0 = None
        var_1 = None
        var_2 = None
        var_3 = None
        playbook_include_0 = PlaybookInclude()
        var_4 = playbook_include_0.load_data(var_0, var_1, var_2, var_3)
    assert 'ds (%s) should be a dict but was a %s' in str(excinfo.value)

    # Test for error
    with pytest.raises(AnsibleAssertionError) as excinfo:
        var_0 = dict()
        var_1 = dict()
        var_2 = dict()
        var_3 = dict()
        playbook_include_1 = Playbook

# Generated at 2022-06-25 05:41:13.091117
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    print('TEST: PlaybookInclude.preprocess_data()')

    var_1 = {'import_playbook': 'file_name_1.yml', 'vars': {'dst': 'var_1', 'src': 'var_1'}}
    var_2 = {'import_playbook': 'file_name_1.yml', 'vars': {'dst': 'var_2', 'src': 'var_2'}}
    var_3 = {'import_playbook': 'file_name_1.yml', 'vars': {'dst': 'var_3', 'src': 'var_3'}}

# Generated at 2022-06-25 05:41:16.374685
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    var_0 = {'import_playbook': 'xXxXxXxXx', 'when': 'xXxXxXxXx'}
    playbook_include_0 = PlaybookInclude()
    ansible_mapping_0 = playbook_include_0.preprocess_data(var_0)


# Generated at 2022-06-25 05:41:18.747470
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0, var_0)


# Generated at 2022-06-25 05:41:39.769664
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0, var_0)


# Generated at 2022-06-25 05:41:43.052463
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = {}
    playbook_include_0 = PlaybookInclude()

    var_2 = {}
    var_3 = {}
    playbook_include_0.load_data(var_2, var_3)


if __name__ == '__main__':
    test_case_0()
    test_PlaybookInclude_load_data()

# Generated at 2022-06-25 05:41:50.169765
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = {}
    var_1 = {}
    var_2 = {}
    var_3 = {}
    var_4 = PlaybookInclude()
    var_5 = var_4.load_data(var_0, var_1, var_2, var_3)
    var_6 = {}
    var_7 = {}
    var_8 = {}
    var_9 = {}
    var_10 = PlaybookInclude()
    var_11 = var_10.load_data(var_6, var_7, var_8, var_9)
    var_12 = {}
    var_13 = {}
    var_14 = {}
    var_15 = {}
    var_16 = PlaybookInclude()

# Generated at 2022-06-25 05:41:58.629838
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    print(">>> test_PlaybookInclude_load_data")
    var_0 = {}
    var_1 = {}
    var_2 = {}
    var_3 = {}
    var_4 = {}
    var_5 = {}
    var_7 = {}
    playbook_include_0 = PlaybookInclude()
    try:
        var_6 = playbook_include_0.load_data(var_0, var_1, var_2, var_3)
    except AnsibleParserError:
        print('AnsibleParserError raised')
    else:
        print('no exception for load_data')
        print(var_6)


# Generated at 2022-06-25 05:42:04.450520
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    passed=0
    failed=0

    var_0 = {}
    var_1 = {}
    var_2 = {}
    var_3 = {}
    var_4 = {}
    var_5 = {}
    var_6 = {}
    var_7 = {}
    var_8 = {}
    var_9 = {}
    var_10 = {}

    try:
        test_case_0()
        passed += 1
    except Exception:
        failed += 1

    print('***************************')
    print('* Unit Test Summary Report *')
    print('***************************')
    print('# tests: ' + str(passed + failed))
    print('# passed: ' + str(passed))
    print('# failed: ' + str(failed))

# Generated at 2022-06-25 05:42:09.050659
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # test_case_0():
    var_2 = {}
    playbook_include_1 = PlaybookInclude()
    assert playbook_include_1.preprocess_data(var_2) == {}, 'playbook_include_1.preprocess_data({}) == {}'


# Generated at 2022-06-25 05:42:15.367610
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # set up test case args
    data = {'item1': 'value1', 'item2': 'value2'}
    basedir = 'test_basedir'
    variable_manager = {'var1': 'value1', 'var2': 'value2'}
    loader = {'item1': 'value1', 'item2': 'value2'}
    # set up test case
    playbook_include_0 = PlaybookInclude()
    # run test
    var_0 = playbook_include_0.load_data(data, basedir, variable_manager, loader)
    # assert return values
    assert var_0 == None



# Generated at 2022-06-25 05:42:20.771905
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts({"foo": "bar"})
    variable_manager.set_nonpersistent_facts({"a": "b"})
    display.deprecated("Use of '-c local' is deprecated.  Use '-c default:localhost' instead", version='2.14')
    var_0 = {'connection': 'local', 'playbook_dir': '/playbooks', 'play_hosts': ['localmachine'], 'remote_user': 'root', 'current_user': 'root', 'foo': 'bar', 'hostname': 'localhost', '_ansible_no_log': False, 'a': 'b'}
    playbook_include_0 = PlaybookInclude()
    assert isinstance(playbook_include_0._loader, BaseLoader)
    var

# Generated at 2022-06-25 05:42:28.226712
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    ds = {"" : ""}
    basedir = "/etc/ansible/roles"
    variable_manager = {"" : ""}
    loader = loader = {"" : ""}
    playbook_include_ = PlaybookInclude()
    var_1 = playbook_include_.load_data(ds, basedir, variable_manager, loader)
    assert var_1 == None


# Generated at 2022-06-25 05:42:30.190574
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0, var_0)



# Generated at 2022-06-25 05:42:59.888263
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0, var_0)

    assert var_1 is not None


# Generated at 2022-06-25 05:43:02.843744
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0, var_0)


# Generated at 2022-06-25 05:43:05.069388
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_4 = {}
    playbook_include_1 = PlaybookInclude()
    var_5 = playbook_include_1.load_data(var_4, var_4, var_4, var_4)



# Generated at 2022-06-25 05:43:07.387164
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    var_0 = {}
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.preprocess_data(var_0)


# Generated at 2022-06-25 05:43:11.754041
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    with pytest.raises(AnsibleParserError) as excinfo:
        playbook_include_0 = PlaybookInclude()
        playbook_include_0.load_data({}, 'foo/bar', None, None)
    assert 'playbook import parameter is missing' in str(excinfo.value)



# Generated at 2022-06-25 05:43:16.623979
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_13 = {}
    playbook_include_1 = PlaybookInclude()
    var_14 = {}
    var_15 = {}
    var_16 = {}
    var_17 = playbook_include_1.load_data(var_14, var_15, var_16, var_17)


# Generated at 2022-06-25 05:43:24.078101
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = {}
    var_0 = {}
    var_0 = {}
    var_0 = {}
    obj_0 = PlaybookInclude()
    obj_0.load_data(var_0, var_0, var_0, var_0)
    # Relies on the file name for tests to pass.
    #assert True


# Generated at 2022-06-25 05:43:28.664984
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = {}
    var_0 = {}
    var_1 = {}
    var_1 = {}
    var_2 = {}
    var_2 = {}
    playbook_include_0 = PlaybookInclude()
    var_3 = playbook_include_0.load_data(var_0, var_1, var_2, var_2)
    assert isinstance(var_3, object)
    var_0 = {}
    var_0 = {}
    var_0 = {}
    var_1 = {}
    var_1 = {}
    var_1 = {}
    var_2 = {}
    var_2 = {}
    var_2 = {}
    var_3 = {}
    var_3 = {}
    var_3 = {}
    var_4 = {}
    var_4 = {}
    var

# Generated at 2022-06-25 05:43:33.552263
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_2 = {}
    var_2 = PlaybookInclude()
    var_3 = {}
    var_3 = var_2.load_data(var_3, var_3, var_3, var_3)


# Generated at 2022-06-25 05:43:35.548309
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    var_1 = {}
    playbook_include_1 = PlaybookInclude()
    var_2 = playbook_include_1.preprocess_data(var_1)
