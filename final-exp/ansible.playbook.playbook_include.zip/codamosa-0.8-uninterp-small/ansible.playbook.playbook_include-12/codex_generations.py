

# Generated at 2022-06-25 05:34:31.089834
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    print("playbook_include_0.load_data(ds, basedir, variable_manager, loader)")


# Generated at 2022-06-25 05:34:37.079151
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    value_0=playbook_include_0.load_data({'import_playbook': 'a', 'vars': {'b': 'c'}}, 'a', None, None)



# Generated at 2022-06-25 05:34:42.215309
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    assert playbook_include_0.load_data() == None


# Generated at 2022-06-25 05:34:51.130335
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # Data
    ds = {
        "import_playbook": "../roles/role_b/meta/main.yml",
        "vars": {
            "var_a": 1,
            "var_b": 2
        }
    }

    # Test
    playbook_include = PlaybookInclude()
    result = playbook_include.preprocess_data(ds)

    # Assert
    assert playbook_include.import_playbook == "../roles/role_b/meta/main.yml"
    assert playbook_include.vars == {
        "var_a": 1,
        "var_b": 2
    }

# Test that the load method creates a Playbook object

# Generated at 2022-06-25 05:34:56.776345
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # TODO
    #playbook_include_0 = PlaybookInclude()
    #playbook_include_0.preprocess_data()
    pass

# Generated at 2022-06-25 05:35:01.834337
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    ds = "test_value_1"
    basedir = "test_value_2"
    variable_manager = PlaybookInclude()
    loader = PlaybookInclude()
    new_obj = playbook_include_0.load_data(ds, basedir, variable_manager, loader)
    assert isinstance(new_obj, PlaybookInclude)
    assert new_obj._validate_data() is True


# Generated at 2022-06-25 05:35:13.114140
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude()
    playbook_include_2 = PlaybookInclude()
    playbook_include_3 = PlaybookInclude()
    playbook_include_4 = PlaybookInclude()
    playbook_include_5 = PlaybookInclude()
    playbook_include_6 = PlaybookInclude()

    ds = dict(import_playbook='hosts')
    playbook_include_0.load_data(ds, '/path/to/playbooks')
    ds = dict(import_playbook='hosts tags=foo,bar')
    playbook_include_1.load_data(ds, '/path/to/playbooks')
    ds = dict(import_playbook='hosts vars=foo,bar')
    playbook_include_2.load

# Generated at 2022-06-25 05:35:22.546221
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_load_data = AnsibleMapping()
    playbook_include_load_data["test_PlaybookInclude_load_data"] = [
        {
            "import_playbook": "/home/trannguyen/ansible-repos/ansible-module-develop/test/import_playbook/another_playbook.yml",
            "vars": {
                "var_1": "var_value_1"
            }
        }
    ]
    for testcase in playbook_include_load_data["test_PlaybookInclude_load_data"]:
        yield (run_PlaybookInclude_load_data, testcase)


# Generated at 2022-06-25 05:35:34.053522
# Unit test for method preprocess_data of class PlaybookInclude

# Generated at 2022-06-25 05:35:40.543958
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    input = {'include': 'some_playbook.yaml'}
    playbook_include_1 = PlaybookInclude.load(input, '/a/playbook/dir')
    expected = {'import_playbook': 'some_playbook.yaml'}
    assert playbook_include_1._ds == expected


# Generated at 2022-06-25 05:35:52.515420
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = 'Lk^Y_!]!OP'
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude()
    var_0 = playbook_include_1.load(str_0, playbook_include_0)


# Generated at 2022-06-25 05:35:58.751489
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = dict()
    dict_0['tasks'] = {'include_tasks': 'tasks.yml'}
    dict_0['roles'] = {'include_role': {'name': 'common'}}
    str_0 = 'common'
    dict_1 = dict()
    dict_1['name'] = 'common'
    dict_0['hosts'] = str_0
    playbook_include_1 = PlaybookInclude()
    playbook_include_2 = PlaybookInclude()
    var_0 = playbook_include_2.load_data(dict_0, playbook_include_1, playbook_include_0)


# Generated at 2022-06-25 05:36:01.116825
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = 'Lk^Y_!]!OP'
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude()
    var_0 = playbook_include_1.load(str_0, playbook_include_0)


# Generated at 2022-06-25 05:36:06.216589
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    ansible_map_0 = AnsibleMapping()
    str_0 = 'm\\1='
    str_1 = '[T=d?0'
    playbook_include_1 = PlaybookInclude()
    var_0 = playbook_include_1.load(str_1, playbook_include_0)
    

# Generated at 2022-06-25 05:36:12.848995
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    ds = 'PlaybookInclude'
    basedir = 'tmpscjzZ9i'
    variable_manager = 'tmpscjzZ9i'
    loader = 'tmpscjzZ9i'
    var_0 = playbook_include_0.load_data(ds, basedir, variable_manager, loader)
    assert var_0.__class__.__name__ == 'Playbook'
    # self.assertEqual(len(var_0.entries), 5)



# Generated at 2022-06-25 05:36:17.016937
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = dict()
    basedir_0 = 'N-N5#+'
    variable_manager_0 = 'w'
    loader_0 = '9'
    playbook_0 = playbook_include_0.load_data(dict_0, basedir_0, variable_manager_0, loader_0)


# Generated at 2022-06-25 05:36:23.437294
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include = PlaybookInclude()
    ds = AnsibleMapping()
    ds["import_playbook"] = "./ansible-modules-core/cloud/amazon"
    var_0 = playbook_include.load_data(ds, ".")
    assert var_0 is not None
    # TODO: Write proper test case


# Generated at 2022-06-25 05:36:32.991320
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import tempfile
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword

    '''
    Unit test for method load_data of class PlaybookInclude.
    '''

    # Init test
    print('Init test')
    play_0 = Play('play_0')
    play_1 = Play('play_1')
    play_2 = Play('play_2')
    play_3 = Play('play_3')
    play_4 = Play('play_4')
    var_0 = play_3.task_blocks
    var_1 = play_4.task_blocks
    var_2 = play_4.load('str_0', play_2)

# Generated at 2022-06-25 05:36:37.274395
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    yaml_data = """
- include: test_include_playbook.yml
    tags:
      - foo
    vars:
      foo: bar
      baz: bang
"""
    pbin = PlaybookInclude.load_data(yaml_data, '.')
    assert pbin is not None
    assert pbin._entries is not None
    assert len(pbin._entries) == 3
    assert pbin._entries[0].tags == ['foo']
    assert pbin._entries[0].vars == {'foo': 'bar', 'baz': 'bang'}



# Generated at 2022-06-25 05:36:41.508042
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_2 = PlaybookInclude()
    str_1 = 'Lk^Y_!]!OP'
    playbook_include_3 = PlaybookInclude()
    playbook_include_4 = PlaybookInclude()
    var_1 = playbook_include_4.load_data(str_1, playbook_include_3)


# Generated at 2022-06-25 05:36:50.591672
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude()
    playbook_include_2 = PlaybookInclude()
    str_0 = '- import_playbook: a'
    str_1 = 'name: value'
    var_0 = playbook_include_1.load(str_0, playbook_include_2)
    var_1 = playbook_include_0.load_data(str_1, playlist_include_2)


# Generated at 2022-06-25 05:36:53.845315
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    data = {}
    basedir = '/Users/shashank/Development/ansible/lib/ansible/plugins/action/include_role.py'
    variable_manager = None
    loader = None
    playbookinclude = PlaybookInclude()
    playbookinclude.load_data(data=data, basedir=basedir, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-25 05:36:57.709581
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude()
    playbook_include_1.load_data(playbook_include_0, playbook_include_0, playbook_include_1, playbook_include_0)


# Generated at 2022-06-25 05:36:59.969065
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    assert playbook_include_0.load_data() == None


# Generated at 2022-06-25 05:37:04.328523
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    temp_data = AnsibleMapping()
    mypb_include = PlaybookInclude()

    assert (mypb_include.preprocess_data(temp_data) == temp_data)


# Generated at 2022-06-25 05:37:09.232107
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Load data with simple string
    data = 'Lk^Y_!]!OP'
    basedir = 'f^:4E0I5i?A8q, H|~'
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = playbook_include_0.load_data(data, basedir)
    assert playbook_include_1 is not None

# Generated at 2022-06-25 05:37:12.607870
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_2 = PlaybookInclude()
    var_1 = 'Lk^Y_!]!OP'
    playbook_include_3 = PlaybookInclude()
    var_2 = playbook_include_3.load(var_1, playbook_include_2)


# Generated at 2022-06-25 05:37:13.427852
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-25 05:37:20.263107
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude()
    playbook_include_2 = PlaybookInclude()
    str_0 = 'n/d$TVBL&6@'

    try:
        playbook_include_2.load_data(str_0, playbook_include_0, playbook_include_1)
    except Exception as e:
        print("Caught exception: %s" % e)



# Generated at 2022-06-25 05:37:24.575523
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = 'qk-a'
    basedir_0 = 'oo7:f'
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude()
    var_0 = playbook_include_1.load_data(str_0, basedir_0, playbook_include_0)


# Generated at 2022-06-25 05:37:36.513578
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = {}
    var_1 = 'I@QMr-b`6g`(z`@'
    var_0 = playbook_include_0.load_data(var_0, var_1)


# Generated at 2022-06-25 05:37:39.948682
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = 'Lk^Y_!]!OP'
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude()
    playbook_include_1.load(str_0, playbook_include_0)


# Generated at 2022-06-25 05:37:44.693620
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    str_0 = '&xTz+a!R88/TdH^/'
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude()
    playbook_include_2 = PlaybookInclude()
    playbook_include_3 = PlaybookInclude()
    playbook_include_3.load_data(str_0, playbook_include_1, playbook_include_2, playbook_include_0)


# Generated at 2022-06-25 05:37:47.445546
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude()
    str_0 = 'Lk^Y_!]!OP'
    var_0 = playbook_include_1.load(str_0, playbook_include_0)
    assert var_0


# Generated at 2022-06-25 05:37:52.339474
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    print("unittest for method load_data of class PlaybookInclude")
    test_case_0()


# Generated at 2022-06-25 05:37:54.988498
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = 'Lk^Y_!]!OP'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(str_0, playbook_include_0)
    if not var_0:
        assert var_0


# Generated at 2022-06-25 05:37:58.737538
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = 'Ck_Q'
    ansible_Base_0 = ansible.playbook.base.Base()
    ansible_PlaybookInclude_0 = PlaybookInclude()
    var_0 = ansible_PlaybookInclude_0.load_data(str_0, ansible_Base_0)


# Generated at 2022-06-25 05:38:04.404121
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_1 = {}
    playbook_include_2 = PlaybookInclude()
    playbook_include_3 = PlaybookInclude()
    playbook_include_3.load_data(var_1, playbook_include_2)


# Generated at 2022-06-25 05:38:10.295967
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    global str_0
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude()
    var_0 = playbook_include_1.load(str_0, playbook_include_0)
    var_0 = playbook_include_1.preprocess_data(playbook_include_0)
    return var_0


# Generated at 2022-06-25 05:38:18.950150
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = 'Lk^Y_!]!OP'
    list_0 = [str_0, str_0]
    str_1 = ';\x7f\xdd\xd6\xa8\x0c\xfd\xd9\x0e\x0f\xc5\xcb'
    int_0 = -1844441284
    list_2 = [str_1, int_0]
    str_2 = '=w|\x80\xea\xfb\xc9\x18'
    int_1 = 561208967
    list_3 = [str_2, int_1]
    str_3 = 'Lk^Y_!]!OP'
    dict_0 = {str_3: list_2}

# Generated at 2022-06-25 05:38:30.891785
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_0 = PlaybookInclude()
    ds_0 = AnsibleMapping()
    new_ds_0 = playbook_include_0.preprocess_data(ds_0)


# Generated at 2022-06-25 05:38:35.357059
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = 'Lk^Y_!]!OP'
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude()
    var_0 = playbook_include_1.load_data(str_0, playbook_include_0)


# Generated at 2022-06-25 05:38:37.519556
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include = PlaybookInclude()
    assert playbook_include.preprocess_data(False) == None


# Generated at 2022-06-25 05:38:40.186326
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # set the playbook include
    playbook_include = PlaybookInclude()
    playbook_include.load_data(variable_manager=None, basedir=None, ds=None, loader=None)

# Generated at 2022-06-25 05:38:44.485370
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = 'Lk^Y_!]!OP'
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude()
    playbook_include_1.load(str_0, playbook_include_0)

test_case_0()

# Generated at 2022-06-25 05:38:50.254294
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_2 = PlaybookInclude()
    playbook_include_3 = PlaybookInclude()
    str_1 = 'Lk^Y_!]!OP'
    str_2 = 'W_M&'
    var_1 = playbook_include_3.load_data(str_1, str_2)
    print(var_1)


# Generated at 2022-06-25 05:38:56.724095
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    v0 = PlaybookInclude()
    v1 = 'Qy1]|_1'
    v2 = '~[uZ-L'
    v3 = None
    v4 = None
    display.deprecated('The provided filter "lower" is deprecated and will be removed in a future release. Use "to_lower" instead.', version='2.12')
    v5 = v0.load_data(v1, v2, v3, v4)


# Generated at 2022-06-25 05:39:01.182076
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include = PlaybookInclude()
    try:
        playbook_include.load_data(str, playbook_include)
    except AssertionError:
        pass


# Generated at 2022-06-25 05:39:07.796217
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = 'Lk^Y_!]!OP'
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude()
    playbook_include_0.load_data(str_0, playbook_include_1)


# Generated at 2022-06-25 05:39:09.951103
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_obj = PlaybookInclude()
    pb = playbook_include_obj.load_data()
    assert pb is not None

# Generated at 2022-06-25 05:39:31.503083
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    test_playbook_include = PlaybookInclude()
    try:
        test_playbook_include.load_data(None, None)
    except TypeError as e:
        print("load_data raises a TypeError error\n")
    try:
        test_playbook_include.load_data('', None)
    except TypeError as e:
        print("load_data raises a TypeError error\n")
    try:
        test_playbook_include.load_data('', '')
    except TypeError as e:
        print("load_data raises a TypeError error\n")


# Generated at 2022-06-25 05:39:35.049617
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var = {}
    playbook_include = PlaybookInclude()
    playbook_include.load_data(var, playbook_include)


# Generated at 2022-06-25 05:39:38.447961
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    print("Test PlaybookInclude.load_data()")
    test_case_0()


# Generated at 2022-06-25 05:39:44.954090
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    data = {}
    basedir = {}
    variable_manager = {}
    loader = {}

    # Create an instance of the class under test (method under test)
    playbook_include = PlaybookInclude()
    # Invoke the load_data method
    playbook_include.load_data(data, basedir, variable_manager, loader)


# Generated at 2022-06-25 05:39:51.291922
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_1 = "test/data/test_playbook_include/test_playbook_include.yaml"
    var_2 = {'var_1': 'test/data/test_playbook_include/test_playbook_include.yaml'}
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.preprocess_data(var_1)
    var_x = playbook_include_0.load_data(var_0, playbook_include_0)
    assert var_x.__class__ == Playbook
    assert var_x.vars == var_2


# Generated at 2022-06-25 05:39:59.351558
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_2 = {}
    playbook_include_1 = PlaybookInclude()
    mock_variable_manager_0 = {}
    mock_loader_0 = {}
    var_3 = playbook_include_1.load_data(var_2, playbook_include_1, mock_variable_manager_0, mock_loader_0)
    var_4 = {}
    playbook_include_2 = PlaybookInclude()
    mock_variable_manager_1 = {}
    mock_loader_1 = {}
    var_5 = playbook_include_2.load_data(var_4, playbook_include_2, mock_variable_manager_1, mock_loader_1)


# Generated at 2022-06-25 05:40:01.940018
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    ds = {}
    basedir = ''
    variable_manager = ''
    loader = ''

    playbook_include_0 = PlaybookInclude()
    playbook_include_0.load_data(ds, basedir, variable_manager, loader)

# Generated at 2022-06-25 05:40:06.537617
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = {}
    var_1 = playbook_include_0.load_data(var_0, playbook_include_0)
    assert type(var_1) == PlaybookInclude


# Generated at 2022-06-25 05:40:08.848792
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = {}
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.load_data(var_0, playbook_include_0)


# Generated at 2022-06-25 05:40:13.104062
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_1 = playbook_include_0.load_data(var_0, playbook_include_0)


# Generated at 2022-06-25 05:40:51.272833
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_2 = {'import_playbook': 'hello.yml'}
    playbook_include_1 = PlaybookInclude()
    var_3 = playbook_include_1.load_data(var_2, playbook_include_1)
    assert var_3 is None

    var_4 = {'import_playbook': 'hello.yml'}
    playbook_include_2 = PlaybookInclude()
    var_5 = playbook_include_2.load_data(var_4, playbook_include_2)
    assert var_5 is None

    var_6 = {'import_playbook': 'hello.yml'}
    playbook_include_3 = PlaybookInclude()
    var_7 = playbook_include_3.load_data(var_6, playbook_include_3)

# Generated at 2022-06-25 05:41:01.143139
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    # No data source specified. This method is expected to fail
    with pytest.raises(AnsibleAssertionError):
        playbook_include_0.load_data(None, playbook_include_0)
    # Test with a valid data source and the value for basedir specified by the user
    # test_case_0()

    # Test with a valid data source and the value for basedir not specified by the user
    # test case 1
    var_0 = {}
    playbook_include_1 = PlaybookInclude()
    var_1 = playbook_include_1.load_data(var_0, playbook_include_1)


# Generated at 2022-06-25 05:41:03.727339
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    var_0 = {}
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.preprocess_data(var_0)


# Generated at 2022-06-25 05:41:05.288357
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    assert PlaybookInclude.preprocess_data(obj) == dict(import_playbook=file, vars={'x': 1})


# Generated at 2022-06-25 05:41:10.788511
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = dict()
    var_0['include'] = 'test.yml'
    var_0['include'] = 'test.yml'
    var_0['vars'] = dict()
    var_0['when'] = dict()
    var_0['when'] = dict()
    var_0['when'] = 'a'
    var_0['when'] = 'a'
    var_0['when'] = 'a'
    var_0['tags'] = 'a'
    var_0['tags'] = 'a'
    var_0['tags'] = 'a'
    var_0['tags'] = 'a'
    var_0['tags'] = list()
    var_0['tags'] = 'c'
    var_0['tags'] = 'c'

# Generated at 2022-06-25 05:41:17.086890
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_1 = playbook_include_0.load_data(var_0, playbook_include_0)
    assert playbook_include_0._attributes == {}
    assert playbook_include_0._load_name == 'import_playbook'
    assert playbook_include_0._load_options == {}
    assert playbook_include_0._load_terms == {}


# Generated at 2022-06-25 05:41:19.162011
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_1 = playbook_include_0.load_data(var_0, playbook_include_0)


# Generated at 2022-06-25 05:41:23.997900
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = {}
    playbook_include_0.load_data(var_0, playbook_include_0)

# Generated at 2022-06-25 05:41:26.434783
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    var_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_1 = playbook_include_0.preprocess_data(var_0)
    var_2 = playbook_include_0.preprocess_data(var_0)


# Generated at 2022-06-25 05:41:30.084892
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    var_0 = {"vars": {"new_parameter": "yes"}}
    playbook_include_0 = PlaybookInclude()
    var_1 = playbook_include_0.preprocess_data(var_0)

# Generated at 2022-06-25 05:42:42.062279
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Example data for load_data
    data = {}

    # Example outcome of load_data
    result = {}

    # Load playbook_include with example data
    playbook_include = PlaybookInclude()
    playbook_include.load_data(data)

    # Check that result is what we expect
    assert result == playbook_include.data



# Generated at 2022-06-25 05:42:43.459196
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include = PlaybookInclude()
    playbook_include.load_data()


# Generated at 2022-06-25 05:42:49.644080
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = {}
    playbook_include0 = PlaybookInclude()
    obj1 = {'vars': {}, 'import_playbook': 'test'}
    var_2 = playbook_include0.load_data(obj1, playbook_include0)
    assert var_2 == obj1

# Generated at 2022-06-25 05:42:52.872546
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = {}
    playbook_include_0.load_data(var_0, playbook_include_0)

# Generated at 2022-06-25 05:42:55.482798
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_1 = playbook_include_0.load_data(var_0, playbook_include_0)


# Generated at 2022-06-25 05:42:58.288074
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = None
    var_1 = None
    playbook_include_0 = PlaybookInclude()
    var_2 = playbook_include_0.load_data(var_0, var_1)
    assert var_2 == None


# Generated at 2022-06-25 05:43:00.190950
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    # TODO: implement test_PlaybookInclude_load_data
    #raise NotImplementedError

# Generated at 2022-06-25 05:43:02.877282
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_1 = playbook_include_0.load_data(var_0, playbook_include_0)


# Generated at 2022-06-25 05:43:11.617102
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    print("Testing load_data() method of PlaybookInclude class.")

    # Instance of PlaybookInclude class
    test_instance = PlaybookInclude()

    # Test load_data() method
    try:
        test_instance.load_data()
    except TypeError as e:
        print("[+] Implemented load_data() method without any required arguments:", e)
    else:
        print("[-] Did not implemented load_data() method without any required arguments", TypeError)

    # Test load_data() method
    try:
        test_instance.load_data(ds=["test_data_1", "test_data_2"], basedir="test_basedir")
    except TypeError as e:
        print("[+] Implemented load_data() method with required arguments:", e)

# Generated at 2022-06-25 05:43:20.160514
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = {}
    var_1 = None
    var_2 = None
    try:
        var_0 = playbook_include_0.load_data(var_0, playbook_include_0)
        raise Exception('AnsibleAssertionError: ds (%s) should be a dict but was a %s' % (var_0, type(var_0)))
    except:
        pass

    # Unit test for method load_data of class PlaybookInclude
    playbook_include_0 = PlaybookInclude()
    var_0 = []
    var_1 = None
    var_2 = None