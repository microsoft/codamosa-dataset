

# Generated at 2022-06-25 05:34:36.252276
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    ds = dict(a=1, b=2, c=3)
    ds_result = dict(a=1, b=2, c=3)

    result = PlaybookInclude.preprocess_data(PlaybookInclude(), ds)

    assert result == ds_result



# Generated at 2022-06-25 05:34:42.110528
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()

    if __name__ == "__main__":
        test_case_0()  # Case: Test Case 0
        test_PlaybookInclude_preprocess_data()  # Case: preprocess_data

# Generated at 2022-06-25 05:34:44.360761
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence


# Generated at 2022-06-25 05:34:53.002542
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()
    data_to_be_processed = {'import_playbook': 'test_file.yaml', 'vars': {'var1': 'value1', 'var2': 'value2'}, 'tags': ['l1', 'l2']}
    processed_data = playbook_include_0.preprocess_data(data_to_be_processed)
    assert processed_data == {
        'import_playbook': 'test_file.yaml',
        'vars': {'var1': 'value1', 'var2': 'value2'},
        'tags': ['l1', 'l2']
    }
    playbook_include_0 = PlaybookInclude()

# Generated at 2022-06-25 05:35:03.036558
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Test with non-existent basedir
    # TODO: create non-existent basedir
    #pbi_load_data_0 = PlaybookInclude()
    #try:
    #    pbi_load_data_0.load_data(ds, 'non-existent')
    #    assert False
    #except AnsibleParserError:
    #    assert True
    #except Exception:
    #    assert False
    # Test with None basedir
    pbi_load_data_1 = PlaybookInclude()
    try:
        pbi_load_data_1.load_data(ds, None)
        assert False
    except AnsibleParserError:
        assert True
    except Exception:
        assert False
    # Test with None variable_manager
    # TODO: create variable_manager
    #pbi_load_

# Generated at 2022-06-25 05:35:06.489010
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    #import here to avoid a dependency loop
    from ansible.playbook import Playbook
    
    playbook_include       = PlaybookInclude()
    playbook_include.load_data(ds, basedir, variable_manager, loader)


# Generated at 2022-06-25 05:35:08.659029
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include = PlaybookInclude()
    data = {}
    playbook_include.load_data(data, '/home/tom/dev/ansible/lib/')

# Generated at 2022-06-25 05:35:13.649939
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    ds_0 = {}
    basedir_0 = ""
    variable_manager_0 = ""
    loader_0 = ""
    assert playbook_include_0.load_data(ds_0, basedir_0, variable_manager_0, loader_0) == None


# Generated at 2022-06-25 05:35:17.842757
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_1 = PlaybookInclude()
    assert playbook_include_1._preprocess_import('ds', 'new_ds', 'k', 'v') is not None


# Generated at 2022-06-25 05:35:19.383259
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()

# Generated at 2022-06-25 05:35:33.455267
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    # Test raises exception if value of argument ds is not a AnsibleMapping
    with raises(TypeError):
        playbook_include_0.load_data(float_0, bool_0, variable_manager_0, loader_0)
    assert playbook_include_0.load_data(ansible_mapping_0, bool_0, variable_manager_0, loader_0) == False


# Generated at 2022-06-25 05:35:39.825746
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    float_0 = 718.403
    bool_0 = None
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(float_0, bool_0)


# Generated at 2022-06-25 05:35:44.200529
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    float_0 = 696.491
    bool_0 = None
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(float_0, bool_0)
    assert isinstance(var_0, PlaybookInclude) == False


# Generated at 2022-06-25 05:35:46.748188
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    data = {'vars': {'var1': 'value1'}}
    playbook_include_0.load_data(data, 'basedir')


# Generated at 2022-06-25 05:35:52.477005
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    float_0 = 718.403
    bool_0 = None
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(float_0, bool_0)
    assert playbook_include_0



# Generated at 2022-06-25 05:35:55.298566
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    float_0 = 718.403
    bool_0 = None
    var_0 = playbook_include_0.load_data(float_0, bool_0)



# Generated at 2022-06-25 05:36:00.940708
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    #print('\n\n# Unit test for method load_data of class PlaybookInclude')
    ######################
    # TODO: fix test to use proper objects instead of stubs
    ######################
    test_case_0()

# Generated at 2022-06-25 05:36:03.840908
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    test_case_0()


# Generated at 2022-06-25 05:36:14.971292
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = dict()
    dict_0["A"] = "2"
    dict_0["B"] = "4"
    dict_0["C"] = "6"
    dict_0["D"] = "8"
    dict_1 = dict()
    dict_1["E"] = "2"
    dict_1["F"] = "4"
    dict_1["G"] = "6"
    dict_1["H"] = "8"
    dict_2 = dict()
    dict_2["I"] = "2"
    dict_2["J"] = "4"
    dict_2["K"] = "6"
    dict_2["L"] = "8"
    dict_2["M"] = "2"

# Generated at 2022-06-25 05:36:20.245901
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_1 = PlaybookInclude()
    dict_0 = dict()
    dict_0['vars'] = dict()
    dict_0['vars']['gid'] = 5020
    dict_0['vars']['uid'] = 4060
    dict_0['vars']['groups'] = ['adm', 'foo']
    dict_0['vars']['name'] = 'foo'
    playbook_include_2 = playbook_include_1.preprocess_data(dict_0)
    assert isinstance(playbook_include_2, PlaybookInclude)


# Generated at 2022-06-25 05:36:24.961321
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    assert True

# Generated at 2022-06-25 05:36:28.610855
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import pytest
    # Example use
    float_0 = 718.403
    bool_0 = None
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.preprocess_data(float_0)


# Generated at 2022-06-25 05:36:40.147627
# Unit test for method preprocess_data of class PlaybookInclude

# Generated at 2022-06-25 05:36:42.107797
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-25 05:36:47.465963
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    float_0 = 718.403
    bool_0 = None
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(float_0, bool_0)


# Generated at 2022-06-25 05:36:51.006748
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()


# Generated at 2022-06-25 05:36:53.094446
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    float_0 = 718.403
    bool_0 = None
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(float_0, bool_0)

# Generated at 2022-06-25 05:36:56.422189
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    float_0 = 718.403
    bool_0 = None
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(float_0, bool_0)


# Generated at 2022-06-25 05:37:00.019359
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    float_0 = 718.403
    bool_0 = None
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(float_0, bool_0)


# Generated at 2022-06-25 05:37:04.424160
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    float_0 = 718.403
    bool_0 = None
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.load_data(float_0, bool_0)


# Generated at 2022-06-25 05:37:19.159671
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()
    float_0 = 0.0
    float_1 = 0.0
    float_2 = 0.0
    float_3 = 0.0
    float_4 = 0.0
    float_5 = 0.0
    float_6 = 0.0
    float_7 = 0.0
    float_8 = 0.0
    float_9 = 0.0
    float_10 = 0.0
    float_11 = 0.0
    float_12 = 0.0
    float_13 = 0.0
    float_14 = 0.0
    float_15 = 0.0
    float_16 = 0.0
    float_17 = 0.0
    float_18 = 0.0
    float_19 = 0.0
    float_20 = 0

# Generated at 2022-06-25 05:37:23.308529
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    '''
    Test preprocess_data of class PlaybookInclude
    '''
    float_0 = 718.403
    dict_0 = {}
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.preprocess_data(dict_0)

# Generated at 2022-06-25 05:37:26.420937
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    float_0 = 718.403
    bool_0 = None
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(float_0, bool_0)


# Generated at 2022-06-25 05:37:27.637567
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()


# Generated at 2022-06-25 05:37:30.578800
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    float_0 = 1.698e+09
    dict_0 = {}
    playbook_include_0 = PlaybookInclude.load(dict_0, float_0, float_0)
    assert playbook_include_0.preprocess_data(dict_0)



# Generated at 2022-06-25 05:37:32.309472
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data()

# Generated at 2022-06-25 05:37:41.263675
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # noinspection PyUnusedLocal
    playbook_include_0 = PlaybookInclude()
    # noinspection PyUnusedLocal
    float_0 = 718.403
    # noinspection PyUnusedLocal
    bool_0 = None
    display.deprecated("The use of 'playbook include' to import playbooks is deprecated. "
                       "Please use 'import_playbook' instead.", version='2.14')
    try:
        playbook_include_0.load_data(float_0, bool_0)
    except (AnsibleParserError, AnsibleAssertionError) as ae:
        display.display(str(ae), color='yellow')
        display.display('Continuing', color='green')

# Generated at 2022-06-25 05:37:49.605290
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.load_data(719.271, 715.721)
    playbook_include_0.preprocess_data(715.818)
    playbook_include_0._preprocess_import(716.038, 717.706, 711.649, 712.756)


if __name__ == '__main__':
    test_PlaybookInclude_load_data()

# Generated at 2022-06-25 05:37:54.732792
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    float_0 = 718.403
    bool_0 = None
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(float_0, bool_0)
    assert isinstance(var_0, Playbook)



# Generated at 2022-06-25 05:37:57.522466
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    float_0 = 718.403
    bool_0 = None
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(float_0, bool_0)


# Generated at 2022-06-25 05:38:12.572575
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include = PlaybookInclude()
    test_case_0()


# Generated at 2022-06-25 05:38:20.449754
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()

    # Load a PlaybookInclude object by using the load_data() method
    playbook_include_0.load_data('import_playbook', '', Base(), Base())

    # Load a PlaybookInclude object by using the load() static method
    # PlaybookInclude.load(ds=data, basedir=basedir, variable_manager=variable_manager, loader=loader)



# Generated at 2022-06-25 05:38:30.000337
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    test_case_0()

# exit testing if ansible-test was invoked with --pylint, --flake8 or --yaml-lint
if __name__ == '__main__':
    import sys, os
    sys.path.append(os.path.dirname(__file__) + "/../..")
    from lib.util import ansible_test_init
    test_name = os.path.basename(__file__)[5:-3]
    ansible_test_init(test_name)

    test_PlaybookInclude_preprocess_data()

# Generated at 2022-06-25 05:38:37.646930
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    data = dict()
    basedir = dict()
    variable_manager = dict()
    loader = dict()
    PlaybookInclude_obj = PlaybookInclude()
    PlaybookInclude_obj.load_data(data, basedir, variable_manager, loader)
    PlaybookInclude_obj.load_data(data, basedir, variable_manager, loader)


# Generated at 2022-06-25 05:38:42.197949
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
  playbook_include = PlaybookInclude()

  # Call method load_data with parameter playbook_include_0 of MockClass playbook_include
  dict_0 = {playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0}
  var_0 = playbook_include.load_data(dict_0)


# Generated at 2022-06-25 05:38:45.718347
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    data = 'other_playbook.yml'
    basedir = 'other_playbook.yml'
    variable_manager = 'other_playbook.yml'
    loader = 'other_playbook.yml'
    obj = PlaybookInclude()
    actual = obj.load_data(data, basedir, variable_manager, loader)
    expected = PlaybookInclude()

    assert actual == expected


# Generated at 2022-06-25 05:38:50.877476
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0}
    var_0 = playbook_include_0.preprocess_data(dict_0)
    playbook_include_0.load_data(var_0, None, None, None)


# Generated at 2022-06-25 05:38:59.567021
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os
    import shutil
    import tempfile

    # Prepare a temp directory
    temp_dir = tempfile.mkdtemp()

    # original file
    playbook_file_0 = os.path.join(temp_dir, 'test0.yml')
    playbook_text_0 = ('---\n'
                    '- include: test1.yml var1=foo\n'
                    '- include: test2.yml var1=bar')
    with open(playbook_file_0, 'w') as f:
        f.write(playbook_text_0)

    # included file 1
    playbook_file_1 = os.path.join(temp_dir, 'test1.yml')

# Generated at 2022-06-25 05:39:06.937560
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    ds_1 = "username"
    basedir_1 = "playbook.yml"
    var_1 = playbook_include_1.load_data(ds_1, basedir_1)
    #var_1 = playbook_include_1.load_data(ds=ds_1, basedir=basedir_1)


# Generated at 2022-06-25 05:39:07.838983
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    test_case_0()



# Generated at 2022-06-25 05:39:27.112928
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    dict_1 = {}
    basedir_1 = './test/integration/targets/testfile1'
    playbook_include_2 = playbook_include_1.load_data(dict_1, basedir_1)


# Generated at 2022-06-25 05:39:33.149352
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    ds = {
        'import_playbook': 'test_playbook.yml',
        'vars': {'key1': 'value1'},
        'other_key': 'other_value',
    }

    # This is a very brittle test. It will not work on a system where
    # ansible.cfg is not in /etc or /etc/ansible.
    # Hopefully that is not common. :)
    default_config_path = C.DEFAULT_CONFIG_PATH


# Generated at 2022-06-25 05:39:40.562656
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0}
    var_0 = playbook_include_0.load_data(ds=dict_0, basedir='/var/www', variable_manager='VarManager(loader=None, variables=dict_0)', loader='Loader(paths=/var/www)')


# Generated at 2022-06-25 05:39:44.125233
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    dict_1 = {}
    var_1 = playbook_include_1.load_data(dict_1, '1')


# Generated at 2022-06-25 05:39:50.147604
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    #
    # Define test inputs
    #
    # Note: The dict below is intentionally malformed. It's missing a required
    #       entry, the 'import_playbook' variable. It's missing a variable that
    #       object will look for in the first parameter (ds).
    #
    dict_0 = {'vars': dict(), 'tags': '', }

    #
    # Unit test
    #
    try:
        PlaybookInclude.load_data(dict_0, '', None, None)
    except AnsibleParserError:
        pass
    except Exception as e:
        raise


# Generated at 2022-06-25 05:39:53.120956
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0}
    var_0 = playbook_include_0.load_data(dict_0, 'basedir', None, None)

if __name__ == '__main__':
    test_case_0()
    test_PlaybookInclude_load_data()

# Generated at 2022-06-25 05:39:58.288160
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0}
    var_0 = playbook_include_0.load_data(dict_0, playbook_include_0)

# Generated at 2022-06-25 05:40:05.535728
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0}
    var_0 = playbook_include_0.preprocess_data(dict_0)
    dict_1 = {playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0}


# Generated at 2022-06-25 05:40:12.454292
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os
    fpath = '/tmp/test_PlaybookInclude_load_data_file'
    f = open(fpath, 'w')
    f.write('play book content')
    f.close()
    playbook_include_1 = PlaybookInclude()
    dict_1 = {playbook_include_1: playbook_include_1, playbook_include_1: playbook_include_1, playbook_include_1: playbook_include_1, playbook_include_1: playbook_include_1}
    var_1 = playbook_include_1.load_data(dict_1, fpath)
    os.remove(fpath)


# Generated at 2022-06-25 05:40:21.130498
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # Creating a temporary file
    import tempfile
    fd, temp_path = tempfile.mkstemp()
    with os.fdopen(fd, 'w') as temp_file:
        temp_file.write('- import_playbook: test_import_playbook_0.yml\n- import_playbook: test_import_playbook_1.yml\n- import_playbook: test_import_playbook_2.yml\n')

    # Loading the file
    playbook_include = PlaybookInclude()
    import_playbook = playbook_include.load(temp_path, None, None, None)
    assert playbook_include.import_playbook == import_playbook.import_playbook

# Generated at 2022-06-25 05:40:37.146368
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    str_1 = {}
    var_1 = playbook_include_1.load_data(str_1, str_1)


# Generated at 2022-06-25 05:40:38.703021
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    test_case_0()

# Generated at 2022-06-25 05:40:42.480129
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    str_1 = {}
    var_1 = playbook_include_1.load_data(str_1, str_1)
    assert var_1 == None


# Generated at 2022-06-25 05:40:43.443837
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass



# Generated at 2022-06-25 05:40:51.392646
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import_playbook_0 = 'Welcome,'
    var_1 = {'var_1': {'var_1': 'var_1'}, 'var_3': 'var_3', 'var_2': 'var_2'}
    setattr(import_playbook_0, 'vars', var_1)
    var_2 = {'var_3': 'var_3', 'var_1': 'var_1', 'var_2': 'var_2'}
    setattr(import_playbook_0, 'vars', var_2)
    var_3 = {'var_4': 'var_4', 'var_1': 'var_1', 'var_2': 'var_2'}
    setattr(import_playbook_0, 'vars', var_3)

# Generated at 2022-06-25 05:40:52.684895
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # p = PlaybookInclude()
    pass # Not Implemented


# Generated at 2022-06-25 05:40:56.290454
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    str_1 = {}
    var_1 = playbook_include_1.load_data(str_1, str_1)
    assert isinstance(var_1, Playbook)
    assert var_1.loader == str_1

# Generated at 2022-06-25 05:40:58.866474
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    print("\n# Unit test for method load_data of class PlaybookInclude")
    test_case_0()

# Generated at 2022-06-25 05:41:07.690649
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()
    assert playbook_include_0 is not None

    # Dummy ds as input for method preprocess_data
    ds = {
        "e": "a",
        "f": "a",
        "import_playbook": "a",
        "vars": "a",
        "tags": "a",
    }
    expected = {
        'import_playbook': "a",
        'tags': "a",
        'vars': "a",
    }
    # Call the method preprocess_data with dummy input
    result = playbook_include_0.preprocess_data(ds)

    # Check if the result corresponds to the expected value
    assert expected == result



# Generated at 2022-06-25 05:41:09.673847
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    str_1 = Playbook()
    var_0 = playbook_include_1.load_data(str_1, str_1)


# Generated at 2022-06-25 05:41:32.834724
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    str_0 = {'import_playbook': './some_playbook.yml'}
    var_0 = playbook_include_0.load_data(str_0, str_0)



# Generated at 2022-06-25 05:41:40.772255
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    str_0 = {}
    str_1 = {}
    str_2 = {}
    str_3 = {}
    str_4 = {}
    str_5 = {}
    str_6 = {}
    str_7 = {}
    str_8 = {}
    str_9 = {}
    str_10 = {}
    str_11 = {}
    str_12 = {}
    str_13 = {}
    str_14 = {}
    str_15 = {}
    str_16 = {}
    str_17 = {}
    str_18 = {}
    str_19 = {}
    str_20 = {}
    str_21 = {}
    str_22 = {}
    str_23 = {}
    str_24 = {}
    str_25 = {}
    str_26

# Generated at 2022-06-25 05:41:44.195638
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    str_0 = {}
    var_0 = playbook_include_0.load_data(str_0, str_0)

    assert str_0 is None
    assert var_0 is None


# Generated at 2022-06-25 05:41:49.328937
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    str_0 = {}
    var_0 = playbook_include_0.load_data(str_0, str_0)


# Generated at 2022-06-25 05:41:52.315865
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    data_1 = {}
    basedir_1 = {}
    var_1 = playbook_include_1.load_data(data_1, basedir_1)


# Generated at 2022-06-25 05:41:56.075416
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    str_0 = {}
    var_0 = playbook_include_0.load_data(str_0, str_0)


# Generated at 2022-06-25 05:41:59.390486
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_data_0 = {}
    playbook_include_0 = PlaybookInclude()
    playbook_include_data_1 = playbook_include_0.preprocess_data(playbook_include_data_0)
    assert playbook_include_data_1 == playbook_include_data_0


# Generated at 2022-06-25 05:42:02.532851
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # intialize object
    playbook_include_1 = PlaybookInclude()

    # initialize argument 
    str_arg_0 = {}
    str_arg_1 = {}

    var_return = playbook_include_1.load_data(str_arg_0, str_arg_1)

    # check if return value == expected
    assert var_return == {}


# Generated at 2022-06-25 05:42:08.648281
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import_playbook = 'import_playbook'
    vars = 'vars'
    basedir = 'basedir'
    variable_manager = 'variable_manager'
    loader = 'loader'
    playbook_include_0 = PlaybookInclude()
    result_0 = playbook_include_0.load_data(import_playbook, basedir, variable_manager, loader)


# Generated at 2022-06-25 05:42:09.197207
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    test_case_0()



# Generated at 2022-06-25 05:42:44.931935
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    str_0 = {}
    str_1 = {}
    var_0 = playbook_include_0.load_data(str_0, str_1)


# Generated at 2022-06-25 05:42:48.749452
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    assert playbook_include_0.load_data("main.yml", "a_basedir") is not None


# Generated at 2022-06-25 05:42:58.478032
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_import = PlaybookInclude()
    # Case 1
    ds = {'foo': {'tags': 'bar'}}
    str_0 = "foo"
    str_1 = "bar"
    new_ds = {'import_playbook': str_0, 'tags': str_1}
    var_0 = playbook_import.preprocess_data(ds)
    if var_0 == new_ds:
        display.display("test_PlaybookInclude: test_case_1 pass")
    else:
        display.display("test_PlaybookInclude: test_case_1 fail")
    # Case 2
    ds = {'include_playbook': 'bar'}
    str_0 = "bar"
    new_ds = {'import_playbook': str_0}

# Generated at 2022-06-25 05:43:01.760809
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    str_0 = {}
    variable_manager_0 = VariableManager()
    str_1 = {}
    str_2 = {}
    var_0 = playbook_include_0.load_data(str_0, str_1, variable_manager_0, str_2)


# Generated at 2022-06-25 05:43:04.277065
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    str_1 = {}
    var_1 = playbook_include_1.load_data(str_1, str_1)


# Generated at 2022-06-25 05:43:07.729500
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include = PlaybookInclude()

    ds = {'import_playbook': 'common.yml', 'tags': ['base', 'vars'], 'vars': {'var1': 'val1'}}
    variable_manager = 'dummy'
    basedir = 'dummy'
    loader = 'dummy'
    playbook_include.load_data(ds, basedir, variable_manager, loader)


# Generated at 2022-06-25 05:43:08.557058
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    _test_PlaybookInclude_load_data()


# Generated at 2022-06-25 05:43:12.466905
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    x = PlaybookInclude()
    x._load_data = lambda x: 0
    # x._load_data is defined as lambda x: 0, so it will return 0
    assert x.load_data('test_string', 'test_basedir') == 0



# Generated at 2022-06-25 05:43:15.758994
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    assert playbook_include_1.load_data(str, str) == None


# Generated at 2022-06-25 05:43:24.579091
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Test the following operation
    #     playbook_include_0 = PlaybookInclude()
    #     str_0 = {}
    #     var_0 = playbook_include_0.load_data(str_0, str_0)
    playbook_include_0 = PlaybookInclude()
    str_0 = {}
    var_0 = playbook_include_0.load_data(str_0, str_0)


# Generated at 2022-06-25 05:43:52.460558
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    str_1 = {}
    var_1 = playbook_include_1.load_data(str_1, str_1)


# Generated at 2022-06-25 05:44:01.412743
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude()
    str_0 = {}
    str_1 = {}
    str_2 = {}
    str_3 = {}
    str_4 = {}
    var_0 = playbook_include_0.load_data(str_0, str_0, loader=str_1)
    var_1 = playbook_include_1.load_data(str_2, str_0)
    var_2 = playbook_include_1.load_data(str_3, str_0, variable_manager=str_4)


# Generated at 2022-06-25 05:44:04.970502
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-25 05:44:07.778825
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # create a playbook_include
    playbook_include = PlaybookInclude()
    # create a dict and try to load it
    dict = {}
    var = playbook_include.load_data(dict, dict)



# Generated at 2022-06-25 05:44:09.000132
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include = PlaybookInclude()
    assert playbook_include is not None


# Generated at 2022-06-25 05:44:12.764832
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    playbook_include_1.load_data(str, str)


# Generated at 2022-06-25 05:44:14.013824
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    test_case_0()



# Generated at 2022-06-25 05:44:20.337133
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    # Assert no error is raised
    playbook_include_0.load_data(str, str)
    # Assert no error is raised
    playbook_include_0.load_data(str, dict)
    # Assert no error is raised
    playbook_include_0.load_data(str, list)
