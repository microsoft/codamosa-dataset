

# Generated at 2022-06-25 05:34:46.360273
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_1 = PlaybookInclude()
    assert playbook_include_1.preprocess_data("action: ping") == {"action": "ping"}
    assert playbook_include_1.preprocess_data("action: ping\nimport_playbook: test.yml") == \
           {"action": "ping", "import_playbook": "test.yml"}
    # TODO: pylint: disable=unsubscriptable-object
    assert playbook_include_1.preprocess_data("import_playbook: test.yml\nother: True") == \
           {"import_playbook": "test.yml", "other": True}


# Generated at 2022-06-25 05:34:53.519908
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
  import os
  import tempfile
  import yaml


# Generated at 2022-06-25 05:35:03.246879
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Create new PlaybookInclude object for testing and set some defaults
    playbook_include = PlaybookInclude()
    playbook_include.import_playbook = 'baz.yml'
    playbook_include.tags = 'foo'
    playbook_include.vars = {'hello': 'world'}

    # Test1
    ds = {'import_playbook': 'dummy1.yml'}
    new_ds = playbook_include.preprocess_data(ds)
    assert type(new_ds) == AnsibleMapping
    assert new_ds == ds

    # Test2
    ds = {'import_playbook': 'dummy2.yml', 'tags': 'bar'}
    new_ds = playbook_include.preprocess_data(ds)
    assert type(new_ds) == Ansible

# Generated at 2022-06-25 05:35:14.300689
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()
    # Input data is of type AnsibleMapping
    ds = AnsibleMapping()
    ds["include"] = "include_0.yml"
    ds["tags"] = "tags_0"
    ds["vars"] = AnsibleMapping()
    playbook_include_1 = playbook_include_0.preprocess_data(ds=ds)

    # Input data is of type AnsibleMapping
    ds = AnsibleMapping()
    ds["import_playbook"] = "import_playbook_0.yml"
    ds["tags"] = "tags_1"
    ds["vars"] = AnsibleMapping()
    playbook_include_2 = playbook_include_0.preprocess_data(ds=ds)

# Unit test

# Generated at 2022-06-25 05:35:20.144551
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # obj, ds = [], AnsibleMapping()
    # PlaybookInclude.preprocess_data(obj, ds)

    playbook_include_1 = PlaybookInclude()
    ds = AnsibleMapping()
    assert playbook_include_1.preprocess_data(ds) == AnsibleMapping()



# Generated at 2022-06-25 05:35:28.209627
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Test the case that 'ds' is not a dict.
    #
    # Inputs:
    #   ds: the value of data to process
    #
    # Assertion:
    #   The exception AnsibleAssertionError is raised

    # Create the instance to test.
    obj = PlaybookInclude()

    # Try when 'ds' is not a dict.
    try:
        obj.preprocess_data(None)
    except AnsibleParserError as err:
        print("    AnsibleParserError generated as expected: %s" % err.message)
    except:
        print("    Oops. Unexpected exception generated")


# Generated at 2022-06-25 05:35:31.683958
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    """Unit test for method load_data of class PlaybookInclude"""
    # Initialize a new instance of class PlaybookInclude
    playbook_include_0 = PlaybookInclude()

# Generated at 2022-06-25 05:35:38.659356
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()
    ds = dict()
    ds['import_playbook'] = 'test_value'
    ds['vars'] = dict()
    ds['tags'] = 'test_value'
    new_ds = playbook_include_0.preprocess_data(ds)
    assert isinstance(new_ds, dict)
    assert new_ds['import_playbook'] == 'test_value'
    assert isinstance(new_ds['vars'], dict)
    assert new_ds['tags'] == 'test_value'


# Generated at 2022-06-25 05:35:48.503193
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    playbook_include_1 = PlaybookInclude()
    try:
        playbook_include_1.load_data()
        assert 0
    except Exception as e:
        assert isinstance(e, TypeError)

    playbook_include_2 = PlaybookInclude()
    try:
        playbook_include_2.load_data(ds=None, basedir=None)
        assert 0
    except Exception as e:
        assert isinstance(e, AnsibleAssertionError)

    playbook_include_3 = PlaybookInclude()
    try:
        playbook_include_3.load_data(ds=dict(), basedir=None)
        assert 0
    except Exception as e:
        assert isinstance(e, AnsibleAssertionError)

    playbook_include_4 = PlaybookInclude()

# Generated at 2022-06-25 05:35:57.125770
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    '''
    Test the preprocess_data() method of class PlaybookInclude

    PlaybookInclude.preprocess_data() should reformat the input data into a
    standard layout.
    '''

    from ansible.playbook.play import Play

    pbi1 = PlaybookInclude.load(dict(playbook='./play.yml'), './')
    assert isinstance(pbi1, PlaybookInclude)
    assert pbi1.import_playbook == './play.yml'

    pbi2 = PlaybookInclude.load(dict(playbook='play.yml'), './')
    assert isinstance(pbi2, PlaybookInclude)
    assert pbi2.import_playbook == 'play.yml'


# Generated at 2022-06-25 05:36:11.377781
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # In this case, we're going to return a new
    playbook_include_0 = PlaybookInclude()
    byte_0 = ','
    byte_1 = '?'
    byte_2 = 'a'
    byte_3 = 'g'
    byte_4 = '.'
    byte_5 = 'n'
    byte_6 = '.'
    byte_7 = '.'
    byte_8 = '.'
    byte_9 = '.'
    byte_10 = '.'
    byte_11 = '.'
    byte_12 = '.'
    byte_13 = '.'
    byte_14 = '.'
    byte_15 = '.'
    byte_16 = 'o'
    byte_17 = '6'
    byte_18 = '1'
    byte_19 = '.'

# Generated at 2022-06-25 05:36:21.564824
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()
    ds = {
        'import_playbook': 'ks',
        'a': 'A',
        'b': 'B',
    }
    expected_result = dict(
        b='B',
        import_playbook='ks',
        a='A',
    )

    assert playbook_include_0.preprocess_data(ds) == expected_result
    assert isinstance(playbook_include_0.preprocess_data(ds), dict)
    try:
        playbook_include_0.preprocess_data((1, 2))
    except Exception as e:
        assert isinstance(e, AnsibleAssertionError)
        assert str(e) == 'ds (1, 2) should be a dict but was a <class \'tuple\'>'

# Generated at 2022-06-25 05:36:32.893106
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Test playbook include with k=v parameters
    ds = AnsibleMapping()
    # insert new element into ds
    ds["key1"] = "value1"
    assert 'value1' == ds["key1"]
    new_ds = AnsibleMapping()
    # insert new element into new_ds
    new_ds["key1"] = "value1"
    assert 'value1' == new_ds["key1"]
    playbook_include_ds = PlaybookInclude()
    # execute the preprocess_data method of PlaybookInclude class
    playbook_include_ds._preprocess_import(ds, new_ds, "key1", "value1")
    # test the value of imported_playbook
    assert 'value1' == playbook_include_ds.import_playbook
    # test the value of new

# Generated at 2022-06-25 05:36:42.408864
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Setup
    playbook_include_0 = PlaybookInclude()
    playbook_include_0._import_playbook = 'v'
    playbook_include_0._validate_attributes = Mock()
    playbook_include_0.validate_attributes = Mock()
    playbook_include_0._validate_attributes.return_value = None
    playbook_include_0.validate_attributes.return_value = None
    var_0 = Mock()
    var_0.__getitem__.return_value = 'v'
    var_0.__setitem__.return_value = None

    # Test code
    playbook_include_0.preprocess_data(var_0)

    # Assertions
    playbook_include_0._validate_attributes.assert_called_with()
    playbook_include_0

# Generated at 2022-06-25 05:36:50.019721
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # make the ds in the format expected by the method
    ds = {} 
    basedir = 'mybasedir'
    variable_manager = None
    loader = None
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = playbook_include_0.load_data(ds, basedir, variable_manager, loader)
    assert_equal(playbook_include_1.__class__.__name__, 'Playbook') 


# Generated at 2022-06-25 05:36:51.016341
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    ansible_module = PlaybookInclude()
    assert ansible_module.load_data() == None


# Generated at 2022-06-25 05:36:55.380361
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    bytes_0 = b'\xc1\x91\x80MF\xd3(2\x17?`\xa6$\xa2\xb3\xafD'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.preprocess_data(bytes_0)

# Generated at 2022-06-25 05:36:59.396683
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping

    playbook_include_0 = PlaybookInclude()
    ansible_map_0 = AnsibleMapping()
    playbook_include_0.preprocess_data(ansible_map_0)


# Generated at 2022-06-25 05:37:06.337831
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Create a basic PlaybookInclude object
    ds0 = AnsibleMapping()
    ds0.append({'test_key_0': 'test_val_0', 'test_key_1': 'test_val_1'})

    playbook_include_0 = PlaybookInclude()
    playbook_include_0.load_data(ds0, 'ansible_0', 'variable_manager_0', 'loader_0')


# Generated at 2022-06-25 05:37:14.321957
# Unit test for method preprocess_data of class PlaybookInclude

# Generated at 2022-06-25 05:37:31.000696
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    bytes_0 = b'\xc1\x91\x80MF\xd3(2\x17?`\xa6$\xa2\xb3\xafD'
    str_0 = 'j'
    str_1 = '_'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(bytes_0, str_0, str_1)


# Generated at 2022-06-25 05:37:41.181332
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    bytes_0 = b'\xc1\x91\x80MF\xd3(2\x17?`\xa6$\xa2\xb3\xafD'
    str_0 = 'j'
    var_0 = playbook_include_1.load(bytes_0, str_0)

# Generated at 2022-06-25 05:37:48.293667
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    bytes_0 = b'\xc1\x91\x80MF\xd3(2\x17?`\xa6$\xa2\xb3\xafD'
    str_0 = '\xab'
    new_obj = PlaybookInclude()
    var_0 = new_obj.load_data(bytes_0, str_0)

# Generated at 2022-06-25 05:37:51.873423
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # TODO: implement
    return


# Generated at 2022-06-25 05:38:00.100032
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    bytes_0 = b'Z2=\xa3`\xb3\xb9\x9b\xcc\xa1\xcf'
    str_0 = 'w'
    str_1 = '9'
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.load_data(bytes_0, str_0, str_1)
    bytes_1 = b'|\x0c\xdf\xf4\x0e\x07\xdb\x1c\xbe\xbe\xbd\xbf\xb9\x01\xb55\x14\x99\x91\x04\x17\xec\xd3\x80\xc4\xeb\x0c'
    str_2 = 'Z'
    str_3 = 'i'
    playbook

# Generated at 2022-06-25 05:38:06.679486
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    bytes_0 = b'\xc1\x91\x80MF\xd3(2\x17?`\xa6$\xa2\xb3\xafD'
    str_0 = 'j'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load(bytes_0, str_0)


# Generated at 2022-06-25 05:38:16.939297
# Unit test for method preprocess_data of class PlaybookInclude

# Generated at 2022-06-25 05:38:21.858713
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = dict()
    dict_0['playbook'] = "playbook.yml"
    dict_0['vars'] = dict()
    dict_0['var'] = "var"
    dict_0['become'] = "True"
    dict_0['become_user'] = "myUser"
    playbook_include_1 = playbook_include_0.preprocess_data(dict_0)

# Generated at 2022-06-25 05:38:29.952622
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    bytes_0 = b'\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00'
    str_0 = '<path_to_playbook_file>'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(bytes_0, str_0)


# Generated at 2022-06-25 05:38:33.899923
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    str_0 = 'X'
    str_1 = '5'
    str_2 = '}'
    playbook_include_0.load_data(str_0, str_1, str_2)


# Generated at 2022-06-25 05:38:54.072331
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    ds = {'a': 'b'}
    basedir = '.'
    variable_manager = 'ansible/vars/manager'
    loader = 'ansible/parsing/yaml/loader'
    var_0 = playbook_include_0.load_data(ds, basedir, variable_manager, loader)


# Generated at 2022-06-25 05:38:57.820336
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    bytes_0 = b'\xc1\x91\x80MF\xd3(2\x17?`\xa6$\xa2\xb3\xafD'
    str_0 = 'j'
    new_ds = PlaybookInclude.preprocess_data(bytes_0, str_0)
    assert new_ds == {}


# Generated at 2022-06-25 05:39:00.773970
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    bytes_0 = b'\xc1\x91\x80MF\xd3(2\x17?`\xa6$\xa2\xb3\xafD'
    str_0 = 'j'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(bytes_0, str_0)


# Generated at 2022-06-25 05:39:11.680141
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = AnsibleMapping()
    var_0['when'] = []
    var_0['vars'] = {}
    var_0['import_playbook'] = 'tasks/main.yml'
    var_0['tags'] = []
    var_1 = playbook_include_0.load_data(var_0, '', None)
    print(var_1.get_name())
    print(var_1.get_variable_manager())
    print(var_1.get_loader())
    print(var_1.get_hosts())
    print(var_1.get_basedir())
    print(var_1.get_roles_path())
    print(var_1.get_tasks())

# Generated at 2022-06-25 05:39:15.630738
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    ds = {}
    basedir = 'j'
    playbook_include_1 = playbook_include_0.load_data(ds, basedir)


# Generated at 2022-06-25 05:39:23.812999
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    bytes_0 = b'\xb7\x81@\x80\xf6\x0c\x8e\x91\x9b)<\xba\x8b\xd6\x80\xdc\xdc\xc8\x93\xb3q\xbb\xca\x8a\x0f\x00\xd5\x90]\x1e'
    str_0 = 'x'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(bytes_0, str_0)


# Generated at 2022-06-25 05:39:27.843182
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    bytes_0 = b'\xc1\x91\x80MF\xd3(2\x17?`\xa6$\xa2\xb3\xafD'
    str_0 = 'j'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load()


# Generated at 2022-06-25 05:39:30.573494
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    assert playbook_include_0.load_data('abc', 'cde') == None
    assert playbook_include_0.load_data('cde', 'abc') == None


# Generated at 2022-06-25 05:39:39.163344
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    bytes_0 = b'\xc1\x91\x80MF\xd3(2\x17?`\xa6$\xa2\xb3\xafD'
    str_1 = 'k'
    PlaybookInclude_0 = PlaybookInclude()
    PlaybookInclude_0.load_data(bytes_0, str_1)


# Generated at 2022-06-25 05:39:45.332833
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = 'N,\x9a'
    str_1 = 'Y\x1f\xa1\x04\x8f'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(str_0, str_1)
    assert var_0 is None


# Generated at 2022-06-25 05:40:05.319115
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(ds="", basedir="", variable_manager="", loader="")


# Generated at 2022-06-25 05:40:16.227460
# Unit test for method load_data of class PlaybookInclude

# Generated at 2022-06-25 05:40:20.242226
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    data = {'vars': {'var': 'value', 'tags': 'tag1,tag2,tag3'}, 'import_playbook': 'playbook.play'}
    basedir = "."
    variable_manager = None
    loader = None
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(data, basedir, variable_manager, loader)


# Generated at 2022-06-25 05:40:31.016951
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    bytes_0 = b'\x10\x88\xe9{\x9c\x8a\x01\x11\x90?\xfa\x96\xab\xba\xe4\xef\xcc\x0c\x0c'
    str_0 = '0x'
    template_0 = '\x02'
    dict_0 = dict()
    dict_1 = dict()
    dict_1['import_playbook'] = 'X'
    dict_0[template_0] = dict_1
    dict_2 = dict()
    dict_2[template_0] = dict_1
    dict_3 = dict()
    dict_3['vars'] = dict_2
    dict_3['import_playbook'] = 'X'
    dict_0['0x'] = dict

# Generated at 2022-06-25 05:40:42.815198
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    bytes_0 = b'V\x9c\xa4\xe2\x87\xd7\x1d\x0f\x13\x81\x0f\t\xef\x18\xb0\x1b\xde;\x02\x01\x11\x1f?\x89\xfb\xd1\x0e\x16\xc5\xcf'
    str_0 = 'B'
    basedir_0 = 'e'
    playbook_include_0 = PlaybookInclude()
    playbook_1 = playbook_include_0.load_data(bytes_0, basedir_0)
    str_1 = playbook_1.get_host_variables('g')
    str_2 = 'k'
    assert str_1 == str_2


# Generated at 2022-06-25 05:40:46.530888
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    data = {'foo': 'bar'}
    basedir = '.'
    variable_manager = '.'
    loader = '.'
    playbook_include_1 = PlaybookInclude()
    var_1 = playbook_include_1.load_data(data, basedir, variable_manager, loader)


# Generated at 2022-06-25 05:40:51.909647
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Tests exception being thrown
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude()
    bytes_0 = b'\xc1\x91\x80MF\xd3(2\x17?`\xa6$\xa2\xb3\xafD'
    str_0 = 'j'
    # Tests exception being thrown
    try:
        playbook_include_1.load_data(bytes_0, str_0)
    except Exception as e:
        print("Caught exception: %s" % e)


# Generated at 2022-06-25 05:40:55.540058
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    bytes_0 = b'\xc1\x91\x80MF\xd3(2\x17?`\xa6$\xa2\xb3\xafD'
    str_0 = 'j'
    ds_0 = dict()
    obj_0 = PlaybookInclude()
    var_0 = obj_0.load_data(ds_0, str_0)


# Generated at 2022-06-25 05:41:01.270032
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    bytes_0 = b'\xc1\x91\x80MF\xd3(2\x17?`\xa6$\xa2\xb3\xafD'
    str_0 = 'j'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load(bytes_0, str_0)


# Generated at 2022-06-25 05:41:09.006925
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include = PlaybookInclude()
    data = {
        'import_playbook': 'book.yml',
        'vars': {
            'var1': 'value1',
            'var2': 'value2'
        }
    }
    new_data = playbook_include.preprocess_data(data)

    assert new_data['import_playbook'] == 'book.yml'
    assert new_data['vars'] == {'var1': 'value1', 'var2': 'value2'}


# Generated at 2022-06-25 05:42:08.425586
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    bytes_0 = b'\xc1\x91\x80MF\xd3(2\x17?`\xa6$\xa2\xb3\xafD'
    str_0 = 'j'
    dict_0 = dict()
    dict_0['A'] = 'A'
    dict_0['B'] = 'B'
    dict_0['C'] = 'C'
    dict_0['D'] = 'D'
    dict_0['E'] = 'E'
    dict_0['F'] = 'F'
    dict_0['G'] = 'G'
    dict_0['H'] = 'H'
    dict_0['I'] = 'I'
    dict_0['J'] = 'J'
    dict_0['K'] = 'K'
    dict_0['L']

# Generated at 2022-06-25 05:42:09.362682
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-25 05:42:13.990010
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data('test', 'test')


# Generated at 2022-06-25 05:42:20.782455
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    bytes_0 = b'\xc1\x91\x80MF\xd3(2\x17?`\xa6$\xa2\xb3\xafD'
    str_0 = 'j'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(bytes_0, str_0)

# Generated at 2022-06-25 05:42:25.404990
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    load_data_result = PlaybookInclude.load_data(self, ds, basedir, variable_manager, loader)


# Generated at 2022-06-25 05:42:31.214497
# Unit test for method load_data of class PlaybookInclude

# Generated at 2022-06-25 05:42:36.044004
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    bytes_0 = b'\xc1\x91\x80MF\xd3(2\x17?`\xa6$\xa2\xb3\xafD'
    str_0 = 'j'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load(bytes_0, str_0)


# Generated at 2022-06-25 05:42:46.415744
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Test template_data is dict
    playbook_include_0 = PlaybookInclude()

# Generated at 2022-06-25 05:42:48.826678
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    playbook_include_1 = PlaybookInclude()
    playbook_include_2 = PlaybookInclude()
    var_1 = playbook_include_1.load_data(var_0, str_0, playbook_include_2)

# Generated at 2022-06-25 05:42:54.624115
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    bytes_0 = b'\xc1\x91\x80MF\xd3(2\x17?`\xa6$\xa2\xb3\xafD'
    str_0 = 'j'
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.load_data(bytes_0, str_0)


# Generated at 2022-06-25 05:44:00.385440
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-25 05:44:05.357065
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    bytes_0 = b'\xc1\x91\x80MF\xd3(2\x17?`\xa6$\xa2\xb3\xafD'
    str_0 = ''
    variable_manager_0 = VariableManager()
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(bytes_0, str_0, variable_manager_0)



# Generated at 2022-06-25 05:44:08.060433
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    try:
        playbook_include_0.load_data(ds, basedir, variable_manager, loader)
    except:
        playbook_include_0.exception()



# Generated at 2022-06-25 05:44:11.860163
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    bytes_0 = b'\xe3\x1f\xb3\xcd\x8c\x88/\xd2j\x80\x1f\xe9\xbb\xbc\xae'
    str_0 = 'r'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(bytes_0, str_0)


# Generated at 2022-06-25 05:44:16.008606
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    bytes_0 = b'\xc1\x91\x80MF\xd3(2\x17?`\xa6$\xa2\xb3\xafD'
    str_0 = 'z'
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.load_data(bytes_0, str_0)


# Generated at 2022-06-25 05:44:19.492987
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    bytes_0 = b'\xc1\x91\x80MF\xd3(2\x17?`\xa6$\xa2\xb3\xafD'
    str_0 = 'j'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(bytes_0, str_0)
    assert type(var_0) is Playbook
