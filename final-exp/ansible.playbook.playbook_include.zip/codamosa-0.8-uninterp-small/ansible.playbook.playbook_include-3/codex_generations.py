

# Generated at 2022-06-25 05:34:43.567892
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    '''
    Test whether we can use the preprocess_data of playbook include class
    '''

    # The data structure we'll use to test the preprocess_data() method
    testdata0 = {
        'import_playbook': '../common/tasks.yml',
        'vars': {'foo': 'bar'},
    }
    # Test the preprocess data using the data structure above
    pbi = PlaybookInclude()
    data = pbi.preprocess_data(testdata0)

    # Compare the keys and values of the result data structure with our expectations
    assert data.keys() == testdata0.keys()
    assert data.get('import_playbook') == testdata0.get('import_playbook')
    assert data.get('vars') == testdata0.get('vars')


#

# Generated at 2022-06-25 05:34:46.953077
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include = PlaybookInclude()
    playbook_include.load_data('test.yml')


# Generated at 2022-06-25 05:34:51.728462
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()

    data = {'import_playbook': 'bob.yml'}
    assert playbook_include_0.preprocess_data(data) == {'import_playbook': 'bob.yml'}

# Generated at 2022-06-25 05:35:03.056383
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()

    ds_1 = {'import_playbook' : 'test-1.yaml'}
    basedir_1 = str()
    variable_manager_1 = None
    loader_1 = None

    playbook_include_2 = PlaybookInclude()

    ds_2 = {'import_playbook' : 'test-2.yaml'}
    basedir_2 = str()
    variable_manager_2 = None
    loader_2 = None

    playbook_include_3 = PlaybookInclude()

    ds_3 = {'import_playbook' : 'test-3.yaml'}
    basedir_3 = str()
    variable_manager_3 = None
    loader_3 = None

    playbook_include_4 = PlaybookInclude()



# Generated at 2022-06-25 05:35:05.818554
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include = PlaybookInclude()

    # load_data with wrong type of data should return None
    assert playbook_include.load_data("string", "string") is None

# Generated at 2022-06-25 05:35:17.096132
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # test_case_0
    # test correct handling of playbook-like include vars
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.load_data(dict(
        import_playbook = 'foo.yml',
        vars = dict(
            x = 'x.x',
            y = 'y.y',
            z = 'z.z',
            tags = 'a,b,c'
        )
    ))
    assert playbook_include_0.import_playbook == 'foo.yml'
    assert playbook_include_0.vars['x'] == 'x.x'
    assert playbook_include_0.tags == ['a', 'b', 'c']

    # test_case_1
    # test correct handling of legacy playbook-like include vars
    playbook_include_

# Generated at 2022-06-25 05:35:20.541332
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    playbook_include = PlaybookInclude()
    playbook_include.load_data(ds={'import_playbook': '/home/vagrant/demo/common.yml'}, basedir='/home/vagrant/demo')



# Generated at 2022-06-25 05:35:23.797194
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()


# Generated at 2022-06-25 05:35:28.562699
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    #print(playbook_include_0.load_data(ds={'import_playbook': './test.yml', 'vars': {'var_name_0': 'var_value_0'}}))



# Generated at 2022-06-25 05:35:36.944752
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()

    with pytest.raises(Exception) as excinfo:
        playbook_include_1.load_data(ds={}, basedir={}, variable_manager={}, loader={})
    assert 'ds (None) should be a dict but was a NoneType' in str(excinfo.value)

    with pytest.raises(Exception) as excinfo:
        playbook_include_1.load_data(ds={}, basedir={}, variable_manager={}, loader={})
    assert 'you must provide the loader argument to load_data() with playbook_include objects' in str(excinfo.value)


# Generated at 2022-06-25 05:35:43.496700
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()



# Generated at 2022-06-25 05:35:53.693486
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_1 = PlaybookInclude()
    assert playbook_include_1.preprocess_data(ds={'import_playbook': 'some_play'}) == {'import_playbook': 'some_play'}
    playbook_include_2 = PlaybookInclude()
    # TODO: move assert to playbook_include_2.preprocess_data(ds={'import_playbook': 'some_play', 'vars': {'var1': 'val1'}}, var1='val1') == {'import_playbook': 'some_play', 'vars': {'var1': 'val1'}}
    playbook_include_3 = PlaybookInclude()

# Generated at 2022-06-25 05:36:03.336991
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Setting up a playbook_include_0 playbook_include_0
    playbook_include_0 = PlaybookInclude()
    playbook_include_0_ds = {'import_playbook': 'example-playbook.yml', 'tags': 'tag1, tag2', 'vars': {'greeting': 'hello', 'subject': 'world'}, 'when': 'greeting == "hello"'}
    playbook_include_0_expected_result = {'import_playbook': 'example-playbook.yml', 'tags': 'tag1, tag2', 'vars': {'greeting': 'hello', 'subject': 'world'}, 'when': 'greeting == "hello"'}
    playbook_include_0_actual_result = playbook_include_0.preprocess_data(playbook_include_0_ds)


# Generated at 2022-06-25 05:36:08.088302
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    ds = dict()
    ds["playbook_include"] = "playbook.yml"
    basedir = "PlaybookGroups.test_PlaybookInclude_load_data"
    variable_manager_0 = None
    playbook_include_0.load_data(ds, basedir, variable_manager_0, loader=None)


# Generated at 2022-06-25 05:36:10.950046
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.load_data({"import_playbook": "ansible/test_playbook.yaml"})


# Generated at 2022-06-25 05:36:13.241769
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pb = PlaybookInclude.load_data(ds='test: test', basedir='tests/playbooks')
    module = pb.load()
    assert module is not None

# Generated at 2022-06-25 05:36:21.789829
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()

# Generated at 2022-06-25 05:36:26.202933
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()

    pass

# Generated at 2022-06-25 05:36:33.594363
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    data = {}
    basedir = ''
    variable_manager = None
    loader = None

# Generated at 2022-06-25 05:36:40.622396
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude()
    playbook_include_load_data_0 = playbook_include_1.load_data(ds=playbook_include_0, basedir=playbook_include_0, variable_manager=playbook_include_0, loader=playbook_include_0)
    assert playbook_include_load_data_0 == playbook_include_1, "Expected:<{}>, Actual:<{}>".format(playbook_include_0, playbook_include_1)



# Generated at 2022-06-25 05:36:46.002686
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-25 05:36:48.617206
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    assert playbook_include_1.load_data(ds=dict(), basedir='/ansible/test/data/inventory') is not None


# Generated at 2022-06-25 05:36:52.012270
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    yaml_data = ["---\n", "import_playbook: playbook.yml\n"]
    pass


# Generated at 2022-06-25 05:36:53.280034
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    test_case_0()

# Generated at 2022-06-25 05:37:00.384691
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude()

    # pylint: disable=E1101
    assert playbook_include_0.preprocess_data({'import_playbook': 'test_playbook.yaml'}) == {'import_playbook': 'test_playbook.yaml'}
    assert playbook_include_1.preprocess_data({'import_playbook': 'test_playbook.yaml'}) == {'import_playbook': 'test_playbook.yaml'}

# Generated at 2022-06-25 05:37:05.333239
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    rval = playbook_include_0.load_data(ds=None, basedir='/usr/lib/python3.6/site-packages/ansible/modules/system', variable_manager=None, loader=None)


# Generated at 2022-06-25 05:37:06.260340
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    assert PlaybookInclude.load({}) is not None

# Generated at 2022-06-25 05:37:09.359435
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Initialize the variables
    playbook_include_1 = PlaybookInclude()

    # Test the PlaybookInclude class load_data method
    try:
        playbook_include_1.load_data()
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-25 05:37:11.712557
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    a = PlaybookInclude()
    ds = dict(
        import_playbook='test.yml',
        when='a=b'
    )
    a.load_data(ds, '.')

# Generated at 2022-06-25 05:37:16.276262
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.load_data()
    playbook_include_0.load_data(ds=None)
    playbook_include_0.load_data(ds=None, basedir=None, variable_manager=None, loader=None)
    playbook_include_0.ds
    playbook_include_0.basedir
    playbook_include_0.variable_manager
    playbook_include_0.loader


# Generated at 2022-06-25 05:37:25.693707
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = ' takes a list of patterns and reorders them by modifier to apply them consistently '
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.load(str_0, str_0)
    var_0 = playbook_include_0.load_data(None, ' takes a list of patterns and reorders them by modifier to apply them consistently ')
    assert playbook_include_0 is not None


# Generated at 2022-06-25 05:37:31.797867
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    ds = ' takes a list of patterns and reorders them by modifier to apply them consistently '
    basedir = ' takes a list of patterns and reorders them by modifier to apply them consistently '
    variable_manager = ' takes a list of patterns and reorders them by modifier to apply them consistently '
    loader = ' takes a list of patterns and reorders them by modifier to apply them consistently '

    # Test for correct return type
    p = PlaybookInclude()
    ret = p.load_data(ds, basedir, variable_manager, loader)
    assert type(ret).__name__ == 'Playbook'
    assert repr(ret)


# Generated at 2022-06-25 05:37:41.943019
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # test for string_types
    str_0 = ' takes a list of patterns and reorders them by modifier to apply them consistently '
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.load_data(
        str_0,
        str_0
    )

    # test for Conditional
    str_0 = ' takes a list of patterns and reorders them by modifier to apply them consistently '
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.load_data(
        str_0,
        str_0
    )

    # test for Taggable
    str_0 = ' takes a list of patterns and reorders them by modifier to apply them consistently '
    playbook_include_0 = PlaybookInclude()

# Generated at 2022-06-25 05:37:47.804626
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_1 = ' arguments should be a list of patterns '
    playbook_include_1 = PlaybookInclude()
    var_1 = playbook_include_1.load(str_1, str_1)



# Generated at 2022-06-25 05:37:50.504767
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    pass

# Generated at 2022-06-25 05:37:53.025170
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    str_0 = 'hostname'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.preprocess_data(str_0)
    assert playbook_include_0 == var_0


# Generated at 2022-06-25 05:38:00.368436
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    str_0 = ' takes a list of patterns and reorders them by modifier to apply them consistently '
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load(str_0, str_0)
    var_1 = playbook_include_0.preprocess_data(str_0)
    var_1 = playbook_include_0.preprocess_data(str_0)


# Generated at 2022-06-25 05:38:05.161102
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    var_3 = 'Hi, this is an impact with a newline on the end\n'
    var_4 = True
    var_5 = False
    var_6 = True
    var_7 = False
    var_8 = 'one two three four\n'
    var_9 = 'one two three four\n'
    # Load a dict of values
    var_1 = playbook_include_1.load_data({'impact': var_3}, {'impact': var_3})
    # Load a string
    var_2 = playbook_include_1.load_data(var_8, var_9)
    # Load a tuple of dicts

# Generated at 2022-06-25 05:38:06.323601
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-25 05:38:10.663847
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = ' takes a list of patterns and reorders them by modifier to apply them consistently '
    PlaybookInclude_0 = PlaybookInclude()
    PlaybookInclude_0.load_data(str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 05:38:17.398125
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    str_0 = ' takes a list of patterns and reorders them by modifier to apply them consistently '
    idea_0 = PlaybookInclude()
    var_0 = idea_0.preprocess_data(str_0)


# Generated at 2022-06-25 05:38:20.262893
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = ' empty playbooks result in nothing being executed. '
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.load_data(str_0, 'empty playbooks result in nothing being executed.')


# Generated at 2022-06-25 05:38:32.962245
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    print('Testing test_PlaybookInclude_preprocess_data')

    #  (self, ds):
    obj_str = '''
      - hosts: foo
        tasks:
        - debug: msg="Hello World"
    '''
    obj = PlaybookInclude.load(obj_str, './')
    obj.preprocess_data(obj_str)

    # should not cause error
    obj_str = '''
      - hosts: foo
        tasks:
        - debug: msg="Hello World"
        vars:
            foo: bar
    '''
    obj = PlaybookInclude.load(obj_str, './')
    obj.preprocess_data(obj_str)

    # should throw error

# Generated at 2022-06-25 05:38:38.950270
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = '     vars   :  -  var1    '
    str_1 = '                -  var2    '
    str_2 = '    tags    :   tags=value   '
    templar_1 = Templar(loader=loader, variables=all_vars)
    file_name = templar_1.template(new_obj.import_playbook)
    assert file_name.strip() == str_0.strip()


# Generated at 2022-06-25 05:38:48.744105
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = 'gives a list of patterns and reorders them by modifiers to apply them consistently '
    str_1 = 'gives a list of patterns and reorders them by modifiers to apply them consistently '
    str_2 = 'gives a list of patterns and reorders them by modifiers to apply them consistently '
    str_3 = 'gives a list of patterns and reorders them by modifiers to apply them consistently '
    str_4 = 'gives a list of patterns and reorders them by modifiers to apply them consistently '
    str_5 = 'gives a list of patterns and reorders them by modifiers to apply them consistently '
    str_6 = 'gives a list of patterns and reorders them by modifiers to apply them consistently '
    str_7 = 'gives a list of patterns and reorders them by modifiers to apply them consistently '

# Generated at 2022-06-25 05:38:54.437752
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    str_0 = ' takes a list of patterns and reorders them by modifier to apply them consistently '
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load(str_0, str_0)
    var_1 = playbook_include_0.preprocess_data(str_0)


# Generated at 2022-06-25 05:39:00.645085
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # For example, from ansible.errors import AnsibleParserError, AnsibleAssertionError
    assert True

    # For example, from ansible.playbook import Playbook
    assert True

    # For example, from ansible.playbook.play import Play
    assert True

    # For example, from ansible.template import Templar
    assert True

    # For example, from ansible.utils.display import Display
    assert True

    # For example, from ansible.module_utils.six import iteritems, string_types
    assert True

    # For example, def load(data, basedir, variable_manager=None, loader=None):
    assert True

    # For example, def preprocess_data(self, ds):
    assert True


# Generated at 2022-06-25 05:39:11.582364
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    ansible_path = AnsibleCollectionConfig.ansible_path
    AnsibleCollectionConfig.ansible_path = "/Users/vivianli/ansible/lib/ansible"
    str_1 = 'takes a list of patterns and reorders them by module to apply them consistently'
    str_2 = 'takes a list of patterns and reorders them by module to apply them consistently'
    str_3 = 'takes a list of patterns and reorders them by module to apply them consistently'
    playbook_include_1 = PlaybookInclude()
    var_1 = playbook_include_1.load(str_1, str_1)
    var_2 = playbook_include_1.load(str_2, str_1)
    var_3 = playbook_include_1.load(str_3, str_1)
    # Restore the

# Generated at 2022-06-25 05:39:16.204121
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = ' takes a list of patterns and reorders them by modifier to apply them consistently '
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load(str_0, str_0)


# Generated at 2022-06-25 05:39:20.872563
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    str_0 = ' takes a list of patterns and reorders them by modifier to apply them consistently '
    var_0 = playbook_include_0.load_data(str_0, str_0)



# Generated at 2022-06-25 05:39:39.830647
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    str_0 = ' takes a list of patterns and reorders them by modifier to apply them consistently '
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load(str_0, str_0)
    var_1 = playbook_include_0.preprocess_data(str_0)
    assert var_1 == str_0, 'PlaybookInclude.preprocess_data() returned unexpected value'



# Generated at 2022-06-25 05:39:41.908855
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    playbook_include_1.load_data('foo')


# Generated at 2022-06-25 05:39:49.362403
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    ds = ' takes a list of patterns and reorders them by modifier to apply them consi'
    basedir = 'When a collection is specified in a playbook, all of the'
    variable_manager = 'tently '
    loader = ' takes a list of patterns and reorders them by modifier to apply them consistently '
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(ds, basedir, variable_manager, loader)
    assert var_0 is not None


# Generated at 2022-06-25 05:39:55.875026
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    data_0 = '''{ _action: "export", _plugin: "db_export", _include: 1, _line: 10, _args: "file=*.sql", user: "user", password: "password", destination: "out.sql" }'''
    templar_0 = Templar('', '', '')
    ds_0 = PlaybookInclude.load(data_0, templar_0)


# Generated at 2022-06-25 05:39:58.979399
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    str_0 = ' takes a list of patterns and reorders them by modifier to apply them consistently '
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.preprocess_data(str_0)


# Generated at 2022-06-25 05:40:02.699188
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    str_0 = ' takes a list of patterns and reorders them by modifier to apply them consistently '
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load(str_0, str_0)
    playbook_include_0.preprocess_data(str_0)



# Generated at 2022-06-25 05:40:08.107706
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    setattr(playbook_include_0, 'import_playbook', 'devnull')
    str_0 = '/etc/*.conf'
    ds = {}
    templar = Templar(loader=None, variables={})
    boolean = playbook_include_0.load_data(ds, str_0)


# Generated at 2022-06-25 05:40:15.859327
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os
    import tempfile

    try:
        # Create a new temporary directory
        tmpdir = tempfile.mkdtemp()

        # Create a new PlaybookInclude object
        playbook_include_0 = PlaybookInclude()
        str_0 = ' takes a list of patterns and reorders them by modifier to apply them consistently '
        # Call method load_data of playbook_include_0
        playbook_include_0.load_data(str_0, str_0)

        # Delete the directory after the method call
        os.rmdir(tmpdir)
    except OSError as e:
        print("Error: %s - %s." % (e.filename, e.strerror))



# Generated at 2022-06-25 05:40:21.116531
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = ' takes a list of patterns and reorders them by modifier to apply them consistently '
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(str_0, str_0)


# Generated at 2022-06-25 05:40:22.078354
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # TODO: implement proper test
    assert False


# Generated at 2022-06-25 05:40:47.351105
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = ' takes a list of patterns and reorders them by modifier to apply them consistently '
    playbook_include_0 = PlaybookInclude()
    var_1 = playbook_include_0.load_data(str_0, str_0)


# Generated at 2022-06-25 05:40:51.298286
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = ' takes a list of patterns and reorders them by modifier to apply them consistently '
    str_1 = ' is used to change the value of a variable for a single play when the play is run. '
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load(str_0, str_1)
    var_0.preprocess_data(str_1)

# Generated at 2022-06-25 05:40:56.197999
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # This test is incomplete. Please add more below.
    str_0 = ' takes a list of patterns and reorders them by modifier to apply them consistently '
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load(str_0, str_0)


# Generated at 2022-06-25 05:41:00.444743
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = ' takes a list of patterns and reorders them by modifier to apply them consistently '
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(str_0, str_0)


# Generated at 2022-06-25 05:41:01.332558
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    test_case_0()

# Generated at 2022-06-25 05:41:03.582435
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.load_data('line', None, True)


# Generated at 2022-06-25 05:41:06.177684
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = ' takes a list of patterns and reorders them by modifier to apply them consistently '
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load(str_0, str_0)


# Generated at 2022-06-25 05:41:08.081721
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = ' takes a list of patterns and reorders them by modifier to apply them consistently '
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.load_data(str_0, str_0)


# Generated at 2022-06-25 05:41:13.891712
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    str_0 = ' takes a list of patterns and reorders them by modifier to apply them consistently '
    playbook_include_0 = PlaybookInclude()

    # Test with illegal param type
    try:
        playbook_include_0.preprocess_data(str_0)
    except Exception as err:
        assert type(err) == Exception
    # Test with illegal param type
    try:
        playbook_include_0.preprocess_data(str_0)
    except Exception as err:
        assert type(err) == Exception
    # Test with illegal param type
    try:
        playbook_include_0.preprocess_data(str_0)
    except Exception as err:
        assert type(err) == Exception
    # Test with illegal param type

# Generated at 2022-06-25 05:41:20.401625
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    ds = dict()
    basedir = 'a'
    variable_manager = dict()
    loader = dict()

    # Will raise an exception
    playbook_include_0 = PlaybookInclude()
    try:
        playbook_include_0.load_data(ds, basedir, variable_manager, loader)
    except:
        pass


# Generated at 2022-06-25 05:42:13.435190
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = ' takes a list of patterns and reorders them by modifier to apply them consistently '
    basedir_0 = str_0
    variable_manager = None
    loader = None
    playbook_include_0 = PlaybookInclude()
    # Call method
    playbook_include_0.load_data(str_0, basedir_0, variable_manager, loader)
    # Test False condition
    str_1 = ' takes a list of patterns and reorders them by modifier to apply them consistently '
    basedir_1 = str_1
    variable_manager = None
    loader = None
    playbook_include_1 = PlaybookInclude()
    # Call method
    playbook_include_1.load_data(str_1, basedir_1, variable_manager, loader)


# Generated at 2022-06-25 05:42:15.947151
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = ' takes a list of patterns and reorders them by modifier to apply them consistently '
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(str_0, str_0)


# Generated at 2022-06-25 05:42:18.947015
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    str_0 = ' takes a list of patterns and reorders them by modifier to apply them consistently '
    str_1 = ' takes a list of patterns and reorders them by modifier to apply them consistently '
    var_0 = playbook_include_0.load(str_0, str_1)


# Generated at 2022-06-25 05:42:26.843374
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = ' takes a list of patterns and reorders them by modifier to apply them consistently '
    ds_0 = '/home/omn/nocount/nocount/settings.py'
    basedir_0 = '/home/omn/nocount/nocount/settings.py'
    variable_manager_0 = ansible.playbook.variable_manager.VariableManager()
    loader_0 = '/home/omn/nocount/nocount/settings.py'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(ds_0, basedir_0, variable_manager_0, loader_0)


# Generated at 2022-06-25 05:42:38.630540
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
  import sys

  import unittest

  try:
    from unittest.mock import patch
  except ImportError:
    from mock import patch

  from ansible.errors import AnsibleParserError, AnsibleAssertionError, AnsibleCollectionConfigError
  from ansible.playbook import Playbook
  from ansible.playbook.play import Play
  from ansible.playbook.task import Task
  from ansible.parsing.dataloader import DataLoader
  from ansible.template import Templar
  from ansible.vars.manager import VariableManager
  from ansible.vars.unsafe_proxy import UnsafeProxy

  # python27 has no context manager support for files
  if sys.version_info[:2] == (2,7):
    from contextlib import nested

# Generated at 2022-06-25 05:42:43.111160
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    args_0 = {"import_playbook": "a", "vars": {}}
    str_0 = " takes a list of patterns and reorders them by modifier to apply them consistently "
    ret_0 = PlaybookInclude().load_data(args_0, str_0)
    assert ret_0 is not None


# Generated at 2022-06-25 05:42:46.201257
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    str_0 = ' takes a list of patterns and reorders them by modifier to apply them consistently '
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(str_0, str_0)


# Generated at 2022-06-25 05:42:48.608999
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    str_0 = string_types()
    str_1 = string_types()
    result = playbook_include_0.load_data(str_0, str_1)
    return result


# Generated at 2022-06-25 05:42:55.173882
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    file_path_1 = 'dir/dir/dir'
    var_0 = playbook_include_1.load_data(file_path_1, file_path_1)
    file_path_2 = 'dir/dir/dir'
    var_1 = playbook_include_1.load_data(file_path_2, file_path_2)


# Generated at 2022-06-25 05:42:57.212207
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.load_data(str_0, str_0, str_0)
