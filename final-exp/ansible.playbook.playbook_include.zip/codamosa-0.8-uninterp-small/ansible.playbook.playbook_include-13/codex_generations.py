

# Generated at 2022-06-25 05:34:43.156047
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    # AssertionError
    try:
        playbook_include_1.load_data(ds=None, basedir=None, variable_manager=None, loader=None)
    except AssertionError as e:
        print('AssertionError:', e)
        assert type(e) == AnsibleAssertionError
    # Exception
    try:
        playbook_include_1.load_data(ds={'_param': '__mapper__'}, basedir=None, variable_manager=None, loader=None)
    except Exception as e:
        print('Exception:', e)
        assert isinstance(e, AnsibleParserError)
        assert str(e) == "playbook import parameter is missing"

# Generated at 2022-06-25 05:34:49.988310
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.utils.display import Display
    Display.verbosity = 3


    # (1) ##################################################
    # TEST 1:
    #     ds = {'k0': 'v0'}
    # EXPECTED RESULT:
    #     new_ds = {'k0': 'v0'}

    display.display("\n# (1) ##################################################", screen_only=True)
    display.display("# TEST 1", screen_only=True)
    ds = {'k0': 'v0'}
    pbi = PlaybookInclude()
    new_ds = pbi.preprocess_data(ds)
    assert 'k0' in new_ds
    assert new_ds['k0'] == 'v0'


    # (2) ##################################################
    #

# Generated at 2022-06-25 05:34:52.348707
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.load_data({'import_playbook': 'test_playbook.txt'}, '.')


# Generated at 2022-06-25 05:34:57.882717
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude()
    playbook_include_2 = PlaybookInclude()
    playbook_include_3 = PlaybookInclude()


# Generated at 2022-06-25 05:35:07.796929
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Case 0: Fails
    playbook_include_0 = PlaybookInclude()
    # ds is expected to be a dict
    ds_0 = 'ds_0'
    try:
        playbook_include_0.preprocess_data(ds_0)
    except AnsibleAssertionError:
        pass
    else:
        raise AnsibleAssertionError('PlaybookInclude._preprocess_data(ds_0) did not fail as expected')

    # Case 1:
    playbook_include_1 = PlaybookInclude()
    # ds is expected to be a dict
    ds_1 = {}
    # Expected result: {}
    results_1 = playbook_include_1.preprocess_data(ds_1)
    assert results_1 == {}

    # Case 2:
    playbook_include_2

# Generated at 2022-06-25 05:35:12.998703
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    # Unit test for load_data of class PlaybookInclude
    playbook_include_1.load_data(ds=None, basedir="/home/centos/playbooks", variable_manager=None, loader=None)


# Generated at 2022-06-25 05:35:14.910738
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.load_data()


# Generated at 2022-06-25 05:35:26.285727
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_1 = PlaybookInclude()
    ds = {
        'import_playbook': '/path/to/playbook',
        'vars': {'first': True},
        'tags': 'tag1,tag2',
        'when': 'item.value == 1',
    }
    playbook_include_1.preprocess_data(ds) # expected to work
    playbook_include_2 = PlaybookInclude()
    ds = {
        'import_playbook': '/path/to/playbook',
        'vars': {'first': True},
    }
    playbook_include_2.preprocess_data(ds) # expected to work
    playbook_include_3 = PlaybookInclude()

# Generated at 2022-06-25 05:35:31.127738
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()
    result = playbook_include_0.preprocess_data(ds={})
    assert(result == {})


# Generated at 2022-06-25 05:35:35.996465
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include = PlaybookInclude()
    assert playbook_include.preprocess_data({'import_playbook': 'foo.yml', 'tags': 'bar'}) == {'import_playbook': 'foo.yml', 'tags': ['bar']}
    assert playbook_include.preprocess_data({'import_playbook': 'foo.yml', 'vars': {'foo': 'bar', 'x': 1}}) == {'import_playbook': 'foo.yml', 'vars': {'foo': 'bar', 'x': 1}}

# Generated at 2022-06-25 05:35:49.169951
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()
    # This ds should not throw the error, but will on a refactor.
    ds = {"import_playbook": "/path/to/file"}
    new_ds = playbook_include_0.preprocess_data(ds)
    assert isinstance(new_ds, dict)
    assert new_ds.get("import_playbook", None) == "/path/to/file"
    assert new_ds.get("vars", None) == {}
    assert new_ds.get("tags", None) == None
    # This ds should raise the error.
    ds = {"import_playbook": {"k1": ["v1", "v2"], "k2": "v3"}}

# Generated at 2022-06-25 05:35:59.836780
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # when the yaml file is empty
    with pytest.raises(AnsibleAssertionError):
        playbook_include_1 = PlaybookInclude()
        playbook_include_1.load_data(None, None, None, None)

    # when ds is not a dictionary
    with pytest.raises(AnsibleAssertionError):
        playbook_include_2 = PlaybookInclude()
        playbook_include_2.load_data(42, None, None, None)

    # when ds is not a dictionary
    with pytest.raises(AnsibleParserError):
        playbook_include_3 = PlaybookInclude()
        playbook_include_3.load_data({}, None, None, None)

    # when ds.import_playbook is not a string

# Generated at 2022-06-25 05:36:01.618345
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    # verify load_data is working as expected
    playbook_include_1.load_data(ds={}, basedir=None, variable_manager=None, loader=None)

# Generated at 2022-06-25 05:36:08.047477
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_3 = PlaybookInclude()
    PlaybookInclude.load_data(playbook_include_3, '/opt/ansible/playbooks/foo.yml', '', '')
    PlaybookInclude.load_data(playbook_include_3, '/opt/ansible/playbooks/foo.yml', '', '')
    PlaybookInclude.load_data(playbook_include_3, '/opt/ansible/playbooks/foo.yml', '', '')


# Generated at 2022-06-25 05:36:11.654876
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_load_data_0 = PlaybookInclude()
    playbook_include_load_data_0.load_data()


# Generated at 2022-06-25 05:36:14.504436
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.load_data(ds='file_name', basedir='./examples', variable_manager='variable_manager_0', loader='loader_0')


# Generated at 2022-06-25 05:36:19.160327
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()
    ds = {'import_playbook': 'testPlaybook.yml'}

    print("Testing %s" % playbook_include_0.__class__.__name__)
    print("Looking for import_playbook.yml")
    expected_0 = {'import_playbook': 'import_playbook.yml'}
    actual_0 = playbook_include_0.preprocess_data(ds)
    assert expected_0 == actual_0

# Generated at 2022-06-25 05:36:26.366779
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    # test missing required attribute(s)
    try:
        playbook_include_1.load_data(ds=None, basedir=None, variable_manager=None, loader=None)
    except Exception as e:
        print("Expected error: %s" % str(e))
    else:
        raise Exception("No Exception Raised")

    # test expected success
    playbook_include_2 = PlaybookInclude()
    playbook_include_2.load_data(ds='ce96d065-f3fc-4a2a-b1ad-eaf1a62aa879', basedir='0d3635d5-cef5-4a5d-b5e5-f963c8dc2337', variable_manager=None, loader=None)



# Generated at 2022-06-25 05:36:28.748709
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()


# Generated at 2022-06-25 05:36:31.552186
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.preprocess_data(ds={'import_playbook': 'test_value_1'})
    playbook_include_0.preprocess_data(ds={'import_playbook': 'test_value_1', 'test_key_2': 'test_value_2'})


# Generated at 2022-06-25 05:36:40.016056
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()


# Generated at 2022-06-25 05:36:49.549663
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    ds = AnsibleMapping()
    ds['import_playbook'] = 'sample.yml'
    ds['vars'] = {'a': 'b'}
    ds['tags'] = 'c'
    ds['when'] = 'd'
    ds['with_items'] = 'e'

    new_ds = AnsibleMapping()
    new_ds['import_playbook'] = 'sample.yml'
    new_ds['vars'] = {'a': 'b'}
    new_ds['tags'] = 'c'
    new_ds['when'] = 'd'

    playbook_include_1 = PlaybookInclude()
    new_obj = playbook_include_1.preprocess_data(ds)

    assert new_obj == new_ds


# Generated at 2022-06-25 05:36:57.762908
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Create a PlaybookInclude object "playbook_include_0"
    playbook_include_0 = PlaybookInclude()
    assert playbook_include_0.import_playbook is None
    assert playbook_include_0.vars == {}

    # Load data for PlaybookInclude object "playbook_include_0"
    playbook_include_0.load_data(ds=dict(import_playbook="playbook.yml",vars=dict(var1="value1", var2="value2")), basedir="path")


# Generated at 2022-06-25 05:37:00.022050
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include = PlaybookInclude()
    playbook_include_load_data = playbook_include.load_data()


# Generated at 2022-06-25 05:37:10.353235
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    playbook_include_1 = PlaybookInclude()
    data = {}
    basedir = '.'
    variable_manager = None
    loader = None

    with pytest.raises(AnsibleAssertionError) as excinfo:
        playbook_include_1.load_data(ds=data, basedir=basedir, variable_manager=variable_manager, loader=loader)
    excinfo.match('ds \(.*\) should be a dict but was a')

    data = {'import_playbook': 'test/playbook.yml', 'vars': {'var1': 'val1', 'var2': 'val2'}, 'tags': ['tag1', 'tag2']}
    playbook_include_2 = PlaybookInclude()

# Generated at 2022-06-25 05:37:13.788505
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    data = "{'import_playbook': '../other.yml', 'vars': {'foo': 'bar'}}"
    basedir = "."
    playbook_include_1.load_data(data, basedir)


# Generated at 2022-06-25 05:37:19.583106
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    ds_1, basedir_1, variable_manager_1, loader_1 = dict(), 'Sample basedir_1', dict(), dict()
    object_1 = playbook_include_1.load_data(ds_1, basedir_1, variable_manager_1, loader_1)
    assert object_1 == None

# Generated at 2022-06-25 05:37:22.910831
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include = PlaybookInclude()
    assert playbook_include is not None


# Generated at 2022-06-25 05:37:30.405691
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    basedir = '/home/djo/fqcn/'
    data = dict(
        {   'import_playbook': '/home/djo/fqcn/playbook1.yaml',
            'vars': dict({'var1': '123', 'var2': '234'}),
            'tags': ['tag1', 'tag2']}
        )
    variable_manager = 'stub'
    loader = 'stub'
    expected_results = 'stub'
    actual_results = playbook_include_1.load_data(
        data, basedir, variable_manager, loader)

    assert actual_results == expected_results


# Generated at 2022-06-25 05:37:38.146122
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # PlaybookInclude object is created
    playbook_include_0 = PlaybookInclude()

    # initial variables are set
    basedir_0 = None

    # load_data() method is called
    ds_0 = None
    variable_manager_0 = None
    loader_0 = None
    value_0 = playbook_include_0.load_data(ds=ds_0, basedir=basedir_0, variable_manager=variable_manager_0, loader=loader_0)

    # This assertion fails
    assert value_0 is None


# Generated at 2022-06-25 05:37:49.909453
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.vars = dict()
    playbook_include_0.import_playbook='include_test.yaml'
    playbook_include_0.load_data(ds=dict(), basedir='', variable_manager=dict(), loader=dict())

# Generated at 2022-06-25 05:37:55.246582
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    playbook_include = PlaybookInclude()

    basedir = None
    variable_manager = None
    loader = None

    ds = None
    # Test with ds = None
    try:
        playbook_include.load_data(ds, basedir, variable_manager, loader)
    except Exception as exception:
        pass # expected

    ds={"some_key": "some_value"}
    # Test with ds = {"some_key": "some_value"}
    try:
        playbook_include.load_data(ds, basedir, variable_manager, loader)
    except Exception as exception:
        pass # expected

    playbook_file_name = "some_playbook_file_name"
    basedir = None
    variable_manager = None
    loader = None

# Generated at 2022-06-25 05:37:57.846553
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude.load({'import_playbook': 'include.yml'}, './')


# Generated at 2022-06-25 05:38:05.204201
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    ds = AnsibleMapping({u'import_playbook': u'playbooks/test.yml', u'vars': {u'test': u'ok'}})
    playbook_include_1 = playbook_include_0.load_data(ds=ds, basedir=u'./playbooks')
    assert playbook_include_1.entries[0].hosts == [u'testhost']
    assert playbook_include_1.entries[0].tasks[0].action == u'copy'
    assert playbook_include_1.entries[0].tasks[0].dest == u'/tmp/test'
    assert playbook_include_1.entries[0].tasks[0].src == u'files/test.txt'

# Generated at 2022-06-25 05:38:10.452624
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # Load a playbook with a simple name
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.load_data(dict({ "import_playbook": "test.yml" }), "/some/path/to/playbook")
    assert playbook_include_0.import_playbook == "test.yml"

# Generated at 2022-06-25 05:38:19.041373
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude()
    playbook_include_2 = PlaybookInclude()
    playbook_include_3 = PlaybookInclude()
    playbook_2 = playbook_include_3.load_data(ds={"test": 0}, basedir='basedir', variable_manager={}, loader={})
    playbook_1 = playbook_include_2.load_data(ds={"test": 0}, basedir='basedir', variable_manager={}, loader={})
    playbook_3 = playbook_include_1.load_data(ds={}, basedir='basedir', variable_manager={}, loader={})
    playbook_0 = playbook_include_0.load_data(ds={}, basedir='basedir', variable_manager={}, loader={})
    assert playbook_0 is None

# Generated at 2022-06-25 05:38:24.507747
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_load_data_1 = PlaybookInclude()
    playbook_include_load_data_1.load_data()
    playbook_include_load_data_2 = PlaybookInclude()
    playbook_include_load_data_2.load_data(ds)
    playbook_include_load_data_3 = PlaybookInclude()
    playbook_include_load_data_3.load_data(ds, basedir)
    playbook_include_load_data_4 = PlaybookInclude()
    playbook_include_load_data_4.load_data(ds, basedir, variable_manager)
    playbook_include_load_data_5 = PlaybookInclude()
    playbook_include_load_data_5.load_data(ds, basedir, variable_manager, loader)


# Generated at 2022-06-25 05:38:25.863822
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    return


# Generated at 2022-06-25 05:38:28.416527
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude()


# Generated at 2022-06-25 05:38:38.570864
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = None

    playbook_include_data = dict(
        import_playbook = "tasks/foo.yml",
    )

    # import_playbook = "tasks/foo.yml"
    playbook_include_1 = PlaybookInclude()
    playbook_include_1.load_data(playbook_include_data, basedir='/etc/ansible', loader=loader, variable_manager=variable_manager)

    playbook = Playbook()
    playbook._load_playbook_data_from_file(playbook_include_1.import_playbook, variable_manager=variable_manager)
    playbook._ent

# Generated at 2022-06-25 05:38:45.763896
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = {}
    var_1 = playbook_include_0.preprocess_data(var_0)


# Generated at 2022-06-25 05:38:50.877035
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = {}
    var_1 = None
    var_2 = None
    var_3 = None
    var_1 = playbook_include_0.load_data(var_0, var_1, var_2, var_3)
    assert playbook_include_0.vars == {}, "playbook_include_0.vars is: %s" % playbook_include_0.vars


# Generated at 2022-06-25 05:38:53.162488
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include = PlaybookInclude()
    var_0 = {}
    var_1 = playbook_include.load_data(var_0)


# Generated at 2022-06-25 05:38:56.495008
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    var_2 = {}
    var_3 = 'fake'
    var_4 = ansible.utils.display.Display()
    playbook_include_1.load_data(var_2, var_3, display=var_4)


# Generated at 2022-06-25 05:39:04.705563
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import tempfile
    from ansible.playbook import Playbook
    p = Playbook()
    p.load('./test/units/parser/parser_include/test_data/test_playbook_include.yml', './test/units/parser/parser_include')
    assert p.entries[0].import_playbook == 'test_playbook_include.yml'
    assert p.entries[0].vars == {'some_var': 'some_value', 'fruits': ['apple', 'peach', 'banana'], 'empty': {'a': 1, 'b': 2}, 'some_key': 'some_value'}
    assert p.entries[0].file_name == './test/units/parser/parser_include/test_playbook_include.yml'

    # Check that a

# Generated at 2022-06-25 05:39:08.817855
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = {}
    var_1 = playbook_include_0.preprocess_data(var_0)
    pb = playbook_include_0.load_data(var_1, '/home/michael/ansible')
    print (pb)


# Generated at 2022-06-25 05:39:12.596587
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    playbook_include_0 = PlaybookInclude()
    load_0 = playbook_include_0.load_data(ds="any_0", basedir="any_1", variable_manager="any_2", loader="any_3")


# Generated at 2022-06-25 05:39:16.199686
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    var_2 = {}
    playbook_include_1.load_data(ds=var_2, basedir="basedir")

# Generated at 2022-06-25 05:39:21.508593
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # Unit test for method load_data of class PlaybookInclude
    playbook_include_0 = PlaybookInclude()
    var_0 = {}
    var_1 = playbook_include_0.load_data(ds=var_0, basedir='/home/vagrant/', variable_manager=None, loader=None)



# Generated at 2022-06-25 05:39:27.844221
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # import_playbook, playbook_path, playbook_collection
    playbook_include_0 = PlaybookInclude()
    var_0 = "canned_path.yml"
    var_1 = "/path/to/playbook"

    # load a playbook
    playbook_include_0.load_data(var_0, var_1)



# Generated at 2022-06-25 05:39:40.535339
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.module_utils._text import to_bytes
    import ansible.playbook
    import ansible.playbook.play
    playbook_0 = ansible.playbook.Playbook(loader='hello')
    playbook_1 = playbook_include_0.load_data(ds=None, basedir='/home/nazar/ansible/nazar-playbooks/roles/influxdb/')

if __name__ == '__main__':
    test_PlaybookInclude_load_data()
    test_case_0()

# Generated at 2022-06-25 05:39:48.044540
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import mock
    py_0 = PlaybookInclude()
    ds_0 = {}
    basedir_0 = "ansible_file"
    variable_manager_0 = mock.MagicMock()
    loader_0 = mock.MagicMock()
    py_0.load_data(ds_0, basedir_0, variable_manager_0, loader_0)



# Generated at 2022-06-25 05:39:55.941963
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    import os

    playbook_include_0 = PlaybookInclude()
    var_0 = {}
    var_1 = os.getcwd()
    var_2 = None
    playbook_0 = playbook_include_0.load_data(var_0, var_1, var_2)
    assert isinstance(playbook_0, Playbook)



# Generated at 2022-06-25 05:40:03.853156
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    cls = PlaybookInclude()
    # Unsupported arg type
    arg_0 = [1.1, 'foo', False]
    arg_1 = [0, 1.0, 'foo', False]
    arg_2 = [0, 1.1, 'bar', True]
    arg_3 = ['foo', 'foo', 1.0, False]
    arg_4 = ['foo', 'foo', 1.1, True]
    arg_5 = ['foo', 'bar', 0, False]
    arg_6 = ['foo', 'bar', 0, True]

    if True:
        raise Exception('AssertionError: %s %s' % (arg_0, arg_1))
    elif True:
        raise Exception('AssertionError: %s %s' % (arg_2, arg_3))
   

# Generated at 2022-06-25 05:40:09.951747
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include = PlaybookInclude()
    ds = {}
    basedir = 'test_value'
    variable_manager = VariableManager()
    loader = DataLoader()
    result = playbook_include.load_data(ds, basedir, variable_manager, loader)
    assert isinstance(result, Playbook)
    assert result.loader == loader
    assert result._variable_manager == variable_manager
    assert result._entries == []
    assert result._basedir == 'test_value'


# Generated at 2022-06-25 05:40:16.266784
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include = PlaybookInclude()
    playbook_include.import_playbook = './playbook.yaml'
    playbook_include.vars = {}
    playbook_include.load_data(ds='./playbook.yaml', basedir='/home/centos', variable_manager=None, loader=None)

test_PlaybookInclude_load_data()

# Generated at 2022-06-25 05:40:19.376186
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.load_data()

# Generated at 2022-06-25 05:40:21.725130
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = [{"import_role": "foo"}]
    playbook_include_0.load_data(ds=var_0, basedir='.')


# Generated at 2022-06-25 05:40:22.645217
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-25 05:40:27.230457
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    print(test_PlaybookInclude_load_data)

    # The value of PlaybookInclude.vars is a dict so it can be checked in the values function
    playbook_include = PlaybookInclude.load('file1', '/tmp/path/')


# Generated at 2022-06-25 05:40:40.339063
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    assert playbook_include_0.load_data(ds=None, basedir=None, variable_manager=None, loader=None) == playbook_include_0


# Generated at 2022-06-25 05:40:43.818274
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = {}
    var_1 = playbook_include_0.load_data(var_0, None, None)
    assert playbook_include_0._included_path == 'None'

# Generated at 2022-06-25 05:40:50.932148
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_1 = {}
    var_2 = None
    var_3 = None
    var_4 = None
    var_1 = playbook_include_0.load_data(var_1, var_2, var_3, var_4)
    var_1 = playbook_include_0.load_data(var_1, var_2, var_3, var_4)
    var_1 = playbook_include_0.load_data(var_1, var_2, var_3, var_4)
    var_1 = playbook_include_0.load_data(var_1, var_2, var_3, var_4)


# Generated at 2022-06-25 05:40:59.319602
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play

    pbi = PlaybookInclude()
    var_0 = {
        "import_playbook": "file:from_files/playbook.yml"
    }
    var_1 = {
        "import_playbook": "from_files/playbook.yml"
    }
    playbook_include_0 = pbi.load_data(
        ds=var_0,
        basedir='/Users/bob/Documents/workspace/ansible_ss/integration/targets/unit_test/test_playbooks/case_0/tasks',
        variable_manager=None,
        loader=None
    )

# Generated at 2022-06-25 05:41:09.448208
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    # Retrieve a PlaybookInclude
    playbook_include_1 = PlaybookInclude()

    # Get a Playbook
    playbook_1 = Playbook()

    # Store a Playbook in playbook_1
    playbook_1._entries.append("playbook")

    # Get a Play
    play_1 = Play()

    # Store a Play in playbook_1._entries
    playbook_1._entries.append(play_1)

    # Get a string
    string_1 = "test"

    # Call method load_data of playbook_include_1 with arguments playbook_1 and string_1
    var_1 = playbook_include_1.load_data(playbook_1, string_1)


# Generated at 2022-06-25 05:41:16.015308
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    ds = {}
    basedir = "string"
    variable_manager = VariableManager()
    loader = DataLoader()
    playbook_include_1 = playbook_include_0.load_data(ds, basedir, variable_manager, loader)
    assert playbook_include_1 is not None


# Generated at 2022-06-25 05:41:19.766393
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    x = {}
    x.update(test="test")
    x.update(test="test2")
    assert x.get('test') == 'test2'


# Generated at 2022-06-25 05:41:25.895793
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude()
    var_0 = {}
    playbook_include_0.load_data(var_0, 'basedir', variable_manager=None, loader=None)
    playbook_include_1.load_data(var_0, 'basedir', variable_manager=None)


# Generated at 2022-06-25 05:41:29.976509
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    host_0 = Host()
    var_0 = {'hosts': 'localhost'}
    var_1 = Playbook()
    var_2 = host_0.load_data(var_0, var_1)


# Generated at 2022-06-25 05:41:38.504318
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_1 = {}
    var_2 = {}
    var_2['_ansible_verbosity'] = 3
    var_2['_ansible_syslog_facility'] = 'LOG_USER'
    var_2['_ansible_selinux_special_fs'] = set(['fuse', 'nfs', 'vboxsf', 'ramfs'])
    var_2['_ansible_remote_tmp'] = ''
    var_2['_ansible_tmpdir'] = '/tmp/ansible-tmp-1549686075.27-77003416808594'
    var_2['_ansible_version'] = '2.7.8'
    var_2['_ansible_version_info'] = [2, 7, 8]
   

# Generated at 2022-06-25 05:41:55.953484
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include = PlaybookInclude()
    data = {}
    basedir = os.path.abspath('/home/web_user/ansible')
    variable_manager = None
    loader = None
    actual = playbook_include.load_data(data, basedir, variable_manager, loader)
    assert actual is None


# Generated at 2022-06-25 05:41:58.437199
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include = PlaybookInclude.load(data={}, basedir={}, variable_manager={}, loader={})
    assert isinstance(playbook_include, PlaybookInclude)


# Generated at 2022-06-25 05:42:00.352351
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pbi = PlaybookInclude()
    pbi.load_data('/home/ubuntu/bucket/main.yml', '/home/ubuntu/bucket/', {})


# Generated at 2022-06-25 05:42:07.561660
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    print("start test test_PlaybookInclude_load_data")
    playbook_include_0 = PlaybookInclude()
    #
    ds_0 = {}
    basedir_0 = "/"
    variable_manager_0 = None
    loader_0 = "loader_0"
    pb_0 = playbook_include_0.load_data(ds_0, basedir_0, variable_manager_0, loader_0)
    #
    print("end test test_PlaybookInclude_load_data")


# Generated at 2022-06-25 05:42:09.904667
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = {}
    var_1 = playbook_include_0.load_data(ds=var_0, basedir='/')

# Generated at 2022-06-25 05:42:13.051363
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1= PlaybookInclude()
    var_2 = {}
    var_3 = None
    var_4 = None
    var_5 = playbook_include_1.load_data(var_2,var_3,var_4)


# Generated at 2022-06-25 05:42:13.562296
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
   pass


# Generated at 2022-06-25 05:42:15.107994
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_2 = {}
    var_3 = PlaybookInclude.load(var_2, 'None', 'None', 'None')


# Generated at 2022-06-25 05:42:19.799774
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    assert playbook_include_0.load_data(1, 2) is not None, "test_PlaybookInclude_load_data method failed"


# Generated at 2022-06-25 05:42:30.285813
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Load the test data from yaml
    from ansible.playbook.playbook_include import playbook_include_parser_gen
    playbook_include_parser = playbook_include_parser_gen()
    playbook_include = playbook_include_parser.load(playbook_include_loader_fixture)
    # Create the AnsibleTemplate object
    playbook_include_obj = PlaybookInclude()
    # Load the data into the object
    playbook_include_obj.load_data(playbook_include, variable_manager=None, loader=None)
    # Check the data
    assert playbook_include_obj.data == playbook_include
    assert playbook_include_obj.import_playbook == '../common/tasks.yml'

# Generated at 2022-06-25 05:42:45.759889
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0=PlaybookInclude()
    var_0 = {} # ds 
    var_1 = '' # basedir 
    var_2 = '' # variable_manager 
    var_3 = '' # loader 
    var_4 = playbook_include_0.load_data(var_0,var_1,var_2,var_3)



# Generated at 2022-06-25 05:42:49.130262
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    data = {}
    basedir = 'foo01.txt'
    playbook_include_1.load_data(data, basedir)


# Generated at 2022-06-25 05:42:55.058157
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = {}
    var_1 = {}
    var_2 = None
    var_3 = None
    var_4 = playbook_include_0.load_data(data=var_0, ds=var_1, variable_manager=var_2, loader=var_3)
    print(var_4)



# Generated at 2022-06-25 05:43:02.977770
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import tempfile
    import os
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # create a file in the temporary directory
    src = os.path.join(tmpdir,"hello.yaml")
    dest = os.path.join(tmpdir,"world.yaml")

    try:
        open(src,'w').write("""\
- import_playbook: {}
""")

        f = open(src)
        data = PlaybookInclude.load(data=ds, basedir='/tmp', variable_manager=variable_manager, loader=loader)
        assert data is not None
        assert data[0]['import_playbook'] == 'world.yaml'

    finally:
        # Remove the directory after the test
        shutil.rmtree(tmpdir)


# Generated at 2022-06-25 05:43:07.136966
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # load_data
    playbook_include_arguments = dict(import_playbook='test_value', vars=dict())
    playbook_include_instance = PlaybookInclude()
    try:
        assert playbook_include_instance.load_data(ds=playbook_include_arguments, basedir='test_value', variable_manager='test_value', loader='test_value')
    except SystemExit:
        pass

# Generated at 2022-06-25 05:43:10.102508
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = {}
    var_1 = playbook_include_0.load_data(ds=var_0, basedir='', variable_manager=None, loader=None)

# Generated at 2022-06-25 05:43:15.364862
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.vars = {}
    playbook_include_0.tags = {}
    playbook_include_0.when = {}
    playbook_include_0.import_playbook = 'testfile'


# Generated at 2022-06-25 05:43:24.851921
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    file_name = "\"site.yml\""
    playbook = os.path.join(C.DEFAULT_PLAYBOOK_PATH, file_name)
    playbook_collection = None
    variable_manager = None
    var_0 = {}
    loader = None
    var_1 = playbook_include_0.load_data(var_0, playbook, variable_manager, loader)
    assert var_1.__class__.__name__ == "Playbook"

# Generated at 2022-06-25 05:43:30.803265
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    ds_0 = {}
    basedir_0 = ''
    variable_manager_0 = VariableManager()
    loader_0 = DataLoader()
    new_playbook_0 = playbook_include_0.load_data(ds_0, basedir_0, variable_manager_0, loader_0)
    assert type(new_playbook_0) == Playbook


# Generated at 2022-06-25 05:43:35.155999
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    ds = {}
    basedir = 'pa/c?h'
    variable_manager = None
    loader = None
    result = playbook_include_0.load_data(ds, basedir, variable_manager, loader)
    assert result == None


# Generated at 2022-06-25 05:44:00.836769
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = {}
    var_1 = playbook_include_0.load_data(ds=var_0, basedir='string_0', variable_manager=None, loader=None)
    assert var_1 is None

# Generated at 2022-06-25 05:44:04.711222
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = {}
    var_1 = 'ansible.parsing.yaml.objects.AnsibleMapping'
    var_2 = playbook_include_0.load_data(var_0, )
    assert template_type(var_2) == var_1

# Generated at 2022-06-25 05:44:08.260209
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    playbook_include_1 = PlaybookInclude()
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = playbook_include_1.load_data(var_2, var_3, var_4, var_5)


# Generated at 2022-06-25 05:44:15.780920
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_2['import_playbook'] = 'import_playbook'
    dict_1['vars'] = dict_2
    dict_0['playbook include'] = dict_1
    dict_3 = dict_0['playbook include']['vars']
    dict_4 = {}
    dict_4['import_playbook'] = dict_3['import_playbook']
    dict_0['playbook include'] = dict_4
    dict_5 = dict_0['playbook include']
    str_0 = dict_5['import_playbook']
    dict_6 = {}
    dict_6['import_playbook'] = str_0

# Generated at 2022-06-25 05:44:20.642082
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    var_2 = '../../../lib/ansible/playbook/include.py'
    var_3 = '../../../lib/ansible/playbook'
    var_4 = {}
    var_5 = {}
    playbook_include_1.load_data(var_2, var_3, var_4, var_5)
