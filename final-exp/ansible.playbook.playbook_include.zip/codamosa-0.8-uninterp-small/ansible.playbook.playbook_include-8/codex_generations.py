

# Generated at 2022-06-25 05:34:39.184722
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    basedir = "./"
    ds = ""
    variable_manager = {}
    loader = ""

    value = playbook_include_1.load_data(ds=ds, basedir=basedir, variable_manager=variable_manager, loader=loader)
    assert value == ""

# Generated at 2022-06-25 05:34:43.870381
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    data = dict(import_playbook='test.yml')
    pb_inc = PlaybookInclude().load_data(data)
    assert pb_inc.import_playbook == 'test.yml'

# Generated at 2022-06-25 05:34:45.652347
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    assert PlaybookInclude.load("", "", None) is None
    assert isinstance(PlaybookInclude.load("play", "", None), Playbook)


# Generated at 2022-06-25 05:34:46.995315
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_load_data0 = PlaybookInclude()


# Generated at 2022-06-25 05:34:58.905911
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # Test case 1
    yaml_snippet_1 = """
    - import_playbook: '/home/ansible/test_playbook.yml'
    """
    data_structure_1 = PlaybookInclude.load(yaml_snippet_1, '', variable_manager=None, loader=None)
    playbook_include_1 = PlaybookInclude().load_data(data_structure_1, '', variable_manager=None, loader=None)
    playbook_include_1_ds = playbook_include_1.preprocess_data(data_structure_1)
    playbook_include_1_legacy_param = playbook_include_1_ds['import_playbook']
    assert playbook_include_1_legacy_param == '/home/ansible/test_playbook.yml'

   

# Generated at 2022-06-25 05:35:00.690555
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.preprocess_data({})


# Generated at 2022-06-25 05:35:11.648694
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    print("Testing preprocess_data of class AnsibleParser::PlaybookInclude")
    playbook_include_1 = PlaybookInclude()
    playbook_include_2 = PlaybookInclude()
    playbook_include_3 = PlaybookInclude()
    playbook_include_4 = PlaybookInclude()
    playbook_include_5 = PlaybookInclude()
    playbook_include_6 = PlaybookInclude()
    playbook_include_7 = PlaybookInclude()
    playbook_include_8 = PlaybookInclude()
    playbook_include_9 = PlaybookInclude()
    playbook_include_10 = PlaybookInclude()

    # Test passing not a dictionary
    test_input = "Hello world"

# Generated at 2022-06-25 05:35:14.334529
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_1 = PlaybookInclude()

    assert playbook_include_1.import_playbook == ''
    assert playbook_include_1.vars == {}


# Generated at 2022-06-25 05:35:19.154213
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()

    ds = dict()

    new_ds = playbook_include_0.preprocess_data(ds=ds)

    assert 'import_playbook' in new_ds

# Generated at 2022-06-25 05:35:24.010644
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include = PlaybookInclude()
    playbook_include.load_data()



# Generated at 2022-06-25 05:35:38.063411
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # Assert argument types
    playbook_include_1 = PlaybookInclude()
    with pytest.raises(AssertionError) as excinfo:
        playbook_include_1.preprocess_data(ds='ds')
    assert 'should be a dict but was a str' in str(excinfo.value)

    # Test proper exception for wrong type of argument
    playbook_include_2 = PlaybookInclude()
    with pytest.raises(AnsibleAssertionError) as excinfo:
        playbook_include_2.preprocess_data(ds='ds')
    assert 'ds (ds) should be a dict but was a str' in str(excinfo.value)

    # Test improper data structure for import_playbook
    playbook_include_3 = PlaybookInclude()

# Generated at 2022-06-25 05:35:43.991217
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    ds_1 = None
    basedir_1 = ''
    variable_manager_1 = []
    loader_1 = []
    result = playbook_include_1.load_data(ds_1, basedir_1, variable_manager_1, loader_1)
    assert result is None


# Generated at 2022-06-25 05:35:54.196514
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # Test case 1
    playbook_include_1 = PlaybookInclude()
    ds_1 = dict()
    try:
        playbook_include_1.preprocess_data(ds=ds_1)
    except AnsibleParserError:
        pass

    # Test case 2
    playbook_include_2 = PlaybookInclude()
    ds_2 = dict(import_playbook='/dir/file.yml')
    try:
        playbook_include_2.preprocess_data(ds=ds_2)
    except AnsibleParserError:
        pass

    # Test case 3
    playbook_include_3 = PlaybookInclude()
    ds_3 = dict(import_playbook='/dir/file.yml', vars=dict())

# Generated at 2022-06-25 05:36:01.149494
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    data = {}
    basedir = '/root/ansible_stable/lib/ansible/modules/core'
    playbook_include_0.load_data(data=data, basedir=basedir)


# Generated at 2022-06-25 05:36:06.264491
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    ds_0 = "{'import_playbook': 'test.yml'}"
    playbook_include_0 = PlaybookInclude()
    assert playbook_include_0.preprocess_data(ds_0) == {'import_playbook': 'test.yml'}

test_case_0()
test_PlaybookInclude_preprocess_data()

# Generated at 2022-06-25 05:36:15.546396
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook import Play
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    # Create an instance of PlaybookInclude and load a playbook data structure
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.load_data(ds=dict(import_playbook='import_playbook_0'), basedir='/', variable_manager=None, loader=None)
    assert playbook_include_0.import_playbook == 'import_playbook_0'
    #assert playbook_include_0.tags == ['all']
    assert playbook_include_0.vars == {}

# Generated at 2022-06-25 05:36:22.025301
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Initial test cases for preprocess_data
    ds1 = dict(import_playbook="foobar.yaml")
    ds2 = dict(import_playbook="foobar.yaml", tags=["foobar", "snafu"])
    ds3 = dict(import_playbook="foobar.yaml", vars=dict(foo="bar"))
    ds4 = dict(import_playbook="foobar.yaml", vars=dict(foo="bar"), tags=["foobar", "snafu"])
    ds5 = dict(import_playbook="foobar.yaml", foo="bar")
    ds6 = dict(import_playbook="foobar.yaml", foo="bar", tags=["foobar", "snafu"])

    # This is what the result should look like
   

# Generated at 2022-06-25 05:36:29.413547
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    try:
        import_result = playbook_include_1.load_data(
            ds = dict(),
            basedir = dict(),
            variable_manager = dict(),
            loader = dict())
    except NotImplementedError:
        pass
    else:
        raise AssertionError('ExpectedNotImplementedError')


# Generated at 2022-06-25 05:36:33.425309
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.load_data(ds={}, basedir='../playbooks', variable_manager=None, loader=None)


# Generated at 2022-06-25 05:36:43.355988
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_1 = PlaybookInclude(dict(
        import_playbook="test_file",
        when="test_when",
        vars=dict(
            first_var="value1"
        ),
        vars2=dict(
            second_var="value2"
        ),
        tags=[
            "test_tag"
        ],
    ))

    try:
        playbook_include_1.preprocess_data({
            1:1
        })
    except AnsibleAssertionError as e:
        assert e.message == 'ds ({1: 1}) should be a dict but was a <class \'int\'>'
    else:
        assert False


# Generated at 2022-06-25 05:36:51.742028
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    test_case_0()
    # TODO:  Test for class PlaybookInclude
    pass



# Generated at 2022-06-25 05:37:03.694845
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Create an instance of class PlaybookInclude
    playbook_include_0 = PlaybookInclude()

    # Use the mimic AnsibleParserError exception instead of AnsibleParserError as AnsibleParserError is defined
    # in a different module
    class AnsibleParserError(Exception):
        pass

    # Test 1:
    try:
        # Call the preprocess_data method of class PlaybookInclude and
        # assert the exception is raised for the following ds
        # 'ds': 'AnsibleBaseYAMLObject' object
        playbook_include_0.preprocess_data(ds='AnsibleBaseYAMLObject')
        # if the above statement completes normally and does not raise an exception,
        # then the test case will fail
        assert False
    except AnsibleAssertionError as e:
        assert True

# Generated at 2022-06-25 05:37:05.632671
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    playbook_include_0 = PlaybookInclude()
    result = playbook_include_0.preprocess_data('s')
    assert result == ''

# Generated at 2022-06-25 05:37:10.788829
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_ds_0 = dict(
        import_playbook = 'import_playbook_0',
        vars = dict(
            tags = 'tags_0',
            vars = 'vars_0'
        )
    )
    playbook_include_0 = PlaybookInclude().load_data(ds = playbook_include_ds_0, basedir = 'basedir_0')
    return playbook_include_0

# Generated at 2022-06-25 05:37:18.081975
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include = PlaybookInclude()
    playbook_include_ds = {}
    playbook_include_new_ds = playbook_include.preprocess_data(playbook_include_ds)
    assert playbook_include_new_ds == {}
    playbook_include_ds = {'key': 'value'}
    playbook_include_new_ds = playbook_include.preprocess_data(playbook_include_ds)
    assert playbook_include_new_ds == {'key': 'value'}
    playbook_include_ds = [1, 2, 3]
    with raises(AnsibleAssertionError):
        playbook_include.preprocess_data(playbook_include_ds)
    playbook_include_ds = {'import_playbook': './test.yml'}
    playbook_include_new_ds = playbook_

# Generated at 2022-06-25 05:37:28.004304
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    ds = '''include: testTask.yml
          import_playbook: testTask.yml
          import_playbook: testTask2.yml
          include: testTask2.yml'''
    basedir = 'UnitTest/unittest/include'
    playbook_include_0.load_data(ds, basedir)
    playbook_0 = playbook_include_0
    assert playbook_0._entries is not None
    assert playbook_0._basedir is not None
    assert playbook_0._playbook_dir is not None
    assert playbook_0._loader is not None
    playbook_0.validate()
    assert playbook_0.get_variable_manager() is not None
    assert playbook_0.get_loader() is not None


# Generated at 2022-06-25 05:37:38.059386
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    pb_include = PlaybookInclude()

    ds = AnsibleMapping()
    ds['import_playbook'] = 'my.yml'
    ds['vars'] = AnsibleMapping()
    ds['vars']['a'] = 'b'
    ds['when'] = 'a == b'
    ds['tags'] = 'c,d'
    ds_copy = ds.copy()
    new_ds = pb_include.preprocess_data(ds)
    assert ds_copy == ds
    assert new_ds == ds
    assert new_ds is not ds

    ds = AnsibleMapping()
    ds['include'] = 'my.yml'
    ds['vars'] = AnsibleMapping()

# Generated at 2022-06-25 05:37:45.860463
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleSequence
    playbook_include_0 = PlaybookInclude()
    playbook_include_0_ds_0 = {'vars': {'a': 'b'}, 'tags': 'blah'}
    playbook_include_0_ds_1 = {'vars': {'a': 'b'}, 'import_playbook': 'blah'}
    playbook_include_0_ds_2 = {'vars': {'a': 'b'}, 'a': 'b'}
    playbook_include_0_ds_3 = {'a': 'b'}
    playbook_include_0_ds_4 = {'import_playbook': 'blah'}

# Generated at 2022-06-25 05:37:49.986034
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include = PlaybookInclude()
    data = {'include': {'import_playbook': 'test.yml', 'vars': {'user': 'username'}, 'post_tasks': {'name': 'test'}}}
    playbook_include.preprocess_data(data)
    

# Generated at 2022-06-25 05:37:52.057460
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-25 05:38:09.010235
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    ds = dict()
    basedir = ''
    variable_manager = None
    loader = None
    var_2 = playbook_include_0.load_data(ds, basedir, variable_manager, loader)
    assert not var_2


# Generated at 2022-06-25 05:38:14.790209
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_2 = PlaybookInclude()
    var_2 = dict()
    var_3 = playbook_include_2.preprocess_data(var_2)
    # BEGIN #
    playbook_include_2 = PlaybookInclude()
    var_2 = dict()
    var_3 = playbook_include_2.preprocess_data(var_2)
    # END #


# Generated at 2022-06-25 05:38:17.883826
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_2 = PlaybookInclude()
    var_2 = dict()
    var_3 = dict()
    var_4 = dict()
    var_4 = playbook_include_2.load_data(var_2, var_3, var_4)
    print(var_4)

# Generated at 2022-06-25 05:38:20.471825
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_2 = PlaybookInclude()
    var_2 = dict()
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = playbook_include_2.load_data(var_2, var_3, var_4, var_5)

# Generated at 2022-06-25 05:38:26.566720
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = dict()
    basedir_0 = str()
    variable_manager_0 = None
    loader_0 = None
    var_1 = playbook_include_0.load_data(var_0, basedir_0, variable_manager_0, loader_0)

# Generated at 2022-06-25 05:38:30.056126
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    basedir_0 = playbook_include_0.basedir
    ds_0 = dict()
    variable_manager_0 = playbook_include_0.variable_manager
    loader_0 = playbook_include_0.loader
    playbook_include_0.load_data(ds_0, basedir_0, variable_manager_0, loader_0)


# Generated at 2022-06-25 05:38:39.893910
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_2 = PlaybookInclude()
    var_9 = dict()
    playbook_include_2.preprocess_data(var_9)
    try:
        var_10 = playbook_include_2.load_data("/vagrant/ansible/test/unit/data/test_playbook/tree/playbook/test_playbook.yml", "/vagrant/ansible/test/unit/data/test_playbook/tree/playbook", None, None)
    except TypeError as e:
        # There should not be a TypeError exception
        assert False


# Generated at 2022-06-25 05:38:50.122459
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_1 = dict()
    var_1['ansible_pos'] = 0
    var_1['ansible_playbook_python'] = '/usr/bin/python'
    var_1['ansible_version'] = {'full': '2.3.0.0', 'major': 2, 'minor': 3, 'revision': 0, 'string': '2.3.0.0'}
    var_2 = dict()
    var_2['ansible_pos'] = 0
    var_2['ansible_playbook_python'] = '/usr/bin/python'

# Generated at 2022-06-25 05:38:58.897831
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_4 = dict()
    dict_5 = dict()
    dict_6 = dict()
    dict_7 = dict()
    dict_8 = dict()
    dict_9 = dict()
    dict_10 = dict()
    dict_11 = dict()
    dict_12 = dict()
    dict_13 = dict()
    dict_14 = dict()
    dict_15 = dict()
    dict_16 = dict()
    dict_17 = dict()
    dict_18 = dict()
    dict_19 = dict()
    dict_20 = dict()
    dict_21 = dict()
    dict_22 = dict()
    dict

# Generated at 2022-06-25 05:39:01.261017
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    ds = dict()
    basedir = 'str'
    variable_manager = dict()
    loader = dict()
    actual = playbook_include_0.load_data(ds, basedir, variable_manager, loader)


# Generated at 2022-06-25 05:39:14.445115
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_obj = PlaybookInclude()
    ds = dict()
    basedir = 'hieradata'
    variable_manager = None
    loader = None
    assert playbook_include_obj.load_data(ds, basedir, variable_manager, loader) == None


# Generated at 2022-06-25 05:39:22.960867
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    data_0 = dict()
    basedir_0 = ""
    variable_manager_0 = object()
    loader_0 = object()

    # Call method on instance
    assert playbook_include_0.load_data(data_0, basedir_0, variable_manager_0, loader_0) is not None
    # Test for methods which don't have input parameters
    assert playbook_include_0.load_data(data_0, basedir_0, variable_manager_0, loader_0) is not None


# Generated at 2022-06-25 05:39:27.032332
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_obj = PlaybookInclude()
    var = dict()
    var.update({"import_playbook": "${playbook}", "tags": "cleanup"})
    playbook_include_obj.load_data(var)


# Generated at 2022-06-25 05:39:30.939041
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    # AssertionError: ds (None) should be a dict but was a NoneType
    try:
        playbook_include_0.load_data(ds=None, basedir="banal_string", variable_manager=None, loader=None)
    except AssertionError:
        pass


# Generated at 2022-06-25 05:39:39.413636
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    file_name_0 = 'hosts.yml'
    basedir_0 = 'tests/integration/targets'
    var_0 = playbook_include_0.load_data(file_name_0, basedir_0)
    assert var_0 == {}, "Return string is not equal to expected string"


# Generated at 2022-06-25 05:39:40.126494
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-25 05:39:43.474754
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    var_2 = {'vars': {'a': 1}}
    var_3 = playbook_include_1.load_data(var_2, 'basedir', None, None)


# Generated at 2022-06-25 05:39:48.846701
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_load_data_0 = PlaybookInclude()
    assert hasattr(playbook_include_load_data_0, '_import_playbook')
    # Line coverage: never reached
    #assert hasattr(playbook_include_load_data_0, '_vars')



# Generated at 2022-06-25 05:39:53.751700
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = dict()
    var_1 = playbook_include_0.preprocess_data(var_0)
    output_0 = playbook_include_0.load_data(var_1, "basedir", "variable_manager", "loader")

# Generated at 2022-06-25 05:39:57.463636
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = """"""
    var_1 = dict()
    var_2 = dict()
    var_2 = playbook_include_0.load_data(var_0, var_1)

# Generated at 2022-06-25 05:40:16.500011
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    playbook_include_0 = PlaybookInclude.load(data=dict(), basedir='/etc/ansible/playbooks/workspace')


# Generated at 2022-06-25 05:40:19.445514
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    # TODO: Write a test for this.


# Generated at 2022-06-25 05:40:23.447082
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = dict()
    var_1 = './test/test_playbook_include.yml'
    var_2 = None
    var_3 = None
    result = playbook_include_0.load_data(ds = var_0, basedir = var_1, variable_manager = var_2, loader = var_3)
    assert isinstance(result, Playbook)


# Generated at 2022-06-25 05:40:29.756959
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    data_0 = dict()
    basedir_0 = './ansible/test/unit/data/'
    variable_manager_0 = None
    loader_0 = None
    PlaybookInclude.load_data(playbook_include_0,data_0, basedir_0,
        variable_manager=variable_manager_0,loader=loader_0)

# Generated at 2022-06-25 05:40:34.747711
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    var_2 = dict()
    template_2 = playbook_include_1.preprocess_data(var_2)
    playbook_include_1.load_data(template_2, 'test_path')


# Generated at 2022-06-25 05:40:40.519326
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    ds_0 = dict()
    basedir_0 = '/etc'
    variable_manager_0 = MockVariableManager()
    loader_0 = None

    pb_0 = playbook_include_0.load_data(ds_0, basedir_0, variable_manager_0, loader_0)


# Generated at 2022-06-25 05:40:46.745056
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_test_file = 'tests/unit/parsing/yaml/fixtures/playbook_include_test_file'
    variable_manager = None
    basedir = '.'
    loader = None
    playbook_include_2 = PlaybookInclude()
    var_0 = 'tests/parsing/load_cases/playbook_include.yml'
    var_1 = playbook_include_2.load_data(var_0, basedir, variable_manager, loader)


# Generated at 2022-06-25 05:40:49.689762
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    # Variable assignment
    var_0 = dict()
    playbook_include_0.vars = var_0
    var_1 = dict()
    var_2 = dict()
    var_2['import_playbook'] = 'test'
    var_2['vars'] = var_1
    var_3 = playbook_include_0.load_data(var_2)


# Generated at 2022-06-25 05:40:57.468958
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    ds_0 = dict()
    basedir_0 = "yP^t"
    variable_manager_0 = None
    loader_0 = None
    test_0 = playbook_include_0.load_data(ds_0, basedir_0, variable_manager_0, loader_0)
    test_1 = playbook_include_0.load_data(ds_0, basedir_0, variable_manager_0, loader_0)

# Generated at 2022-06-25 05:41:04.455604
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = dict()
    var_1 = dict()
    var_2 = dict()
    var_3 = dict()
    obj_0 = playbook_include_0.load_data(var_0, var_1, var_2, var_3)


# Generated at 2022-06-25 05:41:53.054812
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = dict()
    var_1 = dict()
    var_2 = dict()
    var_3 = dict()
    var_4 = dict()
    var_5 = dict()
    var_6 = dict()
    var_7 = dict()
    var_4[''] = var_5
    var_5['tags'] = 'tag_0'
    var_5['tasks'] = 'tasks_0'
    var_5['vars'] = 'vars_0'
    var_5['roles'] = 'roles_0'
    var_5['name'] = 'name_0'
    var_5['post_tasks'] = 'post_tasks_0'

# Generated at 2022-06-25 05:41:56.823312
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    print("Unit test for method load_data of class PlaybookInclude")
    playbook_include_0 = PlaybookInclude()
    var_0 = dict()
    var_1 = playbook_include_0.load_data(var_0)


# Generated at 2022-06-25 05:42:00.791975
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_2 = PlaybookInclude()
    data_1 = dict()
    basedir_1 = ''
    variable_manager_1 = dict()
    loader_1 = dict()
    assert playbook_include_2.load_data(data=data_1, basedir=basedir_1, variable_manager=variable_manager_1, loader=loader_1) == NotImplemented


# Generated at 2022-06-25 05:42:10.967543
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # Load a PlaybookInclude object from a dict
    entry_0 = PlaybookInclude()
    entry_0.load_data({'import_playbook': './playbook.yml', 'vars': {}})

    # Load a PlaybookInclude object from a dict
    entry_1 = PlaybookInclude()
    entry_1.load_data({'import_playbook': './playbook.yml', 'vars': {}})

    # Check that two PlaybookInclude objects are equal
    assert entry_0 == entry_1

    # Load a PlaybookInclude object from a dict
    entry_2 = PlaybookInclude()
    entry_2.load_data({'import_playbook': './playbook.yml', 'vars': {'item1': 'val1'}})

    # Check

# Generated at 2022-06-25 05:42:13.430460
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pbi = PlaybookInclude()
    playbook_data = {
        'import_playbook': 'test.yml'
    }
    playbook = pbi.load_data(playbook_data, '/some/path')
    assert len(playbook._entries) == 2
    assert isinstance(playbook._entries[0], PlaybookInclude)
    assert isinstance(playbook._entries[1], PlaybookInclude)

# Generated at 2022-06-25 05:42:18.312790
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()

    assert playbook_include_0 is not None



# Generated at 2022-06-25 05:42:23.668530
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()

    var_2 = dict()
    var_2['import_playbook'] = 'playbook.yml'
    var_3 = playbook_include_0.load_data(var_2, './')
    assert isinstance(var_3, 'NoneType')



# Generated at 2022-06-25 05:42:28.412578
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    playbook_include_0.load_data(var_0, var_1, var_2, var_3)

# Generated at 2022-06-25 05:42:32.738091
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = dict()
    var_1 = playbook_include_0.load_data(ds=1, basedir=1, variable_manager=1, loader=1)


# Generated at 2022-06-25 05:42:34.741269
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_2 = PlaybookInclude.load(ds=dict(), variable_manager=None, loader=None, basedir=None)


# Generated at 2022-06-25 05:43:09.404781
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Instantiate an object to avoid deprecation warning for the test
    playbook_include_0 = PlaybookInclude()

    # TODO: Fix test
    # Import playbook name is empty
    assert playbook_include_0.load_data(ds=dict(), basedir=None, variable_manager=None, loader=None)


# Generated at 2022-06-25 05:43:15.720852
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = dict()
    var_1 = playbook_include_0.preprocess_data(var_0)
    var_1 = playbook_include_0.load_data(ds=var_0, basedir=var_0, variable_manager=var_0, loader=var_0)



# Generated at 2022-06-25 05:43:22.015861
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = dict()
    var_1 = playbook_include_0.preprocess_data(var_0)



# Generated at 2022-06-25 05:43:25.783041
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    ds_0 = dict()
    basedir_0 = 'b'
    variable_manager_0 = None
    loader_0 = None
    playbook_0 = playbook_include_0.load_data(ds_0, basedir_0, variable_manager_0, loader_0)



# Generated at 2022-06-25 05:43:31.235701
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # Arrange
    playbook_include_0 = PlaybookInclude()
    var_1 = None
    var_2 = None
    var_3 = None

    # Arrange Act
    try:
        playbook_include_0.load_data(var_1, var_2, var_3)
    except Exception as e:
        print(e)


# Generated at 2022-06-25 05:43:37.906530
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = dict()
    var_1 = playbook_include_0.preprocess_data(var_0)
    var_2 = playbook_include_0.load_data(ds=var_1, basedir=None, variable_manager=None, loader=None)

# Generated at 2022-06-25 05:43:44.410249
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = dict()
    var_1 = '/path/to/include'
    var_2 = dict()
    var_3 = dict()
    #var_3['vars'] = var_2
    var_3['import_playbook'] = var_1
    var_5 = playbook_include_0.load_data(var_3, var_0)
    var_6 = dict()
    var_6['import_playbook'] = var_1
    #var_6['vars'] = var_2
    var_7 = playbook_include_0.load_data(var_6, var_0)
    var_8 = dict()
    var_9 = 'hosts'
    var_8[var_9] = var_2
    var_

# Generated at 2022-06-25 05:43:50.394814
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    playbook_include_0 = PlaybookInclude()
    var_0 = dict()
    var_1 = playbook_include_0.preprocess_data(var_0)
    var_2 = Playbook()
    var_3 = playbook_include_0.load_data(var_1, var_2)


# Generated at 2022-06-25 05:43:56.025255
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude()
    playbook_include_2 = PlaybookInclude()
    playbook_include_3 = PlaybookInclude()
    playbook_include_4 = PlaybookInclude()
    playbook_include_5 = PlaybookInclude()
    playbook_include_6 = PlaybookInclude()
    playbook_include_7 = PlaybookInclude()
    playbook_include_8 = PlaybookInclude()
    playbook_include_9 = PlaybookInclude()
    playbook_include_10 = PlaybookInclude()
    playbook_include_11 = PlaybookInclude()
    playbook_include_12 = PlaybookInclude()
    playbook_include_13 = PlaybookInclude()
    playbook_include_14 = PlaybookInclude()
    playbook_include

# Generated at 2022-06-25 05:43:59.525168
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = dict()
    var_1 = 'basedir'
    var_2 = dict()
    var_3 = dict()
    obj_0 = PlaybookInclude()
    obj_0.load_data(var_0, var_1, var_2, var_3)