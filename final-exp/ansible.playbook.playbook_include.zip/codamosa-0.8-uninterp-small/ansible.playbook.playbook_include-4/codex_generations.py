

# Generated at 2022-06-25 05:34:34.878148
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()

# Generated at 2022-06-25 05:34:42.831818
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_1 = PlaybookInclude()
    ds_1 = {"import_playbook": "../other_playbook.yml", "vars": {"foo": "bar"}}
    new_ds_1 = playbook_include_1.preprocess_data(ds=ds_1)
    assert "import_playbook" in new_ds_1
    assert "vars" in new_ds_1
    assert len(new_ds_1.keys()) == 2
    assert isinstance(new_ds_1, dict)


# Generated at 2022-06-25 05:34:52.950776
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    pb = PlaybookInclude()
    # Basic test case
    ds1 = {'ansible_pos': 'playbooks/playbook_include.yml:1'}
    expected1 = {'ansible_pos': 'playbooks/playbook_include.yml:1'}
    result1 = pb.preprocess_data(ds1)
    assert result1 == expected1
    # Basic test case
    ds2 = {'ansible_pos': 'playbooks/playbook_include.yml:1', 'import_playbook': 'test.yml'}
    expected2 = {'ansible_pos': 'playbooks/playbook_include.yml:1', 'import_playbook': 'test.yml'}
    result2 = pb.preprocess_data(ds2)
    assert result

# Generated at 2022-06-25 05:35:00.803606
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    pb = playbook_include_0.load_data({'import_playbook': 'some_playbook.yml', 'vars': {'s': 'x'} }, '')
    assert pb._entries[0]._included_path is None
    assert pb._entries[0].tags == []
    assert pb._entries[0].vars == {'s': 'x'}


# Generated at 2022-06-25 05:35:02.068525
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_preprocess_data = PlaybookInclude()


# Generated at 2022-06-25 05:35:13.151780
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # First check with an empty dictionary
    playbook_include_obj = PlaybookInclude()
    playbook_inc_data = {}

    try:
        playbook_include_obj.load_data(ds=playbook_inc_data, basedir=None)
        assert False
    except AnsibleAssertionError:
        assert True

    # Now check with a dictionary having only one key 'import_playbook' with a value
    playbook_inc_data = dict(import_playbook="file_path_to_load")
    playbook_include_obj.load_data(ds=playbook_inc_data, basedir=None)

    # Now check with a dictionary having only one key 'vars' with a value
    playbook_inc_data = dict(vars=dict(key1="value1"))
    playbook_include_obj.load_data

# Generated at 2022-06-25 05:35:17.754858
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.load_data({'import_playbook': 'test_include_playbook_0.yml'}, '/ansible/roles/test_role_0/')

# Generated at 2022-06-25 05:35:21.434548
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include = PlaybookInclude()
    ds = {}
    basedir = ""
    # Check for correct behavior when no variable_manager or loader is specified
    playbook_include.load_data(ds=ds, basedir=basedir)


# Generated at 2022-06-25 05:35:29.054320
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    def _run(ds, expected_result, expected_fail_msg=None):
        pb_i = PlaybookInclude()
        try:
            if expected_fail_msg:
                fail_message = "Expected AnsibleParserError with message '%s'" % expected_fail_msg
            else:
                fail_message = None

            result = pb_i.preprocess_data(ds)
            assert result == expected_result, fail_message
        except AnsibleParserError as e:
            if expected_fail_msg:
                assert str(e) == expected_fail_msg, "Expected AnsibleParserError with message '%s', got '%s' instead" % (expected_fail_msg, str(e))
            else:
                error_message = "Unexpected AnsibleParserError '%s'" % str(e)

# Generated at 2022-06-25 05:35:37.508347
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_1 = PlaybookInclude()
    # This test fails due to a bug in the AnsibleParserError 1st argument
    # if we keep the raise exception, then we are forced to use the bug
    # and this test will fail, but for the moment I am disabling it,
    # I am sure that the error_parser is going to be fixed in the future
    # because this code is from Ansible, not from me.
    # value = playbook_include_1.preprocess_data(None)
    # assert value is None
    assert True

    playbook_include_2 = PlaybookInclude()

# Generated at 2022-06-25 05:35:47.727033
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    float_0 = 0.5
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(float_0, float_0)


# Generated at 2022-06-25 05:35:53.348352
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import re
    import unittest
    import ansible.parsing.yaml.loader
    import ansible.parsing.yaml.objects

    float_0 = 0.5
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load(float_0, float_0)


# Generated at 2022-06-25 05:35:55.360966
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    float_0 = 0.5
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load(float_0, float_0)

# Generated at 2022-06-25 05:36:07.528470
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    float_0 = 0.5
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude()
    playbook_include_1.vars = dict()
    playbook_include_2 = PlaybookInclude()
    playbook_include_2.tags = list()
    playbook_include_3 = PlaybookInclude()
    playbook_include_3.when = list()
    playbook_include_4 = PlaybookInclude()
    playbook_include_4.when = list()
    playbook_include_4.tags = list()
    playbook_include_4.vars = dict()
    playbook_include_5 = PlaybookInclude()
    playbook_include_5.tags = list()
    playbook_include_5.vars = dict()
    playbook_include_6 = PlaybookInclude()


# Generated at 2022-06-25 05:36:12.267249
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    float_0 = 0.5
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load(float_0, float_0)


# Generated at 2022-06-25 05:36:14.425393
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()
    ds_0 = playbook_include_0.preprocess_data(float_0)


# Generated at 2022-06-25 05:36:15.736076
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    float_0 = 0.5
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(float_0, float_0)


# Generated at 2022-06-25 05:36:22.312059
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    float_0 = 0.5
    playbook_include_0 = PlaybookInclude()
    str_0 = 'x'
    var_0 = playbook_include_0.load_data(float_0, str_0)


# Generated at 2022-06-25 05:36:27.792477
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    float_0 = 0.5
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(float_0, float_0)


# Generated at 2022-06-25 05:36:34.004456
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    float_0 = 0.4
    float_1 = 0.5
    playbookInclude_0 = PlaybookInclude()
    var_0 = playbookInclude_0.load_data(float_0, float_1)
    assert var_0 is not None


# Generated at 2022-06-25 05:36:54.153772
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    data = 'data'
    basedir = 'basedir'
    variable_manager = 'variable_manager'
    loader = 'loader'
    var_0 = playbook_include_0.load_data(data, basedir, variable_manager, loader)


# Generated at 2022-06-25 05:37:05.592190
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    float_0 = 0.5
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.__dict__['_import_playbook'] = 'play_0'
    playbook_include_0.__dict__['_vars'] = {
        'foo': 'bar',
    }
    playbook_include_0.__dict__['_import_playbook'] = 'play_1'
    playbook_include_0.__dict__['_vars'] = {
        'foo': ['bar'],
    }
    playbook_include_0.__dict__['_import_playbook'] = 'play_2'
    playbook_include_0.__dict__['_vars'] = {
        'foo': 'bar',
    }
    playbook_include_0.__dict__['_import_playbook']

# Generated at 2022-06-25 05:37:08.931479
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    float_0 = 0.5
    var_0 = playbook_include_0.load_data(float_0, float_0)
    #assert var_0 == {}


# Generated at 2022-06-25 05:37:12.447926
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    unicode_0 = u'include'
    float_0 = 0.076790783511
    new_obj = playbook_include_0.load_data(unicode_0, float_0)
    assert isinstance(new_obj, PlaybookInclude)


# Generated at 2022-06-25 05:37:14.123492
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    float_0 = 0.5
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.load_data(float_0, float_0)


# Generated at 2022-06-25 05:37:18.576074
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_load_data_0 = PlaybookInclude()
    float_0 = 0.5
    var_0 = playbook_include_load_data_0.load_data(float_0, float_0)


# Generated at 2022-06-25 05:37:23.513302
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    float_0 = 0.5
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(float_0, float_0, float_0)


# Generated at 2022-06-25 05:37:26.296103
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
	float_0 = 0.5
	playbook_include_0 = PlaybookInclude()
	playbook_include_0.load_data(float_0, float_0, float_0)


# Generated at 2022-06-25 05:37:28.801226
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # playbook_include_0 = PlaybookInclude()
    # AssertionError: load_data is an instance method and should be called with an instance of PlaybookInclude
    pass


# Generated at 2022-06-25 05:37:31.953429
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    float_0 = 0.5
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(float_0, float_0)


# Generated at 2022-06-25 05:37:58.750160
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    float_0 = 0.5
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.load_data(float_0, float_0)


# Generated at 2022-06-25 05:38:05.160950
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    float_0 = 0.5
    playlist_0 = [float_0, float_0]
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(float_0, float_0)



# Generated at 2022-06-25 05:38:09.980481
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.vars = dict()
    data_0 = dict()
    basedir_0 = '/tmp'
    var_0 = playbook_include_0.load_data(data_0, basedir_0)


# Generated at 2022-06-25 05:38:18.768793
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    playbook_include_1 = PlaybookInclude()
    playbook_include_2 = PlaybookInclude()
    playbook_include_3 = PlaybookInclude()
    playbook_include_4 = PlaybookInclude()
    playbook_include_5 = PlaybookInclude()
    playbook_include_6 = PlaybookInclude()
    float_0 = float()
    float_1 = float()
    float_2 = float()
    float_3 = float()
    float_4 = float()
    float_5 = float()
    float_6 = float()
    float_7 = float()
    float_8 = float()
    float_9 = float()
    float_10 = float()
    float_11 = float()
    float

# Generated at 2022-06-25 05:38:25.401953
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()
    float_0 = -10.31
    float_1 = 3.99
    yaml_0 = "tasks: - include_tasks: \"{{ path }}\", tags: deploy, vars: server: '{{ server | default(inventory_hostname) }}', - debug: var: server"
    yaml_1 = "tasks:\n- debug: msg='test_Playbook_load_data'"
    yaml_2 = "server: '{{ hostvars[inventory_hostname][\"ansible_em1\"][\"ipv4\"][\"address\"] }}'"

# Generated at 2022-06-25 05:38:36.700106
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # ------------------------------------------------------------------------
    #
    # ------------------------------------------------------------------------

    # ------------------------------------------------------------------------
    #
    # ------------------------------------------------------------------------
    import datetime

    datetime_1 = datetime.datetime(2006, 7, 7, 1, 56)
    str_0 = 'test_cache'

    # ------------------------------------------------------------------------
    #
    # ------------------------------------------------------------------------
    str_1 = 'test_cache'

    # ------------------------------------------------------------------------
    #
    # ------------------------------------------------------------------------
    str_2 = 'test_cache'

    # ------------------------------------------------------------------------
    #
    # ------------------------------------------------------------------------
    str_3 = 'test_cache'

    # ------------------------------------------------------------------------
    #
    # ------------------------------------------------------------------------
    str_4 = 'test_cache'

    # ------------------------------------------------------------------------
    #
    # ------------------------------------------------------------------------
    str_5 = 'test_cache'

    # ------------------------------------------------------------------------
    #
    # ------------------------------------------------------------------------
   

# Generated at 2022-06-25 05:38:42.251744
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    float_0 = 0.5
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(float_0, float_0)


# Generated at 2022-06-25 05:38:45.378877
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    float_1 = 0.5
    playbook_include_1 = PlaybookInclude()
    var_1 = playbook_include_1.load_data(float_1, float_1)


# Generated at 2022-06-25 05:38:50.232883
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()
    float_0 = 0.5
    int_0 = 0
    dict_0 = dict()
    dict_1 = dict()
    dict_0["_import_playbook"] = "_import_playbook"
    dict_0["_vars"] = "_vars"
    dict_1["_import_playbook"] = "_import_playbook"
    dict_1["_vars"] = "_vars"
    dict_1["vars"] = "_vars"
    var_0 = playbook_include_0.preprocess_data(dict_0)
    var_1 = playbook_include_0.preprocess_data(dict_1)
    assert var_0 == dict_0
    assert var_1 == dict_1


# Generated at 2022-06-25 05:38:54.123248
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    args = {'a': 'b'}
    pb_include = PlaybookInclude()
    pb_include.load_data(args, 'c')


# Generated at 2022-06-25 05:39:21.471294
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    float_0 = 0.5
    ds_0 = AnsibleMapping()
    variable_manager_0 = VariableManager()
    loader_0 = DataLoader()
    #The following assertion error would be raised if load_data is called first
    #assertion_error_0 = Exception()
    #assertion_error_0.args = ('ds (None) should be a dict but was a <type \'NoneType\'>',)
    #assertion_error_1 = Exception()
    #assertion_error_1.args = ('ds (%s) should be a dict but was a %s' % (ds_0, type(ds_0)),)
    playbook_include_0.load_data(ds_0, float_0, variable_manager_0, loader_0)




# Generated at 2022-06-25 05:39:26.178346
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    float_0 = 0.5
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load(float_0, float_0)


# Generated at 2022-06-25 05:39:30.730326
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    """
    Load the data for a PlaybookInclude object, then return a Playbook() object
    to contain the data loaded by the PlaybookInclude object.
    """
    float_0 = 0.5
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(float_0, float_0)


# Generated at 2022-06-25 05:39:32.708682
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    float_1 = 0.5
    playbook_include_1 = PlaybookInclude()
    var_1 = playbook_include_1.load_data(float_1, float_1)


# Generated at 2022-06-25 05:39:39.776993
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    float_0 = 0.14
    playbook_include_0 = PlaybookInclude()
    default_0 = playbook_include_0.load_data(float_0, float_0)
    playbook_include_1 = PlaybookInclude()
    templar_0 = playbook_include_1.load_data(float_0, float_0)
    print(default_0)
    print(templar_0)


# Generated at 2022-06-25 05:39:48.958912
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = 'test.yml'
    var_0 = playbook_include_0.load(var_0, var_0)
    var_1 = 'test_preprocess_data.yml'
    playbook_include_0 = PlaybookInclude()
    var_2 = 'test.yml'
    var_2 = playbook_include_0.load(var_2, var_2)
    print(playbook_include_0.preprocess_data(var_2))
    #assert playbook_include_0.preprocess_data(var_2) == var_1


# Generated at 2022-06-25 05:39:56.022692
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    float_0 = 0.5
    # test_data is of type dict
    test_data = dict()
    # basedir is of type str
    basedir = str()
    # variable_manager is of type object
    variable_manager = object()
    # loader is of type object
    loader = object()
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(test_data, basedir, variable_manager, loader)


# Generated at 2022-06-25 05:39:58.774356
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    float_0 = 0.5
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(float_0, float_0, float_0)


# Generated at 2022-06-25 05:40:00.817944
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(ds=None, basedir=None)


# Generated at 2022-06-25 05:40:04.002136
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    float_0 = 0.5
    dict_0 = {}
    dict_0['a'] = playbook_include_0
    playbook_include_1 = PlaybookInclude()
    playbook_0 = playbook_include_1.load_data(dict_0, float_0)

# Generated at 2022-06-25 05:40:34.905000
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include = PlaybookInclude()
    test_case_0(playbook_include)

# Generated at 2022-06-25 05:40:38.087936
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    float_0 = 0.5
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.load_data(float_0, float_0)


# Generated at 2022-06-25 05:40:42.944602
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    float_0 = 0.0
    playbook_include_0 = PlaybookInclude()
    data = AnsibleMapping()
    basedir = os.path.abspath(os.path.join(C.ANSIBLE_HOME, "playbooks"))
    playbook_include_0.load_data(data, basedir)


# Generated at 2022-06-25 05:40:45.678700
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    float_0 = 0.5
    var_0 = playbook_include_0.load_data(float_0, float_0)


# Generated at 2022-06-25 05:40:47.829885
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    #playbook_include_1.load_data()
    # assert False # TODO: implement your test here


# Generated at 2022-06-25 05:40:57.350228
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Case 1 -
    float_0 = 0.5
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load(float_0, float_0)
    playbook_include_1 = PlaybookInclude()
    var_1 = playbook_include_1.load(float_0, float_0)
    assert(var_0 == var_1)
    # assert(playbook_include_0.load_data(float_0, float_0) == playbook_include_1.load_data(float_0, float_0))
    # Case 2 -
    float_0 = 0.5
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load(float_0, float_0)
    playbook_include_1 = Playbook

# Generated at 2022-06-25 05:41:03.441267
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    float_0 = 1.0
    float_1 = 1.0
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.load_data(float_0, float_1)


# Generated at 2022-06-25 05:41:06.524858
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    f = 0.5
    playbook_include_0 = PlaybookInclude()
    assert playbook_include_0.load_data(f, f) is None
    playbook_include_1 = PlaybookInclude()
    assert playbook_include_1.load_data(f, f) is None


# Generated at 2022-06-25 05:41:11.196233
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    basedir = '/root/anaconda3/envs/ansible/lib/python3.8/site-packages/ansible/playbooks/workspace'
    playbook_include_0 = PlaybookInclude()
    ds = 0.1
    var_0 = playbook_include_0.load_data(ds, basedir)
    assert not isinstance(var_0, PlaybookInclude)


# Generated at 2022-06-25 05:41:13.381779
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    float_0 = 0.5
    playbook_include_0 = PlaybookInclude()
    # Test when first arg is invalid
    with pytest.raises(ansible.errors.AnsibleError):
        playbook_include_0.load_data(float_0, float_0)



# Generated at 2022-06-25 05:42:22.495349
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    float_0 = 0.5
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load(float_0, float_0)



# Generated at 2022-06-25 05:42:28.036733
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    float_0 = 0.05
    float_1 = 0.82
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.load_data(float_0, float_1)


# Generated at 2022-06-25 05:42:37.916674
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play_context import PlayContext

    basedir = '/home/ansible/projects/mazer_test/mazer/test/playbook_includes'
    ds = {'import_playbook': '../../test/integration/targets/import_playbook/subdir/subsubdir/import_me.yml'}

    try:
        playbook_include_0 = PlaybookInclude()
        var_0 = playbook_include_0.load_data(ds, basedir, PlayContext())
    except AnsibleParserError as e:
        msg = 'import_playbook statements must specify the file name to import'
        assert e.message == msg


# Generated at 2022-06-25 05:42:44.930650
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    playbook_include_0 = PlaybookInclude()
    # Check if the PlaybookInclude class returns Playbook object
    playbook_include_0.load_data(ds=None, basedir=None, variable_manager=None, loader=None)
    # Check if the PlaybookInclude class returns Playbook object which has the entries as Play objects
    playbook_include_0.load_data(ds=None, basedir=None, variable_manager=None, loader=None)


# Generated at 2022-06-25 05:42:47.838396
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    ds = dict()
    basedir = 'string_0'
    variable_manager = 'string_1'
    loader = 'string_2'
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(ds, basedir, variable_manager, loader)


# Generated at 2022-06-25 05:42:50.588797
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    float_0 = 0.5
    playbook_include_0 = PlaybookInclude()
    float_1 = 0.5
    # The first argument of the next line is inaccurate
    # The actual argument needs to be playbook_include_0
    var_0 = playbook_include_0.load_data(float_0, float_0, float_1)


# Generated at 2022-06-25 05:42:53.935898
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    float_0 = 1.0
    var_0 = playbook_include_0.load_data(float_0, float_0)


# Generated at 2022-06-25 05:43:02.263925
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    print("\nStarting test_PlaybookInclude_load_data")
    pbi = PlaybookInclude()
    ds = { 'import_playbook': "test-import.yml" }
    pbi = pbi.load_data(ds, "/dummy/basedir")
    print("\nEnd test_PlaybookInclude_load_data")


# Generated at 2022-06-25 05:43:04.035019
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    float_0 = 0.5
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(float_0, float_0)


# Generated at 2022-06-25 05:43:14.364996
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    float_0 = 0.5
    playbook_include_0 = PlaybookInclude()
    dict_0 = dict()
    dict_1 = dict()
    dict_0['vars'] = dict()
    dict_0['import_playbook'] = '/playbooks/interfaces.yml'
    dict_1['vars'] = dict()
    dict_1['import_playbook'] = '/playbooks/interfaces.yml'
    dict_1['vars']['city'] = 'Boston'
    dict_1['vars']['state'] = 'Massachusetts'
    # This assertion is incorrect as it tries to compare Playbook objects, which are complex
    # assert playbook_include_0.load_data(dict_0, '.') == dict_1
