

# Generated at 2022-06-25 05:34:51.055191
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Case1: test for empty data structure
    playbook_include_1 = PlaybookInclude()
    data = {}

    new_data = playbook_include_1.preprocess_data(data)

    assert new_data['import_playbook'] == ''

    # Case2: test for full first data structure
    playbook_include_2 = PlaybookInclude()
    data = dict(
        import_playbook = 'myplaybook',
        tags = 'tag1, tag2'
    )
    new_data = playbook_include_2.preprocess_data(data)
    assert new_data['import_playbook'] == 'myplaybook'
    assert new_data['tags'] == ['tag1', 'tag2']

    # Case3: test for full second data structure
    playbook_include_3 = PlaybookInclude()


# Generated at 2022-06-25 05:34:57.809152
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.__name__ = 'test_playbook_include_name'
    assert playbook_include_0.name == 'test_playbook_include_name'


# Generated at 2022-06-25 05:35:01.490970
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()
    ds = AnsibleMapping()
    ds['vars'] = {'a': 1}
    ds['import_playbook'] = 'test.yml'
    ds['tags'] = ['test']
    playbook_include_0.preprocess_data(ds=ds)

# Generated at 2022-06-25 05:35:02.369033
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    assert True


# Generated at 2022-06-25 05:35:05.248929
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_1 = PlaybookInclude(dict(import_playbook='imported.yml', vars=dict(key1='value1', key2='value2')))

# Generated at 2022-06-25 05:35:12.956878
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    ansible_1 = playbook_include_1.load_data(ds={}, basedir="tests/unit/", variable_manager={}, loader={}) # TODO: Change the value of var 'basedir' to an appropriate value for your test.
    assert isinstance(ansible_1, Playbook)
    assert ansible_1._entries == []
    assert ansible_1._basedir == "tests/unit/"
    assert isinstance(ansible_1._variable_manager, VariableManager)
    assert ansible_1._loader == {}


# Generated at 2022-06-25 05:35:24.118775
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    BOGUS_INPUT = """
- hosts: test
  import_playbook: foobar.yml
  vars:
    x: 1
"""
    try:
        p = Playbook.load(BOGUS_INPUT, variable_manager={'x': 1}, loader=None)
    except Exception as e:
        assert(False)

    BOGUS_INPUT = """
- hosts: test
  import_playbook: foobar.yml
  vars:
    x: 1
    tags: foo,bar
"""
    try:
        p = Playbook.load(BOGUS_INPUT, variable_manager={'x': 1}, loader=None)
    except Exception as e:
        assert(False)


# Generated at 2022-06-25 05:35:25.668685
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass # Nothing to test


# Generated at 2022-06-25 05:35:36.298062
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_1 = PlaybookInclude()
    ds_1 = { 'import_playbook': '/path/to/playbook.yml', 'vars': { 'var1': 'value1', 'var2': 'value2' } }
    new_ds_1 = playbook_include_1.preprocess_data(ds=ds_1)
    assert new_ds_1.import_playbook == '/path/to/playbook.yml'
    assert new_ds_1.vars.var1 == 'value1'
    assert new_ds_1.vars.var2 == 'value2'
    playbook_include_2 = PlaybookInclude()

# Generated at 2022-06-25 05:35:41.583144
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    ds_1 = dict(import_playbook="/home/prakash/test.yml", tags=['web'])
    playbook_include_1.load_data(ds_1, basedir="/home/prakash/", variable_manager={}, loader={})

    ds_2 = dict(import_playbook=["/home/prakash/test.yml", "/home/prakash/test1.yml"], tags=['web'])
    playbook_include_1.load_data(ds_2, basedir="/home/prakash/", variable_manager={}, loader={})

    ds_3 = dict(import_playbook="/home/prakash/test.yml", introduction="Hello", tags=['web'])
    playbook_include_1

# Generated at 2022-06-25 05:35:57.342739
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    vars_1 = {playbook_include_1: playbook_include_1, playbook_include_1: playbook_include_1}
    playbook_include_1.load_data(ds=playbook_include_1, basedir=playbook_include_1, variable_manager=playbook_include_1, loader=playbook_include_1, vars=vars_1)



# Generated at 2022-06-25 05:36:02.312387
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = {playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0}
    playbook_include_0.load_data(var_0, playbook_include_0)


# Generated at 2022-06-25 05:36:09.476689
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0}
    playbook_include_1 = PlaybookInclude()
    dict_1 = dict_0
    dict_2 = {playbook_include_1: playbook_include_1, playbook_include_1: playbook_include_1, playbook_include_1: playbook_include_1}
    dict_3 = dict_2
    dict_4 = dict_3
    dict_5 = {playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0}
    dict_6 = dict_5

# Generated at 2022-06-25 05:36:14.504510
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    dict_1 = {'vars': {'import_playbook': 'str', 'vars': {}}}
    basedir_1 = 'str'
    variable_manager = None
    loader = None
    var_1 = playbook_include_1.load_data(dict_1, basedir_1, variable_manager, loader)
    assert var_1 == None


# Generated at 2022-06-25 05:36:24.622272
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {'vars': {'a': 'b', 'c': 'd'}, 'import_playbook': 'e', 'tags': 'f;g'}
    dict_1 = {'a': 'b', 'c': 'd'}
    dict_2 = {'a': 'b'}
    dict_3 = {'c': 'd'}
    dict_4 = {'a': 'b', 'c': 'd'}
    dict_5 = {'a': 'b', 'c': 'd'}
    dict_6 = {'a': 'b', 'c': 'd'}
    dict_7 = {'a': 'b', 'c': 'd'}

# Generated at 2022-06-25 05:36:27.927316
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0}
    var_0 = playbook_include_0.load_data(dict_0, '/ansible/test_dir/test_file.text', None, None)



# Generated at 2022-06-25 05:36:33.154545
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    dict_1 = {playbook_include_1: playbook_include_1, playbook_include_1: playbook_include_1, playbook_include_1: playbook_include_1}
    var_1 = playbook_include_1.preprocess_data(dict_1)
    var_2 = PlaybookInclude.load(dict_1, var_1)
    print(var_2)

if __name__ == '__main__':
    test_case_0()
    test_PlaybookInclude_load_data()

# Generated at 2022-06-25 05:36:34.984498
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    playbook_include_1.load_data(ds=None, basedir=None, variable_manager=None, loader=None)


# Generated at 2022-06-25 05:36:40.830325
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    ds = dict()
    playbook_include_0 = PlaybookInclude()
    variable_manager = variable_manager
    loader = loader
    playbook_include_0.load_data(ds=ds, basedir='/root/ansible/test/integration', variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-25 05:36:46.414096
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Create an instance of a model formula object
    playbook_include_6 = PlaybookInclude()

    # Create an instance of a model variable manager object
    variable_manager_7 = VariableManager()
    variable_manager_8 = variable_manager_7

    # Create an instance of a model loader object
    loader_9 = DataLoader()
    loader_9 = loader_9

    # Create an instance of a model basedir object
    basedir_10 = None
    # Load data into the model using basedir
    playbook_include_6.load_data(ds='/included.yml', basedir=basedir_10, variable_manager=variable_manager_8, loader=loader_9)


# Generated at 2022-06-25 05:37:06.156200
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Import playbook
    p = PlaybookInclude()

    p.import_playbook = 'test.yml'

    # Create a play to check the pre-processing
    p1 = p._load_data()

    # Check the import_playbook was set
    assert p1.import_playbook == 'test.yml'

    # Check vars are set
    p.vars = {'var': 'Value'}
    p2 = p._load_data()
    assert p2.vars == {'var': 'Value'}

    # Check tags
    p2.tags = 'tag1, tag2'
    p3 = p._load_data()
    assert p3.tags == 'tag1, tag2', p3.tags



# Generated at 2022-06-25 05:37:11.613281
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0}
    playbook_include_0.load_data(dict_0, os.path.abspath('/home/tmcadam/ansible/test/unit/data/src/ansible/playbook_e'))



# Generated at 2022-06-25 05:37:21.532327
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # It should assert if the passed in data is not a dict type
    obj_t = PlaybookInclude()
    data_t = "hello"
    try:
        obj_t.load_data(data_t)
    except AssertionError:
        assert True
    else:
        assert False
    
    # It should set the correct value of variable basedir
    obj_t = PlaybookInclude()
    data_t = {}
    obj_t.load_data(data_t, "/home/ziyu/Ansible")
    assert obj_t.base_pth == "/home/ziyu/Ansible"

    # It should set the correct value of variable variable_manager
    obj_t = PlaybookInclude()
    data_t = {}

# Generated at 2022-06-25 05:37:30.404020
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    vars_0 = {"key": "value"}
    playbook_include_0.vars = vars_0
    dict_0 = {"a": "value", "b": "value"}
    dict_1 = {"import_playbook": "value", "vars": dict_0}
    playbook_include_0.load_data(dict_1, "/a/b/c")
    playbook_include_0.load_data(dict_1, "/a/b/c")
    playbook_include_0.load_data(dict_1, "/a/b/c")
    playbook_include_0.load_data(dict_1, "/a/b/c")
    playbook_include_0.load_data(dict_1, "/a/b/c")

# Generated at 2022-06-25 05:37:35.683731
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0}
    var_0 = playbook_include_0.preprocess_data(dict_0)


# Generated at 2022-06-25 05:37:38.059729
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    playbook_include_1.load_data(ds="some string", basedir="some string")


# Generated at 2022-06-25 05:37:41.302742
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0}
    var_0 = playbook_include_0.load_data(dict_0, 'basedir', 'variable_manager', 'loader')
    assert var_0 is not None, "did not load PlaybookInclude succesfully"


# Generated at 2022-06-25 05:37:52.316886
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0}
    dict_0 = {playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0}
    dict_0 = {playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0}
    var_0 = playbook_include_0.load_data(dict_0, '', None, None)


# Generated at 2022-06-25 05:37:57.229107
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0}
    obj_0 = playbook_include_0.load_data(dict_0, playbook_include_0, playbook_include_0, playbook_include_0)


# Generated at 2022-06-25 05:38:05.203377
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {'vars': dict_0, {'var': var_0, 'var': var_0, 'var': var_0}: dict_0, dict_0: dict_0, {'var': var_0, 'var': var_0, 'var': var_0}: var_0, var_0: {'var': var_0, 'var': var_0, 'var': var_0}, var_0: dict_0, dict_0: {'var': var_0, 'var': var_0, 'var': var_0}, dict_0: var_0, {'var': var_0, 'var': var_0, 'var': var_0}: dict_0, dict_0: dict_0}
    var_0 = playbook_include_

# Generated at 2022-06-25 05:38:21.693366
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # create an instance of class PlaybookInclude
    playbook_include_0 = PlaybookInclude()
    dict_0 = {playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0}
    var_0 = playbook_include_0.preprocess_data(dict_0)

    # load data of PlaybookInclude
    playbook_include_0.load_data(dict_0, "../test/utils/ansible_module_template/module_utils")


# Generated at 2022-06-25 05:38:33.653316
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0}
    dict_1 = {playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0}
    dict_2 = {playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0, playbook_include_0: playbook_include_0}
    var_0 = playbook_include_0.preprocess_data(dict_0)
    var_1 = playbook_include_0.load_data(dict_1, dict_2)

# Generated at 2022-06-25 05:38:42.416995
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude()
    ds_0 = 6
    display_0 = Display()
    basedir_0 = display_0
    var_0 = playbook_include_0.load_data(ds_0, basedir_0)
    playbook_include_1 = PlaybookInclude()
    ds_1 = 6
    display_1 = Display()
    basedir_1 = display_1
    var_1 = playbook_include_1.load_data(ds_1, basedir_1)
    playbook_include_2 = PlaybookInclude()
    ds_2 = 6
    display_2 = Display()
    basedir_2 = display_2

# Generated at 2022-06-25 05:38:47.293788
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    dict_1 = {playbook_include_1: playbook_include_1, playbook_include_1: playbook_include_1, playbook_include_1: playbook_include_1}
    var_1 = playbook_include_1.load_data(dict_1, "dataString")
    return var_1


# Generated at 2022-06-25 05:38:51.456193
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # Load and preprocess_data a set of data to try out
    data = None  # TODO: Put test data here
    results = PlaybookInclude().load_data(data)
    assert(results == None)



# Generated at 2022-06-25 05:38:54.798515
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_1 = PlaybookInclude()
    dict_1 = {playbook_include_1: playbook_include_1, playbook_include_1: playbook_include_1, playbook_include_1: playbook_include_1}
    var_1 = playbook_include_1.preprocess_data(dict_1)

# Generated at 2022-06-25 05:38:56.324893
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    # Assertions
    assert(playbook_include_0.load_data)


# Generated at 2022-06-25 05:39:02.171256
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    dict_1 = {}
    var_1 = playbook_include_1.load_data(ds=dict_1, basedir=None, variable_manager=None, loader=None)
    assert var_1 == None

    # Unit test for method load of class PlaybookInclude

# Generated at 2022-06-25 05:39:08.855623
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {0: 0}
    basedir_0 = dict_0
    dict_0 = dict_0
    var_0 = playbook_include_0.load_data(dict_0, basedir_0, dict_0)
    assert var_0.get_vars() == dict_0


# Generated at 2022-06-25 05:39:12.645378
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    dict_1 = {playbook_include_1: playbook_include_1, playbook_include_1: playbook_include_1, playbook_include_1: playbook_include_1}


# Generated at 2022-06-25 05:39:20.312167
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-25 05:39:27.721875
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include = PlaybookInclude()
    # Put your test logic here.
    # Load data from the ds into this class.
    # In this case, the data is a variable named ds that is defined in the test template.
    var = {}
    var_1 = playbook_include.load_data(var, var, var, var)


# Generated at 2022-06-25 05:39:30.460856
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = {}
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0, var_0)


# Generated at 2022-06-25 05:39:38.716390
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Test entries:
    ds_0 = dict()
    basedir_0 = dict()
    variable_manager_0 = dict()
    loader_0 = dict()
    obj_0 = PlaybookInclude()
    var_0 = obj_0.load_data(ds_0, basedir_0, variable_manager_0, loader_0)

# Generated at 2022-06-25 05:39:46.537723
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = {}
    var_1 = {}
    var_2 = {}
    var_3 = {}
    var_4 = var_1
    var_5 = playbook_include_0.load_data(var_2, var_3, var_4, var_5)
    print(var_5)
    print(var_5)
    print(var_5)
    print(var_5)



# Generated at 2022-06-25 05:39:47.119257
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    assert True == True

# Generated at 2022-06-25 05:39:53.594588
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()

    # NOTE(retr0h): Does not work, parse_kv called on empty string
    #assert playbook_include_0.load_data(var_0, var_0, var_0, var_0) == playbook_0
    return


# Generated at 2022-06-25 05:39:58.994742
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    var_2 = {}
    var_3 = {}
    var_4 = {}
    var_5 = {}
    var_6 = playbook_include_1.load_data(var_2, var_3, var_4, var_5)


# Generated at 2022-06-25 05:40:02.165084
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = {}
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0, var_0)


# Generated at 2022-06-25 05:40:06.356563
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    playbook_include_1 = PlaybookInclude()
    var_42 = {}
    var_43 = playbook_include_1.load_data(var_42, var_42, var_42, var_42)


# Generated at 2022-06-25 05:40:22.046488
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    assert playbook_include_1.load_data(None, None, None, None) is None


# Generated at 2022-06-25 05:40:24.591583
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    var_0 = {}
    var_1 = {}
    var_2 = {}
    var_3 = {}
    var_4 = PlaybookInclude()
    var_5 = var_4.load_data(var_0, var_1, var_2, var_3)


# Generated at 2022-06-25 05:40:26.838439
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude()
    ds_0 = {}
    var_0 = playbook_include_0.preprocess_data(ds_0)
    var_1 = playbook_include_1.preprocess_data(ds_0)

# Generated at 2022-06-25 05:40:28.495947
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = {}
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0, var_0)


# Generated at 2022-06-25 05:40:33.004367
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = {}
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0, var_0)


# Generated at 2022-06-25 05:40:36.721894
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    var_2 = {}
    var_3 = playbook_include_1.load_data(var_2, var_2, var_2, var_2)


# Generated at 2022-06-25 05:40:40.015912
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = {}
    var_1 = playbook_include_0.preprocess_data(var_0)


# Generated at 2022-06-25 05:40:42.425320
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    test_PlaybookInclude_load_data_0()
    test_PlaybookInclude_load_data_1()


# Generated at 2022-06-25 05:40:50.710514
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    playbook_include_0 = PlaybookInclude()

# Generated at 2022-06-25 05:40:55.149869
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    it = PlaybookInclude()
    try:
        it.load_data(dict(), "", "", "")
    except Exception as e:
        assert False



# Generated at 2022-06-25 05:41:39.969561
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # Testing 'when' conditional
    ds = AnsibleMapping()
    ds.update({'when': 'pylint'})
    ds.update({'import_playbook': '../my-collection/my-playbook.yml'})
    ds.update({'tags': 'routing'})
    # Testing properties
    new_ds = AnsibleMapping()
    new_ds.when = 'pylint'
    new_ds.import_playbook = '../my-collection/my-playbook.yml'
    new_ds.tags = 'routing'
    playbook_include_1 = PlaybookInclude()
    var_2 = playbook_include_1.preprocess_data(ds)
    assert var_2 == new_ds

    # Testing 'vars' as dict

# Generated at 2022-06-25 05:41:42.357357
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_2 = {}
    var_3 = playbook_include_0.load_data(var_2, var_2, var_2, var_2)


# Generated at 2022-06-25 05:41:44.672447
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = {}
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0, var_0)


# Generated at 2022-06-25 05:41:49.919476
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    arg0 = {}
    arg1 = {}
    arg2 = {}
    arg3 = {}
    obj = PlaybookInclude()
    result = obj.load_data(arg0, arg1, arg2, arg3)
    assert isinstance(result, object)


# Generated at 2022-06-25 05:41:56.583933
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    try:
        var_0 = {'a': 1, 'b': 2}
        var_1 = PlaybookInclude()
        var_2 = {}
        var_3 = var_1.load_data(var_0, var_2, var_2, var_2)
    except Exception as e:
        print(e)
        raise Exception(
            'Code threw an exception.  Malformed yaml perhaps?  Check the traceback above for errors.')


# Generated at 2022-06-25 05:41:58.943479
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = {}
    playbook_include_0.load_data(var_0, var_0, var_0)


# Generated at 2022-06-25 05:42:01.096142
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # test case 1
    playbook_include_0 = PlaybookInclude()
    var_0 = {}
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0, var_0)


# Generated at 2022-06-25 05:42:05.538937
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = {}
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0, var_0)


# Generated at 2022-06-25 05:42:12.973585
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.data = {'import_playbook': 'examples/import_cp_from_file.yml', 'when': 'ansible_os_family == "Debian"'}
    playbook_include_0.data['import_playbook'] = 'examples/import_cp_from_file.yml'
    playbook_include_0.data['when'] = 'ansible_os_family == "Debian"'
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0, var_0)


# Generated at 2022-06-25 05:42:15.399048
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = {}
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0, var_0)


# Generated at 2022-06-25 05:43:17.950096
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = {}
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0, var_0)
    assert type(var_1) is type(PlaybookInclude().load_data(var_1, var_1, var_0, var_0))


# Generated at 2022-06-25 05:43:24.472373
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Testing a failing case
    playbook_include = PlaybookInclude()
    var_1 = playbook_include.load_data(var_1, var_1, var_2, var_2)

    # Testing a successful case
    playbook_include = PlaybookInclude()
    var_3 = playbook_include.load_data(var_3, var_3, var_4, var_4)


# Generated at 2022-06-25 05:43:26.619855
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = {}
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0, var_0)

# Generated at 2022-06-25 05:43:36.865501
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    data = {}
    basedir = ''
    variable_manager = ''
    loader = ''
    # create the proper input data
    data = {'when': 'some_condition', 'vars': {'var1': 'value1'}, 'tags': 'always', 'import_playbook': 'other-playbook.yml'}
    # create a dummy Loader object to pass in
    loader = DummyLoader()
    # create a dummy variable_manager
    variable_manager = DummyVariableManager()
    # create the PlaybookInclude() object
    PlaybookInclude_0 = PlaybookInclude()
    # verify that calling the load_data() method with the proper input raises not exceptions

# Generated at 2022-06-25 05:43:43.160562
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = {}
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0, var_0)


# Generated at 2022-06-25 05:43:50.978639
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # vars and arguments together
    pbi = PlaybookInclude.load({'import_playbook': 'example.yml', 'vars': {'var1': 'value'}, 'var2': 'value', 'tags': 'tag1,tag2'}, '.')
    assert pbi.vars == {'var1': 'value', 'var2': 'value'}
    assert pbi.tags == ['tag1', 'tag2']
    assert pbi.import_playbook == 'example.yml'
    pbi = PlaybookInclude.load({'import_playbook': 'example.yml var2=value tags=tag1,tag2', 'vars': {'var1': 'value'}}, '.')

# Generated at 2022-06-25 05:43:53.044932
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = {}
    var_1 = playbook_include_0.load_data(var_0, var_0, var_0, var_0)


# Generated at 2022-06-25 05:43:59.917999
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_2 = PlaybookInclude()
    var_2 = {"vars": {"name": "test"}}
    var_3 = {"vars": {"name": "test"}}
    var_4 = playbook_include_2.preprocess_data(var_2)
    assert var_4 == var_3


# Generated at 2022-06-25 05:44:02.618056
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_2 = PlaybookInclude()
    var_2 = {}
    var_3 = playbook_include_2.load_data(var_2, var_2, var_2, var_2)

# Generated at 2022-06-25 05:44:06.976237
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    try:
        test_case_0()
    except (AnsibleParserError, AnsibleAssertionError) as a:
        print("failed: reason:", a)
        raise
