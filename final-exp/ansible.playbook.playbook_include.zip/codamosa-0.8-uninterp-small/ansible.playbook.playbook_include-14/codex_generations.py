

# Generated at 2022-06-25 05:34:38.234206
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    int_0 = 924
    playbook_include_0 = PlaybookInclude()
    ds_0 = {'a': 'b'}
    ansible_mapping_0 = AnsibleMapping()
    playbook_include_0.preprocess_data(ds_0)

# Generated at 2022-06-25 05:34:46.294019
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    int_0 = 924
    playbook_include_0 = PlaybookInclude()
    data_ds = AnsibleMapping()
    playbook_name = 'test_PlaybookInclude_playbook_name'
    basedir_dir_path = 'test_PlaybookInclude_basedir_dir_path'
    int_1 = 772
    variable_manager_manager = VariableManager()
    loader_loader = DataLoader()
    # TODO: Need to resolve this. Many of the classes are not present in this ansible-2.3.2
    # playbook_0 = playbook_include_0.load_data(data_ds, basedir_dir_path, variable_manager_manager, loader_loader)
    # assert_equals(playbook_0.name, playbook_name)
    # assert_equals(playbook_0

# Generated at 2022-06-25 05:34:51.293005
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    int_0 = 924
    playbook_include_0 = PlaybookInclude()
    ds_0 = {'task_include': {}, 'remote_user': 'guest'}
    ds_0['task_include'] = playbook_include_0
    playbook_include_0._preprocess_import(ds_0, ds_0, 'task_include', 'site.yml')
    playbook_include_0.preprocess_data(ds_0)


# Generated at 2022-06-25 05:35:01.955666
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    print('Test load_data of class PlaybookInclude')
    int_0 = 924
    playbook_include_0 = PlaybookInclude()
    int_1 = 818
    ds_0 = AnsibleMapping()
    ds_1 = AnsibleMapping()
    ds_0.ansible_pos = ds_1
    basedir_0 = 476
    variable_manager_0 = ds_0
    loader_0 = ds_0
    print('Test:')
    playbook_include_0.load_data(ds_0, basedir_0, variable_manager=variable_manager_0, loader=loader_0)


# Generated at 2022-06-25 05:35:13.151842
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    int_0 = 924
    playbook_include_0 = PlaybookInclude()
    basedir_0 = '>fh[gO-eQ:ul'
    ds_0 = {'vars': {'A': 'X'}, 'import_playbook': 'f-4&"oZ}zF^nU5'}
    vars_0 = {'d*1': 'ojv_4&'}
    loader_0 = ansible.parsing.dataloader.DataLoader()
    variable_manager_0 = ansible.vars.manager.VariableManager()
    variable_manager_0.extra_vars = vars_0

# Generated at 2022-06-25 05:35:20.363673
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    int_0 = 924
    playbook_include_0 = PlaybookInclude()
    # None and None values are not valid
    try:
        assert playbook_include_0.load_data(ds=None, basedir=None)
    except AnsibleAssertionError as e:
        print("PlaybookInclude load_data error: %s" % type(e))
    # None and None values are not valid
    try:
        assert playbook_include_0.load_data(ds=None, basedir=None)
    except AnsibleAssertionError as e:
        print("PlaybookInclude load_data error: %s" % type(e))


# Generated at 2022-06-25 05:35:27.910311
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()

    # Note, this data structure is not the same as the one normally used
    # to create a PlaybookInclude object, but we want to test the method
    # so this will work
    ds_0 = AnsibleMapping()
    ds_0['import_playbook'] = '/etc/ansible/roles/somedata'
    ds_0['tags'] = 'somevalue'
    playbook_include_0.preprocess_data(ds_0)

# Generated at 2022-06-25 05:35:30.308603
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    int_0 = 924
    playbook_include_0 = PlaybookInclude()


# Generated at 2022-06-25 05:35:39.396621
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # preparing arguments:
    # object ds is of type object
    # object basedir is of type object
    # object variable_manager is of type object
    # object loader is of type object
    ds = ""
    basedir = ""
    variable_manager = ""
    loader = ""
    # return type is of type object
    return_value = None
    # calling load_data method of class PlaybookInclude with arguments:
    # object ds, object basedir, object variable_manager, object loader
    return_value = playbook_include_0.load_data(ds=ds, basedir=basedir, variable_manager=variable_manager, loader=loader)
    # end calling load_data method of class PlaybookInclude


# Generated at 2022-06-25 05:35:41.923169
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    int_0 = 924
    playbook_include_0 = PlaybookInclude()


# Generated at 2022-06-25 05:35:58.513602
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()
    data_0 = {"vars": "test"}
    new_data_0 = playbook_include_0.preprocess_data(data_0)
    assert new_data_0 == {"vars": "test"}
    data_1 = {"import_playbook": "test"}
    new_data_1 = playbook_include_0.preprocess_data(data_1)
    assert new_data_1 == {"import_playbook": "test"}
    data_2 = {"import_playbook": "test", "vars": {"test": "test"}}
    new_data_2 = playbook_include_0.preprocess_data(data_2)
    assert new_data_2 == {"import_playbook": "test", "vars": {"test": "test"}}

# Generated at 2022-06-25 05:36:08.519073
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_0 = PlaybookInclude()
    # This test case is designed for ansible_pos method
    ansible_pos = dict()
    ansible_pos['line'] = 1
    ansible_pos['column'] = 0
    ansible_pos['filename'] = '/home/wzh/Work/Ansible/ansible/lib/ansible/playbook/__init__.py'

    # This test case is designed for ds dict
    ds = dict()
    ds['file'] = 'roles/demo-role/tasks/main.yml'
    ds['when'] = 'ansible_kernel != "Linux"'

    # This test case is designed for new_ds dict
    new_ds = dict()
    new_ds['import_playbook'] = ds['file']

    # This

# Generated at 2022-06-25 05:36:11.670738
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    ds = AnsibleMapping()
    basedir = "/etc/"
    playbook_include_0.load_data(data=ds, basedir=basedir)


# Generated at 2022-06-25 05:36:18.955350
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    """
        Returns a PlaybookInclude object with the data from parameter
        *data* populated into it. The *data* parameter must be a properly
        formatted datastructure to be accepted. This currently means that
        it must be a dict (not a name) and must have a least the key
        *import_playbook* present.
    """
    playbook_include_1 = PlaybookInclude.load(data={}, basedir=os.getcwd())

# Generated at 2022-06-25 05:36:20.770129
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
  playbook_include = PlaybookInclude()
  playbook_include.load_data(ds=[], basedir=None, variable_manager=None, loader=None)


# Generated at 2022-06-25 05:36:22.202734
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass
    # Not implemented


# Generated at 2022-06-25 05:36:26.203199
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()


# Generated at 2022-06-25 05:36:27.908345
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include = PlaybookInclude()
    # test with empty dict
    ds = dict()
    playbook_include.preprocess_data(ds)


# Generated at 2022-06-25 05:36:33.696060
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    playbook_include_1.import_playbook = './path/to/my/playbook.yml'
    playbook_include_1.vars = {'some_var': 'some_value'}
    playbook_include_1.tags = [ 'tag_one' ]

    playbook_include_2 = PlaybookInclude()
    playbook_include_2.import_playbook = './path/to/my/playbook.yml some_var=some_value tags=tag_one'

    playbook_include_3 = PlaybookInclude()
    playbook_include_3.import_playbook = './path/to/my/playbook.yml some_var=some_value tags=tag_one'

# Generated at 2022-06-25 05:36:36.725941
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Integration test for class PlaybookInclude
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Generated at 2022-06-25 05:36:46.953324
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Test the method load_data of class PlaybookInclude with 1 arguments
    # This test case is not implemented yet
    pass


# Generated at 2022-06-25 05:36:54.003046
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(ds=dict_0, basedir=playbook_include_0, variable_manager=None, loader=None)
    print(var_0)


# Generated at 2022-06-25 05:36:56.892774
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load(dict_0, playbook_include_0)


# Generated at 2022-06-25 05:37:03.966878
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_1 = {}
    basedir_1 = string_types()
    variable_manager_1 = VariableManager()
    loader_1 = DataLoader()
    playbook_include_1 = PlaybookInclude()
    var_1 = playbook_include_1.load_data(dict_1, basedir_1, variable_manager_1, loader_1)
# vim:set nospell searchstop=False:

# Generated at 2022-06-25 05:37:06.827080
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    """
    load_data(ds=data, basedir=basedir, variable_manager=variable_manager, loader=loader)
    """
    raise AnsibleParserError("import_playbook parameters cannot be mixed with 'vars' entries for import statements")

# Generated at 2022-06-25 05:37:10.455172
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {u'import_playbook': u'foo.yml', u'vars': {'foo': 'bar'}}

    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load(dict_0, playbook_include_0)


# Generated at 2022-06-25 05:37:17.799720
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Get an instance of PlaybookInclude class
    # PlaybookInclude load_data method using the arguments is not accepted
    # The condition below will evaluate as True only if using named arguments.
    # playbook_include_1 = PlaybookInclude(data=)
    # playbook_include_2 = PlaybookInclude(variable_manager=)
    # playbook_include_3 = PlaybookInclude(loader=)
    playbook_include_4 = PlaybookInclude(ds={}, basedir={})
    playbook_include_5 = PlaybookInclude(ds={}, basedir={}, variable_manager={})
    playbook_include_6 = PlaybookInclude(ds={}, basedir={}, variable_manager={}, loader={})
    # Run method load_data with one or more arguments

# Generated at 2022-06-25 05:37:21.931555
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(ds=dict_0,basedir=playbook_include_0,variable_manager=playbook_include_0)


# Generated at 2022-06-25 05:37:23.396200
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    dict_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load(dict_0, playbook_include_0)


# Generated at 2022-06-25 05:37:28.164322
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # Input
    ds = {}
    basedir = 'path_to_playbook'
    variable_manager = 'variable_manager'
    loader = 'loader'

    # Initialize playbook_include_0
    playbook_include_0 = PlaybookInclude()

    # Invoke method
    var_0 = playbook_include_0.load_data(ds, basedir, variable_manager, loader)


# Generated at 2022-06-25 05:37:39.081397
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    ds = "data structure"
    basedir = "basedir"
    variable_manager = "variable_manager"
    loader = "loader"
    testcase_result = playbook_include_0.load_data(ds, basedir, variable_manager, loader)



# Generated at 2022-06-25 05:37:44.066271
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    data_0 = None
    basedir_0 = None
    variable_manager_0 = None
    loader_0 = None
    try:
        var_0 = playbook_include_0.load_data(data_0, basedir_0, variable_manager_0, loader_0)
    except Exception:
        var_0 = None
    assert var_0 is None, "maybe some exception"


# Generated at 2022-06-25 05:37:50.369263
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()

    dict_0 = {
        "basedir": "",
    }
    if playbook_include_0.load_data(dict_0):
        playbook_include_0.load_data(dict_0)
    else:
        playbook_include_0.load_data(dict_0)


# Generated at 2022-06-25 05:37:53.708798
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.load_data(None, './tests/test_playbook_include.py')


# Generated at 2022-06-25 05:37:57.854881
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {}
    playbook_include_0 = PlaybookInclude()

    # There is a missing element
    try:
        playbook_include_1 = playbook_include_0.load_data(dict_0, playbook_include_0)
    except AnsibleParserError as e:
        assert isinstance(e, AnsibleParserError)


# Generated at 2022-06-25 05:38:00.396689
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Load a pbk_include into a new Playbook object
    dict_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load(dict_0, playbook_include_0)


# Generated at 2022-06-25 05:38:05.018426
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    ds = {}
    basedir = '/home/michael/ansible-playbooks'
    playbook_include_1.load_data(ds, basedir)


# Generated at 2022-06-25 05:38:07.999865
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load(dict_0, playbook_include_0)

# Generated at 2022-06-25 05:38:11.583749
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    x = PlaybookInclude()

    assert definition(PlaybookInclude.load_data) == definition(PlaybookInclude.load_data)

    assert isinstance(x, PlaybookInclude) is True


# Generated at 2022-06-25 05:38:14.671398
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(dict_0, playbook_include_0)


# Generated at 2022-06-25 05:38:21.151757
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(dict_0, playbook_include_0)
# Need to add more tests here


# Generated at 2022-06-25 05:38:26.555436
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    dict_1 = {'k': 'v'}
    var_1 = playbook_include_1.load_data(dict_1, playbook_include_1, playbook_include_1, playbook_include_1)


# Generated at 2022-06-25 05:38:30.329027
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    ds = {}
    basedir = 'ansible-playbook'
    playbook_include_0.load_data(ds, basedir)


# Generated at 2022-06-25 05:38:36.789208
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0_dict = {"x": "~/.ssh/id_rsa.pub", "vars": {"item": "a", "var": "b", "vars": {"item": "a", "var": "b"}}}
    playbook_include_0 = PlaybookInclude()
    var_1 = playbook_include_0.load_data(playbook_include_0_dict, playbook_include_0, playbook_include_0, playbook_include_0)



# Generated at 2022-06-25 05:38:42.252320
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(dict_0, playbook_include_0)


# Generated at 2022-06-25 05:38:52.221632
# Unit test for method load_data of class PlaybookInclude

# Generated at 2022-06-25 05:38:54.967417
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    temp_0 = playbook_include_0.load_data()
    assert temp_0 == None, 'Expected None but got {temp_0} for temp_0'


# Generated at 2022-06-25 05:38:57.189941
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load(dict_0, playbook_include_0)
    assert var_0 is not None


# Generated at 2022-06-25 05:39:02.963226
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    #load() relies on this method to get the job done.
    #This method needs to be tested by itself to ensure proper functionality.
    data = {}
    basedir = '/home/mark/git/ansible/lib/ansible/playbook/__init__.py'
    variable_manager = None
    loader = None
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.load_data(data, basedir, variable_manager, loader)

# Generated at 2022-06-25 05:39:12.007756
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    data = {'playbook': 'playbook.yml',
            'connection': 'local',
            'hosts': 'all'}
    playbook_dir = ""

    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load(data, playbook_include_0)

    if isinstance(var_0, Playbook):
        print("Test 0: PASS: PlaybookInclude.load_data() - returns Playbook object")
    else:
        print("Test 0: FAIL: PlaybookInclude.load_data() - did not return a Playbook object")


# Generated at 2022-06-25 05:39:19.361865
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    return


# Generated at 2022-06-25 05:39:21.879897
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load(dict_0, playbook_include_0)


# Generated at 2022-06-25 05:39:31.726751
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    dict_1 = dict()
    dict_1['vars'] = dict()
    dict_1['vars']['a'] = '1'
    dict_1['vars']['b'] = '2'
    dict_1['import_playbook'] = 'foo.yml'
    dict_1['tags'] = 'foo'
    dict_1['when'] = 'false'
    var_0 = playbook_include_1.load_data(dict_1, 'nowhere')
    print(repr(var_0))
    print(repr(var_0._entries[0]._entries[0]._entries[0]._entries[0]._entries[0]))

# Generated at 2022-06-25 05:39:34.447060
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-25 05:39:38.392847
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(dict_0, playbook_include_0)

# Generated at 2022-06-25 05:39:49.268879
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    global new_obj
    global ds
    global basedir
    global variable_manager_0
    global loader_0
    global pb
    global all_vars
    global entry
    global param_tags
    global templar_0
    global file_name
    global resource_0
    global playbook
    global playbook_collection
    global temp_vars
    global task_block
    new_obj = PlaybookInclude()
    ds = None
    basedir = None
    variable_manager_0 = None
    loader_0 = None

    # Test function invocation

# Generated at 2022-06-25 05:39:52.035221
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {}
    dict_1 = {}
    dict_1['vars'] = dict_0
    dict_1['import_playbook'] = 'foo'
    playbook_include_1 = playbook_include_0.load_data(dict_1, playbook_include_0)


# Generated at 2022-06-25 05:39:58.885910
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # PlaybookInclude.load_data(ds, basedir, variable_manager, loader)

    # main - test_PlaybookInclude_load_data
    # ds (required)
    # basedir (required)
    # variable_manager
    # loader
    pass


# Generated at 2022-06-25 05:40:02.051682
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(dict_0, playbook_include_0, playbook_include_0)


# Generated at 2022-06-25 05:40:10.999220
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    playbook_include_2 = PlaybookInclude()
    playbook_include_3 = PlaybookInclude()
    playbook_include_4 = PlaybookInclude()
    playbook_include_5 = PlaybookInclude()
    playbook_include_6 = PlaybookInclude()
    if (not ((playbook_include_3.load_data(playbook_include_4, playbook_include_5) is None) and (playbook_include_2.load_data(playbook_include_6, playbook_include_0, plugin_loader=playbook_include_1) is None))):
        raise AssertionError("AnsibleAssertionError: ")

# Generated at 2022-06-25 05:40:29.250569
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    dict_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load(dict_0, playbook_include_0)
    assert var_0.entries[0] is Play

# Generated at 2022-06-25 05:40:33.780404
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {}
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = playbook_include_0.load_data(ds = dict_0, basedir = playbook_include_0)


# Generated at 2022-06-25 05:40:40.492946
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load(dict_0, playbook_include_0)
    dict_1 = {}
    dict_1['import_playbook'] = 'test'
    playbook_include_0 = PlaybookInclude()
    var_1 = playbook_include_0.load(dict_1, playbook_include_0)


# Generated at 2022-06-25 05:40:45.759507
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    ds = {}
    basedir = 'tests/'
    variable_manager = None
    loader = 'ansible.parsing.dataloader.DataLoader'
    var_0 = playbook_include_0.load_data(ds, basedir, variable_manager, loader)
    assert playbook_include_0 == var_0


# Generated at 2022-06-25 05:40:49.142675
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {}
    basedir_0 = ""
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = playbook_include_0.load_data(dict_0, basedir_0)
    assert playbook_include_1 is playbook_include_0


# Generated at 2022-06-25 05:40:56.660030
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {}
    basedir_0 = "ansible/playbook/playbook_include.py"
    variable_manager_0 = AnsibleBaseYAMLObject()
    loader_0 = PlaybookInclude()
    playbook_include_0 = PlaybookInclude()
    dict_1 = {}
    templar_0 = Templar(loader_1, variables_0)
    playbook_0 = Playbook(loader_1)
    file_name_0 = templar_0.template(new_obj.import_playbook)
    resource_0 = _get_collection_playbook_path(file_name_0)
    playbook_1 = resource_0[1]
    playbook_collection_0 = resource_0[2]

# Generated at 2022-06-25 05:41:01.530624
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    dict_0 = {}
    playbook_include_0 = PlaybookInclude()
    assert isinstance(playbook_include_0.load_data(dict_0, playbook_include_0), Playbook)
    

# Generated at 2022-06-25 05:41:05.133840
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    playbook_include_1.load_data(ds={'import_playbook': 'playbook.yaml',
                                     'vars':{'a': 1, 'b': 2}},
                                 basedir='.')


# Generated at 2022-06-25 05:41:07.956897
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    print("unit test for method load_data of class PlaybookInclude")
    # TODO: some weird bug in this test
    # dict_0 = {}
    # playbook_include_0 = PlaybookInclude()
    # var_0 = playbook_include_0.load_data(dict_0, playbook_include_0)


# Generated at 2022-06-25 05:41:09.497955
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data({}, playbook_include_0)


# Generated at 2022-06-25 05:41:34.483830
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {}
    playbook_include_0 = PlaybookInclude()
    playbook_include_1 = PlaybookInclude()
    var_0 = playbook_include_0.load(dict_0, playbook_include_0)
    var_1 = playbook_include_1.load_data(dict_0, playbook_include_0)


# Generated at 2022-06-25 05:41:38.641585
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {}
    playbook_include_0 = PlaybookInclude()
    try:
        var_0 = playbook_include_0.load_data(dict_0, playbook_include_0, playbook_include_0, playbook_include_0)
    except Exception as exception_0:
        display.display("Exception expected: {0}".format(exception_0))

# Generated at 2022-06-25 05:41:45.520709
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {
        'import_playbook': '$test_path/test.yml',
        'tags': '$test_tags',
        'when': '$test_when',
        'vars': dict()
    }
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(ds=dict_0, basedir='./test/data/test_tasks', variable_manager=None, loader=None)
    assert var_0._entries[0].vars == {}
    assert var_0._entries[1].vars == {}
    assert var_0._entries[0].tags == ['test_tags']
    assert var_0._entries[1].tags == ['test_tags']

# Generated at 2022-06-25 05:41:49.222302
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_1 = PlaybookInclude()
    dict_0 = {}
    playbook_include_1.load_data(dict_0, playbook_include_1)


# Generated at 2022-06-25 05:41:57.494331
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Test case.
    dict_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load(dict_0, playbook_include_0)
    # Test case.
    dict_1 = {}
    playbook_include_1 = PlaybookInclude()
    var_1 = playbook_include_1.load(dict_0, playbook_include_1)
    # Test case.
    dict_2 = {}
    playbook_include_2 = PlaybookInclude()
    var_2 = playbook_include_2.load(dict_0, playbook_include_2)


# Generated at 2022-06-25 05:42:03.920392
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pb = PlaybookInclude()
    playbook_path = os.path.realpath('test')
    playbook_include = pb.load_data(ds={
        'vars': {
            'var_1': 'val_1',
            'var_2': 'val_2'
        },
        'import_playbook': 'test/test.yml',
        'name': 'test',
        'tags': [
            'tag_1',
            'tag_2'
        ],
    },
                                    basedir=playbook_path,
                                    variable_manager=None,
                                    loader=None)

    assert playbook_include.tasks[0].get_name() == 'debug'

# Generated at 2022-06-25 05:42:13.707882
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Loading 'cs)'
    global basedir
    basedir = None
    playbook_include_1 = PlaybookInclude()
    dict_1 = {'import_playbook': 'cs)', 'vars': {'repository_url': 'git://github.com/ansible/ansible.git'}}
    with pytest.raises(AnsibleParserError) as exec_info:
        playbook_include_1.load_data(ds=dict_1, basedir=basedir, variable_manager=None, loader=None)
    assert 'playbook import parameter must be a string indicating a file path, got NoneType instead' in str(exec_info.value)


# Generated at 2022-06-25 05:42:14.227766
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    test_case_0()


# Generated at 2022-06-25 05:42:16.002657
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    
    dict_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load(dict_0, playbook_include_0)



# Generated at 2022-06-25 05:42:18.709882
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {}
    playbook_include_0 = PlaybookInclude()
    with pytest.raises(AnsibleAssertionError) as err:
        playbook_include_0.load_data(ds=dict_0, basedir=playbook_include_0)
    assert err.value.args[0] == 'ds () should be a dict but was a '


# Generated at 2022-06-25 05:42:41.213568
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load(dict_0, playbook_include_0)
    # test method call with valid argument data set
    assert var_0 is None



# Generated at 2022-06-25 05:42:44.300888
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load(dict_0, playbook_include_0)


# Generated at 2022-06-25 05:42:46.465670
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # Setup the test
    dict_0 = {}
    playbook_include_0 = PlaybookInclude()

    # Test the load_data method
    playbook_include_0.load_data(dict_0, playbook_include_0)


# Generated at 2022-06-25 05:42:52.459982
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    pb = Playbook()

    path = os.path.join(os.path.dirname(__file__), '../../unit/playbooks/playbook_include.yml')
    pb._entries.append(PlaybookInclude().load(ds=dict(import_playbook=path), basedir=os.path.dirname(path)))
    pb._entries.append(PlaybookInclude().load(ds=dict(import_playbook=path), basedir=os.path.dirname(path)))

    assert len(pb._entries) == 2
    assert isinstance(pb._entries[0], Playbook)
    assert isinstance(pb._entries[1], Play)

# Generated at 2022-06-25 05:42:53.503205
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    test_case_0()

# Generated at 2022-06-25 05:42:54.422033
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-25 05:43:02.427516
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    dict_0 = {}
    playbook_include_0 = PlaybookInclude()
    playbook_include_0.import_playbook = 'test_string'
    playbook_include_0.vars = 'test_value'
    print(playbook_include_0.import_playbook)
    print(playbook_include_0.vars)
    playbook_include_0.import_playbook = 'test_string'
    playbook_include_0.vars = 'test_value'
    print(playbook_include_0.import_playbook)
    print(playbook_include_0.vars)
    playbook_include_0.import_playbook = 'test_string'
    playbook_include_0.vars = 'test_value'
    print(playbook_include_0.import_playbook)
   

# Generated at 2022-06-25 05:43:07.007459
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # Test the following parameters:
    # basename, basedir, all_vars, vars, file_name, pb, entry, temp_vars, param_tags
    # Return type is AnsiblePlaybookCollection:
    # Test with playbook parser, call with dict_0 as input
    playbook_include_0 = PlaybookInclude()
    dict_0 = {}
    playbook_include_0.load(dict_0, playbook_include_0)


# Generated at 2022-06-25 05:43:17.335709
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    playbook_include_0 = PlaybookInclude()
    variable_manager_0 = variable_manager_0 = variable_manager_0 = variable_manager_0 = variable_manager_0 = variable_manager_0
    loader_0 = loader_0
    ds_0 = {}
    basedir_0 = basedir_0
    var_0 = playbook_include_0.load_data(ds_0, basedir_0, variable_manager_0, loader_0)
    field_0 = var_0.module_vars
    field_1 = var_0.basedir
    field_2 = var_0.extra_vars
    field_3 = var_0._playbook_dir
    field_4 = var_0._

# Generated at 2022-06-25 05:43:22.796082
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # This test is going to be skipped due to the function throws an exception
    # directly rather than returning a value.
    # assert playbook_include_0.load_data() == expected_result
    raise ValueError("Test is currently not implemented")

# Generated at 2022-06-25 05:43:36.085140
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include = PlaybookInclude()
    ds = {'var1': 1, 'var2': 2}
    basedir = '/'
    playbook_include.load_data(ds, basedir)



# Generated at 2022-06-25 05:43:37.359339
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    pass # could not find test data



# Generated at 2022-06-25 05:43:43.436450
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {}
    basedir_0 = '/etc/ansible'
    assert playbook_include_0.load_data(ds=dict_0, basedir=basedir_0)


# Generated at 2022-06-25 05:43:51.005691
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = dict({u'import_playbook': u'C:\something.yml'})
    playbook_include_0 = PlaybookInclude()
    playbook_1 = playbook_include_0.load_data(dict_0, u'C:\\Users\\hongkliu\\projects\\ansible')
    assert playbook_1.__class__.__name__ == 'Playbook'
    assert playbook_1._entries[0].name == 'My play name'
    playbook_1._entries[0].name = 'My play name'


# Generated at 2022-06-25 05:43:52.507054
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()
    dict_0 = {}
    var_0 = playbook_include_0.load(dict_0, playbook_include_0)

# Generated at 2022-06-25 05:43:54.165947
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = {}
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load_data(dict_0, playbook_include_0)


# Generated at 2022-06-25 05:43:54.921907
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include_0 = PlaybookInclude()


# Generated at 2022-06-25 05:43:56.573507
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    """
    Test load_data method of PlaybookInclude
    """
    # TODO: Ansible-2.10: test_PlaybookInclude_load_data
    pass


# Generated at 2022-06-25 05:44:01.077128
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    dict_0 = dict(
        host_pattern='localhost',
        roles=['common'],
        tags=['tag_one'],
        vars=dict(
            var_one=1,
            var_two='two'
        )
    )
    playbook_include_0 = PlaybookInclude()
    var_0 = playbook_include_0.load(dict_0, playbook_include_0)


# Generated at 2022-06-25 05:44:11.020032
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import_playbook_0 = "import_playbook.yaml"
    basedir_0 = "/var/log/ansible/YAML"
    playbook_include_0 = PlaybookInclude()

    # Case 0
    var_0 = playbook_include_0.load_data(basedir_0, import_playbook_0, playbook_include_0)

    # Case 1
    var_0 = playbook_include_0.load_data("test_case_1", basedir_0, "test_case_1", playbook_include_0)

    # Case 2
    var_0 = playbook_include_0.load_data("test_case_2", import_playbook_0, basedir_0, "test_case_2")
