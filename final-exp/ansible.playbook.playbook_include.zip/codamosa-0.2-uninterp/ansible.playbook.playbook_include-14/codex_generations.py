

# Generated at 2022-06-17 07:46:32.141852
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude

    # test 1: load_data with a simple playbook
    ds = dict(
        import_playbook='test_playbook.yml',
        tags=['tag1', 'tag2'],
        vars=dict(
            var1='value1',
            var2='value2',
        ),
    )
    pb = PlaybookInclude.load(ds, '.')
    assert isinstance(pb, Playbook)

# Generated at 2022-06-17 07:46:44.184900
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-17 07:46:51.594448
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Test with a simple playbook include
    ds = dict(import_playbook='test.yml')
    pbi = PlaybookInclude()
    new_ds = pbi.preprocess_data(ds)
    assert new_ds == dict(import_playbook='test.yml')

    # Test with a playbook include with vars
    ds = dict(import_playbook='test.yml', vars=dict(a=1, b=2))
    pbi = PlaybookInclude()
    new_ds = pbi.preprocess_data(ds)
    assert new_ds == dict(import_playbook='test.yml', vars=dict(a=1, b=2))

    # Test with a playbook include with vars and tags

# Generated at 2022-06-17 07:47:03.016578
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Test with a simple string
    ds = 'test.yml'
    new_ds = PlaybookInclude.preprocess_data(ds)
    assert new_ds['import_playbook'] == 'test.yml'

    # Test with a string with parameters
    ds = 'test.yml var1=value1 var2=value2'
    new_ds = PlaybookInclude.preprocess_data(ds)
    assert new_ds['import_playbook'] == 'test.yml'
    assert new_ds['vars']['var1'] == 'value1'
    assert new_ds['vars']['var2'] == 'value2'

    # Test with a dict with parameters

# Generated at 2022-06-17 07:47:12.261937
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.tasks import TaskInclude
    from ansible.playbook.role.defaults import RoleDefault
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.role.vars import RoleVariable
    from ansible.playbook.role.task_defaults import TaskDefault
    from ansible.playbook.role.task_vars import TaskVariable

# Generated at 2022-06-17 07:47:22.201253
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block_include import BlockInclude
    from ansible.playbook.handler_include import HandlerInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.conditional import Cond

# Generated at 2022-06-17 07:47:29.069367
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.collection_loader import AnsibleCollectionConfig

# Generated at 2022-06-17 07:47:40.722874
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable

    # test for import_playbook
    ds = AnsibleMapping()
    ds['import_playbook'] = 'test.yml'
    ds

# Generated at 2022-06-17 07:47:51.924574
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block_include import BlockInclude
    from ansible.playbook.playbook_include import PlaybookInclude

    # Test preprocess_data for PlaybookInclude
    #
    # PlaybookInclude.preprocess_data() should return a new AnsibleMapping object
    # with the same keys as the original AnsibleMapping object, but

# Generated at 2022-06-17 07:47:58.792661
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.playbook.play import Play

    # Test with a simple string
    data = """
    - import_playbook: test.yml
    """
    ds = AnsibleLoader(data, yaml_loader=yaml.Loader).get_single_data()
    new_ds = PlaybookInclude.preprocess_data(ds[0])
    assert new_ds == {'import_playbook': 'test.yml'}

    # Test with a string with additional parameters

# Generated at 2022-06-17 07:48:15.646845
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base
    from ansible.playbook.play_context import PlayContext

# Generated at 2022-06-17 07:48:27.995314
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager


# Generated at 2022-06-17 07:48:34.061322
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # Test case 1: import_playbook with no parameters
    ds = dict(
        import_playbook='test_playbook.yml'
    )
    basedir = '/path/to/playbook'
    pb = PlaybookInclude.load(ds, basedir)
    assert isinstance(pb, Playbook)

# Generated at 2022-06-17 07:48:43.870808
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # create a playbook include object
    pbi = PlaybookInclude()
    # create a playbook object
    pb = Playbook()

    # create a play object
    play = Play()
    play.name = "test play"
    play.hosts = "all"
    play.tasks = [Task()]


# Generated at 2022-06-17 07:48:54.325243
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # Test load_data with a simple playbook
    ds = dict(
        import_playbook='test_playbook.yml',
        vars=dict(
            var1='value1',
            var2='value2',
        ),
        tags=['tag1', 'tag2'],
    )
    basedir = '.'
    variable_manager = None

# Generated at 2022-06-17 07:49:03.487464
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block_include import BlockInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import IncludeTask
    from ansible.playbook.block_include import IncludeBlock
    from ansible.playbook.handler_task_include import IncludeHandler

# Generated at 2022-06-17 07:49:13.134260
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block_include import BlockInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base

# Generated at 2022-06-17 07:49:22.676818
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-17 07:49:29.109468
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    variable_manager

# Generated at 2022-06-17 07:49:41.782529
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.handler.include import HandlerInclude
    from ansible.playbook.task.action import Action
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.task.block import Block
    from ansible.playbook.task.handler_task import HandlerTask
    from ansible.playbook.task.task import Task

# Generated at 2022-06-17 07:50:00.022049
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable

    # Test load_data with a simple playbook

# Generated at 2022-06-17 07:50:07.121348
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-17 07:50:17.237780
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude

    # create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # create a Playbook object
    playbook = Playbook()

    # create a Play object
    play = Play()
    play.name = "test_play"
    play.hosts = "test_hosts"
    play.vars = dict(var1 = "value1", var2 = "value2")

# Generated at 2022-06-17 07:50:30.540967
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.base import Base

    # Test PlaybookInclude class
    assert issubclass

# Generated at 2022-06-17 07:50:43.068194
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager


# Generated at 2022-06-17 07:50:54.108886
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block_include import BlockInclude
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute


# Generated at 2022-06-17 07:51:00.042717
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # Test playbook include with no parameters
    ds = dict(
        import_playbook='test.yml',
    )
    basedir = '.'
    pb_include = PlaybookInclude.load(ds, basedir)
    assert isinstance(pb_include, Playbook)

# Generated at 2022-06-17 07:51:09.494225
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    # Test with a simple playbook
    pb = PlaybookInclude.load(
        data={'import_playbook': 'test.yml'},
        basedir='/tmp/',
        variable_manager=None,
        loader=None
    )
    assert isinstance(pb, Play)
    assert len(pb.tasks) == 1
    assert isinstance(pb.tasks[0], Task)
    assert pb.tasks[0].action == 'debug'
    assert pb.tasks[0].args['msg'] == 'Hello world!'

    # Test with a playbook with a block
    pb = Playbook

# Generated at 2022-06-17 07:51:22.053711
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    # Create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # Create a Playbook object
    playbook = Playbook()

    # Create a Play object
    play = Play()

    # Create a dict object
    ds = dict()

    # Create a variable manager object
    variable_manager = None

    # Create a loader object
    loader = None

    # Create a basedir object
    basedir = None

    # Call the load_data method of PlaybookInclude
    playbook_include.load_data(ds, basedir, variable_manager, loader)

    # Call the load_data method of PlaybookInclude with a Playbook object

# Generated at 2022-06-17 07:51:30.643013
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.base import Base
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play_context import PlayContext

# Generated at 2022-06-17 07:51:40.986202
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude

    # create a playbook include object
    pbi = PlaybookInclude()

    # create a playbook object
    pb = Playbook()

    # create a play object
    play = Play()

    # create a task object
    task = Task()

    # create a block object
    block = Block()

    # create a role object
    role = Role()

    # create a handler object
    handler = Handler

# Generated at 2022-06-17 07:51:53.310292
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become_prompt import BecomePrompt
    from ansible.playbook.task_fail import TaskFail
    from ansible.playbook.task_debug import TaskDebug

# Generated at 2022-06-17 07:52:02.173289
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # Test 1: test_PlaybookInclude_load_data_1
    # Test 2: test_PlaybookInclude_load_data_2
    # Test 3: test_PlaybookInclude_load_data_3
    # Test 4: test_PlaybookInclude_load_data_4
    # Test 5:

# Generated at 2022-06-17 07:52:13.639496
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base
   

# Generated at 2022-06-17 07:52:25.475192
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-17 07:52:33.548706
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor

# Generated at 2022-06-17 07:52:44.420354
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    # Create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # Create a Playbook object
    from ansible.playbook import Playbook
    playbook = Playbook()

    # Create a Play object
    play = Play()

    # Create a Task object
    task = Task()

    # Create a Block object
    block = Block()

    # Create a Role object
    role = Role()

    # Create a variable manager object
    from ansible.vars.manager import VariableManager
    variable_manager = VariableManager()

    # Create a loader object
    from ansible.parsing.dataloader import Data

# Generated at 2022-06-17 07:52:53.158003
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # create a PlaybookInclude object
    pbi = PlaybookInclude()

    # create a Playbook object
    from ansible.playbook import Playbook
    pb = Playbook()

    # create a Play object
    play = Play()

    # create a Task object
    task = Task()

    # create a Block object
    block = Block()

    #

# Generated at 2022-06-17 07:53:01.390179
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    # test playbook include
    playbook_include

# Generated at 2022-06-17 07:53:10.280737
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-17 07:53:28.723035
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.collection_loader._collection_finder import _get_collection_name_from_path, _get_collection_playbook_path

    # setup the test data

# Generated at 2022-06-17 07:53:41.707733
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.base import Base
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.playbook import Playbook
    from ansible.template import Templar

# Generated at 2022-06-17 07:53:49.755673
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleMapping

# Generated at 2022-06-17 07:54:02.362002
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.playbook import Playbook

    # Test PlaybookInclude.load_data()
    #
    # Test PlaybookInclude.load_data() with a simple playbook
    #
    # Setup

# Generated at 2022-06-17 07:54:12.306093
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # Test with a simple playbook
    playbook_include = PlaybookInclude()
    playbook = playbook_include.load_data(ds='test/test_playbook_include.yml', basedir='test/')
    assert isinstance(playbook, Playbook)

# Generated at 2022-06-17 07:54:21.160013
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    # Create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # Create a Playbook object
    playbook = Playbook()

    # Create a Play object
    play = Play()

    # Create a dict
    ds = dict()

    # Create a variable manager object
    variable_manager = None

    # Create a loader object
    loader = None

    # Create a basedir object
    basedir = None

    # Test load_data method
    playbook_include.load_data(ds, basedir, variable_manager, loader)

    # Test load_data method with a Playbook object
    playbook_include.load_data(playbook, basedir, variable_manager, loader)

    # Test load_data method with a

# Generated at 2022-06-17 07:54:26.466565
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # Create a Playbook object
    playbook = Playbook()

    # Create a Play object
    play = Play

# Generated at 2022-06-17 07:54:37.374368
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude

    # Create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # Create a Playbook object

# Generated at 2022-06-17 07:54:44.975420
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    # Create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # Create a Playbook object
    from ansible.playbook import Playbook
    playbook = Playbook()

    # Create a Play object
    play = Play()

    # Create a Task object
    task = Task()

    # Create a Block object
    block = Block()

    # Create a variable manager object
    from ansible.vars.manager import VariableManager
    variable_manager = VariableManager()

    # Create a loader object
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()

    # Create a variable manager object

# Generated at 2022-06-17 07:54:57.039009
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-17 07:55:23.269239
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude

    # create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # create a Playbook object
    playbook = Playbook()

    # create a Play object
    play = Play()

    # create a Task object
    task = Task()

    # create a Block object
    block = Block()

    # create a Role object
    role = Role()

    # create a Handler object
   

# Generated at 2022-06-17 07:55:34.964223
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # Test 1:
    # Test case for playbook include with no parameters
    #
    # Expected result:
    #   - playbook include object with no parameters
    #   - playbook object with one play
    #   - play object with one task
    #   - task object with one handler
    #   - handler object with one handler

# Generated at 2022-06-17 07:55:42.211333
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

# Generated at 2022-06-17 07:55:53.342653
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject


# Generated at 2022-06-17 07:56:00.557397
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play

    # Create a PlaybookInclude object
    pbi = PlaybookInclude()

    # Create a Playbook object
    from ansible.playbook import Playbook
    pb = Playbook()

    # Create a Play object
    p = Play()

    # Create a variable manager
    from ansible.vars.manager import VariableManager
    variable_manager = VariableManager()

    # Create a loader
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()

    # Create a basedir
    basedir = '.'

    # Create a data structure

# Generated at 2022-06-17 07:56:13.707611
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block_include import BlockInclude
    from ansible.playbook.playbook_include import PlaybookInclude

    # Test load_data with a simple playbook
    playbook_include = PlaybookInclude()
    playbook_include.import_playbook = "./test/test_playbook_include_load_data.yml"
    playbook_