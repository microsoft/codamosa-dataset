

# Generated at 2022-06-17 07:46:28.233645
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.collection_loader import Ans

# Generated at 2022-06-17 07:46:36.706068
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler

    # Test with a simple playbook
    ds = dict(
        import_playbook='test.yml',
        vars=dict(
            var1='value1',
            var2='value2',
        ),
        tags=['tag1', 'tag2'],
    )
    pb = PlaybookInclude.load(ds, '.')
    assert isinstance(pb, Playbook)
    assert len(pb._entries) == 1
    assert isinstance(pb._entries[0], Play)
    assert pb._entries[0].name == 'test'

# Generated at 2022-06-17 07:46:47.088306
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext

# Generated at 2022-06-17 07:47:01.161637
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude

    # Test for import_playbook
    ds = dict(
        import_playbook='playbook.yml',
        vars=dict(
            a=1,
            b=2,
        ),
        tags=['tag1', 'tag2'],
    )
    new_ds = PlaybookInclude.preprocess_data(ds)

# Generated at 2022-06-17 07:47:10.830397
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.reserved import Reserved

# Generated at 2022-06-17 07:47:17.067676
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.collection_loader._collection_finder import _get_collection_name_from_path, _get_collection_playbook_path

    # Setup the default collection paths
    AnsibleCollectionConfig.playbook_paths = [os.path.join(os.path.dirname(__file__), 'data', 'collections')]

    # Test with a collection playbook

# Generated at 2022-06-17 07:47:25.564775
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # Test with a simple playbook
    ds = dict(
        import_playbook='test_playbook.yml',
        vars=dict(
            var1='value1',
            var2='value2',
        ),
        tags=['tag1', 'tag2'],
    )
    pb = PlaybookInclude.load(ds, '.')

# Generated at 2022-06-17 07:47:31.339613
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become_prompt import BecomePrompt
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude

# Generated at 2022-06-17 07:47:42.654750
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.playbook import Playbook

    # test load_data of class PlaybookInclude
    # test load_data of class PlaybookInclude with a playbook with a task

# Generated at 2022-06-17 07:47:47.040846
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # Test 1: Test a simple playbook include
    ds = dict(
        import_playbook = 'test_playbook.yml',
        tags = 'test_tag',
        vars = dict(
            test_var = 'test_value'
        )
    )
    pb = PlaybookInclude.load

# Generated at 2022-06-17 07:48:01.249845
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base
    from ansible.playbook.playbook_include import PlaybookInclude


# Generated at 2022-06-17 07:48:13.419901
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude

# Generated at 2022-06-17 07:48:26.253493
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # Test with a simple playbook
    playbook_include = PlaybookInclude()
    ds = {'import_playbook': 'test.yml'}
    new_ds = playbook_include.preprocess_data(ds)
    assert new_ds == ds

    # Test with a playbook with parameters
    playbook_include = PlaybookInclude()

# Generated at 2022-06-17 07:48:38.427746
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.role.task import Task as RoleTask
    from ansible.playbook.role.defaults import RoleDefaults
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.role.tasks import Tasks
    from ansible.playbook.role.handlers import Handlers

# Generated at 2022-06-17 07:48:43.017405
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-17 07:48:53.905289
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-17 07:49:03.459681
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler_include import HandlerInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play_context import PlayContext

# Generated at 2022-06-17 07:49:13.099711
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    # test with a simple string
    ds = AnsibleLoader(None, None).load('''
    - import_playbook: test.yml
    ''')[0]
    assert isinstance(ds, AnsibleMapping)
    assert len(ds) == 1
    assert ds['import_playbook'] == 'test.yml'

    # test with a string with parameters
    ds = AnsibleLoader(None, None).load('''
    - import_playbook: test.yml tags=foo,bar vars:
        foo: bar
    ''')[0]
    assert isinstance(ds, AnsibleMapping)

# Generated at 2022-06-17 07:49:21.944789
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-17 07:49:30.948623
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.playbook_include import PlaybookInclude

    # Test case 1:
    #   - import_playbook: test1.yml
    #   - import_playbook: test2.yml
    #   - import_playbook: test3.yml
    #   - import_playbook: test4.yml
    #   - import_playbook: test5.yml
    #   - import_play

# Generated at 2022-06-17 07:49:46.048227
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base
    from ansible.parsing.yaml.objects import AnsibleMapping

# Generated at 2022-06-17 07:50:00.950032
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.playbook_include import PlaybookInclude

    # Test with a simple string
    ds = AnsibleMapping(data={'import_playbook': 'test.yml'})
    new_ds = PlaybookInclude.preprocess_data(ds)
    assert new_ds == {'import_playbook': 'test.yml'}

    # Test with a string and a parameter
    ds = AnsibleMapping(data={'import_playbook': 'test.yml with_items=foo'})
    new_ds = PlaybookInclude.preprocess_data(ds)

# Generated at 2022-06-17 07:50:14.723349
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.template import Templar

    # Test with a simple playbook include
    ds = AnsibleMapping()
    ds['import_playbook'] = 'test.yml'
    ds['tags'] = 'tag1'
    ds['vars'] = {'var1': 'value1'}
    ds['when'] = 'var1 == "value1"'
    ds['ignore_errors'] = True
    ds['register'] = 'result'
    ds['delegate_to'] = 'localhost'
    ds['run_once'] = True
    ds['connection'] = 'local'
    ds['remote_user'] = 'root'

# Generated at 2022-06-17 07:50:29.508076
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block_include import BlockInclude
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable

# Generated at 2022-06-17 07:50:39.062851
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    # Create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # Create a Playbook object
    playbook = Playbook()

    # Create a Play object
    play = Play()

    # Create a dict
    ds = dict()

    # Create a variable manager
    variable_manager = None

    # Create a loader
    loader = None

    # Create a basedir
    basedir = None

    # Create a dict
    ds = dict()

    # Create a dict
    ds['import_playbook'] = 'playbook.yml'

    # Create a dict
    ds['vars'] = dict()

    # Create a dict

# Generated at 2022-06-17 07:50:51.971503
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    # create a variable manager
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set

# Generated at 2022-06-17 07:51:03.123484
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude

    # Test for PlaybookInclude
    ds = dict(
        import_playbook='/path/to/playbook.yml',
        tags=['tag1', 'tag2'],
        vars=dict(
            foo='bar',
            baz='qux',
        ),
    )
    new_ds = PlaybookInclude.preprocess_data(ds)

# Generated at 2022-06-17 07:51:11.899067
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute

    class MockVariableManager:
        def __init__(self):
            self.vars = dict()


# Generated at 2022-06-17 07:51:23.202903
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    # Create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # Create a Playbook object
    playbook = Playbook()

    # Create a Play object
    play = Play()

    # Create a Task object
    task = Task()

    # Create a Block object
    block = Block()

    # Create a list of tasks
    tasks = [task, block]

    # Create a list of plays
    plays = [play]

    # Create a list of entries
    entries = [play, task, block]

    # Create a list of tags
    tags = ['tag1', 'tag2']

    # Create a list of variables

# Generated at 2022-06-17 07:51:30.945845
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.tasks import Tasks
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.role.defaults import RoleDefaults

# Generated at 2022-06-17 07:51:43.890764
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject


# Generated at 2022-06-17 07:51:51.194876
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude

    # Create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # Create a Playbook object
    playbook = playbook_include.load_data(ds={'import_playbook': 'test_playbook.yml'}, basedir='/tmp')

    # Check the type of the playbook
    assert isinstance(playbook, Playbook)

    # Check the number of entries in the playbook
    assert len(playbook._entries)

# Generated at 2022-06-17 07:52:00.411927
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable

    # Test PlaybookInclude.load_data()
    #
    # Test 1:
    #   PlaybookInclude.load_data() should return a Playbook object
    #   containing a Play object
    #
    # Test 2:


# Generated at 2022-06-17 07:52:11.842650
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.base import Base

    assert issubclass(PlaybookInclude, Base)


# Generated at 2022-06-17 07:52:24.053793
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

# Generated at 2022-06-17 07:52:32.830159
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # Create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # Create a Playbook object
    from ansible.playbook import Playbook
    playbook = Playbook()

    # Create a Play object
    play = Play()

    # Create a TaskInclude object
    task_include = TaskInclude()

    # Create a Block object
    block = Block()

    # Create a RoleInclude object
    role_include = RoleInclude()

    # Create a HandlerTaskInclude object
    handler_

# Generated at 2022-06-17 07:52:43.443671
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    # Create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # Create a Playbook object
    playbook = Playbook()

    # Create a Play object
    play = Play()

    # Create a PlaybookInclude object
    playbook_include_2 = PlaybookInclude()

    # Create a Playbook object
    playbook_2 = Playbook()

    # Create a Play object
    play_2 = Play()

    # Create a PlaybookInclude object
    playbook_include_3 = PlaybookInclude()

    # Create a Playbook object
    playbook_3 = Playbook()

    # Create a Play object
    play_3 = Play()

    # Create a PlaybookInclude object
    playbook_include

# Generated at 2022-06-17 07:52:45.594341
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-17 07:52:53.284507
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-17 07:52:54.307107
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 07:53:08.476847
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    # Create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # Create a Playbook object
    playbook = Playbook()

    # Create a Play object
    play = Play()

    # Create a Task object
    task = Task()

    # Create a Block object
    block = Block()

    # Create a Role object
    role = Role()

    # Create a dict object
    ds = dict()

    # Create a dict object
    ds1 = dict()

    # Create a dict object
    ds2 = dict()

    # Create a dict object
   

# Generated at 2022-06-17 07:53:17.669312
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-17 07:53:26.176418
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude

    # test for simple playbook include
    ds = dict(
        import_playbook='test_playbook.yml',
    )
    pbi = PlaybookInclude()
    new_ds = pbi.preprocess_data(ds)
    assert new_ds == dict(
        import_playbook='test_playbook.yml',
    )

    # test for playbook include with vars

# Generated at 2022-06-17 07:53:38.562127
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable

    # Test PlaybookInclude.preprocess_data()
    # Test with a simple playbook
    playbook_include = PlaybookInclude()

# Generated at 2022-06-17 07:53:47.161900
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager


# Generated at 2022-06-17 07:54:00.246011
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    # create a playbook include object
    playbook_include = PlaybookInclude()

    # create a playbook object
    playbook = Playbook()

    # create a play object
    play = Play()

    # create a variable manager object
    variable_manager = None

    # create a loader object
    loader = None

    # create a basedir object
    basedir = None

    # create a data structure
    ds = dict()

    # create a new object
    new_obj = playbook_include.load_data(ds, basedir, variable_manager, loader)

    # check the new object
    assert new_obj == playbook

    # create a new object

# Generated at 2022-06-17 07:54:12.114566
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block_include import BlockInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.base import Base
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-17 07:54:25.732746
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # Test PlaybookInclude.load_data() with a playbook that contains a play,
    # a task, a block, a role, a handler, a task include, a role include, and
    # a handler task include.

# Generated at 2022-06-17 07:54:36.518642
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.playbook.playbook_include import PlaybookInclude

    # test data
    data = AnsibleMapping()
    data['import_playbook'] = 'test.yml'
    data['vars'] = AnsibleMapping()
    data['vars']['var1'] = 'value1'
    data['vars']['var2'] = 'value2'
    data['tags'] = 'tag1,tag2'
    data['when'] = 'var1 == value1'

    # test preprocess_data
    result = PlaybookInclude.preprocess_

# Generated at 2022-06-17 07:54:44.240383
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar

# Generated at 2022-06-17 07:55:08.590902
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Test with a simple playbook include
    ds = {'import_playbook': 'test.yml'}
    new_ds = PlaybookInclude.preprocess_data(ds)
    assert new_ds == {'import_playbook': 'test.yml'}

    # Test with a playbook include with a variable
    ds = {'import_playbook': 'test.yml', 'vars': {'var1': 'value1'}}
    new_ds = PlaybookInclude.preprocess_data(ds)
    assert new_ds == {'import_playbook': 'test.yml', 'vars': {'var1': 'value1'}}

    # Test with a playbook include with a variable and a tag

# Generated at 2022-06-17 07:55:17.022596
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.playbook.playbook_include import PlaybookInclude

    # Test data
    data = """
    - import_playbook: test.yml
      vars:
        var1: value1
        var2: value2
    """
    data_result = """
    - import_playbook: test.yml
      vars:
        var1: value1
        var2: value2
    """

    # Test code
    data_yaml = AnsibleLoader(data, yaml_loader=yaml.SafeLoader).get_single_data()
    data_result

# Generated at 2022-06-17 07:55:27.880089
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    - import_playbook: test.yml
    - import_playbook: test.yml tags=foo,bar
    - import_playbook: test.yml vars:
        foo: bar
    - import_playbook: test.yml tags=foo,bar vars:
        foo: bar
    - import_playbook: test.yml tags=foo,bar vars:
        foo: bar
        baz: quux
    '''


# Generated at 2022-06-17 07:55:39.049917
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude

    # Test with a simple playbook
    playbook = """
    - hosts: all
      tasks:
        - name: test
          debug: msg="test"
    """
    data = AnsibleLoader(playbook).get_single_data()

# Generated at 2022-06-17 07:55:50.439900
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.template import Templar
    from ansible.vars import VariableManager

# Generated at 2022-06-17 07:55:59.573296
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.playbook_include import PlaybookInclude

    ds = AnsibleMapping()
    ds['import_playbook'] = 'foo.yml'
    ds['tags'] = 'bar'
    ds['vars'] = {'baz': 'qux'}

    new_ds = PlaybookInclude.preprocess_data(ds)

    assert new_ds == {'import_playbook': 'foo.yml', 'tags': 'bar', 'vars': {'baz': 'qux'}}

    ds = AnsibleMapping()

# Generated at 2022-06-17 07:56:13.345393
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # Test the case that the playbook include is a simple playbook
    # with a single play