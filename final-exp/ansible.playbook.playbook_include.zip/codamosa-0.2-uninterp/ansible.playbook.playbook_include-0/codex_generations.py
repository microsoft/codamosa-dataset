

# Generated at 2022-06-17 07:46:31.463854
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    # Create a PlaybookInclude

# Generated at 2022-06-17 07:46:44.093489
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars

    # test load_data of class PlaybookIn

# Generated at 2022-06-17 07:46:50.496225
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    # create a PlaybookInclude object
    pbi = PlaybookInclude()

    # create a Playbook object
    pb = Playbook()

    # create a Play object
    play = Play()

    # create a Task object
    task = Task()

    # create a Block object
    block = Block()

    # create a Role object
    role = Role()

    # create a variable_manager object
    variable_manager = None

    # create a loader object
    loader = None

    # create a basedir object
    basedir = None

    # create a ds object
    d

# Generated at 2022-06-17 07:47:00.194146
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.playbook import Playbook

    # Create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # Create a Playbook object
    playbook = Playbook()

    # Create a Play object
    play = Play()

    # Create a Task object
    task = Task()

    # Create a Block object
    block = Block()

    # Create a Role object
    role = Role()

    # Create

# Generated at 2022-06-17 07:47:09.954945
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar

    # Test for import_playbook with no parameters
    ds = AnsibleMapping()
    ds['import_playbook'] = 'test.yml'
    pbi = PlaybookInclude()
    pbi.preprocess_data(ds)

# Generated at 2022-06-17 07:47:21.175024
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # Test PlaybookInclude.preprocess_data with a simple playbook
    # that has a single play with a single task
    playbook_include = PlaybookInclude()
    playbook_include.preprocess_data({'import_playbook': 'test_playbook.yml'})
    assert playbook_include.import_playbook == 'test_playbook.yml'


# Generated at 2022-06-17 07:47:32.548011
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import IncludeTask
    from ansible.playbook.task.include_role import IncludeRole
    from ansible.playbook.task.import_role import ImportRole
    from ansible.playbook.task.include_vars import IncludeVars
    from ansible.playbook.task.set_fact import SetFact
    from ansible.playbook.task.vars import Vars

# Generated at 2022-06-17 07:47:43.239295
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    # create a PlaybookInclude object
    pbi = PlaybookInclude()

    # create a Playbook object
    pb = Playbook()

    # create a Play object
    p = Play()

    # create a variable_manager object
    from ansible.vars.manager import VariableManager
    vm = VariableManager()

    # create a loader object
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()

    # create a basedir object
    basedir = '.'

    # create a ds object
    ds = {}

    # create a variable_manager object
    from ansible.vars.manager import VariableManager
    vm = VariableManager()

    # create a loader object

# Generated at 2022-06-17 07:47:53.533891
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.template import Templar

    # Test case 1:
    #   - import_playbook: playbook.yml
    #   - vars:
    #       var1: value1
    #       var2: value2
    #   - tags: tag1,tag2
    #   - when: condition
    #
    # Expected result:
    #   - import_playbook: playbook.yml
    #   - vars:
    #       var1: value1
    #       var2: value2
    #       tags: tag1,tag2
    #   - when: condition

# Generated at 2022-06-17 07:47:59.976246
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-17 07:48:20.201015
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-17 07:48:31.565228
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.base import Base
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.playbook import Playbook

    # Test PlaybookInclude.load_data()
   

# Generated at 2022-06-17 07:48:41.790365
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor

# Generated at 2022-06-17 07:48:52.687481
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-17 07:49:03.344457
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.handler.include import HandlerInclude
    from ansible.playbook.task.action import Action
    from ansible.playbook.task.loop import Loop
    from ansible.playbook.task.when import When
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

# Generated at 2022-06-17 07:49:12.988130
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude

    # test with a simple playbook
    playbook_include = PlaybookInclude()
    playbook_include.import_playbook = 'test_playbook.yml'
    playbook_include.vars = {'var1': 'value1'}
    playbook_include.tags = ['tag1']
    playbook_include.when = ['var1 == value1']


# Generated at 2022-06-17 07:49:13.600562
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-17 07:49:22.961923
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base
    from ansible.playbook.playbook_include import PlaybookInclude

# Generated at 2022-06-17 07:49:34.583617
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars

    # Create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # Create a Playbook object
    playbook = Playbook()

    # Create a Play object

# Generated at 2022-06-17 07:49:45.050705
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    # create a dummy playbook
    pb = Playbook()
    pb._

# Generated at 2022-06-17 07:50:03.503169
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    # Create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # Create a Playbook object
    playbook = Playbook()

    # Create a Play object
    play = Play()

    # Create a dict
    ds = dict()

    # Create a variable_manager object
    variable_manager = dict()

    # Create a loader object
    loader = dict()

    # Create a basedir object
    basedir = dict()

    # Create a new_obj object
    new_obj = dict()

    # Create a templar object
    templar = dict()

    # Create a file_name object
    file_name = dict()

    # Create a resource object
    resource = dict()

    # Create a playbook

# Generated at 2022-06-17 07:50:15.602151
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.playbook import Playbook

    # create a playbook include object
    playbook_include = PlaybookInclude()

    # create a playbook object
    playbook = Playbook()

    # create a play object
    play = Play()

    # create a task object

# Generated at 2022-06-17 07:50:30.017735
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.base import Base

# Generated at 2022-06-17 07:50:37.429700
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-17 07:50:43.557602
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base
    from ansible.playbook.playbook_include import PlaybookInclude

    # Create a

# Generated at 2022-06-17 07:50:49.762186
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role import Role

# Generated at 2022-06-17 07:50:55.502470
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # Create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # Create a Playbook object
    playbook = Playbook()

    # Create a Play object
    play = Play()

    # Create a Task object
    task = Task()

    # Create a Block object
    block = Block()

    #

# Generated at 2022-06-17 07:51:05.450261
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base
    from ansible.playbook.playbook_include import PlaybookInclude

# Generated at 2022-06-17 07:51:17.090166
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task_block import TaskBlock
    from ansible.playbook.handler_block import HandlerBlock
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
   

# Generated at 2022-06-17 07:51:29.062386
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.base import Base
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.helpers import load_list_of_blocks

   

# Generated at 2022-06-17 07:51:55.726378
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block_include import BlockInclude
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable

# Generated at 2022-06-17 07:52:03.388868
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable

    # test load_data with a simple playbook
    playbook_include = PlaybookInclude()
    playbook_include.import_playbook = 'test/test_playbook_include.yml'

# Generated at 2022-06-17 07:52:14.249263
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-17 07:52:28.764804
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.playbook import Playbook

    # test playbook include
    pb_inc = PlaybookInclude()
    pb_inc.import_playbook = 'test_playbook.yml'
    pb_inc.vars = {'var1': 'value1'}
    pb_inc.tags = ['tag1', 'tag2']

# Generated at 2022-06-17 07:52:37.645019
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.tasks import Task as RoleTask
    from ansible.playbook.role.defaults import RoleDefault
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.role.vars import RoleVariable
    from ansible.playbook.role.tasks import Task as RoleTask

# Generated at 2022-06-17 07:52:47.382679
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    import os

    # test playbook_include with import_playbook
    playbook_include = PlaybookInclude()
    ds = AnsibleMapping()
    ds['import_playbook'] = 'test.yml'
    new_ds = playbook_include.preprocess_data(ds)
    assert new_ds['import_playbook'] == 'test.yml'

    # test playbook_include with import_playbook and vars
    playbook_include = PlaybookInclude()
    ds = AnsibleMapping()
    ds['import_playbook'] = 'test.yml'
    ds

# Generated at 2022-06-17 07:52:59.063876
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude

    # Test with a simple playbook
    ds = dict(
        import_playbook='test_playbook.yml',
        vars=dict(
            var1='var1',
            var2='var2',
        ),
        tags=['tag1', 'tag2'],
    )
    pb = PlaybookInclude.load(ds, '.')
    assert isinstance(pb, Playbook)
    assert len(pb._entries) == 1


# Generated at 2022-06-17 07:53:06.320233
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Test with a simple playbook
    data = """
- import_playbook: test.yml
"""
    ds = AnsibleLoader(data, yaml_loader=yaml.SafeLoader).get_single_data()
    new_ds = PlaybookInclude.load(ds, '.').preprocess_data(ds)
    assert new_ds == {'import_playbook': 'test.yml'}

    # Test with a playbook with parameters
    data = """
- import_playbook: test.yml tags=tag1,tag2
"""

# Generated at 2022-06-17 07:53:16.754968
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Test with a simple playbook
    pb = PlaybookInclude.load({'import_playbook': 'test.yml'}, '.')
    assert pb._entries[0].name == 'test'
    assert pb._entries[0].hosts == ['all']
    assert pb._entries[0].tasks[0].action == 'debug'
    assert pb._entries[0].tasks[0].args['msg'] == 'Hello world!'

    # Test with a playbook with a name
    pb = PlaybookInclude.load({'import_playbook': 'test2.yml'}, '.')
    assert pb._entries[0].name == 'test2'
    assert pb._entries[0].hosts == ['all']
    assert pb._entries[0].t

# Generated at 2022-06-17 07:53:25.702038
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block_include import BlockInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base

# Generated at 2022-06-17 07:54:15.867113
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.playbook import Playbook
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    # Create a data structure to pass

# Generated at 2022-06-17 07:54:26.262530
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # test playbook include
    pb = PlaybookInclude.load(dict(import_playbook='test_playbook.yml'), '.')
    assert isinstance(pb, Playbook)
    assert len(pb._entries) == 1
    assert isinstance(pb._entries[0], Play)

# Generated at 2022-06-17 07:54:36.617457
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import Variable

# Generated at 2022-06-17 07:54:44.333655
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block_include import BlockInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base

# Generated at 2022-06-17 07:54:56.685649
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block_include import BlockInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base

# Generated at 2022-06-17 07:55:08.295268
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # Test 1: import_playbook with no parameters
    ds = dict(
        import_playbook='test.yml'
    )
    pb = PlaybookInclude.load(ds, basedir='/tmp')
    assert isinstance(pb, Playbook)
    assert len(pb._entries) == 1

# Generated at 2022-06-17 07:55:16.781668
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.base import Base
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.playbook import Playbook
    from ansible.template import Templar

# Generated at 2022-06-17 07:55:29.552298
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block_include import BlockInclude
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role_dependency import RoleDependency
    from ansible.playbook.task_include import TaskInclude

# Generated at 2022-06-17 07:55:38.758618
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # create a Playbook object
    playbook = Playbook()

    # create a Play object
    play = Play()

    # create a Task object
   

# Generated at 2022-06-17 07:55:49.999361
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude

    # Create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # Create a Playbook object
    from ansible.playbook import Playbook
    playbook = Playbook()

    # Create a Play object
    play = Play()

    # Create a Task object
    task = Task()

    # Create a TaskInclude object
    task_include = TaskInclude()

    # Create a Block object
    block = Block()

    # Create a Role object
    role = Role()

   