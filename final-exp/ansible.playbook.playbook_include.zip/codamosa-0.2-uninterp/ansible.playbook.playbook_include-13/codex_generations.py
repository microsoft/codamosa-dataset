

# Generated at 2022-06-17 07:46:29.521896
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable

# Generated at 2022-06-17 07:46:37.680406
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler_include import HandlerInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-17 07:46:47.640636
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.base import Base
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.playbook import Playbook

    # Test 1: Test with a simple playbook
    # Test

# Generated at 2022-06-17 07:47:01.742966
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # Test for a simple playbook
    ds = dict(
        import_playbook='test_playbook.yml',
        vars=dict(
            var1='value1',
            var2='value2',
        ),
        tags=['tag1', 'tag2'],
    )
    pb = Play

# Generated at 2022-06-17 07:47:11.282632
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base
    from ansible.playbook.taggable import Taggable
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-17 07:47:21.354832
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    # Create a variable manager
    variable_manager = VariableManager()
    variable_manager.extra_vars = combine_vars(loader=None, variables=dict(foo='bar', baz='qux'))

    # Create a loader
    loader = AnsibleLoader(None, variable_manager=variable_manager)

    # Create a templar
    templar = Templar(loader=loader, variables=variable_manager.get_vars())

   

# Generated at 2022-06-17 07:47:28.639845
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.collection_loader._collection_finder import _get_

# Generated at 2022-06-17 07:47:38.969204
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.playbook_include import PlaybookInclude

    # Test with a simple playbook include
    ds = AnsibleMapping()
    ds['import_playbook'] = 'test.yml'
    ds.ansible_pos = (1, 1)
    new_ds = PlaybookInclude.preprocess_data(ds)
    assert new_ds['import_playbook'] == 'test.yml'
    assert new_ds.ansible_pos == (1, 1)

    # Test with a playbook include with a parameter
    ds = AnsibleMapping()

# Generated at 2022-06-17 07:47:50.628125
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude

    # test playbook include
    playbook_include = PlaybookInclude()
    playbook_include.import_playbook = 'test_playbook.yml'
    playbook_include.vars = {'var1': 'value1', 'var2': 'value2'}
    playbook_include.tags = ['tag1', 'tag2']
    playbook_include.when = ['var1 == value1']

    # test playbook

# Generated at 2022-06-17 07:47:57.048208
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    # Create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # Create a Playbook object
    playbook = Playbook()

    # Create a Play object
    play = Play()

    # Create a dict
    ds = dict()

    # Create a variable_manager object
    variable_manager = None

    # Create a loader object
    loader = None

    # Create a basedir object
    basedir = None

    # Test load_data method
    playbook_include.load_data(ds, basedir, variable_manager, loader)

    # Test load_data method with a Playbook object
    playbook_include.load_data(playbook, basedir, variable_manager, loader)

    # Test load_data method with

# Generated at 2022-06-17 07:48:14.510164
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base
    from ansible.playbook.playbook_include import PlaybookInclude

# Generated at 2022-06-17 07:48:27.700725
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.base import Base
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.attribute import FieldAttribute
   

# Generated at 2022-06-17 07:48:39.279827
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    # test the load_data method of PlaybookInclude
    # this is a very simple test, as most of the logic is in the
    # load_data method of Playbook
    #
    # the test is to make sure that the load_data method of PlaybookInclude
    # returns a Playbook object, and that the vars and tags are properly
    # set on the Playbook object
    #
    # the test also makes sure that the conditional is properly set on the
    # Playbook object

    # create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # create a Playbook object
    playbook = Playbook

# Generated at 2022-06-17 07:48:45.226638
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.template import Templar

    # Test with a simple playbook
    yaml_data = """
    - import_playbook: test.yml
    """
    data = AnsibleLoader(yaml_data, file_name='test.yml').get_single_data()
    assert isinstance(data, list)
    assert len(data) == 1
    assert isinstance(data[0], AnsibleMapping)
    assert len(data[0]) == 1

# Generated at 2022-06-17 07:48:53.916872
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block_include import BlockInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base

# Generated at 2022-06-17 07:49:02.479572
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-17 07:49:11.161613
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.template import Templar

    # Test case 1: import_playbook with no parameters
    ds = AnsibleMapping()
    ds['import_playbook'] = 'test_playbook.yml'
    new_ds = PlaybookInclude.preprocess_data(ds)
    assert new_ds['import_playbook'] == 'test_playbook.yml'
    assert 'vars' not in new_ds

# Generated at 2022-06-17 07:49:21.413826
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    # create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # create a Playbook object
    playbook = Playbook()

    # create a Play object
    play = Play()

    # create a dict object
    ds = dict()

    # create a variable_manager object
    variable_manager = dict()

    # create a loader object
    loader = dict()

    # create a basedir object
    basedir = dict()

    # create a new_obj object
    new_obj = dict()

    # create a all_vars object
    all_vars = dict()

    # create a templar object
    templar = dict()

    # create a file_name object
    file_name = dict

# Generated at 2022-06-17 07:49:28.303612
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    # Create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # Create a Playbook object
    playbook = Playbook()

    # Create a Play object
    play

# Generated at 2022-06-17 07:49:35.490209
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.playbook import Playbook
   

# Generated at 2022-06-17 07:49:51.102664
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude

# Generated at 2022-06-17 07:49:58.117312
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.base import Base

    # Create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # Create a Play object
    play = Play()
    play.name = 'test_play'
   

# Generated at 2022-06-17 07:50:07.438654
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.playbook import Playbook
   

# Generated at 2022-06-17 07:50:17.373340
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.collection_loader import Ans

# Generated at 2022-06-17 07:50:30.566402
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-17 07:50:43.067441
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    # Create a variable manager
    variable_manager

# Generated at 2022-06-17 07:50:54.074757
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager

    # Create a playbook include object
    playbook_include = PlaybookInclude()

    # Create a playbook object
    playbook = Playbook()

    # Create a play object
    play = Play()

    # Create a task object
    task = Task()

    # Create a block object
    block = Block()

    # Create a role object
    role = Role()

    # Create a variable manager object
    variable_manager = VariableManager()

    # Create a dictionary
    ds = dict()

    # Create a dictionary
    basedir = dict()

# Generated at 2022-06-17 07:51:04.199672
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block_include import BlockInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_include import HandlerInclude

    # Test 1: test_PlaybookInclude_load_data_1
    # Test 2: test_PlaybookInclude_load_data_2
    # Test 3: test_PlaybookInclude_load_data_3
    # Test 4: test_PlaybookInclude_load_data_4
    # Test

# Generated at 2022-06-17 07:51:15.269737
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

# Generated at 2022-06-17 07:51:28.674527
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

# Generated at 2022-06-17 07:51:53.275016
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # Test with a simple playbook
    ds = dict(
        import_playbook='playbook.yml',
        vars=dict(
            foo='bar',
            baz='qux',
        ),
        tags=['tag1', 'tag2'],
    )

# Generated at 2022-06-17 07:52:01.346123
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.base import Base
    from ansible.playbook.attribute import FieldAttribute
    from ansible.template import Templar
    from ansible.utils.collection_loader import Ansible

# Generated at 2022-06-17 07:52:13.559779
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # Create a playbook include object
    playbook_include = PlaybookInclude()

    # Create a playbook object
    playbook = Playbook()

    # Create a play object
    play = Play()

    # Create a task object
    task = Task()

    # Create a block object
    block = Block()

    #

# Generated at 2022-06-17 07:52:25.440623
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Test with a simple playbook include
    ds = {'import_playbook': 'test.yml'}
    new_ds = PlaybookInclude.preprocess_data(ds)
    assert new_ds == {'import_playbook': 'test.yml'}

    # Test with a playbook include with a variable
    ds = {'import_playbook': 'test.yml', 'vars': {'var1': 'value1'}}
    new_ds = PlaybookInclude.preprocess_data(ds)
    assert new_ds == {'import_playbook': 'test.yml', 'vars': {'var1': 'value1'}}

    # Test with a playbook include with a variable and a tag

# Generated at 2022-06-17 07:52:33.518222
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude

    # Create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # Create a Playbook object
    playbook = playbook_include.load_data(ds={'import_playbook': 'test_playbook.yml'}, basedir='/home/user/ansible/playbooks')

    # Check the type of the Playbook object
    assert isinstance(playbook, Playbook)

    # Check the number of entries in the Playbook

# Generated at 2022-06-17 07:52:43.855268
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block_include import BlockInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable

    # create a PlaybookInclude object
    pbi = PlaybookInclude()
    # create a Playbook object
    pb

# Generated at 2022-06-17 07:52:51.703657
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    # Create a PlaybookInclude object
    pbi = PlaybookInclude()

    # Create a Playbook object
    pb = Playbook()

    # Create a Play object
    p = Play()

    # Create a dict
    ds = dict()

    # Create a dict
    ds1 = dict()

    # Create a dict
    ds2 = dict()

    # Create a dict
    ds3 = dict()

    # Create a dict
    ds4 = dict()

    # Create a dict
    ds5 = dict()

    # Create a dict
    ds6 = dict()

    # Create a dict
    ds7 = dict()

    # Create a dict
    ds8 = dict()

    #

# Generated at 2022-06-17 07:53:01.973269
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.tasks import TaskInclude
    from ansible.playbook.role.defaults import RoleDefault
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.role.vars import RoleVariable
    from ansible.playbook.role.task_defaults import TaskDefault
    from ansible.playbook.role.task_vars import TaskVariable

# Generated at 2022-06-17 07:53:12.535000
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.playbook_include import PlaybookInclude

    # Test 1:
    # Test with a dict
    ds = AnsibleMapping()
    ds['import_playbook'] = 'test.yml'
    ds['vars'] = {'var1': 'value1', 'var2': 'value2'}
    ds['tags'] = 'tag1,tag2'

    new_ds = PlaybookInclude.preprocess_data(ds)
    assert new_ds['import_playbook'] == 'test.yml'
    assert new_ds['vars'] == {'var1': 'value1', 'var2': 'value2'}

# Generated at 2022-06-17 07:53:24.458554
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # Test with a simple playbook include
    ds = AnsibleMapping()
    ds['import_playbook'] = 'test.yml'
    pbi = PlaybookInclude()
    pbi.preprocess_data(ds)

# Generated at 2022-06-17 07:53:56.511794
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # Test 1:
    # Test that the load_data method of PlaybookInclude class returns a Playbook object
    # when the import_playbook parameter is specified in the data structure
    #
    # Input data structure:
    #
    # - import_playbook: test_playbook.yml
    #
    # Expected result:
    #
    # A

# Generated at 2022-06-17 07:54:06.861960
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block_include import BlockInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

# Generated at 2022-06-17 07:54:18.397439
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude

    # create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # create a Playbook object
    playbook = Playbook()

    # create a Play object
    play = Play()

    # create a Task object
    task = Task()

    # create a Block object
    block = Block()

    # create a Role object
    role = Role()

    # create a Handler object
   

# Generated at 2022-06-17 07:54:26.470944
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager


# Generated at 2022-06-17 07:54:36.834373
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-17 07:54:44.587208
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block_include import BlockInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.play_context import PlayContext

# Generated at 2022-06-17 07:54:56.884469
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # test playbook include with no parameters
    ds = dict(
        import_playbook='test_playbook.yml'
    )
    pb = PlaybookInclude.load(ds, basedir='/tmp')
    assert isinstance(pb, Playbook)
    assert len(pb._entries) == 1


# Generated at 2022-06-17 07:55:08.327678
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-17 07:55:16.812510
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-17 07:55:27.717447
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    # Create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # Create a Playbook object
    playbook = Playbook()

    # Create a Play object
    play = Play()

    # Create a Task object
    task = Task()

    # Create a Block object
    block = Block()

    # Create a Role object
    role = Role()

    # Create a Play object
    play1 = Play()

    # Create a Task object
    task1 = Task()

    # Create a Block object
    block1 = Block()

    # Create a Role object
    role1

# Generated at 2022-06-17 07:55:46.609799
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.vars.manager import VariableManager

    # create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # create a VariableManager object
    variable_manager = VariableManager()

    # create a Playbook object
    playbook = Playbook()

    # create a Play object
    play = Play

# Generated at 2022-06-17 07:55:57.619789
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleParserError

# Generated at 2022-06-17 07:56:10.519496
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable

    # test load_data with a simple playbook
    playbook_include = PlaybookInclude()
    playbook = playbook_include.load_data(ds=dict(import_playbook='test_playbook.yml'), basedir='/tmp')
   