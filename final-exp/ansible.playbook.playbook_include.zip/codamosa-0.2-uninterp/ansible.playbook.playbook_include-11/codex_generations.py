

# Generated at 2022-06-17 07:46:32.764921
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-17 07:46:44.360509
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    ds = AnsibleLoader(None, None).load('''
    - import_playbook: test.yml
      vars:
        foo: bar
        baz: quux
    ''')[0]

    assert isinstance(ds, AnsibleMapping)
    assert ds.keys() == ['import_playbook', 'vars']
    assert ds['import_playbook'] == 'test.yml'
    assert ds['vars'].keys() == ['foo', 'baz']

# Generated at 2022-06-17 07:46:55.506055
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task_block import TaskBlock
    from ansible.playbook.role_block import RoleBlock
    from ansible.playbook.handler_block import HandlerBlock

    # Create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # Create a Playbook object
    playbook = Playbook()

    # Create a Play object


# Generated at 2022-06-17 07:47:06.413090
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # Create a PlaybookInclude object
    pbi = PlaybookInclude()

    # Create a Playbook object
    from ansible.playbook import Playbook
    pb = Playbook()

    # Create a Play object
    play = Play()

    # Create a Task object
    task = Task()

    # Create a Role object
    role = Role()

    #

# Generated at 2022-06-17 07:47:18.969231
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-17 07:47:31.092113
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block

    # test playbook include with no parameters
    ds = dict(
        import_playbook='test.yml',
    )
    pbi = PlaybookInclude.load(ds, '.')
    assert isinstance(pbi, Playbook)
    assert len(pbi._entries) == 1
    assert isinstance(pbi._entries[0], Play)
    assert pbi._entries[0].name == 'test'
    assert len(pbi._entries[0].tasks) == 1

# Generated at 2022-06-17 07:47:42.615349
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.base import Base
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-17 07:47:53.105480
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # Test with a simple playbook
    playbook_include = PlaybookInclude()
    playbook = playbook_include.load_data(ds={'import_playbook': 'test_playbook.yml'}, basedir='/tmp')
    assert playbook.__class__.__name__ == 'Playbook'
    assert len(playbook._entries) == 1
    assert playbook

# Generated at 2022-06-17 07:47:59.516261
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # Create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # Create a Playbook object
    playbook = Playbook()

    # Create a Play object
    play = Play()

    # Create a Task object
    task = Task()

    # Create a Block object
    block = Block()

    #

# Generated at 2022-06-17 07:48:12.293249
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block_include import BlockInclude
    from ansible.playbook.role_dependency import RoleDependency
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude

# Generated at 2022-06-17 07:48:28.192708
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.tasks import Tasks
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.role.defaults import RoleDefaults
    from ansible.playbook.role.vars import RoleVars
    from ansible.playbook.role.handlers import Role

# Generated at 2022-06-17 07:48:34.370468
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-17 07:48:42.103904
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    variable_manager.set_play_context(play_context)

    #

# Generated at 2022-06-17 07:48:53.655268
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block_include import BlockInclude
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable

    # Test PlaybookInclude

# Generated at 2022-06-17 07:49:00.498205
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    # create a fake collection
    collection_name = 'my_collection'

# Generated at 2022-06-17 07:49:09.547718
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # Test for import_playbook
    ds = AnsibleMapping()
    ds['import_playbook'] = 'test.yml'
    ds['vars'] = {'var1': 'value1'}
    ds['tags'] = 'tag1,tag2'

# Generated at 2022-06-17 07:49:20.458192
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become_prompt import BecomePrompt
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role


# Generated at 2022-06-17 07:49:27.632483
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-17 07:49:37.483103
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude

    # Create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # Create a Playbook object

# Generated at 2022-06-17 07:49:45.938087
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    import ansible.constants as C
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.collection_loader._collection_finder import _get_collection_name_from_path, _get_collection_playbook_path

    # test data
    ds = AnsibleMapping

# Generated at 2022-06-17 07:50:04.886920
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    import os
    import sys
    import tempfile
    import shutil

    # create a temporary directory
    tmp_dir = tempfile.mkdtemp()
    # create a temporary file
    tmp_file = tempfile.NamedTemporaryFile(dir=tmp_dir, delete=False)
    # create a temporary playbook
    tmp_playbook = tempfile.NamedTemporaryFile(dir=tmp_dir, delete=False)
    # create a temporary role

# Generated at 2022-06-17 07:50:16.345944
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base
   

# Generated at 2022-06-17 07:50:30.352313
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude

    # Create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # Create a Playbook object
    playbook = playbook_include.load_data(ds={'import_playbook': 'test_playbook.yml'}, basedir='/tmp')

    # Check if the Playbook object is created
    assert playbook is not None

    # Check if the Playbook object is of the right type

# Generated at 2022-06-17 07:50:35.254357
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base
   

# Generated at 2022-06-17 07:50:43.313809
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # Create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # Create a Playbook object
    playbook = Playbook()

    # Create a Play object
    play = Play()

    # Create a Task object
    task = Task()

    # Create a Block object
    block = Block()

    #

# Generated at 2022-06-17 07:50:54.244658
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.helpers import load_list_of_blocks
    from ansible.template import Templar

# Generated at 2022-06-17 07:51:04.333511
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base
    from ansible.template import Templar

# Generated at 2022-06-17 07:51:15.360439
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # Create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # Create a Playbook object
    from ansible.playbook import Playbook
    playbook = Playbook()

    # Create a Play object
    play = Play()

    # Create a Task object
    task = Task()

    # Create a Block object
    block = Block()

    #

# Generated at 2022-06-17 07:51:28.701241
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    # Setup
    AnsibleCollectionConfig.playbook_paths = []
    AnsibleCollectionConfig.default_collection = None
    data = """
- import_playbook: test_playbook.yml
  vars:
    var1: value1
    var2: value2
    tags: tag1,tag2
"""
    ds = AnsibleLoader(data, yaml_loader=AnsibleDumper).get_single_data()

# Generated at 2022-06-17 07:51:38.005671
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block_include import BlockInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.base import Base
    from ansible.template import Templar

# Generated at 2022-06-17 07:51:51.055978
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block_include import BlockInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_include import HandlerInclude
    from ansible.playbook.playbook_include import PlaybookInclude

    # test PlaybookInclude.load_data()
    # test PlaybookInclude.load_data() with a PlaybookInclude object
    # test PlaybookInclude.load_data() with a Play object
    # test PlaybookInclude

# Generated at 2022-06-17 07:52:00.309630
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    # Create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # Create a Playbook object
    playbook = Playbook()

    # Create a Play object
    play = Play()

    # Create a dict object
    ds = dict()

    # Create a variable_manager object
    variable_manager = dict()

    # Create a loader object
    loader = dict()

    # Create a basedir object
    basedir = dict()

    # Create a new_obj object
    new_obj = dict()

    # Create a all_vars object
    all_vars = dict()

    # Create a templar object
    templar = dict()

    # Create a file_name object
    file_name = dict

# Generated at 2022-06-17 07:52:11.841947
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude

# Generated at 2022-06-17 07:52:20.059080
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # test PlaybookInclude.load_data()
    # test playbook include

# Generated at 2022-06-17 07:52:31.286524
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # Test 1: import_playbook with no parameters
    ds = dict(
        import_playbook='test.yml',
    )
    new_ds = PlaybookInclude.preprocess_data(ds)
    assert new_ds == dict(
        import_playbook='test.yml',
    )

    # Test 2: import_playbook with parameters

# Generated at 2022-06-17 07:52:37.462736
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    # Create a variable manager
    variable_manager = VariableManager()


# Generated at 2022-06-17 07:52:47.203508
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.tasks import TaskInclude
    from ansible.playbook.role.defaults import RoleDefault
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.role.vars import RoleVariable
    from ansible.playbook.role.task_defaults import TaskDefault
    from ansible.playbook.role.task_vars import TaskVariable

# Generated at 2022-06-17 07:52:59.540224
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-17 07:53:10.556338
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block_include import BlockInclude
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.playbook import Playbook

    # create a PlaybookInclude object
    pi = PlaybookInclude()

    # create a Playbook object
    pb = Playbook()

    # create a Play

# Generated at 2022-06-17 07:53:18.590777
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable

    import_playbook = 'import_playbook.yml'
    vars = {'var1': 'value1', 'var2': 'value2'}
    tags = ['tag1', 'tag2']

# Generated at 2022-06-17 07:53:30.350615
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.tasks import TaskInclude
    from ansible.playbook.role.defaults import RoleDefault
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.role.vars import RoleVariable
    from ansible.playbook.role.task_defaults import TaskDefault
    from ansible.playbook.role.task_vars import TaskVariable

# Generated at 2022-06-17 07:53:42.171289
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.block.include import BlockInclude
    from ansible.playbook.handler.include import HandlerInclude
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.block.include import BlockInclude
    from ansible.playbook.handler.include import HandlerInclude


# Generated at 2022-06-17 07:53:53.355006
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base
    from ansible.playbook.playbook_include import PlaybookInclude

# Generated at 2022-06-17 07:54:01.236017
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

   

# Generated at 2022-06-17 07:54:12.216384
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.template import Templar

# Generated at 2022-06-17 07:54:25.729243
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import Role

# Generated at 2022-06-17 07:54:30.613219
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import IncludeTask
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-17 07:54:40.758734
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    # create a PlaybookInclude object
    pbi = PlaybookInclude()

    # create a Playbook object
    pb = Playbook()

    # create a Play object
    play = Play()

    # create a dict
    ds = dict()

    # create a variable_manager object
    variable_manager = dict()

    # create a loader object
    loader = dict()

    # create a basedir object
    basedir = dict()

    # create a new_obj object
    new_obj = dict()

    # create a all_vars object
    all_vars = dict()

    # create a templar object
    templar = dict()

    # create a file_name object
    file_name = dict()

# Generated at 2022-06-17 07:54:53.649846
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude

    # test playbook include
    ds = dict(
        import_playbook='test_playbook.yml',
        vars=dict(
            foo='bar'
        )
    )
    playbook_include = PlaybookInclude()
    playbook_include.load_data(ds, '.')
    assert playbook_include.import_playbook == 'test_playbook.yml'

# Generated at 2022-06-17 07:55:06.654996
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-17 07:55:23.540638
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.playbook import Playbook
   

# Generated at 2022-06-17 07:55:35.006440
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    # Create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # Create a Playbook object
    from ansible.playbook import Playbook
    playbook = Playbook()

    # Create a Play object
    play = Play()
    play.name = 'test_play'

    # Create a Task object
    task = Task()
    task.name = 'test_task'

    # Create a Block object
    block = Block()
    block.name = 'test_block'

    # Create a Role object
    role = Role()
    role.name = 'test_role'

    # Create a dict object
   

# Generated at 2022-06-17 07:55:46.836051
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block_include import BlockInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

# Generated at 2022-06-17 07:55:54.961429
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude

    # Create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # Create a Playbook object
    playbook = Playbook()

    # Create a Play object
    play = Play()

    # Create a Task object
    task = Task()

    # Create a Block object
    block = Block()

    # Create a Role object
    role = Role()

    # Create a Handler object
   

# Generated at 2022-06-17 07:56:00.853684
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable

    # test for import_playbook

# Generated at 2022-06-17 07:56:13.707702
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager