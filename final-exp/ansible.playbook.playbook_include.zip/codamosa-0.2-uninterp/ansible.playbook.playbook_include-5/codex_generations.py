

# Generated at 2022-06-17 07:46:29.591165
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.play import Play

    # Test with a valid playbook include
    ds = AnsibleMapping()
    ds['import_playbook'] = 'test_playbook.yml'
    ds['vars'] = {'var1': 'value1'}
    ds['tags'] = 'tag1,tag2'
    ds['when'] = 'var1 == value1'
    ds['connection'] = 'local'

    pbi = PlaybookInclude()
    new_ds = pbi.preprocess_data(ds)

    assert new_ds['import_playbook'] == 'test_playbook.yml'
    assert new_ds['vars'] == {'var1': 'value1'}


# Generated at 2022-06-17 07:46:37.744353
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block_include import BlockInclude
    from ansible.playbook.handler_include import HandlerInclude

    # Test PlaybookInclude.preprocess_data with a simple playbook
    ds = AnsibleMapping()
    ds['import_playbook'] = 'test_playbook.yml'

# Generated at 2022-06-17 07:46:47.729913
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    # Create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # Create a Playbook object
    playbook = Playbook()

    # Create a Play object
    play = Play()

    # Create a dict object
    ds = dict()

    # Create a variable manager object
    variable_manager = object()

    # Create a loader object
    loader = object()

    # Create a basedir object
    basedir = object()

    # Create a new_obj object
    new_obj = object()

    # Create a all_vars object
    all_vars = object()

    # Create a templar object
    templar = object()

    # Create a file_name object
    file_name = object()

# Generated at 2022-06-17 07:47:01.832138
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block_include import BlockInclude
    from ansible.playbook.handler_include import HandlerInclude

    # Test 1:
    # Test with a simple playbook
    # The playbook has a play, a task, a role, a block, and a handler
    # The play has a task, a role, a block, and a handler
    # The block has a task, a role, a block, and a handler
    # The handler

# Generated at 2022-06-17 07:47:11.352994
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.template import Templar

    loader = AnsibleLoader(None, None)
    templar = Templar(loader=loader)

    # Test with a simple playbook
    data = '''
- import_playbook: test.yml
'''
    ds = loader.load(data)[0]
    assert isinstance(ds, AnsibleSequence)
    assert len(ds) == 1
    assert isinstance(ds[0], PlaybookInclude)
    assert ds[0].import_playbook == 'test.yml'

    # Test with a playbook with parameters

# Generated at 2022-06-17 07:47:25.803792
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable

# Generated at 2022-06-17 07:47:31.518034
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable

    # create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # create a Playbook object
    from ansible.playbook import Playbook
    playbook = Playbook()

    # create a Play object
    play = Play

# Generated at 2022-06-17 07:47:40.079426
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude

    # Test 1:
    # Test that a simple import_playbook statement with no parameters
    # is correctly parsed
    ds = AnsibleMapping()
    ds['import_playbook'] = 'test.yml'
    pbi = PlaybookInclude()
    new_ds = pbi.preprocess_data(ds)

# Generated at 2022-06-17 07:47:51.569116
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base

    class TestPlaybookInclude(PlaybookInclude):
        _import_playbook = FieldAttribute(isa='string')
        _vars

# Generated at 2022-06-17 07:47:58.602417
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    # Create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # Create a Playbook object
    playbook = Playbook()

    # Create a Play object
    play = Play()

    # Create a Task object
    task = Task()

    # Create a Block object
    block = Block()

    # Create a Role object
    role = Role()

    # Create a dict object
    ds = dict()

    # Create a dict object
    ds_playbook = dict()

    # Create a dict object
    ds_play = dict()

    # Create a dict

# Generated at 2022-06-17 07:48:15.212678
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-17 07:48:26.603049
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable

    # Create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # Create a Playbook object
    from ansible.playbook import Playbook
    playbook = Playbook()

    # Create a Play object
    play = Play

# Generated at 2022-06-17 07:48:38.708374
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a variable manager
    variable_manager = VariableManager()

    # Create a loader
    loader = None

    # Create a templar
    templar = Templar(loader=loader, variables=variable_manager.get_vars())

    # Create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # Create a Playbook object
    playbook = Playbook()

    # Create a Play object
    play = Play()

# Generated at 2022-06-17 07:48:50.656862
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler

    # Test 1:
    # Test the load_data method of class PlaybookInclude
    # with a simple playbook
    #
    # playbook.yml:
    #   - hosts: all
    #     tasks:
    #       - name: test
    #         debug:
    #           msg: "test"
    #
    # playbook_include.yml:
    #   - import_playbook: playbook.yml
    #
    # Expected result:
    #   A Playbook object with one Play object
    #   The Play object has one Task object
    #  

# Generated at 2022-06-17 07:48:59.561625
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-17 07:49:09.260590
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude

    # test with a simple playbook
    ds = dict(
        import_playbook='playbook.yml',
        vars=dict(
            foo='bar',
            baz='qux',
        ),
        tags=['tag1', 'tag2'],
    )
    pb = PlaybookInclude.load(ds, '.')
    assert len(pb._entries) == 1

# Generated at 2022-06-17 07:49:20.459352
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-17 07:49:27.633185
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.playbook_include import PlaybookInclude

    ds = AnsibleMapping()
    ds['import_playbook'] = 'test.yml'
    ds['vars'] = {'a': 'b'}
    ds['tags'] = 'tag1,tag2'
    ds['when'] = 'a == b'
    ds['connection'] = 'local'

    new_ds = PlaybookInclude.preprocess_data(ds)

    assert new_ds['import_playbook'] == 'test.yml'
    assert new_ds['vars'] == {'a': 'b'}
    assert new_ds

# Generated at 2022-06-17 07:49:37.501419
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude

    # test for playbook include
    pb = PlaybookInclude.load(dict(import_playbook='test.yml'), '.')
    assert isinstance(pb, Playbook)
    assert len(pb._entries) == 1
    assert isinstance(pb._entries[0], Play)
    assert pb._entries[0].name == 'test'

# Generated at 2022-06-17 07:49:45.939171
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    # Create a PlaybookInclude object
    obj = PlaybookInclude()

    # Create a Playbook object
    pb = Playbook()

    # Create a Play object
    play = Play()

    # Create a dict object
    ds = dict()

    # Create a variable_manager object
    variable_manager = None

    # Create a loader object
    loader = None

    # Create a basedir object
    basedir = None

    # Create a new_obj object
    new_obj = obj.load_data(ds, basedir, variable_manager, loader)

    # Check the type of the new_obj object
    assert isinstance(new_obj, Playbook)

    # Create a new_obj object
    new_obj = obj

# Generated at 2022-06-17 07:50:01.648801
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    # import here to avoid a dependency loop
    from ansible.playbook import PlaybookInclude

    # test playbook
    playbook_include = PlaybookInclude()
    playbook_include.import_playbook = 'test.yml'
    playbook_include.vars = {'test': 'test'}

    # test playbook
    playbook = Playbook()
    playbook._entries = [Play()]
    playbook._entries[0].vars = {'test': 'test'}
    playbook._entries[0].tags = ['test']

    # test load_data
    playbook_include.load_data(ds=playbook_include, basedir='/', variable_manager=None, loader=None)

    # test load_data


# Generated at 2022-06-17 07:50:15.243381
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.tasks import TaskInclude
    from ansible.playbook.role.defaults import RoleDefault
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.role.vars import RoleVariable
    from ansible.playbook.role.task_defaults import TaskDefault
    from ansible.playbook.role.task_vars import TaskVariable

# Generated at 2022-06-17 07:50:29.855319
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.tasks import Tasks
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.role.defaults import RoleDefaults
    from ansible.playbook.role.vars import RoleVars
    from ansible.playbook.role.tasks import TaskInclude
    from ansible.playbook.role.handlers import RoleHandler
    from ansible.playbook.become import Become
   

# Generated at 2022-06-17 07:50:42.996257
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook

    # create a PlaybookInclude object
    pbi = PlaybookInclude()

    # create a Playbook object
    pb = Playbook()

    # create a Play object
    p = Play()

    # create a dict
    ds = dict()

    # create a variable manager
    variable_manager = None

    # create a loader
    loader = None

    # create a basedir
    basedir = None

    # test load_data
    pb = pbi.load_data(ds, basedir, variable_manager, loader)

    # test load_data with a Playbook object
    pb = pbi.load_data(p, basedir, variable_manager, loader)

    # test load_data with a Play object


# Generated at 2022-06-17 07:50:49.211331
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude

    # test for import_playbook
    ds = AnsibleMapping()
    ds['import_playbook'] = 'test.yml'
    ds['vars'] = {'var1': 'value1'}
    ds['tags'] = 'tag1,tag2'
    ds['when'] = 'var1 == value1'
    pb

# Generated at 2022-06-17 07:51:01.960220
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude

    # Test with a simple playbook
    ds = {'import_playbook': 'test.yml'}
    pb = PlaybookInclude.load(ds, '.')
    assert isinstance(pb, Playbook)
    assert len(pb._entries) == 1
    assert isinstance(pb._entries[0], Play)

# Generated at 2022-06-17 07:51:13.627674
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnic

# Generated at 2022-06-17 07:51:24.749309
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base
    from ansible.playbook.playbook_include import PlaybookInclude

# Generated at 2022-06-17 07:51:37.300889
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable

    # test load_data method of class PlaybookInclude
    # test case 1:
    #   playbook_include_obj.load_data(ds=data, basedir=basedir, variable_manager

# Generated at 2022-06-17 07:51:50.765432
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block_include import BlockInclude
    from ansible.playbook.handler_include import HandlerInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude

# Generated at 2022-06-17 07:52:04.129286
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    # Test for import_playbook with no parameters
    ds = dict(
        import_playbook='/path/to/playbook.yml'
    )
    new_ds = PlaybookInclude.preprocess_data(ds)
    assert new_ds == dict(
        import_playbook='/path/to/playbook.yml'
    )

    # Test for import_playbook with parameters
    ds = dict(
        import_playbook='/path/to/playbook.yml tags=tag1,tag2 vars=var1:value1,var2:value2'
    )
    new_

# Generated at 2022-06-17 07:52:14.370819
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.base import Base

    # Create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # Create a Playbook object
    playbook = Playbook()

# Generated at 2022-06-17 07:52:28.877457
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.tasks import TaskInclude
    from ansible.playbook.role.defaults import DefaultInclude
    from ansible.playbook.role.meta import MetaInclude
    from ansible.playbook.role.vars import VarsInclude
    from ansible.playbook.role.tasks import TaskInclude
    from ansible.playbook.role.handlers import HandlerInclude

# Generated at 2022-06-17 07:52:35.797274
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude

    # Test with a simple playbook
    playbook = PlaybookInclude()
    ds = AnsibleMapping()
    ds['import_playbook'] = 'test.yml'
    ds['tags'] = 'tag1,tag2'
    ds['vars'] = {'var1': 'value1', 'var2': 'value2'}
    d

# Generated at 2022-06-17 07:52:44.532809
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler

    # test with a simple playbook
    playbook = '''
    - import_playbook: test.yml
    '''
    ds = PlaybookInclude.load(playbook, '.')
    assert isinstance(ds, PlaybookInclude)
    assert ds.import_playbook == 'test.yml'

    # test with a playbook with a parameter
    playbook = '''
    - import_playbook: test.yml tags=foo
    '''
    ds = PlaybookIn

# Generated at 2022-06-17 07:52:53.158338
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    # Test with a valid playbook import statement
    ds = AnsibleMapping()
    ds['import_playbook'] = 'test_playbook.yml'
    ds['tags'] = 'test_tag'
    ds['vars'] = {'test_var': 'test_value'}
    ds['when'] = 'test_condition'
    ds['other_key'] = 'other_value'
    new_ds = PlaybookInclude.preprocess_data(ds)
    assert new_ds['import_playbook'] == 'test_playbook.yml'
    assert new_

# Generated at 2022-06-17 07:53:01.389855
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_

# Generated at 2022-06-17 07:53:10.313200
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    # Create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # Create a Playbook object
    playbook = Playbook()

    # Create a Play object
    play = Play()

    # Create a Task object
    task = Task()

    # Create a Block object
    block = Block()

    # Create a Role object
    role = Role()

    # Create a list of objects
    objects = [playbook, play, task, block, role]

    # Create a list of objects' names

# Generated at 2022-06-17 07:53:18.429292
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable

    # create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # create a Playbook object
    playbook = Playbook()

    # create a Play object
    play = Play()

    # create a Task object
    task = Task()

   

# Generated at 2022-06-17 07:53:28.497972
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.template import Templar
    from ansible.vars.manager import Variable

# Generated at 2022-06-17 07:53:49.786409
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.playbook import Playbook

    # Create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # Create a Playbook object
    playbook = Playbook()

    # Create a Play object
    play = Play()

    # Create a Task object


# Generated at 2022-06-17 07:54:02.403250
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block_include import BlockInclude
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.base import Base
   

# Generated at 2022-06-17 07:54:12.306305
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    # Create a variable manager
    variable_manager = VariableManager()
    loader = DataLoader()

    # Create an inventory manager
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    #

# Generated at 2022-06-17 07:54:21.159621
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    # Setup
    AnsibleCollectionConfig.playbook_paths = []
    AnsibleCollectionConfig.default_collection = None

    # Test
    ds = AnsibleMapping()
    ds['import_playbook'] = 'test.yml'
    ds['vars'] = {'var1': 'value1'}
    ds['tags'] = 'tag1,tag2'
    ds['when'] = 'var1 == value1'
    ds['other'] = 'value2'
    ds['other2'] = 'value3'

# Generated at 2022-06-17 07:54:31.701366
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable

    # create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # create a Playbook object
    playbook = Playbook()

    # create a Play object
    play = Play

# Generated at 2022-06-17 07:54:41.439500
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude

    # test with a simple playbook
    ds = AnsibleMapping()

# Generated at 2022-06-17 07:54:54.507714
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.playbook_include import PlaybookInclude

    # test load_data method of class PlaybookInclude
    # test case 1:
    #   playbook_include:
    #     import_playbook: test_playbook.yml
    #     vars:
    #       var1: value

# Generated at 2022-06-17 07:55:00.850273
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # Test with a simple playbook
    playbook_include = PlaybookInclude()
    playbook_include.import_playbook = "test_playbook.yml"
    playbook_include.vars = {"var1": "value1"}
    playbook_include.tags = ["tag1", "tag2"]

# Generated at 2022-06-17 07:55:09.639437
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.playbook import Playbook
   

# Generated at 2022-06-17 07:55:20.100473
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude

    # Test the preprocess_data method of the PlaybookInclude class
    # with a simple playbook include statement
    ds = dict(
        import_playbook='test.yml',
    )
    pbi = PlaybookInclude()
    pbi.preprocess_data(ds)
    assert pbi.import_playbook == 'test.yml'
    assert pbi.vars == {}

    # Test the preprocess_data method of

# Generated at 2022-06-17 07:55:41.433645
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping

    ds = AnsibleLoader(None, None).load('''
    - import_playbook: test.yml
      vars:
        foo: bar
        baz: qux
    ''')[0]

    assert isinstance(ds, AnsibleMapping)
    assert ds['import_playbook'] == 'test.yml'
    assert ds['vars'] == {'foo': 'bar', 'baz': 'qux'}


# Generated at 2022-06-17 07:55:50.908906
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block_include import BlockInclude

    # Test for PlaybookInclude

# Generated at 2022-06-17 07:55:59.600827
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

# Generated at 2022-06-17 07:56:04.809043
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # Create a playbook include object
    playbook_include = PlaybookInclude()

    # Create a playbook object
    playbook = Playbook()

    # Create a play object
    play = Play()

    # Create a task object
    task = Task()

    # Create a block object
    block = Block()

    # Create a role

# Generated at 2022-06-17 07:56:15.566896
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    # Create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # Create a Playbook object
    playbook = Playbook()

    # Create a Play object
    play = Play()

    # Create a dict
    ds = dict()

    # Create a variable manager
    variable_manager = None

    # Create a loader
    loader = None

    # Create a basedir
    basedir = None

    # Create a dict
    data = dict()

    # Create a dict
    new_obj = dict()

    # Create a dict
    all_vars = dict()

    # Create a Templar object
    templar = Templar()

    # Create a string
    file_name = ""

    # Create a list
   