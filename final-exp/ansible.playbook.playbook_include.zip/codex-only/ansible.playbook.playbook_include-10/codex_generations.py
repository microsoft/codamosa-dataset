

# Generated at 2022-06-23 06:34:23.650671
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-23 06:34:32.785027
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include = PlaybookInclude()

    # Test the success of preprocess_data method
    ds = { "import_playbook": "test.yml" }
    new_ds = playbook_include.preprocess_data(ds)
    assert new_ds == {
        'import_playbook': 'test.yml'
    }

    ds = { "import_playbook": "test.yml with_items=1 tags=test" }
    new_ds = playbook_include.preprocess_data(ds)
    assert new_ds == {
        'import_playbook': 'test.yml',
        'tags': 'test',
        'vars': {
            'with_items': '1'
        }
    }

    # Test the failure of preprocess_data method when it is called with an empty

# Generated at 2022-06-23 06:34:41.725266
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    def mock_load_data(*args, **kwargs):
        return args

    def mock_load_data_for_class(*args, **kwargs):
        return args

    def mock_preprocess_data(*args, **kwargs):
        return args

    from ansible.module_utils.six import PY3
    if PY3:
        from unittest.mock import patch, MagicMock
    else:
        from mock import patch, MagicMock

    def mock_PlaybookInclude_load_data(*args, **kwargs):
        return args

    def mock_Playbook_load(*args, **kwargs):
        return args

    # First, replace the load method of the PlaybookInclude class by a mocked one
    # to be able to test it.

# Generated at 2022-06-23 06:34:50.658435
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    #
    # A helper method to test the parameters given
    #
    def test_params(test_name, import_playbook, filename = None, tags = None, vars = None):

        display.display(test_name)

        # Load the import
        pb = PlaybookInclude.load({'import_playbook': import_playbook}, basedir='.')

        # Test the parameters
        if filename is None:
            assert pb.import_playbook == import_playbook
        else:
            assert pb.import_playbook == filename
        assert pb.tags == tags
        assert pb.vars == vars

    # Test with a file name only
    test_params('file_name', 'sample.yml', 'sample.yml')

    # Test with a file name and var
    test_params

# Generated at 2022-06-23 06:35:01.461886
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play_context import PlayContext

    # this method is a bit complicated and data-driven, so one
    # large test with various cases makes sense here

# Generated at 2022-06-23 06:35:02.995108
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pbi = PlaybookInclude()
    assert pbi


# Generated at 2022-06-23 06:35:12.382031
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    assert PlaybookInclude.load({'import_playbook': 'test.yaml'}, '/root/my/dir').preprocess_data({'import_playbook': 'test.yaml'}) == {'import_playbook': 'test.yaml'}
    assert PlaybookInclude.load({'import_playbook': 'test.yaml'}, '/root/my/dir').preprocess_data({'import_playbook': 'test.yaml', 'vars': {'foo': 'bar'}}) == {'import_playbook': 'test.yaml', 'vars': {'foo': 'bar'}}

# Generated at 2022-06-23 06:35:13.510271
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-23 06:35:24.890713
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook

    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.playbook.task import Task

    ds = dict(
        import_playbook = '/tmp/foo.yml',
        vars = dict(
            var1 = 'this is a test',
            var2 = ['an','array','of','values'],
         ),
        tags = ['tag1','tag2'],
        when = 'testexpr'
    )
    pbi = PlaybookInclude.load(ds, '/tmp')
    assert pbi.vars['var1'] == 'this is a test'
    assert pbi.vars['var2'] == ['an','array','of','values']

# Generated at 2022-06-23 06:35:35.424350
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include = PlaybookInclude()
    # Test normal case:
    test_ds = {
            'import_playbook' : 'some_playbook.yaml',
            'vars' : {
                'item1' : 1,
                'item2' : 'value2'
            }
    }
    new_ds = playbook_include.preprocess_data(test_ds)
    assert new_ds == {
        'import_playbook' : 'some_playbook.yaml',
        'vars' : {
            'item1' : 1,
            'item2' : 'value2'
        }
    }
    # Test import_playbook legacy usage:

# Generated at 2022-06-23 06:35:48.235860
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    '''
    Unit test PlaybookInclude.preprocess_data
    '''


# Generated at 2022-06-23 06:36:00.919958
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping


# Generated at 2022-06-23 06:36:02.543985
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-23 06:36:15.277618
# Unit test for method load_data of class PlaybookInclude

# Generated at 2022-06-23 06:36:28.163134
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.collection_loader import AnsibleCollectionConfig, _get_collection_name_from_path
    import yaml

    yaml_data = '''
- import_playbook:
    import_playbook: mycol.mypl.play
'''

    AnsibleCollectionConfig.playbook_paths = ['/path/to/playbooks']
    AnsibleCollectionConfig.collections_paths = ['/path/to/collections']
    AnsibleCollectionConfig.auto_create_collections = True


# Generated at 2022-06-23 06:36:36.056505
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play

    # test preprocess_data
    p = PlaybookInclude.load({'import_playbook': 'test.yaml', 'vars': {'key': 'value'}, 'tags': 'tag1,tag2'}, None)

    # for the test we expect that preprocess_data return a dict,
    # which should have a key named import_playbook,
    # which value should be 'test.yaml'
    assert isinstance(p.preprocess_data({'import_playbook': 'test.yaml', 'vars': {'key': 'value'}, 'tags': 'tag1,tag2'}), dict)

# Generated at 2022-06-23 06:36:45.225998
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    loader = DummyLoader()
    from ansible.playbook.play_context import PlayContext
    pc = PlayContext(loader=loader)
    from ansible.vars.manager import VariableManager
    vm = VariableManager(loader=loader, play_context=pc)
    pi = PlaybookInclude()
    pi.variable_manager = vm
    pi.loader = loader

    def assert_data(data, import_playbook, vars, tags=None, when=None):
        pi.preprocess_data(data)
        assert pi.import_playbook == import_playbook
        if vars is None:
            assert pi.vars == {}
        else:
            assert pi.vars == vars
        if tags is None:
            assert pi.tags == []
        else:
            assert pi.tags == tags

# Generated at 2022-06-23 06:36:56.491367
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # change yaml to migrate yaml tests to pyyaml
    import ansible.parsing.yaml.objects

    # change to isinstance()
    # change to use new AnsibleMapping class from new objects
    class TestDS(AnsibleMapping):
        # change to use new objects
        def __init__(self, d):
            self.data = d
    ds = TestDS({'import_playbook': 'test.yml'})
    assert PlaybookInclude.preprocess_data(ds) == {'import_playbook': 'test.yml'}

    # change to isinstance()
    # change to use new AnsibleMapping class from new objects
    class TestDS(AnsibleMapping):
        # change to use new objects
        def __init__(self, d):
            self.data

# Generated at 2022-06-23 06:37:07.964468
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    from ansible.playbook import PlaybookInclude

    # OrderedDict is used to retain the order of the key/value pairs
    from collections import OrderedDict
    from ansible.parsing.yaml.objects import AnsibleMapping
    import pytest

    def assertEqual(first, second, msg=None):
        # assert first == second if msg is None else msg
        if first != second:
            if msg:
                print(msg)
            else:
                print("first (%s) is not equal to second (%s)" % (first, second))
        assert first == second if msg is None else msg

    # Valid input
    # 1. No arg
    # 2. arg = string of playbook name
    # 3. arg = dictionary of parameters
    # 4. arg = string of playbook name + parameters, i.e.

# Generated at 2022-06-23 06:37:20.634586
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # Test 1: check for valid preprocess data of PlaybookInclude's instance variables
    p = PlaybookInclude(dict(import_playbook="import_playbook", vars=dict(var1="value1", var2="value2")))
    assert p.import_playbook == "import_playbook"
    assert p.vars == dict(var1="value1", var2="value2")

    # Test 2: check for valid preprocess data of PlaybookInclude's instance variables
    # when it contains additional parameters
    p = PlaybookInclude(dict(import_playbook="import_playbook var1=value1 var2=value2"))
    assert p.import_playbook == "import_playbook"
    assert p.vars == dict(var1="value1", var2="value2")

    # Test 3:

# Generated at 2022-06-23 06:37:36.208322
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # Arrange
    # For the test some mocks are needed
    import sys
    from ansible.module_utils._text import to_text
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    class Loader(object):
        pass

    playbook = PlaybookInclude()
    playbook.load_data({
        'import_playbook': 'playbook.yml',
        'vars': {
            'var1': 'value1',
        },
    }, basedir='/path/to/playbook', loader=Loader())

    # Act
    result = playbook.load_data(basedir='/path/to/playbook', loader=Loader())

    # Assert
    assert isinstance(result, Playbook)
    assert len(result.get_plays()) > 0

# Generated at 2022-06-23 06:37:50.015221
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # Test for 5.4
    parser = PlaybookInclude()
    ds = {'include': 'other/main.yml'}
    ret = parser.preprocess_data(ds)
    assert ret == {'import_playbook': 'other/main.yml'}
    # Test for 1.2, with multiple params and vars
    ds = {'import_playbook': ['some/file.yml', 'some_var=some_value some_var2=some_value2']}
    ret = parser.preprocess_data(ds)
    assert ret == {'import_playbook': 'some/file.yml', 'vars': {'some_var': 'some_value', 'some_var2': 'some_value2'}}

# Generated at 2022-06-23 06:37:52.478091
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # This unit test is not that helpful in itself because we mostly
    # just delegate most of the loading to the Playbook class, which
    # is already tested.
    pass

# Generated at 2022-06-23 06:38:05.211236
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.bases import Bases
    import ansible.utils.collection_loader
    pb = PlaybookInclude()
    assert isinstance(pb, Bases)
    new_obj = pb.load_data({'import_playbook': '/tmp/test/test.yml'})
    assert isinstance(new_obj, pb.__class__)
    assert isinstance(new_obj._entries[0], Play)
    assert new_obj._entries[0].name == 'Testing Playbook Include'
    assert new_obj._entries[0].vars['playbook'] == 'test'
    collection_loader_mock = ansible.utils.collection_loader.AnsibleCollectionConfig
    collection_loader_mock.playbook_path

# Generated at 2022-06-23 06:38:15.239780
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # TODO: improve test coverage
    pb = PlaybookInclude.load(
        data={
            'import_playbook': 'test.yml', 
            'hosts': 'all', 
            'connection': 'ssh', 
            'vars': {
                'var2': 'value'
            }
        }, 
        basedir='/home/user'
    )
    assert pb.import_playbook == 'test.yml'
    assert pb.vars == {'var2': 'value'}

# Generated at 2022-06-23 06:38:16.408828
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-23 06:38:29.327015
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Tests that the method PlaybookInclude.load_data returns the correct value
    # when the import_playbook parameter is a relative path, absolute path or FQCN
    # and there are no additional parameters other than 'vars'
    # Assumption: file at path 'test_PlaybookInclude_load_data.yaml' exists at the test directory
    from ansible.playbook import Playbook
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role_include import RoleInclude
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-23 06:38:38.846465
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play

    ds = dict(
        import_playbook = "../common/playbook.yml",
    )
    ds = PlaybookInclude.load(ds, "", "", "").get_data()
    assert ds['import_playbook'] == "../common/playbook.yml"

    ds = dict(
        import_playbook = "../common/playbook.yml",
        tags           = "tag1,tag2"
    )
    ds = PlaybookInclude.load(ds, "", "", "").get_data()
    assert ds['import_playbook'] == "../common/playbook.yml"
    assert PlaybookInclude.load(ds, "", "", "").tags == ['tag1', 'tag2']

   

# Generated at 2022-06-23 06:38:43.965373
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    a = PlaybookInclude(import_playbook='hello', tags=['a', 'b'])
    assert a._import_playbook == 'hello'
    assert a.import_playbook == 'hello'
    assert a.tags == ['a', 'b']

# Generated at 2022-06-23 06:38:46.692412
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # TODO: create unit test for 'load'
    #assert False
    pass


# Generated at 2022-06-23 06:39:00.622632
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['examples/hosts'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test playbook_include with FQCN
    fqcn_path = 'community.general.certbot_dns_netcup'
    pb = PlaybookInclude.load(data=fqcn_path, basedir='examples/playbooks-include/', variable_manager=variable_manager, loader=loader)
    assert pb.entries[0]._entries[0]._entries[0].action == 'include_role'

# Generated at 2022-06-23 06:39:10.162232
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import unittest
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.template import Templar

    class TestPlaybookInclude(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_load_data(self):
            ds = {
                'import_playbook': 'playbook.yml',
                'vars': {'a_var': 1}
            }
            playbook_include = PlaybookInclude()
            pb = playbook_include.load_data(ds, basedir='.')
            play = pb._entries[0]
            self.assertIsInstance(play, Play)

# Generated at 2022-06-23 06:39:19.824449
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Example
    # Given
    # import_playbook: "./s1.yml"
    # vars:
    #   k1: "v1"
    # when: true
    # tags:
    #   - role1
    #   - role2
    dict = {"import_playbook": "./s1.yml",
            "vars": {"k1": "v1"},
            "when": True,
            "tags": ["role1", "role2"]
            }

    # When
    actual = PlaybookInclude.load(dict, ".")

    # Then
    expected_play_count = 3

# Generated at 2022-06-23 06:39:33.453149
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.base import Base
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.parsing.yaml.objects import AnsibleMapping

# Generated at 2022-06-23 06:39:34.099197
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-23 06:39:37.801171
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    playbook_include = PlaybookInclude()
    assert playbook_include.when == None
    assert playbook_include.tags == []
    assert playbook_include._import_playbook == None
    assert playbook_include._vars == {}

# Generated at 2022-06-23 06:39:46.568810
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    dataloader = DataLoader()
    variable_manager = VariableManager()

    playbook_include_load_src = '''
INCLUDES:
    - name: include_playbook_test.yml
'''
    playbook_include_load_data = dataloader.load_from_data(playbook_include_load_src)

    playbook_include_load_result = PlaybookInclude.load(
        data=playbook_include_load_data,
        basedir='playbooks/library/tests/',
        variable_manager=variable_manager,
        loader=dataloader
    )
    assert not isinstance(playbook_include_load_result, PlaybookInclude)



# Generated at 2022-06-23 06:39:51.870622
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():

    # create a task
    pbtask = PlaybookInclude(ds=dict(import_playbook='/temp/foo.yml'))
    # create a Play
    pb = Playbook()
    # add to Play
    pb._entries.append(pbtask)

    # get data
    data = pbtask.get_data(validate=False)
    # create AnsibleMapping task and load data
    new_pbtask = AnsibleMapping()
    new_pbtask.load(data)

    # assert
    assert(new_pbtask.get('import_playbook') == '/temp/foo.yml')

# Generated at 2022-06-23 06:39:56.843094
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    '''
    Construct a minimal PlaybookInclude object.
    '''
    import ansible.playbook.playbook_include as playbook_include
    play_incl = playbook_include.PlaybookInclude()
    assert play_incl._import_playbook is None
    assert play_incl._vars == {}
    assert play_incl.tags == []
    assert play_incl.when == []

# Generated at 2022-06-23 06:40:07.380593
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.playbook import Playbook

    playbook_include_key_value = {
        'import_playbook': 'playbook.yml'
    }

    playbook_include_key_value_with_only_vars = {
        'vars': {
            'var1': 'value1',
            'var2': 'value2'
        }
    }

    playbook_include_key_value_with_vars_and_tags = {
        'vars': {
            'var1': 'value1',
            'var2': 'value2'
        },
        'tags': 'tag1'
    }


# Generated at 2022-06-23 06:40:08.143581
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    PlaybookInclude()

# Generated at 2022-06-23 06:40:15.806347
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import_playbook = {
        'include' : 'include.yml',
        'vars' : {
            'xyz' : 'abc'
        }
    }

    playbook_include = PlaybookInclude()
    playbook_include.load_data(ds=import_playbook, basedir=".")
    assert playbook_include.import_playbook == 'include.yml'
    assert playbook_include.vars['xyz'] == 'abc'

# Generated at 2022-06-23 06:40:29.639990
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # test with valid data
    data = dict(
        import_playbook='test.yml'
    )
    pi = PlaybookInclude.load(data=data, basedir='.')
    assert pi.import_playbook == 'test.yml'
    assert pi.vars == {}

    # test with invalid data
    data = dict(
        no_import_playbook='test.yml'
    )
    try:
        pi = PlaybookInclude.load(data=data, basedir='.')
        assert False, 'AnsibleAssertionError is not raised'
    except AnsibleParserError:
        pass

# Generated at 2022-06-23 06:40:30.246670
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-23 06:40:43.746208
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # Test basic constructor
    ds = dict(import_playbook='site.yml')
    pbi = PlaybookInclude.load(ds, '.')
    assert pbi._import_playbook == 'site.yml'

    # Test constructor with var using equals
    ds = dict(import_playbook='site.yml var=value')
    pbi = PlaybookInclude.load(ds, '.')
    assert pbi._import_playbook == 'site.yml'
    assert pbi._vars['var'] == 'value'

    # Test constructor with var using space
    ds = dict(import_playbook='site.yml var value')
    pbi = PlaybookInclude.load(ds, '.')
    assert pbi._import_playbook == 'site.yml'

# Generated at 2022-06-23 06:40:44.834605
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
   PlaybookInclude()
   pass

# Generated at 2022-06-23 06:40:49.569534
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    # Create a PlaybookInclude object and check its attributes
    pin = PlaybookInclude.load(
        {
            'import_playbook': 'my_playbook.yaml'
        },
        basedir='/home/john'
    )
    assert pin.import_playbook == 'my_playbook.yaml'
    assert pin.when is None
    assert pin.tags == []
    assert pin.vars == {}

# Generated at 2022-06-23 06:40:56.350294
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    '''
    Ansible
    =======

    In the ansible header, you can import a playbook and define various arguments.
    This can contain a combination of tags, variables, some parameters and filename.

    This class is responsible for parsing the ansible header into various objects.
    '''

    # INIT
    playbook_include = PlaybookInclude()
    # Example data structures to be processed
    with_tags = dict(import_playbook='playbook1.yml', tags=['tag1', 'tag2'])
    with_vars = dict(import_playbook='playbook2.yml', vars=dict(var1='val1', var2='val2'))
    with_params = dict(import_playbook='playbook3.yml var1=val1 var2=val2')
    with_params_and_

# Generated at 2022-06-23 06:41:05.063306
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    import ansible.parsing.yaml.objects
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.loader import action_loader

    ##############################################################################################
    # Setup test environment
    ##############################################################################################

    # test data
    ds_test_data = """
    - import_playbook: test_playbook.yml
        tags:
          - test_tag
    """

    # test file
    test_file_path = r"./test_playbook.yml"
    test_file_data = """
    - hosts: localhost
      gather_facts: no
      connection: local
      tasks:
        - debug:
            msg: test_playbook_msg
    """

# Generated at 2022-06-23 06:41:07.952757
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    obj = PlaybookInclude.load(dict(import_playbook="subdir/test.yml"), basedir="subdir")
    assert isinstance(obj, Playbook)



# Generated at 2022-06-23 06:41:18.999244
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    ds = dict(
        import_playbook='/path/to/file.yaml',
        vars=dict(
            foo='bar'
        ),
        when=dict(
            ansible_distribution='RedHat'
        )
    )

    o = PlaybookInclude.load(ds=ds, basedir='/tmp')

    assert o._import_playbook == '/path/to/file.yaml'
    assert o._vars == dict(foo='bar')
    assert isinstance(o.when, list)
    assert len(o.when) == 1
    assert o.when[0].items()[0][0] == 'ansible_distribution'
    assert o.when[0].items()[0][1] == 'RedHat'

# Generated at 2022-06-23 06:41:28.342514
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    c = PlaybookInclude()
    result = c.preprocess_data({'import_playbook': 'foo.yml'})
    assert 'import_playbook' in result
    assert 'import_playbook' in c._ds

    # vars in the datastructure is taken literally
    result = c.preprocess_data({'import_playbook': 'foo.yml', 'vars': 'this is not a dict'})
    assert 'import_playbook' in result
    assert 'vars' in result
    assert not isinstance(result['vars'], dict)

    # vars after 'import_playbook' is parsed into a dict
    result = c.preprocess_data({'import_playbook': 'foo.yml some_var=some_value'})
    assert 'import_playbook' in result


# Generated at 2022-06-23 06:41:30.116093
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-23 06:41:31.131257
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-23 06:41:43.509686
# Unit test for constructor of class PlaybookInclude

# Generated at 2022-06-23 06:41:55.973545
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude

    base_ds = dict(
        import_playbook="test.yml",
        vars=dict(a=1, b=2)
    )
    base_obj = PlaybookInclude().load_data(ds=base_ds)
    assert isinstance(base_obj, PlaybookInclude)
    assert base_obj.import_playbook == "test.yml"
    assert base_obj.vars == dict(a=1, b=2)

    # Non string import_playbook
    base_ds = dict(
        import_playbook=123
    )

# Generated at 2022-06-23 06:41:56.713570
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-23 06:41:58.166153
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-23 06:42:08.720862
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.errors import AnsibleParserError
    from ansible.parsing.yaml.objects import AnsibleMapping


# Generated at 2022-06-23 06:42:18.643043
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    class MockLoader:
        def __init__(self):
            self.result = ""
        def load_from_file(self, filename):
            self.result = filename

    class MockVariableManger:
        def __init__(self):
            self.result = ""
        def get_vars(self):
            return {}

    class MockTemplar:
        def __init__(self):
            self.result = ""
        def template(self, filename):
            return filename

    class MockYamlObject:
        def __init__(self):
            self.result = ""
        def __setitem__(self, key, value):
            self.result = value
        def __getitem__(self, key):
            return "MockYamlObject"

# Generated at 2022-06-23 06:42:31.463164
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook import Playbook
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager

    from six import PY3
    from sys import version_info as py_version_info

    # Create an empty inventory
    inventory = InventoryManager(loader=None, sources=None)
    grp = Group('group1')
    inventory.add_group(grp)
    host = Host('hostname')
    inventory.add_host(host)

    # Create the playbook loader
    loader = DictDataLoader({})

    # Create a variable manager to resolve variables
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create a template based on a string

# Generated at 2022-06-23 06:42:42.810194
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    playbook_include = PlaybookInclude()

    # success case
    playbook_include.preprocess_data({'import_playbook': 'playbook.yml'})
    assert playbook_include.import_playbook == 'playbook.yml'


    # failure case: not a dict
    try:
        playbook_include.preprocess_data('string')
        assert False
    except AssertionError:
        assert True

    # failure case: invalid import_playbook
    try:
        playbook_include.preprocess_data({'import_playbook': []})
        assert False
    except AnsibleParserError:
        assert True

    # failure case: vars is not a dict

# Generated at 2022-06-23 06:42:44.476155
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-23 06:42:45.350442
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass


# Generated at 2022-06-23 06:42:52.053342
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook

    basedir = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'playbook_include_test')
    assert isinstance(PlaybookInclude.load(data='playbook.yml', basedir=basedir), Playbook)

# Generated at 2022-06-23 06:43:01.799120
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Regression test for ticket https://github.com/ansible/ansible/issues/38208
    # TODO: add proper unit tests
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.display import Display
    Display._in_play = True
    PlayContext()
    inventory = InventoryManager(loader=None, sources=[])

    collection_name = 'rmg'
    collection_version = '0.1.0'
    collection_path = '../../ansible_collections/rmg/rmg'
    collection = '%s.%s' % (collection_name, collection_version)
    playbook = '%s/plugins/importers/example.yml' % collection_path

# Generated at 2022-06-23 06:43:10.508965
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # mock base class methods
    class BaseMock(object):
        def __init__(self):
            self.conditional = True
            self.tags = ['t1', 't2']
            self.when = []
            self.vars = {'key1': 'value1'}
        def get_vars(self):
            return {'key2': 'value2'}
    class MockPlaybook(object):
        def __init__(self):
            self.tagged_tasks = []
            self.tagged_name = None
            self.host_set = set()
            self._entries = []
    # mock data

# Generated at 2022-06-23 06:43:21.836959
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    class MyPlaybookInclude(PlaybookInclude):
        def __init__(self):
            self.ds = None

        def preprocess_data(self, ds):
            self.ds = super(MyPlaybookInclude, self).preprocess_data(ds)

    # Test that a string is not allowed
    obj = MyPlaybookInclude(loader=None)

    try:
        obj.preprocess_data("string")
        assert False
    except AnsibleAssertionError:
        assert True

    # Test that a list is not allowed
    obj = MyPlaybookInclude(loader=None)

    try:
        obj.preprocess_data([])
        assert False
    except AnsibleAssertionError:
        assert True

    # Test that a bare import playbook statement is accepted.
    obj = MyPlaybookIn

# Generated at 2022-06-23 06:43:34.927326
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    import ansible.constants as C

    playbook_include = PlaybookInclude()
    results = playbook_include.preprocess_data('test.yml')
    assert results['import_playbook'] == 'test.yml'

    playbook_include = PlaybookInclude()
    results = playbook_include.preprocess_data('test.yml other="param1=value1 param2=value2"')
    assert results['import_playbook'] == 'test.yml'

    playbook_include = PlaybookInclude()

# Generated at 2022-06-23 06:43:40.600102
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
   data = {'include':'play.yml'}
   basedir = "/root/ansible/playbooks/test"
   #import pdb;pdb.set_trace()
   PlaybookInclude.load(data,basedir)

# Generated at 2022-06-23 06:43:52.522040
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    include = PlaybookInclude()
    assert(include.vars == {})
    assert(include.tags == [])
    assert(include.when == [])
    assert(include.import_playbook is None)
    assert(include.debug_str() == 'PlaybookInclude')

    include = PlaybookInclude(vars={'hosts': 'testhost'}, import_playbook=['test.yml'], tags=['tag1', 'tag2'], when=["testvar == 'testvalue'"])
    assert(include.vars == {'hosts': 'testhost'})
    assert(include.tags == ['tag1', 'tag2'])
    assert(include.when == ["testvar == 'testvalue'"])
    assert(include.import_playbook == ['test.yml'])
   

# Generated at 2022-06-23 06:43:59.712328
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.config.manager import ConfigManager

    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    config = ConfigManager()

    # create datastructure test
    ds = AnsibleMapping()
    ds['import_playbook'] = 'example.yml'

    # create variable manager
    variable_manager = VariableManager()

    # create data loader
    loader = DataLoader(config.get_configuration_definition())

    # run method
    PlaybookInclude.load(ds, '.', variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-23 06:44:05.147079
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
        data = {'import_playbook': 'include playbook', 'vars': {'foo': 'bar'}}
        playbook_include = PlaybookInclude.load(data, '', variable_manager=None)
        assert playbook_include.import_playbook == 'include playbook'
        assert playbook_include.vars['foo'] == 'bar'

# Generated at 2022-06-23 06:44:10.009993
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.playbook_include import PlaybookInclude
    # Empty mapping
    ds = {}
    new_ds = PlaybookInclude._preprocess_import(ds, 'k', 'v')
    assert new_ds == ds


# Generated at 2022-06-23 06:44:23.044890
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing import load

    # load the test play file
    datastructure = load('test/playbook_include_test.yml')

    # now process the contents
    assert isinstance(datastructure[0], PlaybookInclude)

    assert len(datastructure) == 8
    assert datastructure[0].import_playbook == 'foo.yaml'
    assert datastructure[0].vars == dict()
    assert datastructure[1].import_playbook == 'foo.yaml'
    assert datastructure[1].vars == dict(name='bob')
    assert datastructure[2].import_playbook == 'bar.yml'
    assert datastructure[2].vars == dict()