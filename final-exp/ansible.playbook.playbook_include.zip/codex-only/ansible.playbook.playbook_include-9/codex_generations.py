

# Generated at 2022-06-23 06:34:23.016533
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-23 06:34:32.066831
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    import os.path
    fixtures_path = os.path.join(os.path.dirname(__file__), 'fixtures')
    hosts_path = os.path.join(fixtures_path, 'test_playbook_include.inv')
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=hosts_path)
    variable_manager.set_inventory(inventory)
    playbook_file = os.path.join(fixtures_path, 'test_playbook_include.yml')

# Generated at 2022-06-23 06:34:41.171791
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    try:
        PlaybookInclude.load({"import_playbook": "foo", "vars": {"x": 1}}, None)
    except Exception as e:
        assert False, "playbook import statement with vars is not allowed: %s" % e

    try:
        PlaybookInclude.load({"import_playbook": "foo", "tags": ["bar", "baz"]}, None)
    except Exception as e:
        assert False, "playbook import statement with tags is not allowed: %s" % e

    # test that import_playbook can accept a list (we might want to do this in the future)
    pb_obj = PlaybookInclude.load({"import_playbook": "import a"}, None)

# Generated at 2022-06-23 06:34:44.233818
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pci = PlaybookInclude()
    assert pci
    assert pci._vars == {}
    pci2 = PlaybookInclude()
    assert pci2 == pci

# Generated at 2022-06-23 06:34:55.263624
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    ds = {'import_playbook': 'path/to/playbook.yml',
          'vars': {'var1': 'foo', 'var2': 'bar'}}
    # first, we use the original parent method to correctly load the object
    # via the load_data/preprocess_data system we normally use for other
    # playbook objects
    new_obj = PlaybookInclude().load_data(ds=ds, basedir=None, variable_manager=None, loader=None)
    print(new_obj)

    # then we use the object to load a Playbook
    pb = Playbook(loader=None)

# Generated at 2022-06-23 06:35:06.331592
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # an example object for the PlaybookInclude class
    #
    # this one just has an import file and a tags parameter
    data = """
    - import_playbook: test_include.yml
      tags:
        - test_tag
        - test_tag2
    """

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # create the object
    pl = PlaybookInclude.load(data, variable_manager=VariableManager(), loader=DataLoader())

    # assert that it parsed correctly
    assert pl.import_playbook == 'test_include.yml'
    assert isinstance(pl.vars, dict)
    assert pl.tags == ['test_tag', 'test_tag2']


# Generated at 2022-06-23 06:35:10.493198
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    pb = PlaybookInclude()
    expected = Playbook()
    expected._entries = [Play().load(dict(hosts='localhost'))]
    actual = pb.load_data(from_data=dict(import_playbook='test/test_play.yml'), basedir='test/test_play.yml')
    assert actual._entries == expected._entries, "Actual: %s\nExpected: %s\n" % (actual._entries, expected._entries)

# Generated at 2022-06-23 06:35:15.480665
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import ansible.playbook.playbook as pl
    playbook = pl.Playbook()
    playbook.set_variable_manager(pl.VariableManager())
    playbook.set_loader(pl.DataLoader())
    manager = playbook.get_variable_manager()
    loader = playbook.get_loader()

    data = {'import_playbook': '/home/user/ansible/test_import_playbook.yml'}
    pbi = PlaybookInclude.load(data, '/home/user/ansible/', manager, loader)
    for p in pbi._entries:
        assert p._included_path == '/home/user/ansible/'

# Generated at 2022-06-23 06:35:26.504417
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    data_structure_1 = {'import_playbook': 'test_path'}
    data_structure_2 = {'import_playbook': 'test_path tags=one,two,three'}
    data_structure_3 = {'import_playbook': 'test_path vars: {foo: one, bar: two}'}
    data_structure_4 = {'import_playbook': 'test_path tags=one,two,three vars: {foo: one, bar: two}'}
    data_structure_5 = {'import_playbook': 'test_path tags=one,two,three', 'vars': {'foo': 'one', 'bar': 'two'}}

# Generated at 2022-06-23 06:35:28.994270
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    #instance of class PlaybookInclude
    pbi =  PlaybookInclude()
    assert pbi



# Generated at 2022-06-23 06:35:41.077468
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    '''
    Unit test for constructor of class PlaybookInclude
    '''

    data = {
        'import_playbook': '../one.yml',
        'vars': {
            'a': 'b',
            'c': 'd',
        },
        'tags': ['one', 'two'],
        'when': 'foo'
    }

    p = PlaybookInclude(**data)
    assert data == p.serialize()

    data = {
        'IMPORT_PLAYBOOK': '../one.yml',
        'vars': {
            'a': 'b',
            'c': 'd',
            'e': 'f',
        },
        'tags': ['one', 'two'],
        'when': 'foo'
    }


# Generated at 2022-06-23 06:35:51.399365
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader

    my_loader = AnsibleLoader(None, None)

# Generated at 2022-06-23 06:35:58.406131
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''
    Exercises the load_data() method to load a Play object
    '''

    # import here to avoid a dependency loop
    from ansible.playbook import Playbook

    # we have to have a playbook object to test this
    pb = Playbook()
    pb._entries = [ ]

    # first test: basic actions

# Generated at 2022-06-23 06:36:07.310034
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    playbookInclude = PlaybookInclude()

    # Test load_data function
    # Test when ds is of wrong type
    try:
        playbookInclude.load_data(ds=1, basedir='', variable_manager=None, loader=None)
        assert False
    except AnsibleAssertionError as e:
        assert str(e) == 'ds (1) should be a dict but was a <type \'int\'>'

    # Test when ds is an empty dict

# Generated at 2022-06-23 06:36:18.612423
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    yaml_data = """
    - import_playbook: test.yml
      when: test_cond
      vars:
        some_var1: some_value1
        some_var2: some_value2
        some_var3: some_value3
        var_to_overwrite: val_to_overwrite
    """
    data = PlaybookInclude.load(data=yaml_data, basedir=".")
    assert data.import_playbook == "test.yml"
    assert data.when == "test_cond"
    assert data.vars.get("some_var1") == "some_value1"
    assert data.vars.get("some_var2") == "some_value2"
    assert data.vars.get("some_var3") == "some_value3"


# Generated at 2022-06-23 06:36:30.177798
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # Check code for issue #35201
    # https://github.com/ansible/ansible/issues/35201
    #
    # We run the same of code from the issue using Python3.7,
    # and it does not raise an exception for us,
    # and it does not raise an exception for us.

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.yaml.loader import Ansible

# Generated at 2022-06-23 06:36:34.826971
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    """
    Create an instance of PlaybookInclude and test method load_data.
    """
    import_playbook, basedir, variable_manager = "pb1.yml", "/tmp", None
    loader = None
    ds = dict(import_playbook=import_playbook)
    pi = PlaybookInclude()
    pi.load_data(ds=ds, basedir=basedir, variable_manager=variable_manager, loader=loader)
    assert pi.import_playbook == import_playbook
    assert pi.basedir == basedir



# Generated at 2022-06-23 06:36:44.591199
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    result = PlaybookInclude.load({'include': 'test_playbook.yml tags=tag1,tag2'})
    assert result.import_playbook == 'test_playbook.yml'
    assert result.tags == ['tag1', 'tag2']
    assert result.vars == {}

    result = PlaybookInclude.load({'include': 'test_playbook.yml vars: var1=value1 var2=value2'})
    assert result.import_playbook == 'test_playbook.yml'
    assert result.vars == {'var1': 'value1', 'var2': 'value2'}

    result = PlaybookInclude.load({'include': 'test_playbook.yml var1=value1 var2=value2'})

# Generated at 2022-06-23 06:36:56.393070
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.vars import VariableManager


# Generated at 2022-06-23 06:37:07.893284
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    '''
    Test load method of class PlaybookInclude
    '''
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    # Test load method without variable manager
    pb_inc = PlaybookInclude.load(ds={'import_playbook': 'playbooks/play_other.yml'}, basedir='.')
    assert isinstance(pb_inc, Playbook)
    assert len(pb_inc._entries) == 1
    assert isinstance(pb_inc._entries[0], Play)
    assert len(pb_inc._entries[0].tasks) == 1
    assert isinstance(pb_inc._entries[0].tasks[0], Task)

    # Test load method with variable manager

# Generated at 2022-06-23 06:37:20.590908
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play

    from units.mock.loader import DictDataLoader


# Generated at 2022-06-23 06:37:36.171965
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import sys
    import yaml

    # test all supported pre vars formats
    # the first four are all deprecated, the last one is still supported

# Generated at 2022-06-23 06:37:36.614004
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-23 06:37:39.999771
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # TODO: add a unit tests for constructor of class PlaybookInclude
    pass

# Generated at 2022-06-23 06:37:40.686256
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-23 06:37:52.624391
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    class TestPlaybookInclude(PlaybookInclude):
        def __init__(self, *args, **kwargs):
            super(TestPlaybookInclude, self).__init__(*args, **kwargs)
            import argparse
            self.parser = argparse.ArgumentParser()

    playbook_include = TestPlaybookInclude(loader=None)

    # test case 1
    test_data = AnsibleMapping()
    test_data['import_playbook'] = 'file_a'
    test_data['tags'] = 'a,b'
    test_data['vars'] = {"a": "b"}
    test_data[0] = 'file_a'
    test_data[1] = 'tag=a,b vars=a=b'

# Generated at 2022-06-23 06:37:53.654949
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-23 06:37:54.672236
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass # TODO

# Generated at 2022-06-23 06:38:06.393804
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.display import Display

    example = """
- import_playbook: test.yml
"""
    ds = AnsibleLoader(None, file_name=to_bytes(example)).get_single_data()
    pb = PlaybookInclude.load(ds[0], '', None, None)
    results = pb.preprocess_data(ds[0])
    assert results['import_playbook'] == 'test.yml'

    example = """
- import_playbook: test.yml vars:
    foo: bar
  tags:
    - tag1
"""

# Generated at 2022-06-23 06:38:16.482635
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook

    # Create a basic PlaybookInclude
    ds = {
        'import_playbook': 'pb.yml'
    }

    basedir = os.path.join(os.path.dirname(__file__), 'playbook_include')
    playbook = PlaybookInclude.load(ds, basedir=basedir)

    assert playbook is not None
    assert isinstance(playbook, Playbook)
    assert len(playbook._entries) == 2

    # Check first included play (pre-tasks)
    play = playbook._entries[0]
    assert isinstance(play, Play)
    assert len(play.pre_tasks) == 1
    assert len(play.tasks) == 0
    assert len(play.post_tasks) == 0

# Generated at 2022-06-23 06:38:29.417005
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.playbook import Playbook

    class Options(object):

        def __init__(self, verbosity=0, tags=None, listhosts=False, listtasks=False, listtags=False, syntax=False):
            self.verbosity = verbosity
            self.tags = tags
            self.listhosts = listhosts
            self.listtasks = listtasks
            self.listtags = listtags
            self.syntax = syntax

    class VariableManager(object):

        def __init__(self):
            self.extra_vars = {}
            self.vars_cache = {}

    # No error if argument is ansible playbook
    playbook = '''
    - import_playbook: test.yml
    '''
    options = Options()
    variable_manager = VariableManager()

    p

# Generated at 2022-06-23 06:38:38.923208
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude

    pb = PlaybookInclude.load({
        "hosts": 'all',
        "import_playbook": "first.yml",
        "roles": [{"role": "test1"}],
        "tasks": [{"include": "other.yml"}],
        "pre_tasks": [{"include": "other.yml", "name": "pre"}],
        "post_tasks": [{"include": "other.yml", "name": "post"}],
        "tags": ["include1"],
        "vars": {"foo": "bar"},
    }, "/tmp")

    assert isinstance(pb, Playbook)
   

# Generated at 2022-06-23 06:38:52.296838
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    ds = dict(
        include = 'testinc.yml',
    )
    variable_manager = VariableManager()
    variable_manager.extra_vars = {"test_var": "test"}
    loader = DataLoader()
    # here we resolve the inventory filepath
    inv_path = loader.path_dwim("inventory.txt")
    inventory = InventoryManager(loader, variable_manager, inv_path)
    results = PlaybookInclude.load(ds, [inv_path], variable_manager, loader)
    assert results is not None


# Generated at 2022-06-23 06:38:53.104102
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-23 06:39:04.279757
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    playbook_data = dict(
        import_playbook = '../foo.yml',
        vars = dict(a=1, b=2),
        tags = 'tag_one,tag_two',
    )
    # FIXME: This test should set up a test collection and use the path to
    # that test collection in the playbook data.  However, the collection
    # loader code needs to be refactored to make it easier to unit test.
    # For now, load a different playbook which we know is not a collection
    # playbook.
    playbook_data['import_playbook'] = playbook_data['import_playbook'].replace('../foo.yml', '../test/playbooks/playbook_include/playbook.yml')

# Generated at 2022-06-23 06:39:16.414543
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    playbook_include = PlaybookInclude()

    assert playbook_include.import_playbook is None
    assert len(playbook_include.vars) == 0
    assert playbook_include._import_playbook is None
    assert playbook_include._vars is None

    playbook_include.import_playbook = 'test_playbook.yml'
    playbook_include.vars['var1'] = 'test_value1'
    playbook_include.vars['var2'] = 'test_value2'

    # test that _import_playbook and _vars is same as import_playbook and vars
    assert playbook_include._import_playbook == playbook_include.import_playbook
    assert playbook_include._vars == playbook_include.vars

    # test that we can set _import_playbook and _vars and get

# Generated at 2022-06-23 06:39:17.305825
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass



# Generated at 2022-06-23 06:39:24.097273
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    '''
    Unit test for method preprocess_data of class PlaybookInclude
    '''
    import json
    import pytest
    from ansible.utils.display import Display
    from ansible.parsing.yaml.data import AnsibleMapping
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task


# Generated at 2022-06-23 06:39:28.574262
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # Test loading of a playbook without a dictionary
    filename = 'filename'
    pb = PlaybookInclude(import_playbook=filename)
    assert pb.import_playbook == filename
    assert pb.vars == {}

# Generated at 2022-06-23 06:39:36.465337
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    pb_name = 'testPlaybookInclude.yml'
    p = PlaybookInclude()
    pb = p.load(pb_name, './test/units/plugins/test_playbook_inlcude', None, None)

    assert isinstance(pb, Playbook)
    assert len(pb._entries) == 4

    assert isinstance(pb._entries[0], Play)
    assert pb._entries[0].name == 'testPlaybookInclude.yml (1)'
    assert pb._entries[0]._included_path is not None
    assert pb._entries[0].vars['test_playbook_include_var1'] == 'value1'

# Generated at 2022-06-23 06:39:42.828420
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml_obj = AnsibleLoader(None, None).load('''
- include_playbook: stuff.yml
''')[0]

    pb = PlaybookInclude()
    pb.load_data(yaml_obj, variable_manager=None, loader=None)

# Generated at 2022-06-23 06:39:55.491063
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    ds = {}
    ds['import_playbook'] = "test.yml"
    ds['vars'] = {'key1': 'val1', 'key2': 'val2'}
    ds['tags'] = 'tag1,tag2'
    ds['when'] = 'ansible_os_family == "RedHat"'

    ds_test = AnsibleMapping()
    ds_test['import_playbook'] = "test.yml"
    ds_test['vars'] = {'key1': 'val1', 'key2': 'val2'}
    ds_test['tags'] = 'tag1,tag2'
    ds_test['when'] = ['ansible_os_family == "RedHat"']

    obj = PlaybookInclude()
    obj.preprocess

# Generated at 2022-06-23 06:40:06.465170
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import json
    import yaml

    # loading a whole playbook
    basedir = 'test/integration/playbooks'
    playbook_file = 'test_include.yml'
    ds = {'import_playbook': playbook_file}
    ds = yaml.load(yaml.dump(ds))
    ds = PlaybookInclude().preprocess_data(ds)
    pb = PlaybookInclude().load_data(ds, basedir)
    result = json.loads(pb.dump())
    assert(len(result['plays']) == 4)

    # loading a single play
    basedir = 'test/integration/playbooks'
    playbook_file = 'test_include.yml'

# Generated at 2022-06-23 06:40:19.465903
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.parsing.vault import VaultLib
    from ansible.vars.manager import VariableManager

    vault = VaultLib([])
    varmgr = VariableManager(loader=None, inventory=None, vault_secrets=vault)
    # iana: case 1
    data = dict(import_playbook='play.yml', tags=['t1', 't2'], vars=dict(var1='v1', var2=dict(k1='v1', k2='v2')))
    expected_data = dict(import_playbook='play.yml', tags=['t1', 't2'], vars=dict(var1='v1', var2=dict(k1='v1', k2='v2')))

# Generated at 2022-06-23 06:40:33.438414
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    # prepare a minimal PlaybookInclude object
    data = {
        'import_playbook': '/path/to/include.yml',
        'vars': {
            'with': 'variable'
        }
    }
    basedir = '/path/to'
    variable_manager = None
    loader = None
    playbook_include = PlaybookInclude()
    playbook_include.load_data(data, basedir, variable_manager, loader)

    assert playbook_include._import_playbook == '/path/to/include.yml'
    assert playbook_include.vars['with'] == 'variable'

    # mocks
    import ansible.playbook.play
    import os


# Generated at 2022-06-23 06:40:46.651360
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    C._ACTION_IMPORT_PLAYBOOK = ['include', 'import_playbook']
    print("Testing method load of class PlaybookInclude")
    # Test case:
    ds = {
        'include': 'outside.yml',
        'vars': {'testing': True},
        'tags': 'tag,tag2'
    }

    file_name = 'include'

    # Test case:
    # No such file
    pb = PlaybookInclude.load(ds, file_name, 1, 1)
    assert pb.file_name == 'outside.yml'
    assert pb.name == 'outside.yml'
    assert pb.vars == {'testing': True}
    assert pb.tags == ['tag', 'tag2']



# Generated at 2022-06-23 06:40:54.597617
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible import constants as C

    valid_data = '''
    - import_playbook: /path/to/playbook.yml
    - import_playbook: /path/to/playbook.yml option1=1 option2=2
    - import_playbook: /path/to/playbook.yml option1=1
    - import_playbook: /path/to/playbook.yml tags=foo,bar
    - import_playbook: /path/to/playbook.yml option1=1 tags=foo,bar
    - import_playbook: /path/to/playbook.yml vars: option1: 2
    - import_playbook: /path/to/playbook.yml option1=1 vars: option2: 2 option3: 3
    '''

    invalid_data

# Generated at 2022-06-23 06:40:56.501558
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-23 06:41:02.432616
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # test param 'import_playbook'
    pbi = PlaybookInclude()
    # test param 'vars'
    pbi = PlaybookInclude()
    assert type(pbi.vars) is dict
    pbi = PlaybookInclude(vars={'key': 'value'})
    assert type(pbi.vars) is dict
    assert pbi.vars['key'] == 'value'



# Generated at 2022-06-23 06:41:14.404138
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    import ansible.playbook.play
    import ansible.playbook.task
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader

    basedir = "/home/user/tests/project"
    variable_manager = None
    loader = AnsibleLoader(None, variable_manager)

    # TODO: Should it be possible to load data into a Playbook instance?
    #       Apparently, ds in test_Playbook_load_data() is a Playbook instance
    #       without a loader defined.
    #       In this test method, ds is defined as an AnsibleMapping
    #       (see class PlaybookInclude, method load_data)
    # If so, the test fails with the following error:
    #
    #     AnsibleAssertionError: ds (<

# Generated at 2022-06-23 06:41:20.582939
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Given
    pbi = PlaybookInclude()
    ds = {'import_playbook': 'playbook.yml'}
    # When
    result = pbi.preprocess_data(ds)
    # Then
    assert isinstance(result, AnsibleMapping)
    assert len(result.keys()) == 2
    assert result['import_playbook'] == 'playbook.yml'
    assert result['vars'] == dict()



# Generated at 2022-06-23 06:41:26.967975
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    PlaybookInclude(import_playbook='include/.yml', vars=dict(content='this is my content')).post_validate()
    try:
        PlaybookInclude(import_playbook=dict(), vars=dict()).post_validate()
        assert False, "import_playbook should not have been able to be set to an empty dict"
    except AnsibleAssertionError:
        pass
    try:
        PlaybookInclude(import_playbook=None, vars=dict()).post_validate()
        assert False, "import_playbook should not have been able to be set to None"
    except AnsibleParserError:
        pass

# Generated at 2022-06-23 06:41:37.272944
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook import Playbook

    ds = PlaybookInclude.load(ds=dict(import_playbook='../../load_me.yml'), basedir='/path/to/basedir', variable_manager=VariableManager(), loader=DataLoader())
    pb = Playbook.load(ds, variable_manager=VariableManager(), loader=DataLoader())

    assert pb.basedir == '/path/to/basedir'
    assert pb.vars == {}
    assert pb.filters == {}
    assert pb.inventory == InventoryManager()
    assert len(pb.playbook) == 2

# Generated at 2022-06-23 06:41:38.787422
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    h = PlaybookInclude()
    assert h is not None

# Generated at 2022-06-23 06:41:48.229151
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # empty
    res = PlaybookInclude._preprocess_import(dict(), dict(), 'k', None)
    assert res is None

    # invalid vars
    with pytest.raises(AnsibleParserError):
        PlaybookInclude._preprocess_import(dict(), dict(), 'vars', None)
    with pytest.raises(AnsibleParserError):
        PlaybookInclude._preprocess_import(dict(), dict(), 'vars', '1')
    with pytest.raises(AnsibleParserError):
        PlaybookInclude._preprocess_import(dict(), dict(), 'vars', 1)

    # test with vars
    d1 = dict()
    d1['vars'] = 'a: 1'
    res = PlaybookInclude.preprocess_data(d1)
    assert res

# Generated at 2022-06-23 06:41:48.955449
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pass

# Generated at 2022-06-23 06:41:52.908274
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # we should test both the normal case and the case where load() is called

    # we should also test the case where the included playbook has
    # variables that should override defaults

    # TODO: something similar for PlaybookIncludes (as done for Plays)
    assert True


# Generated at 2022-06-23 06:41:54.633054
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    playbook_include = PlaybookInclude()
    assert playbook_include is not None


# Generated at 2022-06-23 06:42:04.643142
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Playbook
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    playbook_path = './test/fixtures/playbooks/include_play.yml'

    pb_include = PlaybookInclude.load(
        data={'include': playbook_path},
        basedir='.',
    )
    assert isinstance(pb_include, Playbook)
    assert len(pb_include._entries) == 1
    assert pb_include._entries[0].name == 'role'
    assert pb_include._entries[0].hosts == ['all']
    assert len(pb_include._entries[0].roles) == 1

# Generated at 2022-06-23 06:42:16.133173
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml_str = """
---
- import_playbook: invalid
    tags:
      - tag1
      - tag2
    vars:
      var1: value1
      var2: value2
- import_playbook: valid.yml tags=tag3,tag4 var=value3
- import_playbook: valid.yml
    tags:
      - tag5
    vars:
      var4: value4
      var5: value5
    """

    yaml_data = AnsibleLoader(yaml_str).get_single_data()
    obj = PlaybookInclude().load_data(yaml_data, None)
    valid_obj = obj._entries[0]

# Generated at 2022-06-23 06:42:28.900320
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    data = dict()
    data['import_playbook'] = 'foo'
    data['ignore_errors'] = 'true'
    data['vars'] = dict()
    data['vars']['bar'] = 1
    data['priority'] = 0
    data['tags'] = 'some, more, tags'

    include = PlaybookInclude().load_data(ds=data, basedir='/foo')
    # We cannot directly compare data and include, because the data is of
    # dictionaries, while the include is of objects. The dictionaries are
    # nested, while the objects are flat.

    # Comparing simple attributes
    assert include.import_playbook == 'foo'
    assert include.ignore_errors == 'true'
    assert include.priority == 0

    # Comparing tags

# Generated at 2022-06-23 06:42:40.598334
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    basedir = os.path.join(os.path.dirname(os.path.realpath(__file__)), '..')
    include_data = {
        'hosts': 'all',
        'vars': {
            'sub_var': 'sub_value',
        },
        'import_playbook': 'sub.yml',
    }
    playbook_data = {'sub_var': 'sub_value'}

    pb = PlaybookInclude.load(include_data, basedir)
    assert isinstance(pb, Playbook)
    assert len(pb._entries) == 1
    assert isinstance(pb._entries[0], Play)
    vars = pb._entries[0].vars

# Generated at 2022-06-23 06:42:48.471485
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # Make sure we can create a PlaybookInclude object
    PlaybookInclude.load({
        'import_playbook': 'myhost1.yml',
        'vars': {'var1': 1, 'var2': 'two'}
    }, None, None)

    # Try with more than one file.
    # This is deprecated.
    PlaybookInclude.load({
        'import_playbook': 'myhost1.yml,myhost2.yml',
        'vars': {'var1': 1, 'var2': 'two'}
    }, None, None)

    # Try with more than one file, and extra parameters
    # This is deprecated.

# Generated at 2022-06-23 06:42:59.338825
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import ansible.playbook 
    obj = PlaybookInclude()
    obj.import_playbook = "/tmp/my_playbook.yml"
    obj.vars = {"a":"b"}
    
    fake_basedir = "/tmp"
    fake_variable_manager =  ansible.playbook.VariableManager()
    fake_loader = "fake_loader"

    pb = obj.load_data({}, fake_basedir, fake_variable_manager, fake_loader)
    assert pb.__class__.__name__ == 'Playbook'
    assert pb._variable_manager.__class__.__name__ == 'VariableManager'
    assert pb._loader.__class__.__name__ == 'DataLoader'


# Generated at 2022-06-23 06:43:01.030185
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # No unit test for the method PlaybookInclude.load
    # because of the use of dynamic import of AnsibleBaseYAMLObject
    assert True

# Generated at 2022-06-23 06:43:01.530866
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-23 06:43:06.387743
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    """
    Constructor Test for class PlaybookInclude
    """
    assert PlaybookInclude.load({}) is not None
    assert PlaybookInclude.load({"import_playbook": "test.yml",
                                 "vars": {"myvar": "myvalue"}}) is not None

# Load test for preprocess_data of class PlaybookInclude

# Generated at 2022-06-23 06:43:09.886051
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    p = PlaybookInclude.load({}, '/root')


# Generated at 2022-06-23 06:43:13.575004
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # ansible.playbook.included_file.PlaybookInclude.load_data()
    pass



# Generated at 2022-06-23 06:43:22.765121
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # Make a fake PlaybookInclude object (since we've been
    # testing it 'abstractly' until now)
    pbi = PlaybookInclude()

    # set a fake import_playbook
    pbi.import_playbook = '/path/to/fake_file'

    # set a fake basedir
    basedir = '/path/to/basedir'

    # set a fake variable_manager
    variable_manager = {
        'vars': {
            'fake_var': 'fake_value'
        }
    }

    # set a fake loader
    loader = {
        'module_utils': 'fake_module_utils'
    }

    # set a fake data structure

# Generated at 2022-06-23 06:43:35.288903
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    import shutil
    import tempfile

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()
    collection_name = "my_collection"
    collection_path = os.path.join(tmp_dir, collection_name)

    # Create a collection named my_collection
    my_collection = os.path.join(tmp_dir, collection_name)
    shutil.copytree(os.path.join(os.path.dirname(__file__), 'data/collections_data/test_collection/'), my_collection)

    # Create a collection named another_collection
    another_collection = os.path.join(tmp_dir, "another_collection")

# Generated at 2022-06-23 06:43:37.738988
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    playbook_include = PlaybookInclude()
    assert playbook_include


# Generated at 2022-06-23 06:43:49.098925
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.module_utils.six import StringIO
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleVaultEncryptedUnicode

    # Test normal case
    ds1 = "~/path/to/import_file.yml"
    ds1 = PlaybookInclude.load(ds1, '/home/ansible')
    assert isinstance(ds1, PlaybookInclude)
    assert ds1.import_playbook == "~/path/to/import_file.yml"

    # Test with vars
    ds2 = "- import_playbook: ~/path/to/import_file.yml\n  vars: {}"
    ds2 = PlaybookInclude.load(ds2, '/home/ansible')

# Generated at 2022-06-23 06:43:58.636464
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    from ansible.playbook.play import Play

    playbook_include_obj = PlaybookInclude.load(dict(
        import_playbook='some_playbook.yml',
        vars=dict(a=1, b=2)
    ))

    ansible_playbook_array = playbook_include_obj.load_data(dict(
        import_playbook='some_playbook.yml',
        vars=dict(a=1, b=2)
    ), '.')

    assert(isinstance(ansible_playbook_array, Play))
    assert(len(ansible_playbook_array._entries) == 1)
    assert(ansible_playbook_array._entries[0].vars['a'] == 1)

# Generated at 2022-06-23 06:44:10.860908
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    playbook_include = PlaybookInclude()
    assert playbook_include._import_playbook is None
    assert playbook_include._vars == {}
    assert playbook_include.tags is None
    assert playbook_include._attributes['when'] is None
    assert playbook_include._included_path is None

    playbook_include = PlaybookInclude(import_playbook='test.yml', vars={'a': 'b'}, tags=['test'], when="ansible_os_family != 'RedHat'")
    assert playbook_include._import_playbook == 'test.yml'
    assert playbook_include._vars == {'a': 'b'}
    assert playbook_include.tags == ['test']
    assert playbook

# Generated at 2022-06-23 06:44:20.101038
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    PlaybookInclude.load_data({
        "import_playbook": "/etc/ansible/test_playbook",
        "vars": {
            "foo": "bar"
        }
    }, "/Users/presi")
    assert isinstance(PlaybookInclude.load_data({
        "import_playbook": "/etc/ansible/test_playbook",
        "vars": {
            "foo": "bar"
        }
    }, "/Users/presi"), Playbook)


# Generated at 2022-06-23 06:44:29.254485
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    from ansible.playbook.group import Group
    from ansible.playbook.host import Host
    from ansible.playbook.task import Task

    play_data = dict(
        name="Ansible Play",
        hosts=["all"],
        tasks=[
            dict(action=dict(module="setup"), register="shell_out"),
            dict(action=dict(module="debug", msg="{{shell_out.stdout}}"))
        ]
    )
    include_data = dict(
        import_playbook="test.yml"
    )

    loader, inventory, variable_manager = testing_help.get_test_objects()
