

# Generated at 2022-06-23 06:34:38.250013
# Unit test for method preprocess_data of class PlaybookInclude

# Generated at 2022-06-23 06:34:50.930368
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude

    # test ansible tag usage
    ds = { 'include': 'foobar' }
    new_ds = PlaybookInclude().preprocess_data(ds)
    assert(new_ds['import_playbook'] == 'foobar')

    # test ansible tag usage
    ds = { 'import_playbook': 'foobar' }
    new_ds = PlaybookInclude().preprocess_data(ds)
    assert(new_ds['import_playbook'] == 'foobar')

    # test ansible tag usage
    ds = { 'import_playbook': 'foobar', 'when': 'foo' }
    new_ds = PlaybookInclude().preprocess_data(ds)

# Generated at 2022-06-23 06:34:51.751498
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-23 06:35:02.869856
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    playbook = PlaybookInclude.load(
        data={
            u'import_playbook': u'test_play',
            u'tags': u'upgrade'
            },
        basedir=u'/datadisks/d1/dmimura/git/oneops/ansible',
        variable_manager='',
        loader='')

    # check import of playbook
    assert isinstance(playbook, Playbook)
    assert playbook.filename == u'/datadisks/d1/dmimura/git/oneops/ansible/test_play'
    assert playbook.role_names == []
    assert playbook.entry_point is None

    # check import of play
    assert len(playbook._entries) == 1
    play = playbook

# Generated at 2022-06-23 06:35:12.381854
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude

    plinc = PlaybookInclude()

    # first test : with a simple import_playbook
    data = { 'import_playbook': './test.yml' }
    pb = plinc.load_data(data, basedir='./')

    assert pb._entries[0].name == 'test'
    assert isinstance(pb._entries[0], Play)
    assert len(pb._entries[0].tasks)

# Generated at 2022-06-23 06:35:17.807423
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    _loader = DictDataLoader({})
    ds = AnsibleMapping()

    obj = PlaybookInclude()

    new_ds = AnsibleMapping()
    obj._preprocess_import(ds, new_ds, 'import_playbook', None)

    assert isinstance(new_ds, AnsibleMapping)
    assert len(new_ds) == 1
    assert 'import_playbook' in new_ds
    assert new_ds['import_playbook'] is None

    new_ds = AnsibleMapping()
    obj._preprocess_import(ds, new_ds, 'import_playbook', 42)

    assert isinstance(new_ds, AnsibleMapping)
    assert len(new_ds) == 1
    assert 'import_playbook' in new_ds

# Generated at 2022-06-23 06:35:19.740143
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    print('In test_PlaybookInclude()')

    playbook_include = PlaybookInclude()

    print(playbook_include)

    playbook_include = PlaybookInclude.load({})

    print(playbook_include)

if __name__ == "__main__":
    test_PlaybookInclude()

# Generated at 2022-06-23 06:35:30.252597
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    """Unit tests for PlaybookInclude.preprocess_data
    """
    import unittest
    import ansible
    from ansible.playbook.playbook_include import PlaybookInclude

    class MyPlaybookInclude(PlaybookInclude):
        pass

    class MyPlaybookInclude1(PlaybookInclude):
        pass

    class MyPlaybookInclude2(PlaybookInclude):
        pass

    class MyPlaybookInclude3(PlaybookInclude):
        pass

    class MyPlaybookInclude4(PlaybookInclude):
        pass

    class MyPlaybookInclude5(PlaybookInclude):
        pass

    class MyPlaybookInclude6(PlaybookInclude):
        pass

    class MyPlaybookInclude7(PlaybookInclude):
        pass


# Generated at 2022-06-23 06:35:41.137643
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.role.definition import RoleDefinition
    test_data = AnsibleMapping({'import_playbook': 'include_playbook.yml', 'vars': {'var1': 'value1'}})
    include_playbook = PlaybookInclude.load(test_data, os.getcwd())
    include_playbook.preprocess_data(test_data)
    assert isinstance(include_playbook, PlaybookInclude)
    test_data = AnsibleBaseYAMLObject({'import_playbook': 'include_playbook.yml', 'vars': {'var1': 'value1'}})
    test_data.ansible_pos = {}
   

# Generated at 2022-06-23 06:35:42.647141
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pb = PlaybookInclude()
    assert pb._import_playbook == None
    assert pb.vars == {}

# Generated at 2022-06-23 06:35:48.634819
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # Setup
    import unittest
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    import ansible.playbook.play_context
    from ansible.playbook.task_include import TaskInclude
    playbook = PlaybookInclude.load(data={}, basedir='/tmp', variable_manager=None, loader=None)
    # assert playbook
    assert playbook == None


# Generated at 2022-06-23 06:35:56.360896
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader
    options = parser.parse_args()
    loader = DataLoader()
    variable_manager = VariableManager()
    host_list = ['localhost']
    host = Host(name='localhost')
    playbook = Playbook()
    playbook.set_variable_manager(variable_manager)
    variable_manager.set_playbook_basedir(playbook.basedir)
    variable_manager.extra_vars = load_extra_vars()
    variable_manager.options_vars = load_options_vars(options)
    variable_manager.set_inventory(inventory)
    pb = PlaybookInclude()
    pb.variable_manager = variable_manager
    pb.loader = loader

# Generated at 2022-06-23 06:36:06.623019
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy

    playbook_include = PlaybookInclude()

    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(planet='world')

    p = Play()
    p._ds = dict(hosts='host1')
    p._included_path = None
    p.vars = dict(hello='world', planet='earth')
    p.tasks = [TaskInclude()]
    p.t

# Generated at 2022-06-23 06:36:11.161990
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    yaml_data = '''\
    - hosts: all
      tasks:
        - name: check ping
          ping:

    - import_playbook: foo.yml
      vars:
        var1: value1
        var2: value2

    - import_playbook: foo2.yml
      vars:
        var1: value1
        var2: value2
      tags: imp, play
    '''

    from ansible.parsing.yaml.data import DataLoader

    data = DataLoader().load(yaml_data)[0]
    pb = PlaybookInclude.load(data[1], variable_manager=None, loader=None)
    assert pb.import_playbook == 'foo.yml'


# Generated at 2022-06-23 06:36:20.319897
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    collection_paths = AnsibleCollectionConfig.playbook_paths
    collection_paths.clear()
    collection_paths.append('/home/user/data/collections')

    try:
        PlaybookInclude.load(dict(import_playbook='ansible.collections.test_ns.test_coll.boo'),
                             basedir='.')
    except AssertionError:
        pass
    else:
        raise AssertionError('Import of collection playbook failed')

    ansible_playbook_paths = AnsibleCollectionConfig.playbook_paths
    AnsibleCollectionConfig.playbook_paths = collection_paths
    assert AnsibleCollectionConfig.playbook_paths == collection_paths

    AnsibleCollectionConfig.playbook_paths = ansible_playbook_paths

# Generated at 2022-06-23 06:36:21.856652
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-23 06:36:31.182510
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import sys
    import unittest
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    class TestPlaybookInclude(unittest.TestCase):

        def test_load_data(self):
            playbook_include = PlaybookInclude()
            playbook_include.import_playbook = './default.yml'

            playbook_dir = os.path.dirname(os.path.realpath(__file__))
            playbook = playbook_include.load_data(
                None, playbook_dir, None, None)

            self.assertIsInstance(playbook, Playbook)
            self.assertEqual(len(playbook._entries), 2)
            self.assertIsInstance(playbook._entries[0], Play)

# Generated at 2022-06-23 06:36:42.646016
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Setup - create a template for an include statement
    # Include file has no roles or tasks, but does have vars
    # (modified from include_role/tasks)
    ds = ansible.parsing.yaml.objects.AnsibleMapping()
    ds['import_playbook'] = '../../test/integration/includes/main.yml'
    ds['tags'] = 'include_tags'    
    ds.ansible_pos = (1,2)

    # Setup - create a template for a playbook
    # Playbook has no plays, roles, or tasks, but does have vars
    # (modified from test_playbook_load_data)
    pb = ansible.parsing.yaml.objects.AnsibleMapping()
    pb['hosts'] = 'local'


# Generated at 2022-06-23 06:36:54.235801
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    ds = AnsibleMapping()

    # test legacy playbook include with tags and vars
    ds['import_playbook'] = "foo.yml tags=bar_tag,baz_tag vars: foo=bar"
    print(ds)
    expected_new_ds = AnsibleMapping()
    expected_new_ds['import_playbook'] = "foo.yml"
    expected_new_ds['tags'] = "bar_tag,baz_tag"
    expected_new_ds['vars'] = dict(foo="bar")
    print(expected_new_ds)
    pb = PlaybookInclude()
    new_ds = pb.preprocess_data(ds)
    assert new_ds == expected_new_ds
    del ds

    # test playbook include with vars

# Generated at 2022-06-23 06:37:06.822211
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    from ansible.parsing.yaml.objects import AnsibleMapping
    import yaml

    # test preprocessing of a playbook include line with no additional
    # parameters
    data = yaml.load('''
    - import_playbook: test.yml
    ''')
    assert isinstance(data, list)

    include = PlaybookInclude()
    result = include.preprocess_data(data[0])
    assert isinstance(result, AnsibleMapping)
    assert result.keys() == ['import_playbook']
    assert result['import_playbook'] == 'test.yml'

    # test preprocessing of a playbook include line with a single
    # positional parameter
    data = yaml.load('''
    - import_playbook: test.yml one
    ''')

# Generated at 2022-06-23 06:37:11.796248
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    playbook_include_obj = PlaybookInclude()
    playbook_include = playbook_include_obj.load(data={}, basedir='/some/directory', variable_manager=None, loader=None)

# Generated at 2022-06-23 06:37:22.373001
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import ansible.playbook.play
    error_count = 0
    # PlaybookInclude.load_data() errors
    # 1. path is not set
    # 2. path is not set as a string type
    # 3. path is not an absolute path
    # 4. path is not a file
    # 5. invalid playbook
    # 6. load playbook file successfully
    try:
        # __getitem__(0) is the path, __getitem__(1) is the data structure
        # test case 1
        ansible.playbook.play.Play.load(None)
        error_count += 1
        display.display("test_PlaybookInclude_load_data(): Exception is not thrown for invalid path.")
    except Exception as e:
        pass

# Generated at 2022-06-23 06:37:32.597687
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory(os.path.join(os.path.dirname(__file__), 'vars', 'hosts')))
    variable_manager._extra_vars = {'test_playbook_include': ['1.1.1.1', '1.1.1.2']}
    variable_manager.set_play_context(PlayContext())
    variable_manager.set_loader(loader)

    d

# Generated at 2022-06-23 06:37:42.492374
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook = PlaybookInclude()
    data = {'import_playbook': 'test.yml', 'tags': 'tag1,tag2', 'vars': {'foo': 'bar'}}
    playbook.load_data(data, '')
    assert playbook._import_playbook == 'test.yml'
    assert playbook._tags == ['tag1', 'tag2']
    assert playbook._vars == {'foo': 'bar'}

    # test for error conditions
    data = {}
    try:
        playbook.load_data(data, '')
        assert False
    except AnsibleParserError:
        pass

    data = {'import_playbook': 'test.yml', 'vars': {'foo': 'bar'}}
    playbook.load_data(data, '')
    assert playbook._import_playbook

# Generated at 2022-06-23 06:37:48.318297
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from unittest import TestCase
    from ansible.playbook.role.include import RoleInclude
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.six import string_types
    import yaml

    class TestCase(TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def _extend_vars(self, vars_original, vars_to_extend):
            result = combine_vars(vars_original, vars_to_extend)
            return result

# Generated at 2022-06-23 06:38:01.421587
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    print()
    print("Test method load of class PlaybookInclude")
    from ansible.playbook.play import Play
    ds = {"import_playbook": "ansible/test_playbook.yml"}
    pbi = PlaybookInclude().load_data(ds, None)
    assert isinstance(pbi, PlaybookInclude)
    assert isinstance(pbi._entries[0], Play)
    display.verbosity = 3
    assert isinstance(pbi._entries[1], Play)
    assert pbi._entries[1].name == "pb_with_bad_syntax"
    assert pbi._entries[1]._included_path is None
    display.verbosity = 0

test_PlaybookInclude_load()

# Generated at 2022-06-23 06:38:08.985079
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # instantiate variable_manager and loader
    variable_manager = None
    loader = None

    # instantiate and call method to test
    target_obj = PlaybookInclude()
    actual_result = target_obj.load_data({'import_playbook': 'play.yml'},
                                                 '/path/to/basedir',
                                                 variable_manager,
                                                 loader)

    # assert isinstance(actual_result, Playbook)
    # assert actual_result.filename = '/path/to/basedir/play.yml'
    # assert actual_result._entries = [TODO]



# Generated at 2022-06-23 06:38:18.653428
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    from ansible.playbook.play import Play

    # Make sure the given data ds is dictionary
    ds = 'ds'
    pb = PlaybookInclude()
    try:
        pb.preprocess_data(ds)
    except AnsibleAssertionError:
        pass
    else:
        raise AssertionError('Preprocess data did not handle ds not of type dict.')

    # Make sure the import_playbook parameter is present
    ds = {}
    pb = PlaybookInclude()
    try:
        pb.preprocess_data(ds)
    except AnsibleParserError:
        pass
    else:
        raise AssertionError('Preprocess import did not handle import_playbook parameter'
                             'missing.')

    # Make sure the import_playbook parameter is a string
   

# Generated at 2022-06-23 06:38:31.431413
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    playbook = '''---
- hosts: localhost
  gather_facts: no
  tasks:
    - include_playbook: test.yml
      vars:
        var1: value1
      tags:
        - skip_tag1
        - skip_tag2
        - skip_tag3
'''

    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    pb = Playbook.load(playbook, loader=DataLoader(), variable_manager=VariableManager(), inventory=InventoryManager())
    assert(isinstance(pb, Playbook))

# Generated at 2022-06-23 06:38:38.483894
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # CHECK 1: return a Playbook() object
    import ansible.playbook
    import ansible.playbook.play
    class MyPlaybookInclude(PlaybookInclude):
        def load_data(self, ds, basedir, variable_manager=None, loader=None):
            return ansible.playbook.Playbook()

    class Test():
        def load(self):
            return MyPlaybookInclude()

    assert isinstance(PlaybookInclude.load(None, None, loader=Test()), ansible.playbook.Playbook), 'PlaybookInclude does not return a Playbook object'


# Generated at 2022-06-23 06:38:40.360788
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    playbook_include = PlaybookInclude()
    # playbook_include.load()

# Generated at 2022-06-23 06:38:49.936957
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    """
    Test whether `PlaybookInclude.load_data()` works as expected.
    """
    import_playbook = 'site.yml'

    vars = {'var_in_vars': 'var_in_vars'}
    ds = {'import_playbook': import_playbook, 'vars': vars}

    playbook_include = PlaybookInclude.load(ds, '.')
    assert playbook_include.import_playbook == import_playbook
    assert playbook_include.vars == vars

# Generated at 2022-06-23 06:39:02.786267
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play

    # Test with yaml from AnsibleModule.run_command

# Generated at 2022-06-23 06:39:08.051557
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    playbook_include = PlaybookInclude()
    assert playbook_include.import_playbook is None
    assert playbook_include.vars == {}
    assert playbook_include.tags == []
    assert playbook_include.conditional is None
    assert playbook_include.when is None


# Generated at 2022-06-23 06:39:12.679020
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    ds={"- import_playbook": "../import_playbook.yml"}
    p = PlaybookInclude(ds, basedir=None, variable_manager=None, loader=None)
    assert p.import_playbook == "../import_playbook.yml"

# Generated at 2022-06-23 06:39:21.081263
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()

    # test 1
    ds = {'import_playbook': 'test1.yml'}
    new_ds = PlaybookInclude().preprocess_data(ds)
    assert new_ds == {'import_playbook': 'test1.yml'}

    # test 2
    ds = {'import_playbook': 'test2.yml var1=toto'}
    new_ds = PlaybookInclude().preprocess_data(ds)
    assert new_ds == {'import_playbook': 'test2.yml', 'vars': {'var1': 'toto'}}

    # test 3


# Generated at 2022-06-23 06:39:34.408137
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    pb = PlaybookInclude()
    ds = AnsibleMapping({
        'import_playbook': 'test_pb.yml',
        'vars': {'ansible_forks': 100},
        'tags': ['tag1']})
    templar = Templar(loader=None, variables=None)
    playbook_path = os.path.abspath(os.path.join(os.getcwd(), 'test_pb.yml'))
    p = Playbook()
    p._load_playbook_data(file_name=playbook_path, variable_manager=None, vars=None)


# Generated at 2022-06-23 06:39:36.054710
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    playbook_include = PlaybookInclude()
    assert playbook_include

# Generated at 2022-06-23 06:39:38.302150
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pl = PlaybookInclude()
    assert pl._import_playbook is None
    assert pl._vars == {}
    assert pl.vars is not None
    assert pl.tags is not None
    assert pl.when is not None


# Generated at 2022-06-23 06:39:46.372941
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    #Create a PlaybookInclude object, then call the load_data method with ds
    # Make sure that the resulting data structure is what we expect
    playbookInclude = PlaybookInclude()
    ds = AnsibleMapping({'import_playbook': 'foo.yml'})
    result = playbookInclude.preprocess_data(ds)
    assert isinstance(result, AnsibleMapping)
    assert len(result.keys()) == 1
    assert 'import_playbook' in result
    assert result['import_playbook'] == 'foo.yml'

    ds = AnsibleMapping({'include': 'foo.yml'})
    result = playbookInclude.preprocess_data(ds)
    assert isinstance(result, AnsibleMapping)
    assert len(result.keys()) == 1

# Generated at 2022-06-23 06:39:52.436499
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    import_tasks = PlaybookInclude(import_playbook='/home/user/test_pb.yml', tags=['tag1', 'tag2'])
    assert import_tasks.import_playbook == '/home/user/test_pb.yml'
    assert 'tag1' in import_tasks.tags
    assert 'tag2' in import_tasks.tags

# Generated at 2022-06-23 06:39:54.980600
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    playbook_include = PlaybookInclude.load({'some_playbook.yml': {}}, loader=None)
    assert isinstance(playbook_include, PlaybookInclude)

# Generated at 2022-06-23 06:40:06.422195
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    import ansible.parsing.yaml.loader
    class TestLoader:
         def fail_on_undefined_errors(self):
             return True
    yaml_loader = ansible.parsing.yaml.loader.AnsibleLoader

    t = PlaybookInclude()

    ds = dict(import_playbook="test.yml", tags=["tag1", "tag2"])

    pb = t.load_data(ds, basedir='/', variable_manager=None, loader=TestLoader())

    # Test class PlaybookInclude
    def test_class_PlaybookInclude():
        assert isinstance(t, PlaybookInclude)

    # Test class Playbook
    def test_class_Playbook():
        assert isinstance(pb, PlaybookInclude)


# Generated at 2022-06-23 06:40:19.411017
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    '''
    This test data is of the form:
    #0 is a dictionary with the data
    #1 is a dictionary with the expected result
    #2 is a description of the result
    '''

# Generated at 2022-06-23 06:40:20.442874
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass # TODO: implement your test here

# Generated at 2022-06-23 06:40:29.094365
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    yaml_str = """
    - include: '<%= @path %>/../integration/smoke-tests/module_utils/facts/fixtures/collection.yml'
      name: 'smoke-test-facts'
      tags: 'smoke-test-facts'
      vars:
          collection: 'ansible.builtin'
    """
    res = AnsibleLoader(yaml_str, file_name=None, variable_manager=VariableManager(), loader=DataLoader()).get_single_data()

# Generated at 2022-06-23 06:40:31.024587
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pb = PlaybookInclude(None)
    assert pb is not None


# Generated at 2022-06-23 06:40:44.337806
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence

    loader = AnsibleLoader(None, dict(), variable_manager=None, loader=None)
    data = '''
- import_playbook: test.yml
- import_playbook: test.yml
  from: here
  vars:
    x: 1
    y: 2
- import_playbook: test.yml
  tags: [1, 2, 3]
- import_playbook: test.yml
  vars:
    a: 1
    b: 2
  tags: [1, 2, 3]
- import_playbook: test.yml
  when: 2 > 1
'''
    results = list(loader.load(data))


# Generated at 2022-06-23 06:40:53.233929
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook import Playbook
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    ds = { u'import_playbook': u'/home/user/test/main.yml', 'tags': u'blah' }
    pbi = PlaybookInclude()
    (import_playbook, tags, vars) = pbi._preprocess_import(ds, None, u'import_playbook', u'/home/user/test/main.yml blah')
    assert import_playbook == u'/home/user/test/main.yml'
    assert tags == u'blah'
    assert vars == {}

    ds = { u'import_playbook': u'/home/user/test/main.yml tags=blah' }
    pbi = Play

# Generated at 2022-06-23 06:41:04.119540
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    print("Testing PlaybookInclude")
    test_data = dict(
        import_playbook='/etc/ansible/include.yml',
        tags=['include_tag'],
        vars=dict(
            remote_port='22',
            verbose=True
        )
    )
    pbi = PlaybookInclude()
    pbi.load_data(ds=test_data, variable_manager=None, loader=None)
    print("PlaybookInclude: " + str(pbi))
    print("PlaybookInclude: " + str(pbi.import_playbook))
    print("PlaybookInclude: " + str(pbi.tags))
    print("PlaybookInclude: " + str(pbi.vars))

# Generated at 2022-06-23 06:41:10.027403
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play

    pb = PlaybookInclude()

    # Empty
    ds = dict()
    expected = dict()
    processed = pb.preprocess_data(ds)
    assert processed == expected

    # Only import
    ds = dict(import_playbook='/foo/bar.yml')
    expected = dict(import_playbook='/foo/bar.yml')
    processed = pb.preprocess_data(ds)
    assert processed == expected

    # Only vars
    ds = dict(vars=dict(foo="FOO", bar='BAR'))
    expected = dict(vars=dict(foo="FOO", bar='BAR'))
    processed = pb.preprocess_data(ds)
    assert processed == expected

    # Both import and

# Generated at 2022-06-23 06:41:13.157091
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # Test PlaybookInclude constructor
    p = PlaybookInclude({'import_playbook': './test.yml'})
    assert p.import_playbook == './test.yml'

# Generated at 2022-06-23 06:41:25.824862
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.module_utils._text import to_text
    import os
    import json

    # Workaround the fact that most python versions don't support loading modules with a __pycache__ directory
    # in the module path.  (See https://stackoverflow.com/questions/18137185/python-import-module-from-directory-above)
    import importlib
    import sys
    importlib.reload(sys.modules['ansible'])
    from ansible.module_utils import basic

    basedir = os.path.dirname(__file__)

    # Get the directory where this test script is and use it as the base directory
    # for storing temporary files. The tests will not create any temporary files
    # outside this directory

# Generated at 2022-06-23 06:41:36.482574
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    """
    Test load_data method of PlaybookInclude.
    """
    import unittest
    from ansible.module_utils._text import to_text, to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.plugins import vars as vars_loader

    loader = DataLoader()

    args = {}

# Generated at 2022-06-23 06:41:44.942570
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    variables = {'var_name': 'value'}
    import_playbook = 'playbook.yml'
    tags = ['tag1', 'tag2']
    ds = {'import_playbook': 'playbook.yml', 'vars': variables, 'tags': ','.join(tags)}
    pbs = PlaybookInclude.load(ds, '', variable_manager=None, loader=None)
    for entry in pbs._entries:
        assert isinstance(entry, PlaybookInclude)
        assert entry.import_playbook == import_playbook
        assert entry.vars == variables
        assert entry.tags == tags

# Generated at 2022-06-23 06:41:51.424536
# Unit test for method preprocess_data of class PlaybookInclude

# Generated at 2022-06-23 06:41:54.909587
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # With required parameters
    pbi = PlaybookInclude(playbook='playbook.yml')
    assert pbi.playbook == 'playbook.yml'

    # With required + optional parameters
    pbi = PlaybookInclude(playbook='playbook.yml', vars={ 'test': 'test'})
    assert pbi.playbook == 'playbook.yml'
    assert pbi.vars == { 'test': 'test'}

# Generated at 2022-06-23 06:42:04.834780
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    class MyVars(dict):
        pass
    vars_mgr = MyVars()
    vars_mgr['foovar'] = 'foodef'
    template_ds = AnsibleLoader(None, vars_mgr).load('''
- import_playbook: play.yml
- import_playbook: another.yml vars:
    a: b
- import_playbook: other.yml vars:
    c: d
''')

    for ds in template_ds:
        pi = PlaybookInclude()
        pi.preprocess_data(ds)
        assert pi.import_playbook is not None

# Generated at 2022-06-23 06:42:15.168638
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager

    data = """
    - import_playbook: import_test_playbook.yml
    """
    ds = AnsibleLoader(None, variable_manager=VariableManager()).load(data)[0]

    assert isinstance(ds, list)
    assert len(ds) == 1
    assert isinstance(ds[0], PlaybookInclude)
    assert ds[0].import_playbook == 'import_test_playbook.yml'
    assert ds[0].tags == []
    assert ds[0].when == []
    assert ds[0].vars == {}

# Generated at 2022-06-23 06:42:28.639354
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    # test with absolute path
    ds = {'import_playbook': '/path/to/collection/playbook.yml'}
    pbi = PlaybookInclude(ds=ds, basedir='/path/to/backup')
    r = pbi.load(ds=ds, basedir='/path/to/backup')
    assert isinstance(r, Playbook)
    assert len(r._entries) == 1
    assert not r._entries[0]._included_conditional
    assert r._entries[0]._included_path == '/path/to/collection'
    assert r._entries[0].name == 'playbook'
    assert isinstance(r._entries[0], Play)



# Generated at 2022-06-23 06:42:35.208997
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    
    playbook = """
- hosts: test_hosts
  tasks:
  - include: playbook.yml
    vars:
      foo: bar
"""
    
    playbook = """
- hosts: test_hosts
  tasks:
  - include_tasks: task.yml
    when: var1 == "val1"
"""
    
    
    #case 1
    
    
    
    
    
    
    #case 2

# Generated at 2022-06-23 06:42:44.280288
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.module_utils._text import to_text

    test_data = AnsibleMapping()
    test_data.ansible_pos = {'lnum':5, 'col':3}
    test_data['import_playbook']='test.yml'
    test_data['tags']=['a']
    test_data['vars']={'test':'a'}

    res_obj = PlaybookInclude.load(test_data, '/test/test')
    res_data = res_obj.preprocess_data(test_data)
    assert isinstance(res_data, AnsibleMapping)
    assert 'import_playbook' in res_data
    assert 'tags' in res_data
    assert 'vars' in res_data
    assert 'ansible_pos' in res_data
   

# Generated at 2022-06-23 06:42:55.352411
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.utils.collection_loader._collection_finder import _get_collection_playbook_path
    from ansible.utils.collection_loader._collection_finder import _get_collection_name_from_path
    ds_0_5 = {
        'import_playbook': '../other_playbook.yml',
        'vars': {
            'foo': 'bar'
        },
        'tags': 'example, import, manual'
    }

    playbook_obj = PlaybookInclude.load(ds_0_5, '/tmp')
    assert playbook_obj.import_playbook == '../other_playbook.yml'
    assert playbook_obj.vars == {'foo': 'bar'}

# Generated at 2022-06-23 06:42:58.774034
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.play import Play
    pbi = PlaybookInclude()
    assert isinstance(pbi.load('foobar.yml'), Play)


# Generated at 2022-06-23 06:43:09.493063
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    unquoted_yaml = ( 'import_playbook: playbook.yml\n'
                     'vars:\n'
                     '  foo: bar\n'
                     '  baz: true\n' )
    with open('/tmp/inventory', 'w') as fh:
        fh.write(unquoted_yaml)

    loader = AnsibleLoader(None, True)
    data = loader.load_from_file('/tmp/inventory')
    assert isinstance(data, list)
    assert len(data) == 1
    assert isinstance(data[0], AnsibleMapping)

# Generated at 2022-06-23 06:43:14.935548
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping

    # test 1: test parameter import_playbook and tags specified
    # by:
    #    - import_playbook: file-name.yml tags=tag1,tag2
    # expected:
    #    - the mapping new_ds has key 'import_playbook' with value 'file-name.yml',
    #    key 'tags' with value 'tag1,tag2', and key 'vars' with an empty value
    #    (empty mapping)
    ds = AnsibleMapping()
    ds['import_playbook'] = "file-name.yml tags=tag1,tag2"

# Generated at 2022-06-23 06:43:22.139165
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    # Test Tag
    value = "testTag"
    playbookInclude = PlaybookInclude()
    assert playbookInclude.tags == []
    playbookInclude.tags.append(value)
    assert playbookInclude.tags == [value]

    # Test Variable Manager
    playbookInclude.vars = {"var1":1}
    assert playbookInclude.vars == {"var1":1}

# Generated at 2022-06-23 06:43:30.180957
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    d = {}
    d['import_playbook'] = "playbook.yml"
    a = PlaybookInclude()
    b = PlaybookInclude.load(d, ".", variable_manager=None, loader=None)

    # both load() and the normal Playbook() constructor should produce
    # the same results if we use a datastructure that's in the proper format
    assert a.__dict__ == b.__dict__

# Generated at 2022-06-23 06:43:39.368261
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager.set_inventory(inventory)
    basedir = os.path.dirname(os.path.dirname(__file__))
    file_name = os.path.join(basedir, 'lib/ansible/playbook/test_data/playbooks/vault_include.yml')

    pb = PlaybookInclude.load(loader.load_from_file(file_name), basedir, variable_manager, loader)

    print(pb)

# Generated at 2022-06-23 06:43:50.095282
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    p = PlaybookInclude()
    ds = 'test.yml'

    # Create a valid playbook object with a 'test' play
    loader = DataLoader()
    pb = p.load_data(ds, '/home/test', None, loader)

    assert isinstance(pb, Playbook)
    assert isinstance(pb._entries[0], Play)
    assert pb._entries[0].name =='test'
    assert pb._entries[0].vars == {}
    assert pb._entries[0].tags == []
    assert pb._entries[0].included_path == None

    # Create a valid playbook object with vars and tags
    pb = p.load

# Generated at 2022-06-23 06:43:57.042710
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play

    # Create a playbook_include
    playbook_include = PlaybookInclude(import_playbook='example.yml', tags=['abc'])
    playbook_include.setup_loader(loader=None)
    playbook_include.post_validate(templar=None)
    playbook_include._load_data(ds=[], variable_manager=None)

    # Load an external playbook from the playbook include
    playbook = playbook_include.load_data(ds=[], basedir='/tmp', variable_manager=None, loader=None)
    assert(isinstance(playbook, PlaybookInclude))
    assert(len(playbook_include.get_children()) == 3)
    assert(playbook_include.get_children()[0].name == 'play1')

# Generated at 2022-06-23 06:44:02.657417
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    # Create an object of PlaybookInclude class using it's constructor.
    # Since the constructor of the class is __init__. We just need to set parameter name.
    PlaybookIncludeObj = PlaybookInclude(name='test')

    assert PlaybookIncludeObj.name == 'test'
    assert PlaybookIncludeObj.when is None
    assert PlaybookIncludeObj.tags == []

# Generated at 2022-06-23 06:44:15.321077
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # TODO: Remove AnsibleCollectionConfig.playbook_paths
    #       once we cleanup the old collection paths
    AnsibleCollectionConfig.playbook_paths = []

    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    from ansible.playbook.play import Play
    from ansible.playbook.role import Role

    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.template import Templar

    add_all_plugin_dirs()

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=["/dev/null"])


# Generated at 2022-06-23 06:44:26.950129
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml_string = """
    - import_playbook: tasks.yml
    """
    yaml_data = AnsibleLoader(yaml_string).get_single_data()

    # Construct the object and verify it's data structure
    pbincl = PlaybookInclude(yaml_data[0])
    assert type(pbincl) is PlaybookInclude
    assert pbincl.import_playbook == "tasks.yml"
    assert pbincl.tags == None
    assert pbincl.vars == {}
    assert pbincl.when == []

    yaml_string = """
    - import_playbook: tasks.yml tags=foo,bar
    """