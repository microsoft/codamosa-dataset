

# Generated at 2022-06-23 06:34:36.601059
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    yaml_str =  '''
- hosts: localhost
  connection: local
  gather_facts: no
  roles:
    - foo
  tasks:
    - name: "included playbook"
      import_playbook: include_playbook.yml myvar=helloworld
'''
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    loader = DataLoader()
    mydata = loader.load(yaml_str)[0]
    assert isinstance(mydata, list)
    mydata = mydata[0]
    assert isinstance(mydata, AnsibleMapping)
    assert mydata.keys() == ['hosts', 'roles', 'tasks']

# Generated at 2022-06-23 06:34:44.381267
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook import Playbook

    from ansible.vars.unsafe_proxy import UnsafeProxy

    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    variable_manager = UnsafeProxy({'name': 'john'}, 'jacob')

    ds = AnsibleMapping()

    ds['import_playbook'] = "./example_vars.yml"
    ds['vars'] = {'name' : 'john', 'surname': 'doe'}


# Generated at 2022-06-23 06:34:55.263407
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    import ansible.playbook.play
    import ansible.playbook.block
    import ansible.playbook.task
    import ansible.playbook.handler
    import ansible.parsing.yaml.objects

    # parametrize
    basedir = './'
    variable_manager = None
    loader = None
    ds = ansible.parsing.yaml.objects.AnsibleMapping()
    ds.ansible_pos = None
    ds[u'hosts'] = u'localhost'

    # init class
    playbookinclude_load = PlaybookInclude.load(ds, basedir, variable_manager, loader)

    # assert test

# Generated at 2022-06-23 06:35:04.942008
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import_playbook = PlaybookInclude()
    ds = AnsibleMapping()
    ds['import_playbook'] = '../qa/test.yaml'
    ds['vars'] = {'qq': 'vv'}
    ds['tasks'] = None

    assert import_playbook.preprocess_data(ds) == {'import_playbook': '../qa/test.yaml', 'vars': {'qq': 'vv'}}

    ds = AnsibleMapping()
    ds['import_playbook'] = '../qa/test.yaml'
    ds['somevar'] = 'somevalue'
    ds['tags'] = 'some,tags'
    ds['vars'] = {'qq': 'vv'}


# Generated at 2022-06-23 06:35:15.584098
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    import os

    playbook_path = os.path.join(os.path.dirname(__file__), 'playbook_include_test.yml')
    base_dir = os.path.dirname(playbook_path)
    print(('basdir: ' + base_dir))
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=('localhost,'))
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    playbooks = loader

# Generated at 2022-06-23 06:35:23.166291
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    p = PlaybookInclude()
    import_playbook = 'import_playbook'
    ansible_pos = (2, 3)
    v = 'something'
    ds = AnsibleMapping()
    ds[import_playbook] = v
    ds.ansible_pos = ansible_pos
    new_ds = p.preprocess_data(ds)
    assert new_ds['import_playbook'] == v
    assert new_ds.ansible_pos == ansible_pos

# Generated at 2022-06-23 06:35:29.076559
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    '''
    This is just a simple test to ensure the class was created
    properly.  More in-depth testing will be done as part of the
    unit tests for the Playbook class, which extensively uses this
    class to load playbooks for execution.
    '''
    playbook_include = PlaybookInclude.load({}, None)
    assert playbook_include is not None, "Unable to create PlaybookInclude instance"

if __name__ == "__main__":
    import nose
    nose.runmodule()

# Generated at 2022-06-23 06:35:31.313724
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    print("Testing basic PlaybookInclude properties")
    PlaybookInclude()
    print("PlaybookInclude initialization passed")


# Generated at 2022-06-23 06:35:43.013754
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    test_cases = [
        # No data
        (dict(), 'playbook-import', None),
        (dict(import_playbook='a.yaml'), 'playbook-import', None),
        (dict(import_playbook='a.yaml'), 'playbook-invalid', 'Normal import playbook with data does not give error.'),
        (dict(import_playbook='a.yaml'), 'playbook-invalid', 'Normal import playbook with data and various other data does not give error.')
    ]

    for (data, expected_error, expected_msg) in test_cases:
        try:
            PlaybookInclude().preprocess_data(data)
        except AnsibleParserError:
            if expected_error == 'playbook-invalid':
                # test is successful
                pass

# Generated at 2022-06-23 06:35:52.521388
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    import_playbook = {
        'import_playbook': 'test.yml',
        'tags': 'tag1',
        'vars': {
            'key1': 'val1',
            'key2': 'val2'
        }
    }
    expected_vars = {
        'key1': 'val1',
        'key2': 'val2'
    }
    expected_tags = ['tag1']

    # Test
    pb = PlaybookInclude.load(import_playbook, '.')

    # Assertions
    assert isinstance(pb, Playbook)
    assert len(pb._entries) == 1

# Generated at 2022-06-23 06:35:59.182511
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=None, variable_manager=variable_manager)
    pl_include = PlaybookInclude.load(dict(import_playbook='/test'), '/etc', loader=loader, variable_manager=variable_manager)
    assert isinstance(pl_include, Playbook)
    assert len(pl_include._entries) == 1
    assert isinstance(pl_include._entries[0], Play)

# Generated at 2022-06-23 06:36:03.397527
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    p = PlaybookInclude.load({'import_playbook': 'test.yml'})
    assert p.import_playbook == 'test.yml'

# Unit tests for preprocess_data method in class PlaybookInclude

# Generated at 2022-06-23 06:36:15.844118
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    import mock
    import unittest

    import ansible
    from ansible.venv import AnsibleVenv

    ansible_path = os.path.dirname(ansible.__file__)
    venv_path = os.path.join(ansible_path, 'venv')
    AnsibleVenv(venv_path).create()

    from ansible.playbook import Playbook
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader

    class TestPlaybookInclude(unittest.TestCase):

        @mock.patch.object(AnsibleCollectionConfig, 'playbook_paths', ['unittest_resources/playbooks'])
        def test_PlaybookInclude_load_data_1(self):
            ds = dict

# Generated at 2022-06-23 06:36:26.675834
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    import os.path
    basedir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))

    # Test loading a playbook from ansible collection
    pb = PlaybookInclude.load(data={}, basedir=basedir)
    pb.load_data(ds={'import_playbook': 'test_collection.test_playbook'}, basedir=basedir)
    assert isinstance(pb, Playbook)

    # Test loading a playbook from a local dir
    pb = PlaybookInclude.load(data={}, basedir=basedir)
    pb.load_data(ds={'import_playbook': 'test/test_playbook.yml'}, basedir=basedir)

# Generated at 2022-06-23 06:36:35.744645
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    import_playbook_data = dict(
        import_playbook='FilePath'
    )

    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(Var1="Var1_Value")
    variable_manager._vars = dict(Var2="Var2_Value")

    loader = DataLoader()

# Generated at 2022-06-23 06:36:45.517146
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    args = [
        'file.yml',
        'file.yml other=val',
        'file.yml other1=val1 other2=val2',
        'file.yml other=val vars=val',
    ]

    excepted_data = [
        {'import_playbook': 'file.yml'},
        {'import_playbook': 'file.yml', 'vars': {'other': 'val'}},
        {'import_playbook': 'file.yml', 'vars': {'other1': 'val1', 'other2': 'val2'}},
        {'import_playbook': 'file.yml', 'vars': {'other': 'val', 'vars': 'val'}},
    ]


# Generated at 2022-06-23 06:36:46.891215
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # TODO: implement
    return

# Generated at 2022-06-23 06:36:52.060633
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    yaml_data = '''
---
- import_playbook: site.yml
'''
    obj = PlaybookInclude.load(yaml_data, 'fakedir', None, None)
    assert obj.import_playbook == 'site.yml'
    assert obj.vars == {}

# Generated at 2022-06-23 06:37:06.245424
# Unit test for method preprocess_data of class PlaybookInclude

# Generated at 2022-06-23 06:37:19.631834
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    # Constructor should successfully construct PlaybookInclude object with
    # five attributes when correct parameters are passed
    playbook_include = PlaybookInclude(import_playbook='test_file.yaml')
    assert playbook_include.import_playbook == 'test_file.yaml'
    assert playbook_include._created is not None
    assert playbook_include.when is None
    assert playbook_include.tags == []
    assert playbook_include.vars == {}

    # Constructor should successfully construct PlaybookInclude object with
    # two attributes when only two parameters are passed
    playbook_include = PlaybookInclude(import_playbook='test_file.yaml', tags=['tag'])
    assert playbook_include.import_playbook == 'test_file.yaml'
    assert playbook_include._created is not None
    assert playbook_include

# Generated at 2022-06-23 06:37:35.477163
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar

    # initial PlaybookInclude object
    playbook_include = PlaybookInclude()

    # initial TaskInclude object
    task_include = TaskInclude()

    # initial Playbook object
    playbook = Playbook()

    # initial Play object
    play = Play()
    play.name = "test_play"

    # initial Task object
    task = Task()

    # assign PlaybookInclude object to Playbook object
    playbook.set_loader(playbook_include)

    # assign PlaybookInclude object to TaskInclude object

# Generated at 2022-06-23 06:37:44.015370
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    import os
    import sys

    class TestLoader(object):
        def get_basedir(self, *args, **kwargs):
            return os.getcwd()

    sys.modules['ansible'] = object()
    sys.modules['ansible.parsing.yaml'] = object()
    sys.modules['ansible.parsing.yaml.objects'] = object()
    sys.modules['ansible.parsing.yaml.objects.AnsibleBaseYAMLObject'] = AnsibleBaseYAMLObject
    sys.modules['ansible.parsing.yaml.objects.AnsibleMapping'] = AnsibleMapping

    sys.modules['ansible.playbook'] = object()
    sys.modules['ansible.playbook.base'] = object()

# Generated at 2022-06-23 06:37:55.427596
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.yaml.loader import AnsibleLoader

    test_data = """---
    - import_playbook: test_file.yml
      tags: 'tag1'
    - import_playbook: test_file.yml
      vars:
        k1: v1
    - import_playbook: test_file.yml
      vars:
        k1: v1
      tags: 'tag1'
    """
    test_ds = AnsibleLoader(None, protective=False).load(test_data)
    assert len(test_ds) == 3
    assert test_ds[0]['import_playbook'] == 'test_file.yml' and test_ds[0]['tags'] == 'tag1'

# Generated at 2022-06-23 06:38:06.843864
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    data = '''
    ---
    - import_playbook: ../tasks/main.yml
      tags:
        - foo
        - bar
        - baz
      when: qux
    '''
    data_mapping = '''
    ---
    import_playbook: ../tasks/main.yml
    tags:
      - foo
      - bar
      - baz
    when: qux
    '''

# Generated at 2022-06-23 06:38:13.814950
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    data = """
    - import_playbook: test.yml
    """
    include_object = PlaybookInclude.load(data, ".")
    new_ds = AnsibleMapping()
    new_ds['import_playbook'] = "test.yml"
    assert include_object.preprocess_data({'import_playbook': 'test.yml'}) == new_ds

# Generated at 2022-06-23 06:38:20.776061
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Play

    pb = PlaybookInclude.load(
        dict(playbook='play.yml', tags=['foo', 'bar'], vars=dict(name='joe', foo='bar')),
        basedir='/foo',
        variable_manager=None, loader=None)

    for entry in pb._entries:
        assert isinstance(entry, Play)
        assert entry.tags == ['foo', 'bar']
        assert entry.vars['name'] == 'joe'
        assert entry.vars['foo'] == 'bar'

# Generated at 2022-06-23 06:38:22.697218
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    p = PlaybookInclude()
    assert p is not None


# Generated at 2022-06-23 06:38:30.645953
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    import os
    import shutil
    import tempfile

    here = os.path.dirname(os.path.abspath(__file__))
    test_playbook = os.path.join(here, 'test_playbook_import.yml')

    collection_path = os.path.join(here, 'collection', 'ansible_collections', 'my_namespace', 'my_collection')
    collection_playbook = os.path.join(collection_path, 'playbooks', 'test_collection_playbook.yml')


# Generated at 2022-06-23 06:38:40.007417
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import collections
    import textwrap

    # Set up some inputs
    playbook_dir = u'/home/test/test-1.0/exe'
    playbook_name = 'test.yml'
    playbook_path = '/home/test/test-1.0/exe/test.yml'
    playbook_file_data = collections.OrderedDict()
    playbook_file_data[u'import_playbook'] = playbook_path
    playbook_file_data[u'vars'] = {u'var1': u'value1', u'var2': u'value2'}

    # Add some when conditions
    playbook_file_data[u'when'] = [u'when1', u'when2']

    # Run the preprocess_data method to get the re-organized data structure
    pd = PlaybookInclude

# Generated at 2022-06-23 06:38:54.676190
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    import ansible.playbook.playbook_include as pi

    ds = {
        'import_playbook': 'myplaybook.yml',
        'tags': ['tag1', 'tag2'],
        'vars': {'hosts': 'host1:host2', 'group': 'group1'},
        'when': 'ansible_facts["distribution"] == "Fedora"'
    }

    playbook_include = pi.PlaybookInclude.load(ds)
    assert playbook_include is not None
    assert playbook_include.import_playbook == 'myplaybook.yml'
    assert playbook_include.tags == ['tag1', 'tag2']
    assert playbook_include.vars == {'hosts': 'host1:host2', 'group': 'group1'}
    assert playbook_include.when

# Generated at 2022-06-23 06:39:01.629801
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    #Prepare the mocked objects and call the tested method
    data = 'include: tests/test_playbook_include.yml'
    basedir = './'
    variable_manager = {'hostvars':'example'}
    loader = 'loader'
    obj = PlaybookInclude.load(data, basedir, variable_manager, loader)

    #Assert the test result
    assert(isinstance(obj,object))


# Generated at 2022-06-23 06:39:14.238142
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # create an instance of the PlaybookInclude class
    pbi = PlaybookInclude()
    # create an instance of the AnsibleMapping class that we can use to build the argument
    # for the load_data() method call. The data structure loaded by load_data() will
    # be validated by the load_data() method
    ds = AnsibleMapping()
    ds['import_playbook'] = "import_playbook.yml"
    ds['vars'] = {'a': '1', 'b': [2, 3], 'c': {'d': '4'}}
    ds['tags'] = "tag1"
    # invoke the load_data() method of the class
    result = pbi.load_data(ds, "/tmp", variable_manager=None, loader=None)

# Generated at 2022-06-23 06:39:28.112930
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    assert PlaybookInclude.load({'include': 'fake_pb.yml'}, '/does/not/matter/')

    # Create a variable manager for the playbook:
    variable_manager = VariableManager()
    loader = DataLoader()

    # test case to make sure conditional includes work properly
    conditional_include = PlaybookInclude.load({'include': "{{ my_pb_file }}", 'when': 'some_var > 5'}, '/does/not/matter/', variable_manager=variable_manager, loader=loader)

    # test case to make sure additional params work properly

# Generated at 2022-06-23 06:39:38.647888
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    variable_manager = None
    loader = None
    basedir = None
    data = {
        "import_playbook": "./playbooks/playbook1.yml",
        "vars": {"playbook_var": "playbook_var"},
        "when": "playbook_var"
    }
    playbook_include = PlaybookInclude.load(data=data, basedir=basedir, variable_manager=variable_manager, loader=loader)
    print(type(playbook_include))
    print(playbook_include.import_playbook)
    print(playbook_include.vars)

# Unit test function for method preprocess_data of class PlaybookInclude

# Generated at 2022-06-23 06:39:46.642488
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import yaml
    from ansible.parsing.yaml.dumper import AnsibleDumper
    yaml.add_representer(AnsibleMapping, AnsibleDumper.represent_dict)
    yaml.add_representer(AnsibleUnicode, AnsibleDumper.represent_str)

    ds = "import_playbook: test.yml"
    ds = yaml.load(ds, Loader=yaml.loader.BaseLoader)
    ds = PlaybookInclude.preprocess_data(ds)
    assert ds == {'import_playbook': "test.yml"}

    ds = "import_playbook: test.yml vars: var1: ansible"
    ds = yaml.load(ds, Loader=yaml.loader.BaseLoader)
   

# Generated at 2022-06-23 06:39:50.429009
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    ds = dict(
        import_playbook='/tmp/test.yml',
        vars=dict(
            foo='bar',
        )
    )

    basedir = '/tmp'
    obj = PlaybookInclude(ds, basedir=basedir, variable_manager=None, loader=None)
    assert obj.import_playbook == 'test.yml'
    assert obj.vars == dict(foo='bar')

# Generated at 2022-06-23 06:39:51.172760
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass


# Generated at 2022-06-23 06:40:01.253710
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Test case of PlaybookInclude.preprocess_data method
    # TestPlaybookInclude.preprocess_data1.yml

    # TestPlaybookInclude.preprocess_data1()
    # Test result of original data structure(called ds)
    original_ds = AnsibleMapping()

    # Test items of original data structure
    # Test item1 of original data structure
    original_ds.set('import_playbook', 'webservers.yaml')
    # Test item2 of original data structure
    original_ds.set('vars', AnsibleMapping())

    # Test result of new data stucture(called new_ds)


# Generated at 2022-06-23 06:40:11.734823
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    '''
    Test the preprocess_data method of the PlaybookInclude class.
    '''
    from ansible.parsing.yaml.objects import AnsibleMapping

    # Test 1: A string as value for a key.
    # This test will fail because the value of import_playbook must be a dict.
    ds = {
        'import_playbook': 'test.yml'
    }

    try:
        PlaybookInclude.preprocess_data(PlaybookInclude(), ds)
    except AnsibleParserError as e:
        assert e.message == "playbook import parameter must be a string indicating a file path, got <class 'str'> instead"

    # Test 2: A dictionary is provided as value for a key.
    # This test will fail because there must be only one key 'import_playbook'.

# Generated at 2022-06-23 06:40:15.069881
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # TODO: implement proper unit tests
    pb = PlaybookInclude()
    pb.load_data(ds=dict(), basedir=None, variable_manager=None, loader=None)


# Generated at 2022-06-23 06:40:31.089305
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    ds = dict()
    obj = PlaybookInclude()
    assert(obj.preprocess_data(ds) == ds)
    ds['import_playbook'] = 'foo'
    assert(obj.preprocess_data(ds) == ds)
    ds = dict()
    ds['include'] = 'foo'
    assert(obj.preprocess_data(ds) == {'import_playbook': 'foo'})
    ds['tags'] = 'tag1,tag2'
    assert(obj.preprocess_data(ds) == {'import_playbook': 'foo', 'tags': 'tag1,tag2'})
    ds = dict()
    ds['include'] = 'foo.yml'

# Generated at 2022-06-23 06:40:44.375467
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # Test that preprocess_data() raises error if ds is not a dict
    ds = "hello"
    try:
        new_ds = PlaybookInclude().preprocess_data(ds)
    except AnsibleAssertionError as e:
        assert(str(e).find("should be a dict but was a ") != -1)


    # Test that preprocess_data() raises error if ds is not a dict
    ds = "hello"
    try:
        new_ds = PlaybookInclude().preprocess_data(ds)
    except AnsibleAssertionError as e:
        assert(str(e).find("should be a dict but was a ") != -1)

    # Test that preprocess_data() raises error if include_playbook is set with
    # vars in ds
    d

# Generated at 2022-06-23 06:40:46.683328
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    p = PlaybookInclude()
    p.load_data('foo.yml', C.DEFAULT_LOCAL_TMP)

# Generated at 2022-06-23 06:40:54.626851
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    """
    This is a unit test to ensure that playbook include is working as we expect

    Added test case to ensure that multiple parameters in import_playbook are
    deprecated and that using 'vars:' instead is recommended.
    """
    p = PlaybookInclude(dict(import_playbook='file.yml'))
    assert p and p.import_playbook == 'file.yml'
    assert not p.vars

    p = PlaybookInclude(dict(import_playbook='file.yml var=val foo=bar'))
    assert p
    assert p.vars == dict(var='val', foo='bar')

    p = PlaybookInclude(dict(import_playbook='file.yml var=val foo=bar', vars=dict(baz='bam')))
    assert p
    assert p.v

# Generated at 2022-06-23 06:41:04.809275
# Unit test for method preprocess_data of class PlaybookInclude

# Generated at 2022-06-23 06:41:15.860015
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.playbook.playbook import Playbook

    # Test with only the required fields
    data = dict(
        hosts='testhost',
        import_playbook='test.yml',
    )

    pb = PlaybookInclude(data)
    assert pb._import_playbook == 'test.yml'

    data = dict(
        import_playbook='test.yml',
    )

    pb = PlaybookInclude(data)
    assert pb._import_playbook == 'test.yml'

    data = dict(
        import_playbook='test.yml',
        vars={'var1': 'value1',
              'var2': 'value2',
              'var3': 'value3'},
    )

    pb = PlaybookInclude(data)
    data

# Generated at 2022-06-23 06:41:24.737763
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext

    pl = PlaybookInclude.load(dict(include=test_import_playbook), variable_manager=PlayContext())

    assert pl.import_playbook == test_import_playbook
    assert pl.vars == {}
    assert pl.when == []

    pl = PlaybookInclude.load(dict(include=test_include_import_playbook), variable_manager=PlayContext())

    assert pl.import_playbook == test_include_import_playbook_playbook_import_playbook
    assert pl.vars == dict(var1=1)
    assert pl.when == [{'condition': 'false', 'var': 'var1'}, {'condition': 'true', 'var': 'var2'}]


# Generated at 2022-06-23 06:41:36.067373
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import json
    import sys
    import textwrap
    from ansible.parsing.yaml.loader import AnsibleLoader

    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.collection_loader._collection_finder import _get_collection_name_from_path
    from ansible.parsing.vault import VaultLib


    def check(name, want, got):
        if want != got:
            print("FAILURE: PlaybookInclude.preprocess_data() %s" % name, file=sys.stderr)
            print("want=%s" % json.dumps(want, sort_keys=True, indent=4, cls=AnsibleDumper), file=sys.stderr)

# Generated at 2022-06-23 06:41:46.371712
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    try:
        from ansible.playbook.play import Play
        from ansible.playbook.role import Role
        from ansible.playbook import Playbook
        from ansible.parsing.dataloader import DataLoader
    except ImportError:
        print('Skipped import test')
        return

    ds = dict(
        playbook = 'playbook',
        playbook_path = os.path.join(os.path.dirname(__file__), 'playbook'),
        role_path = os.path.join(os.path.dirname(__file__), 'roles'),
    )
    ds = PlaybookInclude.load(ds, basedir='/tmp', variable_manager=None, loader=DataLoader())
    assert(isinstance(ds, Playbook))     # is of correct type

# Generated at 2022-06-23 06:41:52.863496
# Unit test for method preprocess_data of class PlaybookInclude

# Generated at 2022-06-23 06:41:54.932807
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pb = PlaybookInclude()
    print(pb)
    assert pb.import_playbook is None
    assert pb.vars == {}

# Generated at 2022-06-23 06:42:07.297389
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.play import Play
    import yaml

    # Create a PlaybookInclude object
    pb_include = PlaybookInclude()

    # Define a playbook (data)
    playbook = 'import_playbook: abc.yml vars: {param3: value3} param1: value1 param2: value2'
    # Load playbook to PlaybookInclude object
    pb_include.load(yaml.safe_load(playbook), '', None, None)

    # Get the preprocessed data
    processed_data = pb_include.preprocess_data(pb_include._ds)

    # Define expected data (playbook)

# Generated at 2022-06-23 06:42:17.970518
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    import os

    playbook = PlaybookInclude.load(dict(import_playbook='playbook.yml'), basedir='.')
    assert isinstance(playbook, Playbook)
    assert len(playbook._entries) == 2
    assert playbook._entries[0].name == "play"

    play = playbook._entries[0]
    assert isinstance(play, Play)
    assert len(play.tasks) == 2

    task = play.tasks[0]
    assert isinstance(task, Task)
    assert task.action == "debug"
    assert task.args['msg'] == "task 1"

    task = play.tasks[1]

# Generated at 2022-06-23 06:42:30.729670
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    yaml_data = dict(
        import_playbook='foo.yml',
        import_playbook__tags=['bar'],
        import_playbook__vault_password='this-is-a-password',
        import_playbook__vars=dict(
            foo='bar',
            baz='yes'
        )
    )

    pbi = PlaybookInclude()
    pbi.preprocess_data(yaml_data)

    assert pbi.import_playbook == 'foo.yml'
    assert pbi.tags == ['bar']
    assert pbi.vars['foo'] == 'bar'

# Generated at 2022-06-23 06:42:38.009593
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_object1 = PlaybookInclude()
    playbook_include_object2 = PlaybookInclude()
    playbook_include_object1.preprocess_data("test.yml")
    playbook_include_object2.preprocess_data("test.yml vars: { a: b }")
    assert(playbook_include_object1.vars == dict())
    assert(playbook_include_object2.vars == dict(a='b'))

# Generated at 2022-06-23 06:42:44.442231
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    import unittest
    import sys

    class TestPlaybookInclude(unittest.TestCase):
        def test_PlaybookInclude(self):
            p = PlaybookInclude()
            p.import_playbook = 'test.yml'
            v = PlaybookInclude()
            v.vars = {'testvar': 'testvalue'}
            if not v.vars['testvar'] == 'testvalue':
                sys.exit(1)

    unittest.main()

# Generated at 2022-06-23 06:42:55.414258
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    # create playbook
    entry = PlaybookInclude()

    playbook = Playbook()
    playbook._load_playbook_data = lambda x, y, z: None # mock the load of a playbook

    result = entry.load_data(ds=dict(), basedir='/tmp', variable_manager=None, loader=None)

    assert result == playbook
    assert isinstance(result, Playbook)

    # create playbook
    entry = PlaybookInclude()
    entry.import_playbook = 'some.pb'
    entry.vars = dict()

    playbook = Playbook()

    playbook._entries = [ PlaybookInclude() ]

    playbook._load_playbook_data = lambda x, y, z: None # mock the load of a

# Generated at 2022-06-23 06:43:07.268196
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    import yaml

    yaml_test_data = """
---
- test_playbook.yml:
    vars:
        param1: value1
        param2: value2
    tags:
        - tag1
        - tag2
    when:
        - condition1
"""
    assert isinstance(yaml.safe_load(yaml_test_data), list)

    data = yaml.safe_load(yaml_test_data)[0]
    assert len(data.keys()) == 1
    assert len(data.values()) == 1

    # import_playbook: test_playbook.yml
    # vars: value1
    # tags: tag1 tag2
    # when: condition1

# Generated at 2022-06-23 06:43:13.571299
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    import ansible.parsing.yaml.loader

    tmp_vars = dict(
        foo="bar",
        bam="baz",
    )
    tmp_structure = dict(
        import_playbook="../../tests/test_playbook_include.yml",
        vars=tmp_vars,
        tags=["tag1", "tag2"],
    )

    tmp_yaml = ansible.parsing.yaml.loader.AnsibleLoader(tmp_structure, "").get_single_data()
    from ansible.parsing.dataloader import DataLoader
    tmp_playbook = PlaybookInclude.load(tmp_yaml, ".", variable_manager=None, loader=DataLoader())
    assert tmp_playbook is not None

    # get the first entry of the

# Generated at 2022-06-23 06:43:22.730355
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import os.path
    from ansible.parsing.yaml.objects import AnsibleMapping

    # pysaml2.org/py3k.html
    unittest.TestCase.assertIs(PlaybookInclude.preprocess_data(None), None)

    # pysaml2.org/py3k.html
    unittest.TestCase.assertIsInstance(PlaybookInclude.preprocess_data(AnsibleMapping()), AnsibleMapping)

    # pysaml2.org/py3k.html
    unittest.TestCase.assertEqual(PlaybookInclude.preprocess_data({"import_playbook": "aaa"})["import_playbook"], "aaa")

    # pysaml2.org/py3k.html
    unittest.TestCase.assertEqual

# Generated at 2022-06-23 06:43:35.242677
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    file_name = "test_import_playbook.yml"
    playbook_path = os.path.dirname(os.path.abspath(__file__))
    playbook = os.path.join(playbook_path, file_name)
    playbook_collection = _get_collection_name_from_path(playbook)
    if playbook_collection:
        # it is a collection playbook, setup default collections
        AnsibleCollectionConfig.default_collection = playbook_collection
    else:
        # it is NOT a collection playbook, setup adjecent paths
        AnsibleCollectionConfig.playbook_paths.append(playbook_path)

# Generated at 2022-06-23 06:43:47.623688
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.playbook import Playbook
    file1 = 'test_playbook_include_1.yml'
    file2 = 'test_playbook_include_2.yml'
    playbook1 = 'test_playbook_1.yml'
    playbook2 = 'test_playbook_2.yml'

    old_root_dir = os.path.dirname(os.path.abspath(__file__))
    old_dir = os.path.dirname(old_root_dir)
    os.system('cd %s; for i in *.yml; do mv $i $i.bak; done' % playbook2)

# Generated at 2022-06-23 06:43:55.963304
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    '''
    Unit test for method preprocess_data of class PlaybookInclude
    '''

    # Import this here to avoid a dependency loop
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.template import Templar
    from ansible.utils.display import Display
    from os import path

    # set the display
    display = Display()

    # set the playbook
    playbook = path.join(path.split(path.realpath(__file__))[0], 'test_playbook_import.yml')

    # create a templar
    templar = Templar()

    # create a playbook

# Generated at 2022-06-23 06:44:03.501229
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play

    playbook_include = PlaybookInclude()

    # Test with a valid playbook
    playbook = './test_playbook_include_playbook.yml'
    pb = playbook_include.load(playbook, basedir='')
    assert isinstance(pb, Playbook)
    entry = pb._entries[0]
    assert isinstance(entry, Play)
    assert entry._included_path is None
    assert entry.name == "Ansible Playbook Include Test Play"
    assert entry.vars == {'import_var': 'value', 'harry': 'potter'}
    assert entry.tags == ['tag1', 'tag2']
    assert entry.tasks[0].action == 'debug'

# Generated at 2022-06-23 06:44:16.215911
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.template import Templar
    from ansible.vars import VariableManager

    templar = Templar(loader=None, variables={})
    variable_manager = VariableManager()

    data = AnsibleMapping()
    data.update({
        'import_playbook': 'some_playbook',
        'vars': {
            'foo': 'bar'
        }
    })

    pbincl = PlaybookInclude()
    pbincl.vars = {}
    pbincl.load_data(data, variable_manager=variable_manager, templar=templar)


# Generated at 2022-06-23 06:44:19.172522
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pi = PlaybookInclude()
    assert pi

if __name__ == "__main__":
    test_PlaybookInclude()

# Generated at 2022-06-23 06:44:30.870260
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    '''
    Test that preprocess_data() produces the needed format.
    '''

    section = AnsibleMapping()
    section['include'] = 'tests/test_include.yml'
    section['vars'] = {"var1": 1, "var2": "foo", "var3": [1,2,3]}
    section['tags'] = 'tag1,tag2'
    section['when'] = 'False'
    section['priority'] = 50

    target = PlaybookInclude()
    target._preprocess_data(section)

    assert target.import_playbook == u'tests/test_include.yml'
    assert len(target.vars) == 3
    assert target.vars['var1'] == 1
    assert target.vars['var2'] == u'foo'
    assert target.v