

# Generated at 2022-06-23 06:34:26.086857
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-23 06:34:38.534126
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Monkey-patch for unit testing
    class FieldAttribute:
        def __init__(self, *args, **kwargs):
            pass

    FieldAttribute = FieldAttribute

    class AnsibleMapping:
        def __init__(self, *args, **kwargs):
            self.attributes = {}
            self.attributes.update(*args)
            self.attributes.update(kwargs)

        def __getitem__(self, k):
            return self.attributes[k]

        def __setitem__(self, k, v):
            self.attributes[k] = v

        def __contains__(self, k):
            return k in self.attributes

        def __iter__(self):
            return iter(self.attributes)


# Generated at 2022-06-23 06:34:51.218273
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing import vault
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    dl = DataLoader()
    inv_manager = InventoryManager(loader=dl, sources=['tests/inventory'])
    inv_manager.parse_sources(cache=False)
    pb_name = 'tests/playbooks/playbook_include.yml'
    vault.VaultLib.setup_crypto()
    vault_pass = None
    vault_ids = []
    cs = vault.VaultLib(vault_pass, vault_ids)
    cs.load(pb_name)
    p = cs.decrypt(cs.data)
    pb = PlaybookInclude.load(p, '.')
    task = pb.pop()

# Generated at 2022-06-23 06:35:02.030390
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os
    import sys
    import unittest

    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.playbook_include import test_PlaybookInclude_load_data as test
    from ansible.module_utils.six import PY2

    class TestPlaybookInclude(unittest.TestCase):
        ''' testing PlaybookInclude class '''

        def test_loader_error(self):
            # test if the playbook include finds a playbook in a collection
            # but the collection is not found in the collection path

            # mock the loader
            loader = MagicMock()
            # set the mock so it returns None every time is_collection is called
            loader.is_collection.return_value = None
            # set mock so it returns the collection path to test if the playbook is

# Generated at 2022-06-23 06:35:07.102855
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include = PlaybookInclude()

    # Test a valid use case
    ds = {'import_playbook': 'test_play.yml', 'vars': {'var1': 'value'}}
    new_ds = playbook_include.preprocess_data(ds)
    assert new_ds['import_playbook'] == 'test_play.yml'
    assert new_ds['vars']['var1'] == 'value'
    assert 'tags' not in new_ds

    ds = {'import_playbook': 'test_play.yml', 'tags': 'tag1,tag2'}
    new_ds = playbook_include.preprocess_data(ds)
    assert new_ds['import_playbook'] == 'test_play.yml'
    assert 'vars' not in new_

# Generated at 2022-06-23 06:35:14.410900
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # First, we create a playbook include object with a new instance of the class
    playbook_include_object = PlaybookInclude()
    # We create a dict based on a playbook include file that we have on the project
    # It will be used as the data ds
    data_ds = AnsibleMapping()
    data_ds['import_playbook'] = '/home/vagrant/repo/tests/functional/include/ansible/test_import_playbook_1.yml'
    data_ds['vars'] = dict()
    data_ds['vars']['number'] = 2
    # Now we want to call the load_data method to the playbook include object
    # The method returns a Playbook object

# Generated at 2022-06-23 06:35:19.502557
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.playbook import Playbook

    loader = DataLoader()

    pb = PlaybookInclude.load(dict(import_playbook="import_playbook.yaml"), '.', loader=loader)
    assert isinstance(pb, Playbook)

# Generated at 2022-06-23 06:35:29.959183
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():

    from ansible.module_utils._text import to_bytes

    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    # We need to provide a variable manager, so we're going to mock
    # one. We'll use this in the next test as well.
    vm = type('VariableManager', (), {})
    vm.get_vars = lambda self: {}

    # I needed to create a fake loader for this, too.
    loader = type('Loader', (), {})
    loader.get_basedir = lambda self: "."

    # We're going to do a little more mocking here. The file we're
    # loading is synthetic, so we need to provide the content. We'll
    # create a synthetic class for this as well.

# Generated at 2022-06-23 06:35:35.161700
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.playbook.play import Play

    # Test playbook with only file name
    pc = PlaybookInclude()
    playbook = pc._preprocess_data({'import_playbook': 'test_playbook_include'})
    assert len(playbook._entries) == 1
    assert isinstance(playbook._entries[0], Play)

    # Test playbook with variable
    pc = PlaybookInclude()
    playbook = pc._preprocess_data({'import_playbook': 'test_playbook_include_with_vars', 'vars': {'var_1': 'value_1'}})
    assert len(playbook._entries) == 1
    assert isinstance(playbook._entries[0], Play)
    assert playbook._entries[0].vars['var_1'] == 'value_1'

# Generated at 2022-06-23 06:35:41.279570
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pb_inc = PlaybookInclude(import_playbook='inc.yml', vars={'key1': 'val1'})

# Generated at 2022-06-23 06:35:50.880678
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    pb = PlaybookInclude.load(
        dict(
            import_playbook = 'foo.yml',
            vars=dict(
                foo='bar'
            ),
            tags=[ 'tag1', 'tag2' ],
            when=[ {'condition': 'is_windows'} ],
        ),
        variable_manager=None,
        loader=None,
        basedir='/path/to/dir'
    )

    assert pb._import_playbook == 'foo.yml'
    assert pb._vars == {
        'foo': 'bar'
    }
    assert pb.tags == [ 'tag1', 'tag2' ]
    assert pb.when == [ {'condition': 'is_windows'} ]

# Generated at 2022-06-23 06:36:02.755585
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    import json

    display = Display()
    display.verbosity = 3

    playbookInclude = PlaybookInclude()

    PlaybookInclude.load(
        data=dict(
            import_playbook="test.yaml",
            extra_vars=dict(
                test_var="test_val"
            ),
            tags="tag1,tag2,tag3"
        )
    )
    PlaybookInclude.load(
        data=dict(
            import_playbook="test.yaml",
            vars=dict(
                test_var="test_val"
            ),
            tags="tag1,tag2,tag3"
        )
    )

# Generated at 2022-06-23 06:36:15.353624
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    import os
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager

    # load a test playbook with a single play
    test_file = os.path.join(os.path.dirname(__file__), 'test_playbook_include.yml')
    p = Playbook.load(test_file, variable_manager=VariableManager(), loader=None)
    t = Templar(variables=p._variable_manager.get_vars())

    # test the base case where we include a non-collection playbook
    include = p._entries[0]
    assert isinstance(include, PlaybookInclude)
    assert include.import_playbook == '../../test_playbook_include_play.yml'

# Generated at 2022-06-23 06:36:28.161733
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # Testing for constructor of class PlaybookInclude
    obj = PlaybookInclude()
    assert obj._import_playbook == ''
    assert obj._vars == {}
    assert obj.tags == []
    assert obj.when == []

    obj2 = PlaybookInclude()
    assert obj == obj2

    obj3 = PlaybookInclude(dict(import_playbook='tests/playbooks/foo.yml', vars=dict(a=1, b=2)),
                           dict(import_playbook='tests/playbooks/foo.yml', vars=dict(a=1, b=2)))
    obj3.tags.append('test')
    assert obj3.import_playbook == 'tests/playbooks/foo.yml'
    assert obj3.vars == dict(a=1, b=2)


# Generated at 2022-06-23 06:36:32.332219
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
   playbook_include = PlaybookInclude()
   assert playbook_include.vars == {}
   assert playbook_include.when == []
   assert playbook_include.tags == []

# Generated at 2022-06-23 06:36:43.180102
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.template import Templar

    def _create_data_structure(name, vars):
        datastructure = AnsibleMapping()
        datastructure[name] = vars
        return datastructure

    inventory_manager = InventoryManager(loader=DataLoader())
    inventory_manager.set_inventory([])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory_manager)
    variable_manager

# Generated at 2022-06-23 06:36:54.652140
# Unit test for method preprocess_data of class PlaybookInclude

# Generated at 2022-06-23 06:37:00.832239
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include = PlaybookInclude()

    # Check one for loops without fail
    playbook_include.load_data({'include': 'test.yml'}, '')

    # Check one for loops without fail
    playbook_include.load_data({'import_playbook': 'test.yml'}, '')


# Generated at 2022-06-23 06:37:02.296458
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # TODO
    pass

# Generated at 2022-06-23 06:37:10.908251
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    '''
    Test case to check that preprocess_data() method of PlaybookInclude class is able to handle incorrect data structure formats
    Test Steps:
        1. Prepare data structures
        2. Run preprocess_data() with incorrect input data
        3. Verify that AnsibleAssertionError exception is raised with correct error message
    '''

    test_obj = PlaybookInclude()
    assert isinstance(test_obj, PlaybookInclude)
    ds = AnsibleMapping()
    ds['import_playbook'] = '/var/lib/awx/projects/test_proj/playbooks/test_import.yml'
    ds['vars'] = AnsibleMapping()
    ds['vars']['other_var'] = 'other_value'

    from ansible.playbook.play import Play
   

# Generated at 2022-06-23 06:37:17.602482
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    p = PlaybookInclude.load(data={"import_playbook": "first.yml", "vars": {"a": "1"}}, basedir=".")
    assert p._import_playbook == "first.yml"
    assert UnsafeProxy(p._vars)['a'] == "1"
    assert isinstance(p._vars, AnsibleMapping)

    p = PlaybookInclude.load(data={"include": "first.yml", "vars": {"a": "1"}}, basedir=".")
    assert p._import_playbook == "first.yml"

# Generated at 2022-06-23 06:37:26.569568
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include = PlaybookInclude()
    ds = {'include': 'test.yml'}
    ds_out = playbook_include._preprocess_include(ds, {})
    assert ds_out == {'include': 'test.yml'}
    ds_out['include'] = '../test.yml'
    ds_out_2 = playbook_include._preprocess_include(ds_out, {})
    assert ds_out_2 == ds_out
    try:
        ds_out['include'] = 1
        playbook_include._preprocess_include(ds_out, {})
    except AnsibleParserError:
        raise AssertionError

# Generated at 2022-06-23 06:37:33.715301
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = 'variable_manager'
    basedir = '/tmp'

    ds = dict(import_playbook='test_import_playbook.yml')
    pbi = PlaybookInclude.load(ds, basedir, variable_manager, loader)
    # FIXME: I'm not sure, how to test loading of a Playbook object from a
    # PlaybookInclude object.

# Generated at 2022-06-23 06:37:43.283697
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    loader = None
    variable_manager = None
    playbook = './test/unit/lib/ansible/playbook/test_helpers/playbook_include.yaml'
    basedir = './test/unit/lib/ansible/playbook/test_helpers'

    with open(playbook, 'r') as f:
        test_playbook = PlaybookInclude.load(f.read(), basedir, variable_manager, loader)
        assert test_playbook
        assert test_playbook._entries[0].name == 'include 1'
        assert test_playbook._entries[1].name == 'include 2'
        assert test_playbook._entries[0].vars['ansible_hosts'] == 'hosts/hosts.yaml'
        assert test_playbook._entries[1].v

# Generated at 2022-06-23 06:37:48.794154
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible import context
    from ansible.utils.display import Display
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook

    display = Display()
    display.verbosity = 4

    # setup
    context.CLIARGS = {}

    # test_PlaybookInclude_load_data: entries has correct length and type
    ds = dict(import_playbook='playbook.yml', tags=['a'], vars=dict(x=1))
    entries = PlaybookInclude.load(ds, '/home/test/test1')._entries
    assert len(entries) == 1 and isinstance(entries[0], Play)

    # test_PlaybookInclude_load_data: e_0, entries[0], has correct 'tags' attribute
    entries = Play

# Generated at 2022-06-23 06:38:02.168818
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Play

    # import here to avoid a dependency loop
    from ansible.playbook import Playbook

    ds = {
        "_import_playbook": "somefile",
        "vars": {
            "var1": "value1",
            "var2": "value2",
            "var3": "value3",
        }
    }

    pbi = PlaybookInclude().load(ds, basedir='./test')

    assert isinstance(pbi, Playbook)
    assert len(pbi._entries) == 1
    assert len(pbi._entries[0].tasks) == 1
    assert isinstance(pbi._entries[0], Play)

# Generated at 2022-06-23 06:38:12.010422
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.tasks.task import Task
    from ansible.playbook.block import Block
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.reserved import reserved_variables

    # setup a fake playbook object to load with

# Generated at 2022-06-23 06:38:21.603777
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    import json
    import unittest

    from ansible.parsing.yaml.constructor import AnsibleConstructor

    def to_yaml(value):
        return AnsibleConstructor.construct_yaml_object(parent=None, node=value, deep=True)

    class TestPlaybookInclude(unittest.TestCase):

        def test_constructor(self):
            data = dict(
                import_playbook="test.yml",
            )
            with self.assertRaises(AnsibleParserError):
                PlaybookInclude.load(data, "/")
            data['vars'] = dict()
            to_yaml(data)
            import_playbook = PlaybookInclude.load(data, "/")

# Generated at 2022-06-23 06:38:33.065968
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    # import here to avoid a dependency loop
    from ansible.playbook.play import Play

    # test calling load with None
    import_playbook = PlaybookInclude()
    test_playbook = import_playbook.load(None, None)
    assert test_playbook is None

    # test calling load with non-dict data structure
    import_playbook = PlaybookInclude()
    test_playbook = import_playbook.load("test", None)
    assert test_playbook is None

    # test calling load with an empty dict data structure
    import_playbook = PlaybookInclude()
    test_playbook = import_playbook.load({}, None)
    assert type(test_playbook) is Playbook
    assert len(test_playbook._entries) == 0

# Generated at 2022-06-23 06:38:36.329960
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    p = PlaybookInclude.load(data={'import_playbook': 'playbook.yml'}, basedir='/etc')
    assert isinstance(p, Playbook)

# Generated at 2022-06-23 06:38:37.970708
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    assert False, "test_PlaybookInclude_load_data not implemented"


# Generated at 2022-06-23 06:38:51.997605
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # Import is required.
    assert_raises(AnsibleParserError, PlaybookInclude, ds={})
    assert_raises(AnsibleParserError, PlaybookInclude, ds={'import_playbook':None})
    assert_raises(AnsibleParserError, PlaybookInclude, ds={'import_playbook':1})
    # Import must be a string.
    assert_raises(AnsibleParserError, PlaybookInclude, ds={'import_playbook':'foo', 'vars':{'bar':'baz'}})

    # Import with vars
    assert PlaybookInclude(ds={'import_playbook':'foo', 'vars':{'bar':'baz'}})
    # Import with tags

# Generated at 2022-06-23 06:39:03.157853
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # Import
    import pytest
    # pytestmark = pytest.mark.skipif(reason="AnsibleCollectionConfig is not loaded")
    # Setup
    ds = 'import_playbook="tests/foo.yml",vars={"a":1,"b":2},tags=["bar","baz"]'
    basedir = 'tests/'
    # Exercise
    result = PlaybookInclude.load(data=ds, basedir=basedir)
    # Verify
    assert result.import_playbook == 'tests/foo.yml'
    assert result.vars == {'a': 1, 'b': 2}
    assert result.tags == ['bar', 'baz']
    # Cleanup - done automatically by destructor


# Generated at 2022-06-23 06:39:12.841785
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Setting up
    ds = {'import_playbook': 'value1', 'tags': 'tag1', 'ignore_errors': 'yes'}

    # Testing
    new_ds = AnsibleMapping()
    new_ds['import_playbook'] = 'value1'
    new_ds['tags'] = 'tag1'
    new_ds['ignore_errors'] = 'yes'

    test_pb_inc = PlaybookInclude()
    n_ds = test_pb_inc.preprocess_data(ds)

    # Verifying
    assert new_ds == n_ds



# Generated at 2022-06-23 06:39:21.157940
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import unittest
    import ansible.playbook.play as play
    from ansible.playbook.playbook import Playbook

    class MyTest(unittest.TestCase):
        def runTest(self):
            ds = {'import_playbook': 'playbook.yml'}
            ansible_pos = None
            pb = PlaybookInclude.load_data(ds=ds, basedir='.', variable_manager=None, loader=None)
            self.assertTrue(isinstance(pb, Playbook))
            #TODO: validate all elements of pb

            ds = {'import_playbook': 'playbook.yml include=foo.yml'}
            ansible_pos = None

# Generated at 2022-06-23 06:39:27.140427
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    import os

    import pytest

    from units.mock.loader import DictDataLoader

    ROOT_DIR = os.path.dirname(__file__)
    TEST_PLAYBOOK = os.path.join(ROOT_DIR, '_data', 'playbook.yml')

    template_dir = os.path.join(ROOT_DIR, '_data', 'template')

    loader = DictDataLoader({})


# Generated at 2022-06-23 06:39:40.543791
# Unit test for method preprocess_data of class PlaybookInclude

# Generated at 2022-06-23 06:39:47.091211
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    basedir = 'tests/units/parsing/fixtures/include'
    playbook_str = '''
    - foo: bar
    - bar: foo
    - include: included.yml
    '''
    playbook = PlaybookInclude.load(playbook_str, basedir, variable_manager=variable_manager, loader=loader)
    assert playbook
    assert playbook._entries
    assert playbook._entries[2].tasks[0].action == 'include'
    assert playbook._entries[2].tasks[0].args['include'] == 'included.yml'

# Generated at 2022-06-23 06:39:56.277794
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager.set_inventory(inventory)

    playbook_include = PlaybookInclude()
    playbook_include.import_playbook = 'new_playbook.yaml'
    playbook_include.vars = {'x':'y'}
    playbook_include.tags = ['test']

    playbook_include.load_data(None, "", variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-23 06:40:07.032850
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    import os
    import json

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost', 'tests/inventory'])
    variable_manager.set_inventory(inventory)

    # parse the playbook
    pb = Playbook.load('examples/include_playbook.yml', variable_manager=variable_manager, loader=loader)
    assert len(pb.get_plays()) == 1
    play = pb.get_plays()[0]

    # verify the included playbook has entries
   

# Generated at 2022-06-23 06:40:14.835064
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.playbook.task.include import Include
    from ansible.playbook.task.include_role import IncludeRole
    from ansible.vars.manager import VariableManager

    # create a play to test load a playbook
    pb = Playbook.load('test/unit/utils/fixtures/literal_include_playbook.yml', 
                        variable_manager = VariableManager(),
                        loader = None)
    assert len(pb.get_plays()) == 1
    assert pb.get_plays()[0].hosts == ['localhost']

    # create a play to test load a playbook with inline vars

# Generated at 2022-06-23 06:40:27.236282
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''
    Unit test for method load_data of class PlaybookInclude
    '''

    from ansible.playbook import Playbook
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    import ansible.constants as C

    p = Playbook()

    loader = DataLoader()

    pb1 = PlaybookInclude.load({"import_playbook": "playbook1.yaml"}, C.DEFAULT_LOCAL_TMP, loader=loader, variable_manager=VariableManager())
    assert isinstance(pb1, Playbook)

    pb2 = PlaybookInclude.load({"import_playbook": "playbook2.yaml"}, C.DEFAULT_LOCAL_TMP, loader=loader, variable_manager=VariableManager())
   

# Generated at 2022-06-23 06:40:35.551604
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    def should_have_similar_content(data1, data2):
        for key in data2:
            if key not in data1:
                return False
            if isinstance(data1[key], dict) and isinstance(data2[key], dict):
                if not should_have_similar_content(data1[key], data2[key]):
                    return False
            elif isinstance(data2[key], list):
                if set(data1[key]) != set(data2[key]):
                    return False
            elif data1[key] != data2[key]:
                return False
        return True


# Generated at 2022-06-23 06:40:37.123085
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass


# Generated at 2022-06-23 06:40:38.337656
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    PlaybookInclude.load({})

# Generated at 2022-06-23 06:40:48.561368
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # Test the constructor
    pbI = PlaybookInclude()

    # Test the import_playbook attribute
    pbI.import_playbook = "playbook.yml"
    assert pbI.import_playbook == "playbook.yml"

    # Test the vars attribute
    pbI.vars = dict(a=1, b=2)
    assert len(pbI.vars) == 2
    assert pbI.vars['b'] == 2

    # Test the when attribute
    pbI.when = "a==1"
    assert pbI.when == "a==1"

# Generated at 2022-06-23 06:40:59.631511
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.dataloader import DataLoader

    ds = dict(
        import_playbook='/path/to/import.yml',
    )

    # When import_playbook is given as a C._ACTION_IMPORT_PLAYBOOK key,
    # the key is converted to import_playbook.
    result = PlaybookInclude.load(ds, basedir='/path/to/ansible')
    assert isinstance(result, PlaybookInclude) and result.import_playbook == '/path/to/import.yml'

    # When import_playbook is not given as a key, an error is risen.
    ds = dict(
        import_playbooks='/path/to/import.yml',
    )

# Generated at 2022-06-23 06:41:01.975562
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    PlaybookInclude.load(data=dict(import_playbook='some_file'), basedir='..')


# Generated at 2022-06-23 06:41:13.962422
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    def _test_include(ds):
        p = PlaybookInclude.load(ds, './test/')
        assert len(p._entries) == 1
        P = p._entries[0]
        assert isinstance(P, Play.__class__)
        assert P.name == 'test'

    ds = {'import_playbook': './test/test_playbook.retry'}
    _test_include(ds)

    ds = {'import_playbook': './test/test_playbook.retry limit=localhost'}
    _test_include(ds)

    ds = {'import_playbook': './test/test_playbook.retry limit=localhost tags=tag1'}
    _test_include(ds)


# Generated at 2022-06-23 06:41:26.167452
# Unit test for method preprocess_data of class PlaybookInclude

# Generated at 2022-06-23 06:41:36.775829
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.template import Templar


# Generated at 2022-06-23 06:41:46.868065
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    data = {'import_playbook': './all.yml'}
    expected_data = {'import_playbook': './all.yml', 'vars': {}}
    actual_data = PlaybookInclude._PlaybookInclude__preprocess_data(data)
    assert expected_data == actual_data

    data = {'import_playbook': './all.yml tags=test'}
    expected_data = {'import_playbook': './all.yml', 'tags': 'test', 'vars': {}}
    actual_data = PlaybookInclude._PlaybookInclude__preprocess_data(data)
    assert expected_data == actual_data

    data = {'import_playbook': './all.yml tags=test vars: test'}

# Generated at 2022-06-23 06:41:57.154238
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # Check for None
    try:
        PlaybookInclude.load_data(None)
        assert False
    except AssertionError:
        pass

    # Check for a non-dict
    bad_ds = "not a dict"
    try:
        PlaybookInclude.load_data(bad_ds)
        assert False
    except AssertionError:
        pass

    # Check for the presence of a non-dict 'vars' entry
    bad_ds = {'vars': 'not a dict'}
    try:
        PlaybookInclude.load_data(bad_ds)
        assert False
    except AnsibleParserError:
        pass

    # Check for an empty dict
    try:
        PlaybookInclude.load_data({})
        assert False
    except AnsibleParserError:
        pass


# Generated at 2022-06-23 06:42:09.369430
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import ansible.playbook.play
    import ansible.playbook.task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.taggable import Taggable
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    result = []

    with open('/tmp/test-include', 'w+') as f:
        f.write(
            """
            ---
            - hosts: localhost
              roles:
              - role_a

            - hosts: localhost
              tasks:
              - name: task_a
              - name: task_b
            """)

    def variable_manager_update_vars_func(self, vars_dict):
        pass


# Generated at 2022-06-23 06:42:20.393869
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handlers.handler import Handler
    from ansible.playbook.role.include import RoleInclude

    ds = {
        'import_playbook': 'playbook.yml',
        'vars': {
            'key1': 'value1'
        },
        'tags': 'tag1,tag2'
    }
    basedir = '/home/user'

    # create DataLoader
    loader = Data

# Generated at 2022-06-23 06:42:33.213019
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    ds = AnsibleMapping()
    ds['import_playbook'] = 'new_playbook.yml'
    ds['vars'] = {'foo': 'bar'}
    ds['tags'] = ['tag1', 'tag2']

    new_ds = AnsibleMapping()
    new_ds['import_playbook'] = 'new_playbook.yml'
    new_ds['vars'] = {'foo': 'bar'}
    new_ds['tags'] = ['tag1', 'tag2']

    pbi = PlaybookInclude()
    actual_ds = pbi.preprocess_data(ds)
    assert(actual_ds == new_ds)

    display.deprecated_warning = False
    ds = AnsibleMapping()

# Generated at 2022-06-23 06:42:44.230073
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os
    import sys

    import ansible.playbook
    import ansible.playbook.play
    import ansible.playbook.block
    from ansible.module_utils.six import StringIO

    from ansible.utils.vars import combine_vars

    #####################################################################
    # Test load_data with a simple playbook
    #####################################################################

    # load_data must work with a simple playbook

    # Create the directory for the playbook
    test_directory = os.path.join(os.path.dirname(__file__), 'test_data', 'include', '1')

    # Create the playbook file
    playbook_path = os.path.join(test_directory, 'playbook.yml')

    # Write the playbook
    with open(playbook_path, 'w') as file_p:
        file

# Generated at 2022-06-23 06:42:51.812105
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Create a PlaybookInclude object and assign value to attribute basedir
    playbook_include = PlaybookInclude()
    playbook_include.basedir = './tests/unit/lib/ansible/playbook'

    # Load data from playbook include
    playbook_include.load_data(ds={'import_playbook':'tests/unit/lib/ansible/playbook/include_file.yml'})

    # Check the output of playbook include is a playbook
    assert playbook_include._entries is not None

# Generated at 2022-06-23 06:43:04.432686
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    """ Unit test for method load_data of class PlaybookInclude"""
    import pdb

    # Test 1 ------------------------------------------------------------------
    import_playbook = "test/test_playbook_include.yml"
    ds = {
        'import_playbook': import_playbook
    }
    basedir = os.path.join(os.path.dirname(__file__), '..', '..', 'lib', 'ansible', 'playbook')

    playbook_result_file = os.path.join(basedir, import_playbook)
    playbook_result_file = os.path.abspath(playbook_result_file)

    playbook_include = PlaybookInclude.load(
        ds=ds,
        basedir=basedir
    )

    assert playbook_include._entries[0]._included_

# Generated at 2022-06-23 06:43:15.491270
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # Creating mock of module
    playbook_include_class_mock = PlaybookInclude()
    playbook_include_class_mock.__dict__['_import_playbook'] = 'test_playbook.yml'
    playbook_include_class_mock.__dict__['_vars'] = {'var_1':'test1'}

    # assert error is thrown when ds is not a dict
    try:
        playbook_include_class_mock.preprocess_data('test_data')
    except AnsibleAssertionError as e:
        assert 'ds (test_data) should be a dict but was a %s' % type('test_data') in e.message
    else:
        assert False


# Generated at 2022-06-23 06:43:26.673375
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.parsing.yaml.objects import AnsibleMapping

    yaml_obj = AnsibleMapping()
    yaml_obj.update({'include_playbook': {'import_playbook': 'test.yaml', 'vars': {'key1': 'value1', 'key2': 'value2'}, 'tags': 'tag1,tag2'}})

    pb_include = PlaybookInclude.load(yaml_obj, '/tmp/')
    assert pb_include.import_playbook == "test.yaml"
    assert 'tag1' in pb_include.tags
    assert 'tag2' in pb_include.tags
    assert pb_include.vars == {'key1': 'value1', 'key2': 'value2'}

# Generated at 2022-06-23 06:43:37.855994
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.playbook_include import PlaybookInclude
    import sys
    import os

    playbook_file = "test1.yml"
    playbook_content="""
- hosts:  '127.0.0.1'
  tasks:
  - name:  test
    ping:
  tags:
    - test_tag1
    - test_tag2
    """
    f = open(playbook_file, "w")
    f.write(playbook_content)
    f.close()

    playbook_include_content = """
- import_playbook: test1.yml
      """
    playbook_include_file = "playbook_include_file.yml"
    f2 = open(playbook_include_file, "w")

# Generated at 2022-06-23 06:43:49.099871
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # test_data1 is a dict with a key "import_playbook" and value "a/path/to/another/playbook.yml"
    test_data1 = {
        "import_playbook": "a/path/to/another/playbook.yml"
    }

    # test_data2 is a dict with the same key, but with the value "a/path/to/another/playbook2.yml tags=foo,bar var1=value1"
    test_data2 = {
        "import_playbook": "a/path/to/another/playbook2.yml tags=foo,bar var1=value1"
    }

    # test_data3 is a dict with the same key, but with the value "a/path/to/another/playbook3.yml tags=foo,bar var

# Generated at 2022-06-23 06:43:56.758771
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Task as Handler

    def get_entry(playbook, entry_type=Play, name='play'):
        entry = None
        for entry in playbook._entries:
            if isinstance(entry, entry_type) and name in entry.name:
                break
        return entry

    def get_task(play_entry, task_type=Task, name='task'):
        task = None
        for task in play_entry.tasks:
            if isinstance(task, task_type) and name in task.name:
                break
        return task

    def get_handler(play_entry, handler_type=Handler, name='handler'):
        handler = None

# Generated at 2022-06-23 06:44:08.515612
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Test that a playbookimport is correctly translated to a playbook_include
    playbookimport = {'playbookimport': './test/new.yml', 'vars': {'newvar': 'newval', 'tags': 'test,test2'}}
    import_playbook = PlaybookInclude.preprocess_data(playbookimport)
    assert import_playbook == {'import_playbook': './test/new.yml', 'vars': {'newvar': 'newval', 'tags': 'test,test2'}}
    # Test that a playbookimport is correctly split and translated to a playbook_include
    playbookimport = {'playbookimport': './test/new.yml newvar=newval tags=test,test2'}
    import_playbook = PlaybookInclude.preprocess_data(playbookimport)
   

# Generated at 2022-06-23 06:44:21.582588
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    ds1 = {
        'include': 'test/test.yml',
        'vars': {
            'a': 1,
            'b': 2
        },
        'tags': 'foo,bar'
    }

    ds2 = {
        'import_playbook': 'test/test.yml',
        'vars': {
            'a': 1,
            'b': 2
        },
        'tags': 'foo,bar'
    }

    pbi1 = PlaybookInclude.load(ds1, loader=loader, basedir='/')
    pbi2 = PlaybookInclude.load(ds2, loader=loader, basedir='/')
    assert pbi1.vars == p

# Generated at 2022-06-23 06:44:27.818363
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    p = PlaybookInclude()
    p.import_playbook = "include_this.yml"
    p.tags = ["tag1", "tag2"]
    p.vars = {"var1":"value1","var2":"value2"}
    assert p.import_playbook == "include_this.yml"
    assert p.tags == ["tag1", "tag2"]
    assert p.vars["var1"] == "value1"
    assert p.vars["var2"] == "value2"