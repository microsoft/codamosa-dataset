

# Generated at 2022-06-23 06:34:22.947863
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-23 06:34:32.031804
# Unit test for method load of class PlaybookInclude

# Generated at 2022-06-23 06:34:34.934854
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    playbook_include = PlaybookInclude()
    assert playbook_include.tags == None
    assert playbook_include.when == None
    assert playbook_include.vars == {}
    assert playbook_include.import_playbook == None

# Generated at 2022-06-23 06:34:35.617381
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    PlaybookInclude()

# Generated at 2022-06-23 06:34:43.738712
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import vars_loader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager.add_vars({'FooVar': 'foo_value'})
    variable_manager._extra_vars = {'FooVar2': 'foo_value2'}


# Generated at 2022-06-23 06:34:54.943823
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    import ansible.playbook.playbook
    import ansible.playbook.play
    import ansible.template.template
    import ansible.parsing.vault
    import ansible.utils
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.constructor import AnsibleConstructor

    # Create a simple yaml data structure
    yaml = '''
- include_playbook: collection/namespace/playbook.yml
    vars:
      var1: value1
      var2: value2
- hosts: localhost
  tasks:
  - debug:
      msg: Hello World
'''
    yaml_ds = AnsibleConstructor(ansible=True, safe=False).construct_yaml_map(yaml)


# Generated at 2022-06-23 06:34:55.503929
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pass

# Generated at 2022-06-23 06:35:05.269051
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    ds = AnsibleMapping(dict(import_playbook = 'playbook.yml'))
    ds_expected = AnsibleMapping(dict(import_playbook = 'playbook.yml'))
    assert ds == ds_expected
    ds = AnsibleMapping(dict(import_playbook = 'playbook.yml', vars = dict(a = 'b')))
    ds_expected = AnsibleMapping(dict(import_playbook = 'playbook.yml', vars = dict(a = 'b')))
    assert ds == ds_expected
    ds = AnsibleMapping(dict(import_playbook = 'playbook.yml tags=tag1,tag2'))

# Generated at 2022-06-23 06:35:12.569489
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # test PlaybookInclude with invalid ds.
    ds = 'Invalid Datastructure'
    try:
        PlaybookInclude().load_data(ds=ds, basedir='/basedir', variable_manager=None, loader=None)
    except Exception as e:
        assert isinstance(e, AnsibleAssertionError)

    # test PlaybookInclude with valid ds.
    ds = {'import_playbook': '/path/to/playbook', 'vars': {'var1': 'value1', 'var2': 'value2'}}
    result = PlaybookInclude().load_data(ds=ds, basedir='/basedir', variable_manager=None, loader=None);

# Generated at 2022-06-23 06:35:22.844221
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    yaml_str = '''
    - hosts: all
      import_playbook: foo.yml
    '''
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    import ansible.constants as C

    loader = DataLoader()

    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list=C.DEFAULT_HOST_LIST)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    obj = PlaybookInclude.load(yaml_str, variable_manager=variable_manager, loader=loader)
    print(obj._entries)

# Generated at 2022-06-23 06:35:31.275816
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # we are testing the PlaybookInclude class
    from ansible.playbook import PlaybookInclude

    # valid Dict
    ds = dict(
        import_playbook = "playbook.yml",
        vars = dict(
            key = "value"
        )
    )

    # invalid Dict
    ds2 = dict(
        import_playbook = "playbook.yml",
        vars = "value"
    )

    # test PlaybookInclude with valid ds
    o = PlaybookInclude.load(ds, "")
    assert o.import_playbook == "playbook.yml"
    assert o.vars == dict(key="value")

    # test PlaybookInclude with invalid ds

# Generated at 2022-06-23 06:35:41.470269
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()

    # Initialize a playbook include
    playbook_include = PlaybookInclude()

    # Basic test
    playbook_include_data = '''
- import_playbook: playbooks/test_playbook.yml   
    vars:
      var_1: "123"
      var_2: "456"

- import_playbook: playbooks/test_playbook.yml   
    vars:
      var_3: "789"
      var_4:
        var_4_1: "ABC"
'''

# Generated at 2022-06-23 06:35:54.221212
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.parsing.utils.addresses import parse_address
    playbook_path = '/Users/daniel/ansible-playbooks/playbook1.yml'
    basedir = '.'
    absolute_playbook_path = os.path.join(basedir, playbook_path)
    display.display("absolute_playbook_path is: %s"%absolute_playbook_path)
    display.display("basedir is %s"%basedir)
    ds = {'import_playbook': '../playbook2.yml',
          'vars': {'var_3': 3, 'var_4': 4},
          'when': {'var_1': 1, 'var_2': 2}}
    variable_manager = None
    loader = None

# Generated at 2022-06-23 06:36:05.253811
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    ds = {}
    ds[0] = {'import_playbook': 'foo.yml', 'vars': {'foo': 'bar'}, 'tags': ['tag1', 'tag2']}
    ds[1] = {'import_playbook': 'foo.yml', 'vars': {'foo': 'bar'}}
    ds[2] = {'import_playbook': 'foo.yml', 'extra_param': {'foo': 'bar'}}
    for d in ds:
        p = PlaybookInclude.load(d, '')
        assert p.import_playbook == d[list(d.keys())[0]]
        if d.get('vars', None):
            assert p.vars['foo'] == d['vars']['foo']

# Generated at 2022-06-23 06:36:17.321687
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play import Play

    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    v = VariableManager()
    v.set_variable('testvar', 'testvalue')
    v.set('testvar2', 'testvalue2')

    pb = PlaybookInclude()
    pb.load_data(ds="playbook.yml", basedir='/foo/bar/baz', variable_manager=v)

    assert v == pb._variable_manager

    pb = Playbook()

# Generated at 2022-06-23 06:36:29.006002
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Initialize with data to be tested in preprocess
    data = dict(
        import_playbook='./playbook1.yml',
        name=dict(
            first=dict(
                middle='first',
                last="last"
            )
        ),
        vars=dict(
            var1="value1"
        )
    )
    new_ds = AnsibleMapping()
    new_ds['import_playbook'] = data['import_playbook']
    new_ds['vars'] = data['vars']

    # test preprocessor
    test_preprocess_data = PlaybookInclude().preprocess_data(data)
    assert test_preprocess_data == new_ds

# Generated at 2022-06-23 06:36:33.268819
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    playbook_include =  PlaybookInclude()
    assert playbook_include is not None, 'PlaybookInclude object should not be empty'

# Generated at 2022-06-23 06:36:34.051773
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-23 06:36:44.190545
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.playbook.play import Play
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.errors import AnsibleParserError
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Test simple valid case
    data = '''
- import_playbook: /playbook.yml
'''
    loader = AnsibleLoader(data, 'memory')
    loaded_data = PlaybookInclude.load(data=loader.get_single_data(), basedir='.')
    assert isinstance(loaded_data, PlaybookInclude)
    assert loaded_data.import_playbook == '/playbook.yml'
    assert loaded_data.vars == dict()
    assert loaded_data.tags == list()
    assert loaded_data.when == list()

    # Test

# Generated at 2022-06-23 06:36:44.969553
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    playbook_include = PlaybookInclude()
    assert playbook_include

# Generated at 2022-06-23 06:36:56.426715
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import ansible.playbook as playbook
    import ansible.playbook.play_context as context
    from ansible.vars import VariableManager

    # PlaybookInclude().load_data() takes 6 arguments, which we can use to set
    # the defaults. We are going to test the function with a different set of
    # arguments. Hence, let's define the variables, with different values.
    ds = {'import_playbook': 'test_playbook_1.yml'}
    basedir = 'tests_data/playbooks'
    loader = None
    vars_ = {'var1': ['value1'], 'var2': 'value2'}
    variable_manager = VariableManager()
    variable_manager.extra_vars = vars_

    # The method returns a Playbook object. Let us define a variable to hold

# Generated at 2022-06-23 06:37:07.986035
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    '''
    Ensures that a PlaybookInclude object can be loaded
    '''
    from ansible.playbook import Play
    from ansible.playbook.play import Playbook

    ds = dict(
        import_playbook="foo.yml",
        when=True
    )
    p = PlaybookInclude.load(ds, '.')
    assert isinstance(p, Playbook)
    assert len(p._entries) == 1

    play = p._entries[0]
    assert isinstance(play, Play)
    assert play.name == "foo.yml"
    assert len(play.tasks) == 0
    assert len(play.roles) == 0
    assert len(play.pre_tasks) == 0
    assert len(play.post_tasks) == 0

# Generated at 2022-06-23 06:37:20.678022
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.dataloader import DataLoader

    basedir = os.path.dirname(os.path.dirname(__file__))
    loader = DataLoader()

    playbook_include = PlaybookInclude.load(dict(import_playbook='test.yml'), None, loader=loader)

    assert playbook_include.import_playbook == 'test.yml'
    assert playbook_include.vars == {}
    assert playbook_include.tags == []

    playbook_include = PlaybookInclude.load(dict(import_playbook='test.yml tags=tag1,tag2'), None, loader=loader)

    assert playbook_include.import_playbook == 'test.yml'
    assert playbook_include.vars == {}

# Generated at 2022-06-23 06:37:35.938024
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import ansible.playbook.tests.preprocess_data.data as __test_data
    from ansible.playbook.tests.preprocess_data import assert_data_equal

    # preprocess_data() should return an AnsibleMapping object
    playbook_import = PlaybookInclude()
    assert playbook_import.preprocess_data(__test_data.PLAYBOOK_IMPORT_INPUT_DATA) == AnsibleMapping
    playbook_import_clean = playbook_import.preprocess_data(__test_data.PLAYBOOK_IMPORT_INPUT_DATA)
    # Parameters in the input data should have been moved to the correct places,
    # and redundant ones removed
    assert_data_equal(playbook_import_clean, __test_data.PLAYBOOK_IMPORT_CLEAN_DATA)

# Generated at 2022-06-23 06:37:43.452305
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook_include import PlaybookInclude
    data = AnsibleMapping()

    data['playbook'] = 'script/test.yml'
    data['vars'] = {'var_1': 'test_1'}
    data['when'] = ['a', 'b']
    data['tags'] = 'tag1,tag2'
    basedir = '.'
    variable_manager = None
    loader = None

    from ansible.playbook import Playbook
    playbook = PlaybookInclude().load(data, basedir, variable_manager, loader)
    assert isinstance(playbook, Playbook)


# Generated at 2022-06-23 06:37:54.497649
# Unit test for method preprocess_data of class PlaybookInclude

# Generated at 2022-06-23 06:37:55.473742
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-23 06:38:00.303528
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    import yaml
    yaml.safe_load('''
- import_playbook: ./my_import_playbook.yml
''')


# Generated at 2022-06-23 06:38:06.302357
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # Test PlaybookInclude by loading an external playbook
    playbook_file_name = os.path.join(C.TEST_DIR, 'support/test_playbook.yml')
    playbook_include = PlaybookInclude.load(data={"import_playbook": playbook_file_name},
                                            basedir=C.TEST_DIR,
                                            variable_manager=None,
                                            loader=None)
    assert playbook_include.vars == {}



# Generated at 2022-06-23 06:38:07.591401
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass


# Generated at 2022-06-23 06:38:17.942420
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():

    # imports here, to make sure they are present when testing load
    import ansible.playbook
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook import Playbook


# Generated at 2022-06-23 06:38:30.861536
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode


# Generated at 2022-06-23 06:38:31.818865
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass


# Generated at 2022-06-23 06:38:41.762679
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext
    import ansible.playbook

    class AnsibleOptions(object):
        connection = 'local'
        module_path = None
        forks = 10
        become = None
        become_method = None
        become_user = None
        check = False
        diff = False
        listhosts = None
        listtasks = None
        listtags = None
        syntax = None
        tags = None
        verbosity = False
        start_at_task = None

    class AnsibleRunner(object):
        def __init__(self):
            pass


# Generated at 2022-06-23 06:38:53.801315
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    import_playbook = '../playbooks/playbook.yml'
    vars = {'variable1':'value1', 'variable2':'value2'}
    import_playbook_obj = PlaybookInclude()
    import_playbook_obj.import_playbook = import_playbook
    import_playbook_obj.vars = vars

    assert import_playbook_obj.import_playbook == import_playbook
    assert import_playbook_obj.vars == vars
    assert import_playbook_obj.name is None
    assert import_playbook_obj.tags == []
    assert import_playbook_obj.when == []



# Generated at 2022-06-23 06:39:04.581454
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''
    Part of unit tests for Ansible module: ansible.parsing.yaml.objects.PlaybookInclude
    '''
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleUnicode, AnsibleSequence

    variables = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variables)

    # Prepare the data and basedir

# Generated at 2022-06-23 06:39:16.647738
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task

    # get the class reference to PlaybookInclude
    PlaybookInclude = PlaybookInclude()

    # generate a mock playbook.yml data structure (without the class)
    # and use load_data() to generate a new playbook object

# Generated at 2022-06-23 06:39:31.291110
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import os

    import pytest
    from ansible.errors import AnsibleParserError, AnsibleAssertionError
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader

    code_dir = os.path.dirname(os.path.realpath(__file__))
    base_dir = os.path.join(code_dir, 'playbook-include-test-playbooks')

    #  Test to check preprocess_data method for the correctness of the datatype of ds
    p = PlaybookInclude()
    with pytest.raises(AnsibleAssertionError) as exec_info:
        p.preprocess_data(['sample'])

# Generated at 2022-06-23 06:39:32.282347
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-23 06:39:43.904122
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import io
    import tempfile
    import yaml

    def _write_playbook(playbook_name, playbook_content):
        temp_dir = tempfile.mkdtemp()
        playbook_path = os.path.join(temp_dir, playbook_name)
        with open(playbook_path, 'w') as fd:
            yaml.safe_dump(playbook_content, fd)
        return playbook_path, temp_dir

    def _write_collection(collection_name, collection_content):
        temp_dir = tempfile.mkdtemp()
        collection_dir = os.path.join(temp_dir, collection_name)
        os.mkdir(collection_dir)

# Generated at 2022-06-23 06:39:55.846695
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    from ansible.playbook.loader import Loader
    from ansible.template import Templar
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    test_dir = os.path.dirname(os.path.realpath(__file__))
    parent_dir = os.path.dirname(test_dir)
    config_data = {}
    config = C.config.load(config_data, "/fake/path")
    loader = Loader(config, variable_manager=None)
    pb_include = PlaybookInclude()
    playbook = Playbook.load(os.path.join(parent_dir, 'playbook_include.yml'), loader=loader)

    # to load a playbook, load() method of class AnsibleCollectionConfig will
    # be called with its

# Generated at 2022-06-23 06:40:06.515382
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    playbook = PlaybookInclude.load(dict(import_playbook='file_name'), 'basedir')
    assert playbook.import_playbook == 'file_name'
    assert playbook.vars == {}
    assert playbook.tags == []

    playbook = PlaybookInclude.load(dict(import_playbook='file_name vars=dict'), 'basedir')
    assert playbook.import_playbook == 'file_name vars=dict'
    assert playbook.vars == {}
    assert playbook.tags == []

    playbook = PlaybookInclude.load(dict(import_playbook='file_name vars=dict tags=tag'), 'basedir')
    assert playbook.import_playbook == 'file_name vars=dict tags=tag'
    assert playbook.vars == {}
    assert playbook.tags == []


# Generated at 2022-06-23 06:40:19.519098
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.base import Base
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude

    loader = AnsibleLoader(None, None)
    playbooks = {}
    playbooks['playbook_include.yml'] = loader.load_from_file('test/units/modules/playbook_include.yml')
    playbooks['playbook_include_role.yml'] = loader.load_from_file('test/units/modules/playbook_include_role.yml')
    playbooks['playbook_include_task.yml'] = loader.load_

# Generated at 2022-06-23 06:40:24.270116
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.template import Templar
    ds = dict(
        name = 'Imported Play',
        hosts = 'myhost',
        import_playbook = '/foo',
        vars = dict(x=1),
        tags = 'foo,bar',
        when = 'b == 1'
    )
    pbi = PlaybookInclude()
    pb = Playbook()
    pb._entries.append(Play())
    pb._entries[0]._load_data(ds)
    pb._entries[0]._task_blocks = [[Play()]]

# Generated at 2022-06-23 06:40:30.468596
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    import os
    import sys
    from ansible.errors import AnsibleError
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from units.mock.vars_plugin import MockVarsModule

    # Load the fixtures
    # FIXME: create fixtures from static files present in tests/fixtures/parsing
    #        so that this test won't break when a new fixture is added
    loader = DataLoader()
    # FIXME: clarify playbook vs. playbook_include loading
    # FIXME: use AnsibleFileLoader to load data from files

# Generated at 2022-06-23 06:40:37.011002
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # construct object
    pi = PlaybookInclude()
    # check that default values are correct
    assert pi.import_playbook == None
    assert pi.vars == dict()
    assert pi.tags == list()
    assert pi.when == []


if __name__ == "__main__":
    test_PlaybookInclude()

# Generated at 2022-06-23 06:40:38.668491
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    #####################################
    # init
    #####################################
    PlaybookInclude()

# Generated at 2022-06-23 06:40:50.402429
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.module_utils.six import StringIO

    # PlaybookInclude with no tags and no vars
    data = '''- import_playbook: foo.yml'''
    playbook = PlaybookInclude.load(data, '/path/to/playbook')
    stream = StringIO()
    playbook.dump(stream=stream)
    assert data == stream.getvalue()

    # PlaybookInclude with tags and vars
    data = '''
    - import_playbook: foo.yml
      tags:
        - debug
        - verbose
      vars:
        foo: bar
    '''
    playbook = PlaybookInclude.load(data, '/path/to/playbook')
    stream = StringIO()
    playbook.dump(stream=stream)
    assert data == stream.getvalue()



# Generated at 2022-06-23 06:41:01.311531
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import sys
    args = ['-v', '-d']
    args.extend(sys.argv[1:])
    import unittest

    if len(args) > 1 and args[1] == '-v':
        display.verbosity = 2
    if len(args) > 1 and args[1] == '-d':
        display.debug = True

    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.utils.display import Display
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    from ansible.utils.vars import combine_vars

    display = Display()


# Generated at 2022-06-23 06:41:13.286961
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    import os
    import tempfile
    from ansible.playbook.playbook_include import PlaybookInclude
    import ansible.constants as C
    import ansible.playbook as playbook
    import ansible.utils.display as display
    import ansible.utils.collection_loader as collection_loader
    from ansible.utils.collection_loader._collection_finder import _get_collection_name_from_path, _get_collection_playbook_path
    from ansible.utils.collection_loader._collection_finder import _is_collection_path
    from ansible.utils.collection_loader._collection_finder import _get_collection_version_from_tree
    from ansible.utils.display import Display

    display = Display()


# Generated at 2022-06-23 06:41:22.681892
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    ds = AnsibleMapping()
    ds['import_playbook'] = "test.yml"

    import_pb = PlaybookInclude()
    new_ds = import_pb.preprocess_data(ds)
    assert(new_ds['import_playbook'] == 'test.yml')

    ds2 = AnsibleMapping()
    ds2['import_playbook'] = 'test.yml'
    ds2['vars'] = {'test': 'var'}
    new_ds2 = import_pb.preprocess_data(ds2)
    assert(new_ds2['import_playbook'] == 'test.yml')

# Generated at 2022-06-23 06:41:35.700178
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    ds = dict(
        import_playbook='/path/to/playbook.yml',
        vars=dict(foo='bar'),
        tags=['a', 'b'],
    )
    p_include = PlaybookInclude.load(ds, variable_manager=None, loader=None)
    assert p_include
    assert p_include.import_playbook == '/path/to/playbook.yml'
    assert p_include.vars == dict(foo='bar')
    assert p_include.tags == ['a', 'b']

    ds = dict(include='/path/to/playbook.yml')
    p_include = PlaybookInclude.load(ds, variable_manager=None, loader=None)

# Generated at 2022-06-23 06:41:46.169561
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pb = PlaybookInclude.load(dict(hosts='foo', import_playbook='bar/baz.yml', vars=dict(a=1)), '.')
    assert pb.import_playbook == 'bar/baz.yml'
    assert pb.vars == dict(a=1)

    pb = PlaybookInclude.load(dict(hosts='foo', import_playbook='bar/baz.yml', tags=['a','b']), '.')
    assert "a" in pb.tags
    assert pb.tags == ['a', 'b']

    pb = PlaybookInclude.load(dict(hosts='foo', import_playbook='bar/baz.yml', tags='a,b'), '.')
    assert "a" in pb.tags


# Generated at 2022-06-23 06:41:56.780119
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook, Play
    from ansible.playbook.play_context import PlayContext

    # test case 1: load_data with no data
    playbook_include1 = PlaybookInclude()
    playbook1 = playbook_include1.load_data(None, '.', None)
    assert playbook1 is None

    # test case 2: load_data with import_playbook
    data = AnsibleMapping()
    data['import_playbook'] = 'test_playbook.yml'
    pb_include2 = PlaybookInclude()
    playbook2 = pb_include2.load_data(data, '.', None)
    assert isinstance(playbook2, Playbook)

    # test case 3: load_data with import_playbook and vars

# Generated at 2022-06-23 06:42:07.384977
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    pb = PlaybookInclude()

    ds = dict(import_playbook='/path/to/playbook.yaml', tags=['admin'])
    assert pb.preprocess_data(ds) == {'import_playbook': '/path/to/playbook.yaml', 'tags': ['admin']}

    ds = dict(import_playbook='/path/to/playbook.yaml notags=1')
    assert pb.preprocess_data(ds) == {'import_playbook': '/path/to/playbook.yaml', 'vars': {'notags': '1'}}

    ds = dict(import_playbook='/path/to/playbook.yaml test=1')

# Generated at 2022-06-23 06:42:08.923816
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # FIXME: implement unit tests
    pass

# Generated at 2022-06-23 06:42:18.747006
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import json
    import yaml
    from ansible.module_utils.six import StringIO

    # Create a mock Playbook
    PlaybookMock = type('PlaybookMock', (object,), {})
    PlaybookMock.__name__ = 'PlaybookMock'
    PlaybookMock.load = lambda self, data, basedir, variable_manager, loader: data
    PlaybookMock.__str__ = lambda self: json.dumps(self.__dict__)
    PlaybookMock.__repr__ = lambda self: self.__str__()

    # Create a mock Play
    PlayMock = type('PlayMock', (object,), {})
    PlayMock.__name__ = 'PlayMock'

# Generated at 2022-06-23 06:42:26.085157
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    playbook_include = PlaybookInclude(import_playbook='some_playbook.yml', vars={'var1':'value1'})
    assert playbook_include.import_playbook == 'some_playbook.yml'
    assert playbook_include.vars == {'var1':'value1'}


# Generated at 2022-06-23 06:42:38.062008
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.tasks import Task
    from ansible.playbook.role import Role

    #
    #   Test for preprocessing of playbook include statement
    #
    playbook_include = PlaybookInclude()
    #
    #   Test for basic loading of playbook include statement
    #
    playbook_include.load_data(dict(import_playbook='dummy_playbook'), basedir='', variable_manager=None, loader=None)
    assert playbook_include.import_playbook == 'dummy_playbook'
    assert playbook_include.vars == {}
    #
    #   Test for loading of playbook include statement with tags
    #

# Generated at 2022-06-23 06:42:45.690157
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # test of preprocess_data with a normal dictionary
    import_playbook_dict = dict(
        import_playbook='test_file.yml',
        tags=['test1', 'test2'],
        vars={'test3': 'test4'}
    )

    pbi = PlaybookInclude()
    ds = pbi.preprocess_data(import_playbook_dict)

    assert ds.get('import_playbook') == import_playbook_dict.get('import_playbook')
    assert ds.get('tags') == import_playbook_dict.get('tags')
    assert ds.get('vars') == import_playbook_dict.get('vars')

# Generated at 2022-06-23 06:42:47.932406
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass



# Generated at 2022-06-23 06:42:59.306234
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    print("test load_data of class PlaybookInclude")
    # use dummy values for the parameter basedir and variable_manager of the method.
    basedir = "/home/ansible/collection/ansible_collections/app-delivery"
    variable_manager = "/home/ansible/collection/ansible_collections/app-delivery"

    # test the method load_data with data as a dict, where 'import_playbook' is a key of the dict
    print("\ttest case: data is a dict, where 'import_playbook' is a key of the dict")
    # define the test data
    data = {"import_playbook": "example_playbook.yml"}
    pbi = PlaybookInclude()

# Generated at 2022-06-23 06:43:01.024245
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # Create an empty object
    p = PlaybookInclude()
    assert p

# Generated at 2022-06-23 06:43:07.476367
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():

    # test_PlaybookInclude_load: required attributes missing
    data = dict()
    result = PlaybookInclude.load(data=data, basedir=None)
    assert result is False, "PlaybookInclude.load should return False for missing 'import_playbook'"

    # test_PlaybookInclude_load: not a string
    data = dict(
        import_playbook=dict()
    )
    result = PlaybookInclude.load(data=data, basedir=None)
    assert result is False, "PlaybookInclude.load should return False for not a string 'import_playbook'"

    # test_PlaybookInclude_load: empty string
    data = dict(
        import_playbook=''
    )
    result = PlaybookInclude.load(data=data, basedir=None)

# Generated at 2022-06-23 06:43:10.564748
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    loaded_PlaybookInclude = PlaybookInclude.load({}, ".")
    assert loaded_PlaybookInclude.import_playbook == ""
    assert not loaded_PlaybookInclude.tags
    assert not loaded_PlaybookInclude.when
    assert not loaded_PlaybookInclude.vars


# Generated at 2022-06-23 06:43:21.834576
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping

    ds = AnsibleMapping(data={'import_playbook': 'test.yml', 'vars': {'var1': 'val1', 'var2': 'val2'}})
    new_ds = PlaybookInclude.preprocess_data(ds)
    assert isinstance(new_ds, AnsibleMapping)
    assert 'import_playbook' in new_ds
    assert 'vars' in new_ds
    assert 'var1' in new_ds['vars']
    assert 'var2' in new_ds['vars']
    assert new_ds['vars']['var1'] == 'val1'
    assert new_ds['vars']['var2'] == 'val2'

# Generated at 2022-06-23 06:43:24.914367
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Given vars with a mandatory parameter
    # When load_data is called
    # Then AnsibleAssertionError is raised
    pass

# Generated at 2022-06-23 06:43:36.799551
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.playbook import Playbook
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml_data = """
        - import_playbook: imported_playbook.yml
          vars:
            var1: 1
            var2: 2
        - import_playbook: imported_playbook.yml var1=1 var2=2
        - import_playbook: imported_playbook.yml var1=1 var2=2
    """

    variable_manager = VariableManager()

    # Testing PlaybookInclude constructor
    data = AnsibleLoader(yaml_data).get_single_data()

# Generated at 2022-06-23 06:43:38.505798
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # TODO: Add some tests
    pass

# Generated at 2022-06-23 06:43:49.542362
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    pb = Playbook()
    pb._load_playbook_data(file_name='test_playbook_include.yml', variable_manager=None, loader=None)
    pb_include = pb._entries[0]
    # test if the first PlaybookInclude was correctly loaded
    assert pb_include.import_playbook == 'test_playbook_include_2.yml'
    assert pb_include.vars == {'var1': 'value1', 'var2': 'value2'}
    assert pb_include.tags == ['tag1', 'tag2', 'tag3']
    assert pb_include.when == ['var0 == "value0"']
    # test if the Playbook

# Generated at 2022-06-23 06:43:58.032616
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # import here to avoid a dependency loop
    from ansible.playbook import Playbook

    class TestPlaybookInclude(PlaybookInclude):

        pass

    playbook_file = os.path.join(os.path.dirname(__file__), "data/playbook-include-keyword.yml")
    playbook = Playbook.load(playbook_file)
    playbooks = list(playbook.get_plays())
    assert len(playbooks) == 2
    assert isinstance(playbooks[0], Playbook)
    assert isinstance(playbooks[1], Playbook)
    assert playbooks[0]._entries[0]._included_path == os.path.dirname(playbook_file)

# Generated at 2022-06-23 06:44:00.046622
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    """
    Test initializing object of class PlaybookInclude
    """
    obj = PlaybookInclude()
    assert obj is not None

# Generated at 2022-06-23 06:44:00.621885
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-23 06:44:05.346092
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    pass

# Generated at 2022-06-23 06:44:18.319404
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.inventory import Host, Inventory

    host1 = Host(name="www.example.com")
    host2 = Host(name="www.example2.com")
    host3 = Host(name="otherhost.example.com")

    inventory = Inventory()
    inventory.add_host(host1)
    inventory.add_host(host2)
    inventory.add_host(host3)

    # test play with 'import_playbook' statement and additional parameters

# Generated at 2022-06-23 06:44:28.401166
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os
    import sys
    import types
    import unittest2 as unittest

    test_dir = os.path.dirname(__file__)
    sys.path.append(test_dir)

    from unit.mock.loader import DictDataLoader
    from unit.mock.path import mock_unfrackpath_noop
    from ansible.parsing.dataloader import DataLoader

    mock_loader = DictDataLoader({
        "test_PlaybookInclude_load_data.yaml": "{{ collections_paths }} include_playbook: test_PlaybookInclude_load_data_include.yaml",
        "test_PlaybookInclude_load_data_include.yaml": "{{ collections_paths }} test_PlaybookInclude_load_data_include"
    })