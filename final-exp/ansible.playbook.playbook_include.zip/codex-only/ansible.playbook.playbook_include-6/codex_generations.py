

# Generated at 2022-06-23 06:34:30.233929
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    import_playbook = 'foo.yml'
    tags = 'tag1,tag2'
    vars = {"var1": 1, "var2": 2, "tag3": "tag3"}
    playbook_include = PlaybookInclude()
    assert playbook_include.import_playbook == None
    assert playbook_include.tags == []
    assert playbook_include.vars == {}
    playbook_include = PlaybookInclude(import_playbook, vars, tags)
    assert playbook_include.import_playbook == import_playbook
    assert playbook_include.tags == tags.split(',')
    assert playbook_include.vars == vars

# Generated at 2022-06-23 06:34:41.688131
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    from ansible.playbook.play import Play
    from ansible.parsing.yaml.objects import AnsibleUnicode

    ds = AnsibleMapping()
    ds.ansible_pos = dict(lnum=1)
    ds['import_playbook'] = AnsibleUnicode('/tmp/some_play.yml')
    ds['tags'] = 'some_tag'
    ds2 = AnsibleMapping()
    ds2['vars'] = AnsibleMapping()
    ds2['vars']['some'] = AnsibleUnicode('var')
    ds2['vars']['other'] = AnsibleUnicode('var')
    ds['vars'] = ds2

    pbi = PlaybookInclude()

# Generated at 2022-06-23 06:34:46.351226
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    # Test 1: check if constructor works with all default values
    args = dict(import_playbook='test1.yaml')
    play = PlaybookInclude(**args)
    assert play.import_playbook == 'test1.yaml'
    assert play.vars == dict()

    # Test 2: check if constructor works with all values
    args = dict(import_playbook='test2.yaml', vars=dict(file='test2.txt'))
    play = PlaybookInclude(**args)
    assert play.import_playbook == 'test2.yaml'
    assert play.vars == dict(file='test2.txt')


# Generated at 2022-06-23 06:34:54.742695
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    obj = PlaybookInclude.load({ 'import_playbook': "test/test.yml", 'vars': {'foo': 'baz' }, 'tags': 'bar'})
    assert obj.import_playbook == "test/test.yml"
    assert obj.vars['foo'] == 'baz'
    assert obj.tags == ['bar']

    # test loading a playbook in a collection
    obj = PlaybookInclude.load({ 'import_playbook': "my.collection.playbook_name"})
    assert obj.import_playbook == "my.collection.playbook_name"

# Generated at 2022-06-23 06:34:55.661038
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-23 06:35:06.641282
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # Arrange
    basedir = os.getcwd()
    mock_variable_manager = None
    mock_loader = None
    mock_ds = dict(import_playbook='test.yml',vars=dict(test=True))

    # Act
    ansible_pb_include = PlaybookInclude().load_data(mock_ds, basedir, mock_variable_manager, mock_loader)

    # Assert
    assert 'test.yml' in ansible_pb_include._entries
    assert 'test.yml' in ansible_pb_include._playbook_files
    assert ansible_pb_include._entries['test.yml'].vars['test'] == True
    assert ansible_pb_include._entries['test.yml']._included_path == os.getcwd

# Generated at 2022-06-23 06:35:11.654460
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    result = PlaybookInclude().preprocess_data(dict(include='my_playbook.yml'))
    assert result.pop('include') == 'my_playbook.yml'
    assert result == dict(import_playbook='my_playbook.yml')

    result = PlaybookInclude().preprocess_data(dict(include='my_playbook.yml vars={"var1": "value1", "var2": "value2"}'))
    assert result.pop('include') == 'my_playbook.yml vars={"var1": "value1", "var2": "value2"}'
    assert result == dict(import_playbook='my_playbook.yml', vars=dict(var1='value1', var2='value2'))

# Generated at 2022-06-23 06:35:12.301161
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-23 06:35:13.889784
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # TODO: implement this test
    pass


# Generated at 2022-06-23 06:35:25.215541
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    data = {
        'import_playbook': 'common.yml',
        'roles': {
            'foo': { 'role': 'bar' }
        },
        'tags': ['bar', 'baz'],
        'vars': {
            'foo': 'bar'
        },
        'when': 'foo.bar is defined'
    }
    new_data = PlaybookInclude.load_data(data, '', None)
    assert new_data.tags == ['bar', 'baz']
    assert new_data.vars == { 'foo': 'bar' }
    assert new_data.import_playbook == 'common.yml'
    assert new_data.when == 'foo.bar is defined'
    assert new_data.roles == { 'foo': { 'role': 'bar' } }

# Generated at 2022-06-23 06:35:35.592091
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.template import Templar
    from ansible.playbook.play import Play
    templar = Templar(loader=None, variables={'var1': 1, 'var2': '2'})
    included_playbook = PlaybookInclude()
    data = {'import_playbook': '../../library/hello_world.yaml', 'vars': {'msg': 'Hello_world'}, 'tags': ['TAG1', 'TAG2']}
    included_playbook.load_data(data, '.', templar=templar)
    assert included_playbook.import_playbook == "../../library/hello_world.yaml"
    assert included_playbook.vars == {'msg': 'Hello_world'}
    assert included_playbook.tags == ['TAG1', 'TAG2']

# Generated at 2022-06-23 06:35:48.377228
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    # Load a PlaybookInclude and make sure it is a Playbook
    ds = dict(import_playbook='/path/to/playbook.yml')
    pb = PlaybookInclude.load(ds, '/path')
    assert isinstance(pb, Playbook)

    # Make sure the Playbook is populated
    assert pb._entries

    # Load a PlaybookInclude and make sure it adds the vars to the entries
    ds = dict(import_playbook='/path/to/playbook.yml', vars=dict(foo='bar', test='var'))
    pb = PlaybookInclude

# Generated at 2022-06-23 06:36:01.024752
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.tasks import Task
    from ansible.parsing.yaml.objects import AnsibleSequence
    variable_manager = {'hostvars': {}}
    loader = {}
    basedir = './'

    # Test import of playbook with tags in import_playbook statement
    data1 = dict(
        import_playbook='../roles/my_role/playbook.yml tags=tag1,tag2',
    )
    pbi1 = PlaybookInclude().load_data(data1, basedir, variable_manager, loader)
    assert len(pbi1._entries) == 1
    play1 = pbi1._entries[0]

# Generated at 2022-06-23 06:36:08.419710
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

    class FakePlaybook(object):
        def __init__(self, file_name):
            self.filename =  file_name

    class FakeVariableManager(object):
        def __init__(self):
            self.vars = {}

        def get_vars(self):
            return self.vars


    class FakeLoader(object):
        pass   

    import_params = "${{some_var}} pre_tasks: some_tags: - somesecondtag roles: - some_role: some_tag: - some_tag"

# Generated at 2022-06-23 06:36:15.124874
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    d = dict(
        import_playbook = 'test.yml',
        ansible_pos = '/some/path'
    )

    p = PlaybookInclude()
    result = p.load_data(d, basedir='/some/path')

    assert result.import_playbook == 'test.yml'
    assert result.ansible_pos == '/some/path'



# Generated at 2022-06-23 06:36:22.089954
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    import os
    import tempfile
    import shutil
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    cwd = os.getcwd()
    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-23 06:36:28.608574
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # Test creation of a PlaybookInclude object using two empty dictionaries.
    assert PlaybookInclude.load(dict(), dict())

    # Test creation of a PlaybookInclude object using two empty AnsibleMapping objects.
    assert PlaybookInclude.load(AnsibleMapping(), AnsibleMapping())

# Generated at 2022-06-23 06:36:39.259364
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # Create a dictionary to pass to the constructor via the load method
    test_dict = {'_import_playbook': 'playbook.yml', '_vars': {'var': 'val'}}
    test_PlaybookInclude = PlaybookInclude.load(data=test_dict,
                                                variable_manager={'var': 'mgr'}, loader={})
    # Check the class variables
    assert test_PlaybookInclude._import_playbook == 'playbook.yml'
    assert test_PlaybookInclude._vars == {'var': 'val'}



# Generated at 2022-06-23 06:36:51.035449
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    test_data = {
        'include': 'my-tasks.yml'
    }

    p = PlaybookInclude()
    data = p.preprocess_data(test_data)

    assert 'import_playbook' in data, "Expected to find 'import_playbook' in preprocessed data"
    assert data['import_playbook'] == 'my-tasks.yml'

    test_data = {
        'include': 'my-tasks.yml',
        'vars': {
            'a': 'b'
        }
    }

    data = p.preprocess_data(test_data)
    assert 'import_playbook' in data, "Expected to find 'import_playbook' in preprocessed data"

# Generated at 2022-06-23 06:36:54.196633
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-23 06:37:00.423056
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    data = {'playbook': 'samples/playbook.yml', 'tags': 'tag_one,tag_two'}
    d = PlaybookInclude(**data)
    assert d.import_playbook == 'samples/playbook.yml'
    assert d.tags == ['tag_one', 'tag_two']


# Generated at 2022-06-23 06:37:09.979401
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    import tempfile
    import shutil
    import os
    import os.path
    import imp
    import ansible.constants as C
    import ansible.plugins.loader as plugins
    import ansible.plugins.action as action
    import ansible.module_utils.six.moves.queue as Queue

    module_name = "test_module"
    module_args = "arg1=foo arg2=bar"


# Generated at 2022-06-23 06:37:16.982319
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import ansible.playbook.block as block

    # Test No. 1
    # Check it fails if the data structure is not a dictionary
    # Data structure
    ds = block.Block()
    # Instantiate the PlaybookInclude class
    pi = PlaybookInclude()
    # Assert that it fails with AnsibleAssertionError
    try:
        # Preprocess data
        pi.preprocess_data(ds)
        assert False
    except AnsibleAssertionError:
        assert True

    # Test No. 2
    # Check it runs fine if the data structure is a dictionary
    # Data structure
    ds = {}
    # Instantiate the PlaybookInclude class
    pi = PlaybookInclude()
    # Assert that it fails with AnsibleAssertionError

# Generated at 2022-06-23 06:37:18.629045
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Test case 1
    # TODO
    pass


# Generated at 2022-06-23 06:37:34.918061
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    import tempfile
    import yaml

    display = Display()
    variable_manager = VariableManager()
    variable_manager._options = Options()

    # create a playbook yaml file
    temp_dir = tempfile.mkdtemp()
    playbook_path = tempfile.mktemp(dir=temp_dir)
    pb_yaml = """
    - hosts: all
      tasks:
        - name: Print hello
          debug:
            msg: Hello
    """
    pb_file = open(playbook_path, "w")
    pb_file.write(pb_yaml)
    pb_file.close()

    # create the include yaml file
    include_path = tempfile.mktemp(dir=temp_dir)

# Generated at 2022-06-23 06:37:40.292643
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    import os
    import tempfile
    from ansible.playbook.playbook import Playbook
    from ansible.constants import DEFAULT_COLLECTIONS_PATH

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()
    os.environ['ANSIBLE_COLLECTIONS_PATHS'] = os.pathsep.join((tmpdir, DEFAULT_COLLECTIONS_PATH))
    collection_dirname = os.path.join(tmpdir, 'my_namespace-my_collection')
    os.mkdir(collection_dirname)
    tasks_dirname = os.path.join(collection_dirname, 'tasks')
    os.mkdir(tasks_dirname)
    playbooks_dirname = os.path.join(collection_dirname, 'playbooks')

# Generated at 2022-06-23 06:37:41.304259
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    pass

# Generated at 2022-06-23 06:37:52.845377
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # import here to avoid a dependency loop
    from ansible.parsing.yaml.loader import AnsibleLoader


# Generated at 2022-06-23 06:38:04.480477
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    pi = PlaybookInclude()
    # Valid playbook import statement
    ds = AnsibleMapping()
    ds['import_playbook'] = "./test-playbook.yml"
    ds['vars'] = {'foo': 'bar'}
    ds['tags'] = 'test'
    ds['when'] = 'false'
    pi.preprocess_data(ds)
    assert(pi.import_playbook == './test-playbook.yml')
    assert(pi.vars == {'foo': 'bar'})
    assert(pi.tags == ['test'])
    assert(pi.when == 'false')
    # Invalid playbook import statement (missing import_playbook).
    ds = AnsibleMapping

# Generated at 2022-06-23 06:38:18.235729
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    from tempfile import mkdtemp
    from shutil import rmtree

    from ansible.config import Config

    config = Config()
    config.set_config_value('DEFAULT_ROLES_PATH', None)
    config.set_config_value('DEFAULT_ROLES_PATH', None)


# Generated at 2022-06-23 06:38:31.094579
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # checking if the constructor works in normal cases
    data = dict(import_playbook="/abcdef")
    obj = PlaybookInclude()
    play = obj.load(data=data, basedir="")
    assert play is not None
    assert type(play).__name__ == "Playbook"
    assert play.basedir == "/"
    assert play.filename == "/abcdef"

    data = dict(import_playbook="/abcdef",vars={"var":"value"})
    obj = PlaybookInclude()
    play = obj.load(data=data, basedir="")
    assert play is not None
    assert type(play).__name__ == "Playbook"
    assert play.basedir == "/"
    assert play.filename == "/abcdef"


# Generated at 2022-06-23 06:38:40.375570
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    '''
    This is a unit test for the method load in class PlaybookInclude.

    The method is called with parameters basedir, variable_manager and loader.
    loader is set to None here.

    :return:
    '''

    from .test_context import TestContext
    from .test_data import TestData


# Generated at 2022-06-23 06:38:48.562644
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task.include import TaskInclude

    # Check that 'import_playbook' works with filename only
    data1 = dict(type="import_playbook", import_playbook="foo.yml")

    obj1 = PlaybookInclude.load(data1, "/tmp/")
    assert isinstance(obj1, Playbook)
    assert len(obj1._entries) == 1
    assert isinstance(obj1._entries[0], Play)
    assert obj1._entries[0].name == "foo.yml"
    assert obj1._entries[0]._included_path == "/tmp/"

    # Check that

# Generated at 2022-06-23 06:38:59.849125
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # check without parameter
    try:
        PlaybookInclude()
    except TypeError as e:
        assert "missing 1 required positional argument" in str(e)

    try:
        PlaybookInclude(ds=None, basedir=None)
    except AnsibleAssertionError as e:
        assert "should be a dict but was a" in str(e)

    # check with parameter
    pbi = PlaybookInclude(ds={}, basedir='')
    assert isinstance(pbi, PlaybookInclude)
    assert pbi._import_playbook is None
    assert pbi._vars == {}


# Generated at 2022-06-23 06:39:01.363293
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pb = PlaybookInclude.load({})

# Generated at 2022-06-23 06:39:10.971830
# Unit test for method load_data of class PlaybookInclude

# Generated at 2022-06-23 06:39:12.994124
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # Test simple creation of object with no data
    p = PlaybookInclude()
    assert p is not None


# Generated at 2022-06-23 06:39:13.660547
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-23 06:39:14.705173
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass


# Generated at 2022-06-23 06:39:28.157885
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    obj = PlaybookInclude()

    ds = {
        'import_playbook': 'foo',
        'vars': {'a': 'b'}
    }
    assert obj.preprocess_data(ds) == {
        'import_playbook': 'foo',
        'vars': {'a': 'b'}
    }

    ds = {
        'import_playbook': 'foo',
        'a': 'b'
    }
    assert obj.preprocess_data(ds) == {
        'import_playbook': 'foo',
        'vars': {'a': 'b'}
    }

    ds = {
        'import_playbook': 'foo bar',
        'vars': {'a': 'b'}
    }

# Generated at 2022-06-23 06:39:33.613337
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
   playbook_include = PlaybookInclude.load(
       dict(import_playbook='other.yml'),
       '/path/to/dir/',
       variable_manager=None,
       loader=None)
   assert playbook_include.import_playbook == 'other.yml'


# Generated at 2022-06-23 06:39:44.706695
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # Test when ansible_pos is present in data
    # ansible_pos should be set for the object

    data = {
        'import_playbook': 'a.yml'
    }
    basedir = '/root'

    class AnsibleCollectionConfig(object):
        playbook_paths = []
        default_collection = None

    class AnsibleLoader(object):
        pass

    class AnsibleVariableManager(object):
        pass

    class Playbook(object):
        _entries = [
            PlaybookInclude()
        ]

    loader = AnsibleLoader()
    variable_manager = AnsibleVariableManager()

    Playbook.load = PlaybookInclude.load
    PlaybookInclude.load_data = PlaybookInclude.load_data
    PlaybookInclude.preprocess_data = PlaybookInclude.pre

# Generated at 2022-06-23 06:39:56.236381
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    import pytest
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars import VariableManager

    v = VariableManager()
    v.extra_vars = dict(foo='foo_value')
    v.options_vars = dict(host_specific='host_specific')
    templar = Templar(loader=DataLoader(), variables=v)

    # empty playbook
    pib = PlaybookInclude.load(data=dict(), basedir='/nonexistent', variable_manager=v, loader=DataLoader())

    # empty playbook
    pib = PlaybookInclude.load(data={}, basedir='/nonexistent', variable_manager=v, loader=DataLoader())

    # setting tags

# Generated at 2022-06-23 06:40:06.989109
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import ansible.parsing.yaml.objects

    # Create an instance of PlaybookInclude from the class definition
    PlaybookInclude_instance = PlaybookInclude()

    # Create a ds that would be the same as 'import_playbook: /path/to/file.yml'
    ds = {'import_playbook': "/path/to/file.yml"}
    ds = ansible.parsing.yaml.objects.AnsibleMapping(ds)
    ds['import_playbook'] = ansible.parsing.yaml.objects.AnsibleUnicode(ds['import_playbook'])

    # Call the preprocess_data method to check that the result is what we expect
    result = PlaybookInclude_instance.preprocess_data(ds)
    assert result == d

# Generated at 2022-06-23 06:40:14.804976
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.playbook_include import PlaybookInclude
    import ansible.playbook.play_context

    p = PlaybookInclude()
    pc = ansible.playbook.play_context.PlayContext()

    # call load function with pc and ds
    # load function returns 'ansible.playbook.play.Play' instance.
    assert isinstance(p.load(ds={}, basedir='/', variable_manager=pc.variable_manager, loader=pc.loader), PlaybookInclude)

    # call load_data function with basedir and pc
    # returns 'ansible.playbook.playbook.Playbook' instance.
    assert isinstance(p.load_data({}, basedir='/', variable_manager=pc.variable_manager, loader=pc.loader), PlaybookInclude)

# Generated at 2022-06-23 06:40:30.848166
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    basedir = '/path/to/playbook'
    ds = {'playbook': 'playbook.yml'}
    variable_manager = {}
    loader = None
    obj = PlaybookInclude.load(data=ds, basedir=basedir, variable_manager=variable_manager, loader=loader)
    expected = Playbook(loader=loader)
    expected._load_playbook_data(file_name='/path/to/playbook/playbook.yml', variable_manager=variable_manager, vars={})
    assert obj._entries == expected._entries
    assert obj._parsed_vars == expected._parsed_vars
    assert obj._loader == loader
    assert obj._file_name == '/path/to/playbook/playbook.yml'


# Generated at 2022-06-23 06:40:44.180394
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    import json
    import yaml

    # basic
    pbi = PlaybookInclude.load(dict(
        import_playbook='test.yml',
    ), variable_manager=None, loader=None)
    assert pbi.import_playbook == 'test.yml'

    # yaml
    yaml_str = """
    - import_playbook: test.yml
    """
    pbi = PlaybookInclude.load(yaml.safe_load(yaml_str), variable_manager=None, loader=None)
    assert pbi.import_playbook == 'test.yml'

    # json
    json_str = """
    [
        {
            "import_playbook": "test.yml"
        }
    ]
    """

# Generated at 2022-06-23 06:40:51.374378
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    # Valid playbook includes
    # no options
    test_pb = PlaybookInclude.load('../main.yml', './', None, None)
    assert isinstance(test_pb, Playbook)
    assert len(test_pb._entries) == 2
    assert isinstance(test_pb._entries[0], Play)
    assert test_pb._entries[0].playbook == 'main.yml'
    assert test_pb._entries[0].play_hosts == 'web'
    assert isinstance(test_pb._entries[1], Play)
    assert test_pb._entries[1].playbook == 'main.yml'

# Generated at 2022-06-23 06:41:00.026769
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    ##############################################################################################
    # test_PlaybookInclude_preprocess_data: All of keys of original dictionary should be included
    ##############################################################################################
    # Params
    ds = {'import_playbook': '../first.yml',
          'vars': {'one': 'value'},
          'tags': 'first, last'}

    obj = PlaybookInclude()
    new_ds = obj.preprocess_data(ds)

    assert new_ds == ds

    ##############################################################################################################################
    # test_PlaybookInclude_preprocess_data: when no import_playbook, raise AnsibleParserError with message "playbook import parameter is missing"
    ##############################################################################################################################
    # Params
    ds = {}

    obj = PlaybookInclude

# Generated at 2022-06-23 06:41:12.135948
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.vars.unsafe_proxy import UnsafeProxy

    ds = {}
    ds["import_playbook"] = "../test/test1.yml"
    ds["vars"] = {}
    ds["vars"]["test_var1"] = "test1"
    ds["vars"]["test_var2"] = "test2"
    ds["tags"] = "test_tag"

    pi = PlaybookInclude().load_data(ds, "../test", None, None)
    print(repr(pi))
    assert pi is not None
    assert isinstance(pi, Playbook)
    assert len(pi._entries) > 0
    assert isinstance(pi._entries[0], PlaybookInclude)
   

# Generated at 2022-06-23 06:41:25.122441
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    import tempfile
    import os
    import sys
    import ansible.utils.collection_loader
    from ansible.cli import CLI
    from ansible.utils.display import Display
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.collection_loader._collection_finder import _get_collection_name_from_path
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.parsing.yaml.dumper import AnsibleDumper

    display = Display()
    try:
        cli = CLI(None, display=display)
    except TypeError:
        cli = CLI(display=display)

    # create temp file to write playbook to
    (fd, tpath) = tempfile.mkstemp()
    os.close(fd)


# Generated at 2022-06-23 06:41:31.152527
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    p = PlaybookInclude.load(dict(import_playbook='x'), DataLoader(), VariableManager())
    assert p.import_playbook == 'x'

# Generated at 2022-06-23 06:41:43.559392
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include = PlaybookInclude()

    # Case 1: Test playbook_include with import_playbook and tags
    playbook_include_input = {'import_playbook': 'playbook.yml', 'tags': ['provision']}
    playbook_include_expected = {'import_playbook': 'playbook.yml', 'tags': 'provision'}
    playbook_include_result = playbook_include.preprocess_data(data=playbook_include_input)
    assert playbook_include_expected == playbook_include_result, "Failed to preprocess data with import_playbook and tags"

    # Case 2: Test playbook_include with import_playbook, tags and vars

# Generated at 2022-06-23 06:41:56.030919
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    import_playbook_data = """
  - import_playbook: test.yml
  """


# Generated at 2022-06-23 06:41:56.719819
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-23 06:41:57.764183
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-23 06:42:10.036066
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    PlaybookInclude.load({"import_playbook": "../../files/test-import-playbook.yml"}, basedir="test/unit/resources/test-include-data")
    a = PlaybookInclude.load({"import_playbook": "test/unit/resources/test-import-playbook2.yml"}, basedir="test/unit/resources/test-include-data")
    b = a.load_data(ds={}, basedir="test/unit/resources/test-include-data", variable_manager=None, loader=None)
    assert isinstance(b, Playbook)
    assert len(b._entries) == 2
    assert b._entries[0].name == "a.yml"

# Generated at 2022-06-23 06:42:21.937022
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Case 1: Assemble a proper PlaybookInclude object
    ds = {'import_playbook': 'test.yml', 'vars': {'foo': 1}}
    pb = PlaybookInclude().preprocess_data(ds)
    assert pb['import_playbook'] == 'test.yml'
    assert pb['vars'] == {'foo': 1}

    # Case 2: Assemble a proper PlaybookInclude object with additional parameters
    ds = {'include': 'test.yml foo=bar'}
    pb = PlaybookInclude().preprocess_data(ds)
    assert pb['import_playbook'] == 'test.yml'
    assert pb['vars'] == {'foo': 'bar'}

    # Case 3: Mixing additional parameters with key-value vars

# Generated at 2022-06-23 06:42:34.476186
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import sys
    import yaml

    from ansible.module_utils.six import PY3
    from ansible.parsing.yaml.objects import AnsibleMapping
    if PY3:
        from io import StringIO
    else:
        from io import BytesIO as StringIO

    def do_test(input_data, expected_output):
        import_playbook = PlaybookInclude()
        ds = yaml.load(StringIO(input_data))

        output = import_playbook.preprocess_data(ds)
        assert output == expected_output

    def do_test_error(input_data, exception):
        import_playbook = PlaybookInclude()
        ds = yaml.load(StringIO(input_data))

        caught = False

# Generated at 2022-06-23 06:42:35.576736
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass



# Generated at 2022-06-23 06:42:43.303485
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():

    # minimal load test, just verifies what was loaded is what was dumped
    assert PlaybookInclude.load(dict(import_playbook='/tmp/mytest/test.yml')) == dict(import_playbook='/tmp/mytest/test.yml')
    assert PlaybookInclude.load(dict(import_playbook='/tmp/mytest/test.yml', vars=dict(myvar='myvalue'))) == dict(import_playbook='/tmp/mytest/test.yml', vars=dict(myvar='myvalue'))

# Generated at 2022-06-23 06:42:54.723116
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # in case a test crashes, you know what file and test has issues
    print('+++ test_PlaybookInclude_load')

    # prepare a fake loader
    myLoader = dict()
    myLoader['_basedir'] = './test_dir/'

    # prepare a fake variable manager
    myVarManager = dict()
    myVarManager['_extra_vars'] = dict()
    myVarManager['_hostvars'] = dict()

    obj = PlaybookInclude.load('../test_hosts', basedir='./test_dir/', loader=myLoader, variable_manager=myVarManager)

# Generated at 2022-06-23 06:42:57.189907
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    playbook_include_object = PlaybookInclude()
    assert playbook_include_object.vars == dict()
    assert playbook_include_object.import_playbook is None

# Generated at 2022-06-23 06:43:08.533614
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    from ansible.parsing.yaml.objects import AnsibleSequence

    # pylint: disable=too-few-public-methods

    class PlaybookIncludeTest(PlaybookInclude):
        def __init__(self, data, variable_manager=None, loader=None):
            self.variable_manager = variable_manager
            self.loader = loader

            super(PlaybookIncludeTest, self).load_data(ds=data, variable_manager=variable_manager, loader=loader)

    # Run preprocess_data() without variable_manager
    ds = {
        'import_playbook': 'foo.yml'
    }

    pb = PlaybookIncludeTest(ds)
    result = pb.preprocess_data(ds)

# Generated at 2022-06-23 06:43:20.884790
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():

    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    basedir = os.path.abspath(os.path.dirname(__file__))
    data = dict(import_playbook=u'test_import_playbook.yml', tags=u'tag_one,tag_two')
    playbook = PlaybookInclude.load(data, basedir)
    assert isinstance(playbook, Playbook)
    assert len(playbook._entries) == 1
    play = playbook._entries[0]
    assert isinstance(play, Play)
    assert len(play.tasks) == 1
    assert play.tasks[0]["action"]["module"] == "debug"
    assert play.tasks[0]["action"]["msg"] == "Hello World!"


# Generated at 2022-06-23 06:43:28.702204
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    # Case1: format the variable declaration wrong
    pb = PlaybookInclude()
    try:
        import_data = dict(a=1, b=2)
        pb.load_data(import_data, "")
        raise Exception("Test play1 fail!")
    except AnsibleParserError:
        pass

    # Case2: when we try to define vars in extra param, it conflicts with 'vars' in playbook
    pb = PlaybookInclude()
    try:
        import_data = dict(import_playbook="a.yml", vars={"a":1}, b=2)
        pb.load_data(import_data, "")
        raise Exception("Test play2 fail!")
    except AnsibleParserError:
        pass

    # Case3: when we put extra params inside vars,

# Generated at 2022-06-23 06:43:30.074614
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-23 06:43:37.812567
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    variable_manager = VariableManager()
    variable_manager.set_variable('ansible_python_interpreter', 'python3')

    basedir = '/home/vagrant/ansible'
    ds={
        'include_playbook': './other.yml',
        'vars': {
            'var1': 'value1'
        },
        'tags': 'tag_1,tag_2'
    }
    r = PlaybookInclude.load(data=ds, basedir=basedir, variable_manager=variable_manager)
    assert(type(r) is Playbook)

# Generated at 2022-06-23 06:43:49.099639
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import ansible.playbook.playbook_include as pbi
    import ansible.playbook.play as play
    ds = AnsibleMapping() 
    ds = {'import_playbook' : 'test_imports/import_playbook_test.yml', 'var1': 'value_var1', 'var2': 'value_var2'}
    new_ds = pbi.PlaybookInclude().preprocess_data(ds)
    assert isinstance(new_ds, AnsibleMapping)
    assert new_ds['import_playbook'] == 'test_imports/import_playbook_test.yml'
    assert new_ds['vars']['var1'] == 'value_var1'
    assert new_ds['vars']['var2'] == 'value_var2'

# Generated at 2022-06-23 06:43:59.469696
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # create data structure
    ds = dict(
        import_playbook = 'playbook.yml',
        vars = dict(
            foo = 'bar'
        ),
        tags = ['first', 'second']
    )

    # instantiate object
    new_pi = PlaybookInclude(ds)

    # validate object attributes
    assert hasattr(new_pi, 'import_playbook')
    assert hasattr(new_pi, 'vars')
    assert hasattr(new_pi, 'tags')
    assert not hasattr(new_pi, 'other')

    # validate attribute values
    assert new_pi.import_playbook == 'playbook.yml'
    assert new_pi.vars == dict(foo='bar')
    assert new_pi.tags == ['first', 'second']

# Unit test

# Generated at 2022-06-23 06:44:11.880468
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    import ansible.playbook.play as play

    data = dict(
        import_playbook='playbook_name'
    )
    playbook = PlaybookInclude().load_data(data, basedir='/playbooks')
    for play in playbook._entries:
        assert isinstance(play, Play)

    assert playbook._included_path == '/playbooks'

    # check with variable_manager
    variable_manager = MockVariableManager({'test':'variables'})
    playbook = PlaybookInclude().load_data(data, basedir='/playbooks', variable_manager=variable_manager)
    for play in playbook._entries:
        assert isinstance(play, Play)
        assert play.vars['test'] == 'variables'

    assert playbook._included_path

# Generated at 2022-06-23 06:44:21.813922
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    playbook = "\n".join(
        ["- import_playbook: tasks/main.yml", ])

    from ansible.parsing.yaml.objects import AnsibleMapping

    ds, ds_copy = yaml_load(playbook)
    ds = ds.get_single_data()
    ds_copy = ds_copy.get_single_data()

    pbi = PlaybookInclude.load(ds, '.')

    import json
    assert json.dumps(pbi.dump(), indent=4) == json.dumps(ds_copy, indent=4)