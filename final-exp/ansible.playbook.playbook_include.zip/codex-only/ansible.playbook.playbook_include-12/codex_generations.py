

# Generated at 2022-06-23 06:34:31.843207
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # Test 1
    ds = dict(include="example.yml")
    new_ds = dict(import_playbook="example.yml")
    print(ds)
    print(new_ds)
    assert PlaybookInclude.preprocess_data(ds) == new_ds

    # Test 2
    ds = dict(include="example.yml tags=tag_value")
    new_ds = dict(import_playbook="example.yml", tags="tag_value")
    print(ds)
    print(new_ds)
    assert PlaybookInclude.preprocess_data(ds) == new_ds

    # Test 3
    ds = dict(import_playbook="example.yml tags=tag_value")

# Generated at 2022-06-23 06:34:43.455064
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    '''
    Test of method preprocess_data of class PlaybookInclude.
    '''

    # test the basics
    yaml_obj = {"import_playbook": "my-playbook.yml"}
    playbook_include = PlaybookInclude.load(yaml_obj, "")
    new_ds = playbook_include.preprocess_data(yaml_obj)
    assert new_ds["import_playbook"] == "my-playbook.yml"
    assert len(new_ds) == 1

    # test extra parameters
    yaml_obj = {"import_playbook": "my-playbook.yml var1=simple"}
    playbook_include = PlaybookInclude.load(yaml_obj, "")
    new_ds = playbook_include.preprocess_data(yaml_obj)

# Generated at 2022-06-23 06:34:54.824610
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    args = dict(
        import_playbook=['/tmp/test.yaml'],
        vars=dict(
            foo=dict(
                bar=['baz1', 'baz2']
            )
        )
    )
    pbi = PlaybookInclude(**args)
    ds = dict()
    ds['import_playbook'] = 'test.yaml'
    ds['vars'] = dict(
        bing=['bang']
    )
    pb = pbi.load(ds, '/tmp')
    assert pb.basedir == '/tmp/test.yaml'
    assert pb.vars == dict(
        bing=['bang'],
        foo=dict(
            bar=['baz1', 'baz2']
        )
    )
    assert len

# Generated at 2022-06-23 06:35:04.615295
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    context = PlayContext()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    PlaybookInclude.load(data={u'import_playbook': 'test0.yml'}, basedir=os.getcwd(), variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-23 06:35:12.990321
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    class TestPlaybookInclude(PlaybookInclude):

        def __init__(self):
            self._attrs['import_playbook'] = 'test.yml'

    class TestPlaybook():

        def __init__(self):
            self._attrs = dict()
            self._attrs['_entries'] = list()
            self._attrs['_playbook_files'] = list()

        def paths(self):
            return list()

        def set_variable_manager(self, variable_manager):
            self._attrs['variable_manager'] = variable_manager

        def set_loader(self, loader):
            self._attrs['loader'] = loader

        def add_entry(self, entry):
            self._entries.append(entry)

        def add_playbook(self, playbook):
            self._play

# Generated at 2022-06-23 06:35:14.998456
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # Create PlaybookInclude object
    print('Create PlaybookInclude object')
    PlaybookInclude()

# Generated at 2022-06-23 06:35:26.109132
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():

    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = None

    # load 
    load = PlaybookInclude.load({"import_playbook": "../../../include_playbook.yml"}, variable_manager=variable_manager, basedir='/etc/ansible/playbooks/test_playbook.yml', loader=loader)
    assert(load.import_playbook == "../../../include_playbook.yml")
    assert(load.vars == {})

    # load_data
    # TODO: fix this to test a real include statement
    # load_data = load.load_data(ds={"import_playbook": "../../../include_playbook.yml"}, basedir='/etc/ansible/playbooks/test_playbook

# Generated at 2022-06-23 06:35:33.194725
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    basedir = '/tmp'
    ds = {'import_playbook': '../test.yml', 'vars': {'foo': 'bar'}}
    # Call method to test
    pb_include = PlaybookInclude.load(ds, basedir, loader=loader)
    # Check result
    assert pb_include is not None
    assert pb_include._entries is not None

# Generated at 2022-06-23 06:35:42.244868
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    from ansible.playbook.play import Play

    obj = PlaybookInclude()

    # Ensure import_playbook is an attribute
    assert obj.import_playbook == None
    # Ensure vars is an attribute
    assert obj.vars == dict()
    # Ensure import_playbook is a FieldAttribute
    assert isinstance(obj.import_playbook, FieldAttribute)
    # Ensure vars is a FieldAttribute
    assert isinstance(obj.vars, FieldAttribute)

    # Test the load() method
    obj = PlaybookInclude.load({'import_playbook': 'test',
                                'vars': {'name': 'test'},
                                'tags': 'test'}, 'test')

    # Ensure load() returns a PlaybookInclude object and import_playbook, vars and tags are set correctly

# Generated at 2022-06-23 06:35:44.741443
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    args = ""
    pbinclude = PlaybookInclude.load(args, '/path/to/file/')
    assert pbinclude

# Generated at 2022-06-23 06:35:53.591275
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play_context import PlayContext

    import ansible.playbook
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.block

    # Set up a PlayContext()
    src = "/home/centos/playbooks/tasks/main.yml"
    variable_manager = ansible.playbook.VariableManager()
    loader = ansible.playbook.get_loader(variable_manager, src)
    play_context = PlayContext() # FIXME: what is this?

    # Construct the data we want to test
    # a dict of the form:
    # {
    #   'import_playbook':  "import_playbook.yml",
    #   'vars': {
    #     'param1': 'value1'


# Generated at 2022-06-23 06:36:04.729909
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    """Test preprocess_data of class PlaybookInclude"""


# Generated at 2022-06-23 06:36:16.911258
# Unit test for method preprocess_data of class PlaybookInclude

# Generated at 2022-06-23 06:36:22.929359
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    from ansible.playbook.playbook_include import PlaybookInclude

    import_playbook = PlaybookInclude()
    assert import_playbook is not None, "PlaybookInclude was not created"

    # import_playbook.import_playbook = b'PlaybookInclude.yml'
    # import_playbook.tags = 'Playbook_Include_Tags'
    # import_playbook.vars = {}
    # import_playbook.vars[b'var1'] = b'val1'
    # import_playbook.vars[b'var2'] = b'val2'
    # import_playbook.when = b'when'
    #
    # data = {'import_playbook': b'PlaybookInclude.yml', 'tags': 'Playbook_Include_Tags', '

# Generated at 2022-06-23 06:36:23.596372
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    playbook_include = PlaybookInclude()
    assert playbook_include.vars == {}

# Generated at 2022-06-23 06:36:33.541267
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.playbook_include import PlaybookInclude

    pb = PlaybookInclude.load(dict(import_playbook='../playbook.yml', tags=['tag1', 'tag2'], vars={'user': 'root'}), './')

    assert(isinstance(pb, Playbook))
    assert(len(pb._entries) == 1)
    assert(isinstance(pb._entries[0], Play))
    assert(pb._entries[0].name == 'first play')
    assert(pb._entries[0].tags == ['tag1', 'tag2'])
    assert(pb._entries[0].vars == {'user': 'root'})

   

# Generated at 2022-06-23 06:36:43.261527
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.parsing.yaml.loader import AnsibleLoader

    variables = dict()

    loader = AnsibleLoader(None)
    data = loader.load("""
    - import_playbook: test1.yml
    - import_playbook: test2.yml
    """)

    playbook_include = PlaybookInclude.load(data=data, loader=loader)
    assert playbook_include.import_playbook == 'test1.yml'
    assert playbook_include.vars == dict()

    playbook_include = PlaybookInclude.load(data=data, loader=loader)
    assert playbook_include.import_playbook == 'test2.yml'
    assert playbook_include.vars == dict()



# Generated at 2022-06-23 06:36:48.116639
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    # Test import_playbook with no additional parameters
    data = "{% include_playbook 'hello.yml' %}"
    results = PlaybookInclude.load(data=data, basedir='/tmp/', variable_manager=None, loader=None)
    assert results._entries

# Generated at 2022-06-23 06:36:53.298709
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.base import Base

    p = PlaybookInclude()
    assert isinstance(p.load(dict()), Base)

    p = PlaybookInclude()
    assert isinstance(p.load(dict(import_playbook='a.yml')), Play)


# Generated at 2022-06-23 06:37:06.333505
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import yaml
    from ansible.playbook.play_context import PlayContext

    # test_PlaybookInclude_preprocess_data_1 => import_playbook
    yaml_text = '''
        - import_playbook: test.yaml
    '''
    ds = yaml.load(yaml_text)
    obj = PlaybookInclude()
    obj.load_data(ds, [])
    entry = obj.preprocess_data(obj._ds)
    assert entry['import_playbook'] == 'test.yaml'

    # test_PlaybookInclude_preprocess_data_2 => import_playbook: <path>
    yaml_text = '''
        - import_playbook: "path/test.yaml"
    '''

# Generated at 2022-06-23 06:37:19.672946
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import yaml
    yaml_data = '''
    - include: playbook1.yml
    '''

    p = yaml.load(yaml_data)
    for i in p:
        if i.get('include'):
            i = PlaybookInclude.load(i, '/tmp')
            assert i.import_playbook == 'playbook1.yml'
            assert i.vars == {}
            assert i.tags == []

    yaml_data = '''
    - include: playbook1.yml vars:
        key1: 1
    '''

    p = yaml.load(yaml_data)
    for i in p:
        if i.get('include'):
            i = PlaybookInclude.load(i, '/tmp')

# Generated at 2022-06-23 06:37:35.477491
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Use a temporary environment value
    os.environ['ANSIBLE_COLLECTIONS_PATHS'] = 'tests/unit/parsing/yaml/fixtures/collections'

    # Test case 1:
    # Test loading an import file with parameters.
    #   no tags,
    #   parameters are in a dictionary
    ds = {'import_playbook': 'import_playbook_test.yml somevar=this othervar="that"'}
    basedir = 'tests/unit/parsing/yaml/fixtures/import_playbook'
    (pb, new_ds, entries, variable_manager, loader) = _test_load_data(ds, basedir)

    if len(entries) != 3:
        raise AssertionError('Loading import file with parameters: number of entries should be 3')

   

# Generated at 2022-06-23 06:37:40.547058
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import os
    import random
    import shutil
    import tempfile

    from ansible.module_utils._text import to_bytes
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader

    from ansible.playbook.playbook_include import PlaybookInclude

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary playbooks
    playbook1 = os.path.join(tmpdir, 'playbook1.yml')
    f = open(playbook1, 'wt')

# Generated at 2022-06-23 06:37:43.421241
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    p = PlaybookInclude()
    assert p is not None

# Generated at 2022-06-23 06:37:47.253093
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    test_data = {'import_playbook': 'file1',
                 'vars': {'var1': 'val1'},
                 'another_var': 'another_val'}

    clean_test_data = {'import_playbook': 'file1',
                       'vars': {'var1': 'val1', 'var2': 'val2'}}

    test_obj = PlaybookInclude()

    assert test_obj.preprocess_data(test_data) == clean_test_data


# Generated at 2022-06-23 06:38:00.677786
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # Test case with dictionary data
    data = {'import_playbook': 'test_import.yml', 'vars': { 'test_param': 'test_val'}}
    pbi = PlaybookInclude(data)
    assert pbi.import_playbook == 'test_import.yml'
    assert pbi.vars['test_param'] == 'test_val'
    # Test case with AnsibleMapping data
    data = AnsibleMapping()
    data['import_playbook'] = 'test_import.yml'
    data['vars'] = {'test_param': 'test_val'}
    pbi = PlaybookInclude(data)
    assert pbi.import_playbook == 'test_import.yml'

# Generated at 2022-06-23 06:38:10.594648
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # instantiate a PlaybookInclude object
    playbook_include_obj = PlaybookInclude.load(data=dict(import_playbook="/path/to/import/playbook", tags=["tag1", "tag2"], vars={"foo": "bar"}), basedir="/path/to/basedir")

    # call the load_data method of the object
    # check if the method raise exception of type 'ValueError'
    try:
        playbook_include_obj.load_data(ds="data", basedir="basedir")
    except ValueError:
        pass
    except:
        assert False

    # call the load_data method of the object
    # check if the method raise exception of type 'ValueError'

# Generated at 2022-06-23 06:38:11.718428
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass


# Generated at 2022-06-23 06:38:12.639342
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-23 06:38:21.767950
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play
    playground = PlaybookInclude()
    ds = {'import_playbook': 'playbook1.yml'}
    new_ds = AnsibleMapping()
    new_ds['import_playbook'] = 'playbook1.yml'
    assert new_ds == playground.preprocess_data(ds)
    ds = {'import_playbook': 'playbook2.yml', 'tags': 'all'}
    new_ds = AnsibleMapping()
    new_ds['import_playbook'] = 'playbook2.yml'
    new_ds['tags'] = 'all'
    assert new_ds == playground.preprocess_data(ds)

# Generated at 2022-06-23 06:38:33.164181
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include = PlaybookInclude()

    # Testing simple import_playbook with string
    ds = AnsibleBaseYAMLObject({'import_playbook': 'common.yml'})
    expected_result = AnsibleMapping(import_playbook='common.yml')
    result = playbook_include.preprocess_data(ds)
    assert result == expected_result

    # Testing import_playbook with a list
    ds = AnsibleBaseYAMLObject({'import_playbook': ['common.yml']})
    expected_result = AnsibleMapping(import_playbook='[common.yml]')
    result = playbook_include.preprocess_data(ds)
    assert result == expected_result

    # Testing import_playbook with a list and params
    ds = AnsibleBaseYAMLObject

# Generated at 2022-06-23 06:38:43.025044
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.objects import AnsibleMapping

    playbook_include = PlaybookInclude()

    py_filename = "/path/to/file"
    playbook_include.import_playbook = py_filename
    playbook_include.vars = AnsibleMapping()
    playbook_include.vars["var1"] = "value1"
    playbook_include.vars['var2'] = "value2"

    playbook_include._ds = playbook_include.preprocess_data(playbook_include._ds)
    playbook = playbook_include.load_data(playbook_include._ds, "/path")

    assert playbook._entries
    assert len(playbook._entries) == 1
    assert playbook._entries[0].name == py_filename
   

# Generated at 2022-06-23 06:38:47.138403
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    '''
    Validate PlaybookInclude for proper constructor signature.
    '''
    p = PlaybookInclude(loader=None, variable_manager=None)
    assert p.vars == {}

# Generated at 2022-06-23 06:38:48.185858
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-23 06:38:49.315605
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-23 06:38:56.392503
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    test_data = dict()
    test_data['import_playbook'] = "../playbooks/common.yml"
    import_playbook_obj = PlaybookInclude()
    new_ds = import_playbook_obj.preprocess_data(test_data)
    assert new_ds['import_playbook'] == "../playbooks/common.yml"


# Generated at 2022-06-23 06:38:58.906016
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    playbook_include = PlaybookInclude()
    assert playbook_include.vars == {}


# Generated at 2022-06-23 06:39:03.832808
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task.import_role import TaskImportRole
    from ansible.playbook.handler.include import HandlerInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task.include_tasks import TaskIncludeTasks
    from ansible.playbook.task_include.strategy_add import TaskIncludeStrategyAdd
    from ansible.playbook.task_include.strategy_linear import TaskIncludeStrategyLinear
    from ansible.playbook.task_include.strategy_merge import TaskIncludeStrategyMerge

# Generated at 2022-06-23 06:39:04.475210
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    pass

# Generated at 2022-06-23 06:39:16.547284
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.plugins import vars as vars_loader
    import ansible.constants as C
    import os
    import tempfile

    check_files = []
    check_files_names = []
    check_files_names.append(u'include_resource.yml')
    check_files_names.append(u'include_resource.yml')
    check_files.append(u'---\n#include: include_resource.yml\n- ping:')
    check_files.append(u'---\n#include: include_resource.yml\n- ping:')
    for i, f in enumerate(check_files_names):
        with open(f, u'w') as fp:
            fp

# Generated at 2022-06-23 06:39:26.264895
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    yaml_data = """
    - import_playbook: test.yml
    """
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.errors import AnsibleParserError
    loader = AnsibleLoader(yaml_data, file_name='<string>')
    playbook_include = PlaybookInclude.load(ds=loader.get_single_data(), basedir='/tmp/')
    assert playbook_include._import_playbook == 'test.yml'

# Generated at 2022-06-23 06:39:27.733785
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    #TODO
    pass


# Generated at 2022-06-23 06:39:37.943471
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    import sys
    import __builtin__
    if sys.version_info < (2, 7):
        built_in_module = __builtin__
    else:
        import builtins as built_in_module

    try:
        from unittest import mock
    except ImportError:
        import mock

    PlaybookInclude.preprocess_data(built_in_module.dict())

    with mock.patch("ansible.playbook.PlaybookInclude.preprocess_data") as mock_preprocess_data:
        PlaybookInclude.preprocess_data(built_in_module.dict())
        assert mock_preprocess_data.called

# Generated at 2022-06-23 06:39:46.637330
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    '''
    Unit test for method preprocess_data of class PlaybookInclude
    '''
    import pytest

    # Verify that no exception is raised when ds is a dictionary
    try:
        ds = {}
        PlaybookInclude.preprocess_data(ds)
    except Exception as e:
        pytest.fail('Unexpected exception raised: %s' % e)

    # Verify that 'AnsibleAssertionError' is raised when ds is not a dictionary
    with pytest.raises(AnsibleAssertionError):
        ds = []
        PlaybookInclude.preprocess_data(ds)

    # Verify that 'AnsibleAssertionError' is raised when 'vars' is not a dictionary

# Generated at 2022-06-23 06:39:53.003427
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import add_all_plugin_dirs

    add_all_plugin_dirs()
    loader = DataLoader()
    variable_manager = VariableManager()

    results = dict(
        changed=False,
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='Hello'))),
            dict(action=dict(module='debug', args=dict(msg='World'))),
        ],
    )


# Generated at 2022-06-23 06:39:57.616450
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.playbook.play_context import PlayContext
    import ansible.playbook.play
    import ansible.errors
    import io
    from ansible.parsing.plugin_docs import read_docstring

    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import callback_loader
    from ansible.executor.playbook_executor import PlaybookExecutor


# Generated at 2022-06-23 06:39:58.837295
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-23 06:40:09.901285
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # Test class load for loading the playbook include
    playbook = PlaybookInclude.load(dict(import_playbook='../../../yaml/test_playbook_include_data.yaml',
                                         vars=dict(foo='baz')),
                                    basedir=os.path.join('test', 'unit', 'ansible_module_utils_basic'))
    # Check that the value of the attribute _entries is the same as the value of
    # the variables you expect
    expected_entries = [{'hosts': 'all', 'name': 'Test playbook include',
                         'tasks': [{'name': 'task1', 'yum': 'name={{ foo }} state=present'}], 'vars': {'foo': 'baz'}}]
    assert playbook._entries == expected_entries


#

# Generated at 2022-06-23 06:40:16.582175
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    import os
    import ruamel.yaml
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy

    current_basedir = os.path.dirname(os.path.realpath(__file__))

    loader = ruamel.yaml.RoundTripLoader


# Generated at 2022-06-23 06:40:32.041380
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    ds = {}
    try:
        PlaybookInclude.load(ds, '.', None)
        assert False
    except AnsibleAssertionError:
        pass

    ds = [1, 2, 3]
    try:
        PlaybookInclude.load(ds, '.', None)
        assert False
    except AnsibleAssertionError:
        pass

    ds = {'var': 'value'}

# Generated at 2022-06-23 06:40:45.069789
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import os
    import sys

    if sys.version_info[0] >= 3:
        from io import StringIO
    else:
        from StringIO import StringIO

    # Setup fake stdin, stdout and stderr
    sys.stdin = StringIO()
    sys.stdout = sys.__stdout__
    sys.stderr = sys.__stderr__

    display.verbosity = 3
    current_dir = os.getcwd()
    # We must be inside a directory containing a collection with a valid
    # ansible.cfg
    os.chdir('test/sanity/collection_loader/valid_collection1')


# Generated at 2022-06-23 06:40:49.542741
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    ds = {'import_playbook': "/absolute/file1", 'tags': ['tag2']}
    playbook_include = PlaybookInclude.load({'import_playbook': '../relative/file1', 'vars': {'k1': 'v1', 'tags': 'tag1,tag2'}}, '.')
    assert playbook_include.preprocess_data(ds) == ds



# Generated at 2022-06-23 06:40:55.109621
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pb = PlaybookInclude()
    pb.load(data="import_playbook: test1.yaml", basedir='.')
    assert pb._entries[0]._entries[0]._entries[0]._entries[0].action == 'ping'



# Generated at 2022-06-23 06:40:57.036121
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-23 06:41:08.630982
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task.include import Include
    from ansible.playbook.task.action import Action

    import_playbook = PlaybookInclude()

    task1 = {'include': "file_name"}
    task2 = {'include': "file_name tags=A,B,C"}
    task3 = {'import_playbook': "file_name"}
    task4 = {'import_playbook': "file_name tags=A,B,C"}
    task5 = {'include_tasks': "file_name"}
    task6 = {'include_tasks': "file_name tags=A,B,C"}
    task7 = {'import_tasks': "file_name"}
   

# Generated at 2022-06-23 06:41:14.491751
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''
    [description]
    test load_data method of PlaybookInclude
    '''

    # example import
    ds = '''
    - import_playbook: ../../playbook.yml
    '''
    # load_data
    print(PlaybookInclude.load(data=ds, basedir='/tmp'))


# Generated at 2022-06-23 06:41:26.491692
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    result = None
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader

    from ansible.vars import VariableManager
    from ansible.inventory import Inventory, Host, Group
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=['localhost'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()

    playbook_include = PlaybookInclude()
    playbook = Playbook.load("a.yml", variable_manager=variable_manager, loader=loader)

    # set test dataset
    ds1 = dict(import_playbook="b.yml")

# Generated at 2022-06-23 06:41:36.997634
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.playbook.play import Play

    # construct a simple playbook with a single play
    pb = PlaybookInclude(import_playbook="playbooks/foo.yaml")
    assert pb.import_playbook == "playbooks/foo.yaml"
    assert pb.vars == {}

    # try with one entry in vars
    pb = PlaybookInclude(import_playbook="playbooks/foo.yaml", vars=dict(foo='bar'))
    assert pb.import_playbook == "playbooks/foo.yaml"
    assert pb.vars == dict(foo='bar')

    # try with multiple entries in vars

# Generated at 2022-06-23 06:41:47.016104
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
        #import here to avoid a dependency loop
        from ansible.playbook import Playbook
        from ansible.playbook.play import Play

        # first, we use the original parent method to correctly load the object
        # via the load_data/preprocess_data system we normally use for other
        # playbook objects
        new_obj = PlaybookInclude.load(data='playbook.yml', basedir='.', variable_manager=None, loader=None)

        # then we use the object to load a Playbook
        pb = Playbook(loader=None)

        playbook = 'playbook.yml'
        playbook_collection = None

        # it is NOT a collection playbook, setup adjecent paths

# Generated at 2022-06-23 06:41:47.812927
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-23 06:41:50.442512
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    playbook_include = PlaybookInclude()
    assert playbook_include._import_playbook == ''
    assert playbook_include._vars == {}

# Generated at 2022-06-23 06:41:59.439907
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # import here to avoid a dependency loop
    from ansible.playbook import PlaybookInclude

    pb = PlaybookInclude()
    with pytest.raises(AnsibleAssertionError) as excinfo:
        pb.preprocess_data("invalid")
    assert excinfo.value.message == "ds (invalid) should be a dict but was a <type 'str'>"

    # test_preprocess_data_invalid_import_playbook
    with pytest.raises(AnsibleParserError) as excinfo:
        pb.preprocess_data({'import_playbook': None})
    assert excinfo.value.message == "playbook import parameter is missing"

# Generated at 2022-06-23 06:42:00.118016
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-23 06:42:00.766245
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-23 06:42:04.154945
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    b = PlaybookInclude()
    assert b.import_playbook == None
    assert b.vars == {}
    assert b.tags == []
    assert b.when == []
    assert b.name == None

# Generated at 2022-06-23 06:42:07.225478
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook

    # FIXME: not sure how to test this for now, all of the methods
    #        in the load() method are tested elsewhere
    assert True

# Generated at 2022-06-23 06:42:17.891878
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import ansible.errors as ae
    import ansible.parsing.yaml.objects as ao
    from ansible.playbook.play import Play

    # Construct an object of class PlaybookInclude with some dummy data
    pi = PlaybookInclude()
    pi.basedir = 'some_directory'
    pi.vars = {}

    # Test 1: ds argument not a dictionary
    ds = 'not a dictionary'
    try:
        rc = pi.preprocess_data(ds)
        assert False, "unexpected return from preprocess_data operation"
    except ae.AnsibleAssertionError as e:
        pass

    # Test 2: ds argument is a dictionary
    ds = {}

    # Test 2.1: No 'import_playbook' field
    rc = pi.preprocess

# Generated at 2022-06-23 06:42:23.545675
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook

    pb = Playbook()
    pb._load_playbook_data(file_name="test-fixtures/collection_playbook.yml",
                           variable_manager=None,
                           vars=None)
    assert pb

# Generated at 2022-06-23 06:42:35.311073
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    test_loader = DataLoader()
    test_templar = Templar(loader=test_loader)
    test_variable_manager = None
    test_ds = {
        "@bits": "8",
        "@version": "1.0",
        "import_playbook": "included_playbook.yml",
        "vars": {
            "a": "1",
            "b": "2",
            "c": "3",
            "d": "4"
        },
        "tags": ["tag1", "tag2"]
    }
    test_basedir = '/home/'

    test_play

# Generated at 2022-06-23 06:42:45.430017
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    #try some good examples that should work
    ds = dict(
        import_playbook = 'tasks/main.yml',
        vars = dict(
            x = 1,
            y = 2,
            z = 3,
        ),
    )
    expected = dict(
       import_playbook = 'tasks/main.yml',
       vars = dict(
           x = 1,
           y = 2,
           z = 3,
       ),
    )
    obj = PlaybookInclude()
    result = obj.preprocess_data(ds)
    assert result == expected


# Generated at 2022-06-23 06:42:47.085855
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-23 06:42:59.258761
# Unit test for method preprocess_data of class PlaybookInclude

# Generated at 2022-06-23 06:43:04.586221
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    yaml_obj = PlaybookInclude.load(dict(import_playbook='/path/to/playbook', vars=dict(foo='bar')), basedir='/path/to')
    assert yaml_obj.import_playbook == '/path/to/playbook'
    assert yaml_obj.vars['foo'] == 'bar'

# Generated at 2022-06-23 06:43:09.409360
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play_context import PlayContext

    p = Play().load(dict(hosts='localhost', roles='test1'))
    p.post_validate(PlayContext(play=p))   # To setup _attributes

    ds = dict(import_playbook='a')
    new_obj = PlaybookInclude().load_data(ds=ds, basedir='/test_dir')
    assert isinstance(new_obj, Playbook)
    assert new_obj._entries[0] == p

    ds = dict(import_playbook='a', vars=dict(a='b'))

# Generated at 2022-06-23 06:43:21.681908
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    p = PlaybookInclude.load("foobar.yml")
    assert p.import_playbook == "foobar.yml"
    assert p.vars is None
    assert p.tags is None

    p = PlaybookInclude.load("foobar.yml tags=1,2,3")
    assert p.import_playbook == "foobar.yml"
    assert p.tags == ['1', '2', '3']
    assert p.vars is None

    p = PlaybookInclude.load("foobar.yml one=1 two=2")
    assert p.import_playbook == "foobar.yml"
    assert p.vars == dict(one='1', two='2')
    assert p.tags is None


# Generated at 2022-06-23 06:43:34.770783
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.parsing.dataloader import DataLoader

    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    task_ds = dict(
        action=dict(
            module='debug',
            args=dict(
                msg='foo'
            )
        ),
        when=dict(
            equals=dict(
                platform='linux'
            )
        ),
    )

    ds = dict(
        import_playbook='included.yml',
        when=dict(
            equals=dict(
                platform='linux'
            )
        ),
        vars=dict(
            apache=True
        ),
        tags=['first']
    )


# Generated at 2022-06-23 06:43:41.934275
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():

    my_PlaybookInclude = PlaybookInclude.load({
        'import_playbook': 'roles/webserver/tasks/main.yml',
        'tags': ['tag_one', 'tag_two'],
        'vars': {
            'server': 'foo',
        },
        'when': 'host == "foo"',
    })
    assert my_PlaybookInclude
    assert my_PlaybookInclude.import_playbook == 'roles/webserver/tasks/main.yml'
    assert my_PlaybookInclude.tags == ['tag_one', 'tag_two']
    assert my_PlaybookInclude.vars == {'server': 'foo'}


# Generated at 2022-06-23 06:43:54.133358
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    pb_inc = PlaybookInclude()

    # empty input
    ds = {}
    result = pb_inc.preprocess_data(ds)
    assert result == {}, "Assertion failed, expected '{}' but got '{}'".format({}, result)

    # simple input
    ds = {'import_playbook': 'test.yml'}
    result = pb_inc.preprocess_data(ds)
    assert result == {'import_playbook': 'test.yml'}, "Assertion failed, expected '{'import_playbook': 'test.yml'}' but got '{}'".format(result)

    # import with vars
    ds = {'import_playbook': 'test.yml', 'vars': {'a': '1'}}


# Generated at 2022-06-23 06:44:02.249361
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # Example of a simple test
    test_PBD = { 'import_playbook': "/path/to/file", 'vars': { 'var1': 'val1' } }
    result_PBD = {'import_playbook': '/path/to/file', 'vars': {'var1': 'val1'}}
    assert result_PBD == PlaybookInclude.preprocess_data(test_PBD)

    # Example of a more complex test
    test_PBD = {'include': "/path/to/file", 'vars': {'var1': 'val1'}}
    result_PBD = {'import_playbook': '/path/to/file', 'vars': {'var1': 'val1'}}

# Generated at 2022-06-23 06:44:14.856580
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # Create a test PlaybookInclude object
    test_obj = PlaybookInclude()

    # Test calling preprocess_data() with an empty dict
    new_ds = test_obj.preprocess_data({})
    assert new_ds == {}, 'preprocess_data returned invalid result'

    # Test calling preprocess_data() with an empty AnsibleMapping
    new_ds = test_obj.preprocess_data(AnsibleMapping())
    assert new_ds == {}, 'preprocess_data returned invalid result'

    # Test calling preprocess_data() with a mapping containing an invalid import_playbook statement
    new_ds = test_obj.preprocess_data({
        'import_playbook': None
    })
    assert new_ds == {}, 'preprocess_data returned invalid result'


# Generated at 2022-06-23 06:44:21.763069
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    #p = PlaybookInclude().load(ds=dict(), basedir='/tmp', variable_manager=None, loader=None)
    #print("p = {0}".format(p))
    assert isinstance(PlaybookInclude.load(ds=dict(), basedir='/tmp', variable_manager=None, loader=None), Playbook)


# Generated at 2022-06-23 06:44:30.284381
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import sys
    import copy
    from unittest import TestCase

    class PlaybookIncludeTest(TestCase):

        def test_simple_import(self):
            from ansible.playbook import PlaybookInclude

            # create a test object to use
            ds = dict(
                import_playbook='test_playbook.yml'
            )
            pbi = PlaybookInclude()

            # The load() function for PlaybookInclude classes returns a
            # Playbook object, so we will instantiate one to test against
            from ansible.playbook import Playbook
            pb = Playbook()

            # Add a test playbook entry to the playbook object
            from ansible.playbook.play import Play