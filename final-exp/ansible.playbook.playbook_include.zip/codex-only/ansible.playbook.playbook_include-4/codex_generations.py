

# Generated at 2022-06-23 06:34:38.297809
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    import os
    import yaml
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    collection_playbook_dir = os.path.dirname(os.path.realpath(__file__))
    collection_playbook_path = os.path.join(collection_playbook_dir, "lib/ansible/test/roles/using_collections")

    # first check if we can load using an absolute path
    p = PlaybookInclude.load({"import_playbook": collection_playbook_path}, '', loader=DataLoader())
    assert isinstance(p, Playbook)
    assert p.entries[0].included_path == os.path.dirname(collection_playbook_path)



# Generated at 2022-06-23 06:34:45.403313
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include = PlaybookInclude()
    ds = AnsibleMapping()
    ds['import_playbook'] = "somewhere.yml"
    ds['vars'] = {'one': 1, 'two': 2}
    playbook_include.preprocess_data(ds)
    assert playbook_include.import_playbook == "somewhere.yml"
    assert playbook_include.vars == {'one': 1, 'two': 2}
    ds = AnsibleMapping()
    ds['import_playbook'] = "somewhere-with-params.yml var1=value1 var2=value2"
    playbook_include.preprocess_data(ds)
    assert playbook_include.import_playbook == "somewhere-with-params.yml"
    assert playbook_include

# Generated at 2022-06-23 06:34:47.146195
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include=PlaybookInclude()
    assert playbook_include.load_data(ds={'import_playbook': 'my_play.yml'}, basedir='~/Desktop') is not None


# Generated at 2022-06-23 06:34:56.902043
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    import os
    import sys
    import tempfile
    basedir = tempfile.mkdtemp()
    if os.path.isabs(basedir):
        basedir = os.path.relpath(basedir)
    test_file = os.path.join(basedir, 'test.yml')
    with open(test_file, 'w') as f:
        f.write('- name: test\n')
        f.write('  debug: msg={{ some_var }}')
    ds = {'import_playbook': test_file, 'vars': {'some_var': 'test'}}
    playbook_include = PlaybookInclude.load(ds, basedir)
    assert playbook_include
    # Since we are testing a private method, we have to cheat a little to
    # get to the _entries

# Generated at 2022-06-23 06:35:01.196804
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook

    import_path = '../tests/test_playbook_include/sample.yml'
    parent_dir = os.path.abspath('.')
    playbook_obj = PlaybookInclude().load(import_path, parent_dir)

    assert playbook_obj.__class__ == Playbook

# Generated at 2022-06-23 06:35:11.517895
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include = PlaybookInclude()

    try:
        playbook_include.preprocess_data("content")
        assert False, "Error not raised"
    except AnsibleAssertionError:
        pass

    try:
        playbook_include.preprocess_data({})
        assert False, "Error not raised"
    except AnsibleParserError:
        pass

    playbook_include.preprocess_data({'import_playbook': 'playbook1.yml'})
    playbook_include.preprocess_data({'import_playbook': 'playbook1.yml', 'tags': 'tag1'})
    playbook_include.preprocess_data({'import_playbook': 'playbook1.yml', 'when': 'when1', 'vars': {'var1': 'val1'}})

# Generated at 2022-06-23 06:35:23.116583
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    class MockPlaybook(object):
        def __init__(self):
            self.vars = dict()
            self.tags = list()

    class MockPlay(object):
        def __init__(self):
            self.vars = dict()
            self.tags = list()
            self.pre_tasks = [MockPlaybook()]
            self.tasks = [MockPlaybook()]
            self.roles = [MockPlaybook()]
            self.post_tasks = [MockPlaybook()]

    class MockPlaybookInclude(object):
        def __init__(self):
            self.vars = dict()
            self.tags = list()
            self.import_playbook = 'test/foo.yml'


# Generated at 2022-06-23 06:35:25.671487
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # Import the class under test
    from ansible.playbook.play_include import PlaybookInclude

    # Tests
    assert(True)

    # TODO: Implement more unit tests

# Generated at 2022-06-23 06:35:36.098678
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    from ansible.playbook.playbook_include import PlaybookInclude

    # Checking different combination of fields :
    # - import_playbook
    # - vars
    # - tags

# Generated at 2022-06-23 06:35:48.902690
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.playbook_include import PlaybookInclude

    # Use factory function to create a PlaybookInclude object in order to
    # minimize side effects.
    pi = PlaybookInclude.load({'import_playbook': 'test_hosts'}, basedir='/test/dir')
    result = pi.preprocess_data({'import_playbook': 'test_hosts'})
    assert result == {
        'import_playbook': 'test_hosts',
    }

    pi = PlaybookInclude.load({'include': 'test_hosts'}, basedir='/test/dir')
    result = pi.preprocess_data({'include': 'test_hosts'})
    assert result == {
        'import_playbook': 'test_hosts',
    }

    pi = Playbook

# Generated at 2022-06-23 06:36:01.604969
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.connection import Connection
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars import VariableManager
    from ansible.playbook.play import Play

    ds = AnsibleLoader('').load('''
    - import_playbook: pb1.yaml
    - import_playbook:
        import_playbook: pb2.yaml
        tags:
          - t1
          - t2
        vars:
          - v1: "{{ a }}"
          - v2: "{{ b }}"
    '''.strip())
    variable_manager = VariableManager()

# Generated at 2022-06-23 06:36:15.173125
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play import Play
    import ansible.constants as C
    import ansible.module_utils.module_finder as module_finder

    # Fake loader
    loader = module_finder.ModuleFinder(paths=[])

    # Fake variable_manager
    variable_manager = FakeVariableManager()

    # Fake playbook
    playbook = Play()

    # Fake fake_collection_playbook
    fake_collection_playbook = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../tests/data/collections/ansible_collections/collection_collection/collection_name/plugins/module_utils/collection_utils.py'))

    # Fake

# Generated at 2022-06-23 06:36:23.738066
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    block = PlaybookInclude()
    assert block._import_playbook == None
    assert block._vars == {}

    data = dict(
        import_playbook = "../my_play.yml"
    )
    block = PlaybookInclude.load(data, "/home/juan/ansible", variable_manager=dict(), loader=None)
    assert block._import_playbook == "../my_play.yml"

# Generated at 2022-06-23 06:36:31.862188
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play

    ds = dict(import_playbook='playbook.yaml')
    variable_manager = VariableManager()
    basedir = '/tmp'
    pb = PlaybookInclude.load(ds, basedir, variable_manager)

    # we expect that a new Playbook object would be returned here,
    # and it would contain a single entry, of type Play
    assert isinstance(pb, Playbook)
    assert len(pb._entries) == 1
    assert isinstance(pb._entries[0], Play)

# Generated at 2022-06-23 06:36:42.895264
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook_include import PlaybookInclude
    play1 = Play()
    play1.name = "play1"
    play2 = Play()
    play2.name = "play2"
    playbook_include1 = PlaybookInclude()
    playbook_include1.import_playbook = "test_playbook1"
    playbook_include1._entries = [play1, ]
    playbook_include2 = PlaybookInclude()
    playbook_include2.import_playbook = "test_playbook2"
    playbook_include2._entries = [play2, ]
    playbook_include2.when = ["test_conditional1", ]
    playbook_include1.preprocess_data([playbook_include2, ])
    assert playbook_include

# Generated at 2022-06-23 06:36:54.426403
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    from ansible.playbook.role import Role

    # Test for valid data structures for PlaybookInclude
    for item in [
        {
            'import_playbook': "myplaybook.yml"
        },
        {
            'import_playbook': 'myplaybook.yml',
            'vars': {'key': 'value'}
        }
    ]:
        try:
            pbi = PlaybookInclude.load(
                item,
                basedir='/some/playbook/dir/'
            )
            assert isinstance(pbi, Playbook)
        except Exception as e:
            pytest.fail("Incorrect data structure for PlaybookInclude: {}, error: {}".format(item, e))


    # Test for valid data structures for PlaybookInclude

# Generated at 2022-06-23 06:37:06.899074
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Play

    playbookfile_path = os.path.join(os.path.dirname(__file__), 'test_playbook_include.yml')

    # create a fake variable manager and loader so we don't need those to work
    # properly to call load()
    variable_manager = FakeVariableManager()
    loader = FakeLoader()

    # read in our test data
    (data, basedir) = loader.load_from_file(playbookfile_path)

    # run our method under test
    pb = PlaybookInclude.load(data=data, basedir=basedir, variable_manager=variable_manager, loader=loader)

    # make sure the object was returned ok
    assert isinstance(pb, PlaybookInclude)

    # make sure it looks like it loaded correctly

# Generated at 2022-06-23 06:37:14.093980
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    ds = dict(
        import_playbook = 'include.yml',
        tags = ['tag1', 'tag2'],
    )
    obj = PlaybookInclude.load(
        ds = ds,
        basedir = '.',
    )
    assert obj.load_data(ds, '.') == obj


# Generated at 2022-06-23 06:37:23.531308
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_context import RoleContext
    from ansible.parsing.yaml.objects import AnsibleSequence

    # init objects
    context = PlayContext()
    context.CLIARGS = {}
    context.connection = None
    context.vars = {}
    context.CLIARGS = {'vault_password_file': None}

    play_obj = Play().load({})
    play_obj._variable_manager = None
    play_obj._loader = None

    role_obj = RoleContext(play=play_obj)

    block1 = AnsibleMapping()
    block1.ansible_pos = (0,0)

# Generated at 2022-06-23 06:37:34.326036
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    parent_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    playbook = os.path.join(parent_dir, 'test', 'playbooks', 'playbook_import_playbook.yml')
    with open(playbook, 'rb') as f:
        data = f.read()

    path = os.path.join(parent_dir, 'test', 'playbooks')
    pb = PlaybookInclude().load_data(data, path)
    assert isinstance(pb, Playbook)
    assert pb.entries[1].hosts == 'test'
    assert pb.entries[1].vars['test'] == 'test2'

# Generated at 2022-06-23 06:37:43.606167
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext

    include_playbook = '../my/playbook.yml'
    parameters = 'extra_var=foo extra_var2=bar'

    # Test a 'normal' playbook import line
    import_playbook_entry = dict(import_playbook='../my/playbook.yml extra_var=foo extra_var2=bar')
    expected_import_playbook = dict(import_playbook=include_playbook,
                                    vars=dict(extra_var='foo', extra_var2='bar'))
    assert PlaybookInclude.load_data(import_playbook_entry, basedir='.')._ds == expected_import_playbook

    # Test an 'import_playbook' line with 'tags'

# Generated at 2022-06-23 06:37:48.995664
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    pb = PlaybookInclude(loader={})

    assert pb._import_playbook is None
    assert pb.vars == {}
    assert isinstance(pb, Conditional)
    assert isinstance(pb, Base)

    example_yaml = """
- import_tasks: testPlaybookInclude.yaml
    tags: tag_one
    vars:
        key_one: value_one
- import_tasks: testPlaybookInclude.yaml
    tags: tag_two
    vars:
        key_two: value_two
        key_one: value_three
    """
    pb = PlaybookInclude.load(example_yaml, '', loader={})


# Generated at 2022-06-23 06:37:51.022233
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pbi = PlaybookInclude()
    pbi.import_playbook = 'foobar.yml'

# Generated at 2022-06-23 06:37:51.680091
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-23 06:37:58.287824
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # Setup arguments for a simple constructor test
    args = {}
    args['import_playbook'] = '../test/test.yml'
    args['vars'] = {}

    # Test the constructor
    test_obj = PlaybookInclude(**args)

    # assert test_obj.import_playbook == '../test/test.yml'
    assert test_obj.vars == {}


# Generated at 2022-06-23 06:38:04.763863
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    ds = dict(
        include = 'somefile',
        include_tasks = 'somefile',
    )

    for k in ds:
        p = PlaybookInclude.load(ds, dict(), variable_manager=None, loader=None)
        assert isinstance(p, PlaybookInclude)
        assert p.import_playbook == ds[k]


# Generated at 2022-06-23 06:38:18.285572
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pb = []
    vars = {'vars_test': '{{value_test}}', 'vars_test2': '{{value_test2}}'}
    tags = ['tag1', 'tag2']
    when = ['when_test','when_test2']

    import_playbook = {'import_playbook': 'test-pb.yml', 'vars': vars, 'tags': tags, 'when': when}
    obj = PlaybookInclude.load(import_playbook, '/home/user')

    assert obj._entries == pb
    assert obj._included_path == '/home/user'
    assert obj._included_conditional == when
    assert obj.conditional is None
    assert obj.tags == tags
    assert obj.vars == vars



# Generated at 2022-06-23 06:38:30.810552
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # Test for empty playbook
    playbook = PlaybookInclude.load(dict(), '/a/b/c')
    assert playbook._entries == []

    # Test for playbook with no tasks and no handlers
    playbook = PlaybookInclude.load({'import_playbook': 'd'}, '/a/b/c')
    assert playbook._entries == []

    # Test for playbook with tasks and handlers
    playbook = PlaybookInclude.load({'import_playbook': 'e', 'vars': {'f': 'g'}}, '/a/b/c')
    assert playbook._entries == []

    # Test for invalid playbook
    playbook = PlaybookInclude.load({'import_playbook': 'h'}, '/a/b/c')
    assert playbook._entries == []

# Generated at 2022-06-23 06:38:31.622548
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    return


# Generated at 2022-06-23 06:38:41.598439
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import sys
    sys.path.append('/Users/shone/Documents/workspace/ansible_server/ansible-version/ansible/lib/ansible/plugins/action')

    # ansible-version/ansible/lib/ansible/plugins/module_utils/basic.py
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection, ConnectionError

    # ansible-version/ansible/lib/ansible/plugins/action/normal.py
    from ansible.plugins.action.normal import ActionModule as _ActionModule
    #from ansible.plugins.action.normal import ActionModule as _ActionModule
    #from ansible.plugins.action.network import ActionModule as _ActionModule

    # ansible-version/ansible/lib/ansible/plugins/action/

# Generated at 2022-06-23 06:38:44.227613
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pb = PlaybookInclude()
    assert (pb.import_playbook is None)
    assert (pb.vars == {})

# Generated at 2022-06-23 06:38:54.676073
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''
    Load_data method is used to load data of playbook_include class
    '''
    data = {'import_playbook': 'playbook/test.yml', 'vars': {'var1': 'var1'}}
    playbook_include = PlaybookInclude()
    playbook_include.load_data(data, '/some/path/')
    assert playbook_include.import_playbook == 'playbook/test.yml'
    assert playbook_include.vars == {'var1': 'var1'}


# Generated at 2022-06-23 06:39:04.918970
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # Create a basic variable manager for the main playbook
    variable_manager = VariableManager()

    # Create an inventory manager for the main playbook
    inventory = InventoryManager(loader=DataLoader(), variable_manager=variable_manager, sources=[])

    # Load the data for the PlaybookInclude
    import_yaml = '''
    - import_playbook: ./contrib/inventory/ec2.py
    '''
    import_yml = '''
    - import_playbook: ./contrib/inventory/ec2.py
    '''

# Generated at 2022-06-23 06:39:15.064922
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.parsing.yaml.loader import AnsibleLoader
    p = PlaybookInclude.load(
        dict(import_playbook='playbook.yml', vars=dict(spam='eggs')),
        basedir='/tmp/ansible/roles/role_name/',
        variable_manager=dict(nested=dict(vars=dict(spam='ham'))),
        loader=AnsibleLoader
    )

    assert(isinstance(p, Playbook))
    assert(p.vars == dict(spam='ham'))


# Generated at 2022-06-23 06:39:28.460354
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    playbookInclude_1 = PlaybookInclude()
    playbookInclude_2 = PlaybookInclude(vars={'a':'b'})
    playbookInclude_3 = PlaybookInclude(vars={'a':'b'}, tags=['tag1','tag2'])
    playbookInclude_4 = PlaybookInclude(vars={'a':'b'}, tags=['tag1','tag2'], import_playbook='test1.yml')
    playbookInclude_5 = PlaybookInclude(vars={'a':'b'}, tags=['tag1','tag2'], import_playbook='test1.yml', when='(a or b)')

# Generated at 2022-06-23 06:39:41.706460
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    import os

    # test default values of empty object
    assert PlaybookInclude()._import_playbook == None
    assert PlaybookInclude()._vars == {}

    # test init with kwargs
    assert PlaybookInclude(**{'_import_playbook': 'file'})._import_playbook == 'file'
    assert PlaybookInclude(**{'_import_playbook': 'file', '_vars': {'test': 'variable'}})._vars == {'test': 'variable'}

    # test init with args
    assert PlaybookInclude('file')._import_playbook == 'file'
    assert PlaybookInclude('file', {'test': 'variable'})._vars == {'test': 'variable'}

    # test init with wrong args
    success = False

# Generated at 2022-06-23 06:39:48.511287
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    class MockPlaybookInclude(PlaybookInclude):
        def __init__(self):
            self.import_playbook = None
            self.vars = None
            self.tags = None
            self.when = None

    mock_pbi = MockPlaybookInclude()

    # Check for invalid types
    try:
        mock_pbi.preprocess_data(123456)
        raise AssertionError('Expected a failure due to invalid data type')
    except AnsibleParserError:
        # Uncomment the following line when you are debugging any failures in the tests
        #print "Caught the expected exception for incorrect type given to preprocess_data"
        pass

    # Check for empty dict

# Generated at 2022-06-23 06:39:50.546136
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    p = PlaybookInclude()

    assert p.import_playbook is None
    assert p.vars == {}

# Generated at 2022-06-23 06:39:51.563711
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # TODO
    pass

# Generated at 2022-06-23 06:40:01.628064
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    c = PlaybookInclude()

    playbook_path = os.path.dirname(__file__)
    basedir = playbook_path + '/../../playbooks'
    playbook_file = playbook_path + '/../../playbooks/playbookinclude.yml'
    pb = Playbook()

    # test if the YAML file can be loaded correctly
    pb._load_playbook_data(file_name=playbook_file, basedir=basedir, variable_manager=None, loader=None)

    # test the load_data method of class PlaybookInclude
    result = c.load_data(pb._entries[0]._data, basedir=basedir, variable_manager=None, loader=None)

    #

# Generated at 2022-06-23 06:40:12.030314
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.template import Templar

    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    # create a playbook object with two plays
    pb = Playbook()
    pb._entries = [Play().load({'name': 'play1'}, templar=Templar({})),
                   Play().load({'name': 'play2'}, templar=Templar({}))]

    # create a PlaybookInclude object to load the playbook
    pbi = PlaybookInclude()
    pb2 = pbi.load_data(ds='test.yaml', basedir='.', variable_manager=None, loader=None)


# Generated at 2022-06-23 06:40:23.726752
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Play

    inc = PlaybookInclude()
    inc.load_data({'import_playbook': 'test.yml'}, basedir=".", variable_manager=None, loader=None)
    assert isinstance(inc.import_playbook, string_types)
    assert len(inc._entries) == 2 # this file is imported in the test and it contains 2 plays
    assert isinstance(inc[0], Play)
    assert isinstance(inc[1], Play)

    inc.load_data({'import_playbook': 'test.yml', 'tags': 'foo'}, basedir=".", variable_manager=None, loader=None)
    assert isinstance(inc.import_playbook, string_types)
    assert len(inc._entries) == 2 # this file is imported in the test

# Generated at 2022-06-23 06:40:35.386034
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager.set_inventory(inventory)

    loader.set_basedir('tests/playbooks')

    pi = PlaybookInclude(variable_manager=variable_manager, loader=loader)
    pb = pi.load('import_playbook.yml')
    assert isinstance(pb, AnsibleMapping)
    assert pb.get('playbook').get('hosts') == ['all']
    assert pb.get('playbook').get('vars').get('var1') == 'value1'

# Generated at 2022-06-23 06:40:47.530381
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    import sys
    import yaml
    from ansible.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager

    data = '''
        - hosts:
          import_playbook: test.yml
    '''

    # data_obj = PlaybookInclude.load(data = data, basedir='/tmp')


# Generated at 2022-06-23 06:40:58.776545
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    from ansible.parsing.yaml.objects import AnsibleMapping


    test_data = AnsibleMapping()
    test_data.update(dict(z=3))
    test_data.update(dict(import_playbook='foo'))
    test_data.update(dict(x=1))
    test_data.update(dict(vars=dict(a=1, b=2)))
    test_data.update(dict(tags='a,b,c'))

    data = dict(y=2, import_playbook="setup,vars=foo.yml,tags=includetest", x=1, vars=dict(a=1, b=2), tags='a,b,c')
    data_obj = AnsibleMapping(data)

# Generated at 2022-06-23 06:41:04.259008
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    """
    Unit test for method preprocess_data of class PlaybookInclude
    """
    import_playbook = PlaybookInclude()
    import_playbook.preprocess_data(dict(
        import_playbook=dict(
            include='foo.yml'),
        vars=dict(a=1, b=2),
        tags='a'))
    assert dict(import_playbook='foo.yml', vars=dict(a=1, b=2), tags=['a']) == import_playbook.serialize()



# Generated at 2022-06-23 06:41:08.369628
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Set up some objects we need
    from ansible.playbook import Playbook
    assert PlaybookInclude.load_data(ds={'import_playbook': 'test-play'}, basedir='.') == Playbook(loader=None, variable_manager=None)

# Generated at 2022-06-23 06:41:19.641917
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    import os
    import sys
    import tempfile
    #from ansible.utils.collection_loader import _get_collection_name_from_path
    #from ansible.utils.collection_loader._collection_finder import _get_collection_playbook_path
    import ansible.playbook.playbook_include
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook

    testfile = u"""
    - import_playbook: foo.yaml tags=one
    - import_playbook: bar.yaml tasks:
    -- vars:
    --- a: b
    - import_playbook: bas.yaml vars:
    --- c: d
    --- e: f
    """

    # Set up temporary directories
    tmp_test_dir = tempfile.mkdtemp()
   

# Generated at 2022-06-23 06:41:28.541708
# Unit test for method preprocess_data of class PlaybookInclude

# Generated at 2022-06-23 06:41:30.593593
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-23 06:41:42.840954
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook_include import PlaybookInclude
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Change the display setting to suppress output during testing
    display.verbosity = 3

    # Test playbook that contains a playbook include
    playbook_path = "./test/units/utils/include-playbook.yml"
    playbook_data = None
    with open(playbook_path) as f:
        playbook_data = f.read()

    # The playbook_data is read in as a string.  Load the data
    # into a data structure.
    loader = AnsibleLoader(playbook_data)
    data = loader.get_single_data()

    # Create the playbook object

# Generated at 2022-06-23 06:41:55.506623
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    include = PlaybookInclude()

    # -------------------------------------------------------------------------------------------
    # test case#1: test normal case, with only one task
    # -------------------------------------------------------------------------------------------
    data = dict(import_playbook='test.yml')
    expect_result = dict(import_playbook='test.yml')
    result = include.preprocess_data(data)
    assert expect_result == result

    # -------------------------------------------------------------------------------------------
    # test case#2: test specified with vars and tags
    # -------------------------------------------------------------------------------------------
    data = dict(import_playbook='test.yml', vars=dict(host='localhost', port=100), tags=['a', 'b'])
    expect_result = dict(import_playbook='test.yml', vars=dict(host='localhost', port=100), tags=['a', 'b'])
    result

# Generated at 2022-06-23 06:41:56.402648
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # For now lets just test that it exists
    pass

# Generated at 2022-06-23 06:42:09.092367
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.playbook_include import PlaybookInclude

    # Create a "raw" data structure of a playbook include
    # with invalid parameter type.
    raw_data_1 = {
        'include': 1,
    }
    # Create a "raw" data structure of a playbook include
    # with unknown key.
    raw_data_2 = {
        'include': 'test.yml',
        'unknown_key': 'unknown_value',
    }
    # Create a "raw" data structure of a playbook include
    # with vars only.
    raw_data_3 = {
        'vars': {
            'a': 1,
            'b': 2,
            'c': 5,
        },
    }
    # Create a "raw" data structure of a playbook include
    # with vars

# Generated at 2022-06-23 06:42:10.274456
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pl = PlaybookInclude()

# Generated at 2022-06-23 06:42:15.101649
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.playbook.base import Base
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable

    pbi = PlaybookInclude()

    assert isinstance(pbi, Base)
    assert isinstance(pbi, Conditional)
    assert isinstance(pbi, Taggable)

# Generated at 2022-06-23 06:42:16.037082
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    PlaybookInclude.load_data()

# Generated at 2022-06-23 06:42:16.924191
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    PlaybookInclude()



# Generated at 2022-06-23 06:42:29.485298
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleBaseYAMLObject
    from ansible.utils.vars import combine_vars

    # create an instance of PlaybookInclude
    obj = PlaybookInclude()

    # the test structure
    ds = AnsibleMapping()
    ds['import_playbook'] = 'import_playbook.yml'
    ds['vars'] = {'var1': 1}
    ds['tags'] = ['tag1']
    ds['when'] = ['when1']

    # call the method
    new_ds = obj.preprocess_data(ds)

    # validate the result

# Generated at 2022-06-23 06:42:41.162028
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()

    import_playbook = 'roles/test_playbook_include/playbook/test_playbook_include.yml'

    playbook = PlaybookInclude()
    playbook.load(import_playbook, '/tmp/', variable_manager, loader)

    # Test playbook import_playbook path
    assert playbook.import_playbook == 'roles/test_playbook_include/playbook/test_playbook_include.yml'

    context = PlayContext(loader=loader)

# Generated at 2022-06-23 06:42:48.774162
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    import os
    import tempfile

    fakedir = tempfile.mkdtemp(dir='/tmp')
    testfile = os.path.join(fakedir, 'playbook.yml')
    with open(testfile, 'w') as f:
        f.write('- hosts: all\n  tasks:\n  - debug: msg=Hello\n')
    pb = PlaybookInclude.load(dict(import_playbook='%s' % testfile), '/tmp', None)
    assert isinstance(pb, Playbook)
    assert len(pb._entries) == 1
    assert isinstance(pb._entries[0], Play)
    assert pb._entries[0].hosts == 'all'

# Generated at 2022-06-23 06:43:00.113227
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    import yaml
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.play_context import PlayContext

    context = PlayContext()
    context.CLIARGS = {}
    context.vars = {}

    # test preprocess_data for import_playbook
    yml = """
    - import_playbook: test_foobar.yml
    """
    obj = yaml.safe_load(yml)
    task = PlaybookInclude.load(obj[0], variable_manager=context.variable_manager, loader=context.loader)
    play = 'test_preprocess_data_for_import_playbook'
    assert play == task.name
    assert play not in task.vars


# Generated at 2022-06-23 06:43:09.548341
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # Setup test case
    class TestPlaybookInclude(PlaybookInclude):
        def __init__(self):
            super(TestPlaybookInclude, self).__init__()
            self.desired = AnsibleMapping()

        def _preprocess_import(self, ds, new_ds, k, v):
            pass

    # Setup test
    test_include_obj = TestPlaybookInclude()
    test_input_ds = AnsibleMapping()
    test_input_ds['import_playbook'] = 'imported-playbook'

    # Test: Test with non-dict input

# Generated at 2022-06-23 06:43:21.713875
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.utils.collection_loader import AnsibleCollectionConfig, _get_paths_from_collection_name

    AnsibleCollectionConfig.default_collections_path = None
    pbi = PlaybookInclude()

    # Test old style - simple
    ds = {
        'include': {
            'import_playbook': 'play1.yml',
        }
    }
    new_ds = pbi.preprocess_data(ds)
    assert new_ds == {'import_playbook': 'play1.yml'}

    # test for hack in preprocess_data - should be fixed in the future
    AnsibleCollectionConfig.default_collections_path = ['col1', 'col2']

# Generated at 2022-06-23 06:43:28.355536
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    ds = dict(
        _import_playbook = dict(file = 'testfile.yml', vars = dict(one = 'two'), tags = 'atag'),
        vars = dict(three = 'four')
    )
    pi = PlaybookInclude()
    pi.load_data(ds)
    print(pi.dump())

# Generated at 2022-06-23 06:43:32.080673
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    playbook = PlaybookInclude.load(data=dict(import_playbook='../Playbooks/hosts.yml'),
                                    basedir='/home/ansible/ansible')
    pass

# Generated at 2022-06-23 06:43:40.666747
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pbi = PlaybookInclude.load(dict(import_playbook='foo.yml'))
    assert pbi.import_playbook == 'foo.yml'
    assert len(pbi.tags) == 0
    assert len(pbi.vars) == 0
    assert pbi.when is None
    assert pbi.failed_when is None

    pbi = PlaybookInclude.load(dict(import_playbook='foo.yml', tags=['one', 'two'], vars=dict(blah='blah'), failed_when=False))
    assert pbi.import_playbook == 'foo.yml'
    assert len(pbi.tags) == 2
    assert len(pbi.vars) == 1
    assert pbi.vars['blah'] == 'blah'
    assert p

# Generated at 2022-06-23 06:43:48.492208
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    # constructor should not accept invalid arguments
    try:
        p = PlaybookInclude(dummy=True)
    except Exception as e:
        assert True
    else:
        assert False, "Failed to raise exception"

    # constructor should assign default values correctly
    p = PlaybookInclude()
    assert p.import_playbook == ''
    assert p.vars == dict()
    assert p.tags == list()
    assert p.when == list()

# Generated at 2022-06-23 06:43:58.238226
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.dataloader import DataLoader

    ds = dict(
        file='../../common/tasks.yml',
        vars=dict(
            foo='bar',
            cheese='cheddar'),
        tags=['stuff'])
    pi = PlaybookInclude()
    try:
        pi.preprocess_data(ds)
        assert(0)
    except AnsibleParserError:
        pass
    ds = dict(
        import_playbook='../../common/tasks.yml',
        vars=dict(
            foo='bar',
            cheese='cheddar'),
        tags=['stuff'])
    pv = pi.preprocess_data(ds)

# Generated at 2022-06-23 06:44:10.065549
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    '''
    Tests to check if the method preprocess_data of class PlaybookInclude works as it should.

    :param module: An ansible v2.8 playbook_include module (fake).
    :type module: dict

    :param collection: A collection (fake).
    :type collection: dict

    :param playbook_file: playbook_file (fake).
    :type playbook_file: str

    :param variable_manager: variable_manager (fake).
    :type variable_manager: dict

    :param loader: loader (fake).
    :type loader: dict
    '''

    # Setup test data.
    playbook_include_object = PlaybookInclude()
    playbook_include_object_dict = {'elvis': 'left the building'}

# Generated at 2022-06-23 06:44:23.118359
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    """
    Test to make sure that "import_playbook: somevalue" is correctly translated
    into expected keys and values for this class when using the preprocess_data
    function
    """
    b = PlaybookInclude()

# Generated at 2022-06-23 06:44:34.266739
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.plugins.loader import action_loader, add_all_plugin_dirs
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    add_all_plugin_dirs(action_loader)

    play = Play.load({'hosts': 'localhost', 'import_playbook': 'foo.yml', 'roles': ['foobar']}, variable_manager=VariableManager(), loader=loader)

    # This should fail because we're mixing k=v params with vars