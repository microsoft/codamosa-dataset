

# Generated at 2022-06-23 06:34:23.375166
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass



# Generated at 2022-06-23 06:34:24.747632
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    p = PlaybookInclude()

# Generated at 2022-06-23 06:34:25.707378
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass


# Generated at 2022-06-23 06:34:38.487512
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence

    ds = AnsibleSequence()
    ds.append("playbook.yml")
    ds.ansible_pos = (1,1)

    loader = AnsibleLoader(None, None)
    p = PlaybookInclude().load_data(ds, '/path/to', loader=loader)
    assert isinstance(p, PlaybookInclude)
    assert p.import_playbook == "playbook.yml"
    assert loader.errors == []

    # test extension to new_ds
    ds = AnsibleSequence()
    ds.append("playbook.yml")
    ds.ansible_pos = (1,1)
    ds

# Generated at 2022-06-23 06:34:51.162483
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    #VariableManager is only required in load, so we ignore the error.
    #pylint: disable=unused-variable
    import ansible.parsing.dataloader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.splitter import split_args

    # Test load from a simple playbook
    mocker.patch('ansible.parsing.yaml.objects.AnsibleVaultEncryptedUnicode.__eq__', return_value=False)
    mocker.patch('ansible.parsing.yaml.dumper.AnsibleDumper.add_representer', return_value=None)
    mocker.patch('os.path.join', return_value='/tmp/subdir')
    mocker.patch

# Generated at 2022-06-23 06:35:02.029368
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.errors import AnsibleError
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.task import TaskInclude


# Generated at 2022-06-23 06:35:07.153955
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    # mock collection_loader
    old_collection_loader = AnsibleCollectionConfig._get_collection_loader

    def _get_collection_loader():
        return True

    AnsibleCollectionConfig._get_collection_loader = _get_collection_loader

    # create fake collection and playbook
    # NOTE: we must use abspath, because the playbook_include
    #   is using "basedir" to read the playbook

# Generated at 2022-06-23 06:35:19.397564
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import pytest
    from ansible.errors import AnsibleParserError
    from ansible.playbook.playbook_include import PlaybookInclude

    # Test for when vars is not specified as a dictionary.
    data = dict(
        import_playbook="playbook.yml",
        vars = "foo"
    )
    expected_msg = "vars for import_playbook statements must be specified as a dictionary"
    with pytest.raises(AnsibleParserError, match=r".*{}.*".format(expected_msg)):
        PlaybookInclude.preprocess_data(data)

    # Test for when import_playbook parameters cannot be mixed with 'vars' entries for import statements.

# Generated at 2022-06-23 06:35:22.542417
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    import_playbook = 'import_playbook'
    vars_ = {'key': 'value'}

    playbook_include = PlaybookInclude(import_playbook, vars_)

    assert playbook_include.import_playbook == import_playbook
    assert playbook_include.vars == vars_

# Generated at 2022-06-23 06:35:24.140100
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # TODO implement proper test for PlaybookInclude
    pass

# Generated at 2022-06-23 06:35:35.183881
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.dataloader import DataLoader

    obj = PlaybookInclude()
    ds  = {
        'import_playbook': 'test1.yml',
        'other_key': 'other value',
    }
    assert obj.preprocess_data(ds) == {
        'import_playbook': 'test1.yml',
        'other_key': 'other value',
    }

    ds  = {
        'import_playbook': 'test2.yml with_space',
        'other_key': 'other value',
    }

# Generated at 2022-06-23 06:35:44.402029
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # test constructors
    source = dict(
        tasks = [dict(), dict()]
    )
    pbi = PlaybookInclude.load(source, None)
    assert isinstance(pbi, PlaybookInclude)

    pbi = PlaybookInclude().load_data(source, None)
    assert isinstance(pbi, PlaybookInclude)

    pbi = PlaybookInclude()
    pbi.load_data(source, None)
    assert isinstance(pbi, PlaybookInclude)

# Generated at 2022-06-23 06:35:52.484141
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    import_playbook = 'test_import_playbook'
    vars = dict(
        param_1 = 'test_param_1',
        param_2 = 'test_param_2',
    )
    playbook_include = PlaybookInclude(import_playbook, vars)

    # Get constructor result to check
    result_import_playbook = playbook_include.import_playbook
    result_vars = playbook_include.vars

    # Check constructor result to assert
    assert result_import_playbook == import_playbook, 'Test failed: constructor result of import_playbook not match'
    assert result_vars == vars, 'Test failed: constructor result of vars not match'



# Generated at 2022-06-23 06:35:57.505185
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Preprocess data
    import_1 = dict(import_playbook='/home/user/pb1.yaml',
                    vars=dict(p1='p1-val'))
    import_2 = dict(import_playbook='/home/user/pb2.yaml',
                    tags='tag1,tag2',
                    vars=dict(p1='p1-val', p2='p2-val'))
    import_3 = dict(import_playbook='/home/user/pb1.yaml',
                    tags='tag1,tag2')
    import_4 = dict(import_playbook='/home/user/pb1.yaml',
                    tags='tag1,tag2',
                    vars=dict(p2='p2-val', p3='p3-val'))

    # Test

# Generated at 2022-06-23 06:36:01.120778
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pbi = PlaybookInclude()
    pbi.load({'import_playbook': 'a.yml'})
    assert pbi.import_playbook == 'a.yml'


# Generated at 2022-06-23 06:36:08.445221
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    import_playbook = PlaybookInclude()

    result_dict = {}
    result_dict['import_playbook'] = "./a/b/c.yml"

    # 1 test: 'include some_file.yml'
    ds = "./a/b/c.yml"
    preprocessed_data = import_playbook.preprocess_data(ds)
    assert preprocessed_data == result_dict, preprocessed_data

    # 2 test: 'include: some_file.yml'
    ds = {'include': "./a/b/c.yml"}
    preprocessed_data = import_playbook.preprocess_data(ds)
    assert preprocessed_data == result_dict, preprocessed_data

    # 3 test: 'include: "./a/b/

# Generated at 2022-06-23 06:36:20.749032
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():

    # Build the following playbook.yml
    #- hosts: localhost
    #  roles:
    #  - role1
    #  - role2
    #  tasks:
    #  - debug: var=test
    #
    #- hosts: localhost
    #  roles:
    #  - role3
    #  tasks:
    #  - debug: var=test2
    #

    from ansible.playbook.play import Play
    from ansible.playbook.role import Role

    hosts  = "localhost"
    roles  = [ Role(name="role1"), Role(name="role2") ]
    tasks  = { "debug" : { "var" : "test" } }

    roles2 = [ Role(name="role3") ]

# Generated at 2022-06-23 06:36:28.486279
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook, PlaybookInclude
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    p = PlaybookInclude()
    pb = p.load(data={"include" : "test_playbook.yml"}, basedir="tests/unit")
    assert isinstance(pb, Playbook)
    assert isinstance(pb._entries[0], Play)

# Generated at 2022-06-23 06:36:36.256004
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os
    import mock

    # data represents a PlaybookInclude
    data = {
        'import_playbook': 'foo.yml',
        'vars': {
            'test_var': 'Test value'
        }
    }

    basedir = '/test/basedir'

    # mock the class Playbook
    mock_playbook_class = mock.Mock()
    mock_playbook_class.return_value = 'foo'
    with mock.patch('ansible.playbook.playbook_include.Playbook', new=mock_playbook_class):
        with mock.patch('ansible.playbook.playbook_include.os.path.exists', return_value=True):
            # load the data
            loaded_data = PlaybookInclude.load(data, basedir)

            # assert

# Generated at 2022-06-23 06:36:45.343453
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import sys
    import os
    import yaml
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleSequence, AnsibleMapping

    here = sys.path[0]
    if not here:
        here = os.getcwd()
    data_path = os.path.join(here, 'unittests', 'parsing', 'yaml', 'playbook_include')

    for filename in os.listdir(data_path):
        if filename.startswith("test_"):
            # read the file
            test_fh = open(os.path.join(data_path, filename))
            test_data = test_fh.read()
            test_fh.close()

# Generated at 2022-06-23 06:36:56.554962
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    collection_paths = AnsibleCollectionConfig.default_collection_paths

    def _setup_mocks(mocker):
        mocker.patch('ansible.utils.collection_loader._collection_finder._get_fqcn_from_path')
        get_fqcn_from_path = mocker.patch('ansible.utils.collection_loader._collection_finder._get_collection_name_from_path')
        get_fqcn_from_path.return_value = 'a.b.c'

    # Collection not FQCN
    _setup_mocks(mocker)
    basedir = 'tests/unit/playbooks'
    ds = {'import_playbook': '../units/playbook_include.yml'}


# Generated at 2022-06-23 06:37:07.996376
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    p = PlaybookInclude()
    assert p.preprocess_data(dict()) == dict()
    assert p.preprocess_data(dict(import_playbook='/tmp/test1.yaml')) == dict(import_playbook='/tmp/test1.yaml')
    assert p.preprocess_data(dict(import_playbook='/tmp/test2.yaml', tags='tag1')) == dict(import_playbook='/tmp/test2.yaml', tags='tag1')

# Generated at 2022-06-23 06:37:20.677615
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.module_utils._text import to_native
    from ansible.playbook.playbook_include import PlaybookInclude

    entry = """
    - import_playbook:
        name: test_playbook.yml
        tags: tag1, tag2
        some_arg: some value
    """
    pb_include = PlaybookInclude.load(entry, os.path.dirname(__file__))

    assert isinstance(pb_include, PlaybookInclude)
    assert pb_include.import_playbook == 'test_playbook.yml'
    assert pb_include.tags == ['tag1', 'tag2']
    assert pb_include.vars == dict(some_arg='some value')

    # test invalid playbook import parameter

# Generated at 2022-06-23 06:37:36.245235
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    class fake_variable_manager():
        def __init__(self):
            self.vars = {'mel':44444444444444444444,
                         'eww':33333333333333333333}

        def get_vars(self):
            return self.vars

    class fake_loader():
        def __init__(self, config):
            self.config = config

        def load_from_file(self, file_name):
            config = {}
            if 'name' in self.config:
                config['name'] = self.config['name']
            return config

        def path_dwim(self, file_name):
            if 'name' in self.config:
                return self.config['name']
            else:
                return file_name


# Generated at 2022-06-23 06:37:50.374926
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()

    # Test the PlaybookInclude load_data method with args in import_playbook attribute
    playbook_import = '../my_playbook.yml some_var=5 some_list=[1,2,3] some_other_list=["a","b","c"]'
    ds = dict(import_playbook=playbook_import, tags=['foo'])
    ds = PlaybookInclude.preprocess_data(ds)
    assert 'import_playbook' in ds
    assert 'vars' in ds
    assert 'tags' in ds
    assert ds['import_playbook'] == '../my_playbook.yml'

# Generated at 2022-06-23 06:37:55.332845
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    play = PlaybookInclude.load({'import_playbook': 'test.yml', 'vars': {'foo': 'bar'}, 'other': 'baz'})
    assert play.import_playbook == 'test.yml'
    assert play.vars == {'foo': 'bar'}
    assert play.other == 'baz'

# Generated at 2022-06-23 06:38:06.802148
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # load_data method of PlaybookInclude returns Playbook instance, not PlaybookInclude instance
    # so this is the test case.
    from ansible.playbook import Playbook
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.collection_loader._collection_finder import _get_collection_name_from_path, _get_collection_playbook_path

    playbook_data = dict(
        include = dict(
            import_playbook = "./import_playbook.yaml",
            vars = dict(
                foo = "bar"
            )
        )
    )
    playbook = Playbook.load(
        data = playbook_data,
        basedir = "/path/to/basedir",
        variable_manager = None
    )


# Generated at 2022-06-23 06:38:19.206509
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    #
    # TODO: shall we do that only in unit tests?
    #
    # check that the variable manager is correctly populated
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    # Create a variable manager
    v = dict(test_var1='other')
    variable_manager = DummyVariableManager()
    variable_manager.set_nonpersistent_facts(v)

    # Create a loader
    loader = DummyLoader()

    # Create a playbook
    pb = Playbook()

    # Create a PlaybookInclude object
    include_obj = PlaybookInclude()

# Generated at 2022-06-23 06:38:26.310780
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.playbook import PlaybookInclude
    from ansible.template import Templar
    from ansible.vars import VariableManager

    t = Templar(loader=None, variables=VariableManager())

    pl = PlaybookInclude()
    result = pl.load_data({"import_playbook": "foo.yml"}, basedir="/tmp", variable_manager=VariableManager())
    assert result is not None

# Generated at 2022-06-23 06:38:35.838724
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # test playbook include without variables
    data = {
        "import_playbook": "./common_tasks.yml"
    }
    playbook = PlaybookInclude.load(data, basedir="ansible/playbooks")

    assert playbook.import_playbook == "./common_tasks.yml"
    assert playbook.vars == {}
    assert playbook.tags == []

    # test playbook include with variables
    data = {
        "import_playbook": "./common_tasks.yml",
        "vars": {
            "some_var": 42
        }
    }
    playbook = PlaybookInclude.load(data, basedir="ansible/playbooks")

    assert playbook.import_playbook == "./common_tasks.yml"

# Generated at 2022-06-23 06:38:48.750703
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence

    data = '''
- import_playbook: import_playbook_playbook.yml vars:
    key: value
    hello: world
  with_items: one two
'''

    playbook_include = PlaybookInclude.load(data=data, basedir='/home/ansible/playbooks')
    data = AnsibleLoader(data, '', '', None, None).get_single_data()
    data = AnsibleSequence(data)
    playbook_include.preprocess_data(data[0])
    assert playbook_include.import_playbook == 'import_playbook_playbook.yml vars'

# Generated at 2022-06-23 06:39:02.027844
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.play_context import PlayContext

    pc = PlayContext()
    loader = AnsibleLoader(None, pc, True)

    # test for importing playbook
    data = '''
- import_playbook: test_play.yaml
'''
    playbook_include = PlaybookInclude.load(data, "", loader=loader)
    # this should be the same result as the yaml above
    new_ds = playbook_include.preprocess_data(loader.get_single_data(data))
    assert new_ds == {'import_playbook': 'test_play.yaml'}

    # test for importing playbook with param 'tags'

# Generated at 2022-06-23 06:39:13.546936
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    ds = {
        'include': 'imported_playbook.yml',
        'vars': {
            'var1': 'value1',
            'var2': 'value2'
            },
        'tags': 'default'
    }
    ds_result = {
        'import_playbook': 'imported_playbook.yml',
        'vars': {
            'var1': 'value1',
            'var2': 'value2'
            },
        'tags': 'default'
    }
    assert ds_result == PlaybookInclude.load_data(ds, basedir=None).data

# Test at the end to avoid adding this function into the playbook class before its declaration

# Generated at 2022-06-23 06:39:14.064316
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-23 06:39:27.857466
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook import Playbook
    c = PlaybookInclude.load({'import_playbook': 'playbook.yml'}, '.')

    assert c.preprocess_data({'import_playbook': 'playbook.yml'}) == {
        'import_playbook': 'playbook.yml',
    }

    assert c.preprocess_data({'somevar': 'somevalue', 'import_playbook': 'playbook.yml'}) == {
        'import_playbook': 'playbook.yml',
        'somevar': 'somevalue',
    }


# Generated at 2022-06-23 06:39:28.519174
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():

    pass

# Generated at 2022-06-23 06:39:35.737152
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    '''
    Test the PlaybookInclude class
    '''
    def_playbook = {
        'playbook_import': 'playbook.yml',
    }

    playbook = PlaybookInclude.load(def_playbook, './')

    print(playbook)
    print(playbook.import_playbook)
    print(playbook.vars)
    print(playbook.tags)
    print(playbook.when)

# Generated at 2022-06-23 06:39:45.590011
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # Test defaults
    PlaybookInclude()

    # Test if parameter 'when' is not list and throwing AnsibleAssertionError
    try:
        PlaybookInclude(when='')
        assert False
    except AssertionError:
        assert True
    except:
        assert False

    # Test if parameter 'tags' is not list and throwing AnsibleAssertionError
    try:
        PlaybookInclude(tags='')
        assert False
    except AssertionError:
        assert True
    except:
        assert False

    # Test if parameter 'vars' is not dict and throwing AnsibleAssertionError
    try:
        PlaybookInclude(vars='')
        assert False
    except AssertionError:
        assert True
    except:
        assert False

# Generated at 2022-06-23 06:39:56.689641
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    obj = PlaybookInclude.load()
    result = obj.preprocess_data({'import_playbook': 'foo.yml', 'vars': {'a': 'b'}})
    assert isinstance(result, dict)
    assert result == {'import_playbook': 'foo.yml', 'vars': {'a': 'b'}}
    result = obj.preprocess_data({'import_playbook': 'foo.yml', 'tags': ['testing', 'not']})
    assert isinstance(result, dict)
    assert result == {'import_playbook': 'foo.yml', 'tags': ['testing', 'not']}
    expected = {'import_playbook': 'foo.yml', 'vars': {'a': 'b'}, 'tags': ['testing', 'not']}
    result

# Generated at 2022-06-23 06:40:08.234152
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role import Role
    from ansible.playbook.tasks.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_context import RoleContext
    from ansible.parsing.dataloader import DataLoader

    p = PlaybookInclude()

    # create a single task PlaybookInclude
    datastructure = dict(import_playbook="test/import1.yml")
    data = p.load_data(datastructure,'./',variable_manager=None, loader=DataLoader())
    assert isinstance(data, Playbook)

# Generated at 2022-06-23 06:40:10.348466
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    PlaybookInclude()
    pass

# Generated at 2022-06-23 06:40:16.893285
# Unit test for method preprocess_data of class PlaybookInclude

# Generated at 2022-06-23 06:40:27.354146
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # Create a mock object to store the load method paramters
    class mock_variable_manager(object):
        pass

    class mock_loader(object):
        pass

    # Create a dictionary to store the mock object
    mock_param_dict = dict()
    mock_param_dict['basedir']         = 'basedir'
    mock_param_dict['variable_manager']= mock_variable_manager
    mock_param_dict['loader']          = mock_loader

    # Create a PlaybookInclude class object
    PlaybookInclude_object = PlaybookInclude()

    # Invoke the load method with mock objects
    PlaybookInclude_object.load('ds',**mock_param_dict)

    # Assert to find the same mock variable manager in the args
    assert mock_param_dict['variable_manager'] == mock_variable

# Generated at 2022-06-23 06:40:39.624315
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.dataloader import DataLoader

    ds = dict(
        import_playbook="a.yml",
        private=True,
        connection="local",
    )
    basedir = 'foo' # doesn't matter for this test
    loader = DataLoader()
    obj = PlaybookInclude(loader=loader)
    nds = obj.preprocess_data(ds)
    assert 'import_playbook' in nds
    assert 'private' in nds
    assert 'connection' in nds
    assert 'tags' not in nds
    assert 'vars' not in nds

    ds = dict(
        import_playbook="a.yml",
        private=True,
        connection="local",
        vars={
            'b': 1,
        },
    )

# Generated at 2022-06-23 06:40:51.051617
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    PlaybookInclude_class = PlaybookInclude()

    # test case 1
    # default structure test
    obj = dict(
        import_playbook='docker_service.yml',
        when='some_condition',
        tags='some_tag'
    )
    ds = PlaybookInclude_class.preprocess_data(obj)
    assert ds['import_playbook'] == 'docker_service.yml'
    assert ds['when'] == 'some_condition'
    assert ds['tags'] == 'some_tag'

    # test case 2
    # test structure with params
    obj = dict(
        import_playbook='docker_service.yml some_param=some_value other_param=other_value',
        when='some_condition',
        tags='some_tag'
    )
   

# Generated at 2022-06-23 06:40:52.130017
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    """Unit test for ``PlaybookInclude.load`` method."""
    # TODO: to be implemented

# Generated at 2022-06-23 06:41:03.588318
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    '''Unit test for method preprocess_data of class PlaybookInclude'''

    # create class instance
    PlaybookInclude_class = PlaybookInclude()

    #####################
    # test 'import_playbook' parameter
    #####################
    # test 'import_playbook' with no file
    data = {'import_playbook': ''}
    result = PlaybookInclude_class.preprocess_data(data)
    assert result == {}

#     # test 'import_playbook' with file
#     data = {'import_playbook': 'file'}
#     result = PlaybookInclude_class.preprocess_data(data)
#     assert result == {'import_playbook': 'file'}

    #####################
    # test 'vars' parameter
    #####################
    # v

# Generated at 2022-06-23 06:41:14.828800
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    import sys
    import os
    import pytest
    import tempfile
    import json
    import yaml
    from copy import deepcopy
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    loader = DataLoader()
    variable_manager = VariableManager()
    inventories = []
    inventory = InventoryManager(loader=loader, sources="localhost")
    variable_manager.set_inventory(inventory)

    tmpdir = tempfile.mkdtemp()

    simple_playbook = u"""
    - hosts: all
      tasks:
        - name: a simple task
          ping:
    """

    test

# Generated at 2022-06-23 06:41:23.960882
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    class TestPlaybookInclude(PlaybookInclude):
        def __init__(self):
            super(TestPlaybookInclude, self).__init__()
            self._attributes = {}

    playbook = TestPlaybookInclude()
    assert playbook.preprocess_data({'hosts': 'hosts', 'import_playbook': 'import_playbook.yml'}) == {'hosts': 'hosts', 'import_playbook': 'import_playbook.yml'}


# Generated at 2022-06-23 06:41:29.177905
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.dataloader import DataLoader

    def do(inputs):
        for i in inputs:
            yaml = to_bytes(DataLoader().load(i, None, None))
            old_ds = AnsibleMapping.load(yaml)
            new_ds = PlaybookInclude.preprocess_data(old_ds)
            import_playbook = new_ds.get('import_playbook')
            if not import_playbook:
                raise AssertionError("import_playbook missing from new ds")
            vars_new_ds = new_ds.get('vars')
            if not vars_new_ds:
                raise AssertionError("vars missing from new ds")
            vars_old_ds = old_ds.get('vars')

# Generated at 2022-06-23 06:41:41.360496
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import os
    import sys
    import tempfile
    import pytest

    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.template import Templar

    with tempfile.NamedTemporaryFile(mode='wb', delete=False) as f:
        f.write(b'some content')
    temp_file_name = to_bytes(f.name)
    from ansible.utils.path import makedirs_safe
    makedirs_safe(temp_file_name)
    temp_file_name = os.path.join(temp_file_name, b'file.yml')

# Generated at 2022-06-23 06:41:42.033134
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-23 06:41:47.603523
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    assert PlaybookInclude
    pb = PlaybookInclude.load({'import_playbook': '../tests/import_playbook1.yml', 'vars': {
        'var1': 'c',
        'var2': 'd'}}, os.path.dirname(os.path.realpath(__file__)))
    assert pb.vars['var1'] == 'c'
    assert pb.vars['var2'] == 'd'

# Generated at 2022-06-23 06:41:56.719101
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    p = PlaybookInclude()
    playbook_path = "/Users/adam/Documents/Ansible/project/playbook.yml"
    ds = AnsibleMapping()
    ds['import_playbook'] = "%s" % playbook_path
    assert p.preprocess_data(ds)['import_playbook'] == playbook_path
    import_playbook = "playbook.yml tags=test_tag var1=test_var1"
    ds['import_playbook'] = "%s" % import_playbook
    assert p.preprocess_data(ds)['import_playbook'] == import_playbook
    assert p.preprocess_data(ds)['tags'] == 'test_tag'

# Generated at 2022-06-23 06:41:57.234623
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-23 06:42:09.426379
# Unit test for method preprocess_data of class PlaybookInclude

# Generated at 2022-06-23 06:42:19.054342
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars

    ds = AnsibleLoader(None, 'fake_yaml', True, None).get_single_data('')
    ds.ansible_pos = [0,0,0,0]
    pb = PlaybookInclude(loader=None)
    pb.vars = {}
    res = pb.preprocess_data(ds)
    assert not res, 'Should be None'
    ds['import_playbook'] = 'test.yml'
    res = pb.preprocess_data(ds)
    assert not res, 'Should be None'
    ds['tags'] = ['foo']

# Generated at 2022-06-23 06:42:32.018823
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    display = Display()
    # pylint: disable=too-many-locals
    # pylint: disable=too-many-branches
    # pylint: disable=too-many-statements
    # pylint: disable=unused-variable
    # pylint: disable=protected-access
    mock_variable_manager = None
    mock_loader = None
    mock_basedir = "."
    mock_ds = None
    mock_playbook = None
    assert PlaybookInclude.load(mock_ds,
                                mock_basedir,
                                mock_variable_manager,
                                mock_loader) is None
    playbook_include = PlaybookInclude()
    playbook_include._import_playbook = "import_playbook"
    playbook_include._vars = "vars"
   

# Generated at 2022-06-23 06:42:35.682755
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    # Constructor can't be tested if all parameters are not passed
    my_test = PlaybookInclude()
    my_test.load_data(ds=dict(), basedir="", variable_manager=None, loader=None)

# Generated at 2022-06-23 06:42:36.449126
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pass

# Generated at 2022-06-23 06:42:44.768044
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # Test that a valid data structure is unchanged
    data = { "import_playbook": "/path/to/playbook.yml", "vars": { "key": "value" } }
    expected = data
    playbook_include = PlaybookInclude()
    processed = playbook_include.preprocess_data(data)
    assert processed == expected

    # Test that import_playbook is moved to the correct field name
    data = { "playbook": "/path/to/playbook.yml", "vars": { "key": "value" } }
    expected = { "import_playbook": "/path/to/playbook.yml", "vars": { "key": "value" } }
    playbook_include = PlaybookInclude()
    processed = playbook_include.preprocess_data(data)
    assert processed == expected



# Generated at 2022-06-23 06:42:57.679153
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    from ansible.playbook.role import Role
    from ansible.template import Templar

    t = Templar(loader=None)

    data = {
        'import_playbook': "/path/to/playbook",
        'vars': {
            'foo': 'bar',
            'mojoloco': '{{mojoe}}',
        },
        'tags': ['baz', 'bah'],
        'roles': [
            {'role': 'joe'},
            {'role': 'jane', 'when': 'foo is bar'}
        ],
        'tasks': [
            {'name': 'this task'},
            {'name': 'that task'},
        ],
    }

    p = PlaybookInclude()
    p._loader = None
    p._variable_manager = None
   

# Generated at 2022-06-23 06:43:08.721120
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task import Task, TaskInclude
    from ansible.parsing.yaml.objects import AnsibleMapping

    playbook = 'import_me.yml'
    playbook_data = {'import_playbook': playbook}

    playbook_static_data = {'import_playbook': playbook}

    playbook_data_with_params = {'import_playbook': '%s foo=bar baz=foo' % playbook}
    playbook_static_data_with_params = {'import_playbook': playbook, 'vars': {'foo': 'bar', 'baz': 'foo'}}

    playbook_data_with_tags = {'import_playbook': '%s tags=mytag,another' % playbook}
    playbook_static_

# Generated at 2022-06-23 06:43:09.230319
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-23 06:43:14.083729
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    PlaybookInclude.load(dict(import_playbook='../path/to/playbook.yaml'), '.')

# Generated at 2022-06-23 06:43:23.347707
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    data = dict(
        import_playbook='base_setup.yaml',
        tags='setup',
        vars=dict(
            user_id='jerry'
        )
    )

    play = PlaybookInclude()
    play.load_data(data)

    assert play.import_playbook == 'base_setup.yaml'
    assert play.tags == ['setup']
    assert play.vars['user_id'] == 'jerry'

# Generated at 2022-06-23 06:43:35.863314
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import ansible.parsing.yaml.loader
    import ansible.parsing.yaml.objects
    from copy import deepcopy
    # create an instance of the PlaybookInclude class
    pb = PlaybookInclude()
    # construct the playbook key-value pair
    playbook_kv = ansible.parsing.yaml.loader.AnsibleLoader(None, None).construct_mapping(node=None, deep=True)
    playbook_kv.update({'include': 'all.yml', 'remote_user': 'root'})
    # construct the vars key-value pair
    vars_kv = ansible.parsing.yaml.loader.AnsibleLoader(None, None).construct_mapping(node=None, deep=True)

# Generated at 2022-06-23 06:43:42.930790
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    '''
    Unit testing for class PlaybookInclude
    '''
    pb = PlaybookInclude()
    assert pb.__class__ == PlaybookInclude
    assert pb.import_playbook == None
    assert pb.vars == dict()
    assert pb.when == None
    assert pb.tags == list()

# Generated at 2022-06-23 06:43:55.050288
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    playbook_include = PlaybookInclude()
    basedir_playbook_include = "./"

    playbook_include.import_playbook = "./test_import_playbook"
    playbook_include.vars = {"vars":"test_vars_value"}

    playbook_include.vars["include_tasks"] = "./test_include_tasks"
    playbook_include.vars["include_vars"] = "./test_include_vars"

    ds = {}
    ds["import_playbook"] = playbook_include.import_playbook
    ds["vars"] = playbook_

# Generated at 2022-06-23 06:44:06.484757
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # Mock up the information needed to instantiate a PlaybookInclude object
    ds = dict(
        some_key = 'some_value',
        import_playbook = 'test_include.yaml',
    )

    basedir = '/path/to/ansible/lib'

    # Do the instantiation
    pbi = PlaybookInclude.load(ds, basedir)

    # Verify it has the attributes we are looking for
    assert hasattr(pbi, 'some_key')

    assert hasattr(pbi, 'import_playbook')
    assert pbi.import_playbook == 'test_include.yaml'

    # Verify that original data structure was not modified
    assert 'some_key' in ds
    assert 'import_playbook' in ds



# Generated at 2022-06-23 06:44:07.637743
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass


# Generated at 2022-06-23 06:44:20.635859
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    import_playbook = "import_playbook.yml"
    import_playbook_with_vars = "import_playbook.yml var1=1 var2=2"
    import_playbook_with_tags = "import_playbook.yml tags=tag1,tag2"
    import_playbook_with_tags_and_vars = "import_playbook.yml tags=tag1,tag2 var1=1 var2=2"
    import_playbook_with_vars_and_tags = "import_playbook.yml var1=1 var2=2 tags=tag1,tag2"
    import_playbook_with_vars_in_section = "import_playbook.yml var1=1 var2=2"

# Generated at 2022-06-23 06:44:29.479923
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # Test variables
    playbook_path = '/test/path/test.yaml'
    test_parameter1 = 'test_parameter1'
    test_parameter2 = 'test_parameter2'
    test_parameter3 = 'test_parameter3'
    test_parameter4 = 'test_parameter4'
    test_parameter5 = 'test_parameter5'
    test_value1 = 'test_value1'
    test_value2 = 'test_value2'
    test_value3 = 'test_value3'
    test_value4 = 'test_value4'
    test_vars = {'parameter1': test_value1}