

# Generated at 2022-06-23 06:34:27.845852
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''
    The method load_data() of class PlaybookInclude returns the right value
    '''
    pass

# Generated at 2022-06-23 06:34:34.492711
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    p = PlaybookInclude()
    ds = dict(import_playbook='foo/bar.yml', foo='fooval')
    ds = p.preprocess_data(ds)
    assert isinstance(ds, dict)
    assert ds['import_playbook'] == 'foo/bar.yml'
    assert ds['vars'] == dict(foo='fooval')


# Generated at 2022-06-23 06:34:43.196218
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    '''
    Test PlaybookInclude class
    '''

    from ansible.playbook import Playbook

    # Test parsed the playbook. This returns a Playbook object, not a
    # PlaybookInclude object.
    # The playbook includes a task that does nothing.
    p = Playbook.load('./test/playbook_include/playbook.yml', variable_manager=None, loader=None)
    assert len(p.get_entries()) == 1

    # Test playbook import.
    # The included playbook contains a task that echos "it works".
    p = Playbook.load('./test/playbook_include/playbook_import.yml', variable_manager=None, loader=None)
    assert len(p.get_entries()) == 1

# Generated at 2022-06-23 06:34:46.367413
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pb_test = PlaybookInclude()
    assert pb_test._vars == dict()
    assert pb_test.tags == []
    assert pb_test.when == []

# Generated at 2022-06-23 06:34:56.682376
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # First test with 'include' statement, then with 'include_tasks'
    for keyword in C._ACTION_IMPORT_PLAYBOOK:

        # Test with single argument
        ds = {keyword: 'some_requested_playbook.yml'}
        new_ds = PlaybookInclude.preprocess_data(ds)
        assert new_ds == {'import_playbook': 'some_requested_playbook.yml'}

        # Test with arguments and vars
        ds = {keyword: 'some_requested_playbook.yml grab_this_var=some_value grab_this_var_too=other_value', 'vars': {'grab_all_vars': 'some_value'}}
        new_ds = PlaybookInclude.preprocess_data(ds)
        assert new_

# Generated at 2022-06-23 06:35:06.326539
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook

    # case 1: include playbook as a relative path
    include_playbook = PlaybookInclude.load({'import_playbook': 'playbook.yml'}, basedir='/etc/ansible/playbooks')
    assert isinstance(include_playbook, Playbook)
    assert include_playbook.basename == 'playbook.yml'
    assert include_playbook._entries[0].basename == 'main.yml'
    assert include_playbook._entries[0]._included_path == '/etc/ansible/playbooks'
    assert isinstance(include_playbook._entries[0], Play)

    # case 2: include playbook as a relative path with tags
    include_playbook = PlaybookInclude

# Generated at 2022-06-23 06:35:08.435290
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pb = PlaybookInclude()
    assert pb._import_playbook is None
    assert pb._vars == dict()

# Generated at 2022-06-23 06:35:14.322043
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.parsing.dataloader import DataLoader

    basedir = os.path.join(C.DATA_PATH, "vault")
    variable_manager = None
    loader = DataLoader()

    assert PlaybookInclude.load("playbook.yml", basedir, variable_manager, loader) is not None

# Generated at 2022-06-23 06:35:25.574322
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    import os

    p = PlaybookInclude()

    p.import_playbook = "test_include.yml"
    # test_include.yml contains one play
    pb = p.load_data({"name": "test_include.yml"}, basedir="test/units/lib/ansible/playbook")
    assert len(pb._entries) == 1
    assert isinstance(pb._entries[0], Play)

    # test_include.yml contains a task include line
    p.import_playbook = "test_task_include.yml"

# Generated at 2022-06-23 06:35:32.858346
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    import ansible.playbook.play_context
    import ansible.playbook.block
    import ansible.playbook.handler
    import ansible.playbook.task_include
    import ansible.playbook.vars
    import ansible.playbook.role_include
    import ansible.template
    import ansible.template.safe_eval
    import ansible.template.vars
    import ansible.vars.manager
    import ansible.parsing.yaml.objects

    # Test parameters
    playbook_include_ds = AnsibleMapping()
    playbook_include_ds.import_playbook

# Generated at 2022-06-23 06:35:42.189278
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import ansible.playbook.playbook as playbook

    # Playbook object to be loaded
    playbook_object = playbook.Playbook
    assert playbook_object is not None

    # Variable manager object to be passed to load_data
    variable_manager_object = None

    # Inventory Loader object to be passed to load_data
    inventory_loader_object = None

    # pb_include is an instance of PlaybookInclude class
    pb_include = PlaybookInclude()
    pb_include.import_playbook = 'playbook.yaml'
    data_structure = pb_include.load_data(ds=pb_include, basedir='../ansible_test/test_data')
    assert type(data_structure) == playbook_object
    assert data_structure.filename == 'playbook.yaml'


# Generated at 2022-06-23 06:35:55.208930
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Instantiate object
    playbook_include = PlaybookInclude()

    # Test AnsibleAssertionError
    try:
        playbook_include.load_data(None, None)
    except AnsibleAssertionError as ae:
        assert 'should be a dict but was a <NoneType>' in ae.message

    # Test AnsibleParserError
    try:
        playbook_include.load_data(dict(), None)
    except AnsibleParserError as ape:
        assert 'playbook import parameter is missing' in ape.message
    try:
        playbook_include.load_data(dict(import_playbook=[]), None)
    except AnsibleParserError as ape:
        assert 'playbook import parameter must be a string indicating a file path, got <class \'list\'> instead' in ape.message

# Generated at 2022-06-23 06:35:56.665556
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # TODO: write actual tests since this is intended to be used
    pass

# Generated at 2022-06-23 06:35:58.873989
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include = PlaybookInclude()
    # playbook_include.load_data()

# Generated at 2022-06-23 06:36:03.102202
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # test valid play definition
    foo = dict(
        import_playbook = "foo.yml"
    )
    play = PlaybookInclude(**foo)
    assert play.import_playbook == "foo.yml"

# Generated at 2022-06-23 06:36:07.463080
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbookinclude = PlaybookInclude()
    data = playbookinclude.load(dict(import_playbook='site.yml'))
    playbookinclude.preprocess_data(data)
    assert playbookinclude.import_playbook == 'site.yml'

# Generated at 2022-06-23 06:36:18.703608
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.utils.collection_loader._collection_finder import _get_collection_name_from_path
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.vars.manager import VariableManager
    def _test_load(playbook_name, basedir, collection_path=None):
        playbook_name = playbook_name
        basedir = basedir
        playbook_file_path = os.path.join(basedir, playbook_name)
        collection_name = _get_collection_name_from_path(playbook_file_path)
        # load playbook
        pi = PlaybookInclude()
        ds = dict(import_playbook=playbook_name)
        pb = pi.load(data=ds, basedir=basedir, variable_manager=VariableManager(), loader=None)


# Generated at 2022-06-23 06:36:30.218921
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    import os
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role

    basedir = './test/playbooks/playbooks'
    variable_manager = 'a variable manager'
    loader = 'a loader'
    ds = """
    - import_playbook: sub_playbook.yml
      vars:
        foo: bar
        baz:
          - a
          - b
          - c
      tags:
        - foo
        - bar
    """
    p = PlaybookInclude.load(ds, basedir, variable_manager, loader)
    assert isinstance(p, Playbook)
    assert len(p._entries) == 1
    entry = p._entries[0]

# Generated at 2022-06-23 06:36:37.485056
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    from ansible.parsing.yaml.objects import AnsibleMapping


    # Dummy main play
    mainPlay = AnsibleMapping()    # Create a dummy main play
    mainPlay.ansible_pos = (None, None)
    mainPlay.update({
        'hosts': AnsibleMapping(),
        'vars': AnsibleMapping(),
        'vars_files': AnsibleMapping(),
        'pre_tasks': AnsibleMapping(),
        'roles': AnsibleMapping(),
        'tasks': AnsibleMapping(),
        'post_tasks': AnsibleMapping(),
        'handlers': AnsibleMapping()
    })

    # PlaybookInclude object
    playbookInclude = AnsibleMapping()    # Create a dummy Playbook

# Generated at 2022-06-23 06:36:39.914775
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    PlaybookInclude.load(
        {
            'import_playbook': 'another_playbook.yml',
            'vars': {
                'foo': 'bar'
            }
        },
        '/'
    )
    assert True

# Generated at 2022-06-23 06:36:52.152884
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # import_playbook with just filename
    ds1 = AnsibleMapping({'import_playbook': 'vars.yml'})
    obj1 = PlaybookInclude.load_data(ds1, '~')
    assert dict(obj1.vars) == {}
    assert 'import_playbook' in obj1._attributes
    assert obj1.import_playbook == 'vars.yml'
    assert not obj1.tags
    assert not obj1.when

    # import_playbook with filename and key-value parameters
    ds2 = AnsibleMapping({'import_playbook': 'vars.yml'}, ansible_pos=42)
    obj2 = PlaybookInclude.load_data(ds2, '~')
    assert dict(obj2.vars) == {}

# Generated at 2022-06-23 06:36:53.120373
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass


# Generated at 2022-06-23 06:37:06.290854
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    import yaml

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()

    ds = yaml.safe_load("""
    - hosts: all
      tasks:
        - shell: cat /tmp/test
      roles:
        - { role: ping }
      pre_tasks:
        - setup:

      post_tasks:
        - shell: /bin/echo "hello world"
    """)

    pb = PlaybookInclude.load(ds, 'test.yml', loader=loader, variable_manager=variable_manager)
    assert isinstance(pb, Playbook)


# Generated at 2022-06-23 06:37:08.311988
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    playbook_include = PlaybookInclude()
    assert playbook_include is not None

# Generated at 2022-06-23 06:37:20.882764
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    """
    Template: playbook.include
    Context: this test case is to test load_data method of class PlaybookInclude
    Test cases:
        - empty dict()
        - dict with import_playbook
        - dict with vars
        - dict with vars and import_playbook
    """

    # Arrange
    path = "file.yml"
    basedir = "/tmp/"
    content = []
    content.append(dict())

    import_playbook = "playbook.yml"
    vars_ = dict(name="foo")
    content.append(dict(import_playbook=import_playbook))

    content.append(dict(vars=vars_))

    content.append(dict(vars=vars_, import_playbook=import_playbook))

    # Act

# Generated at 2022-06-23 06:37:28.347169
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Setup
    playbook_include = PlaybookInclude()

    # Exercise

    # Verify
    assert playbook_include.load('/invalid.yml') is not None



# Generated at 2022-06-23 06:37:37.831746
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # Test with a dictionary that is not of type
    # AnsibleBaseYAMLObject, which is the type of dict we want
    # to test.
    #
    # AnsibleBaseYAMLObject is in the ansible.parsing.yaml.objects module
    # and it is imported by the test case by a previous import of the PlaybookInclude
    # module in this same file (playbook_include.py).
    #
    # This test uses the class AnsibleAssertionError and the function
    # load_data which are both defined in the
    # ansible.playbook.playbook_include module.

    ds = dict(a=1, b=2)
    includes = PlaybookInclude()

# Generated at 2022-06-23 06:37:51.587055
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # check simple playbook import without parameters
    simple_import = "import_playbook: playbook.yml"
    new_ds = PlaybookInclude().preprocess_data(parse_kv(simple_import))
    assert "import_playbook" in new_ds
    assert "vars" not in new_ds
    assert "tags" not in new_ds
    assert new_ds["import_playbook"] == "playbook.yml"

    # check playbook import with parameters
    import_with_params = "import_playbook: playbook.yml vars: \"@params.json\" tags: tag1,tag2"
    new_ds = PlaybookInclude().preprocess_data(parse_kv(import_with_params))
    assert "import_playbook" in new_ds
    assert "vars" in new_

# Generated at 2022-06-23 06:37:52.217044
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-23 06:38:05.051692
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.template import Templar
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task import Task

    temp = Templar(loader=None, variables={})
    included_playbook = PlaybookInclude.load(dict(import_playbook='playbook_include/playbook_include.yml'), 'playbook_include/playbook_include.yml')
    assert isinstance(included_playbook, PlaybookInclude)

    try:
        # missing play or playbook
        PlaybookInclude.load(dict(import_playbook='not_exists_playbook_include.yml'), 'playbook_include/playbook_include.yml')
    except AnsibleParserError:
        pass

    # load a playbook with a

# Generated at 2022-06-23 06:38:12.944939
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Test loading empty data
    data = {}
    result = PlaybookInclude.load(data=data, basedir='.')
    assert result is None

    # Test loading simple data
    data = {'import_playbook': 'test_playbook.yml'}
    result = PlaybookInclude.load(data=data, basedir='.')
    assert result is not None


# Generated at 2022-06-23 06:38:21.893049
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    collection = """
        - hosts: local
          tasks:
            - debug:
                msg: "Hi!"
    """
    basedir = "/home"

    # define a datastructure,
    ds = dict()
    ds['import_playbook'] = "./test.yml"
    ds['vars'] = dict(test="test")
    ds['tags'] = "test"
    ds['when'] = "test"
    ds['start_at_task'] = "test"

    pb = PlaybookInclude()
    loader = DataLoader()
    pb = pb.load_data(ds, basedir, loader=loader)

# Generated at 2022-06-23 06:38:33.231043
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.hosts import Hosts

    basedir = os.path.abspath(".")

    mypb = PlaybookInclude()
    data = {"import_playbook": "../first_playbook.yml", "vars": {"param1": "value1" }, "tags": "tag1,tag2"}
    parent_pb = Playbook()
    parent_pb.vars = {"param0": "value0"}
    parent_pb._included_path = "/tmp/"
    mypb.load_data(ds=data, basedir=basedir)
    assert isinstance(mypb, PlaybookInclude)

# Generated at 2022-06-23 06:38:43.065056
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # PlaybookInclude should inherit from Base, Conditional, and Taggable
    conditional = PlaybookInclude.load(dict(when="2 > 3"), basedir=".")
    for cls in (Base, Conditional, Taggable):
        assert isinstance(conditional, cls)

    # Test to make sure the preprocess_data() function just works
    with open("../../test/units/parsing/yaml/fixtures/playbook_include.yml", "rb") as yaml_file:
        data = yaml_file.read()
    playbook_include = PlaybookInclude.load(data, basedir=".")
    assert playbook_include.import_playbook == "other.yml"
    assert playbook_include.tags == set(["debug"])

# Generated at 2022-06-23 06:38:43.747386
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-23 06:38:44.982405
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-23 06:38:59.428028
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os
    import sys
    import tempfile
    import shutil
    import io
    import yaml
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault_init import VaultEditor
    from ansible.parsing.vault import VaultSecret
    from ansible.playbook.play import Play
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.tasks import Task
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils._text import to_bytes, to_text

    # Suppress DeprecationWarnings
    import warnings
    warnings.simplefilter("ignore")

    # Create temp directory, and move to it
    old

# Generated at 2022-06-23 06:39:00.063360
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass #TODO

# Generated at 2022-06-23 06:39:04.926191
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Test no playbook file
    try:
        PlaybookInclude.load(data={"import_playbook": None}, basedir="")
        assert False
    except AnsibleParserError as e:
        assert e.message == "playbook import parameter is missing"

    # Test the playbook file is empty string
    try:
        PlaybookInclude.load(data={"import_playbook": ""}, basedir="")
        assert False
    except AnsibleParserError as e:
        assert e.message == "playbook import parameter must be a string indicating a file path, got %s instead" % type(str())

    # Test the playbook file is not string
    try:
        PlaybookInclude.load(data={"import_playbook": {}}, basedir="")
        assert False
    except AnsibleParserError as e:
        assert e

# Generated at 2022-06-23 06:39:16.894123
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.vault import vault_decrypt_file
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

    playbook_file = vault_decrypt_file("test/playbooks/ansible-playbook-include-test-playbook.yml", "ansible")

    playbook = Playbook.load(playbook_file, variable_manager=None, loader=None)

    vars_playbook = playbook._entries[0]
    assert isinstance(vars_playbook, Play) and vars_playbook.name == "include_var_playbook"

# Generated at 2022-06-23 06:39:19.022484
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pi = PlaybookInclude()
    print(pi)

# Generated at 2022-06-23 06:39:20.610160
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-23 06:39:23.384777
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include = PlaybookInclude()
    # Only test if the method exists
    assert playbook_include.load_data

# Generated at 2022-06-23 06:39:24.020550
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-23 06:39:28.786313
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    ds = {
        'import_playbook': 'test_playbook_include.yml var1=foo var2=bar',
        'vars': {'var3': 'value'},
        'when': "ansible_distribution == 'Debian'"
    }
    obj = PlaybookInclude()
    new_ds = obj.preprocess_data(ds)
    assert new_ds == {
        'import_playbook': 'test_playbook_include.yml',
        'tags': 'var1=foo,var2=bar',
        'when': ["ansible_distribution == 'Debian'"],
        'vars': {'var3': 'value'}
    }

# Generated at 2022-06-23 06:39:41.869344
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.template import Templar

    ds = { 'include' : 'some_file'}
    t = Templar(loader=None, variables=dict())
    loader = None
    variable_manager = None
    pb = PlaybookInclude.load(ds, basedir='', variable_manager=variable_manager, loader=loader)
    expected_ds = AnsibleMapping()
    expected_ds['import_playbook'] = 'some_file'
    assert pb.preprocess_data(ds) == expected_ds

    ds = {'import_playbook': 'some_file'}
    pb = Play

# Generated at 2022-06-23 06:39:54.518928
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    p = PlaybookInclude(import_playbook='/path/to/foo.yml', tags=['mytag'], vars={'foo': 'bar'}, when={'condition': 'True'})
    assert p.load_data({'import_playbook': '/path/to/foo.yml', 'tags': ['mytag'], 'vars': {'foo': 'bar'}, 'when': {'condition': 'True'}}, basedir='/path/to')
    # p.load_data should return a new Playbook object.
    assert isinstance(p, PlaybookInclude)
    assert p.import_playbook == '/path/to/foo.yml'
    assert p.tags == ['mytag']
    assert p.vars == {'foo': 'bar'}

# Generated at 2022-06-23 06:40:05.899344
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # import here to avoid a dependency loop
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    pb = PlaybookInclude()
    data = {'import_playbook': 'foo.yml'}
    pb.load_data(data, '/tmp')
    assert pb.import_playbook == 'foo.yml'
    assert pb.vars == {}
    assert pb.tags == []
    assert pb.when == []

    data = {'import_playbook': 'foo.yml', 'tags': 'a, b, c'}
    pb.load_data(data, '/tmp')
    assert pb.import_playbook == 'foo.yml'
    assert pb.tags == ['a', 'b', 'c']
    assert p

# Generated at 2022-06-23 06:40:18.875410
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    ds = {'import_playbook': './test/playbooks/include1.yml', 'vars': {'var': 'value'}}
    # we need to also pass the connection to reload
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['127.0.0.1'])
    variable_manager.set_inventory(inventory)
    pb = PlaybookInclude.load(ds, './test/playbooks', variable_manager=variable_manager, loader=loader)
    assert pb.entries[0].hosts == 'world'
    assert pb.entries

# Generated at 2022-06-23 06:40:20.862611
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pbi = PlaybookInclude()
    assert pbi is not None
    assert type(pbi) is PlaybookInclude

# Generated at 2022-06-23 06:40:31.483483
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    try:
        test_data = '''
        import_playbook: test_playbook.yml
        tags: test
        vars:
          test_var: test_val
        '''
        PlaybookInclude.load(data=test_data, basedir='/tmp')
    except Exception as e:
        raise Exception("\nTest Failed: PlaybookInclude.load_data() should not have thrown an exception")


# Generated at 2022-06-23 06:40:39.044159
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    loader = DictDataLoader({})
    variable_manager = VariableManager()
    import_playbook_instance = PlaybookInclude()
    ds = dict(
        import_playbook="playbook.yml",
        vars=dict(
            foo="bar"
        )
    )
    p = import_playbook_instance.preprocess_data(ds)
    assert p == ds

# Generated at 2022-06-23 06:40:40.513358
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass


# Generated at 2022-06-23 06:40:46.903818
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play
    include_1 = PlaybookInclude.load(dict(include="foo.yml"), basedir=None)
    assert not isinstance(include_1, Play)
    include_2 = PlaybookInclude.load(dict(import_playbook="foo.yml"), basedir=None)
    assert isinstance(include_2, Play)

# Generated at 2022-06-23 06:40:51.279233
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    obj = PlaybookInclude("somefile.yml")
    assert obj._import_playbook == "somefile.yml"
    assert obj._vars == {}

    obj = PlaybookInclude("somefile.yml", vars={"foo":"bar"})
    assert obj._import_playbook == "somefile.yml"
    assert obj._vars == {"foo":"bar"}

# Generated at 2022-06-23 06:40:51.942513
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-23 06:41:00.310811
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_str = """
    - include_tasks: test_include_tasks.yml
        vars: var_for_include_tasks
    - import_playbook: test_import_playbook.yml
        vars: var_for_import_playbook1
    - import_playbook: test_import_playbook.yml varvar=var_for_include_tasks
        vars: var_for_import_playbook2
    """
    obj = PlaybookInclude().load_data(ds=dict(), basedir='', variable_manager=None, loader=None)
    ds = obj.load_data(ds=playbook_str, basedir='', variable_manager=None, loader=None)

# Generated at 2022-06-23 06:41:12.389862
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    import yaml
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test PlaybookInclude.__init__():
    p1 = PlaybookInclude()
    assert p1.import_playbook is None
    assert p1.tags == []
    assert p1.vars == {}

    # Test PlaybookInclude._load_tags():
    p2 = PlaybookInclude()
    p2.tags = ['t1', 't2', 't3']
    assert p2.tags == ['t1', 't2', 't3']

    # Test PlaybookInclude._preprocess_data():
    p3 = PlaybookInclude()

# Generated at 2022-06-23 06:41:25.306328
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    import ansible.plugins.loader as plugin_loader


# Generated at 2022-06-23 06:41:36.306184
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # paramters of the instance which we need to check
    import_playbook = 'include_playbook.yml'
    var = {'var1': 'value1'}
    tags = ['tag1', 'tag2']

    # create a new instance of PlaybookInclude
    pbinclude = PlaybookInclude()

    # create the data structure to be preprocessed
    ds = dict()

    # check if the import_playbook was correctly processed
    ds[k] = v
    pbi_ds = pbinclude.preprocess_data(ds)
    assert pbi_ds['import_playbook'] == import_playbook

    # check if the vars were correctly processed
    ds = dict()
    ds['vars'] = var

# Generated at 2022-06-23 06:41:46.526157
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook

    # Scenario 1: Test object creation for PlaybookInclude
    playbooks = set()

    # Execute test
    pb_incl = PlaybookInclude()
    playbooks2 = pb_incl.load(data='testdata', basedir='testbasedir', variable_manager='testvar', loader='testload')

    # Verify results
    assert playbooks == playbooks2

    # Scenario 2: Test object creation for PlaybookInclude
    # Execute test
    playbooks = set()

    # Execute test
    pb_incl = PlaybookInclude()
    playbooks2 = pb_incl.load(data='testdata', basedir='testbasedir', variable_manager='testvar', loader='testload')

    # Verify results
    assert playbooks2

# Generated at 2022-06-23 06:41:56.974903
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # test for FQCN
    playbook = PlaybookInclude.load(data={"import_playbook": "@namespace.collection/path/to/playbook.yaml"}, basedir=".")
    assert playbook.entries[0].hosts == "all"
    assert playbook.entries[0].connection == "local"

    # test for relative path
    playbook = PlaybookInclude.load(data={"import_playbook": "path/to/playbook.yaml"}, basedir=".")
    assert playbook.entries[0].hosts == "all"
    assert playbook.entries[0].connection == "local"

    # test for absolute path
    playbook = PlaybookInclude.load(data={"import_playbook": "/path/to/playbook.yaml"}, basedir=".")

# Generated at 2022-06-23 06:42:03.852448
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.parsing.yaml.objects import AnsibleSequence
    # Constructor 1
    pbi = PlaybookInclude({})

    # Constructor 2
    v = {'import_playbook': '/path/to/playbook.yml', 'vars': {}}
    result = pbi.load_data(v, basedir='/path/to')

    assert isinstance(result, AnsibleSequence)
    assert isinstance(result._entries, list)

# Generated at 2022-06-23 06:42:15.498679
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    import_playbook = PlaybookInclude()


    with pytest.raises(AnsibleAssertionError):
        import_playbook._preprocess_import('/dev/null', {}, '', 'value')


    # test playbook include with string playbook parameter
    ds = AnsibleMapping()
    ds['import_playbook'] = 'test_playbook.yml'
    import_playbook.preprocess_data(ds)

    # test playbook include with playbook file and tags
    ds = AnsibleMapping()
    ds['import_playbook'] = 'test_playbook.yml tags=tag1,tag2'
    import_playbook.preprocess_data(ds)

    # test playbook include with playbook file and tags and vars
    ds = AnsibleMapping()

# Generated at 2022-06-23 06:42:28.683573
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.play import Play

    # a test playbook to include

# Generated at 2022-06-23 06:42:40.319982
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    import tempfile
    import shutil
    import os
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    ds_str = """
    - import_playbook: test_pb.yml
      vars:
        vr1: 11
        vr2: 12
        vr4: 14
        vr3: 13
    """
    ds = AnsibleLoader(ds_str, file_name='/test_pb_include.yml').get_single_data()

    # create temp directory for testing
    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-23 06:42:48.313943
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    include = PlaybookInclude.load({'include': 'test.yml'}, loader=loader)
    assert include.import_playbook == 'test.yml'
    include = PlaybookInclude.load({'import_playbook': 'test.yml'}, loader=loader)
    assert include.import_playbook == 'test.yml'
    include = PlaybookInclude.load({'include': 'test.yml tags=foo vars=bar: baz'}, loader=loader)
    assert include.import_playbook == 'test.yml'
    assert include.tags == ['foo']
    assert include.vars['bar'] == 'baz'

# Generated at 2022-06-23 06:42:59.701665
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    from ansible.playbook.playbook import Playbook

    plain_pb = PlaybookInclude(import_playbook='/tmp/a.yaml', vars={'foo': 'bar'})
    assert plain_pb.included_path is None
    assert plain_pb.import_playbook == '/tmp/a.yaml'
    assert plain_pb.vars['foo'] == 'bar'

    pb = Playbook.load(filename='/dev/null', variable_manager=None)
    pb.basedir = '/tmp'
    result_pb = plain_pb.load(basedir=pb.basedir, variable_manager=None)
    assert result_pb.filename == '/tmp/a.yaml'

    pb = Playbook.load(filename='/dev/null', variable_manager=None)
    p

# Generated at 2022-06-23 06:43:05.387109
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # noinspection PyProtectedMember
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.template import Templar

    yaml_result = {
        'import_playbook': 'test.yml',
        'vars': {
            'foo': 'bar'
        },
        'tags': 'tag1,tag2',
    }
    yaml_data = AnsibleMapping(yaml_result)

    playbook = Playbook()
    templar = Templar(None)

# Generated at 2022-06-23 06:43:15.493634
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    #Check for all the possible errors
    #1) When playbook file is not specified
    ds = AnsibleMapping()
    ds['import_playbook'] = None
    p = PlaybookInclude()
    try:
        p.preprocess_data(ds)
    except AnsibleParserError as e:
        assert str(e) == "import_playbook parameter is missing"
    #2) When playbook file is not string
    ds = AnsibleMapping()
    ds['import_playbook'] = 'ansible-playbook'
    p = PlaybookInclude()
    try:
        p.preprocess_data(ds)
    except AnsibleParserError as e:
        assert str(e) == "playbook import parameter must be a string indicating a file path, got <class 'str'> instead"
    #3

# Generated at 2022-06-23 06:43:26.673301
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    import_playbook_1 = """
        # This is a playbook include -*- yaml -*-

        - import_playbook: name1
          vars:
              var1: 1
              tags: tag1, tag2
    """
    import_playbook_2 = """
        # This is a playbook include -*- yaml -*-

        - import_playbook: name2
          params:
              var2: 2
              tags: tag2,tag3
    """
    import_playbook_3 = """
        - import_playbook: name3
          vars:
              var3: 3
          params:
              var4: 4
              tags: tag4, tag5
    """
    import_playbook_4 = """
        - import_playbook: name4
          var5: 5
    """



# Generated at 2022-06-23 06:43:35.317744
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # Test for good case

    # create a variable manager, add a variable and populate it with a dict
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    mgr = VariableManager()
    mgr.extra_vars = {'var1': {'key1': 'value1', 'key2': 'value2'}}
    templar = Templar(mgr)

    # create a playbook_include object and populate it with data
    playbook_include = PlaybookInclude()

# Generated at 2022-06-23 06:43:46.953291
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    loader = TestDummyFileLoader()
    data = {
        'import_playbook': 'playbook.yaml',
        'connection': 'local',
        'vars': {'x': 'y'},
    }
    base_dir = './'
    variable_manager = TestDummyVars()

    obj = PlaybookInclude.load(data, base_dir, variable_manager, loader)
    obj.post_validate(templar=Templar(loader=loader, variables={}))
    assert isinstance(obj, PlaybookInclude)
    assert obj.import_playbook == 'playbook.yaml'
    assert obj.vars['x'] == 'y'
    assert obj.connection == 'local'



# Generated at 2022-06-23 06:43:56.880950
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleSequence
    import sys

    ds_simple = 'test.yml'
    ds_pos = AnsibleSequence([ 'test.yml' ],
                             pos='/home/someuser/playbook.yml:3')
    ds_params = 'test.yml tags=tag1,tag2'
    ds_vars = { 'vars' : { 'foo' : 'bar' } }

    pbi = PlaybookInclude()
    new_ds = pbi.preprocess_data(ds_simple)
    assert isinstance(new_ds, AnsibleMapping)
    assert 'import_playbook' in new_ds
    assert 'vars' in new_ds
    assert 'tags' not in new_ds
    assert new

# Generated at 2022-06-23 06:44:08.747954
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude

    # input datastructure to be tested

# Generated at 2022-06-23 06:44:19.230998
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader

    basedir = os.path.dirname(os.path.resolve_path('../../test/playbooks/playbook_include.yml', __file__))
    loader = DataLoader()
    pb_incl_path = '../../test/playbooks/playbook_include.yml'
    pb_incl_path = os.path.join(basedir, pb_incl_path)
    ds = loader.load_from_file(pb_incl_path)

    PlaybookInclude.load(ds, basedir, loader=loader)

# Generated at 2022-06-23 06:44:30.870720
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    '''
    Unit test for constructor of class PlaybookInclude
    '''
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    # data structure for PlaybookInclude
    data = dict(
        import_playbook='../../../../ansible/test/sanity/collection/ansible_collections/ntc/ntc_show_command/playbooks/test_show.yml',
        when='inventory_hostname == "localhost"',
        connection='local',
        tags=['all', 'foo'],
        vars=dict(
            username='root',
            password='pass123'
        )
    )
    #