

# Generated at 2022-06-23 06:34:36.525706
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''
    Test load data method of class PlaybookInclude
    '''
    load_data = PlaybookInclude.load_data
    playbook = load_data.__func__

    import ansible.playbook
    # setup test objects
    basedir = 'test/unit/test_playbook_include/'
    variable_manager = None
    loader = ansible.playbook.Playbook.loader
    load_data = PlaybookInclude.load_data
    ds = {
        "tasks":[
            {
                "debug":
                {
                    "msg":"playbook1"
                }
            }
        ]
    }
    new_obj = PlaybookInclude()
    # test with wrong ds type

# Generated at 2022-06-23 06:34:44.354734
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # Make sure the variable manager is ready
    variable_manager = VariableManager()
    variable_manager.extra_vars = load_extra_vars(loader=None, options=None, passwords=None)

    # Test for a conditional that is just a string
    ds = { 'playbook': 'example.yml' }
    new_obj = PlaybookInclude.load(ds, basedir=os.getcwd(), variable_manager=variable_manager)

    # Should be a list of plays
    assert isinstance(new_obj.get_entries(), list)

    # TODO: This is failing, probably need to load the playbooks before we can test
    #assert new_obj.get_entries()[0].name == 'Example Play'

    # Test for a conditional that is an array

# Generated at 2022-06-23 06:34:55.263364
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    # Construct an object of class PlaybookInclude with a valid argument
    pbi = PlaybookInclude(import_playbook="/path/to/import.yml")

    # Check if the constructor worked properly
    assert pbi._import_playbook == "/path/to/import.yml"
    assert pbi._vars == {}
    assert pbi._attributes == dict(import_playbook="/path/to/import.yml", vars={})

    # Construct an object of class PlaybookInclude with a None argument
    try:
        pbi = PlaybookInclude(import_playbook=None)
        assert False
    except AnsibleParserError:
        assert True

    # Construct an object of class PlaybookInclude with a non-string argument

# Generated at 2022-06-23 06:35:04.941866
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    #check:
    # - use of vars as part of import_playbook
    # - use of vars in the normal 'vars' key
    # - use of tags as part of import_playbook
    pb_include = PlaybookInclude.load({
        'import_playbook': 'pb.yml vars="k1=v1 k2=v2 k3=v3 tags=tag1,tag2"',
        'vars': {'k4': 'v4', 'k5': 'v5'},
    }, '')
    pb_include.validate()
    assert pb_include.vars == {'k1': 'v1', 'k2': 'v2', 'k3': 'v3', 'k4': 'v4', 'k5': 'v5'}
    assert p

# Generated at 2022-06-23 06:35:15.586082
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager)

# Generated at 2022-06-23 06:35:20.533625
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    ds = PlaybookInclude.load({
        'import_playbook': 'test.yml',
        'vars': {'foo': 'bar'},
        'tags': ['baz']
    }, os.path.dirname(__file__))
    assert isinstance(ds, Playbook)
    assert isinstance(ds._entries[0], Play)
    assert ds.vars == {}
    assert ds._entries[0].vars == {'foo': 'bar'}
    assert ds._entries[0].tags == ['baz']
    assert ds._entries[0].name == 'test.yml'


# Generated at 2022-06-23 06:35:30.073911
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.handler import Handler
    from ansible.module_utils.six import binary_type

    assert pb_include.load({'import_playbook': 'test.yml'}) == PlaybookInclude(import_playbook = 'test.yml')
    assert pb_include.load({'import_playbook': 'test.yml', 'vars': {'myvar': 'hello'}}) == PlaybookInclude(import_playbook = 'test.yml', vars = {u'myvar': u'hello'})

# Generated at 2022-06-23 06:35:34.773913
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    old_ds = AnsibleMapping()
    old_ds['import_playbook'] = "../playbooks/subplay.yml"
    old_ds['vars'] = {"var_A":"value A"}
    old_ds['tags'] = "tag1,tag2"

    new_ds = AnsibleMapping()
    new_ds['import_playbook'] = "../playbooks/subplay.yml"
    new_ds['vars'] = {"var_A":"value A"}
    new_ds['tags'] = "tag1,tag2"

    pb = PlaybookInclude()
    ds = pb.preprocess_data(ds=old_ds)

    assert ds == new_ds

# Generated at 2022-06-23 06:35:47.506523
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # TestCase 1
    ds = AnsibleMapping()
    ds['import_playbook'] = './playbook.yml'
    ds['vars'] = 'test'
    try:
        PlaybookInclude.preprocess_data(ds)
    except AnsibleParserError as pe:
        assert str(pe) == "vars for import_playbook statements must be specified as a dictionary"

    # TestCase 2
    ds = AnsibleMapping()
    ds['import_playbook'] = './playbook.yml'
    ds['vars'] = {}

# Generated at 2022-06-23 06:35:48.857291
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    """ Unit test for method load_data of class PlaybookInclude"""


# Generated at 2022-06-23 06:35:51.495618
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    plin = PlaybookInclude()
    assert plin


# Generated at 2022-06-23 06:35:52.100189
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-23 06:35:57.073095
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook import Playbook
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar

    # load_data test:
    # load_data test:
    # load_data test:

    # load data with temp playbooks and a var manager
    loader = DataLoader()
    vars_manager = VariableManager(loader=loader)
    inventory = InventoryManager

# Generated at 2022-06-23 06:36:06.931170
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import tempfile
    import shutil
    import sys


# Generated at 2022-06-23 06:36:18.388108
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar

    # Set up basic environment
    loader = AnsibleLoader(None, vault_password_files=[],
                           vault_ids=[])
    result = AnsibleMapping()
    templar = Templar(loader=loader)

    # Test good data
    entry = AnsibleMapping()
    entry.update({'playbook': 'test.yml'})
    entry.update({'tags': 'test_tag'})
    entry.update({'vars': {'foo1': 'bar1'}})

# Generated at 2022-06-23 06:36:30.148693
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play

    # Testing a valid playbook
    basedir = os.path.abspath(os.path.dirname(__file__))

    file_name = 'test_play.yml'
    pb = PlaybookInclude()

    pb.vars = dict(var1='var1')

    pb.import_playbook = 'test_play.yml'

    playbook = pb.load_data(ds=pb.vars, basedir=basedir)

    assert playbook.basedir == basedir
    assert playbook.filename == file_name
    assert playbook.get_variable_manager() == None

    # Testing a playbook with Vars

# Generated at 2022-06-23 06:36:32.584471
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    """
    PlaybookInclude:test_PlaybookInclude_load
    """
    # Add test here
    #
    #
    #
    #
    #
    #
    pass

# Generated at 2022-06-23 06:36:43.343905
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # test some invalid data structures
    # test empty
    ds = {}
    pbi = PlaybookInclude()
    try:
        pbi.preprocess_data(ds)
        assert False, "Shouldn't get here"
    except AnsibleAssertionError:
        pass

    # test wrong type
    ds = []
    try:
        pbi.preprocess_data(ds)
        assert False, "Shouldn't get here"
    except AnsibleAssertionError:
        pass

    # test with no import_playbook
    ds = {'name': 'import_none', 'test_tags': 'some_tag'}
    ds2 = pbi.preprocess_data(ds)
    assert ds2 == ds, ds2

    # test with import_playbook alone
    d

# Generated at 2022-06-23 06:36:54.764576
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    #
    # Introspect to find the filename and lineno of the code currently
    # being executed.
    #
    import inspect
    frame = inspect.currentframe()
    caller_filename = inspect.getframeinfo(frame).filename
    caller_lineno = frame.f_lineno

    #
    # Set up the structure of the object that is usually deserialised
    # from a YAML file.
    #
    ds = AnsibleMapping()
    ds.ansible_pos = caller_filename + ':' + str(caller_lineno)
    ds['tasks'] = AnsibleMapping()
    ds['tasks']['name'] = 'INCLUDE TEST'

# Generated at 2022-06-23 06:37:07.051387
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    loader = DataLoader()

    p = Playbook.load("include.yml", loader=loader, variable_manager=VariableManager())
    assert p.get_variable_manager().get_vars() == {'foo': 'bar'}

    assert isinstance(p.get_entries()[0], Task)
    assert p.get_entries()[0].get_name() == 'task1'

    assert isinstance(p.get_entries()[1], Task)

# Generated at 2022-06-23 06:37:16.030573
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    playbookClass = PlaybookInclude()
    assert playbookClass.when is None
    assert playbookClass.vars == {}
    assert playbookClass.tags == []

    playbookClass = PlaybookInclude(when=['foo'], tags=['bar'], vars={'baz': 'qux'})
    assert playbookClass.when == ['foo']
    assert playbookClass.vars == {'baz': 'qux'}
    assert playbookClass.tags == ['bar']

# Generated at 2022-06-23 06:37:25.644770
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handlers.task import TaskHandler

    # Test with a simple include
    ds = dict(import_playbook='playbook2.yml')
    pb = Playbook()
    # Note that we are using the load_data method of PlaybookInclude
    # rather than the load method in order to get a return value
    # This is the method that is called by Playbook.load
    pb = PlaybookInclude.load(ds, basedir='.')
    assert len(pb._entries) == 1
    assert isinstance(pb._entries[0], Play)

    # Test

# Generated at 2022-06-23 06:37:36.831017
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    import os
    import sys
    import copy
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude

    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.playbook_include import _get_collection_name_from_path, _get_collection_playbook_path
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.module_utils._text import to_bytes

    from .test_playbook import TestPlaybookCommon
    from .test_play import TestPlayCommon


# Generated at 2022-06-23 06:37:50.772066
# Unit test for method preprocess_data of class PlaybookInclude

# Generated at 2022-06-23 06:37:54.960457
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    assert PlaybookInclude(import_playbook='test_1.yml',
                           vars={'host': 'host1'},
                           tags=['t1', 't2'],
                           when=['x=="y"', 'y=="x"'])

# Generated at 2022-06-23 06:38:06.567972
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.module_utils._text import to_text
    from ansible.playbook import Play

    ParentPlay = Play.load({
        'hosts': 'localhost',
        'connection': 'local'
    })

    import_playbook_path = os.path.join(C.DEFAULT_LOCAL_TMP, 'load_test_pb')
    import_playbook_content = '''
- hosts: localhost
  name: TASK 1
- hosts: remote_host
  name: TASK 2
'''

    with open(import_playbook_path, 'w') as pb_fd:
        pb_fd.write(to_text(import_playbook_content, encoding='utf-8'))


# Generated at 2022-06-23 06:38:19.095380
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    playbookPath = 'docs/examples/ansible-examples/test_PlaybookInclude/load.yml'
    playbookFile = open(playbookPath, 'r')
    playbookData = playbookFile.read()
    playbookFile.close()

    playbook = PlaybookInclude.load(
        data=playbookData,
        basedir="docs/examples/ansible-examples/test_PlaybookInclude"
    )

    assert playbook.vars['new_var'] == 'value of new_var'
    assert playbook.import_playbook == 'test.yml'

    assert len(playbook._entries) == 2
    assert playbook._entries[0].hosts == 'host1'
    assert playbook._entries[1].hosts == 'host3'


# Generated at 2022-06-23 06:38:22.745188
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
# TODO: it is difficult to test this, because we need to mock the loader object
#       and the file processing. this should be mocked.
    pass


# Generated at 2022-06-23 06:38:23.284756
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-23 06:38:34.025962
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    import unittest

    class TestPlaybookIncludeClass(unittest.TestCase):
        def setUp(self):
            import ansible.playbook.play_context
            self.pc = ansible.playbook.play_context.PlayContext()
            if not os.path.exists("/tmp/ansible_playbook_include_test"):
                os.makedirs("/tmp/ansible_playbook_include_test")
            f = open("/tmp/ansible_playbook_include_test/playbook.yaml", "w")
            f.write("- hosts: all\n  tasks:\n    - debug: var=hostvars")
            f.close()

        def tearDown(self):
            import shutil

# Generated at 2022-06-23 06:38:45.373613
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import ansible.playbook.play_context
    import ansible.template
    import ansible.vars.manager

    fake_ds_with_vars = {
        'hosts': 'host_name',
        'vars': {
            'var1': '1',
            'var2': '2'
        }
    }

    fake_ds_without_vars = {
        'hosts': 'host_name',
        'tasks': [
            {
                'name': 'debug1'
            },
            {
                'name': 'debug2'
            }
        ]
    }

    # This is a real world example of the structure that may come from a playbook
    # imported by PlaybookInclude

# Generated at 2022-06-23 06:38:59.691280
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    import sys
    import os

    current_sys_argv = sys.argv

    # Note: we cannot use os.path.join here, as the return value of os.path.join() is platform specific
    # so we just use the forward slash / instead.
    this_dir = os.path.dirname(os.path.realpath(__file__))
    # We need to specify the full path for playbook_include_test.yml to make the test work under Windows
    file_name = this_dir + "/playbook_include_test.yml"
    sys.argv = [file_name]

    # load playbook
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook

# Generated at 2022-06-23 06:39:03.583207
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.parsing.dataloader import DataLoader
    p = PlaybookInclude()
    p.load(dict(import_playbook='{{ playbook_path }}/sub-playbook.yml', vars=dict(extra_var=True)), basedir='.', loader=DataLoader())

# Generated at 2022-06-23 06:39:14.184751
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    PlaybookIncludeData = {
        'import_playbook': '../../playbook/playbook3.yml',
        'tags': 'setup,cleanup',
        'vars': {
            'var1': 'value1',
            'var2': 'value2',
        }
    }

    p = PlaybookInclude().load(PlaybookIncludeData, '/path/to/basedir/')
    assert p.import_playbook == ('../../playbook/playbook3.yml')
    assert p.tags == ['setup', 'cleanup']
    assert p.vars == {'var1': 'value1', 'var2': 'value2'}

# Generated at 2022-06-23 06:39:25.312261
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    task = {'tasks': [{'import_tasks': 'tasks/first_task.yml'},
                      {'include_tasks': 'tasks/second_task.yml'},
                      {'include_role': 'roles/first_role'}]}
    playbook = PlaybookInclude().load_data(data=task, basedir='/CWD/')
    assert playbook._entries[0].name == 'tasks/first_task.yml'
    assert playbook._entries[1].name == 'tasks/second_task.yml'
    assert playbook._entries[2].name == 'roles/first_role'

# Generated at 2022-06-23 06:39:38.180157
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # file name
    assert PlaybookInclude.load({'import_playbook': '../my.yml'})

    # file with extra spaces
    assert PlaybookInclude.load({'import_playbook': ' ../my.yml '})

    # file name with parameters
    assert PlaybookInclude.load({'import_playbook': ' ../my.yml tag1=foo'})
    assert PlaybookInclude.load({'import_playbook': ' ../my.yml foo=bar'})
    assert PlaybookInclude.load({'import_playbook': ' ../my.yml foo=bar tag1=foo'})

    # invalid data

# Generated at 2022-06-23 06:39:46.307094
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.module_utils.six import PY2
    from ansible.plugins.loader import action_loader
    from ansible.module_utils.six import string_types

    # Create the inventory, and feed the host and group variables into it
    def get_action_plugin(action):
        return action_loader.get(action, class_only=True)

    new_include = PlaybookInclude()
    assert isinstance(new_include, PlaybookInclude)

    # set import_playbook
    new_include.import_playbook = 'tasks/test.yml'
    assert new_include.import_playbook == 'tasks/test.yml'

    # set tags
    new_include

# Generated at 2022-06-23 06:39:56.957676
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    test_data = """
    - hosts: localhost
      tasks:
      - import_playbook: test.yaml
      - import_playbook:
          file: ../TestPlaybooks/play-import.yaml
          tags:
            - test
    """
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    data = loader.load(test_data)

    # Create the inventory and pass to var manager
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    p = PlaybookInclude.load(data[0], loader=loader, variable_manager=variable_manager)

    assert isinstance

# Generated at 2022-06-23 06:40:07.430413
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    import os
    import re

    # Initialize a PlaybookInclude object
    plugin_obj = PlaybookInclude()

    # Check if import_playbook parameter is missing
    try:
        plugin_obj.preprocess_data({'import_playbook': None})
        assert False, 'Invalid import_playbook: missing import_playbook parameter'
    except AnsibleParserError:
        assert True

    # Check if import_playbook filename is not specified
    try:
        plugin_obj.preprocess_data({'import_playbook': ' '})
        assert False, 'Invalid import_playbook: missing filename to import'
    except AnsibleParserError:
        assert True

    # Check if import_playbook filename is not specified (test case insensitive)

# Generated at 2022-06-23 06:40:15.624624
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.taggable import Taggable
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    ds = 'yaml'
    basedir = '.'
    variable_manager = 'VariableManager'
    loader = 'AnsibleLoader'

    # test when import_playbook is missing
    my_playbook_include = PlaybookInclude()
    expected_result = AnsibleParserError
    try:
        my_playbook_include.load_data(ds, basedir, variable_manager, loader)
    except (AnsibleParserError, AnsibleAssertionError) as e:
        assert isinstance(e, expected_result)
    else:
        assert False

    # test when

# Generated at 2022-06-23 06:40:31.567048
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.play import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    import ansible.playbook.playbook

    p = ansible.playbook.playbook.PlayBook()
    name = "myplay"
    play = Play().load({
        "hosts": "webservers",
        "name": name,
        "tasks": [{"action": "debug", "msg": "hello world"}],
    }, p._basedir, variable_manager=None, loader=None)
    p._entries.append(play)
    p._filenames.append("my.yml")
    assert p.filenames == ["my.yml"]
    assert p.get_depended

# Generated at 2022-06-23 06:40:32.270732
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    PlaybookInclude()

# Generated at 2022-06-23 06:40:45.252760
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():

    display.verbosity = 3
    display.deprecation = True

    pb = PlaybookInclude.load(
        {
            'import_playbook': 'import_playbook/play.yaml',
            'tags': 'all'
        },
        basedir='/tmp',
    )

    assert 'playbook_name' in pb._entries[0]._attributes
    assert pb._entries[0]._attributes['playbook_name'] == 'foo'
    assert 'task' in pb._entries[0]._entries[1]._attributes
    assert pb._entries[0]._entries[1]._attributes['task']['name'] == 'task foo'
    assert 'task' in pb._entries[0]._entries[1]._attributes
   

# Generated at 2022-06-23 06:40:48.821048
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    ds = {}
    var = {}
    basedir = ''
    varMan = None
    loader = None
    # Constructor
    pbi = PlaybookInclude().load_data(ds, basedir, varMan)
    assert isinstance(pbi, PlaybookInclude)

# Generated at 2022-06-23 06:40:59.661677
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.playbook.play import Play

    basedir = os.path.realpath('./')
    playbook_path = os.path.realpath('../../lib/ansible/playbooks/playbook_include.yml')
    playbook_path_no_such_file = os.path.realpath('../../lib/ansible/playbooks/import_playbook_no_such_file.yml')
    playbook_path_no_such_file_on_include = os.path.realpath('../../lib/ansible/playbooks/import_playbook_no_such_file_on_include.yml')

    #
    # Test for import playbook
    #
    p = PlaybookInclude.load({'import_playbook': playbook_path}, basedir)


# Generated at 2022-06-23 06:41:05.864672
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    data = dict()
    data = AnsibleMapping()
    pbi = PlaybookInclude()
    assert pbi != None

    # test with some data
    data['import_playbook'] = "data"
    # test preprocess
    ds = dict()
    ds['import_playbook'] = "data"
    ds['vars'] = dict()
    pbi.preprocess_data(ds)

# Generated at 2022-06-23 06:41:06.914143
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pass


# Generated at 2022-06-23 06:41:11.290808
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    p = PlaybookInclude()
    with open('./test_playbook_include.yml', 'r') as f:
        data = AnsibleMapping.load(f)
    p.load_data(data, '/')

# Generated at 2022-06-23 06:41:21.329295
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.play_context import PlayContext

    p = PlaybookInclude()

    # here is a playbook that is included as a data structure
    data = dict(
        include=dict(
            import_playbook='webservers.yml'
        )
    )

    # set the Play's basedir so we can use a relative path
    p._basedir = os.getcwd()

    try:
        result = p.load_data(data, p._basedir)
    except Exception as e:
        raise AssertionError('failed to load data: %s' % e)

    assert result._entries[0].hosts == ['host1', 'host2'], result._entries[0].hosts
    assert result

# Generated at 2022-06-23 06:41:21.954906
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-23 06:41:30.412900
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import_playbook = 'playbook.yml'
    data = {
        'import_playbook': import_playbook,
    }
    pbi = PlaybookInclude().load_data(data, '')
    assert pbi.import_playbook == import_playbook

# Generated at 2022-06-23 06:41:31.029197
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-23 06:41:43.406458
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    assert PlaybookInclude.load(
        {'import_playbook': 'play.pb'},
        basedir='/some/path'
    ).import_playbook == 'play.pb'
    assert PlaybookInclude.load(
        {'include': 'play.pb'},
        basedir='/some/path'
    ).import_playbook == 'play.pb'
    assert PlaybookInclude.load(
        {'import_playbook': 'play.pb', 'tags': 'tag1,tag2'},
        basedir='/some/path'
    ).tags == ['tag1', 'tag2']
    assert PlaybookInclude.load(
        {'import_playbook': 'play.pb', 'vars': {'x': 1}},
        basedir='/some/path'
    ).v

# Generated at 2022-06-23 06:41:55.853086
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Test when a playbook path is not absolute and basedir is empty
    playbook_include = PlaybookInclude.load(data=dict(import_playbook='test-playbook.yml'), basedir='')
    assert playbook_include.import_playbook == 'test-playbook.yml'

    # Test when a playbook path is not absolute and basedir is not empty
    playbook_include = PlaybookInclude.load(data=dict(import_playbook='test-playbook.yml'), basedir='path/to/playbooks')
    assert playbook_include.import_playbook == 'path/to/playbooks/test-playbook.yml'

    # Test when a playbook path is absolute

# Generated at 2022-06-23 06:42:08.657608
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    import ansible.constants as C
    import ansible.parsing.yaml.objects as yaml_objects

    loader_obj = yaml_objects.AnsibleLoader(None, None)
    ds = loader_obj.load('foo.yml')[0]
    if isinstance(ds, dict):
        # We're dealing with a simple import_playbook statement
        # In current syntax, this should be a dict (as opposed to an AnsibleMapping)
        assert(ds == PlaybookInclude.load(data=ds, basedir='/nonexistent', variable_manager=None, loader=None).dump())
    else:
        orig_data = ds.dump()
        # Restore original data

# Generated at 2022-06-23 06:42:18.606261
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from collections import OrderedDict

    var_mgr = None
    loader = None


# Generated at 2022-06-23 06:42:24.508110
# Unit test for method preprocess_data of class PlaybookInclude

# Generated at 2022-06-23 06:42:26.141696
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    PlaybookInclude._load()

# Generated at 2022-06-23 06:42:38.061807
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    ds = {
        'import_playbook': 'file2.yml',
        'tags': ['tag1', 'tag2'],
        'vars': {
            'var1': 'value1',
            'var2': 'value2',
        },
    }
    loader = DataLoader()
    variable_manager = VariableManager()
    pb = PlaybookInclude.load(ds, '.', variable_manager=variable_manager, loader=loader)
    assert isinstance(pb, Playbook)
    assert len(pb._entries) == 1
    assert pb._entries[0]._included_path == '.'
    assert pb._

# Generated at 2022-06-23 06:42:45.614285
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pbi1 = PlaybookInclude(
        import_playbook='playbook.yml',
        vars=dict(
            foo='bar',
            baz=dict(
                one=10,
                two=dict(
                    three=20
                )
            )
        ),
        tags=['foo'],
        when='yo'
    )

    assert pbi1.get_vars() == dict(
        foo='bar',
        baz=dict(
            one=10,
            two=dict(
                three=20
            )
        )
    )
    assert pbi1.tags == ['foo']
    assert pbi1.when == ['yo']
    assert pbi1.import_playbook == 'playbook.yml'


# Generated at 2022-06-23 06:42:50.916190
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pbi = PlaybookInclude()
    assert pbi._import_playbook is None
    assert pbi.import_playbook is None
    assert pbi._vars == dict()
    assert pbi.vars == dict()

# Generated at 2022-06-23 06:43:01.347928
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():

    from ansible.playbook import Playbook
    from ansible.module_utils.six import StringIO
    from ansible.parsing.yaml.loader import AnsibleLoader
    import json

    data = """
- hosts: localhost
  any_errors_fatal: true
  pre_tasks:
  - include_playbook: playbook.yml

- hosts: all
  pre_tasks:
  - include_playbook: playbook.yml
  - block:
    - debug: var=my_var
    rescue:
    - include_playbook: playbook.yml
    always:
    - include_playbook: playbook.yml
"""
    sio = StringIO(data)
    loader = AnsibleLoader(sio, file_name='<string>')

# Generated at 2022-06-23 06:43:10.186262
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    import sys
    if sys.version_info >= (3, 0):
        py3 = True
    else:
        py3 = False

    from ansible.playbook.play import Play
    from ansible.playbook.block import Block

    # test for original and new style playbook includes
    playbook_include_new_style = dict(
        import_playbook='/etc/ansible/main.yaml'
    )
    playbook_include_old_style = dict(
        playbook='/etc/ansible/main.yaml'
    )
    playbook_include_new_style_with_args = dict(
        import_playbook='/etc/ansible/main.yaml tags=some_tag,other_tag vars=foo,"obj={{ package_state }}"'
    )
    playbook_include_new_style_

# Generated at 2022-06-23 06:43:21.775882
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.template import Templar

    # VariableManager for test
    variable_manager = VariableManager()

    # prepare data structure (ds)
    ds = AnsibleMapping()
    ds['import_playbook'] = '../test/test_import.yml'
    ds['vars'] = AnsibleMapping()
    ds['vars']['test_var'] = 'test_value'
    ds['tags'] = 'test'
    ds['when'] = 'test_var is defined'

    # prepare Templar
    templar = Templar(loader=None, variables=variable_manager.get_vars())

    p

# Generated at 2022-06-23 06:43:23.283682
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    PlaybookInclude.load({})

# Generated at 2022-06-23 06:43:33.893789
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    playbook_include = PlaybookInclude()
    playbook_include.import_playbook = 'import_playbook_file'
    playbook_include.vars = {'var1': 'value1'}

    # import here to avoid a dependency loop
    from ansible.playbook import Playbook

    pb = Playbook()
    pb._entries = [playbook_include]
    playbook_include._playbook = pb

    playbook_include.load(playbook_include, basedir="", variable_manager=None, loader=None)
    assert playbook_include._playbook.entries[0] == pb


# Generated at 2022-06-23 06:43:47.254909
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # Import required modules
    import copy

    # set up dicts with which to test preprocess_data
    ds_import_good = AnsibleMapping({'import_playbook': 'space in filename'})
    ds_import_extra = AnsibleMapping({'import_playbook': 'space in filename', 'tags': 'my-tag'})
    ds_import_with_vars = AnsibleMapping({'import_playbook': 'space in filename', 'vars': {'foo': 'bar'}})
    ds_mixed = AnsibleMapping({'import_playbook': 'space in filename', 'vars': {'foo': 'bar', 'tags': 'my-tag'}})

    # Set up the one PlaybookInclude() object that will be used for all tests
    pi = PlaybookInclude()

# Generated at 2022-06-23 06:43:57.182074
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    assert PlaybookInclude.load(data='included_playbook.yml', basedir='/').preprocess_data(ds='included_playbook.yml') == {'import_playbook': 'included_playbook.yml'}
    assert PlaybookInclude.load(data='included_playbook.yml foo=1 bar=2', basedir='/').preprocess_data(ds='included_playbook.yml foo=1 bar=2') == {'import_playbook': 'included_playbook.yml', 'vars': {'foo': '1', 'bar': '2'}}

# Generated at 2022-06-23 06:44:09.083030
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task import Task
    import ansible.parsing.loader
    loader = ansible.parsing.dataloader.DataLoader()
    result = PlaybookInclude.load(data=['test.yaml', 'vars={"a":1}'],
                                  basedir=os.path.join(os.path.dirname(__file__), 'playbook_include_data'),
                                  loader=loader)
    assert isinstance(result, Playbook)
    assert len(result._entries) == 1
    entry = result._entries[0]
    assert isinstance

# Generated at 2022-06-23 06:44:21.965870
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader)
    variable_manager.set_inventory(inventory)
    basedir = os.getcwd()

    # if the include doesn't contain a vars section, it is added
    ds = { 'import_playbook': '../../lib/ansible/modules/system/ping.yaml' }
    pbi = PlaybookInclude.load(ds, basedir, variable_manager)
    assert 'vars' in pbi._entries[0]._entries[0]._entries[0]._entries[0]._attributes

    #

# Generated at 2022-06-23 06:44:33.730324
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    from ansible.parsing.yaml.objects import AnsibleMapping

    # Test case: Empty dictionary
    new_ds = PlaybookInclude.preprocess_data(ds = {})
    assert new_ds == AnsibleMapping()

    # Test case: Valid playbook import statement
    ds = {'include_playbook':"./play.yml"}
    new_ds = PlaybookInclude.preprocess_data(ds = ds)
    assert new_ds == AnsibleMapping(import_playbook = './play.yml')

    # Test case: When not specified
    ds = {'import_playbook':"./play.yml"}
    new_ds = PlaybookInclude.preprocess_data(ds = ds)