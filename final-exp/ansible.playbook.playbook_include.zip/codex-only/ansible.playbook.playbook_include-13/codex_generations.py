

# Generated at 2022-06-23 06:34:32.838384
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Test for logic to fix error for mix between vars and import_playbook as k=v
    ds = {'import_playbook': 'site.yml', 'vars': {'var1': 'value1', 'var2': 'value2'}}
    pbi = PlaybookInclude()
    pbi.preprocess_data(ds)
    assert ds == {'import_playbook': 'site.yml', 'vars': {'var1': 'value1', 'var2': 'value2'}}

    ds = {'import_playbook': 'site.yml vars=var1=value1 var2=value2'}
    pbi = PlaybookInclude()
    pbi.preprocess_data(ds)

# Generated at 2022-06-23 06:34:41.802927
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    import ansible.constants as C
    import os

    ROLE_TEST = os.path.join(C.DEFAULT_ROLES_PATH, "test")
    PLAYBOOK_INCLUDE_TEST = os.path.join("test/playbook/playbook_include")
    DATA_TEST = os.path.join("test/unit/data")

    data = {'import_playbook': "test_include_playbook.yml", 'when': ['test1']}

# Generated at 2022-06-23 06:34:50.731146
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.playbook.task_include import TaskInclude

    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.playbook import Playbook

    from ansible.playbook.preprocessors import HandlerInclude

    all_vars = dict()
    loader = None
    playbook = 'playbook_test.yml'

    # create playbooks, plays and tasks
    pb = Playbook()

# Generated at 2022-06-23 06:34:51.185839
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-23 06:34:54.196822
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    pass

# Generated at 2022-06-23 06:35:00.411113
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Set up a simple playbook include with all parameter and no vars
    ds = AnsibleMapping(
            import_playbook='foo.yml',
            tags='tag1,tag2'
    )

    # Initialize a PlaybookInclude object and call the preprocess_data method
    obj = PlaybookInclude()
    new_ds = obj.preprocess_data(ds)

    # Check if the new data structure is as expected
    assert new_ds == ds


# Generated at 2022-06-23 06:35:08.285249
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.playbook_include import PlaybookInclude
    import ansible.constants as C
    import ansible.parsing.plugin_docs as plugin_docs
    plugin_docs.subcommand_load()

    p = PlaybookInclude()

    # Calling load_data with invalid data structure
    try:
        p.load_data(ds=[], basedir="")
        assert False
    except AssertionError as e:
        pass
    except:
        assert False

    playbook_file = "import_playbook_test_include.yml"

# Generated at 2022-06-23 06:35:11.933976
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    inst = PlaybookInclude()
    assert inst.import_playbook is None
    assert inst.vars == {}
    assert inst.tags == []


# Generated at 2022-06-23 06:35:23.521580
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # Test with normal parameters
    ds = {'import_playbook': 'defaults.yml', 'tags': 'foo,bar', 'vars': {'foo': 'bar'}}
    new_ds = {'import_playbook': 'defaults.yml', 'tags': 'foo,bar', 'vars': {'foo': 'bar'}}
    temp_ds = PlaybookInclude().preprocess_data(ds)
    assert new_ds == temp_ds

    # Test with parameters not in the right place
    ds = {'import_playbook': 'defaults.yml', 'tags': 'foo,bar', 'vars': {'foo': 'bar'}, 'extra': 'dummy'}

# Generated at 2022-06-23 06:35:35.087541
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.vault_password import VaultPassword
    import os
    import sys

    vault_password = VaultPassword(None, None)

    # Obtain current working directory
    cwd = os.getcwd()

    # Restore cwd after the test

# Generated at 2022-06-23 06:35:35.717491
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-23 06:35:36.573028
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass



# Generated at 2022-06-23 06:35:49.466531
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    with pytest.raises(AnsibleParserError) as excinfo:
        PlaybookInclude.load({}, "")
    assert 'import_playbook is required' in str(excinfo)
    assert 'import_playbook must be a string' in str(excinfo)

    with pytest.raises(AnsibleParserError) as excinfo:
        PlaybookInclude.load({'import_playbook': u''}, "")
    assert 'import_playbook is required' in str(excinfo)
    assert 'not a valid playbook' in str(excinfo)

    with pytest.raises(AnsibleParserError) as excinfo:
        PlaybookInclude.load({'import_playbook': u'plugins/test_not_exist.py'}, "")

# Generated at 2022-06-23 06:36:02.151176
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.role_include import RoleInclude
    from ansible.template import Templar

    sample_data = {
        'import_playbook': 'my/playbook.yml',
        'vars': {'var1': 'value1'},
        'tags': 'tag1,tag2',
        'when': 'somevar is defined'
    }

    my_playbook_include = PlaybookInclude()
    data = my_playbook_include.load_data(data=sample_data, loader=AnsibleLoader(None, variable_manager=None, collection_loader=None))
    assert (data.vars == sample_data['vars'])

# Generated at 2022-06-23 06:36:04.090807
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass
# end - test_PlaybookInclude_load()

# Generated at 2022-06-23 06:36:04.940334
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    PlaybookInclude()


# Generated at 2022-06-23 06:36:17.079466
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Play
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Test case 1
    # Input:
    # ds = {'import_playbook': 'test/test_playbook.yml', 'vars': {'test_var_1': 'test_val_1', 'test_var_2': 'test_val_2'}}
    # basedir = "."
    # variable_manager = VariableManager()
    # loader = None
    #
    # Expected Output:
    # playbook = Playbook(loader=loader)
    # playbook._load_playbook_data(file_name="test/test_playbook.yml", variable_manager

# Generated at 2022-06-23 06:36:17.521165
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-23 06:36:18.468462
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass


# Generated at 2022-06-23 06:36:19.679688
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-23 06:36:26.319016
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    loader = AnsibleLoader(None, variable_manager=variable_manager)
    play = PlaybookInclude.load(dict(hosts='a', remote_user='b'), 'c', variable_manager=variable_manager, loader=loader)
    assert isinstance(play, PlaybookInclude)

# Generated at 2022-06-23 06:36:28.824653
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pl = PlaybookInclude()
    assert pl is not None


# Generated at 2022-06-23 06:36:35.925629
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pb = PlaybookInclude()
    ds = { 'import_playbook': '../main.yml', 'tags': 'tag1', 'vars': { 'var1': 'val1' } }
    assert pb.load_data(ds=ds, basedir='/base/dir')

# Generated at 2022-06-23 06:36:40.261011
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    import_playbook = 'abc/def.yml'
    vars = {'name':'Tom'}

    pbi = PlaybookInclude(import_playbook,vars)

    assert pbi.import_playbook == import_playbook
    assert pbi.vars == vars


    

# Generated at 2022-06-23 06:36:45.286550
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.parsing.yaml.loader import AnsibleLoader
    loader = AnsibleLoader(None, False)
    data = loader.load('''
- import_playbook: playbook.yml
    vars:
        var1: val1
        var2: val2
        var3: val3
        var4: val4
''')
    pb = PlaybookInclude.load(data[0], '/tmp')
    assert pb is not None

# Generated at 2022-06-23 06:36:53.119430
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pm = PlaybookInclude.load(
            {
                'import_playbook': 'import_actions.yaml',
                'vars': {'var1': 'val1'}
            },
            '/some/basedir/'
            )

    assert pm._import_playbook == 'import_actions.yaml'
    assert pm._vars == {'var1': 'val1'}

    assert pm._included_conditional == []
    assert pm._included_path == '/some/basedir'

# Generated at 2022-06-23 06:36:56.492360
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    plbookInclude = PlaybookInclude()
    print(plbookInclude)
    print(plbookInclude.__dict__)


# Generated at 2022-06-23 06:37:00.836488
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # test with FQCN
    basedir = '/tmp'
    data = 'ansible_collections.namespace.playbook'
    new_obj = PlaybookInclude.load(data, basedir)
    assert new_obj is not None

    # test with path
    basedir = os.getcwd()
    data = 'playbook.yml'
    new_obj = PlaybookInclude.load(data, basedir)
    assert new_obj is not None



# Generated at 2022-06-23 06:37:10.229480
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import yaml
    yaml.load = AnsibleBaseYAMLObject.load
    
    if yaml.__with_libyaml__:
        yaml.CSafeLoader.add_constructor(
            u'tag:yaml.org,2002:python/unicode',
            yaml.CSafeLoader.construct_python_unicode)
    else:
        yaml.SafeLoader.add_constructor(
            u'tag:yaml.org,2002:python/unicode',
            yaml.SafeLoader.construct_python_unicode)
    from ansible.utils.unicode import unicode_wrap

    # Test definition

# Generated at 2022-06-23 06:37:21.555839
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # Trivial case
    pbi = PlaybookInclude()
    ds = dict()
    ds['import_playbook'] = 'example.yml'
    new_ds = pbi.preprocess_data(ds)
    assert 'import_playbook' in new_ds
    assert new_ds['import_playbook'] == 'example.yml'
    assert 'tags' not in new_ds
    assert 'vars' not in new_ds

    # Non-trivial case
    ds = dict()
    ds['include'] = 'asteroids.yml force=true'
    new_ds = pbi.preprocess_data(ds)
    assert 'import_playbook' in new_ds
    assert new_ds['import_playbook'] == 'asteroids.yml'

# Generated at 2022-06-23 06:37:31.628936
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.attribute import FieldAttribute
    from ansible.template import Templar
    import ansible.constants as C
    localhost = dict(hostname=C.DEFAULT_HOST_LIST)
    play1 = Play().load_data(dict(hosts=C.DEFAULT_HOST_LIST,
                                  tasks=dict(action=dict(module="debug",
                                                         args=dict(msg="Hello world")))))
    play1.post_validate(templar=Templar({}))
    play

# Generated at 2022-06-23 06:37:41.468246
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task.include import Include
    from ansible.playbook.block import Block
    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml='''
---
- tasks:
    - import_playbook: my_playbook.yml tags=foo,bar
...
'''
    pd = AnsibleLoader(None, yaml).get_single_data()

    playbook = PlaybookInclude.load(pd['tasks'][0], basedir='/some/basedir/')
    assert playbook.import_playbook == 'my_playbook.yml'
    assert playbook.tags == ['foo', 'bar']
    assert playbook.when == []
    assert playbook.vars == {}

    assert playbook._load_data

# Generated at 2022-06-23 06:37:48.508479
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    import json

    PlaybookInclude.load({'hosts': 'host1'}, '/home/user/myplaybook.yml')
    PlaybookInclude.load({'import_playbook': 'other.yml', 'vars': {'test': 'test'}}, '/home/user/myplaybook.yml')

# Generated at 2022-06-23 06:37:49.366702
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-23 06:38:02.697496
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    # Create a PlaybookInclude object
    data = {"include": "test.yml", "test": "value"}
    ds = AnsibleLoader(data, yaml_loader=yaml.Loader).get_single_data()
    PlaybookIncludeObj = PlaybookInclude.load(ds, '.')
    # Try loading a PlaybookInclude object
    data = {"include": "test.yml", "test": "value"}
    ds = AnsibleLoader(data, yaml_loader=yaml.Loader).get_single_data()

# Generated at 2022-06-23 06:38:12.576259
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # this test is designed to be run in conjunction with the test_playbook_include_load test in test/integration/targets/playbook_include_loader.yml
    # which loads a playbook into a variable and then verifies the structure of the fields in the loaded playbook, hence this test cannot be run independently
    # and must be run in conjunction with the integration test mentioned, which is always run by tox.
    from ansible.playbook import Playbook, PlaybookInclude
    from ansible.parsing.dataloader import DataLoader

    data = {'include': 'test/integration/targets/playbook_include.yml', 'vars': {'var1': 'value1'}, 'tags': 'tag1,tag2'}

    loader = DataLoader()
    p = PlaybookInclude(loader=loader)


# Generated at 2022-06-23 06:38:21.741736
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Test PlaybookInclude.preprocess_data:
    # Input parameter: ds is a AnsibleMapping object
    # Expected output: A AnsibleMapping object new_ds

    from ansible.playbook.block import Block

    pb = PlaybookInclude()
    ds = AnsibleMapping()
    new_ds = pb.preprocess_data(ds)

    assert isinstance(new_ds, AnsibleMapping)

    ds = AnsibleMapping(vars={"a": "b", "c":"d"}, import_playbook="test.yml")
    new_ds = pb.preprocess_data(ds)
    # check vars
    for key, value in new_ds['vars'].items():
        assert ds['vars'][key] == value

    # no invalid

# Generated at 2022-06-23 06:38:33.132696
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.playbook.play import Play
    import sys

    play_list = []
    if sys.version_info[0] > 2:
        play_list.append(Play().load(dict(hosts='localhost', gather_facts='no', tasks=[{'debug': {'msg': 'play1'}}])))
        play_list.append(Play().load(dict(hosts='localhost', gather_facts='no', tasks=[{'debug': {'msg': 'play2'}}])))
    else:
        play_list.append(Play().load(dict(hosts='localhost', gather_facts='no', tasks=[{'debug': {'msg': 'play1'}}])))

# Generated at 2022-06-23 06:38:43.685984
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    ansible_cfg = os.path.join(os.path.dirname(__file__),'ansible.cfg')

    # must have ANSIBLE_CONFIG set to something or it will default to /etc/ansible/ansible.cfg
    os.environ['ANSIBLE_CONFIG'] = ansible_cfg

    display.verbosity = 4

    args = dict(
        import_playbook = '../test/test_playbook_include.yml',
        vars            = dict(
                            a=1,
                            b=2,
                            ),
        )


# Generated at 2022-06-23 06:38:57.464204
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # TODO
    print('test_PlaybookInclude_load')
    pass
    #import ansible.playbook.playbook_include as playbook_include
    #import ansible.playbook.base as base
    #import ansible.playbook.conditional as conditional
    #import ansible.playbook.taggable as taggable
    #from ansible.module_utils._text import to_bytes
    #import os
    #PlaybookInclude = playbook_include.PlaybookInclude
    #Base = base.Base
    #Conditional = conditional.Conditional
    #Taggable = taggable.Taggable
    #x = PlaybookInclude()
    #assert isinstance(x, PlaybookInclude)
    #assert isinstance(x, Base)
    #assert isinstance(x, Conditional)


# Generated at 2022-06-23 06:38:58.459456
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    assert False, "A unit test has not been implemented"


# Generated at 2022-06-23 06:39:01.590612
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    import_playbook = "import.yml"
    ds = dict({'import_playbook': import_playbook})
    pbi = PlaybookInclude()
    pbi.preprocess_data(ds)
    assert pbi.import_playbook is not None
    assert pbi.import_playbook == import_playbook

# Generated at 2022-06-23 06:39:14.185184
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    ds = AnsibleMapping(file_name="test", data={'import_playbook': 'pb_name', 'roles': 'roles'})
    ds.ansible_pos = "pos"
    ds2 = AnsibleMapping(file_name="test", data={'import_playbook': 'pb_name', 'vars': {'foo': 'bar'}, 'tags': 'tag1,tag2'})
    ds2.ansible_pos = "pos"
    pb = PlaybookInclude()
    pb.load_data(ds=ds, basedir=None)

# Generated at 2022-06-23 06:39:22.254601
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    file_name = '/ansible-playbook/playbook.yml'
    basedir = '/ansible-playbook'
    pb = PlaybookInclude.load(data=file_name, basedir=basedir)
    assert pb._entries[0] is Play
    assert pb._entries[0]._basedir == basedir

# Generated at 2022-06-23 06:39:28.132270
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook

    # check that it fails if playbook is None
    assert_raises(AnsibleParserError, PlaybookInclude.load, None, 'basedir', None, None)

    # check that it fails if playbook is not a dict
    assert_raises(AnsibleParserError, PlaybookInclude.load, [], 'basedir', None, None)

    # check that it fails if playbook is a dict but wrong key
    assert_raises(AnsibleParserError, PlaybookInclude.load, {'not_import_playbook': 'invalid test'}, 'basedir', None, None)

    # check that it fails if basedir is None

# Generated at 2022-06-23 06:39:35.367311
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.module_utils.six import PY3

    class FakeVariableManager:
        def get_vars(self):
            return {}

    fake_variable_manager = FakeVariableManager()
    fake_loader = None
    fake_basedir = None
    fake_ds = None
    result = PlaybookInclude.load(fake_ds, fake_basedir, fake_variable_manager, fake_loader)
    assert result



# Generated at 2022-06-23 06:39:36.008972
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pass

# Generated at 2022-06-23 06:39:44.576298
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.playbook.playbook_include import PlaybookInclude

    # Check for normal instantiation
    pb_inc = PlaybookInclude()
    assert pb_inc.import_playbook is None
    assert pb_inc.vars == {}

    # Check for normal instantiation with kwargs
    pb_inc = PlaybookInclude(import_playbook='test.yml', vars={'foo': 'bar'})
    assert pb_inc.import_playbook == 'test.yml'
    assert pb_inc.vars == {'foo': 'bar'}


# Generated at 2022-06-23 06:39:47.113403
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # This is a stub.
    raise Exception("Test not implemented")


# Generated at 2022-06-23 06:39:53.672799
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():

    # Load module with params
    def load_module(ds):
        # define import
        from ansible.playbook.play_include import PlaybookInclude
        # execute load
        return PlaybookInclude.load(ds=ds, basedir=".")

    # Define tests
    play_path = os.path.join(C.ANSIBLE_DEMOS, "playbooks", "playbook_include.yml")
    ds1 = load_module({'include': play_path})
    ds2 = load_module({'import_playbook': play_path})
    ds3 = load_module({'include': ".", "vars": {"foo": 1}})
    ds4 = load_module({'import_playbook': ".", "vars": {"foo": 1}})

# Generated at 2022-06-23 06:39:56.065255
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    display.deprecated("Please use 'test_playbook_include_load' instead", version='2.14')
    test_playbook_include_load()



# Generated at 2022-06-23 06:40:06.706016
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # deprecated test: vars in import
    yaml_text = """
    hosts: all
    vars:
      var1: test1
    tasks:
        - import_playbook: playbook.yml var2=test2 var3=test3
    """

    # deprecated test: params in import
    yaml_text_param = """
    hosts: all
    tasks:
        - import_playbook: playbook.yml var2=test2 var3=test3
    """

    # deprecated test: include_playbook
    yaml_text_include = """
    hosts: all
    tasks:
        - include_playbook: playbook.yml var2=test2 var3=test3
    """

    data = None

# Generated at 2022-06-23 06:40:08.219723
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pi = PlaybookInclude()
    assert isinstance(pi, PlaybookInclude)

# Generated at 2022-06-23 06:40:08.827087
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-23 06:40:16.258595
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.playbook.play import Play

    add_all_plugin_dirs()

    PlaybookInclude(dict(import_playbook='abcd'))

    try:
        PlaybookInclude(dict(foo='abcd'))
    except AnsibleParserError:
        pass
    else:
        raise AssertionError("failed to raise AnsibleParserError")

# Generated at 2022-06-23 06:40:27.266890
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # load a fixture playbook
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback='default',
        run_tree=None,
        # setting forks=1 because otherwise this test hangs
        forks=1,
    )

    playbook_path = os.path.join(C.TEST_DIR, 'fixtures', 'playbooks', 'include_vars.yml')
    playbook = PlaybookInclude.load(os.path.basename(playbook_path), os.path.dirname(playbook_path), variable_manager=None, loader=tqm.loader)
    assert playbook is not None

    #

# Generated at 2022-06-23 06:40:39.468395
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-23 06:40:45.149972
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pbi = PlaybookInclude()
    assert pbi.__class__ == PlaybookInclude
    # test that defaults are set as expected
    assert pbi.vars == {}
    assert pbi._attributes['tags'] == []
    assert pbi.when is None

# Generated at 2022-06-23 06:40:46.592429
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    PlaybookInclude(playbook="playbook.yml")

# Generated at 2022-06-23 06:40:47.175406
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-23 06:40:47.724801
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-23 06:40:58.942925
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Test for correct error in case the import_playbook parameter is missing
    ds_import_playbook_missing = {}
    assert_exc_msg(AnsibleParserError, "playbook import parameter is missing", PlaybookInclude.preprocess_data, ds_import_playbook_missing)

    # Test for correct error in case the import_playbook parameter value is not a string
    ds_import_playbook_not_string = {'import_playbook': 1}
    assert_exc_msg(AnsibleParserError, "playbook import parameter must be a string indicating a file path, got int instead", PlaybookInclude.preprocess_data, ds_import_playbook_not_string)

    # Test for correct error in case the import_playbook parameter value is an empty string
    ds_import_playbook_empty

# Generated at 2022-06-23 06:40:59.557782
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-23 06:41:11.718297
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import yaml

    ds = {'import_playbook': 'test.yml'}
    ds1 = {'include': 'test.yml'}
    ds2 = {'import_playbook': 'test.yml', 'vars': {'a': 1, 'b': 2}}
    ds3 = {'import_playbook': 'test.yml', 'tags': 'test'}
    ds4 = {'import_playbook': 'test.yml', 'tags': 'test', 'when': 'ansible_os_family == "RedHat"'}
    ds5 = {'import_playbook': 'test.yml', 'vars': {'a': 1}, 'tags': 'test'}

# Generated at 2022-06-23 06:41:24.808516
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml import objects
    from ansible.parsing.yaml.loader import AnsibleLoader
    loader = AnsibleLoader(None, file_name="_")

    # Test case where ds is dict
    pbi = PlaybookInclude()
    ds = dict()
    ds['import_playbook'] = "playbook.yml"
    ds['vars'] = dict()
    ds['vars']['var1'] = "value"
    ds['tags'] = "tags"
    ds['when'] = "when"

    new_ds = pbi.preprocess_data(ds)
    assert new_ds['import_playbook'] == "playbook.yml"
    assert new_ds['vars'] == dict()

# Generated at 2022-06-23 06:41:31.717475
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():

    ##
    # Test loading a playbook include file with parameters.
    p = PlaybookInclude.load(
        dict(import_playbook='"test/test.yml"',
             vars=dict(a=1, b='hello')),
        "/tmp")
    assert p.vars == dict(a=1, b='hello')

# Generated at 2022-06-23 06:41:40.546451
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os

    # AnsibleCollectionConfig.playbook_paths needs to be set to the root directory of the collection
    AnsibleCollectionConfig.playbook_paths.append(os.path.abspath(os.path.join(os.path.dirname(__file__),
                                                                              '..', '..', '..', 'ansible_collections',
                                                                              'ansible_collections', 'test_collection',
                                                                              'playbooks')))
    playbook_include = PlaybookInclude()
    test_data = {
        'when': 'foo',
        'import_playbook': 'test_collection.test_collection.include_playbook.yml',
        'terms': ['bar'],
        'vars': {'x': 'y'}
    }

    test_

# Generated at 2022-06-23 06:41:52.480370
# Unit test for constructor of class PlaybookInclude

# Generated at 2022-06-23 06:41:55.520300
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.template import Templar

    # create object for Playbook to test
    pb = PlaybookInclude()

    # create object for Playbook to use as template
    tpb = Playbook()

    # create object for Play
    play = Play()

    # create object for Templar
    templar = Templa

# Generated at 2022-06-23 06:41:59.536871
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    ds = dict(action=dict(import_playbook="test.yml"))
    PlaybookInclude().preprocess_data(ds)
    assert ds == dict(import_playbook="test.yml")

# Generated at 2022-06-23 06:42:10.220413
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext

    test_playbook_include1 = PlaybookInclude()
    test_playbook_include1.preprocess_data(dict(action='import_playbook', import_playbook='test'))
    assert isinstance(test_playbook_include1.vars, dict)

    test_playbook_include2 = PlaybookInclude()
    test_playbook_include2.preprocess_data(dict(import_playbook='test --tags tag1,tag2'))
    assert isinstance(test_playbook_include2.vars, dict)
    assert 'tag1,tag2' == test_playbook_include2.tags


# Generated at 2022-06-23 06:42:15.498486
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    '''
    Usage:python -m ansible.playbook.playbook_include
    :return:
    '''

    ds = {"import_playbook": "../abc/book.yml"}

    playbook = PlaybookInclude(ds)
    print(playbook)


if __name__ == "__main__":
    test_PlaybookInclude()

# Generated at 2022-06-23 06:42:28.684411
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    def _tmpl(str):
        return str
    Templar._template = _tmpl

    loader = object()
    basedir = os.path.join(os.path.dirname(__file__), 'fixtures', 'playbook_include')
    playbook = os.path.join(basedir, 'playbook.yml')
    includes = ['include', 'list_include', 'dict_include']

# Generated at 2022-06-23 06:42:29.295626
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-23 06:42:34.735850
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    import_playbook = 'import_playbook'
    vars = {'var': 'var'}

    pb_include = PlaybookInclude(import_playbook=import_playbook, vars=vars)

    assert pb_include.vars == vars
    assert pb_include.import_playbook == import_playbook

# Generated at 2022-06-23 06:42:44.984713
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    play1 = Play()
    play2 = Play()
    task1 = Task()
    task1._attributes['action'] = 'task1'
    task2 = Task()
    task2._attributes['action'] = 'task2'
    play1.tasks.append(task1)
    play2.tasks.append(task2)
    playbook_include = PlaybookInclude()
    play1._included_path = '/base/'
    play1.tags = ['tag1']
    playbook = playbook_include.load_data({'import_playbook': './test.yml', 'tags': 'tag2'}, '/base/', None, None)
    assert playbook._entries == [play1, play2]

# Generated at 2022-06-23 06:42:58.026281
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    #test for full import with vars
    import yaml
    block = yaml.safe_load("""- import_playbook: /path/to/imported_playbook.yaml
                                  vars:
                                    password: '{{ vault_password }}'
                                    extra_var: 1""")
    import_playbook = PlaybookInclude.load(block, '.')
    assert import_playbook.import_playbook == '/path/to/imported_playbook.yaml'
    assert 'password' in import_playbook.vars
    assert 'extra_var' in import_playbook.vars
    #test for import without vars
    block = yaml.safe_load("""- import_playbook: /path/to/imported_playbook.yaml""")

# Generated at 2022-06-23 06:43:09.406918
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include = PlaybookInclude()
    # Test case 1: import_playbook only
    # ds is dict
    ds = {'import_playbook': 'test_play.yml'}
    new_ds = playbook_include.preprocess_data(ds)
    assert isinstance(new_ds, dict)
    assert new_ds == {'import_playbook': 'test_play.yml'}
    # ds is AnsibleMapping
    ds = AnsibleMapping(ds)
    new_ds = playbook_include.preprocess_data(ds)
    assert isinstance(new_ds, dict)
    assert new_ds == {'import_playbook': 'test_play.yml'}

    # Test case 2: import_playbook plus space separated parameter
    # ds is dict


# Generated at 2022-06-23 06:43:16.058329
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    '''
    Constructor PlaybookInclude
    '''

    test_playbook_include = PlaybookInclude()

    assert test_playbook_include is not None
    assert test_playbook_include._import_playbook is None
    assert test_playbook_include._vars == {}


# Generated at 2022-06-23 06:43:26.963143
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # Invalid input
    ds = None
    basedir = '/abc/def/'
    variable_manager = None
    loader = None
    playbook_include = PlaybookInclude.load(ds=ds, basedir=basedir, variable_manager=variable_manager, loader=loader)
    assert playbook_include is None
    ds = list()
    playbook_include = PlaybookInclude.load(ds=ds, basedir=basedir, variable_manager=variable_manager, loader=loader)
    assert playbook_include is None
    ds = 123
    playbook_include = PlaybookInclude.load(ds=ds, basedir=basedir, variable_manager=variable_manager, loader=loader)
    assert playbook_include is None
    ds = 'abc'

# Generated at 2022-06-23 06:43:37.891911
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.included_file import IncludedFile

    pbi = PlaybookInclude.load({"include":"test.yml","tags":"test"}, basedir="tests/")
    assert isinstance(pbi, PlaybookInclude)
    assert pbi.tags == ["test"]
    assert pbi.import_playbook == "test.yml"
    assert pbi.vars == {}

    pbi = PlaybookInclude.load({"include": "test.yml", "tags": "test", "vars": {"a":"1"}}, basedir="tests/")

# Generated at 2022-06-23 06:43:49.009613
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    class MockLoader:

        class MockVarsManager:
            def get_vars(self):
                return dict()

            def get_available_variables(self, play=None, host=None, task=None, include_delegate_to=False):
                return dict()

        def __init__(self):
            self.vars_manager = self.MockVarsManager()

    class MockTask:
        def __init__(self):
            self.when = []
            self.tags = []

    class MockBlock:
        def __init__(self):
            self._attributes = dict()
            self.when = []

        @property
        def tasks(self):
            return [MockTask()]


# Generated at 2022-06-23 06:43:49.649498
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    assert True

# Generated at 2022-06-23 06:43:51.925719
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # Unit test for method load of class PlaybookInclude
    # Nothing to test here; the code is trivial and results in a call to the base
    pass

# Generated at 2022-06-23 06:43:54.838279
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    p = PlaybookInclude('test.yml', {})
    assert p
    assert p.import_playbook == 'test.yml'
    assert p.vars == {}


# Generated at 2022-06-23 06:43:57.623668
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pb = PlaybookInclude()
    assert pb._import_playbook == None
    assert pb.vars == {}

# Generated at 2022-06-23 06:43:59.001507
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # No tests possible using a stub class
    pass

# Generated at 2022-06-23 06:44:11.301791
# Unit test for method preprocess_data of class PlaybookInclude

# Generated at 2022-06-23 06:44:23.813659
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    #
    # import_playbook foo.yml
    #
    p = PlaybookInclude.load(dict(import_playbook = 'foo.yml'), basedir='/var/lib/awx/projects/_00001_test')
    assert p._import_playbook == 'foo.yml'
    assert p._vars == dict()

    #
    # import_playbook bar.yml vars=foo.bar
    #
    p = PlaybookInclude.load(dict(import_playbook = 'bar.yml vars=foo.bar'), basedir='/var/lib/awx/projects/_00001_test')
    assert p._import_playbook == 'bar.yml'
    assert p._vars == dict(foo=dict(bar=True))