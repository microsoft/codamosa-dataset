

# Generated at 2022-06-23 06:34:25.354127
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    pass # Nothing to test in this function



# Generated at 2022-06-23 06:34:31.883052
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    display.display("Constructing PlaybookInclude...", color='blue')
    data = dict(import_playbook='test.yml')
    pi = PlaybookInclude.load(data=data, basedir='.')
    display.display("{0}".format(pi.get_vars()), color='blue')

# Generated at 2022-06-23 06:34:40.968201
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    '''
    Unit test for method load of class PlaybookInclude
    '''
    from ansible.playbook import Playbook
    from io import StringIO
    import yaml
    from ansible.parsing.utils.yaml import from_yaml
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.facts.cache import FactsCache
    from ansible.module_utils.facts.system.base import BaseFactCollector

    # Here we create a basic playbook which includes a sample playbook
    playbook1 = Playbook()
    playbook1._entries = []
    playbook1._basedir = '/tmp'
    playbook1._filename = '/tmp/testPlaybook.yml'

    playbook2 = PlaybookInclude()
    playbook2.import_play

# Generated at 2022-06-23 06:34:49.596174
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Play

    # ds: data structure
    assert PlaybookInclude.load({'playbook': 'test.yml'}, '/')[0].__class__ == Play
    assert PlaybookInclude.load({'import_playbook': 'test.yml'}, '/')[0].__class__ == Play
    assert PlaybookInclude.load({'include_playbook': 'test.yml'}, '/')[0].__class__ == Play


# Generated at 2022-06-23 06:34:53.200862
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pm = dict(a = 'A', b = dict(c = 'C', d = 'D'))

    # TBD: implement load_data()
    # pb = PlaybookInclude()
    # pb.load_data(ds = pm, variable_manager = None, loader = None)



# Generated at 2022-06-23 06:34:57.716891
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # create a valid playbook
    pb = PlaybookInclude.load({'import_playbook': 'some_playbook.yml', 'vars': {'foo': 'bar'}}, 'ignored')
    assert isinstance(pb, Playbook)

# Generated at 2022-06-23 06:34:59.831547
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    playbook_include_load = PlaybookInclude.load()
    assert playbook_include_load == NotImplementedError


# Generated at 2022-06-23 06:35:07.153584
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    """
    Test that a playbook can be loaded from an import_playbook statement.
    """
    cur_dir = os.path.dirname(__file__)
    playbook_name = 'data/playbook_include.yaml'
    playbook_path = os.path.join(cur_dir, playbook_name)

    pb = PlaybookInclude.load(dict(), playbook_path, variable_manager={}, loader={})

    assert pb



# Generated at 2022-06-23 06:35:11.112983
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    #Create a playbook include object
    pbi = PlaybookInclude()
    # Check to ensure that it's not none
    assert pbi is not None


# Generated at 2022-06-23 06:35:22.542524
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Test regular case
    regular_playbook_include = PlaybookInclude()
    ds = dict(
        import_playbook='test.yml',
        vars=dict(foo='bar'),
        tags=['tag'],
    )
    new_ds = regular_playbook_include.preprocess_data(ds)
    # new_ds is a dict, not a AnsibleMapping, so no pos.
    assert new_ds == dict(
        import_playbook='test.yml',
        vars=dict(foo='bar'),
        tags=['tag'],
    )

    # Test regular case, with multiple params
    regular_playbook_include = PlaybookInclude()

# Generated at 2022-06-23 06:35:26.564656
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # the importing of ansible.playbook.include is delayed till now,
    # so we can avoid circular imports
    from ansible.playbook import PlaybookInclude
    from ansible.parsing.yaml.loader import AnsibleLoader
    ds = dict(
        name = 'roles/foo/tasks/main.yaml'
    )

    fake_playbook = 'playbook.yml'
    fake_basedir = '/fake/basedir'
    templar = Templar(loader=None, variables=dict())
    loader = AnsibleLoader(templar, dict())
    pb_include = PlaybookInclude.load(ds, fake_basedir, None, loader)
    assert pb_include.__class__.__name__ == 'Playbook'

# Generated at 2022-06-23 06:35:36.336157
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    result_data = {
        'import_playbook': 'foo',
        'tags': 'tag1,tag2',
        'vars': {
            'var1': 'value1',
            'var2': 'value2',
        }
    }

    # test with just the playbook path
    playbook_path_only = AnsibleMapping()
    playbook_path_only['import_playbook'] = 'foo'
    assert PlaybookInclude.preprocess_data(playbook_path_only) == result_data

    # test with playbook path and vars
    playbook_path_and_vars = AnsibleMapping({'import_playbook': 'foo', 'vars': {'var1': 'value1', 'var2': 'value2'}})

# Generated at 2022-06-23 06:35:49.165506
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext

    context = PlayContext()
    variable_manager = VariableManager()

    # Test with string of type 'dict'
    test_data = {'var1': 'val1', 'var2': 'val2'}
    test_expected = {'vars': {'var1': 'val1', 'var2': 'val2'}}

    # test_data is a string of type 'dict', expecting a dictionary object as output
    test_data_1 = PlaybookInclude().load_data(ds=test_data, basedir='/test/foo/bar')
    if isinstance(test_data_1, dict):
        assert(test_data_1 == test_expected)
        print('test_data_1: ', test_data_1)
    else:
        print

# Generated at 2022-06-23 06:36:01.908471
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    ds = dict(
        import_playbook="foobar",
        when="ansible_distribution == 'Fedora'",
        tags="tag1,tag2"
    )
    result = PlaybookInclude.load(ds, "/some/basedir")
    assert isinstance(result, PlaybookInclude)
    assert result.import_playbook == "foobar"
    assert result.when == ["ansible_distribution == 'Fedora'"]
    assert result.tags == ["tag1", "tag2"]
    assert result.vars == {}

    ds = dict(
        import_playbook="foobar",
        vars=dict(
            foo="bar",
            bar="baz"
        )
    )
    result = PlaybookInclude.load(ds, "/some/basedir")

# Generated at 2022-06-23 06:36:15.180108
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.yaml.objects import AnsibleUnicode


    # Test empty input as required parameter
    try:
        pbin = PlaybookInclude.load(data=None, basedir=None)
    except AnsibleParserError as e:
        assert e.message == 'ds (None) should be a dict but was a NoneType'
    else:
        raise AssertionError('Expected AnsibleParserError for empty input')

    # Test input as not a dict

# Generated at 2022-06-23 06:36:28.158898
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    pc = PlayContext()
    p = PlaybookInclude()
    p.load_data({'include': 'test.yml'}, pc, loader)
    assert p.import_playbook == 'test.yml'
    assert p.vars == {}
    assert p.tags == []

    p = PlaybookInclude()
    p.load_data({'include': 'test.yml tags=foo'}, pc, loader)
    assert p.import_playbook == 'test.yml'
    assert p.tags == ['foo']
    assert p.vars == {}

    p = PlaybookInclude()

# Generated at 2022-06-23 06:36:40.898049
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    import sys
    import collections
    import pprint
    import ansible.constants as C

    try:
        from ansible.playbook.role import Role
    except:
        pass
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    AnsibleCollectionConfig.default_collection = 'ansible_namespace.role_name'


# Generated at 2022-06-23 06:36:41.524580
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-23 06:36:47.858397
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.base import PlaybookBase
    import sys

    # PlaybookInclude.load_data() is protected by condiditional check
    # which is based on the import_playbook parameter. The check
    # runs in the parent method PlaybookBase.load_data(). So, to execute
    # the method under test, we need to replace its parent.
    original_bases = PlaybookInclude.__bases__
    PlaybookInclude.__bases__ = (PlaybookBase, )

    print('------ Test for PlaybookInclude.load_data() method ------')
    sys.stderr.write('TODO: implement test for PlaybookInclude.load_data() method.\n')

# Generated at 2022-06-23 06:36:58.107994
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()


# Generated at 2022-06-23 06:36:59.846186
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    playbook_include = PlaybookInclude()


# Generated at 2022-06-23 06:37:05.019832
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    play_name = "dummy_play"
    import_playbook = "import_playbook"
    playbook_include = PlaybookInclude(play_name, import_playbook)
    assert playbook_include.name == play_name
    assert playbook_include.import_playbook == import_playbook

# Generated at 2022-06-23 06:37:18.728685
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook

    # Create a Play object
    play = Play().load({
        u'name': u'Hedlund Division',
        u'hosts': u'west',
        u'gather_facts': u'no',
        u'roles': [u'mythic_database']
    })

    # Create a PlaybookInclude with the Play object
    pb_include = PlaybookInclude(
        import_playbook=u'/tmp/data/ansible/roles/mythic_database/tests/data/playbook.yml'
    )

# Generated at 2022-06-23 06:37:34.918089
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.task_include import TaskInclude

    yaml_tag = '!include'
    expected_vars = {'k1': 'v1'}
    playbook_file = 'test_playbook.yml'
    data = {yaml_tag: playbook_file, 'vars': expected_vars}

    playbook_include = PlaybookInclude.load(data, '/')
    assert playbook_include.import_playbook == playbook_file
    assert playbook_include.vars == expected_vars

    playbook_file_with_params = playbook_file + ' var1=val1 var2=val2'
    data = {yaml_tag: playbook_file_with_params}
    playbook_include = PlaybookInclude

# Generated at 2022-06-23 06:37:37.805405
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    p = PlaybookInclude.load({'import_playbook': 'foo.yml'}, loader=loader)

    assert p._import_playbook == 'foo.yml'
    assert p.vars == {}

# Generated at 2022-06-23 06:37:51.587227
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    ds = dict(
        import_playbook = 'playbook.yml',
        vars = dict(
            foo = 'bar',
        ),
        tags = 'test,test2',
    )
    result = PlaybookInclude.load(data=ds, basedir='.')
    assert result.import_playbook == 'playbook.yml'
    assert result.tags == ['test', 'test2']
    assert result.vars == dict(foo='bar')

    ds = dict(
        NOT_import_playbook = 'playbook.yml',
        vars = dict(
            foo = 'bar',
        ),
        tags = 'test,test2',
    )

# Generated at 2022-06-23 06:38:04.512518
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing import loader, ds
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    import pytest

    variable_manager = VariableManager()
    loader = loader.DataLoader()
    context = PlayContext(variable_manager=variable_manager, loader=loader)
    test_data = ds.DataLoader()


# Generated at 2022-06-23 06:38:18.234721
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # set up mock objects
    test_file = '/foo/bar.yml'
    test_dir = '/foo/dir/'
    test_ds = { test_file: {} }
    test_variable_manager = 'test_variable_manager'
    test_loader = 'test_loader'

    # set up mock objects
    mock_PlaybookInclude = PlaybookInclude()
    def mock_load_data(ds, basedir, variable_manager=None, loader=None):
        assert ds == test_ds
        assert basedir == test_dir
        assert variable_manager == test_variable_manager
        assert loader == test_loader
        return mock_PlaybookInclude
    mock_PlaybookInclude.load_data = mock_load_data

    # call PlaybookInclude.load()
    result = PlaybookIn

# Generated at 2022-06-23 06:38:27.640002
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    mockloader = Mock()
    pm = PlaybookInclude()
    mockloader.load_from_file.return_value = {}

    pb = pm.load_data('my-collection/my-playbook.yml', basedir='/tmp/ansible', loader=mockloader)
    assert pb.basedir == '/tmp/ansible'
    assert pb.playbook == 'my-collection/my-playbook.yml'
    assert pb._included_files == set()
    assert pb.filenames == []



# Generated at 2022-06-23 06:38:37.890151
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.dataloader import DataLoader

    ds = dict(
        import_playbook=dict(
            file1=dict(
                a=1,
                b=2,
                c=3,
                d=[1, 2, 3],
            )
        )
    )
    basedir = '/tmp'

    # some standard error checking
    try:
        PlaybookInclude.preprocess_data(None, ds=dict(import_playbook=1))
    except AnsibleParserError:
        pass
    else:
        assert False, "Should have raised an exception for a non-dict ds"


# Generated at 2022-06-23 06:38:51.899922
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    # dummy Datastructure
    ds={ 'import_playbook': "playbook to import"
       , 'vars': { 'var1': 'var1', 'var2': 'var2' }
       , 'tags':  ['tag1', 'tag2']
       }
    # dummy playbook
    pb=Playbook()
    pb._entries = [Play().load(ds, None, None)]

    # dummy playbook_include
    pi=PlaybookInclude()
    pi.import_playbook = "playbook to import"
    pi.vars = { 'var1': 'var1', 'var2': 'var2' }
    pi.tags = ['tag1', 'tag2']
    pi.when  = []

# Generated at 2022-06-23 06:39:01.044984
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_file = "playbook_include.yml"
    playbook_dir = os.path.dirname(os.path.realpath(__file__))
    playbook_file_path = os.path.join(playbook_dir, playbook_file)
    p = PlaybookInclude.load(data=playbook_file_path, basedir=playbook_dir)
    assert isinstance(p, PlaybookInclude)
    assert p._import_playbook == "playbook.yml"
    assert p._vars == dict()

# Generated at 2022-06-23 06:39:10.505461
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.playbook.play import Play

    pb = PlaybookInclude.load({}, '/test')
    assert pb.import_playbook is None
    assert pb.vars == {}
    assert pb.tags == []
    assert pb.conditional is None

    pb2 = PlaybookInclude.load({'import_playbook': 'test.yml'}, '/test')
    assert pb2.import_playbook == 'test.yml'
    assert pb2.vars == {}
    assert pb2.tags == []
    assert pb2.conditional is None

    pb3 = PlaybookInclude.load({'import_playbook': 'test.yml'}, '/test',
                               variable_manager=None, loader=None)
    assert pb3.import_play

# Generated at 2022-06-23 06:39:11.256035
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-23 06:39:23.651685
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    single_include_yaml = """
    - include: test_playbook_include.yml
    - name: test
      ping:
    """
    pb = Playbook.load(single_include_yaml, '.')

    assert len(pb.get_plays()) == 2

    data = {'include': 'test_playbook.yml', 'tags': 'test,include'}
    pbi = PlaybookInclude()
    pbi.load_data(data, '.')

    assert pbi.import_playbook == 'test_playbook.yml'
    assert pbi.tags == ['test', 'include']
    assert pbi.vars == {}


# Generated at 2022-06-23 06:39:36.411307
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    """
    Unit test for PlaybookInclude.load()
    """

    import ansible.parsing.yaml.objects

    def load_config_with_file(file_name, data):

        import yaml
        yaml.load = fake_yaml_load
        #import ansible.playbook
        #ansible.playbook.Playbook.load = fake_playbook_load

        module_loader = 'test_PlaybookInclude_load.module_loader'
        variable_manager = 'test_PlaybookInclude_load.variable_manager'

        pb = PlaybookInclude.load(data, 'basedir', variable_manager, loader=module_loader)

        assert pb.import_playbook == file_name


# Generated at 2022-06-23 06:39:37.070570
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-23 06:39:38.091419
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-23 06:39:46.519988
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    ds = dict(vars=dict(a=1, b=2, c=3), import_playbook='test_file.yml')
    ds['test_key'] = 'test_value'
    ds['vars']['test_var'] = 'test_var_value'
    pb = PlaybookInclude.load_data(ds, '/tmp')
    assert pb.import_playbook == 'test_file.yml'
    assert pb.vars['a'] == 1
    assert pb.vars['b'] == 2
    assert pb.vars['c'] == 3
    assert pb.vars['test_var'] == 'test_var_value'
    assert pb.test_key == 'test_value'

# Generated at 2022-06-23 06:39:52.923387
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Create test data
    data1 = dict(import_playbook='imported.yml')
    data2 = dict(k=dict(import_playbook='imported2.yml'))
    data3 = dict(import_playbook='imported3.yml', tags='TAG')
    data4 = dict(import_playbook='imported4.yml', vars=dict(a=2,b=3))
    data5 = dict(import_playbook='imported5.yml', foo=True, bar=False)
    data6 = dict(import_playbook='imported6.yml', foo=True, bar=False, vars=dict(a=2,b=3))
    data7 = dict(import_playbook='imported7.yml', vars=dict(tags='TAG'))


# Generated at 2022-06-23 06:40:03.787271
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.conditional import Conditional

    from ansible.playbook.base import Base
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.module_utils.six import string_types

    pb_inc = PlaybookInclude.load(
        data=dict(
            import_playbook="rcd_playbook.yml",
            tags="tag1"
        ),
        basedir="./",
        variable_manager=None,
        loader=None
    )

# Generated at 2022-06-23 06:40:12.945019
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook = PlaybookInclude()

    # test multiple import_playbook statements
    dict_0 = dict(tasks='do something', import_playbook='file1')
    with pytest.raises(AnsibleParserError):
        playbook.preprocess_data(ds=dict_0)

    dict_1 = dict()
    dict_1['tasks'] = 'do something'
    dict_1['import_playbook'] = 'file1'
    with pytest.raises(AnsibleParserError):
        playbook.preprocess_data(ds=dict_1)

    # import_playbook has to be a string type
    dict_2 = dict()
    dict_2['tasks'] = 'do something'

# Generated at 2022-06-23 06:40:28.520475
# Unit test for method preprocess_data of class PlaybookInclude

# Generated at 2022-06-23 06:40:30.948155
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    PlaybookInclude("/tmp/test.yml",variable_manager=None,loader=None)

# Generated at 2022-06-23 06:40:44.257559
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.module_utils.six import PY3
    from six import StringIO
    from collections import OrderedDict
    import sys

    # we'll mock the loading of playbooks and tasks to verify we're correctly using
    # the data that is returned
    class MockPlaybook(object):
        def __init__(self):
            self._entries = []


# Generated at 2022-06-23 06:40:49.747595
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    playbook_file = 'tests/playbooks/playbook_inc_load.yml'
    self = PlaybookInclude()
    display = Display()
    variable_manager = None
    loader = None
    pb = self.load(playbook_file, basedir='', variable_manager=variable_manager, loader=loader)
    assert pb._entries[0].name == 'Import Playbook of variable_manager class'

# Generated at 2022-06-23 06:40:53.378388
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import types
    import ansible.playbook.play as pb
    template = types.SimpleNamespace(
        template='test',
        variable_manager=None,
        loader=None,
    )
    playbook = PlaybookInclude()
    playbook.load_data(template, '/tmp')
    assert isinstance(playbook, pb.Playbook)

# Generated at 2022-06-23 06:41:04.205879
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # Test single-level play imports
    #   Single-level play imports should create a playbook including
    #   the single-level play file.
    def test_single_level_play_import_with_tags_and_vars():
        import_playbook = 'playbook.yml'
        # When tags and vars are provided
        tags = 'tag1,tag2'
        vars = {'var1': 'value1', 'var2': 'value2'}
        test_object = PlaybookInclude(import_playbook=import_playbook, tags=tags, vars=vars)
        assert test_object.import_playbook == import_playbook
        assert test_object.tags == tags
        assert test_object.vars == vars

    #   Single-level play imports should create a playbook including
    #

# Generated at 2022-06-23 06:41:12.390825
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    mock_ds = {'import_playbook': '~/dir/playbook.yml vars_name={{ test_var }} key1=value1'}
    basedir = '/tmp/test'
    pb = PlaybookInclude.load(data=mock_ds, basedir=basedir)
    assert pb.data == {'import_playbook': '~/dir/playbook.yml', 'vars': {'vars_name': '{{ test_var }}', 'key1': 'value1'}}

# Generated at 2022-06-23 06:41:23.758400
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    ds = AnsibleMapping({ 'include': 'test.yml' })
    ds.ansible_pos = 1
    dl = DataLoader()
    vm = VariableManager()

    pi = PlaybookInclude()
    new_ds = pi.preprocess_data(ds)

    assert isinstance(new_ds, dict)
    assert len(new_ds) == 1

    assert 'import_playbook' in new_ds
    assert new_ds['import_playbook'] == 'test.yml'



# Generated at 2022-06-23 06:41:32.136009
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    # Example of a PlaybookInclude with vars
    base_data = '''
        - include_playbook: playbook.yml
          vars:
            a: 1
            b: 2
    '''

    pm = PlaybookInclude.load(base_data, '', variable_manager=None, loader=None)
    assert isinstance(pm, PlaybookInclude)



# Generated at 2022-06-23 06:41:44.059223
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # Create AnsibleMapping to use as fake ds
    fake_ds = AnsibleMapping()
    # Set attributes to fake ds
    fake_ds['import_playbook'] = './test_data/test_import.yml'
    fake_ds['tags'] = ['tag']
    fake_ds['vars'] = {'v1': '1'}
    fake_ds['when'] = ['1']

    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude

    # Get test dir
    test_dir = os.path.dirname(__file__)
    # Call load method of PlaybookInclude
    playbook_include = PlaybookInclude.load(fake_ds, test_dir)
    # Assert playbook_include is a Playbook

# Generated at 2022-06-23 06:41:56.516736
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    #from ansible.playbook.play_context import PlayContext
    #from ansible.inventory.manager import InventoryManager
    #from ansible.inventory.host import Host, Group
    #from ansible.parsing.dataloader import DataLoader

    #loader = DataLoader()
    #inventory = InventoryManager(loader=loader, sources=['localhost,'])
    #variable_manager = VariableManager(loader=loader, inventory=inventory)
    #play_context = PlayContext()

    new_obj = Playbook

# Generated at 2022-06-23 06:42:00.180741
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    '''
    Constructor of class PlaybookInclude
    '''
    import_play = PlaybookInclude()
    assert import_play is not None


# Generated at 2022-06-23 06:42:12.213941
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    pbi = PlaybookInclude()
    b_dir='/test'
    data = dict(import_playbook='/test/test.yml', tags='test2,test3', vars=dict(test='test'), when='test')
    pb = pbi.load_data(data, b_dir)
    assert pb._entries[0]._included_path == b_dir
    assert pb._entries[0]._included_conditional == ['test']
    assert pb._entries[0].tags == ['test', 'test2', 'test3']
    assert pb._entries[0].vars['test'] == 'test'

# Generated at 2022-06-23 06:42:22.593462
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    tmp = dict(
        import_playbook="/var/admins/playbooks/foo.yml",
        vars=dict(x=1),
    )
    obj = PlaybookInclude()

    # Test the case when the parameter name is import_playbook
    obj.preprocess_data(tmp)

    # Test the case when the parameter name does not match any
    # known import_playbook keywords
    tmp['import_playbook_wrong'] = tmp.pop('import_playbook')
    obj.preprocess_data(tmp)

    # Test the case when the value is not a string
    tmp['import_playbook'] = 2
    obj.preprocess_data(tmp)

# Generated at 2022-06-23 06:42:34.772920
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # import here to avoid a dependency loop
    from ansible.playbook.play import Play
    import sys

    sys.path.insert(0, '../')

    # setup
    _play = Play()
    _play.load_data({})
    _play.name = 'test'
    playbook = PlaybookInclude()
    playbook.load_data({})
    playbook.import_playbook = 'test/test1'
    playbook.when = "True"
    playbook.tags = ['skip', 'test']

    # add test play to loaded plays
    playbook.loader.set_basedir('.')
    playbook.loader.loaded_plays = [_play]

    # test with no variable_manager
    pb = playbook.load_data(playbook, '.')

    # verify that the loaded play is executed
    assert p

# Generated at 2022-06-23 06:42:36.367543
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    assert False, "unit tests for this class not implemented"


# Generated at 2022-06-23 06:42:46.107010
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping


# Generated at 2022-06-23 06:42:46.655317
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-23 06:42:53.091396
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include = PlaybookInclude()
    with py.test.raises(AnsibleAssertionError) as excinfo:
        playbook_include.load_data(dict(), "/")
    assert 'ds should be a dict but was a <class \'dict\'>' in str(excinfo.value)


# Generated at 2022-06-23 06:43:01.030999
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.parsing.vault import VaultLib

    test_args = dict(
        import_playbook='/var/lib/awx/projects/someproject/playbook.yml',
        tags=['one', 'two'],
        vars=dict(foo='bar'),
    )
    pbi = PlaybookInclude(**test_args)
    # pbi.dump()
    # can't just do == due to VaultSecret being in there
    assert pbi._import_playbook == test_args['import_playbook']
    assert pbi.vars == test_args['vars']
    assert pbi.tags == test_args['tags']

# Generated at 2022-06-23 06:43:12.116441
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from io import BytesIO
    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()
        display.verbosity = 3
    fake_yaml_text = """
- import_playbook: /the/playbook.yml
    vars:
        debug: true
    tags: alpha,bravo
    force_handlers: true
"""
    if PY3:
        fake_yaml_file = StringIO(fake_yaml_text)

# Generated at 2022-06-23 06:43:13.575088
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass


# Generated at 2022-06-23 06:43:26.405577
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play

    basedir = '.'
    ds = '''
    - include_playbook: test.yml
      when: my_var
    '''
    data = PlaybookInclude.load(data=ds, basedir=basedir)
    assert isinstance(data, Play)
    assert len(data._entries) == 1
    assert data._entries[0]._included_conditional == ['my_var']

    # Test to make sure each loaded play has the correct tags and variables

# Generated at 2022-06-23 06:43:37.612865
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.module_utils.six import PY3

    if PY3:
        unicode = str

    # The code being tested
    from ansible.playbook.include import PlaybookInclude

    # The test cases

# Generated at 2022-06-23 06:43:49.100114
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import sys
    import os
    import tempfile

    # change to test dir
    _test_dir = os.path.join(os.path.dirname(__file__))
    _old_dir = os.getcwd()
    os.chdir(_test_dir)

    # create data structures
    _variable_manager = dict()
    _loader = dict()
    _ds = dict(import_playbook='pb_import.yml')
    _basedir = './includedir'

    # create instance
    _playbook_include = PlaybookInclude()

    # test load_data method
    _pb = _playbook_include.load_data(_ds, _basedir, _variable_manager, _loader)
    assert _pb.name is None
    assert _pb.hosts is None
    assert _pb

# Generated at 2022-06-23 06:43:56.733969
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    test_data = dict(import_playbook='/some/path/someplay.yml', tags=['foo'], vars={})
    p = PlaybookInclude()
    p.load_data(test_data)
    assert p.import_playbook == '/some/path/someplay.yml'
    assert p.tags == ['foo']
    assert p.vars == dict()
    # Test constructor with playbook which has inline vars
    test_data = dict(import_playbook='/some/path/someplay.yml foo=1 bar=2', tags=['foo'])
    p = PlaybookInclude()
    p.load_data(test_data)
    assert p.import_playbook == '/some/path/someplay.yml foo=1 bar=2'

# Generated at 2022-06-23 06:44:08.515550
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.taggable import Taggable

    # Test constructor of class PlaybookInclude
    # Test if isinstance(PlaybookInclude(), Base) == True
    assert isinstance(PlaybookInclude(), Base)

    # Test if isinstance(PlaybookInclude(), Conditional) == True
    assert isinstance(PlaybookInclude(), Conditional)

    # Test if isinstance(PlaybookInclude(), Taggable) == True
    assert isinstance(PlaybookInclude(), Taggable)

    tp = type(PlaybookInclude())
    assert tp.__name__ == "PlaybookInclude"

# Generated at 2022-06-23 06:44:09.472459
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-23 06:44:10.202936
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-23 06:44:15.004568
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.playbook.play import Play

    hostvars = {"foo": "bar"}
    variable_manager = DictDataManager(hostvars)
    loader = DataLoader()
    results = PlaybookInclude(loader=loader, variable_manager=variable_manager)
    assert type(results) is PlaybookInclude
    assert type(results._play) is Play

    # test the invalid case
    invalid_ds = {'import_playbook': 'new_play.yml', 'invalid_key': 'invalid_value'}
    try:
        result = results.preprocess_data(invalid_ds)
    except Exception as e:
        assert type(e) is AnsibleParserError

# Generated at 2022-06-23 06:44:24.087957
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    data = {
        'import_playbook': 'all.yaml',
        'vars': dict(a=1),
        'tags': ['t1', 't2'],
        'when': [],
    }

    pb = PlaybookInclude(data)
    print("pb.import_playbook: ", pb.import_playbook)
    print("pb.vars: ", pb.vars)
    print("pb.tags: ", pb.tags)
    print("pb.when: ", pb.when)