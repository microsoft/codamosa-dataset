

# Generated at 2022-06-23 06:34:37.968747
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.roles import Roles
    from ansible.module_utils.common._collections_compat import Mapping

    p = PlaybookInclude()
    # Test Base class will be tested with other classes
    assert isinstance(p, Base)
    # Test Taggable class will be tested with other classes
    assert isinstance(p, Taggable)
    # Test Conditional class will be tested with other classes
    assert isinstance(p, Conditional)

    # test load_data
    with pytest.raises(AnsibleAssertionError) as excinfo:
        p.load_data

# Generated at 2022-06-23 06:34:50.651276
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    import tempfile
    import os
    import mock
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play import Play

    playbook = Playbook()

    pb = PlaybookInclude()
    pb = PlaybookInclude.load({'import_playbook': 'test.yaml'}, '/etc/ansible')

    #reload the playbook again and see if it changed
    ds = {'imported_playbook': 'import_playbook.yaml', 'vars': {'name': 'test'} }
    pb = pb.load_data(ds, '/etc/ansible')


# Generated at 2022-06-23 06:35:00.172559
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.template import Jinja2Template
    from ansible.parsing.splitter import play_contexts
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible import context
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    # Collection loader
    loader = AnsibleCollectionLoader()

    # Collection config
    collection_config = AnsibleCollectionConfig(loader)

    # Context
    context._init_global_context(collection_config)

    # Inventory
    variable_manager = VariableManager()
    loader = DataLoader()

# Generated at 2022-06-23 06:35:10.073319
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import yaml # For testing

    # arrange
    ds = yaml.safe_load("""
        - import_playbook: import_playbook_file.yml
          vars:
            a_var: a_value
            another_var: another_value
          when: not rs_at_capacity
    """)

    # act
    new_ds = PlaybookInclude().preprocess_data(ds)

    # assert
    assert(new_ds['import_playbook'] == 'import_playbook_file.yml')
    assert(new_ds['vars']['a_var'] == 'a_value')
    assert(new_ds['vars']['another_var'] == 'another_value')

# Generated at 2022-06-23 06:35:21.925768
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.playbook.play import Play

    playbook_include_object = PlaybookInclude()
    ds = {'import_playbook': '../roles/common/tasks/main.yml'}

    # Check method return type
    playbook_obj = playbook_include_object.load_data(ds, None)
    assert isinstance(playbook_obj, Playbook)

    # Check method return type
    basedir = '/home/user'
    playbook_obj = playbook_include_object.load_data(ds, basedir)
    assert isinstance(playbook_obj, Playbook)

    # Check method return type
    basedir = '/home/user'
    ds = {'import_playbook': 'my.ansible.collection/roles/common/tasks/main.yml'}
    playbook

# Generated at 2022-06-23 06:35:30.914007
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
  # Create a play for testing
  from ansible.playbook import Playbook
  from ansible.playbook.play_context import PlayContext
  pb_inst = Playbook()
  play_inst = pb_inst.load('- hosts: localhost\n  tasks:\n    - debug: msg="something"')[0]
  PlaybookInclude.load("ansible/test.yaml", "/tmp/", loader=pb_inst._loader, variable_manager=pb_inst._variable_manager)

  # Create a PlaybookInclude for testing
  pbi_inst = PlaybookInclude.load("ansible/test.yaml", "/tmp/", loader=pb_inst._loader, variable_manager=pb_inst._variable_manager)

  #Test the "load" method

# Generated at 2022-06-23 06:35:32.817950
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():

    # TODO: make this a unit test when the module is python3-compatible
    pass

# Generated at 2022-06-23 06:35:42.160155
# Unit test for method preprocess_data of class PlaybookInclude

# Generated at 2022-06-23 06:35:55.169722
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    # Test with valid data
    ds = dict(
        import_playbook = "./some_playbook.yml"
    )
    pb = PlaybookInclude.load(ds, basedir=".")
    assert pb.import_playbook == "./some_playbook.yml"
    assert pb.vars == {}

    # Test with invalid data
    ds = dict(
        include = "./some_playbook.yml"
    )
    try:
        pb = PlaybookInclude.load(ds, basedir=".")
        assert False
    except AnsibleParserError as e:
        assert e.obj == ds

    # Test with different syntax
    ds = dict(
        include = "./some_playbook.yml"
    )

# Generated at 2022-06-23 06:36:04.052148
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    pb = PlaybookInclude.load({
        'test_playbook': 'test.yml',
        'test_playbook_2': 'test2.yml',
        'test_playbook_3': 'test3.yml'
    }, loader=loader, basedir='/')

    assert isinstance(pb, Playbook)
    assert len(pb.get_plays()) == 3



# Generated at 2022-06-23 06:36:16.495204
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import become_loader

    # create a `PlayContext` object for use with `PlaybookInclude`
    become_loader.get('sudo')
    pc = PlayContext()
    pc._become = 'sudo'
    pc.become_flags = ['-H']

    # create a `PlaybookInclude` object (Note this object does not directly
    # map to a YAML block in the playbook. It's a "virtual" object)
    #
    # The `import_playbook` value is the only thing actually required to load
    # a playbook include. This can be done directly by passing a 'string' value
    # as the `import_playbook` argument.

# Generated at 2022-06-23 06:36:22.788726
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play_context import PlayContext

# Generated at 2022-06-23 06:36:31.307014
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    playbook_include = PlaybookInclude()
    assert playbook_include.vars == {}
    assert playbook_include.when == []
    assert playbook_include._valid_attrs["import_playbook"] == FieldAttribute(isa='string')
    assert playbook_include._valid_attrs["vars"] == FieldAttribute(isa='dict', default=dict)
    playbook_include._vars = {1: 1}
    assert playbook_include.vars == {1: 1}
    playbook_include.when = [1]
    assert playbook_include.when == [1]


# Generated at 2022-06-23 06:36:42.729868
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # Test PlaybookInclude with option - file_name and vars
    import json

    playbook_include = PlaybookInclude.load({"import_playbook": "included_playbook.yml", "vars": {"key1": "value1", "key2": "value2"}}, "/")

    assert playbook_include.import_playbook == 'included_playbook.yml'
    assert playbook_include.vars == {"key1": "value1", "key2": "value2"}

    # Test PlaybookInclude with option - file_name and with 'vars' and 'params'

# Generated at 2022-06-23 06:36:43.756379
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # TODO
    assert True

# Generated at 2022-06-23 06:36:53.549329
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    d = {}
    d['import_playbook'] = '/dev/null'
    d['tags'] = 'all'
    d['vars'] = {'a': '1'}
    pb = PlaybookInclude.load(d, '/tmp')
    assert isinstance(pb, Playbook)
    assert len(pb.plays) == 1
    p = pb.plays[0]
    assert isinstance(p, Play)
    assert len(p.tasks) == 0
    assert len(p.handlers) == 0

# Generated at 2022-06-23 06:36:57.738275
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    source = dict(import_playbook="foo.yml")
    pb = PlaybookInclude(source)
    assert pb.import_playbook == "foo.yml"
    assert pb.vars == {}

# Generated at 2022-06-23 06:37:05.831928
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook = """
    - hosts: localhost
      tasks:
        - include_playbook: foo.yml
          vars:
            foo: bar
    """

    task = PlaybookInclude.load(data=playbook, basedir='.')
    result_tasks = task._entries[0].tasks[0]
    assert result_tasks['include_playbook'] == 'foo.yml'
    assert result_tasks['vars']['foo'] == 'bar'

# Generated at 2022-06-23 06:37:19.256245
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    ds = {'import_playbook': 'playbook.yml'}
    instance = PlaybookInclude()
    assert instance.preprocess_data(ds) == {'import_playbook': 'playbook.yml'}

    ds = {'include': 'playbook.yml'}
    instance = PlaybookInclude()
    assert instance.preprocess_data(ds) == {'import_playbook': 'playbook.yml'}

    ds = {'import_playbook': 'playbook.yml tags=all vars="a=1 b=2"', 'tags': 'first-import'}
    instance = PlaybookInclude()

# Generated at 2022-06-23 06:37:25.896102
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    playbook_include = PlaybookInclude()
    assert playbook_include.import_playbook == ''
    assert playbook_include.vars == {}

# Generated at 2022-06-23 06:37:36.921356
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():

    # import here to avoid a dependency loop
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    import ansible.constants as C
    from ansible.utils.collection_loader._collection_finder import AnsibleCollectionRef, _get_collection_playbook_path
    from ansible.vars.manager import VariableManager

    # For more information on fixture_path and loading YAML files see:
    #
    # https://pytest-ansible.readthedocs.io/en/v0.5.0/writing_tests.html#accessing-the-fixtures
    #
    # and
    #
    # https://docs.pytest.org/en/stable/tmpdir.html

    # Example PlaybookInclude object to load

# Generated at 2022-06-23 06:37:49.227763
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    '''
    Test case for the method preprocess_data of class PlaybookInclude
    '''

    import_playbook = PlaybookInclude()
    ds = {'import_playbook': 'playbook1.yml', 'vars': {'param1': 'value1'}}
    new_ds = AnsibleMapping()
    new_ds[C.STRING_IMPORT_PLAYBOOK_FORMAT_PARAMETER] = 'playbook1.yml'
    new_ds['vars'] = {'param1': 'value1'}
    assert new_ds == import_playbook.preprocess_data(ds)

# Generated at 2022-06-23 06:38:01.692198
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    ds = dict(
        import_playbook=dict(
            file='/tmp/play.yml'
        )
    )
    pb = PlaybookInclude.load(ds, basedir='/tmp', variable_manager=VariableManager(), loader=DataLoader())
    assert isinstance(pb, Playbook)
    assert len(pb._entries) == 1
    e = pb._entries[0]
    assert isinstance(e, Play)
    assert e.name == 'play.yml'


# Generated at 2022-06-23 06:38:04.425105
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    p = PlaybookInclude()
    a = PlaybookInclude.load({"vars": {"a": "b"}, "import_playbook": "abc.yml"}, ".")
    assert a



# Generated at 2022-06-23 06:38:18.151105
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    # Array of test cases that return a Playbook object
    test_case_0 = [
        {
            "import_playbook": "roles/common/tasks/main.yml",
            "vars": {
                "foo": "bar"
            }
        },
        Playbook(loader=None)
    ]

# Generated at 2022-06-23 06:38:31.013275
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    test_str = u"test.yml tag1,tag2 var1=1 var2=2"

    play = AnsibleBaseYAMLObject()
    play.ansible_pos = (0, 0)

    play.data = dict(
        import_playbook='test.yml',
        vars={'var1': '1'},
    )
    pb = PlaybookInclude()
    ds = pb.preprocess_data(play)
    assert 'import_playbook' in ds
    assert 'test.yml' == ds['import_playbook']
    assert 'vars' in ds
    assert 'var1' in ds['vars']

# Generated at 2022-06-23 06:38:36.373023
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    print("\n============================= test_PlaybookInclude_load =============================")
    data = dict(
        import_playbook='test_import.yml',
        when=dict(
            test_import="True"
        )
    )
    pbi = PlaybookInclude.load(data, basedir='playbooks/')
    print("pbi: %s" % pbi)


# Generated at 2022-06-23 06:38:49.937695
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible import constants as C

    # test to ensure the class can load a yaml file with a list of dicts
    loader, inventory, variable_manager = C.load_extra_vars_file(C.DEFAULT_EXTRA_VAR_PATH)

    basedir = './test/unit/playbook_include'


# Generated at 2022-06-23 06:39:02.744837
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.playbook_include import PlaybookInclude
    from collections import OrderedDict

    ds_dict = {'include': 'roles/test.yml',
               'name': 'test playbook'}
    # new_ds must return an ordereddict
    new_ds = PlaybookInclude.preprocess_data(None, ds_dict)
    assert isinstance(new_ds, OrderedDict)
    assert new_ds == OrderedDict([
        ('import_playbook', 'roles/test.yml'), ('name', 'test playbook')
    ])

    ds_dict = {'include': 'roles/test.yml',
               'vars': {'legacy': 'var'},
               'name': 'test playbook'}
    # new_ds must return an ordered

# Generated at 2022-06-23 06:39:04.016625
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    assert True

# Generated at 2022-06-23 06:39:16.190718
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    pb = PlaybookInclude.load({u'import_playbook': u'playbook.yml', u'tags': u'all'}, basedir='.')
    assert isinstance(pb, Playbook)
    assert isinstance(pb._entries[0], Play)
    assert isinstance(pb._entries[1], Block)
    assert isinstance(pb._entries[1].block[0], Task)
    assert isinstance(pb._entries[1].block[1], Handler)
    assert isinstance(pb._entries[2], Play)

# Generated at 2022-06-23 06:39:30.643602
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = PlayContext()

    # Test for the wrong format of ds value
    ds = """
    hello: "world"
    """
    try:
        PlaybookInclude.load(ds, '', variable_manager, loader)
        assert False, 'AnsibleParserError should be raised'
    except AnsibleParserError:
        pass

    # Test for the wrong format of "vars" value
    ds = """
    import_playbook: /etc/ansible/roles/common/tasks/main.yml
    vars:
        hello: "world"
    """

# Generated at 2022-06-23 06:39:42.906778
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # Data structures used to test load method
    basedir = 'basedir'
    variable_manager = None
    loader = None
    data = {'hosts': 'hosts', 'import_playbook': 'import_playbook', 'vars': 'vars',
            'connection': 'connection', 'serial': 'serial', 'gather_facts': 'gather_facts'}
    # Test when values of data is None
    data = {'import_playbook': None}
    try:
        PlaybookInclude.load(data, basedir, variable_manager, loader)
    except Exception as err:
        assert isinstance(err, AnsibleParserError)
    # Test when values of data is int
    data = {'import_playbook': 1}

# Generated at 2022-06-23 06:39:55.580099
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    test_file_path = './tests/test_data/test_playbook_include/test_play_import_playbook.yml'
    test_file_dir = 'tests/test_data/test_playbook_include'

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host, Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    include = PlaybookInclude()

# Generated at 2022-06-23 06:40:06.473088
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Time to setup a mocker for load_data
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.hosts import Hosts
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    playbook_include = PlaybookInclude()
    display.verbosity = 3

# Generated at 2022-06-23 06:40:19.466748
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Import here to avoid a dependency loop
    from ansible.playbook.play import Play

    b_obj = PlaybookInclude()
    c_obj = b_obj.load_data({'import_playbook': 'test.yml'}, '/')

    assert not isinstance(c_obj, PlaybookInclude)
    assert isinstance(c_obj, Play)
    assert c_obj._entries[0]._included_path == '/'
    assert c_obj._entries[0]._included_name == 'test.yml'
    assert c_obj._included_path == '/'
    assert c_obj._included_name == 'test.yml'
    assert c_obj._entries[0]._included_conditional == []

    # this Playbook also contains a play, and the included

# Generated at 2022-06-23 06:40:21.041514
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    """Test the load method of class PlaybookInclude
    """
    pass

# Generated at 2022-06-23 06:40:27.325541
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    playbook_include = PlaybookInclude()
    assert playbook_include._import_playbook is None
    assert playbook_include._vars == dict()

    playbook_include = PlaybookInclude(import_playbook='test.yml')
    assert playbook_include._import_playbook == 'test.yml'

    playbook_include.import_playbook = 'test1.yml'
    assert playbook_include.import_playbook == 'test1.yml'


# Generated at 2022-06-23 06:40:39.572347
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    ''' Unit test for method preprocess_data of class PlaybookInclude '''

    from ansible.utils.display import Display
    display = Display()

    import textwrap
    playbook_include = textwrap.dedent(
        """
        - import_playbook: '{playbook}'
        """
    )
    playbook_include_dict = {
        'import_playbook': '{playbook}'
    }

    display.verbosity = 3

    import tempfile
    fd_playbook, playbook_filename = tempfile.mkstemp()
    with os.fdopen(fd_playbook, 'wb') as playbook_file:
        playbook_file.write(playbook_include)

    import os
    from ansible.parsing.dataloader import DataLoader
    dataloader = DataLoader()

# Generated at 2022-06-23 06:40:51.012477
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    # prepare test examplary PlaybookInclude object
    test_include = PlaybookInclude(
        load_data=dict(
            import_playbook='test_import_playbook.yaml',
            vars=dict(
                test_include_var='test_include_var_value',
            ),
            tags='test_include_tag_1,test_include_tag_2'
        )
    )

    # prepare test examplary Playbook object

# Generated at 2022-06-23 06:40:51.833264
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass


# Generated at 2022-06-23 06:40:56.992886
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
  # Test load with empty data and default parameters
  playbook_include = PlaybookInclude()
  assert playbook_include.load(data=None, basedir=None, variable_manager=None, loader=None) is None
  assert playbook_include.load_data(ds=None, basedir=None, variable_manager=None, loader=None) is None
  assert playbook_include.preprocess_data(ds=None) is None

# Generated at 2022-06-23 06:41:08.581233
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    import ansible.playbook

    # easy test: load a file with no params
    ds = dict(
        import_playbook = 'main.yml'
    )
    pb = PlaybookInclude.load(data=ds, basedir='.')
    assert isinstance(pb, ansible.playbook.Playbook)
    assert len(pb._entries) == 2
    assert pb._entries[0].name == 'foo'

    # test with params, which is deprecated
    ds = dict(
        import_playbook = 'main.yml with_items=1:2'
    )
    pb = PlaybookInclude.load(data=ds, basedir='.')
    assert isinstance(pb, ansible.playbook.Playbook)
    assert len(pb._entries) == 2


# Generated at 2022-06-23 06:41:19.798541
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    fixture_path = os.path.join(os.path.dirname(__file__), 'fixtures', 'playbook_include_load_data.yml')
    variable_manager = None
    loader = None
    basedir = os.path.dirname(os.path.abspath(to_bytes(fixture_path, errors='surrogate_or_strict')))

    playbook = PlaybookInclude.load(data=loader.load_from_file(fixture_path), basedir=basedir, variable_manager=variable_manager, loader=loader)

    assert isinstance(playbook, Playbook)
    assert len(playbook._entries) == 1

    # load_data() should reset _included_path for

# Generated at 2022-06-23 06:41:28.601010
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    basedir = os.path.dirname(__file__)
    loader = None


    playbook = basedir + "/playbookinclude_playbook.yml"
    display.verbosity = 3

    variable_manager = VariableManager()
    variable_manager.extra_vars = {
        "var_one": "This is variable one",
        "var_two": "This is variable two",
        "var_three": "This is variable three",
        "var_four": "This is variable four",
    }

    with open(playbook, "r") as f:
        data = f.read()
    ds = PlaybookIn

# Generated at 2022-06-23 06:41:41.203183
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook, PlaybookInclude

    # import_playbook = test/test_import_playbook.yml
    ds = { "import_playbook" : "test/test_import_playbook.yml" }
    basedir = os.path.dirname(__file__)
    playbook_include = PlaybookInclude.load(data=ds, basedir=basedir)
    assert playbook_include == Playbook(loader=None, variable_manager=None, basedir=basedir)

    # import_playbook = test/test_import_playbook.yml
    # Extra arguments are deprecated
    ds = { "import_playbook" : "test/test_import_playbook.yml with_items=loop_list" }

# Generated at 2022-06-23 06:41:49.683665
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import ansible.parsing.yaml.objects
    import os
    import tempfile
    import yaml

    # Create temp directory
    tmpdir = tempfile.mkdtemp()

    # Create playbooks
    playbook_filename = 'playbook.yml'
    playbook_path = os.path.join(tmpdir, playbook_filename)

# Generated at 2022-06-23 06:41:54.668440
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    ii = PlaybookInclude(import_playbook="shipit.yml", vars={"foo": "bar"}, tags=['all'])
    assert ii.import_playbook == "shipit.yml"
    assert ii.vars == {'foo': 'bar'}
    assert ii.tags == ['all']
    assert not ii.when

# Generated at 2022-06-23 06:42:05.393938
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    print()
    # Tests for method load
    # 1. basic test
    ds = {
        'import_playbook': 'site.yml',
        'vars': {'key1': 'val1', 'key2': 'val2'},
        'tags': 'globaltag'
    }
    basedir = '/home/vagrant'
    pbi = PlaybookInclude().load(ds, basedir)
    assert pbi._import_playbook == ds['import_playbook']
    assert pbi._vars == ds['vars']
    assert pbi._tags == ds['tags'].split(',')


# Generated at 2022-06-23 06:42:11.902629
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    yaml_ds = dict(
        import_playbook = "test_playbook.yml",
        vars = dict(
            foo = "bar"
        )
    )

    res = PlaybookInclude.load(data=yaml_ds, basedir=".")

    assert isinstance(res, PlaybookInclude)
    assert res.import_playbook == "test_playbook.yml"
    assert res.vars == dict(foo="bar")

# Generated at 2022-06-23 06:42:24.014151
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Basic success case with no parameters
    raw_ds = {
        'import_playbook': 'test1.yml',
    }
    expected_ds = {
        'import_playbook': 'test1.yml',
    }

    ds = PlaybookInclude().preprocess_data(raw_ds)
    assert ds == expected_ds

    # Basic success case with parameters and vault-encrypted parameters
    raw_ds = {
        'import_playbook': 'test1.yml another_play.yml',
        'vars': {
            'func1': 'value1',
            'func2': AnsibleVaultEncryptedUnicode('value2')
        }
    }

# Generated at 2022-06-23 06:42:35.647312
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    '''
    This is a first test of the method load of class PlaybookInclude. It tests
    whether a playbook include without tags or variables is correctly loaded.
    '''
    # create an instance of AnsibleBaseYAMLObject and assign it to a variable
    # data_structure
    data_structure = AnsibleBaseYAMLObject()
    # set the attribute _ds to some data structure consisting of an import_playbook
    # directive
    data_structure._ds = 'import_playbook: hello'

    # call the method load of class PlaybookInclude on the object
    # PlaybookInclude.load(data, basedir)
    # the data structure you've assigned to the attribute _ds is the data and
    # the current directory is the basedir

# Generated at 2022-06-23 06:42:37.286339
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    assert PlaybookInclude


# Constructor test for class PlaybookInclude

# Generated at 2022-06-23 06:42:46.693274
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''
    Unit test for method load_data of class PlaybookInclude
    '''
    import unittest
    from ansible.module_utils.six.moves import builtins

    class TestPlaybookIncludeLoadData(unittest.TestCase):
        '''
        TestPlaybookIncludeLoadData class is a subclass of unittest.TestCase
        This class test the method load_data from class PlaybookInclude
        '''
        def setUp(self):
            '''
            The method setUp create a PlaybookInclude object for future actions
            '''
            self.playbook_include = PlaybookInclude()

        def tearDown(self):
            '''
            The method tearDown delete the variable playbook_include
            '''
            del self.playbook_include


# Generated at 2022-06-23 06:42:47.868456
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-23 06:42:49.903453
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # PlaybookInclude.load_data() uses Playbook.load() which is already tested in test_playbook

    pass

# Generated at 2022-06-23 06:43:00.885305
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Test some valid datastructures
    # No args
    ds = AnsibleMapping()
    PlaybookInclude.preprocess_data(ds)  # Should not raise an exception

    # No args with invalid data
    ds = AnsibleMapping(dict(foo="foo"))
    try:
        PlaybookInclude.preprocess_data(ds)
        assert False, "AnsibleParserError expected"
    except AnsibleParserError:
        pass

    # With valid args
    ds = AnsibleMapping(dict(import_playbook="foo.yml"))
    PlaybookInclude.preprocess_data(ds)  # Should not raise an exception

    # With valid args and invalid data
    ds = AnsibleMapping(dict(import_playbook="foo.yml", foo="foo"))

# Generated at 2022-06-23 06:43:10.037967
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # Define test case datastructure
    ds = AnsibleMapping({'import_playbook': 'test.yml', 'vars': {'foo': 'bar'}, 'tags': 'tag'})

    # Test when the datastructure is empty
    ds = AnsibleMapping()
    try:
        PlaybookInclude.load(ds, '.')
        assert False, "AnsibleParserError not raised"
    except AnsibleParserError as e:
        assert str(e) == "playbook import parameter is missing"

    # Test when the datastructure is not a dict
    ds = "notdict"

# Generated at 2022-06-23 06:43:21.745346
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.template import Templar

    p = PlaybookInclude.load({'import_playbook': 'import_playbook_test.yml', 'tags': 'tag1,tag2'}, None)
    assert p.import_playbook == 'import_playbook_test.yml'
    for tag in ['tag1', 'tag2']:
        assert tag in p.tags
    assert p.vars == {}
    assert p.when is None

    # test string and dict variables together
    p = PlaybookInclude.load({'import_playbook': 'import_playbook_test.yml', 'tags': 'tag1,tag2', 'vars': {'key1': 'value1', 'key2': {'key3': 'value2'}}}, None)

# Generated at 2022-06-23 06:43:34.821140
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    #
    # Check that the test is a valid test
    #
    assert PlaybookInclude.preprocess_data.__name__ == 'preprocess_data'

    #
    # Create a playbook-include-object with a dict of a data-structure
    #
    test_object = PlaybookInclude({})

    #
    # Check that the data-structure is created properly
    #
    try:
        assert isinstance(test_object.data, dict)
        assert test_object.data == {}
    except:
        raise

    #
    # Check that the data-structure is passed to preprocess_data()
    # properly and correctly
    #
    correct_data = AnsibleMapping()
    correct_data['import_playbook'] = '/home/ansible/file.yml'
    correct_data

# Generated at 2022-06-23 06:43:42.522683
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader

    # test load_data
    pb_include = PlaybookInclude.load(
        dict(
            # metadata
            ansible_pos=dict(
                lineno=1,
                colno=0
            ),
            # import
            include='utils.yml',
            when=dict(
                is_test='True'
            )
        ),
        "/path/to/playbooks",
        variable_manager=None,
        loader=DataLoader()
    )

    # Check that the result is correct
    assert(isinstance(pb_include, Playbook))
    assert(len(pb_include._entries) == 1)

# Generated at 2022-06-23 06:43:54.659987
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    import sys
    # Needed for the following import to find modules in ../../../lib/ansible/modules
    sys.path.insert(0, '../../../lib/ansible/modules')

    from ansible.playbook.play import Play
    from ansible.playbook import PlaybookInclude

    yaml_data = """
    import_playbook: test.yml
    """

    data = yaml.load(yaml_data)

    obj = PlaybookInclude.preprocess_data(data)

    assert obj.import_playbook == 'test.yml'

    yaml_data = """
    import_playbook: test.yml tags=test
    """

    data = yaml.load(yaml_data)

    obj = PlaybookInclude.preprocess_data(data)

    assert obj

# Generated at 2022-06-23 06:43:55.294626
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    assert True

# Generated at 2022-06-23 06:44:07.249829
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # here we create a playbook include
    playbook_include = PlaybookInclude()
    # here we check if the method load_data is working correctly
    # for the case when we have a short name for the playbook to be included
    playbook_include.load_data(ds={'import_playbook': 'mysql_playbook.yaml'}, basedir='.')
    # for the case when we have a FQCN for the playbook to be included
    playbook_include.load_data(ds={'import_playbook': 'ansible.builtin.file:mysql_playbook.yaml'}, basedir='.')
    # for the case when we have a path to the playbook to be included

# Generated at 2022-06-23 06:44:15.897206
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():

    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    filename = 'test_data/import.yml'
    basedir = 'test_data/'

    data = open(filename).read()
    data = data.replace('{basedir}', basedir)

    loader = DataLoader()
    variable_manager = VariableManager()
    pb = PlaybookInclude.load(data, basedir, variable_manager, loader=loader)

    print(pb)
    assert pb is not None

# Generated at 2022-06-23 06:44:27.376701
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include = PlaybookInclude()

    # Case 1: original_ds is a dictionary, contains "import_playbook"
    # Expectation: key "import_playbook" will be replaced by key "import_playbook"
    original_ds = {
        "import_playbook": "test.yml"
    }

    expected_new_ds = {
        "import_playbook": "test.yml"
    }
    new_ds = playbook_include.preprocess_data(original_ds)
    assert new_ds == expected_new_ds, "Unit test for PlaybookInclude_preprocess_data failed"

    # Case 2: original_ds is a dictionary, contains key "vars"
    # Expectation: key "vars" will not be replaced