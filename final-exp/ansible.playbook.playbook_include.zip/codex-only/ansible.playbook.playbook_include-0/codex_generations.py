

# Generated at 2022-06-23 06:34:31.556975
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # Create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # Write a playbook inside a collection
    playbook = "---\n" + \
               "- hosts: 127.0.0.1\n" + \
               "  connection: local\n" + \
               "  gather_facts: no\n" + \
               "  tasks:\n" + \
               "    - debug:\n" + \
               "        msg: Test\n"
    with open("test_col_playbook_include.yml", "w") as f:
        f.write(playbook)

    # get and load the playbook inside the collection
    playbook = "---\n" + \
               "- include_tasks: test_col_playbook_include.yml\n"

# Generated at 2022-06-23 06:34:32.461306
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    print("hello")

# Generated at 2022-06-23 06:34:44.081226
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    template_ds =  dict(
        import_playbook = "{{ x }}",
        vars = dict(
            y = "{{ y }}"
        ),
        tags = [ "z", "{{ z }}" ],
        when = "{{ w }}"
    )

    # Create a PlaybookInclude instance with a dictionary
    pb_include = PlaybookInclude.load(ds=template_ds, basedir="")

    # Create a dummy variable manager
    vm = ansible.vars.VariableManager()
    vm.extra_vars = dict(
        w = "1",
        x = "path/to/playbook",
        y = "foo",
        z = "bar"
    )

    # Create a Playbook instance with a dictionary

# Generated at 2022-06-23 06:34:52.738163
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    data = dict(
        import_playbook='test.yml',
        vars={
            'key1': 'value1',
            'key2': 'value2',
        }
    )
    data2 = dict(
        import_playbook='test.yml',
        key1='value1',
        key2='value2',
    )
    ds = PlaybookInclude()
    ds.load_data(ds=data, basedir='/tmp')
    ds.load_data(ds=data2, basedir='/tmp')


# Generated at 2022-06-23 06:35:04.924606
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.playbook.play import Play

    test_play = Play.load(dict(name='foo'), variable_manager={}, loader=None)
    a = PlaybookInclude.load(
        dict(
            import_playbook='/test/test.yml',
            tags=['testtag'],
            vars=dict(
                foo='bar',
                baz='bat',
                test_boolean=False,
            )
        ),
        basedir="/test/",
        variable_manager={},
        loader=None
    )._entries[0]


# Generated at 2022-06-23 06:35:05.959045
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # Test the load function in PlaybookInclude class
    pass


# Generated at 2022-06-23 06:35:07.411980
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    p = PlaybookInclude()
    assert p is not None

# Generated at 2022-06-23 06:35:19.660084
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # the data structure for `preprocess_data` method is a dict.
    # the following params seems to be the most complex entry.
    test_ds = {
        'import_playbook': 'includes/common.yml',
        'connection': 'local',
        'vars': {
            'version': '1.2.3',
        },
    }

    expected = {
        'import_playbook': 'includes/common.yml',
        'connection': 'local',
        'vars': {
            'version': '1.2.3',
        },
    }

    new_ds = PlaybookInclude.load_data(ds=test_ds, basedir='.')

    assert new_ds.import_playbook == expected['import_playbook']
    assert new_ds.connection == expected['connection']

# Generated at 2022-06-23 06:35:21.534138
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    PlaybookInclude(import_playbook='/tmp/foo.yml', tags=['bar'])



# Generated at 2022-06-23 06:35:29.576725
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # import here to avoid a dependency loop
    from ansible.playbook import Playbook
    PlaybookInclude_obj=PlaybookInclude()
    PlaybookInclude_obj.import_playbook = "import_playbook_test"
    Playbook_instance=PlaybookInclude_obj.load_data(ds={'import_playbook':'import_playbook_test'},
        basedir = os.path.abspath(__file__), variable_manager='variable_manager', loader='loader')
    assert type(Playbook_instance) == Playbook
    assert Playbook_instance.basedir == os.path.abspath(__file__)


# Generated at 2022-06-23 06:35:41.108194
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    import os
    import sys
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    playbook_include = PlaybookInclude()

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_vars({"hostvars": {"test": "var"}, "groupvars": {'all': {'some': 'var'}}})

    res = playbook_include.load_data({"some": "var", "import_playbook": "test.yaml"}, ".", variable_manager=variable_manager, loader=loader)

    assert isinstance(res, Play)
    assert res._included_vars == {"some": "var"}
    assert not res._included_path
   

# Generated at 2022-06-23 06:35:47.463863
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook, Play

    playbook = Playbook()
    playbook.add_play(Play().load({
          'name': 'play',
          'hosts': 'all',
          'import_playbook': './playbook.yml'
    }))
    PlaybookInclude.load(playbook.get_plays()[0].get_import_playbook()[0].get_ds(), '', None, None)

# Generated at 2022-06-23 06:35:55.534636
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import pytest
    from ansible.parsing.vault import VaultLib
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from io import BytesIO
    from ansible.playbook.block import Block

    playbook_data_str = """\
- hosts: localhost
  tasks:
  - include_tasks: include.yml
"""
    include_data_str = """\
- block:
    tasks:
    - debug:
        msg: This is a debug message
  rescue:
    - debug:
        msg: This is the rescue message
  always:
    - debug:
        msg: This is the always message
"""

# Generated at 2022-06-23 06:36:06.170845
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible import context
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.playbook import Playbook
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    loader = 'Disable'
    variable_manager = VariableManager()
    variable_manager._extra_vars = dict(collections_paths=['./'])
    template = Templar(loader=loader, variables=variable_manager._extra_vars)

    # Test error case with ansible_pos
    ds = AnsibleBaseYAMLObject()
    ds.ansible_pos = {'lnum':5, 'col':3}

# Generated at 2022-06-23 06:36:08.741693
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    p = PlaybookInclude()
    assert p.import_playbook == None
    assert p.vars == {}

# Generated at 2022-06-23 06:36:19.184417
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include = PlaybookInclude()

    # Test with empty dict
    assert playbook_include.preprocess_data({}) == {}, "Failed to return empty dict when providing {}"

    # Test with simple dict
    assert playbook_include.preprocess_data({'import_playbook': "test.yml"}) == {'import_playbook': "test.yml"}, "Failed to return {'import_playbook': test.yml} when providing {'import_playbook': test.yml}"

    # Test with dict with simple other parameter

# Generated at 2022-06-23 06:36:30.510163
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude
    class AnsibleModuleFake:
        def __init__(self):
            self.params = {}

    class VariableManager:
        def __init__(self):
            self.vars = {'role_name': 'somerolename'}

    class Loader:
        def __init__(self, variable_manager):
            self.path_basedir = os.path.normcase(os.path.normpath(os.path.join(os.getcwd(), 'test')))
            self.paths = [os.path.normcase(os.path.normpath(os.path.join(self.path_basedir, 'test.yml')))]
            self.variable_manager = variable_manager



# Generated at 2022-06-23 06:36:42.214766
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars import VariableManager

    class MockLoader(object):
        pass

    class MockVariableManager(VariableManager):
        def __init__(self, loader):
            super(MockVariableManager, self).__init__()
            self._loader = loader

        def get_vars(self, play=None, host=None, task=None, include_hostvars=True):
            return dict(a="abc", b=dict(c="def", d="ghi"))

    class MockHost(object):
        pass

    class MockPlay(Play):
        pass

    class MockTask(object):
        pass

    basedir = "./tests/playbooks"
    loader = MockLoader()

# Generated at 2022-06-23 06:36:54.080719
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.template import Templar
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager
    import os
    import sys

    curpath = os.path.dirname(os.path.realpath(__file__))
    '''
    Test PlaybookInclude.load_data by loading a real world embedded playbook
    '''

# Generated at 2022-06-23 06:37:06.703336
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    yaml_ds = """
    - import_playbook: /path/to/import_playbook.yml
    """

    yaml_ds2 = """
    - import_playbook: /path/to/import_playbook.yml
      vars:
        foo: bar
    """

    # Generate a playbook
    pb = PlaybookInclude.load(yaml_ds, variable_manager=VariableManager(), loader=DataLoader())
    pb2 = PlaybookInclude.load(yaml_ds2, variable_manager=VariableManager(), loader=DataLoader())

    # Check attributes
    assert p

# Generated at 2022-06-23 06:37:07.612181
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-23 06:37:20.419702
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # create a dummy loader object
    fake_loader = DictDataLoader({})

    # create a fake variable manager
    fake_variables = VariableManager()

    def test(ds, expect_pass, expected_ds=None, expected_msg=None, expect_exception=False):
        '''
        Tests the preprocess_data() method of the PlaybookInclude class
        '''

        # create a new PlaybookInclude object
        p = PlaybookInclude()

        # call preprocess_data()

# Generated at 2022-06-23 06:37:36.060653
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    class A(PlaybookInclude):
        def __init__(self):
            self.vars = dict()

    # Test "import_playbook: xxx" is converted to import_playbook: xxx
    ds = {'import_playbook': 'xxx'}
    a = A()
    assert a.preprocess_data(ds) == dict(import_playbook='xxx')

    # Test "include: xxx" is converted to import_playbook: xxx
    ds = {'include': 'xxx'}
    a = A()
    assert a.preprocess_data(ds) == dict(import_playbook='xxx')

    # Test "import_playbook: xxx tags=xxx" is converted to import_playbook=xxx tags=xxx

# Generated at 2022-06-23 06:37:46.859708
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    '''
    Unit test for ansible.playbook.play_include.PlaybookInclude()
    '''
    # first, we use the original parent method to correctly load the object
    # via the load_data/preprocess_data system we normally use for other
    # playbook objects
    playbook_include = PlaybookInclude.load({'import_playbook': './tests/playbook_include.yml'}, './')

    assert playbook_include.import_playbook == './tests/playbook_include.yml'

# Generated at 2022-06-23 06:38:00.304118
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # 1. Test typical case:
    # {"import_playbook": "foo.yaml"}
    pb_i = PlaybookInclude()
    ds = AnsibleMapping()
    ds['import_playbook'] = 'foo.yaml'
    processed = pb_i.preprocess_data(ds)
    assert 'import_playbook' in processed
    assert processed['import_playbook'] == 'foo.yaml'

    # 2. Test when vars is specified
    # {"vars": { "var1": "foo", "var2": "bar" }, "import_playbook": "foo.yaml"}
    pb_i = PlaybookInclude()
    ds = AnsibleMapping()
    ds['import_playbook'] = 'foo.yaml'
    ds['vars']

# Generated at 2022-06-23 06:38:10.447375
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # PlaybookInclude.preprocess_data expects an AnsibleMapping
    assert PlaybookInclude.load(None, None).preprocess_data({}) == {}
    assert PlaybookInclude.load(None, None).preprocess_data(AnsibleMapping()) == AnsibleMapping()

    # Test __init__
    assert PlaybookInclude.load(None, None).preprocess_data({'import_playbook': 'main.yaml'}) == {'import_playbook': 'main.yaml'}
    assert PlaybookInclude.load(None, None).preprocess_data({'import_playbook': 'main.yaml', 'tags': 'tag1'}) == {'import_playbook': 'main.yaml', 'tags': 'tag1'}

# Generated at 2022-06-23 06:38:13.595874
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # instantiate an object
    pbi = PlaybookInclude

    # get the load_data method
    method = getattr(pbi, 'load_data')

    #assert(method)

# Generated at 2022-06-23 06:38:14.271103
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-23 06:38:19.696980
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    ds = dict(import_playbook='test.yml', tags='tag1,tag2')
    pb = PlaybookInclude.load(ds)
    assert isinstance(pb, PlaybookInclude)
    assert pb.import_playbook == 'test.yml'
    assert 'tag1' in pb.tags and 'tag2' in pb.tags



# Generated at 2022-06-23 06:38:21.804064
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # PlaybookInclude class has no load method
    pass


# Generated at 2022-06-23 06:38:22.710472
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-23 06:38:30.770031
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.playbook.play import Play
    pb = PlaybookInclude()
    assert pb is not None
    try:
        pb._load_playbook_data('tasks/main.yml')
        assert False
    except NotImplementedError:
        assert True
    assert pb.vars == {}
    data = {
        'import_playbook':'playbook.yml',
        'vars': {'var1':'value1', 'var2':'value2'}
    }
    new_pb = pb.load(data, '/tmp/')
    assert isinstance(new_pb, PlaybookInclude)
    assert new_pb.import_playbook == 'playbook.yml'

# Generated at 2022-06-23 06:38:40.112548
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    import yaml
    from ansible.playbook.task import Task
    from ansible.template import Templar

    # Create template and variables
    template = Templar(loader=None, variables={})

    # Create a task
    task_ds = yaml.safe_load("""\
    - name: test
      debug:
        msg: var_test
      vars:
        var_test: 'test string'
    """)
    task = Task().load(task_ds, template)

    # Create an included playbook
    playbook_include_ds = yaml.safe_load("""\
    - import_playbook: include.yml
      vars:
        var_test: 'override string'
    """)
    playbook_include = PlaybookInclude().load(playbook_include_ds, '.')

    # Create

# Generated at 2022-06-23 06:38:48.344635
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.taggable import Tag

    ds = AnsibleMapping()
    ds.ansible_pos = (1,1)
    ds['include'] = "ok.yml"
    ds['tags'] = 'tag1,tag2'
    ds['vars'] = {'var1': 1, 'var2': 2}

    expected_ds = AnsibleMapping()
    expected_ds._attributes['import_playbook'] = "ok.yml"
    expected_ds._attributes['vars'] = {'var1': 1, 'var2': 2}
    expected_ds._attributes['tags'] = [Tag('tag1'), Tag('tag2')]
    expected_ds.ansible_pos = (1,1)

    result = PlaybookInclude().preprocess_

# Generated at 2022-06-23 06:38:49.006359
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass


# Generated at 2022-06-23 06:39:01.183291
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    ds = dict(
        import_playbook='common.yml',
        vars=dict(
            foo='bar'
        ),
        when=[
            'some_var',
        ],
        tags=[
            'tag1',
            'tag2'
        ]
    )
    pi = PlaybookInclude()
    pi.load_data(ds, '/tmp')

    assert pi.import_playbook == 'common.yml'
    assert pi.vars['foo'] == 'bar'
    assert pi.when == [ 'some_var' ]
    assert 'tag1' in pi.tags
    assert 'tag2' in pi.tags
    assert len(pi.tags) == 2

# Generated at 2022-06-23 06:39:03.434887
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    obj = PlaybookInclude()
    assert isinstance(obj._import_playbook, type(None))
    assert isinstance(obj._vars, dict)


# Generated at 2022-06-23 06:39:13.130113
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.plugins.loader import action_loader
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    action_loader.add_directory(os.path.join(os.path.dirname(__file__), '../../../plugins/actions'))
    action_loader.add_directory(os.path.join(os.path.dirname(__file__), '../../../plugins/tasks'))

    display.verbosity = 3
    playbook = Playbook.load('playbook_include_unit_test.yml', variable_manager={'include_vars':'var_to_include.yml'})
    assert playbook.entries != None
    assert playbook.entries[0] != None
    assert playbook.entries[0].__class__ == Play
   

# Generated at 2022-06-23 06:39:26.448444
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create sample data
    templar = Templar(variables={})
    play_context = PlayContext()
    variable_manager = VariableManager()

    data = {'import_playbook': 'abc', 'tags': ['foo', 'bar']}
    data['vars'] = {'foo': 'bar'}

    # Initialize PlaybookInclude object
    playbook_include = PlaybookInclude(loader=None)

    # Call method under test
    result = playbook_include.load_data(ds=data, basedir='.', variable_manager=variable_manager, loader=None)

    # Assert the result
    assert isinstance(result, list)

# Generated at 2022-06-23 06:39:39.019018
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    basedir = "/path/to/playbooks/dir"
    pb_data = {"import_playbook": "/path/to/import.yml"}
    loader = DataLoader()
    variable_manager = VariableManager()

    # Test 1: no playbook_paths set
    pb_include = PlaybookInclude.load(pb_data, basedir, variable_manager, loader)
    assert pb_include._entries == []

    # Test 2: with playbook_paths set
    pb_include = PlaybookInclude.load(pb_data, basedir, variable_manager, loader)
    assert pb_include._entries == []

    # Test 3: with playbook_paths set
   

# Generated at 2022-06-23 06:39:40.448924
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pbi = PlaybookInclude()
    assert pbi is not None


# Generated at 2022-06-23 06:39:47.579228
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    # test the main bulk of preprocess_data
    ds1 = AnsibleMapping.constructor(loader=AnsibleLoader(playbook=dict(name='playbook_foo')), node=dict(k='import_playbook', v='foo.yml'))
    pi1 = PlaybookInclude.load(ds1)
    processed = pi1.preprocess_data(ds1)
    assert processed == AnsibleMapping({'import_playbook': 'foo.yml'})


# Generated at 2022-06-23 06:39:54.220803
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    test_data_path = os.path.join(C.TEST_DIR, 'utils/playbook_include/preprocess_data')
    for test_input in [
        'ansible-galaxy.yml',
        'v1/include_role.yml',
        'v2/include_role.yml',
        'v1/include_tasks.yml',
        'v2/include_tasks.yml',
        'v1/import_playbook.yml',
        'v2/import_playbook.yml'
    ]:
        test_input_path = os.path.join(test_data_path, test_input)

# Generated at 2022-06-23 06:40:04.492541
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():

    from ansible.playbook.play import Play

    playbook_include = PlaybookInclude()
    playbook_include.load({'import_playbook': '../../playbooks/test_playbook.yml'}, '.')
    assert playbook_include.import_playbook == '../../playbooks/test_playbook.yml'

    # TODO: This is a hack to get the unit test to work. The playbooks/test_playbook.yml file
    # TODO: is not relative to the test/unit/playbook/test_playbook_include.py file. I tried
    # TODO: using tempfile.mkdtemp() and os.chdir() to set up a temporary directory with the
    # TODO: right test yaml files, but it did not work. I got an error that the playbook
    # TODO:

# Generated at 2022-06-23 06:40:13.388814
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.yaml.data import DataLoader

    yaml_str = """
    - import_playbook: test.yml
      vars:
        var1: value1
        var2: value2
      tags: tag1,tag2
    """
    data = DataLoader().load(yaml_str)
    assert isinstance(data, list)
    assert len(data) == 1
    task = data[0]
    assert isinstance(task, PlaybookInclude)

    playbooks = task.load(task.get_ds(), basedir="./test/unit/parsing/parser/parser_data", variable_manager=None, loader=None)
    assert isinstance(playbooks, type([]))

# Generated at 2022-06-23 06:40:17.757930
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    playbook = dict(name = 'test playbook')
    playbook['include'] = dict(file= 'test include', vars=dict(test_var='test_val'), tags= ['test_tag'])

    pb_include = PlaybookInclude.load(data=playbook, basedir='test_dir')

    assert pb_include.playbook == playbook['name']
    assert pb_include.import_playbook == playbook['include']['file']
    assert pb_include.vars == playbook['include']['vars']
    assert pb_include.tags == playbook['include']['tags']

# Generated at 2022-06-23 06:40:18.828769
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass


# Generated at 2022-06-23 06:40:33.127591
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.playbook.playbook_include import PlaybookInclude
    import ansible.constants as C

    # Test basic constructor
    pi = PlaybookInclude()
    assert pi._import_playbook is None
    assert pi._vars == dict()

    # Test __getattr__
    assert pi.vars == dict()

    # Test load, with default arguments

# Generated at 2022-06-23 06:40:46.022533
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    PlaybookInclude(import_playbook='playbook.yml', vars={'foo': 'bar'})

    with pytest.raises(AnsibleParserError) as err:
        PlaybookInclude(import_playbook='playbook.yml', vars=['foo', 'bar'])
    assert 'vars for import_playbook statements must be specified as a dictionary' in to_text(err.value)

    with pytest.raises(AnsibleParserError) as err:
        PlaybookInclude(import_playbook='playbook.yml', vars={'foo': 'bar'}, vars={'baz':'baz'})
    assert "import_playbook parameters cannot be mixed with 'vars' entries for import statements" in to_text(err.value)


# Generated at 2022-06-23 06:40:53.197074
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    variable_manager = DummyVars()

    playbook_include = PlaybookInclude()

    """
    This is a test.

    import_playbook: dummy.yml
    hostname: mwdehaan

    """

    playbook_include.load(
        ds=[
            '---\n',
            'import_playbook: dummy.yml\n',
            'hostname: mwdehaan\n'
        ],
        basedir=".",
        variable_manager=variable_manager)

    assert playbook_include.import_playbook == 'dummy.yml'
    assert playbook_include.hostname == 'mwdehaan'

# Generated at 2022-06-23 06:40:58.025431
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pi = PlaybookInclude(import_playbook="test_playbook.yml", vars={"test_var":"test_value"}, tags=["test_tag"])

# Generated at 2022-06-23 06:41:05.468072
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    from ansible.parsing.yaml.objects import AnsibleUnicode

    #create the playbook_include object
    pbi = PlaybookInclude()

    #create a list with the lines of the playbook to be tested

# Generated at 2022-06-23 06:41:17.293116
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play
    import_playbook = PlaybookInclude()
    input_ds = {
        'playbook': "playbookA.yml",
        'vars': {'a': '1', 'b': '2'},
        'tags': "tagA,tagB"
    }
    expected_output_ds = {
        'import_playbook': 'playbookA.yml',
        'vars': {'a': '1', 'b': '2'},
        'tags': 'tagA,tagB'
    }

    assert import_playbook.preprocess_data(input_ds) == expected_output_ds
    assert import_playbook.import_playbook == expected_output_ds['import_playbook']
    assert import_playbook.vars == expected_

# Generated at 2022-06-23 06:41:27.499663
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # Instance of PlaybookInclude class
    pi = PlaybookInclude()

    # Test preprocess_data with file name and no other parameters
    ds = {'import_playbook': 'sample.yml'}
    new_ds = {'import_playbook': 'sample.yml'}
    result = pi.preprocess_data(ds)
    assert result == new_ds

    # Test preprocess_data with file name, tags and variables
    ds = {'import_playbook': 'sample.yml tags=one,two vars={"a":"1","b":"2"}'}
    new_ds = {'import_playbook': 'sample.yml', 'vars': {'b': '2', 'a': '1'}, 'tags': 'one,two'}
    result = pi.preprocess

# Generated at 2022-06-23 06:41:37.898967
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play

    # try to load with missing block
    ds = dict(hosts='localhost', tasks=[dict(action=dict(module='debug', args=dict(msg='x')))])
    try:
        PlaybookInclude.load(data=ds, basedir='.')
    except AnsibleParserError as e:
        assert 'missing required fields' in to_bytes(e)

    # try to load with empty block
    ds = dict(hosts='localhost', tasks=[])
    try:
        PlaybookInclude.load(data=ds, basedir='.')
    except AnsibleParserError as e:
        assert 'invalid data' in to_bytes(e)

    # try to load with invalid block as top level item

# Generated at 2022-06-23 06:41:47.680006
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    from ansible_collections.satellite.satellite6.tests.unit.mock import patch

    basedir = '/tmp'
    path = '/tmp/playbook.yml'
    excluded_path = os.path.join(basedir, 'excluded.yml')

    ds = dict(
        import_playbook='playbook.yml',
        tags=['sat6_agent'],
        vars=dict(agents=dict(roles=['satellite_agent', 'satellite_agent_ssh']))
    )

    fake_loader = 'dummy loader'
    fake_variable_manager = 'dummy variable manager'
    fake_playbook = Playbook(loader=fake_loader)

# Generated at 2022-06-23 06:41:53.682126
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude

    # PlaybookInclude.load should return a playbook
    # when it is passed a valid path to a playbook
    playbook_include = PlaybookInclude()
    playbook_include.import_playbook = "test/test_playbook_include.yml"
    playbook = playbook_include.load("/etc/ansible/test/test_playbook_include.yml", basedir="/etc/ansible")
    assert playbook
    assert playbook.__class__.__name__ == "Playbook"

    # PlaybookInclude.load should raise an error
    # when it is passed a path to a non-existent
    # playbook
    playbook_include = PlaybookInclude()

# Generated at 2022-06-23 06:41:59.337262
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    (
        pb_in,
        pb_out,
        pb_res
    ) = test_PlaybookInclude_load_data_fixture()
    assert load_data(pb_in, 'basedir', None, None) == pb_res


# Generated at 2022-06-23 06:42:11.376997
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # Test loading import_playbook with tags
    ds = {'import_playbook': 'import_playbook.yml tags=a,b,c'}
    pb = PlaybookInclude.load(ds, '/some/path')
    assert pb.import_playbook == 'import_playbook.yml'
    assert pb.tags == ['a', 'b', 'c']
    assert pb.vars == {}

    # Test loading import_playbook with vars
    ds = {'import_playbook': 'import_playbook.yml vars=a:b,c:d', 'vars': {'e': 'f'}}
    pb = PlaybookInclude.load(ds, '/some/path')
    assert pb.import_playbook == 'import_playbook.yml'

# Generated at 2022-06-23 06:42:23.373028
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pbInclude = PlaybookInclude()
    assert pbInclude is not None

    pbInclude = PlaybookInclude.load(ds=dict(
        import_playbook='playbook.yaml',
        tags=['tag1', 'tag2']),
        basedir='.')
    assert pbInclude is not None
    assert pbInclude.import_playbook == 'playbook.yaml'
    assert pbInclude.tags == ['tag1', 'tag2']


# Generated at 2022-06-23 06:42:35.198426
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    import ansible.parsing.yaml.objects

    # PlaybookInclude().load_data will take dict or object of class: ansible.parsing.yaml.objects.AnsibleBaseYAMLObject
    # As input. 
    # This test uses a dict as input to `load_data` and check if returned object is of class: 
    # ansible.playbook.playbook.Playbook
    test_data = {'import_playbook': 'test_playbook.yml', 'vars': {}}
    import_playbook_object = PlaybookInclude({},{}).load_data(test_data, '')


# Generated at 2022-06-23 06:42:35.926608
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-23 06:42:45.809060
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # create a variable manager
    variable_manager = VariableManager()
    variable_manager.extra_vars = load_extra_vars({'v1': 'foo'})
    # create a loader
    loader = DataLoader()
    # create a playbook Include object
    pbp_include = PlaybookInclude(variable_manager=variable_manager, loader=loader)
    # set the basedir
    basedir = os.path.abspath(os.path.dirname(__file__))
    # create a recursive structure similar to a playbook for testing
    data = {'import_playbook': './test_playbook.yml', 'tags': 'tag_pb_include', 'vars': {'v2': 'bar'}}
    # load the playbook Include object

# Generated at 2022-06-23 06:42:59.018980
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    class Options(object):
        def __init__(self):
            self.connection = 'local'
            self.module_path = None
            self.forks = 10
            self.become = None
            self.become_method = None
            self.become_user = None
            self.check = False
            self.diff = False
            self.listhosts = None
            self.listtasks = None
            self.listtags = None
            self.syntax = None
            self.tags = None
            self.skip_tags = None
            self.verb

# Generated at 2022-06-23 06:43:06.710207
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.parsing.yaml.loader import AnsibleLoader
    ds = AnsibleLoader(None, None).load("""
- import_playbook: test.yml
  tags: test
""")
    playbookInclude = PlaybookInclude()
    playbookInclude.preprocess_data(ds[0])
    assert playbookInclude.import_playbook == "test.yml"
    assert playbookInclude.tags == ["test"]
    assert playbookInclude.vars == {}


# Generated at 2022-06-23 06:43:13.225548
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pb_inc = PlaybookInclude.load(
        {
            'import_playbook': 'test_playbook.yml'
        }, basedir='test_basedir',
        variable_manager={'test_var': 'test_value'},
        loader=None
    )
    assert isinstance(pb_inc, Playbook)
    assert pb_inc.plays[0].tasks[0].action == 'include_tasks'
    assert pb_inc.plays[0].tasks[0].args['file'] == 'test_basedir/test_playbook.yml'
    assert pb_inc.plays[0].tasks[0].args['test_var'] == 'test_value'
    assert pb_inc.plays[0].tasks[0].include_role is None

# Generated at 2022-06-23 06:43:20.484972
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager

    test_file_json_string = "{\"import_playbook\": \"test play name\"}"
    loader = AnsibleLoader(test_file_json_string, None, True)
    data = loader.get_single_data()

    playbook_include = PlaybookInclude()
    playbook_include.preprocess_data(data)

    assert playbook_include.import_playbook == "test play name"


# Generated at 2022-06-23 06:43:28.067589
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    data = {'import_playbook': './playbook.yml var1=value1 var2=value2',
            'vars': {'var1': 'value1_override', 'var3': 'value3'},
            'tags': ['tag1', 'tag2']}
    plugin = PlaybookInclude.load(data, None, None)
    assert plugin.import_playbook == './playbook.yml'
    assert plugin.vars == {'var1': 'value1_override', 'var2': 'value2', 'var3': 'value3'}
    assert plugin.tags == ['tag1', 'tag2']

test_PlaybookInclude_preprocess_data()

# Generated at 2022-06-23 06:43:30.343054
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # TODO: Implement test_PlaybookInclude_load_data
    raise NotImplementedError


# Generated at 2022-06-23 06:43:31.045772
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-23 06:43:39.298220
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    import_ds = dict(
        import_playbook='hello.yml',
        tags='foo,bar',
        vars=dict(
            username='bob',
            passowrd='password123'
        ),
        when='not example_playbook'
    )
    playbook_include = PlaybookInclude().load(import_ds, None, None, None)
    assert playbook_include.import_playbook == 'hello.yml'
    assert playbook_include.tags == ['foo', 'bar']
    assert playbook_include.vars['username'] == 'bob'
    assert playbook_include.vars['passowrd'] == 'password123'
    assert playbook_include.when == ['not example_playbook']

# Generated at 2022-06-23 06:43:49.740939
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    vars = {'var1': 'foo', 'var2': 'bar'}
    import_playbook = '/home/vagrant/playbook.yml'

    temp_playbook_include = PlaybookInclude()

    assert isinstance(temp_playbook_include, PlaybookInclude)
    assert temp_playbook_include._vars == {}
    assert temp_playbook_include._import_playbook == None

    temp_playbook_include = PlaybookInclude(vars=vars, import_playbook=import_playbook)

    assert isinstance(temp_playbook_include, PlaybookInclude)
    assert temp_playbook_include._vars == vars
    assert temp_playbook_include._import_playbook == import_playbook

# Generated at 2022-06-23 06:43:50.319001
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    ...

# Generated at 2022-06-23 06:43:59.636398
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    '''
    Method to test the preprocess_data method of class PlaybookInclude
    '''
    ## Invalid datastructure - not a dictionary
    ds = "abcd"
    ds_1 = dict()

    try:
        obj = PlaybookInclude()
        obj.preprocess_data(ds)
    except AnsibleAssertionError:
        pass
    else:
        raise AssertionError("The code did not raise AnsibleAssertionError")

    ## Valid inputs - no parameter passed
    ds_1['import_playbook'] = "play.yml"
    new_ds_1 = dict()
    new_ds_1['import_playbook'] = "play.yml"
    obj = PlaybookInclude()
    temp_ds = obj.preprocess_data(ds_1)


# Generated at 2022-06-23 06:44:12.039811
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    '''
    Test load method of class PlaybookInclude
    '''
    basedir = "/tmp/"
    data = """
            - import_playbook: sample.yml
            - import_playbook: sample.yml tags=tag1,tag2
            - import_playbook: sample.yml vars={"key": value}
            - import_playbook: sample.yml when: true
            - import_playbook: sample.yml tags=tag1 vars:
                - key: value
            - import_playbook: sample.yml tags=tag1 vars={"key": value}
            - import_playbook: sample.yml vars:
                - key: value1
            - import_playbook: sample.yml vars={"key": value}
            """

# Generated at 2022-06-23 06:44:24.839805
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    import ansible.constants as C
    import os

    loader = AnsibleLoader(None, True, 'test')
    fake_loader = DataLoader()
    fake_inventory = InventoryManager(fake_loader, sources=C.DEFAULT_HOST_LIST)