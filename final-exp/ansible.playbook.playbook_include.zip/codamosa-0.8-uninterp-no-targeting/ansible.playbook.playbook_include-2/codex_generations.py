

# Generated at 2022-06-21 00:53:31.929416
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play

    # Create a Playbook object and load data
    playbook_include_obj = PlaybookInclude()
    playbook_include_obj.vars = {'ansible_connection': 'local'}
    playbook_include_obj.tags = ['tag_1']
    playbook_include_obj.import_playbook = '../test_playbooks/role_test.yml'
    playbook_include_obj._entries = []

    playbook = playbook_include_obj.load_data('../test_playbooks', '../test_playbooks')
    assert playbook
    assert playbook.hosts == ['all']
    assert playbook.name == 'role_test'
    assert playbook.vars == playbook_include_obj.vars
    assert playbook.tags == playbook_include_obj.tags

    # Ensure

# Generated at 2022-06-21 00:53:38.264469
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pb = PlaybookInclude(import_playbook="/path/to/playbook",
                         vars=dict(a=1),
                         tags=['a','b','c'])

    assert pb.import_playbook == "/path/to/playbook"
    assert pb.vars['a'] == 1
    assert pb.tags == ['a','b','c']

# Generated at 2022-06-21 00:53:46.455369
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    playbook_include = PlaybookInclude()

    ds = dict(import_playbook='example.yml')
    file_name = 'example.yml'
    basedir = '/Test'
    pb = playbook_include.load(data=ds, basedir=basedir)
    assert isinstance(pb, Playbook)
    assert pb._entries[0].name == file_name



# Generated at 2022-06-21 00:53:57.377429
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():

    # testing import of playbook with absolute path
    import_playbook = 'import_playbook: /tmp/sample.yml'
    ds = AnsibleMapping(import_playbook)
    assert ds == PlaybookInclude.load(ds, basedir='/tmp/')

    # testing import of playbook with relative path
    import_playbook = 'import_playbook: sample.yml'
    ds = AnsibleMapping(import_playbook)
    assert ds == PlaybookInclude.load(ds, basedir='/tmp/')

    # testing import of playbook with relative path and tags
    import_playbook = 'import_playbook: sample.yml tags=tag1,tag2'
    ds = AnsibleMapping(import_playbook)

# Generated at 2022-06-21 00:54:02.347039
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    playbook_include = PlaybookInclude("test.yml")
    assert playbook_include.import_playbook == "test.yml", playbook_include.import_playbook
    assert playbook_include.vars == {}, playbook_include.vars


# Generated at 2022-06-21 00:54:15.133076
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # Create an instance of a model
    yaml_dict = {}
    PlaybookInclude_instance = PlaybookInclude(None, yaml_dict)
    assert PlaybookInclude_instance != None

    # Verify of attributes
    assert PlaybookInclude_instance._import_playbook == 'None'
    assert PlaybookInclude_instance.vars == {}

    # C14850
    # Python 2.6+ only
    #assert PlaybookInclude_instance.__dict__ == {'_playbook_include_vars': {}, '_playbook_include_import_playbook': 'None', '_attributes': {'import_playbook': {'required': True}, 'vars': {}}}

# Generated at 2022-06-21 00:54:18.530567
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    # test
    pb = PlaybookInclude()
    pb.load({'import_playbook': 'abc.yml'})
    assert type(pb.when) is list
    assert pb.import_playbook == 'abc.yml'

# Generated at 2022-06-21 00:54:25.225329
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    ds_raw = 'include.yml'
    ds = PlaybookInclude.load(ds_raw, None)._ds

    assert isinstance(ds, dict)
    assert len(ds.keys()) == 1
    assert 'import_playbook' in ds
    assert ds['import_playbook'] == ds_raw

    ds_raw = 'include.yml tags=foo'
    ds = PlaybookInclude.load(ds_raw, None)._ds

    assert isinstance(ds, dict)
    assert len(ds.keys()) == 2
    assert 'import_playbook' in ds
    assert ds['import_playbook'] == 'include.yml'
    assert 'tags' in ds
    assert ds['tags'] == 'foo'


# Generated at 2022-06-21 00:54:30.503803
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    PlaybookInclude._import_playbook = FieldAttribute(isa='string')
    PlaybookInclude._vars = FieldAttribute(isa='dict', default=dict)
    PlaybookInclude.vars = {}
    PlaybookInclude.import_playbook = "xyz.yml"
    p = PlaybookInclude()
    assert p.import_playbook == 'xyz.yml' and p.vars == {}

# Generated at 2022-06-21 00:54:42.840806
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.errors import AnsibleParserError
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    playbook = Playbook.load('../../examples/playbooks/import_playbook.yml', variable_manager=None, loader=None)

    assert playbook is not None
    first_play = playbook._entries[0]
    assert isinstance(first_play, Play)
    assert first_play.name == 'Import include_tasks'
    assert first_play.vars == {}
    assert first_play.tasks[1].name == 'throw_away'  # index 0 is an include_tasks that we don't care about

    second_play = playbook._entries[1]
    assert isinstance(second_play, Play)
    assert second_play.name

# Generated at 2022-06-21 00:55:00.289386
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import ansible.playbook
    import ansible.playbook.play
    import collections
    import copy
    import types

    ds = collections.OrderedDict()
    ds['import_playbook'] = '[test/test.yml]'
    ds['vars'] = {'test': 'true'}
    ds_original = copy.deepcopy(ds)

    new_ds = collections.OrderedDict()
    new_ds['import_playbook'] = 'test/test.yml'
    new_ds['vars'] = {'test': 'true'}

    new_ds_from_file = collections.OrderedDict()
    new_ds_from_file['import_playbook'] = 'test/test.yml'

# Generated at 2022-06-21 00:55:01.698252
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass


# Generated at 2022-06-21 00:55:04.339788
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    
    # test for correct return type
    assert True
    # test for correct attribute values
    assert True

# Generated at 2022-06-21 00:55:13.872571
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    def _check_New_Playbook_Include(data):
        '''
        Load PlaybookInclude data and check that it worked as expected.
        '''

        # load the data, convert to YAML
        ds = PlaybookInclude.load(data, None, None, None)
        assert ds.data is not None
        if ds.data is not None:
            yaml.dump(ds.data)

        # check values of the loaded data
        vars_data = {'test_var': 'test_val'}
        assert (ds.vars == vars_data)
        assert (ds.import_playbook == 'test_playbook')
        assert (ds.tags == None)


    # The PlaybookInclude class can handle a dictionary of data - this should work as expected.

# Generated at 2022-06-21 00:55:14.757770
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-21 00:55:15.384596
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-21 00:55:20.281588
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.playbook.playbook_include import PlaybookInclude

    p = PlaybookInclude()

    ds = dict(import_playbook='main.yml')
    p.load_data(ds, '/tmp')

    assert p._import_playbook == 'main.yml'

    ds = dict(import_playbook='main.yml vars=a:b')
    p.load_data(ds, '/tmp/test')

    assert p.vars['vars'] == dict(a='b')

# Generated at 2022-06-21 00:55:32.590713
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play

    # test the method load_data of class PlaybookInclude
    # using minimal input data to bypass the preprocess stage
    entries = PlaybookInclude().load_data({'import_playbook': 'sample-playbook'}, '.')._entries

    # check the resulting entries (based on sample-playbook.yml)
    assert len(entries) == 1
    assert isinstance(entries[0], Play)
    assert entries[0].name == 'test play'
    assert entries[0].hosts == ['testhost']
    assert entries[0].roles == []
    assert entries[0].vars == {}
    assert entries[0].meta == {}
    assert entries[0].tags == []
    assert entries[0].connection == 'ssh'

# Generated at 2022-06-21 00:55:42.221040
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # Test whether the preprocessing works correctly for dictionary input
    ds = {"import_playbook": "path/to/pb.yml", "vars": {"foo": "bar"}}

    # Create a new playbook include object
    pi = PlaybookInclude(None, loader=None)

    # The preprocess should generate a new datastructure. Let's check
    # that it matches our expectation
    processed_ds = pi.preprocess_data(ds)
    expected_ds = dict(import_playbook="path/to/pb.yml", vars=dict(foo="bar"))
    assert processed_ds == expected_ds

    # Test whether the preprocessing works correctly for AnsibleMapping input

# Generated at 2022-06-21 00:55:52.979348
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    mock_loader = MagicMock()
    mock_loader.load_from_file.return_value = [{"name":
                                                "include "
                                                "test.yml"
                                                " name=test",
                                                "ansible_pos": 0},
                                               {"name": "all",
                                                "ansible_pos": 0},
                                               {"tasks":
                                                [{"name": "include "
                                                  "test.yml"
                                                  " name=test",
                                                  "ansible_pos": 0},
                                                 {"name": "all",
                                                  "ansible_pos": 0}],
                                                "ansible_pos": 0}]
    mock_play = MagicMock()

# Generated at 2022-06-21 00:56:11.708422
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    import yaml

    ## check loading of playbook and role level yaml
    yaml_value = """
        - include: install_apache.yml
          var1: 1
          vars:
            var2: 2
    """
    try:
        play = PlaybookInclude.load(yaml.safe_load(yaml_value), basedir='/')
        assert False, "Should have raised exception for ambiguous include statement"
    except AnsibleParserError as e:
        assert e.message == "import_playbook parameters cannot be mixed with 'vars' entries for import statements"


# Generated at 2022-06-21 00:56:23.709739
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    '''
    This is a little meta, as this is actually testing the test code to
    make sure it works.
    '''

    # Basic creation, should work
    bl = PlaybookInclude.load({
        'import_playbook': 'test.yml'
    }, '/')

    assert bl.import_playbook == 'test.yml'

    # creation with multiple params, should work
    bl = PlaybookInclude.load({
        'import_playbook': 'test.yml one=1 two=2'
    }, '/')

    assert bl.import_playbook == 'test.yml'
    assert bl.vars['one'] == '1'
    assert bl.vars['two'] == '2'

    # creation with multiple params and vars, should not work

# Generated at 2022-06-21 00:56:24.579511
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-21 00:56:33.818927
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play

    basedir = os.path.join(os.path.dirname(__file__), 'data', 'playbook_include_data')

    class Tester(object):
        def __init__(self, *args, **kwargs):
            self._ds = args[0]
            self._name = os.path.basename(self._ds['import_playbook'])

    playbook = PlaybookInclude.load(
        dict(
            import_playbook='play.yml',
            tags=['tag1a', 'tag1b'],
            vars=dict(
                foo='var1',
                bar='var2',
            ),
        ),
        basedir,
        loader=Tester,
    )


# Generated at 2022-06-21 00:56:35.319620
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    PlaybookInclude()


# Generated at 2022-06-21 00:56:36.754472
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pb = PlaybookInclude()

# Generated at 2022-06-21 00:56:40.085031
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    from ansible.playbook.playbook_include import PlaybookInclude

    # test_constructor_negative
    try:
        PlaybookInclude()
    except Exception as e:
        assert isinstance(e, TypeError)

    # test_constructor_positive
    assert PlaybookInclude()

# Generated at 2022-06-21 00:56:52.370038
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    obj = PlaybookInclude()

    ds = { 'import_playbook': 'test.yml', 'vars': { 'var1': 'val1', 'var2': 2, 'var3': { 'subvar1': 'subval1' } } }
    new_ds = obj.preprocess_data(ds)
    assert new_ds == ds

    ds = { 'include': 'test.yml', 'vars': { 'var1': 'val1', 'var2': 2, 'var3': { 'subvar1': 'subval1' } } }
    new_ds = obj.preprocess_data(ds)
    assert new_ds == ds


# Generated at 2022-06-21 00:57:01.913655
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import pytest
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    yaml_str = '''
---
- import_playbook: foo.yml
'''
    new_ds = AnsibleConstructor(typ='safe').construct_yaml_map(yaml_str)
    pbinc = PlaybookInclude()
    result_ds = pbinc.preprocess_data(new_ds)
    assert result_ds == {'import_playbook': 'foo.yml'}

    # test error checking: vars must be dict
    new_ds = AnsibleMapping()
    new_ds.update({'import_playbook': 'bar.yml', 'vars': '1'})
   

# Generated at 2022-06-21 00:57:14.146543
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Test for parsing import_playbook with vars as a string:
    #
    #     import_playbook: test.yml tags=foo,bar vars=a=b
    #
    data = """
    - import_playbook: test.yml tags=foo,bar vars=a=b
    """
    yaml_ds = load_data(data)
    ds = yaml_ds[0]
    new_ds = PlaybookInclude().preprocess_data(ds)
    assert new_ds == {
        'import_playbook': 'test.yml',
        'tags': 'foo,bar',
        'vars': {'a': 'b'}
    }

    # Test for parsing import_playbook with vars as a dict:
    #
    #     import_playbook: test

# Generated at 2022-06-21 00:57:28.982198
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    playbook_include = PlaybookInclude()
    playbook_include.load({'import_playbook': 'my.yml'})
    assert playbook_include.import_playbook == 'my.yml'

    playbook_include.load({'import_playbook': 'my.yml tags=foo'})
    assert playbook_include.tags == ['foo']
    assert playbook_include.import_playbook == 'my.yml tags=foo'

    playbook_include.load({'import_playbook': 'my.yml foo=bar'})
    assert playbook_include.vars['foo'] == 'bar'
    assert playbook_include.import_playbook == 'my.yml foo=bar'

    # Import with vars and tags

# Generated at 2022-06-21 00:57:40.528368
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    yaml_data = '''- import_playbook: test.yml
      tags:
      - test
      when: not host_has_bootstrapped
      vars: {test_var: test_val}'''

    ds = PlaybookInclude.load(data=yaml_data, variable_manager=None, loader=None)
    assert isinstance(ds, PlaybookInclude)
    assert isinstance(ds.vars, dict)
    assert len(ds.tags) == 1
    assert ds.tags[0] == 'test'
    assert ds._included_conditional == 'not host_has_bootstrapped'
    assert ds.import_playbook == 'test.yml'


# Generated at 2022-06-21 00:57:44.560814
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.utils.collection_loader._yaml_loader import AnsibleLoader


# Generated at 2022-06-21 00:57:55.567345
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    AnsibleCollectionConfig.set_collection_playbook_paths([os.path.join(os.path.dirname(__file__), '..', '..', '..', 'test', 'unit', 'playbooks', 'playbooks_collections')])
    ds = AnsibleMapping()
    ds['import_playbook'] = 'includer.yml tags=hello,world'
    loader = AnsibleLoader(ds, VariableManager())
    new_obj = PlaybookInclude()

# Generated at 2022-06-21 00:58:06.808989
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    '''
    Test the class PlaybookInclude
    '''
    import tempfile
    from ansible.utils.display import Display
    from ansible.playbook.play import Play

    display = Display()
    # Set up the test input
    data = {
        'import_playbook': './../test_vars1.yml',
        'tags': ['tag1', 'tag2'],
        'vars': {'var1': 1, 'var2': 2},
        'when': {'cond': False}
    }

    # Set up the derived object
    inc = PlaybookInclude()

    # Validate preprocess_data method
    derived_data = inc.preprocess_data(data)
    assert derived_data == data

    # Set up temp dir for test_vars1.yml test playbook


# Generated at 2022-06-21 00:58:16.869165
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play

    # load data
    data = {'import_playbook': 'test_playbook', 'vars': {'x': 'y'}}
    temp_playbook_include = PlaybookInclude.load(data, basedir='.')

    # get entries
    playbook_entries = temp_playbook_include._entries

    assert len(playbook_entries) == 1
    assert isinstance(playbook_entries[0], Play)
    assert playbook_entries[0]._included_path == '.'
    assert playbook_entries[0]._included_conditional == []
    assert playbook_entries[0].vars == {'x': 'y'}

# Generated at 2022-06-21 00:58:26.173951
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    '''
    PlaybookInclude.load()
    '''

    # PlaybookInclude.load unit test with following inputs
    # data = None
    # basedir = None
    # variable_manager = None
    # loader = None

    # setup test
    playbook_include = PlaybookInclude()
    data = None
    basedir = None
    variable_manager = None
    loader = None

    # test
    result = playbook_include.load(data=data, basedir=basedir, variable_manager=variable_manager, loader=loader)

    # assert
    assert True


# Generated at 2022-06-21 00:58:39.360769
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_text = '''
    - import_playbook: file1
    - import_playbook: file2
      vars:
        foo: bar
        baz: blah
      tags: taglist
    '''
    (pb, basedir) = PlaybookInclude.load(playbook_text, basedir='')
    # play1
    play1 = pb._entries[0]
    assert play1._included_path == ''
    assert play1.vars == {}
    assert play1.tags == []
    # play2
    play2 = pb._entries[1]
    assert play2._included_path == ''
    assert play2.vars == {'foo': 'bar', 'baz': 'blah'}
    assert play2.tags == ['taglist']

# Unit

# Generated at 2022-06-21 00:58:46.099316
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.playbook_include import PlaybookInclude

    test_include = PlaybookInclude.load({ 'import_playbook': 'foo.yml' }, '.')
    test_include = test_include.preprocess_data(test_include.__dict__)

    assert test_include.import_playbook is not None
    assert test_include.import_playbook == 'foo.yml'

    assert test_include.vars is not None
    assert test_include.vars == {}

# Generated at 2022-06-21 00:58:58.447623
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import tempfile
    import json
    import shutil
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    test_dir = tempfile.mkdtemp()
    test_vars_dir = tempfile.mkdtemp()
    test_vars_file = os.path.join(test_vars_dir, "main.yml")


# Generated at 2022-06-21 00:59:09.331869
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    test_ds = """
    - import_playbook: test.yml
      vars:
        var1: foo
        var2: bar
    """
    yaml_ds = PlaybookInclude.load(test_ds, None)
    assert yaml_ds[0].import_playbook == 'test.yml'
    assert yaml_ds[0].vars['var1'] == 'foo'
    assert yaml_ds[0].vars['var2'] == 'bar'


# Generated at 2022-06-21 00:59:21.812992
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.module_utils.six import StringIO
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.template import Templar
    import yaml
    import collections
    parallel = collections.namedtuple("parallel",["hosts"])
    parallel.hosts = "all"
    play = collections.namedtuple("play", ["hosts"])
    play.hosts = "all"
    playbook = collections.namedtuple("playbook",["play"])
    playbook.play = play
    playbook_include = collections.namedtuple("playbook_include",["hosts"])
    playbook_include.hosts = "all"
    display.display("Display for playbook include")
    playbook_include1

# Generated at 2022-06-21 00:59:30.512165
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # First of all, let's create a PlaybookInclude object
    import_playbook = dict(
        import_playbook='include/play1.yml',
        vars=dict(
            tom='cat',
            jerry='mouse',
        ),
        tags=['include_play'],
    )

    import_playbook_obj = PlaybookInclude()
    import_playbook_obj.load_data(import_playbook)

    assert import_playbook_obj.import_playbook == 'include/play1.yml'
    assert import_playbook_obj.vars['tom'] == 'cat'
    assert 'include_play' in import_playbook_obj.tags
    assert import_playbook_obj.vars['jerry'] == 'mouse'



# Generated at 2022-06-21 00:59:40.546931
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.role import Role
    from ansible.parsing.yaml.loader import AnsibleLoader

    # test cases

# Generated at 2022-06-21 00:59:49.528433
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class MockLoader(object):
        pass

    # create playbook include
    playbook_include = PlaybookInclude(loader=MockLoader())
    ds = {
        "test" : "test",
        "import_playbook" : "test.yml"
    }
    basedir = os.path.abspath(os.path.dirname(__file__))
    variable_manager = VariableManager(templar=Templar(), loader=MockLoader())
    variable_manager.set_nonpersistent_facts({"test": "test"})

# Generated at 2022-06-21 00:59:56.024365
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pbi = PlaybookInclude.load(dict(import_playbook='foo.yaml', tags=['tag1', 'tag2']),
        basedir=C.DEFAULT_PLAYBOOK_PATH, loader=None, variable_manager=None)
    assert(pbi.import_playbook == 'foo.yaml')
    assert(pbi.tags == ['tag1', 'tag2'])

# Generated at 2022-06-21 01:00:07.209619
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    ds = AnsibleMapping()
    ds['import_playbook'] = 'foo.yml'

    include_obj = PlaybookInclude()
    playbook = include_obj.load_data(ds, '.', variable_manager, loader)
    assert isinstance(playbook, Playbook)
    assert playbook.basedir == os.path.abspath(os.curdir)
    assert playbook._entries == []
    assert playbook._entries[0].basedir == os.path.abspath(os.curdir)

# Generated at 2022-06-21 01:00:10.196609
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pb = PlaybookInclude()
    print("test PlaybookInclude(): ", pb)

# Generated at 2022-06-21 01:00:11.057847
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-21 01:00:13.268364
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    p = PlaybookInclude()

    assert p is not None

# Generated at 2022-06-21 01:00:32.308356
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar

    # Overwrite module_utils._text.to_text. This method is used to convert to text when generating
    # stats. Since our test cases use mock, we can't just assign to_text of the real module, because
    # it'll call the mock one, resulting in recursion.
    def mock_to_text(obj):
        if isinstance(obj, string_types):
            return obj
        else:
            return obj.__str__()

    import ansible.module_utils._text
    old_to_text = ansible.module_utils._text.to_text
    ansible.module_utils._text.to_text = mock_to_text


# Generated at 2022-06-21 01:00:38.913811
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.data import DataLoader

    ds = DataLoader().load('''
    - import_playbook: test.yml
    ''')

    expected_ds = """import_playbook: test.yml"""

    p = PlaybookInclude()
    preprocessed_ds = p.preprocess_data(ds[0])
    preprocessed_dict = preprocessed_ds.copy()
    del(preprocessed_dict['ansible_pos'])

    assert expected_ds == preprocessed_dict



# Generated at 2022-06-21 01:00:49.183054
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # Given: no data
    # When: preprocess_data() is called
    # Then: an exception is raised
    data = ''
    basedir = 'basedir'
    variable_manager = None
    loader = None
    this = PlaybookInclude()
    try:
        preprocessed_data = this.preprocess_data(data)
        assert False
    except:
        assert True


    # Given: no file
    # When: preprocess_data() is called
    # Then: an exception is raised
    data = {
        'tasks': {
            'import_playbook': 'test.yml'
        }
    }
    basedir = 'basedir'
    variable_manager = None
    loader = None
    this = PlaybookInclude()

# Generated at 2022-06-21 01:00:50.313624
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-21 01:01:00.965045
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    '''
    To test this class, run the following commands:

    # unit tests
    $ ansible-test units -v --cov-args '--omit tests/unit/modules/parsing/test_playbook_include.py' --cov playbooklib.py

    # integration tests
    $ ansible-test integration -v --cov-args '--omit tests/integration/modules/parsing/test_playbook_include.py' --cov playbooklib.py

    # sanity check tests
    $ ansible-test sanity -v playbooklib --python 3
    '''

    import_playbook = 'playbook.yml'
    variable_manager = None
    loader = None

    # Test case without variable manager and loader

# Generated at 2022-06-21 01:01:08.173194
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pr1 = PlaybookInclude.load(dict(import_playbook='/test/test.yml'), None)
    assert pr1.import_playbook == '/test/test.yml'
    assert pr1.tags is None
    assert pr1.vars == {}
    assert pr1.when is None

    pr2 = PlaybookInclude.load(dict(import_playbook='/test/test.yml tags=foo,bar'), None)
    assert pr2.import_playbook == '/test/test.yml'
    assert pr2.tags == ['foo', 'bar']
    assert pr2.vars == {}
    assert pr2.when is None

    pr3 = PlaybookInclude.load(dict(import_playbook='/test/test.yml var1=1 var2=2'), None)


# Generated at 2022-06-21 01:01:21.431798
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    def test_include_func(include):
        if include == 'task':
            return TaskInclude
        elif include == 'handler':
            return HandlerTaskInclude
        elif include == 'play':
            return Play
        else:
            raise Exception('Test implementation - no include found: %s' % include)

    # TODO - test with handler_task_include
    # TODO - test with task_include

    # ------------------------
    # PlaybookInclude - basic
    # ------------------------


# Generated at 2022-06-21 01:01:32.238515
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # create an PlaybookInclude object
    pbi = PlaybookInclude()

    # populate a variable manager with some vars
    variable_manager = VariableManager()
    variable_manager.set_variable_manager('test1.yml', variable_manager)
    variable_manager.set_variable('test_var', 'test_value')

    # create a loader
    loader = DataLoader()

    # create a mock ds
    ds = MockDS()

    # test import_playbook
    ds.data = 'import_playbook=test2.yml'
    ds.ansible_pos = {'lnum': 1, 'col': 22}
    new_ds = pbi._preprocess_data(ds, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-21 01:01:43.657660
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play_context import PlayContext

    ds = ''.join('''---
                        import_playbook: test.yml
                        tags:
                            - test
                        vars:
                            test_var: foo
                            test_var2: bar
                    '''.split('\n'))

    import_playbook_reference_path = os.path.dirname(os.path.realpath(__file__)) + os.sep + 'test.yml'
    playbook_object = PlaybookInclude.load(data=ds, basedir='/tmp', loader=FakeLoader())
    playbook_object.validate()
    playbook_object.post_validate(play_context=PlayContext())

    assert playbook_object.import_playbook == import_playbook_reference_path
    assert playbook_

# Generated at 2022-06-21 01:01:50.211734
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    """
    Test load_data method of PlaybookInclude.

    """

    # Test import string with no params
    ds = "playbook.yml"
    pb = PlaybookInclude().load_data(ds, basedir="")
    assert len(pb._entries) == 2
    assert pb._entries[0].name == 'include_tasks_1'
    assert pb._entries[1].name == 'include_role_1'

    # Test import string with tags
    ds = "import_playbook=playbook.yml tags=test"
    pb = PlaybookInclude().load_data(ds, basedir="")
    assert len(pb._entries) == 2
    assert pb._entries[0].name == 'include_tasks_1'
    assert pb._

# Generated at 2022-06-21 01:02:23.491252
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    playbook_include = PlaybookInclude()
    with pytest.raises(AnsibleAssertionError):
        playbook_include.preprocess_data(ds=[])
    with pytest.raises(AnsibleParserError):
        playbook_include.preprocess_data(ds={'bad_key': 'bad_value'})
    with pytest.raises(AnsibleParserError):
        playbook_include.preprocess_data(ds={'import_playbook': None})
    with pytest.raises(AnsibleParserError):
        playbook_include.preprocess_data(ds={'import_playbook': 1234})
    with pytest.raises(AnsibleParserError):
        playbook_include.preprocess_data(ds={'import_playbook': ' '})

# Generated at 2022-06-21 01:02:31.866046
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    ds = {
        '- include': 'test.yml',
        'vars': {'var1': 'val1'}
    }

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts(dict())

    pbi = PlaybookInclude()
    assert isinstance(pbi.preprocess_data(ds), AnsibleMapping)
    assert pbi.import_playbook == 'test.yml'
    assert len(pbi.vars) == 0

    for key, value in iteritems(pbi.preprocess_data(ds)):
        assert key in ('import_playbook', 'vars')
        assert value == d

# Generated at 2022-06-21 01:02:41.873712
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base
    from ansible.playbook.taggable import Taggable
    from ansible.parsing.yaml.objects import AnsibleSequence

    ds_vars = dict()
    ds_vars['roles'] = AnsibleSequence()
    ds_vars['roles'].ansible_pos = dict(col=14, lno=22)
    ds_vars['roles'].append('stuff')

    ds = dict()
    ds['import_playbook'] = 'file.yml'
    ds['when'] = 'we need'
    ds['vars'] = ds_vars
    ds['force_handlers'] = True

# Generated at 2022-06-21 01:02:52.586454
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # The test case for method preprocess_data
    def test_case_preprocess_data(ds, exp_ds):

        # Create a mock object to hold the data structure ds using the MockString class
        mock_ds = MockString(ds)
        mock_ds.ansible_pos = {}

        # This is used to hold the processed datastructure
        pb_obj = PlaybookInclude()
        pb_ds = pb_obj.preprocess_data(mock_ds)

        # Assert that the process datastructure is correct
        assert pb_ds == exp_ds


    # Test 1: Check processing of valid import_playbook
    ds = 'file.yml'
    exp_ds = {'import_playbook': 'file.yml'}

# Generated at 2022-06-21 01:02:55.028150
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    p = PlaybookInclude()
    assert p is not None

# Generated at 2022-06-21 01:03:04.297202
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # create object 'ds'
    ds = AnsibleMapping()
    ds['import_playbook'] = 'test_playbook.yml'

    # create object 'vars' and add to 'ds'
    vars = AnsibleMapping()
    vars['var_one'] = 'var_one'
    vars['var_two'] = [1, 2, 3]
    ds['vars'] = vars

    # create object 'tags' and add to 'ds'
    ds['tags'] = 'one,two,three'

    # create object 'when' and add to 'ds'
    when = ['first condition', 'second condition']
    ds['when'] = when

    # create object 'raw_ds'
    raw_ds = AnsibleMapping()

# Generated at 2022-06-21 01:03:14.436799
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader

    play_yaml = """
- hosts: all
  tasks:
  - debug:
      msg: Hello from included playbook 2
"""

    test_yaml = """
- import_playbook: test_playbook.yml vars:
    VAR1: test1
    VAR2: test2
    VAR3: test3
"""
