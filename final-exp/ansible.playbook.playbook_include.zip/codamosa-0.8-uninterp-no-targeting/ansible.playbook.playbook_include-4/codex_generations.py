

# Generated at 2022-06-21 00:53:33.292960
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pb_include = PlaybookInclude()
    data = {'include': {'import_playbook': 'test_file.yaml'}, 'tags': ['test_tag'], 'when': 'test_condition'}
    assert pb_include.load(data=data, basedir='/test_dir', variable_manager='test_variable_manager', loader='test_loader')
    assert pb_include.import_playbook == 'test_file.yaml'
    assert pb_include.tags == ['test_tag']
    assert pb_include.when[0] == 'test_condition'

    data = {'import_playbook': 'test_file.yaml'}

# Generated at 2022-06-21 00:53:45.841909
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    playbook_include = PlaybookInclude('import_playbook', dict(
        import_playbook='/path/to/imported/playbook.yaml'
    ))
    assert playbook_include.import_playbook == '/path/to/imported/playbook.yaml'
    assert playbook_include.vars == dict()

    playbook_include = PlaybookInclude('import_playbook', dict(
        import_playbook='/path/to/imported/playbook.yaml',
        vars=dict(
            key='value'
        )
    ))
    assert playbook_include.import_playbook == '/path/to/imported/playbook.yaml'
    assert playbook_include.vars == dict(
        key='value'
    )


# Generated at 2022-06-21 00:53:50.437188
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    # init AnsibleCollectionConfig
    args = ['-T', '10']
    collection_finder = AnsibleCollectionConfig(args)
    # load system collections
    collection_finder._load_collections([])

    ds = {'import_playbook': 'playbook.yml', 'vars': {'foo': 'bar'}, 'tags': ['t1', 't2']}

    pb = PlaybookInclude.load(data=ds, basedir='/a/b/c', variable_manager=None, loader=None)

    assert isinstance(pb, Playbook)
    assert len(pb.get_plays()) == 1
    assert isinstance(pb.get_plays()[0], Play)
    assert pb.get

# Generated at 2022-06-21 00:53:56.923762
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook

    # Create inventory
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()

    # Create variable manager
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'hosts': 'webservers',
                                   'somevar': 'somevalue'}

    # Set variablemanager as global variable manager
    variable_manager.set_global_vars()

    # Here we load and run a playbook defined as a string
    # The playbook is defined as a string

# Generated at 2022-06-21 00:54:09.607960
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping

    # setup test data
    ds_test = AnsibleMapping()
    ds_test[C._ACTION_IMPORT_PLAYBOOK] = 'imported_playbook.yml'
    ds_test['vars'] = AnsibleMapping()
    ds_test['vars']['foo'] = 'bar'

    # test init method when using 'import_playbook'
    pbinclude = PlaybookInclude(loader=None)
    new_ds_test = pbinclude.preprocess_data(ds=ds_test)

    assert new_ds_test is not None
    assert isinstance(new_ds_test, AnsibleMapping)
    assert len(new_ds_test) == 2
    assert new_ds_test

# Generated at 2022-06-21 00:54:20.702637
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # Tests for playbook include without conditional
    # PlaybookInclude will create a Playbook type
    # with no conditional and no tags
    pb = PlaybookInclude().load_data(ds={'import_playbook': 'playbook.yml'}, basedir='/a/path')
    assert pb.basedir == '/a/path'
    assert isinstance(pb, Playbook)
    assert not pb.has_tasks()
    assert pb.tasks == []
    assert pb.filtered is False
    assert pb.has_vars()
    assert pb.variables == {}
    assert pb.has_handlers()
    assert pb.handlers == []
    assert pb.has_tasks()
    assert pb.tags == []
    assert pb.has_default_vars

# Generated at 2022-06-21 00:54:22.192772
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    p = PlaybookInclude()

    assert p == None


# Generated at 2022-06-21 00:54:32.248103
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    import os

    module_loader, ds, _ = TaskInclude.load(dict(include='andrew.yml', tags='tag1,tag2', vars=dict(firstvar='firstval', secondvar='secondval')))
    block = Block.load(dict(tasks=[ds]), play=object(), variable_manager=None, loader=module_loader)
    playbook = PlaybookInclude.load(ds, variable_manager=None, loader=module_loader, basedir=os.path.dirname(os.path.realpath(__file__)))

# Generated at 2022-06-21 00:54:45.659003
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook import Playbook

    playbookInclude = PlaybookInclude()
    playbook_data = AnsibleMapping()
    playbook_data['import_playbook'] = 'my-playbook.yml'
    playbook_data['tags'] = 'tag1'
    playbook_data['vars'] = {'var1': 'val1', 'var2': 'val2'}
    playbook_data['when'] = '{{some_var == "some_value"}}'
    pb = playbookInclude.load_data(ds=playbook_data, basedir='.', variable_manager=None, loader=None)
    assert isinstance(pb, Playbook)
    assert pb._included_path == os.path.abspath

# Generated at 2022-06-21 00:54:54.381798
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Now test the PlaybookInclude class
    # Test when pb.load returned a Playbook and a PlaybookInclude
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.plugins.loader import fragment_loader
    from ansible.vars.manager import VariableManager

    basedir = os.path.realpath(os.path.join(os.path.dirname(__file__), os.path.pardir, os.path.pardir, os.path.pardir, 'lib', 'ansible', 'test', 'sanity', 'playbook', 'playbook_include'))
    p1 = PlaybookInclude.load('import_playbook="test_playbook_include.yml"', basedir, None, fragment_loader)

# Generated at 2022-06-21 00:55:03.829927
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # TODO: write unit test for PlaybookInclude.load_data()
    pass


# Generated at 2022-06-21 00:55:08.599247
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook

    pb = PlaybookInclude.load(
        {'import_playbook': 'test_playbook.yml', 'when': 'test_condition'},
        basedir='/'
    )

    assert isinstance(pb, Playbook)



# Generated at 2022-06-21 00:55:09.494676
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    assert PlaybookInclude()

# Generated at 2022-06-21 00:55:20.149855
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    playbook_lines = """
    - import_playbook: test.yml
    """

    ds = AnsibleMapping.load(playbook_lines)
    ds = PlaybookInclude.load(ds[0], '.')

    assert ds.vars == dict()
    assert ds.tags == []
    assert ds.when == []

    playbook_lines = """
    - import_playbook: test.yml
      tags:
        - tag_1
        - tag_2
      vars:
        var1: value1
        var2: value2
    """

    ds = AnsibleMapping.load(playbook_lines)
    ds = PlaybookInclude.load(ds[0], '.')


# Generated at 2022-06-21 00:55:21.895692
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    assert False, "Test not implemented"



# Generated at 2022-06-21 00:55:33.241180
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import yaml
    pbi = PlaybookInclude()

    # Test case with invalid ds
    try:
        pbi.preprocess_data("nothing")
    except AnsibleAssertionError:
        pass
    except:
        raise AssertionError("Unexpected failure in test case.")

    # Test case with vars in ds
    data = '''
        - hosts: webservers
          import_playbook: vars1.yml
    '''
    ds = yaml.safe_load(data)
    for playbook in ds:
        try:
            pbi.preprocess_data(playbook)
        except AnsibleParserError as e:
            assert "playbook import parameter is missing" in e.message
        except:
            raise AssertionError("Unexpected failure in test case.")

    data

# Generated at 2022-06-21 00:55:42.909188
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.playbook.block import Block

    p = Playbook.load(dict(
        import_playbook = './test.yaml',
        when = 'test'
    ), '/some/path')

    assert isinstance(p, Playbook)
    assert len(p._entries) == 1
    assert isinstance(p._entries[0], Play)
    assert len(p._entries[0].tasks) == 2, [_._attributes for _ in p._entries[0].tasks]
    assert isinstance(p._entries[0].tasks[0], Block)

# Generated at 2022-06-21 00:55:54.885921
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    data = '''
    - import_playbook: foo/bar.yml
    - import_playbook: foo/bar.yml vars:
        foo: bar
    - import_playbook: foo/bar.yml tags:
        - tag1
    - import_playbook: foo/bar.yml tags:
        - tag1
      vars:
        foo: bar
    '''
    obj1 = PlaybookInclude.load(data, 'asdf')
    assert obj1.import_playbook == 'foo/bar.yml'
    assert obj1.vars == dict()

    obj2 = PlaybookInclude.load(data, 'asdf')
    assert obj2.import_playbook == 'foo/bar.yml'
    assert obj2.vars == dict(foo='bar')
   

# Generated at 2022-06-21 00:55:57.405047
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    '''
    The most basic test of the PlaybookInclude class
    '''
    pbi = PlaybookInclude()
    assert pbi is not None



# Generated at 2022-06-21 00:56:06.485346
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    import ansible.playbook.playbook
    playbook_include = PlaybookInclude()
    pb = PlaybookInclude.load(ds=dict(import_playbook='load_test_data.yaml', when='1'), basedir='/tmp')
    assert pb._entries[0].name == 'load_test_data'
    assert pb._entries[0].hosts == ['host1', 'host2']

# Generated at 2022-06-21 00:56:23.709662
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # import here to avoid a dependency loop
    from ansible.playbook import Playbook

    # set up test objects and data
    basedir = '/home/user'
    pm = PlaybookInclude()
    ds = dict(import_playbook='/home/user/test.yml', tags=['a','b','c'], vars=dict(a=1, b=2))

    # run the method
    pb = pm.load_data(ds, basedir)

    # verify that the Playbook object was returned
    assert isinstance(pb, Playbook)
    assert pb._basedir == '/home/user'
    assert pb._filename == '/home/user/test.yml'
    assert pb._entries[0].tags == ['a','b','c']

    # run the method, with a relative

# Generated at 2022-06-21 00:56:33.350303
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.utils.addresses import parse_address
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-21 00:56:42.982228
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.errors import AnsibleAssertionError

    playbook_include = PlaybookInclude()

    ds = AnsibleMapping()
    assert playbook_include.preprocess_data(ds) == {}, "Expected empty dictionary, got %s" % playbook_include.preprocess_data(ds)

    playbook_include._preprocess_import(ds, ds, 'import_playbook', 'test')
    ds['import_playbook'] = 'test'
    assert playbook_include.preprocess_data(ds) == {'import_playbook': 'test'}, "Expected {'import_playbook': 'test'}, got %s" % playbook_include.preprocess_

# Generated at 2022-06-21 00:56:53.894781
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    import ansible.playbook.play_context
    import ansible.playbook.block_context

    yaml_data = dict(
        import_playbook='test.yaml',
        when='inventory_hostname=="localhost"',
        tags=['foo', 'bar'],
        vars=dict(foo='bar', bam='boo'),
        connection='local',
    )

    ds = PlaybookInclude.load(yaml_data, None)
    assert isinstance(ds, Playbook)


# Generated at 2022-06-21 00:56:58.503165
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    """
    Constructor test for PlaybookInclude
    """
    pbi = PlaybookInclude()
    assert pbi.vars == dict()
    assert pbi.tags == []
    assert pbi.when == []
    assert pbi.name is None
    pbi = PlaybookInclude(name='filename')
    assert pbi.name == 'filename'


# Generated at 2022-06-21 00:57:12.698178
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.template import Templar

    vars = dict(
        a=dict(
            b=1,
            c=2,
        )
    )

    # find the role path (https://github.com/ansible/ansible/issues/7546)
    role_path = os.path.join(os.path.dirname(__file__), '../../../test/sanity/playbooks/roles')

    # check if we can find the collection

# Generated at 2022-06-21 00:57:18.829425
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    playbook_include = PlaybookInclude(import_playbook='somefile.yml', tags=['tag1', 'tag2'])
    assert playbook_include.import_playbook == 'somefile.yml'
    assert playbook_include.tags == ['tag1', 'tag2']

# Generated at 2022-06-21 00:57:22.214152
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    test_obj = PlaybookInclude()
    assert test_obj
    assert test_obj.vars == {}
    assert test_obj.tags == []

# Generated at 2022-06-21 00:57:34.646842
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # create obj using constructor
    pb_include_obj = PlaybookInclude('/path/to/playbook', extra_vars={'varD': 'ValueD'}, tags=['test'], when={'condition': '0 == 1'})

    # check parameters is set properly
    assert pb_include_obj.import_playbook == '/path/to/playbook'
    assert pb_include_obj.vars == {'varD': 'ValueD'}
    assert pb_include_obj.tags == ['test']
    assert pb_include_obj.when == {'condition': '0 == 1'}

    # check additional parameters
    assert pb_include_obj.name == 'pb_import'
    assert pb_include_obj.parent is None



# Generated at 2022-06-21 00:57:44.337895
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    obj = PlaybookInclude()
    ds = None
    new_ds = obj.preprocess_data(ds)
    assert new_ds == dict()
    ds = dict()
    new_ds = obj.preprocess_data(ds)
    assert new_ds == dict()
    ds = dict(foo='bar')
    new_ds = obj.preprocess_data(ds)
    assert new_ds == dict(foo='bar')
    ds = dict(import_playbook='/etc/ansible/myplaybook.yml')
    new_ds = obj.preprocess_data(ds)
    assert new_ds == dict(import_playbook='/etc/ansible/myplaybook.yml')

# Generated at 2022-06-21 00:58:06.138472
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # PlaybookInclude without any variables
    data = """
- import_playbook: '{{ list_path }}/install-unzip.yml'
"""
    ds = PlaybookInclude.load(data, basedir="test/playbook")
    new_ds = ds.preprocess_data(ds=ds.ds)
    assert len(new_ds) == 2
    assert new_ds['import_playbook'] == "{{ list_path }}/install-unzip.yml"
    assert new_ds['vars'] == {}

    # PlaybookInclude with a single variable
    data = """
- import_playbook: '{{ list_path }}/install-unzip.yml'
  create_dir: False
"""

# Generated at 2022-06-21 00:58:17.168491
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os
    import sys
    import tempfile
    import ansible.playbook.playbook_include

    this_dir = os.path.dirname(__file__)
    collection_dir = os.path.join(this_dir, '../../../test/')
    playbook = os.path.join(collection_dir, 'test_playbook.yml')
    collection_name = "my_namespace"
    collection_parent_dir = os.path.join(this_dir, '../../../test/')
    collection_dir = os.path.join(collection_parent_dir, collection_name)
    collection_path = os.path.join(collection_dir, "ansible_collections", collection_name, "test_playbook.yml")


# Generated at 2022-06-21 00:58:27.862883
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    ansible_obj = PlaybookInclude()
    dict_obj = dict(ansible_obj.preprocess_data(dict(
            import_tasks='A',
            import_playbook='B',
            import_role='C',
            include='D',
            include_tasks='E',
            include_role='F',
            import_playbook_tasks='G',
            vars=dict(
                a=1,
                b=2,
                c=3,
            ),
        )))
    assert dict_obj == dict(
        import_playbook='B',
        vars=dict(a=1, b=2, c=3),
    )


# Generated at 2022-06-21 00:58:39.969164
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    data_string = " - include_tasks: ntp.yml\n"
    data_string += "   vars: { ntp_server: ntp.example.org }\n"
    data_string += " - include_tasks: ntp.yml\n"
    data_string += "   vars:\n"
    data_string += "     ntp_server: ntp.example.org\n"
    data_string += "     ntp_enabled: true\n"
    data_string += " - include_tasks: ntp.yml\n"
    data_string += "   tags: ['tag1', 'tag2']\n"

# Generated at 2022-06-21 00:58:48.796655
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import_playbook_obj = PlaybookInclude()
    # test if import_playbook_obj is instance of PlaybookInclude
    assert isinstance(import_playbook_obj, PlaybookInclude)
    # test the ds with string_types
    ds = "test_PlaybookInclude_preprocess_data"
    assert isinstance(ds, string_types)
    # test the ds with dict
    ds = dict(a=10, b=20)
    assert isinstance(ds, dict)
    # test the ds with dict
    ds = dict(import_playbook=10)
    assert isinstance(ds, dict)
    # test the ds with dict
    ds = dict(import_playbook=10, vars=20)
    assert isinstance(ds, dict)
    # test

# Generated at 2022-06-21 00:58:59.351050
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # Test code
    import ansible.parsing.yaml.objects

    ds = ansible.parsing.yaml.objects.AnsibleMapping()
    ds['tasks'] = ansible.parsing.yaml.objects.AnsibleSequence()
    ds['tasks'][0] = ansible.parsing.yaml.objects.AnsibleMapping()
    ds['tasks'][0]['import_playbook'] = 'test.yml arg1=value1 arg2=value2'
    ds['tasks'][1] = ansible.parsing.yaml.objects.AnsibleMapping()
    ds['tasks'][1]['import_playbook'] = 'test.yml other=test'

    pi = PlaybookInclude()


# Generated at 2022-06-21 00:59:08.586493
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # Make sure to use the patched module in ansible.module_utils.basic.py
    import ansible.module_utils.basic
    # ansible.module_utils.basic.AnsibleModule.run_command = mock.MagicMock(return_value=(0, '', ''))
    # module_args = dict(
    #     state='absent',
    #     name='sample',
    #     type='user',
    #     password='',
    #     update_password='always'
    # )
    # set_module_args(module_args)
    # my_obj = PlaybookInclude()
    # with pytest.raises(AnsibleExitJson) as exc:
    #    my_obj.apply()
    # assert exc.value.args[0]['changed']
    assert False

# Generated at 2022-06-21 00:59:09.490313
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    PlaybookInclude()

# Generated at 2022-06-21 00:59:10.640534
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-21 00:59:23.549675
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():

    p = PlaybookInclude()

    # Test exception of not passing a dict
    with pytest.raises(AnsibleAssertionError) as excinfo:
        p.load(None, "basedir", "variable_manager")
    assert 'ds (None) should  be a dict but was a <class \'NoneType\'>' in str(excinfo.value)

    # Test exception of passing a dict but missing basedir
    with pytest.raises(AnsibleAssertionError) as excinfo:
        p.load({'import_playbook': 'file.yml'}, None, "variable_manager")
    assert 'basedir (None) should be a str but was a <class \'NoneType\'>' in str(excinfo.value)

    # Test exception of passing a dict but missing variable_manager

# Generated at 2022-06-21 00:59:40.855054
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.vault import VaultLib
    from ansible.vars import VariableManager

    vm = VariableManager()

# Generated at 2022-06-21 00:59:49.598499
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    """
    This test ensures the output of a PlaybookInclude object matches the
    expected output when a playbook is loaded.
    """
    import os
    from six import StringIO
    from ansible.playbook import Play
    from ansible.playbook import Playbook
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.template import Templar

    test_dir = os.path.dirname(os.path.realpath(__file__))
    test_data_dir = os.path.join(test_dir, 'test_data/playbook_include')
    variable_manager = TaskQueueManager.load_variable_manager_from_directory(test_data_dir)

# Generated at 2022-06-21 00:59:53.810570
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    playbook_include = PlaybookInclude()
    assert playbook_include.import_playbook == None
    assert playbook_include.vars == {}


# Generated at 2022-06-21 01:00:00.872818
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # Testing with good parameters
    ds = "playbook.yml"
    pb_inc = PlaybookInclude()
    pb_inc.load_data(ds, basedir=None)
    assert ds == pb_inc.import_playbook

    # Testing with bad parameters
    ds = "playbook.yml not_a_parameter"
    pb_inc = PlaybookInclude()
    try:
        pb_inc.load_data(ds, basedir=None)
    except AnsibleParserError:
        pass
    else:
        assert False, "Should have raised an AnsibleParserError"

# Generated at 2022-06-21 01:00:07.599086
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # here you should write your tests to test the load_data method of class PlaybookInclude
    # here are some sample tests

    # tests for valid load of data
    data = {
         "import_playbook": "my_imported_playbook.yml",
         "vars": { "var1": "foo", "var2": "bar" }
    }
    playbook = PlaybookInclude.load(data=data, basedir='/foo/bar/baz', variable_manager=None, loader=None)
    assert playbook is not None
    assert playbook.import_playbook == data['import_playbook']
    assert playbook.vars == data['vars']

    # tests for invalid load of data

# Generated at 2022-06-21 01:00:15.712571
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    import os

    basedir = os.path.join(os.path.dirname(__file__), 'test_data', 'playbook_included_playbooks')
    p = PlaybookInclude.load({'import_playbook': './playbook_1.yml'}, basedir=basedir)
    assert(len(p._entries) == 3)

# Generated at 2022-06-21 01:00:17.336275
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass


# Generated at 2022-06-21 01:00:23.076250
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pbi = PlaybookInclude.load(dict(include='playbook.yml'), '/some/path')
    assert pbi.import_playbook == 'playbook.yml'
    assert pbi.vars == dict()

# Generated at 2022-06-21 01:00:28.999050
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    filename = 'test_PlaybookInclude_load.yaml'
    with open(filename, 'w') as f:
        f.write('''
        - import_playbook: /path/to/file.yml
        ''')

    f.close()
    pb = PlaybookInclude.load(filename, '.', variable_manager=None, loader=None)
    os.remove(filename)
    assert pb._entries[0].file_name == '/path/to/file.yml'

# Generated at 2022-06-21 01:00:39.570218
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.vault import VaultLib

    # PlaybookInclude.preprocess_data with normal data
    data = {'import_playbook': 'site.yml'}
    assert PlaybookInclude.preprocess_data(data) == {'import_playbook': 'site.yml'}

    # PlaybookInclude.preprocess_data with extra arguments
    data = {'import_playbook': 'site.yml --tags "a,b"'}
    assert PlaybookInclude.preprocess_data(data) == {'import_playbook': 'site.yml', 'tags': 'a,b'}

    # PlaybookInclude.preprocess_data with extra arguments with quotes
    data = {'import_playbook': 'site.yml --tags "tag a,tag b"'}
   

# Generated at 2022-06-21 01:01:09.108313
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.template import Templar
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    ds = AnsibleMapping()
    ds['import_playbook'] = '/test/test_playbook.yml'
    ds['vars'] = {'one':'one', 'two':'two'}

    templar = Templar(loader=None, variables={})
    file_name = templar.template(ds['import_playbook'])

    # Check for FQCN
    resource = _get_collection_playbook_path(file_name)
    if resource is not None:
        playbook = resource[1]


# Generated at 2022-06-21 01:01:23.574452
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import jinja2
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.six import PY3

    def dump(data):
        # regular dump does not preserve the original order
        if PY3:
            return jinja2.escape(yaml.dump(data, Dumper=AnsibleDumper, width=1000, default_flow_style=False, allow_unicode=True))
        else:
            return jinja2.escape(yaml.safe_dump(data, Dumper=AnsibleDumper, width=1000, default_flow_style=False, allow_unicode=True))


# Generated at 2022-06-21 01:01:24.544332
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass # TODO

# Generated at 2022-06-21 01:01:28.612184
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # setup
    ds = {}
    expected_result = {}

    # call tested method
    result = PlaybookInclude._PlaybookInclude__preprocess_data(ds)

    # validate
    assert result == expected_result



# Generated at 2022-06-21 01:01:30.542819
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-21 01:01:42.761562
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    import shutil
    import tempfile

    from ansible.module_utils.six import StringIO

    from ansible.errors import AnsibleParserError
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task


# Generated at 2022-06-21 01:01:49.714682
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping

    display = Display()
    display.deprecated = lambda msg, version: None
    loader = AnsibleLoader(None, variable_manager=None, all_vars=None)

    # Test case 1 - Confirm correct return value
    data = {
        'import_playbook': 'test.yml',
    }
    data = data.copy()
    data = loader.load(data)

    variable_manager = VariableManager()
    variable_manager.set_inventory(None)

    data = PlaybookInclude.load(data, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-21 01:01:57.626725
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    filename = "dummyfile"
    variable_manager = None
    loader = None
    basedir = os.getcwd()
    display = Display()
    options = dict()
    PlaybookInclude.load(data=None, basedir=basedir, variable_manager=variable_manager, loader=loader)

# Unit testing function for PlaybookInclude class

# Generated at 2022-06-21 01:02:11.307930
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    data = ['../test_playbooks/include.yml',
            '../test_playbooks/include2.yml',
            '../test_playbooks/include3.yml',
            '../test_playbooks/include4.yml']
    basedir = "/home/renaud/Documents/Ansible/lib/ansible/playbook"
    variable_manager = None
    
    pb_include = PlaybookInclude()

    playbooks = []
    for d in data:
        playbooks.append(pb_include.load_data(ds=d, basedir=basedir, variable_manager=variable_manager))

    assert(playbooks[0]._entries[0].name == 'Include')


# Generated at 2022-06-21 01:02:23.477384
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    playbook_include = PlaybookInclude()
    # test with invalid import playbook
    import_playbook = 1
    result = playbook_include.load(data=import_playbook, basedir="test/test_include_playbooks", variable_manager=None, loader=None)
    assert result == 1

    # test with invalid variable manager
    import_playbook = {
        'import_playbook': 'test/test_include_playbooks/playbook1.yml'
    }

    result = playbook_include.load(data=import_playbook, basedir="test/test_include_playbooks", variable_manager=None, loader=None)
    assert result != 1