

# Generated at 2022-06-21 00:53:30.315208
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.vars.hostvars import HostVars

    # test empty argument
    assert PlaybookInclude.preprocess_data({}) == {}

    # test tags
    assert PlaybookInclude.preprocess_data({'import_playbook': './include.yaml tags=foo,bar'}) == {'import_playbook': './include.yaml', 'tags': ['foo', 'bar']}
    assert PlaybookInclude.preprocess_data({'import_playbook': './include.yaml', 'tags': ['foo', 'bar']}) == {'import_playbook': './include.yaml', 'tags': ['foo', 'bar']}

    # test vars
    assert PlaybookInclude.pre

# Generated at 2022-06-21 00:53:31.010253
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # TODO
    pass

# Generated at 2022-06-21 00:53:43.044724
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    def _basic_test():
        pbi = PlaybookInclude()

        ds = dict(
                import_playbook = 'test_file.yml',
                a = 'b',
                vars = dict(
                    c = 'd',
                ),
            )
        new_ds = pbi.preprocess_data(ds)

        assert new_ds['import_playbook'] == ds['import_playbook']
        assert new_ds['vars'] == ds['vars']
        assert 'a' in new_ds
        assert new_ds['a'] == 'b'

        # We don't care about order here, just that
        # both returned ds are equal and then we
        # compare them to each other
        new_ds = pbi.preprocess_data(dict(ds))

        assert new_

# Generated at 2022-06-21 00:53:55.442554
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    ds = dict(
        import_playbook = 'test_playbook.yml',
        vars = dict(
            key1 = 'value1',
            key2 = 'value2',
        ),
    )
    basedir = os.path.dirname(os.path.dirname(__file__))
    loader = DataLoader()
    p = PlaybookInclude.load(ds, basedir, None, loader)
    assert p is not None
    assert len(p._entries) == 2
    assert p._entries[0].vars['key1'] == 'value1'
    assert p._entries[0].vars['key2'] == 'value2'

# Generated at 2022-06-21 00:54:06.798183
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    doc = dict(
        import_playbook='./child.yaml',
        when=dict(testvar=7, other="{{ testvar + 1 }}", third=False),
        tags=['foo', 'bar'],
    )
    pbi = PlaybookInclude.load(doc, basedir='/does/not/exist')
    assert pbi.import_playbook == './child.yaml'
    assert pbi.when == dict(testvar=7, other="{{ testvar + 1 }}", third=False)
    assert pbi.tags == ['foo', 'bar']

    # Test preprocess to take legacy when: params
    doc = dict(
        import_playbook='./child.yaml',
        testvar=7,
        foo="{{ other + 1 }}",
    )
    pbi = Play

# Generated at 2022-06-21 00:54:18.664358
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.task import Task
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.six import PY2
    from ansible.playbook.play import Play
    import pytest

    def _test_preprocess_data(parameters, expected_result, expected_playbook, expected_playbook_vars):
        playbook_include = PlaybookInclude()
        playbook_include.vars = dict()
        playbook_include.tags = []
        playbook_include.when = []

        class PlaybookMock(object):
            def __init__(self):
                self._entries = []


# Generated at 2022-06-21 00:54:28.267639
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.groupvars import GroupVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.playbook.play_context import PlayContext
    import pytest
    import os

    # Setup the inventory and Variable manager
    inventory = Inventory(host_list=[], vault_password='secret')
    variable_manager = VariableManager(loader=None, inventory=inventory)

    # Setup Ansible config
    os.environ['ANSIBLE_HOST_KEY_CHECKING'] = '0'

# Generated at 2022-06-21 00:54:30.259183
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    play_book_include = PlaybookInclude()
    assert play_book_include is not None

# Generated at 2022-06-21 00:54:39.297813
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)

    playbook = PlaybookInclude()
    playbook.load_data(
        dict(import_playbook='test'),
        '.',
        variable_manager=variable_manager,
        loader=loader,
    )

    assert playbook._entries[0].get_name() == 'test'


# Generated at 2022-06-21 00:54:41.972641
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    variable_manager = None
    loader = None

    file_name = "tests/fixtures/playbooks/playbook_test.yml"
    playbook_include = PlaybookInclude.load(file_name, variable_manager=variable_manager, loader=loader)
    print(playbook_include._entries)


# Generated at 2022-06-21 00:54:48.230473
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-21 00:54:54.450508
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # testing playbook include
    playbook_include = PlaybookInclude.load("test.yml", "/dev/null")

    # testing playbook
    playbook_include.load_data("test.yml", "/dev/null")

    # testing other scenarios
    playbook_include.load_data("")


# Generated at 2022-06-21 00:55:02.101293
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_obj = PlaybookInclude()
    ds1 = {'import_playbook': './playbook-dir/playbook.yml'}
    assert playbook_include_obj.preprocess_data(ds1) == ds1
    ds2 = {'import_playbook': './playbook-dir/playbook.yml', 'vars': {'key1': 'value1'}}
    assert playbook_include_obj.preprocess_data(ds2) == ds2
    ds3 = {'import_playbook': 'playbook.yml', 'key1': 'value1', 'key2': 'value2'}

# Generated at 2022-06-21 00:55:03.828394
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pi = PlaybookInclude()
    assert pi


# Generated at 2022-06-21 00:55:13.586939
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # initialisation of class to test
    loader = DataLoader()
    variable_manager = VariableManager()
    test_include = PlaybookInclude()


    # check with correct data
    ds = {'import_playbook': 'test.yml'}
    test_data = test_include.preprocess_data(ds)
    expected_data = AnsibleMapping()
    expected_data['import_playbook'] = 'test.yml'
    assert test_data == expected_data

    # check with incorrect data
    ds = {'import_playbook': 'test.yml', 'vars': 'test'}

# Generated at 2022-06-21 00:55:18.000132
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    p  = PlaybookInclude()
    # TODO: update the tests t once a new dict based API is in place
    #assert p.names is None
    #assert p.vars is None
    #assert p.options is None
    #assert p.tags is None
    #assert p.when is None

# Generated at 2022-06-21 00:55:25.239462
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    f = PlaybookInclude.load({'import_playbook': 'test_playbook.yml', 'tags': 'test_tag'}, basedir=os.getcwd())
    assert f['import_playbook'] == 'test_playbook.yml'
    assert f['tags'] == ['test_tag']

# Generated at 2022-06-21 00:55:28.700802
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # Test with no arguments
    pb = PlaybookInclude()
    assert pb._import_playbook == None
    assert pb._vars == {}
    assert pb._tags == []

# Generated at 2022-06-21 00:55:38.458283
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.parsing.dataloader import DataLoader

    # test proper loading of a collection playbook
    # from /path/to/my_collection/my_namespace/my_playbook_name.yml
    # to fqcn my_collection.my_namespace.my_playbook_name
    # TODO: BUG:  template_paths path needs to be fixed (otherwise it fails)
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo_var': 'bar'}
    variable_manager.extra_vars = {'foo_var': 'bar'}
    basedir = '.'

# Generated at 2022-06-21 00:55:51.786951
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    pb = Playbook()

    class DataLoader(object):
        pass
    data_loader = DataLoader()

    play_context = PlayContext()
    play_context.CLIARGS = None
    play_context.main = {}
    play_context.vars = {}
    play_context.defaults = {}
    play_context.CLIARGS = None
    play_context.new_stdin = None
    play_context.connection_user = None
    play_context.become_method = None
    play_context.become_user = None
    play_context.become_password = None
    play_context.become_exe = None

# Generated at 2022-06-21 00:56:10.400002
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Play

    pb_include = PlaybookInclude()

    playbooks = {}
    playbooks[1] = {
        'import_playbook': 'test_pb.yml',
        'vars': {
            'var1': 'val1',
            'var2': 'val2',
        },
    }
    playbooks[2] = {
        'import_playbook': 'test_pb.yml',
        'tags': 'tag1,tag2',
        'vars': {
            'var1': 'val1',
            'var2': 'val2',
        }
    }

# Generated at 2022-06-21 00:56:21.550491
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    # init needed objects
    basedir = './'
    variable_manager = None
    loader = None

    # create an empty Playbook() object, which we will load into
    pb = Playbook()

    # create a data structure
    import_playbook_file = 'tasks/main.yml'
    ds = {
        'import_playbook': import_playbook_file,
        'vars': {
            'var1': 'val1'
        },
        'tags': 'tag1'
    }

    # call load_data
    playbook_include = PlaybookInclude()
    playbook_include.load_data(ds, basedir, variable_manager, loader)

    # set vars and tags for the

# Generated at 2022-06-21 00:56:32.614028
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    class MockPlaybookInclude_preprocess_data:

        def __init__(self):
            self.display_deprecated = []

        def deprecated(self, msg, version):
            self.display_deprecated.append(msg)

        @property
        def display(self):
            """returns a mocked display object"""
            return self

    D.display = MockPlaybookInclude_preprocess_data()

# Generated at 2022-06-21 00:56:42.597714
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.playbook_include import PlaybookInclude

    import os
    import sys
    import doctest
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor


# Generated at 2022-06-21 00:56:44.141102
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass



# Generated at 2022-06-21 00:56:54.413502
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os
    current_dir = os.path.dirname(os.path.abspath(__file__))
    collections = AnsibleCollectionConfig()
    collections.add_collection(path="ansible_namespace.collection/roles/service")
    collections_root = collections.get_collections_paths()
    pb_incl = PlaybookInclude.load(
        {"import_playbook": "ansible_namespace.collection.collection_playbook"},
        basedir=current_dir,
        variable_manager=None,
        loader=None
    )
    assert pb_incl._entries[0]._included_path == os.path.dirname(os.path.join(current_dir, collections_root[0], "ansible_namespace.collection.collection_playbook"))

# Unit

# Generated at 2022-06-21 00:57:03.407115
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    print(">>test_PlaybookInclude_load:")
    UNVALID_YAML_OBJECT = AnsibleBaseYAMLObject()
    UNVALID_YAML_OBJECT.ansible_pos = (0, 0)

    # Test when ds is empty, should return False
    print(">>>test when ds is empty")
    pbi_load = PlaybookInclude.load(data={}, basedir='/var/tmp', variable_manager=None, loader=None)
    assert pbi_load is False
    print("test when ds is empty: OK")

    # Test when ds is not a dict, should raise AnsibleAssertionError
    print(">>>test when ds is not a dict")

# Generated at 2022-06-21 00:57:14.672364
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude

    # test using the 'import_playbook' syntax
    ds = dict(import_playbook="test_play.yml", tags=['tag1'], vars=dict(foo='bar'))
    pbi = PlaybookInclude()
    p = pbi.load_data(ds, '.')
    assert isinstance(p, Play)
    assert isinstance(p.get_vars(), dict)
    assert 'foo' in p.get_vars().keys()
    assert p.get_vars()['foo'] == 'bar'
    assert p.tags == ['tag1']

    # test using the old 'include' syntax

# Generated at 2022-06-21 00:57:26.484610
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook

    data = dict(import_playbook="test.yml",
                when=["ansible_facts['distribution'] == 'Debian'"],
                tags=["tests"],
                vars=dict(var1="1", var2="2"))
    obj = PlaybookInclude()
    pb = obj.load_data(data, "/home/user/")
    
    assert obj.import_playbook == "test.yml"

# Generated at 2022-06-21 00:57:35.770418
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    import os
    import sys
    import tempfile
    # Create temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create temporary playbook file
    playbook_file = os.path.join(tmpdir, 'test_PlaybookInclude.yml')
    playbook_body = '---\n- hosts: localhost\ntasks:\n  - name: test task\n    debug: msg="hello!!!"\n'
    fd = open(playbook_file, 'w')
    import_body = '\n- import_playbook: ' + playbook_file + '\n'
    fd.write(import_body)
    fd.close()

    # Create an inventory file
    inventory_file = os.path.join(tmpdir, 'test_inventory')

# Generated at 2022-06-21 00:57:48.683309
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    import_playbook = 'var_prompt.yml'
    vars = dict()

    playbook = PlaybookInclude()
    playbook.import_playbook = import_playbook
    playbook.vars = vars

    assert playbook.import_playbook == import_playbook
    assert playbook.vars == vars

# Generated at 2022-06-21 00:58:02.262515
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from itertools import chain
    from ansible.utils.vars import combine_vars

    def _check_combine_vars(a, b):
        ret = combine_vars(a, b)
        assert len(ret) == len(a.data) + len(b.data)
        assert len(ret) > 0
        assert ret == dict(chain(a.data.items(), b.data.items()))

    def _check_load_data(loader, ds, basedir, in_dir, vars=None, is_playbook=False):
        all_vars = VariableManager()
        all_vars.update(vars)

# Generated at 2022-06-21 00:58:03.171327
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass # TODO

# Generated at 2022-06-21 00:58:14.659679
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')

    playbook_include = PlaybookInclude.load(
        ds=dict(
            import_playbook='site.yml',
        ),
        basedir='',
        loader=loader,
        variable_manager=VariableManager(loader=loader, inventory=inventory),
    )
    # FIXME: assert playbook_include is not None
    # FIXME: add more asserts


# Generated at 2022-06-21 00:58:15.675294
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass # TODO

# Generated at 2022-06-21 00:58:27.403923
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # Import here to avoid a dependency loop
    from ansible.playbook import Playbook

    data = dict()
    data['include_tasks'] = 'file1'
    data['tags'] = 'tag1'
    data['vars'] = {'name1': 'val1'}
    data['when'] = "ansible_os_family == 'RedHat'"
    basedir = '/'
    variable_manager = None
    loader = None
    obj = PlaybookInclude()

    assert obj != PlaybookInclude().load_data(ds=data, basedir=basedir, variable_manager=variable_manager, loader=loader)

    assert obj != PlaybookInclude.load(data=data, basedir=basedir, variable_manager=variable_manager, loader=loader)

# Unit Test for method preprocess_data of class

# Generated at 2022-06-21 00:58:30.885572
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    ds = {}
    PlaybookInclude.load(ds, loader=None)


# Generated at 2022-06-21 00:58:41.232982
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper


# Generated at 2022-06-21 00:58:47.482178
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
	from ansible.playbook.play import Play
	from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
	from ansible.playbook.task import Task
	from ansible.playbook.task_include import TaskInclude
	from ansible.playbook.role_include import RoleInclude
	from ansible.parsing import ds as data_structure
	from ansible.parsing.yaml.dumper import AnsibleDumper
	from ansible.template import Templar
	from ansible.vars.manager import VariableManager
	from ansible.inventory.manager import InventoryManager
	from ansible.parsing.mod_args import ModuleArgsParser
	from ansible.utils.collection_loader import AnsibleCollectionConfig

	AnsibleCollectionConfig.default_collection_type = 'ansible'

# Generated at 2022-06-21 00:58:59.008955
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # Arrange
    import ansible.playbook.play_context as pc
    import ansible.playbook.play as play
    import ansible.playbook.role as role
    import ansible.playbook.task as task

# Generated at 2022-06-21 00:59:10.063416
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.plugins.loader import vars_loader
    import_object = PlaybookInclude()
    new_ds = {}
    with pytest.raises(AnsibleAssertionError):
        import_object.preprocess_data(ds=new_ds)
    new_ds = "my string"
    with pytest.raises(AnsibleAssertionError):
        import_object.preprocess_data(ds=new_ds)
    new_ds = {'test': 'test'}
    assert import_object.preprocess_data(ds=new_ds) == new_ds
    new_ds = {}
    new_ds['vars'] = {'x': 'y'}
    assert import_object.preprocess_data(ds=new_ds) == new_ds

# Generated at 2022-06-21 00:59:23.549793
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    basedir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..', '..'))
    pb = 'test/integration/module_utils/test_include.yml'

    # Generate the PlaybookInclude object
    loader = DataLoader()
    variable_manager = VariableManager()
    ds = PlaybookInclude.load(pb, basedir, variable_manager, loader)

    # Assertions
    assert isinstance(ds, PlaybookInclude)
    assert ds.import_playbook == pb
    assert ds.vars == {'a': 1}

# Generated at 2022-06-21 00:59:27.067741
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # Creates a PlaybookInclude module from a dictionary
    PlaybookInclude.load({'k':'v'}, loader=None)

# Generated at 2022-06-21 00:59:39.275877
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # type is a class, not an object
    pi = PlaybookInclude

    # test input and expected results

# Generated at 2022-06-21 00:59:39.940199
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass


# Generated at 2022-06-21 00:59:41.474826
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():    # noqa
    p = PlaybookInclude()
    assert p is not None


# Generated at 2022-06-21 00:59:45.923894
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    yaml_data = """
    - import_playbook: foo.yaml
    """
    data = AnsibleMapping.load(yaml_data)
    p = PlaybookInclude.load(data[0], None)
    assert p.import_playbook == 'foo.yaml'
    assert p.vars == dict()



# Generated at 2022-06-21 00:59:58.604039
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    test_data_dict_simple = dict(
        import_playbook=dict(
            import_playbook='/path/to/playbook.yaml'
            )
        )
    test_data_ansible_mapping = AnsibleMapping(
        import_playbook=dict(
            import_playbook='/path/to/playbook.yaml'
            )
        )

    # create a PlaybookInclude from the dict
    test_PlaybookInclude_simple = PlaybookInclude.load(
        data=test_data_dict_simple,
        basedir='/path/to/project/root'
        )
    # assert that import_playbook is a string and equates to the test_data
    assert isinstance(test_PlaybookInclude_simple.import_playbook, string_types)
   

# Generated at 2022-06-21 01:00:05.527592
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    ds = {'include': 'somefile.yml',
          'vars': {'a': 'b'},
          'tags': 'c'}
    new_ds = PlaybookInclude.preprocess_data(PlaybookInclude, ds)
    assert new_ds == {'import_playbook': 'somefile.yml',
                      'tags': 'c',
                      'vars': {'a': 'b'}}



# Generated at 2022-06-21 01:00:06.834592
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-21 01:00:21.807964
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.data import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()


    # Typical case with dict as a dict
    ds = dict(import_playbook='test.yml')
    new_ds = PlaybookInclude.preprocess_data(ds, loader, variable_manager)

    assert isinstance(new_ds, dict)
    assert len(new_ds) == 1
    assert 'import_playbook' in new_ds
    assert new_ds['import_playbook'] == 'test.yml'


    # Typical case with dict as an AnsibleMapping
    ds = AnsibleMapping(import_playbook='test.yml')
    new_ds = PlaybookInclude.preprocess_data

# Generated at 2022-06-21 01:00:24.474497
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # TODO: this doesn't not yet test anything
    # TODO: add test
    pass

# Generated at 2022-06-21 01:00:33.080115
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    """Unit test for method preprocess_data of class PlaybookInclude"""

    #######################
    # TEST WITH LEGACY PARAMS
    #######################

    # Test with legacy parameters
    ds = {'import_playbook': '../other_playbook.yml'}
    new_ds = AnsibleMapping()
    new_ds['import_playbook'] = '../other_playbook.yml'
    result = PlaybookInclude.preprocess_data(ds)

    assert(result == new_ds)

    ds = {'import_playbook': '../other_playbook.yml', 'vars': {'var1': 'foo'}}
    new_ds = AnsibleMapping()
    new_ds['import_playbook'] = '../other_playbook.yml'
    new_

# Generated at 2022-06-21 01:00:40.337904
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    ds = dict(
        filename='importtest.yml',
        import_playbook='testfile.yml',
        tags=['tag1', 'tag2'],
        when=[('testvar', 'testvalue')],
        vars=dict(
            testvar='testvalue'
        )
    )


# Generated at 2022-06-21 01:00:50.066338
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.module_utils.six import PY3

    # Test loading the data
    test_data_to_load = AnsibleLoader(None, vault_password_file=C.DEFAULT_VAULT_PASSWORD_FILE).load('''
        - hosts: all
          tasks:
            - tag1:
                import_playbook: /path/to/playbook.yaml
    ''')
    playbook = PlaybookInclude.load(test_data_to_load, '/')

# Generated at 2022-06-21 01:01:00.871980
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook = """
    - name: playbook
      hosts: localhost
      vars:
        var_playbook: value_playbook
      tasks:
      - import_playbook: include_playbook.yml
    """

# Generated at 2022-06-21 01:01:08.098670
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    ds = { 'import_playbook': 'file1',
           'hosts': 'host1'}
    new_ds = {'import_playbook': 'file1',
              'hosts': 'host1'}
    ansible_ds = AnsibleMapping(ds)

    import_playbook = PlaybookInclude()
    result = import_playbook.preprocess_data(ansible_ds)
    assert result == new_ds

    ds = { 'import_playbook': 'file1',
           'vars': {'var1': 'val1'},
           'hosts': 'host1'}
    new_ds = {'import_playbook': 'file1',
              'vars': {'var1': 'val1'},
              'hosts': 'host1'}
    ansible_

# Generated at 2022-06-21 01:01:21.400371
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # import here to avoid a dependency loop
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    # Create a PlaybookInclude object
    playbook_include = PlaybookInclude()

    # Load a sime role with basic data
    data = dict()
    data['import_playbook'] = 'test_playbook_include.yml'
    data['tags'] = 'include_tag'
    data['vars'] = dict()
    data['vars']['var1'] = 'value1'
    data['vars']['var2'] = 'value2'
    playbook

# Generated at 2022-06-21 01:01:22.784427
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():  # noqa: E501
    PlaybookInclude()

# Generated at 2022-06-21 01:01:32.695730
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play

    # Create the object
    pi_a = PlaybookInclude()

    # Create a play and add it to the playbook_include object
    pi_a.load({'import_playbook': 'playbook.yml'})

    # Create a play and add it to the playbook_include object
    pi_a.load({u'import_playbook': u'playbook.yml', u'vars': {u'var1': u'value1'}})

    # Create a play and add it to the playbook_include object
    pi_a.load({u'import_playbook': u'playbook.yml', u'tags': u'foo'})

    # Create a play and add it to the playbook_include object
    pi_

# Generated at 2022-06-21 01:02:00.448369
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():

    # Assign result of class's method load to a local variable
    result = PlaybookInclude.load(data=dict(import_playbook='/some/path.yml'), basedir='/some/path/to/a/playbook/')

    # Assert that result['_entries'] is not empty
    assert result._entries is not None

    # Assert that result['_default_vars'] is not empty
    assert result._default_vars is not None

    # Assert that result['_playbook_vars'] is not empty
    assert result._playbook_vars is not None

    # Assert that result['_role_names'] is not empty
    assert result._role_names is not None

    # Assert that result['_variable_manager'] is not empty
    assert result._variable_manager is not None

   

# Generated at 2022-06-21 01:02:12.551031
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.play import Play

    # build a set of test data to call preprocess_data on

# Generated at 2022-06-21 01:02:20.924552
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    datastructure = {
        'import_playbook': 'foo.yml',
        'vars': {
            'foo': 'bar'
        }
    }

    # import here to avoid a dependency loop
    from ansible.playbook import Playbook

    # should return a Playbook object
    result = PlaybookInclude.load(data=datastructure, basedir='/ansible/playbook')
    assert isinstance(result, Playbook)


# Generated at 2022-06-21 01:02:24.482083
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    PlaybookInclude.load(data=dict(import_playbook="include_playbook.yaml"), basedir="tests/integration/hello_world_playbook/")



# Generated at 2022-06-21 01:02:24.942426
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pass

# Generated at 2022-06-21 01:02:32.373373
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pbinclude = PlaybookInclude()

    # Test if import_playbook is raise exception if its not string or None
    with pytest.raises(AnsibleParserError) as excinfo:
        pbinclude.import_playbook = []
    assert "playbook import parameter must be a string indicating a file path, got list instead" in str(excinfo.value)

    # Test if __str__() working
    pbinclude.import_playbook = '/home/user/playbook.yml'
    assert isinstance(str(pbinclude), string_types)

    # Test if preprocess_data() is working
    with pytest.raises(AnsibleParserError) as excinfo:
        pbinclude.preprocess_data({'import_playbook': None})
    assert "playbook import parameter is missing" in str

# Generated at 2022-06-21 01:02:42.027616
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import json
    import os

    from ansible.playbook import PlaybookInclude

    from ansible.utils.collection_loader._collection_finder import _annotate_collections_to_match

    ansible_base_dir = os.path.dirname(__file__)
    collection_dirs = [os.path.join(ansible_base_dir, '_data', 'playbooks')]
    collection_dirs = _annotate_collections_to_match(collection_dirs)

    import_playbook_file = os.path.join(ansible_base_dir, '_data', 'playbooks', 'import_playbook.yml')
    playbook_includes = PlaybookInclude._load_playbook_includes(import_playbook_file, collection_dirs)


# Generated at 2022-06-21 01:02:42.863366
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-21 01:02:43.899172
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-21 01:02:48.670461
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    playbook_include = PlaybookInclude()
    assert playbook_include.tags == []
    assert playbook_include.when == []
    assert playbook_include.import_playbook == ''
    assert playbook_include.vars == {}

# Generated at 2022-06-21 01:03:14.410898
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    ds = dict(
        import_playbook = 'other_playbook.yml',
        when            = 'foo',
        tags            = ['bar'],
        vars            = dict(
            foo = 'bar'
        )
    )
    basedir = '/home/michael/ansible'
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources="localhost,")
    variable_manager.set_inventory(inventory)

    # creation of playbook object
    playbook_include = PlaybookInclude()
    playbook_include.load_data(ds, basedir, variable_manager, loader)