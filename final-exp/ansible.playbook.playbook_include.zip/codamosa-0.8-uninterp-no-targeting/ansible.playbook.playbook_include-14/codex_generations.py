

# Generated at 2022-06-21 00:53:29.097846
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.playbook import Playbook
    from ansible.playbook.tasks import Task
    from ansible.playbook.play import Play

    import_playbook = './included_playbook.yml'
    vars = {'var_from_included_playbook': 'value_from_included_playbook'}
    tags = ['dummy_tag']

    playbook_include = PlaybookInclude()
    playbook_include.import_playbook = import_playbook
    playbook_include.vars = vars
    playbook_include.tags = tags

    pb = playbook_include.load_data(ds=playbook_include, basedir='/test_playbook_include')

    assert isinstance(pb, Playbook)

# Generated at 2022-06-21 00:53:36.917832
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''
    Unit test for method load_data of class PlaybookInclude
    '''
    from ansible.plugins.loader import playbook_loader
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    playbook_loader.add('tasks/main.yml', b'''---
- include_tasks: other.yml
''')
    playbook_loader.add('other.yml', b'''---
- debug:
    msg: 'example'
''')

    pb = PlaybookInclude.load({'import_playbook': 'tasks/main.yml'},
                              '/foo/bar', loader=playbook_loader)
    assert isinstance(pb, Playbook)
    assert len(pb._entries) == 1

# Generated at 2022-06-21 00:53:48.937113
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import_playbook_assignments = C._ACTION_IMPORT_PLAYBOOK
    for assignment_method in import_playbook_assignments:
        test_data = { assignment_method: 'test.yaml' }
        pbi = PlaybookInclude()
        pbi.load_data(test_data, basedir='.', variable_manager=None, loader=None)
        assert pbi.import_playbook == 'test.yaml'
        assert pbi.vars == {}
        assert pbi.tags is None
        assert pbi.when is None

        test_data = { C._ACTION_IMPORT_PLAYBOOK[0]: 'test.yaml tags=tag1,tag2',
                      'vars': {'test':'value' } }
        pbi = PlaybookInclude()
        pbi.load

# Generated at 2022-06-21 00:53:59.001189
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task

    # test for no playbook
    assert PlaybookInclude.load({}, '/') is None

    # test for invalid playbook
    assert PlaybookInclude.load({'include': 'my_playbook'}, '/') is None

    # test for playbook without paths
    assert PlaybookInclude.load({'include': 'my_playbook.yaml'}, '/') is None

    # test for playbook with paths
    paths = {
        'roles': [],
        'collections': [],
        'tasks': [],
        'defaults': [],
        'meta': [],
        'vars': []
    }

# Generated at 2022-06-21 00:54:11.850062
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.vars import VariableManager
    from ansible.template import Templar

    basedir = os.path.join(os.path.dirname(__file__), 'playbook_include')
    pb = Playbook.load(basedir + os.sep + 'test.yml', loader=DataLoader(), variable_manager=VariableManager())
    templar = Templar(loader=pb._loader)

    # check generated playbooks
    assert len(pb._entries) == 2
    assert isinstance(pb._entries[0], Play)

# Generated at 2022-06-21 00:54:23.470975
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    plbk_inc = PlaybookInclude()
    data = {'import_playbook': 'test.yml', 'vars': {'key1': 'value1'}, 'tags': 'import'}
    result = plbk_inc.load_data(data, None, None, None)
    assert result.__class__.__name__ == 'Playbook'
    assert result.entries[0].__class__.__name__ == 'Play'
    assert 'test.yml' in result.entries[0].get_name()
    plbk_inc = PlaybookInclude()
    data = {'import_playbook': 'test.yml', 'tags': 'playbook,tag1,tag2'}
    result = plbk_inc.load_data(data, None, None, None)
   

# Generated at 2022-06-21 00:54:33.488059
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # Method preprocess_data is a helper method that is used to
    # convert the raw data structure into the expected format for
    # the initialization of an instance of the PlaybookInclude class.
    # When this method is changed, a unit test to make sure that
    # the expected data structure is generated from the raw one
    # should be added to this test module.

    # This is the raw data structure that is used to test the method
    ds = dict(
        # This should be converted to import_playbook="filename"
        import_playbook='filename',
        # This should remain unchanged
        other_key='other value'
    )

    # This is the expected data structure that should be generated
    # by the preprocess_data method

# Generated at 2022-06-21 00:54:41.299865
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # Test case 1: if v is not a string, raise AnsibleParserError
    obj = PlaybookInclude()
    with pytest.raises(AnsibleParserError):
        obj._preprocess_import("", "", "", None)
    with pytest.raises(AnsibleParserError):
        obj._preprocess_import("", "", "", 1)
    with pytest.raises(AnsibleParserError):
        obj._preprocess_import("", "", "", [])
    with pytest.raises(AnsibleParserError):
        obj._preprocess_import("", "", "", {})
    with pytest.raises(AnsibleParserError):
        obj._preprocess_import("", "", "", True)

    # Test case 2: if the v has a ":" in the middle

# Generated at 2022-06-21 00:54:46.498069
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    from ansible.playbook.play import Play

    ds = {
        'import_playbook': 'webservers.yml'
    }
    data = PlaybookInclude.load(ds, basedir='/tmp')
    assert isinstance(data, Playbook)
    assert isinstance(data[0], Play)
    assert data[0].name == 'webservers.yml'

    ds = {
        'import_playbook': 'webservers.yml',
        'vars': {
            'http_port': 80,
            'maxclients': 200,
        }
    }
    data = PlaybookInclude.load(ds, basedir='/tmp')
    assert isinstance(data, Playbook)
    assert isinstance(data[0], Play)

# Generated at 2022-06-21 00:54:54.905450
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
  from ansible.playbook.play import Play
  yaml_obj = {"- import_playbook": "test.yml", "hosts": "localhost", "tasks": [{"debug": {"msg": "test"}}]}
  pb = PlaybookInclude.load(data=yaml_obj, basedir=".")
  assert(isinstance(pb, Play))

# Generated at 2022-06-21 00:55:01.393308
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    playbook_include = PlaybookInclude.load(data={}, basedir='.')
    assert playbook_include is not None


# Generated at 2022-06-21 00:55:12.137550
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    class DummyPlaybookInclude(PlaybookInclude):
        def __init__(self):
            self.load_data = PlaybookInclude.load_data

    ##################################
    # import_playbook with no vars
    ##################################
    data = dict(
        import_playbook='/tmp/file'
    )
    basedir = '/tmp'
    variable_manager = None
    loader = None
    expected_pb = Playbook()
    expected_pb.vars = []
    expected_pb.tasks = []
    expected_pb.handlers = []
    actual = DummyPlaybookInclude().load(data, basedir, variable_manager, loader)
    assert expected_pb == actual

    ##################################
    # import_playbook with vars
    ##################################

# Generated at 2022-06-21 00:55:16.095350
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    my_playbook_include = PlaybookInclude()
    assert (my_playbook_include != None)
    assert (my_playbook_include.vars == {})

# Generated at 2022-06-21 00:55:16.908937
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-21 00:55:28.259801
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    PlaybookInclude.load_data(ds={'import_playbook':'foo.yml','vars':{'myvar':2}})
    # PlaybookInclude.load_data(ds={'import_playbook':'foo.yml','tags':'tag1,tag2','vars':{'myvar':2}})
    # FIXME: Should return an error because no tags
    # PlaybookInclude.load_data(ds={'import_playbook':'foo.yml','tags':'','vars':{'myvar':2}})

# Generated at 2022-06-21 00:55:40.731283
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    pbi = PlaybookInclude()
    data = {
        'key1': 'value1',
        'import_playbook': 'name_of_playbook.yaml vars',
        'tags': 'tag1,tag2',
        'vars': {
            'var1': 'value1',
            'var2': 'value2'
            }
        }
    new_data = pbi.preprocess_data(data)
    assert new_data['import_playbook'] == 'name_of_playbook.yaml'
    assert new_data['tags'].split(',') == ['tag1', 'tag2']
    assert new_data['vars']['var1'] == 'value1'
    assert new_data['vars']['var2'] == 'value2'

# Generated at 2022-06-21 00:55:49.875657
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    data = u'---\n' \
           u'- import_playbook: /path/to/file1\n' \
           u'  vars:\n' \
           u'    foo: bar\n' \
           u'    baz: qux\n' \
           u'  tags: "{{ tags }}"\n' \
           u'- import_playbook: /path/to/file2\n' \
           u'  tags: tag1,tag2\n' \
           u'  vars:\n' \
           u'    foo: bar\n'

    from ansible.playbook.playbook_include import PlaybookInclude

    include = PlaybookInclude.load(data, '.')
    assert len(include._entries) == 2
    assert include._entries[0].vars

# Generated at 2022-06-21 00:55:59.675029
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os
    import tempfile
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()
    os.makedirs(tmp_dir + '/group_vars')
    os.makedirs(tmp_dir + '/host_vars')

    # Create temporary files for 'hosts' and 'site.yml'
    fd, hosts_file = tempfile.mkstemp(dir=tmp_dir)
    print("[test]") >> hosts_file
    print("localhost name=localhost") >> hosts_file
    os.close(fd)

    fd, input_file = tempfile.mkstemp(dir=tmp_dir)

# Generated at 2022-06-21 00:56:00.647114
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-21 00:56:01.524009
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-21 00:56:17.773780
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.block import Block

    play_book_include = PlaybookInclude()

#     # Test 1: missing import playbook value
#     ds = AnsibleMapping()
#     ds['tasks'] = Block()
#     result = play_book_include.load_data(ds=ds, basedir='/path/to/playbooks/')
#     assert result.__class__.__name__ == 'Playbook'
#     assert result.entries[0].__class__.__name__ == 'Play'
#     assert result.entries[0].tasks == ds['tasks']

#     # Test 2: bad import playbook value
#     ds = AnsibleMapping()
#     ds['import_playbook'] = 1
#     ds['tasks'] = Block()


# Generated at 2022-06-21 00:56:30.445637
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    import os
    tmp_path = '/tmp/ansible_test_playbook_include'
    if not os.path.exists(tmp_path):
        os.mkdir(tmp_path)
    with open('/tmp/ansible_test_playbook_include/include_test.yml', 'wb') as f:
        f.write("""- hosts: all
  tasks:
  - name: task1
    ping:
- hosts: all
  tasks:
  - name: task2
    ping:
""")
    data = """
- import_playbook: include_test.yml
"""
    obj = PlaybookInclude.load(data, '/tmp/ansible_test_playbook_include')
   

# Generated at 2022-06-21 00:56:38.243306
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-21 00:56:51.430443
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play
    import_playbook = "import_playbook.yml"
    include_vars = {'name': 'John'}
    playbook = PlaybookInclude.load(
        {'include': "{0} name=John".format(import_playbook)}, '.')
    playbook.preprocess_data(playbook.data)
    assert playbook.import_playbook == import_playbook
    assert playbook.vars == include_vars
    playbook = PlaybookInclude.load(
        {'include': "{0} name=John tags=tag1,tag2".format(import_playbook)}, '.')
    playbook.preprocess_data(playbook.data)
    assert playbook.import_playbook == import_playbook
    assert playbook.vars == include_vars

# Generated at 2022-06-21 00:56:55.398180
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pb = PlaybookInclude()
    pb.load({'import_playbook': 'test.yml',
             'vars': {'foo': 'bar'}})
    assert pb.import_playbook == 'test.yml'
    assert pb.vars['foo'] == 'bar'
    assert pb.tags == []

# Generated at 2022-06-21 00:57:04.224219
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    import_playbook = '/path/to/import_playbook.yml'
    vars = dict(ping='pong')
    include_tags = 'include_tags'
    exclude_tags = 'exclude_tags'
    when = 'ping == pong'

    # test with import_playbook, vars, tags and when
    pb_include = PlaybookInclude()
    pb_include.import_playbook = import_playbook
    pb_include.vars = vars
    pb_include.tags = [include_tags, exclude_tags]
    pb_include.when = when

    # assert about vars
    assert pb_include.vars is not None
    assert pb_include.vars == vars

    # assert about import_playbook

# Generated at 2022-06-21 00:57:14.999377
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    global __file__
    __file__ = os.path.dirname(__file__)
    if __file__ != "" and os.getcwd() != __file__:
        os.chdir(__file__)

    # Placeholder test that uses assertTrue instead of assertEqual to verify if
    # objects are identical.  Can be removed once proper testing is added.
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    from ansible.playbook.inventory import Inventory

    add_all_plugin_dirs()
    variable_manager = VariableManager()
    loader = DataLoader()

    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost')

# Generated at 2022-06-21 00:57:25.674375
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # check for proper parsing of import_tasks
    import_playbook_data = {'import_playbook': 'subplaybook.yml'}
    result = PlaybookInclude.preprocess_data(import_playbook_data)
    assert result['import_playbook'] == 'subplaybook.yml'

    # check for proper parsing of import_tasks with parameters
    import_playbook_data = {'import_playbook': 'subplaybook.yml some_param=foo another_param=bar'}
    result = PlaybookInclude.preprocess_data(import_playbook_data)
    assert result['import_playbook'] == 'subplaybook.yml'
    assert result['vars']['some_param'] == 'foo'

# Generated at 2022-06-21 00:57:36.837625
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    loader = AnsibleLoader(None, False, None, None)
    dumper = AnsibleDumper()


# Generated at 2022-06-21 00:57:45.691534
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''
    Unit test for method load_data of class PlaybookInclude
    '''

    # Load a playbook which includes the playbook 'include_playbook.yml'.
    # This playbook contains two tasks in pre_tasks, two roles, two tasks in
    # tasks, and two tasks in post_tasks.

    import ansible.playbook.play
    import ansible.inventory
    import ansible.vars.manager
    import ansible.parsing.dataloader
    import ansible.utils.collection_loader

    data = {
        'import_playbook': 'include_playbook.yml',
        'vars': {
            'v': 'value'
         }
    }
    basedir = os.path.abspath('test/units/playbook_include')
    inv_file = os

# Generated at 2022-06-21 00:57:56.391821
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    p = PlaybookInclude()
    assert p.vars == dict()
    assert p.import_playbook is None
    assert p.tags == []

# Generated at 2022-06-21 00:57:58.434582
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pbi = PlaybookInclude()
    assert pbi is not None


# Generated at 2022-06-21 00:58:08.278228
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Play
    import ansible.playbook.playbook
    import ansible.playbook.block
    p = PlaybookInclude.load({"import_playbook": "foo"}, '/home/runner/workspace/ansible-core-tests/core/hacking/test_playbook_include.yml')
    assert type(p) is ansible.playbook.playbook.Playbook
    assert len(p._entries) == 1
    assert type(p._entries[0]) is Play
    assert len(p._entries[0].tasks) == 2
    assert type(p._entries[0].tasks[0]) is ansible.playbook.block.Block
    assert p._entries[0]._included_path == '/home/runner/workspace'


# Unit

# Generated at 2022-06-21 00:58:18.030613
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os
    import tempfile
    import shutil
    import json
    from ansible.module_utils.six import PY3

    from ansible.playbook import Playbook
    from ansible.parsing.dataloader import DataLoader

    from units.mock.loader import DictDataLoader

    # make a tmp directory to operate in
    tmpdir = tempfile.mkdtemp()

    # create a minimal playbook to import
    playbook_filename = os.path.join(tmpdir, 'main.yml')
    playbook_files = ['---', '- hosts: all', '  tasks:', '    - debug:', '        msg: Hello world!']

# Generated at 2022-06-21 00:58:28.176790
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from units.mock.loader import DictDataLoader

    loader = DictDataLoader({
        "test_playbook_include.yaml": """
        - hosts: all
          tasks:
            - debug:
                msg: foo

        - import_playbook: test_playbook_include2.yaml
          vars:
            http_port: 8080
            maxRequestsPerChild: 8081
        """,
        "test_playbook_include2.yaml": """
        - hosts: all
          tasks:
            - debug:
                msg: bar
        """
    })

    variable_manager = VariableManager()

# Generated at 2022-06-21 00:58:40.174013
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.module_utils.six import u
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import re

    # create a unicode object (cannot use u"" with python3)
    unicode_val = AnsibleUnicode(u('this is a unicode string'))
    # create a normal string object
    string_val = 'this is a python2 str object'

    # check that both strings are not equal
    assert not unicode_val == string_val
    # check that unicode and string are not equal
    assert unicode_val != string_val
    # ensure the __eq__ function does not get called

# Generated at 2022-06-21 00:58:48.927109
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    print('Test PlaybookInclude_load')
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.playbook_executor import PlaybookExecutor

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_loader(loader)
    variable_manager.extra_vars = {'hosts': 'localhost'}
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)

    pc = PlayContext()
    pi = PlaybookInclude()
    ds = AnsibleMapping()
    ds['import_playbook']

# Generated at 2022-06-21 00:58:53.508161
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    x = PlaybookInclude(import_playbook='http://someserver.com/somedir/someplaybook.yml', tags=[u'foo', u'bar'])
    assert x.import_playbook == 'http://someserver.com/somedir/someplaybook.yml'
    assert x.tags == [u'foo', u'bar']

if __name__ == "__main__":
    test_PlaybookInclude()

# Generated at 2022-06-21 00:59:06.509597
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    current_dir = os.getcwd()

    # test for non-collection playbook path, absolute
    playbook_path = os.path.join(current_dir, "test_playbook.yml")
    pb = PlaybookInclude.load(data="include: '{0}'".format(playbook_path), basedir=current_dir)
    assert type(pb) is Playbook

    # test for non-collection playbook path, relative
    playbook_path = "test_playbook.yml"
    pb = PlaybookInclude.load(data="include: '{0}'".format(playbook_path), basedir=current_dir)
    assert type(pb) is Playbook

    # test for collection playbook path,

# Generated at 2022-06-21 00:59:07.986032
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass


# Generated at 2022-06-21 00:59:54.974394
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import_playbook_string = "include.yml"
    variable_manager_mock = MagicMock()
    loader_mock = MagicMock()
    basedir = "."
    ds = MagicMock()
    data = dict(import_playbook=import_playbook_string)
    pbi = PlaybookInclude.load(data, basedir, variable_manager=variable_manager_mock, loader=loader_mock)
    assert_that(pbi, instance_of(Playbook))



# Generated at 2022-06-21 01:00:07.976364
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Test that import_playbook with a single arg is good
    ds = { 'import_playbook': 'test1.yml' }
    expected_ds = {'import_playbook': 'test1.yml'}
    result = PlaybookInclude.preprocess_data(ds)
    assert result == expected_ds, "playbook_include preprocess_data() with a single arg failed"

    # Test that import_playbook with a vars and single arg is good
    ds = { 'import_playbook': 'test1.yml' , 'vars': {'var1': 'value1'}}
    expected_ds = {'import_playbook': 'test1.yml', 'vars': {'var1': 'value1'}}
    result = PlaybookInclude.preprocess_data(ds)


# Generated at 2022-06-21 01:00:08.970101
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pb_include = PlaybookInclude()
    assert isinstance(pb_include, PlaybookInclude)

# Generated at 2022-06-21 01:00:20.209350
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook

    pi = PlaybookInclude()
    ds = dict(
        import_playbook='/path/to/playbook.yml',
        vars=dict(
            myvar1=1,
            myvar2=2
        ),
        tags=['tag1', 'tag2'],
        when=dict(
            test=True
        )
    )
    pbLoad = pi.load(data=ds, basedir='/path/to/')
    assert isinstance(pbLoad, Playbook)
    assert pbLoad._entries[0].vars == dict(
        myvar1=1,
        myvar2=2
    )

# Generated at 2022-06-21 01:00:30.898120
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import sys
    if sys.version_info >= (3,):
        from io import StringIO
    else:
        from io import BytesIO as StringIO
    # Note: we don't use yaml.load here because we need yaml.YAMLObject.__new__ for
    # subclassing to work
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    def cleanup_lines(string):
        lines = ["%s\n" % line if not line.startswith('- ') else line for line in string.split('\n')]
        string = ''.join(lines)
        return string


# Generated at 2022-06-21 01:00:41.882861
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    import shutil
    import tempfile
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    current_dir = os.getcwd()
    temp_dir = tempfile.mkdtemp(prefix='ansible-test-playbookinclude-load')
    os.chdir(temp_dir)

    # Create a playbook
    playbook_str = '''- hosts: localhost
      roles:
         - { role: myrole, x: 42 }
      tasks:
         - name: mytask
           debug:
              msg: "This is a message"
      '''
    playbook_file = open(os.path.join(temp_dir, "test-playbook.yml"), 'w')

# Generated at 2022-06-21 01:00:50.585264
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import pytest
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    ds = AnsibleMapping({"name": "foo", "import_playbook": "bar"})
    ds.ansible_pos = (1, 1)

    pi = PlaybookInclude()
    new_ds = pi.preprocess_data(ds)

    assert isinstance(new_ds, AnsibleBaseYAMLObject)
    assert new_ds[0] == "import_playbook"
    assert new_ds[1] == "bar"
    assert new_ds[2] == "name"
    assert new_ds[3] == "foo"
    assert new_ds.ansible_pos == (1, 1)


# Generated at 2022-06-21 01:01:01.066791
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    import ansible.playbook.play
    import ansible.playbook.task_include
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    class MockPlay(ansible.playbook.play.Play):
        _tasks = []

    class MockTaskInclude(ansible.playbook.task_include.TaskInclude):
        def __init__(self):
            super(MockTaskInclude, self).__init__()
            self._included_path = None

    tmp_file = '/tmp/test_playbook_include.yml'

# Generated at 2022-06-21 01:01:01.867014
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    assert 1 == 1

# Generated at 2022-06-21 01:01:11.125581
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.inventory.manager import InventoryManager

    # Test 1 - import_playbook with string import
    data1 = dict(import_playbook='my_task.yml')
    result1 = PlaybookInclude.load(data1, '', variable_manager=None).get_data()
    assert result1['import_playbook'] == 'my_task.yml'

    # Test 2 - import_playbook with list import
    data2 = dict(import_playbook=['my_task.yml'])
    result2 = PlaybookInclude.load(data2, '', variable_manager=None).get_data()
    assert result2['import_playbook'] == 'my_task.yml'

    # Test 3 - import_playbook with list import and parameters

# Generated at 2022-06-21 01:01:51.770365
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.playbook import Play
    from ansible.playbook.attribute import Attribute
    from ansible.playbook.task import Task
    from ansible.parsing.yaml.objects import AnsibleUnicode
    my_dict = dict(
            playbook = 'tests/ansible_module/test_module_include_playbook.yml',
            vars = dict()
    )
    my_dict_ = dict(
            playbook = 'tests/ansible_module/test_module_include_playbook.yml',
            vars = dict(
                test_var= 'test_var'
            )
    )
    # test __init__
    pb = PlaybookInclude.load(my_dict, 'home')
    # some basic error checking
    # should not be able to create a playbook with none

# Generated at 2022-06-21 01:02:01.796459
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    pb = PlaybookInclude

    # Test valid preprocess_data call
    ds = dict(
        import_playbook=dict(
            playbook_path='file_name',
            vars=dict(
                var1="value1",
                var2=["value2", "value3"],
                var3=dict(
                    var4="value4",
                ),
            ),
            tags='some_tag',
        ),
        tags='some_other_tag',
        when=dict(
            test1='test2',
        ),
    )
    result = pb.preprocess_data(ds)
    assert result['tags'] == ['some_other_tag', 'some_tag']

# Generated at 2022-06-21 01:02:12.981577
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    test_obj = PlaybookInclude()
    test_ds = {'import_playbook': '/tmp/playbook.yml'}
    new_ds = test_obj.preprocess_data(test_ds)
    assert new_ds['import_playbook'] == '/tmp/playbook.yml'
    test_ds = {'import_playbook': '/tmp/playbook.yml', 'vars': {'var1': 'value1', 'var2': 'value2'}}
    new_ds = test_obj.preprocess_data(test_ds)
    assert new_ds['import_playbook'] == '/tmp/playbook.yml'
    assert new_ds['vars'] == {'var1': 'value1', 'var2': 'value2'}

# Generated at 2022-06-21 01:02:24.787868
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    data_struct1 =  {
        'import_playbook': '../library/role/main.yml',
        'vars': {'foo': 'bar'}
    }
    new_ds = PlaybookInclude().preprocess_data(data_struct1)
    assert new_ds == {'import_playbook': '../library/role/main.yml', 'vars': {'foo': 'bar'}}

    data_struct2 =  {
        'import_playbook': '../library/role/main.yml',
        'tags': 'foo'
    }
    new_ds = PlaybookInclude().preprocess_data(data_struct2)
    assert new_ds == {'import_playbook': '../library/role/main.yml', 'tags': 'foo'}

    data_struct

# Generated at 2022-06-21 01:02:32.324981
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    playbook = Playbook()
    play_with_roles = Play().load(dict(name='play_with_roles', roles=[dict(name='role1'), dict(name='role2')]))
    play_with_tasks = Play().load(dict(name='play_with_tasks', tasks=[dict(name='task1'), dict(name='task2')]))
    playbook._entries.append(play_with_roles)
    playbook._entries.append(play_with_tasks)

    basedir = '/path/to/playbook'
    playbook_include = PlaybookInclude()
    ds = dict(import_playbook='test.yaml', tags=['include_test_tag'])
    playbook

# Generated at 2022-06-21 01:02:40.542121
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    data= [{'import_playbook':'test.yaml'}]

    PlaybookInclude.load(data=data, basedir='../test/units/', variable_manager=VariableManager(), loader=DataLoader())
    assert type(PlaybookInclude.load(data=data, basedir='../test/units/', variable_manager=VariableManager(), loader=DataLoader())) == Playbook

# Generated at 2022-06-21 01:02:52.202998
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    class test_PlaybookInclude():
        def __init__(self):
            # the new, cleaned datastructure, which will have legacy
            # items reduced to a standard structure
            self.new_ds = dict()
            self.new_ds['import_playbook'] = 'ROOT'
            self.new_ds['vars'] = dict()
            self.new_ds['when'] = list()
            self.new_ds['tags'] = list()

    class test_AnsibleMapping():
        def __init__(self):
            self.ansible_pos = list()

    class test_ArgSpec():
        def __init__(self):
            self.args = dict()
            self.kwargs = dict()
            # argument "ds"
            self.args['ds'] = None
            # argument "basedir

# Generated at 2022-06-21 01:03:01.239995
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    data = dict(
        import_playbook = "test.yml",
        vars            = dict(
            a = True,
            b = False,
        ),
        other_key       = 'value'
    )
    result = PlaybookInclude._preprocess_data(data)
    assert result == {
        'import_playbook': 'test.yml',
        'vars': {
            'a': True,
            'b': False,
        },
        'other_key': 'value'
    }

# Generated at 2022-06-21 01:03:13.278164
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    '''
    At the moment, having this test here is the only way to have it run in our
    test suite.  It cannot be added to the tests/playbook/test_include_playbook.py
    because that class is not loaded on Travis, resulting in all of those tests
    being skipped.
    '''
    # pylint: disable=too-many-locals

    # import here to avoid a dependency loop
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    # first, we use the original parent method to correctly load the object
    # via the load_data/preprocess_data system we normally use for other
    # playbook objects
    basedir = 'foo'
    variable_manager = None
    loader = None

    # then we use the object to load a Playbook
    pb