

# Generated at 2022-06-21 00:53:20.243285
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # __init__(self, loader=None, variable_manager=None, all_vars=None)
    # method load_data(self, ds, basedir, variable_manager=None, loader=None):
    pass

# Generated at 2022-06-21 00:53:30.310727
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping

    ds = AnsibleMapping()
    ds['import_playbook'] = 'foo.yml'
    new_ds = PlaybookInclude.preprocess_data(ds)
    assert new_ds['import_playbook'] == 'foo.yml'
    assert new_ds['vars'] == {}

    ds['tags'] = 'bar,baz'
    new_ds = PlaybookInclude.preprocess_data(ds)
    assert new_ds['import_playbook'] == 'foo.yml'
    assert new_ds['vars'] == {}
    assert new_ds['tags'] == ['bar', 'baz']

    ds['vars'] = AnsibleMapping()

# Generated at 2022-06-21 00:53:30.849572
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pass

# Generated at 2022-06-21 00:53:33.333031
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook

    playbook_include = PlaybookInclude()
    assert playbook_include.load_data("test-playbook", "/test/test-playbook/path").__class__ == Playbook

# Generated at 2022-06-21 00:53:45.842610
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # check creation of a PlaybookInclude object with empty data
    import_playbook = PlaybookInclude.load({}, '.')
    assert import_playbook._import_playbook == None

    # check creation of a PlaybookInclude object with single string
    import_playbook = PlaybookInclude.load({'import_playbook': 'playbook.yml'}, '.')
    assert import_playbook._import_playbook == 'playbook.yml'
    assert import_playbook._vars == {}

    # check creation of a PlaybookInclude object with single string + vars
    import_playbook = PlaybookInclude.load({'import_playbook': 'playbook.yml', 'vars': {'key': 'value'}}, '.')

# Generated at 2022-06-21 00:53:47.032320
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    '''
    Test method load of class PlaybookInclude.
    '''
    assert 1 == 2

# Generated at 2022-06-21 00:53:57.764859
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude

    playbook_include = PlaybookInclude()
    playbook_include.load_data({'import_playbook':'hello_world.yml'})
    playbook_include.load_data({'_import_playbook':'hello_world.yml'})
    playbook_include.load_data({'_import_playbook':'hello_world.yml', '_included_conditional':'1'})
    playbook_include.load_data({'_import_playbook':'hello_world.yml', '_vars':{'x':'y', 'a':'b'}})

# Generated at 2022-06-21 00:54:03.311508
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    '''
    Unit test for constructor of class PlaybookInclude
    '''
    import_playbook = "../../../files/sample.yml"
    playbook_include = PlaybookInclude(import_playbook=import_playbook)
    assert playbook_include.import_playbook == import_playbook

# Generated at 2022-06-21 00:54:04.778555
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass


# Generated at 2022-06-21 00:54:14.618206
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Play, Playbook

    play1 = Play()
    play1.hosts = ['localhost']
    play1.roles = ['role1', 'role2']
    play1.vars = {
        'b': 3
    }

    playbook = Playbook()
    playbook._entries = [play1]

    result = PlaybookInclude.load(data={
        'import_playbook': 'some-file.yml'
    }, basedir='/path/to', variable_manager=None, loader=None)
    assert type(result) is Playbook



# Generated at 2022-06-21 00:54:28.303679
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    print('Test load of class PlaybookInclude')
    data = {'import_playbook': 'test.yml'}
    basedir = './'
    variable_manager = None
    loader = None
    import ansible.parsing.dataloader
    # Test with a simple data
    ansible_obj = PlaybookInclude.load(data, basedir, variable_manager, loader)

    assert ansible_obj.__class__.__name__ == 'Playbook'


# Generated at 2022-06-21 00:54:33.756743
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # POC
    yaml_ds = {
        '- import_playbook': 'some_playbook.yml'
    }

    # Init
    pb_include_obj = PlaybookInclude()

    # Test
    results = pb_include_obj.load_data(yaml_ds, '.')

    # Assert
    assert results.data == yaml_ds



# Generated at 2022-06-21 00:54:41.405282
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.tasks.include_vars import IncludeVars
    from ansible.playbook.block import Block
    from ansible.playbook.task.include_tasks import IncludeTasks
    from ansible.playbook.handler.include import IncludeHandler
    from ansible.playbook.role import RoleRequirement
    from ansible.parsing.splitter import parse_kv, split_args
    from ansible.utils.collection_loader._collection_finder import _get_collection_name_from_path, _get_collection_playbook_path

    # First we test with a simple case
    playbook_data = {
        "import_playbook": "test.yml"
    }

# Generated at 2022-06-21 00:54:46.583223
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    def get_mock_ds(data):
        return AnsibleMapping(dict(ansible_pos=dict(line=1, column=1), data=data))

    import_playbook = "file1.yml"

    ds = get_mock_ds(dict(import_playbook=import_playbook))
    pi = PlaybookInclude.load(ds, basedir='/home/steve/ansible')
    assert pi.import_playbook == import_playbook

    ds = get_mock_ds(dict(import_playbook=import_playbook + " vars"))
    pi = PlaybookInclude.load(ds, basedir='/home/steve/ansible')
    assert pi.import_playbook == import_playbook + " vars"

    ds = get_mock_

# Generated at 2022-06-21 00:54:59.008050
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play

    # case 0: empty data
    data = {}
    pb_i = PlaybookInclude.load(data=data, basedir='.')
    assert isinstance(pb_i, PlaybookInclude)
    assert pb_i._import_playbook is None
    assert pb_i._vars == {}
    assert pb_i.tags == []

    # case 1: simple data
    data = {'import_playbook': 'my_playbook.yml'}
    pb_i = PlaybookInclude.load(data=data, basedir='.')
    assert isinstance(pb_i, PlaybookInclude)
    assert pb_i._import_playbook == 'my_playbook.yml'

# Generated at 2022-06-21 00:54:59.508744
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-21 00:55:11.126000
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    ds = AnsibleMapping()

    # check import_playbook as top level key
    ds['import_playbook'] = 'test-playbook'
    ds = PlaybookInclude.preprocess_data(ds)
    assert ds['import_playbook'] == 'test-playbook'
    assert ds['import_playbook'] is not None

    # check import_playbook as top level key and tags
    ds = AnsibleMapping()
    ds['import_playbook'] = 'test-playbook tags=test-tags'
    ds = PlaybookInclude.preprocess_data(ds)
    assert ds['import_playbook'] == 'test-playbook'
    assert ds['import_playbook'] is not None
    assert ds['tags'] == 'test-tags'

# Generated at 2022-06-21 00:55:20.484865
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    class MockInclude:
        def __init__(self):
            self.import_playbook = None
            self.tags = None
            self.when = None
            self.vars = None

    def mock_load(data, basedir, variable_manager=None, loader=None):
        return MockInclude()

    # Setup loaded playbook
    class MockPlay:
        def __init__(self):
            self.vars = {'test': '123'}

        def __repr__(self):
            return 'test_var_%s_' % (self.vars['test'])

    class MockPlaybook:
        def __init__(self):
            self.loader = None
            self._entries = []


# Generated at 2022-06-21 00:55:31.714006
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.playbook import Playbook
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()

    pbi = PlaybookInclude.load("import_playbook: test2.yml\n", loader=loader, variable_manager=variable_manager)
    pb = pbi.load_data("import_playbook: test2.yml\n", "", variable_manager=variable_manager, loader=loader)

    assert isinstance(pb, Playbook)
    assert len(pb._entries) == 1
    assert not isinstance(pb._entries[0], PlaybookInclude)

# Generated at 2022-06-21 00:55:41.780508
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # minimal data structure to enable processing of AnsibleMapping
    ds = AnsibleMapping()
    ds.ansible_pos = {}
    ds[to_bytes('playbook', errors='surrogate_or_strict')] = to_bytes('/etc/ansible/other.yml', errors='surrogate_or_strict')
    ds[to_bytes('vars', errors='surrogate_or_strict')] = {to_bytes('some_var', errors='surrogate_or_strict'): to_bytes('some_value', errors='surrogate_or_strict')}

    import_p = PlaybookInclude()
    new_ds = import_p.preprocess_data(ds)

    assert 'import_playbook' in new_ds
    assert 'playbook'

# Generated at 2022-06-21 00:55:51.291455
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.playbook import Playbook

    # Should return an instance of class Playbook
    result = PlaybookInclude.load(
        data=dict(
            import_playbook="playbook_to_import.yml"
        ),
        basedir=".",
        variable_manager=None,
        loader=None
    )
    assert isinstance(result, Playbook)

# Generated at 2022-06-21 00:56:01.819024
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader

    basedir = os.path.dirname(os.path.realpath(__file__))
    yaml_file = os.path.join(basedir, 'PlaybookInclude.yml')
    yaml_file_content = open(yaml_file).read()
    playbook_yaml = yaml_file_content
    variable_manager = None
    loader = DataLoader()
    res = PlaybookInclude.load(playbook_yaml, basedir, variable_manager, loader)
    assert(isinstance(res, Playbook))
    assert(len(res._entries) == 2)

# Generated at 2022-06-21 00:56:12.554777
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # define data structure
    ds = dict()
    ds['import_role'] = './some/role/filename'
    ds['connection'] = 'local'
    ds['vars'] = dict()
    ds['vars']['var1'] = 'first'
    ds['vars']['var2'] = 'second'

    pbi = PlaybookInclude()
    # call method
    new_ds = pbi.preprocess_data(ds)

    # test if results are as expected
    assert new_ds['import_playbook'] == './some/role/filename'
    assert new_ds['connection'] == 'local'
    assert 'vars' in new_ds
    assert new_ds['vars']['var1'] == 'first'

# Generated at 2022-06-21 00:56:18.691908
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # First create an object
    p = PlaybookInclude()
    # Check the import_playbook and vars fields
    assert p.import_playbook is None, "Failed to initialize import_playbook"
    assert p.vars == dict(), "Failed to initialize dict() for vars"
    assert p.tags == [], "Failed to initialize empty list for tags"

# Generated at 2022-06-21 00:56:30.901493
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():

    # In this test case, we just test that the load() and load_data()
    # from PlaybookInclude are working correctly, by using the
    # Playbook() object to verify that the returned object (which is
    # actually a Playbook() object and not a PlaybookInclude()) is
    # properly loaded and has the correct attributes

    # import here to avoid a dependency loop
    from ansible.playbook import Playbook

    # create a valid data structure to work with
    ds = {
        'import_playbook': 'playbook.yaml'
    }

    # create the object, which should return a Playbook() object
    obj = PlaybookInclude.load(ds, '/path/to/playbook')

    # verify the correct class type was returned
    assert isinstance(obj, Playbook)

    # and that the object has

# Generated at 2022-06-21 00:56:36.161854
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    data = {'import_playbook': 'test.yml', 'tags': 'test'}
    basedir = os.path.abspath(os.curdir)
    variable_manager = object()
    loader = object()
    p = PlaybookInclude.load(data, basedir, variable_manager, loader)
    for key, value in iteritems(data):
        assert getattr(p, '_' + key) == value
    assert p.basedir == basedir
    assert p.variable_manager == variable_manager
    assert p.loader == loader


# Generated at 2022-06-21 00:56:44.646283
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.playbook import Playbook

# Generated at 2022-06-21 00:56:54.639772
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    import sys
    import yaml
    from ansible.playbook.play_context import PlayContext

    yaml_str = """
---
- hosts: all
  gather_facts: no

  tasks:
    - include_playbook:
        import_playbook: test.yml
        vars:
            foo: bar
        tags:
            - tag1
            - tag2
"""
    p = PlayContext()
    p._ds = yaml.load(yaml_str)
    p._play = p._ds[0]
    p._play_context = p._play.get_vars(loader=None)

# Generated at 2022-06-21 00:57:03.622874
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # import here to avoid a dependency loop
    from ansible.playbook import Playbook

    data = dict(
            a='a',
            import_playbook='a.yml',
            b='b',
            vars=dict(
                c='c',
                tags='c'),
            tags='a,b',
            d='d')

    include = PlaybookInclude.load(data, basedir='/')

    assert isinstance(include, Playbook)
    assert len(include._entries) == 1
    assert include._entries[0].vars.get('a') == 'a'
    assert include._entries[0].vars.get('b') == 'b'
    assert include._entries[0].vars.get('c') == 'c'
    assert include._entries[0].vars

# Generated at 2022-06-21 00:57:04.524361
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-21 00:57:19.903298
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    '''playbook_include.py:TestPlaybookInclude.test_PlaybookInclude()'''
    pli = PlaybookInclude.load({})
    assert pli.vars == dict(), 'Default attribute value for vars is dict()'


# Generated at 2022-06-21 00:57:26.447261
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pbi = PlaybookInclude()
    pbi._import_playbook = 'mymodule.yml'
    pbi._vars = dict(x=1, y=2)
    pbi.tags.append('TAG')
    pbi.when = [dict(a=1)]

    assert pbi.tags == ['TAG']
    assert pbi.vars == dict(x=1, y=2)
    assert pbi.import_playbook == 'mymodule.yml'
    assert pbi.when == [dict(a=1)]

# Generated at 2022-06-21 00:57:37.352889
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    playbook_string = u"""
    - import_playbook: pb1
      vars:
        var1: foo
      tags:
        - custom_tag
    - import_playbook: pb2
      vars:
        var2: bar
      tags:
        - custom_tag
        - other_tag
    - import_playbook: pb3
    """

    def create_playbook(pb_string, path):
        loader = DataLoader()
        playbook_data = loader.load_from_file(path)
        playbook_data[0] = pb_string
        return Playbook

# Generated at 2022-06-21 00:57:45.947041
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # Successful creation
    PlaybookInclude.load({'playbook': 'test_playbook1.yml'}, "fakepath")

    # Exception if playbook argument is missing
    try:
        PlaybookInclude.load({}, "fakepath")
        raise AssertionError("Failed to raise AnsibleParserError exception if playbook argument is missing")
    except Exception as e:
        if "playbook import parameter is missing" != str(e):
            raise AssertionError("Failed to raise AnsibleParserError exception with expected message")

    # Exception if playbook argument is empty

# Generated at 2022-06-21 00:57:58.293835
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    # Make sure that calling entry_type returns the correct entry type
    assert PlaybookInclude.entry_type == 'include'

    # Create a variable manager and data structure to test
    variable_manager = FakeVariableManager()
    variable_manager._vars = dict(foo='foo', bar='bar')

    temp_vars = dict(foo='foo', bar='bar')

    data = dict(
        import_playbook='play.yaml',
        vars=temp_vars,
        when='foo == "bar"')

    # Create a PlaybookInclude object and load the data
    obj = PlaybookInclude()
    entry = obj.load(data, '', variable_manager=variable_manager)

# Generated at 2022-06-21 00:58:08.040585
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    ## test 'import_playbook' only

# Generated at 2022-06-21 00:58:12.945519
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    import __main__
    __main__.display = Display()
    import_playbook = "test.yml"
    playbook = PlaybookInclude(import_playbook)
    assert playbook.import_playbook == import_playbook

# Generated at 2022-06-21 00:58:17.532320
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pbinclude = PlaybookInclude()
    assert pbinclude._import_playbook is None
    assert pbinclude._vars == {}

# Generated at 2022-06-21 00:58:20.192044
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    myplay = PlaybookInclude.load({'vars': {'foo': 'bar'}, 'import_playbook': '/etc/ansible/foo.yml'})
    assert myplay.vars['foo'] == 'bar'
    assert myplay.import_playbook == '/etc/ansible/foo.yml'


# Generated at 2022-06-21 00:58:28.802408
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.template import Templar

    # Setup
    loader = DictDataLoader({
        'myfile': """
            - hosts: all
              tasks:
                - debug:
                    msg: Hello World
                - debug:
                    msg: Goodbye World
            """,
        'anotherfile': """
            - hosts: all
              tasks:
                - debug:
                    msg: Hello World
                - debug:
                    msg: Goodbye World
            """
    })
    mock_variable_manager = MagicMock()
    mock_variable_manager.get_vars.return_value = {}

    data = 'myfile.yml'
    templar = Templar(loader=loader, variables={})
    new_data = templar.template(data)



# Generated at 2022-06-21 00:58:59.041373
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    import ansible.constants as C


# Generated at 2022-06-21 00:59:08.449176
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    data = 'include_tasks: a.yaml'
    ds = PlaybookInclude.load(data, '.', None, None)
    assert ds._import_playbook == 'a.yaml'
    assert ds._vars == {}

    data = 'include_tasks: a.yaml tags=test'
    ds = PlaybookInclude.load(data, '.', None, None)
    assert ds._import_playbook == 'a.yaml'
    assert ds._vars == {}
    assert ds._tags == ['test']

    data = 'include_tasks: a.yaml vars="a=b"'
    ds = PlaybookInclude.load(data, '.', None, None)
    assert ds._import_playbook == 'a.yaml'


# Generated at 2022-06-21 00:59:15.478174
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    mypb = PlaybookInclude()
    assert isinstance(mypb, PlaybookInclude)
    assert isinstance(mypb, Conditional)
    assert isinstance(mypb, Taggable)
    assert isinstance(mypb, Base)
    assert mypb._import_playbook is None
    assert mypb.vars == {}


# Generated at 2022-06-21 00:59:27.280807
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode

    # test data to be tested
    data = AnsibleMapping({
        'include_playbook': AnsibleUnicode('../foo/bar.yml'),
        'vars': {
            'one': 1,
            'two': 2
        },
        'tags': ['tag1', 'tag2'],
        'some/other/param': AnsibleUnicode('some other value'),
        'test_sequence': AnsibleSequence([1, 2, 3, 4])
    })

    # expected results

# Generated at 2022-06-21 00:59:34.751009
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Load a valid playbook array with 2 entries
    # [{'task_file': 'file1'}, {'task_file': 'file2'}]
    # Make sure the first entry is valid and contains the correct data
    # Make sure the second entry is valid and contains the correct data
    pass
# end of test_PlaybookInclude_load_data


# Generated at 2022-06-21 00:59:41.652846
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager.get_vars())

    data = {
        u'import_playbook': u'play.yml',
        u'vars': {
            u'var1': u'foo',
            u'var2': u'bar',
        },
        u'when': u'baz == "foo"',
        u'tags': [u'tag1', u'tag2'],
    }

   

# Generated at 2022-06-21 00:59:49.998447
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    class MyLoader(object):

        def __init__(self):
            self.path_exists = True

        def path_exists(self, path):
            return self.path_exists

    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task_include import TaskInclude

    ###############################
    # setup test cases
    play = Play()
    block = Block()
    task = Task()
    handler = Handler()
    role = RoleInclude()
    task_include = TaskInclude()


# Generated at 2022-06-21 01:00:00.545649
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook

    basedir = 'some/path'
    file_name = 'subdir1/subdir2/test.yml'

    # returns a Playbook object as per the following logic
    # 1. setup basedir and file_name
    # 2. do preprocessing
    # 3. create and return a Playbook
    # 4. copy tags and vars from current PlaybookInclude attribute to each entry in the returned Playbook
    # 5. if the returned Playbook is a Play, add conditional and update conditional in each task block

    # case 1: conditional include
    data = {'include_tasks': 'subdir1/subdir2/test.yml', 'when': 'True'}

    pbInclude = PlaybookInclude()
    p

# Generated at 2022-06-21 01:00:07.977381
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    import json
    import yaml
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = yaml.SafeLoader
    variable_manager.set_inventory(InventoryManager(loader=loader, sources=[]))

    data = {
        'import_playbook': 'site.yml',
        'vars': {
            'foo': 'bar',
        }
    }
    obj = PlaybookInclude.load(data, '/etc/ansible')

    assert isinstance(obj, PlaybookInclude)
    assert isinstance(obj.vars, dict)
    assert obj.vars.get('foo', None) == 'bar'
    assert obj.import_playbook == 'site.yml'


# Generated at 2022-06-21 01:00:13.022343
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook import PlaybookIO
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block

    class MockTemplar(object):
        def __init__(self, loader=None, variables=None):
            self.loader = loader
            self.vars = variables

        def template(self, value):
            return str(value)

    class MockPlaybookInclude(PlaybookInclude):
        def __init__(self):
            pass

    pb = MockPlaybookInclude()

    # test playbook import with a relative path
    playbook = 'test.yml'
    basedir = './testdir'
    playbook_name = os.path.join(basedir, playbook)
    playbook_path = os

# Generated at 2022-06-21 01:00:54.493105
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # Test with valid data
    ds = AnsibleMapping()
    ds['import_playbook'] = 'file_name'

    playbook_include = PlaybookInclude().load_data(ds=ds, basedir='')

    assert isinstance(playbook_include, PlaybookInclude)

# Generated at 2022-06-21 01:01:02.919346
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    from ansible.utils.collection_loader import AnsibleCollectionLoader
    collection_loader = AnsibleCollectionLoader()
    mock_ds = AnsibleMapping({
        u'my_playbook': u'roles/foo/tasks/main.yml',
        u'vars': {
            u'newhost': u'jupiter'
        }
    })

    mock_pb = PlaybookInclude.load(mock_ds, 'roles/foo/tasks', collection_loader=collection_loader)

    assert 'import_playbook' in mock_pb
    assert 'vars' in mock_pb

    assert mock_pb.import_playbook == 'roles/foo/tasks/main.yml'
    assert mock_pb.vars['newhost'] == 'jupiter'

# Generated at 2022-06-21 01:01:11.343933
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.connection_info import ConnectionInfo

    example_yaml = """
    - import_playbook: playbook_example.yaml
      vars:
        var1: foo
        var2:
          - nested1
          - nested2
      tags:
        - tag1
        - tag2
    """
    loader = DictDataLoader({
        'playbook_example.yaml': """
        - hosts: localhost
          tasks:
             - import_playbook:
                 import_playbook: playbook_include_example.yaml
                 vars:
                    var1: bar
                    var2:
                      - nested3
                      - nested4
    """
    })


# Generated at 2022-06-21 01:01:22.502575
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():

    # Will create a fake playbook
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    class FakePlay(object):
        pass

    fake_play = FakePlay()
    fake_play.vars = {}
    fake_play.tags = []
    fake_play._included_path = None

    # Fake the number of time we browse the dir
    class FakeList(object):

        def __init__(self):
            self.n = 0

        def __iter__(self):
            for _ in range(self.n):
                yield 'test'

        def pop(self):
            self.n = self.n + 1

    class FakeOs(object):

        def __init__(self):
            self.fake_list = FakeList()


# Generated at 2022-06-21 01:01:25.023703
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pb = PlaybookInclude()
    assert pb is not None

# Generated at 2022-06-21 01:01:33.357433
# Unit test for method load of class PlaybookInclude

# Generated at 2022-06-21 01:01:44.582869
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():

    display.verbosity = 4

    # test to make sure it raises on bad data
    try:
        PlaybookInclude.load(None, None)
        assert False, "this should never happen, an error should be raised"
    except:
        assert True

    data = dict(
        import_playbook = "foo",
    )

    data2 = dict(
        import_playbook = "foo",
        when = "false",
    )

    # Test for 'import_playbook' attribute set properly
    pb = PlaybookInclude.load(data, None)
    assert pb.import_playbook == "foo"

    # Test for 'when' attribute set properly
    pb = PlaybookInclude.load(data2, None)
    assert pb.when == "false"

# Generated at 2022-06-21 01:01:45.959858
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    raise NotImplementedError


# Generated at 2022-06-21 01:01:47.357684
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pi = PlaybookInclude()
    assert pi.vars == {}

# Generated at 2022-06-21 01:01:49.226505
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    """ this needs better testing """
    pass