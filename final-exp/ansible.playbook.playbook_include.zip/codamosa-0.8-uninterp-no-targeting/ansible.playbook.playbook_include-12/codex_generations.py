

# Generated at 2022-06-21 00:53:18.599524
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pb_include = PlaybookInclude()
    print(pb_include._import_playbook)
    assert pb_include._import_playbook is None
    assert pb_include._vars == dict() 
    print(pb_include._vars)

if __name__ == '__main__':
    test_PlaybookInclude()

# Generated at 2022-06-21 00:53:24.270895
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    display.deprecated = lambda msg, ver: None
    basedir = os.path.dirname(__file__) + os.sep + os.pardir + os.sep + os.pardir + os.sep + os.pardir
    ds = {'import_playbook': 'roles/common/tasks/main.yml'}
    pb = PlaybookInclude.load(ds, basedir)
    assert pb is not None

# Generated at 2022-06-21 00:53:25.135323
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass


# Generated at 2022-06-21 00:53:31.268487
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.playbook.play import Play

    # Create a PlaybookInclude object
    data = {'import_playbook': 'play.yml'}
    include = PlaybookInclude.load(data, variable_manager=None, loader=None)

    # Test __srepr__ method of PlaybookInclude
    text_repr = include.__repr__()
    assert 'PlaybookInclude(import_playbook=u\'play.yml\')' == text_repr

# Generated at 2022-06-21 00:53:41.725773
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    data = {'import_playbook': '../tasks_from_file/simple_playbook.yml'}

    playbook_include = PlaybookInclude.load(data, basedir='/tmp', variable_manager=variable_manager, loader=loader)

    assert playbook_include.entries[0]._entries[0].name == 'hello'

# Generated at 2022-06-21 00:53:44.868414
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    pb_incl = PlaybookInclude()
    assert pb_incl.import_playbook == ''
    assert pb_incl.vars == {}

# Generated at 2022-06-21 00:53:49.258772
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    playbook_include = PlaybookInclude()
    assert playbook_include.import_playbook == None
    assert playbook_include.vars == {}
    assert playbook_include.tags == []
    assert playbook_include.when == []



# Generated at 2022-06-21 00:53:59.210863
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    ## ds = dict
    ## new_ds = AnsibleMapping
    ## k = string
    ## v = string
    import os
    import copy
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.playbook import Playbook

    from ansible.vars.manager import VariableManager

    list_keys = [
        'vars',
        'become', 'become_user', 'become_method', 'become_flags',
        'tags',
        'when', 'gather_facts',
        'environment',
        'roles', 'tasks', 'handlers',
    ]


# Generated at 2022-06-21 00:54:11.894971
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.module_utils.common.collections import ImmutableDict

    #asserting that the class PlaybookInclude.load() has been invoked in the class PlaybookInclude.__init__()
    def setup_method(self):
        self._hosts_patterns = None
        self._initial_variable_manager = None
        self._variable_manager = None
        self._inventory = None
        self._loader = None
        self._tqm = None

    #asserting that the class PlaybookInclude.load() has been invoked in the class PlaybookInclude.__init__()
    def load(self, variable_manager=None, loader=None):
        self

# Generated at 2022-06-21 00:54:22.155009
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    """
    Test load of class PlaybookInclude
    """

    playbook = dict(
        import_playbook='test.yml',
        when='a = 1',
        name='Play1',
        tags=['tag1', 'tag2'],
        include_tasks='test2.yml',
        vars=dict(
            var1='var1',
            var2=2,
            var3='var3',
            var4=4
        )
    )

    pb = PlaybookInclude.load(
        data=playbook,
        basedir='/tmp',
        variable_manager=None,
        loader=None
    )

    assert pb.import_playbook == 'test.yml'
    assert pb.when == ['a = 1']

# Generated at 2022-06-21 00:54:45.865425
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    import_playbook = 'file1.yml'
    vars = {'var1': 'abc'}
    pb_i = PlaybookInclude(import_playbook=import_playbook, vars=vars)
    assert pb_i.import_playbook == import_playbook
    assert pb_i.vars == vars


# Generated at 2022-06-21 00:54:51.405207
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import os

    # Load test case
    test_file = os.path.join(os.path.dirname(__file__), 'PlaybookInclude_test_1.yml')
    ds = AnsibleBaseYAMLObject.load_yaml_file(filename=test_file)

    # Instantiate object
    playbook_include = PlaybookInclude()
    pb_import = playbook_include.preprocess_data(ds)

    assert pb_import['vars'] == {'x': 1, 'y': 2, 'z': 3}



# Generated at 2022-06-21 00:55:03.910172
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import pytest

    from ansible.playbook.play import Play

    def _create_playbook_conditional_item(tagged):
        ds = {'import_playbook': '../test/integration/targets/include_playbook_test.yml'}
        if tagged:
            ds.update({'tags': ['include_tag']})
        playbook_include_item = PlaybookInclude.load(ds, '', None, None)
        return playbook_include_item

    test_obj = _create_playbook_conditional_item(False)
    loader = None
    ds = {'import_playbook': '../test/integration/targets/include_playbook_test.yml'}
    basedir = '.'


# Generated at 2022-06-21 00:55:13.658699
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.plugins import module_finder

    # AnsibleCollectionConfig.default_collection = None

    # create PlaybookInclude object and load a Playbook
    pbi = PlaybookInclude()

    # create Playbook object
    pb = Playbook()

    # loading the Playbook object
    f = open("test/unit/test_playbook_include.yml", 'r')
    c = f.read()
    #print(c)
    f.close()

    # use "data" key and set "import_playbook" key to "test_playbook.yml"
    data = {
        'import_playbook': 'test_playbook.yml',
    }

    # call method load_data
   

# Generated at 2022-06-21 00:55:21.126395
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.collection_loader._collection_finder import _get_collection_name_from_path

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources= [])
    coll_finder = AnsibleCollectionConfig()
    # fake collection path, will not be used
    coll_finder.collection_paths = ['/fake/collection/path1', '/fake/collection/path2']


# Generated at 2022-06-21 00:55:26.503979
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os
    import sys
    import tempfile
    import shutil

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    sys.path.append("tests/support/dummy_collections")

    class MockFile:
        def __init__(self, name):
            self.mname = name

        def __repr__(self):
            return self.name

        @property
        def name(self):
            return self.mname

    # demo playbook
    yaml_pb = """
    - import_playbook: my_playbook
      tags:
        - my_playbook_tag
    """

    # demo playbook file

# Generated at 2022-06-21 00:55:27.977627
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    p = PlaybookInclude()
    assert p is not None

# Generated at 2022-06-21 00:55:40.700453
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    # Test that playbook compilation fails when import_playbook
    # statement doesn't specify a file name.
    from ansible.parsing.yaml.dumper import AnsibleDumper
    ds = { 'import_playbook': None }
    try:
        # The following will fail. It is just to get the error message.
        PlaybookInclude.load(ds, basedir='.')
    except AnsibleParserError as e:
        if e.message != 'playbook import parameter is missing':
            raise

    # Test that playbook compilation fails when import_playbook
    # statement specifies a non-string file name.
    ds = { 'import_playbook': [] }

# Generated at 2022-06-21 00:55:49.932933
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    playbook_included = PlaybookInclude()
    playbook_included.vars = {'a':'b'}

    entries = [Play(),Play()]
    playbook = Playbook(entries=entries)
    playbook_included.load_data(ds={'import_playbook': 'test.yml'}, basedir='0.0', variable_manager=None)
    assert playbook_included.when is None

# Generated at 2022-06-21 00:55:51.344052
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass


# Generated at 2022-06-21 00:56:10.957024
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    yaml_data = u'  - name: play1\n    hosts: all\n    tasks:\n      - debug: msg="foo"\n'
    fake_loader = DataLoader()
    fake_playbook = '/tmp/fakeplaybook'
    fake_loader.set_basedir(os.path.dirname(fake_playbook))
    with open(fake_playbook, 'w') as fake_playbook_fd:
        fake_playbook_fd.write(yaml_data)
    fake_variable_manager = VariableManager()

# Generated at 2022-06-21 00:56:21.799531
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    yaml_data = '''
- hosts: all
  import_playbook: a.yml
  vars:
    foo: bar
    baz: '{{ somevar }}'
  tags:
    - include-yaml-dictionary
    - include-yaml-dictionary-and-condition
  when: "'include-yaml-dictionary' in tags or 'include-yaml-dictionary-and-condition' in tags"
'''
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    yaml_obj = AnsibleLoader(yaml_data, loader=loader).get_single_data()

    from ansible.playbook.play import Play


# Generated at 2022-06-21 00:56:32.707868
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    def constructor(import_playbook=None, vars=None, tags=None, when=None):
        return PlaybookInclude(import_playbook=import_playbook, vars=vars, tags=tags, when=when)

    # Test with valid case
    pbi = constructor(import_playbook='playbook.yml', vars={u'var1': u'val1', u'var2': u'val2'}, tags=['tag1', 'tag2'],
                      when=[dict(test1='blah', test2='blah')])
    assert pbi is not None

    # Test when variable types are incorrect
    try:
        pbi = constructor(import_playbook=None, vars=None, tags='blah', when={})
        assert False
    except Exception:
        assert True

    #

# Generated at 2022-06-21 00:56:42.653404
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    # Create playbook include
    playbook_include = PlaybookInclude(
        import_playbook="playbook.yml",
        vars={
            "foo":  "bar"
        }
    )
    playbook_include.post_validate(dict(), [])

    # Create variable manager
    variable_manager = VariableManager()

    # Load Data
    playbook_include.load_data(
        ds=playbook_include._attributes,
        basedir=os.getcwd(),
        variable_manager=variable_manager,
        loader=DataLoader(),
    )


# Make sure the PlaybookInclude is loadable
PlaybookInclude.register_loader()


# Generated at 2022-06-21 00:56:53.497887
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    #test for loading playbook including
    playbook_include = PlaybookInclude.load({'include': 'include_test.yml'}, '/usr/local/ansible/')
    assert playbook_include.import_playbook == 'include_test.yml'
    assert playbook_include.tags == []
    assert playbook_include.vars == {}

    #test for loading playbook including with parameters
    playbook_include = PlaybookInclude.load({'include': 'include_test.yml tags=tag1'}, '/usr/local/ansible/')
    assert playbook_include.import_playbook == 'include_test.yml'
    assert playbook_include.tags == ['tag1']
    assert playbook_include.vars == {}

    #test for loading playbook including with vars

# Generated at 2022-06-21 00:57:02.219183
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager

    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(var1='test')
    templar = Templar(loader=loader, variables=variable_manager.get_vars())


# Generated at 2022-06-21 00:57:08.552980
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pb = PlaybookInclude.load(
        dict(
            include="role.yaml",
            when=dict(
                test=1,
            ),
        ),
        basedir=".",
    )
    assert isinstance(pb, PlaybookInclude)


# Generated at 2022-06-21 00:57:09.410354
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-21 00:57:13.004380
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pbi = PlaybookInclude()

    assert isinstance(pbi.vars, dict)


# Generated at 2022-06-21 00:57:25.717544
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import ansible.constants as C
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    from ansible.template import Templar

    def get_preprocess_data(ds):
        plb = PlaybookInclude()
        return plb.preprocess_data(ds)

    # Not a dict
    assert_raises(AnsibleAssertionError, get_preprocess_data, 'aaa')

    # Invalid usage for vars:
    #   * Not a dict
    #   * Mixture with k=v
    #   * Already have a 'vars' key

    ds_vars = AnsibleMapping()
    ds_vars['vars'] = 'aaa'

# Generated at 2022-06-21 00:57:41.768815
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    ds = {
        'import_playbook': '/path/to/file.yml',
        'vars': {'var1': 'val1', 'var2': 'val2'},
    }
    p = PlaybookInclude.load(ds=ds, basedir='/tmp/', variable_manager=None, loader=None)
    assert p is not None


# Generated at 2022-06-21 00:57:54.637897
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Test case which covers the module AnsibleParserError
    playbook = {
        'import_playbook': 'foo.yml',
        'tags': 'tag1'
    }
    with pytest.raises(AnsibleParserError):
        PlaybookInclude.load(data=playbook, basedir='/tmp/ansible_test/')

    # Test case which covers the module display.deprecated
    playbook = {
        'import_playbook': 'foo.yml tags=tag1'
    }
    assert PlaybookInclude.load(data=playbook, basedir='/tmp/ansible_test').import_playbook == 'foo.yml'

    # Test case which covers the module AnsibleParserError

# Generated at 2022-06-21 00:58:03.122701
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    playbook_include = PlaybookInclude(
        import_playbook='value_of_import_playbook',
        vars={'key_of_vars': 'value_of_vars'},
        tags=[],
        when=[]
    )
    assert playbook_include.import_playbook == 'value_of_import_playbook'
    assert playbook_include.vars == {'key_of_vars': 'value_of_vars'}


# Generated at 2022-06-21 00:58:16.044598
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    ds = dict(
        import_playbook='playbook_one.yml',
        vars=dict(
            var1=1,
            var2=2,
            kwonly=dict(
                kwvar='kwvalue',
            ),
        ),
    )

    class MockLoader(DataLoader):
        def __init__(self, *args, **kwargs):
            pass


# Generated at 2022-06-21 00:58:27.464935
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import sys
    sys.path.append('/home/avocad/ansible')
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    variable_manager = VariableManager()
    loader = DataLoader()
    yaml_data = '''
    - import_playbook: "/home/avocad/ansible/lib/ansible/galaxy/collections/ansible/community/general/tasks/main.yml"       vars:
        ansible_user: "avocad"
        ansible_ssh_pass: "abc123"
        ansible_sudo_pass: "abc123"
      tags:
        - install_vim
    '''

    import_playbook = Play

# Generated at 2022-06-21 00:58:39.772731
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    '''
    Unit test for method preprocess_data of class PlaybookInclude
    '''

    # Create playbook including data
    data_dict = { 'import_playbook': 'imported_pb.yml' }
    include_data = AnsibleMapping(data_dict)

    # Create playbook including object
    pbi = PlaybookInclude()

    # Preprocess data with playbook including object
    processed_data = pbi.preprocess_data(include_data)

    # Check if original playbook including data is processed correctly
    assert(processed_data['import_playbook'] == 'imported_pb.yml')
    assert(processed_data['vars'] == {})

    # Create playbook including data with more tags

# Generated at 2022-06-21 00:58:48.660482
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    # When no vars are provided, we should get an empty dict for them
    ds = dict(
        import_playbook='subdir/sub_import.yml',
    )
    pb_include = PlaybookInclude.load(ds, None)
    assert pb_include.vars == {}

    # same with vars=
    ds = dict(
        import_playbook='subdir/sub_import.yml',
        vars=dict(),
    )
    pb_include = PlaybookInclude.load(ds, None)
    assert pb_include.vars == {}

    # when vars that are in the legacy format are provided, they should be converted
    # and added to the vars dict.

# Generated at 2022-06-21 00:58:57.866307
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # prepare test environment
    PlaybookInclude.load = Base.__load
    PlaybookInclude.preprocess_data = Base.__preprocess_data

    # declare testing data
    data = {
        'import_playbook': 'test_playbook'
    }

    # perform test
    test_obj = PlaybookInclude()
    result = test_obj.load_data(data, '/')

    # assert test results
    assert result == 'test_playbook', "test_PlaybookInclude_load_data: load_data returned %s instead of %s" % (result, 'test_playbook')


# Generated at 2022-06-21 00:59:07.548381
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # Create a PlaybookInclude object
    playbook_include_obj = PlaybookInclude()
    # Create a playbook to be imported
    ds = {'hosts': 'localhost', 'tasks': [{'debug': {'msg': 'hello world'}}]}
    # Create a Playbook object
    pb = Playbook()
    # Load the playbook
    pb._process_playbook_data(ds)
    # Create a playbook include
    playbook_include_ds = {'import_playbook': pb}
    # Load the playbook include using the method load
    playbook_include_obj.load_data(playbook_include_ds)
    # Assert that the playbook is imported
    assert playbook_include_obj.import_playbook == pb

# Generated at 2022-06-21 00:59:09.332600
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    PlaybookInclude.load([], None)

# Generated at 2022-06-21 00:59:18.947435
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-21 00:59:28.834019
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import ansible.playbook.include as pb_include

    # the input dataset
    ds = dict(
        import_playbook='/some/import_playbook/file.yml',
        vars=dict(
            foo='one',
            bar='two'
        )
    )

    # the expected result
    ds_expected = AnsibleMapping(
        import_playbook='/some/import_playbook/file.yml',
        vars=dict(
            foo='one',
            bar='two'
        )
    )

    # process the input dataset
    res = pb_include.PlaybookInclude.preprocess_data(ds)

    # verify the results match expectations
    assert isinstance(ds_expected, AnsibleMapping)
    assert isinstance(res, AnsibleMapping)

# Generated at 2022-06-21 00:59:39.936084
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.playbook.play import Play

    yaml_data = """
---
- import_playbook: test_playbook_include_playbook.yaml
  when: test_hosts is defined
  vars:
      my_var1: value1
  tags:
      - my_tag1
      - my_tag2
"""
    import_data = yaml.load(yaml_data)

    playbook = PlaybookInclude.load(import_data, os.path.dirname(__file__), None, loader=None)
    assert len(playbook._entries) == 1
    play = playbook._entries[0]
    assert play._file_name == 'test_playbook_include_playbook.yaml'
    assert play.vars.get('my_var1') == 'value1'

# Generated at 2022-06-21 00:59:49.060716
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    import os
    import tempfile

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # Create temp directory
    tmpdir = tempfile.mkdtemp()

    # Create temp playbook
    playbook_path = os.path.join(tmpdir, "playbook.yml")
    with open(playbook_path, "w") as f:
        f.write("- hosts: localhost\n  tasks:\n  - debug: msg=\"{{ ansible_facts[\"os_family\"] }}\"\n")

    # Create temp playbook for include
    playbook_to_include_path = os.path.join(tmpdir, "playbook_to_include.yml")

# Generated at 2022-06-21 00:59:58.338435
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    my_pb = PlaybookInclude()
    my_pb.load({'import_playbook': 'example', 'vars': {'foo': 'bar'}})
    assert my_pb.import_playbook == 'example'
    # assert my_pb.tags == [ 'all' ]
    assert my_pb.vars == {'foo': 'bar'}
    my_pb = PlaybookInclude()
    my_pb.load({'import_playbook': 'example', 'foo': 'bar'})
    assert my_pb.import_playbook == 'example'
    assert my_pb.vars == {}

# Generated at 2022-06-21 01:00:07.977216
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    #Create the playbookInclude object
    playbookInclude = PlaybookInclude()

    #Create the playbookLoader object
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()

    #Create the variableManager object
    from ansible.vars.manager import VariableManager
    variableManager = VariableManager()

    # Create the MOCK_DS 
    MOCK_DS= '''- name: include vars file in play
  include_vars: "{{ item }}"
  with_first_found:
    - "{{ my_dir }}/vars1.yml"
    - "{{ my_dir }}/vars2.yml"
  loop_control:
    loop_var: item
'''
    basedir = '/etc/ansible/'
    result = playbookInclude.load

# Generated at 2022-06-21 01:00:19.847234
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    import sys
    import os
    import unittest
    from ansible.parsing.splitter import split_args, parse_kv

    # find the location of this file for the unit tests
    mydir = os.path.dirname(sys.modules[__name__].__file__)

    # this is a string
    myargs = "some_file.yml"
    results = split_args(myargs)
    assert results == ["some_file.yml"], results

    # this is a quoted string
    myargs = "\"some file.yml\""
    results = split_args(myargs)
    assert results == ["some file.yml"], results

    # this is a quoted string with an escaped quote in the string

# Generated at 2022-06-21 01:00:27.073066
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    class TestPlaybookInclude(PlaybookInclude):
        def __init__(self):
            self._import_playbook = ""
            self._vars = dict()

    pi = TestPlaybookInclude()
    ds = dict(
        import_playbook="test_import_playbook.yml",
        vars=dict(
            key1="value1",
            key2="value2",
            key3="value3"
        ),
        tags=["tag1", "tag2"],
        when="some_condition"
    )
    pi.load_data(ds=ds, basedir="/path/to/basedir/")
    assert pi._import_playbook == "test_import_playbook.yml"

# Generated at 2022-06-21 01:00:39.135701
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    '''
    Unit test for method preprocess_data of class PlaybookInclude
    '''
    import os
    import json
    import tempfile
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import ansible.constants as C
    C.DEFAULT_INVENTORY = '/dev/null'
    C.DEFAULT_MODULE_PATH = os.path.join(os.path.dirname(__file__), '../../../lib/ansible/modules/')

    # Test that preprocess_data fails with a dict that does not have the key k in C._ACTION_IMPORT_PLAYBOOK
    ds = {'foo': 'foo'}
    pbi = PlaybookInclude()

# Generated at 2022-06-21 01:00:49.358921
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    PlaybookInclude.load({'import_playbook': 'site.yml'})
    PlaybookInclude.load({'import_playbook': 'site.yml', 'tags': 'tag1,tag2'})
    PlaybookInclude.load({'import_playbook': 'site.yml', 'vars': {'key': 'value'}})
    PlaybookInclude.load({'import_playbook': 'site.yml', 'tags': 'tag1,tag2', 'vars': {'key': 'value'}})
    PlaybookInclude.load({'import_playbook': 'site.yml', 'vars': {'tags': 'tag1,tag2', 'vars': {'key': 'value'}}})

    # Raise error
    raised = False

# Generated at 2022-06-21 01:01:12.101533
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    from ansible.vars import VariableManager

    p = PlaybookInclude()
    pc = Playbook.load(
        '''
        - hosts: localhost
          vars:
            test_var: value
          tasks:
            - copy:
                content: "{{ test_var }}"
                dest: "/tmp/test_var"
        ''',
        variable_manager=VariableManager(),
    )
    assert len(pc._entries) == 1
    pb = p.load(
        {
            'import_playbook': 'test.yml'
        },
        basedir='/tmp',
        variable_manager=VariableManager()
    )
    assert isinstance(pb, Playbook)
    assert len(pb._entries) == 1


# Generated at 2022-06-21 01:01:14.253448
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass


# Generated at 2022-06-21 01:01:18.582342
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    p = PlaybookInclude()
    assert p.import_playbook is None
    assert p.vars == dict()
    assert hasattr(p, '_import_playbook')
    assert hasattr(p, '_vars')

# Generated at 2022-06-21 01:01:30.872871
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    pi = PlaybookInclude.load({'import_playbook': 'playbook-name.yml'})
    assert pi.import_playbook == 'playbook-name.yml'
    assert pi.vars == dict()

    pi2 = PlaybookInclude.load({'import_playbook': 'playbook-name.yml', 'vars': {'var1': 'value1', 'var2': 'value2'}})
    assert pi2.import_playbook == 'playbook-name.yml'
    assert pi2.vars == {'var1': 'value1', 'var2': 'value2'}

    pi3 = PlaybookInclude.load({'import_playbook': 'playbook-name.yml var1=value1 var2=value2'})
    assert pi3.import_play

# Generated at 2022-06-21 01:01:35.857595
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    #create test object
    pb = PlaybookInclude()
    data, basedir = {}, '.'
    #assert
    assert(pb.load_data(ds = data, basedir = basedir) is not None)

# Generated at 2022-06-21 01:01:45.594743
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.module_utils.six import StringIO
    from ansible.playbook.play_context import PlayContext

    ds = None
    new_ds = None

    # case1: no ds, expect AnsibleParserError
    try:
        PlaybookInclude.preprocess_data(ds)
    except AnsibleParserError as e:
        assert "ds (None) should be a dict but was a <class 'NoneType'>" in str(e)

    # case2: ds is not a dict, expect AnsibleParserError
    ds = [
        {'hosts': 'localhost'}
    ]

# Generated at 2022-06-21 01:01:52.349267
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    good_data=[
      {'import_playbook': 'foo.yml'},# No tags or vars
      {'import_playbook': 'foo.yml', 'tags': 'bar'},
      {'import_playbook': 'foo.yml', 'vars': {'foo': 'bar'}},
    ]
    bad_data=[
      {'import_playbook': 'foo.yml', 'vars': 'bar'},
      {'import_playbook': 'foo.yml', 'tags': 'bar', 'vars': {'foo': 'bar'}},
    ]
    for d in good_data:
        try:
            PlaybookInclude.load(d, '/tmp')
            assert True
        except:
            assert False

# Generated at 2022-06-21 01:02:00.439819
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible import context
    from ansible.context import CLIContext
    # set up context for unit tests
    context._init_global_context(CLIContext())
    playbookInclude = PlaybookInclude()
    # test the way that playbook_import used to work
    playbookInclude.load_data({'playbook_import': 'bar.yml'}, variable_manager=None, loader=None)
    assert playbookInclude.import_playbook == 'bar.yml'
    assert playbookInclude.vars == {}
    assert playbookInclude.tags == []

    playbookInclude.load_data({'import_playbook': 'bar.yml'}, variable_manager=None, loader=None)
    assert playbookInclude.import_playbook == 'bar.yml'

# Generated at 2022-06-21 01:02:05.247182
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    '''
    This test verifies that the load() static method of class PlaybookInclude
    processes the playbook data structure and returns an instance of the
    Playbook class.
    '''

    pass

# Generated at 2022-06-21 01:02:14.103319
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Fails import_playbook parsing due to invalid playbook name
    data = dict(import_playbook=123,
                pre_tasks=[
                    dict(setup=dict()),
                    dict(include_tasks=dict(file='playbooks/main.yml'))
                ])
    try:
        PlaybookInclude.preprocess_data(data)
        assert False
    except AnsibleParserError:
        pass

    # Fails import_playbook parsing due to vars not being a dict
    data = dict(import_playbook='playbook.yml',
                vars=123,
                pre_tasks=[
                    dict(include_tasks=dict(file='playbooks/main.yml'))
                ])