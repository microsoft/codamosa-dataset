

# Generated at 2022-06-21 00:53:23.434717
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Test for valid preprocess_data with import_playbook
    test_data = PlaybookInclude.load({'import_playbook': '/a/file.yml', 'vars': {'a': 1}}, '/a/b')
    assert isinstance(test_data, PlaybookInclude)
    assert test_data.import_playbook == '/a/file.yml'
    assert test_data.vars == {'a': 1}


# Generated at 2022-06-21 00:53:32.586153
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.playbook.play import Play

    def make_dict(filename=None, parameter=None):
        ds = AnsibleMapping()
        ds[C._ACTION_IMPORT_PLAYBOOK] = filename
        if parameter:
            ds.update(parameter)
        return ds

    # PlaybookInclude creates different types of next object according to
    # the filename. If the filename is a playbook path, this object creates
    # a play object. If the filename is a directory, this object creates
    # a Playbook object.
    #
    # The tests below ensure that the PlaybookInclude class works properly
    # except the file validation such as existence of the file or whether
    # file is a playbook or not. The file existence and file type checks
    # are tested in test_playbook.test_load_playbook()

# Generated at 2022-06-21 00:53:35.900973
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    playbook_include = PlaybookInclude.load(data={'include': 'sub.yml'})
    assert playbook_include.import_playbook == 'sub.yml'

# Generated at 2022-06-21 00:53:48.245131
# Unit test for constructor of class PlaybookInclude

# Generated at 2022-06-21 00:53:48.903340
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-21 00:53:59.001962
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.yaml.data import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.vars.manager import VariableManager

    # FIXME: we should not use a relative path here,
    # this is very likely to fail on other systems
    simple_playbook = """
    - import_playbook: 'test_playbook_include.yml'
    """
    data = DataLoader().load(simple_playbook)
    assert data == [
        {'import_playbook': u'test_playbook_include.yml', 'vars': {} }
    ]


# Generated at 2022-06-21 00:54:11.858721
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    PlaybookInclude.vars = FieldAttribute(isa='dict', default=dict)

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])
    play_source = dict(
            name="Ansible Play",
            hosts='localhost',
            gather_facts='no',
            tasks=[
                dict(action=dict(module='debug', args=dict(msg='{{a_var}} {{b_var}}')))
            ]
        )

    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-21 00:54:22.124890
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # Test load
    import os
    import sys
    import json
    import tempfile
    import shutil
    import ansible.constants as C

    from ansible.errors import AnsibleParserError
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars import VariableManager

    # We need to create a temporary folder to hold the collections
    # and fake collection structure
    temp_col_path = tempfile.mkdtemp()

# Generated at 2022-06-21 00:54:23.471295
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-21 00:54:33.488308
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader

    class MockVariableManager(object):
        def __init__(self):
            self._fact_cache = {}
            self._vars_cache = {}

    class MockLoader(object):
        def __init__(self):
            self._basedir = '/tmp/'
            self._data_parser = AnsibleLoader

    loader = MockLoader()
    ds = '''
    - include_playbook:
        import_playbook: playbook.yml
        tags:
            - always
    '''

    new_ds = PlaybookInclude.load(ds, basedir='/tmp/', loader=loader, variable_manager=MockVariableManager())


    assert new_ds._ent

# Generated at 2022-06-21 00:54:45.305586
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_obj = PlaybookInclude()
    playbook_include_obj.vars = {'var': 'var value'}
    playbook_include_obj.when = 'when statement'
    playbook_include_obj.tags = 'tag1,tag2'
    playbook_include_obj.register = 'register'
    playbook_include_obj.delegate_to = 'delegate_to'
    playbook_include_obj.run_once = 'run_once'
    playbook_include_obj.ignore_errors = 'ignore_errors'
    playbook_include_obj.first_available_file = 'first_available_file'
    playbook_include_obj.locale_lang = 'locale_lang'
    playbook_include_obj.transport = 'transport'
    playbook_include_obj.connection = 'connection'
   

# Generated at 2022-06-21 00:54:54.151820
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader


# Generated at 2022-06-21 00:55:01.978331
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    class FakeTemplar:
        def template(self, data):
            return 'collection1.namespace1.test'

    class FakeVariableManager:
        def __init__(self):
            self.data = dict()

        def get_vars(self):
            return self.data

    class FakeLoader:
        def __init__(self, result):
            self.result = result

        def load_from_file(self, file_name):
            return self.result

    # case 1: path is valid and is an collection playbook
    input_data = "collection1.namespace1.test"
    root_data = dict()
    root_data['import_playbook'] = input_data

    root_ds = AnsibleM

# Generated at 2022-06-21 00:55:04.111913
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # TODO: Re-use code of unit test for class Playbook
    pass


# Generated at 2022-06-21 00:55:13.780232
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import datetime
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleVaultEncryptedBytes
    from ansible.plugins.loader import role_resolver
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task

    # create some plain text objects
    plain_text_object_1 = 'Hello World'
    plain_text_object_2 = 'This is a test'
    plain_text_object_3 = 'This is a test of byte type'

    # create some byte objects
    byte_object_1 = b'Hello World'
    byte_object_2 = b'This is a test of byte type'

    #

# Generated at 2022-06-21 00:55:20.763881
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    data = {}
    data['import_playbook'] = './test/test.yml'
    data['tags'] = 'tag1,tag2'
    data['vars'] = {'var1': 'value1', 'var2': 'value2'}
    data['when'] = 'var2 == value2'
    obj = PlaybookInclude()
    obj.load_data(data)
    assert obj._import_playbook == './test/test.yml'
    assert obj.tags == ['tag1', 'tag2']
    assert obj.vars == {'var1': 'value1', 'var2': 'value2'}
    assert obj.when == [{'var2': 'value2'}]


# Generated at 2022-06-21 00:55:26.107532
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager

    pb = PlaybookInclude.load(dict(import_playbook='playbook.yml', tags=['tag1']), '.')

    assert isinstance(pb, Playbook)
    assert isinstance(pb._entries[0], Play)
    assert isinstance(pb._entries[0].pre_tasks[0], TaskInclude)
    assert isinstance(pb._entries[0].pre_tasks[0].task, Block)

# Generated at 2022-06-21 00:55:29.695401
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    import_playbook = "common.yml"
    playbook_include = PlaybookInclude(import_playbook)
    playbook_include.vars["templates_dir"] = "./templates"
    print (vars(playbook_include))

if __name__ == "__main__":
    test_PlaybookInclude()

# Generated at 2022-06-21 00:55:38.935732
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pbi = PlaybookInclude.load(dict({"import_playbook": "sub.yml"}), ".")
    assert pbi.import_playbook == "sub.yml"
    assert pbi.vars == dict()

    pbi = PlaybookInclude.load(dict({"import_playbook": "sub.yml tags=foo,bar"}), ".")
    assert pbi.import_playbook == "sub.yml"
    assert pbi.vars == dict({"tags": "foo,bar"})

# Generated at 2022-06-21 00:55:52.035509
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook

    p = Playbook.load('test/playbook.yml', 'test/')
    assert len(p._entries) == 5

    assert p._entries[0].name == 'first'
    assert p._entries[0].import_playbook == 'test/playbook2.yml'
    assert p._entries[0].vars['a'] == 'foo'

    assert p._entries[1].name == 'second'
    assert p._entries[1].import_playbook == 'test/playbook2.yml'
    assert p._entries[1].vars['a'] == 'bar'

    assert p._entries[2].name == 'third'

# Generated at 2022-06-21 00:56:05.446235
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # Unit test for constructor of class PlaybookInclude
    # Test for instantiation with a string
    play_include = PlaybookInclude.load({'include_playbook': '../some_play.yaml', 'vars': {'some_var': 'some_value'}})
    assert play_include
    assert play_include.import_playbook == '../some_play.yaml'
    assert not play_include.tags
    assert play_include.vars['some_var'] == 'some_value'

    # Test for instantiation with a string and a tags list
    play_include = PlaybookInclude.load({'include_playbook': '../some_play.yaml some_var=some_value tags=tag1,tag2',
                                         'vars': {'some_var': 'some_value'}})

# Generated at 2022-06-21 00:56:06.268916
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    playbook_include = PlaybookInclude()
    assert playbook_include is not None

# Generated at 2022-06-21 00:56:18.605031
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader

    p = PlaybookInclude.load(
        dict(
            import_playbook = 'relative/path/to/playbook.yml',
            when            = 'foo',
            tags            = ['tag1', 'tag2'],
            vars            = dict(
                foo = 'bar'
            ),
            other           = 'field',
        ),
        basedir = '/example',
        variable_manager = PlayContext().variable_manager,
        loader = DataLoader(),
    )

    assert p.import_playbook == 'relative/path/to/playbook.yml'
    assert p.when == 'foo'
    assert p.tags == ['tag1', 'tag2']

# Generated at 2022-06-21 00:56:30.867431
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    def _make_ds_obj(*args, **kwargs):
        '''
        make a data object for the constructor test
        '''
        ds = dict(*args, **kwargs)
        ds = AnsibleMapping(data=ds)
        ds.ansible_pos = (0,0)
        return ds

    def _get_ds_values(ds, *args):
        '''
        return the value of a key in a data structure
        '''
        if len(args) > 1:
            return _get_ds_values(ds[args[0]], *args[1:])
        else:
            return ds[args[0]]

    # no args
    yield (None, AnsibleParserError)

    # empty dict
    yield (_make_ds_obj(), AnsibleParserError)



# Generated at 2022-06-21 00:56:41.937928
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Imports needed for unittest
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook

    # Create a PlaybookInclude
    playbook_include = PlaybookInclude()

    # Create a dict with all supported options
    ds = dict(
        when        = 'foo',
        import_playbook = 'bar',
        vars        = dict(
            foo = 'bar',
            baz = 'foo',
        ),
        tags        = ['tag1', 'tag2', 'tag3'],
    )

    # Call the preprocess_data method of the playbook_include object

# Generated at 2022-06-21 00:56:43.438709
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    raise NotImplementedError


# Generated at 2022-06-21 00:56:54.080967
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.utils.collection_loader._collection_finder import _get_collection_playbook_path
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook import Playbook

    #Test a base case
    test_string = "some_file.yaml"
    test_base = Base()
    test_yaml = AnsibleBaseYAMLObject(test_string, test_base.ansible_pos)
    test_ds = {"import_playbook" : test_yaml}

# Generated at 2022-06-21 00:57:00.355790
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Set up objects
    include = PlaybookInclude()

    # Create data
    ds = AnsibleMapping()
    ds['import_playbook'] = 'my_playbook.yml'

    # Validate preprocessing
    new_ds = include.preprocess_data(ds)
    assert isinstance(new_ds, AnsibleMapping)
    assert new_ds.ansible_pos == ds.ansible_pos

# Generated at 2022-06-21 00:57:13.745367
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Create the object to be tested
    playbook_include = PlaybookInclude()
    # Create a mapping of data structure
    data_structure = AnsibleMapping()
    # Set the first key and value of the mapping
    data_structure['first'] = 'first'
    # Set the key import_playbook and its value
    data_structure['import_playbook'] = 'second: second'
    # Create another mapping to be used as value for the key vars
    var_structure = AnsibleMapping()
    # Create the key and value for the vars' mapping
    var_structure['var_key'] = 'var_value'
    # Set the vars key with the new mapping
    data_structure['vars'] = var_structure
    # Call the method preprocess_data of class PlaybookInclude


# Generated at 2022-06-21 00:57:22.573735
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    # Test with import_playbook statement
    playbook_include_1 = PlaybookInclude.load(dict(
        import_playbook='playbook.yml',
    ), basedir='/some/dir')

    assert playbook_include_1.import_playbook == 'playbook.yml'

    # Test with import_playbook and vars
    playbook_include_2 = PlaybookInclude.load(dict(
        import_playbook='playbook.yml',
        vars=dict(
            param1='value1',
            param2='value2',
        ),
    ), basedir='/some/dir')

    assert playbook_include_2.import_playbook == 'playbook.yml'

# Generated at 2022-06-21 00:57:38.714774
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # set up initial data structure
    ds = dict(
        import_role = 'foo.yml'
    )
    # instantiate the object
    pin = PlaybookInclude()

    # test missing file
    ds = dict(
        import_role = None
    )
    try:
        new_ds = pin.preprocess_data(ds)
        assert False
    except AnsibleParserError:
        pass
    except:
        assert False

    # test non-string file
    ds = dict(
        import_role = dict(foo=1, bar=2)
    )
    try:
        new_ds = pin.preprocess_data(ds)
        assert False
    except AnsibleParserError:
        pass
    except:
        assert False

    # test normal operation

# Generated at 2022-06-21 00:57:46.896878
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader

    ds = AnsibleLoader(None, None).load_from_file('test/units/parsing/data/action_plugin/import_playbook.yml')
    ds = list(ds)[0]
    ds = ds.get_original_data()

    playbook_include = PlaybookInclude.load(ds, 'basedir', variable_manager=None, loader=None)
    assert playbook_include.import_playbook == 'playbook1.yml'
    assert playbook_include.tags == ['tag2']

    vars = playbook_include.vars
    assert vars == {'var1': 'value1'}


# for backwards compatibility, the PlaybookObject subclasses should be
# imported here for others to reference

# Generated at 2022-06-21 00:57:59.997611
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # Check for special case of empty ds
    pb = PlaybookInclude.load(None, None, None)
    assert pb.import_playbook == ''
    assert pb.vars == {}
    assert pb.tags == []
    assert pb.when == []

    # Check for case when passed in ds is not a dict
    try:
        pb = PlaybookInclude.load('test', None, None)
        assert False
    except AnsibleAssertionError as e:
        assert str(e) == 'ds (test) should be a dict but was a <class \'str\'>'

    # Check for basic case with just import_playbook
    pb = PlaybookInclude.load({'import_playbook': 'foo.yml'}, None, None)
    assert pb.import_play

# Generated at 2022-06-21 00:58:03.810456
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    '''
    This is for smoke test for the constructor of class PlaybookInclude
    '''
    playbook_include = PlaybookInclude()
    assert playbook_include is not None
    playbook_include.load_data({}, '/')

# Generated at 2022-06-21 00:58:10.178780
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pl = PlaybookInclude()
    pl.import_playbook = "testplay.yaml"
    assert pl.import_playbook == "testplay.yaml"
    assert pl.vars == {}
    assert not pl.tags
    assert not pl.when

# Generated at 2022-06-21 00:58:18.874530
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.conditional import Conditional

    # valid
    ds = {"include": "somefile.yml", "tags": "tag1,tag2"}
    data = PlaybookInclude.load(ds, None)
    new_ds = data.preprocess_data(ds)
    assert new_ds["import_playbook"] == "somefile.yml"
    assert new_ds["vars"]["tags"] == "tag1,tag2"

    # invalid
    ds = "include"
    try:
        data = PlaybookInclude.load(ds, None)
        new_ds = data.preprocess_data(ds)
        assert False
    except AnsibleAssertionError as e:
        assert "should be a dict but was a" in str(e)

    # test for invalid

# Generated at 2022-06-21 00:58:20.854749
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    #TODO: implement test
    pass


# Generated at 2022-06-21 00:58:28.967673
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    """
    Test PlaybookInclude load method.

    The test imports a simple playbook, which includes another playbook.
    The test checks that the two playbooks were imported successfully.

    The test checks that a playbook with a broken include causes an error.

    The test checks that an include without giving a playbook name causes an error.

    :return: None
    """

    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    # Test a playbook that does include another playbook
    playbookPath = 'lib/ansible/playbook/tests/data/include_playbook/include_playbook.yml'
    playbookPath = loader.path_dwim(playbookPath)

# Generated at 2022-06-21 00:58:40.333824
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os

    # Import here to avoid a dependency loop
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    playbook_include = PlaybookInclude()
    basedir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

    assert isinstance(playbook_include.load_data(dict(import_playbook="../../examples/playbooks/ansible-playbook.yml"), basedir), Playbook)

    # Passing invalid parameter to load_data.
    # Being an invalid parameter, it should raise an exception

# Generated at 2022-06-21 00:58:49.050855
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.group import Group
    from ansible.playbook.hosts import Hosts
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    from ansible.template import Templar

    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.loader import AnsibleLoader

    from ansible.utils import context_objects as co

    # Create a custom DataLoader object to handle two things:
    # 1) make sure that when we call the PlaybookInclude.load_data method,
    #    the basedir is set to the directory of the main playbook
    # 2) make sure that the loader class used is the AnsibleLoader class
   

# Generated at 2022-06-21 00:59:06.692752
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.helpers import load_list_of_tasks

    # set up the test data
    data = dict(
        import_playbook='foo.yml',
        connection='local',
        hosts='1.2.3.4,5.6.7.8'
    )

    # set up the test environment
    basedir = os.getcwd()
    variable_manager = None
    loader = None

    # instantiate the class with the test data and test environment
    pbi = PlaybookInclude.load(data, basedir, variable_manager, loader)

    # execute the method under test

# Generated at 2022-06-21 00:59:08.068984
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    """test load of class PlaybookInclude"""
    pass

# Generated at 2022-06-21 00:59:17.768670
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    p = PlaybookInclude()
    ds = {'import_playbook': 'playbook1.yml', 'tags': 'tag1, tag2'}
    pb = p.load_data(ds=ds, basedir='/home/user/ansible/playbooks')
    assert isinstance(pb, Playbook)
    assert pb._entries[0].tags == ['tag1', 'tag2']


# Generated at 2022-06-21 00:59:26.166317
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    obj = PlaybookInclude()
    assert obj._import_playbook is None
    assert obj._vars == {}
    assert obj.vars == {}
    obj = PlaybookInclude(import_playbook='test.yml', vars="{'test': 1}")
    assert obj._import_playbook == 'test.yml'
    assert obj.import_playbook == 'test.yml'

# Generated at 2022-06-21 00:59:27.608705
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    playbookinclude = PlaybookInclude()
    assert playbookinclude

# Generated at 2022-06-21 00:59:39.512383
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    display.verbosity = 3

    import ansible.playbook
    import ansible.playbook.play
    import ansible.playbook.tasks

    def create_playbook_object():
        return ansible.playbook.PlaybookInclude.load(dict(import_playbook='basic.yml'), '/path/to/playbooks')

    def create_playbook_object_with_parameters():
        return ansible.playbook.PlaybookInclude.load(dict(import_playbook='basic.yml name=value'), '/path/to/playbooks')

    def create_playbook_object_with_vars():
        return ansible.playbook.PlaybookInclude.load(dict(import_playbook='basic.yml', vars=dict(name='value')), '/path/to/playbooks')

   

# Generated at 2022-06-21 00:59:48.576411
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    PlaybookInclude_object = PlaybookInclude()
    # Test 1
    ds = {'import_playbook': './test1.yml'}
    ds_expected = {'import_playbook': './test1.yml'}
    ds_result = PlaybookInclude_object.preprocess_data(ds)
    assert ds_result == ds_expected
    # Test 2
    ds = {'import_playbook': './test1.yml', 'vars': {'a': 1, 'b': 2}}
    ds_expected = {'import_playbook': './test1.yml', 'vars': {'a': 1, 'b': 2}}
    ds_result = PlaybookInclude_object.preprocess_data(ds)
    assert ds_

# Generated at 2022-06-21 00:59:59.959842
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    """ Unit test for class PlaybookInclude.preprocess_data """
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude

    # init var
    _vars = dict(key1='value1',
                 key2='value2',
                 key3='value3')
    _when = ['when1', 'when2', 'when3']
    _tags = ['tag1', 'tag2', 'tag3']

    # init ds
    ds = dict(include='filename.yml',
              vars=_vars,
              tags=_tags,
              when=_when)

    # init new_ds

# Generated at 2022-06-21 01:00:06.958826
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    import yaml

    filename = "test_PlaybookInclude_preprocess_data.yml"
    ds = "import_playbook: test_PlaybookInclude_preprocess_data.yml"
    ds = yaml.safe_load(ds)
    assert ds == {u'import_playbook': u'test_PlaybookInclude_preprocess_data.yml'}

    ds = "import_playbook: test_PlaybookInclude_preprocess_data.yml vars: {a: b}"
    ds = yaml.safe_load(ds)

# Generated at 2022-06-21 01:00:19.449363
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-21 01:00:29.117041
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault.vault import VaultSecret

    playbook_include_ds = AnsibleLoader(None, vault_secrets=[VaultSecret(password='test')]).load('''
    - import_playbook: test_playbook.yml
    ''')
    playbook_include = PlaybookInclude()
    playbook_include.preprocess_data(playbook_include_ds[0])

    assert playbook_include.import_playbook == 'test_playbook.yml'
    assert playbook_include.name == 'import_playbook'



# Generated at 2022-06-21 01:00:39.330710
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    #playbook_data = """---
    #    - import_playbook: test.yml
    #"""
    #
    #playbook_data = {"import_playbook": "test.yml"}
    #pb = Playbook.load(playbook_data, variable_manager=variable_manager, loader=loader)
    #assert pb is not None
    #assert isinstance(pb, Playbook)
    #assert isinstance(pb._entries[0], Play)

    playbook_data = """---
        - include: test.yml
    """

    pb = Playbook.load(playbook_data, variable_manager=variable_manager, loader=loader)
    assert pb is not None

# Generated at 2022-06-21 01:00:49.528883
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    pbi = 'include_playbook'
    ds = {pbi: 'playbook.yml'}
    obj = PlaybookInclude.load(ds, variable_manager=variable_manager, loader=loader)
    assert obj.import_playbook == 'playbook.yml'

    ds = {pbi: 'playbook.yml vars: var=value'}
    obj = PlaybookInclude.load(ds, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-21 01:00:57.570012
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.playbook import Playbook

    # create a playbook load
    playbook_include = PlaybookInclude()

    # create a ds with a 'collection'
    ds = dict(import_playbook='import_playbook_file')

    # create a playbook basedir
    basedir = './'

    result = playbook_include.load(data=ds, basedir=basedir)

    assert isinstance(result, Playbook)
    assert result._entries != []

# Generated at 2022-06-21 01:01:09.566709
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    import json

    p = PlaybookInclude.load(data={'import_playbook': './test.yml'}, basedir='/home/ansible/')
    assert p._entries[0].tasks[0].action == 'shell'
    assert len(p.get_tasks()) == 1

    p = PlaybookInclude.load(data={'import_playbook': './test.yml', 'tags': 'tag1'}, basedir='/home/ansible/')
    assert p._entries[0].tags == ['tag1']
    assert len(p.get_tasks(tags='tag1')) == 1


# Generated at 2022-06-21 01:01:20.363694
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Test Case: Case when input is empty
    dummy1 = dict({})
    dummy2 = PlaybookInclude().load_data(ds=dummy1, basedir='/dummy/basedir')
    assert dummy2 == []
    # Test Case: Case when input contains data
    dummy1 = dict({'import_playbook': 'playbook'})
    dummy2 = PlaybookInclude().load_data(ds=dummy1, basedir='/dummy/basedir')
    assert dummy2.get_entries()[0]._included_path == '/dummy/basedir'



# Generated at 2022-06-21 01:01:24.453909
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # Create class
    playbookInclude = PlaybookInclude()
    # Execute load, check results
    assert playbookInclude.load(None, None) == playbookInclude

# Generated at 2022-06-21 01:01:33.082428
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.template import Templar

    dl = DataLoader()
    all_vars = dict(foo='bar')
    templar = Templar(loader=dl, variables=all_vars)

    obj = AnsibleMapping()
    obj['import_playbook'] = 'tests/core/playbook_include.yml'
    obj['vars'] = dict(foo='baz')

    pb = PlaybookInclude.load(obj, basedir='.', variable_manager=None, loader=dl)

    assert obj['import_playbook'] == pb._entries[0]._included_path
    assert len(pb._entries) == 1

# Generated at 2022-06-21 01:01:37.177985
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
   playbook_include = PlaybookInclude()
   playbook_include.load({'import_playbook': 'abc.yml', 'vars': {'a': 'b'}})
   return playbook_include.import_playbook == 'abc.yml' and playbook_include.vars == {'a': 'b'}

# Generated at 2022-06-21 01:01:45.100023
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Setup
    ds = AnsibleMapping({
        'import_playbook': '../../common/apache.yml',
        'tags': 'apache',
        'vars': {'eins': 'zwei', 'drei': 'vier'}
    })

    # Test
    ds2 = PlaybookInclude(loader=None, variable_manager=None).preprocess_data(ds)

    # Assertions
    assert ds2 == {
        'import_playbook': '../../common/apache.yml',
        'tags': 'apache',
        'vars': {'eins': 'zwei', 'drei': 'vier'}
    }

# Generated at 2022-06-21 01:02:01.420058
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Play

    # test empty playbooks, should return a list of plays with zero entries
    empty = PlaybookInclude.load(None, None)
    assert len(empty.get_plays()) == 0

    # try a basic import of a file which has a single play
    basic = PlaybookInclude.load(dict(
        import_playbook="ansible-examples/playbooks/trivial-playbook.yml"
    ),
    os.path.join(C.DEFAULT_MODULE_PATH, "core"),
    )
    assert len(basic.get_plays()) == 1

    # the loaded play should have a task list of the same length as the
    # tasks in the included play
    play = basic.get_plays()[0]

# Generated at 2022-06-21 01:02:02.313220
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass # TODO

# Generated at 2022-06-21 01:02:05.651290
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pb = PlaybookInclude()
    assert pb.__class__.__name__ == 'PlaybookInclude'
    pass

# Generated at 2022-06-21 01:02:14.182957
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    '''
    This function is used to test the constructor of the PlaybookInclude class
    '''

    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    play_book_include = PlaybookInclude()

    playbook_include_dict = {}
    playbook_include_dict['_import_playbook'] = 'test_playbook_path'

    playbook = Playbook()
    playbook._entries = [Play()]
    playbook._entries[0]._included_path = 'play'

    playbook_include_obj = PlaybookInclude().load_data(ds=playbook_include_dict, basedir='.',variable_manager=None, loader=None)

# Generated at 2022-06-21 01:02:25.215194
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import sys
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    loader = DataLoader()
    context = PlayContext()
    inventory = InventoryManager(loader, variable_manager, host_list=[])

    # Test case with no vars specified
    data = dict(
        import_playbook='foo/bar.yml',
        hosts=['localhost'],
        become='yes',
        become_user='root',
    )
    playbook_include = PlaybookInclude.load(data, 'foo', variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-21 01:02:32.471722
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play

    pbi = PlaybookInclude()
    pbi.import_playbook = "test.yml"
    pbi.vars = {"a": 1, "b": 2}

    basedir = './test/'
    pb = pbi.load_data(pbi, basedir=basedir)
    assert(isinstance(pb, PlaybookInclude))

    for entry in pb._entries:
        assert(isinstance(entry, Play))
        assert(entry.vars is not None)
        assert(entry._included_path is not None)
        assert(entry._included_path == basedir)
        assert(len(entry.tags) == 0)
        assert(len(entry.tasks) == 1)

# Generated at 2022-06-21 01:02:42.066489
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    test_inventory = "host_one"

    # Multi-Level dictionary to place in vars
    exported_vars = {
        "a": {
            "b": {
                "c": "TEST"
            }
        }
    }

    # Collection Name to use as test data
    collection_name = "test_collection"

    # Playbook Include to test
    play_inc = PlaybookInclude(loader = [])

    # Playbook to test with
    test_play = Play(name = "test",
                     hosts = test_inventory)

# Generated at 2022-06-21 01:02:52.670478
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    from ansible.utils.collection_loader import AnsibleCollectionConfig as ACC
    from ansible.parsing.yaml.loader import AnsibleLoader
    import yaml
    # pass a test yaml file and yaml object
    config_obj = ACC.load_config_file()
    config_obj.set_collection_playbook_paths([os.path.join(os.path.dirname(os.path.realpath(__file__)), 'collections/')])
    # load and reference the test yaml file we want to test
    loader = AnsibleLoader(yaml.safe_load(open(os.path.join(os.path.dirname(os.path.realpath(__file__)), 'test_playbook_include.yml'))))
    ds = loader.get_single_data()

    # preprocess

# Generated at 2022-06-21 01:03:03.558889
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    ds = dict(import_playbook='/home/ansible/cat.yml')
    assert PlaybookInclude.load(ds, '/home/ansible/').import_playbook == '/home/ansible/cat.yml'

    # no playbook import statement should result in an exception
    try:
        ds = dict()
        PlaybookInclude.load(ds, '/home/ansible/')
        raise Exception('should not have gotten here')
    except AnsibleParserError as e:
        pass

    # playbook import parameters must be separated by commas