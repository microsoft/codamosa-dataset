

# Generated at 2022-06-21 00:53:28.918680
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.module_utils._text import to_bytes
    from ansible.playbook.play import Play

    from units.mock.loader import DictDataLoader

    loader = DictDataLoader({
        'pf1.yml': """
        - hosts: localhost
          tasks:
          - debug: var=f1_var1
        """,
        'pf2.yml': """
        - hosts: localhost
          tasks:
          - debug: var=f2_var1
          - debug: var=f2_var2
        """
    })

    # load tests
    # first use case: normal playbook
    data = b"""
        - hosts: localhost
          tasks:
          - debug: var=test_var
        """
    from ansible.parsing.dataloader import Data

# Generated at 2022-06-21 00:53:36.826433
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # Test 1
    # Description:
    # Testes with a correctly formated import_playbook line
    # Expected result:
    # The correct data is returned.
    ds = {
        'import_playbook' : 'my_playbook.yml'
    }

    pbi = PlaybookInclude()
    result = pbi.preprocess_data(ds)
    assert result == ds
    assert result.ansible_pos is ds.ansible_pos

    # Test 2
    # Description:
    # Testes with an incorrectly formated import_playbook line, adding a variable
    # Expected result:
    # The correct data is returned.

# Generated at 2022-06-21 00:53:48.776730
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task_include import TASK_INCLUDE_ARG_SPEC
    from ansible.playbook.role_include import ROLE_INCLUDE_ARG_SPEC

    import_playbook = 'import_playbook.yml'
    args = dict(import_playbook=import_playbook)
    p = PlaybookInclude(**args)
    pb = p.load(basedir='/basedir', variable_manager={}, loader={})

    assert isinstance(pb, Playbook)

    assert pb.vars == {}
    assert len(pb.entries) == 1

    entry = pb.entries[0]

# Generated at 2022-06-21 00:53:58.907817
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():

    import ansible.playbook.block
    import ansible.playbook.play
    import ansible.playbook.task
    from ansible.module_utils.common.collections import ImmutableDict


# Generated at 2022-06-21 00:54:01.142315
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    raise NotImplementedError('Test not implemented.')


# Generated at 2022-06-21 00:54:13.976384
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    main = dict(
        hosts='all',
        gather_facts='no',
        vars=dict(
            foo='bar'
        ),
        tasks=[
            dict(
                name='test task',
                ping="pong"
            )
        ]
    )

    playbook_include = dict(
        import_playbook='test.yml',
        when="inventory_hostname.endswith('example.com')"
    )

    p = PlaybookInclude.load(playbook_include, variable_manager=None, loader=None)
    assert p.import_playbook == "test.yml"
    assert p.when == "inventory_hostname.endswith('example.com')"


# Generated at 2022-06-21 00:54:14.368229
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
  return

# Generated at 2022-06-21 00:54:23.154135
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    test_path = os.path.dirname(os.path.realpath(__file__))
    test_data_path = os.path.join(test_path, 'playbook_include_data')
    test_playbook = os.path.join(test_data_path, 'playbook.yml')
    with open(test_playbook, 'r') as f:
        import_playbook_data = f.read()
    playbook_include = PlaybookInclude.load(ds=import_playbook_data, basedir='/ansible/dir')
    expected = '''PlaybookInclude:
  file: ansible_dir/imported.yml
  vars:
    var1: 1'''
    assert playbook_include.preprocess_data(import_playbook_data) == expected

# Generated at 2022-06-21 00:54:33.157669
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    p = PlaybookInclude()
    assert p.load is not None, "PlaybookInclude load() method not present"
    assert p.load_data is not None, "PlaybookInclude load_data() method not present"

    test_ds = dict()
    test_ds["import_playbook"] = "./playbook.yml"
    here = os.path.dirname(os.path.realpath(__file__))
    expected_playbook = Playbook()
    expected_playbook._entries.append(Play().load(dict(hosts='localhost', tasks=[dict(action=dict(module='debug', args=dict(msg='Hello World')))]), variable_manager=None, loader=None))
    expected_play

# Generated at 2022-06-21 00:54:46.772231
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    """
    This is a test unit for the preprocess_data method of class
    PlaybookInclude. This test covers the following:

      - Test parsing import_playbook items with invalid types
      - Test parsing import_playbook file paths with no arguments
      - Test parsing import_playbook file paths with arguments
      - Test parsing import_playbook file paths with arguments and a vars dictionary

    :return:
    """
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader


# Generated at 2022-06-21 00:55:06.106922
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    import_playbook_constructor_args = {
        "import_playbook": 'Inventory.yml'
    }
    import_playbook_constructor = PlaybookInclude(**import_playbook_constructor_args)

    assert import_playbook_constructor._import_playbook == "Inventory.yml"
    assert import_playbook_constructor.import_playbook == "Inventory.yml"
    assert import_playbook_constructor._vars == {}
    assert import_playbook_constructor.vars == {}

# Generated at 2022-06-21 00:55:14.758170
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Test with valid data
    testval = dict(
        import_playbook = 'relative/path/to/playbook.yaml',
        vars = dict(
            foo = 'bar',
        ),
        tags = ['test'],
        when = 'foo',
    )
    test = PlaybookInclude(testval)
    test.post_validate(test._ds, [])
    test.preprocess_data(test._ds)
    test.finalize_data(test._ds)
    playbook_include = test.load_data(test._ds, basedir='/absolute/path/to/playbooks/')
    assert playbook_include.is_subset(test)
    assert playbook_include.import_playbook == '/absolute/path/to/playbooks/relative/path/to/playbook.yaml'

# Generated at 2022-06-21 00:55:21.902106
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    import_data1 = """
        - import_playbook: ../../../linux/one.yml
        - import_playbook: ../../../linux/two.yml
    """
    import_data2 = """
        - import_playbook: ../../../linux/one.yml
          vars:
            - k01: v01
            - k02: v02
        - import_playbook: ../../../linux/two.yml
    """

# Generated at 2022-06-21 00:55:22.864114
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-21 00:55:33.688683
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import shlex
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.six import string_types
    from ansible.module_utils.common.collections import is_sequence


# Generated at 2022-06-21 00:55:34.262379
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-21 00:55:43.850575
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import_playbook_1 = dict(
        import_playbook="playbook_1.yml",
        vars=dict(
            foo="bar"
        )
    )

    import_playbook_2 = dict(
        # parameters are deprecated
        import_playbook="playbook_2.yml foo=bar",
        vars=dict(
            foo="bar"
        )
    )

    import_playbook_3 = dict(
        # parameters are deprecated
        import_playbook="playbook_3.yml foo=bar tags=blah",
        vars=dict(
            foo="bar"
        )
    )


# Generated at 2022-06-21 00:55:46.888493
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # When we have a new PlaybookInclude object then it should be empty
    import_playbook = PlaybookInclude()
    assert import_playbook.import_playbook == None
    assert import_playbook.tags == []
    assert import_playbook.vars == {}

# Generated at 2022-06-21 00:55:47.725772
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-21 00:55:54.356653
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    from ansible.parsing.yaml.loader import AnsibleLoader

    PLAYBOOK_INCLUDE_YAML = '''
- import_playbook: playbook_include.yml
  vars:
    key1: value1
    key3: value3'''

    loader = AnsibleLoader(PLAYBOOK_INCLUDE_YAML, file_name = '<string>')
    playbook_include = loader.get_single_data()

    assert playbook_include[0]['import_playbook'] == 'playbook_include.yml'
    assert playbook_include[0]['vars']['key1'] == 'value1'
    assert playbook_include[0]['vars']['key3'] == 'value3'

# Generated at 2022-06-21 00:56:08.138081
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    yaml_data = '''
    - import_playbook: child.yml
      tags:
        - tag1
        - tag2
    '''
    PlaybookInclude.load(yaml_data, '', '', '')

# Generated at 2022-06-21 00:56:18.823639
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.dataloader import DataLoader

    # the datastructure we're testing
    ds = {
        "import_playbook": "foo.yml",
        "tags": "bar,baz,bat"
    }

    # now load it and see if we get what we expect
    pbi = PlaybookInclude(loader=DataLoader())
    new_ds = pbi.preprocess_data(ds)
    assert len(new_ds) == 2
    assert type(new_ds) == AnsibleMapping
    assert 'import_playbook' in new_ds
    assert 'tags' in new_ds

# Generated at 2022-06-21 00:56:30.962526
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    loader = DataLoader()
    variable_manager = PlayContext()

    ds = AnsibleMapping()
    ds['import_playbook'] = './some.yml'
    ds['vars'] = dict(a=1, b=2)
    ds['tags'] = 'tag1,tag2,tag3'

    pi = PlaybookInclude.load(ds, variable_manager=variable_manager, loader=loader)
    assert pi.import_playbook == './some.yml'
    assert pi.vars == {'a':1, 'b':2}
    assert pi.tags == ['tag1', 'tag2', 'tag3']

    ds = Ansible

# Generated at 2022-06-21 00:56:41.970778
# Unit test for method load of class PlaybookInclude

# Generated at 2022-06-21 00:56:53.166001
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.playbook.playbook_include import PlaybookInclude
    class FakeVarsModule(object):
        def __init__(self,vars):
            self._vars = vars

        def get_vars(self):
            return self._vars

    data = dict(
        import_playbook='tasks/test.yml',
        vars={'a': 1},
        tags=['t'],
        when={'t': 1},
    )

    basedir = '.'

    pbi = PlaybookInclude()
    pb = PlaybookInclude.load(data, basedir)
    assert isinstance(pb, Playbook)
    assert isinstance(pb._entries[0], Play)

# Generated at 2022-06-21 00:56:53.941107
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pass

# Generated at 2022-06-21 00:57:01.584751
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    ds = { "import_playbook": "test.yaml" }
    play = PlaybookInclude()
    # omit loader because it is not called in the tested method
    play.load_data(ds, basedir='', variable_manager='', loader=None)
    assert play.import_playbook == "test.yaml"

    ds = { "include_playbook": "test.yaml" }
    play = PlaybookInclude()
    # omit loader because it is not called in the tested method
    play.load_data(ds, basedir='', variable_manager='', loader=None)
    assert play.import_playbook == "test.yaml"

# Generated at 2022-06-21 00:57:14.110234
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook import PlaybookInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block

    ds = dict(import_playbook='playbook.yml', tags=['playbook_include_tag'], vars=dict(foo='bar'))
    p_include = PlaybookInclude(ds)

    pb = Playbook()

# Generated at 2022-06-21 00:57:26.233807
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from collections import namedtuple

    TestOptions = namedtuple('TestOptions', [])
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = { 'foobar': 'foobarzoo' }
    pb = PlaybookInclude()
    opts = TestOptions()
    opts.connection = 'local'
    opts.module_path = ['/path/to/mymodules']
    opts.forks = 10
    opts.remote_user = 'myuser'
    opts.private_key_file = '/path/to/my/key'
    opt

# Generated at 2022-06-21 00:57:37.272796
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.vars.manager import VariableManager

    data = '''
# in playbook.yml
tasks:
    - name: call some_playbook.yml
      import_playbook: some_playbook.yml
'''

    playbook_path = 'playbook.yml'
    loader = AnsibleLoader(data, file_name=playbook_path)
    vault_secrets = VaultLib(password_files=[])
    variable_manager = VariableManager()
    variable_manager.set_playbook_basedir(playbook_path)
    variable_manager.set_vault_secrets(vault_secrets)


# Generated at 2022-06-21 00:57:57.581463
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six import StringIO

    # Test for method load of class PlaybookInclude
    # This is a complete test demonstrating usage of the PlaybookInclude class.
    # The test creates a scene wherein a playbook is imported with a variety of tags and variables.
    # The tags and variables are tested to ensure they are being properly set on the imported plays.
    # NOTE: This test should be kept in sync with the descriptions of the import_playbook feature in the Ansible docs.
    # The test is run twice: once with Python 2 and once with Python 3 to ensure it is working in both cases.


# Generated at 2022-06-21 00:58:08.065125
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.playbook_include import PlaybookInclude

    import_playbook_line = ("import_playbook: "
                            "include_playbook.yml data=firstvar host={{inventory_hostname}}")
    ds = parse_kv(import_playbook_line)
    new_ds = PlaybookInclude.preprocess_data(ds)
    assert isinstance(new_ds, AnsibleMapping)
    assert len(new_ds) == 3
    assert 'import_playbook' in new_ds
    assert 'vars' in new_ds
    assert 'data' in new_ds['vars']
    assert 'host' in new_ds['vars']
    assert new_ds['vars']['host'] == '{{inventory_hostname}}'



# Generated at 2022-06-21 00:58:12.994376
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    playbook_include = PlaybookInclude()
    assert playbook_include.vars == {}

    playbook_include = PlaybookInclude(vars={'foo': 'bar'})
    assert playbook_include.vars == {'foo': 'bar'}

# Generated at 2022-06-21 00:58:26.664660
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper

    legacy_ds = dict(
        import_playbook='/path/to/playbook.yml',
        ignore_errors=False,
        when=dict(
            test_var='testing var',
            op='eq',
            value=False,
        ),
        limit='localhost',
        tags='test',
        vars=dict(
            test_vars='test',
        ),
    )
    basemodule = PlaybookInclude()
    basemodule.vars = dict()

# Generated at 2022-06-21 00:58:39.447870
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    class FakeLoader():
        def __init__(self):
            self.paths = []
            self.basedir = '/root'

    class FakePlaybook():
        def __init__(self):
            self.loader = FakeLoader()

    pbi = PlaybookInclude()

    ds = dict(import_playbook='a.yml', vars=dict(x=1))
    pb = PlaybookInclude.load_data(pbi, ds, basedir='/root', loader=pbi.loader)

    assert pb.import_playbook == 'a.yml'
    assert pb.vars == dict(x=1)

    ds = dict(import_playbook='a.yml tags=foo,bar', vars=dict(x=1))

# Generated at 2022-06-21 00:58:42.304226
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    playbook_include = PlaybookInclude()
    assert playbook_include.load("test", basedir="basedir", variable_manager="variable_manager", loader="loader") is None

# Generated at 2022-06-21 00:58:49.971602
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.playbook.play import Play

    from ansible.playbook.task import Task
    from ansible.template import Templar

    path = os.path.dirname(os.path.realpath(__file__))
    pb = PlaybookInclude()
    data = { 'import_playbook': "test.yml" }
    pb.load_data(data, path)
    assert isinstance(pb._entries[0], Play)
    assert isinstance(pb._entries[0].get_tasks(), AnsibleSequence)
    assert pb._entries[0].get_tasks()[0].action in ('debug', 'setup')
    assert pb._entries[0].get_tasks()[1].action

# Generated at 2022-06-21 00:58:59.756784
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import ansible.playbook.unittests.unit_test_loader as loader

    def test_yaml_object(new_ds, expected):
        fields = dict([(k, None) for k in expected])
        fields.update(dict(ansible_pos=new_ds.ansible_pos))
        for k in new_ds:
            fields[k] = new_ds[k]
        target_class = type('YamlObject', (AnsibleBaseYAMLObject,), fields)
        return target_class()

    def test_loader(ds):
        def load():
            return PlaybookInclude.load(data=test_yaml_object(ds, ['import_playbook', 'vars']), basedir='.', loader=None, variable_manager=None)
        return load

    loader.load_module

# Generated at 2022-06-21 00:59:09.332069
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    import copy
    import json
    import os
    import re
    import sys
    import time
    import yaml

    # Make sure this import works even if the working
    # directory is not the directory the module is in
    ansible_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    ansible_path = ansible_path + os.sep + 'ansible'
    sys.path.insert(1, ansible_path)

    from ansible.module_utils.six import string_types
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

# Generated at 2022-06-21 00:59:19.120474
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Initialize a object of class PlaybookInclude
    obj = PlaybookInclude()

    # Initialize a map with the data of the playbook_include element
    ds = {}
    ds["import_playbook"] = "test.yml"

    # Initialize the expected results
    new_ds = {}
    new_ds["import_playbook"] = "test.yml"

    # Check if the preprocess_data method returned what is expected
    assert obj.preprocess_data(ds) == new_ds

#Unit test for method _preprocess_import of class PlaybookInclude

# Generated at 2022-06-21 01:00:02.504356
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    # test when the import_playbook parameter is missing
    ds1 = AnsibleMapping({'save_log': False,'tags': 'foo'})
    with pytest.raises(AnsibleParserError):
        PlaybookInclude().preprocess_data(ds1)

    # test when the import_playbook parameter is None
    ds2 = AnsibleMapping({'import_playbook': None})

# Generated at 2022-06-21 01:00:08.364982
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.tasks import Task

    # PlaybookInclude.load_data
    #   Playbook 
    #       |_ pre_tasks
    #          |_ Tasks
    #       |_ roles
    #          |_ Task
    #       |_ tasks
    #          |_ Task
    #       |_ post_tasks
    #          |_ Task

    # create a playbook
    pb = Playbook()

    # add pre_tasks
    p1 = Play()
    p1.name = "pre_tasks"
    # add pre_tasks
    t1 = Task()
    t1.name = "task1"
    t2 = Task()

# Generated at 2022-06-21 01:00:19.976174
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    import os
    import sys
    sys.path.append(os.path.join(os.path.dirname(__file__), '../../lib'))

    from ansible.module_utils.six import PY3
    from ansible.utils.display import Display
    from ansible.playbook.play import Play

    class DummyPlaybook:
        pass

    class DummyVariableManager:
        def get_vars(self, *args, **kwargs):
            return dict()

    class DummyLoader:
        def get_basedir(self, *args, **kwargs):
            basedir = os.path.dirname(__file__)
            for _ in range(4):
                basedir = os.path.dirname(basedir)
            return basedir

    # Setup
    display = Display()
    display

# Generated at 2022-06-21 01:00:30.787754
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # import_playbook can be used with parameters
    ds_old = {'import_playbook': 'test.yml foo=bar'}
    ds_new = PlaybookInclude.load(ds_old, '').preprocess_data(ds_old)
    assert ds_new['import_playbook'] == 'test.yml'
    assert ds_new['vars']['foo'] == 'bar'

    # import_playbook with parameters does not conflict with vars:
    ds_old = {'import_playbook': 'test.yml foo=bar', 'vars': {'name': 'value'}}
    ds_new = PlaybookInclude.load(ds_old, '').preprocess_data(ds_old)

# Generated at 2022-06-21 01:00:31.293678
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pass

# Generated at 2022-06-21 01:00:41.541695
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():

    import os
    import sys
    import pytest

    current_dir = os.path.dirname(os.path.realpath(__file__))
    pytest.importorskip("ansible.plugins.loader")
    test_file = os.path.join(current_dir, 'yaml/playbook_include_load.yml')

    playbook_include = PlaybookInclude.load(
        data={"import_playbook": "../files/ansible.cfg"},
        basedir=current_dir,
        variable_manager=None,
        loader=None
    )
    assert playbook_include is not None
    assert playbook_include._entries is not None
    assert len(playbook_include._entries) > 0

# Generated at 2022-06-21 01:00:48.239317
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # file name without any params
    ds = dict(
        import_playbook='some_file.yml'
    )
    obj = PlaybookInclude.load(ds, None)
    assert obj.import_playbook == 'some_file.yml'
    assert obj.vars == dict()

    # file name with params
    ds = dict(
        import_playbook='some_file.yml vars=this:that'
    )
    obj = PlaybookInclude.load(ds, None)
    assert obj.import_playbook == 'some_file.yml'
    assert obj.vars == dict(vars=dict(this='that'))

    # file name with params

# Generated at 2022-06-21 01:01:00.142524
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # Create a FakeLoader object to return some fake data,
    # just for testing purposes
    class FakeLoader:
        data = {
            '_tasks/main.yml': [
                {'name': 'task1'},
                {'name': 'task2'}
            ]
        }

    fake_loader = FakeLoader()

    # Mock the loader.load_from_file method, to return the correct data
    # based on the fake file path
    def load_from_file(file_name):
        return fake_loader.data[file_name]

    fake_loader.load_from_file = load_from_file

    # Mock the loader.path_dwim method, which is the main method used
    # to find the file path of the included playbook file

# Generated at 2022-06-21 01:01:03.091240
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    PlaybookInclude.load(data=None, basedir=None, variable_manager=None, loader=None)

# Generated at 2022-06-21 01:01:09.311221
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    '''
    Test preprocess_data method of class PlaybookInclude
    '''
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.template import Templar

    # test valid data
    valid_data = {'include': 'include_me.yml'}
    playbook = PlaybookInclude()
    updated_data = playbook.preprocess_data(valid_data)
    assert(updated_data == {'import_playbook': 'include_me.yml'})

    # test valid with parameters
    valid_data = {'include': 'include_me.yml tags=foo,bar'}
    playbook = PlaybookInclude()
    updated_data = playbook.preprocess_data(valid_data)

# Generated at 2022-06-21 01:02:52.850296
# Unit test for method load of class PlaybookInclude

# Generated at 2022-06-21 01:03:03.640722
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    import os
    import tempfile
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.errors import AnsibleParserError
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence

    # pass empty ds so we don't need to supply base data
    ds = AnsibleSequence()

    # don't want to support --first-pass in a unit test, so we need to
    # explicitly set this value
    C.DEFAULT_FORKS = 0

    testfiles_dir = os.path.join(tempfile.mkdtemp(), 'testfiles')