

# Generated at 2022-06-21 00:53:30.353155
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    import io


# Generated at 2022-06-21 00:53:32.866943
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    playbook = PlaybookInclude()
    assert playbook.name is None
    assert playbook.import_playbook is None
    assert playbook.tags == []
    assert playbook.vars == {}



# Generated at 2022-06-21 00:53:34.342029
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-21 00:53:46.402758
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import yaml

# Generated at 2022-06-21 00:53:57.338919
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block

    ds = dict(vars=dict(include_var='include_var'),
              import_playbook='test.yml',
              )

    basedir = '/some/path/to/file'
    variable_manager = None
    loader = None

    # Check when a given playbook has a task in it
    playbook = Playbook()
    play = Play()
    play.included_path = '/some/path/to/file/test.yml'
    playbook._entries.append(play)
    task = Task()

# Generated at 2022-06-21 00:53:58.832283
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pb = PlaybookInclude()
    assert pb is not None

# Generated at 2022-06-21 00:54:11.846889
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os.path as op
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import callback_loader
    from ansible.vars.manager import VariableManager

    test_dir = op.dirname(op.dirname(op.dirname(op.dirname(__file__))))
    test_pf = op.join(test_dir, 'test/units/playbooks/playbook_include_test.yml')
    
    p = PlaybookInclude.load("test/units/playbooks/playbook_include_test.yml", os.getcwd(), loader=None)

    p.validate()

    # All entries of the playbook loaded with the same _included_path
    assert len(p._entries) == 4

# Generated at 2022-06-21 00:54:14.869767
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    ds = {'import_playbook': 'example.yml'}
    b = PlaybookInclude(ds, variable_manager=None)

# Generated at 2022-06-21 00:54:23.471508
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import ansible.playbook

    ds = dict(import_playbook = dict(playbook='path', params=dict(vars=dict(x='x', y='y'))))
    new_ds = ansible.playbook.PlaybookInclude().preprocess_data(ds)
    if 'import_playbook' not in new_ds or new_ds['import_playbook'] != 'path':
        raise AssertionError("Failed to preprocess playbook import statement: playbook key")

# Generated at 2022-06-21 00:54:33.489290
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    '''
    This unit test is to test method preprocess_data of class PlaybookInclude
    '''
    import textwrap

    ds = {
        'import_playbook': 'import_me.yml',
        'vars': {
            'foo': 'bar',
        },
        'tags': 'foo, bar, baz',
    }

    play = textwrap.dedent("""\
        - import_playbook: import_me.yml
          vars:
            foo: bar
          tags:
            - foo
            - bar
            - baz
    """)
    playbook = PlaybookInclude()
    new_ds = playbook.preprocess_data(ds)
    assert play == new_ds


# Generated at 2022-06-21 00:54:41.176246
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    playbook_include = PlaybookInclude()
    assert playbook_include is not None, 'Error constructing PlaybookInclude'

# Generated at 2022-06-21 00:54:43.620994
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    pb = Playbook()
    pb._load_playbook_data(file_name='playbook.yaml', variable_manager=None, vars=None)

    assert isinstance(pb, Playbook)

    for entry in pb._entries:
        assert isinstance(entry, Play)

# Generated at 2022-06-21 00:54:48.301490
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    from ansible.module_utils._text import to_bytes
    from ansible.template import Templar

    # 1. test for error handling (errors are raised as exceptions)
    ds = {'import_playbook': 1}
    try:
        pb = PlaybookInclude()
        pb.preprocess_data(ds)
    except AnsibleParserError:
        pass
    else:
        assert False

    # 2. test for "normal" case
    ds = dict(import_playbook='../../common/foo.yml')
    # display.deprecated expected
    pb = PlaybookInclude()
    pb.preprocess_data(ds)
    assert pb.import_playbook == '../../common/foo.yml'

    # 3. test for "normal" case with multiple parameters
    ds

# Generated at 2022-06-21 00:54:54.905512
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # Testing that the __init_ method of PlaybookInclude class
    # works properly
    PlaybookInclude.load(
        {
            'import_playbook': 'playbook.yml'
        },
        '.',
        variable_manager=None,
        loader=None
    )


# Generated at 2022-06-21 00:54:57.530453
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook

    pb = PlaybookInclude.load(data={'import_playbook': 'test.pb'}, basedir='.')

    assert isinstance(pb, Playbook)

# Generated at 2022-06-21 00:55:03.554279
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.playbook.attribute import Attribute, FieldAttribute
    import yaml
    import sys


    class TestAttribute(Attribute):

        def serialize(self, class_name, field_name):
            return '%s.%s' % (class_name, field_name)

        def deserialize(self, value):
            return 'DEFAULT'

    class Test(object):
        _field_name_1 = FieldAttribute(isa='string', default='DEFAULT', serialize_as=TestAttribute)
        _field_name_2 = FieldAttribute(isa='string')

    obj = Test()

# Generated at 2022-06-21 00:55:17.163992
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    loader, inventory, variable_manager = CLI.setup()
    variable_manager.extra_vars = {
        'a': 1,
        'b': 2,
        'c': 3,
        'd': 4,
        'e': 5,
        'f': 6,
        'g': 7,
    }
    variable_manager.set_inventory(inventory)

    expected_pb = Playbook.load(os.path.join(os.path.dirname(__file__), '../playbooks/playbook_include.yml'), variable_manager=variable_manager, loader=loader)

    # Create Playbook

# Generated at 2022-06-21 00:55:30.989295
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible import context
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    import pytest

    context._init_global_context(PlayContext())

    # check absolute playbook path
    file_name = "test_import_playbook.yml"
    ans_collection_config = AnsibleCollectionConfig()
    ans_collection_config.default_collection = 'test_collection'
    data = {'import_playbook': file_name}
    result_object = PlaybookInclude.load(data, "/tmp", variable_manager=VariableManager())
    assert result_object._entries[0]._included_path is not None

# Generated at 2022-06-21 00:55:32.040538
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    pass

# Generated at 2022-06-21 00:55:41.912592
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    PlaybookInclude("/root/test.yml")
    PlaybookInclude("/root/test.yml", "key1=value1,key2=value2")
    PlaybookInclude("/root/test.yml", "key1=value1,key2=value2", False)
    try:
        PlaybookInclude("/root/test.yml", "key1=value1", "key2=value2")
    except AnsibleParserError as e:
        print(e)
    PlaybookInclude("/root/test.yml", vars={'key1': 'value1', 'key2': 'value2'})
    PlaybookInclude("/root/test.yml", vars={'key1': 'value1', 'key2': 'value2'}, conditional='True')

# Generated at 2022-06-21 00:55:59.993430
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Play
    from ansible.template import Templar

    class DummyLoader:
        path = []


# Generated at 2022-06-21 00:56:08.247899
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # test imported playbook with single file
    test_ds = dict(import_playbook='test1.yml')
    pybk_include = PlaybookInclude()
    new_ds = pybk_include.preprocess_data(test_ds)
    assert 'import_playbook' in new_ds
    assert 'playbook' not in new_ds
    assert new_ds['import_playbook'] == 'test1.yml'
    # test imported playbook with multiple files
    test_ds = dict(import_playbook='test1.yml, test2.yml')
    new_ds = pybk_include.preprocess_data(test_ds)
    assert 'import_playbook' in new_ds
    assert 'playbook' not in new_ds

# Generated at 2022-06-21 00:56:20.525612
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import os

    from ansible.playbook.playbook_include import PlaybookInclude

    # Test for correct results when vars are specified in playbook.
    playbook_include_vars_dict = {"import_playbook": "../common/main.yml",
                                  "vars": {"foo": "bar"},
                                  "tags": ["ok"]}
    playbook_include_vars_yaml = """
    import_playbook: ../common/main.yml
    vars:
        foo: bar
    tags:
        - ok
    """
    playbook_include_vars = PlaybookInclude.load(data=playbook_include_vars_yaml, basedir=os.getcwd())

# Generated at 2022-06-21 00:56:31.646520
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.loader import PlaybookLoader
    from ansible.playbook.play import Play
    import io
    import os
    import os.path
    import tempfile

    # Create a temporary directory to hold playbook
    tempdir = tempfile.mkdtemp()
    playbook_dir = os.path.join(tempdir, 'test')
    os.makedirs(playbook_dir)
    playbook_path = os.path.join(playbook_dir, 'playbook.yaml')

# Generated at 2022-06-21 00:56:42.192770
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    import ansible.playbook.playbook_include

    ansibledir = os.path.dirname(__file__)

    ds = {'import_playbook': 'another.yaml'}
    basedir = os.path.join(ansibledir, '..', '..')
    variable_manager = None
    loader = None

    playbook = PlaybookInclude.load(ds, basedir, variable_manager, loader)

    assert isinstance(playbook, Playbook)
    assert len(playbook._entries) == 1
    assert playbook.basedir == basedir
    assert playbook._included_filenames == ['another.yaml']
    assert playbook._entries[0]._included_path

# Generated at 2022-06-21 00:56:43.099459
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-21 00:56:53.934010
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pbi = PlaybookInclude()

    assert pbi.vars is None
    assert pbi.tags is None

    _data = AnsibleMapping()
    _data['import_playbook'] = 'foo.yml'
    _data['vars'] = AnsibleMapping({'A': 'B'})

    pbi = PlaybookInclude()
    pbi.load_data(_data, basedir='fakebasedir')

    assert pbi.vars['A'] == 'B'

    # makes sure the vars parameter overrides in load_data() works
    pbi = PlaybookInclude()
    pbi.load_data(_data, basedir='fakebasedir', vars={'A': 'C'})

    assert pbi.vars['A'] == 'C'

# Generated at 2022-06-21 00:57:02.930591
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    file_name = 'common.yml'
    basedir = '/path/to/ansible/data'
    playbook = '/path/to/ansible/data/common.yml'
    playbook_path = '/path/to/ansible/data/'

    # it is a collection playbook, setup default collections
    playbook_collection = 'michi'
    AnsibleCollectionConfig.default_collection = playbook_collection

    # it is NOT a collection playbook, setup adjecent paths
    AnsibleCollectionConfig.playbook_paths.append(playbook_path)

    pb = PlaybookInclude.load(file_name, basedir, loader=None)

    assert pb._entries[0]._included_path == playbook_path
    assert AnsibleCollectionConfig.default_collection == playbook_collection

# Generated at 2022-06-21 00:57:14.213863
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    data = '''
    ---
    - name: Test import playbook
      import_playbook: playbook1.yml
    '''

    pbi = PlaybookInclude()
    new_ds = pbi.preprocess_data(ds=data)


if __name__ == '__main__':
    from ansible.module_utils.basic import AnsibleModule
    from ansible.errors import AnsibleError

    try:
        test_PlaybookInclude_preprocess_data()
    except AnsibleError as e:
        module_args = dict(data=dict(failed=True, msg=to_bytes(e)))
        module = AnsibleModule(argument_spec=dict(data=dict(type='dict', required=True)))
        module.exit_json(**module_args)

# Generated at 2022-06-21 00:57:15.786696
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass


# Generated at 2022-06-21 00:57:35.375964
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.context import AnsibleContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    mock_results = [{'_ansible_parsed': True, 'changed': True, 'reboot_required': False},
                    {'_ansible_parsed': True, 'changed': True, 'reboot_required': False}]
    mock_play_context = PlayContext(play=dict(), options=dict(), passwords=dict(), connection_user='test',
                                    filename=None, become_method='sudo', extra_vars=dict())
    mock_context = Ans

# Generated at 2022-06-21 00:57:38.591826
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pbi = PlaybookInclude()
    assert pbi.import_playbook == None
    assert pbi.vars == {}

# Generated at 2022-06-21 00:57:46.699017
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    import io

    # Setup vars
    VariableManager.set_default_whitelist_externals((b'EXECUTABLE_NAME',))

    # Setup ds
    ds1 = '- hosts: localhost\n  tasks:\n  - name: test 1\n    shell: date\n'
    ds1 = io.BytesIO(to_bytes(ds1))
    ds2 = 'import_playbook: test.yml\n'
    ds2 = io.BytesIO(to_bytes(ds2))

    dl = DataLoader()
    playbook_include = PlaybookIn

# Generated at 2022-06-21 00:57:59.617864
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    ds = dict(
        include='./playbooks/playbook.yml',
        include_tasks='./playbooks/tasks/main.yml',
        import_playbook='../playbook.yml',
        import_playbook2='../playbooks/playbook2.yml foo=bar',
        import_playbook3='../playbooks/playbook3.yml foo=bar tags=tag_x,tag_y',
        import_playbook4='../playbooks/playbook4.yml othervars={"a":1,"b":"two"}'
    )


# Generated at 2022-06-21 00:58:12.808376
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # import here to avoid a dependency loop
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    pbi = PlaybookInclude()

    playbook = Playbook()
    playbook._entries = []
    playbook._entries.append(Play())
    playbook._entries[0].tags = ['tag1', 'tag2']
    playbook._entries[0].vars = {'var1': 'value1', 'var2': 'value2'}

    pbi_ds = AnsibleMapping({'import_playbook': 'import.yml', 'tags': ['tag3', 'tag4'], 'vars': {'var3': 'value3'}})
    pbi.load_data(pbi_ds, basedir='/path/to/basedir')
    result = playbook._

# Generated at 2022-06-21 00:58:25.023022
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook

    playbook_include = PlaybookInclude.load(dict(import_playbook='imported_playbook', tags=['tag_1', 'tag_2'], vars=dict(a=1, b=2)), '.')

    assert playbook_include.import_playbook == 'imported_playbook'
    assert playbook_include.tags == ['tag_1', 'tag_2']
    assert playbook_include.vars == {'a': 1, 'b': 2}

    assert playbook_include.when == list()

    assert isinstance(playbook_include, Playbook)



# Generated at 2022-06-21 00:58:38.685730
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # Ansible 2.10
    from ansible.playbook.play import Play
    from ansible.variable_manager import VariableManager
    from ansible.vars.manager import DataLoader
    from ansible.errors import AnsibleParserError

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)

    pbi = PlaybookInclude()
    try:
        pbi.load_data(ds=dict(import_playbook='test_playbook.yml'),
                      basedir='.',
                      variable_manager=variable_manager,
                      loader=loader)
    except AnsibleParserError as e:
        assert e.message == "import_playbook parameters cannot be mixed with 'vars' entries for import statements"


# Generated at 2022-06-21 00:58:45.492050
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    obj = PlaybookInclude()
    ds = AnsibleMapping()
    ds['import_playbook'] = 'book'
    new_ds = obj.preprocess_data(ds)
    assert new_ds.get('import_playbook') == 'book'
    ds = AnsibleMapping()
    ds['include'] = 'book'
    new_ds = obj.preprocess_data(ds)
    assert new_ds.get('import_playbook') == 'book'

# Generated at 2022-06-21 00:58:53.188635
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook

    import_playbook = "playbook.yml"
    playbook_include = PlaybookInclude(import_playbook=import_playbook)
    playbook_file = playbook_include.load({"import_playbook": import_playbook}, "/tmp")
    assert playbook_file.__class__ == Playbook

# Generated at 2022-06-21 00:58:56.310637
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    '''
    Make sure that load() works as expected
    '''
    # TODO: test conditional loading
    # TODO: test limit loading
    # TODO: test vars loading
    # TODO: test tags loading
    pass

# Generated at 2022-06-21 00:59:06.117583
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # TODO
    pass


# Generated at 2022-06-21 00:59:14.400577
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    obj = PlaybookInclude()
    assert isinstance(obj, PlaybookInclude)
    assert isinstance(obj, Conditional)
    assert isinstance(obj, Taggable)
    assert isinstance(obj, Base)
    assert not hasattr(obj, '_included_conditional')
    assert hasattr(obj, '_import_playbook')
    assert hasattr(obj, '_vars')

# Generated at 2022-06-21 00:59:26.357929
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    ds = dict()
    ds['import_playbook'] = 'test.yml'
    ds['vars'] = dict()
    ds['vars']['var1'] = 'val1'
    ds['vars']['var2'] = 'val2'
    ds['vars']['var3'] = 'val3'
    play = PlaybookInclude.load(ds, '.')
    assert (play is not None)
    assert (play.import_playbook == 'test.yml')
    assert (play.vars['var1'] == 'val1')
    assert (play.vars['var2'] == 'val2')
    assert (play.vars['var3'] == 'val3')

# Generated at 2022-06-21 00:59:38.890490
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    """PlaybookInclude: test preprocess_data method."""
    from units.mock.loader import DictDataLoader
    variable_manager = DictDataLoader()

    # Test case 1
    ds = {'import_playbook': 'setup.yml'}
    playbook_include = PlaybookInclude()
    new_ds = playbook_include.preprocess_data(ds)
    assert new_ds['import_playbook'] == 'setup.yml'
    assert new_ds['vars'] == {}

    # Test case 2
    ds = {'include_playbook': 'setup.yml',
          'vars': {'a': 1}}
    playbook_include = PlaybookInclude()
    new_ds = playbook_include.preprocess_data(ds)

# Generated at 2022-06-21 00:59:47.460767
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Import is only needed to test this function,
    # the import is placed here to avoid the dependency loop
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    # Test: loading a playbook that is not a collection playbook
    playbook_include = PlaybookInclude.load({"import_playbook": "playbook.yml"}, "basedir")
    assert playbook_include
    assert playbook_include.name == "playbook.yml"
    assert playbook_include.import_playbook == "playbook.yml"
    assert playbook_include._playbook_dir == "basedir"
    assert playbook_include._included_path is None
    assert playbook_include._included_files == {"playbook.yml": 1}

    # Test: loading a playbook that is a collection playbook
    playbook_

# Generated at 2022-06-21 00:59:59.102333
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task


# Generated at 2022-06-21 01:00:08.211075
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    import ansible.parsing.yaml.loader
    from ansible.parsing.yaml.objects import AnsibleSequence
    import sys

    def get_variable_manager(*args):
        return VariableManager()

    def get_loader(*args):
        return ansible.parsing.yaml.loader.AnsibleLoader(None, variables=dict())

    def test(ds):
        pb_include = PlaybookInclude.load(ds, './ing')
        assert isinstance(pb_include, AnsibleSequence)
        pb_include_obj = pb_include.pop()
        assert isinstance(pb_include_obj, PlayContext)

# Generated at 2022-06-21 01:00:12.579518
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    '''
    Constructor of class PlaybookInclude
    :return:
    '''
    p = PlaybookInclude()
    assert p


# Generated at 2022-06-21 01:00:13.502456
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-21 01:00:21.807352
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task import Task
    from ansible.playbook.task.include import TaskInclude

    data = dict(
        import_playbook="test_import",
        vars=dict(
            var1="var1_val",
        ),
        tags=["tag1", "tag2"],
    )

    base = "."
    input = PlaybookInclude.load(data, basedir=base)

    assert isinstance(input, Playbook)
    assert isinstance(input.inventory, InventoryManager)
   

# Generated at 2022-06-21 01:01:11.774827
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    data_loader = DataLoader()
    variable_manager = VariableManager()
    temp = Templar(loader=data_loader, variables=variable_manager.get_vars())
    obj = PlaybookInclude.load({'import_playbook': '/tmp/abc'}, basedir='/', variable_manager=variable_manager, loader=data_loader)
    assert obj.import_playbook == '/tmp/abc'
    assert isinstance(obj, PlaybookInclude)
    obj.import_playbook = temp.template('{{ playbook_dir }}/tmp/abc')

# Generated at 2022-06-21 01:01:22.547781
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    import yaml
    from hashlib import sha1
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    basedir = '/tmp'
    playbook_import_data = {'import_playbook': ['main.yml'], 'vars': {'foo': ['bar']}}
    playbook_data = {'name': u'foo', 'hosts': 'all', 'vars': {'sha1test': AnsibleVaultEncryptedUnicode(sha1(u'abc').hexdigest())}, 'tasks': [{'block': {'tasks': [{'name': u'bar'}]}}]}

# Generated at 2022-06-21 01:01:26.851739
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    '''
    Unit test for constructor of class PlaybookInclude
    '''

    obj = PlaybookInclude()
    assert obj._import_playbook is not None

# Generated at 2022-06-21 01:01:39.973985
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()

    file_name = 'include_playbook_file.yml'
    basedir = os.path.dirname(os.path.realpath(__file__))
    pb = PlaybookInclude.load(file_name, basedir, variable_manager, loader)

    assert isinstance(pb, Playbook)
    assert pb.loader == loader

# Generated at 2022-06-21 01:01:41.518911
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # TODO: Write unit test for method load_data of class PlaybookInclude
    pass


# Generated at 2022-06-21 01:01:48.921240
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    import ansible.playbook
    import ansible.playbook.play
    import ansible.template
    import ansible.vars
    import ansible.parsing.yaml.objects
    pbi = PlaybookInclude()

    # Mocking the input parameters to load method
    basedir = ansible.constants._cached_var_obj()
    mock_variables = ansible.vars.VariableManager(loader=None, variables=None)
    mock_loader = ansible.parsing.dataloader.DataLoader()

    # Mocking the output of method load_data to be returned by method load
    mock_ds = ansible.parsing.yaml.objects.AnsibleMapping()
    mock_playbook = ansible.playbook.Playbook(loader=mock_loader)
    mock_

# Generated at 2022-06-21 01:01:59.766738
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    # inven = InventoryManager(loader=loader, sources='')
    # inven._inventory = ""
    inv = InventoryManager(loader=loader, sources=["tests/inventory"]) #inven
    variable_manager = VariableManager(loader=loader, inventory=inv)
    PlayContext.variable_manager=variable_manager
    PlayContext.loader=loader

    PlaybookInclude.load({}, '.', variable_manager)

# Generated at 2022-06-21 01:02:12.225007
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.playbook.playbook import Playbook
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = None
    p = Playbook.load('/etc/ansible/hosts', variable_manager=variable_manager, loader=loader)
    l = PlaybookInclude.load({'import_playbook': 'common.yml', 'vars': {'foo': 'bar'}}, basedir='/home/jdoe/playbooks', loader=loader, variable_manager=variable_manager)
    assert p.entries[1]._included_path == '/home/jdoe/playbooks'
    assert p.entries[1].vars['foo'] == 'bar'


# Generated at 2022-06-21 01:02:24.477088
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    playbook = Playbook()

# Generated at 2022-06-21 01:02:30.581811
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    yaml_object = """
    - name: playbook_test
      hosts: localhost
      import_playbook: ./test_playbook
      vars:
          vars_test: true
      tags:
          - test
    """

    playbook_include = PlaybookInclude.load(yaml_object, variable_manager=None, loader=None)
    assert playbook_include.import_playbook == "./test_playbook"
    assert playbook_include.vars["vars_test"] == True
    assert playbook_include.tags == ["test"]