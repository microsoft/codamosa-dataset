

# Generated at 2022-06-21 00:53:30.405466
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.module_utils.six import StringIO
    from ansible.parsing.yaml.loader import AnsibleLoader

    class DummyLoader:
        def get_basedir(self, host):
            return 'basedir'

        @staticmethod
        def load_file(file_name, cache=True):
            # When the folder name starts with 'test_' we execute
            # the tests for the local file
            file_name = file_name.replace('/', '_')
            file_path = file_name[:file_name.rfind('.')]
            module = __import__('playbook_tests.lib.loader.test_' + file_path, globals(), locals(), file_path)
            return getattr(module, 'playbook')

    loader = DummyLoader()
    playbook = PlaybookIn

# Generated at 2022-06-21 00:53:37.971129
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # Test PlaybookInclude.load()
    # Action = import_playbook
    data = {'import_playbook': 'test/fixtures/playbook_include/test_import.yml'}
    playbook = PlaybookInclude.load(data, basedir='.')
    assert playbook.__class__.__name__ == 'Playbook'
    # Action = include_playbook
    data = {'include_playbook': 'test/fixtures/playbook_include/test_import.yml'}
    playbook = PlaybookInclude.load(data, basedir='.')
    assert playbook.__class__.__name__ == 'Playbook'
    # Action = import_tasks
    data = {'import_tasks': 'test/fixtures/playbook_include/test_import.yml'}
   

# Generated at 2022-06-21 00:53:43.043862
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    """
    playbook_include.py Tests
    """
    yaml_text = """
- import_playbook: example.yml
    """
    p_b_include = PlaybookInclude.load(yaml_text, variable_manager=None, loader=None)
    assert p_b_include.import_playbook == 'example.yml'

# Generated at 2022-06-21 00:53:49.045539
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    '''
    Validate creation of a PlaybookInclude object
    '''
    pbi = PlaybookInclude()
    assert pbi.import_playbook is None
    assert pbi.vars == {}
    assert pbi.tags == []
    assert pbi.when is None
    assert len(pbi._attributes) == 3

# Generated at 2022-06-21 00:53:59.063356
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    temp_vars = dict(foo=1, bar=2)
    include_object = PlaybookInclude( 'test.yml', tags=['tag1', 'tag2'], vars=temp_vars, when=dict(foo='bar'))
    pb = include_object.load_data(ds=None, basedir='./ansible/playbooks', variable_manager=None, loader=None)

    # Checking for the resulting object type
    assert isinstance(pb, Playbook)
    # Checking for the resulting values in the Playbook
    assert pb.entries == []
    assert pb.hosts == 'all'
    assert pb.import_playbook == 'test.yml'

# Generated at 2022-06-21 00:54:07.447533
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():

    # Setup arguments used by instantiation of class
    args = dict(
        import_playbook='foo/bar.yml',
        vars=dict(
            foo=dict(
                bar=dict(
                    baz=dict(
                        qux='value',
                    ),
                ),
            ),
        ),
    )

    # Instantiate the class and run method
    pbi = PlaybookInclude()
    result = pbi.load(**args)

    # Assert we got the expected result
    assert result == args

# Generated at 2022-06-21 00:54:10.133115
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    display.verbosity = 3
    PlaybookInclude.load(dict(include=dict(tasks=dict(name='test'))), '/tmp')

# Generated at 2022-06-21 00:54:21.065818
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    import textwrap

    playbook_include = textwrap.dedent("""
    - import_playbook: test.yml
    """)

    pb_include = PlaybookInclude.load(data=playbook_include, basedir=None, variable_manager=None, loader=None)
    assert pb_include is not None
    assert pb_include._entries[0].get_name() == 'test.yml'

    playbook_include = textwrap.dedent("""
    - import_playbook: 'test.yml vars=var1=foo'
    """)

    pb_include = PlaybookInclude.load(data=playbook_include, basedir=None, variable_manager=None, loader=None)
    assert pb_include is not None

# Generated at 2022-06-21 00:54:28.082602
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    yaml = '''
- import_playbook: myinclude.yml
    '''
    data = AnsibleLoader(yaml, yaml_impl=AnsibleDumper).get_single_data()
    include = PlaybookInclude().load_data(data, 'test')
    assert include.import_playbook == 'myinclude.yml'


# Generated at 2022-06-21 00:54:33.735948
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Setup
    ds = AnsibleMapping()

    # Test
    pi = PlaybookInclude().load_data(ds, '/tmp/')

    # Verify
    assert pi.import_playbook is None


# Case 1

# Case 1.1

# Generated at 2022-06-21 00:54:50.288932
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    # use the dataloader to read in the data, which automatically handles
    # vault and templating
    loader = DataLoader()
    vars_manager = None
    basedir = '/etc/ansible'
    ds = dict(import_playbook="/path/to/playbook", vars=dict(extra_var="extra_value"))
    pb = PlaybookInclude.load(ds, basedir, variable_manager=vars_manager, loader=loader)

    assert isinstance(pb, Playbook)

    for entry in pb._entries:
        assert entry._included_path == '/etc/ansible'

# Generated at 2022-06-21 00:54:52.907970
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play

    assert False, "Write unit tests for this class"

# Generated at 2022-06-21 00:55:01.528562
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.vars.manager import VariableManager

    pm = PlaybookInclude.load({
        u'import_playbook': u'../../playbooks/example.yml',
        u'tags': u'rhel',
        u'when': u"ansible_distribution == 'Fedora'",
        u'vars': {
            u'example_var': u'set'
        }
    }, basedir='plays')

    assert isinstance(pm, Playbook)
    assert len(pm._entries) == 1

    #Test the parent_block is None
    assert pm._entries[0].parent_block is None

    #Test the included path is setup

# Generated at 2022-06-21 00:55:04.230304
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    playbook_include = PlaybookInclude
    pb = playbook_include()
    print(pb)


if __name__ == "__main__":
    test_PlaybookInclude()

# Generated at 2022-06-21 00:55:05.932550
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass


# Generated at 2022-06-21 00:55:18.746520
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    yaml_obj = PlaybookInclude.load("import.yml", "tests/lib/ansible/playbook", variable_manager, loader)
    assert isinstance(yaml_obj, Play)
    assert yaml_obj.hosts == "all"
    assert yaml_obj.name == "Imported"
    assert yaml_obj.vars == {}

# Generated at 2022-06-21 00:55:32.056712
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    pc = PlayContext()
    templar = Templar(loader=None, variables=pc.vars)

    # test with import_playbook and vars as dict
    data = {'import_playbook': 'test_playbook.yml', 'vars': {'name': 'banana'}}
    play = PlaybookInclude()
    play.load_data(data, basedir='/tmp')
    assert play.import_playbook == 'test_playbook.yml'
    assert play.vars == {'name': 'banana'}

    # test with import_playbook, vars as dict and conditional

# Generated at 2022-06-21 00:55:41.654808
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    pbi = PlaybookInclude()

    # test invalid data structure
    for value in [[], 'some string', 3, bool, int]:
        try:
            pbi.preprocess_data(ds=value)
            assert False, '%s is not an invalid value for data structure' % value
        except AnsibleAssertionError:
            pass

    # test no import_playbook
    try:
        pbi.preprocess_data(ds={})
        assert False, 'Missing import_playbook should raise exception'
    except AnsibleParserError:
        pass

    # test multiple import_playbook

# Generated at 2022-06-21 00:55:53.485293
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # empty data structure
    ds = AnsibleMapping()
    new = PlaybookInclude()
    ds = new.preprocess_data(ds)
    assert ds == AnsibleMapping()

    # only import_playbook
    ds = AnsibleMapping(dict(import_playbook='any.txt'))
    new = PlaybookInclude()
    ds = new.preprocess_data(ds)
    assert ds == AnsibleMapping(dict(import_playbook='any.txt'))

    # only vars
    ds = AnsibleMapping(dict(vars=dict(a=1, b=2)))
    new = PlaybookInclude()
    ds = new.preprocess_data(ds)

# Generated at 2022-06-21 00:56:03.191797
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import io
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-21 00:56:12.767690
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-21 00:56:22.772655
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    data1 = dict(
        import_playbook=dict(
            file='test',
            tags='test1',
            vars=dict(test='test'),
            when=dict(test1='test1')
        )
    )

    data2 = dict(
        import_playbook=dict(
            file='test',
            tags='test1',
            vars=dict(test='test'),
            when=dict(test1='test1')
        )
    )

    data

# Generated at 2022-06-21 00:56:26.063737
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # TODO: uncomment once we have a mock lib
    # assert_equal(True, False)
    pass


# Generated at 2022-06-21 00:56:30.075710
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    c = PlaybookInclude()
    assert c.import_playbook is None
    assert c.vars == dict()
    assert c.tags == list()
    assert c.when == list()
    assert c.only_tags == set()
    assert c.skip_tags == set()


# Generated at 2022-06-21 00:56:41.553000
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    def assert_preprocessor_error(source, error_msg):
        try:
            PlaybookInclude.load({'import_playbook': source}, '/foo/bar')
            assert False, "AnsibleParserError was not thrown as expected"
        except AnsibleParserError as e:
            assert error_msg in to_bytes(e)

    # import using deprecated positional format
    p = PlaybookInclude.load({'import_playbook': 'test.yml'}, '/foo/bar')
    assert p.import_playbook == 'test.yml'
    assert p.vars == dict()

    # import using deprecated positional format with a sub var
    p = PlaybookInclude.load({'import_playbook': 'test.yml vars: x=1'}, '/foo/bar')
    assert p.import_play

# Generated at 2022-06-21 00:56:52.970048
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from io import StringIO
    import shutil
    import tempfile
    pl = PlaybookInclude()
    ds = dict(import_playbook='imported_playbook.yml')
    res = pl.preprocess_data(ds)
    assert res['import_playbook'] == 'imported_playbook.yml'
    ds = dict(import_playbook='imported_playbook.yml', vars=dict(boo='bar'))
    res = pl.preprocess_data(ds)

# Generated at 2022-06-21 00:57:02.071342
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    import sys
    import os

    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.common.collections import is_sequence

    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.include import RoleIn

# Generated at 2022-06-21 00:57:07.569386
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # Set up
    yaml_data = {'import_playbook': 'test_playbook.yml', 'vars': {'test_var': 'test_value'}}
    basedir = '/test'
    # Test
    test_obj = PlaybookInclude()
    test_obj.load_data(yaml_data, basedir)
    # Assert
    assert test_obj._import_playbook == 'test_playbook.yml'
    assert test_obj._vars == {'test_var': 'test_value'}

# Generated at 2022-06-21 00:57:15.592930
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    """
    >>> from ansible.playbook.playbook_include import PlaybookInclude
    >>> from ansible.parsing.dataloader import DataLoader
    >>> from ansible.vars.manager import VariableManager
    >>> from ansible.inventory.manager import InventoryManager
    >>> from ansible.utils.display import Display
    >>> from ansible.errors import AnsibleError
    >>> yaml_ds = """

# Generated at 2022-06-21 00:57:17.151068
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    pass


# Generated at 2022-06-21 00:57:41.353675
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    print("unit test - PlaybookInclude_load")
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    basedir = 'testdata'
    ds = dict(import_playbook = 'testdata/playbook2.yml')
    test_obj = PlaybookInclude.load(ds, basedir, loader=loader)
    assert len(test_obj._entries) == 2
    assert isinstance(test_obj._entries[0], Play)
    assert test_obj._entries[0].playbook == os.path.join(basedir, 'playbook2.yml')
    assert test_obj._entries[1].playbook == os.path.join(basedir, 'playbook2.yml')


# Generated at 2022-06-21 00:57:44.962395
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pb = PlaybookInclude.load({})
    raise Exception('TODO')


# Generated at 2022-06-21 00:57:55.815578
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    argument1 = 'my_var'
    argument2 = 'another_var'
    ds = AnsibleSequence([
        AnsibleMapping(
            [
                ('include', 'included.yml'),
                ('vars', AnsibleMapping(
                    [
                        ('my_var', argument1),
                    ]
                ))
            ]
        ),
        AnsibleMapping(
            [
                ('include', 'included.yml'),
                ('vars', AnsibleMapping(
                    [
                        ('another_var', argument2),
                    ]
                ))
            ]
        )
    ])

    basedir

# Generated at 2022-06-21 00:57:56.693006
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-21 00:57:57.318060
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass


# Generated at 2022-06-21 00:58:01.213116
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pbi = PlaybookInclude.load(dict(import_playbook='test_playbook'))
    assert isinstance(pbi, PlaybookInclude)


# Generated at 2022-06-21 00:58:02.482380
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass


# Generated at 2022-06-21 00:58:15.771015
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    import mock

    # Test case 1
    playbook_file = 'file.yml'
    playbook_dir = '/path/to/dir'
    playbook_tags = 'tag1,tag2'
    playbook_vars = {'key1': 'value1', 'key2': 'value2'}
    playbook_when = "ansible_os_family == 'RedHat'"

    conditional = Conditional()
    conditional.load_data(playbook_when, None, None)

    ds = {'import_playbook': playbook_file, 'tags': playbook_tags, 'vars': playbook_vars, 'when': playbook_when}
    pb = PlaybookInclude()
    pb.load_data(ds, playbook_dir)

    assert playbook_file == pb.import_playbook

# Generated at 2022-06-21 00:58:19.969827
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import pytest

    data_string = {
        'include': 'myinclude',
        'vars': {
            'foo': 'bar',
        }
    }
    expected_output = {
        'import_playbook': 'myinclude',
        'vars': {
            'foo': 'bar',
        }
    }

    # Test for the legacy `include` keyword
    result = PlaybookInclude.preprocess_data(data_string)
    assert result == expected_output

    # Test for the new `import_playbook` keyword
    data_string['import_playbook'] = 'myinclude'
    del data_string['include']
    result = PlaybookInclude.preprocess_data(data_string)
    assert result == expected_output

    # Test an invalid input
    data_string = {}
   

# Generated at 2022-06-21 00:58:28.742962
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    ds = AnsibleMapping({"playbook-one": {"include": "common.yml", "vars": {"a": 1}}})
    obj = PlaybookInclude()

    # verify assertion errors for wrong ds
    try:
        obj.preprocess_data(list())
        assert False, "Should have raised"
    except (AssertionError, AnsibleParserError):
        pass

    # verify assertion error for wrong k=v pair
    try:
        obj.preprocess_data({"vars": 1})
        assert False, "Should have raised"
    except (AssertionError, AnsibleParserError):
        pass

    # verify assertion error for extra param

# Generated at 2022-06-21 00:58:48.105674
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
  pass

# Generated at 2022-06-21 00:58:57.947453
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    display.verbosity = 3
    pb = PlaybookInclude.load(dict(include="foo.yml"),'/path')
    assert pb._import_playbook == "foo.yml"
    pb = PlaybookInclude.load(dict(import_playbook="foo.yml"),'/path')
    assert pb._import_playbook == "foo.yml"
    pb = PlaybookInclude.load(dict(import_playbook="foo.yml tags=tag1,tag2"),'/path')
    assert pb._import_playbook == "foo.yml"
    assert pb._tags == ['tag1','tag2']


# Generated at 2022-06-21 00:58:59.603977
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    '''
    unit test for load method of class PlaybookInclude
    '''

    # todo: create unit test

    pass

# Generated at 2022-06-21 00:59:08.665335
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    ds = dict(
        import_playbook = './playbooks/setup.yml'
    )
    processed_ds = PlaybookInclude.preprocess_data(ds, variable_manager=None, loader=None)
    assert 'import_playbook' in processed_ds
    assert 'vars' in processed_ds
    assert 'tags' not in processed_ds
    assert 'when' not in processed_ds
    assert not processed_ds['vars']

    ds = dict(
        import_playbook = './my-playbook.yml var1=a var2=b'
    )
    processed_ds = PlaybookInclude.preprocess_data(ds, variable_manager=None, loader=None)
    assert 'import_playbook' in processed_ds
    assert 'vars' in processed_ds


# Generated at 2022-06-21 00:59:21.532725
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO


# Generated at 2022-06-21 00:59:22.392329
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-21 00:59:27.532451
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    """
    This is a simple test to make sure the __init__ function works
    """
    playbook_include = PlaybookInclude(import_playbook='test_data/test_playbook.yaml')
    assert hasattr(playbook_include, '_import_playbook')
    assert playbook_include._import_playbook == 'test_data/test_playbook.yaml'
    assert playbook_include._vars == dict()

# Generated at 2022-06-21 00:59:39.469773
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    # prepare test data data structure
    data = AnsibleMapping()
    data.ansible_pos = {}
    data['import_playbook'] = 'test.yml'
    data['role'] = 'a_role'
    data['vars'] = {'var1': 'foo'}
    data['tags'] = ['test_tag']

    # prepare method arguments
    basedir = '/tmp'
    variable_manager = {}
    loader = AnsibleLoader(None, False, False)

    # create object under test
    import_obj = PlaybookInclude()

    #

# Generated at 2022-06-21 00:59:47.626025
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    from ansible.playbook.helpers import load_list_of_blocks
    from ansible.template import Templar
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.collection_loader._collection_finder import _get_collection_name_from_path
    import copy
    import os

    # First set of tests
    playbook_filename = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data/playbook.yml')
    test_playbook = """
    - import_playbook: '{0}'
    """.format(playbook_filename)

# Generated at 2022-06-21 00:59:59.142760
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # import to avoid a dependency loop
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    # Create PlaybookInclude object
    yaml_obj = {"include": "playbook.yml"}
    pbi = PlaybookInclude()
    pbi.load_data(yaml_obj, ".")

    # Create a valid playbook
    vars = {"tasks": []}
    playbook_obj = {"vars": vars, "tasks": [[]], "plays": [{"include": "playbook.yml"}], "format": 1}
    pb = Playbook()
    pb.load_data(playbook_obj, ".")

    # Check that calling load with a playbook returns a new Playbook object

# Generated at 2022-06-21 01:01:10.425687
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    ds = 'include_role: my_role'
    expected_ds = '- include_role: my_role'
    #raise Exception(expected_ds + ds)
    assert(PlaybookInclude.load(ds, basedir='.').dump() == expected_ds)

    ds = '- include_role: my_role'
    expected_ds = ds
    assert(PlaybookInclude.load(ds, basedir='.').dump() == expected_ds)

    ds = '- include_role: other_role'
    expected_ds = ds
    assert(PlaybookInclude.load(ds, basedir='.').dump() == expected_ds)

    ds = '- import_playbook: test_playbook.yml'
    expected_ds = ds

# Generated at 2022-06-21 01:01:22.271436
# Unit test for method preprocess_data of class PlaybookInclude

# Generated at 2022-06-21 01:01:32.124250
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():

    from ansible.module_utils._text import to_text

    path = os.path.join(os.path.dirname(__file__), 'playbooks/pb_include_test.yaml')
    playbook = PlaybookInclude(filename=path)
    assert playbook.import_playbook == "playbook.yaml"
    assert playbook.vars == dict(
        server_port=5307,
    )
    playbook_json = playbook.to_json()
    playbook_json_text = to_text(playbook_json, encoding='utf-8')
    assert playbook_json_text == '{"import_playbook": "playbook.yaml", "vars": {"server_port": 5307}}'



# Generated at 2022-06-21 01:01:36.020177
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    assert PlaybookInclude()._load_name == 'import_playbook'
    assert 'tags' not in PlaybookInclude().vars

# Generated at 2022-06-21 01:01:45.625728
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    data = {
        '- hosts: localhost': {},
        '  import_playbook: test/playbook.yml': {},
    }

    basedir = os.path.dirname(__file__)
    collection_basedir = os.path.join(basedir, 'roles', 'test_role_include_collection', 'test_role_include_ns', 'test_role_include_coll')

    pb = PlaybookInclude.load(data, basedir=collection_basedir)

    assert isinstance(pb, Playbook)
    assert len(pb._entries) == 1

    play = pb._entries[0]


# Generated at 2022-06-21 01:01:51.052935
# Unit test for method preprocess_data of class PlaybookInclude

# Generated at 2022-06-21 01:02:01.654192
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import ansible.module_utils.basic
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars import VariableManager

    # Create a fake data structure to pass to the load_data method
    ds = {'import_playbook': 'playbook.yml'}

    # Create a PlaybookInclude object and call the load_data method
    # A playbook object is created, so we need to initialize it's attributes to make it easier to test
    playbook_include = PlaybookInclude()
    playbook_include.vars = {}
    playbook_include.tags = []

    # Create a VariableManager object, load a playbook and load_data
    # An exception will be thrown if load_data fails
    variable_manager = VariableManager()
    playbook = Playbook(loader=None)
   

# Generated at 2022-06-21 01:02:12.923218
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # Create a MockPlaybook
    mock_playbook_dict = {
            'hosts': '127.0.0.1',
            'gather_facts': 'no',
            'tasks': [
                {
                    'action': {
                        'module': 'shell',
                        'args': 'ls'
                    }
                }],
            }
    mock_playbook = PlaybookInclude.load(mock_playbook_dict, '/tmp/')

    # Check the contents of the mock Playbook
    assert mock_playbook.hosts == '127.0.0.1'
    assert mock_playbook.gather_facts == 'no'

    # Check the contents of the mock Playbook's tasks
    mock_playbook_tasks = mock_playbook.tasks

# Generated at 2022-06-21 01:02:24.757027
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    import os
    from ansible.parsing.loader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()

    results = []
    results.append({"host_name": "test", "status": "ok"})

    # create a mock callback plugin
    class TestCallbackModule(object):
        def on_any(self, *args, **kwargs):
            pass

        def runner_on_ok(self, host, res):
            pass

    pb = PlaybookInclude.load(ds={}, basedir=".", variable_manager=VariableManager(), loader=loader)
    assert pb is None

    pb = PlaybookInclude.load(ds={"import_playbook": "test"}, basedir=".", variable_manager=VariableManager(), loader=loader)
    assert pb is None

# Generated at 2022-06-21 01:02:29.324899
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():

    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude

    # we'll just test a simple playbook file, to make sure it's loaded
    # correctly.
