

# Generated at 2022-06-21 00:53:30.680437
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    play = """
    - hosts: all
      gather_facts: no
      tasks:
      - debug:
          msg: before import
      - import_playbook: test.yml
      - debug:
          msg: after import
    """

    import ansible.playbook.play

    # This should not throw an exception
    obj = ansible.playbook.play.Play.load(play, variable_manager=None, loader=None)
    assert(obj.get_vars() == [])
    assert(obj.get_tasks() == [])
    assert(obj.roles == [])
    assert(obj.handlers == [])

    # This should not throw an exception
    obj = ansible.playbook.play.Play.load(play, variable_manager=None, loader=None)

# Generated at 2022-06-21 00:53:38.134271
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader


# Generated at 2022-06-21 00:53:50.669552
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.compat.tests import mock
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    pb_include = PlaybookInclude()

    with mock.patch.object(pb_include, 'load_data', autospec=True) as m_load_data:
        pb_include.load(dict(), '/tmp')
        m_load_data.assert_called_once_with(ds={}, basedir='/tmp', variable_manager=None, loader=None)

    pb = pb_include.load_data(ds={'import_playbook': 'test'}, basedir='/tmp', variable_manager=None, loader=None)
    assert isinstance(pb, Playbook)
    assert len(pb._entries) == 1

# Generated at 2022-06-21 00:53:58.174463
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    ds = {
        'import_playbook': 'foo.yml',
        'vars': {
            'hello': 'world'
        }
    }
    new_ds = AnsibleMapping()
    import_playbook = PlaybookInclude()
    result = import_playbook._preprocess_import(ds, new_ds, 'import_playbook', ds['import_playbook'])
    assert result == None
    assert new_ds['import_playbook'] == 'foo.yml'
    assert new_ds['vars']['hello'] == 'world'


# Generated at 2022-06-21 00:54:11.245152
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader
    loader = AnsibleLoader(None, 'file', data=b'')
    playbook_include = PlaybookInclude()

    # test empty dict
    data = {}
    expected_result = {}
    actual_result = playbook_include.preprocess_data(data)
    assert expected_result == actual_result

    # test empty YAML-file
    data = loader.get_single_data(b'')
    expected_result = {}
    actual_result = playbook_include.preprocess_data(data)
    assert expected_result == actual_result

    # test simple string
    data = './file'
    expected_result = {'import_playbook': './file'}

# Generated at 2022-06-21 00:54:21.797567
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    # AnsibleCollectionConfig.default_collection and AnsibleCollectionConfig.playbook_paths are loaded in every test method

    # Check to see if a new Playbook is returned
    class MyPlaybookInclude(PlaybookInclude):
        def __init__(self):
            super(MyPlaybookInclude, self).__init__()

    pb = ansible.playbook.playbook.Playbook()
    p1 = ansible.playbook.play.Play()

    pi = MyPlay

# Generated at 2022-06-21 00:54:31.880286
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    pb_data = '''
- hosts: all
  pre_tasks:
  - name: deprecated test
    debug:
      msg: "this is a test"
'''


# Generated at 2022-06-21 00:54:45.313922
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    loader = DataLoader()
    include_ds = dict(
            import_playbook='/path/to/playbook.yml',
            vars=dict(a=1),
            when=[('some_condition', 'some_value')],
            tags=['tag1', 'tag2']
        )
    pbi = PlaybookInclude.load(include_ds, '/tmp', loader=loader)
    assert isinstance(pbi, Playbook)
    assert len(pbi._entries) > 0
    assert isinstance(pbi._entries[0], Play)
    assert pbi._entries[0].vars == {'a': 1}
   

# Generated at 2022-06-21 00:54:49.517335
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import os
    import sys

    # Fix basepath when running as installation test
    ansible_base_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    if not os.path.exists(ansible_base_path):
        ansible_base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    # fix basepath when running from source tree

# Generated at 2022-06-21 00:54:59.945840
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    """
    check method PlaybookInclude.load_data()
    """
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import vars_loader
    from ansible.utils.collection_loader import AnsibleFileLoader
    from ansible.utils.collection_loader import AnsibleFileIncludeLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    basedir = os.path.join(C.DEFAULT_LOCAL_TMP, 'inventory')
    inventory = InventoryManager(loader=AnsibleFileLoader('/dev/null'), sources=['localhost', ':memory:'])
    variable_manager = VariableManager()
    variable_manager._

# Generated at 2022-06-21 00:55:14.330883
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import ansible.playbook.playbook_include
    playbook_include = ansible.playbook.playbook_include.PlaybookInclude()

    # test playbook_include.preprocess_data(ds)
    # ds is not a dict
    ds = 'hoge'
    try:
        playbook_include.preprocess_data(ds)
    except Exception as e:
        assert isinstance(e, AnsibleAssertionError)
        assert str(e) == 'ds (hoge) should be a dict but was a %s' % type(ds)

    # ds is a dict
    ds = {'import_playbook': 'playbook.yml'}
    new_ds = playbook_include.preprocess_data(ds)
    assert isinstance(new_ds, AnsibleMapping)
    assert new

# Generated at 2022-06-21 00:55:21.572654
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping


# Generated at 2022-06-21 00:55:33.127468
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    pi = PlaybookInclude.load({}, basedir='/tmp')
    assert pi.import_playbook is None
    assert pi.vars == {}

    pi = PlaybookInclude.load({'import_playbook': 'foo.yml'}, basedir='/tmp')
    assert pi.import_playbook == 'foo.yml'
    assert pi.vars == {}


# Generated at 2022-06-21 00:55:33.618065
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-21 00:55:42.356092
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pbi = PlaybookInclude({'import_playbook': '/path/to/file.yml'})
    assert pbi.import_playbook == '/path/to/file.yml'
    pbi = PlaybookInclude({'import_playbook': '/path/to/file.yml', 'tags': 'tag1,tag2'})
    assert pbi.import_playbook == '/path/to/file.yml'
    assert pbi.tags == ['tag1', 'tag2']
    pbi = PlaybookInclude({'import_playbook': '/path/to/file.yml', 'tags': 'tag1,tag2', 'vars': {'var1': 'val1', 'var2': 'val2'}})

# Generated at 2022-06-21 00:55:52.688378
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook

    pbi1 = PlaybookInclude()
    pbi2 = pbi1.load(data={'import_playbook': 'some-file.yml'}, basedir='/some/basedir')
    assert isinstance(pbi2, Playbook)
    assert pbi2._entries[0]._included_path == '/some/basedir'
    assert pbi2._entries[0]._included_file == 'some-file.yml'

    # relative paths from subdirectories are ok as well
    pbi3 = pbi1.load(data={'import_playbook': '../some-file.yml'}, basedir='/some/basedir')
    assert isinstance(pbi3, Playbook)

# Generated at 2022-06-21 00:56:00.062195
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    import_playbook = "../test_import.yml"
    obj = {'import_playbook': import_playbook}

    playbook_include = PlaybookInclude()
    playbook = playbook_include.load_data(obj, ".")

    assert playbook is not None
    assert isinstance(playbook, Playbook)
    assert len(playbook._entries) == 1
    assert isinstance(playbook._entries[0], Play)
    assert playbook._entries[0].name == "Test Play"
    assert playbook._entries[0]._included_path is not None


# Generated at 2022-06-21 00:56:02.702325
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    ds = dict(
        import_playbook='./playbook.yml',
    )
    result = PlaybookInclude.load(ds, '')
    assert(result)

# Generated at 2022-06-21 00:56:12.871347
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    
    def assert_data_structure(data, result):
        data_structure = PlaybookInclude.load(data)
        assert data_structure == result
    
    data = dict(
        include="test/test.yml",
        vars=dict(
            key="test"
        )
    )
    result = dict(
        import_playbook="test/test.yml",
        vars=dict(
            key="test"
        )
    )
    assert_data_structure(data, result)
    
    data = dict(
        include="test/test.yml"
    )
    result = dict(
        import_playbook="test/test.yml"
    )
    assert_data_structure(data, result)
    

# Generated at 2022-06-21 00:56:23.710449
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    _ds = {
        "import_playbook": "external.yml anotherparam=foo third_param=hello world",
        "vars": {
            "somevar": "somevalue"
        },
        "tags": "foo,bar",
        "when": "ansible_os_family == 'RedHat'"
    }
    _ds_obj = AnsibleUnicode("""
---
import_playbook: external.yml anotherparam=foo third_param=hello world
vars:
  somevar: somevalue
tags:
- foo
- bar
when: ansible_os_family == 'RedHat'
""")
    _ds_obj.ansible_pos = (1, 1)

# Generated at 2022-06-21 00:56:37.984328
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    PlaybookInclude(dict(import_playbook='/console/console.yml'))
    PlaybookInclude(dict(import_playbook='/console/console.yml', vars={"var1": "value1"}))
    PlaybookInclude(dict(import_playbook='/console/console.yml', vars={"var1": "value1"}, when="value1 == 'value2'"))

# Generated at 2022-06-21 00:56:51.267995
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    import json
    import sys

    # initialize
    ds = dict()
    ds['import_playbook'] = "playbook_include_playbook.yml"
    ds['vars'] = dict()
    ds['vars']['playbook_include_playbook_role_var1'] = "playbook_include_playbook_role_value1"
    ds['vars']['playbook_include_playbook_role_var2'] = "playbook_include_playbook_role_value2"
    ds['vars']['playbook_include_playbook_role_tasks_var1'] = "playbook_include_playbook_role_tasks_value1"

# Generated at 2022-06-21 00:56:52.672535
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass


# Generated at 2022-06-21 00:57:02.017379
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    ds1 = dict(import_playbook='tasks.yml')
    playbook_include = PlaybookInclude()
    pd = playbook_include.preprocess_data(ds1)
    assert pd == dict(import_playbook='tasks.yml')

    ds2 = dict(include='others/tasks.yml')
    pd = playbook_include.preprocess_data(ds2)
    assert pd == dict(import_playbook='others/tasks.yml')

    ds3 = dict(import_playbook='tasks.yml', tags='test')
    pd = playbook_include.preprocess_data(ds3)
    assert pd == dict(import_playbook='tasks.yml', tags='test')


# Generated at 2022-06-21 00:57:10.402680
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    from ansible.playbook.play import Play

    # Create an import ds with legacy format and parameters
    ds = AnsibleMapping({'import_playbook': 'my_playbook.yml', 'tags': ['this', 'that']})
    ds.ansible_pos = (2, 3)

    # Create a new PlaybookInclude using the legacy format ds.
    n = PlaybookInclude()
    p = n.preprocess_data(ds)

    # Verify the ds converted to the new format.
    assert p['import_playbook'] == 'my_playbook.yml'
    assert p['tags'] == ['this', 'that']
    assert p['vars'] == {}
    assert ds.ansible_pos == (2, 3)

    # Create an include ds with a vars entry

# Generated at 2022-06-21 00:57:12.185167
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # Instantiate class
    PlaybookInclude()

# Generated at 2022-06-21 00:57:19.464580
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    data = 'testdata/playbook_include.yml'
    basedir = '.'
    variable_manager = None
    loader = None

    PB = PlaybookInclude.load(data, basedir, variable_manager, loader)
    assert PB.import_playbook == "foo.yml"
    assert PB.vars["a"] == "b"

# Generated at 2022-06-21 00:57:32.613669
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play

    pbi = PlaybookInclude()

    ds = dict(
        import_playbook = 'file.yml',
        tags = 'tag1,tag2',
        vars = dict(
            var1 = 'val1',
            var2 = 'val2'
        ),
        conditional = dict(
            when = dict(
                condition = "true"
            )
        )
    )
    expected_ds = dict(
        import_playbook = 'file.yml',
        tags = ['tag1', 'tag2'],
        when = dict(
            condition = "true"
        ),
        vars = dict(
            var1 = 'val1',
            var2 = 'val2'
        )
    )
    new_ds = pbi.pre

# Generated at 2022-06-21 00:57:34.582062
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # TODO: write test
    pass

# Generated at 2022-06-21 00:57:35.978800
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass



# Generated at 2022-06-21 00:57:49.328652
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    playbook = Playbook()
    # playbook._entries = [Play()]
    playbook._entries = []
    new_obj = PlaybookInclude()

    # tested method call
    playbook = new_obj.load(data={'import_playbook': 'playbook.yml'}, basedir='/dev/null',
                            variable_manager=VariableManager(), loader=None)

    # check for properties values
    # if len(playbook._ent

# Generated at 2022-06-21 00:57:57.579061
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager

    p = PlaybookInclude()

# Generated at 2022-06-21 00:58:02.367085
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include = PlaybookInclude()

    # Case 1 - missing playbook
    ds = dict(
        tags=['t1', 't2'],
        when='x > y'
    )
    try:
        playbook_include.preprocess_data(ds)
        assert False, "Test case 1 failed"
    except AnsibleParserError:
        pass

    # Case 2 - playbook is not a string
    ds = dict(
        import_playbook=123,
        tags=['t1', 't2'],
        when='x > y'
    )
    try:
        playbook_include.preprocess_data(ds)
        assert False, "Test case 2 failed"
    except AnsibleParserError:
        pass

    # Case 3 - wrong vars type

# Generated at 2022-06-21 00:58:15.701405
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    import os

    # Test playbook include
    playbook_include = PlaybookInclude()
    playbook_include.vars = dict()
    playbook_include.tags = list()

    # Test playbook include with bad data...
    try:
        playbook_include.load_data(ds=None, basedir=".")
    except AnsibleParserError:
        pass
    else:
        print("Unit test failed")
        return 1
    try:
        playbook_include.load_data(ds="", basedir=".")
    except AnsibleParserError:
        pass
    else:
        print("Unit test failed")
        return 1
    try:
        playbook_include.load_data(ds=0, basedir=".")
    except AnsibleParserError:
        pass
    else:
        print("Unit test failed")
        return 1

   

# Generated at 2022-06-21 00:58:27.403571
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    playbook = "test_playbook_include.yml"
    fake_ds = dict(import_playbook="playbook.yml", tags="bar", vars=dict(foo="foovalue"))

    pb_include = PlaybookInclude.load(fake_ds, "/tmp", None, None)

    # returns Playbook object
    assert isinstance(pb_include, Playbook)

    # it should be an array with only 1 entry
    assert len(pb_include._entries) == 1
    assert isinstance(pb_include._entries[0], Play)

    # it should be the entry from the imported file
    assert pb_include._entries[0].name == "test_play"

# Generated at 2022-06-21 00:58:39.770860
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    '''
    test_PlaybookInclude_preprocess_data ensures PlaybookInclude.preprocess_data
    loads playbook data correctly
    '''
    import os

    from ansible.playbook.play import Play

    # test returns correct value for new_ds
    pb = PlaybookInclude()
    ds = AnsibleMapping(dict(
        import_playbook=u"test/test_playbook_include.yml",
        tags=u"test_tags",
        vars=dict(hosts=u"test_hosts"),
        when=u"ansible_os_family == 'RedHat'"
    ))

    new_ds = pb.preprocess_data(ds)
    assert isinstance(new_ds, AnsibleMapping)


# Generated at 2022-06-21 00:58:48.660287
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    
    # import_playbook test
    playbook_include = PlaybookInclude()
    playbook_include.load_data({'import_playbook': './test/test_playbook_import.yml'})
    assert playbook_include.import_playbook == './test/test_playbook_import.yml'
    playbook_include.load_data({'import_playbook': './test/test_playbook_import.yml', 'vars': {'var_name': 'var_value'}})
    assert playbook_include.vars['var_name'] == 'var_value'

    # preprocess_data test
    playbook_include = PlaybookInclude()

# Generated at 2022-06-21 00:58:52.917437
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    new_ds = {
        'import_playbook': 'test.yml',
        'vars': {
            'name': 'test',
            'ansible_connection': 'local'
        }
    }
    old_ds = ds = {
        'include': 'test.yml',
        'vars': {
            'name': 'test',
            'ansible_connection': 'local'
        }
    }
    assert PlaybookInclude.preprocess_data(ds) == new_ds

    old_ds = ds = {
        'include': 'test.yml',
        'vars': {
            'name': 'test',
            'ansible_connection': 'local'
        },
        'tags': ['foo', 'bar']
    }
    assert PlaybookInclude.preprocess_

# Generated at 2022-06-21 00:59:00.612521
# Unit test for constructor of class PlaybookInclude

# Generated at 2022-06-21 00:59:08.729036
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook import Playbook, Play

    yaml_str = "---\n- import_playbook: foo.yml\n"
    yaml_str += "  vars:\n"
    yaml_str += "    a: b\n"
    yaml_str += "  tags: c,d\n"
    ds = yaml.load(yaml_str)
    print(ds)
    pbi = PlaybookInclude.load(ds, basedir="/home/ansible/test")
    print(pbi)
    assert isinstance(pbi, Playbook)
    assert isinstance(pbi._entries[0], Play)

# Generated at 2022-06-21 00:59:15.515345
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-21 00:59:24.320024
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    yml_data = '''---
- imports: 
  -playbook: "playbook1.yml"
  -playbook: "playbook2.yml"
    tags: tag1,tag2
    vars: 
      user: root
'''
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.utils.path import unfrackpath

    # print(yml_data)
    data = AnsibleLoader(yml_data, vault_password=VaultLib.DEFAULT_VAULT_ID).get_single_data()
    # print

# Generated at 2022-06-21 00:59:38.155158
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    import ansible.playbook.play

    basedir = "/path/to/playbook/collection"
    playbook = "playbook.yaml"

    t = PlaybookInclude()
    t._load_playbook_data(file_name=playbook, basedir=basedir)
    assert(t._include == None)

    t = PlaybookInclude()
    t._import_playbook = "test.yml"
    t._load_playbook_data(file_name=playbook, basedir=basedir)
    assert(isinstance(t._include, ansible.playbook.play.Playbook))

    t = PlaybookInclude()
    t._import_playbook = "test.yml"
    t._vars = {"var1": "1", "var2": "2"}
    t._load_

# Generated at 2022-06-21 00:59:47.204244
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # Test with proper parameters (vars as dict)
    pi = PlaybookInclude()
    ds = {'import_playbook': 'some_name', 'vars': {'foo': 'bar'}}
    pi.preprocess_data(ds)
    print(ds)
    assert ds['vars'] == {'foo': 'bar'}

    # Test with proper parameters (vars as dict) but also
    # with other k=v parameters where k is a string
    pi = PlaybookInclude()
    ds = {'import_playbook': 'some_name', 'vars': {'foo': 'bar'}, 'tags': 'untagged'}
    pi.preprocess_data(ds)
    print(ds)
    assert ds['vars'] == {'foo': 'bar'}

    # Test

# Generated at 2022-06-21 00:59:48.322129
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-21 00:59:59.843150
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Load empty PlaybookInclude
    t = PlaybookInclude()
    expected_result = {'import_playbook': '', 'tags': '', 'vars': {}}
    assert t.preprocess_data({}) == expected_result, "Unexpected result: %s" % (t.preprocess_data({}))
    # Load import_playbook without parameters
    t = PlaybookInclude()
    expected_result = {'import_playbook': '/some/path/some_playbook.yml', 'tags': '', 'vars': {}}

# Generated at 2022-06-21 01:00:08.502398
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    pbi = PlaybookInclude()
    ds = {'import_playbook': "../../../../../../../../etc/passwd"}
    new_ds = pbi.preprocess_data(ds)
    assert new_ds == {'import_playbook': "../../../../../../../../etc/passwd"}

    ds = {'include_playbook': "../../../../../../../../etc/passwd"}
    new_ds = pbi.preprocess_data(ds)
    assert new_ds == {'import_playbook': "../../../../../../../../etc/passwd"}

    ds = {'import_playbook': "../../../../../../../../etc/passwd", 'vars': {'somevar': "somevalue"}}
    new_ds = pbi.pre

# Generated at 2022-06-21 01:00:20.027594
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os
    import sys
    import unittest

    from ansible.module_utils._text import to_bytes, to_text

    import ansible.constants as C

    class TestPlaybookInclude(unittest.TestCase):
        def setUp(self):
            self.loader = DictDataLoader({
                u'roles/foo/main.yml': u'---\n- hosts: all\n  tasks:\n    - debug: msg="Foo"',
                # create a file in a subdir of the playbook to test the edge case where we're not dealing with a full collection name
                u'roles/foo/tasks/print.yml': u'some_var: "{{ print_var }}"',
            })


# Generated at 2022-06-21 01:00:30.820870
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    imp_playbook = PlaybookInclude()
    data_one = dict(import_playbook='ab')
    data_one['vars'] = dict(a='b')
    data_one['tags'] = 'abc'
    data_one['when'] = 'abc'
    imp_playbook.load_data(data_one)
    assert imp_playbook.import_playbook == 'ab'
    assert imp_playbook.vars == dict(a='b')
    assert imp_playbook.tags == ['abc']
    assert imp_playbook.when == ['abc']

    data_two = dict(import_tasks='cd')
    imp_playbook.load_data(data_two)
    assert imp_playbook.import_playbook == 'cd'


# Generated at 2022-06-21 01:00:41.738417
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    p = PlaybookInclude()
    assert p.import_playbook == None
    assert p.vars == dict()

    p = PlaybookInclude(import_playbook='/some/path', tags=['tag1','tag2'], vars=dict(foo='bar', baz=dict(x='y')))
    assert p.import_playbook == '/some/path'
    assert p.vars == dict(foo='bar', baz=dict(x='y'))
    assert p.tags == ['tag1', 'tag2']

    p = PlaybookInclude(import_playbook='some_file', tags=['tag3'], vars=dict(foo='baz'))
    assert p.import_playbook == 'some_file'
    assert p.vars == dict(foo='baz')
   

# Generated at 2022-06-21 01:00:48.762446
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    variable_manager = 'something'
    loader = 'something_else'
    pass

# Generated at 2022-06-21 01:01:00.407077
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible import playbook
    from ansible.parsing.dataloader import DataLoader
    from ansible.variable_manager import VariableManager

    loader = DataLoader()

    def _create_play(name=None, spec=None, variable_manager=None, loader=None):
        return playbook.Playbook().load(name, variable_manager=variable_manager, loader=loader, use_handlers=False,
                                        task_blocks=[spec.strip().split('\n')])

    p = PlaybookInclude()
    p.import_playbook = 'vars.yml'

    pb = p.load_data(dict(import_playbook='vars.yml'), loader=loader, variable_manager=VariableManager())
    assert isinstance(pb, playbook.Playbook)

# Generated at 2022-06-21 01:01:09.041741
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    yaml_ds = dict(
        import_playbook = 'playbook.yml',
        vars            = dict(a=1, b=2),
        when            = "inventory_hostname == 'foo'",
        tags            = ['t1', 't2'],
    )
    pl = PlaybookInclude.load(yaml_ds, '/path/to/here')
    assert pl.import_playbook == 'playbook.yml', pl.import_playbook
    assert pl.vars == dict(a=1, b=2), pl.vars

# Generated at 2022-06-21 01:01:10.504909
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass


# Generated at 2022-06-21 01:01:13.731697
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pb = PlaybookInclude()
    assert isinstance(pb, PlaybookInclude)

# Generated at 2022-06-21 01:01:14.720924
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    test_include = PlaybookInclude()
    assert test_include._import_playbook is None
    assert test_include._vars == {}

# Generated at 2022-06-21 01:01:25.706350
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    class MockVariableManager:
        def __init__(self, vars):
            self.vars = vars
            self.omit_token = None

        def get_vars(self, loader=None, play=None, task=None, include_hostvars=True, include_delegate_to=True, use_cache=True):
            return self.vars

    class MockLoader:
        def __init__(self):
            self.omit_token = None

    mock_variable_manager = MockVariableManager({
        "vars": {
            "add1": "hello",
            "add2": "world"
        }
    })

    # Test case when ds is not a dict
    from ansible.playbook.playbook_include import PlaybookInclude
    playbook_include = PlaybookInclude()


# Generated at 2022-06-21 01:01:33.373644
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # If a constructor receives a non-dict object
    assert_raises(AnsibleAssertionError, PlaybookInclude.load, 1, '.')

    # If a constructor receives a dict object
    # which misses 'import_playbook' key
    data = {'vars': {}}
    assert_raises(AnsibleParserError, PlaybookInclude.load, data, '.')

    # If a constructor receives a dict object
    # which has invalid 'vars' value
    data = {'import_playbook': 'test_import'}
    data['vars'] = 'test'
    assert_raises(AnsibleParserError, PlaybookInclude.load, data, '.')

    # If a constructor receives a dict object
    # which has invalid 'tags' value

# Generated at 2022-06-21 01:01:35.132012
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    """
    For load_data method of class PlaybookInclude,
    """
    pass

# Generated at 2022-06-21 01:01:46.954948
# Unit test for method load_data of class PlaybookInclude

# Generated at 2022-06-21 01:02:03.572119
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    from ansible.playbook.playbook_include import PlaybookInclude

    # testing data
    playbook_data = AnsibleMapping()
    playbook_data['import_playbook'] = 'p1.yml'
    playbook_data['tags'] = 't1'
    playbook_data['vars'] = dict(a='a1', b='b1')

    # method under test
    playbook_include = PlaybookInclude()
    result = playbook_include.preprocess_data(playbook_data)

    # asserts
    assert(result['import_playbook'] == 'p1.yml')
    assert(result['tags'] == ['t1'])
    assert(result['vars'] == {'a': 'a1', 'b': 'b1'})


# Generated at 2022-06-21 01:02:13.607299
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible import constants as C
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    test_playbook_import = dict(
        import_playbook = "./test_import.yml",
        vars = dict(x=1, y=2),
        tags = ['a', 'b', 'c'],
        when = 'ansible_distribution == "OpenBSD"'
    )

    display.verbosity = 3
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory_manager = InventoryManager(loader=loader, sources=C.DEFAULT_HOST_LIST)
    variable_manager.set_inventory(inventory_manager)

    new_pb_obj = PlaybookInclude.load

# Generated at 2022-06-21 01:02:24.283684
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext(variable_manager=variable_manager)

    ds = {
        'import_playbook': 'basic.yml'
    }
    PlaybookInclude.load(ds=ds, basedir='.', variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-21 01:02:29.787434
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    """
    Test creation of PlaybookInclude objects.
    """
    a = PlaybookInclude()
    assert a.import_playbook is None
    assert a.vars == dict()
    a = PlaybookInclude(import_playbook='foo/bar', vars={'baz':'boo'})
    assert a.import_playbook == 'foo/bar'
    assert a.vars['baz'] == 'boo'

# Generated at 2022-06-21 01:02:41.257630
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    def_vars = dict()

    # Unit test case 1: Calling the constructor
    data = dict(import_playbook='abc.yml', tags=['apple', 'banana'], vars=dict())
    pbi = PlaybookInclude()
    pbi.load_data(data, basedir='.', variable_manager=None, loader=None)
    assert(pbi.import_playbook == 'abc.yml')
    assert(pbi.vars == def_vars)
    assert(pbi.tags == ['apple', 'banana'])

    # Unit test case 2: Calling the constructor with empty vars and empty tags
    data = dict(import_playbook='abc.yml', vars=dict(), tags=[])
    pbi = PlaybookInclude()

# Generated at 2022-06-21 01:02:44.675968
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    playbook_include = PlaybookInclude()
    assert playbook_include.import_playbook is ""
    assert playbook_include.vars == {}

# Generated at 2022-06-21 01:02:53.582520
# Unit test for method load of class PlaybookInclude

# Generated at 2022-06-21 01:02:54.860210
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-21 01:03:04.219095
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.block
    yaml_text ='''
- import_playbook: playbook/test.yml
'''

    # Need to implement a playbook and a play including a task and a block
    playbook = ansible.playbook.Playbook.load(yaml_text, variable_manager=None, loader=None)
    play = ansible.playbook.play.Play()
    play._load_data(playbook._entries[0])
    assert isinstance(play, ansible.playbook.play.Play)
    assert isinstance(play.get_tasks()[0], ansible.playbook.task.Task)