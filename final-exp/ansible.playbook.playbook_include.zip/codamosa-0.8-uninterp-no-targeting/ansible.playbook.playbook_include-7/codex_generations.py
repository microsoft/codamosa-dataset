

# Generated at 2022-06-21 00:53:24.846447
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    ds = {'import_playbook': 'common.yml'}
    p = PlaybookInclude()
    new_ds = p.preprocess_data(ds)
    assert len(new_ds) == 1
    assert new_ds['import_playbook'] == 'common.yml'

    ds = {'import_playbook': 'common.yml', 'some_thing': 'some_value'}
    p = PlaybookInclude()
    new_ds = p.preprocess_data(ds)
    assert len(new_ds) == 2
    assert new_ds['import_playbook'] == 'common.yml'
    assert new_ds['some_thing'] == 'some_value'

# Generated at 2022-06-21 00:53:33.897253
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    # this is the test data
    playbooks_data = """
- import_playbook: playbook1.yml
- import_playbook: playbook2.yml
- import_playbook: playbook3.yml
"""
    # this is the expected result
    playbooks_expected = [PlaybookInclude(), PlaybookInclude(), PlaybookInclude()]
    playbooks_expected[0].load_data(dict(import_playbook='playbook1.yml'), basedir='test/data/playbooks')
    playbooks_expected[1].load_data(dict(import_playbook='playbook2.yml'), basedir='test/data/playbooks')
    playbooks

# Generated at 2022-06-21 00:53:46.174674
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.yaml.objects import AnsibleSequence

    import_playbook_data_1 = {'import_playbook': './test/test_playbook.yml', 'vars': {'ab_var' : 'ab_value'}}
    import_playbook_1 = PlaybookInclude(import_playbook_data_1)
    load_data_from_import_playbook_1 = import_playbook_1.load_data(import_playbook_data_1, '.')

    assert isinstance(load_data_from_import_playbook_1, RoleDefinition) is False
    assert isinstance(load_data_from_import_playbook_1, AnsibleSequence) is False

# Generated at 2022-06-21 00:53:57.177783
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    class Test1:
        def load_data(self, ds, variable_manager, loader):
            return super(PlaybookInclude, self).load_data(ds, variable_manager, loader)
        def preprocess_data(self, ds):
            return super(PlaybookInclude, self).preprocess_data(ds)
        def preprocess_safe_atime(self, ds):
            return super(PlaybookInclude, self).preprocess_data(ds)
    class Test2:
        def __init__(self):
            self.entries = [Play()]

    basedir = "ansible/playbooks/"
    variable_manager = None
    loader = None


# Generated at 2022-06-21 00:54:09.971591
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
  playbook = PlaybookInclude()

  ds = AnsibleMapping()
  ds['import_playbook'] = 'some_playbook.yml'
  ds['tags'] = 'do_something'
  ds['vars'] = {}
  ds['vars']['hello'] = 'world'
  ds['vars']['foo'] = 'bar'

  new_ds = playbook.preprocess_data(ds)
  assert('import_playbook' in new_ds)
  assert(new_ds['import_playbook'] == 'some_playbook.yml')
  assert('tags' in new_ds)
  assert(new_ds['tags'] == 'do_something')
  assert('vars' in new_ds)

# Generated at 2022-06-21 00:54:20.944902
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.block import Block

    p = PlaybookInclude()

    # Test the case of a dict datastructure
    test_ds = AnsibleMapping()
    test_ds['import_playbook'] = 'test.yml'
    test_ds['vars'] = AnsibleMapping()
    test_ds['vars']['var1'] = 'value1'
    test_ds['vars']['var2'] = 'value2'
    test_ds['vars']['var3'] = 'value3'
    test_ds['tags'] = 'tag1,tag2'

# Generated at 2022-06-21 00:54:24.983061
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    import_playbook_obj = PlaybookInclude()
    assert(import_playbook_obj.import_playbook == '')
    assert(import_playbook_obj.vars == {})

# Generated at 2022-06-21 00:54:34.738232
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # This test checks if the method: preprocess_data of class: PlaybookInclude is working
    # as expected. The preprocess_data method should transform any input data structure
    # into a standard structure which is expected by the class in its attribute.

    # Arrange
    playbook_include = PlaybookInclude()

    # Assert
    # There are two main branches of the preprocess_data method.
    # 1) When the playbook_include object is not a dict type, it should raise
    #    an AnsibleAssertionError.
    # 2) If the playbook_include object is a dict type, it should return
    #    a new AnsibleMapping object after calling the super class method
    #    preprocess_data.
    #
    # This first test checks the first branch, which is when the input object is a string type.

# Generated at 2022-06-21 00:54:48.167990
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # TODO: Write unit-tests for method load_data of class PlaybookInclude

    # check that get_collection_playbook_path() returns None in case of empty string
    if not _get_collection_playbook_path('') is None:
        raise AssertionError('Failed to check for empty string!')

    # check that get_collection_playbook_path() returns None in case of non existing FQCN
    if not _get_collection_playbook_path('does.not.exist') is None:
        raise AssertionError('Failed to check for non existing FQCN!')

    # check that get_collection_name_from_path() returns None in case of empty string

# Generated at 2022-06-21 00:54:59.639785
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.playbook.task import Task
    import ansible.constants as C

    ds = {}
    ds['import_playbook'] = "../../test/integration/import_playbook_test/success/success.yml"
    ds['vars'] = { 'x' : 2 }
    ds['tags'] = ['test1', 'test2']
    ds['when'] = "ansible_os_family == 'RedHat'"

    pi = PlaybookInclude()
    pb = pi.load_data(ds, './', None)

    assert isinstance(pb, Playbook)
    assert len(pb._entries) == 1

    entry = pb._entries[0]
   

# Generated at 2022-06-21 00:55:16.619362
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # import here to prevent cyclical import
    from ansible.playbook import Playbook


# Generated at 2022-06-21 00:55:30.685843
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import os
    import tempfile

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook

    loader = DataLoader()

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'inventory_dir': './tests/inventory',
                                   'inventory_file': './tests/inventory/hosts.yml',
                                   'playbook_dir': './',
                                   'name': 'test'}

    inventory = Inventory(loader, variable_manager, 'localhost')
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-21 00:55:41.500723
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # test verifies agains a normal v1 playbook import
    data = "playbook.yml"
    data_ds = { 'playbook': data }
    result_ds = PlaybookInclude().preprocess_data(data_ds)
    assert result_ds['import_playbook'] == data
    assert result_ds['vars'] == {}

    # test verifies agains a normal v2 playbook import (with one parameter)
    data = "playbook.yml parameter1=value1"
    data_ds = { 'import_playbook': data }
    result_ds = PlaybookInclude().preprocess_data(data_ds)
    assert result_ds['import_playbook'] == "playbook.yml"
    assert result_ds['vars'] == { 'parameter1': 'value1' }

    # test

# Generated at 2022-06-21 00:55:52.866870
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    import os
    from ansible.errors import AnsibleParserError

    ds = dict(
        import_playbook=None,
        tags=None,
        vars=None,
    )

    # try incorrect type
    try:
        PlaybookInclude.load(ds=3, basedir=None)
        assert False, "should be unreachable"
    except AnsibleParserError:
        pass

    # try incorrect type
    try:
        PlaybookInclude.load(ds=3, basedir=None)
        assert False, "should be unreachable"
    except AnsibleParserError:
        pass

    # try incorrect import path

# Generated at 2022-06-21 00:56:00.617072
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # create instance of PlaybookInclude so we have access to its method preprocess_data
    # we need to pass in a loader so we can load the playbooks,
    # data_loader is already in scope from conftest.py
    p = PlaybookInclude()
    # pb_incl = p.load_data(ds=dict(include='../../../lib/ansible/playbook/__init__.py', vars=dict(options=dict(foo='bar'))), basedir='.', loader=data_loader)
    pb_incl = p.load_data(ds=dict(include='../../../lib/ansible/playbook/__init__.py', vars={'options': {'foo': 'bar'}}), basedir='.', loader=data_loader)

# Generated at 2022-06-21 00:56:01.478315
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pass

# Generated at 2022-06-21 00:56:12.437203
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.parsing.yaml.loader import AnsibleLoader
    data = '''
        - import_playbook: include_me.yml
          vars:
            var_name: "var_value"
          tags:
            - tag1
    '''
    data = AnsibleLoader(data).get_single_data()
    play = PlaybookInclude(data, variable_manager=None, loader=None)
    assert play.import_playbook == 'include_me.yml'
    assert play.vars == {'var_name': 'var_value'}
    assert 'tag1' in play.tags

# Generated at 2022-06-21 00:56:20.834166
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Play
    basedir = os.getcwd()
    loader = MockDataLoader()
    variable_manager = MockVariableManager()
    p1 = PlaybookInclude.load(dict(import_playbook='test_playbook_include.yml'), basedir, variable_manager, loader)
    assert(isinstance(p1, Play))
    assert(len(p1.vars) == 1)
    assert(p1.tags == ['test_playbook_include_tag'])
    assert(p1.name == 'test_playbook_include')


# Generated at 2022-06-21 00:56:27.462496
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    args = {'import_playbook': 'abc.yaml', 'vars': {'var1': 'value1'}}
    obj = PlaybookInclude(**args)
    assert obj._import_playbook == 'abc.yaml'
    assert obj._vars == {'var1': 'value1'}

# Generated at 2022-06-21 00:56:40.317229
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.parsing.dataloader import DataLoader

    ds = dict(
      import_playbook = "../test_play.yml",
      tags = [ "tag1", "tag2" ],
      vars = dict(
        foo = "bar",
        blip = dict(
          wibble = "wobble",
        ),
      ),
    )
    ds = PlaybookInclude.load(ds, '/path', DataLoader())

    assert 'import_playbook' in ds.data
    assert 'tags' in ds.data
    assert 'vars' in ds.data
    assert ds.import_playbook == '../test_play.yml'
    assert ds.tags == [ "tag1", "tag2" ]
    assert ds.vars['foo']

# Generated at 2022-06-21 00:56:54.274712
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    import os, sys
    sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', '..', 'lib'))
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.inventory.manager import InventoryManager


# Generated at 2022-06-21 00:57:03.263970
# Unit test for method preprocess_data of class PlaybookInclude

# Generated at 2022-06-21 00:57:14.606697
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    yaml_ds = dict(
        import_playbook='tests/import_play_1.yml',
        connection='local',
        sudo='yes',
        sudo_user='root'
    )

    new_pb = PlaybookInclude().load(yaml_ds)

    for k in ['connection', 'sudo', 'sudo_user']:
        assert getattr(new_pb, k) == yaml_ds[k]
    assert new_pb.import_playbook == yaml_ds['import_playbook']

    # Make sure vars get in there based on legacy params
    yaml_ds = dict(
        import_playbook='tests/import_play_1.yml connection=local sudo=yes sudo_user=root'
    )

    new_pb = PlaybookInclude().load(yaml_ds)

# Generated at 2022-06-21 00:57:15.486856
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-21 00:57:26.729252
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook = PlaybookInclude()

    # test when playbook parameter is not specified
    with pytest.raises(AnsibleParserError):
        playbook.load_data([], ".")

    # test when playbook parameter is None
    with pytest.raises(AnsibleParserError):
        playbook.load_data({"import_playbook": None}, ".")

    # test when playbook parameter is not a string
    with pytest.raises(AnsibleParserError):
        playbook.load_data({"import_playbook": ['playbook.yaml']}, ".")

    # test when playbook parameter does not contains file name
    with pytest.raises(AnsibleParserError):
        playbook.load_data({"import_playbook": ' '}, ".")


# Generated at 2022-06-21 00:57:38.095893
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Sample input data
    ds = dict(
        import_playbook='/home/testuser/playbook.yml',
        connection='local',
        gather_facts='yes',
        vars=dict(a=10, b=True, c='test')
    )

    import tempfile
    basedir = tempfile.gettempdir()
    pb_include = PlaybookInclude().load_data(ds=ds, basedir=basedir)
    pb = pb_include.load(data=None, basedir=basedir)
    assert len(pb._entries) == 1
    assert pb._entries[0].vars == dict(a=10, b=True, c='test')
    assert pb._entries[0].connection == 'local'

# Generated at 2022-06-21 00:57:45.289403
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Test dictionary

# Generated at 2022-06-21 00:57:46.708172
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass


# Generated at 2022-06-21 00:57:56.612567
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    import os
    import tempfile
    from ansible.playbook.play import Play
    from ansible.playbook.base import Base
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultLib

    # Make tmp dir
    tmp_dir = tempfile.mkdtemp()

    # Create vault password file
    open(os.path.join(tmp_dir, '.vault_pass'), 'wb').write(VaultLib.encrypt_string(VaultLib(), 'secret'))

    # Create playbook
    test_file = os.path.join(tmp_dir, 'test.yml')

# Generated at 2022-06-21 00:58:07.210400
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    '''
    PlaybookInclude.preprocess_data test
    '''
    data = {
        'import_playbook': 'test.yml',
        'tags':           'test-tag',
        'vars': {
            'var1': 'test1',
        },
        'when':           'test_when',
    }

    # Validate that the preprocess_data method will not throw an exception
    playbook_include = PlaybookInclude.load(data, '.', variable_manager=None)

    # Validate that the data is as expected
    assert playbook_include
    assert playbook_include.import_playbook == 'test.yml'
    assert playbook_include.tags == ['test-tag']
    assert playbook_include.when == ['test_when']

# Generated at 2022-06-21 00:58:26.869114
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import sys

    sys.argv = ['ansible-playbook', '--extra-vars', '@/tmp/test_vars.yml']
    obj = PlaybookInclude.load({'import_playbook': '/tmp/testfile.yml'}, '/tmp', None)
    assert obj.import_playbook == '/tmp/testfile.yml'
    assert obj.tags is None

    obj = PlaybookInclude.load({'import_playbook': '/tmp/testfile.yml tags=tag1,tag2'}, '/tmp', None)
    assert obj.import_playbook == '/tmp/testfile.yml'
    assert obj.tags == 'tag1,tag2'


# Generated at 2022-06-21 00:58:34.173615
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    yaml_str = """
    - name: Test PlaybookInclude
      import_playbook: include_play.yml
    """
    playbook_include = PlaybookInclude.load(yaml_str, '.', None, None)
    assert playbook_include.import_playbook == 'include_play.yml'

# Generated at 2022-06-21 00:58:45.176496
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    p = PlaybookInclude()
    templar = Templar(loader=None, variables={})

    # test playbook name alone
    ds = AnsibleMapping({'import_playbook': "file"})
    new_ds = p.preprocess_data(ds)
    assert new_ds == {'import_playbook': "file", 'vars': {}}

    # test playbook name with mixed params
    ds = AnsibleMapping({'import_playbook': "file test=a foo"})
    new_ds = p.preprocess_data(ds)
    assert new_ds == {'import_playbook': "file", 'vars': {'test': 'a', 'foo': True}}

    # test playbook name with switched params

# Generated at 2022-06-21 00:58:57.908546
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    set_loader = DictDataLoader({
        'test.yml': """
    - import_playbook: test2.yml
    """,
        'test2.yml': """
    - debug:
        msg: Hello World
    """
    })
    p = Playbook.load(playbook_path="test.yml", variable_manager=None, loader=set_loader)
    print("+++")
    print("class: %s" % p.__class__)
    print("vars: %s" % p.vars)
    print("vars: %s" % p.vars)
    for entry in p._entries:
        print("+++")
        print("class: %s" % entry.__class__)
        print("vars: %s" % entry.vars)
        print

# Generated at 2022-06-21 00:59:01.306770
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    b = PlaybookInclude()
    assert b.import_playbook is None
    assert b.vars == dict()



# Generated at 2022-06-21 00:59:09.332500
# Unit test for method preprocess_data of class PlaybookInclude

# Generated at 2022-06-21 00:59:17.422622
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    ds = {"import_playbook": "test.yml"}
    ds1 = {"include": "test.yml"}
    import_playbook = PlaybookInclude()
    pb1 = import_playbook.load(ds, ".")
    pb2 = import_playbook.load(ds1, ".")
    assert pb1.get_entries() == pb2.get_entries()


# Generated at 2022-06-21 00:59:28.159131
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    import datetime
    from ansible.parsing.dataloader import DataLoader

    host = 'localhost'
    playbook_path='/some/path/some_playbook.yml'


# Generated at 2022-06-21 00:59:39.696996
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include = PlaybookInclude()

    # Test with no args passed
    with pytest.raises(AnsibleAssertionError) as exc:
        playbook_include.preprocess_data(None)
    assert 'ds (None) should be a dict but was a <class \'NoneType\'>' == str(exc.value)

    # Test with a string passed
    with pytest.raises(AnsibleAssertionError) as exc:
        playbook_include.preprocess_data('string')
    assert 'ds (string) should be a dict but was a <class \'str\'>' == str(exc.value)

    # Test with a list passed
    with pytest.raises(AnsibleAssertionError) as exc:
        playbook_include.preprocess_data(['list'])

# Generated at 2022-06-21 00:59:40.126763
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-21 01:00:05.564747
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    ds = dict(
        import_playbook='new.yaml',
        vars=dict(firstvar='first'),
        tags=['secondtag', 'firsttag'],
    )

    ds2 = dict(
        include='new.yaml',
        vars=dict(firstvar='first'),
        tags=['secondtag', 'firsttag'],
    )

    import_playbook = PlaybookInclude.load(data=ds, basedir='')
    assert import_playbook.import_playbook == 'new.yaml'
    assert import_playbook.vars == ds['vars']
    assert set(import_playbook.tags) == set(ds['tags'])


# Generated at 2022-06-21 01:00:19.065560
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play_context import PlayContext
    import ansible.constants as C
    import ansible.utils.template as template
    import ansible.template as a_template
    import ansible.utils.vars as vars_util
    from ansible.vars.clean import module_response_deepcopy
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # setup context for playbook include
    playbook = PlaybookInclude()
    context = PlayContext(play=playbook)
    context._ansible_no_log = set()
    play_vars = dict(
        testvars = dict(
            foo = 'test',
        )
    )
    vars_manager = vars_util.VarsModule()
    vars_manager.set_

# Generated at 2022-06-21 01:00:30.533661
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    import ansible.playbook
    import ansible.playbook.play
    import ansible.playbook.task

    # Create a playbook to load
    playbook_data_dict = dict()
    playbook_data_dict['hosts'] = 'localhost'
    playbook_data_dict['tasks'] = [{'shell': '/bin/echo hello'}]
    playbook_data = AnsibleMapping(playbook_data_dict)

    # Create a playbook include object
    playbook_include_dict = dict()
    playbook_include_dict['import_playbook'] = './'
    playbook_include_data = AnsibleMapping(playbook_include_dict)

    # Create an empty playbook
    pb = ansible.playbook.Playbook(loader=None)

    # Create a playbook include object
    p = PlaybookInclude

# Generated at 2022-06-21 01:00:41.190509
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    import os
    # Setup the class
    playbook_include = PlaybookInclude()
    # Verify that the setup was successful
    assert playbook_include is not None, "PlaybookInclude load setup failed"

    # Create a fake ds
    s = 'include: "hello.yml"\n'

    # Create fake os.path.exists
    class FakePathExists():
        def __init__(self, value):
            self.value = value

        def exists(self, path):
            return self.value
    # Create fake os.path.isdir
    class FakePathIsDir():
        def __init__(self, value):
            self.value = value

        def isdir(self, path):
            return self.value
    # Create fake os.path.isfile

# Generated at 2022-06-21 01:00:50.392978
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext

    ds = dict(
        import_playbook = 'subset.yml',
        vars = dict(
            foo = 'bar',
        ),
        tags = 'tag1,tag2',
    )
    playbook = PlaybookInclude.load(ds, '', None)
    assert playbook.import_playbook == 'subset.yml'
    assert playbook.vars == dict(foo='bar')
    assert playbook.tags == ['tag1', 'tag2']

    ds = dict(
        import_playbook = 'subset.yml foo=bar tags=foo,bar',
    )
    playbook = PlaybookInclude.load(ds, '', None)
    assert playbook.import_playbook == 'subset.yml'
    assert playbook

# Generated at 2022-06-21 01:01:00.988686
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    ds = dict(
        include='role.yml'
    )

    ds1 = PlaybookInclude.preprocess_data(ds)
    assert ds1['import_playbook'] == 'role.yml'
    assert 'vars' in ds1.keys() and type(ds1['vars']) == dict and ds1['vars'] == {}

    ds = dict(
        include='role.yml some_vars=foo'
    )

    ds1 = PlaybookInclude.preprocess_data(ds)
    assert ds1['import_playbook'] == 'role.yml'
    assert 'vars' in ds1.keys() and type(ds1['vars']) == dict and ds1['vars'] == dict(some_vars='foo')

   

# Generated at 2022-06-21 01:01:05.204252
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(loader=loader))
    variable_manager.extra_vars = {
        'foo': 'bar',
        'baz': 'qux'
    }

    # Test playbook with a single task
    p = {'import_playbook': 'playbook.yml'}
    yaml_ds = """
    - hosts: all
      tasks:
        - name: test_task
          ping:
    """
    playbook

# Generated at 2022-06-21 01:01:09.355531
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    p = PlaybookInclude()
    assert not p.vars
    assert p.tags == []
    assert p.import_playbook is None
    assert p.when is None


# ---- AnsibleModule internal code ----
# Should be moved to module_utils/parsing/convert_bool.py
# --------------------------------------
from ansible.module_utils._text import to_native


# Generated at 2022-06-21 01:01:21.881501
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # Create ds for test
    ds = AnsibleMapping()

    # Set import_playbook
    ds['import_playbook'] = 'some-playbook'

    # Set other params
    ds['some_parameter'] = 'some_value'

    # Set vars
    ds['vars'] = {'some_var': 'some_value'}

    # Create class object
    include_class_object = PlaybookInclude()

    # Get data
    data = include_class_object.preprocess_data(ds)

    # Check data
    assert data['import_playbook'] == 'some-playbook'
    assert data['some_parameter'] == 'some_value'
    assert data['vars'] == {'some_var': 'some_value'}



# Generated at 2022-06-21 01:01:32.395810
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play

    pb = PlaybookInclude()

    # PlaybookInclude object accepts only dictionary type of data
    # Test input as None
    data = None
    try:
        pb.preprocess_data(data)
    except AnsibleAssertionError:
        print("Test passed: AssertionError raised as expected")
    else:
        print("Test failed: AssertionError was not raised")

    # Test input as int
    data = 1
    try:
        pb.preprocess_data(data)
    except AnsibleAssertionError:
        print("Test passed: AssertionError raised as expected")
    else:
        print("Test failed: AssertionError was not raised")

    # Test input as list
    data = [1, 2]

# Generated at 2022-06-21 01:02:23.454282
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook = """
---
- include_role:
    name: "foo"
- name: bad vars
  vars:
  - foo: bar
"""
    loader = DataLoader()
    display = Display()
    variable_manager = VariableManager(loader=loader, display=display)
    try:
        PlaybookInclude.load(load_data(playbook), variable_manager=variable_manager)
    except Exception as e:
        assert "must be specified as a dictionary" in str(e)

# Generated at 2022-06-21 01:02:31.842458
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from .test_playbook.construct_data_include import TestDataInclude

    # Syntax 1
    # Check if the module is able to handle correct input
    try:
        result = TestDataInclude.playbook1
        p = PlaybookInclude.load(result, '', None, None)
        assert p.import_playbook == 'test_playbook.yml'
    except AnsibleParserError:
        print('Incorrect input was not handled')
        raise

    # Syntax 2
    try:
        result = TestDataInclude.playbook2
        p = PlaybookInclude.load(result, '', None, None)
        assert p.import_playbook == 'test_playbook.yml'
    except AnsibleParserError:
        print('Incorrect input was not handled')
        raise

    # Synt

# Generated at 2022-06-21 01:02:41.849486
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # DeprecationWarning: to_native() is deprecated. Use to_text() instead
    # During module execution, Ansible may call to_native() on a template result
    # in order to convert any bytestrings to text. Previously, to_native() would
    # default to utf-8 encoding. As of Ansible 2.3, to_native() will no longer have
    # a default encoding. This feature will be removed in version 2.10.
    # Please update your templates and filters to use to_text() instead
    # list(ds.items())[0]
    # for k,v in ds.items():

    # import_playbook: foo.yml
    ds = AnsibleMapping({u'import_playbook': u'foo.yml'})

# Generated at 2022-06-21 01:02:52.354089
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # NOTE: this test is currently commented out, as it fails and it
    # is unclear why.  It is also unclear that testing this class is
    # worth the effort to find out why, as it doesn't seem like
    # we're planning to extend this class in the future.  If this is
    # not the case, please update and fix this test, but if this is
    # then true, please remove this test.
    import pytest
    pytest.skip('fails with no explanation')
    pass
    # TODO: this test is currently commented out, as it fails and it
    # is unclear why.
    #from ansible.playbook.playbook_include import PlaybookInclude
    #obj = PlaybookInclude()
    #assert obj.load() == 'redefined'


# Generated at 2022-06-21 01:02:55.451931
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pbi = PlaybookInclude()
    assert isinstance(pbi, PlaybookInclude)

# Generated at 2022-06-21 01:03:04.445576
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    import ansible.playbook.playbook_include
    from ansible.template import Templar

    # load_data()
    # Called from load()
    # Includes a play from a separate file
    #
    # The included file can contain new variables that will override the
    # ones defined on the primary file.

    # In the PlaybookInclude class, this path must be defined
    basedir = "/path/to/playbook"
    # This is the path to the included file
    file_name = 'include_playbook.yaml'
    # This is the path to the included file
    playbook = "/path/to/playbook/include_playbook.yaml"
    # Create a dummy ds which will be returned by load_data().
    # It has a filename to be included on the import_playbook param

# Generated at 2022-06-21 01:03:14.484969
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include = {
        'import_playbook': '../foo.yml'
    }
    PlaybookInclude.preprocess_data(playbook_include)
    assert playbook_include == {
        'import_playbook': '../foo.yml'
    }

    playbook_include = {
        'import_playbook': '../foo.yml',
        'vars': {
            'foo': 'baz',
            'c': 'd'
        }
    }
    PlaybookInclude.preprocess_data(playbook_include)
    assert playbook_include == {
        'import_playbook': '../foo.yml',
        'vars': {
            'foo': 'baz',
            'c': 'd'
        }
    }
