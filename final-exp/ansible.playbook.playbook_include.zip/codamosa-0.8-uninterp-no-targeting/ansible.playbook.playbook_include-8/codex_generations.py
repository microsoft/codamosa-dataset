

# Generated at 2022-06-21 00:53:29.571083
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    assert PlaybookInclude

    # test if 'import_playbook' as only parameter works
    pbi = PlaybookInclude()
    pbi.load_data(ds='import_playbook: dummy_play.yml', basedir='playbooks', variable_manager=None)
    assert pbi.import_playbook == 'dummy_play.yml'
    assert pbi.vars == {}

    # test if providing 'vars' works
    pbi = PlaybookInclude()
    new_ds = 'import_playbook: dummy_play.yml \n' + \
             '      vars: \n' + \
             '          foo: bar\n'
    pbi.load_data(ds=new_ds, basedir='playbooks', variable_manager=None)
    assert pbi.import_playbook

# Generated at 2022-06-21 00:53:37.241759
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # TODO: move to tests after fixes
    import sys
    import os
    import shutil
    import tempfile
    import ansible.constants as C
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.playbook import Playbook


# Generated at 2022-06-21 00:53:37.872348
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    assert PlaybookInclude

# Generated at 2022-06-21 00:53:50.419311
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    PLAYBOOK_INCLUDE_DATA1 = {
        'import_playbook': 'default.yml',
        'tags': 'test_tag',
        'vars': {
            'test_var': 'test_var_value',
        }
    }
    PLAYBOOK_INCLUDE_DATA2 = {
        'import_playbook': 'default.yml',
        'tags': 'test_tag',
        'vars': {
            'test_var': 'test_var_value'
        },
        'test_param': 'test_value',
    }
    PLAYBOOK_INCLUDE_DATA3 = {
        'import_playbook': 'default.yml',
        'test_param': 'test_value',
    }

# Generated at 2022-06-21 00:53:59.557756
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-21 00:54:11.943752
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    import ansible.playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

    # create an empty play
    play = ansible.playbook.Play()
    play.hosts = ['host1']

    # create an empty task
    task1 = ansible.playbook.Task()
    task1.action = 'setup'
    task1.name = 'test_task_name'
    task1.args = dict()

    # create a handler
    handler1 = ansible.playbook.Handler()
    handler1.name = 'test_handler_name'

    # set the play object's attribute
    play.set_children([task1, handler1])
    # create a playbookInclude object
    playbookInclude = ansible

# Generated at 2022-06-21 00:54:13.706179
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # TODO: write
    pass

# Generated at 2022-06-21 00:54:23.470779
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.collection_loader._collection_finder import _get_collection_name_from_path, _get_collection_playbook_path
    from ansible.parsing.dataloader import DataLoader

    AnsibleCollectionConfig.default_collection = None

    # Test case #1 - check correct preprocessing of import statement
    loader = DataLoader()
    yaml_str1 = """
                 - import_playbook: test_playbook.yaml
                 """

    ds1 = AnsibleLoader(yaml_str1, loader=loader).get_single_data()
    import_playbook = PlaybookInclude.load_data(ds1, '/does/not/matter')

# Generated at 2022-06-21 00:54:30.464400
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    expected = {'import_playbook': '../my-play.yml',
                'vars': {'a': 1,
                         'b': 2,
                         'c': 3}}
    new_ds = {}
    pbi = PlaybookInclude()
    playbook = {'include': '../my-play.yml a=1 b=2 c=3'}
    pbi.preprocess_data(playbook)
    for attr, value in iteritems(playbook):
        print(attr, value)
    assert playbook == expected

# Generated at 2022-06-21 00:54:42.843324
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    assert(PlaybookInclude.load({}, '.') is None)

    #import_playbook
    ds = AnsibleMapping(dict(import_playbook='some_playbook.yml'))
    ds.ansible_pos = (1, 1, 1)
    data = PlaybookInclude.load(ds, '.')
    assert(data.import_playbook == 'some_playbook.yml')

    #import

# Generated at 2022-06-21 00:54:59.322832
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    import sys

    if sys.version_info.major == 2:
        from StringIO import StringIO
        pass
    else:
        from io import StringIO
        pass

    data = """
    - include_playbook:
       - included_playbook1.yaml
       - included_playbook2.yaml
       - included_playbook3.yaml
    """

    file_path = os.path.dirname(os.path.realpath(__file__))
    basedir = os.path.realpath(file_path + '/../../')
    pb = PlaybookInclude.load(data, basedir)
    assert pb is not None


# Generated at 2022-06-21 00:55:04.452527
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():

    import pytest

    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    # First, create load function
    load_function = PlaybookInclude.load

    # Second, create example data
    basedir = 'dummy'
    data = {'import_playbook': 'dummy_playbook.yml'}

    # Third, create template object
    playbook_include = PlaybookInclude()

    # Fourth, create example Playbook function output
    result_playbook = Playbook()
    for play in range(0, 2):
        play = Play()
        # Add some tags
        play.tags = ['one', 'two']
        # Dictionary of variables
        play_vars = {'var1': 'value1'}
        play.vars = play_vars
        # Add

# Generated at 2022-06-21 00:55:06.106584
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass


# Generated at 2022-06-21 00:55:18.837500
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.playbook.play import Play

    p = PlaybookInclude()
    assert p is not None

    # Test the copy constructor
    p2 = PlaybookInclude(p)
    assert p2 is not None and p2 != p

    # Test the add_parent() method
    p3 = PlaybookInclude()
    p3.add_parent(p2)
    assert p3 is not None and p3 != p2 and p3.parents != p2.parents

    # test the load() method
    p4 = PlaybookInclude.load([])
    assert p4 is not None

    # test the load_data() method
    p5 = PlaybookInclude().load_data({})
    assert p5 is not None

    # test the preprocess_data() method

# Generated at 2022-06-21 00:55:32.095536
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    #  make sure 'vars' parameters are set correctly
    playbook_include_object = PlaybookInclude()
    # case 1: 'vars' is a dict
    test_data = AnsibleMapping(dict(import_playbook="test1.yml", vars=dict(a='b', c=['d', 'e'])))
    playbook_include_object.preprocess_data(test_data)
    assert playbook_include_object.vars == test_data['vars']
    # case 2: 'vars' is not a dict, raise exception
    test_data = AnsibleMapping(dict(import_playbook="test2.yml", vars=1))
    try:
        playbook_include_object.preprocess_data(test_data)
    except AnsibleParserError:
        assert True
    #

# Generated at 2022-06-21 00:55:41.693367
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Import here to avoid dependency loop
    from ansible.module_utils._text import to_text
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.vars.manager import VariableManager
    import tempfile
    import json
    import os

    # setup needed for unit tests
    os.chdir(tempfile.mkdtemp())
    sample_module = {
      'module': 'test',
      'arguments': {
          'test_arg1': 'test_value1',
          'test_arg2': 'test_value2',
          'test_arg3': 'test_value3',
      },
    }

# Generated at 2022-06-21 00:55:51.558238
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # Ensure that load() of class PlaybookInclude raises an error for malformed data
    _data = dict()
    _basedir = "."
    _variable_manager = None
    _loader = None

    try:
        _PlaybookInclude = PlaybookInclude.load(_data, _basedir, _variable_manager, _loader)
        assert False, 'Expected an AnsibleAssertionError to be raised'
    except AnsibleAssertionError:
        assert True

    # Ensure that load() of class PlaybookInclude raises an error for data with playbook 
    # import parameter missing
    _data = dict()
    _data['some_param'] = "some_value"
    _data['import_playbook'] = None


# Generated at 2022-06-21 00:55:52.411830
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    pass

# Generated at 2022-06-21 00:55:53.040326
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-21 00:55:56.728490
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # TODO: This is not a proper unit test as it does not test any code paths
    # and it does not assert on any conditions.  This should be converted to
    # a proper unit test.
    test_target = PlaybookInclude()

# Generated at 2022-06-21 00:56:13.457235
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import yaml
    yaml_str1 = '- import_playbook: playbook/p1.yml'
    ds1 = yaml.load(yaml_str1)
    p1 = PlaybookInclude().load_data(ds=ds1, basedir='./')
    assert p1._entries[0].name == 'playbook/p1.yml'

    yaml_str2 = '- import_playbook: playbook/p1.yml tags: ccc'
    ds2 = yaml.load(yaml_str2)
    p2 = PlaybookInclude().load_data(ds=ds2, basedir='./')
    assert p2._entries[0].name == 'playbook/p1.yml'

# Generated at 2022-06-21 00:56:19.880701
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    '''
    Tests that playbook objects are loaded and added
    to a playbook
    '''

    from ansible.playbook import Playbook
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_include import HandlerInclude

    playbook = """
    - hosts: hosts
      tasks:
      - debug: msg="this is a task"
      import_playbook: vars.yml
      - debug: msg="this is another task"
    """

    vars_yml = """
    - hosts: hosts
      tasks:
      - debug: msg="this is a task from vars.yml"
    """

    # FIXME: the system needs some kind of temporary directory
    #        support to do this properly
    (fd, path) = tempfile.mkstemp()
   

# Generated at 2022-06-21 00:56:31.338738
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    '''
    Unit test for method preprocess_data of class PlaybookInclude
    '''

    data = (
        { 'import_playbook': 'test.yml' },
        { 'import_playbook': 'test.yml', 'tags': 'tag1,tag2' },
        { 'import_playbook': 'test.yml', 'vars': { 'k1':'v1', 'k2':'v2' } },
        { 'include': 'test.yml', 'vars': { 'k1':'v1', 'k2':'v2' } },
    )
    for d in data:
        res = PlaybookInclude.load(d, '.')
        assert res.import_playbook == "test.yml"
        if 'vars' in d:
            assert res

# Generated at 2022-06-21 00:56:40.621918
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    import_playbook1 = PlaybookInclude(import_playbook='/path/to/playbook.yml')
    import_playbook2 = PlaybookInclude(import_playbook='/path/to/playbook.yml', vars={'var1': 'val1'})

    assert import_playbook1._import_playbook == '/path/to/playbook.yml'
    assert not import_playbook1._vars
    assert import_playbook2._import_playbook == '/path/to/playbook.yml'
    assert import_playbook2._vars == {'var1': 'val1'}


# Generated at 2022-06-21 00:56:47.615777
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    # Test initializing PlaybookInclude without any arguments
    pbi = PlaybookInclude()
    assert pbi.import_playbook == '', "failed to initialize PlaybookInclude.import_playbook"
    assert pbi.vars == {}, "failed to initialize PlaybookInclude.vars"

# Generated at 2022-06-21 00:56:56.476850
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # Test for successful include_tasks
    assert True

    # Test for successful include_role
    assert True

    # Test for successful include_playbook
    assert True

    # Test for successful include_vars
    assert True

    # Test for invalid include_tasks
    assert True

    # Test for invalid include_role
    assert True

    # Test for invalid include_playbook
    assert True

    # Test for invalid include_vars
    assert True

# Generated at 2022-06-21 00:56:57.069053
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-21 00:57:01.416377
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pb = PlaybookInclude()
    assert pb.import_playbook is None
    assert pb.when == list()
    assert pb.tags == list()
    assert pb.vars == dict()
    assert pb.name is None
    assert pb.hosts is None
    assert pb.roles is None
    assert pb.tasks is None

# Generated at 2022-06-21 00:57:04.832360
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # TODO: It needs a playbook_Include object to test
    pass


# Generated at 2022-06-21 00:57:15.177374
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    ds = dict(
        import_playbook='test_import.yml',
        vars=dict(
            var=True,
        ),
        tags=['test_tag'],
    )

    # first, we use the original parent method to correctly load the object
    # via the load_data/preprocess_data system we normally use for other
    # playbook objects
    result = PlaybookInclude().load_data(ds=ds, basedir='/path/to/basedir', variable_manager=None, loader=loader)

    assert result._loader._basedir == '/path/to/basedir'
    assert result._variable_manager is None

# Generated at 2022-06-21 00:57:55.286690
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.inventory import Inventory

    ds = dict(
        import_playbook = 'test.yml'
    )

    playbook = PlaybookInclude()
    playbook.load_data(ds, './')

    assert isinstance(playbook, Playbook)
    assert isinstance(playbook.inventory, Inventory)


# Generated at 2022-06-21 00:58:05.587925
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # This test data is generated with:
    #   $ python -c "from __future__ import print_function; import yaml; print(yaml.dump({'import_playbook': 'docker-mediawiki.yml'}, default_flow_style=False))"

    data_string = """\
import_playbook: docker-mediawiki.yml
"""
    data = yaml.load(data_string)
    assert isinstance(data, dict)

    obj = PlaybookInclude()
    data = obj.preprocess_data(data)

    assert data == {
        'import_playbook': 'docker-mediawiki.yml',
    }



# Generated at 2022-06-21 00:58:16.992614
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Monkey patch the collecttion loader to always return false
    class MockCollectionLoader:
        def _get_collection_playbook_path(self, path):
            return None
    from ansible.utils.collection_loader import _get_collection_loader
    _get_collection_loader = MockCollectionLoader

    from ansible.parsing.dataloader import DataLoader
    variable_manager = None
    loader = DataLoader()
    test_file = 'tests/unit/parsing/yaml/sample_playbook_include.yml'
    output = PlaybookInclude.load(loader.load_from_file(test_file)[0], '', variable_manager=variable_manager, loader=loader)

    # Check the number of plays loaded
    assert len(output._entries) == 2

    # Check the first play
    first

# Generated at 2022-06-21 00:58:17.354736
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-21 00:58:27.920384
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import os
    import tempfile
    import yaml
    import logging
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject, AnsibleMapping
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    logger = logging.getLogger("unit_tests")
    log_level = logging.getLevelName('WARN')
    logger.setLevel(log_level)
    stream_handler = logging.StreamHandler()
    stream_handler.setLevel(log_level)
    formatter = logging.Formatter("%(levelname)s %(filename)s:%(lineno)d")
    stream_handler.setFormatter(formatter)

# Generated at 2022-06-21 00:58:29.252955
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-21 00:58:40.485822
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    p = PlaybookInclude.load(dict(import_playbook='name1', vars=dict(a='1'), tags=['tag1', 'tag2']), basedir='/')
    assert isinstance(p, Playbook)
    assert p._entries[0].vars == dict(a='1')
    assert sorted(p._entries[0].tags) == sorted(['tag1', 'tag2'])

    # This is to increase the coverage of the method
    p = PlaybookInclude()
    p.load_data(dict(import_playbook='name1', vars=dict(a='1'), tags=['tag1', 'tag2']), basedir='/')

    # This is to increase the coverage of the method
    p = PlaybookInclude()
   

# Generated at 2022-06-21 00:58:49.143037
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    data = dict(
        import_playbook='playbooks/site.yml',
        force_handlers=True,
        args=dict(
            key1='value1',
            key2='value2',
            key3='value3',
        ),
    )

    pbi = PlaybookInclude.load(data, '')
    assert 'import_playbook' in pbi._ds
    assert 'force_handlers' in pbi._ds
    assert 'args' in pbi._ds
    assert isinstance(pbi._ds['args'], dict)
    assert 'key1' in pbi._ds['args']
    assert pbi._ds['args']['key1'] == 'value1'
    assert 'key2' in pbi._ds['args']

# Generated at 2022-06-21 00:58:51.961591
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    p = PlaybookInclude()
    assert not p._import_playbook


# Generated at 2022-06-21 00:58:52.870002
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-21 00:59:13.299633
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Just check the method can be called without error
    pbi = PlaybookInclude()
    pbi.load_data('pbi.yml', '')

# Generated at 2022-06-21 00:59:13.724233
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-21 00:59:23.256006
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude

    # load playbook
    ip = PlaybookInclude.load(
        data=dict(
            import_playbook = 'play1.yml'
        ),
        basedir='/playbook/path'
    )

    # playbookInclude.load returns a Playbook object
    assert isinstance(ip, Playbook)

    # playbook has one entry
    assert len(ip._entries) == 1

    # entry is a Play object
    assert isinstance(ip._entries[0], Play)

    # play has no entries

# Generated at 2022-06-21 00:59:33.178510
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    import_playbook = "site.yml"
    vars = {"var1": {"var2": 0, "var3": "string"}, "var4": 1}

    # test empty
    p = PlaybookInclude()
    assert p.import_playbook == None
    assert p.vars == {}

    # test constructor
    p = PlaybookInclude(import_playbook, vars)
    assert p.import_playbook == import_playbook
    assert p.vars == vars



# Generated at 2022-06-21 00:59:38.666751
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    PlaybookInclude('playbook.yaml', tags=[])
    PlaybookInclude('playbook.yaml', tags=[ 'tag1', 'tag2' ],
                    vars=dict(var1='value1', var2='value2'))
    PlaybookInclude('playbook.yaml', tags=[],
                    vars=dict(var1='value1', var2='value2'))

# Generated at 2022-06-21 00:59:47.401882
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    import os.path
    import pprint

    os.chdir('..')
    loader = DataLoader()
    vars_manager = VariableManager()

    test1 = '''
    - vars:
        myvar: yes
        mylist:
          - a
          - b
          - c
      import_playbook: imported_play.yml
    '''

    test2 = '''
    - import_playbook: imported_play.yml
      vars:
        mylist:
          - 0
          - 1
          - 2
        myvar: yes
    '''

    test3 = '''
    - import_playbook: included_play.yml
      when: 1 < 2
    '''


# Generated at 2022-06-21 00:59:58.446870
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # A correct playbook include.
    ds = {"import_playbook": "test.yml"}
    assert PlaybookInclude.preprocess_data(ds) == {"import_playbook": "test.yml"}

    # A correct playbook include with no parameters.
    ds = {"import_playbook": "test.yml"}
    assert PlaybookInclude.preprocess_data(ds) == {"import_playbook": "test.yml"}

    # A correct playbook include with a tag.
    ds = {"import_playbook": "test.yml", "tags": "tag"}
    assert PlaybookInclude.preprocess_data(ds) == {"import_playbook": "test.yml", "tags": ["tag"]}

    # A correct playbook include with a tag and extra parameters.

# Generated at 2022-06-21 01:00:01.103899
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    playbook = PlaybookInclude()
    assert playbook._import_playbook is None
    assert playbook._vars == {}

# Generated at 2022-06-21 01:00:08.904807
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.plugins.loader import action_loader

    playbook_include_obj = PlaybookInclude()
    task_include_obj = Task()
    task_include_obj.action = 'debug'
    task_include_obj.register = 'debug_var'
    task_include_obj.args = {'msg': '{{ var1 }}'}
    block_include_obj = Block()
    block_include_obj._add_task(task_include_obj)
    import_playbook_obj = PlaybookInclude()
    import_playbook_obj.import_playbook = 'include_test/test.yml'
    import_playbook_obj.vars = {'var1': 'some_var_1'}

# Generated at 2022-06-21 01:00:10.662570
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass



# Generated at 2022-06-21 01:00:36.874780
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-21 01:00:45.168480
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    data = {
        'key1': 'value1',
        'key2': 'value2',
        'tags': ['tag1'],
        'vars': {'var1': 'value1'},
        'tasks': [{'action': {'module': 'echo', 'args': {'key1': 'value1'}}}],
    }
    pbi = PlaybookInclude.load(data, '', None)

if __name__ == "__main__":
    test_PlaybookInclude()

# Generated at 2022-06-21 01:00:52.678797
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # Test default values for PlaybookInclude attributes
    _PlaybookInclude = PlaybookInclude()
    assert _PlaybookInclude.import_playbook == None
    assert _PlaybookInclude.vars == {}
    assert _PlaybookInclude.tags == []
    assert _PlaybookInclude.when == []

# Generated at 2022-06-21 01:01:02.106897
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    module = PlaybookInclude()

    # import here to avoid a dependency loop
    from ansible.playbook import Playbook

    # Check that if vars are given with the k=v format and not as a dict, then we get an error
    data = dict(vars='foo=bar', import_playbook='foo.yaml')
    try:
        module.preprocess_data(data)
        assert(False)
    except AnsibleParserError as e:
        assert(e.obj is data)
        assert(e.message == "vars for import_playbook statements must be specified as a dictionary")

    # Check that if 'vars' is used both with the k=v format and the dict format, then we get an error

# Generated at 2022-06-21 01:01:08.790062
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import sys
    sys.modules['__main__'] = sys.modules['ansible.parsing.yaml.objects']
    import __main__ as main
    try:
        del main.__dict__['PlaybookInclude']
    except Exception:
        pass

    module = '''
import_playbook: foo.yml
# We don't have the playbook in hand to check for the existence of
# vars in the correct position, but if it's not a dict, we should
# see an error
vars:
    foo: bar
    baz: qux
'''
    ds = AnsibleBaseYAMLObject.load(module)
    import_obj = PlaybookInclude().load(ds, "")
    assert import_obj.import_playbook == "foo.yml"
    assert import_obj.v

# Generated at 2022-06-21 01:01:21.646983
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader, variable_manager)
    pb = PlaybookInclude.load(dict(import_playbook="sample_playbook_one.yml"), basedir=".", variable_manager=variable_manager, loader=loader)

    assert pb._entries[0].name == "Sample Playbook One"

    pb = PlaybookInclude.load(dict(import_playbook="sample_playbook_two.yml"), basedir=".", variable_manager=variable_manager, loader=loader)

    assert pb._entries[0].name == "Sample Playbook Two"

# Generated at 2022-06-21 01:01:32.329782
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # Tests where the argument is not a dictionary
    def test_AnsibleAssertionError():
        try:
            p = PlaybookInclude.load(None, '.')
        except AnsibleAssertionError:
            pass
        else:
            raise AssertionError('AnsibleAssertionError not raised')

    # Tests where the dictionary has no 'import_playbook' key
    def test_AnsibleAssertionError():
        try:
            p = PlaybookInclude.load({'key': 'value'}, '.')
        except AnsibleAssertionError:
            pass
        else:
            raise AssertionError('AnsibleAssertionError not raised')

    # Test where the import_playbook value is None

# Generated at 2022-06-21 01:01:37.466985
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pb = PlaybookInclude()
    assert pb.vars == dict()
    assert pb.import_playbook is None
    assert pb.tags == list()



# Generated at 2022-06-21 01:01:39.973618
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-21 01:01:50.082284
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    print("Test: PlaybookInclude_load_data")

    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.template import Templar

    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.errors import AnsibleParserError

    # TODO: find a way to mock Loader without duplicating code
    path = 'tests/data/test_playbook_include'

    ds = AnsibleMapping()
    ds['import_playbook'] = 'test_playbook_include_vars_1.yml'
    ds['tags'] = 'tag1'
    ds['vars'] = AnsibleMapping(dict(var2='value2'))


# Generated at 2022-06-21 01:02:54.967712
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    import os.path
    ##########################
    # Setup for test load
    ##########################
    # Create a task
    task = TaskInclude()
    task.name = 'mytest'
    task.action = 'action'
    # Create a block
    block = Block()
    block.block = [task]
    block.name = 'myblock'
    # Create a play
    play = Play()
    play._entries = [block]
    # Create a playbook
    playbook = PlaybookInclude()
    playbook._entries = [play]
    # Create a path

# Generated at 2022-06-21 01:03:04.272205
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pi1 = PlaybookInclude()
    print(pi1.__dict__)
    assert pi1.import_playbook is None
    assert pi1.vars == {}
    assert pi1.tags == []
    assert pi1._included_path == None

    pi2 = PlaybookInclude.load({'import_playbook': './path/to/playbook.yml', 'tags': ['tag1', 'tag2'], 'vars': {'k1': 'v1', 'k2': 'v2'}})
    print(pi2.__dict__)
    assert pi2.import_playbook == './path/to/playbook.yml'
    assert pi2.vars == {'k1': 'v1', 'k2': 'v2'}

# Generated at 2022-06-21 01:03:14.410840
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # setup temporary test file
    import tempfile
    from ansible.parsing.yaml.loader import AnsibleLoader
    (fd, path) = tempfile.mkstemp()
    f = os.fdopen(fd, "w")
    f.write("""
# this is a comment
- import_playbook: test.yml
- import_playbook: test.yml tags=foo,bar
    """)
    f.close()
    ds = AnsibleLoader(None, file_name=path).get_single_data()
    os.remove(path)

    (fd, path) = tempfile.mkstemp()
    f = os.fdopen(fd, "w")
    f.write("""
- import_playbook: :test.yml""")
    f.close()
    ds