

# Generated at 2022-06-21 00:53:26.109276
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    """
    Test the method preprocess_data of class PlaybookInclude
    """
    import_playbook_1 = PlaybookInclude.load({'include': 'playbooks/proxy.yml', 'tags': 'proxy'})
    ref_dict_1 = {'import_playbook': 'playbooks/proxy.yml', 'tags': 'proxy'}
    assert import_playbook_1.preprocess_data({'include': 'playbooks/proxy.yml', 'tags': 'proxy'}) == ref_dict_1

    import_playbook_2 = PlaybookInclude.load({'include': 'playbooks/proxy.yml'})
    ref_dict_2 = {'import_playbook': 'playbooks/proxy.yml'}

# Generated at 2022-06-21 00:53:30.556749
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    play_include = PlaybookInclude()
    data = '''
    - import_playbook: test.yml
      vars:
          name: "test"
    '''
    play_include.load(data, "/")
    assert play_include._import_playbook == "test.yml"

test_PlaybookInclude_load()

# Generated at 2022-06-21 00:53:38.080996
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    playbook_include = PlaybookInclude()

    loader = DataLoader()
    variable_manager = VariableManager()


# Generated at 2022-06-21 00:53:50.614730
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Unit tests for method preprocess_data of class PlaybookInclude
    #
    # Load a playbook include object with a plain string for 'import_playbook' key
    playbook_include_obj = PlaybookInclude()
    data = {'import_playbook': 'test.yml'}
    playbook_include_obj.load_data(data, '/home/ansible')
    assert playbook_include_obj.import_playbook == 'test.yml'

    # Load a playbook include object with a plain string for 'import_playbook' key and 'extra_vars'
    playbook_include_obj = PlaybookInclude()
    data = {'import_playbook': 'test.yml', 'vars': {'a': 'b'}}
    playbook_include_obj.load_data(data, '/home/ansible')

# Generated at 2022-06-21 00:53:59.637873
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import pytest
    from ansible.parsing.yaml.objects import AnsibleSequence

    # prepare a variable_manager
    class variable_manager:
        def __init__(self):
            self.vars = dict()
        def get_vars(self):
            return self.vars

    variable_manager_instance = variable_manager()
    variable_manager_instance.vars = {
            'some_dict': { 
                'str_value': 'str',
                'int_value': 1,
            },
            'some_list': [
                'list_item1',
                'list_item2'
            ]
    }

    # create PlaybookInclude instance
    instance = PlaybookInclude()
    instance.loader = None

    # perform test

# Generated at 2022-06-21 00:54:00.874692
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pi = PlaybookInclude()
    

# Generated at 2022-06-21 00:54:01.523494
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-21 00:54:14.391006
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Play
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Since this is a unit test, we force the import path to be current directory.
    # This will change once we move playbooks out of the ansible repo
    basedir = '.'
    import_playbook_path = './test/playbooks/import_playbook_test.yml'
    var_manager = None
    loader = AnsibleLoader(None, true_basedir=basedir)
    playbook_include = PlaybookInclude.load(data=import_playbook_path, basedir=basedir, variable_manager=var_manager, loader=loader)
    assert type(playbook_include) == Play
    assert len(playbook_include.tasks) == 2

# Generated at 2022-06-21 00:54:21.023847
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import sys
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    class FakeDS:
        pass

    class FakeVariableManager:
        def __init__(self):
            self.vars = {'foo': 'bar', 'baz': 'bat'}

        def get_vars(self):
            return {'foo': 'bar', 'baz': 'bat'}

    class FakeTemplar:
        def template(self, path):
            if path == './not-a-playbook.yml':
                return './not-a-playbook.yml'
            else:
                return '/Users/michael/ansible/playbooks/site.yml'

    class FakeLoader:
        pass


# Generated at 2022-06-21 00:54:31.270146
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    ##########################
    # Unit test for method load of class PlaybookInclude
    ##########################
    # We will only assess the created playbook, not the playbook include object itself
    # This is because the entire playbook is created inside the load method, using a
    # recursive call to the load method of the base class

    ### Initialize the normal include case
    # First, we create a playbook include object
    pbincl = PlaybookInclude()
    # We are missing the include_tasks attribute
    assert not hasattr(pbincl, 'import_playbook')

    # We create a dictionary that somewhat resembles the datastructure
    # of a playbook include but with all the required attributes for the playbook to load
    # file_name is the

# Generated at 2022-06-21 00:54:44.779123
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():

    # Test with None
    try:
        PlaybookInclude.load(None, None)
    except Exception as exc:
        assert isinstance(exc, TypeError)
        assert "argument of type 'NoneType'" in str(exc)

    # Test with wrong type for ds
    try:
        PlaybookInclude.load([], None)
    except Exception as exc:
        assert isinstance(exc, TypeError)
        assert "argument of type 'list'" in str(exc)

    # Test with wrong type for basedir
    try:
        PlaybookInclude.load({}, 23)
    except Exception as exc:
        assert isinstance(exc, TypeError)
        assert "argument of type 'int'" in str(exc)

    # Test with import_playbook as string

# Generated at 2022-06-21 00:54:52.513372
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pbi = PlaybookInclude()
    pbi.import_playbook = 'playbook.yml'
    assert pbi.import_playbook == 'playbook.yml'
    pbi.vars = {'var1': 'val1', 'var2': {'var3': 'val3'}}
    assert pbi.vars == {'var1': 'val1', 'var2': {'var3': 'val3'}}
    assert pbi.vars['var2']['var3'] == 'val3'
    assert pbi.get_vars() == {'var1': 'val1', 'var2': {'var3': 'val3'}}
    assert pbi.tags == []

# Generated at 2022-06-21 00:55:05.120528
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.utils.collection_loader._collection_finder import _get_collection_name_from_path

    playbooks = [
        ('./test/units/include_playbook/playbook1.yaml', 'fake_collection', './test/units/include_playbook/playbook1.yaml'),
        ('collections/ignore/fake_collection/playbook1.yaml', 'fake_collection', './test/units/include_playbook/playbook1.yaml'),
        ('playbook1.yaml', None, './test/units/include_playbook/playbook1.yaml'),
    ]


# Generated at 2022-06-21 00:55:14.331533
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    variable_manager = None
    loader = None

    # sample data sets for testing
    dataset_1 = dict(import_playbook="test_hosts.yml", when="foo")
    dataset_2 = dict(import_playbook="test_hosts.yml", tags="foo")
    dataset_3 = dict(import_playbook="test_hosts.yml", vars=dict(bar="baz"))
    dataset_4 = dict(import_playbook="test_hosts.yml")

    # first, test loading a simple data set with no parameters
    ds = PlaybookInclude.load(data=dataset_4, basedir=".", variable_manager=variable_manager, loader=loader)
    assert isinstance

# Generated at 2022-06-21 00:55:16.896137
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    '''
    Test the PlaybookInclude constructor
    '''
    playbookInclude = PlaybookInclude()



# Generated at 2022-06-21 00:55:26.591925
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    playbook_include_obj = PlaybookInclude.load(dict(
        import_playbook='/dev/null',
        when=dict(test='test'),
        tags=dict(test='test'),
        vars=dict(test='test'),
    ), basedir='.')

    assert playbook_include_obj._import_playbook == '/dev/null'
    assert playbook_include_obj._vars == dict(test='test')

# Generated at 2022-06-21 00:55:32.545745
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    import os
    import tempfile
    import shutil
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    # Create a temporary directory
    tmp_src = tempfile.mkdtemp()
    # create file in temporary directory

# Generated at 2022-06-21 00:55:33.390372
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    playbook_include = PlaybookInclude()

# Generated at 2022-06-21 00:55:43.065190
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.parsing.yaml.objects import AnsibleMapping

    # Testing with a simple string
    ds = AnsibleMapping(import_playbook='my_playbook')
    pb = PlaybookInclude()
    pb.load_data(ds)
    assert pb.import_playbook == 'my_playbook'

    # Testing with a string and parameters
    ds = AnsibleMapping(import_playbook='my_playbook tags=tag1,tag2 var1=value1 var2=value2')
    pb = PlaybookInclude()
    pb.load_data(ds)
    assert pb.import_playbook == 'my_playbook'
    assert pb.tags == ['tag1', 'tag2']

# Generated at 2022-06-21 00:55:53.941181
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    import copy
    import sys
    '''
    Unit test for class PlaybookInclude
    '''

    ################################################################################
    # Testing: constructor of class PlaybookInclude
    ################################################################################
    playbook_include = PlaybookInclude()
    assert playbook_include.import_playbook == None
    assert playbook_include.vars == {}
    assert playbook_include.tags == []
    assert playbook_include.when == []
    assert playbook_include.changed_when == []

    playbook_include = PlaybookInclude({'import_playbook': 'test1.yml'})
    assert playbook_include.import_playbook == 'test1.yml'
    assert playbook_include.vars == {}
    assert playbook_include.tags == []
    assert playbook_include.when == []
    assert playbook

# Generated at 2022-06-21 00:56:11.325974
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
  from ansible.inventory import Inventory
  from ansible.vars import VariableManager
  from ansible.parsing.dataloader import DataLoader
  from ansible.playbook.play import Play
  from ansible.executor.task_queue_manager import TaskQueueManager

  class Options(object):
    def __init__(self):
      self.connection = 'local'
      self.verbosity = 3
      self.extra_vars = {'some_host': 'localhost', 'some_other_host': '192.168.1.1:22'}
      self.inventory = Inventory('/etc/ansible/hosts')

  file_name = './tests/unit/playbook_include/foobarplaybook.yml'
  variable_manager = VariableManager()

# Generated at 2022-06-21 00:56:14.025172
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pbi = PlaybookInclude()
    assert pbi.vars == dict()

# Generated at 2022-06-21 00:56:17.819055
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    print("Testing method preprocess_data")
    my_object = PlaybookInclude()
    my_object.preprocess_data({'a': 1, 'b': 2, 'c': 3})


# Generated at 2022-06-21 00:56:30.446867
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    ds = AnsibleMapping(
        import_playbook='test.yml',
        tags='allhosts',
        vars=dict(baz='qux'),
    )
    pbi = PlaybookInclude()
    assert pbi.import_playbook == 'test.yml'
    assert pbi.tags == ['allhosts']
    assert pbi.vars == dict(baz='qux')
    assert pbi.when is None

    ds = AnsibleMapping(
        import_playbook='test.yml tags=allhosts vars=baz=qux',
        when=[
            dict(name='foo', value='bar'),
        ],
    )
    pbi = PlaybookInclude()
    assert pbi.import_playbook == 'test.yml'
    assert p

# Generated at 2022-06-21 00:56:38.242100
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    '''
    PlaybookInclude unit test
    '''

    # construct PlaybookInclude object
    pbi = PlaybookInclude()

    # Make sure we've got the right object
    assert pbi.__class__.__name__ == "PlaybookInclude", 'Object of incorrect type, should be PlaybookInclude'

    # Make sure we've got the right super class
    assert pbi.__class__.__bases__[0].__name__ == "Base", 'Incorrect super class, should be Base'
    assert pbi.__class__.__bases__[1].__name__ == "Conditional", 'Incorrect super class, should be Conditional'
    assert pbi.__class__.__bases__[2].__name__ == "Taggable", 'Incorrect super class, should be Taggable'



# Generated at 2022-06-21 00:56:51.430345
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    ##
    ## PlayBookInclude
    ##

    from ansible.parsing.yaml.loader import AnsibleLoader

    # input datastructure
    inp_ds = AnsibleMapping()
    inp_ds['import_playbook'] = 'test_playbook.yml'
    inp_ds['tags'] = 'tag1,tag2'

    # expected datastructure
    exp_ds = AnsibleMapping()
    exp_ds['import_playbook'] = 'test_playbook.yml'
    exp_ds['tags'] = ['tag1', 'tag2']

    actual = PlaybookInclude.load_data(None, None, ds=inp_ds)
    assert actual.import_playbook == exp_ds['import_playbook']
    assert sorted(actual.tags) == sorted

# Generated at 2022-06-21 00:57:01.588773
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook

    # SETUP
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import io
    from ansible.module_utils.six.moves.urllib.parse import quote
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader

    def quoted_contents(yaml_contents):
        ansible_loader = AnsibleLoader(yaml_contents, None)
        yaml_data = ansible_loader.get_single_data()
        yaml_contents = AnsibleDumper().dump(yaml_data, explicit_start=True, explicit_end=True)

# Generated at 2022-06-21 00:57:08.391592
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    data_struct = dict(
        import_playbook='test-script.yml',
        vars=dict(var1=5)
    )
    result = PlaybookInclude.load(data_struct, '/test/path', None, None)
    assert result is not None

# Generated at 2022-06-21 00:57:12.706391
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    ds = {"import_playbook": "foo.yml", "vars": {"var1": "val1"}}
    obj = PlaybookInclude.load(ds)
    assert obj.import_playbook == "foo.yml"
    assert obj.vars == {"var1": "val1"}
    assert obj.tags == []
    assert obj.when == []

# Generated at 2022-06-21 00:57:14.871887
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pb_inc = PlaybookInclude()
    pb_inc.load({})

# Generated at 2022-06-21 00:57:24.943982
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pass

# Generated at 2022-06-21 00:57:32.255924
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    # create an empty playbook include object
    pb = PlaybookInclude()

    # test setting an import_playbook on an empty object
    pb.import_playbook = "foo"
    assert pb.import_playbook == "foo"

    # test setting a vars dictionary on an empty object
    pb.vars = {"foo": "bar"}
    assert pb.vars == {"foo": "bar"}

    # test loading a playbook_include datastructure
    data = {"import_playbook": "foo", "vars": {"foo": "bar"}}
    temp_pb = pb.load(ds=data, variable_manager=None, loader=None)

    # verify the loaded object is a Playbook() object
    assert temp_pb.__class__.__name__ == "Playbook"

    # verify the

# Generated at 2022-06-21 00:57:41.484021
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    loader = DictDataLoader({
        "_collections": ["my.collection"],
        "my.collection": {
            "my.collection.playbook": {}
        }
    })

    # test with FQCN
    play = PlaybookInclude().load_data({
        "import_playbook": "my.collection.playbook"
    }, variable_manager=None, loader=loader)
    assert play.import_playbook == "my.collection.playbook"



# Generated at 2022-06-21 00:57:46.782195
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # Create a PlaybookInclude object
    test_include = PlaybookInclude()

    # Check that the object is of the correct class
    assert(isinstance(test_include, PlaybookInclude))

# Generated at 2022-06-21 00:57:59.698602
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():

    play = "playbook_wade.yml"

    # Use constructor of super class (class Base) to construct an object
    b = Base()
    assert isinstance(b, Base)

    # Use the constructor of class PlaybookInclude to construct a object
    pi = PlaybookInclude.load(play, None)
    assert isinstance(pi, PlaybookInclude)

    # Use __repr__() to get the string representation of the object
    # It will be used for the unit test
    #print ("The repr of the PlaybookInclude object is : ")
    #print (pi.__repr__())

    # Use __str__() to get the string representation of the object
    #print ("The str of the PlaybookInclude object is : ")
    #print (pi.__str__())

    # test get_resource

# Generated at 2022-06-21 00:58:08.648675
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.role import Role

    # Build PlaybookInclude object
    options = {'basedir': '/opt/ansible'}
    variable_manager = None
    loader = None
    pi = PlaybookInclude()
    pi._load_data(ds={'import_playbook': 'include.yml'}, basedir=options['basedir'], variable_manager=variable_manager, loader=loader)

    # Build Playbook object

# Generated at 2022-06-21 00:58:09.660679
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-21 00:58:15.020321
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # Valid input for class PlaybookInclude
    ds_1 = dict(
        import_playbook='../playbook1.yml',
        vars=dict(
            var1='value1',
            var2='value2',
        ),
        tags=['tag1', 'tag2'],
    )
    ds_2 = dict(
        import_playbook='../playbook1.yml tags=tag1,tag2 vars=var1=value1 var2=value2'
    )

    # Invalid input for class PlaybookInclude
    ds_3 = dict(
        import_playbook='../playbook1.yml tags=tag1,tag2 vars=var1=value1 vars=var2=value2'
    )

# Generated at 2022-06-21 00:58:27.087573
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():

    display.verbosity = 4

    #####################################################
    #
    # test 1. basic playbook.yml
    #
    test_file = '''
    name: test playbook.yml
    hosts: test_hosts

    tasks:
    - debug:
        msg: 'Hello, world'
    '''

    basedir = '/path/to/playbook.yml'
    playbook_data = PlaybookInclude.load(test_file, basedir)
    assert playbook_data.name == 'test playbook.yml'
    assert playbook_data.hosts == 'test_hosts'
    assert playbook_data.tasks[0]['debug']['msg'] == 'Hello, world'

    #####################################################
    #
    # test 2. basic playbook.yml with variables
    #
    test_

# Generated at 2022-06-21 00:58:39.571246
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.utils.collection_loader._yaml_loader import AnsibleLoader

    loader = AnsibleLoader(None)

    # ############################
    # first: one play, one task
    # ############################
    ds = {
        'import_playbook': 'heinz.yml'
    }
    pb = PlaybookInclude.load(ds=ds, basedir='playbooks')
    assert(len(pb._entries)==3)
    assert(isinstance(pb._entries[0], Play))
    assert(isinstance(pb._entries[1], Play))
    assert(isinstance(pb._entries[2], Play))
    # the first entry should not have any tasks or handlers

# Generated at 2022-06-21 00:59:00.631357
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # Initialize PlaybookInclude
    my_PlaybookInclude = PlaybookInclude()

    # preprocess data
    ds = {}
    test_PlaybookInclude = my_PlaybookInclude.preprocess_data(ds=ds)
    assert test_PlaybookInclude == {}

    ds = {'import_playbook': 'my_include_playbook'}
    test_PlaybookInclude = my_PlaybookInclude.preprocess_data(ds=ds)
    assert test_PlaybookInclude == ds

    ds = {'import_playbook': 'my_include_playbook', 'vars': {'a': '42'}}
    test_PlaybookInclude = my_PlaybookInclude.preprocess_data(ds=ds)
    assert test_PlaybookInclude == ds

   

# Generated at 2022-06-21 00:59:08.759142
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    """
    Unit test for method load_data of class PlaybookInclude
    """
    from ansible.playbook.play import Play

    basedir = '/playbook/path'
    file_name = 'playbook.yml'

    # it is NOT a collection playbook, setup adjecent paths
    old_playbook_paths = AnsibleCollectionConfig.playbook_paths
    AnsibleCollectionConfig.playbook_paths = [os.path.join(basedir, os.path.pardir)]
    old_default_collection = AnsibleCollectionConfig.default_collection
    AnsibleCollectionConfig.default_collection = None

    ds = { 'import_playbook': file_name }
    playbooks = PlaybookInclude.load(ds, basedir)
    assert type(playbooks) is not PlaybookInclude

# Generated at 2022-06-21 00:59:21.569207
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.playbook.play_context import PlayContext

    pb = PlaybookInclude()
    assert pb.vars == dict()

    # test k=v form
    pb = PlaybookInclude.load({'import_playbook': 'some_pb.yaml'})
    assert pb.vars == dict()

    # test k=yaml form
    pb = PlaybookInclude.load({'import_playbook': {'some_pb.yaml': None}})
    assert pb.vars == dict()

    # test k=yaml form with params
    pb = PlaybookInclude.load({'import_playbook': {'some_pb.yaml': {'tags': 'tag1,tag2', 'vars': {'value1': 1, 'value2': 2}}}})

# Generated at 2022-06-21 00:59:25.723017
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pb = PlaybookInclude()
    assert pb._import_playbook is None
    assert pb.vars == {}
    assert pb.tags == []
    assert pb.when == []
    assert pb.failed is False
    assert pb.skipped is False

# Generated at 2022-06-21 00:59:38.550138
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook, Play
    from ansible.playbook.play import Play

    playbook1 = Playbook()
    playbook1.load(os.path.join('test', 'test_modules', 'include_files', 'test_include_1.yaml'))
    playbook2 = Playbook()
    playbook2.load(os.path.join('test', 'test_modules', 'include_files', 'test_include_2.yaml'))
    playbook3 = Playbook()
    playbook3.load(os.path.join('test', 'test_modules', 'include_files', 'test_include_3.yaml'))

    assert playbook1.get_children() == playbook2.get_children()
    assert isinstance(playbook1.get_children()[0], Play)

# Generated at 2022-06-21 00:59:43.256042
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook

    PBID = PlaybookInclude.load(data=dict(import_playbook=dict(path='playbook.yml')), basedir='/tmp')
    assert isinstance(PBID, Playbook)

# Generated at 2022-06-21 00:59:50.922713
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.module_utils._text import to_bytes

    from ansible.parsing.yaml.objects import AnsibleSequence

    playbook_include = PlaybookInclude()

    ds = {
        'import_playbook': 'tmp/example.yml',
        'vars': {'test': 'foobaz'},
        'something_else': 'test',
    }
    new_ds = AnsibleSequence([('import_playbook', 'tmp/example.yml'), ('vars', {'test': 'foobaz'}), ('something_else', 'test')])
    playbook_include.preprocess_data(ds)
    assert ds == new_ds

    # Check for an invalid value for the dictionary key 'import_playbook'.
    ds = {'import_playbook': 123456}

# Generated at 2022-06-21 00:59:56.421171
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.playbook.play_context import PlayContext

    pbi = PlaybookInclude()
    assert pbi.vars == dict()
    assert pbi.when is None
    assert pbi.tags is None
    assert pbi.import_playbook is None
    assert pbi.context is PlayContext()
    assert isinstance(pbi.metadata, dict)

# Generated at 2022-06-21 01:00:07.345155
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # mock
    import ansible.playbook.play_context
    import ansible.playbook.play

    test_ds = dict(
        import_playbook = "/path/to/playbook1.yaml",
        vars = dict( var1 = 1, var2 = 2),
        tags = "tag1,tag2",
        ignore_errors = "ignore_errors",
    )
    test_ds2 = dict(
        import_playbook = "/path/to/playbook2.yaml",
        vars = dict( var1 = 1, var2 = 2),
        tags = "tag1,tag2",
        ignore_errors = "ignore_errors",
    )

    # test
    play_context = ansible.playbook.play_context.PlayContext()
    pc = PlaybookInclude()
    pc

# Generated at 2022-06-21 01:00:19.622893
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.yaml.loader import AnsibleLoader

    collect_ignore = ["setup.py"]

    def file_data(file_name):
        data = None
        with open(file_name, 'r') as f:
            data = f.read()
        return data

    # Inputs
    test_data_file = os.path.join(os.path.dirname(__file__), 'test_data', 'playbook_include_test_input.yml')
    test_data = file_data(test_data_file)
    _test_data = AnsibleLoader(test_data, file_name=test_data_file).get_single_data()
    test_import_playbook = _test_data['test_import_playbook']

    # Expected results
    expected_results_

# Generated at 2022-06-21 01:00:45.005002
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # Test case #1: execute with invalid `ds` argument
    #
    # Expect AnsibleAssertionError is thrown

    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.plugins.loader import shared_plugin_loader

    ds = 1
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(a=1, b=2, c=3)
    variable_manager.options_vars = dict(option_a=1, option_b=2, option_c=3)
    variable_manager.options_vars['vault_password'] = 'ansible'
    loader = shared_plugin_loader()
    loader.set_basedir('/home/vagrant/ansible')

# Generated at 2022-06-21 01:00:58.629334
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():

    import ansible.parsing.yaml.objects

    # Testing with a properly structured playbook
    playbook_1 = """
    - include_tasks: playbook_1.yml vars:
        yaml_key: yaml_value
        with_dict:
          - key_1: value_1
          - key: value_2
        with_list:
          - key_1: value_1
          - key: value_2
    """

    pb_1 = ansible.parsing.yaml.objects.AnsibleMapping()
    pb_1.ansible_pos = (1, 1)
    pb_1.load(playbook_1)
    pb_1 = pb_1.preprocess_data(pb_1)


# Generated at 2022-06-21 01:01:00.632523
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    assert PlaybookInclude.load([], '') is not None

# Generated at 2022-06-21 01:01:10.716854
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from pprint import pprint
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler

    ds = dict(import_playbook='/tmp/include.yml', tags=['collect'], vars= dict(var1 = 'var1_value', var2 = 'var2_value'))
    basedir = '/tmp'
    # create PlaybookInclude object
    playbookInclude = PlaybookInclude.load(ds, basedir)

    # create playbook.Playbook object

# Generated at 2022-06-21 01:01:12.162298
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pass

# Generated at 2022-06-21 01:01:22.658146
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # make sure import works as expected
    b_ds = {"import_playbook": "test.yml"}
    obj = PlaybookInclude.load(b_ds, "/some/basedir")
    assert obj != None

    # make sure we can set a var for the included play
    b_ds = {"import_playbook": "test.yml", "vars": {"foo": "baz"}}
    obj = PlaybookInclude.load(b_ds, "/some/basedir")
    assert obj != None

    # make sure old style param works
    b_ds = {"import_playbook": "test.yml foo=baz"}
    obj = PlaybookInclude.load(b_ds, "/some/basedir")
    assert obj != None

    # make sure old style param is not allowed when using new style vars

# Generated at 2022-06-21 01:01:32.668503
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import yaml
    loader = yaml.SafeLoader
    loader.add_constructor(u'!include', PlaybookInclude.load)
    loader.add_constructor(u'!import', PlaybookInclude.load)


# Generated at 2022-06-21 01:01:44.581876
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    yaml_data = """
    - name: localhost
      hosts: localhost
      fail_when_unreachable: False
      tasks:
        - import_playbook: playbook-4.yml
          vars:
            port: 9000
        - import_playbook: playbook-1.yml
          vars:
            username: admin
            password: secret
          tags:
            - tag1
            - tag2
        - import_playbook: playbook-2.yml
          vars:
            - user: admin
              password: secret
            - user: johndoe
              password: topsecret
        - import_playbook: playbook-3.yml
          vars:
            port: 8000
    """
    results = PlaybookInclude.load(yaml_data, 'playbooks/')
    assert results

# Generated at 2022-06-21 01:01:45.393114
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-21 01:01:47.077139
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pi = PlaybookInclude()
    assert isinstance(pi, PlaybookInclude)

# Generated at 2022-06-21 01:02:25.993576
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    ds = '''
    - import_playbook: test
      when: foo # to check we don't prepend this when to the tasks
    '''
    ds = AnsibleMapping.load(ds)
    p = PlaybookInclude.load(ds, basedir='/path/to/playbook')

    assert p.import_playbook == 'test'
    assert p.when == ['foo']

    ds = '''
    - import_playbook: test
      when: foo # to check we don't prepend this when to the tasks
      vars:
        foo: bar
    '''
    ds = AnsibleMapping.load(ds)
    p = PlaybookInclude.load(ds, basedir='/path/to/playbook')

    assert p.import_playbook == 'test'
   

# Generated at 2022-06-21 01:02:38.350990
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.parsing.yaml.data import DataLoader
    from ansible.vars.manager import VariableManager

    data = """
        - include_tasks: foo.yml
          vars:
            foo: bar
          tags:
            - a
            - b
    """

    loader = DataLoader()
    results = loader.load(data)
    if not results:
        raise Exception("DataLoader failed to produce results: %s" % results)

    if not isinstance(results[0], PlaybookInclude):
        raise Exception("Results are not what was expected: %s" % type(results[0]))

    variable_manager = VariableManager()
    variable_manager.set_matching_facts(
        { 'ansible_distribution': 'RedHat' }
    )

    used_vars = variable

# Generated at 2022-06-21 01:02:51.346468
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Note that ansible_pos is not used in a deep comparison but is used to
    # create a YAML object, which is deep compared with the dict
    import_playbook = dict(
        ansible_pos=dict(
            line=4,
            column=0
        ),
        import_playbook='test.yml',
        vars=dict(test=1)
    )
    import_playbook_with_tags = dict(
        ansible_pos=dict(
            line=4,
            column=0
        ),
        import_playbook='test.yml tags=test',
        tags='test'
    )

# Generated at 2022-06-21 01:03:03.280929
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Play
    from ansible.playbook.play import Playbook

    playbook = Playbook()
    playbook._load_playbook_data(file_name='/dev/null', variable_manager=None, vars=dict())
    vars = dict()
    ds = dict(
        import_playbook='no_such_file',
        tags=['tag1', 'tag2'],
        when=True
    )
    # Test file not found
    try:
        PlaybookInclude.load(ds=ds, basedir=__file__, variable_manager=None, loader=None)
        assert False
    except AnsibleParserError as e:
        assert 'no_such_file' in str(e)

    # Test file found but without correct structure
    import tempfile
    tmp_fd,

# Generated at 2022-06-21 01:03:14.033115
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.become import Become
    from ansible.playbook.connection_info import ConnectionInfo
    from ansible.parsing.yaml.loader import AnsibleLoader

    #################################################################################################
    ### Creation of the PlaybookInclude object in order to test its method preprocess_data
    #################################################################################################

    # PlaybookInclude object we want to test
    test_PlaybookInclude = PlaybookInclude()

    #################################################################################################
    ### Test 1: Call of the method preprocess_data