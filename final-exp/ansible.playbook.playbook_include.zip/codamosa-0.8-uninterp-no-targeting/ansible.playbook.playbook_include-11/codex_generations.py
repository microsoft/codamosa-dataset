

# Generated at 2022-06-21 00:53:25.016825
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    play_ds = '''
    - hosts: all
      remote_user: root
      tasks:
      - include: /etc/ansible/roles/my-common-role/tasks/main.yml
        vars:
          user: root
      roles:
      - my-common-role
      - my-other-common-role
    '''

    loader = DataLoader()
    play = Play().load(play_ds, loader=loader)
    play_include = play.get_blocks()[0]
    assert(type(play_include.preprocess_data(play_include._attributes))) == dict

# Generated at 2022-06-21 00:53:29.839789
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():

    from ansible.playbook.test_helpers import load_fixture

    # Loads the content of test_helpers/fixtures/test_PlaybookInclude.yml
    # as a PlaybookInclude, then run the test
    ds = PlaybookInclude.load(load_fixture('test_PlaybookInclude.yml'), '.')

    assert ds is not None

# Generated at 2022-06-21 00:53:37.405926
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # source that has absolute path...
    source = '/path/to/playbook/some_file'
    # ... should remain the same

    # AnsibleBaseYAMLObject is the class that the mock of the yaml_load_unsafe
    # method will return
    with patch('ansible.playbook.include.PlaybookInclude._yaml_load_unsafe') as yaml_load_unsafe:
        # yaml_load_unsafe should always return the same object, in order to always
        # get the same result from the load_data method
        yaml_load_unsafe.return_value = AnsibleBaseYAMLObject(source, {'_import_playbook': source})

        # init the object
        obj = PlaybookInclude()

        # load the data
        obj.load_data(source)

   

# Generated at 2022-06-21 00:53:49.414528
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    loader = DataLoader()
    variable_manager = VariableManager()

    basedir = os.path.dirname(__file__)


# Generated at 2022-06-21 00:53:59.287505
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping

    ds = AnsibleMapping()
    ds["import_playbook"] = "foo.yml"
    ds["vars"] = dict(foo=1)
    ds["tags"] = "one,two"
    ds["connection"] = "local"

    plb = PlaybookInclude().preprocess_data(ds)

    assert plb.import_playbook == "foo.yml"
    assert plb.vars == dict(foo=1)
    assert plb.tags == ['one', 'two']
    assert plb.connection == "local"

    ds = AnsibleMapping()
    ds["import_playbook"] = "foo.yml"
    ds["tags"] = "one,two"



# Generated at 2022-06-21 00:54:03.534440
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    data = 'foo.yml'
    data_obj = PlaybookInclude.load(data, basedir='/')
    assert data_obj.import_playbook == 'foo.yml'

    data = 'foo.yml with_items=bar.yml'
    data_obj = PlaybookInclude.load(data, basedir='/')
    assert data_obj.import_playbook == 'foo.yml'
    assert data_obj.vars == {'with_items': 'bar.yml'}

    data = 'foo.yml with_items=bar.yml'
    data_obj = PlaybookInclude.load(data, basedir='/')
    assert data_obj.import_playbook == 'foo.yml'

# Generated at 2022-06-21 00:54:11.244580
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''
    NOTE: This test is different from most tests in ansible-test.  This test uses
    ansible-test to run a playbook which checks out a collection and then executes
    a playbook that is part of that collection.  This test is a bit of a hack.  But
    it works.

    You can execute this test like so:
    ansible-test sanity --test test_PlaybookInclude_load_data

    You will see the test pass.
    '''
    pass

# Generated at 2022-06-21 00:54:21.800931
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    import unittest
    import yaml

    # Note that the yaml for the test below is hard-coded below because this is a relatively simple test.
    # However, in the real-world case, ansible-playbook parses the input yaml file and creates a data
    # structure before passing it to the load method.
    playbook_include_yaml = yaml.load("""
- hosts: localhost
  import_playbook: pb.yml
  vars:
    - a: 1
    - b: 1
    - c: 1
    - d: 1
    - e: 1
""")

    # Create the object to test
    playbook_include = PlaybookInclude()

    # Load the data into the object

# Generated at 2022-06-21 00:54:31.869333
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    ds = AnsibleMapping()
    ds["- include"]="test.yml"
    ds["vars"]="a: 1"
    ds["tags"]="tag1"
    ds["when"]="1"
    ds.ansible_pos = 1, 0
    result = PlaybookInclude().preprocess_data(ds)
    assert isinstance(result, AnsibleMapping)
    assert len(result) == 4
    assert result["import_playbook"] == "test.yml"
    assert result["vars"] == "a: 1"
    assert result["tags"] == "tag1"
    assert result["when"] == "1"
    assert result.ansible_pos == 1, 0
    assert isinstance(result["vars"], dict)


# Generated at 2022-06-21 00:54:45.313192
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Test 1.
    test_obj = PlaybookInclude()
    test_ds = {'import_playbook': 'site.yml', 'tags': ['foo', 'bar']}
    expected_result = {'import_playbook': 'site.yml', 'tags': 'foo,bar'}
    actual_result = test_obj.preprocess_data(test_ds)
    assert expected_result == actual_result

    # Test 2.
    test_obj = PlaybookInclude()
    test_ds = {'include': 'site.yml', 'tags': ['foo', 'bar']}
    expected_result = {'import_playbook': 'site.yml', 'tags': 'foo,bar'}
    actual_result = test_obj.preprocess_data(test_ds)

# Generated at 2022-06-21 00:55:00.626165
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    loader = None
    variable_manager = None
    v = 'vars'
    ds1 = [
        ('import_playbook', 'import_playbook.yml'),
        ('vars', dict(a=1)),
        (v, dict()),
    ]
    ds2 = dict(
        [
            ('import_playbook', 'import_playbook.yml'),
            ('vars', dict(a=1)),
            (v, dict()),
        ]
    )
    obj = PlaybookInclude.load(ds1, 'basedir', variable_manager, loader)
    obj = PlaybookInclude.load(ds2, 'basedir', variable_manager, loader)
    #
    # assert len(obj.vars) == 1
    # assert 'a' in obj.vars
    #

# Generated at 2022-06-21 00:55:11.715045
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include = PlaybookInclude()

    # Test incorrect datastructures
    playbook_include._preprocess_import(
        {'import_playbook': "filepath.yml"},
        {},
        'import_playbook',
        None
    )

    playbook_include._preprocess_import(
        {'import_playbook': None},
        {},
        'import_playbook',
        None
    )

    playbook_include._preprocess_import(
        {'import_playbook': []},
        {},
        'import_playbook',
        None
    )

    playbook_include._preprocess_import(
        {'import_playbook': 123},
        {},
        'import_playbook',
        123
    )


# Generated at 2022-06-21 00:55:13.287596
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # TODO
    pass


# Generated at 2022-06-21 00:55:21.083312
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # arrange
    from ansible.playbook import Playbook
    from ansible.parsing.vault import VaultLib

    data = '''
- hosts: localhost
  gather_facts: no
  tasks: []
'''
    temp_data = '''
- hosts: localhost
  gather_facts: no
  vars:
    key: value
  tasks: []
'''

    # act
    playbook = Playbook.load('/some/file', 'content', vault_password='password')

    pb_include = PlaybookInclude()
    pb_include.loader = None
    pb_include.vars = dict()
    pb_include.import_playbook = data
    pb = pb_include.load_data(pb_include, '/', variable_manager=None, loader=None)

# Generated at 2022-06-21 00:55:23.492758
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # Testing load method of class PlaybookInclude
    pass

# Generated at 2022-06-21 00:55:33.986027
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.play import Play

    # Test loading an empty playbook include
    playbook_include = PlaybookInclude()
    # load the data
    ds = AnsibleMapping()
    playbook_include = playbook_include.load_data(ds, basedir=None)
    # Ensure the result is an empty Playbook
    assert playbook_include._entries == []

    # Test loading a playbook include with a single play
    playbook_include = PlaybookInclude()
    # Create the data structure
    playbook_data = AnsibleMapping()
    playbook_data['import_playbook'] = 'playbook.yml'
    # Set the data and get the playbook object

# Generated at 2022-06-21 00:55:43.630828
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_str="""
- import_playbook: collection.my_namespace.my_name.my_playbook.yml
  when: "True"
  vars:
    var1: true
"""

    pb_inc = PlaybookInclude.load(data=yaml_str, basedir=None)
    actual = AnsibleDumper().dump(pb_inc, width=60)
    expected = """
- import_playbook: collection.my_namespace.my_name.my_playbook.yml
  vars:
    var1: true
  when:
  - True
"""
    assert actual == expected


# Generated at 2022-06-21 00:55:53.495177
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.variable_manager import VariableManager
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(InventoryManager(loader=loader))
    variable_manager.set_vars({'testvar': 'test1'})
    variable_manager._extra_vars = {'extra': 'test2'}


# Generated at 2022-06-21 00:55:56.007427
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    playbook_include = PlaybookInclude()
    assert playbook_include.__class__.__name__ == 'PlaybookInclude'

# Generated at 2022-06-21 00:56:04.689434
# Unit test for method load of class PlaybookInclude

# Generated at 2022-06-21 00:56:21.169556
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # Import playbook without args
    import_no_args = "test.yml"
    ds = {C._ACTION_IMPORT_PLAYBOOK: import_no_args}
    new_ds = PlaybookInclude._preprocess_import(ds, ds, C._ACTION_IMPORT_PLAYBOOK, import_no_args)
    assert 'import_playbook' in new_ds
    assert 'vars' not in new_ds
    assert 'tags' not in new_ds
    assert new_ds['import_playbook'] == "test.yml"

    # Import playbook with args
    import_args = "test.yml extra=foo other=bar"
    ds = {C._ACTION_IMPORT_PLAYBOOK: import_args}

# Generated at 2022-06-21 00:56:31.829169
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    import io
    import textwrap

    p = PlaybookInclude()
    vars = dict()

    # p must be a Playbook object after call to load_data method
    # with a path to a file returning a Play object
    test_file = io.StringIO(textwrap.dedent(u'''
        ---
        - hosts: localhost
          gather_facts: no
          tasks:
            - name: ping
              ping:
    '''))
    loaded_object = p.load_data(
        ds=dict(
            import_playbook='ping.yml'
        ),
        basedir='/tmp',
        variable_manager=None,
        loader=None
    )

# Generated at 2022-06-21 00:56:42.290568
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    var_manager = None
    loader = None
    inventory = None
    ds = dict(
        import_playbook='test_import.yml',
        vars=dict(
            test_var1=1,
            test_var2=2
        ),
    )
    pi = PlaybookInclude.load(ds=ds, basedir='.', variable_manager=var_manager, loader=loader)
    assert pi.get_vars()['test_var1'] == 1
    assert pi.get_vars()['test_var2'] == 2

    ds = dict(
        import_playbook='test_import.yml tags=test1,test2',
    )
    pi = PlaybookInclude.load(ds=ds, basedir='.', variable_manager=var_manager, loader=loader)


# Generated at 2022-06-21 00:56:53.314003
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    import ansible.constants as C
    import ansible.playbook.playbook_include as playbook_include

    # Test PlaybookInclude no parameter
    with pytest.raises(AnsibleParserError):
        playbook_include.PlaybookInclude._preprocess_import({}, {}, 'import_playbook', ' ')

    # Test PlaybookInclude single parameter No Error
    playbook_include.PlaybookInclude._preprocess_import({}, {}, 'import_playbook', './play.yml')

    # Test PlaybookInclude two parameter No Error

# Generated at 2022-06-21 00:57:02.152584
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    '''
    Unit test for method load_data of class PlaybookInclude
    '''
    import os
    import tempfile

    with tempfile.NamedTemporaryFile() as pb_file:
        pb_file.write('{"1":"1"}')
        pb_file.flush()

        # test no file name specified
        data = {'import_playbook':''}
        pbi = PlaybookInclude.load(data, os.getcwd())
        assert pbi.import_playbook == ''

        # test valid file name specified
        data = {'import_playbook':pb_file.name}
        pbi = PlaybookInclude.load(data, os.getcwd())
        assert pbi.import_playbook == pb_file.name

# Generated at 2022-06-21 00:57:07.974519
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # Create a mock playbook object
    pb = Playbook()

    # Create a mock playbook object
    import_pb = PlaybookInclude()

    # Create a mock play object
    play = Play()

    # Create a mock task object
    task1 = Task()

    # Create a mock task object
    task2 = Task()

    # Create a mock task object
    task3 = Task()

    # Create a mock task object
    task4 = Task()

    # Create a mock task object
    task5 = Task()

    # Create a mock task object
    task6 = Task()

    # Create a mock task object
    task7 = Task()

    # Create a mock task object
    task8 = Task()

    # Create a mock task object
    task9 = Task()

    # Create a mock task object
    task10 = Task()



# Generated at 2022-06-21 00:57:16.140313
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    ds = dict(
        dict(
            include=dict(
                file='play.yaml',
                vars=dict(
                    foo='bar',
                    tags=['tag1', 'tag2']
                ),
                tasks=dict(
                    debug=dict(
                        msg='test'
                    )
                )
            )
        ),
        dict(
            include=dict(
                file='play.yaml',
                var1='1',
                foo='bar',
                tags='tag1,tag2'
            )
        ),
        dict(
            include=dict(
                file='play.yaml',
                foo='bar',
                tags='tag1,tag2',
                tasks=dict(
                    debug=dict(
                        msg='test'
                    )
                )
            )
        )
    )

# Generated at 2022-06-21 00:57:27.289244
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.yaml.loader import AnsibleLoader

    def assert_ds(ds, expect):
        if 'tasks' in ds:
            ds['tasks'] = [e.get_name() for e in ds['tasks']]
        if 'pre_tasks' in ds:
            ds['pre_tasks'] = [e.get_name() for e in ds['pre_tasks']]
        if 'post_tasks' in ds:
            ds['post_tasks'] = [e.get_name() for e in ds['post_tasks']]

# Generated at 2022-06-21 00:57:38.424469
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    import os
    import sys

    sys.path.append(os.path.abspath(os.path.dirname(__file__)+'/../../../'))

    p = PlaybookInclude.load(yaml.load("""
    import_playbook: test.yml
    """), basedir="test/integration/inventory", variable_manager=None, loader=None)
    assert isinstance(p, Playbook)

    entry = p._entries[0]
    assert isinstance(entry, Play)
    assert entry.hosts == "all"
    assert entry.name == "test play"

    entry = p._entries[1]
    assert isinstance(entry, Play)

# Generated at 2022-06-21 00:57:46.555524
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    from ansible.utils.collection_loader import _load_collections
    from ansible.plugins import module_loader
    from ansible.parsing.dataloader import DataLoader

    def _create_collection_loader(collections=None):
        loader = DataLoader()
        if collections is not None:
            _load_collections(collections, loader)
        return loader

    import ansible.playbook
    import ansible.module_utils
    import ansible.inventory
    import ansible.vars
    import ansible.compat

    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.plugins.loader import module_loader


# Generated at 2022-06-21 00:58:07.016639
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import tempfile
    import os
    import shutil
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.modules.source_control.git import _git_common

    dir_name = tempfile.mkdtemp()
    os.makedirs(os.path.join(dir_name, 'test_playbook'))
    with open(os.path.join(dir_name, 'test_playbook', 'test_playbook.yml'), 'w') as f:
        f.write("test_var: test_value")

# Generated at 2022-06-21 00:58:17.489204
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Tests that the method load_data of class PlaybookInclude can return a new Playbook object with imported data
    # Test case 1: a playbook doesn't exist
    ds = {'include': 'not_existing_playbook.yml'}
    basedir = os.path.abspath('.')
    # TODO - replace the following line with a mock object
    variable_manager = None
    loader = None
    playbook_include_obj = PlaybookInclude.load(ds, basedir, variable_manager, loader)
    assert playbook_include_obj is None

    # Test case 2: a playbook exists, but it is not a well-formed playbook
    ds = {'include': 'test/data/playbooks/not_well_formed_playbook.yml'}
    playbook_include_obj = PlaybookInclude.load

# Generated at 2022-06-21 00:58:27.997455
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # Test load_data of the PlaybookInclude class
    import os
    import tempfile
    import yaml

    def _get_reference_playbook(playbook_filename):
        """
        Create a reference playbook with a single included file to be validated.
        """
        playbook_include_content = '''
# This is a simple comment
- import_playbook: '{0}'
  vars:
    foo: bar
  tags:
    - test1
    - test2
'''.format(playbook_filename)
        playbook_content = '''
# comment
- include: included_playbook1.yml
'''
        ref_playbook = tempfile.NamedTemporaryFile(delete=False)
        with open(playbook_include_content) as f:
            included_playbook1_content = f

# Generated at 2022-06-21 00:58:39.406483
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    yaml_text = """
    - import_playbook: /home/ansible/some_playbook.yml
      vars: { arg_one: 1, arg_two: 2, arg_three: qwerty}
      tags: deprecated
    """

    pb_include = PlaybookInclude.load(data=yaml_text, variable_manager=None, loader=None)
    assert pb_include.import_playbook == "/home/ansible/some_playbook.yml"
    assert pb_include.vars == {
        "arg_one": 1,
        "arg_two": 2,
        "arg_three": "qwerty",
    }
    assert pb_include.tags == ["deprecated"]

# Generated at 2022-06-21 00:58:48.395549
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.six import PY3
    if PY3:
        from io import StringIO
    else:
        from StringIO import StringIO

    # Define a fake resource from collections
    def _get_collection_playbook_path(name):
        if name == 'my.playbook':
            return ('my.playbook','/fake/playbook.yml', 'my.playbook')

    # Define a fake resource from collections
    def _get_collection_name_from_path(path):
        if path == '/fake/playbook.yml':
            return 'my.playbook'

    # Define temporary fake resource

# Generated at 2022-06-21 00:58:52.434288
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include = PlaybookInclude()
    playbook_include.load_data({'import_playbook': 'imported.yml'}, '.')


# Generated at 2022-06-21 00:58:55.182078
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    playbook_include = PlaybookInclude.load("include: c.yml", "./")
    assert playbook_include.import_playbook == "c.yml"


# Generated at 2022-06-21 00:59:00.588096
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Setup
    ds = {}
    ds['include'] = 'test_import.yml'
    ds['tags'] = 'test'
    ds['vars'] = {'a': 'b'}
    new_ds = {}
    playbook_include = PlaybookInclude()

    # Execute
    playbook_include.preprocess_data(ds)

    # Assert
    assert ds['vars'] == new_ds['vars']
    assert ds['tags'] == new_ds['tags']
    assert ds['include'] == new_ds['import_playbook']



# Generated at 2022-06-21 00:59:05.769922
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook_include = PlaybookInclude()
    ds = {'import_playbook': 'test.yml', 'vars': {'foo': 'a', 'bar': 'b'}}
    pb = playbook_include.load_data(ds, None, None)

    assert pb._entries
    assert pb._entries[0].vars['foo'] == 'a'

# Generated at 2022-06-21 00:59:19.037002
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    loader = DataLoader()

    play_text = """
    - include: tasks.yml
      vars:
        key: value
    """
    play_ds = loader.load(play_text)[0]
    play = Play().load(play_ds, variable_manager=None, loader=loader)

    task = play.tasks[0]
    assert isinstance(task, TaskInclude)
    assert task._role_name == 'tasks'
    assert task.vars == {'key': 'value'}
    assert task.static is True


# Generated at 2022-06-21 00:59:38.472761
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook.play import Play
    import os
    import tempfile
    basedir = os.path.dirname(__file__)
    dir_name = tempfile.mkdtemp()
    p = PlaybookInclude.load({"import_playbook": "test_playbook_include.yml"}, basedir, variable_manager=None)
    first_entry_of_pb = p._entries[0]
    assert isinstance(first_entry_of_pb, Play)
    assert first_entry_of_pb.name == 'test play'
    p2 = PlaybookInclude.load({"import_playbook": "test_playbook_include.yml", "tags": "test"}, basedir, variable_manager=None)
    first_entry_of_pb = p2._entries[0]


# Generated at 2022-06-21 00:59:47.335010
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    '''
    Test load method of class PlaybookInclude.
    '''
    from ansible.playbook import Playbook

    ds = dict(import_playbook='test_playbook.yml',
              vars=dict(ofirst=1, osecond=2),
              tags=['otag1', 'otag2'],
              when=dict(cfirst=1, csecond=2))
    basedir = '/tmp'

    result = PlaybookInclude.load(ds=ds, basedir=basedir)

    assert isinstance(result, Playbook)
    assert result._entries[0]._included_path == '/tmp'
    assert result._entries[0].vars == dict(ofirst=1, osecond=2)

# Generated at 2022-06-21 00:59:58.214714
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    # Test invalid datastructures
    ds = [42, "foo"]
    try:
        PlaybookInclude.load(ds, basedir=None)
        assert False
    except AnsibleAssertionError:
        assert True

    ds = 42
    try:
        PlaybookInclude.load(ds, basedir=None)
        assert False
    except AnsibleAssertionError:
        assert True

    # Test PlaybookInclude with one subkey
    for k, v in {
            "import_playbook": "foobar",
        }.items():
        ds = {k: v}
        try:
            PlaybookInclude.load(ds, basedir=None)
            assert False
        except AnsibleParserError:
            assert True

    # Test PlaybookInclude with one valid import subkey

# Generated at 2022-06-21 01:00:07.898117
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from collections import OrderedDict  # Use OrderedDict to make comparisons independent of dictionary ordering

    # old 'include' form
    ds = OrderedDict([('include', 'my_plabook.yml')])
    playbook_include_obj = PlaybookInclude()
    obj = playbook_include_obj.preprocess_data(ds)
    assert obj == {'import_playbook': 'my_plabook.yml'}

    # new 'import_playbook' form
    ds = OrderedDict([('import_playbook', OrderedDict([('name', 'my_plabook.yml')]))])
    obj = playbook_include_obj.preprocess_data(ds)
    assert obj == {'import_playbook': 'my_plabook.yml'}

    # validate

# Generated at 2022-06-21 01:00:19.821176
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.data import DataLoader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.collection_loader._collection_finder import AnsibleCollectionFinder

    # Define test data
    loader = DataLoader()

# Generated at 2022-06-21 01:00:30.717468
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.playbook.play import Play

    def get_play(with_conditional=False):
        p = Play().load(dict(
            name="test play",
            hosts="foo",
            tasks=[dict(action=dict(module="ping"))]
        ), variable_manager=variable_manager, loader=loader)
        if not with_conditional:
            p._included_conditional = None
        return p

    # Create a loader since this would be called by the Playbook constructor
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    variable_manager = None
    playbook_include = PlaybookInclude()

    # Test that the correct variable is set when the import_playbook variable is declared in the normal way

# Generated at 2022-06-21 01:00:41.609057
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    import sys
    import ast
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    ack_good = "import_playbook: hello.yml"
    ack_good_b = "import_playbook:\n  - hello.yml"
    ack_good_c = "import_playbook:\n" + "  - hello.yml"
    ack_good_d = "import_playbook: hello.yml\nother_param: other"
    ack_good_e = "import_playbook: hello.yml with spaces"
    ack_good_x = "import_playbook: hello.yml with spaces\n  vars:\n    foo: bar\n    baz: 12345"

# Generated at 2022-06-21 01:00:42.580048
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-21 01:00:49.944127
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    from ansible.utils import context_objects as co

    pb = PlaybookInclude()
    pb.import_playbook = 'test/test1.yml'
    pb.vars['x'] = '{{ 1+2 }}'
    pb.vars['y'] = '{{ test1 }}'

    pb = pb.load(ds=pb.dump(), basedir='/tmp', variable_manager=co.VariableManager(), loader=co.Loader())
    assert isinstance(pb, Playbook)
    assert pb.vars['x'] == '3'
    assert pb.vars['y'] == 'test1'

# Generated at 2022-06-21 01:00:50.819038
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-21 01:01:20.527482
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    m_ds = AnsibleMapping()
    m_ds['import_playbook'] = 'someplaybook.yml'
    m_ds['tags'] = ['a_tag']
    m_ds['vars'] = {'a_var': 'a_value', 'b_var': 'b_value'}
    pi = PlaybookInclude.load(data=m_ds, basedir='/a/path')
    assert isinstance(pi, PlaybookInclude)
    assert pi.import_playbook == 'someplaybook.yml'
    assert pi.tags == ['a_tag']
    assert pi.vars['a_var'] == 'a_value'
    assert pi.vars['b_var'] == 'b_value'
    # No basedir

# Generated at 2022-06-21 01:01:31.864077
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import unittest
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    # this is just a stub for the moment since the module is not fully implemented yet
    class PlaybookInclude_test(unittest.TestCase):

        loader = DataLoader()

        def setUp(self):
            self.variable_manager = VariableManager()

        def tearDown(self):
            self.variable_manager = None

        def test_load_data(self):
            import os
            dir = os.path.dirname(__file__)
            include_path = os.path.join(dir, 'fixtures/include_file.yml')
            fh = open(include_path, 'rb')
            ds = self.loader.load(fh)

# Generated at 2022-06-21 01:01:43.472869
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    test_cases = dict()

    test_cases[0] = dict(
        desc='Test class attributes are set by constructor',
        data=dict(
            import_playbook='/some/where/foo.yml',
            vars=dict(
                foo='bar',
                baz='faz',
            ),
            tags=dict(
                always='true',
            ),
        ),
        exp_class_attributes=dict(
            import_playbook='/some/where/foo.yml',
            vars=dict(
                foo='bar',
                baz='faz',
            ),
            tags=['always'],
        ),
    )

    test_cases[1] = test_cases[0].copy()
    test_cases[1]['desc']='Test class attributes are set by calling load'

# Generated at 2022-06-21 01:01:51.532171
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    # Test the function preprocess_data with specifying playbook with ansible-test
    playbook_path = "/path/to/test-playbook.yml"
    playbook_include = PlaybookInclude()
    test_data_dict = {
        "import_playbook": "ansible-test ansible/test/integration/foo/playbook.yaml"
    }

    # Test the function preprocess_data with specifying playbook without ansible-test
    playbook = playbook_include.preprocess_data(test_data_dict)["import_playbook"]
    assert playbook == playbook_path

    # Test the function preprocess_data with vars

# Generated at 2022-06-21 01:02:01.738889
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    text1 = """
        tasks:
          - name: test
            debug: msg={{ test1 }}
    """
    text2 = """
        tasks:
          - name: test2
            debug: msg={{ test2 }}
    """

    # Test constructor of the class PlaybookInclude - constructor of the class Base
    pb = PlaybookInclude()
    assert isinstance(pb, Base)

    # Test constructor of the class PlaybookInclude - constructor of the class Conditional
    pb = PlaybookInclude()
    assert isinstance(pb, Conditional)

    # Test constructor of the class PlaybookInclude - constructor of the class Taggable
    pb = PlaybookInclude()

# Generated at 2022-06-21 01:02:02.616307
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    pass

# Generated at 2022-06-21 01:02:10.540614
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    play_book_include1 = PlaybookInclude()
    play_book_include2 = PlaybookInclude()
    play_book_include1.import_playbook="../../examples/apache.yml"
    play_book_include1.tags=["databases", "dev", "web"]
    play_book_include1.vars = {"foo": "bar", "baz": "buzz"}
    assert play_book_include1 != play_book_include2

# Generated at 2022-06-21 01:02:23.565997
# Unit test for method preprocess_data of class PlaybookInclude

# Generated at 2022-06-21 01:02:26.783092
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.tasks import Task

    playbook = PlaybookInclude.load({'import_playbook': './playbook.yml'})

    assert isinstance(playbook, Playbook)
    assert len(playbook.entries) == 1

    play = playbook.entries[0]
    assert isinstance(play, Play)
    assert len(play.tasks) == 1

    task = play.tasks[0]
    assert isinstance(task, Task)
    assert task.name == 'name'

# Generated at 2022-06-21 01:02:28.712901
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # playbook_include is of type PlaybookInclude
    playbook_include = PlaybookInclude()

    assert playbook_include is not None


# Generated at 2022-06-21 01:03:02.728466
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    fake_playbook_path = os.path.join(os.getcwd(), "playbook.yml")
    fake_playbook_dir = os.path.dirname(fake_playbook_path)

    with open(fake_playbook_path, 'w') as f:
        f.write("""
        ---
        - hosts: all
          tasks:
            - debug:
                msg: ok
            - name: include tasks from another file
              include: test_include.yml
              vars:
                extra_var: 3
            - debug:
                msg: ok
        """)

    fake_include_path = os.path.join(fake_playbook_dir, "test_include.yml")

# Generated at 2022-06-21 01:03:04.593821
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pbi = PlaybookInclude()
    assert pbi.import_playbook is None