

# Generated at 2022-06-21 00:53:22.823286
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.template import Templar
    import ansible.constants as C
    templar = Templar(loader=None, variables={})

    # Check without FQCN
    pbx = PlaybookInclude()
    pbx._import_playbook = 'test_playbook.yml'
    pbx._vars = {'a': 'b', 'c': 'd'}
    pbx.tags = ['tag1', 'tag2']
    pb = pbx.load_data(ds=None, basedir=None, variable_manager=None, loader=None)
    assert isinstance(pb, Playbook)
    assert len(pb._entries) == 1

# Generated at 2022-06-21 00:53:32.100711
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    module = PlaybookInclude()
    ds = {}
    result = module.preprocess_data(ds)
    assert result == ds

    ds = {'z':1}
    result = module.preprocess_data(ds)
    assert result == ds

    ds = {'import_playbook':'name.yml'}
    result = module.preprocess_data(ds)
    assert result['import_playbook'] == 'name.yml'

    ds = {'import_playbook':'name.yml tags=tagname'}
    result = module.preprocess_data(ds)
    assert result['import_playbook'] == 'name.yml'
    assert result['tags'] == 'tagname'


# Generated at 2022-06-21 00:53:44.037549
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.playbook_include import PlaybookInclude

    # Test a normal dict
    d = dict(playbook='./file1.yaml', tags='foo,bar')
    ds = PlaybookInclude.preprocess_data(d)
    assert 'playbook' in ds
    assert ds['playbook'] == d['playbook']
    assert 'tags' in ds
    assert ds['tags'] == 'foo,bar'

    # Test a "normal" import_playbook line
    d = dict(playbook='./file1.yaml', tags='foo,bar', some_var='value1')
    ds = PlaybookInclude.preprocess_data(d)
    assert 'import_playbook' in ds

# Generated at 2022-06-21 00:53:49.045323
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    playbook_include = PlaybookInclude()
    load = playbook_include.load(
        data = {
            'import_playbook': 'foobar.yml'
        },
        basedir = 'test_data'
    )
    assert load is not None

# Generated at 2022-06-21 00:53:59.062453
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():

    from ansible.parsing.yaml.loader import AnsibleLoader
    loader = AnsibleLoader(None, dict())

    # check for missing value
    ds_missing = AnsibleMapping(loader=loader)
    ds_missing['include'] = 'import_playbook'
    assert PlaybookInclude().preprocess_data(ds_missing) == dict()

    # check for bad value type
    ds_bad_value = AnsibleMapping(loader=loader)
    ds_bad_value['include'] = 'import_playbook'
    ds_bad_value['import_playbook'] = ['bad_type']
    assert PlaybookInclude().preprocess_data(ds_bad_value) == dict()

    # check for error on additional parameters

# Generated at 2022-06-21 00:54:11.907251
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    class MockVariableManager(object):
        def __init__(self, value):
            self.value = value
        def get_vars(self):
            return self.value

    class MockTemplar(object):
        def __init__(self, value):
            self.value = value
        def template(self, value):
            return self.value

    class MockLoader(object):
        def __init__(self, value):
            self.value = value
        def get_basedir(self):
            return self.value

    class MockPlaybook(object):
        def __init__(self, loader=None):
            self.loader = loader
        def _load_playbook_data(self, file_name, variable_manager, vars=None):
            self.file_name = file_name
            self.variable_

# Generated at 2022-06-21 00:54:20.293148
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    pbi = PlaybookInclude()
    # Test load_data
    pbi.load_data({}, '')
    pbi.load_data({'import_playbook': '/path/to/pb1'}, '/path/to')
    pbi.load_data({'import_playbook': 'pb1'}, '/path/to')
    # Test preprocess_data
    pbi.preprocess_data({})
    pbi.preprocess_data({'import_playbook': 'pb1'})
    pbi.preprocess_data({'import_playbook': '/path/to/pb1'})

# Generated at 2022-06-21 00:54:20.886518
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass # TODO

# Generated at 2022-06-21 00:54:31.099246
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():

    # import here to avoid a dependency loop
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    # test PlaybookInclude.load() with invalid ds
    pbi = PlaybookInclude()
    try:
        pbi.load(ds=None, basedir=None)
    except AnsibleParserError as e:
        assert "parameter is missing" in str(e), str(e)

    # test PlaybookInclude.load() with invalid basedir
    ds = "invalid_name.yml"
    try:
        pbi.load(ds=ds, basedir=None)
    except AnsibleParserError as e:
        assert "Could not find or access" in str(e), str(e)

    # test PlaybookInclude load with valid ds

# Generated at 2022-06-21 00:54:43.940316
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    p = PlaybookInclude()

    # test play initialization
    p.import_playbook = "test_playbook.yml"
    assert p.import_playbook == "test_playbook.yml"

    # Test whether playbook parsing is working
    if os.path.exists("test_playbook.yml"):
        os.remove("test_playbook.yml")
    fd = open("test_playbook.yml", "w")
    fd.write("- hosts: all\n  tasks:\n    - debug: msg=\"This is a test message\"\n")
    fd.close()

# Generated at 2022-06-21 00:54:58.625024
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # Create object
    obj = PlaybookInclude()

    # Check fields
    assert obj._import_playbook == None
    assert obj._vars == {}

# Generated at 2022-06-21 00:55:10.659382
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # imports needed for these tests
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.template import Templar

    # setup
    basedir = "/path/to/basedir/"
    variable_manager = None
    loader = None
    # test data
    playbook_include_data = {'import_playbook': 'test_playbook.yml'}

    # run test
    test_playbook_include = PlaybookInclude.load(data=playbook_include_data, basedir=basedir, variable_manager=variable_manager, loader=loader)
    # assert that the data is correct
    assert isinstance(test_playbook_include, Playbook)

    # now load the data again, but with a template
    # setup
    variable_manager = variable_manager = D

# Generated at 2022-06-21 00:55:20.415410
# Unit test for constructor of class PlaybookInclude

# Generated at 2022-06-21 00:55:32.629717
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader

    ds = dict(
        import_playbook='~/ansible-playbooks/roles/foo/tasks/main.yml',
        vars={
            'nginx_port': 8080
        }
    )
    basedir = '/etc/ansible'

    pbi = PlaybookInclude()
    pbi.load_data(
        ds,
        basedir,
        variable_manager=None,
        loader=action_loader
    )

    assert pbi._import_playbook == '~/ansible-playbooks/roles/foo/tasks/main.yml'

# Generated at 2022-06-21 00:55:42.097346
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    ds = AnsibleMapping()

    ds['import_playbook'] = './test.yml'
    ds['vars'] = { 'foo': 'bar' }

    result = PlaybookInclude.preprocess_data(ds)
    assert result == ds

    ds = AnsibleMapping()

    ds['include'] = './test.yml'
    ds['vars'] = { 'foo': 'bar' }

    result = PlaybookInclude.preprocess_data(ds)
    assert result == ds

    ds = AnsibleMapping()

    ds['import_playbook'] = './test.yml'
    ds['vars'] = { 'foo': 'bar' }
    result

# Generated at 2022-06-21 00:55:43.564195
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass


# Generated at 2022-06-21 00:55:54.836647
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook import Playbook
    from ansible.parsing.yaml.objects import AnsibleSequence

    # test creation of a playbook
    pb = PlaybookInclude.load({u"import_playbook": u"/var/tmp/foo.yml"}, u"/usr/local/lib/ansible/")
    assert isinstance(pb, Playbook)

    # test failure
    try:
        PlaybookInclude.load({u"import_playbook": None}, u"/usr/local/lib/ansible/")
    except AnsibleParserError:
        pass

# Generated at 2022-06-21 00:56:03.995142
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():

    # Test for playbook include with valid data
    ds = dict( import_playbook = 'some_playbook' )
    pb = PlaybookInclude()
    pb_result = pb.load_data( ds = ds, basedir = '/some_path/playbooks' )

    assert pb_result.filename == os.path.join( '/some_path/playbooks', 'some_playbook')
    assert len( pb_result.plays ) == 1
    assert pb_result.vars == {}
    assert pb_result.roles == []
    assert pb_result._entries[0].hosts == 'all'

    # Test for playbook include with invalid data

# Generated at 2022-06-21 00:56:13.314509
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.module_utils.six.moves import StringIO
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    warning_messages = []
    output = StringIO()
    yaml = AnsibleLoader(output, warnings=warning_messages)

    variable_manager = VariableManager()
    variable_manager.extra_vars = {"test": "value"}
    variable_manager.options_vars = {"options_var": "value"}
    variable_manager.set_nonpersistent_facts({"nonpersistent_fact": "value"})

   

# Generated at 2022-06-21 00:56:14.313454
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
   v = PlaybookInclude()
   assert(v)

# Generated at 2022-06-21 00:56:28.024561
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # dummy class vars, just to prevent errors
    data = {}  # AnsibleMapping
    basedir = None
    variable_manager = None
    loader = None

    pbincl = PlaybookInclude.load(data, basedir, variable_manager, loader)
    assert pbincl is not None

# Generated at 2022-06-21 00:56:40.622926
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    # Import here to avoid a dependency loop
    from ansible.playbook.play import Play
    from ansible.template import Templar
    import os
    import sys

    # Load a real playbook
    playbook_file = 'playbook_include.yml'
    basedir = os.path.dirname(os.path.abspath(to_bytes(__file__)))
    playbook_file = os.path.join(basedir, playbook_file)
    kwargs = dict(filename=playbook_file, loader=None, variable_manager=None, passwords=None)
    pbi = PlaybookInclude.load(kwargs['filename'], basedir, **kwargs)

    # Check that the loader was deleted
    assert pbi._loader is None

    # Check that the variable manager was deleted

# Generated at 2022-06-21 00:56:51.671874
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    import unittest
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    class AnsibleModule:
        def __init__(self, params):
            self.params = params
    class AnsibleMockMixin:
        def __init__(self, params):
            self.params = params
            self.result = dict(
                msg = 'sentinel',
                rc = 0,
                changed = False,
                ansible_facts = dict(),
                ansible_version = dict(
                    full = '2.9.1'
                )
            )
            self.exit_json = self.exit_json_native


# Generated at 2022-06-21 00:57:01.693201
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    host = "test"
    ds = """
        - import_playbook: playbook_with_vars.yml
          vars:
            param1: value1
            param2: value2
            tags: param3
        - import_playbook: playbook_with_params.yml param1=value1 param2=value2 tags=param3
    """
    data_list = yaml.load(ds)

    expected_list = yaml.load("""
        - import_playbook: playbook_with_vars.yml
          vars:
            param1: value1
            param2: value2
            tags: param3
        - import_playbook: playbook_with_params.yml
          tags: param3
          vars:
            param1: value1
            param2: value2
    """)

# Generated at 2022-06-21 00:57:10.102167
# Unit test for constructor of class PlaybookInclude

# Generated at 2022-06-21 00:57:18.327175
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    pl = PlaybookInclude()

    assert pl.preprocess_data(dict(name='hello'), check_all_valid=True) == dict(name='hello')
    assert pl.preprocess_data(dict(import_playbook='hello'), check_all_valid=True) == dict(import_playbook='hello', tags=[])
    assert pl.preprocess_data(dict(import_playbook='hello world'), check_all_valid=True) == dict(import_playbook='hello world', tags=[])
    assert pl.preprocess_data(dict(import_playbook='hello', tags=[], random=True), check_all_valid=True) == dict(import_playbook='hello', tags=[], random=True)

# Generated at 2022-06-21 00:57:20.141327
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    assert False, "Test not implemented"


# Generated at 2022-06-21 00:57:22.305021
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    PB = PlaybookInclude()
    assert isinstance(PB, PlaybookInclude)

# Generated at 2022-06-21 00:57:23.125309
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-21 00:57:35.325710
# Unit test for method load of class PlaybookInclude

# Generated at 2022-06-21 00:58:04.986358
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    def test_normal(hosts, module_name, args, tags, vars):
        pb = PlaybookInclude()
        data = dict(
            hosts=hosts,
            import_playbook=module_name,
        )
        if vars:
            data['vars'] = vars
        if tags:
            data['tags'] = tags
        pb = pb.load(data=data, variable_manager=None, loader=None)

        assert pb.hosts == hosts
        assert pb.module_name == module_name
        assert pb.args == args
        assert pb.vars == vars
        assert pb.tags == tags

    def test_tags_as_vardict(hosts, module_name, args, tags, vars):
        pb = PlaybookInclude()


# Generated at 2022-06-21 00:58:16.774978
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    # testing normal playbook
    playbook = PlaybookInclude.load(
        data = {
            'import_playbook': 'playbook.yml',
            'vars': {
                'key1': 'val1'
            }
        },
        basedir = '/home/')
    assert isinstance(playbook, Play)
    assert playbook.vars == {'key1': 'val1'}
    assert playbook.tags == []
    assert playbook.included_files == ['/home/playbook.yml']
    assert playbook.pre_tasks == []
    assert playbook.post_tasks == []
    assert playbook.roles == []
    assert playbook.tasks[0].module_name == 'shell'
   

# Generated at 2022-06-21 00:58:23.950577
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    from ansible.parsing.dataloader import DataLoader

    yaml_data = """
- import_playbook: include_me.yml
"""
    loader = DataLoader()
    new_obj = PlaybookInclude.load(yaml_data, '.', loader=loader)

    assert new_obj.import_playbook == 'include_me.yml'

# Generated at 2022-06-21 00:58:37.923254
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    # Test empty object creation
    p = PlaybookInclude()
    assert p.vars == {}
    assert p.tags == []

    # Test load_data() method
    p = PlaybookInclude.load({'import_playbook': 'test.yml'})
    assert p.vars == {}
    assert p.tags == []
    assert p.import_playbook == 'test.yml'

    # Test load_data() method
    p = PlaybookInclude.load({'import_playbook': 'test.yml', 'tags': 'first'})
    assert p.vars == {}
    assert p.tags == ['first']
    assert p.import_playbook == 'test.yml'

    # Test load_data() method

# Generated at 2022-06-21 00:58:46.571232
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    playbook_include_object = PlaybookInclude()

    # test for playbook_include with 'tags' parameter
    ds = {'import_playbook': 'somefile.yml tags=foo,bar'}
    expected = {'import_playbook': 'somefile.yml', 'tags': 'foo,bar'}
    actual = playbook_include_object.preprocess_data(ds)
    assert expected == actual

    # test for playbook_include with 'vars' parameter
    ds = {'import_playbook': 'somefile.yml vars=foo,bar'}
    expected = {'import_playbook': 'somefile.yml', 'vars': 'foo,bar'}
    actual = playbook_include_object.preprocess_data(ds)
    assert expected == actual

    # test for playbook_include

# Generated at 2022-06-21 00:58:58.553736
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    playbook = PlaybookInclude()
    playbook.import_playbook = "playbook.yml"

    # Load the playbook including a role. This should be ignored
    playbook_data_with_role = {
        'roles': [
            'role2',
        ],
        'hosts': 'all',
        'tasks': [
            {
                'include': 'role1',
                'name': 'import role1',
            },
            {
                'include': 'role2',
                'name': 'import role2',
            }
        ]
    }
    playlist = playbook.load_data(playbook_data_with_role, '/etc/ansible/playbook/')
    assert len(playlist._entries) == 1
    assert len(playlist._entries[0].tasks) == 2
   

# Generated at 2022-06-21 00:59:08.279406
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    import os

    playbook_include_data = [
        dict(import_playbook="./testPlaybook.yaml"),
        dict(import_playbook="testPlaybook.yaml")
    ]

    basedir = os.path.join(os.path.dirname(__file__), 'playbook_include_test')
    loader = DataLoader()
    loader.set_basedir(basedir)
    inventory = InventoryManager(loader=loader, sources=["hosts"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-21 00:59:21.306696
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    '''
    Test load method of PlaybookInclude class
    '''

    # Fixture for load
    def mock_load(ds, basedir, variable_manager=None, loader=None):
        return ds

    # Fixture for load_data
    orig_load_data = PlaybookInclude.load_data

    def mock_load_data(inst, ds, basedir, variable_manager=None, loader=None):
        return ds

    PlaybookInclude.load_data = mock_load_data
    PlaybookInclude.load = mock_load

    pb = PlaybookInclude.load('', '')

    assert pb == '', 'value of pb should be a string but is %s' % type(pb)

    PlaybookInclude.load_data = orig_load_data
    Playbook

# Generated at 2022-06-21 00:59:30.014274
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    ds1 = {'import_playbook': 'playbook.yml'}
    ds2 = {'import_playbook': 'playbook.yml', 'vars': {'x': 1}}
    ds3 = {'import_playbook': 'playbook.yml', 'tags': 'tag1'}
    ds4 = {'import_playbook': 'playbook.yml', 'vars': {}, 'tags': 'tag1 tag2'}
    ds5 = {'import_playbook': 'playbook.yml', 'vars': {'x': 1}, 'tags': 'tag1 tag2'}
    ds6 = {'import_playbook': 'playbook.yml var1=val1 tags=tag1 tag2', 'vars': {'x': 1}}


# Generated at 2022-06-21 00:59:40.364985
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    import os
    import sys
    import unittest

    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.role import Role
    from ansible.utils.display import Display
    display = Display()

    class TestPlaybookInclude(unittest.TestCase):

        def setUp(self):
            self.basedir = os.path.abspath(os.path.dirname(__file__))


# Generated at 2022-06-21 01:00:21.356622
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():

    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.playbook.play import Play

    # load creates a Playbook
    p = PlaybookInclude.load({u'hosts': u'all', u'debug': u'var=hostvars[inventory_hostname]',
                              u'import_playbook': u'test.yml', u'vars': {u'var': u'/tmp'}, u'tags': u'a_tag,another_tag'})
    assert isinstance(p, Play)

    # load creates a Play with a base attribute
    assert p.base_vars

    # load creates a Play with a host attribute
    assert p.hosts and 'all' in p.hosts

# Generated at 2022-06-21 01:00:31.323295
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.block
    import ansible.playbook.role
    assert issubclass(PlaybookInclude, Base)
    assert issubclass(PlaybookInclude, Conditional)
    assert issubclass(PlaybookInclude, Taggable)

# Generated at 2022-06-21 01:00:42.626260
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])
    playbook = PlaybookInclude()
    playbook.vars = dict(
        foo = 'bar',
        foobar = 'baz',
        tags = 'foo,bar',
        foobars = dict(
            one = 'two',
            three = 'four',
        )
    )
    playbook.import_playbook = 'test_playbook.yml'
    playbook._loader = loader

# Generated at 2022-06-21 01:00:50.748901
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    # Create a sample PlaybookInclude object and a matching data structure
    import_playbook = "import_playbook.yml"
    vars = {'to_import': 'vars'}

    sample_ds = AnsibleMapping()
    sample_ds['import_playbook'] = import_playbook
    sample_ds['vars'] = vars

    sample_object = PlaybookInclude()
    sample_object.import_playbook = import_playbook
    sample_object.vars = vars

    # Load the data structure into the object and check the results
    assert sample_object.load_data(ds=sample_ds, basedir=".") != None
    assert sample_object.import_playbook == import_playbook
    assert sample_object.vars['to_import'] == 'vars'

    # Unit

# Generated at 2022-06-21 01:00:52.181282
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    pass

# Generated at 2022-06-21 01:00:56.563172
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    a = PlaybookInclude()
    a._import_playbook = 'a'
    print(a._get_parent_attribute('_import_playbook'))
    print(a.import_playbook)


# Generated at 2022-06-21 01:01:08.703046
# Unit test for method preprocess_data of class PlaybookInclude
def test_PlaybookInclude_preprocess_data():
    '''
    Test function to check the preprocess_data method of class PlaybookInclude
    :return: nothing
    '''

    pbi = PlaybookInclude()
    ds = dict( import_playbook='playbook.yml', vars=dict(a=1, b=1) )

    result = pbi.preprocess_data(ds)
    assert 'import_playbook' in result
    assert 'vars' in result
    assert 'a' in result['vars']
    assert 'b' in result['vars']
    assert result['vars']['a'] == 1
    assert result['vars']['b'] == 1
    assert result['import_playbook'] == 'playbook.yml'

# Generated at 2022-06-21 01:01:21.616737
# Unit test for constructor of class PlaybookInclude
def test_PlaybookInclude():
    import_playbook_string = "../play.yaml"
    # Below line will raise assertion error as parameter ds should be of type dict
    # import_playbook = PlaybookInclude.load(data=None, basedir="~/Ansible")
    import_playbook = PlaybookInclude.load(data=import_playbook_string, basedir="~/Ansible")
    assert isinstance(import_playbook, PlaybookInclude)
    assert not isinstance(import_playbook, Playbook)
    assert isinstance(import_playbook._ds, dict)
    assert isinstance(import_playbook.name, string_types)
    assert isinstance(import_playbook.import_playbook, string_types)
    assert import_playbook.import_playbook == import_playbook_string

# Generated at 2022-06-21 01:01:30.175152
# Unit test for method load of class PlaybookInclude
def test_PlaybookInclude_load():
    playbook_file = os.path.join(os.path.dirname(os.path.realpath(__file__)), "data", "include_role.yml")
    pb = PlaybookInclude.load(data={'include_role': {'name': 'include_role'}}, basedir=os.path.dirname(os.path.realpath(__file__)), variable_manager=None, loader=None)
    assert playbook_file == pb._entries[0].roles[0]._role.get_path()

# Generated at 2022-06-21 01:01:42.543792
# Unit test for method load_data of class PlaybookInclude
def test_PlaybookInclude_load_data():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    # Mocking the Playbook class
    playbook = Playbook()
    playbook._load_playbook_data = lambda file_name, variable_manager, vars: file_name  # pylint: disable=unnecessary-lambda
    playbook.vars = {'testvar': 'testvalue'}
    playbook.tags = ['tag1', 'tag2']
    playbook._included_path = 'test_dir'
    playbook._entries = [Block(ds={'block': 'testblock'}),
                         Play(ds={'play': 'testplay'}),
                         Task(ds={'task': 'testtask'})]
    playbook