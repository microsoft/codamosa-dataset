

# Generated at 2022-06-24 14:10:50.523024
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    """Test method run of class XAttrMetadataPP."""
    pass

# Generated at 2022-06-24 14:10:52.105515
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    import pytest
    XAttrMetadataPP()
    # TODO: check if xattr is available and actually write metadata

# Generated at 2022-06-24 14:10:54.626886
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    stored_pp = XAttrMetadataPP()
    assert stored_pp is not None

if __name__ == "__main__": # pragma: no cover
    test_XAttrMetadataPP()

# Generated at 2022-06-24 14:10:57.818155
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from .. import YoutubeDL
    x = XAttrMetadataPP()
    ydl = YoutubeDL(params = {})
    x.set_downloader(ydl)
    assert x.downloader == ydl


# Generated at 2022-06-24 14:11:08.171566
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import unittest
    import os
    from .mock_temp_dir import MockTempDirCase
    from .mock_downloader import MockYoutubeDL
    from .mock_exec_command import MockExecCommand
    from .mock_eliminate_zz_chars import MockEliminateZZChars

    info = {
        'webpage_url': 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
        'title': 'RICK ASTLEY - NEVER GONNA GIVE YOU UP',
        'description': 'I\'m never gonna give you up',
        'upload_date': '20010101',
        'format': 'best',
        'uploader': 'Rick Astley',
        'filepath': 'output_file_name',
    }

    #


# Generated at 2022-06-24 14:11:09.739615
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    postprocessor = XAttrMetadataPP(None)
    assert postprocessor is not None

# Generated at 2022-06-24 14:11:20.439421
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    import sys
    import tempfile
    from ..utils import find_xattr

    fd, temp_file = tempfile.mkstemp()

    sys.stdout.write('Testing xattr-based metadata enrichment in ' + temp_file + ': ')
    sys.stdout.flush()

    # Normal run
    pp = XAttrMetadataPP()
    res, info = pp.run({
        'filepath': temp_file,
        'webpage_url': 'https://www.youtube.com/watch?v=test-test-test',
        'title': 'test-test-test',
        'upload_date': 'test-test-test',
        'description': 'test-test-test',
        'uploader': 'test-test-test',
    })

# Generated at 2022-06-24 14:11:26.969750
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    info = {
        'webpage_url': 'http://www.youtube.com/',
        'title': 'Sample title',
        'upload_date': '20121221',
        'description': 'Sample description',
        'uploader': 'Sample uploader',
    }
    pp = XAttrMetadataPP()
    result, info = pp.run(info)
    
if __name__ == "__main__":
    test_XAttrMetadataPP()

# Generated at 2022-06-24 14:11:37.895502
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import unittest
    from ..downloader.common import FileDownloadInfo
    from ..utils import strip_jsonp

    class MockYDL:

        def __init__(self):
            self.to_screen_calls = []
            self.report_warning_calls = []
            self.report_error_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)

        def report_warning(self, msg):
            self.report_warning_calls.append(msg)

        def report_error(self, msg):
            self.report_error_calls.append(msg)


# Generated at 2022-06-24 14:11:38.446265
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    assert False

# Generated at 2022-06-24 14:11:46.784849
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..YoutubeDL import YoutubeDL

    test_dl = YoutubeDL()
    test_dl.params['simulate'] = True
    test_pp = XAttrMetadataPP()
    test_pp.set_downloader(test_dl)
    return test_dl, test_pp


if __name__ == '__main__':
    test_dl, test_pp = test_XAttrMetadataPP()


# Generated at 2022-06-24 14:11:47.362345
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pass

# Generated at 2022-06-24 14:11:55.127814
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..utils import prepare_extractor

    info = {
        # 'webpage_url': 'https://www.youtube.com/watch?v=BaW_jenozKc',
        # 'description': 'The opening scene of the movie Pee Wee\'s Big Adventure.',
        'title': 'Tequila - Pee Wee Herman',
        # 'upload_date': '20120106',
        # 'uploader': 'Paul Reubens',
        # 'format': '1 - 480p',
    }

    pp = XAttrMetadataPP(prepare_extractor(), 'test', {})
    pp.run(info)

# Generated at 2022-06-24 14:11:56.112809
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    XAttrMetadataPP()

# Generated at 2022-06-24 14:12:06.498992
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import os
    import tempfile
    import unittest
    from ..utils import xattr_write, xattr_read


# Generated at 2022-06-24 14:12:14.794871
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os
    import tempfile
    from .common import FileDownloader
    from .extractor import gen_extractors
    # The downloader object is not really used since we don't call the downloader.
    # However, the FileDownloader object is required for the postprocessor we use in this test
    downloader = FileDownloader({})
    postprocessor = XAttrMetadataPP(downloader)
    ext_dict = gen_extractors()


# Generated at 2022-06-24 14:12:23.881974
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os
    from unittest import TestCase

# Generated at 2022-06-24 14:12:25.480324
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..downloader import YoutubeDL
    xattrmetadatapp = XAttrMetadataPP(YoutubeDL())
    assert xattrmetadatapp is not None

# Generated at 2022-06-24 14:12:35.883257
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    """ Unit test for method run of class XAttrMetadataPP """
    from ..utils import platform_get_os

    def write_xattr(a1, a2, a3):
        """ Record extended attributes written by XAttrMetadataPP.run """
        nonlocal xattr_list

        mapping = {
            'user.xdg.referrer.url': 'webpage_url',
            # 'user.xdg.comment':            'description',
            'user.dublincore.title': 'title',
            'user.dublincore.date': 'upload_date',
            'user.dublincore.description': 'description',
            'user.dublincore.contributor': 'uploader',
            'user.dublincore.format': 'format',
        }
       

# Generated at 2022-06-24 14:12:36.366750
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-24 14:12:45.304191
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import datetime
    import tempfile
    import unittest

    import os
    import sys

    class Test_test_XAttrMetadataPP_run(unittest.TestCase):

        xattr_unavailable_error = u"No module named xattr"
        xattr_metadata_error = u"metadata error"

# Generated at 2022-06-24 14:12:55.120972
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    info = {
        'id': 'Z_dGSQ2n4fc',
        'display_id': 'Z_dGSQ2n4fc',
        'upload_date': '20101223',
        'title': 'We wish you a Merry Christmas',
        'description': 'Lalalala',
        'uploader': 'Santa Claus',
        'format': 'mp4',
        'webpage_url': 'http://youtube.com/truc',
        'duration': 2,
        'ext': 'mp4',
        'thumbnails': [],
        'resolution': '1280x720',
        'filesize': 2,
        'fulltitle': 'We wish you a Merry Christmas',
    }
    return info

# Generated at 2022-06-24 14:12:56.725359
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    postprocessor = XAttrMetadataPP(['dummy'])
    return postprocessor

# Generated at 2022-06-24 14:13:06.256314
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from collections import namedtuple
    from .common import FileDownloader
    from ..utils import encodeFilename

    class InfoDict(dict):

        def __init__(self, *args, **kwargs):
            super(InfoDict, self).__init__(*args, **kwargs)
            self.filename = 'filename'

        def __setitem__(self, key, value):
            super(InfoDict, self).__setitem__(key, value)
            if key == 'filepath':
                self.filename = encodeFilename(value)

    Info = namedtuple('Info', ['filename', 'filepath'])

    def report_warning(msg):
        warnings.append(msg)

    def report_error(msg):
        errors.append(msg)

    # pylint: disable=W0613

# Generated at 2022-06-24 14:13:11.275796
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    """ test constructor of class XAttrMetadataPP """
    print("testing constructor of class XAttrMetadataPP")
    xattr_mapping = {
        'user.xdg.referrer.url': 'webpage_url',
        'user.xdg.comment': 'description',
        'user.dublincore.title': 'title',
        'user.dublincore.date': 'upload_date',
        'user.dublincore.description': 'description',
        'user.dublincore.contributor': 'uploader',
        'user.dublincore.format': 'format',
    }
    assert XAttrMetadataPP.__bases__[0].__name__ == 'PostProcessor'
    assert XAttrMetadataPP.xattr_mapping

# Generated at 2022-06-24 14:13:12.939323
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP is not None, 'Unable to create XAttrMetadataPP class!'



# Generated at 2022-06-24 14:13:22.623231
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass
#    import tempfile
#    # Create a temporary file to test on
#    fd, tmpfilename = tempfile.mkstemp(
#        prefix="youtube-dl_", suffix=".bin")
#    tmppath = os.path.dirname(tmpfilename)
#    os.close(fd)
#    with open(tmpfilename, 'w') as f: f.write('')
#
#    # Let's write some metadata
#    info = {
#        'filepath': tmpfilename,
#        'webpage_url': 'http://www.youtube.com/watch?v=BaW_jenozKc',
#        'description': 'Very interesting video that you really want to see',
#        'title': 'youtube-dl test video',
#        'uploader': 'Mr. Test',
#

# Generated at 2022-06-24 14:13:33.242962
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    #create the downloader object
    ydl_opts = {'logger': FakeLogger()}
    ydl = YoutubeDL(ydl_opts)

    #create the infolabels dict
    expected_result = {
        'title': 'test_title',
        'format': 'test_format',
        'webpage_url': 'http://www.youtube.com/watch?v=hT_nvWreIhg',
        'description': 'test_description',
        'upload_date': '20131021',
        'uploader': 'test_uploader'}
    #create a test file

# Generated at 2022-06-24 14:13:40.276119
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import sys
    sys.modules['xattr'] = None

    import os
    if hasattr(os, 'setxattr'):
        del os.setxattr

    if hasattr(os, 'getxattr'):
        del os.getxattr

    # Import xattr if available
    from ..utils import write_xattr, XAttrUnavailableError, XAttrMetadataError

    # Create dummy class
    class DummyYDL(object):
        def report_error(self, msg):
            print(msg)

        def report_warning(self, msg):
            print(msg)

        def to_screen(self, msg):
            print(msg)

    ydl = DummyYDL()
    xattr_metadata = XAttrMetadataPP(ydl)


# Generated at 2022-06-24 14:13:43.851075
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    global x
    x = XAttrMetadataPP()

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-24 14:13:49.804131
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    #
    # Unit tests for method run of class XAttrMetadataPP
    #

    class FakeDownloader(object):

        def __init__(self):
            self.to_screen_buffer = []
            self.errors_buffer = []
            self.warnings_buffer = []

        def to_screen(self, msg):
            self.to_screen_buffer.append(msg)

        def report_error(self, msg):
            self.errors_buffer.append(msg)

        def report_warning(self, msg):
            self.warnings_buffer.append(msg)

    class FakeFileSystem:

        def __init__(self):
            self.xattrs = {}


# Generated at 2022-06-24 14:13:50.983346
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pp = XAttrMetadataPP()

# Generated at 2022-06-24 14:13:55.290619
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    print('downloader.py:test_XAttrMetadataPP_run:')
    # TODO: Proper unit test
    #x = XAttrMetadataPP(YoutubeDL(), {})
    #assert True
    return


# Generated at 2022-06-24 14:14:03.313419
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from . import YoutubeDL
    from .common import FileDownloader

    class FakeYoutubeDL(YoutubeDL):
        def download(self, *args):
            pass

    class FakeFD(FileDownloader):
        def _match_entry(self, *args):
            return {
                'id': 'foo',
                'url': 'http://example.com/foo',
                'title': 'This is a foo video',
                'description': 'This is the description of the foo video',
                'filename': 'foo.mp4',
                'format': 'bar',
                'thumbnail': 'foo.jpg',
                'uploader': 'Mr Foo',
            }

    assert FakeFD(FakeYoutubeDL()).postprocessors['xattr_metadata']

# Generated at 2022-06-24 14:14:12.212861
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .common import FileDownloader
    from ..compat import compat_os_name
    from ..utils import xattr_supported

    if xattr_supported:
        import tempfile

        dir = tempfile.mkdtemp()
        downloader = FileDownloader({
            'outtmpl': dir + '/%(title)s.%(ext)s',
            'usenetrc': False,
            'username': 'none',
            'password': 'none',
            'verbose': True,
        })

# Generated at 2022-06-24 14:14:18.320344
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .common import FileDownloader
    import tempfile
    import os

    # Create a video info

# Generated at 2022-06-24 14:14:19.323839
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    xattr_pp = XAttrMetadataPP()

# Generated at 2022-06-24 14:14:25.210553
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    """Test the constructor of XAttrMetadataPP."""
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    d = YoutubeDL({})
    d.add_info_extractor(YoutubeIE())
    pp = XAttrMetadataPP(d)
    assert pp.filepath == '%(title)s-%(id)s.%(ext)s'
    assert pp.ie == d._ies[0]
    assert pp.downloader == d

# Generated at 2022-06-24 14:14:34.635980
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..compat import compat_str
    from .common import FileDownloader
    from .utils import make_fake_info_dict

    testdata = dict(
        webpage_url='http://myurl.com',
        title='Test video',
        upload_date='20120101',
        description='Description',
        uploader='Uploader',
        formats=[
            {
                'ext': 'mp4',
                'format': 'Some format',
                'format_id': 'some_format',
                'filesize': '123456789',
            }
        ]
    )
    info = make_fake_info_dict(**testdata)


# Generated at 2022-06-24 14:14:38.826620
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..utils import PY3
    from ..extractor.common import InfoExtractor
    from ..extractor.youtube import YoutubeIE

    info = {'filepath': __file__}
    ie = InfoExtractor(YoutubeIE.ie_key())

    XAttrMetadataPP(ie).run(info)

    # No error is raised

# Generated at 2022-06-24 14:14:44.779569
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    metadata = {
        'title': 'This is a Title',
        'upload_date': '20081124',
        'description': 'This is a description \u00f1',
        'uploader': 'The uploader',
        'format': 'The format',
        'webpage_url': 'https://web.page/example.html',
        'filepath': 'somewhere/else/over/the/rainbow',
    }

    downloaded = []
    pp = XAttrMetadataPP()
    t = pp.run(metadata)
    downloaded.extend(t[0])
    metadata = t[1]

    assert downloaded == []

    # If XAttrs are not enabled on the file system, then the metadata should be unchanged.
    assert metadata['title'] == 'This is a Title'

# Generated at 2022-06-24 14:14:54.821512
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import pytest
    from .common import FileDownloader
    from ..extractor import gen_extractors
    from ..utils import encode_data_uri


# Generated at 2022-06-24 14:14:56.211433
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass


# Generated at 2022-06-24 14:14:58.314872
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    xattr_metadata_pp = XAttrMetadataPP()
    assert xattr_metadata_pp is not None

# Generated at 2022-06-24 14:15:08.324069
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor import VideoExtractor
    class FakeDownloader(object):
        class FakeInfoExtractor(object):
            def __init__(self, downloader):
                pass
        def to_screen(self, *args, **kargs):
            pass
        def report_warning(self, *args, **kargs):
            pass
        def report_error(self, *args, **kargs):
            pass
        def add_default_extra_info(self, *args, **kargs):
            pass
        @property
        def IE_NAME(self):
            return 'fake'
        @property
        def params(self):
            return None
    class FakeInfo(dict):
        def __init__(self):
            dict.__init__(self)

# Generated at 2022-06-24 14:15:17.337750
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # For testing purposes purpose create a temp file
    # and remove it after the test method is run
    import tempfile
    import os
    import time
    import shutil

    class FakeInfo(dict):
        def __init__(self, filename):
            dict.__init__(self)
            self['filepath'] = filename
            self['format'] = '720p'
            self['title'] = 'test title'
            self['description'] = 'a super awesome test title'
            self['upload_date'] = '20140101'  # YYYYMMDD
            self['uploader'] = 'test uploader'

    class FakeYDL():
        def to_screen(self, *args, **kwargs):
            pass  # commented out printing to screen


# Generated at 2022-06-24 14:15:27.776769
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    """
    Unit test for method run of class XAttrMetadataPP
    """
    import os
    import sys
    import tempfile
    if sys.version_info >= (3, 0):
        import pickle
    else:
        import cPickle as pickle
    import py

    from ..downloader.common import FileDownloadInfo
    from ..extractor.common import InfoExtractor
    from ..compat import compat_str, compat_urllib_request
    from .common import PostProcessorTest

    # Create test info
    TEST_URL = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    TEST_VIDEO_ID = 'BaW_jenozKc'
    TEST_TITLE = 'youtube-dl test video "'

# Generated at 2022-06-24 14:15:31.718949
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    """
    Description: Check that constructor of class XAttrMetadataPP raises no
    exception.

    Test conditions: Calling of constructor.
    Expected result: No exception is raised.
    """

    XAttrMetadataPP()

# Generated at 2022-06-24 14:15:40.406637
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import os
    import shutil
    import tempfile
    from .common import FileDownloader

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Populate the directory with a test file
    path = os.path.join(tmpdir, 'test.txt')
    with open(path, 'wb') as f:
        f.write(b'foo')

    # This should succeed
    info = {
        'title': 'Checking extended attributes',
        'webpage_url': 'http://youtube.com/',
        'uploader': 'yt-uploader',
        'format': '18 - 640x360 (medium)',
    }
    ydl = FileDownloader({})
    pp = XAttrMetadataPP(ydl)
    (returncode, new_info) = pp.run

# Generated at 2022-06-24 14:15:43.817277
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP.__name__ == 'XAttrMetadataPP'
    metadataPP = XAttrMetadataPP()
    assert metadataPP is not None

# Generated at 2022-06-24 14:15:44.492523
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # XAttrMetadataPP test stub
    return

# Generated at 2022-06-24 14:15:46.539764
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    XAttrMetadataPP('pytube_eXtended_Attribute_metadata_post_processor', True)

# Generated at 2022-06-24 14:15:48.390038
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x = XAttrMetadataPP('foo')
    x.run({'filepath': 'bar'})

# Generated at 2022-06-24 14:15:57.976373
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import tempfile
    import shutil
    import os
    import fnmatch
    import re
    import sys

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create a test file
    f = open(os.path.join(tmp_dir, "test.mp4"), "w")
    f.write("test")
    f.close()

    # Create an instance of XAttrMetadataPP
    pp = XAttrMetadataPP()

    # Mock attributes from Downloader
    pp._downloader = type('MockDownloader', (object,), {'to_screen': lambda x: None})()

    # Run the test

# Generated at 2022-06-24 14:16:08.156971
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    import os
    import unittest
    import shutil
    import tempfile

    from ..utils import prepend_extension

    class XAttrUnavailableError_raised(Exception):
        pass

    class XAttrMetadataError_raised(Exception):
        pass

    class XAttrMetadataPP_test(XAttrMetadataPP):
        def __init__(self, downloader=None, config=None, params=None):
            super(XAttrMetadataPP_test, self).__init__(downloader, config, params)
            self.tempdir = tempfile.mkdtemp()
            self.files = {}

        def _get_filesystem_encoding(self):
            return 'utf-8'

        def _get_temp_filename(self, filename):
            self.files[filename] = {}


# Generated at 2022-06-24 14:16:17.921317
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..downloader import youtube_dl

    # FIXME: downloader.py needs to be called with --proc-infos argument
    #        for this test to pass
    
    # Simulate an --write-info-json result

# Generated at 2022-06-24 14:16:18.735945
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP()
    assert pp

# Generated at 2022-06-24 14:16:27.295689
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .test import PostProcessorTest
    from .test import get_testcases_XAttrMetadataPP

    for test_info in get_testcases_XAttrMetadataPP():
        test = PostProcessorTest(XAttrMetadataPP)
        test.test_run(test_info)

# Invokes the unit tests if file run as main
if __name__ == '__main__':
    import sys

    def run_test(test_func, msg):
        """ Runs test_func and prints verbose message. """
        if test_func():
            print('✔ ' + msg + '... OK')
        else:
            print('✘ ' + msg + '... ERROR')
            print('Please report this bug!')


# Generated at 2022-06-24 14:16:35.320599
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..youtube_dl import YoutubeDL

    class FakeInfoDict(dict):
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                self[k] = v

    # check for correct parsing of metadata
    class FakeYDL:
        def __init__(self):
            self.params = {}
            self.to_screen_called_with = None

        def to_screen(self, msg):
            self.to_screen_called_with = msg

    ydl = FakeYDL()
    xattr_pp = XAttrMetadataPP(ydl)


# Generated at 2022-06-24 14:16:44.999065
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import prepend_extension
    import os

    import unittest
    from unittest.mock import patch, MagicMock

    from ytdl import YoutubeDL

    class TestPP(XAttrMetadataPP):
        def __init__(self):
            XAttrMetadataPP.__init__(self, None)

    class MyTestCase(unittest.TestCase):

        def setUp(self):
            self._temp_filename = 'temp_test'
            self._remove_from_system(self._temp_filename)
            self._temp_file = open(self._temp_filename, 'wb')
            self._temp_file.close()
            self._pp = TestPP()
            self._ytdl = YoutubeDL(params={})
            self._ytdl.process_ie_result

# Generated at 2022-06-24 14:16:45.405001
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-24 14:16:48.356595
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    """ Unit test for constructor of class XAttrMetadataPP """

    # Constructor without parameters
    XAttrMetadataPP()

# Generated at 2022-06-24 14:16:56.139950
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # initialize downloader
    _downloader = object()

    # initialize info
    info = {
        'webpage_url': 'http://example.com/1',
        'title': 'title 1',
        'upload_date': 'upload date 1',
        'description': 'description 1',
        'uploader': 'uploader 1',
        'format': 'format 1',
        'filepath': '/tmp/file 1',
    }

    # initialize post-processor
    xa_pp = XAttrMetadataPP(_downloader)
    xa_pp.run(info)

    # check that all the expected metadata was written to the file's xattrs
    import xattr

# Generated at 2022-06-24 14:17:07.010426
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..compat import compat_str
    from ..downloader import FakeYDL
    from ..extractor import gen_extractors

    class FakeInfo:
        def __init__(self):
            self.filepath = '/tmp/test.mp4'
            self.webpage_url = 'website'
            self.title = 'this is a title'
            self.upload_date = '20160101'
            self.description = 'this is a description'
            self.uploader = 'uploader'
            self.extractor = 'youtube'
            self.format = 'flv'

    fakeout = FakeYDL()
    xattribs_pp = XAttrMetadataPP(FakeYDL(), FakeInfo())

    fakeinfo = FakeInfo()

# Generated at 2022-06-24 14:17:15.724047
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():

    import io
    import tempfile

    # Create a temporary empty file
    filename = os.path.join(tempfile.gettempdir(), 'XAttrMetadataPP_test')
    open(filename, 'w').close()

    downloader = object()
    downloader.to_screen = lambda x: None
    downloader.report_error = lambda x: None
    downloader.report_warning = lambda x: None

    # Initialize the postprocessor
    pp = XAttrMetadataPP(downloader)

    #
    # Test write_xattr
    #


# Generated at 2022-06-24 14:17:24.145963
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..YoutubeDL import YoutubeDL
    from .common import FileDownloader
    import os

    class MyYoutubeDL(YoutubeDL):
        def __init__(self, params):
            YoutubeDL.__init__(self, params)

        def to_screen(self, message):
            pass

        def report_error(self, msg):
            raise RuntimeError(msg)

        def report_warning(self, msg):
            raise RuntimeWarning(msg)

    def test_xattrs(info, expected_keys):
        filename = 'test.txt'

        dl = MyYoutubeDL({})
        fd = FileDownloader(dl, {'outtmpl': filename})
        fd.to_screen = lambda x: x
        fd.process_ie_result(info)

# Generated at 2022-06-24 14:17:33.776698
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from .common import FileDownloader

    filename = '/tmp/foobar.mp4'
    info_dict = {
        'filepath': filename,
        'webpage_url': 'http://youtube.com/watch?v=BaW_jenozKc',
        'title': 'Foobar',
        'upload_date': '20121004',
        'description': 'Foo bar baz',
        'uploader': 'BYUtv',
        'format': '1920x1080',
    }
    downer = FileDownloader({})
    pp = XAttrMetadataPP(downer)
    _, info_dict_out = pp.run(info_dict)
    assert info_dict == info_dict_out

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-24 14:17:36.572061
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP()

    assert pp.run({}) == ([], {})

# Generated at 2022-06-24 14:17:47.906265
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ytdl.YoutubeDL import YoutubeDL
    import sys

    ydl = YoutubeDL({})
    pp = XAttrMetadataPP()
    pp._downloader = ydl

# Generated at 2022-06-24 14:17:57.104437
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    from ..utils.tempdir import temp_gettempdir
    from .common import FileDownloader
    from .get_video_info import GetVideoInfoPP
    from .extract_audio import ExtractAudioPP
    from .embedthumbnail import EmbedThumbnailPP
    from .writeannotations import WriteAnnotationsPP
    from .writedescription import WriteDescriptionPP
    from .writesubtitles import WriteSubtitlesPP

    # Create temporary directories and downloader object
    with temp_gettempdir() as tempdir:
        downloader = FileDownloader({
            'outtmpl': os.path.join(tempdir, '%(title)s.%(ext)s'),
            'postprocessors': [
                GetVideoInfoPP(),
                XAttrMetadataPP(),
            ],
        })
        # Set up the youtube-dl extract

# Generated at 2022-06-24 14:17:57.996464
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-24 14:18:09.020971
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor import YoutubeIE
    from .test_common import get_testdata

    input_json = 'static/video_info/youtube/yi7RH4JRpNc'
    input_dict = json.load(open(get_testdata(input_json)))
    input_url = input_dict['webpage_url']

    info = YoutubeIE()._extract_info(input_url, input_dict)

    # Write the metadata to the file's xattrs
    _downloader = object()
    _downloader.to_screen = lambda msg: print('\n[metadata] ' + msg)
    _downloader.report_warning = lambda msg: print('\n[warning]: ' + msg)
    _downloader.report_error = lambda msg: print('\n[error]: ' + msg)


# Generated at 2022-06-24 14:18:18.863606
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..youtube_dl.extractor.youtube import YoutubeIE

    test_filepath = 'test_file'

    # Function to create a YouTubeIE instance
    def extractor_test():
        return YoutubeIE(lambda: None)

    # Function to test for the xattrs written by XAttrMetadataPP
    def xattrs_test(filename, xattrname, exp_value):
        from .xattrs import xattr

        # check that the attribute exists
        attrs = xattr(filename).list()
        return attrs and xattrname in attrs

        # check that its value is as expected
        value = attr.get(xattrname).decode('utf-8')
        return value == exp_value

    # Test data

# Generated at 2022-06-24 14:18:19.388026
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert True

# Generated at 2022-06-24 14:18:20.890597
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    xat = XAttrMetadataPP()
    assert xat

# Generated at 2022-06-24 14:18:23.505066
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    try:
        XAttrMetadataPP('', '')
    except:
        print('Do not pass arguments to constructor of class XAttrMetadataPP')
        raise

# Generated at 2022-06-24 14:18:26.085872
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    downloader = Dummy(params={})
    pp = XAttrMetadataPP(downloader)
    pp.run({'filepath': 'file.mp4'})



# Generated at 2022-06-24 14:18:26.979401
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x = XAttrMetadataPP(None)

# Generated at 2022-06-24 14:18:31.942444
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    import io
    import sys
    import time

    class FakeYDL():

        def __init__(self):
            self.to_screen_buffer = io.StringIO()
            self.warn_buffer = io.StringIO()
            self.error_buffer = io.StringIO()

        def to_screen(self, s):
            self.to_screen_buffer.write(s)

        def report_warning(self, s):
            self.warn_buffer.write(s)

        def report_error(self, s):
            self.error_buffer.write(s)

    class FakeHook():
        pass

    dummy_filepath = 'dummy'


# Generated at 2022-06-24 14:18:33.158734
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass


# Generated at 2022-06-24 14:18:34.617307
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass


# Generated at 2022-06-24 14:18:35.501818
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # TODO: unit tests
    pass

# Generated at 2022-06-24 14:18:36.700948
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    xattrmetadatapp = XAttrMetadataPP()

# Generated at 2022-06-24 14:18:42.507019
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP(None)
    path = "C:/fake/path/to/vido.mp4"
    info = {
        'filepath': path
    }
    (formats, info) = pp.run(info)
    assert not formats, "Didn't expect formats to be non-empty."
    assert "filepath" in info and info["filepath"] == path, "Expected filepath to be unchanged"

# Generated at 2022-06-24 14:18:52.411734
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import tempfile
    import os
    from ..utils import xattr_set

    filepath = tempfile.mktemp()
    info = {
        'id': 'ytid',
        'title': 'ThisIsATitle',
        'uploader': 'ThisIsAnUploader',
        'upload_date': '20101012',
        'webpage_url': 'http://example.org/',
        'description': 'ThisIsADescription',
        'format': 'ThisIsAFormat',
        'filepath': filepath,
    }


# Generated at 2022-06-24 14:18:54.749201
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    dh = DummyPostProcessor()
    pp = XAttrMetadataPP(dh)

    assert pp.from_plugin
    assert dh is pp.get_downloader()


from .dummy import DummyPostProcessor

# Generated at 2022-06-24 14:18:56.446094
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP({})
    assert pp.__class__.__name__ == 'XAttrMetadataPP'

# Generated at 2022-06-24 14:19:03.705183
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..utils import prepend_extension
    from .common import FileDownloader
    from .test import get_test_cases, get_temp_filename
    import os.path

    for input_name, info in get_test_cases().items():
        outputname = prepend_extension(get_temp_filename(prefix=input_name), info['ext'])
        t = FileDownloader({
            'outtmpl': os.path.join('./', outputname),
            'quiet': True,
        })
        t.add_info_extractor(None)
        t.add_post_processor(XAttrMetadataPP())
        t._setup_opts()
        t.result_values = info
        t.process_info(info)


if __name__ == '__main__':
    test_X

# Generated at 2022-06-24 14:19:14.086698
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import shutil
    from ..utils import xattr_writable

    class DummyYDL(object):

        def __init__(self):
            self.to_screen = lambda x: True
            self.report_warning = lambda x: True

        def report_error(self, msg):
            raise XAttrUnavailableError(msg)

    ydl = DummyYDL()

    xattrs_writable = xattr_writable()

    class DummyInfo(object):

        def __init__(self, filepath):
            self.filepath = filepath

    if xattrs_writable:
        xattr_file = '/tmp/.xyz'
        open(xattr_file, 'w').close()
        info = DummyInfo(xattr_file)

        # Test writing the attributes.
        pp = X

# Generated at 2022-06-24 14:19:14.955417
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP()

# Generated at 2022-06-24 14:19:25.884169
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..downloader import YouTubeDL
    from ..extractor.youtube import YoutubeIE

    ydl = YouTubeDL()
    ydl.add_default_info_extractors()
    ie = YoutubeIE(ydl=ydl)

    ydl.add_info_extractor(ie)
    xattr_pp = XAttrMetadataPP(ydl)


# Generated at 2022-06-24 14:19:26.432039
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-24 14:19:34.986935
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor import gen_extractors
    from ..downloader import Downloader

    GEN_EXTRACTORS = gen_extractors()

    for extractor in GEN_EXTRACTORS.values():
        dl = Downloader(extractor)
        assert 'xattr_metadata' not in dl.postprocessors
        dl = Downloader(extractor, {'writedescription': True})
        assert 'xattr_metadata' in dl.postprocessors


if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-24 14:19:38.581431
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP('/tmp/', None, {}, {'youtube-dl.log': 'logpath', 'download_archive': 'archivepath'})
    assert pp.downloader is None
    assert pp.params == {'youtube-dl.log': 'logpath', 'download_archive': 'archivepath'}
    assert pp.filename == '/tmp/'
    assert pp.info == {}

# Generated at 2022-06-24 14:19:40.136391
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    import sys

    postproc = XAttrMetadataPP(sys.stderr)
    assert postproc

# Generated at 2022-06-24 14:19:48.034811
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP()
    info= {'webpage_url':'http://www.youtube.com/watch?v=ZsybB_SSjKc',
           'description':'Candy',
           'title':'Candy',
           'upload_date':'20140105',
           'uploader':'Candy',
           'format':'3GP',
           'filepath':'/home/user/videos/candy.mp4'}
    errs, inf = pp.run(info)
    assert errs == []

# Generated at 2022-06-24 14:19:55.985333
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import os

    from subprocess import Popen, PIPE

    from ..utils import xdg_open

    from .utils import DEFAULT_OUTTMPL
    from .common import FileDownloader

    from .test_utils import TestDownloader

    # Test the XAttrMetadataPP does nothing if there's no xattr support
    # (eg. on the current filesystem, on a non-Unix OS, etc).
    output_template = 'test_%(id)s.%(ext)s'
    fd = FileDownloader({
        'format': 'best',
        'outtmpl': os.path.join('test_output', output_template),
    })
    fd.add_info_extractor(TestDownloader())
    fd.add_post_processor(XAttrMetadataPP())

# Generated at 2022-06-24 14:20:01.599207
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    """
    Unit test for method run of class XAttrMetadataPP
    """
    # pylint: disable=W0212
    from .common import FileDownloader
    from .xattr import attr

    import os
    import tempfile
    from ..extractor.youtube import YoutubeIE
    from ..utils import DateRange

    # Prepare directory for testing
    tmp_dir = tempfile.mkdtemp(prefix='youtubedl_')


# Generated at 2022-06-24 14:20:07.593249
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP({}).run({'filepath': 'foo.bar', 'title': "title", 'upload_date': '19990101', 'uploader': 'author', 'format': '3gp', 'description': 'the description'}) == ([], {'filepath': 'foo.bar', 'title': "title", 'upload_date': '19990101', 'uploader': 'author', 'format': '3gp', 'description': 'the description'})

# Generated at 2022-06-24 14:20:12.542106
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .internal import YoutubeDL
    from tempfile import TemporaryFile

    # File without xattr support
    with TemporaryFile() as f:
        ydl = YoutubeDL({})
        pp = XAttrMetadataPP(ydl)
        ydl.add_post_processor(pp)
        pp.run({'filepath': f.name, 'title': 'title', 'ext': 'mp4', 'format': 'SomeFormat'})

    # File with xattr support
    with YouTubeDL(ydl_opts={}) as ydl:
        info_dict = ydl.extract_info('http://www.youtube.com/watch?v=BaW_jenozKc', download=False)
        # A video that doesn't exist
        assert 'entries' not in info_dict

# Generated at 2022-06-24 14:20:13.471010
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP()
    assert pp.name == 'xattrs'

# Generated at 2022-06-24 14:20:14.301646
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass


# Generated at 2022-06-24 14:20:25.488581
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    xattr_pp = XAttrMetadataPP()

    info = {
        'filepath': 'filename',
        'webpage_url': 'http://example.com/',
        'format': 'mp4',
        'title': 'The title',
        'upload_date': '20180201',
        'description': 'The description',
        'uploader': 'The uploader',
    }

    # Test that the method always return a status tuple with the same
    # number of elements (e.g. (0,) or (0, ''))
    xattr_pp_result = xattr_pp.run(info)
    assert len(xattr_pp_result) == 2
    assert xattr_pp_result[0] == []
    assert xattr_pp_result[1] == info

    # Test that no exception is

# Generated at 2022-06-24 14:20:27.392320
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    instance = XAttrMetadataPP(None)
    # verify its type
    assert isinstance(instance, XAttrMetadataPP)


# Generated at 2022-06-24 14:20:37.713846
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    # Testing write_xattr, this code should be moved to test.py
    from .common import FileDownloader, PostProcessingError
    from ..utils import write_xattr

    info = {
        'filepath': 'test_file_path', # if filename doesn't exist, write_xattr fails
        'webpage_url': 'http://www.example.org',
        'title': 'Test video',
        'upload_date': '20010101',
        'description': 'Test description of the video.',
        'uploader': 'Test Uploader',
        'format': 'Test format',
    }

    write_xattr(info['filepath'], 'user.xdg.referrer.url', info['webpage_url'].encode('utf-8'))

# Generated at 2022-06-24 14:20:38.547228
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass


# Generated at 2022-06-24 14:20:39.686623
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert isinstance(XAttrMetadataPP(), XAttrMetadataPP)

# Generated at 2022-06-24 14:20:40.541822
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass


# Generated at 2022-06-24 14:20:50.332144
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    """ Unit test for method run of class XAttrMetadataPP """
    import os
    import sys

    from .test_common import make_mock_info, make_mock_postprocessor

    from ..utils import (
        XAttrMetadataError,
        XAttrUnavailableError,
    )

    mock_info = make_mock_info(
        title='title test',
        webpage_url='url test',
        description='description test',
        uploader='uploader test',
        upload_date='date test',
        format='format test',
    )

    mock_downloader = make_mock_postprocessor(
        XAttrMetadataPP,
        {},
        {'filepath': 'file.ext'},
    )
