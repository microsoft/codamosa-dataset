

# Generated at 2022-06-24 14:10:59.598114
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    class YD(object):

        @staticmethod
        def to_screen(message):
            print('TS: %s' % message)

        @staticmethod
        def report_error(message):
            print('RE: %s' % message)

        @staticmethod
        def report_warning(message):
            print('RW: %s' % message)

    yd = YD()

    filename = '/tmp/test.mp4'

    import os
    import tempfile
    if os.path.exists(filename):
        os.remove(filename)
    with tempfile.NamedTemporaryFile(dir='/tmp', delete=False) as f:
        os.rename(f.name, filename)


# Generated at 2022-06-24 14:11:01.407201
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP()
    assert isinstance(pp, PostProcessor)


# Generated at 2022-06-24 14:11:10.564505
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor import gen_extractors
    from .common import FileDownloader
    from .get_thumbnail import GetThumbnailPP

    downloader = FileDownloader({})
    expected_pp = [
        {
            'key': 'FFmpegMetadataPP',
            'name': 'FFmpegMetadataPP',
            'description': 'Writes metadata to the given file using ffmpeg'
        },
        {
            'key': 'XAttrMetadataPP',
            'name': 'XAttrMetadataPP',
            'description': 'Writes metadata to the file\'s xattrs (using xattr -w on Linux)'
        },
        {
            'key': 'GetThumbnailPP',
            'name': 'GetThumbnailPP',
            'description': 'Downloads thumbnail images'
        }
    ]

# Generated at 2022-06-24 14:11:18.935691
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    from ..utils import encodeFilename
    infos = []
    infos.append({
        'webpage_url': 'http://www.youtube.com/watch?v=BaW_jenozKc',
        'filepath': encodeFilename('test'),
        'format': '22',
        'upload_date': '20130404',
        'uploader': 'test',
        'title': 'test 1',
        'description': 'test 2',
    })
    xattr_pp = XAttrMetadataPP()
    res, infos = xattr_pp.run(infos[0])

# Generated at 2022-06-24 14:11:27.926959
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import json
    from collections import namedtuple
    from .common import FileDownloader
    from ..utils import *
    from ..compat import *


# Generated at 2022-06-24 14:11:30.435761
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    global xattr_metadata_pp
    xattr_metadata_pp = XAttrMetadataPP()

    assert(xattr_metadata_pp != None)

# Generated at 2022-06-24 14:11:40.330481
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    def check_xattr(filepath, xattrname, expected_value):
        if compat_os_name == 'nt':
            # TODO
            pass
        else:
            command = ['getfattr', '-n', xattrname, filepath]
            _, stdout, _ = run_external_command(command)
            value = stdout.decode('utf-8').strip()
            assert value.startswith('{}="'.format(xattrname)), value
            assert value.endswith('"')
            value = value[len(xattrname)+2:len(value)-1]
            assert value == expected_value, value

    from ..compat import compat_os_name
    from .test_postprocessor_run import run_postprocessor
    from ..utils import run_external_command

    is_nt

# Generated at 2022-06-24 14:11:48.695719
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import XAttrUnavailableError

    import os

    import tempfile

    # Create a temporary file and a temporary directory, and then write some
    # xattrs to the temporary file.
    file = tempfile.NamedTemporaryFile(prefix='ytdl')
    dir =  tempfile.mkdtemp(prefix='ytdl')


# Generated at 2022-06-24 14:11:58.489820
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    from io import BytesIO
    from unittest import TestCase

    class XAttrMetadataPP_runTestCase(TestCase):

        def test_should_return_empty_errors_and_info(self):

            xattr_metadata_pp = XAttrMetadataPP()
            result = xattr_metadata_pp.run(dict(
                filepath = 'test/test-test_metadata.test',
                title = 'test_title',
                description = 'test_description',
                webpage_url = 'test_url',
                upload_date = 'test_upload_date',
                uploader = 'test_uploader',
                format = 'test_format',
                # duration = 'test_duration',
                # thumbnail = 'test_thumbnail',
                # resolution = 'test_resolution',
            ))


# Generated at 2022-06-24 14:12:08.679746
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import tempfile
    import os

    tmpfile = tempfile.NamedTemporaryFile(delete=False)
    filename = tmpfile.name
    tmpfile.close()

    # Initialise test variables
    info = {
        'title': 'video title',
        'webpage_url': 'http://www.youtube.com/watch?v=12345',
        'uploader': 'uploader name',
        'upload_date': '20120222',
        'description': 'video description',
        'format': 'video format',
        'filepath': filename,
    }

    # Test file without xattr support
    # Test for already existing xattr metadata

# Generated at 2022-06-24 14:12:09.640841
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-24 14:12:11.345160
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x = XAttrMetadataPP.create_instance('test_XAttrMetadataPP')
    assert isinstance(x, XAttrMetadataPP)

# Generated at 2022-06-24 14:12:14.369057
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP.__name__ == 'XAttrMetadataPP'


# Generated at 2022-06-24 14:12:15.865628
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP()
    assert pp is not None

# Generated at 2022-06-24 14:12:24.475525
# Unit test for method run of class XAttrMetadataPP

# Generated at 2022-06-24 14:12:35.189069
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os
    import shutil
    import tempfile
    from .test_utils import make_temp_dir

    tempdir = make_temp_dir()
    folder = 'tests/tests/'

    # Create a dummy file to apply xattrs on
    open(os.path.join(tempdir, 'dummy.txt'), 'w').close()

    with open(tempdir + 'dummy.txt', 'wb') as f:
        pp = XAttrMetadataPP(None)

# Generated at 2022-06-24 14:12:37.294805
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    XAttrMetadataPP('/foo/bar')
    return True

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-24 14:12:38.526814
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    res = XAttrMetadataPP('test_XAttrMetadataPP')

# Generated at 2022-06-24 14:12:46.872741
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from .common import PostProcessorTest
    from ..compat import compat_os_name

    XAttrMetadataPP_test = PostProcessorTest(
        XAttrMetadataPP,
        expected={
            'webpage_url': 'webpage_url_test',
            'upload_date': 'upload_date_test',
            'format': 'format_test',
            'title': 'title_test',
            'description': 'description_test',
            'uploader': 'uploader_test',
        }
    )

    # Add 'filepath' to expected dict
    XAttrMetadataPP_test.expected['filepath'] = '/tmp/x-attribute-test-file'

    # Create fake file

# Generated at 2022-06-24 14:12:49.105421
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    import sys
    try:
        XAttrMetadataPP(None)
    except Exception as e:
        print (e)
        print ('unit test failed')
        sys.exit(1)
    print ('unit test successful')


# Generated at 2022-06-24 14:12:54.628652
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    class TestDownloader:
        def report_warning(self, msg):
            assert(type(msg) == type(''))

        def report_error(self, msg):
            assert(type(msg) == type(''))

        def to_screen(self, msg):
            assert(type(msg) == type(''))

    class TestInfo:
        def get(self, key):
            assert(type(key) == type(''))
            return ''

    pp = XAttrMetadataPP(TestDownloader())

    pp.run(TestInfo())


if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-24 14:12:56.684075
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    xattrmetadatapp = XAttrMetadataPP({})
    assert xattrmetadatapp is not None

# Generated at 2022-06-24 14:13:06.224913
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..extractor.youtube import YoutubeIE
    from ..utils import DateRange
    from .common import FileDownloader
    from .external import ExternalFD
    from .http import HttpFD
    from .youtube import YoutubeFD

    class DummyYoutubeIE(YoutubeIE):
        def _real_initialize(self):
            self._available = True

    class DummyFD(FileDownloader):
        def __init__(self, ydl):
            super(DummyFD, self).__init__(ydl)
            self._requested_formats = [{
                'format_note': '720p',
                'filesize': 1024,
                'format_id': '1',
                'ext': 'mp4',
                'tbr': 30,
                'format': '720p',
            }]
            self._available

# Generated at 2022-06-24 14:13:15.349183
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import read_xattr
    import os
    import sys

    def get_filename():
        filename = ''.join([chr(i) for i in range(1, 255)]) + '%#?*'
        if sys.version_info[0] == 2:
            filename = filename.decode('utf-8')
        return filename

    assert not read_xattr(get_filename(), 'user.xdg.referrer.url')
    assert not read_xattr(get_filename(), 'user.xdg.comment')
    assert not read_xattr(get_filename(), 'user.dublincore.title')
    assert not read_xattr(get_filename(), 'user.dublincore.date')

# Generated at 2022-06-24 14:13:20.592932
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    filename = 'test.mp3'
    info = {
        'webpage_url': 'http://www.youtube.com/watch?v=BgC3Hs3mJ8E',
        'upload_date': '2013-11-27'
    }

    xattr_metadata_pp = XAttrMetadataPP()
    xattr_metadata_pp.run(info)

# Generated at 2022-06-24 14:13:30.344767
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..compat import compat_b
    from ..utils import get_xattr, remove_xattr
    from io import BytesIO

    # Check write_xattr with file without empty xattrs
    file = BytesIO(compat_b('content'))
    filename = getattr(file, 'name', 'file')
    write_xattr(filename, 'user.mood', 'happy')
    assert get_xattr(filename, 'user.mood') == 'happy'
    remove_xattr(filename, 'user.mood')

    # Check write_xattr
    filename = getattr(file, 'name', 'file')
    write_xattr(filename, 'user.mood', 'happy')
    assert get_xattr(filename, 'user.mood') == 'happy'

# Generated at 2022-06-24 14:13:41.593402
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    import unittest
    import tempfile
    import os

    class XAttrMetadataPPTest(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.output_filename = os.path.join(self.tmpdir, 'video.mp4')
            self.open(self.output_filename, 'wb').close()

            class PseudoDownloader(object):
                def __init__(self):
                    pass

                def to_screen(self, a):
                    pass

                def report_warning(self, a):
                    pass

                def report_error(self, a):
                    pass

            self.process = XAttrMetadataPP(PseudoDownloader())

        def tearDown(self):
            os.remove(self.output_filename)

# Generated at 2022-06-24 14:13:47.694170
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import sys

    from pytube.compat import compat_os_name
    from pytube.postprocessor import XAttrMetadataPP
    from pytube.extractor import YoutubeIE
    from pytube.cipher import Cipher
    from pytube.downloader import FileDownloader
    from pytube.utils import make_xattr_filename

    if not Cipher.has_decryption_key():
        return

    if compat_os_name == 'nt':
        return

    downloader = FileDownloader(
        YoutubeIE(),
        'https://www.youtube.com/watch?v=BaW_jenozKc',
        params={
            'noplaylist': True,
            'quiet': True,
        },
        prepend_extension=None,
    )


# Generated at 2022-06-24 14:13:58.991253
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import tempfile
    import os
    f = tempfile.NamedTemporaryFile(delete=False)
    os.close(f.fileno())
    info = {
        'webpage_url': 'https://www.youtube.com/watch?v=6lCVUblvmZU',
        'description': 'a description of my video',
        'title': 'my test video',
        'upload_date': '20110101',
        'uploader': 'myself',
        'format': 'my format',
        'filepath': f.name
    }
    x = XAttrMetadataPP()


# Generated at 2022-06-24 14:13:59.632337
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # TODO: Write unit test
    pass

# Generated at 2022-06-24 14:14:06.124155
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    """ Test constructor of class XAttrMetadataPP """

    from ..YoutubeDL import YoutubeDL
    from ..extractor.common import InfoExtractor

    class FakeIE(InfoExtractor):

        _VALID_URL = 'http://www.youtube.com/video'

        def __init__(self):
            InfoExtractor.__init__(self)

    ydl = YoutubeDL({}).add_default_info_extractors()
    ydl.add_info_extractor(FakeIE())

    info = ydl.extract_info('http://www.youtube.com/watch?v=BaW_jenozKc', download=False)
    xattr_pp = XAttrMetadataPP()
    xattr_pp.run(info)

# Generated at 2022-06-24 14:14:13.762261
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..extractor import gen_extractors
    from ..utils import prepare_filename
    from .common import FileDownloader
    from ..compat import compat_os_name
    import tempfile
    import os
    import sys

    if sys.version_info < (3,):
        import urllib2 as urllib_request
    else:
        import urllib.request as urllib_request

    class MockYDL(object):
        def __init__(self, params):
            self.params = params
            self.tmpfilename = tempfile.mkstemp()[1]
            if compat_os_name == 'nt':
                self.tmpfilename += '.mp4'

# Generated at 2022-06-24 14:14:20.188512
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    print('Testing XAttrMetadataPP ...')
    from ..YoutubeDL import YoutubeDL
    from ..utils import get_xattr_filepath
    from shutil import rmtree
    from os.path import basename
    import sys
    filename = 'test_video.flv' if compat_os_name == 'nt' else 'test_video'
    ydl = YoutubeDL({
        'no_warnings': True,
        'simulate': True,
        'outtmpl': filename,
        'writethumbnail': True,
        'writeinfojson': True,
    })
    ydl.add_post_processor(XAttrMetadataPP())
    # Prepare test video
    sys.stderr.write('  - preparing test video ...')

# Generated at 2022-06-24 14:14:29.065863
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ytdl_info import YDLInfo
    from ytdl_postprocessor import YDLPostProcessor
    from ytdl_downloader import YDLDownloader

    # Check if xattrs are unavailable on this machine
    try:
        filename = __file__
        xattrname = 'user.xdg.comment'
        byte_value = 'bash'.encode('utf-8')
        write_xattr(filename, xattrname, byte_value)
    except XAttrUnavailableError:
        return

    postprocessors = [{'key': 'XAttrMetadata', 'preferredcodec': 'mp4'}]
    downloader = YDLDownloader({'format': 'best[height<=480]', 'logger': 'internal', 'postprocessors': postprocessors})
    downloader.add_

# Generated at 2022-06-24 14:14:29.633332
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-24 14:14:31.319495
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP(None)
    assert pp is not None


# Generated at 2022-06-24 14:14:39.417819
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..downloader import Downloader
    from ..extractor import gen_extractors
    from ..utils import encodeFilename

    ydl = Downloader({})
    d = XAttrMetadataPP()
    d.add_info_extractor(gen_extractors(ydl, ['http://www.youtube.com/watch?v=BaW_jenozKc']))

    # Retrieve and parse video's info page
    info_dict = d.extractors[0].get_info('http://www.youtube.com/watch?v=BaW_jenozKc')

    # Let's simulate an existing file
    info_dict['filepath'] = encodeFilename('Local filename.mp4')

    # Run xattr metadata pp
    d.run(info_dict)

# Generated at 2022-06-24 14:14:45.925852
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from .common import FileDownloader
    from ntpath import basename
    from ..utils import sanitize_filename
    import tempfile
    import os

    # If a platform doesn't support xattr, we should not get an error
    # trying to create a XAttrMetadataPP object
    try:
        x = XAttrMetadataPP()
    except:
        raise AssertionError("XAttrMetadataPP object should be created")

    # Test if we can create the object
    if x is None:
        raise AssertionError("XAttrMetadataPP object should be created")

    # Fake info

# Generated at 2022-06-24 14:14:56.298450
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..utils import encodeArgument
    from . import get_info_extractor
    from .fragment import FragmentFD
    from .http import HttpFD
    from .http import HeadRequest
    from .misc import DummyFD
    from .youtube import YoutubeIE

    class MockYoutubeIE(YoutubeIE):
        def __init__(self, downloader=None, ie_key=None, **kwargs):
            super(MockYoutubeIE, self).__init__(downloader=downloader, ie_key=ie_key, **kwargs)
            self.ie_key = ie_key

        def _real_initialize(self):
            pass

        def _real_extract(self, url, video_id):
            return self.url_result(encodeArgument(url))

    ie = MockYoutube

# Generated at 2022-06-24 14:14:59.099679
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    dummy_downloader = object()
    pp = XAttrMetadataPP(dummy_downloader)
    assert pp.downloader == dummy_downloader



# Generated at 2022-06-24 14:15:01.045343
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pass

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-24 14:15:02.035521
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # TODO
    pass

# Generated at 2022-06-24 14:15:11.932865
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import tempfile
    import shutil

    import xattr

    from ..utils import DateRange

    def _test_XAttrMetadataPP_run_impl(xattr_available, raise_value_too_long_error, raise_no_space_error):

        class _FakeDownloader:
            def to_screen(self, msg):
                pass

            def report_warning(self, msg):
                pass

            def report_error(self, msg):
                pass

        dl = _FakeDownloader()

        tempdir = tempfile.mkdtemp()
        tmpfile = tempfile.mkstemp(dir=tempdir)[1]

# Generated at 2022-06-24 14:15:16.000198
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    class FakeDownloader:
        def __init__(self, *args, **kwargs):
            pass

        def to_screen(self, msg):
            print(msg)
            msg = msg.strip()

        def report_error(self, msg):
            print('ERROR: ' + msg)

        def report_warning(self, msg):
            print('WARNING: ' + msg)

    from .common import FileDownloader

    d = FileDownloader(FakeDownloader(), None)
    x = XAttrMetadataPP(d)
    x.run({'filepath': '/tmp/foo.mp4', 'title': 'Foö', 'webpage_url': 'http://föö.com', 'upload_date': '20150218'})

# vim:sw=4:ts=4:et:

# Generated at 2022-06-24 14:15:22.126714
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from six.moves import http_client
    filename = 'file.ext'

    def _file_write_xattr_error(filename, xattrname, value):
        raise XAttrMetadataError('RANDOM_ERROR')

    def _file_write_xattr(filename, xattrname, value):
        raise XAttrMetadataError('NO_SPACE')

    def _file_write_xattr_many(filename, xattrname, value):
        if xattrname == 'user.dublincore.title':
            raise XAttrMetadataError('NO_SPACE')
        elif xattrname == 'user.dublincore.comment':
            raise XAttrMetadataError('VALUE_TOO_LONG')


# Generated at 2022-06-24 14:15:33.182992
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    xattr_mapping = {
        'user.xdg.referrer.url': 'webpage_url',
        'user.xdg.comment': 'description',
        'user.dublincore.title': 'title',
        'user.dublincore.date': 'upload_date',
        'user.dublincore.description': 'description',
        'user.dublincore.contributor': 'uploader',
        'user.dublincore.format': 'format',
    }

    downloader = lambda : None
    downloader.to_screen = lambda x: None
    downloader.report_error = lambda x: None
    downloader.report_warning = lambda x: None


# Generated at 2022-06-24 14:15:41.373469
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # pylint: disable=import-error
    from ..utils import xattr
    # pylint: enable=import-error
    pp = XAttrMetadataPP()
    if not xattr.is_xattr_available('.'):
        if not xattr.is_run_as_root():
            # Need to run as root
            return True, "Don't have enough privileges to test XAttrMetadataPP.run()"
        if xattr.is_fuse_available():
            return True, "File system doesn't support extended attributes"
        return False, "XAttrMetadataPP.run() won't work"

# Generated at 2022-06-24 14:15:52.426060
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os
    import tempfile
    import shutil

    class FakeYDL:
        def to_screen(self, s):
            print(s)

        def report_error(self, s):
            print(s)

        def report_warning(self, s):
            print(s)

    info_dict = {
        'webpage_url': 'https://www.youtube.com/watch?v=BaW_jenozKc',
        'title': 'Music at Google: Janelle Monáe',
        'upload_date': '20130223',
        'description':
            'Audrey discusses the importance of music in her life and introduces Janelle Monáe.',
        'uploader': 'Google',
        'format': '16:9',
    }

    xattrs_postprocessor = XAttrMetadataPP

# Generated at 2022-06-24 14:16:00.521646
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import logging
    import unittest
    import tempfile

    from .common import FileDownloader

    from .common import FakeFileDownloader
    from .common import FakeInfoExtractor

    from .common import (
        GOOGLE_URL,
        YOUTUBE_URL,
        YOUTUBE_PLAYLIST_URL,
        YOUTUBE_IE_DESC,
        YOUTUBE_IE_NAME,
        YOUTUBE_IE_URL,
    )

    from .common import (
        SIMPLE_PLAYLIST,
        SIMPLE_PLAYLIST_TITLE,
        SIMPLE_PLAYLIST_ID,
        SIMPLE_PLAYLIST_UPLOADER,
        SIMPLE_PLAYLIST_DESCRIPTION,
        SIMPLE_PLAYLIST_UPLOAD_DATE,
    )


# Generated at 2022-06-24 14:16:10.119339
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .common import FileDownloader
    from ..extractor.youtube import YoutubeIE
    from ..utils import DateRange

    youtube_ie = YoutubeIE()

# Generated at 2022-06-24 14:16:13.245990
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert isinstance(XAttrMetadataPP({}), XAttrMetadataPP)
    assert isinstance(XAttrMetadataPP({'downloader': 'fake'}), XAttrMetadataPP)



# Generated at 2022-06-24 14:16:16.254212
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP({})
    return pp

if __name__ == "__main__":
    test_XAttrMetadataPP()

# Generated at 2022-06-24 14:16:25.220444
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    xattr_mapping = {
        'user.xdg.referrer.url': 'webpage_url',
        # 'user.xdg.comment':            'description',
        'user.dublincore.title': 'title',
        'user.dublincore.date': 'upload_date',
        'user.dublincore.description': 'description',
        'user.dublincore.contributor': 'uploader',
        'user.dublincore.format': 'format',
    }

    if compat_os_name == 'nt':
        print('Unit test fails on Windows')
    else:
        from .._extractor_common import YoutubeIE
        from ..extractor import YoutubeSearchListIE
        from .common import FileDownloader


# Generated at 2022-06-24 14:16:27.518458
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    xattr_pp = XAttrMetadataPP()
    assert isinstance(xattr_pp,PostProcessor)
    assert isinstance(xattr_pp.run,object)

# Generated at 2022-06-24 14:16:29.425160
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pass

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-24 14:16:32.298883
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

if __name__ == '__main__':
    import sys
    import utils.common
    os.chdir(os.path.dirname(os.path.realpath(__file__)))
    utils.common.unit_tests.init(sys.argv, globals())

# Generated at 2022-06-24 14:16:34.506363
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    m = XAttrMetadataPP({})
    assert m.run({}) == ([], {})


if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-24 14:16:35.938760
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP()
    assert pp is not None

# Generated at 2022-06-24 14:16:45.551421
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..downloader import Downloader
    from ..postprocessor import FFmpegMetadataPP
    from ..utils import encodeFilename, prepend_extension
    import requests
    import time
    import os
    import sys

    # Get video filename
    video_filename = encodeFilename('small.mp4')
    video_url = 'https://devimages.apple.com.edgekey.net/streaming/examples/bipbop_16x9/gear1/prog_index.m3u8'
    info = {'id': 'small.mp4', 'ext': 'mp4', 'title': 'Small MP4', 'webpage_url': video_url, 'upload_date': time.strftime('%Y%m%d'), 'uploader': 'Youtube', 'format': 'MP4'}
    # Download video
    download

# Generated at 2022-06-24 14:16:52.737612
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import pytest
    pp = XAttrMetadataPP({})
    info = {
        'filepath': 'tests/files/test.ext',
        'webpage_url': 'http://www.example.com/page.html',
        'format': 'mp4',
        'description': 'test video file',
        'title': 'test video title',
        'upload_date': '20150214',
        'uploader': 'test uploader',
    }
    result, info = pp.run(info)
    assert result == []
    assert info == info

# Generated at 2022-06-24 14:16:55.041914
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    p = XAttrMetadataPP(ydl)
    assert p is not None

# Generated at 2022-06-24 14:16:58.781027
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x = XAttrMetadataPP('test_XAttrMetadataPP')
    from ..compat import xrange
    assert xrange(5) == [0, 1, 2, 3, 4]

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-24 14:17:01.665124
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from .test import get_test_data
    from ..downloader import YoutubeDL

    XAttrMetadataPP(YoutubeDL(get_test_data())).run({'filepath': '-'})

# Generated at 2022-06-24 14:17:02.837189
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    # TODO
    pass

# Generated at 2022-06-24 14:17:04.184575
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    XAttrMetadataPP()

# Generated at 2022-06-24 14:17:05.172303
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass
    # TODO

# Generated at 2022-06-24 14:17:13.632449
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import tempfile
    import os

    # Write temp file
    temp_file = tempfile.NamedTemporaryFile(delete=False)
    temp_file.write(b'Hello')
    temp_file.close()

    # First of all check that file doesn't have any extended attributes
    try:
        write_xattr(temp_file.name, 'user.xdg.comment', 'temp-file')
    except XAttrMetadataError as e:
        if e.reason == 'NO_SUPPORT':
            # This filesystem doesn't support extended attributes;
            # don't run this unit test
            return True
        raise e

    # Make sure that no extended attributes is set

# Generated at 2022-06-24 14:17:17.962357
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # test a known working case
    info = XAttrMetadataPP({'upload_date': '20140101'})
    assert info['upload_date'] == '20140101'

    info = XAttrMetadataPP({'upload_date': '20140101, 20141231'})
    assert info['upload_date'] == '20140101, 20141231'

# Generated at 2022-06-24 14:17:27.563500
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .common import FFmpegPostProcessor, PostProcessingError, PostProcessingWarning
    from ..utils import DateRange, FileDownloader
    from ..compat import compat_os_name
    from ..extractor import YoutubeIE

    if compat_os_name == 'nt':
        return

    # Prepare test

# Generated at 2022-06-24 14:17:30.049345
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    metadata_pp = XAttrMetadataPP(None)  # none is downloader instance

    assert isinstance(metadata_pp, XAttrMetadataPP) is True

# Generated at 2022-06-24 14:17:39.859301
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():

    config = {}
    ydl = FakeYDL()
    pp = XAttrMetadataPP(ydl, config)

    # Call run() method
    info = {'webpage_url': 'http://example.com/', 'description': 'desc: xattr metadata pp test', 'title': 'title: xattr metadata pp test',
            'upload_date': '1970-01-01 00:00:00 +0000', 'uploader': 'uploader: xattr metadata pp test', 'format': 'format: xattr metadata pp test'}
    try:
        pp.run(info)
    except XAttrMetadataError as e:
        print(e)

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-24 14:17:40.467688
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-24 14:17:48.917857
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    filename = 'output_1.mp4'
    info = {
        'webpage_url': 'http://www.youtube.com/watch?v=aBcDeFG',
        'title': 'abc def',
        'upload_date': '20071201',
        'description': 'abc def',
        'uploader': 'abc def',
        'format': 'mp4',
        'filepath': filename,
        'fulltitle': 'abc def',
    }

    #
    # Run the code and check the results.
    #
    class MockYoutubeDLError(Exception):
        def report_warning(self, msg):
            print('WARNING: %s' % msg)

        def report_error(self, msg):
            print('ERROR: %s' % msg)


# Generated at 2022-06-24 14:17:55.886490
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    ydl_opts = {
        'writethumbnail': True,
        'writeinfojson': True,
        'writeautomaticsub': True,
        'writeannotations': True,
        'writesubtitles': True,
        'write_all_thumbnails': True,
    }
    ydl = FakeYDL()
    ydl.add_post_processor(XAttrMetadataPP(ydl))
    ydl.params = ydl_opts
    assert (XAttrMetadataPP not in ydl.registered_pp_classes())


# Generated at 2022-06-24 14:18:02.794860
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import unittest
    import tempfile
    import os
    import stat
    import errno
    import platform
    import sys

    if compat_os_name == 'nt':
        return

    if sys.version_info < (3, 0):
        def decode_str(str):
            return str
    else:
        def decode_str(str):
            return str.decode('utf-8')

    class XAttrTest(unittest.TestCase):
        def setUp(self):
            self.temp_file = tempfile.NamedTemporaryFile(delete=False)
            self.downloader = object
            self.pp = XAttrMetadataPP(self.downloader)

        def tearDown(self):
            os.remove(self.temp_file.name)
            self.temp_file = None

# Generated at 2022-06-24 14:18:07.315948
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import datetime

    from youtube_dl.YoutubeDL import YoutubeDL
    #from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.postprocessor.xattrmetadata import XAttrMetadataPP

    class FakeYDL:
        def __init__(self, filename):
            self.filename = filename
            self.my_dir = os.path.dirname(os.path.abspath(__file__))

        def to_screen(self, s):
            print(s)

        def report_warning(self, s):
            print('WARNING: ' + s)

        def report_error(self, s):
            print('ERROR: ' + s)

        def temp_name(self, s):
            return os.path.join(self.my_dir, self.filename)



# Generated at 2022-06-24 14:18:13.997130
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # Do some usual initialization stuff
    downloader = DummyYDL()
    ie = DummyIE()
    ie._ies = ['dummy_ie']
    ie.set_downloader(downloader)
    ie.add_info_extractor(ie)
    pp = XAttrMetadataPP()
    pp.set_downloader(downloader)
    # Test constructor of class XAttrMetadataPP
    assert pp


# Generated at 2022-06-24 14:18:16.662449
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor.common import InfoExtractor
    ydl = InfoExtractor()
    pp = XAttrMetadataPP(ydl)
    assert isinstance(pp, XAttrMetadataPP)
    assert isinstance(pp, PostProcessor)

# Generated at 2022-06-24 14:18:17.159290
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-24 14:18:25.510937
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..compat import compat_os_name
    from ..extractor import gen_extractors

    if compat_os_name != 'nt':
        info = {
            'filepath': 'video.mp4',
            'format': 'format',
            'webpage_url': 'webpage_url',
            'description': 'description',
            'upload_date': 'upload_date',
            'uploader': 'uploader',
            'title': 'title'
        }

        try:
            assert XAttrMetadataPP(gen_extractors()[0])
            assert True
        except AssertionError:
            assert False

# Generated at 2022-06-24 14:18:33.110889
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    from .common import PostProcessorTest

    with PostProcessorTest(XAttrMetadataPP) as t:

        #
        # Test for return of xattr names (xattr is not available)
        #
        res = t.run_test({'filepath': 'test.mkv', 'title': 'test title', 'format': 'test format', 'webpage_url': 'test_url'})
        exp = [], {'filepath': 'test.mkv', 'title': 'test title', 'format': 'test format', 'webpage_url': 'test_url'}
        assert res == exp, 'Result of method run is not as expected.\nReturned: ' + str(res) + '\nExpected: ' + str(exp) + '\n'



# Generated at 2022-06-24 14:18:43.444460
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    res={'filepath':'test.mp4','webpage_url':'http://www.youtube.com/watch?v=2sD4vEfR2hQ','title':'test title','upload_date':'20000101','description':'test description','uploader':'test uploader','format':'test format'}
    x = XAttrMetadataPP()
    assert x.run(res)==([],{'filepath': 'test.mp4', 'webpage_url': 'http://www.youtube.com/watch?v=2sD4vEfR2hQ', 'title': 'test title', 'upload_date': '20000101', 'description': 'test description', 'uploader': 'test uploader', 'format': 'test format'})


# Generated at 2022-06-24 14:18:53.590057
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..youtube_dl.YoutubeDL import YoutubeDL
    import tempfile
    import shutil
    import os
    import xattr

    workdir = tempfile.mkdtemp()
    dummy_file = os.path.join(workdir, 'testvid.webm')
    with open(dummy_file, 'wb') as f:
        f.write(b'Some file content')

    def _do_test(ydl, expected_keys, expected_values):
        """
        put expected keys and values in a dict.
        if values is empty, the presence of the key is tested.
        """
        assert ydl.download([]) == 0

        for key in expected_keys:
            assert expected_values[key] or key in xattr.listxattr(dummy_file)


# Generated at 2022-06-24 14:19:03.034021
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..YoutubeDL import YoutubeDL
    from ..extractor import common


# Generated at 2022-06-24 14:19:04.393993
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # Placeholder for test
    return True

# Generated at 2022-06-24 14:19:05.779954
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    """Unit test for method run of class XAttrMetadataPP"""

    pass

# Generated at 2022-06-24 14:19:15.293694
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    class DummyYDL:
        def __init__(self):
            self.to_screen = lambda x: None
            self.report_warning = lambda x: None
            self.report_error = lambda x: None
            self.params = {'writedescription': True}

    # Testing normal case:
    pp = XAttrMetadataPP()

    ydl = DummyYDL()
    pp._downloader = ydl


# Generated at 2022-06-24 14:19:23.342311
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    # It's difficult to know if a filesystem supports xattrs or not.
    # Then, there's no easy way to do a unit test.
    #
    # One idea could be to test run on a specific file, then read the xattrs and
    # check if they are the expected ones.
    # But this would mean that we can't use that specific file anymore.
    #
    # Another idea would be to use a virtual filesystem.
    # But this is probably not worth the effort.
    #
    # I'll leave it for now.
    pass

# Generated at 2022-06-24 14:19:30.544926
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import unittest
    import tempfile
    import os
    import xml.dom.minidom
    import shutil
    class MockYDL(object):
        def __init__(self):
            self.params = {'quiet': True, 'no_warnings': True}
            self.to_screen = lambda *args: None
            self.report_warning = lambda *args: None
            self.report_error = lambda *args: None
    class MockFD(object):
        def __init__(self):
            self.filepath = tempfile.mkstemp(text=True)[1]
            self.tmpfilename = self.filepath + '_%(epoch)s.tmp'
            self.tmpfilename = self.tmpfilename.replace("\\", "\\\\")
            self.name = self.filepath

# Generated at 2022-06-24 14:19:38.133547
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    """Unit test for method run of class XAttrMetadataPP"""

    import os
    import shutil
    import tempfile

    # Create temp directory
    tmp_dir = tempfile.mkdtemp(prefix='yttmp_')

    tmp_file = os.path.join(tmp_dir, 'hello.mp4')

    # Create a dummy file of size 100 bytes
    with open(tmp_file, 'wb') as f:
        f.write(b'\x00' * 100)

    # Test for:
    # - xattr support
    # - xattrs on media files

    pp = XAttrMetadataPP()

# Generated at 2022-06-24 14:19:39.303107
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    #TODO implement XAttrMetadataPP unit test
    pass

# Generated at 2022-06-24 14:19:47.857523
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    filename = '/tmp/testfile.flv'
    xattrname = 'user.xdg.comment'
    xattr_mapping = {
        xattrname: 'description'
    }
    try:
        for xattrname, infoname in xattr_mapping.items():
            value = 'XAttrMetadataPP test'
            write_xattr(filename, xattrname, value.encode('utf-8'))
    except NotImplementedError as e:
        pass  # no xattr module
    except Exception as e:
        print(e)
        return False
    return True

# Generated at 2022-06-24 14:19:48.798423
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-24 14:19:56.510379
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import tempfile

    from .common import FileDownloader
    from .fragment import FragmentFD
    from .http import HttpFD

    # Creating objects
    ydl = FileDownloader({'outtmpl': '%(id)s'})
    xattr_pp = XAttrMetadataPP(ydl)
    http_fd = HttpFD(ydl, {'url': 'http://127.0.0.1/'}, {})
    fragment_fd = FragmentFD(ydl, http_fd, {})

    # Creating temporary file
    temp_file = tempfile.NamedTemporaryFile(
        prefix='%s_' % __name__, suffix='.test', delete=False)
    temp_file.close()

    # Testing run method
    ydl.params['writedescription'] = True


# Generated at 2022-06-24 14:20:06.697588
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..downloader.common import FileDownloader
    from ..extractor.common import InfoExtractor
    from ..jsinterp import JSInterpreter

    downloader = FileDownloader({})
    extractor = InfoExtractor({})
    downloader.add_info_extractor(extractor)
    extractor.add_post_processor(XAttrMetadataPP(downloader))

    # Test xattr support
    if XAttrMetadataPP._xattr_supported:
        # Let it fail if unsupported filesystem
        extractor.download(['http://localhost/~rg3/youtube-dl_test/'])
        extractor.download(['http://localhost/~rg3/youtube-dl_test/xattrs_test.html'])

# Generated at 2022-06-24 14:20:14.518763
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..downloader.common import FileDownloader

    class DummyIE():

        def __init__(self, url):
            pass

        def real_download(self, filename, info_dict):
            return filename

    fd = FileDownloader(DummyIE('http://www.youtube.com/watch?v=BaW_jenozKc'), {})
    fd.add_info_extractor(DummyIE)
    fd.add_post_processor(XAttrMetadataPP)

    filename = 'dummy_file'

# Generated at 2022-06-24 14:20:25.703542
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # Test with empty info dict
    pp = XAttrMetadataPP()
    info = {}

    try:
        pp.run(info)
    except XAttrUnavailableError as e:
        assert True

    info['filepath'] = '/some/file/name'
    try:
        pp.run(info)
    except XAttrUnavailableError as e:
        assert True

    # Test with video-only info dict
    info['id'] = 'abcdefghijklmnopqrstuvwxyz'
    info['ext'] = 'mp4'
    info['title'] = 'Test video file'
    info['thumbnail'] = 'http://example.org/thumbnail.jpg'
    info['description'] = 'Some description'
    info['upload_date'] = '20121001'

# Generated at 2022-06-24 14:20:26.689572
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    XAttrMetadataPP({})

# Generated at 2022-06-24 14:20:36.743449
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import platform
    os_name = platform.system()
    if os_name == 'Darwin':
        # osx doesn't support xattrs so test won't work there
        return

    import tempfile
    import os

    if os_name == 'Linux':
        # Check if extended attributes are mounted
        with open('/proc/mounts', 'r') as mounts:
            mounts = mounts.read()
            assert (mounts.find(tempfile.gettempdir()) != -1
                    and mounts.find('user_xattr') != -1), \
                    "In order to test XAttrMetadataPP class on GNU/Linux, you must have user_xattr option set in your fstab."

    # Test default case
    from .common import FileDownloader
    from ..YoutubeDL import YoutubeDL

# Generated at 2022-06-24 14:20:43.807357
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    xattrmetadata = XAttrMetadataPP(object)
    assert xattrmetadata
    assert xattrmetadata.run({'filepath': 'test'})
    assert xattrmetadata.run({'filepath': 'test', 'title': 'test'})
    assert xattrmetadata.run({'filepath': 'test', 'webpage_url': 'test'})
    assert xattrmetadata.run({'filepath': 'test', 'upload_date': 'test'})
    assert xattrmetadata.run({'filepath': 'test', 'description': 'test'})
    assert xattrmetadata.run({'filepath': 'test', 'uploader': 'test'})
    assert xattrmetadata.run({'filepath': 'test', 'format': 'test'})

# Generated at 2022-06-24 14:20:47.364813
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    '''
    Test the constructor of XAttrMetadataPP with a simple example
    '''
    xatt_metadata = XAttrMetadataPP()
    assert isinstance(xatt_metadata, XAttrMetadataPP)

# Generated at 2022-06-24 14:20:47.950254
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-24 14:20:49.352717
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP()

    assert pp.run({}) == ([], {})

# Generated at 2022-06-24 14:20:59.742673
# Unit test for method run of class XAttrMetadataPP