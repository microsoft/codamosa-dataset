

# Generated at 2022-06-24 14:10:52.488545
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-24 14:10:59.985742
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    from ..utils import (
        DateRange,
        FakeDownloader,
        parse_resolution,
    )

    # Test with date range
    date_range = DateRange('20100501', '20100601')

    # Test with duration range
    duration_range = DateRange(10, 100)

    # Test with formats

# Generated at 2022-06-24 14:11:09.731683
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..downloader import FakeYDL
    from ..extractor import gen_extractors
    from .common import FileDownloader
    from ..utils import DateRange

    youtube_ie = gen_extractors(u'youtube')[0]

    ydl = FakeYDL()
    ydl.params['writethumbnail'] = True
    ydl.params['writeinfojson'] = True
    ydl.params['outtmpl'] = '%(id)s.%(ext)s'
    ydl.add_info_extractor(youtube_ie)

    fd = FileDownloader(ydl, {u'url': u'http://youtube.com/v/BaW_jenozKc',
        u'http_chunk_size': 1024**2})
    info = fd.prepare()
    postprocessor = X

# Generated at 2022-06-24 14:11:10.313052
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pass

# Generated at 2022-06-24 14:11:21.021379
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    class FakeFileDownloader:
        def to_screen(self, msg):
            print(msg)

        def report_error(self, msg):
            print('Error: ' + msg)

        def report_warning(self, msg):
            print('Warning: ' + msg)

    class FakeInfoExtractor:
        pass

    from ..compat import compat_os_name, compat_xattr_set, compat_xattr_remove, compat_xattr_get
    import tempfile
    import shutil
    import os
    import stat

    # Save the old functions
    OLD_compat_os_name = compat_os_name
    OLD_compat_xattr_set = compat_xattr_set
    OLD_compat_xattr_remove = compat_xattr_remove
    OLD_compat_x

# Generated at 2022-06-24 14:11:24.997504
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    """
    Unit test for constructor of class XAttrMetadataPP.
    """

    from ..YoutubeDL import YoutubeDL
    downloader = YoutubeDL({})

    pp = XAttrMetadataPP(downloader=downloader)
    print(pp._downloader.ydl_opts)


# Generated at 2022-06-24 14:11:36.374871
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..compat import compat_xattr_get
    from ..utils import encodeFilename, ENCODING
    def write_xattr(filename, key, value):
        filename = encodeFilename(filename)
        f = open(filename, 'w')
        f.write(value)
        f.close()
    import tempfile
    temp_filename = tempfile.mktemp()

# Generated at 2022-06-24 14:11:44.087834
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import format_bytes
    from .common import FileDownloader
    from .simpledefragpp import SimpleDefragPP

    class DummyYDL(object):
        def __init__(self, params):
            self.params = params

    # I can't use the _TEST_FILE_SIZE because there are xattrs to write
    # for the tests to be accurate.

# Generated at 2022-06-24 14:11:44.587609
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pass

# Generated at 2022-06-24 14:11:46.647676
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    ydl_opts = {}
    pp = XAttrMetadataPP(ydl_opts)


# Generated at 2022-06-24 14:11:50.221367
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor.common import InfoExtractor
    from ..youtube_dl.YoutubeDL import YoutubeDL
    xattr_pp = XAttrMetadataPP(YoutubeDL(dict()))
    # No exception raised? Great!
    assert xattr_pp is not None

# Generated at 2022-06-24 14:11:57.137686
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ydl.utils import DateRange

    pp = XAttrMetadataPP()

    # Normal complete info dict
    info = {
        'id': '1234567',
        'url': 'http://example.com/some_video',
        'title': 'Some video title',
        'description': 'Some video description',
        'uploader': 'Some uploader',
        'upload_date': DateRange('2017'),
        'format': 'Some format',
        'webpage_url': 'http://example.com',
    }

    assert pp.run(info) == ([], info)

# Generated at 2022-06-24 14:12:07.567828
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import unittest

    class XAttrMetadataPP_run_TestCase (unittest.TestCase):
        def setUp(self):
            self.pp = XAttrMetadataPP({})
            self.info = {
                'filepath': 'test.mp4',
                'title': 'title',
                'upload_date': '20120201',
                'description': 'description',
                'uploader': 'uploader',
                'format': 'format',
                'webpage_url': 'webpage_url',
            }
            self.pp.add_info_extractor(lambda self,info:info)

        def test_write_metadata(self):
            self.pp.run(self.info)


# Generated at 2022-06-24 14:12:15.577345
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from io import BytesIO
    import tempfile
    import os
    import stat

    filename = tempfile.mktemp()
    destination = BytesIO()
    destination.name = filename
    info = {
        'filepath': filename,
        'format': 'mp4',
        'title': 'Awesome!',
        'description': 'Really awesome',
        'upload_date': '20111010',
        'uploader': 'uploader',
        'webpage_url': 'http://youtube.com/watch?v=',
    }

    # Check if extended attributes need to be enabled

# Generated at 2022-06-24 14:12:24.311849
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..ytdl import YoutubeDL
    from ..extractor.youtube import YoutubeIE

    test_pp = XAttrMetadataPP()
    test_dl = YoutubeDL({})
    test_url = 'https://www.youtube.com/watch?v=BaW_jenozKc'
    # YoutubeDL built with ffmpeg=True
    test_ie = YoutubeIE(test_dl)

    md = test_ie.extract(test_url)
    assert len(md['entries']) == 1
    info = md['entries'][0]
    filepath = test_dl.prepare_filename(info)
    assert info['_filename'] == '41ztHn7A8os'
    assert filepath == '41ztHn7A8os.f137.mp4'

# Generated at 2022-06-24 14:12:32.946267
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..downloader import FakeYDL

    ydl = FakeYDL()
    ydl.params['writedescription'] = True
    XAttrMetadataPP(ydl).run({
        'filepath': 'filepath',
        'webpage_url': 'webpage_url',
        'title': 'title',
        'upload_date': 'upload_date',
        'description': 'description',
        'uploader': 'uploader',
        'format': 'format',
    })


if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-24 14:12:33.866710
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass


# Generated at 2022-06-24 14:12:34.444594
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-24 14:12:43.683160
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import xattr_supported

    if not xattr_supported():
        return

    class DummyDownloader:
        def report_error(self, msg):
            print(msg)

        def report_warning(self, msg):
            print(msg)

        def to_screen(self, msg):
            print(msg)

    downloader = DummyDownloader()

    import tempfile
    tmp_file = tempfile.NamedTemporaryFile(delete=False)
    tmp_file.write(b'foobar')
    tmp_file.close()

    import os
    os.remove(tmp_file.name)


# Generated at 2022-06-24 14:12:46.009806
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass


if __name__ == '__main__':
    print(test_XAttrMetadataPP_run())

# Generated at 2022-06-24 14:12:47.004728
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert(XAttrMetadataPP)

# Generated at 2022-06-24 14:12:49.462100
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    xattr_pp = XAttrMetadataPP()
    assert xattr_pp is not None

# Generated at 2022-06-24 14:12:55.581319
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import unittest

    class TestCase(unittest.TestCase):
        pass

    # TODO:
    #  1) Test a successful run
    #     - return statements
    #     - xattrs written correctly
    #  2) Test XAttrUnavailableError
    #  3) Test XAttrMetadataError

    suite = unittest.TestSuite([
        unittest.defaultTestLoader.loadTestsFromTestCase(TestCase)
    ])

    return suite

# Generated at 2022-06-24 14:12:56.115959
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-24 14:12:58.731730
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():

    # Downloader dummy
    downloader = object

    # Create a XAttrMetadataPP object to test
    postprocessor = XAttrMetadataPP(downloader)


# Generated at 2022-06-24 14:13:09.179440
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor.common import InfoExtractor
    from ..utils import match_filter_func
    from .common import FileDownloader
    from .subtitles import SubtitlesPP
    from .xattr import XAttrMetadataPP

    from collections import namedtuple
    from tempfile import NamedTemporaryFile

    test_data = [
        ('youtube', InfoExtractor),
    ]
    SupportedInfoExtractor = namedtuple(
        'SupportedInfoExtractor', 'ie_key ie_obj')

    info_extractors = [SupportedInfoExtractor(i[0], i[1])
                       for i in test_data]

    ie = InfoExtractor(info_extractors)


# Generated at 2022-06-24 14:13:11.853161
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .common import get_testcases

    testcases = get_testcases()

    for testcase in testcases:
        #
        # TODO: find a way to test this post-processor and write a unit test for it
        #
        pass

# Generated at 2022-06-24 14:13:12.363118
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-24 14:13:15.380395
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP(None)
    print(pp)


if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-24 14:13:25.428785
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    from io import UnsupportedOperation
    from unittest.case import SkipTest

    try:
        from .postprocessor.test_metadata import (
            info_dict,
            metadata_messages,
        )
    except ImportError:
        raise SkipTest('Unable to import test_metadata.py')

    from .common import FileDownloader
    from .utils import match_filter_func

    def postprocessor_factory(ydl, dl, exe):
        return XAttrMetadataPP(ydl)

    def write_xattr(filename, xattrname, byte_value):
        pass

    def raise_XAttrUnavailableError():
        raise XAttrUnavailableError('xattr are unavailable')

    def no_space_exception():
        raise XAttrMetadataError('NO_SPACE')


# Generated at 2022-06-24 14:13:35.689240
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import os
    import textwrap
    import unittest
    from tempfile import mkstemp
    from ydl.utils import compat_os_name

    from .common import prepend_extension
    from .run import run_ffmpeg_pp

    from ..utils import prepend_extension

    # TODO:
    #  * check that 'extra' metadata doesn't go in xattr

    @unittest.skipUnless(compat_os_name == 'posix', 'requires POSIX')
    class TestXAttrMetadataPP_run(unittest.TestCase):

        def setUp(self):
            fd, self.tmpfile = mkstemp(prefix='ydl-test_XAttrMetadataPP_run', suffix='.flv')
            os.close(fd)


# Generated at 2022-06-24 14:13:37.504834
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    '''
    Not easy to test this one in limited-resources unit tests
    '''
    pass

# Generated at 2022-06-24 14:13:38.053528
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-24 14:13:38.551638
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pass

# Generated at 2022-06-24 14:13:46.572945
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # Test with xattr support
    try:
        import xattr  # noqa: F401
    except ImportError:
        import pyxattr as xattr  # noqa: F401

    pp = XAttrMetadataPP(None)
    import os
    import tempfile
    test_filepath = os.path.join(tempfile.gettempdir(), 'ytdl_test_file.txt')
    info = {
        'title': 'test title',
        'webpage_url': 'https://www.youtube.com/watch?v=test',
        'format': 'test format',
        'filepath': test_filepath,
        'uploader': 'test uploader',
        'description': 'test description',
        'upload_date': 'test upload date',
    }

# Generated at 2022-06-24 14:13:57.756207
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..downloader import YoutubeDL
    from ..extractor import YoutubeIE

    ydl = YoutubeDL({})
    ie = YoutubeIE(ydl)
    pp = XAttrMetadataPP(ydl)
    pp.add_info_extractor(ie)

    # Unit tests on a system without extended attributes

# Generated at 2022-06-24 14:13:59.212670
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP(None)._downloader is None
    assert XAttrMetadataPP(None)._filename == ''
    assert XAttrMetadataPP(None)._info is None

# Generated at 2022-06-24 14:14:06.269524
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    ydl = YoutubeDL({})
    ydl.add_default_info_extractors()
    ydl.process_ie_result(
        {
            '_type': 'url',
            'url': 'https://example.com/video',
            'ie_key': 'Youtube',
            'title': 'Video title',
            'id': 'video_id',
            'ext': 'mp4',
            'upload_date': '20171010',
            'uploader': 'Author',
            'description': 'Lorem ipsum',
            'format': '480p',
        }
    )

    pp = XAttrMetadataPP(ydl)


# Generated at 2022-06-24 14:14:12.838303
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os
    import tempfile
    import shutil

    from ..compat import (
        compat_os_name,
        compat_resource_filename,
        compat_urlparse,
    )

    from ..utils import (
        is_xattr_writable,
        XAttrUnavailableError,
        XAttrMetadataError,
    )

    # Mock downloader
    class MockDownloader(object):
        def to_screen(self, msg):
            pass

        def report_warning(self, msg):
            pass

        def report_error(self, msg):
            pass

    import sys
    if not hasattr(sys, '_called_from_test'):
        print('You must do "nosetests -s" to run these tests, not "python runtests.py"')


# Generated at 2022-06-24 14:14:13.215561
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-24 14:14:14.879376
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP().name == 'xattrm'
    assert XAttrMetadataPP().description == 'Write metadata to file\'s xattrs'

# Generated at 2022-06-24 14:14:20.961365
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    try:
        # The following line will fail if run on a filesystem without xattr support
        write_xattr('/tmp', 'user.dummy.test', b'1')
    except XAttrUnavailableError:
        return
    except XAttrMetadataError:
        return

    class DummyDownloader():
        def to_screen(self, msg): pass
        def report_error(self, msg): pass
        def report_warning(self, msg): pass

    xattr_pp = XAttrMetadataPP(DummyDownloader())

    # Put some data into the download info

# Generated at 2022-06-24 14:14:22.997902
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})
    pp = XAttrMetadataPP(ydl)
    assert pp is not None

# Generated at 2022-06-24 14:14:31.851594
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import sys
    import unittest
    from .common import FakeYDL

    from .test_utils import (
        get_filesystem_byte_string,
        make_tempdir,
        remove_tempdir,
        touch_file,
    )

    from ..utils import (
        write_xattr,
        XAttrMetadataError,
    )

    byte_str = get_filesystem_byte_string()

    @unittest.skipUnless(compat_os_name == 'posix', 'Test only available on Posix systems.')
    class TestXAttrMetadataPP_run(unittest.TestCase):

        def setUp(self):
            self.temp_workdir = make_tempdir()

            # Prepare temp file
            self.temp_filename = self.temp_workdir + byte_str

# Generated at 2022-06-24 14:14:41.146780
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    import unittest
    import tempfile
    import os
    import xattr

    class TestXAttrMetadataPP(unittest.TestCase):

        def setUp(self):
            self.tempname = None

        def tearDown(self):
            try:
                if self.tempname is not None:
                    os.remove(self.tempname)
            except OSError:
                pass

        def temp_file(self):
            if self.tempname is None:
                _, self.tempname = tempfile.mkstemp()

            return self.tempname

        def test_xattr_available(self):
            """ Test that class XAttrMetadataPP can check if xattr is available on filesystem. """

            a = XAttrMetadataPP()

            tempname = self.temp_file()

           

# Generated at 2022-06-24 14:14:49.003103
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    try:
        import xattr
    except ImportError:
        print(
            'Info: the Python module xattr was not found. Unit test skipped.',
            file=sys.stderr)
        return None
    try:
        xattr.setxattr('/', 'user.dublincore.title', 'value')
        xattr.setxattr('/', 'user.dublincore.title', b'value')
        xattr.setxattr('/', b'user.dublincore.title', b'value')
    except (IOError, OSError):
        print('Info: extended attributes not supported by your filesystem. Unit test skipped.', file=sys.stderr)
        return None
    import tempfile
    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-24 14:14:53.444376
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..downloader import Downloader
    ydl = Downloader()
    ydl.params['writethumbnail'] = True
    ydl.params['writeautomaticsub'] = False
    ydl.params['writeinfojson'] = False
    pp = XAttrMetadataPP(ydl)
    assert pp.get_name() == 'xattrs'

# Generated at 2022-06-24 14:14:54.380385
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass


# Generated at 2022-06-24 14:15:05.392736
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    try:
        import xattr
    except ImportError:
        return True
    xattrname = 'user.xdg.referrer.url'
    filename = 'TEST_FILENAME'
    value = 'TEST_VALUE'
    byte_value = value.encode('utf-8')
    info = {
        'filepath': filename,
        'webpage_url': value,
        'title': value,
        'upload_date': '20170228',
        'description': value,
        'uploader': value,
        'format': value,
    }
    write_xattr(filename, xattrname, byte_value)
    assert xattr.getxattr(filename, xattrname).decode('utf-8') == value

# Generated at 2022-06-24 14:15:15.944189
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import sys
    from .common import FileDownloader
    from .test_utils import make_fake_info_dict

    info_dict = make_fake_info_dict()
    filename = 'test.mp4'

    class XAttrMetadataPP_run_MockFileDownloader(FileDownloader):

        processed_info_dicts = []

        def report_error(self, msg):
            self.processed_info_dicts.append('ERROR')

        def report_warning(self, msg):
            self.processed_info_dicts.append('WARNING')

        def to_screen(self, msg):
            pass


# Generated at 2022-06-24 14:15:17.689255
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from .common import FileDownloader
    # TODO: find a way to test that with real xattrs
    ydl = FileDownloader({})

# Generated at 2022-06-24 14:15:18.431406
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP('a', 'b')

# Generated at 2022-06-24 14:15:19.150082
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-24 14:15:26.126931
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from .common import PostProcessor
    from .common import FileDownloader
    from .common import FFmpegPostProcessor
    from .xattrpp import XAttrMetadataPP

    youtube_pp = PostProcessor([FFmpegPostProcessor(), XAttrMetadataPP()])
    downloader = FileDownloader({}, youtube_pp, None)
    xattr_metadata_pp = XAttrMetadataPP(downloader)

    assert xattr_metadata_pp is not None

# Generated at 2022-06-24 14:15:36.011315
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    import sys

    # sys.argv = [sys.argv[0], '-i', 'https://www.youtube.com/watch?v=BaW_jenozKc']
    sys.argv = [sys.argv[0],
                '--xattrs',
                '-i', 'https://www.youtube.com/watch?v=BaW_jenozKc']

    from ..YoutubeDL import YoutubeDL

    ydl = YoutubeDL()
    ydl.params['logger'].addHandler(ydl.params['file_handler'])
    ydl.download(['https://www.youtube.com/watch?v=BaW_jenozKc'])


if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-24 14:15:41.346780
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    import sys
    from .common import FileDownloader
    from .xattr import _xattr_available

    # Testing if the constructor does not crash in case xattr is available and
    # if it prints an error message in case xattr is not available.
    if _xattr_available():
        x = XAttrMetadataPP(FileDownloader({}))
    else:
        sys.stderr.write('TESTERROR: xattr was not available on your system, '
                         'but the error message was not written.\n')
        sys.exit(99)

# Generated at 2022-06-24 14:15:43.195866
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert isinstance(XAttrMetadataPP({}), PostProcessor)



# Generated at 2022-06-24 14:15:44.157706
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-24 14:15:54.953423
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .common import FileDownloader
    from .get_thumbnail import GetThumbnailPP
    from .xattr_writer import XAttrMetadataPP
    from ..utils import get_filesystem_encoding
    import pytest
    import shutil
    import os

    filename = 'testvideo.mkv'

# Generated at 2022-06-24 14:15:58.317028
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    """ Create an instance of XAttrMetadataPP, for testing purposes. """
    from ..YoutubeDL import YoutubeDL
    return XAttrMetadataPP(YoutubeDL())

# Generated at 2022-06-24 14:16:08.194721
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    import pytest
    from ..downloader import Downloader
    from .common import FileDownloader
    from ..extractor import YoutubeIE
    from ..utils import encodeFilename

    pytest.main(args=['-v', '--tb=no', os.path.abspath(__file__)])

    test_urls = [
        'http://www.youtube.com/watch?v=BaW_jenozKc',
        'https://www.youtube.com/watch?v=UxxajLWwzqY',
    ]

    dl = Downloader(params={
        'outtmpl': '%(id)s'
    })

    ie = YoutubeIE(dl)

    def test_video_data(expected_info):
        info_dict = {}

# Generated at 2022-06-24 14:16:10.622601
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    XAttrMetadataPP('test_downloader')


# Generated at 2022-06-24 14:16:13.075486
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    """
    Test the method XAttrMetadataPP.run(info).
    """
    pass

# Generated at 2022-06-24 14:16:23.344562
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # Create an instance XAttrMetadataPP
    pp = XAttrMetadataPP()

    # Create a dictionary to pass it as a parameter "info" to method run
    # The pp.run method need at least these two elements in "info"

# Generated at 2022-06-24 14:16:30.319017
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import encodeFilename


# Generated at 2022-06-24 14:16:31.619544
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    xattrs_pp = XAttrMetadataPP({})
    assert xattrs_pp is not None

# Generated at 2022-06-24 14:16:34.968149
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # To be considered:
    #   Setting more than one xattr in a single 'setxattr(2)' system call.
    #   Error handling.
    #   ...

    #
    # FIXME: Can you write unit tests for XAttrMetadataPP?
    #
    pass

# vim:et:sw=4:ts=4

# Generated at 2022-06-24 14:16:36.500890
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# vim: tabstop=8 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-24 14:16:45.946540
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ytdl_server.extractors.common import InfoExtractor
    from ytdl_server.downloader.FileDownloader import FileDownloader
    from ytdl_server.utils import sanitize_path
    from ytdl_server.YoutubeDL import YoutubeDL
    from ytdl_server.compat import compat_os_name

    if compat_os_name != 'posix':
        return

    def fake_info_extractor_constructor(id_str):
        return InfoExtractor(FakeYoutubeDL(), id_str)


# Generated at 2022-06-24 14:16:55.155107
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import tempfile

    # Get the path and name of a temporary file
    fd, filename = tempfile.mkstemp()

    # Remove the file
    os.remove(filename)

    # Create a file, which will be used in the test
    fp = open(filename, 'w')
    fp.close()

    # Initialize the post-processor
    pp = XAttrMetadataPP('/bin/echo')

    # Initialize info dict

# Generated at 2022-06-24 14:17:00.917951
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import tempfile

    info = {'filepath': tempfile.mktemp(), 'title': 'title', 'upload_date': 'upload_date', 'description': 'description',
            'uploader': 'uploader', 'format': 'format', 'webpage_url': 'webpage_url'}

    actual = XAttrMetadataPP().run(info)
    expected = ([], info)

    assert actual == expected


post_processor_class = XAttrMetadataPP

# Generated at 2022-06-24 14:17:01.494362
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-24 14:17:05.073670
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    '''
    Run a construction test on class XAttrMetadataPP
    '''

    xattr_metadata_pp = XAttrMetadataPP({})
    assert xattr_metadata_pp

# Generated at 2022-06-24 14:17:13.562414
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..downloader import YoutubeDL

    class YoutubeDLMock(YoutubeDL):
        def __init__(self, *args, **kwargs):
            self.filepath = kwargs.pop('filepath')
            self.to_screen_calls = []
            self.report_warning_calls = []
            self.report_error_calls = []
            super(YoutubeDLMock, self).__init__(*args, **kwargs)

        def to_screen(self, message):
            self.to_screen_calls.append(message)

        def report_warning(self, message):
            self.report_warning_calls.append(message)

        def report_error(self, message):
            self.report_error_calls.append(message)


# Generated at 2022-06-24 14:17:14.328527
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr = XAttrMetadataPP(None)

# Generated at 2022-06-24 14:17:16.592211
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():

    # assert XAttrMetadataPP.run(1, 2) == 3
    # assert XAttrMetadataPP.run(2, 3) == 4

    assert True

# Generated at 2022-06-24 14:17:20.467357
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass


if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-24 14:17:21.595164
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP(None)
    assert pp is not None

# Generated at 2022-06-24 14:17:27.952745
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from .common import FileDownloader
    info = {
        'webpage_url': 'http://youtube.com/watch?v=BaW_jenozKc',
        'uploader': 'Lil Wayne',
        'format': 'webm',
        'title': 'VEVO Playlist - The Best Of Vevo - 2014',
        'description': 'Here is a compilation of the best vevo videos of the year 2014.',
        'upload_date': '20141212',
    }
    ydl = FileDownloader(params={})
    ydl.post_processors['metadata'] = XAttrMetadataPP(ydl)
    ret = ydl.post_processors['metadata'].run(info)

# Generated at 2022-06-24 14:17:32.230547
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    try:
        pp = XAttrMetadataPP()
    except:
        raise AssertionError("Cannot construct XAttrMetadataPP")

# Generated at 2022-06-24 14:17:40.059459
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os
    import tempfile
    import shutil
    import sys

    # Create temporary download directory
    download_dir = tempfile.mkdtemp()

    # Create file
    test_file = os.path.join(download_dir, 'test.mp4')
    f = open(test_file, 'w')
    f.write("this is a test")
    f.close()

    # Test video info
    info = {
            'filepath': test_file,
            'webpage_url': 'http://www.youtube.com/watch?v=example',
            'title': 'A Youtube Video',
            'description': 'This is a Youtube video',
            'upload_date': '20120101',
            'uploader': 'Youtuber',
            'format': 'video (mp4)',
    }



# Generated at 2022-06-24 14:17:42.835689
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # There must be a way to unit test postprocessors too, not only extensions...
    xattr = XAttrMetadataPP()
    # xattr.run()

# Generated at 2022-06-24 14:17:54.460937
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    """ Tests constructor of class XAttrMetadataPP """
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import sanitize_open

    # Prepare vars
    test_url = r'http://www.youtube.com/watch?v=BaW_jenozKc'

# Generated at 2022-06-24 14:18:02.466909
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    """
    Test XAttrMetadataPP.run
    """
    info = {'filepath': '/tmp/file', 'webpage_url': 'foo', 'title': 'bar', 'upload_date': '123',
            'description': 'foobar', 'uploader': 'foo bar', 'format': 'abc def'}
    pp = XAttrMetadataPP(None)
    return pp.run(info)

#
# End of XAttrMetadataPP
#

if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-24 14:18:11.665050
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from .common import PostProcessor
    from .ffmpeg import FFmpegPostProcessor
    from .execafterdownload import ExecAfterDownloadPP
    from .metadatafromtitle import MetadataFromTitlePP
    from .embedthumbnail import EmbedThumbnailPP
    from .xattrmetadata import XAttrMetadataPP
    from .ffmpegmetadata import FFmpegMetadataPP
    from .execafterdownload import ExecAfterDownloadPP

    ffmpeg_postprocessor = FFmpegPostProcessor()

    # Tests all defined post processors
    postprocessors = [
        MetadataFromTitlePP(),
        EmbedThumbnailPP(),
        XAttrMetadataPP(),
        FFmpegMetadataPP(),
        ExecAfterDownloadPP(),
    ]

    # ffmpeg_postprocessor is not a member of the postprocessors list but it could be used in combination with a post processor like Embed

# Generated at 2022-06-24 14:18:20.355060
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import unittest
    import os.path
    import io
    import re
    from .common import PostProcessorTest
    from ..utils import encodeFilename, sanitize_filename

    TEST_FILE = '3WaSdTs1dlw.mp4'
    TEST_URL = 'https://www.youtube.com/watch?v=3WaSdTs1dlw'
    TEST_DATE = '20111103'
    TEST_TITLE = 'Matt Willis - Hey Kid (Official Video)'
    TEST_DESCRIPTION = 'Visit Matt Willis\' website for exclusive content & news http://www.mattwillis.com/ Facebook: https://www.facebook.com/MattWillisFans Twitter: https://twitter.com/mattjwillis #MattWillis #HeyKid #Vevo #Pop #OfficialMusicVideo'
    TEST_UPL

# Generated at 2022-06-24 14:18:29.841542
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    from ..downloader.common import FileDownloader
    from ..compat import compat_os_name


# Generated at 2022-06-24 14:18:35.844476
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import os
    import tempfile

    from .test_postprocessor_pp import (
        test_PostProcessor_run__ok,
        test_PostProcessor_run__none,
    )

    # Create a dummy temporary file
    fd, filename = tempfile.mkstemp()
    os.write(fd, b'0123456789')
    os.close(fd)

    # This is a valid info object
    info = {
        'filepath': filename,
        'webpage_url': 'http://foo.bar',
        'title': 'This is a title',
        'upload_date': '20140531',
        'description': 'This is a description',
        'uploader': 'An uploader',
        'format': 'The format',
    }

    # With this info object, this test gets 100

# Generated at 2022-06-24 14:18:36.619777
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    return

# Generated at 2022-06-24 14:18:45.643690
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    try:
        import pyxattr
    except ImportError:
        import pytest
        pytest.skip('pyxattr is not available')

    from tempfile import TemporaryDirectory
    from ..downloader import YoutubeDL
    from ..extractor import YoutubeIE

    with TemporaryDirectory() as tmpdir:
        filename = tmpdir + '/test_video.mp4'
        open(filename, 'a').close()


# Generated at 2022-06-24 14:18:50.108377
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP.__name__ == 'XAttrMetadataPP'
    assert XAttrMetadataPP.__module__ == 'youtube_dl.postprocessor.xattr_metadata'

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-24 14:18:57.715736
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import unittest
    import os
    import shutil
    import tempfile
    import xattr
    from collections import OrderedDict
    from .common import FileDownloader

    from . import XAttrMetadataPP, download_with_files

    class TestXAttrMetadataPP(unittest.TestCase):

        def test_run(self):
            tmp_dir = tempfile.mkdtemp()

            # Testing the extended attributes writing
            file_path = os.path.join(tmp_dir, 'dummy')

            open(file_path, 'a').close()


# Generated at 2022-06-24 14:18:58.272183
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-24 14:19:09.720043
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from .. import YoutubeDL
    metadata = {
        'upload_date': '20130203',
        'resolution': '1024x768',
        'format': 'FooBar format',
        'title': 'The foo-bar show',
        'uploader': 'fooman',
        'description': 'This is a foo bar video',
        'creator': 'foo man choo',
        'webpage_url': 'http://www.example.com/video/12345-foobar',
        'thumbnail': 'http://www.example.com/thumbnails/123456.jpg',
        'duration': 42,
    }
    temp_filename = 'myfile.tmp'

# Generated at 2022-06-24 14:19:10.449609
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP()

# Generated at 2022-06-24 14:19:17.599925
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os
    import re
    from .internal import FakeYDL
    from ..utils import (
        PY2,
        prepend_extension,
        xattr_writable,
    )

    # Generate a fake info_dict
    info = {}
    info['webpage_url'] = 'https://www.youtube.com/watch?v=_n5GqYqr3aI'
    info['title'] = 'The End - The Doors (Original)'
    info['upload_date'] = '19700101'
    info['description'] = """People are strange when you're a stranger"""
    info['uploader'] = 'The Doors'
    info['format'] = 'audio only'

    filename = 'The Doors - The End.webm'

# Generated at 2022-06-24 14:19:20.679476
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    xattr = XAttrMetadataPP()

    return True


if __name__ == '__main__':
    print(test_XAttrMetadataPP())

# Generated at 2022-06-24 14:19:24.080294
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    """ Test XAttrMetadataPP constructor """

    # Constructor with no params
    XAttrMetadataPP()
    return

# Generated at 2022-06-24 14:19:26.130469
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP.__name__ == 'XAttrMetadataPP'


if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-24 14:19:34.429135
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os
    import shutil
    from .common import FileDownloader
    from .tmpfiles import TemporaryDirectory
    from .extractor import YoutubeIE

    # Create a temporary directory, and a subdirectory with a dummy file inside
    tmp = TemporaryDirectory(suffix='_youtubedl')
    tmp_sub = os.path.join(tmp.getname(), 'sub')
    os.mkdir(tmp_sub)
    with open(os.path.join(tmp_sub, 'video.flv'), 'w') as f:
        f.write('test data')

    # Initialize FileDownloader with our YouTubeIE as the only one IE

# Generated at 2022-06-24 14:19:44.266759
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_dict = {}
    test_dict['title'] = "test"
    test_dict['webpage_url'] = "www.test.com"

# Generated at 2022-06-24 14:19:48.167353
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    xattr_pp = XAttrMetadataPP(
        'youtube-dl',
        {
            'title': 'abc',
            'webpage_url': 'https://example.com',
            'upload_date': '20200801',
            'uploader': 'test',
            'format': 'testformat',
            'filepath': 'test.mp4'
        }
    )


# Generated at 2022-06-24 14:19:56.079063
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    try:
        import xattr
    except ImportError:
        return # skip test

    ydl = FakeYDL()
    ydl.add_info_extractor(FakeIE())
    ydl.params['writethumbnail'] = True
    ydl.params['writeinfojson'] = True

    filename = 'test_video.mp4'
    with open(filename, 'wb') as f:
        f.write(b'A' * 1048576)


# Generated at 2022-06-24 14:20:06.384904
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import unittest
    import os.path
    from ..extractor.common import InfoExtractor
    from ..utils import fs_encode


    class TestIE(InfoExtractor):

        def _real_extract(self, url):
            return {
                'id': '123456789',
                'title': 'test video',
                'uploader': 'test_uploader',
                'description': 'test description',
                'webpage_url': 'http://www.test.com/numerique.html?id=video&v=57824',
                'upload_date': '20150607',
                'ext': 'test_ext',
                'format': 'test_format',
                'dummy_xattr': 'test_xattr',
            }


# Generated at 2022-06-24 14:20:11.421621
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..utils import DateRange
    from ..extractor import YoutubeIE

    info = dict(
        filepath = 'TEST',
        webpage_url = 'TEST',
        description = 'TEST',
        title = 'TEST',
        upload_date = DateRange('TEST'),
        uploader = 'TEST',
        format = 'TEST',
    )

    pp = XAttrMetadataPP(YoutubeIE(), {})
    pp.run(info)

# Generated at 2022-06-24 14:20:13.403397
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    ydl = XAttrMetadataPP(None, None, {})
    assert ydl is not None

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-24 14:20:24.606779
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # TODO: improve unit test

    from ..downloader import DummyYDL
    from ..extractor import gen_extractors
    from ..utils import DateRange

    url = 'https://youtu.be/BaW_jenozKc'


# Generated at 2022-06-24 14:20:34.828435
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import encodeFilename
    from .common import FileDownloader
    from .test.test_postprocessor import _test_postprocessor_run
    from ..compat import compat_xattr
    from ..compat import compat_os_name
    from ..compat import compat_os_path
    from ..compat import compat_urllib_request

    class FakeInfoExtractor(object):
        def __init__(self, ie_description, ie_name, ie_thumbnail = None, **ie_kwargs):
            self.ie_kwargs = ie_kwargs

    class FakeFileDownloader(FileDownloader):
        def __init__(self, *args, **kwargs):
            pass

        def to_screen(self, msg):
            pass

        def report_warning(self, msg):
            pass


# Generated at 2022-06-24 14:20:35.712841
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pass # TODO : Add test for this class

# Generated at 2022-06-24 14:20:36.945395
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP()
    assert pp is not None


# Generated at 2022-06-24 14:20:37.570928
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    result = XAttrMetadataPP()
    assert result

# Generated at 2022-06-24 14:20:39.332821
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP()

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-24 14:20:40.037229
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert True

# Generated at 2022-06-24 14:20:41.889962
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # Test the constructor of class XAttrMetadataPP
    pp = XAttrMetadataPP()
    assert(str(pp) == "XAttrMetadataPP")



# Generated at 2022-06-24 14:20:51.782994
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from collections import OrderedDict
    from ..compat import compat_os_name

    from .common import PostProcessorTestCase

    from .common import get_temp_filename

    class XAttrMetadataPPTest(PostProcessorTestCase):

        def setUp(self):
            """ Set up the test, for instance with read/write access to a temp dir """

            self.tempdir = tempfile.mkdtemp()
            self.filedir = os.path.join(self.tempdir, 'temp.file')

        def tearDown(self):
            if os.path.isdir(self.tempdir):
                shutil.rmtree(self.tempdir)

        # Test that the metadata is written to the file's xattrs (if possible)

# Generated at 2022-06-24 14:20:55.166637
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    filedata = []
    pp = XAttrMetadataPP(filedata)
    assert pp.new_filepath is None
