

# Generated at 2022-06-26 13:44:04.611130
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    info_0 = {}
    print('[*] Calling run on XAttrMetadataPP, giving it 1 parameter named info_0')
    print('    info_0: ' + str(info_0))
    (return_value_0, return_value_1) = x_attr_metadata_p_p_0.run(info_0)
    print('    Return value: ' + str(return_value_0))
    print('    Return value: ' + str(return_value_1))

if __name__ == '__main__':
    test_case_0()
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:44:06.090572
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()



# Generated at 2022-06-26 13:44:13.784242
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()

    # Test for the exception error
    try:
        x_attr_metadata_p_p_0.run(None)
    except RuntimeError:
        pass

    # Test for the exception error
    try:
        x_attr_metadata_p_p_0.run((None,))
    except RuntimeError:
        pass

    # Test for the exception error
    try:
        x_attr_metadata_p_p_0.run([None])
    except RuntimeError:
        pass

    # Test for the exception error
    try:
        x_attr_metadata_p_p_0.run((None, None))
    except RuntimeError:
        pass

    # Test for the exception error

# Generated at 2022-06-26 13:44:21.906431
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    info = {
        'filepath': '/tmp/video.mp4',
        'webpage_url': 'http://www.youtube.com/watch?v=BaW_jenozKc',
        'description': 'This is a test video description',
        'title': 'test video title',
        'upload_date': '20121002',
        'uploader': 'test video uploader',
        'format': 'test video format',
        }

    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0.run(info) == ([], info)

test_case_0()
test_XAttrMetadataPP_run()
print('passed all tests')

# Generated at 2022-06-26 13:44:25.783188
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP(test_case_0)

test_XAttrMetadataPP()

# Generated at 2022-06-26 13:44:31.286852
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    filename = "Hello World!"
    infoname = "Hello World!"
    info = {'filepath': filename, 'format': infoname}
    exit_code_0, info = x_attr_metadata_p_p_0.run(info)
    assert(exit_code_0 == [])
    assert(info == info)

# Generated at 2022-06-26 13:44:34.833485
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    # TODO: Add tests for method run of class XAttrMetadataPP

# Generated at 2022-06-26 13:44:45.067715
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    # Initialize namespace
    in_filepath_0 = 'XAttrMetadataPP_0.xattr'
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    in_info_0 = {}
    in_info_0['filepath'] = in_filepath_0
    in_info_0['webpage_url'] = 'webpage_url_0'
    in_info_0['title'] = 'title_0'
    in_info_0['upload_date'] = 'upload_date_0'
    in_info_0['height'] = 'height_0'
    in_info_0['description'] = 'description_0'
    in_info_0['Uploader'] = 'Uploader_0'
    in_info_0['ext'] = 'ext_0'

# Generated at 2022-06-26 13:44:46.047062
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pass

# Generated at 2022-06-26 13:44:48.650829
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    print("[XAttrMetadataPP] Constructor test")
    print("[XAttrMetadataPP] Constructor test finished")
    return True


# Generated at 2022-06-26 13:45:02.929724
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from youtube_dl.YoutubeDL import YoutubeDL


# Generated at 2022-06-26 13:45:07.247902
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = None
    x_attr_metadata_p_p_1 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_1.run(x_attr_metadata_p_p_0)



# Generated at 2022-06-26 13:45:16.027220
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = {'uploader': 'uploader', 'title': 'title', 'webpage_url': 'webpage_url', 'ext': 'ext',
                             'format': 'format', 'id': 'id', 'description': 'description', 'upload_date': 'upload_date',
                             'filename': 'filename'}
    x_attr_metadata_p_p_1 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_1.run(x_attr_metadata_p_p_0) == ([], x_attr_metadata_p_p_0)

# Test for function write_xattr of module 'compat.xattr'

# Generated at 2022-06-26 13:45:18.749087
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_8 = XAttrMetadataPP()
    return x_attr_metadata_p_p_8


# Generated at 2022-06-26 13:45:25.447831
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(test_case_0())
    assert var_0 == [], 'test_XAttrMetadataPP_run failed'


if __name__ == '__main__':
    # Unit test
    test_XAttrMetadataPP_run()

    print(
        'The unit test will not actually do anything, because writing extended attributes to files is platform dependent '
        'and requires special permissions on some systems. It will only verify that the code runs without crashing.')

# Generated at 2022-06-26 13:45:27.101132
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    print('Testing method run of class XAttrMetadataPP')
    test_case_0()


# Generated at 2022-06-26 13:45:29.971512
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    # test method run
    assert x_attr_metadata_p_p_0.run(None) is None

# test_case_0()

# Generated at 2022-06-26 13:45:32.301070
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    # TODO: py.test: unit test for XAttrMetadataPP.__init__


# Generated at 2022-06-26 13:45:38.081909
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from .common import PostProcessor
    from .xattrpp import XAttrMetadataPP
    from .aa import AA
    from .aafilter import AAFilter
    from .aacfilter import AACFilter
    from .aacpp import AACPP
    from .antitopic import AntiTopic
    from .audioqualitymodifier import AudioQualityModifier
    from .concatpp import ConcatPP
    from .embedthumbnail import EmbedThumbnail
    from .ffmpegmetadata import FFmpegMetadata
    from .ffmpegmux import FFmpegMux
    from .ffmpegpostprocessor import FFmpegPostProcessor
    from .ffmpegthumbnail import FFmpegThumbnail
    from .ffmpegtilex import FFmpegTileX
    from .ffmpegtiley import FFmpegTileY
    from .ffmpegvideofilters import FFmpeg

# Generated at 2022-06-26 13:45:38.912728
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # Test case 0
    #
    # Test case 1
    pass


# Generated at 2022-06-26 13:45:54.791377
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = None
    x_attr_metadata_p_p_1 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_1.run(x_attr_metadata_p_p_0)

if __name__ == '__main__':
    test_case_0()
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:45:57.686330
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = None
    x_attr_metadata_p_p_1 = XAttrMetadataPP()


# Generated at 2022-06-26 13:45:58.540081
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()

# Generated at 2022-06-26 13:46:00.212470
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p = XAttrMetadataPP()
    assert x_attr_metadata_p_p != None


# Generated at 2022-06-26 13:46:02.986698
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_2 = None
    x_attr_metadata_p_p_3 = XAttrMetadataPP()
    var_1 = x_attr_metadata_p_p_3.run(x_attr_metadata_p_p_2)


# Generated at 2022-06-26 13:46:06.398002
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    x_attr_metadata_p_p_0.run(x_attr_metadata_p_p_0)

# Generated at 2022-06-26 13:46:17.155941
# Unit test for method run of class XAttrMetadataPP

# Generated at 2022-06-26 13:46:22.983212
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = None
    x_attr_metadata_p_p_1 = XAttrMetadataPP()
    assert isinstance(x_attr_metadata_p_p_1, XAttrMetadataPP)
    # Test method XAttrMetadataPP.run()
    x_attr_metadata_p_p_0 = None
    var_0 = x_attr_metadata_p_p_1.run(x_attr_metadata_p_p_0)

# Generated at 2022-06-26 13:46:25.448003
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    try:
        pass
    except:
        # TODO: implement your test here
        assert False


# Test class for XAttrMetadataPP, class of module youtube_dl.postprocessor

# Generated at 2022-06-26 13:46:30.401863
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from sys import stdout
    from pytube.compat import compat_expanduser
    from pytube import Playlist
    from pytube.cli import get_cached_path, cache_path
    from pytube.cipher import Cipher

    import time
    import os

    from pytube.compat import (
        compat_str,
        compat_os_name,
    )

    from pytube.exceptions import (
        CipherError,
        PytubeError,
        RegexMatchError,
        VideoUnavailable,
        LiveStreamError,
    )


# Generated at 2022-06-26 13:46:53.309216
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = None
    x_attr_metadata_p_p_1 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_1.run(x_attr_metadata_p_p_0)


# Generated at 2022-06-26 13:46:54.092256
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    assert True



# Generated at 2022-06-26 13:46:55.632062
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p = XAttrMetadataPP()
    x_attr_metadata_p_p.run(dict())

# Generated at 2022-06-26 13:46:56.711517
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP() is not None

# Generated at 2022-06-26 13:46:59.236206
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    print("Start testing XAttrMetadataPP()")
    test_case_0()
    print("End testing XAttrMetadataPP()")



# Generated at 2022-06-26 13:47:00.097368
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()


# Generated at 2022-06-26 13:47:03.493888
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(123)
    print(var_0)

# Generated at 2022-06-26 13:47:05.383398
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()

if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:47:08.412002
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert(isinstance(x_attr_metadata_p_p_0, XAttrMetadataPP))


# Generated at 2022-06-26 13:47:14.521154
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = None
    x_attr_metadata_p_p_1 = XAttrMetadataPP()
    # Unit test for method run()
    assert x_attr_metadata_p_p_1.run(x_attr_metadata_p_p_0) == ([], x_attr_metadata_p_p_0)

if __name__ == "__main__":
    test_case_0()
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:47:55.672335
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    assert isinstance(test_case_0(), tuple)

# Generated at 2022-06-26 13:48:02.111551
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = None
    x_attr_metadata_p_p_1 = XAttrMetadataPP()
    x_attr_metadata_p_p_2 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_1.run(x_attr_metadata_p_p_0)
    var_1 = x_attr_metadata_p_p_2.run(x_attr_metadata_p_p_0)


# Generated at 2022-06-26 13:48:08.090612
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    #
    # Test ID: 0
    #
    # Test name: test_case_0
    #
    # Test description: Test method run of class XAttrMetadataPP
    #
    # Steps:
    # 1. Create an instance of class XAttrMetadataPP
    # 2. Invoke run, passing an instance of class Dict as parameter
    #
    # Expected result:
    # 1. Instance of class XAttrMetadataPP is created
    # 2. Method run of class XAttrMetadataPP is invoked
    #

    test_case_0()

# Generated at 2022-06-26 13:48:12.062716
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = None
    x_attr_metadata_p_p_1 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_1 is not None


# Generated at 2022-06-26 13:48:22.004146
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    x_attr_metadata_p_p = XAttrMetadataPP()

    x_attr_metadata_p_p.run(None)

# END_OF_CLASS_DEFINITION

if __name__ == "__main__":
    import sys
    import io
    import traceback

    from contextlib import contextmanager
    from collections import deque

    @contextmanager
    def stdoutIO(stdout=None):
        old = sys.stdout
        if stdout is None:
            stdout = io.StringIO()
        sys.stdout = stdout
        yield stdout
        sys.stdout = old

    @contextmanager
    def stderrIO(stderr=None):
        old = sys.stderr
        if stderr is None:
            stderr = io.StringIO()

# Generated at 2022-06-26 13:48:22.911007
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()


# Generated at 2022-06-26 13:48:24.066587
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()
    pass


# Generated at 2022-06-26 13:48:26.306362
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    return x_attr_metadata_p_p_0

# Generated at 2022-06-26 13:48:29.399379
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = None
    x_attr_metadata_p_p_1 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_1.run(x_attr_metadata_p_p_0)

# Generated at 2022-06-26 13:48:39.119731
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    filename = 'test'
    xattr_mapping = {
        'user.xdg.referrer.url': 'webpage_url',
        'user.dublincore.title': 'title',
        'user.dublincore.date': 'upload_date',
        'user.dublincore.description': 'description',
        'user.dublincore.contributor': 'uploader',
        'user.dublincore.format': 'format',
    }

    # Test case no: 0

# Generated at 2022-06-26 13:50:04.701059
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    global x_attr_metadata_p_p_0
    x_attr_metadata_p_p_0 = XAttrMetadataPP()

    # Run tests
    test_case_0()

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:50:05.533127
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()


# Generated at 2022-06-26 13:50:10.567887
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = None
    x_attr_metadata_p_p_1 = XAttrMetadataPP()
    # Testing parameter: info
    x_attr_metadata_p_p_0 = None
    var_0 = x_attr_metadata_p_p_1.run(x_attr_metadata_p_p_0)
    var_1 = x_attr_metadata_p_p_1.run(x_attr_metadata_p_p_0)
    assert var_0 == var_1

# Generated at 2022-06-26 13:50:11.852946
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

# Generated at 2022-06-26 13:50:13.570825
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass


if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:50:14.735291
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p = XAttrMetadataPP()

# Generated at 2022-06-26 13:50:18.688980
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    if compat_os_name != 'nt':
        x_attr_metadata_p_p_0 = None
        x_attr_metadata_p_p_1 = XAttrMetadataPP()
        var_0 = x_attr_metadata_p_p_1.run(x_attr_metadata_p_p_0)
        assert var_0 == ([], None)

test_case_0()

# Generated at 2022-06-26 13:50:19.889045
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()

# vim: tabstop=8 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-26 13:50:21.601621
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # Instantiation of class XAttrMetadataPP
    x_attr_metadata_p_p = XAttrMetadataPP()


# Generated at 2022-06-26 13:50:22.321214
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()