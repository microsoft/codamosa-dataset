

# Generated at 2022-06-26 13:43:59.679973
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()
    return True


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 13:44:08.741093
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # Create an instance of class XAttrMetadataPP
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    # Create a variable for argument "info"
    info_0 = 'eX8#N{B!v'
    # Invoke method "run" of class "XAttrMetadataPP" with argument "info"
    return_value_0 = x_attr_metadata_p_p_0.run(info_0)


# Generated at 2022-06-26 13:44:19.080463
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    # Action
    info_0 = {'filepath': 'index', 'upload_date': 'index', 'format': 'index', 'uploader': 'index', 'title': 'index', 'description': 'index', 'webpage_url': 'index'}
    x_attr_metadata_p_p_0.run(info_0)

if __name__ == '__main__':
    test_case_0()
    test_XAttrMetadataPP_run()
    print('Unit test completed')

# Generated at 2022-06-26 13:44:22.012828
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()

# Generated at 2022-06-26 13:44:31.649687
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # x_attr_metadata_p_p_0 = XAttrMetadataPP()
    try:
        # Exception raised when it doesn't have the required attributes
        x_attr_metadata_p_p_1 = XAttrMetadataPP(["abc"], ["abc"], ["abc"], ["abc"], ["abc"], ["abc"], ["abc"], ["abc"], ["abc"], ["abc"], ["abc"], ["abc"], ["abc"], ["abc"], ["abc"], ["abc"], ["abc"], ["abc"], ["abc"], ["abc"], ["abc"], ["abc"], ["abc"], ["abc"], ["abc"])
    except Exception as exc:
        print(exc)


# Generated at 2022-06-26 13:44:35.175540
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    print('test_XAttrMetadataPP: ' + str(XAttrMetadataPP))

if __name__ == "__main__":
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:44:37.726975
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()


# Generated at 2022-06-26 13:44:40.240305
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:44:41.841702
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()


# Generated at 2022-06-26 13:44:44.819141
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    return x_attr_metadata_p_p_0

# if __name__ == '__main__':
#     test_XAttrMetadataPP()

# Generated at 2022-06-26 13:45:00.948741
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_1 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_1._downloader == None,\
        "Constructor of class XAttrMetadataPP is not working as expected"
    assert x_attr_metadata_p_p_1._downloader_prefs == None,\
        "Constructor of class XAttrMetadataPP is not working as expected"
    assert x_attr_metadata_p_p_1._ie_key == None,\
        "Constructor of class XAttrMetadataPP is not working as expected"
    assert isinstance(x_attr_metadata_p_p_1.name, str),\
        "Constructor of class XAttrMetadataPP is not working as expected"


# Generated at 2022-06-26 13:45:01.361703
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    assert(True)

# Generated at 2022-06-26 13:45:05.787981
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    info = {'webpage_url': 'https://www.youtube.com/watch?v=dQw4w9WgXcQ'}
    info['filepath'] = '/tmp/unavailable_path'
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    x_attr_metadata_p_p_0.run(info)

if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:45:07.247630
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0 is not None


# Generated at 2022-06-26 13:45:17.374193
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    filename = 'filename'
    info = {
        'filepath': filename,
        'title': 'title',
        'description': 'description',
        'uploader': 'uploader',
        'upload_date': 'upload_date',
        'format': 'mp4',
    }
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    filename = info['filepath']

# Generated at 2022-06-26 13:45:18.285777
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()


# Generated at 2022-06-26 13:45:20.709636
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert x_attr_metadata_p_p_0.__class__.__name__ == 'XAttrMetadataPP'


# Generated at 2022-06-26 13:45:21.259044
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-26 13:45:27.232544
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

# Unit test
# pytest -v -s test_XAttrMetadataPP.py

# Unit test coverage
# pytest --cov=YoutubeDL --cov-report term-missing -v -s test_XAttrMetadataPP.py

# Integration test
# python -m YoutubeDL.extractor.XAttrMetadataPP

# Integration test coverage
# coverage run --source=YoutubeDL -m YoutubeDL.extractor.XAttrMetadataPP; coverage report

# Integration test verbose
# python -m YoutubeDL.extractor.XAttrMetadataPP -v

# Generated at 2022-06-26 13:45:28.900732
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    try:
        test_case_0()
        assert True
    except AssertionError:
        assert False

# Generated at 2022-06-26 13:45:42.896233
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    str_0 = '1T/y$P"4;e7%`)zShTag'
    str_1 = ''
    var_0 = x_attr_metadata_p_p_0.run(str_1)
    str_1 = ''
    var_1 = x_attr_metadata_p_p_0.run(str_1)
    str_1 = ''
    var_2 = x_attr_metadata_p_p_0.run(str_1)
    str_1 = ''
    var_3 = x_attr_metadata_p_p_0.run(str_1)

# Generated at 2022-06-26 13:45:44.959639
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

if __name__ == "__main__":
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:45:48.414855
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert isinstance(x_attr_metadata_p_p_0, XAttrMetadataPP)

# Generated at 2022-06-26 13:45:50.942947
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    assert(isinstance(XAttrMetadataPP().run(1), tuple))
    assert(isinstance(XAttrMetadataPP().run(""), tuple))

# Generated at 2022-06-26 13:45:57.563889
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert isinstance(x_attr_metadata_p_p_0, PostProcessor) is True
    boolean_0 = x_attr_metadata_p_p_0.is_enabled()
    if boolean_0:
        str_1 = 'Rb0Cd8]v'
        var_0 = x_attr_metadata_p_p_0.run(str_1)



# Generated at 2022-06-26 13:46:00.512408
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p = XAttrMetadataPP()
    # Case 0
    str = 'wY@!%H^JmzI9)ZX?~D$3q'
    var_0 = x_attr_metadata_p_p.run(str)

# Generated at 2022-06-26 13:46:01.816186
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert callable(XAttrMetadataPP), 'XAttrMetadataPP is not callable'


# Generated at 2022-06-26 13:46:02.913921
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # TODO: Unit test for method run of class XAttrMetadataPP
    pass

# Generated at 2022-06-26 13:46:05.441626
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # Test 0
    test_case_0()

if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:46:10.562752
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    try:
        x_attr_metadata_p_p_0 = XAttrMetadataPP()
        x_attr_metadata_p_p_0.run(1)
    except XAttrMetadataError as e:
        return True
    return False


# Generated at 2022-06-26 13:46:21.922421
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # TODO
    pass


# Generated at 2022-06-26 13:46:25.683251
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    str_0 = '1T/y$P"4;e7%`)zShTag'
    var_0 = x_attr_metadata_p_p_0.run(str_0)
    assert not (var_0 is None)


# Generated at 2022-06-26 13:46:26.432969
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()

# Generated at 2022-06-26 13:46:27.620671
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()

# Generated at 2022-06-26 13:46:28.740231
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

# Generated at 2022-06-26 13:46:29.660956
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

# Generated at 2022-06-26 13:46:32.408753
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    str_0 = '`S'
    var_0 = XAttrMetadataPP().run(str_0)
    var_1 = XAttrMetadataPP().run(str_0)

# Generated at 2022-06-26 13:46:34.519816
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()

if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:46:41.735974
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()

    #
    # More info about extended attributes for media:
    #   http://freedesktop.org/wiki/CommonExtendedAttributes/
    #   http://www.freedesktop.org/wiki/PhreedomDraft/
    #   http://dublincore.org/documents/usageguide/elements.shtml
    #
    # TODO:
    #  * capture youtube keywords and put them in 'user.dublincore.subject' (comma-separated)
    #  * figure out which xattrs can be used for 'duration', 'thumbnail', 'resolution'
    #

    # Test case for str input of run method

# Generated at 2022-06-26 13:46:51.749784
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(None)
    assert var_0 == ([], None)

    str_0 = '1T/y$P"4;e7%`)zShTag'
    var_1 = x_attr_metadata_p_p_0.run(str_0)
    assert var_1 == ([], str_0)

    str_0 = ' !aq"2q&s3WrTn'
    var_2 = x_attr_metadata_p_p_0.run(str_0)

# Generated at 2022-06-26 13:47:13.207467
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_1 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_1 is not None

# Generated at 2022-06-26 13:47:16.693927
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()

    # AssertionError: Failed to create XAttrMetadataPP object: Class XAttrMetadataPP is an abstract class.
    pass



if __name__ == '__main__':
    test_case_0()
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:47:23.102197
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata = XAttrMetadataPP()
    x_attr_metadata._downloader = True
    print("***** XAttrMetadataPP test_run *****")
    print("****** Testing data ******")
    print("x_attr_metadata: ", x_attr_metadata)
    print("Testing data is ready")
    print("****** Testing execution ******")
    x_attr_metadata.run("tu nombre")
    print("testing")
    print("Done")

# Generated at 2022-06-26 13:47:29.075607
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    str_0 = 'Zs?9a7hJ]*'
    var_0 = x_attr_metadata_p_p_0.run(str_0)
    assert str_0 == 'Zs?9a7hJ]*'
    assert var_0[0] == []
    assert var_0[1] == 'Zs?9a7hJ]*'

# Generated at 2022-06-26 13:47:30.793875
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()


# Generated at 2022-06-26 13:47:32.892279
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0 != None


# Generated at 2022-06-26 13:47:34.301346
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pass



# Generated at 2022-06-26 13:47:37.357808
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    str_0 = '1T/y$P"4;e7%`)zShTag'
    var_0 = x_attr_metadata_p_p_0.run(str_0)

# Generated at 2022-06-26 13:47:39.136474
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0 is not None

# Generated at 2022-06-26 13:47:41.909663
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    str_0 = '1T/y$P"4;e7%`)zShTag'
    var_0 = x_attr_metadata_p_p_0.run(str_0)
    print(var_0)



# Generated at 2022-06-26 13:48:26.729474
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    str_0 = 'H,=J7@g+}[duK4Rz'
    var_0 = x_attr_metadata_p_p_0.run(str_0)


# Generated at 2022-06-26 13:48:30.638323
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    str_0 = '1T/y$P"4;e7%`)zShTag'
    var_0 = x_attr_metadata_p_p_0.run(str_0)


# Generated at 2022-06-26 13:48:33.695378
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p = XAttrMetadataPP()
    x_attr_metadata_p_p.run(None)


# Generated at 2022-06-26 13:48:34.481519
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()

# Generated at 2022-06-26 13:48:41.467593
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    str_0 = '1T/y$P"4;e7%`)zShTag'
    tuple_0 = x_attr_metadata_p_p_0.run(str_0)
    assert len(tuple_0) == 2, 'list length was: %d' % len(tuple_0)
    assert tuple_0[0] == [], 'list was: %s' % repr(tuple_0[0])
    assert tuple_0[1] == '1T/y$P"4;e7%`)zShTag'


# Generated at 2022-06-26 13:48:42.300924
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()

# Generated at 2022-06-26 13:48:43.357301
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:48:45.243691
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p = XAttrMetadataPP()
    assert x_attr_metadata_p_p.__class__ == XAttrMetadataPP



# Generated at 2022-06-26 13:48:47.058201
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()

if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:48:50.937803
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_1 = XAttrMetadataPP()
    x_attr_metadata_p_p_2 = XAttrMetadataPP()
    str_1 = '7mF.RjhXD'
    var_1 = x_attr_metadata_p_p_2.run(str_1)
    return (var_1)


# Test for exception XAttrMetadataError.
# Reason:
#  Unable to write extended attributes due to too long values.

# Generated at 2022-06-26 13:50:18.364421
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()


# Generated at 2022-06-26 13:50:21.528058
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    str_0 = '1T/y$P"4;e7%`)zShTag'
    var_0 = x_attr_metadata_p_p_0.run(str_0)

# Generated at 2022-06-26 13:50:24.158291
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    case_0_results = [
        ['[metadata] Writing metadata to file\'s xattrs']
    ]
    test_case_0()
    assert case_0_results == 'done'


if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:50:26.651135
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0 is not None


# Generated at 2022-06-26 13:50:27.885152
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # Test case 0
    test_case_0()

# Generate unit tests

# Generated at 2022-06-26 13:50:30.961769
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    try:
        test_case_0()
        test_case_1()
    except:
        print ("test case not ok")
    else:
        print ("test case ok")


# Generated at 2022-06-26 13:50:33.484389
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()

if __name__ == '__main__':
    test_case_0()
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:50:35.316800
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()
    # TODO: Add more tests

if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:50:36.012703
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    assert True == True


# Generated at 2022-06-26 13:50:37.148998
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # tests if an object of the class could be created.
    XAttrMetadataPP()
