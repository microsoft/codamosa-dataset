

# Generated at 2022-06-26 13:43:58.754458
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    XAttrMetadataPP()

# Unit testing for run

# Generated at 2022-06-26 13:44:01.949045
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    XAttrMetadataPPClass.run()


# Generated at 2022-06-26 13:44:11.530332
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..compat import mock, compat_os_name

    test_data = {
        'filepath': '/Users/nati/Downloads/test.mp4',
        'webpage_url': 'http://www.youtube.com/watch?v=ABCDEFG',
        'title': 'Test Title',
        'upload_date': '20130701',
        'uploader': 'Test User',
        'description': 'Test Description',
    }


# Generated at 2022-06-26 13:44:12.821768
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()


# Generated at 2022-06-26 13:44:22.145726
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    filename = 'test_filepath'
    num_written = 2
    error_msg = 'This filesystem doesn\'t support extended attributes. '\
                + '(You may have to enable them in your /etc/fstab)'

    write_xattr = lambda filename, xattrname, byte_value: True
    xattr_mapping = {'user.xdg.referrer.url': 'webpage_url',
                     'user.dublincore.title': 'title'}
    try:
        from ..utils import XAttrUnavailableError
        raise XAttrUnavailableError('Unavailable')
    except XAttrUnavailableError as e:
        assert str(e) == 'Unavailable', 'Unavailable error not working.'


# Generated at 2022-06-26 13:44:25.013025
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()


# Generated at 2022-06-26 13:44:25.945129
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pass

# Generated at 2022-06-26 13:44:29.712210
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()


if __name__ == '__main__':
    test_case_0()
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:44:39.169452
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()

    filename = "downloads/TEST_FILE"
    info = {
        'webpage_url' : "TEST",
        'title' : "TEST",
        'upload_date' : "TEST",
        'description' : "TEST",
        'uploader' : "TEST",
        'format' : "TEST",
        'filepath': filename,
    }
    x_attr_metadata_p_p_0.run(info)

# Generated at 2022-06-26 13:44:43.511716
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p = XAttrMetadataPP()
    if (x_attr_metadata_p_p.__class__.__name__ == 'XAttrMetadataPP'):
        print("Testcase for constructor of class XAttrMetadataPP passed.")
    else:
        print("Testcase for constructor of class XAttrMetadataPP failed.")


# Generated at 2022-06-26 13:44:50.311913
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()


# Generated at 2022-06-26 13:44:55.099250
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
#     x_attr_metadata_p_p_0.run(float_0)

# Generated at 2022-06-26 13:44:58.415204
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    float_0 = -137.5398
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(float_0)


# Generated at 2022-06-26 13:45:01.143154
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    float_0 = -137.5398
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert isinstance(x_attr_metadata_p_p_0, XAttrMetadataPP)


# Generated at 2022-06-26 13:45:05.849452
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # There is no disk space left, disk quota exceeded or filesystem xattr limit exceeded.
    assert test_case_0() == (None, -137.5398)

if __name__ == '__main__':
    import sys
    import nose
    #from nose.tools import *
    module_name = sys.modules[__name__].__file__

    result = nose.run(argv=[sys.argv[0],
                            module_name,
                            '-s', '-v'])

# Generated at 2022-06-26 13:45:07.895271
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()


# Generated at 2022-06-26 13:45:08.901778
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert True


# Generated at 2022-06-26 13:45:18.872777
# Unit test for method run of class XAttrMetadataPP

# Generated at 2022-06-26 13:45:21.377640
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    var_0 = XAttrMetadataPP()
    upload_date_0 = var_0.run(1384991489)

# Generated at 2022-06-26 13:45:22.540801
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()

# End of test cases for method run of class XAttrMetadataPP

# Generated at 2022-06-26 13:45:34.178286
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0.run(10) == []

# Generated at 2022-06-26 13:45:35.518638
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    float_0 = -137.5398
    assert (XAttrMetadataPP().run(float_0) == ([], -137.5398))

# Generated at 2022-06-26 13:45:36.992248
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    var_0 = XAttrMetadataPP()
    if (not isinstance(var_0, XAttrMetadataPP)):
        raise Exception("Missing type casting")


# Generated at 2022-06-26 13:45:38.599875
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    float_0 = 11
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(float_0)

# Generated at 2022-06-26 13:45:44.522869
# Unit test for method run of class XAttrMetadataPP

# Generated at 2022-06-26 13:45:48.040850
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0.run is not None

# Generated at 2022-06-26 13:45:51.604358
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    float_0 = -137.5398
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(float_0)

# Generated at 2022-06-26 13:45:52.857978
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert isinstance(x_attr_metadata_p_p_0, XAttrMetadataPP)



# Generated at 2022-06-26 13:45:56.382002
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    float_1 = -137.5398
    x_attr_metadata_p_p_1 = XAttrMetadataPP()
    var_1 = x_attr_metadata_p_p_1.run(float_1)

# Generated at 2022-06-26 13:45:57.923126
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert isinstance(XAttrMetadataPP(), XAttrMetadataPP), "Incorrect type of object!"


# Generated at 2022-06-26 13:46:17.882817
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pass

# Generated at 2022-06-26 13:46:19.207173
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    obj = XAttrMetadataPP()



# Generated at 2022-06-26 13:46:27.377884
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    assert XAttrMetadataPP().run((-7, -5)) == (5, -7)
    assert XAttrMetadataPP().run((4, 1)) == (1, 4)
    assert XAttrMetadataPP().run((-2, 10)) == (8, -2)
    assert XAttrMetadataPP().run((6, -7)) == (-1, 6)
    assert XAttrMetadataPP().run((-9, 4)) == (-5, -9)
    assert XAttrMetadataPP().run((3, -1)) == (2, 3)
    assert XAttrMetadataPP().run((-10, -10)) == (0, -10)
    assert XAttrMetadataPP().run((1, 1)) == (0, 1)

# Generated at 2022-06-26 13:46:37.113933
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # Test case 0
    float_0 = -137.5398
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(float_0)
# Test case 1
    float_1 = 30.6
    x_attr_metadata_p_p_1 = XAttrMetadataPP()
    var_1 = x_attr_metadata_p_p_1.run(float_1)
# Test case 2
    float_2 = 137.5398001
    x_attr_metadata_p_p_2 = XAttrMetadataPP()
    var_2 = x_attr_metadata_p_p_2.run(float_2)
# Test case 3
    float_3 = -45.7
   

# Generated at 2022-06-26 13:46:41.105661
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    float_0 = -137.5398
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0.run(float_0) == ([], float_0)

# Generated at 2022-06-26 13:46:51.349389
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    if (x_attr_metadata_p_p_0.run() != None):
        var_0 = True
    else:
        var_0 = False
    assert var_0

# print(test_case_0())

# class TestXAttrMetadataPP(unittest.TestCase):
#
#     def test_run(self):
#         x_attr_metadata_p_p_0 = XAttrMetadataPP()
#         if (x_attr_metadata_p_p_0.run() != None):
#             var_0 = True
#         else:
#             var_0 = False
#         assert var_0
#
#
# if __name__ == '__main__':
#     un

# Generated at 2022-06-26 13:46:54.015888
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    float_0 = -137.5398
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(float_0)

# Generated at 2022-06-26 13:46:56.064555
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    a = XAttrMetadataPP()
    assert_equals(a.run, None)


if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:46:58.300461
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    # AssertionError: expected {'float_0': -137.5398}, got {'var_0': ([], -137.5398)}
    test_case_0()

# Generated at 2022-06-26 13:47:03.329659
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    assert test_XAttrMetadataPP_run.__doc__ == XAttrMetadataPP.run.__doc__
    test_case_0()


if __name__ == '__main__':
    import pytest
    pytest.main(['--tb=line', 'test_XAttrMetadataPP.py'])

# Generated at 2022-06-26 13:47:42.914682
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    try:
        test_case_0()
        assert True
    except AssertionError:
        assert False


# Generated at 2022-06-26 13:47:52.714156
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    float_0 = -137.5398
    float_1 = float('nan')
    float_2 = float('-inf')
    float_3 = float('inf')
    str_0 = '9h\x99\x91\n\xb6\xe4\t\n\t\n'
    str_1 = '9h\x99\x91\n\xb6\xe4\t\n\t\n'
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    int_0 = x_attr_metadata_p_p_0.run(float_0)
    int_1 = x_attr_metadata_p_p_0.run(float_1)
    int_2 = x_attr_metadata_p_p_0.run(float_2)


# Generated at 2022-06-26 13:47:56.883136
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0 != None

if __name__ == "__main__":
    test_XAttrMetadataPP()
    test_case_0()

# Generated at 2022-06-26 13:48:01.395495
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    for test_input in [
                        ]:
        print(test_input)
        assert test_input==test_input, "test_Input is not test_Input"


# Entrypoint of this module
if __name__ == '__main__':
    print("Running unit test for XAttrMetadataPP class")
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:48:04.676798
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    float_0 = -171.25
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(float_0)
    print(var_0)

test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:48:08.040613
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # Create new object
    obj_XAttrMetadataPP = XAttrMetadataPP()

if __name__ == '__main__':
    test_XAttrMetadataPP()
    test_case_0()

# Generated at 2022-06-26 13:48:12.018882
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    try:
        x_attr_metadata_p_p_0 = XAttrMetadataPP()
        print('Success: XAttrMetadataPP was created')
    except NameError:
        print('Failed: XAttrMetadataPP was not created')

# Generated at 2022-06-26 13:48:21.972548
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # Arrange
    float_0 = -137.5398
    x_attr_metadata_p_p_0 = XAttrMetadataPP()

    # Act
    var_0 = x_attr_metadata_p_p_0.run(float_0)

    actual = var_0
    assert actual == [], f"Expected: [], Actual: {actual}"


# Generated at 2022-06-26 13:48:23.502088
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()



# Generated at 2022-06-26 13:48:25.447592
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    # TODO: test


# Generated at 2022-06-26 13:49:50.122652
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    mm_0 = XAttrMetadataPP()


# Generated at 2022-06-26 13:49:52.838798
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # Unit test for XAttrMetadataPP.run(info)
    # test_case_0()
    pass

# Program entry point
if __name__=='__main__':
    # test_XAttrMetadataPP()
    pass

# Generated at 2022-06-26 13:50:04.096975
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert 1 == 1

    float_0 = -137.5398
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(float_0)

    float_0 = -137.5398
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(float_0)

    float_0 = -137.5398
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(float_0)

    float_0 = -137.5398
    x_attr_metadata_p_p_0 = X

# Generated at 2022-06-26 13:50:11.374307
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from random import random
    from string import ascii_letters, digits

    alphabet = list(ascii_letters) + list(digits)
    test_str = ''.join([alphabet[int(random() * 62)] for _ in range(35)])
    info_dict = {
        'filepath': test_str,
        'webpage_url': 'about:blank',
        'title': 'title',
        'upload_date': '20140101',
        'description': 'description',
        'uploader': 'uploader',
        'format': 'format',
    }
    xattrmetadatapp = XAttrMetadataPP()

    from ..utils import _external_downloader

# Generated at 2022-06-26 13:50:14.415253
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()


# Generated at 2022-06-26 13:50:17.925080
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    try:
        x_attr_metadata_p_p_0 = XAttrMetadataPP()
        test_case_0()
    except NameError as e:
        return "an exception was thrown"
    else:
        return x_attr_metadata_p_p_0

XAttrMetadataPP()

# Generated at 2022-06-26 13:50:21.746263
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    float_0 = -47.2686
    x_attr_metadata_p_p_0.run(float_0)
    var_0 = x_attr_metadata_p_p_0.run(float_0)
    test_case_0()


# Generated at 2022-06-26 13:50:22.786090
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()

# Generated at 2022-06-26 13:50:25.661751
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # Test for method run of class XAttrMetadataPP
    # Testing with no arguments passed
    assert False


# Generated at 2022-06-26 13:50:27.058288
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
