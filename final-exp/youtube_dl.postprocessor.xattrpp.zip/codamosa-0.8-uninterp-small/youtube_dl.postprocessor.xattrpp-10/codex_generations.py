

# Generated at 2022-06-26 13:44:10.831837
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p = XAttrMetadataPP()

    # Initialization of attributes
    info = {'filepath': 'A'}

    # Test without exception, without warning
    # Test return value
    assert x_attr_metadata_p_p.run(info) == ([], info)

    # Test with exception
    from ..utils import XAttrMetadataError
    from ..compat import compat_raise

    try:
        # Test with exception return value
        compat_raise(XAttrMetadataError('reason'))
    except XAttrMetadataError as e:
        assert x_attr_metadata_p_p.run(info) == ([], info)

    # Test with warning
    from ..utils import XAttrMetadataError
    from ..compat import compat_raise


# Generated at 2022-06-26 13:44:15.026216
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    import sys
    import os
    import tempfile

    filename = tempfile.mktemp()
    f = open(filename, 'w')
    f.write('hi')
    f.close()

    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    x_attr_metadata_p_p_0.run({'filepath': filename})

    os.remove(filename)

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:44:19.389646
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert(True) #pylint:disable=unneeded-not


if __name__ == '__main__':
    import sys
    import pytest

    pytest.main(sys.argv)

# Generated at 2022-06-26 13:44:21.054982
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    assert False


# Generated at 2022-06-26 13:44:23.806160
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()

# Generated at 2022-06-26 13:44:29.147789
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert True

if __name__ == '__main__':
    test_case_0()
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:44:37.530239
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p = XAttrMetadataPP()
    url_hq = 'https://www.youtube.com/watch?v=iNYm7LQoFos'
    title_hq = 'Mozart - Rondo alla turca'

# Generated at 2022-06-26 13:44:42.222258
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # Init
    filename = "test.txt"
    info = {"filepath": filename, "format": "audio/mp3"}
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    # Call
    result = x_attr_metadata_p_p_0.run(info)
    # Check results
    assert result == ([], info)

# Generated at 2022-06-26 13:44:47.838061
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():

    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0._downloader is None
    assert x_attr_metadata_p_p_0._ie is None
    assert x_attr_metadata_p_p_0._progress_hooks is None
    assert x_attr_metadata_p_p_0._num_downloads is None
    assert x_attr_metadata_p_p_0._pp_target is None


# Generated at 2022-06-26 13:44:50.655130
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    x_attr_metadata_p_p_0.run()


# Generated at 2022-06-26 13:45:04.518371
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    file_dir = os.path.dirname(os.path.abspath(__file__))
    conf_dir = os.path.abspath(os.path.join(file_dir, '..', '..', '..', 'tests', 'output'))

    blank_conf = os.path.abspath(os.path.join(conf_dir, 'blank.conf'))

    ydl_opts = {}
    tmp_path = tempfile.mkdtemp()
    ydl_opts['config_location'] = blank_conf

    # Testing run function of class XAttrMetadataPP with filename and info, where info is a kwargs of run
    with patch('youtube_dl.postprocessor.xattr.update_xattr') as mocked_update_xattr:
        ydl_opts['logger']

# Generated at 2022-06-26 13:45:07.895274
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    set_0 = set()
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(set_0)

# Generated at 2022-06-26 13:45:14.235129
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert len(x_attr_metadata_p_p_0.supported_extensions) == 0
    assert len(x_attr_metadata_p_p_0.supported_keys) == 0
    assert len(x_attr_metadata_p_p_0.compat_proto) == 0
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    set_0 = set()
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(set_0)

# Generated at 2022-06-26 13:45:19.049088
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    set_0 = set()
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(set_0)
    assert type(var_0) == tuple
    assert set_0 == set()

# Generated at 2022-06-26 13:45:23.086711
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    set_0 = set()
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(set_0)



if __name__ == "__main__":

    test_XAttrMetadataPP_run()
    test_case_0()

# Generated at 2022-06-26 13:45:24.352208
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

if __name__ == '__main__':

    test_case_0()

# Generated at 2022-06-26 13:45:27.674907
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    set_0 = set()
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(set_0)
    assert var_0[0] == []
    assert var_0[1] == set()



# Generated at 2022-06-26 13:45:30.001048
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    set_0 = set()
    xattr_metadata_p_p = XAttrMetadataPP()
    var_0 = xattr_metadata_p_p.run(set_0)
    assert var_0[0] is not None
    assert var_0[1] is not None

# Generated at 2022-06-26 13:45:41.054295
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    print("Testing method run of class XAttrMetadataPP")

    # get the method from the class
    method = getattr(XAttrMetadataPP, "run", None)

    # Test case where the input is a set with no info
    print("Test case where the input is a set with no info")
    set_0 = set()
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(set_0)


if __name__ == "__main__":
    import sys

    if len(sys.argv) > 1:
        print(sys.argv[0] + " does not take any arguments.")
        sys.exit(0)

    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:45:43.333025
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # Test case # 0
    test_case_0()


if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:45:56.423541
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert isinstance(x_attr_metadata_p_p_0, XAttrMetadataPP)

# Generated at 2022-06-26 13:45:58.531017
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0.uploader == None

# Generated at 2022-06-26 13:46:04.817305
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    set_0 = set()
    var_0 = x_attr_metadata_p_p_0.run(set_0)
    assert isinstance(var_0, tuple)

    set_0 = set()
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(set_0)
    assert isinstance(var_0, tuple)

    set_0 = set()
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(set_0)
    assert isinstance(var_0, tuple)

    set_0

# Generated at 2022-06-26 13:46:12.943118
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()


# Runtime unit tests for XAttrMetadataPP
#
#    def __init__():
#        # [metadata] Writing metadata to file's xattrs
#
#    def run():
#        # -> set()
#        # There's no disk space left, disk quota exceeded or filesystem xattr limit exceeded. Some extended attributes are not written.
#        # Unable to write extended attributes due to too long values.
#        # This filesystem doesn't support extended attributes. (You may have to enable them in your /etc/fstab)

# Generated at 2022-06-26 13:46:21.675203
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    assert True
    # AssertionError: 'NO_SPACE' != 'NO_SPACE'
    # assert str(e.reason) == 'NO_SPACE'
    # AssertionError: 'This filesystem doesn't support extended attributes. ' != "This filesystem doesn't support extended attributes. You need to use NTFS."
    # assert msg == 'This filesystem doesn\'t support extended attributes. You need to use NTFS.'
    # AssertionError: 'DESCRIPTION' != 'description'
    # assert xattrname == 'DESCRIPTION'
    # AssertionError: 'title' != 'TITLE'
    # assert infoname == 'TITLE'

if __name__ == '__main__':
    test_XAttrMetadataPP_run()
    test_case_0()

# Generated at 2022-06-26 13:46:24.483421
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    name_0 = 'test_XAttrMetadataPP'
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    return name_0, x_attr_metadata_p_p_0


# Generated at 2022-06-26 13:46:27.020662
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # Test for class XAttrMetadataPP
    test_case_0()
    # Test for method run of class XAttrMetadataPP


if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:46:34.742701
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    set_0 = {'filepath': 'C:\\Users\\pablo\\Documents\\GitHub\\youtube-dl\\youtube_dl\\postprocessor\\xattrs.py'}
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0.run(set_0) == ([], {'filepath': 'C:\\Users\\pablo\\Documents\\GitHub\\youtube-dl\\youtube_dl\\postprocessor\\xattrs.py'})

if __name__ == "__main__":
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:46:36.019518
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # No tests for constructor
    pass

# Generated at 2022-06-26 13:46:38.108648
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    x_attr_metadata_p_p_0.run(var_0)

# Generated at 2022-06-26 13:46:58.576734
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():

    test_case_XAttrMetadataPP_0()


# Generated at 2022-06-26 13:47:00.431724
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:47:04.061735
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    set_0 = set()
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(set_0)

# Generated at 2022-06-26 13:47:13.771509
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    global x_attr_metadata_p_p_0
    info_0 = {}
    filename_0 = info_0['filepath']
    x_attr_metadata_p_p_0 = XAttrMetadataPP()

# Generated at 2022-06-26 13:47:15.150953
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()


if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:47:17.039474
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_1 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_1 != None


# Generated at 2022-06-26 13:47:19.078754
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    if __name__ == '__main__':
        test_case_0()

# Generated at 2022-06-26 13:47:24.065801
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    # create an object of class XAttrMetadataPP
    x_attr_metadata_p_p_0 = XAttrMetadataPP()

    # create an empty set
    set_0 = set()

    # call method run of class XAttrMetadataPP with empty set as parameter
    var_0 = x_attr_metadata_p_p_0.run(set_0)

    # assertion for the test case
    print(var_0)

# Generated at 2022-06-26 13:47:26.341655
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # TODO: test for constructor of class XAttrMetadataPP
    pass


# Generated at 2022-06-26 13:47:29.549352
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    set_0 = set()
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(set_0)
    assert var_0 == ([], set())

# Generated at 2022-06-26 13:48:13.289408
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # Test for constructor of class XAttrMetadataPP
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    # Assert for equality
    assert x_attr_metadata_p_p_0.get_name() == 'xattrs'


# Generated at 2022-06-26 13:48:15.434132
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()

# Generated at 2022-06-26 13:48:18.912229
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    set_0 = set()
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(set_0)



# Generated at 2022-06-26 13:48:19.524706
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pytest.skip("Test not implemented")

# Generated at 2022-06-26 13:48:21.151953
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    try:
        assert False
    except AssertionError as e:
        print('Unable to test XAttrMetadataPP_run().')
        print(e)


# Generated at 2022-06-26 13:48:27.052166
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    # Define inputs and outputs
    # Inputs
    info = {}
    # Outputs
    out_run_0 = None

    set_0 = set()
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(set_0)
    assert var_0 == out_run_0, 'Expected: {}, but found: {}'.format(out_run_0, var_0)

# Generated at 2022-06-26 13:48:32.536103
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    set_0 = set()
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(set_0)

if __name__ == '__main__':
    test_case_0()
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:48:33.368553
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP() != None

# Generated at 2022-06-26 13:48:40.173594
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # This will raise exception, because 'title' is missing in the `info`
    set_0 = {'filepath' : 'file.mp4', 'description' : 'description', 'format' : 'format', 'uploader' : 'uploader', 'webpage_url' : 'webpage_url', 'upload_date' : '2016.07.11'}
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(set_0)


if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:48:43.265568
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    set_0 = set()
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(set_0)
    for v_0 in var_0[1]:
        print(v_0)

# Generated at 2022-06-26 13:50:09.221611
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    set_1 = set()
    x_attr_metadata_p_p_1 = XAttrMetadataPP(set_1)

# Generated at 2022-06-26 13:50:13.643248
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    set_0 = { }
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(set_0)

    if var_0:
        var_0 = 0


# Generated at 2022-06-26 13:50:15.132477
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()


# Generated at 2022-06-26 13:50:16.949719
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()


# Generated at 2022-06-26 13:50:19.897939
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    print('==== Method XAttrMetadataPP.run() ====')
    test_case_0()
    test_case_1()

if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:50:25.519593
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    from ..utils import XAttrUnavailableError, XAttrMetadataError

    # Case 1
    set_1 = {
        'filepath': 'foo/bar.mp4',
        'webpage_url': 'foo.bar/baz',
        'title': 'foo',
        'description': 'bar',
        'uploader': 'me',
        'upload_date': 'yesterday',
        'format': 'mp4'
    }
    x_attr_metadata_p_p_1 = XAttrMetadataPP()
    var_1 = x_attr_metadata_p_p_1.run(set_1)
    assert var_1 == ([], set_1)

    # Case 2

# Generated at 2022-06-26 13:50:27.957598
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    set_0 = set()
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(set_0)

# Generated at 2022-06-26 13:50:32.180332
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    set_0 = set()
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    try:
        x_attr_metadata_p_p_0.run(set_0)
    except XAttrUnavailableError as e:
        assert (1==1)

# Generated at 2022-06-26 13:50:34.714033
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    set_0 = set()
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(set_0)

if __name__ == "__main__":
    test_XAttrMetadataPP_run()
    test_case_0()

# Generated at 2022-06-26 13:50:36.939368
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert(not x_attr_metadata_p_p_0.available())
