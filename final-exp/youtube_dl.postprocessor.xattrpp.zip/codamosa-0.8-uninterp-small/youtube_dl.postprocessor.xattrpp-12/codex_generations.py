

# Generated at 2022-06-26 13:44:01.942880
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert callable(XAttrMetadataPP.run)
    return

# Generated at 2022-06-26 13:44:04.166644
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

if __name__ == '__main__':
    test_case_0()
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:44:05.133772
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # TODO: write test
    pass

# Generated at 2022-06-26 13:44:05.923031
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

# Generated at 2022-06-26 13:44:07.227594
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()


# Generated at 2022-06-26 13:44:12.384747
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    info = {
        'filepath': 'filepath',
        'webpage_url': 'webpage_url',
        'title': 'title',
        'upload_date': 'upload_date',
        'description': 'description',
        'uploader': 'uploader',
        'format': 'format'
    }
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    x_attr_metadata_p_p_0.run(info)

if __name__ == '__main__':
    test_case_0()
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:44:13.606281
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert(isinstance(XAttrMetadataPP(), XAttrMetadataPP))


# Generated at 2022-06-26 13:44:15.670059
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert x_attr_metadata_p_p_0

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:44:18.882932
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    with pytest.raises(NotImplementedError):
        XAttrMetadataPP().run(dict())

# Generated at 2022-06-26 13:44:21.201153
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    assert XAttrMetadataPP(None).run({}) == ([], {})


# Generated at 2022-06-26 13:44:31.453454
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    bytes_0 = b'i\x0f\xff(K\xe7\xc8\xf8\xbdNMs\xe6=\xe6\xec'
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(bytes_0)
    assert(var_0 == [])


# Generated at 2022-06-26 13:44:33.887094
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # assert isinstance(XAttrMetadataPP(), PostProcessor)
    pass


# Generated at 2022-06-26 13:44:36.347074
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:44:41.841272
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # Create test inputs
    var_0 = 0
    var_1 = 68
    # Create test output
    var_0 = XAttrMetadataPP()
    var_1 = 'we'
    var_2 = '\x0f\xfd\x80\xfd\x9f'
    var_3 = [var_0, var_1, var_2]


# Generated at 2022-06-26 13:44:43.073132
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
	x_attr_metadata_p_p_0 = XAttrMetadataPP()

# Generated at 2022-06-26 13:44:45.026006
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    a_XAttrMetadataPP_0 = XAttrMetadataPP()
    test_case_0()


# Generated at 2022-06-26 13:44:49.020132
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    try:
        fp = None
        # open file for writing
        fp = open("/tmp/test_XAttrMetadataPP_run.log", "w")

        # write info to log file
        fp.write("##### test_XAttrMetadataPP_run #####\n")

        # run test case 0
        test_case_0()

    except (IOError, OSError):
        print("Error while writing to log file /tmp/test_XAttrMetadataPP_run.log")
    finally:
        # close log file
        if fp is not None:
            fp.close()

# Generated at 2022-06-26 13:44:59.889071
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    with pytest.raises(Exception):
        XAttrMetadataPP(1, 2)


#
# def test_case_1():
#     bytes_0 = b'i\x0f\xff(K\xe7\xc8\xf8\xbdNMs\xe6=\xe6\xec'
#     x_attr_metadata_p_p_0 = XAttrMetadataPP()
#     var_0 = x_attr_metadata_p_p_0.run(bytes_0)
#
#
# def test_case_2():
#     bytes_0 = b'i\x0f\xff(K\xe7\xc8\xf8\xbdNMs\xe6=\xe6\xec'
#     x_attr_metadata_p_p_0 = XAttr

# Generated at 2022-06-26 13:45:07.027438
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    bytes_0 = b'\x93\xfcx\xfe\xed\xdc\xad\xb6\xff\xca\xea\xfe\xfdQ\xd4\xda\xa6\xbb\xa8\xbf\xb4\xa4\xff\xfeP\xaa\xf4'
    bytes_1 = b'p\x8c\xba\xa4i\x9a\x8e\xee\x83\x92\xa1'
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(bytes_1)
    x_attr_metadata_p_p_0.run(bytes_0)
    x_attr_metadata_p_p_

# Generated at 2022-06-26 13:45:08.718309
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
 
    assert test_case_0() == (None, None)

# Generated at 2022-06-26 13:45:19.241401
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()


# Generated at 2022-06-26 13:45:24.606639
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # Parameter 'info'
    bytes_0 = b'\xe0\xfc\xd8\xab\xb7\x1e\x0b\xc8\xff\xf4\xd4\xbf\xee\xab\xbb\xfb'
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(bytes_0)



# Generated at 2022-06-26 13:45:26.782668
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    obj = XAttrMetadataPP()
    assert obj._downloader is None
    assert obj._filename is None
    assert obj._info is None
    assert obj._outtmpl is None

# Generated at 2022-06-26 13:45:30.485282
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    x_attr_metadata_p_p_0 = XAttrMetadataPP()

    try:
        with open('/non/existing/file', 'r') as file_input_0:
            x_attr_metadata_p_p_0.run(file_input_0)
    except FileNotFoundError:
        pass


# Generated at 2022-06-26 13:45:31.505624
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

# SYS_TEST : 

# Generated at 2022-06-26 13:45:32.662977
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()


# Generated at 2022-06-26 13:45:43.338256
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..extractor.common import InfoExtractor
    from ..compat import bytes_input

    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    info_extractor_0 = InfoExtractor()
    info_extractor_0.report_download_page = lambda *args, **kargs: None
    info_extractor_0.extract = lambda *args, **kargs: ({'id': 'id_1'}, {})
    info_extractor_0.suitable = lambda *args, **kargs: True
    info_extractor_0.download = lambda *args, **kargs: (bytes_input, None)
    info_extractor_0.report_warning = lambda *args, **kargs: None

# Generated at 2022-06-26 13:45:52.579488
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    ppmock = PostProcessor()
    ppmock.get_info_dict.return_value = 'test_info_dict'
    ppmock.report_warning.return_value = None
    ppmock.report_error.return_value = None
    ppmock.to_screen.return_value = None

    xmp = XAttrMetadataPP()
    xmp.run(ppmock)

    assert ppmock.get_info_dict.called
    assert ppmock.to_screen.called
    assert ppmock.report_error.called
    assert ppmock.report_warning.called

# Generated at 2022-06-26 13:45:54.539174
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    var_0 = XAttrMetadataPP()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 13:45:57.395588
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    print('Executing constructor test for class XAttrMetadataPP')
    x_attr_metadata_p_p_0 = XAttrMetadataPP()


# Generated at 2022-06-26 13:46:17.881900
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass



# Generated at 2022-06-26 13:46:19.879693
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP(): 
    test_case_0()
    
    
if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:46:21.533992
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert True

if __name__ == '__main__':
	test_XAttrMetadataPP()

# Generated at 2022-06-26 13:46:24.639625
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    print(chr(27) + "[2J")
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    test_case_0()
    print(chr(27) + "[2J")
    print('Tests Done!')

# Generated at 2022-06-26 13:46:25.793358
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()

# Generated at 2022-06-26 13:46:27.097366
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

# Generated at 2022-06-26 13:46:30.365871
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    print('Testing constructor of class XAttrMetadataPP')

    assert(type(XAttrMetadataPP()) is XAttrMetadataPP)


# test_XAttrMetadataPP()
# test_case_0()

# Generated at 2022-06-26 13:46:39.364503
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    var_2 = XAttrMetadataPP()
    bytes_0 = b'd\x92\x1a\x1c\xa9\xb5\xf7\xe5\x1a\xaaI\x0e\x05\xcd\xa8\x86\xd0\x81\x07\x0c\xf1'
    var_0 = var_2.run(bytes_0)

# Generated at 2022-06-26 13:46:47.947022
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert callable(XAttrMetadataPP.run)
    assert hasattr(XAttrMetadataPP, "__call__")
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(bytes(128))
    assert isinstance(var_0, tuple)
    assert len(var_0) == 2
    assert all(isinstance(v, list) for v in var_0)
    assert var_0[0] == []
    assert var_0[1] == bytes(128)

# Generated at 2022-06-26 13:46:49.841178
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()


if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:47:30.677002
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    test_case_0()

# Generated at 2022-06-26 13:47:39.285183
# Unit test for constructor of class XAttrMetadataPP

# Generated at 2022-06-26 13:47:40.067107
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pass



# Generated at 2022-06-26 13:47:44.593380
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
  x_attr_metadata_p_p_0 = XAttrMetadataPP()
  string_0 = '\x0c\x8b!\xbf\x80\x1a\x9c\xbb\xad\xf2\x96\xd2\x8a\xa0z\x02\x99\xa8\x97'
  var_0 = x_attr_metadata_p_p_0.run(string_0)

# Generated at 2022-06-26 13:47:45.468607
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

# Generated at 2022-06-26 13:47:47.890348
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # test case 0
    test_case_0()

# Test case for method run of class XAttrMetadataPP

# Generated at 2022-06-26 13:47:53.166332
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    bytes_0 = b'i\x0f\xff(K\xe7\xc8\xf8\xbdNMs\xe6=\xe6\xec'
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(bytes_0)

# Create an instance of the class to be tested

# Generated at 2022-06-26 13:48:01.960905
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    var_1 = XAttrMetadataPP()
    # assert that the class is an instance of XAttrMetadataPP class
    assert isinstance(var_1, XAttrMetadataPP), "Should be an instance of class XAttrMetadataPP"
    # assert that the class is an instance of PostProcessor class
    assert isinstance(var_1, PostProcessor), "Should be an instance of class PostProcessor"
    # assert that the class is an instance of class object
    assert isinstance(var_1, object), "Should be an instance of class object"
    # assert that the run method exists
    assert callable(getattr(var_1, u"run", None)), u"Should have a run method"

# Generated at 2022-06-26 13:48:03.417185
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()


# Generated at 2022-06-26 13:48:04.246845
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    assert True == False

# Generated at 2022-06-26 13:49:33.025176
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    bytes_0 = b'i\x0f\xff(K\xe7\xc8\xf8\xbdNMs\xe6=\xe6\xec'
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(bytes_0)

# Generated at 2022-06-26 13:49:34.739330
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert isinstance(x_attr_metadata_p_p_0, XAttrMetadataPP)


# Generated at 2022-06-26 13:49:35.771907
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP() is not None


# Generated at 2022-06-26 13:49:36.513981
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()


# Generated at 2022-06-26 13:49:38.469854
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    test_case_0()


# Generated at 2022-06-26 13:49:43.398147
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    bytes_0 = b'i\x0f\xff(K\xe7\xc8\xf8\xbdNMs\xe6=\xe6\xec'
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(bytes_0)

# Generated at 2022-06-26 13:49:49.684105
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    bytes_0 = b'i\x0f\xff(K\xe7\xc8\xf8\xbdNMs\xe6=\xe6\xec'
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_1 = x_attr_metadata_p_p_0.run(bytes_0)

if __name__ == '__main__':
    test_case_0()
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:49:51.129709
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()


# Generated at 2022-06-26 13:49:54.636699
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    xattr_metadata_pp = XAttrMetadataPP()

    assert True # TODO: implement your test here

# TODO: Implement test to check that the file's xattr are being set correctly

# Generated at 2022-06-26 13:49:56.538551
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    filename = "sample"
    xAttrMetadataPP = XAttrMetadataPP()
    xAttrMetadataPP.run(filename)

# Generated at 2022-06-26 13:53:25.155916
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

test_XAttrMetadataPP()

# Generated at 2022-06-26 13:53:25.821358
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    t_case_0 = test_case_0()

# Generated at 2022-06-26 13:53:30.609974
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():

    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    x_attr_metadata_p_p_0.run(b'\x15\x97\x87g\xb9\x01@')


if __name__ == '__main__':
    test_case_0()
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:53:31.270258
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    assert x == y


# Generated at 2022-06-26 13:53:35.489776
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert isinstance(x_attr_metadata_p_p_0, XAttrMetadataPP)
    assert isinstance(x_attr_metadata_p_p_0, PostProcessor)



# Generated at 2022-06-26 13:53:42.490377
# Unit test for method run of class XAttrMetadataPP

# Generated at 2022-06-26 13:53:49.706592
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    assert 0

# def test_case_1():
#     bytes_0 = b'\xae\xfb'
#     x_attr_metadata_p_p_0 = XAttrMetadataPP()
#     var_0 = x_attr_metadata_p_p_0.run(bytes_0)

# # Unit test for method run of class XAttrMetadataPP
# def test_XAttrMetadataPP_run():
#     assert 0

# def test_case_2():
#     bytes_0 = b'\x9a0\xc6\xac\xe8'
#     x_attr_metadata_p_p_0 = XAttrMetadataPP()
#     var_0 = x_attr_metadata_p_p_0.run(bytes_0)

# # Unit test

# Generated at 2022-06-26 13:53:54.130732
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    # Make an instance of XAttrMetadataPP
    bytes_0 = b'i\x0f\xff(K\xe7\xc8\xf8\xbdNMs\xe6=\xe6\xec'
    x_attr_metadata_p_p_0 = XAttrMetadataPP()

    # Call method run of x_attr_metadata_p_p_0 with bytes_0 as argument
    var_0 = x_attr_metadata_p_p_0.run(bytes_0)