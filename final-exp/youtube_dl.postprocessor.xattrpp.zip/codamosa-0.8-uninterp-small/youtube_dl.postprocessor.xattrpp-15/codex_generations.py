

# Generated at 2022-06-26 13:44:06.444950
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    info = {}
    retval = x_attr_metadata_p_p_0.run(info)
    assert isinstance(retval, list)
    assert isinstance(retval[0], list)
    assert isinstance(retval[1], dict)

# Generated at 2022-06-26 13:44:08.709798
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert test_case_0() == None, "Constructor for class XAttrMetadataPP didn't work"

# Test case for method run of class XAttrMetadataPP

# Generated at 2022-06-26 13:44:16.588561
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    result_run_0 = x_attr_metadata_p_p_0.run({})
    return result_run_0

if __name__ == '__main__':
    test_case_0()
    test_XAttrMetadataPP_run()
"""

"""

# Generated at 2022-06-26 13:44:18.937325
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_1 = XAttrMetadataPP(
        downloader=downloader_0)


# Generated at 2022-06-26 13:44:19.826097
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    assert True == False

# Generated at 2022-06-26 13:44:24.107452
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
   # Test for constructor of class XAttrMetadataPP
   x_attr_metadata_p_p_0 = XAttrMetadataPP()


# Generated at 2022-06-26 13:44:33.177431
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_1 = XAttrMetadataPP()
    info = { }
    assert x_attr_metadata_p_p_1.run(info) == ([], info)
    info = { 'description': 'description' }
    assert x_attr_metadata_p_p_1.run(info) == ([], info)
    info = { 'title': 'title' }
    assert x_attr_metadata_p_p_1.run(info) == ([], info)
    info = { 'thumbnail': 'thumbnail', 'title': 'title' }
    assert x_attr_metadata_p_p_1.run(info) == ([], info)
    info = { 'thumbnail': 'thumbnail', 'title': 'title', 'webpage_url': 'webpage_url' }


# Generated at 2022-06-26 13:44:42.262964
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # filename = '5j2QYH3qZHE'
    # info = {'filepath': '/Users/vince/Downloads/5j2QYH3qZHE.mp4', 'upload_date': '20130826', 'description': 'aa', 'title': 'bbb', 'format': 'mp4', 'webpage_url': 'ccc', 'extractor_key': 'Youtube', 'uploader': 'ddd'}
    # x_attr_metadata_p_p_0 = XAttrMetadataPP()
    # x_attr_metadata_p_p_0.run(info)
    # assert True
    pass

# Generated at 2022-06-26 13:44:44.555917
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()

    # Verifies method run for class XAttrMetadataPP
    assert True

# Generated at 2022-06-26 13:44:47.962899
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # 1. Test for case: Successful execution
    x_attr_metadata_p_p_0 = XAttrMetadataPP()

    # x_attr_metadata_p_p_0.run()
    # 2. Test for case: Unsuccessful execution
    x_attr_metadata_p_p_1 = XAttrMetadataPP()

    # x_attr_metadata_p_p_1.run()
    try:
        assert False
    except:
        pass


# Generated at 2022-06-26 13:44:54.885533
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    filename = 'crash.txt'
    xattrname = 'user.xdg.referrer.url'
    infoname = 'webpage_url'
    value = 'https://www.youtube.com/watch?v=gCYcHz2k5x0'
    byte_value = value.encode('utf-8')
    write_xattr(filename, xattrname, byte_value)

# Generated at 2022-06-26 13:44:56.596706
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()


# Generated at 2022-06-26 13:44:57.677300
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()

# Generated at 2022-06-26 13:45:03.702230
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    xml_doc_0 = xml.dom.minidom.parseString('<a/>')
    url_0 = urlparse('http://foo.com/bar')
    json_0 = json.loads('{"foo": "bar"}')
    x_attr_metadata_p_p_0.run(xml_doc_0)
    x_attr_metadata_p_p_0.run(url_0)
    x_attr_metadata_p_p_0.run(json_0)

# Generated at 2022-06-26 13:45:07.515288
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    # Constructor test
    x_attr_metadata_p_p_0 = XAttrMetadataPP()

    # Variable test
    var_0 = x_attr_metadata_p_p_0.run(None) # None is passed as argument to the method
    print(var_0)

# Generated at 2022-06-26 13:45:10.900383
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    bool_0 = False
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(bool_0)


# Generated at 2022-06-26 13:45:11.718590
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    assert test_case_0()


# Generated at 2022-06-26 13:45:13.451390
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert True


# Generated at 2022-06-26 13:45:16.439709
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # Test case 0
    # test run
    test_case_0()


if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:45:20.323193
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # set up context
    x_attr_metadata_p_p = XAttrMetadataPP()
    # TODO: investigate why test fails (is it a bug in test or the code)
    # test the code
    # x_attr_metadata_p_p.run()

# Generated at 2022-06-26 13:45:40.183493
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    bool_0 = True
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    bool_1 = bool_0
    x_attr_metadata_p_p_0.run(bool_1)
    str_0 = ">[metadata] Writing metadata to file's xattrs"
    var_0 = x_attr_metadata_p_p_0._downloader.to_screen(str_0)
    str_1 = "You may have to enable them in your /etc/fstab)"
    var_1 = x_attr_metadata_p_p_0._downloader.report_error(str_1)
    return var_0, var_1

# Generated at 2022-06-26 13:45:41.533591
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # TODO: add more tests
    test_case_0()

# Generated at 2022-06-26 13:45:48.493417
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    bool_0 = False
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    info_0 = {}
    var_0 = x_attr_metadata_p_p_0.run(info_0)
    assert type(var_0) is list
    assert len(var_0) == 2
    

if __name__ == '__main__':
    test_XAttrMetadataPP_run()
    test_case_0()

# Generated at 2022-06-26 13:45:51.031239
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    test_case_0()



# Generated at 2022-06-26 13:46:00.786536
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # File path should have a length greater than 0
    filename = 'test_file'
    assert len(filename) > 0

    xattr_mapping = {
        'user.xdg.referrer.url': 'webpage_url',
        'user.dublincore.title': 'title',
        'user.dublincore.date': 'upload_date',
        'user.dublincore.description': 'description',
        'user.dublincore.contributor': 'uploader',
        'user.dublincore.format': 'format',
    }

    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    num_written = 0

# Generated at 2022-06-26 13:46:03.828698
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    bool_0 = False
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(bool_0)



# Generated at 2022-06-26 13:46:07.197353
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    test_case_0()


if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:46:11.081327
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # default value test
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0



# Generated at 2022-06-26 13:46:15.500766
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    var_0 = XAttrMetadataPP()
    var_1 = None
    try:
        var_0.run(var_1)
    except XAttrMetadataError:
        var_0.run(var_1)
    except XAttrUnavailableError:
        var_0.run(var_1)

# Generated at 2022-06-26 13:46:17.398480
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    print("Testing constructor of XAttrMetadataPP...")
    test_case_0()
    print("Done testing constructor of XAttrMetadataPP")

# Generated at 2022-06-26 13:46:39.709855
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    arg_0 = None
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    x_attr_metadata_p_p_0.run(arg_0)

# Generated at 2022-06-26 13:46:42.827490
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from .common import PostProcessor
    from .xattrpp import XAttrMetadataPP
    obj = PostProcessor(None, {})
    test_case_0()

# Generated at 2022-06-26 13:46:52.231553
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pp = XAttrMetadataPP()
    info = {
        'webpage_url': 'https://youtube.com/watch?v=bARQQmHzTmQ',
        'title': 'Rammstein - Deutschland (Official Video)',
        'description': 'Official music video by Rammstein performing Deutschland. ▻ Website: http://www.rammstein.com ▻ Shop: http://shop.rammstein.de Premiere: March 28th, 2019 Director: Specter Berlin Production: Mmaattcchh Berlin _ More information on http://www.rammstein.de Video herunterladen',
        'upload_date': '20190328',
        'uploader': 'Rammstein Official',
        'format': 'mp4',
    }
    pp.run(info)

test_case_0()


# Generated at 2022-06-26 13:46:57.261001
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    bool_0 = True
    x_attr_metadata_p_p_0 = XAttrMetadataPP()

    try:
        var_0 = x_attr_metadata_p_p_0.run(bool_0)
    except XAttrUnavailableError as error_0:
        int_0 = error_0.errno
        str_0 = error_0.strerror
        int_0 = error_0.errno
        str_0 = error_0.strerror
        str_0 = error_0.strerror


# Generated at 2022-06-26 13:47:00.097946
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    bool_0 = False
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    x_attr_metadata_p_p_0.run(bool_0)


# Generated at 2022-06-26 13:47:00.872006
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()

# Generated at 2022-06-26 13:47:05.741510
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    bool_0 = True
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(bool_0)
    __expect_exception0 = "AssertionError"
    __expect_exception1 = "AssertionError"
    __expect_exception2 = "AssertionError"
    __expect_exception3 = "AssertionError"
    __expect_exception4 = "AssertionError"
    __expect_exception5 = "AssertionError"
    __expect_exception6 = "AttributeError"
    __expect_exception7 = "AssertionError"
    __expect_exception8 = "AttributeError"
    __expect_exception

# Generated at 2022-06-26 13:47:07.566073
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # TODO: create object XAttrMetadataPP and later call method run
    assert(True)


test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:47:09.310245
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()

# Generated at 2022-06-26 13:47:10.155068
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()

# Generated at 2022-06-26 13:47:51.889997
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    var_0 = False
    var_1 = XAttrMetadataPP()
    var_2 = var_1.run(var_0)
    test_case_0()


# Generated at 2022-06-26 13:47:53.610163
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    res0 = None
    assert res0 is None


# Generated at 2022-06-26 13:47:56.026467
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    return x_attr_metadata_p_p_0


# Generated at 2022-06-26 13:47:57.302692
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()


# Generated at 2022-06-26 13:48:02.828326
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    bool_0 = False
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(bool_0)
    assert False
    assert False
    assert False
    assert False
    x_attr_metadata_p_p_0.run(bool_0)
    assert False
    assert False

test_case_0()
test_XAttrMetadataPP()

# Generated at 2022-06-26 13:48:04.740002
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    print('In test_XAttrMetadataPP constructor')
    test_case_0()

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:48:05.751450
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()

# Generated at 2022-06-26 13:48:10.536872
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    bool_0 = False
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    x_attr_metadata_p_p_0.run(bool_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 13:48:13.537188
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    bool_0 = False
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(bool_0)

# Generated at 2022-06-26 13:48:15.283132
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()


# Generated at 2022-06-26 13:49:36.765507
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

# Generated at 2022-06-26 13:49:46.237249
# Unit test for method run of class XAttrMetadataPP

# Generated at 2022-06-26 13:49:48.031656
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    bool_0 = False
    x_attr_metadata_p_p_0 = XAttrMetadataPP()


# Generated at 2022-06-26 13:49:49.569306
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert True

# Generated at 2022-06-26 13:49:50.084122
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    assert True

# Generated at 2022-06-26 13:49:52.441078
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():

    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0 != None, 'Error: Object is NULL'


# Generated at 2022-06-26 13:49:54.638515
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()

# Generated at 2022-06-26 13:49:56.208356
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()

# Generated at 2022-06-26 13:49:58.478344
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0.run

# Generated at 2022-06-26 13:50:01.138363
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()

if __name__ == '__main__':
    # Unit tests
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:53:31.098842
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()


# Generated at 2022-06-26 13:53:31.807767
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()

# Generated at 2022-06-26 13:53:32.890987
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    assert True # TODO: implement your test here


# Generated at 2022-06-26 13:53:37.763636
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # Arrange
    # Create XAttrMetadataPP obj
    x_attr_metadata_p_p_0 = XAttrMetadataPP()

    # Act
    # Call the method run on x_attr_metadata_p_p_0
    x_attr_metadata_p_p_0.run()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 13:53:38.986619
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

test_XAttrMetadataPP()

# Generated at 2022-06-26 13:53:40.558945
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()


# Generated at 2022-06-26 13:53:42.124104
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_pp_0 = XAttrMetadataPP()
    x_attr_metadata_pp_0 = XAttrMetadataPP()


# Generated at 2022-06-26 13:53:43.776240
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    bool_0 = False
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(bool_0)


# Generated at 2022-06-26 13:53:45.204509
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    x_attr_metadata_p_p_0.run()

# Generated at 2022-06-26 13:53:46.041734
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pass # TODO: construct test