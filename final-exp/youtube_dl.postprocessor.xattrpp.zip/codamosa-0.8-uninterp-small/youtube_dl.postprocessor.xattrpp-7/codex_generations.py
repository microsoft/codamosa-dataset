

# Generated at 2022-06-26 13:44:02.344280
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()

# Generated at 2022-06-26 13:44:09.395873
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    bytes_0 = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    assert x_attr_metadata_p_p_0.run({'webpage_url': bytes_0})[1]['webpage_url'] == 'http://www.youtube.com/watch?v=BaW_jenozKc'


# Generated at 2022-06-26 13:44:13.060546
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # Test case 0: pass
    test_case_0()

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:44:22.233218
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    filename = ['C://adp/youtube_dl/README.txt']

# Generated at 2022-06-26 13:44:25.165191
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    assert len(test_case_0.x_attr_metadata_p_p_0.run({})) == 0

# Generated at 2022-06-26 13:44:26.742656
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    assert False


# Generated at 2022-06-26 13:44:32.489585
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()

    info_0 = {'upload_date': '20170217', 'format': 'webm', 'webpage_url': 'https://www.youtube.com/watch?v=eBGIQ7ZuuiU', 'title': 'Obama: Farewell Address', 'uploader': 'The Daily Conversation', 'description': 'Obama: Farewell Address. 1/10/2017.'}
    x_attr_metadata_p_p_0.run(info_0)


# Generated at 2022-06-26 13:44:33.508822
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

#

# Generated at 2022-06-26 13:44:38.705194
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    # TODO: Add test
    assert False

if __name__ == '__main__':
    test_case_0()
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:44:47.472677
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    # Fill in the test data
    info_given = {
        'format': 'm4a',
        'webpage_url': 'https://youtu.be/tntOCGkgt98',
        'title': 'title',
        'description': 'description',
        'upload_date': '20190220',
        'uploader': 'uploader',
        'filepath': 'filepath',
    }

    # Fill in the expected output
    ret_expected = ([], {
        'format': 'm4a',
        'webpage_url': 'https://youtu.be/tntOCGkgt98',
        'title': 'title',
        'description': 'description',
        'upload_date': '20190220',
        'uploader': 'uploader',
        'filepath': 'filepath',
    })

# Generated at 2022-06-26 13:44:54.599841
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    assert False # TODO: implement your test here


# Generated at 2022-06-26 13:44:55.593570
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

# Generated at 2022-06-26 13:44:56.554421
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

# Generated at 2022-06-26 13:44:58.370444
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

if __name__ == "__main__":
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:44:59.970645
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()


# Generated at 2022-06-26 13:45:02.398892
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    bool_0 = False
    var_0 = x_attr_metadata_p_p_0.run(bool_0)

# Generated at 2022-06-26 13:45:06.520671
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    x_attr_metadata_p_p_0.run('/Users/lab/Library/Caches/Youtube-dl/384875/3/yt-1080p.mp4')


# Generated at 2022-06-26 13:45:09.034444
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    test_case_0()


if __name__ == '__main__':

    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:45:11.636528
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    bool_0 = False
    var_0 = x_attr_metadata_p_p_0.run(bool_0)

# Generated at 2022-06-26 13:45:13.662439
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

# Main of the unit test
if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:45:25.086475
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # Test constructor
    assert XAttrMetadataPP is not None

# Generated at 2022-06-26 13:45:28.904360
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():

    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    if (x_attr_metadata_p_p_0.dump_intermediate_pages != False):
        return 0

    if (x_attr_metadata_p_p_0.match_filter != None):
        return 0

    if (x_attr_metadata_p_p_0.merge_output_format != None):
        return 0


# Generated at 2022-06-26 13:45:33.892534
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
   x_attr_metadata_p_p_0 = XAttrMetadataPP()
   bool_0 = False
   var_0 = x_attr_metadata_p_p_0.run(bool_0)
   if (not (var_0 is None)):
      raise AssertionError('XAttrMetadataPP: run did not return None')

# Generated at 2022-06-26 13:45:37.051140
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    bool_0 = False
    x_attr_metadata_p_p_0.run(bool_0)


# Generated at 2022-06-26 13:45:39.571380
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0.run == XAttrMetadataPP.run

# Generated at 2022-06-26 13:45:42.778308
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    bool_0 = False
    var_0 = x_attr_metadata_p_p_0.run(bool_0)
    print(var_0)
    print(x_attr_metadata_p_p_0)

if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:45:54.500681
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    str_0 = 'webpage_url'
    dict_0 = dict()
    dict_0['upload_date'] = str_0
    dict_0['id'] = 'id'
    dict_2 = dict()
    dict_2['format'] = str_0
    dict_2['description'] = 'description'
    dict_2['title'] = 'title'
    dict_2['uploader'] = 'uploader'
    dict_2['webpage_url'] = 'webpage_url'
    dict_0['info_dict'] = dict_2
    dict_0['url'] = 'url'
    dict_0['ext'] = 'ext'
    dict_0['fulltitle'] = 'fulltitle'
    dict_0

# Generated at 2022-06-26 13:45:58.659335
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    bool_0 = False
    var_0 = x_attr_metadata_p_p_0.run(bool_0)


if __name__ == "__main__":
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:46:00.619321
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0 is not None


# Generated at 2022-06-26 13:46:01.376012
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

# Generated at 2022-06-26 13:46:24.809575
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    int_0 = x_attr_metadata_p_p_0.run(None)

if __name__ == "__main__":
    test_case_0()
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:46:27.710524
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # Initializing objects
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    bool_0 = False
    # Testing function call
    test_case_0()

if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:46:28.781605
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()

# Generated at 2022-06-26 13:46:31.507217
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run('test')


# Generated at 2022-06-26 13:46:36.517711
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert type(x_attr_metadata_p_p_0) == XAttrMetadataPP, "constructor of class XAttrMetadataPP failed"


if __name__ == '__main__':
    test_XAttrMetadataPP()
    test_case_0()

# Generated at 2022-06-26 13:46:39.364760
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_3 = XAttrMetadataPP()
    x_attr_metadata_p_p_3.run(True)

if __name__ == '__main__':
    test_case_0()
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:46:40.569303
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass


# Generated at 2022-06-26 13:46:47.071687
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    info_0 = None
    assert x_attr_metadata_p_p_0.run(info_0)[0] == [], 'assert_equal failed at index 0'
    assert x_attr_metadata_p_p_0.run(info_0)[1] == None, 'assert_equal failed at index 1'

# vim: ts=4 sw=4 et

# Generated at 2022-06-26 13:46:49.999752
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    bool_0 = False
    var_0 = x_attr_metadata_p_p_0.run(bool_0)
    return var_0

# Generated at 2022-06-26 13:46:52.191357
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # Test cases of class XAttrMetadataPP
    test_case_0()

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:47:39.137088
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # Test if constructor is not None
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0 is not None

    # Test if constructor is XAttrMetadataPP
    assert isinstance(x_attr_metadata_p_p_0, XAttrMetadataPP)

    # Test exception of no xattrs
    # Using XAttrMetadataPP.run
    # x_attr_metadata_p_p_0.run(bool_0)
    # Test expected exception message of run

    # Test if constructor is PostProcessor
    assert issubclass(XAttrMetadataPP, PostProcessor)



# Generated at 2022-06-26 13:47:42.382906
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    bool_0 = True
    var_0 = x_attr_metadata_p_p_0.run(bool_0)
    var_1 = x_attr_metadata_p_p_0.run(bool_0)

if __name__ == '__main__':
    test_case_0()
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:47:43.232744
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()


# Generated at 2022-06-26 13:47:43.770889
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass


# Generated at 2022-06-26 13:47:46.484721
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0.run(False) == [], False

# Generated at 2022-06-26 13:47:51.578686
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # Set up mock object
    mock_downloader = Mock()
    x_attr_metadata_p_p = XAttrMetadataPP(mock_downloader)

    # Call the tested method
    x_attr_metadata_p_p.run('info')

    # Asserts
    m_to_screen.assert_called_with('[metadata] Writing metadata to file\'s xattrs')

# Generated at 2022-06-26 13:47:54.965508
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p = XAttrMetadataPP()
    assert x_attr_metadata_p_p is not None


if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:47:59.137178
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    bool_0 = True
    var_0 = x_attr_metadata_p_p_0.run(bool_0)
    assert str(var_0) == "([], True)"

# Generated at 2022-06-26 13:48:00.749455
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

if __name__== "__main__":
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:48:01.989052
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    print()
    assert True


test_XAttrMetadataPP()

# Generated at 2022-06-26 13:49:34.578277
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    bool_0 = False
    dict_0 = {
        'uploader': 'uploader',
        'upload_date': 'upload_date',
        'thumbnail': 'thumbnail',
        'creator': 'creator',
        'format': 'format',
        'webpage_url': 'webpage_url',
        'duration': 'duration',
        'title': 'title',
        'filepath': 'video.webm',
        'age_limit': 0,
        'resolution': 'resolution',
        'id': 'id',
        'ext': 'webm',
        'description': 'description',
    }
    tuple_0 = ((), dict_0)

# Generated at 2022-06-26 13:49:35.338541
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    var_0 = XAttrMetadataPP()

# Generated at 2022-06-26 13:49:40.083154
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    # String representation of the class
    assert str(x_attr_metadata_p_p_0) == '<XAttrMetadataPP>'
    # Check if the object is of type XAttrMetadataPP
    assert isinstance(x_attr_metadata_p_p_0, XAttrMetadataPP)


# Generated at 2022-06-26 13:49:48.021353
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p = XAttrMetadataPP()
    filepath = "filepath"
    info = {"filepath" : filepath}
    write_xattr_backup = XAttrMetadataPP.write_xattr
    XAttrMetadataPP.write_xattr = lambda _self,_filename,_xattrname,_byte_value: _filename
    ret_0 = XAttrMetadataPP.run(x_attr_metadata_p_p, info)
    assert ret_0 == [], "Return value from 'run' method is not []. Actual return value is {}".format(ret_0)
    var_0 = info

# Generated at 2022-06-26 13:49:56.744562
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    info = {
        'webpage_url': 'webpage_url',
        'title': 'title',
        'upload_date': 'upload_date',
        'description': 'description',
        'uploader': 'uploader',
        'format': 'format',
        'filepath': 'filepath',
    }
    bool_0 = False
    var_0 = x_attr_metadata_p_p_0.run(info)
    assert var_0 == ([], info)

test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:49:58.011965
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()


# Generated at 2022-06-26 13:50:01.003157
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # Testcase 0
    test_case_0()

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:50:02.694247
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()


test_XAttrMetadataPP()

# Generated at 2022-06-26 13:50:07.808977
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    bool_0 = False
    var_0 = x_attr_metadata_p_p_0.run(bool_0)
    var_1 = x_attr_metadata_p_p_0.run(bool_0)
    var_2 = x_attr_metadata_p_p_0.run(bool_0)
    return var_0, var_1, var_2


# Generated at 2022-06-26 13:50:11.239035
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # No exception thrown
    try:
        test_case_0()
    except Exception as e:
        print('Exception thrown: ' + type(e).__name__ + ': ' + str(e))
        assert False

if __name__ == "__main__":
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:53:59.633701
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # Write the metadata to the file's xattrs
    # _downloader.to_screen('[metadata] Writing metadata to file\'s xattrs')

    filename = info['filepath']
