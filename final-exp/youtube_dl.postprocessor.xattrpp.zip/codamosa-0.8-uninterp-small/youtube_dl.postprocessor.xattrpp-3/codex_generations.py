

# Generated at 2022-06-26 13:44:01.318365
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()

# end class XAttrMetadataPP



# Generated at 2022-06-26 13:44:10.538359
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p = XAttrMetadataPP()
    info = {
        'webpage_url': 'https://www.youtube.com/watch?v=w3jLJU7DT5E',
        'title': 'title xattr',
        'webpage_url': 'https://www.youtube.com/watch?v=w3jLJU7DT5E',
        'description': 'description xattr',
        'upload_date': '20170101',
        'uploader': 'uploader xattr',
        'format': 'format xattr'
    }

    x_attr_metadata_p_p.run(info)

# Generated at 2022-06-26 13:44:14.652305
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0 is not None


# Generated at 2022-06-26 13:44:18.717902
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    print("Test: XAttrMetadataPP")
    test_case_0()
    print("Test: XAttrMetadataPP - Success")
if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:44:22.433072
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    x_attr_metadata_p_p_0.run()

# Generated at 2022-06-26 13:44:30.761030
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    x_attr_metadata_p_p_0.run({'_filename': '', 'filepath': '', 'format': '', 'uploader': '', 'webpage_url': '', 'upload_date': '', 'title': '', 'description': '', 'ext': ''})

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:44:39.127397
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    info = {'filepath': 'test filepath', 'webpage_url': 'test webpage_url', 'title': 'test title', 'upload_date': 'test upload_date', 'description': 'test description', 'uploader': 'test uploader', 'format': 'test format'}
    x_attr_metadata_p_p_0.run(info)


# Generated at 2022-06-26 13:44:42.431928
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    x_attr_metadata_p_p_0.run('{"filepath": "abc", "format": "abc"}')

test_case_0()
test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:44:44.724253
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0.run(info={}) == ([],{})

# Generated at 2022-06-26 13:44:46.605985
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    x_attr_metadata_p_p_0.run()

# Generated at 2022-06-26 13:45:04.860315
# Unit test for method run of class XAttrMetadataPP

# Generated at 2022-06-26 13:45:09.654865
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    try:
        test_case_0()
    except:
        try:
            '   When using other function, test case 0 should be passed!   '
        finally:
            import traceback
            traceback.print_exc()
    print('Test done!')

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:45:17.281349
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    # assert_raises
    with pytest.raises(XAttrMetadataError) as e_1:
        x_attr_metadata_p_p_0.run(None)
    assert str(e_1.value) == 'NO_SPACE'
    # assert_raises
    with pytest.raises(XAttrUnavailableError) as e_2:
        x_attr_metadata_p_p_0.run(None)
    assert str(e_2.value) == 'NO_SPACE'

# Generated at 2022-06-26 13:45:19.226107
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # This test is from test/test_postprocessor.py
    # I will ignore it for now
    pass

# Generated at 2022-06-26 13:45:27.439922
# Unit test for method run of class XAttrMetadataPP

# Generated at 2022-06-26 13:45:30.290677
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_1 = XAttrMetadataPP()
    x_attr_metadata_p_p_1.run({})

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:45:31.357917
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p = XAttrMetadataPP()

# Generated at 2022-06-26 13:45:38.812932
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    filename = "filename"
    info = {
        'filepath': filename,
        'title': "title",
        'webpage_url': "webpage_url",
        'description': "description",
        'upload_date': "upload_date",
        'uploader': "uploader",
        'format': "format"
    }
    x_attr_metadata_p_p = XAttrMetadataPP()
    x_attr_metadata_p_p.run(info)

# Generated at 2022-06-26 13:45:42.308176
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import xattr
    import tempfile
    import os

    class ArgsMock(object):
        def __init__(self, format):
            self.format = format


# Generated at 2022-06-26 13:45:44.172078
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_1 = XAttrMetadataPP()


# Generated at 2022-06-26 13:45:57.224562
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert isinstance(x_attr_metadata_p_p_0, XAttrMetadataPP)


# Generated at 2022-06-26 13:45:59.060693
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    set_0 = set()
    x_attr_metadata_p_p_0 = XAttrMetadataPP(set_0)

# Generated at 2022-06-26 13:45:59.712181
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()


# Generated at 2022-06-26 13:46:00.786485
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

# Generated at 2022-06-26 13:46:01.851382
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()


# Test for the class XAttrMetadataPP

# Generated at 2022-06-26 13:46:03.711249
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()


# Generated at 2022-06-26 13:46:09.091391
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    int_0 = -343
    x_attr_metadata_p_p_1 = XAttrMetadataPP()
    set_0 = {int_0}
    x_attr_metadata_p_p_2 = XAttrMetadataPP(set_0)


# Generated at 2022-06-26 13:46:11.244965
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # TODO: add test cases
    assert True


# Generated at 2022-06-26 13:46:20.592704
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

#
# This module was developed as a part of a software solution for this problem:
#
# Problem:
# Download videos from youtube and set its metadata
#
# Solution:
# Download youtube-dl (https://rg3.github.io/youtube-dl/)
#
# Requirements:
# For id3v2 to run, you need to install either
#    - Mutagen (http://code.google.com/p/mutagen/)
# or - eyeD3 (http://eyed3.nicfit.net/)
#
# Put this file and youtube-dl.py in the same directory.
# Usage: python youtube-dl.py --postprocessor-args "-a path/to/this/file" http://www.youtube.com/watch?v=XXXXXXXXXXX
#
#
#
#
# Ugly solution

# Generated at 2022-06-26 13:46:21.839848
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    assert True == True # TODO: implement your test here



# Generated at 2022-06-26 13:46:42.826728
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

# Python 2.6 - 2.7: unittest module
import unittest

# Generated at 2022-06-26 13:46:46.444569
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    x_attr_metadata_p_p_0.run()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 13:46:50.768120
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # Should not get here with compatibility mode
    try:
        x_attr_metadata_p_p_0 = XAttrMetadataPP()
        assert False
    except AssertionError:
        expected = 'Unhandled exception'
        actual = 'Unhandled exception'
        assert expected == actual

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:46:51.624356
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

# Generated at 2022-06-26 13:46:52.159855
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()


# Generated at 2022-06-26 13:46:57.462381
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    var_0 = -343
    x = XAttrMetadataPP(var_0)
    try:
        var_1 = 'the date of this'
        x._downloader.todate(var_1)
    except Exception as inst:
        print(inst.args)


if __name__ == '__main__':
    test_XAttrMetadataPP_run()
    test_case_0()

# Generated at 2022-06-26 13:47:07.081035
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#


# Generated at 2022-06-26 13:47:09.558794
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    assert None

if __name__ == "__main__":
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:47:12.016208
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()
    # print('Expected Output: ([], {})\nActual Output:', test_case_0())
    # assert test_case_0() == ([], {})

# Generated at 2022-06-26 13:47:12.631504
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()

# Generated at 2022-06-26 13:47:58.809070
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    int_0 = 367
    x_attr_metadata_p_p_1 = XAttrMetadataPP()
    set_0 = {int_0}
    x_attr_metadata_p_p_2 = XAttrMetadataPP(set_0)
    assert x_attr_metadata_p_p_2.isSuitable(x_attr_metadata_p_p_0) == False


# Generated at 2022-06-26 13:48:01.785579
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

if __name__ == '__main__':
    import sys
    import py_compile
    py_compile.compile(sys.argv[0])
    sys.exit(0)

# Generated at 2022-06-26 13:48:07.436896
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # Test non-trivial input
    int_0 = -343
    x_attr_metadata_p_p_0 = XAttrMetadataPP(int_0)
    set_0 = {int_0}
    x_attr_metadata_p_p_1 = XAttrMetadataPP(set_0)
    # Test singleton input
    int_1 = 343
    x_attr_metadata_p_p_2 = XAttrMetadataPP(int_1)
    x_attr_metadata_p_p_3 = XAttrMetadataPP(int_1)
    # Test identity input
    x_attr_metadata_p_p_4 = XAttrMetadataPP(x_attr_metadata_p_p_0)
    # Test array-input pairs

# Generated at 2022-06-26 13:48:18.794546
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():

    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0 != None

    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0 == None

    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0 == False

    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0 == False

    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0 == True


# Generated at 2022-06-26 13:48:26.695198
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # Test case 1
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    x_attr_metadata_p_p_0._downloader = argparse.ArgumentParser()
    # Test case 2
    set_0 = set()
    x_attr_metadata_p_p_1 = XAttrMetadataPP(set_0)
    x_attr_metadata_p_p_1._downloader = argparse.ArgumentParser()
    # Test case 3
    x_attr_metadata_p_p_2 = XAttrMetadataPP()
    x_attr_metadata_p_p_2._downloader = argparse.ArgumentParser()
    # Test case 4
    set_0 = set()

# Generated at 2022-06-26 13:48:34.333270
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_3 = XAttrMetadataPP({'user.xdg.comment', 'user.dublincore.creator', 'user.dublincore.description', 'user.dublincore.publisher', 'user.dublincore.rights', 'user.dublincore.format', 'user.xdg.referrer.url'})
    map_0 = {}
    x_attr_metadata_p_p_3.run(map_0)

test_case_0()
test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:48:40.173494
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0.postprocessors == set()

    int_0 = -343
    x_attr_metadata_p_p_1 = XAttrMetadataPP()
    set_0 = {int_0}
    x_attr_metadata_p_p_2 = XAttrMetadataPP(set_0)
    assert x_attr_metadata_p_p_2.postprocessors == {int_0}

# Generated at 2022-06-26 13:48:40.968264
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

# Generated at 2022-06-26 13:48:42.326017
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    assert 'path' == 'path'

# Final test for class XAttrMetadataPP

# Generated at 2022-06-26 13:48:43.639117
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()
    # AssertionError: ValueError: dict contains fields not in fields

# Generated at 2022-06-26 13:50:07.088224
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    var_0 = XAttrMetadataPP()


# Generated at 2022-06-26 13:50:13.338635
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    int_0 = -343
    x_attr_metadata_p_p_1 = XAttrMetadataPP()
    set_0 = {int_0}
    x_attr_metadata_p_p_2 = XAttrMetadataPP(set_0)
    int_1 = -9
    set_1 = {int_1}
    x_attr_metadata_p_p_3 = XAttrMetadataPP(set_1)
    int_2 = -576
    set_2 = {int_2}
    x_attr_metadata_p_p_4 = XAttrMetadataPP(set_2)
    str_0 = 'SPaRK'
    str_1 = 'Literal'
    str

# Generated at 2022-06-26 13:50:18.911067
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    set_0 = set()
    x_attr_metadata_p_p_0 = XAttrMetadataPP(set_0)
    set_0 = set()
    x_attr_metadata_p_p_1 = XAttrMetadataPP(set_0)
    assert type(x_attr_metadata_p_p_0) == type(x_attr_metadata_p_p_1)
    assert len(x_attr_metadata_p_p_0.__dict__) == len(x_attr_metadata_p_p_1.__dict__)


# Generated at 2022-06-26 13:50:26.044291
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()

# Generated at 2022-06-26 13:50:27.161694
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    var_0 = test_case_0()
    return var_0


# Generated at 2022-06-26 13:50:34.185151
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    int_0 = -343
    x_attr_metadata_p_p_1 = XAttrMetadataPP()
    set_0 = {int_0}
    x_attr_metadata_p_p_2 = XAttrMetadataPP(set_0)
    assert x_attr_metadata_p_p_1.run(x_attr_metadata_p_p_0) == x_attr_metadata_p_p_2.run(x_attr_metadata_p_p_0)


# Generated at 2022-06-26 13:50:35.471351
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    XAttrMetadataPP()
    XAttrMetadataPP({})


# Generated at 2022-06-26 13:50:37.627062
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()

if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:50:42.573214
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    str_0 = 'XAttrMetadataPP'
    str_1 = 'ytdl'
    str_2 = str_0 + '.' + str_1
    str_3 = str_2 + '.' + str_1
    var_0 = x_attr_metadata_p_p_0.run(str_3)


# Generated at 2022-06-26 13:50:46.796400
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    var_0 = XAttrMetadataPP()
    if assert_equal(var_0.targets, set(['default'])):
        test_case_0()
    

if __name__ == '__main__':
    test_XAttrMetadataPP()