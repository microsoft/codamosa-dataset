

# Generated at 2022-06-26 13:44:08.062755
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()


import unittest

test_suite_0 = unittest.TestLoader().loadTestsFromTestCase(XAttrMetadataPP)

test_suite_1 = unittest.TestLoader().loadTestsFromTestCase(test_XAttrMetadataPP)

test_suite = unittest.TestSuite([test_suite_0, test_suite_1])

# Generated at 2022-06-26 13:44:09.698674
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:44:12.725836
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_1 = XAttrMetadataPP()


# Generated at 2022-06-26 13:44:15.112931
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p = XAttrMetadataPP()


# Generated at 2022-06-26 13:44:22.007697
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    from ..YoutubeDL import YoutubeDL
    from ..YoutubeDL import YoutubeDL
    from ..YoutubeDL import YoutubeDL

    ydl_1 = YoutubeDL()
    ydl_1.params = {}
    ydl_1.add_info_extractor(test_case_0)
    ydl_1.add_post_processor(test_case_0)
    ydl_1.params['outtmpl'] = '%(epoch)s.%(ext)s'
    test_case_0.run(ydl_1.extract_info(test_case_0, download=False))



# Generated at 2022-06-26 13:44:24.937843
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    info = {}
    inst = XAttrMetadataPP()
    inst.run(info)

# Generated at 2022-06-26 13:44:26.232731
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-26 13:44:27.158672
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP()


# Generated at 2022-06-26 13:44:36.367251
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..YoutubeDL import YoutubeDL
    from ..YoutubeDL import YoutubeDLProcessor

    class FakeYoutubeDL(YoutubeDL):

        def __init__(self, options=None):
            self.params = {}
            if options and options.get('outtmpl'):
                self.params['outtmpl'] = options['outtmpl']
            self.params['writedescription'] = True
            self.params['writeinfojson'] = True
            self.params['writethumbnail'] = True
            self.params['writesubtitles'] = True
            self.params['writeautomaticsub'] = True
            self.params['write_all_thumbnails'] = False
            self.params['ignoreerrors'] = False
            self.params['forceduration'] = False
            self.params['nooverwrites'] = False


# Generated at 2022-06-26 13:44:39.126939
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    x_attr_metadata_p_p_0.run(info)

# Generated at 2022-06-26 13:44:50.312530
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    int_0 = -251
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(int_0)
    assert var_0 == [], var_0.info

# Test for method run of class XAttrMetadataPP
# Test for method run of class XAttrMetadataPP
# Test for method run of class XAttrMetadataPP
# Test for method run of class XAttrMetadataPP

# Generated at 2022-06-26 13:44:54.383254
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    int_0 = -251
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(int_0)

# Generated at 2022-06-26 13:44:56.812904
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run({})


# Generated at 2022-06-26 13:45:05.097061
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    assert True


if __name__ == "__main__":
    import sys
    import os
    import io

    if sys.version_info < (3, 0):
        sys.exit("ERROR: Python 2.x has no support for extended attributes")

    if sys.platform == 'linux':
        # Run test on tmpfs to check that we don't hit the xattr limit
        if not os.path.isdir('/tmpfs') or os.listdir('/tmpfs'):
            sys.exit("ERROR: mount a tmpfs on /tmpfs first")
        os.chdir('/tmpfs')

    #
    # Environment setup
    #

    # Set the current working directory to the script directory so the file can be created
    # (This is done to avoid permission denied issues with creation of file on Windows)

# Generated at 2022-06-26 13:45:05.992041
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()


# Generated at 2022-06-26 13:45:09.611994
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()


if __name__ == '__main__':
    test_case_0()
    #test_XAttrMetadataPP()

# Generated at 2022-06-26 13:45:19.665145
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x = XAttrMetadataPP

    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    x_attr_metadata_p_p_0.run(None)

    x_attr_metadata_p_p_1 = XAttrMetadataPP()
    x_attr_metadata_p_p_1.run(None)

    x_attr_metadata_p_p_2 = XAttrMetadataPP()
    x_attr_metadata_p_p_2.run(None)

    x_attr_metadata_p_p_3 = XAttrMetadataPP()
    x_attr_metadata_p_p_3.run(None)

    x_attr_metadata_p_p_4 = XAttrMetadataPP()
    x_attr_metadata_p_p_4

# Generated at 2022-06-26 13:45:27.752790
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    data_0 = []
    str_0 = "lNh6UvqFZwS6:52:52:52"
    data_0.append(str_0)
    data_1 = []
    data_1.append(data_0)
    data_2 = {}
    data_2[str_0] = data_1
    data_3 = []
    data_3.append(data_2)
    data_4 = []

# Generated at 2022-06-26 13:45:38.129574
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    test_case_0()

# -- OLD
# def add_metadata(filename, info):
#     """Set extended attributes on downloaded file (if xattr support is found)."""
#     downloader = info.get('downloader', None)
#     if downloader is None:
#         return
#     downloader.to_screen('[metadata] Writing metadata to file\'s xattrs')

#     try:
#         xattr_mapping = {
#             # user.
#             'user.xdg.referrer.url':      'webpage_url',
#             'user.xdg.comment':           'description',
#             'user.dublincore.title':      'title',
#             'user.d

# Generated at 2022-06-26 13:45:42.549311
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    int_0 = -251
    var_0 = x_attr_metadata_p_p_0.run(int_0)
    int_1 = -251
    var_1 = x_attr_metadata_p_p_0.run(int_1)
    int_2 = -251
    var_2 = x_attr_metadata_p_p_0.run(int_2)
    if var_0 == int_0:
        return 0
    else:
        return 1

# Generated at 2022-06-26 13:45:54.378508
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    int_0 = -251
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(int_0)
    return

if __name__ == "__main__":
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:45:56.156525
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    obj = XAttrMetadataPP()

# Generated at 2022-06-26 13:46:02.419482
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # Setup test
    test_XAttrMetadataPP_run.x_attr_metadata_p_p_0 = XAttrMetadataPP()
    test_XAttrMetadataPP_run.int_0 = -251

    # Invoke method to test
    test_XAttrMetadataPP_run.var_0 = test_XAttrMetadataPP_run.x_attr_metadata_p_p_0.run(test_XAttrMetadataPP_run.int_0)


if __name__ == '__main__':
    test_case_0()
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:46:06.824416
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    int_0 = -251
    var_0 = x_attr_metadata_p_p_0.run(int_0)
    return x_attr_metadata_p_p_0


# Generated at 2022-06-26 13:46:11.038149
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    int_0 = 16
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(int_0)

# Generated at 2022-06-26 13:46:14.460230
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert (x_attr_metadata_p_p_0.arg_values) == ([], 0, '', [], True, None)


# Generated at 2022-06-26 13:46:16.967533
# Unit test for method run of class XAttrMetadataPP

# Generated at 2022-06-26 13:46:20.005160
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    int_0 = -251
    var_0 = x_attr_metadata_p_p_0.run(int_0)


# Generated at 2022-06-26 13:46:22.330074
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    xattrmetadatapp_0 = XAttrMetadataPP()
    assert isinstance(xattrmetadatapp_0, XAttrMetadataPP) == True


# Generated at 2022-06-26 13:46:23.230747
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()

# Generated at 2022-06-26 13:46:45.213740
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    var_0 = XAttrMetadataPP()
    assert var_0 is not None
    assert var_0.run

# Generated at 2022-06-26 13:46:47.196185
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p = XAttrMetadataPP()
    #assert x_attr_metadata_p_p.run() == None

# Generated at 2022-06-26 13:46:48.309546
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    assert True

# Unit tests for private method _run of class XAttrMetadataPP

# Generated at 2022-06-26 13:46:49.777098
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    int_0 = -251
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(int_0)

# Generated at 2022-06-26 13:46:54.419477
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_2 = XAttrMetadataPP()
    import unittest
    class TestRun(unittest.TestCase):
        def test_run_1(self):
            int_0 = -251
            var_0 = x_attr_metadata_p_p_2.run(int_0)
    unittest.main()

# Class for unit testing run method of XAttrMetadataPP

# Generated at 2022-06-26 13:46:57.504677
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0 is not None


# Generated at 2022-06-26 13:46:59.355107
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:47:05.428024
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
	# Arrange
	int_0 = -251
	x_attr_metadata_p_p_0 = XAttrMetadataPP()
	# Act
	var_0 = x_attr_metadata_p_p_0.run(int_0)
	# Assert
	var_1 = None
	if var_0 != var_1:
		raise ValueError("Expected: "+str(var_1)+" Actual: "+str(var_0))


# Generated at 2022-06-26 13:47:12.651282
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    try:
        int_0 = -251
        x_attr_metadata_p_p_0 = XAttrMetadataPP()
        var_0 = x_attr_metadata_p_p_0.run(int_0)
        var_1 = x_attr_metadata_p_p_0.run(int_0)
    except XAttrMetadataError as e:
        print(e.message)

    except XAttrUnavailableError as e:
        print(e.message)

# test_case_0()
test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:47:13.694799
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    XAttrMetadataPP()


# Generated at 2022-06-26 13:47:54.520564
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pass


# Generated at 2022-06-26 13:48:00.748128
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    int_0 = -251
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(int_0)
    assert(var_0[0] == [])
    assert(var_0[1] == -251)

if __name__ == '__main__':
    test_case_0()
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:48:01.284417
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

# Generated at 2022-06-26 13:48:03.768697
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0.__class__ == XAttrMetadataPP


# Generated at 2022-06-26 13:48:05.825430
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert True

if __name__ == '__main__':
    test_XAttrMetadataPP()
    test_case_0()

# Generated at 2022-06-26 13:48:09.984861
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    xattrmetadatapp_0 = XAttrMetadataPP()
    print(xattrmetadatapp_0)

if __name__ == "__main__" :
    test_case_0()
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:48:12.726346
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()


if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:48:19.857135
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run()
    assert isinstance(var_0, tuple)
    assert isinstance(var_0[0], list)
    assert isinstance(var_0[1], dict)
    assert len(var_0) == 2


if __name__ == '__main__':
    test_case_0()
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:48:20.497894
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

# Generated at 2022-06-26 13:48:22.081637
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    print ('Testing unit case of class XAttrMetadataPP...')
    test_case_0()

# Generated at 2022-06-26 13:49:46.880866
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p = XAttrMetadataPP()


# Generated at 2022-06-26 13:49:57.349148
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from uuid import uuid4
    from random import randint
    

# Generated at 2022-06-26 13:50:03.574602
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    int_0 = 128
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    x_attr_metadata_p_p_0.run(int_0)
    int_0 = -251
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    x_attr_metadata_p_p_0.run(int_0)


# Generated at 2022-06-26 13:50:07.948656
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    int_0 = -251
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(int_0)


# def main():
#     test_case_0()
#     test_XAttrMetadataPP_run()


# if __name__ == '__main__':
#     main()

# Generated at 2022-06-26 13:50:10.139411
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass


if __name__ == '__main__':
    print(test_case_0())
    print(test_XAttrMetadataPP_run())

# Generated at 2022-06-26 13:50:14.042603
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    # No Exception
    x_attr_metadata_p_p_0.run('undefined')

# AssertionError: None != (1,None) == (23,None)

# Generated at 2022-06-26 13:50:15.518417
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    if __name__ == '__main__':
        test_case_0()

test_XAttrMetadataPP()

# Generated at 2022-06-26 13:50:19.627464
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # if the exception is properly raised when the xattr library is not available
    if compat_os_name != 'nt':
        # noinspection SpellCheckingInspection
        assert Raises(XAttrUnavailableError, test_case_0) is None
    # TODO: add other tests
    assert True  # TODO: implement your test here

# Generated at 2022-06-26 13:50:26.556305
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    xattr_mapping_0 = {'user.dublincore.description': 'description', 'user.xdg.comment': 'description', 'user.xdg.referrer.url': 'webpage_url', 'user.dublincore.contributor': 'uploader', 'user.dublincore.format': 'format', 'user.dublincore.title': 'title', 'user.dublincore.date': 'upload_date'}

# Generated at 2022-06-26 13:50:35.317253
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    from ..YoutubeDL import YoutubeDL
    from ..PostProcessor import PostProcessor
    from ..compat import compat_os_name
    from ..extractor import gen_extractors
    from ..utils import prepend_extension

    gen_extractors()
    test_dir = os.path.dirname(__file__)