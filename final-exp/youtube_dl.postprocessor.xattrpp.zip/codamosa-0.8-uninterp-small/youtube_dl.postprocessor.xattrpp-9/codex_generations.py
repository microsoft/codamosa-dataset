

# Generated at 2022-06-26 13:44:04.326499
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0.run(['filepath']) == [[], ['filepath']]

# Generated at 2022-06-26 13:44:05.297432
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass


# Generated at 2022-06-26 13:44:06.645450
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # TODO: Test for constructor of class XAttrMetadataPP
    pass


# Generated at 2022-06-26 13:44:14.222137
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from .common import DownloadContext
    from ..YoutubeDL import YoutubeDL
    from .XAttrMetadataPP import XAttrMetadataPP


# Generated at 2022-06-26 13:44:18.016403
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0.run("info") == ([], "info")


# Generated at 2022-06-26 13:44:20.004877
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    x_attr_metadata_p_p_0.run()



# Generated at 2022-06-26 13:44:21.871151
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

# Generated at 2022-06-26 13:44:27.294100
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p = XAttrMetadataPP()
    assert x_attr_metadata_p_p.SUCCESS == 0
    assert x_attr_metadata_p_p.FAILED == 1


# Generated at 2022-06-26 13:44:36.509275
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_1 = XAttrMetadataPP()
    info0 = {}
    retval1 = x_attr_metadata_p_p_1.run(info0)
    filename2 = info0['filepath']
    xattrname3 = 'user.xdg.referrer.url'
    byte_value4 = 'webpage_url'.encode('utf-8')
    retval5 = write_xattr(filename2, xattrname3, byte_value4)
    xattrname6 = 'user.dublincore.title'
    byte_value7 = 'title'.encode('utf-8')
    retval8 = write_xattr(filename2, xattrname6, byte_value7)

# Generated at 2022-06-26 13:44:39.913321
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()

    x_attr_metadata_p_p_0.run({})

test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:44:46.170043
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # TODO : Implement test_XAttrMetadataPP_run
    assert True

# Generated at 2022-06-26 13:44:49.689399
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0.run == x_attr_metadata_p_p_0.run


# Generated at 2022-06-26 13:44:50.613842
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()


# Generated at 2022-06-26 13:44:58.848989
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    class_type = type(XAttrMetadataPP())
    assert isinstance(XAttrMetadataPP(), object), \
        "Expected XAttrMetadataPP to be of type 'object', but got %r" % class_type

    assert hasattr(XAttrMetadataPP(), 'run'), \
        "Expected XAttrMetadataPP to have a 'run' attribute"

    assert callable(getattr(XAttrMetadataPP(), 'run', None)), \
        "Expected XAttrMetadataPP to have a callable 'run' attribute"


# Generated at 2022-06-26 13:45:01.670932
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    set_0 = set()
    assert x_attr_metadata_p_p_0.run(set_0)

test_XAttrMetadataPP()
test_case_0()

# Generated at 2022-06-26 13:45:02.438708
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()


# Generated at 2022-06-26 13:45:04.157572
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    for i in range(0, 10):
        test_case_0()

# Generated at 2022-06-26 13:45:13.998030
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # Expected values
    info = {}
    filename = "filename"
    value = "value"
    byte_value = value.encode('utf-8')


    # Testing for missing xattr support
    # Initialized the class
    class MockXAttrNotSupported(XAttrMetadataPP):
        def __init__(self):
            pass

        def write_xattr(filename, xattrname, byte_value):
            raise XAttrUnavailableError("Unavailable")

        run(self, info)

    # Testing for disk space
    # Initialized the class
    class MockXAttrNoSpace(XAttrMetadataPP):
        def __init__(self):
            pass


# Generated at 2022-06-26 13:45:20.328068
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from .common import PostProcessor
    set_0 = set()
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert isinstance(x_attr_metadata_p_p_0, XAttrMetadataPP) and isinstance(x_attr_metadata_p_p_0, PostProcessor)
    assert x_attr_metadata_p_p_0.run(set_0) == ([], set_0)

# Generated at 2022-06-26 13:45:22.569664
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    set_0 = set()
    var_0 = x_attr_metadata_p_p_0.run(set_0)
    # assert var_0 == ["",]

# Generated at 2022-06-26 13:45:36.593431
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    print('Test: Run method of class XAttrMetadataPP')

    # Testcase 0
    test_case_0()


if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:45:40.146740
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    set_0 = set()
    var_0 = x_attr_metadata_p_p_0.run(set_0)


# Generated at 2022-06-26 13:45:40.973068
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # Test case 0
    test_case_0()

# Generated at 2022-06-26 13:45:43.922699
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # test_case_0
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    set_0 = set()
    var_0 = x_attr_metadata_p_p_0.run(set_0)


if __name__ == '__main__':
    test_case_0()
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:45:46.937115
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()

if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:45:48.751165
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_1 = XAttrMetadataPP()


# Generated at 2022-06-26 13:45:50.943153
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()


# Generated at 2022-06-26 13:45:52.443091
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    assert False, "Test with mock object"

# Generated at 2022-06-26 13:45:54.403844
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()

if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:45:58.941720
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    set_0 = set()
    var_0 = x_attr_metadata_p_p_0.run(set_0)


if __name__ == '__main__':
    import sys
    sys.exit(test_XAttrMetadataPP())

# Generated at 2022-06-26 13:46:22.411066
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # set-up variables for test_case_0
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    set_0 = set()

    # run test case
    result_0 = x_attr_metadata_p_p_0.run(set_0)
    print(result_0)



# Generated at 2022-06-26 13:46:26.397592
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    set_0 = set()
    var_0 = x_attr_metadata_p_p_0.run(set_0)
    assert(str(var_0) == "([], set())")

test_case_0.testname = "test_case_0"



# Generated at 2022-06-26 13:46:29.536244
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0 is not None

# Unit test helper function for class XAttrMetadataPP

# Generated at 2022-06-26 13:46:31.211900
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:46:34.099361
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    tester = XAttrMetadataPP()
    info = {}
    tester.run(info)


if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:46:38.223241
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    set_0 = set()
    var_0 = x_attr_metadata_p_p_0.run(set_0)


if __name__ == "__main__":
    test_case_0()
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:46:43.376760
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()


# Generated at 2022-06-26 13:46:45.507958
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()


# Generated at 2022-06-26 13:46:48.160648
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    set_0 = set()
    var_0 = x_attr_metadata_p_p_0.run(set_0)

# Generated at 2022-06-26 13:46:52.346403
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_1 = XAttrMetadataPP()
    set_1 = set()
    var_0 = x_attr_metadata_p_p_1.run(set_1)
    check_0 = []
    check_1 = set()
    if check_0 != var_0[0]:
        print("Test case 1 failed")
    elif check_1 != var_0[1]:
        print("Test case 1 failed")
    else:
        print("Test case 1 passed")

if __name__ == '__main__':
    test_case_0()
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:47:32.619959
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p = XAttrMetadataPP()

    # testing the method run of class XAttrMetadataPP
    test_case_0()

# Generated at 2022-06-26 13:47:35.054742
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert callable(XAttrMetadataPP)
    assert isinstance(XAttrMetadataPP(), XAttrMetadataPP)
    

# Generated at 2022-06-26 13:47:35.894514
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP()

# Generated at 2022-06-26 13:47:37.281322
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()

# Function used to generate test functions for class XAttrMetadataPP

# Generated at 2022-06-26 13:47:38.077200
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
	pass



# Generated at 2022-06-26 13:47:38.881584
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()

# Generated at 2022-06-26 13:47:40.240935
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()


# Generated at 2022-06-26 13:47:41.760850
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

if __name__ == "__main__":
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:47:42.554361
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

# Generated at 2022-06-26 13:47:46.537593
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p = XAttrMetadataPP()
    if ((x_attr_metadata_p_p.get_downloader() != None)):
        raise Exception("Assert failed: (x_attr_metadata_p_p.get_downloader() != None)")


# Generated at 2022-06-26 13:49:12.394918
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    assert set() == XAttrMetadataPP().run(set())
    assert {'filepath': '/tmp/test.mp4'} == XAttrMetadataPP().run({'filepath': '/tmp/test.mp4'})
    assert {'filepath': '/tmp/test.mp4', 'upload_date': '20150421', 'uploader': 'test uploader', 'description': 'test description',
            'title': 'test title', 'webpage_url': 'https://github.com'} == \
        XAttrMetadataPP().run({'filepath': '/tmp/test.mp4', 'upload_date': '20150421', 'uploader': 'test uploader',
                               'description': 'test description', 'title': 'test title', 'webpage_url': 'https://github.com'})

# Generated at 2022-06-26 13:49:15.802442
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    set_0 = set()
    var_0 = x_attr_metadata_p_p_0.run(set_0)
    pass # test case stub


# Generated at 2022-06-26 13:49:17.673706
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0 is not None


# Generated at 2022-06-26 13:49:26.260922
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    #
    # Test with valid data
    #
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    info_0 = dict()
    filename_0 = 'some_file.mp4'
    info_0['filepath'] = filename_0
    xattrname_0 = 'user.dublincore.format'
    infoname_0 = 'format'
    xattrname_1 = 'user.dublincore.title'
    infoname_1 = 'title'
    xattrname_2 = 'user.dublincore.date'
    infoname_2 = 'upload_date'
    xattrname_3 = 'user.dublincore.contributor'
    infoname_3 = 'uploader'
    xattrname_

# Generated at 2022-06-26 13:49:29.166997
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    set_0 = set()
    var_0 = x_attr_metadata_p_p_0.run(set_0)
    assert var_0[0] == []

# Generated at 2022-06-26 13:49:31.958109
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()


# Generated at 2022-06-26 13:49:36.240851
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    set_0 = set()
    x_attr_metadata_p_p_0.run(set_0)
    # x_attr_metadata_p_p_0.__init__()
    # x_attr_metadata_p_p_0.__init__()
    # x_attr_metadata_p_p_0.__init__()


# Generated at 2022-06-26 13:49:37.001995
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    obj = XAttrMetadataPP()

# Generated at 2022-06-26 13:49:37.991291
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()


# Generated at 2022-06-26 13:49:38.758909
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()
#

# Generated at 2022-06-26 13:52:57.612363
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

# Generated at 2022-06-26 13:53:03.710373
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    set_0 = set()
    var_0 = x_attr_metadata_p_p_0.run(set_0)


# Needed because external code imports this module
try:
    from ..utils import (
        get_xattr,
        read_xattr,
        remove_xattr,
        write_xattr,
        XAttrUnavailableError,
        XAttrMetadataError,
    )
except Exception as e:
    print(e)

# Generated at 2022-06-26 13:53:05.739831
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert (x_attr_metadata_p_p_0.run == XAttrMetadataPP.run)

# Generated at 2022-06-26 13:53:06.613876
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP() != None


# Generated at 2022-06-26 13:53:10.523029
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    x_attr_metadata_p_p_0.run(set({'filepath': 'file'}))
    x_attr_metadata_p_p_0.run(set({'filepath': 'file'}))

if __name__ == '__main__':
    test_case_0()
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:53:14.053717
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    set_0 = set()
    var_0 = x_attr_metadata_p_p_0.run(set_0)

# Generated at 2022-06-26 13:53:16.935468
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    set_0 = set()
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(set_0)


# Generated at 2022-06-26 13:53:19.083809
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_1 = XAttrMetadataPP()
    x_attr_metadata_p_p_1.run(set())

# Generated at 2022-06-26 13:53:21.577190
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from .downloader import postprocessor_classes
    obj = XAttrMetadataPP()
    f1 = (
        'run',
        None,
    )
    assert getattr(obj, f1[0]) == getattr(postprocessor_classes[0], f1[0])



# Generated at 2022-06-26 13:53:22.273267
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

#