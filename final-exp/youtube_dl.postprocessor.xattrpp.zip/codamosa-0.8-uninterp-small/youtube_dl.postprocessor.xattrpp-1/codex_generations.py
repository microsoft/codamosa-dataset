

# Generated at 2022-06-26 13:44:09.014855
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    info = {'filepath': None}
    x_attr_metadata_p_p_0.run(info)

# This is call from the python script
if __name__ == '__main__':
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    info = {'filepath': None}
    x_attr_metadata_p_p_0.run(info)

# Generated at 2022-06-26 13:44:15.635957
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0.run(info = {'upload_date' : 'upload_date'}) == ([], {'upload_date' : 'upload_date'})


# Generated at 2022-06-26 13:44:18.380320
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # TODO: Need to test
    return

if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:44:19.693218
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:44:22.734422
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert test_case_0() is None, "Constructor of class XAttrMetadataPP"


# Generated at 2022-06-26 13:44:25.791919
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert True


if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:44:35.093859
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    filename = "filename"
    xattr_mapping = {
        'user.xdg.referrer.url': 'webpage_url',
        # 'user.xdg.comment':            'description',
        'user.dublincore.title': 'title',
        'user.dublincore.date': 'upload_date',
        'user.dublincore.description': 'description',
        'user.dublincore.contributor': 'uploader',
        'user.dublincore.format': 'format',
    }
    num_written = 0

# Generated at 2022-06-26 13:44:39.706563
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    filename = ''
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    x_attr_metadata_p_p_0.run(filename)
    pass


if __name__ == '__main__':
    # test_case_0()
    pass

# Generated at 2022-06-26 13:44:40.958512
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass # we can't test this class since it writes stuff to file system


# Generated at 2022-06-26 13:44:50.313675
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p = XAttrMetadataPP()

    # Test 1:
    x_attr_metadata_p_p_run_0 = x_attr_metadata_p_p.run({
        'webpage_url': 'webpage_url',
        'title': 'title',
        'upload_date': 'upload_date',
        'description': 'description',
        'uploader': 'uploader',
        'format': 'format',
        'filepath': 'filepath'
    })

# Generated at 2022-06-26 13:45:03.992410
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_1 = XAttrMetadataPP()
    bytes_1 = b'M\xaaX\x9bx\x1d\xc6\xda\x077\xb5'
    var_1 = x_attr_metadata_p_p_1.run(bytes_1)
# var_1: (list[str], dict)

# Test each if statements
x_attr_metadata_p_p_1 = XAttrMetadataPP()
bytes_1 = b'M\xaaX\x9bx\x1d\xc6\xda\x077\xb5'
var_1 = x_attr_metadata_p_p_1.run(bytes_1)
# var_1: (list[str], dict)

# Generated at 2022-06-26 13:45:07.034126
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0 is not None


# Unit tests for XAttrMetadataPP.run()

# Generated at 2022-06-26 13:45:09.076162
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:45:14.990091
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()

    # test getter and setter of variable filepath
    bytes_0 = b'Z\xbf\xa3\x93\xf8\\'
    assert x_attr_metadata_p_p_0.filepath == None
    x_attr_metadata_p_p_0.filepath = bytes_0
    assert bytes_0 == x_attr_metadata_p_p_0.filepath


# Generated at 2022-06-26 13:45:23.087669
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    # Minimal test
    x_attr_metadata_p_p = XAttrMetadataPP()
    result = x_attr_metadata_p_p.run(10)
    assert result[0] == [], 'Minimal test failed'

    # Non-trivial test
    x_attr_metadata_p_p = XAttrMetadataPP()
    result = x_attr_metadata_p_p.run(20)
    assert result[1] == 20, 'Non-trivial test failed'


if __name__ == '__main__':
    test_XAttrMetadataPP_run()
    test_case_0()

# Generated at 2022-06-26 13:45:23.737582
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pass


# Generated at 2022-06-26 13:45:29.613816
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    bytes_0 = b'\x0c\xfeJ\x1eRFXG\x0e\xbc\x1e'
    return_value_0 = x_attr_metadata_p_p_0.run(bytes_0)
    assert return_value_0 == (bytes_0, b'\x0c\xfeJ\x1eRFXG\x0e\xbc\x1e')


# Generated at 2022-06-26 13:45:30.033735
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert True

# Generated at 2022-06-26 13:45:34.556292
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p = XAttrMetadataPP()
    # Unit test for run() of class XAttrMetadataPP
    test_case_0()

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:45:36.669392
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()


# Generated at 2022-06-26 13:45:52.383975
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p = XAttrMetadataPP()
    assert hasattr(x_attr_metadata_p_p, 'run'), 'Function call "run" is not implemented in class XAttrMetadataPP'
    assert hasattr(x_attr_metadata_p_p, '_downloader'), 'Attribute "_downloader" is not implemented in class XAttrMetadataPP'

# Generated at 2022-06-26 13:45:55.932885
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    result = test_case_0()
    if result:
        print("Unit test for method run of class XAttrMetadataPP failed.")
    else:
        print("Unit test for method run of class XAttrMetadataPP passed.")

# Generated at 2022-06-26 13:46:00.091933
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p = XAttrMetadataPP()
    assert x_attr_metadata_p_p is not None, 'Unit test for class XAttrMetadataPP failed'
    assert x_attr_metadata_p_p.run is not None, 'Unit test for method run() of class XAttrMetadataPP failed'


# Generated at 2022-06-26 13:46:03.119841
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    bytes_0 = b'\x0c\xfeJ\x1eRFXG\x0e\xbc\x1e'
    var_0 = x_attr_metadata_p_p_0.run(bytes_0)

# Generated at 2022-06-26 13:46:05.482412
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    assert True

if __name__ == '__main__':
    test_case_0()
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:46:16.439047
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # mock xattr.supports_xattr to return false
    from . import XAttrMetadataPP
    from nose.tools import assert_equals, assert_raises
    import mock
    pp = XAttrMetadataPP()
    xattr = mock.MagicMock()
    xattr.supports_xattr = False
    with mock.patch('youtube_dl.postprocessor.xattr', xattr):
        out, info = pp.run(dict(filepath='mockfile'))
        assert_equals(out, [])
        assert_equals(info, dict(filepath='mockfile'))

    xattr = mock.MagicMock()
    xattr.supports_xattr = True
    xattr.setxattr.side_effect = lambda *args: xattr_tester(args)
   

# Generated at 2022-06-26 13:46:17.359274
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert True



# Generated at 2022-06-26 13:46:18.738775
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    for _ in range(10):
        test_case_0()

# Generated at 2022-06-26 13:46:19.629305
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert True


# Generated at 2022-06-26 13:46:21.636587
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p = XAttrMetadataPP()
    assert x_attr_metadata_p_p is not None


# Generated at 2022-06-26 13:46:47.602285
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    bytes_0 = b'\x0c\xfeJ\x1eRFXG\x0e\xbc\x1e'
    var_0 = x_attr_metadata_p_p_0.run(bytes_0)

if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:46:50.168957
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    print('Test run of method XAttrMetadataPP.run')
    test_case_0()

if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:46:53.869892
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    bytes_0 = b'\x0c\xfeJ\x1eRFXG\x0e\xbc\x1e'
    var_0 = x_attr_metadata_p_p_0.run(bytes_0)

# Generated at 2022-06-26 13:46:55.190194
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()


#
# Test class XAttrMetadataPP
#

# Generated at 2022-06-26 13:47:01.295443
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    bytes_0 = b'\x0c\xfeJ\x1eRFXG\x0e\xbc\x1e'
    var_0 = x_attr_metadata_p_p_0.run(bytes_0)


if __name__ == '__main__':
    test_case_0()
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:47:02.580474
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_1 = XAttrMetadataPP()

# Generated at 2022-06-26 13:47:06.797605
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    bytes_0 = b'\x0c\xfeJ\x1eRFXG\x0e\xbc\x1e'
    var_0 = x_attr_metadata_p_p_0.run(bytes_0)


# Generated at 2022-06-26 13:47:11.545418
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_1 = XAttrMetadataPP()
    bytes_1 = b'\x0c\xfeJ\x1eRFXG\x0e\xbc\x1e'
    var_1 = x_attr_metadata_p_p_1.run(bytes_1)


# Generated at 2022-06-26 13:47:14.031725
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    assert '\x1f\x0f\x1e' == XAttrMetadataPP().run('\x17\x1fL')


# Generated at 2022-06-26 13:47:15.347210
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert(XAttrMetadataPP() is not None)

if __name__ == '__main__':
    test_XAttrMetadataPP()
    test_case_0()

# Generated at 2022-06-26 13:48:03.103484
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0.check_progress == True
    assert x_attr_metadata_p_p_0.downloader == None
    assert x_attr_metadata_p_p_0.fatal_error == None
    assert x_attr_metadata_p_p_0.progress == 0
    assert x_attr_metadata_p_p_0.total == 0
    x_attr_metadata_p_p_0.on_progress()
    x_attr_metadata_p_p_0.on_finished()
    x_attr_metadata_p_p_0.on_error()
    x_attr_metadata_p_p_0.on_download_finished()
    x_attr_metadata_p

# Generated at 2022-06-26 13:48:05.742159
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0 is not None, 'Instance of XAttrMetadataPP is not initialized'

# Generated at 2022-06-26 13:48:11.329652
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    bytes_0 = b'\x0c\xfeJ\x1eRFXG\x0e\xbc\x1e'
    var_0 = x_attr_metadata_p_p_0.run(bytes_0)


# Generated at 2022-06-26 13:48:21.440725
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    print("Test of method run of class XAttrMetadataPP")

    # Test case 0: Test with correct correct values
    test_case_0()

    # Test case 1: Test with correct correct values
    x_attr_metadata_p_p_1 = XAttrMetadataPP()
    print("Test of method run of class XAttrMetadataPP")
    bytes_1 = b'T\x1f\x1c\x0e\xda"L\x9b\xbb\x89\xc6\xd2\x87\xfa'
    var_1 = x_attr_metadata_p_p_1.run(bytes_1)

    # Test case 2: Test with correct correct values
    x_attr_metadata_p_p_2 = XAttrMetadataPP()

# Generated at 2022-06-26 13:48:27.448635
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0.run(b'\x0c\xfeJ\x1eRFXG\x0e\xbc\x1e') == (
        [], b'\x0c\xfeJ\x1eRFXG\x0e\xbc\x1e')

test_case_0()

# vim: tabstop=4 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-26 13:48:29.180230
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()

if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:48:38.857063
# Unit test for method run of class XAttrMetadataPP

# Generated at 2022-06-26 13:48:46.559074
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # Test Sample
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    bytes_0 = b'\x0c\xfeJ\x1eRFXG\x0e\xbc\x1e'
    var_0 = x_attr_metadata_p_p_0.run(bytes_0)
    assert var_0 == ([], bytes_0)

    # Test Sample
    x_attr_metadata_p_p_1 = XAttrMetadataPP()

# Generated at 2022-06-26 13:48:48.029308
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP()


if __name__ == "__main__":
    import sys
    import pytest
    sys.exit(pytest.main([__file__]))

# Generated at 2022-06-26 13:48:49.589613
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_obj = XAttrMetadataPP()
    x_attr_metadata_p_p_obj.run(info)


# Generated at 2022-06-26 13:50:17.748244
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run(): 
    # Default case
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    result = x_attr_metadata_p_p_0.run()
    
    # Test case 1
    x_attr_metadata_p_p_1 = XAttrMetadataPP()
    result = x_attr_metadata_p_p_1.run()
    
    # Test case 2
    x_attr_metadata_p_p_2 = XAttrMetadataPP()
    result = x_attr_metadata_p_p_2.run()

# Generated at 2022-06-26 13:50:21.603751
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    bytes_0 = b'\x0c\xfeJ\x1eRFXG\x0e\xbc\x1e'
    var_0 = x_attr_metadata_p_p_0.run(bytes_0)



# Generated at 2022-06-26 13:50:23.238772
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p = XAttrMetadataPP()
    x_attr_metadata_p_p.run()

# Generated at 2022-06-26 13:50:32.102990
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # Tests for exceptions
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    bytes_0 = b'\x0c\xfeJ\x1eRFXG\x0e\xbc\x1e'
    var_0 = x_attr_metadata_p_p_0.run(bytes_0)
    assertTrue(isinstance(var_0, tuple))
    assertEqual(len(var_0), 2)
    assertEqual(len(var_0[0]), 0)

    assertTrue(isinstance(var_0[1], bytes))
    assertEqual(var_0[1], bytes_0)

# Generated at 2022-06-26 13:50:36.631505
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    bytes_0 = b'\x0c\xfeJ\x1eRFXG\x0e\xbc\x1e'
    result = x_attr_metadata_p_p_0.run(bytes_0)
    assert result == ([], bytes_0), 'Error, the result should be [], bytes_0'


if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:50:37.510979
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    print(20)
    test_case_0()


# Generated at 2022-06-26 13:50:40.502139
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # Test case 0
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    bytes_0 = b'\x0c\xfeJ\x1eRFXG\x0e\xbc\x1e'
    var_0 = x_attr_metadata_p_p_0.run(bytes_0)
    print("TEST CASE 0")
    print("PASSED!")


# Generated at 2022-06-26 13:50:46.167440
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    bytes_0 = b'\x0c\xfeJ\x1eRFXG\x0e\xbc\x1e'
    var_0 = x_attr_metadata_p_p_0.run(bytes_0)


# Generated at 2022-06-26 13:50:49.968884
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    bytes_0 = b'\x0c\xfeJ\x1eRFXG\x0e\xbc\x1e'
    var_0 = x_attr_metadata_p_p_0.run(bytes_0)

# Generated at 2022-06-26 13:50:51.959119
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p = XAttrMetadataPP()
