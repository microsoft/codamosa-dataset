

# Generated at 2022-06-26 13:44:10.975997
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .common import InfoExtractor
    from .utils import unescapeHTML

    #
    # Test creation of dublin core extended attributes
    #
    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        IE_DESC = 'Test IE'

        def report_webpage_download(self, *args, **kwargs):
            return True

        def report_download_webpage(self, *args, **kwargs):
            return {'id': 'v0'}


# Generated at 2022-06-26 13:44:19.949375
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    import sys
    from ..utils import unescapeHTML
    from ..YoutubeDL import YoutubeDL
    from .common import InfoExtractor
    from .extractor.youtube import YoutubeIE
    from .downloader.http import HttpFD

    class MockYoutubeDl(object):

        def __init__(self, ydl):
            self.ydl = ydl

        def to_screen(self, msg):
            print(msg)

        def report_warning(self, msg):
            print(msg)

        def report_error(self, msg):
            print(msg)

        def to_stdout(self, s, on_same_line=False):
            print(s)

        def to_stderr(self, s):
            print(s)


    class MockInfoExtractor(InfoExtractor):

        IE_

# Generated at 2022-06-26 13:44:30.623042
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    info = {
        'filepath': '/tmp/test.flv',
        'webpage_url': 'http://test.com',
        'title': 'test title',
        'upload_date': '20170101',
        'description': 'test description',
        'uploader': 'test uploader',
        'format': 'flv',
    }
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    x_attr_metadata_p_p_0.run(info)


if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:44:34.899484
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()

# def main():
#     test_XAttrMetadataPP_run()
#
#
# if __name__ == '__main__':
#     main()

# Generated at 2022-06-26 13:44:36.278286
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

# Generated at 2022-06-26 13:44:38.705296
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p = XAttrMetadataPP()


# Generated at 2022-06-26 13:44:45.107303
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()

    filename  = "file.mp3"
    infos = {
        'filepath' : filename,
        'title' : "Title",
        'webpage_url' : 'https://webpage_url',
        'upload_date' : '2018-11-14',
        'description' : "Description",
        'uploader' : 'Uploader',
        'format' : 'mp3',
    }

    x_attr_metadata_p_p_0.run(infos)

# Generated at 2022-06-26 13:44:46.610200
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p = XAttrMetadataPP()
    pass # TODO: add more tests

# Generated at 2022-06-26 13:44:49.773437
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    print('TEST: class XAttrMetadataPP')
    test_case_0()
    print('TEST: class XAttrMetadataPP: PASS')

# Unit test wrapper

# Generated at 2022-06-26 13:44:56.420178
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # Test 1: no arguments
    try:
        x_attr_metadata_p_p_1 = XAttrMetadataPP()
        if isinstance(x_attr_metadata_p_p_1, XAttrMetadataPP):
            print(x_attr_metadata_p_p_1, ": Pass")
    except ValueError:
        print(x_attr_metadata_p_p_1, ": Fail")



# Generated at 2022-06-26 13:45:02.955757
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()

#
# if __name__ == '__main__':
#     test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:45:04.403299
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()

# Generated at 2022-06-26 13:45:14.238164
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0 == XAttrMetadataPP()
    assert x_attr_metadata_p_p_0 == XAttrMetadataPP
    assert x_attr_metadata_p_p_0 == 'XAttrMetadataPP'
    assert x_attr_metadata_p_p_0 == ''
    assert x_attr_metadata_p_p_0 == 'XAttrMetadataPP'
    assert x_attr_metadata_p_p_0 == None
    assert x_attr_metadata_p_p_0 == (1, 2, 3)
    assert x_attr_metadata_p_p_0 != False
    assert x_attr_metadata_p_p_0 != 1
    assert x

# Generated at 2022-06-26 13:45:16.542461
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_pp = XAttrMetadataPP()
    assert x_attr_metadata_pp is not None

# Generated at 2022-06-26 13:45:18.344391
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # Test cases
    # TODO: is there a way to have test cases that make sense?
    test_case_0()


if __name__ == '__main__':
    # Unit tests for XAttrMetadataPP.run
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:45:21.682228
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(x_attr_metadata_p_p_0)


# Generated at 2022-06-26 13:45:22.818429
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()

test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:45:24.390068
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()


# Generated at 2022-06-26 13:45:29.209321
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # Input variables
    postProcessor = 'postProcessor'

    x_attr_metadata_p_p_0 = XAttrMetadataPP(postProcessor)
    x_attr_metadata_p_p_0.run(set_metadata_pp)

    # Check initializers
    assert_equals(x_attr_metadata_p_p_0.postProcessor, postProcessor)

# Generated at 2022-06-26 13:45:32.663506
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # case 1
    x_attr_metadata_p_p_1 = XAttrMetadataPP()
    var_1 = x_attr_metadata_p_p_1.run(x_attr_metadata_p_p_1)
    if var_1 == ([], {}):
        print(True)
    else:
        print(False)

# Generated at 2022-06-26 13:45:44.717768
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0 is not None

# Generated at 2022-06-26 13:45:51.558093
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # Check that the method run works correctly
    x_attr_metadata_p_p = XAttrMetadataPP()
    # Test when the system is windows
    assert x_attr_metadata_p_p.run(x_attr_metadata_p_p)[0] == []
    assert x_attr_metadata_p_p.run(x_attr_metadata_p_p)[1] == x_attr_metadata_p_p



# Generated at 2022-06-26 13:45:52.623075
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert True

# Generated at 2022-06-26 13:45:53.598161
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()


if __name__ == "__main__":
    test_XAttrMetadataPP()
    print("Unit Test Completed")

# Generated at 2022-06-26 13:45:57.883761
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(x_attr_metadata_p_p_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 13:45:59.059966
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_1 = XAttrMetadataPP()

# Generated at 2022-06-26 13:45:59.843084
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()


# Generated at 2022-06-26 13:46:01.320145
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

# python -m edx_dl.postprocessor.xattr_metadata test

# Generated at 2022-06-26 13:46:02.720837
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_1 = XAttrMetadataPP()



# Generated at 2022-06-26 13:46:06.189033
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()
    return None

# End of test function for class XAttrMetadataPP

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:46:27.714608
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    output_0 = '<XAttrMetadataPP object at 0x7fe2a899f080>'
    assert(str(XAttrMetadataPP()) == output_0)

# Generated at 2022-06-26 13:46:29.118172
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # Should not have any exception
    test_case_0()

# Generated at 2022-06-26 13:46:32.993963
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(x_attr_metadata_p_p_0)
    assert(var_0 == ([], x_attr_metadata_p_p_0))

# Generated at 2022-06-26 13:46:40.933007
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    var_1 = XAttrMetadataPP()
    var_2 = {}
    var_2['filepath'] = 'test_file.mp4'
    var_2['duration'] = 123
    var_2['uploader'] = 'niconiconi'
    var_2['title'] = '教科書'
    var_2['webpage_url'] = 'https://www.bilibili.com/video/av9766292'
    var_2['description'] = '这是测试描述'
    var_2['upload_date'] = '20180311'
    var_2['format'] = 'mp4'
    var_3 = var_1.run(var_2)
    print(var_3)
    assert var_3[0] == []

# Generated at 2022-06-26 13:46:42.967242
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    if __name__ == '__main__':
        test_case_0()

# Generated at 2022-06-26 13:46:47.990444
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(x_attr_metadata_p_p_0)
    return var_0


if __name__ == '__main__':
    var_0 = test_XAttrMetadataPP()
    print(var_0)

# Generated at 2022-06-26 13:46:49.221138
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    t = XAttrMetadataPP(None)


# Generated at 2022-06-26 13:46:50.282948
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    print('\nTest constructor of class XAttrMetadataPP')
    x_attr_metadata_p_p_0 = XAttrMetadataPP()



# Generated at 2022-06-26 13:46:54.272462
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_1 = XAttrMetadataPP()
    var_1 = x_attr_metadata_p_p_1.run(x_attr_metadata_p_p_1.CASE_1)
    print("Assertion 1: ", var_1 == [])
    print("Assertion 2: ", var_1 == [])

# Generated at 2022-06-26 13:46:58.183287
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert_equals(x_attr_metadata_p_p_0.run(x_attr_metadata_p_p_0), ([], None))

# Generated at 2022-06-26 13:47:41.357376
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(x_attr_metadata_p_p_0)
    assert var_0[0] == []
    assert var_0[1] == x_attr_metadata_p_p_0

# Generated at 2022-06-26 13:47:43.368762
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

if __name__ == '__main__':

    #
    # test_XAttrMetadataPP()
    #

    pass

# Generated at 2022-06-26 13:47:44.453607
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # Class XAttrMetadataPP can pass unit test
    assert True



# Generated at 2022-06-26 13:47:54.677639
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()

# Generated at 2022-06-26 13:47:55.715280
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

# Generated at 2022-06-26 13:48:01.121318
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    # There should be no exception raised.
    try:
        x_attr_metadata_p_p_0.run(x_attr_metadata_p_p_0)
    except Exception:
        assert False
#
# main()
#

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 13:48:03.614316
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(x_attr_metadata_p_p_0)

# Generated at 2022-06-26 13:48:05.030297
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    print(XAttrMetadataPP().run(XAttrMetadataPP()))

# Generated at 2022-06-26 13:48:09.974211
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    if (x_attr_metadata_p_p_0.run([])):
        raise "AssertionError"
if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:48:16.855708
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(x_attr_metadata_p_p_0)

    # assert var_0 == []  # TODO - Check if this is not a test case, remove ?
    # assert var_0 == {}  # TODO - Check if this is not a test case, remove ?



# Generated at 2022-06-26 13:49:43.931122
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p = XAttrMetadataPP()
    assert(not None)


# Generated at 2022-06-26 13:49:47.171896
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    print('Class XAttrMetadataPP = ', XAttrMetadataPP)
    print('x_attr_metadata_p_p_0 = ', x_attr_metadata_p_p_0)


# Generated at 2022-06-26 13:49:47.993557
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    assert True


# Generated at 2022-06-26 13:49:50.511667
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p = XAttrMetadataPP()


# Generated at 2022-06-26 13:49:52.248550
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    return test_case_0()


if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:49:54.459204
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    filename = ""
    assert XAttrMetadataPP() != None


# Generated at 2022-06-26 13:49:58.082210
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    var_1 = downloader
    x_attr_metadata_p_p_0 = XAttrMetadataPP(var_1)
    var_2 = info
    tuple_0 = x_attr_metadata_p_p_0.run(var_2)
    
    

# Generated at 2022-06-26 13:49:58.973683
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()

# Generated at 2022-06-26 13:50:03.033080
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(x_attr_metadata_p_p_0)
    return var_0

# Generated at 2022-06-26 13:50:05.897467
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(x_attr_metadata_p_p_0)



# Generated at 2022-06-26 13:53:46.330530
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    return XAttrMetadataPP()


# Generated at 2022-06-26 13:53:50.122355
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(x_attr_metadata_p_p_0)


if __name__ == '__main__':
    test_case_0()
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:53:52.285611
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(x_attr_metadata_p_p_0)