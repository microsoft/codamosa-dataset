

# Generated at 2022-06-26 13:44:02.366527
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()
    print("Unit test for class XAttrMetadataPP done !")

# test_XAttrMetadataPP()

# Generated at 2022-06-26 13:44:03.724444
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert test_case_0() == None, 'Constructor failed.'


# Generated at 2022-06-26 13:44:06.335581
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_1 = XAttrMetadataPP()

    # call the function to test
    x_attr_metadata_p_p_1.run()


# Generated at 2022-06-26 13:44:07.666181
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass


# Generated at 2022-06-26 13:44:08.774806
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pass


# Generated at 2022-06-26 13:44:12.391984
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()


# Generated at 2022-06-26 13:44:15.812573
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

if __name__ == "__main__":
    print("You are running %s" % __file__)
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:44:20.729995
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    import sys

    filename = sys.argv[0]

    # Get XAttrMetadataPP

    # Test exception of function "run"
    try:
        x_attr_metadata_p_p_0.run({})
    except NotImplementedError:
        pass


if __name__ == '__main__':
    test_case_0()
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:44:27.533183
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from .common import PostProcessor
    from .xattr_metadata import XAttrMetadataPP
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert isinstance(x_attr_metadata_p_p_0, PostProcessor)


# Generated at 2022-06-26 13:44:28.941535
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert(XAttrMetadataPP)

# Generated at 2022-06-26 13:44:38.248967
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    tuple_0 = ()
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(tuple_0)

# Generated at 2022-06-26 13:44:41.572800
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    tuple_0 = ()
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    # check the type of the returned tuple
    assert isinstance(x_attr_metadata_p_p_0.run(tuple_0), tuple)

# Generated at 2022-06-26 13:44:50.905219
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    var_1 = True
    var_2 = True
    var_3 = True
    for var_4 in range(0, 100):
        var_1 = (var_1 and True)
        var_2 = (var_2 and True)
        var_3 = (var_3 and True)
        x_attr_metadata_p_p_1 = XAttrMetadataPP()
        tuple_1 = ()
        var_5 = x_attr_metadata_p_p_1.run(tuple_1)
        var_1 = (var_1 and True)
        var_2 = (var_2 and True)
        var_3 = (var_3 and True)
    assert var_1
    assert var_2
    assert var_3


# vim:sw=4:ts=4:et:

# Generated at 2022-06-26 13:44:55.384161
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    tuple_0 = ()
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(tuple_0)


# Generated at 2022-06-26 13:44:56.008620
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-26 13:44:59.255239
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    tuple_0 = ()
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(tuple_0)


# Generated at 2022-06-26 13:45:06.633050
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    filename = 'path/to/file'
    info = {
        'filepath': filename,
        'webpage_url': 'http://example.com',
        'title': 'Test video',
        'upload_date': '20170101',
        'description': 'Lorem ipsum dolor sit amet',
        'uploader': 'John Doe',
        'format': 'webm',
    }

# Generated at 2022-06-26 13:45:09.827413
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    tuple_0 = ()
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(tuple_0)

# Generated at 2022-06-26 13:45:12.326267
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    tuple_0 = ()
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(tuple_0)

# Generated at 2022-06-26 13:45:15.332466
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    tuple_0 = ()
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(tuple_0)

if __name__ == '__main__':
    test_case_0()
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:45:27.976462
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    tuple_0 = ()
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(tuple_0)
    #  _downloader = self._downloader
    assert False

# Generated at 2022-06-26 13:45:38.295759
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # Test case where the assertion fails
    # Input parameters: info
    # Expected output: AssertionError
    # Actual output: AssertionError
    tuple_0 = ()
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(tuple_0)

    # Test case where the assertion passes
    # Input parameters: infos
    # Expected output: AssertionError
    # Actual output: AssertionError
    hyphenate_date_0 = 'hyphenate_date'
    XAttrMetadataPP_run_info_0 = hyphenate_date_0
    tuple_1 = (XAttrMetadataPP_run_info_0)
    x_attr_metadata_p_p_1

# Generated at 2022-06-26 13:45:41.086943
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    tuple_0 = ()
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(tuple_0)
    return x_attr_metadata_p_p_0

print(test_XAttrMetadataPP())

# Generated at 2022-06-26 13:45:43.011800
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    return x_attr_metadata_p_p_0


# Generated at 2022-06-26 13:45:45.098364
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

if __name__ == "__main__":
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:45:48.880401
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()
    test_case_0()

if __name__ == '__main__':
    test_XAttrMetadataPP()

# test_XAttrMetadataPP()

# Generated at 2022-06-26 13:45:59.400508
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    tuple_1 = ()
    x_attr_metadata_p_p_1 = XAttrMetadataPP()
    var_1 = x_attr_metadata_p_p_1.run(tuple_1)
    assert_equals(var_1, ([], tuple_1))

    tuple_2 = (('filepath', 'test0.mp4'),)
    x_attr_metadata_p_p_2 = XAttrMetadataPP()
    var_2 = x_attr_metadata_p_p_2.run(tuple_2)
    assert_equals(var_2, ([], tuple_2))


# Generated at 2022-06-26 13:46:01.582373
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    obj = XAttrMetadataPP()
    # call run
    test_case_0()
    assert obj is not None
    assert obj._downloader is None


# test_XAttrMetadataPP()

# Generated at 2022-06-26 13:46:06.231497
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    tuple_0 = ()
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0.run(tuple_0) == ([], ())
    assert x_attr_metadata_p_p_0.run(tuple_0) == ([], ())

# Generated at 2022-06-26 13:46:11.456734
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()

    # Assert x_attr_metadata_p_p_0 to be instance of class XAttrMetadataPP
    assert isinstance(x_attr_metadata_p_p_0, XAttrMetadataPP)

# Generated at 2022-06-26 13:46:35.084821
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    tuple_0 = ()
    var_0 = x_attr_metadata_p_p_0.run(tuple_0)


if __name__ == '__main__':
    print (test_case_0())
    print (test_XAttrMetadataPP_run())

# Generated at 2022-06-26 13:46:38.981716
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    tuple_0 = ()
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    x_attr_metadata_p_p_0.run(tuple_0)


if __name__ == "__main__":
    test_case_0()
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:46:45.458904
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    """ Unit test for XAttrMetadataPP.__init__ """
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    if __name__ == '__main__':
        test_case_0()

if __name__ == '__main__':
    # Unit test for constructor of class XAttrMetadataPP
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:46:50.135199
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    tuple_0 = ()
    tuple_1 = (None,)
    tuple_2 = (tuple_1,)
    var_0 = x_attr_metadata_p_p_0.run(tuple_0)
    assert var_0 == tuple_2
    assert tuple_0 == ()


# Generated at 2022-06-26 13:46:54.417052
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # Save current and restore later
    old_f = XAttrMetadataPP.run
    XAttrMetadataPP.run = lambda *args: None
    XAttrMetadataPP.run("")
    # Restore
    XAttrMetadataPP.run = old_f


if __name__ == '__main__':
    test_case_0()
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:46:57.174527
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import io
    import contextlib
    
    with contextlib.redirect_stdout(io.StringIO()):
        test_case_0()

# Generated at 2022-06-26 13:46:59.355413
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass


if __name__ == "__main__":
    test_case_0()
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:47:02.367160
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    tuple_0 = ()
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(tuple_0)

# Generated at 2022-06-26 13:47:07.233562
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    tuple_0 = ()
    assert x_attr_metadata_p_p_0.run(tuple_0) == ([], ())
    return "x_attr_metadata_p_p_0.run(tuple_0)"

# Generated by test.py
# test.py file is part of youtube-dl

# Generated at 2022-06-26 13:47:11.664193
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    tuple_0 = ()
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    x_attr_metadata_p_p_0.run(tuple_0)
    print("Testing finished")

test_case_0()
test_XAttrMetadataPP()

# Generated at 2022-06-26 13:47:55.487827
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    tuple_0 = ()
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    try:
        var_0 = x_attr_metadata_p_p_0.run(tuple_0)
    except Exception as e:
        print(e)

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:47:57.217284
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert True # TODO: implement your test here


# Generated at 2022-06-26 13:48:00.747975
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert hasattr(x_attr_metadata_p_p_0, 'downloader')
    assert hasattr(x_attr_metadata_p_p_0, '_downloader')


# Generated at 2022-06-26 13:48:01.416094
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP() != None


# Generated at 2022-06-26 13:48:04.180108
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    tuple_0 = ()
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(tuple_0)

test_case_0()

# Generated at 2022-06-26 13:48:07.884395
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    tuple_0 = ()
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(tuple_0)
    assert var_0 == ((), ())

# Generated at 2022-06-26 13:48:11.936771
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    tuple_0 = ()
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(tuple_0)


# Generated at 2022-06-26 13:48:12.946585
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()


# Generated at 2022-06-26 13:48:15.481765
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    assert True == True

if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:48:18.943918
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    tuple_0 = ()
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert_equals(type(x_attr_metadata_p_p_0), XAttrMetadataPP)


# Generated at 2022-06-26 13:49:45.212984
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    tuple_0 = {}
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(tuple_0)
    assert var_0[0] == []
    assert var_0[1] == {}

# if __name__ == '__main__':
#     test_XAttrMetadataPP_run()
#     test_case_0()
#     print('Tests finished')

# Generated at 2022-06-26 13:49:53.145960
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    tuple_0 = ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '')
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(tuple_0)
    # Used if no error is raised
    assert var_0 == ([], tuple_0)

# Generated at 2022-06-26 13:49:57.666030
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    tuple_0 = ()
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(tuple_0)


if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:50:03.304703
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p = XAttrMetadataPP()
    assert isinstance(x_attr_metadata_p_p, XAttrMetadataPP) == True
    #Test if function 'run' returns empty list and dictionary.
    assert x_attr_metadata_p_p.run(dict()) == ([], dict())
    test_case_0()

# Generated at 2022-06-26 13:50:07.413252
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    tuple_0 = ()
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert (x_attr_metadata_p_p_0.run(tuple_0) == ([], ()), "Return value of method run of class XAttrMetadataPP is not as expected")

# End of test for method run of class XAttrMetadataPP


# Generated at 2022-06-26 13:50:09.007001
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p = XAttrMetadataPP()


# Generated at 2022-06-26 13:50:11.615368
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0 is not None


# Generated at 2022-06-26 13:50:15.450973
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    tuple_0 = ()
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    x_attr_metadata_p_p_0.run(tuple_0)


    return 0


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 13:50:18.963588
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # constructor test
    try:
        XAttrMetadataPP()
    except NameError:
        assert False
        print('NameError')

if __name__ == '__main__':
    test_case_0()
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:50:24.605467
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    xattr_mapping = {
        'user.xdg.referrer.url': 'webpage_url',
        # 'user.xdg.comment':            'description',
        'user.dublincore.title': 'title',
        'user.dublincore.date': 'upload_date',
        'user.dublincore.description': 'description',
        'user.dublincore.contributor': 'uploader',
        'user.dublincore.format': 'format',
    }

    tuple_0 = ()
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(tuple_0)
