

# Generated at 2022-06-26 13:44:02.686190
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p = XAttrMetadataPP()
    assert x_attr_metadata_p_p is not None, 'Failed to create XAttrMetadataPP object'


# Generated at 2022-06-26 13:44:04.247431
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
	test_case_0()

test_XAttrMetadataPP()

# Generated at 2022-06-26 13:44:05.655332
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()


# Generated at 2022-06-26 13:44:06.992660
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert isinstance(XAttrMetadataPP(), XAttrMetadataPP)

# Generated at 2022-06-26 13:44:09.681994
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()


if __name__ == '__main__':
    test_case_0()
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:44:19.256604
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    #
    # Log in into youtube
    #
    # Check xattrs are not enabled
    #
    # Enable xattrs
    #
    # Download https://www.youtube.com/watch?v=Pjf2DE0l0j4
    #   (http://www.youtube.com/watch?v=18Kj3qWZ7vc&autoplay=1)
    #
    # Check xattrs are enabled
    #

    # Check xattrs are enabled
    #

    # Show xattrs

    assert False

#
#
#


# Generated at 2022-06-26 13:44:31.618153
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    info_0 = {}
    # copied from test_run of YoutubeDL
    info_0['filepath'] = 'dummy_file_name'
    info_0['format'] = 'dummy_format'
    info_0['title'] = 'dummy_title'
    info_0['description'] = 'dummy_description'
    info_0['upload_date'] = 'dummy_upload_date'
    info_0['uploader'] = 'dummy_uploader'
    info_0['webpage_url'] = 'dummy_webpage_url'
    assert x_attr_metadata_p_p_0.run(info_0) == ([], info_0)

# Generated at 2022-06-26 13:44:35.702424
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    filepath_0 = 'test_filepath'
    post_processors_0 = []
    _downloader_0 = object()
    x_attr_metadata_p_p_0 = XAttrMetadataPP(filepath_0, post_processors_0, _downloader_0)
    assert True


# Generated at 2022-06-26 13:44:39.084883
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP


if __name__ == '__main__':
    test_case_0()
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:44:47.797452
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0.embedder is None
    assert x_attr_metadata_p_p_0.embedder_preferred_format is None
    assert x_attr_metadata_p_p_0._downloader is None
    assert x_attr_metadata_p_p_0.executable == 'exiftool'
    assert x_attr_metadata_p_p_0.get_basename() == 'metadata'
    assert x_attr_metadata_p_p_0.get_config() == {}
    assert x_attr_metadata_p_p_0.get_config_hook() == {}
    assert x_attr_metadata_p_p_0.get_metadata() == {}
    x_attr

# Generated at 2022-06-26 13:44:54.249191
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP() is not None

# Generated at 2022-06-26 13:44:56.685600
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()

    assert x_attr_metadata_p_p_0 is not None


# Generated at 2022-06-26 13:45:05.031110
# Unit test for method run of class XAttrMetadataPP

# Generated at 2022-06-26 13:45:08.524503
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    #
    # If xattr is not available, print an error
    #
    test_case_0()

    #
    # If xattr is available, write metadata to the file's xattrs
    #
    test_case_0()

# Generated at 2022-06-26 13:45:12.170292
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    file_0 = open("XAttrMetadataPP.txt","r")
    num_0 = 0
    num_0 = int(file_0.readline())
    while num_0 > 0:
        num_0 -= 1
        test_case_0()

test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:45:12.681925
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-26 13:45:17.687775
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # test the constructor of the class
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    # validate the class variables
    assert x_attr_metadata_p_p_0.last_downloader == None
    assert x_attr_metadata_p_p_0.get_output_template() == None



# Generated at 2022-06-26 13:45:21.204674
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0

#
# Test cases for the auxiliary functions in this module
#

# Test case for "run" function

# Generated at 2022-06-26 13:45:22.664830
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    print("Testing method run of class XAttrMetadataPP\n")
    test_case_0()


# Generated at 2022-06-26 13:45:24.560219
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    info = {}

    assert x_attr_metadata_p_p_0.run(info) == ([], info)

# Generated at 2022-06-26 13:45:36.338290
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()


if __name__ == '__main__':
    print("Testing main method")
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:45:40.225062
# Unit test for method run of class XAttrMetadataPP

# Generated at 2022-06-26 13:45:41.572186
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()

# Generated at 2022-06-26 13:45:42.738004
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert True

test_case_0()
test_XAttrMetadataPP()

# Generated at 2022-06-26 13:45:43.914180
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    assert test_case_0() == 0

# Generated at 2022-06-26 13:45:45.003623
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    return XAttrMetadataPP().run(None)

# Generated at 2022-06-26 13:45:47.732431
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()


# Generated at 2022-06-26 13:45:50.138194
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()


if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:45:55.613401
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert 'XAttrMetadataPP' in globals(), "Class XAttrMetadataPP is not defined"
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0.run(None) is None
    assert test_case_0() is None

test_XAttrMetadataPP()

# Generated at 2022-06-26 13:45:58.276900
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert (x_attr_metadata_p_p_0.preferredorder == 0)


# Generated at 2022-06-26 13:46:17.712107
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()


# Generated at 2022-06-26 13:46:18.695376
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()

# Generated at 2022-06-26 13:46:20.675786
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    var_0 = XAttrMetadataPP()
    int_0 = None
    var_0.run(int_0)


# Generated at 2022-06-26 13:46:22.247757
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    print('test_XAttrMetadataPP_run')
    test_case_0()
    return



# Generated at 2022-06-26 13:46:23.759228
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()


# Generated at 2022-06-26 13:46:25.245790
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()


# Generated at 2022-06-26 13:46:27.573484
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    int_0 = {}
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(int_0)


# Generated at 2022-06-26 13:46:30.450420
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        assert False

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:46:31.374687
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()

# Generated at 2022-06-26 13:46:33.136817
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_1 = XAttrMetadataPP()
    assert True


# Generated at 2022-06-26 13:47:10.603233
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    assert True

# Generated at 2022-06-26 13:47:11.545080
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()

# Generated at 2022-06-26 13:47:12.979268
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    var_0 = XAttrMetadataPP()
    var_1 = {}
    var_2 = var_0.run(var_1)


# Test program

# Generated at 2022-06-26 13:47:14.134652
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert x_attr_metadata_p_p_0 is not None

# Generated at 2022-06-26 13:47:15.512402
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    assert True == True

if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:47:15.962317
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()

# Generated at 2022-06-26 13:47:18.925781
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    #  Creates an instance of the XAttrMetadataPP class
    x_attr_metadata_p_p_0 = XAttrMetadataPP()

    #  Runs the instance's run() method
    x_attr_metadata_p_p_0.run(None)

if __name__ == '__main__':
    test_XAttrMetadataPP()
    test_case_0()

# Generated at 2022-06-26 13:47:20.249455
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    print('Unit test for method run of class XAttrMetadataPP')
    test_case_0()

if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:47:23.337647
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    file_0 = None
    int_0 = x_attr_metadata_p_p_0.run(file_0)
    return None


# Generated at 2022-06-26 13:47:24.181331
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()

# Generated at 2022-06-26 13:48:38.932288
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()


# Generated at 2022-06-26 13:48:46.346789
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # This is the value we will get when we call the run method.
    # In order to test this method we will have to mock it.
    run_return = []
    # Create the mock and set a side effect on the run
    # method so that whenever the run method is called
    # it will return run_return.
    x_attr_metadata_p_p_mock = mock.MagicMock()
    x_attr_metadata_p_p_mock.run = mock.MagicMock(return_value=run_return)
    case_1 = XAttrMetadataPP()
    # Compare if the return value of the constructor
    # is equal to the mock
    assert_equals(case_1, x_attr_metadata_p_p_mock)

# Generated at 2022-06-26 13:48:48.153594
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    print('Executing test_XAttrMetadataPP_run')
    test_case_0()

# Old style class - just used for quick unittest

# Generated at 2022-06-26 13:48:49.491786
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()


if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:48:50.124961
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    assert True, 'not implemented'

# Generated at 2022-06-26 13:48:55.273940
# Unit test for method run of class XAttrMetadataPP

# Generated at 2022-06-26 13:48:56.821065
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:48:57.714774
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    assert (test_case_0())

# Generated at 2022-06-26 13:48:58.734032
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    assert true


# Generated at 2022-06-26 13:49:01.102530
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

#
# Code for unit testing this module
#
if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:51:57.756598
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_test = XAttrMetadataPP()


# Generated at 2022-06-26 13:52:01.735147
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    int_0 = None
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert isinstance(x_attr_metadata_p_p_0, XAttrMetadataPP)
    test_case_0()
    test_XAttrMetadataPP()

if __name__ == '__main__':
    # test_XAttrMetadataPP()
    pass

# Generated at 2022-06-26 13:52:03.434886
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert test_case_0


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 13:52:06.131544
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    # Case #0
    test_case_0()

    # Case #1
    # Missing argument 'info'

    # Case #2
    # Non-existent argument 'infoo'


# Generated at 2022-06-26 13:52:06.846404
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()

# Generated at 2022-06-26 13:52:07.829236
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_XAttrMetadataPP_0 = test_case_0()
    return True

# Generated at 2022-06-26 13:52:08.714097
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()


# Generated at 2022-06-26 13:52:17.173565
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # Implement a method that tests if XAttrMetadataPP is working correctly

    # Write your test case here
    int_0 = None
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(int_0)
    print(var_0)
    # If you want to see the test case
    return var_0

test_XAttrMetadataPP_run()
# # C:\Users\zachary\AppData\Local\Programs\Python\Python37-32\lib\site-packages\youtube_dl\postprocessor\metadatafromtitle.py
# #!/usr/bin/env python
# # encoding: utf-8
#
# # The MIT License (MIT)
#
# # Copyright (c) 2018 CN

# Generated at 2022-06-26 13:52:19.258432
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    print(x_attr_metadata_p_p_0)
    print('Running test_case_0...')
    test_ca

# Generated at 2022-06-26 13:52:21.457286
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    int_0 = None

    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(int_0)

