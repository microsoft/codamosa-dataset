

# Generated at 2022-06-26 13:44:07.799212
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    print("Testing constructor of class XAttrMetadataPP")

# Generated at 2022-06-26 13:44:14.986075
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # TODO: use temp directory in tests
    # Create a file and write to xattr
    filename_0 = "./xattr_test.txt"
    with open(filename_0, 'w') as file_0:
        file_0.write("Test file for XAttrMetadataPP")

    write_xattr(filename_0, 'user.xdg.referrer.url', 'https://www.youtube.com/watch?v=dQw4w9WgXcQ')
    write_xattr(filename_0, 'user.xdg.comment', 'This is a test Description')
    write_xattr(filename_0, 'user.dublincore.title', 'RickRolled')

# Generated at 2022-06-26 13:44:19.387837
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    info_0 = {}
    x_attr_metadata_p_p_0.run(info_0)

# Generated at 2022-06-26 13:44:24.182328
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert isinstance(x_attr_metadata_p_p_0,XAttrMetadataPP)


# Generated at 2022-06-26 13:44:25.585150
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert callable(XAttrMetadataPP)
    assert isinstance(XAttrMetadataPP(), PostProcessor)


# Generated at 2022-06-26 13:44:29.290865
# Unit test for constructor of class XAttrMetadataPP

# Generated at 2022-06-26 13:44:35.856741
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_1 = XAttrMetadataPP()
    if x_attr_metadata_p_p_1 is None:
        print("Object x_attr_metadata_p_p_1 is None.")

    else:
        print("Object x_attr_metadata_p_p_1 is None.")

# Generated at 2022-06-26 13:44:45.696666
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    info_0_map = {
        'upload_date': '20120616',
        'webpage_url': 'http://www.youtube.com/watch?v=BPgEgaPk62M',
        'uploader': 'nigahiga',
        'format': '720p',
        'title': 'HOW TO BE GANGSTER',
        '_filename': 'HOW TO BE GANGSTER.mp4',
        'description': "I'm bringing gangster back. Sorry you guys, I had to.\n\nTHUMBS UP FOR MORE HOW TO BE..."
    }

# Generated at 2022-06-26 13:44:46.655000
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()


# Generated at 2022-06-26 13:44:49.269078
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_pp = XAttrMetadataPP()
    assert isinstance(x_attr_metadata_pp, XAttrMetadataPP)


# Generated at 2022-06-26 13:45:01.758151
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    x_attr_metadata_p_p_0.run()


# Generated at 2022-06-26 13:45:04.081904
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p = XAttrMetadataPP()
    assert x_attr_metadata_p_p is not None

# Generated at 2022-06-26 13:45:08.194927
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    info_dict_0 = {}
    list_of_str_0, info_dict_1 = x_attr_metadata_p_p_0.run(info_dict_0)

# Generated at 2022-06-26 13:45:11.074152
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    print(x_attr_metadata_p_p_0)
    print(x_attr_metadata_p_p_0._downloader)

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:45:12.168919
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()

# Generated at 2022-06-26 13:45:13.056576
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert True


# Generated at 2022-06-26 13:45:20.278927
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    info = {'format': 'webm', 'webpage_url': 'https://www.youtube.com/watch?v=a1Y73sPHKxw', 'title': 'WebM video', 'filepath': './downloads/WebM-video.webm', 'description': 'This is a sample WebM Video'}
    x_attr_metadata_p_p_0.run(info)

# Generated at 2022-06-26 13:45:25.340540
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    info = {'webpage_url': 'http://www.domain.com/path/to/video.mp4', 'title': 'video title', 'upload_date': '20160726', 'description': 'video description', 'uploader': 'uploader', 'format': 'video format'}
    [], info = x_attr_metadata_p_p_0.run(info)



# Generated at 2022-06-26 13:45:27.505188
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert(isinstance(XAttrMetadataPP(), XAttrMetadataPP))

if __name__ == "__main__":
    test_case_0()
    test_XAttrMetadataPP()

# Generated at 2022-06-26 13:45:28.591730
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    assert callable(XAttrMetadataPP.run)

# Generated at 2022-06-26 13:45:39.651038
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()

# Generated at 2022-06-26 13:45:45.222449
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    try:
        x_attr_metadata_p_p_0 = XAttrMetadataPP()
    except Exception:
        print("Constructor of class XAttrMetadataPP failed.")
        var_0 = True
    else:
        var_0 = False
        # Test for raising of an exception when called with a bool (boolean)
        var_1 = True
        try:
            x_attr_metadata_p_p_0.run(var_1)
        except Exception:
            var_1 = False
        else:
            raise AssertionError("failed to raise Exception")
        assert (not var_1)
        # Test for raising of an exception when called with a bool (boolean)
        var_1 = True

# Generated at 2022-06-26 13:45:47.594705
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    assert True # TODO: implement your test here


# Generated at 2022-06-26 13:45:48.493267
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()

# Generated at 2022-06-26 13:45:53.344262
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert (isinstance(x_attr_metadata_p_p_0._downloader, type(None)))
    assert (x_attr_metadata_p_p_0.name == 'FFmpegMetadataPP')


# Generated at 2022-06-26 13:45:58.623468
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    bool_var_0 = False
    x_attr_metadata_p_p = XAttrMetadataPP()
    tuple_var_0 = x_attr_metadata_p_p.run(bool_var_0)
    # Assertion: test_XAttrMetadataPP.test_XAttrMetadataPP_run
    assert tuple_var_0 == ([], False)



# Generated at 2022-06-26 13:46:00.302985
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()

# End of test case #0

test_case_0()

# Generated at 2022-06-26 13:46:05.757549
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    str_0 = '/home/dave/Downloads'
    str_1 = 'https://www.youtube.com/watch?v=BaW_jenozKc'
    str_2 = 'test'
    str_3 = 'webpage_url'
    str_4 = 'BaW_jenozKc'
    str_5 = 'title'
    str_6 = 'upload_date'
    str_7 = 'description'
    str_8 = 'uploader'
    str_9 = 'format'
    str_10 = 'user.xdg.referrer.url'
    str_11 = 'user.dublincore.date'
    str_12 = 'user.dublincore.description'


# Generated at 2022-06-26 13:46:07.714304
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()
    
if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:46:09.867081
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

# Generated at 2022-06-26 13:46:30.936686
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert True == True


# Generated at 2022-06-26 13:46:33.805466
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    bool_0 = False
    var_0 = x_attr_metadata_p_p_0.run(bool_0)

# Generated at 2022-06-26 13:46:35.773272
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()


# Generated at 2022-06-26 13:46:36.449314
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

# Generated at 2022-06-26 13:46:38.806772
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    bool_0 = True
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(bool_0)

# Generated at 2022-06-26 13:46:39.986564
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    assert test_case_0() is None

# Generated at 2022-06-26 13:46:41.806877
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()
# End of unit test for method run of class XAttrMetadataPP

# Generated at 2022-06-26 13:46:43.377591
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()

# Generated at 2022-06-26 13:46:45.115418
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

test_XAttrMetadataPP()

# Generated at 2022-06-26 13:46:47.470747
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    x_attr_metadata_p_p_0.run(None)



# Generated at 2022-06-26 13:47:28.876586
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert callable(XAttrMetadataPP)


# Generated at 2022-06-26 13:47:37.807340
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    message = "Test Case : Error"
    _test_case_0 = test_case_0()
    info_var = XAttrMetadataPP().run()
    filename_var = info_var['filepath']
    bool_var = False
    if info_var['title']:
        bool_var = True
    elif info_var['upload_date']:
        bool_var = True
    elif info_var['uploader']:
        bool_var = True
    elif info_var['webpage_url']:
        bool_var = True
    elif info_var['format']:
        bool_var = True

    if test_case_0() == (info_var, filename_var) or bool_var:
        message = "Test Case : Passed"
    print(message)

test_X

# Generated at 2022-06-26 13:47:38.620670
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0();

# Generated at 2022-06-26 13:47:40.268309
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    var = XAttrMetadataPP()
    var.run()


# Generated at 2022-06-26 13:47:42.663081
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    bool_0 = False
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(bool_0)

# Generated at 2022-06-26 13:47:45.391337
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    bool_0 = False
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    var_0 = x_attr_metadata_p_p_0.run(bool_0)



# Generated at 2022-06-26 13:47:46.843339
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

# Generated at 2022-06-26 13:47:51.237375
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    bool_0 = False
    var_0 = x_attr_metadata_p_p_0.run(bool_0)

test_case_0()
test_XAttrMetadataPP_run()

# vim:sw=4:ts=4:et:

# Generated at 2022-06-26 13:47:51.775341
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-26 13:47:53.822716
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    """Check if function run raises exceptions"""
    test_case_0()

test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:49:19.267793
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    bool_0 = False
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    bool_1 = False
    var_0 = x_attr_metadata_p_p_0.run(bool_1)

# Test for ai_0 = ai_1

# Generated at 2022-06-26 13:49:21.447487
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p = XAttrMetadataPP()
    assert x_attr_metadata_p_p
    assert x_attr_metadata_p_p.run()

# Generated at 2022-06-26 13:49:23.081671
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    var_0 = XAttrMetadataPP()
    bool_0 = False
    var_0.run(bool_0)


# Generated at 2022-06-26 13:49:33.017770
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    print('Testing method run of class XAttrMetadataPP')
    print()
    test_cases = [
        {
            'inputs': {
                'info': {}
            },
            'assertEqual': {
                'expected_return': [],
                'expected_info': {}
            }
        }
    ]
    for i, test_case in enumerate(test_cases):
        print('Case {}:'.format(i))
        x_attr_metadata_p_p = XAttrMetadataPP()
        return_value, info = x_attr_metadata_p_p.run(
            **test_case['inputs'])

# Generated at 2022-06-26 13:49:38.947377
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    TEST_CASES = [
        (0,),
    ]

    for index, test_case in enumerate(TEST_CASES):
        test_case_0(*test_case)
        print("[ OK ] Test #%d(%r)" % (index, test_case))


if __name__ == '__main__':
    import sys

    if len(sys.argv) > 1:  # some test specified
        for test_index in sys.argv[1:]:
            print("[ RUN ] Test #%s" % test_index)
            globals()["test_%s" % test_index]()
            print("[ OK ] Test #%s" % test_index)
            print("=" * 50)

    else:  # run all tests
        test_XAttrMetadataPP_

# Generated at 2022-06-26 13:49:40.325566
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pass


# Generated at 2022-06-26 13:49:43.931024
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from .common import PostProcessor
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert isinstance(x_attr_metadata_p_p_0, PostProcessor)


# Generated at 2022-06-26 13:49:44.754196
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

# Generated at 2022-06-26 13:49:45.826668
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert callable(XAttrMetadataPP)



# Generated at 2022-06-26 13:49:48.953743
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    x_attr_metadata_p_p_0.run(True)

test_XAttrMetadataPP_run()

# Generated at 2022-06-26 13:53:18.925641
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()

# Generated at 2022-06-26 13:53:19.710676
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_case_0()

# Generated at 2022-06-26 13:53:20.789361
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_1 = XAttrMetadataPP()


# Generated at 2022-06-26 13:53:22.700609
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert isinstance(x_attr_metadata_p_p_0, XAttrMetadataPP) == True


# Generated at 2022-06-26 13:53:24.187934
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()


# Generated at 2022-06-26 13:53:25.554064
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()



# Generated at 2022-06-26 13:53:29.306965
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr_metadata_p_p_0 = XAttrMetadataPP()
    assert isinstance(x_attr_metadata_p_p_0, XAttrMetadataPP)
    return


# Unit test with coverage

# Generated at 2022-06-26 13:53:37.234717
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .common import FakeYDL
    from .common import FakeInfoExtractor

    ie = FakeInfoExtractor()
    ydl = FakeYDL()

    xattrs_metadata_pp = XAttrMetadataPP()

    # Test 1: fake filepath
    filepath = './file1'
    info = {'filepath': filepath}

    # Test 2: fake xattr
    xattr_name = 'user.xdg.referrer.url'
    xattr_value = 'http://localhost'
    info[xattr_name] = xattr_value

    # Test 3: fake xattr
    xattr_name = 'user.dublincore.title'
    xattr_value = 'Dummy title'
    info[xattr_name] = xattr_value

    # Test 4: fake x

# Generated at 2022-06-26 13:53:39.295766
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    print("Test case for class constructor XAttrMetadataPP")
    print("===== Test case 0 =====")
    test_case_0()


# Generated at 2022-06-26 13:53:40.212402
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    test_case_0()