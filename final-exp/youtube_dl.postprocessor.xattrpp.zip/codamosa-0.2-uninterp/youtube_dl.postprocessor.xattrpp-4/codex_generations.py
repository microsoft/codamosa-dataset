

# Generated at 2022-06-18 15:48:01.741043
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..downloader import Downloader
    from ..extractor import YoutubeIE
    from ..utils import DateRange
    from ..compat import compat_str

    dl = Downloader()
    dl.add_info_extractor(YoutubeIE())

    # Test with a single video
    dl.params['usenetrc'] = False
    dl.params['username'] = None
    dl.params['password'] = None
    dl.params['videopassword'] = None
    dl.params['quiet'] = True
    dl.params['forcetitle'] = True
    dl.params['forceid'] = True
    dl.params['forcethumbnail'] = True
    dl.params['forcedescription'] = True
    dl.params['forceurl'] = True
    dl.params

# Generated at 2022-06-18 15:48:03.161458
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP()
    assert pp.run(None) == ([], None)

# Generated at 2022-06-18 15:48:12.489782
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import encodeFilename
    from ..extractor import gen_extractors
    from ..downloader import Downloader
    from ..postprocessor import FFmpegMetadataPP
    from ..compat import compat_os_name
    import os

    # Create a temporary file
    temp_file = encodeFilename(os.path.join(os.path.dirname(__file__), 'test.tmp'))
    with open(temp_file, 'wb') as f:
        f.write(b'foobar')

    # Create a downloader

# Generated at 2022-06-18 15:48:25.545693
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import encodeFilename
    from ..extractor import gen_extractors
    from ..compat import compat_os_name

    # Test for Windows
    if compat_os_name == 'nt':
        return

    # Test for Linux
    if compat_os_name == 'posix':
        # Test for xattr support
        try:
            import xattr
        except ImportError:
            return

    # Test for Mac OS X
    if compat_os_name == 'macos':
        # Test for xattr support
        try:
            import xattr
        except ImportError:
            return

    # Test for FreeBSD
    if compat_os_name == 'freebsd':
        # Test for xattr support
        try:
            import xattr
        except ImportError:
            return

    # Test for OpenBSD
   

# Generated at 2022-06-18 15:48:34.902676
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..downloader import Downloader
    from ..extractor import gen_extractors
    from ..utils import DateRange
    from ..compat import compat_str
    from ..compat import compat_urllib_request

    # Create a downloader
    dl = Downloader({})
    dl.add_info_extractor(gen_extractors()[0])

    # Create a postprocessor
    pp = XAttrMetadataPP(dl)

    # Create a test file
    f = open('test_xattr.txt', 'w')
    f.write('test')
    f.close()

    # Create a test info

# Generated at 2022-06-18 15:48:44.976886
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor import YoutubeIE
    from ..downloader import FileDownloader
    from ..utils import DateRange

    # Test constructor
    XAttrMetadataPP(FileDownloader({}))

    # Test run()

# Generated at 2022-06-18 15:48:47.161197
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP()
    assert pp.run(None) == ([], None)

# Generated at 2022-06-18 15:48:58.464882
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import encodeFilename
    from ..compat import compat_os_name

    if compat_os_name == 'nt':
        return

    import tempfile
    import os
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    (fd, tmpfile) = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create a temporary file with a non-ascii name
    (fd, tmpfile_non_ascii) = tempfile.mkstemp(dir=tmpdir, prefix='Неascii_')
    os.close(fd)

    # Create a temporary file with a non-ascii name
    (fd, tmpfile_non_ascii_2) = tempfile.mk

# Generated at 2022-06-18 15:49:05.627250
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import DateRange

    ydl = gen_ydl()
    ydl.add_post_processor(XAttrMetadataPP())

    # Test with a single video
    ydl.params['nooverwrites'] = True
    ydl.params['writethumbnail'] = True
    ydl.params['writeinfojson'] = True
    ydl.params['writedescription'] = True
    ydl.params['writeannotations'] = True
    ydl.params['writeautomaticsub'] = True
    ydl.params['writesubtitles'] = True
    ydl.params['write_all_thumbnails'] = True
    ydl.params['write_all_metadata'] = True
    ydl.params

# Generated at 2022-06-18 15:49:07.303914
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP()
    assert pp.run({}) == ([], {})

# Generated at 2022-06-18 15:49:20.969684
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..downloader import Downloader
    from ..extractor import YoutubeIE
    from ..utils import DateRange
    from ..compat import compat_str

    # Test with a video that has no upload date

# Generated at 2022-06-18 15:49:33.546807
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..downloader import YoutubeDL
    from ..extractor import YoutubeIE
    from ..utils import DateRange

    ydl = YoutubeDL({'writedescription': True, 'writeinfojson': True})
    ie = YoutubeIE(ydl)

# Generated at 2022-06-18 15:49:35.341063
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP()
    assert pp is not None

# Generated at 2022-06-18 15:49:45.497727
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import DateRange
    from ..compat import compat_str

    # Construct a downloader object
    ydl = gen_ydl()
    ydl.add_post_processor(XAttrMetadataPP())

    # Construct a fake info dict

# Generated at 2022-06-18 15:49:58.012436
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import DateRange

    # Test constructor
    ydl = gen_ydl()
    ydl.add_post_processor(XAttrMetadataPP())

    # Test constructor with non-default options
    ydl = gen_ydl()
    ydl.add_post_processor(XAttrMetadataPP())

    # Test constructor with non-default options
    ydl = gen_ydl()
    ydl.add_post_processor(XAttrMetadataPP())

    # Test constructor with non-default options
    ydl = gen_ydl()
    ydl.add_post_processor(XAttrMetadataPP())

    # Test constructor with non-default options
    ydl = gen_ydl()
   

# Generated at 2022-06-18 15:50:08.553197
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor import YoutubeIE
    from ..downloader import FileDownloader
    from ..utils import DateRange
    from ..compat import compat_str

    # Create a FileDownloader instance

# Generated at 2022-06-18 15:50:19.162088
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..downloader import Downloader
    from ..extractor import YoutubeIE
    from ..utils import encodeFilename

    # Create a downloader
    dl = Downloader(params={})

    # Create an info dict

# Generated at 2022-06-18 15:50:30.238922
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..downloader import Downloader
    from ..extractor import YoutubeIE
    from ..utils import DateRange
    from ..compat import compat_str

    dl = Downloader()
    ie = YoutubeIE(dl)

    # Test with a simple video
    info = ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')
    pp = XAttrMetadataPP(dl)
    pp.run(info)

    # Test with a video with a date range
    info = ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')
    info['upload_date'] = DateRange(datetime.datetime(2012, 1, 1), datetime.datetime(2012, 12, 31))
    pp = XAttrMetadataPP(dl)

# Generated at 2022-06-18 15:50:36.738622
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os
    import tempfile
    import unittest

    from .common import FileDownloader
    from ..utils import (
        check_executable,
        encodeFilename,
        prepend_extension,
        xattr_supported,
    )

    class XAttrMetadataPPTest(unittest.TestCase):

        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.filename = os.path.join(self.tmpdir, 'test.mp4')
            self.fd = open(self.filename, 'wb')
            self.fd.write(b'foobar')
            self.fd.close()

        def tearDown(self):
            import shutil
            shutil.rmtree(self.tmpdir)


# Generated at 2022-06-18 15:50:45.514098
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..downloader import Downloader
    from ..extractor import YoutubeIE
    from ..utils import DateRange

    dl = Downloader()
    dl.add_info_extractor(YoutubeIE())
    dl.params['writethumbnail'] = True
    dl.params['writeinfojson'] = True
    dl.params['writedescription'] = True
    dl.params['writeannotations'] = True
    dl.params['writeautomaticsub'] = True
    dl.params['writesubtitles'] = True
    dl.params['write_all_thumbnails'] = True
    dl.params['outtmpl'] = '%(id)s.%(ext)s'
    dl.params['daterange'] = DateRange('20120101')

# Generated at 2022-06-18 15:51:00.540769
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import DateRange
    from ..compat import compat_str

    # Test constructor
    ydl = gen_ydl()
    ydl.add_post_processor(XAttrMetadataPP())

    # Test constructor with empty dict
    ydl = gen_ydl({})
    ydl.add_post_processor(XAttrMetadataPP())

    # Test constructor with empty list
    ydl = gen_ydl({'postprocessors': []})
    ydl.add_post_processor(XAttrMetadataPP())

    # Test constructor with empty list and empty dict
    ydl = gen_ydl({'postprocessors': [{}]})

# Generated at 2022-06-18 15:51:10.143618
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import DateRange

    # Create a downloader
    ydl = gen_ydl(params={'writedescription': True, 'writeinfojson': True, 'writethumbnail': True})
    ydl.add_post_processor(XAttrMetadataPP)

    # Create a fake info dict

# Generated at 2022-06-18 15:51:21.517679
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os
    import tempfile
    import shutil
    from ..utils import write_xattr
    from ..compat import compat_os_name

    if compat_os_name == 'nt':
        return

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    tmp_file = os.path.join(tmp_dir, 'test.txt')
    with open(tmp_file, 'w') as f:
        f.write('test')

    # Create a XAttrMetadataPP instance
    xattr_metadata_pp = XAttrMetadataPP()

    # Create a info dict

# Generated at 2022-06-18 15:51:32.531779
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import DateRange

    ydl = gen_ydl()
    ydl.add_post_processor(XAttrMetadataPP())

    # Test with a single video
    ydl.params['nooverwrites'] = True
    ydl.params['writethumbnail'] = True
    ydl.params['writeinfojson'] = True
    ydl.params['writedescription'] = True
    ydl.params['writeannotations'] = True
    ydl.params['writeautomaticsub'] = True
    ydl.params['writesubtitles'] = True
    ydl.params['write_all_thumbnails'] = True
    ydl.params['writethumbnail'] = True

# Generated at 2022-06-18 15:51:40.178819
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import DateRange

    # Create a downloader object
    ydl = gen_ydl()

    # Create an extractor object
    ie = gen_extractors(ydl)[0]

    # Create a postprocessor object
    pp = XAttrMetadataPP(ydl)

    # Test 1: Test the constructor

# Generated at 2022-06-18 15:51:40.822398
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-18 15:51:42.830371
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..downloader import Downloader
    d = Downloader()
    pp = XAttrMetadataPP(d)
    assert pp.downloader == d

# Generated at 2022-06-18 15:51:45.446795
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP()
    assert pp.run(None) == ([], None)

# Generated at 2022-06-18 15:51:52.733343
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import DateRange
    from ..compat import compat_str
    from ..compat import compat_urllib_request
    from ..compat import compat_urllib_error
    from ..compat import compat_urllib_parse
    from ..compat import compat_urlparse
    from ..compat import compat_os_path

    #
    # Test XAttrMetadataPP
    #

    # Test constructor
    xattr_pp = XAttrMetadataPP()

    # Test run()
    ydl = gen_ydl()
    ydl.add_post_processor(xattr_pp)

    # Test run() with a video
    ydl.params['noplaylist'] = True
    ydl

# Generated at 2022-06-18 15:52:04.098141
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..downloader import Downloader
    from ..extractor import YoutubeIE
    from ..utils import DateRange

    dl = Downloader()
    dl.add_info_extractor(YoutubeIE())
    dl.params['writethumbnail'] = True
    dl.params['writeinfojson'] = True
    dl.params['writedescription'] = True
    dl.params['writeannotations'] = True
    dl.params['writeautomaticsub'] = True
    dl.params['writesubtitles'] = True
    dl.params['write_all_thumbnails'] = True
    dl.params['outtmpl'] = '%(id)s'
    dl.params['usenetrc'] = False
    dl.params['username'] = None
    dl.params['password']

# Generated at 2022-06-18 15:52:33.834901
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..utils import DateRange
    from ..extractor import YoutubeIE
    from ..downloader import FileDownloader

    # Test with a Youtube video

# Generated at 2022-06-18 15:52:44.723210
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os
    import tempfile
    import shutil
    import unittest

    from ..utils import write_xattr, XAttrMetadataError

    class XAttrMetadataPP_run_Test(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.filename = os.path.join(self.tempdir, 'test.mp4')
            with open(self.filename, 'wb') as f:
                f.write(b'\x00' * 1024)

        def tearDown(self):
            shutil.rmtree(self.tempdir)


# Generated at 2022-06-18 15:52:51.522184
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os
    from .common import FileDownloader
    from ..compat import compat_os_name
    from ..utils import (
        encodeFilename,
        prepend_extension,
    )

    if compat_os_name == 'nt':
        return

    # Create a temporary file
    fd, temp_filename = tempfile.mkstemp(prefix='ytdl_test_', suffix='.tmp')
    os.close(fd)

    # Create a FileDownloader
    ydl = FileDownloader({'outtmpl': temp_filename})

    # Create a XAttrMetadataPP
    pp = XAttrMetadataPP(ydl)

    # Test run method

# Generated at 2022-06-18 15:52:51.987551
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-18 15:53:00.116199
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import DateRange
    from ..compat import compat_str

    ydl = gen_ydl()
    ydl.add_post_processor(XAttrMetadataPP())
    ydl.params['writethumbnail'] = True
    ydl.params['writeinfojson'] = True
    ydl.params['writedescription'] = True
    ydl.params['writeannotations'] = True
    ydl.params['write_all_thumbnails'] = True
    ydl.params['writesubtitles'] = True
    ydl.params['writeautomaticsub'] = True
    ydl.params['allsubtitles'] = True
    ydl.params['subtitlesformat'] = 'srt'
    y

# Generated at 2022-06-18 15:53:08.206565
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import encodeFilename
    from ..extractor import gen_extractors
    from ..downloader import Downloader

    class FakeInfoExtractor(object):
        def __init__(self, ie_name):
            self._ie_name = ie_name

        def _real_initialize(self):
            pass

        def _real_extract(self, url):
            return {
                'id': 'test_id',
                'ext': 'mp4',
                'title': 'test_title',
                'uploader': 'test_uploader',
                'upload_date': '20120101',
                'description': 'test_description',
                'webpage_url': 'http://www.test.com/test_id',
                'format': 'test_format',
            }


# Generated at 2022-06-18 15:53:17.422930
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import DateRange
    from ..extractor import YoutubeIE
    from ..downloader.common import FileDownloader
    from ..compat import compat_str

    # Create a FileDownloader object
    fd = FileDownloader({
        'outtmpl': '%(id)s%(ext)s',
        'format': 'best',
        'nooverwrites': True,
        'noprogress': True,
        'quiet': True,
    })

    # Create a XAttrMetadataPP object
    xa = XAttrMetadataPP()

    # Test 1: Test on a video

# Generated at 2022-06-18 15:53:23.602897
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os
    import tempfile
    import shutil

    from .common import FileDownloader

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp(prefix='youtube-dl-test_XAttrMetadataPP_run-')

    # Create a temporary file
    temp_file = os.path.join(temp_dir, 'temp_file')
    with open(temp_file, 'w') as f:
        f.write('test')

    # Create a FileDownloader
    ydl = FileDownloader({'outtmpl': temp_file})

    # Create a XAttrMetadataPP
    pp = XAttrMetadataPP(ydl)

    # Test

# Generated at 2022-06-18 15:53:33.428980
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os
    import tempfile
    import shutil
    import xattr
    from .common import FileDownloader
    from ..extractor import gen_extractors
    from ..utils import DateRange

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create a temporary file
    tmp_file = os.path.join(tmp_dir, 'test.mp4')
    with open(tmp_file, 'w') as f:
        f.write('test')

    # Create a FileDownloader

# Generated at 2022-06-18 15:53:41.841990
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import tempfile
    import os
    import shutil
    import xattr
    import sys

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    temp_file.close()

    # Create a downloader
    downloader = DummyYDL()

    # Create a postprocessor
    pp = XAttrMetadataPP(downloader)

    # Create a fake info dict

# Generated at 2022-06-18 15:54:27.700871
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import encodeFilename
    from ..compat import compat_os_name

    if compat_os_name == 'nt':
        return

    import os
    import tempfile
    import xattr

    # Create a temporary file
    fd, filename = tempfile.mkstemp()
    os.close(fd)

    # Create a PostProcessor
    pp = XAttrMetadataPP()

    # Create a fake info dict

# Generated at 2022-06-18 15:54:38.681012
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import encodeFilename
    from .common import FileDownloader

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self['filepath'] = encodeFilename('test.mp4')

    info = FakeInfoDict({
        'webpage_url': 'http://www.youtube.com/watch?v=BaW_jenozKc',
        'title': 'Hitchhiker\'s Guide to the Galaxy',
        'upload_date': '20010115',
        'description': 'This is a fake description',
        'uploader': 'Douglas Adams',
        'format': 'fake format',
    })

    pp = XAttrMetadataPP(FileDownloader({}))


# Generated at 2022-06-18 15:54:47.811234
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import encodeFilename
    from ..compat import compat_os_name
    from .common import FileDownloader
    from .http import HttpFD
    from .http import HEADRequest
    from .http import HEADRequestException
    from .http import HEADNoSSLError
    from .http import HEADSSLError
    from .http import HEADNotFoundError
    from .http import HEADContentTooShortError
    from .http import HEADUnknownContentTypeError
    from .http import HEADUnknownServerError
    from .http import HEADUnknownUrlError
    from .http import HEADGeoRestrictedError
    from .http import HEADGeoRestrictedCountryError
    from .http import HEADGeoRestrictedServiceError
    from .http import HEADGeoRestrictedUnknownError
    from .http import HEADGeoRestrictedProxyError

# Generated at 2022-06-18 15:54:48.858457
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP(None).run({}) == ([], {})

# Generated at 2022-06-18 15:55:00.135889
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    import sys
    from ..downloader import Downloader
    from ..extractor import YoutubeIE
    from ..utils import DateRange
    from ..compat import compat_os_name

    if compat_os_name == 'nt':
        return

    # Create a downloader object
    ydl = Downloader({'outtmpl': '%(id)s%(ext)s'})

    # Create a fake extractor
    class FakeExtractor(object):
        IE_NAME = 'fake'
        def __init__(self, downloader):
            self.downloader = downloader

    # Set up a fake info dict

# Generated at 2022-06-18 15:55:06.906816
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor import YoutubeIE
    from ..downloader import FileDownloader
    from ..utils import DateRange
    from ..compat import compat_str

    # Test with a youtube video
    test_url = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    ie = YoutubeIE()
    info = ie.extract(test_url)

    # Test with a file downloader

# Generated at 2022-06-18 15:55:17.039619
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import DateRange
    from ..compat import compat_str

    ydl = gen_ydl()
    ydl.add_post_processor(XAttrMetadataPP())

    # Test with a single video
    ydl.params['nooverwrites'] = True
    ydl.params['writethumbnail'] = True
    ydl.params['writeinfojson'] = True
    ydl.params['writedescription'] = True
    ydl.params['writeannotations'] = True
    ydl.params['write_all_thumbnails'] = True
    ydl.params['write_subtitles'] = True
    ydl.params['writeautomaticsub'] = True

# Generated at 2022-06-18 15:55:24.703409
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import tempfile
    import os
    import shutil
    import sys
    from ..utils import write_xattr
    from ..compat import compat_os_name

    if compat_os_name == 'nt':
        return

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    (fd, filename) = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create a XAttrMetadataPP object
    xattr_metadata_pp = XAttrMetadataPP()

    # Create a downloader object
    downloader = object()
    downloader.to_screen = lambda x: sys.stderr.write(x + '\n')
    downloader.report_warning = lambda x: sys.stderr.write

# Generated at 2022-06-18 15:55:26.971904
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP()
    assert pp is not None

# Generated at 2022-06-18 15:55:37.570925
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..downloader import Downloader
    from ..extractor import YoutubeIE
    from ..utils import DateRange

    # Create a downloader
    ydl = Downloader()

    # Create a postprocessor
    pp = XAttrMetadataPP(ydl)

    # Create a YoutubeIE
    ie = YoutubeIE(ydl)

    # Create an info dict

# Generated at 2022-06-18 15:57:04.713572
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os
    import tempfile
    import shutil

    from .common import FileDownloader

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    temp_file.close()

    # Create a temporary file downloader
    ydl = FileDownloader({'outtmpl': temp_file.name})

    # Create a temporary info dict

# Generated at 2022-06-18 15:57:14.637188
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import DateRange

    ydl = gen_ydl()
    ydl.add_post_processor(XAttrMetadataPP())

    # Test with a video
    info = ydl.extract_info(
        'http://www.youtube.com/watch?v=BaW_jenozKc',
        download=False,
        ie_key='Youtube',
    )
    assert info['title'] == 'youtube-dl test video "\'/\\ä↭𝕐'

    # Test with a playlist

# Generated at 2022-06-18 15:57:26.065600
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os
    import tempfile
    import unittest

    from ..utils import (
        XAttrUnavailableError,
        XAttrMetadataError,
    )

    from .common import FileDownloader

    class FakeInfoExtractor(object):
        def __init__(self, ie_result):
            self.ie_result = ie_result

        def extract(self, url):
            return self.ie_result

    class FakeFileDownloader(FileDownloader):
        def __init__(self, params):
            FileDownloader.__init__(self, params)
            self.to_stderr_called = False
            self.to_screen_called = False

        def to_stderr(self, message):
            self.to_stderr_called = True


# Generated at 2022-06-18 15:57:35.606354
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import encodeFilename
    from ..compat import compat_os_name
    from ..extractor import gen_extractors
    from ..downloader import get_suitable_downloader

    # Create a fake downloader
    class FakeDownloader(object):
        def __init__(self):
            self.to_screen = lambda x: x
            self.report_warning = lambda x: x
            self.report_error = lambda x: x

    # Create a fake info dict

# Generated at 2022-06-18 15:57:45.710586
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import encodeFilename
    from ..compat import compat_os_name

    if compat_os_name == 'nt':
        return

    import os
    import tempfile
    import xattr

    # Create a temporary file
    fd, filename = tempfile.mkstemp()
    os.close(fd)

    # Create a PostProcessor object
    pp = XAttrMetadataPP()

    # Create a fake info dict