

# Generated at 2022-06-18 15:48:00.249896
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import DateRange
    from ..compat import compat_str

    def _test_xattr_metadata(ydl, info):
        xattr_metadata_pp = XAttrMetadataPP(ydl)
        xattr_metadata_pp.run(info)

    # Test with a video
    ydl = gen_ydl()
    ydl.add_default_info_extractors()
    info = ydl.extract_info(
        'https://www.youtube.com/watch?v=BaW_jenozKc', download=False)
    _test_xattr_metadata(ydl, info)

    # Test with a playlist
    ydl = gen_ydl()
    ydl.add_default

# Generated at 2022-06-18 15:48:09.023942
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..downloader import Downloader
    from ..extractor import YoutubeIE
    from ..utils import DateRange
    from ..compat import compat_os_name

    if compat_os_name == 'nt':
        return

    dl = Downloader()
    ie = YoutubeIE(dl)
    info = ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')
    info['filepath'] = 'test.mp4'
    info['format'] = 'mp4'
    info['date'] = DateRange(datetime.datetime(2012, 11, 10), datetime.datetime(2012, 11, 11))

    pp = XAttrMetadataPP(dl)
    pp.run(info)

    # TODO: check that xattrs were actually written

# Generated at 2022-06-18 15:48:13.952575
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    ydl = gen_ydl(params={'writethumbnail': True})
    ydl.add_post_processor(XAttrMetadataPP())
    ydl.add_info_extractor(gen_extractors()[0])
    ydl.download(['http://www.youtube.com/watch?v=BaW_jenozKc'])

# Generated at 2022-06-18 15:48:26.265809
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor.common import InfoExtractor
    from ..downloader.common import FileDownloader
    from ..utils import prepend_extension
    from ..compat import compat_os_name
    import os
    import tempfile

    # Create a temporary file
    (fd, filename) = tempfile.mkstemp(prefix='youtube-dl_test_')
    os.close(fd)

    # Create a FileDownloader
    ydl = FileDownloader({'outtmpl': filename})

    # Create an InfoExtractor
    ie = InfoExtractor()

    # Create an XAttrMetadataPP
    xattr_pp = XAttrMetadataPP(ydl)

    # Test constructor
    assert xattr_pp.supported() == (compat_os_name != 'nt')

    # Test run

# Generated at 2022-06-18 15:48:35.713890
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import DateRange

    # Create a downloader object
    ydl = gen_ydl(params={'writedescription': True})

    # Create a test info dict

# Generated at 2022-06-18 15:48:43.836162
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import encodeFilename

    # Create a PostProcessor object
    xattr_pp = XAttrMetadataPP()

    # Create a dictionary containing the info

# Generated at 2022-06-18 15:48:45.788924
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    xattr_metadata_pp = XAttrMetadataPP()
    assert xattr_metadata_pp is not None

# Generated at 2022-06-18 15:48:57.469772
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import encodeFilename
    from ..compat import compat_os_name

    if compat_os_name == 'nt':
        return

    import os
    import tempfile
    import unittest

    from ..extractor import gen_extractors

    class TestXAttrMetadataPP(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.test_file = os.path.join(self.tempdir, 'test.mp4')
            with open(self.test_file, 'wb') as f:
                f.write(b'\x00' * 1024)

        def tearDown(self):
            import shutil
            shutil.rmtree(self.tempdir)


# Generated at 2022-06-18 15:49:04.876470
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..downloader import YoutubeDL
    from ..extractor import YoutubeIE
    from ..utils import DateRange

    ydl = YoutubeDL({'writedescription': True, 'writeinfojson': True})
    ie = YoutubeIE(ydl)
    info = ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')
    assert info['title'] == 'youtube-dl test video "\'/\\ä↭𝕐'
    assert info['description'] == 'test chars:  "\'/\\ä↭𝕐\ntest URL: https://github.com/rg3/youtube-dl/issues/1892\nThis is a test video for youtube-dl.\n\nFor more information, contact phihag@phihag.de .'

# Generated at 2022-06-18 15:49:05.898762
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP(None).run({}) == ([], {})

# Generated at 2022-06-18 15:49:20.050261
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import DateRange

    # Create a downloader object
    ydl = gen_ydl()

    # Create a test video

# Generated at 2022-06-18 15:49:32.571714
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import DateRange

    ydl = gen_ydl()
    ydl.add_post_processor(XAttrMetadataPP())
    ydl.params['writethumbnail'] = True
    ydl.params['writeinfojson'] = True
    ydl.params['writedescription'] = True
    ydl.params['writeannotations'] = True
    ydl.params['write_all_thumbnails'] = True
    ydl.params['outtmpl'] = '%(id)s.%(ext)s'
    ydl.params['writesubtitles'] = True
    ydl.params['allsubtitles'] = True
    ydl.params['writeautomaticsub'] = True

# Generated at 2022-06-18 15:49:43.465641
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor.common import InfoExtractor
    from ..utils import DateRange
    from ..compat import compat_str

    # Test with a valid date range

# Generated at 2022-06-18 15:49:44.158150
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-18 15:49:56.124871
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import DateRange

    # Test constructor
    xattr_pp = XAttrMetadataPP()

    # Test run()
    ydl = gen_ydl()
    ydl.params['writethumbnail'] = True
    ydl.params['writeinfojson'] = True
    ydl.params['writedescription'] = True
    ydl.params['writeannotations'] = True
    ydl.params['write_all_thumbnails'] = True
    ydl.params['outtmpl'] = '%(id)s.%(ext)s'
    ydl.params['writesubtitles'] = True
    ydl.params['allsubtitles'] = True
    ydl.params['writeautomaticsub']

# Generated at 2022-06-18 15:50:07.427904
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import encodeFilename
    from ..compat import compat_os_name

    import tempfile
    import os
    import sys
    import shutil

    from .common import FileDownloader

    if compat_os_name == 'nt':
        return

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    (fd, tmpfile) = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create a downloader
    ydl = FileDownloader({
        'outtmpl': encodeFilename(tmpfile),
        'nooverwrites': True,
        'quiet': True,
        'logger': FileDownloader.std_logger,
    })

    # Create a postprocessor

# Generated at 2022-06-18 15:50:08.041268
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-18 15:50:18.509070
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import encodeFilename
    from ..compat import compat_os_name
    import tempfile
    import os
    import sys
    import shutil
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    filepath = os.path.join(tmpdir, 'test.mp4')
    with open(filepath, 'wb') as f:
        f.write(b'\0' * 1024)

    # Create a XAttrMetadataPP object
    xattr_metadata_pp = XAttrMetadataPP()

    # Set the downloader
    class FakeDownloader():
        def to_screen(self, msg):
            pass

        def report_error(self, msg):
            pass


# Generated at 2022-06-18 15:50:29.554067
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os
    import tempfile
    import shutil
    from ..utils import write_xattr, read_xattr, XAttrUnavailableError, XAttrMetadataError

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary file
    temp_file = os.path.join(temp_dir, 'test.txt')
    with open(temp_file, 'w') as f:
        f.write('test')

    # Create a PostProcessor object
    pp = XAttrMetadataPP()

    # Test with a file that doesn't support xattrs
    info = {'filepath': temp_file, 'title': 'test', 'upload_date': 'test'}
    pp.run(info)

    # Test with a file that supports xattrs

# Generated at 2022-06-18 15:50:36.398336
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import encodeFilename
    from .common import FileDownloader
    from .http import HttpFD
    from .http import HEADRequest

    # Create a FileDownloader object
    ydl = FileDownloader({'outtmpl': '%(id)s.%(ext)s'})
    ydl.add_info_extractor(None)

    # Create a fake downloader
    class FakeDownloader(object):
        def __init__(self, ydl):
            self.ydl = ydl

        def to_screen(self, msg):
            pass

        def report_error(self, msg):
            pass

        def report_warning(self, msg):
            pass

    # Create a fake http downloader

# Generated at 2022-06-18 15:50:56.217923
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import encodeFilename
    from ..compat import compat_os_name
    from ..extractor import gen_extractors
    from ..downloader import FileDownloader
    from ..postprocessor import PostProcessor
    from ..cache import YoutubeDL

    class FakeFileDownloader(FileDownloader):
        def __init__(self, ydl, params):
            self.ydl = ydl
            self.params = params

        def to_screen(self, msg):
            pass

        def report_error(self, msg):
            pass

        def report_warning(self, msg):
            pass

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, params):
            self.params = params

        def to_screen(self, msg):
            pass

        def trouble(self, msg):
            pass

# Generated at 2022-06-18 15:51:07.251955
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import DateRange
    from ..compat import compat_str

    # Create a downloader
    ydl = gen_ydl(params={'writedescription': True, 'writeinfojson': True})

    # Create an extractor

# Generated at 2022-06-18 15:51:14.026322
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import encodeFilename
    from ..compat import compat_os_name

    if compat_os_name == 'nt':
        return

    import tempfile
    import os
    import shutil
    import xattr

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    tmp_file = os.path.join(tmp_dir, 'test.mp4')
    with open(tmp_file, 'w') as f:
        f.write('test')

    # Create a PostProcessor object
    pp = XAttrMetadataPP()

    # Create a downloader object
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})

    # Set the downloader object to the PostProcessor object

# Generated at 2022-06-18 15:51:24.727262
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import DateRange

    # Create a downloader object
    ydl = gen_ydl(params={'writethumbnail': True, 'writeinfojson': True})

    # Create a test video

# Generated at 2022-06-18 15:51:35.134306
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..downloader import Downloader
    from ..extractor import YoutubeIE
    from ..utils import DateRange
    from ..compat import compat_str

    # Create a downloader object
    ydl = Downloader()

    # Create a XAttrMetadataPP object
    pp = XAttrMetadataPP(ydl)

    # Create a YoutubeIE object
    ie = YoutubeIE(ydl)

    # Get a test video
    test_url = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    info_dict = ie.extract(test_url)

    # Test the run() method
    pp.run(info_dict)

    # Test the run() method with a DateRange object
    info_dict['upload_date'] = DateRange(u'20121002')

# Generated at 2022-06-18 15:51:46.693071
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import DateRange

    # Mock downloader
    class MockDownloader:
        def __init__(self):
            self.params = {'writedescription': True, 'writeinfojson': True, 'writethumbnail': True}
            self.to_screen = lambda *args, **kargs: None
            self.report_error = lambda *args, **kargs: None
            self.report_warning = lambda *args, **kargs: None

    # Mock info dict

# Generated at 2022-06-18 15:51:57.309486
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os
    import tempfile
    import shutil
    import xattr

    from .common import FileDownloader

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create a FileDownloader
    ydl = FileDownloader({'outtmpl': tmpfile})

    # Create a XAttrMetadataPP
    pp = XAttrMetadataPP(ydl)

    # Run the method run of class XAttrMetadataPP

# Generated at 2022-06-18 15:52:08.023056
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..downloader import Downloader
    from ..extractor import YoutubeIE
    from ..utils import encodeFilename

    # Create a downloader
    dl = Downloader(params={})

    # Create an extractor
    ie = YoutubeIE(dl=dl)

    # Create a postprocessor
    pp = XAttrMetadataPP(dl=dl)

    # Test a valid video

# Generated at 2022-06-18 15:52:08.596533
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-18 15:52:15.785132
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import encodeFilename
    from .common import FileDownloader
    from .xattr import XAttrMetadataPP
    from ..compat import compat_os_name

    if compat_os_name == 'nt':
        return

    # Create a FileDownloader object
    ydl_opts = {
        'outtmpl': '%(id)s%(ext)s',
        'writethumbnail': True,
        'writeinfojson': True,
        'writedescription': True,
        'writeannotations': True,
        'writeautomaticsub': True,
        'writesubtitles': True,
        'write_all_thumbnails': True,
        'postprocessors': [{
            'key': 'XAttrMetadataPP',
        }],
    }
    fd = FileDownloader

# Generated at 2022-06-18 15:52:45.745483
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor.common import InfoExtractor
    from ..utils import DateRange
    from ..compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'test'
        _VALID_URL = r'(?i)^https?://.*\.test$'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'title': 'test title',
                'description': 'test description',
                'uploader': 'test uploader',
                'upload_date': 'test upload date',
                'webpage_url': 'test webpage url',
                'duration': DateRange(seconds=1),
                'format': 'test format',
                'thumbnail': 'test thumbnail',
                'resolution': 'test resolution',
            }


# Generated at 2022-06-18 15:52:52.058301
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import encodeFilename
    from ..compat import compat_os_name

    #
    # Test 1:
    #   Test with a file that doesn't exist
    #
    filename = encodeFilename('/tmp/this_file_does_not_exist.mp4')

# Generated at 2022-06-18 15:52:53.234680
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # Test constructor of class XAttrMetadataPP
    pp = XAttrMetadataPP()
    assert pp is not None


# Generated at 2022-06-18 15:52:53.743703
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-18 15:53:00.402985
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import DateRange
    from ..compat import compat_str

    # Create a downloader
    ydl = gen_ydl()

    # Create a test extractor
    class TestInfoExtractor(object):
        IE_NAME = 'test'
        _VALID_URL = r'(?i)^https?://.*'

# Generated at 2022-06-18 15:53:08.385600
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import tempfile
    import os
    import shutil
    from .common import FileDownloader

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    temp_file.close()

    # Create a FileDownloader
    ydl = FileDownloader({'outtmpl': temp_file.name})

    # Create a XAttrMetadataPP
    pp = XAttrMetadataPP(ydl)

    # Run the method run of class XAttrMetadataPP

# Generated at 2022-06-18 15:53:17.552529
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import encodeFilename
    from .common import FileDownloader

    # Create a FileDownloader instance
    fd = FileDownloader({})
    fd.params = {'outtmpl': encodeFilename('%(title)s-%(id)s.%(ext)s')}
    fd.add_info_extractor(lambda i: i)

    # Create a XAttrMetadataPP instance
    pp = XAttrMetadataPP(fd)

    # Test the run method

# Generated at 2022-06-18 15:53:19.506687
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP(None).run({}) == ([], {})

# Generated at 2022-06-18 15:53:29.583235
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import DateRange
    from ..compat import compat_str

    # Create a downloader
    ydl = gen_ydl()
    ydl.params['writedescription'] = True
    ydl.params['writeinfojson'] = True
    ydl.params['writethumbnail'] = True
    ydl.params['writeautomaticsub'] = True
    ydl.params['writeannotations'] = True
    ydl.params['write_all_thumbnails'] = True
    ydl.params['writesubtitles'] = True
    ydl.params['write_all_subtitles'] = True
    ydl.params['write_all_thumbnail'] = True

# Generated at 2022-06-18 15:53:33.566876
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import DateRange

    ydl = gen_ydl()
    ydl.add_post_processor(XAttrMetadataPP())

    # Test with a video
    info = ydl.extract_info(
        'https://www.youtube.com/watch?v=BaW_jenozKc',
        download=False,
        ie_key='Youtube',
    )
    assert info['title'] == 'youtube-dl test video "\'/\\ä↭𝕐'
    assert info['upload_date'] == '20121002'
    assert info['uploader'] == 'Philipp Hagemeister'

# Generated at 2022-06-18 15:54:21.595410
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os
    from ..utils import encodeFilename

    # Create a temporary file
    filename = encodeFilename('test_XAttrMetadataPP_run.tmp')
    with open(filename, 'w') as f:
        f.write('test')

    # Create a XAttrMetadataPP instance
    xattr_metadata_pp = XAttrMetadataPP()

    # Create a fake downloader
    class FakeDownloader(object):
        def to_screen(self, msg):
            pass
        def report_error(self, msg):
            pass
        def report_warning(self, msg):
            pass
    downloader = FakeDownloader()

    # Create a fake info dict

# Generated at 2022-06-18 15:54:29.172013
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import encodeFilename
    from ..extractor import gen_extractors
    from ..downloader import FileDownloader

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self['filepath'] = encodeFilename('test.mp4')

    class FakeYDL(object):
        def __init__(self, *args, **kwargs):
            self.params = {
                'writethumbnail': True,
                'writeinfojson': True,
                'writedescription': True,
                'writeannotations': True,
                'writeautomaticsub': True,
                'writeinfojson': True,
                'write_all_thumbnails': True,
            }


# Generated at 2022-06-18 15:54:40.520980
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os
    import tempfile
    from ..utils import xattr_supported

    if not xattr_supported():
        return

    # Create a temporary file
    temp_fd, temp_filename = tempfile.mkstemp()
    os.close(temp_fd)

    # Create a XAttrMetadataPP instance
    xattr_metadata_pp = XAttrMetadataPP()

    # Create a fake downloader
    class FakeDownloader:
        def to_screen(self, msg):
            pass

        def report_warning(self, msg):
            pass

        def report_error(self, msg):
            pass

    fake_downloader = FakeDownloader()

    # Create a fake info dict

# Generated at 2022-06-18 15:54:49.308685
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import DateRange
    from ..compat import compat_os_name

    if compat_os_name != 'nt':
        ydl = gen_ydl()
        ydl.params['writedescription'] = True
        ydl.params['writeinfojson'] = True
        ydl.params['writesubtitles'] = True
        ydl.params['writeautomaticsub'] = True
        ydl.params['writeannotations'] = True
        ydl.params['write_all_thumbnails'] = True
        ydl.params['write_thumbnail'] = True
        ydl.params['writethumbnail'] = True
        ydl.params['write_xattrs'] = True

# Generated at 2022-06-18 15:55:00.534577
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import encodeFilename
    from ..compat import compat_os_name

    if compat_os_name == 'nt':
        return

    import os
    import tempfile
    import unittest

    from ..extractor.common import InfoExtractor

    class MockInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'mock_id',
                'title': 'mock_title',
                'description': 'mock_description',
                'uploader': 'mock_uploader',
                'upload_date': 'mock_upload_date',
                'webpage_url': 'mock_webpage_url',
                'format': 'mock_format',
            }


# Generated at 2022-06-18 15:55:11.016371
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os
    from .common import FileDownloader

    # Create a temporary file
    fd, filename = tempfile.mkstemp()
    os.close(fd)

    # Create a downloader
    ydl = FileDownloader({
        'outtmpl': filename,
        'quiet': True,
    })

    # Create a postprocessor
    pp = XAttrMetadataPP(ydl)

    # Run the postprocessor
    pp.run({
        'filepath': filename,
        'title': 'test title',
        'webpage_url': 'http://example.com/',
        'upload_date': '20120101',
        'description': 'test description',
        'uploader': 'test uploader',
        'format': 'test format',
    })

    # Check the xattrs
    xattr

# Generated at 2022-06-18 15:55:20.020971
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os
    import tempfile
    import shutil
    import xattr

    from .common import FileDownloader
    from ..extractor import gen_extractors

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a dummy file
    dummyfile = os.path.join(tmpdir, 'dummy.mp4')
    with open(dummyfile, 'wb') as f:
        f.write(b'foobar')

    # Create a dummy info dict

# Generated at 2022-06-18 15:55:26.835732
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..downloader import YoutubeDL
    from ..extractor import YoutubeIE
    from ..utils import DateRange

    # Create a YoutubeDL object

# Generated at 2022-06-18 15:55:37.467509
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..downloader import YoutubeDL
    from ..extractor import YoutubeIE

    ydl = YoutubeDL({'writethumbnail': True, 'writeinfojson': True})
    ie = YoutubeIE(ydl)
    pp = XAttrMetadataPP(ydl)

    assert pp.get_name() == 'xattrs'
    assert pp.get_description() == 'Set extended attributes on downloaded file (if xattr support is found).'
    assert pp.get_supported_extensions() == []
    assert pp.get_supported_information_extensions() == ['description', 'ext', 'format', 'upload_date', 'uploader', 'webpage_url']
    assert pp.get_supported_categories() == []
    assert pp.get_supported_categories() == []
    assert pp.get_supported_categories() == []

# Generated at 2022-06-18 15:55:44.741559
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import encodeFilename
    from ..compat import compat_os_name
    from ..extractor import gen_extractors
    from ..downloader import Downloader
    from ..postprocessor import PostProcessor
    from ..cache import Cache
    from ..compat import compat_urllib_request

    class FakeInfoExtractor(object):
        IE_NAME = 'test'
        IE_DESC = 'test'


# Generated at 2022-06-18 15:57:13.840360
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..YoutubeDL import YoutubeDL
    from ..extractor.common import InfoExtractor
    from ..utils import DateRange
    from .common import FileDownloader
    from .get_thumbnail import GetThumbnailPP
    from .embedthumbnail import EmbedThumbnailPP
    from .xattrpp import XAttrMetadataPP
    from .metadatafromtitle import MetadataFromTitlePP
    from .execafterdownload import ExecAfterDownloadPP
    from .fixup import FixupPP
    from .ffmpegmetadata import FFmpegMetadataPP
    from .xattrpp import XAttrMetadataPP
    from .xattrtomp4 import XAttrToMp4PP
    from .postprocessor import PostProcessor
    from .common import PostProcessingError
    from .compat import compat_os_name
    from .ffmpeg import FFmpegPostProcessor

# Generated at 2022-06-18 15:57:25.349684
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..downloader import Downloader
    from ..extractor import YoutubeIE
    from ..utils import DateRange
    from ..compat import compat_str

    # Create a downloader object
    ydl = Downloader()

    # Create an extractor object
    ie = YoutubeIE()

    # Create a postprocessor object
    pp = XAttrMetadataPP()

    # Test constructor
    assert pp.downloader is None
    assert pp.ie is None

    # Test downloader and ie setter
    pp.set_downloader(ydl)
    assert pp.downloader == ydl
    pp.set_info_extractor(ie)
    assert pp.ie == ie

    # Test run method

# Generated at 2022-06-18 15:57:35.071766
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os
    import tempfile
    import unittest

    from ..utils import (
        XAttrUnavailableError,
        XAttrMetadataError,
    )

    class TestXAttrMetadataPP(unittest.TestCase):

        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.filename = os.path.join(self.tempdir, 'test.mp4')
            with open(self.filename, 'w') as f:
                f.write('test')

        def tearDown(self):
            os.remove(self.filename)
            os.rmdir(self.tempdir)


# Generated at 2022-06-18 15:57:37.072422
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP()
    assert pp.run({}) == ([], {})

# Generated at 2022-06-18 15:57:38.224521
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP()
    assert pp is not None

# Generated at 2022-06-18 15:57:47.822611
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import encodeFilename
    from ..extractor import gen_extractors

    # Create a fake downloader
    class FakeInfoExtractor(object):
        def __init__(self, downloader):
            self.downloader = downloader

    class FakeYoutubeIE(FakeInfoExtractor):
        IE_NAME = 'Youtube'
        _VALID_URL = r'(?:youtube(?:-nocookie)?\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu\.be/)(?P<id>[^?&#]+)'

        def _real_extract(self, url):
            video_id = self._match_id(url)