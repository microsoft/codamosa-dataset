

# Generated at 2022-06-22 09:21:14.901963
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_dict = {
        'webpage_url': 'www.youtube.com',
        'title': 'Video - The Song',
        'upload_date': 'yyyymmdd',
        'description': 'Video Description',
        'uploader': 'John Doe',
        'format': 'mp4',
        'filepath': 'path/to/video.mp4',
    }


# Generated at 2022-06-22 09:21:26.628187
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..YoutubeDL import YoutubeDL
    import shutil
    import tempfile
    import os

    with tempfile.NamedTemporaryFile() as tmp_file:
        tmp_file_path = tmp_file.name
        ydl_opts = {
            'quiet': True,
            'writethumbnail': True,
            'matchtitle':'%(title)s',
            'outtmpl':tmp_file_path + '.%(ext)s'
        }
        ydl = YoutubeDL(ydl_opts)
        XAttrMetadataPP(ydl)

        # This should be enough to trigger the constructor, and
        # by extension the error message.
        with ydl:
            ydl.params['noprogress'] = True

# Generated at 2022-06-22 09:21:39.510066
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import sys
    import tempfile

    from ..compat import compat_os_name
    from ..utils import (
        XAttrMetadataError,
        XAttrUnavailableError,
    )
    from .common import PostProcessorTestCase

    info = {'filepath': tempfile.mktemp(prefix='ytdl_test_')}

    class MockYoutubeDL(object):
        def __init__(self, *args, **kwargs):
            self.extra_info = {}

        def to_stdout(self, msg):
            print(msg)

        def to_screen(self, msg):
            print(msg)

        def to_stderr(self, msg):
            print(msg, file=sys.stderr)


# Generated at 2022-06-22 09:21:51.888993
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from io import BytesIO

    # Set up a mock to return the appropriate values

# Generated at 2022-06-22 09:21:52.501053
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-22 09:21:53.464479
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    XAttrMetadataPP()

# Generated at 2022-06-22 09:21:54.750016
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    xattr_pp = XAttrMetadataPP()
    assert xattr_pp != None

# Generated at 2022-06-22 09:22:05.980330
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    filename = '/this/what/ever'
    info = {
        'upload_date': '20091124',
        'title': 'Test title',
        'description': 'Description of test xattrs',
        'uploader': 'Uploader',
        'format': 'WebM'
    }

    # Test the normal behaviour

# Generated at 2022-06-22 09:22:14.326210
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pp = XAttrMetadataPP()

    filename = 'somefile.mp4'

    # mp4 video
    info = {
        'webpage_url': 'https://example.com/1234',
        'upload_date': '20150812',
        'title': 'title',
        'description': 'description',
        'uploader': 'uploader',
        'format': 'format',
    }

    # xattr unavailable
    pp.write_xattr = lambda filename, xattrname, byte_value: XAttrUnavailableError('no xattrs')
    ignored, info = pp.run(info)

    # xattr filesystem doesn't support

# Generated at 2022-06-22 09:22:25.075848
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .open import open_pp
    desc = 'Test for method run of class XAttrMetadataPP'
    success = True

    try:
        import xattr
    except ImportError:
        print('  xattr module not found. Skipping test.')
        return True

    import tempfile
    import os

    filename = tempfile.mktemp()
    open(filename, 'a').close()
    info = {}


# Generated at 2022-06-22 09:22:31.026001
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # TODO
    pass


# Generated at 2022-06-22 09:22:39.688738
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import make_fake_filesystem_xattr

    def run_test_XAttrMetadataPP_run(infos, expected_xattrs_dict):
        ydl = make_fake_filesystem_xattr()
        ydl.add_post_processor(XAttrMetadataPP())

        info = infos[0]

        # For testing, pretend that the file has already been downloaded
        info['filepath'] = info['url']

        ydl.process_ie_result(info)

        assert ydl.fs.xattrs == expected_xattrs_dict


# Generated at 2022-06-22 09:22:40.804345
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
# TODO
    return True

# Generated at 2022-06-22 09:22:48.164450
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ydl.version import __version__
    import ydl_opts

    def _test_XAttrMetadataPP():

        ydl_opts.setdefault('ignoreerrors', True)
        ydl_opts.setdefault('simulate', True)
        ydl_opts.setdefault('logger', _Logger())
        ydl_opts.setdefault('nocheckcertificate', True)
        ydl_opts.setdefault('prefer_insecure', True)
        ydl_opts.setdefault('verbose', True)
        ydl_opts.setdefault('youtube_include_dash_manifest', True)
        ydl_opts.setdefault('writethumbnail', True)
        ydl_opts.setdefault('writeinfojson', True)

# Generated at 2022-06-22 09:22:49.500116
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # This test is empty
    pass

# Generated at 2022-06-22 09:22:52.004722
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    xattrs = XAttrMetadataPP()
    assert xattrs is not None


# Generated at 2022-06-22 09:22:58.366006
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    import sys
    sys.argv = [sys.argv[0], '-o', '', '-f', 'bestaudio', '--write-thumbnail', '--write-description', '--write-info-json', 'https://www.youtube.com/watch?v=BaW_jenozKc']
    from .YoutubeDL import YoutubeDL
    yt = YoutubeDL({})
    yt.add_post_processor(XAttrMetadataPP())

# Generated at 2022-06-22 09:23:05.460492
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    import tempfile
    import os

    # Touch a file
    filename = os.path.join(tempfile.gettempdir(), 'youtube-dl-unit-test-file.tmp')
    open(filename, 'w').close()

    # Write read-only property to xattr
    try:
        write_xattr(filename, 'user.xdg.referrer.url', 'http://youtube.com/')
    except XAttrMetadataError:
        pass

    # Test
    pp = XAttrMetadataPP({})
    pp.run({'filepath': filename})

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-22 09:23:06.642422
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert True

# Generated at 2022-06-22 09:23:08.217817
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP(None)
    assert pp.run(None)[0] == []

# Generated at 2022-06-22 09:23:29.431257
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .common import FileDownloader
    from ..utils import prepend_extension

    import tempfile
    import stat

    class FakeInfo(dict):
        def __init__(self, *args, **kwargs):
            dict.__init__(self, *args, **kwargs)
            self.__dict__ = self

    # no xattr support
    with tempfile.NamedTemporaryFile() as f:
        info = FakeInfo(filepath=f.name,
                        webpage_url='http://foo.bar.baz/',
                        title='Foo bar',
                        description='Lorem ipsum dolor sit amet',
                        upload_date='20150710',
                        uploader='John Smith',
                        format='mp4')

        XAttrMetadataPP().run(info)

    # xattr support
   

# Generated at 2022-06-22 09:23:30.383849
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # TODO: write unit test
    assert True

# Generated at 2022-06-22 09:23:40.073234
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os
    import tempfile
    import xattr
    from ..extractor.common import InfoExtractor

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    file_path = os.path.join(temp_dir, 'test.txt')
    with open(file_path, 'w') as f:
        f.write('This is a test file')

    # Write extended attributes for the temporary file
    xattr.setxattr(file_path, 'user.dublincore.title', 'Title')

    # Test that the XattrMetadataPP class find the extended attribute written
    # on the temporary file
    class TestIE(InfoExtractor):
        IE_NAME = 'test'
        IE_DESC = False  # Do not list
        _

# Generated at 2022-06-22 09:23:40.694444
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-22 09:23:43.185868
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP(None)
    assert pp is not None

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-22 09:23:47.314719
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP('DummyDownloader')
    assert isinstance(pp.run, types.MethodType)

# Generated at 2022-06-22 09:23:49.331437
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    postprocessor = XAttrMetadataPP(None)
    assert isinstance(postprocessor, PostProcessor)

# Generated at 2022-06-22 09:24:00.566554
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # N.B. This test will FAIL on systems that do not support Python XATTR

    testfile = 'test/test.mp4'

    # Test 1. space left on disk
    try:
        write_xattr('/', 'user.xdg.referrer.url', b'http://www.youtube.com/watch?v=BaW_jenozKc')
        assert False, 'NO_SPACE error not raised'
    except XAttrMetadataError as e:
        assert e.reason == 'NO_SPACE', '"NO_SPACE" error expected, got "{0}"'.format(e.reason)

    # Test 2. long value

# Generated at 2022-06-22 09:24:06.676553
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    """
    Placeholder for testing method run of class XAttrMetadataPP
    """
    
    print("""
    Running unit test for method run of class XAttrMetadataPP
    """)


if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-22 09:24:10.432595
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os
    import shutil
    import tempfile
    import textwrap

    try:
        import xattr
        xattr.getxattr
    except ImportError:
        return
    except OSError:
        return

    info = {
        'filepath': None,
        'title': 'test title',
        'webpage_url': 'test url',
        'description': 'test description',
        'uploader': 'test uploader',
        'upload_date': 'test date',
        'format': 'test format',
    }


    def write_xattr(info):
        from ytdl_gui.ytdl_postprocessor import XAttrMetadataPP
        xattr_pp = XAttrMetadataPP()


# Generated at 2022-06-22 09:24:32.460387
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    return XAttrMetadataPP('youtube-dl', {})

# Generated at 2022-06-22 09:24:38.443037
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor import gen_extractors
    from ..downloader import Downloader
    from ..postprocessor.execafterdownload import ExecAfterDownloadPP

    # Hack to load the class
    for ie in gen_extractors():
        if ie.IE_NAME == 'Youtube':
            yt_ie = ie
            break

    ydl = Downloader({})
    ydl.add_info_extractor(yt_ie)
    ydl.add_post_processor(ExecAfterDownloadPP())
    ydl.add_post_processor(XAttrMetadataPP())

    # Run the unit test
    import os.path
    import subprocess
    import tempfile
    import shutil
    import sys

    # Create temporary directory

# Generated at 2022-06-22 09:24:39.383253
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    assert True

# Generated at 2022-06-22 09:24:49.188743
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import sys
    import unittest
    import tempfile
    import os

    from io import StringIO

    from ..downloader import Downloader
    from ..compat import compat_os_name

    # Suppress stdout
    save_stdout = sys.stdout
    sys.stdout = StringIO()

    #
    # Test: missing xattr support
    #

    class MockXAttrUnavailableError(Exception):
        pass

    downloader = Downloader(None)

    def mock_write_xattr(filename, key, value):
        raise MockXAttrUnavailableError

    XAttrMetadataPP._write_xattr = mock_write_xattr

    with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8') as f:
        info = {'filepath': f.name}

# Generated at 2022-06-22 09:24:57.942561
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .common import FileDownloader
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from .mock import Mock, mock_open
    from ..compat import compat_urllib_request
    from ..compat import compat_xattr

    compat_xattr.AVAILABLE = True
    compat_xattr.XATTR_FAKE = True

    # Create FileDownloader instance
    ydl = FileDownloader({})
    ydl.add_info_extractor(InfoExtractor('test'))
    ydl.params['format'] = 'best'

    # Patch: run ydl.process_ie_result(), return its value
    def process_ie_result(self, ie_result):
        return ie_result
    ydl.process_ie_result = process_ie

# Generated at 2022-06-22 09:25:00.962510
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP()
    dummy_dl = DummyYDL()
    pp.set_downloader(dummy_dl)
    assert pp.downloader == dummy_dl



# Generated at 2022-06-22 09:25:02.372146
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP(None)
    return pp

# Generated at 2022-06-22 09:25:11.890605
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import pytest

    try:
        import xattr
    except ImportError:
        pytest.skip('xattr is not supported on system')

    import tempfile
    import os
    import sys

    m = XAttrMetadataPP({})
    filename = os.path.join(tempfile.gettempdir(), 'testfile')
    if sys.version_info >= (3,):
        f = open(filename, 'wb')
        f.write(b'testcontent')
        f.close()
    else:
        f = open(filename, 'w')
        f.write('testcontent')
        f.close()


# Generated at 2022-06-22 09:25:15.755794
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from .common import FileDownloader
    from ..compat import compat_basestring

    ydl = FileDownloader()
    ydl.add_info_extractor(None)

    pp = XAttrMetadataPP(ydl)
    assert isinstance(pp.get_name(), compat_basestring)
    assert pp.get_version() is not None


# Generated at 2022-06-22 09:25:17.495847
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    obj = XAttrMetadataPP(None)
    assert isinstance(obj, XAttrMetadataPP)

# Generated at 2022-06-22 09:26:07.490158
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    print('# Testing XAttrMetadataPP.run()')

    def testcase(info):

        # Can't test if the xattr writing works, just if it crashes
        # TODO: Test if the xattr writing works
        #       (Beware: Will create files in /tmp/youtube_dl and their xattrs)

        pp = XAttrMetadataPP(None, None)
        pp.run(info)

    info = {
        'webpage_url': 'https://www.youtube.com/watch?v=ImtZ5yENzgE',
        'title': 'dQw4w9WgXcQ',
        'upload_date': '20071223',
        'description': 'now this is a story all about how',
        'uploader': 'somebody that i used to know',
    }

# Generated at 2022-06-22 09:26:17.256102
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import unittest
    from io import BytesIO

    from ..compat import compat_os_name
    from ..utils import xattr_unavailable_reason
    from ..extractor import gen_extractors
    from ..cache import load_json

    from .common import PostProcessorTest

    class XAttrMetadataPPTest(PostProcessorTest):
        def setUp(self):
            self.test_dir = 'test'
            self.test_file = 'test_video.mp4'
            self.test_filepath = self.test_dir + '/' + self.test_file
            self.test_outtmpl = self.test_dir + '/%(extractor_key)s-%(id)s.%(ext)s'

# Generated at 2022-06-22 09:26:28.326716
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor import gen_extractors
    from ..jsinterp import JSInterpreter
    from .execafterdownload import ExecAfterDownloadPP
    from ..downloader import FileDownloader
    from ..utils import prepend_extension
    from ..compat import compat_os_name

    assert issubclass(XAttrMetadataPP, PostProcessor)

    # Test the constructor
    xattr_pp = XAttrMetadataPP()
    assert hasattr(xattr_pp, 'name')
    assert hasattr(xattr_pp, 'description')
    assert hasattr(xattr_pp, '_downloader')

    # Test the run
    # First get a FileDownloader
    js_interp = JSInterpreter(verbose=False)

# Generated at 2022-06-22 09:26:29.433159
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-22 09:26:30.760859
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pass

# Generated at 2022-06-22 09:26:40.552024
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import prepend_extension

    # FIXME : find a way to test without os.environ
    import os
    os.environ['HOME'] = '/tmp'

    def check_xattrvalue(filename, xattrname, expected_value):
        # os.system('xattr -p %s %s' % (xattrname, filename))
        import xattr
        xattrs = xattr.xattr(filename)
        value = xattrs.get(xattrname.encode('utf-8'))
        assert value == expected_value.encode('UTF-8')


# Generated at 2022-06-22 09:26:41.429825
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # TODO
    pass

# Generated at 2022-06-22 09:26:53.386200
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # Skip test on Linux systems without XAttr support
    try:
        write_xattr('', '', '')
    except (XAttrUnavailableError, XAttrMetadataError):
        return

    from ..ytdl.YoutubeDL import YoutubeDL
    from ..YoutubeDL import YoutubeDL as YoutubeDL_real
    from ..utils import DateRange

    class MockYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(MockYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_strs = []
            self.report_warning_strs = []
            self.report_error_strs = []


# Generated at 2022-06-22 09:26:56.293716
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # when downloader is not None
    pp = XAttrMetadataPP(downloader=None)
    assert pp.downloader is None
    assert pp.exe_path is None

# Generated at 2022-06-22 09:27:04.238898
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os
    import tempfile
    import unittest

    fd, temp_filename = tempfile.mkstemp()
    os.close(fd)
    os.remove(temp_filename)

    # create file
    with open(temp_filename, 'w'):
        pass

    # use a postprocessor for testing
    pp = XAttrMetadataPP()

    # test with no xattr support
    info = {'filepath': temp_filename}
    pp.run(info)

    # test with xattr support

# Generated at 2022-06-22 09:28:28.900423
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    input = dict()
    instance = XAttrMetadataPP(input)
    assert isinstance(instance, XAttrMetadataPP)

# Generated at 2022-06-22 09:28:29.404365
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-22 09:28:40.052841
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    import os.path
    import os
    import shutil
    import tempfile
    # https://github.com/ytdl-org/youtube-dl/blob/fc3e3b6e1d6a889425a5e6e93d6cbb33f9d84262/youtube_dl/YoutubeDL.py#L137-L312

# Generated at 2022-06-22 09:28:42.084321
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP({})
    assert pp.__class__.__name__ == 'XAttrMetadataPP'


# Generated at 2022-06-22 09:28:49.243087
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..extractor import common
    from ..compat import compat_str
    from .test_common import TestDownloader
    from .test_postprocessor import MockYDL

    # http://stackoverflow.com/questions/24816456
    class DummyFile(object):
        file_size = 1337
        def __init__(self, *args, **kwargs):
            pass

        def write(self, s):
            pass

        def __enter__(self):
            return self

        def __exit__(self, *args):
            pass

    class MockInfoDict(common.InfoDict):
        def __init__(self, info_dict):
            super(MockInfoDict, self).__init__()
            self.update(info_dict)
            self.pop('_type', None)

   

# Generated at 2022-06-22 09:28:59.991126
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..compat import PY2, compat_os_name, compat_setenv

    compat_setenv('LC_ALL', 'C')

    class DummyInfo:
        def __init__(self, info):
            self.info = info

        def __getitem__(self, key):
            return self.info.get(key)

        def __setitem__(self, key, value):
            self.info[key] = value

    if compat_os_name != 'nt':

        import pyxattr as xattr

        # create and open tmp file
        import tempfile
        (fp, path) = tempfile.mkstemp(prefix="xattr_test_")

        # set some extended attributes for video

# Generated at 2022-06-22 09:29:00.999501
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    XAttrMetadataPP(None)

# Generated at 2022-06-22 09:29:10.347685
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import tempfile
    import os
    from .common import FileDownloader
    # Test for open a file and set the extended attributes for the file
    test_file = tempfile.NamedTemporaryFile(delete=False)
    test_file_name = test_file.name
    test_fd = test_file.file
    test_fd.close()

    # Setting downloader
    test_ydl = FileDownloader({
        'format': 'best',
        'outtmpl': test_file.name,
    })

    # Setting post processor
    test_pp = XAttrMetadataPP(test_ydl)

    # Current info

# Generated at 2022-06-22 09:29:13.640320
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

################################################################################
# Test for XAttrMetadataPP class
################################################################################
import pytest


# Generated at 2022-06-22 09:29:17.596224
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():

    from ..extractor.common import InfoExtractor
    ie = InfoExtractor()
    ie._downloader = None
    ie.add_info_extractor(_x_IE())
    ie.add_post_processor(XAttrMetadataPP())

    ie.extract(url='http://example.com/')

