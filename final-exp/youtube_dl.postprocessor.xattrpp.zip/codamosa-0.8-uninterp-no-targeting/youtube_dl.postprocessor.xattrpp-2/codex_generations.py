

# Generated at 2022-06-22 09:21:04.826629
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    return XAttrMetadataPP()

# Generated at 2022-06-22 09:21:08.630528
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import unittest

    class TestXAttrMetadataPP(unittest.TestCase):
        def test_run(self):
            pass

    return unittest.TestLoader().loadTestsFromTestCase(TestXAttrMetadataPP)

# Generated at 2022-06-22 09:21:16.352521
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    
    from ..utils import xattr_writable, xattr
    
    import tempfile
    import os
    import shutil
    import json
    from os.path import expanduser
    
    import pytest

    # skip test if xattr is not writable, e.g. on BSD
    if xattr_writable():

        file_dir = tempfile.mkdtemp('youtube-dl', 'xattrmetadatapp', expanduser('~'))
        print('file_dir: ' + file_dir)
        filename = os.path.join(file_dir, 'test_filename.mp4')
        print('filename: ' + filename)

        # create a file to test
        open(filename, 'w').close()

        # check if filename exists
        assert os.path.isfile(filename)


# Generated at 2022-06-22 09:21:19.879760
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pr = XAttrMetadataPP()
    info = { 'filepath': 'some_file' }

    # Should return nothing on success
    pr.run( info )
    assert(info == info)

# Generated at 2022-06-22 09:21:29.620708
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    # (1) test without error
    class DummyYDL:
        def to_screen(self, msg):
            pass

    class DummyInfoDict:
        def __init__(self):
            self.info = {
                'filepath': 'filename',
                'title': 'video title',
                'description': 'video description',
                'uploader': 'video uploader',
                'upload_date': 'video upload date',
                'format': 'video format',
            }

    d = DummyYDL()
    i = DummyInfoDict()
    p = XAttrMetadataPP()
    p.set_downloader(d)
    p.run(i.info)

    # (2) test with error
    class DummyYDL:
        def to_screen(self, msg):
            pass

# Generated at 2022-06-22 09:21:39.963528
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    try:
        XAttrMetadataPP(
            downloader=None,
            download_result={
                'webpage_url': 'url',
                'title': 'title',
                'upload_date': 'upload_date',
                'description': 'description',
                'uploader': 'uploader',
                'format': 'format',
                'filepath': 'filepath'
            },
            info_dict={}
        )
    # assert error if
        # 1. the downloader is None,
        # 2. the download_result is None,
        # 3. the download_result does not have a 'filepath',
        # 4. the info_dict is None
    except:
        pass
    else:
        raise Exception

# Generated at 2022-06-22 09:21:43.482485
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp1 = XAttrMetadataPP('xx', 'xx')
    assert pp1 is not None



# Generated at 2022-06-22 09:21:53.145053
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    try:
        import xattr
    except ImportError:
        print('Skipping extended attribute video metadata tests because xattr module is not available')
        return
    from ..ytdl.YoutubeDL import YoutubeDL
    import os

    # Fake youtube-dl.org download
    class FakeYoutubeDL(YoutubeDL):
        def __init__(self):
            super(FakeYoutubeDL, self).__init__()
            self.to_screen = lambda s: print(s)


    fy = FakeYoutubeDL()
    fy.params['outtmpl'] = 'test_%(autonumber)s-%(id)s.%(ext)s'
    ydl = XAttrMetadataPP(fy)


# Generated at 2022-06-22 09:22:04.610361
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import six
    import tempfile
    import os
    import subprocess
    from .common import FFmpegPostProcessor

    # Create a temporary file for testing
    fh, filename = tempfile.mkstemp()
    os.close(fh)

    # Create a FFmpegPP object for testing
    info = {
        'filepath': filename,
        'title': 'ThisIsATitle',
        'upload_date': '20110101',
        'description': 'ThisIsADescription',
        'uploader': 'ThisIsAnUploader',
        'format': 'ThisIsAFormat',
        'webpage_url': 'http://www.example.com/this/is/a/webpage/url',
    }

    # Run the method under test

# Generated at 2022-06-22 09:22:13.566165
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os
    import time
    import shutil
    import tempfile
    import textwrap
    from youtube_dl.downloader.f4m import F4mFD
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.compat import compat_os_name

    if not compat_os_name == 'posix':
        return

    def get_info(urls):
        xattr_metadata_pp = XAttrMetadataPP(YoutubeDL({'outtmpl': '%(id)s'}))
        xattr_metadata_pp.add_info_extractor(TestIE(urls))
        xattr_metadata_pp.run(YoutubeDL({}).extract_info(urls[0]))


# Generated at 2022-06-22 09:22:30.103693
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    """
    Just a test to see the code working.
    """
    import os
    import tempfile
    import unittest
    import sys

    clean = lambda: None
    class Test_Downloader():
        def to_screen(self, msg): print(msg)
        def report_warning(self, msg): print(msg)
        def report_error(self, msg): self.error_message = msg
        def get_filename(self): return 'filename'
        def temp_name(self, suffix):
            temp_fd, fname = tempfile.mkstemp(suffix=suffix)
            os.close(temp_fd)
            return fname

    # Create the Test Case

# Generated at 2022-06-22 09:22:38.976360
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    try:
        import xattr
        xattr.XATTR_NOFOLLOW
    except ImportError:
        return

    import tempfile
    from .common import FileDownloader
    from ..extractor.common import InfoExtractor, SearchInfoExtractor

    LOCALE_TEMP = 'fr'

    class VideoInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            info = {'webpage_url': 'http://www.youtube.com/',
                    'title': 'Video title',
                    'upload_date': '20130101',
                    'description': 'Video description',
                    'uploader': 'Author',
                    'format': 'Video format',
                    }
            return info


# Generated at 2022-06-22 09:22:50.199181
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import tempfile
    from .testutils import (
        FakeFileDownloader,
        FakeInfoExtractor,
        read_xattrs,
        remove_xattrs,
    )

    # set up a FakeInfoExtractor with 'upload_date' set to '20130101'
    ie = FakeInfoExtractor()
    ie._VALUES_TO_COMBINE['upload_date'] = ['20130101']

    # set up a temp file
    (fd, filename) = tempfile.mkstemp(suffix='.mp4')


# Generated at 2022-06-22 09:22:58.702996
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .common import get_testdata_file

    filename = get_testdata_file('test.mp4')

    # Set unique values for the attributes
    provider = 'provider'
    uploader = 'uploader'
    description = 'description'
    timestamp = 'timestamp'
    title = 'title'
    duration = 'duration'
    format = 'format'
    webpage_url = 'webpage_url'

    # Set the metadata
    metadata = {
        'provider':            provider,
        'uploader':            uploader,
        'description':         description,
        'timestamp':           timestamp,
        'title':               title,
        'duration':            duration,
        'format':              format,
    }

    # Try to set the xattrs

# Generated at 2022-06-22 09:23:09.267460
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .common import FileDownloader
    import tempfile
    import os
    import shutil

    def _get_info_dict(key, value):
        info_dict = dict()
        info_dict[key] = value
        return info_dict

    def _remove_file(filename):
        if os.path.exists(filename):
            os.remove(filename)

    # No extended attributes support

# Generated at 2022-06-22 09:23:20.374925
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import mock

    # This test has been automatically generated from test_XAttrMetadataPP_run.
    # It may still contain some errors.

    downloader = mock.MagicMock()
    downloader.to_screen = mock.MagicMock()
    downloader.report_error = mock.MagicMock()
    downloader.report_warning = mock.MagicMock()
    info = {}
    # 1. filename = info['filepath']
    # 2. downloader.to_screen('[metadata] Writing metadata to file\'s xattrs')
    # 3. xattr_mapping = {
                        # 'user.xdg.referrer.url': 'webpage_url',
                        # # 'user.xdg.comment':            'description',
                        # 'user.dublincore.title': 'title',


# Generated at 2022-06-22 09:23:30.677371
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # test_XAttrMetadataPP_run becomes 'run' in run_postprocessor.py
    import pytest
    from .run_postprocessor import test_postprocessor
    from .common import PostProcessor

    class FakeDL(object):
        """ Fake downloader class """
        def report_error(self, msg):
            """ Report error output """
            raise Exception(msg)

        def report_warning(self, msg):
            """ Report warning output """
            raise Exception(msg)

        def to_screen(self, msg):
            """ Print msg to screen """
            return True

    class FakeYDL(FakeDL):
        """ Fake youtube-dl class """
        def __init__(self):
            self.params = {'writedescription': True}

    class FakeInfo(object):
        """ Fake info class """

# Generated at 2022-06-22 09:23:40.256773
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .fake_pycrypto import FakePyCryptoModule
    from .fake_youtube_dl import FakeYoutubeDl

    # Test that a file path is returned from run
    # and that the xattrs were written
    xattr_mapping = {
        'user.xdg.referrer.url': 'webpage_url',
        'user.dublincore.title': 'title',
        'user.dublincore.date': 'upload_date',
        'user.dublincore.description': 'description',
        'user.dublincore.contributor': 'uploader',
        'user.dublincore.format': 'format',
    }


# Generated at 2022-06-22 09:23:48.925670
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    """ Test the behavior of method run of class XAttrMetadataPP. """

    class FakeFile(object):

        def __init__(self):
            self._list = []

        def get_list(self):
            return self._list

        def __enter__(self):
            return self

        def __exit__(self, *args):
            pass

        def setxattr(self, name, value):

            # -- SKIP: No space left on device
            if name == 'user.xdg.referrer.url':
                raise OSError(28, 'No space left on device')

            # -- SKIP: Value too long for extended attribute

# Generated at 2022-06-22 09:23:49.449354
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-22 09:24:00.099607
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    """
    """
    pass

# Generated at 2022-06-22 09:24:00.933641
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # TODO: implement tests
    pass

# Generated at 2022-06-22 09:24:12.150491
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import tempfile
    import os
    import shutil

    video_id = 'abcde'
    video_filename = '%s.mp4' % video_id
    video_filepath = os.path.join(tempfile.gettempdir(), video_filename)

    #
    # Normal case:
    #
    # Write the metadata to the file's xattrs

# Generated at 2022-06-22 09:24:22.934461
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    import tempfile
    import shutil
    import os

    def get_pp_list():
        tmp = tempfile.mkdtemp()
        try:
            pp = XAttrMetadataPP(tmp)
            pp_list = [pp]
            return pp_list
        finally:
            shutil.rmtree(tmp)

    pp_list = get_pp_list()
    assert pp_list is not None
    assert len(pp_list) > 0
    assert pp_list[0].name == 'metadata_xattr'
    assert pp_list[0].description == 'Set metadata to file\'s xattrs'

    # Test destructor
    pp = pp_list[0]
    pp.__del__()

    # Test run() method
    assert pp.run({}) == ([], {})
    assert pp

# Generated at 2022-06-22 09:24:25.351676
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP()
    assert pp is not None

# Generated at 2022-06-22 09:24:36.333895
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from .common import FileDownloader
    from ..extractor import gen_extractors
    downloader = FileDownloader({'outtmpl': '%(id)s.%(ext)s', 'quiet': True})
    downloader.add_info_extractor(gen_extractors()[0])
    pp = XAttrMetadataPP(downloader)


# Generated at 2022-06-22 09:24:43.470234
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import tempfile

    pp = XAttrMetadataPP()
    pp.run({
        'webpage_url': 'http://example.com/?id=123',
        'description': 'This video is great !',
        'title': 'The Title of the Video',
        'upload_date': '20140101',
        'uploader': 'uplo@der',
        'format': 'audio/mpeg',
        'filepath': tempfile.mktemp()
    })

# Generated at 2022-06-22 09:24:45.293130
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    """
    Simple unit test to exercise constructor of class XAttrMetadataPP
    """
    XAttrMetadataPP(None)

# Generated at 2022-06-22 09:24:47.984718
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    metadata_pp = XAttrMetadataPP(None)
    assert metadata_pp is not None


# Generated at 2022-06-22 09:24:56.598417
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import os
    import time
    import shutil
    import tempfile
    import unittest

    from ..utils import (
        encodeFilename,
        format_bytes,
        get_xattr,
        remove_xattr,
        set_xattr,
    )

    class XAttrMetadataPPTest(unittest.TestCase):

        def setUp(self):
            self.tempdir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_XAttrMetadataPP_run(self):

            filename = os.path.join(self.tempdir, "foo.mp4")

            with open(filename, 'wb') as f:
                f.write(b'\0' * 1000)

            dow = object()
           

# Generated at 2022-06-22 09:25:22.776885
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    # set-up unit test
    downloader = DummyYoutubeDL()
    downloader.to_screen = lambda x: x
    downloader.report_error = lambda x: x
    downloader.report_warning = lambda x: x
    pp = XAttrMetadataPP(downloader)

# Generated at 2022-06-22 09:25:23.261238
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-22 09:25:34.128010
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # Prepare arguments
    class FakeYDL():
        def to_screen(self, s):
            pass
        def report_error(self, s):
            pass
    ydl = FakeYDL()
    pp = XAttrMetadataPP(ydl, {})

    # First check must be OK
    filename = 'test_file.mp4'
    info = {
        'filepath': filename,
        'webpage_url': 'http://www.site.com',
        'title': 'title',
        'upload_date': '2018-12-31',
        'description': 'description',
        'uploader': 'uploader',
        'format': 'format',
    }
    res, info = pp.run(info)

    # Second check must be OK

# Generated at 2022-06-22 09:25:36.894024
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass


# Generated at 2022-06-22 09:25:44.623994
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import encode_compat_str

    # Create a downloader
    downloader = FakeYDL()

    # Create an XAttrMetadataPP object
    xattr_pp = XAttrMetadataPP(downloader)

    # Assert unavailabity of xattr raises an exception
    filename = 'video.mp4'
    info = {
        'webpage_url': 'http://example.com/video',
        'title': 'Title',
        'upload_date': '2011-11-11',
        'description': 'Description',
        'uploader': 'Uploader',
        'format': 'Video Format',
    }
    xattr_pp._write_xattr = lambda _, xattrname, value: False  # Simulate that no xattr is available

# Generated at 2022-06-22 09:25:45.263040
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-22 09:25:55.989041
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os
    from ..utils import encodeFilename, xattr_set, xattr_get, XAttrMetadataError, XAttrUnavailableError

    filename = encodeFilename('test_xattr_metadata.webm')
    info = {
        'webpage_url': 'http://s.yt/test_xattr_metadata',
        'description': 'this is a test',
        'upload_date': '20120101',
        'title': 'test xattr metadata',
        'uploader': 'Test Xattr Metadata',
        'format': 'WebM',
        'filepath': filename,
    }


# Generated at 2022-06-22 09:25:58.528492
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    PostProcessor.register_options()
    assert isinstance(XAttrMetadataPP(None), XAttrMetadataPP)

# Generated at 2022-06-22 09:26:06.776591
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor.common import InfoExtractor
    from ..postprocessor.common import PostProcessor
    from ..downloader.common import FileDownloader
    assert(issubclass(XAttrMetadataPP, PostProcessor))
    assert(issubclass(XAttrMetadataPP, PostProcessor))
    ie = InfoExtractor()
    ie.add_default_info_extractors()
    fd = FileDownloader(ie)
    xmp = XAttrMetadataPP(fd)
    assert isinstance(xmp, XAttrMetadataPP)
    assert isinstance(xmp, PostProcessor)
    assert isinstance(xmp, PostProcessor)



# Generated at 2022-06-22 09:26:16.943141
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    #
    # This unit test requires the following packages to be installed:
    #     * PyXattr - https://github.com/python-xattr/xattr
    #     * py.test - http://pytest.org/
    # Or, you can run it from source directory as:
    #     $ python -m pytest -v postprocessor/tests/test_XAttrMetadataPP.py
    #
    # Set the following before running the unit test:
    #     export TEST_VIDEO_OUTPUT=/path/to/test/download/dir
    #     export TEST_VIDEO_URL=https://www.youtube.com/watch?v=BaW_jenozKc
    #
    import os
    from .test_XAttrMetadataPP import XAttrMetadataPP
    from ..utils import to_screen
   

# Generated at 2022-06-22 09:27:03.270685
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .common import FileDownloader
    from ..utils import encodeFilename
    from ..compat import compat_urlparse
    from .get_thumbnail import GetThumbnailPP

    ydl = FileDownloader()
    ydl.postprocessors.append(XAttrMetadataPP())

    # make some fake info dict

# Generated at 2022-06-22 09:27:14.878282
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    try:
        import xattr
        xattr.setxattr(__file__, 'user.xdg.referrer.url', 'http://www.youtube.com/watch?v=BaW_jenozKc')
    except ImportError:
        return
    except OSError:
        return


# Generated at 2022-06-22 09:27:16.867153
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test = XAttrMetadataPP()
    assert test


# Generated at 2022-06-22 09:27:27.505439
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():

    # Tests if XAttrMetadataPP works properly when
    #
    #  * "xattr" is true
    #  * "xattr" is false
    #  * "xattr" is not in options
    #

    # Construct options
    options = {
        'xattr': True,
        'username': 'test_username',
        'password': 'test_password',
    }

    from .common import FileDownloader

    # Construct downloader
    downloader = FileDownloader({'outtmpl': 'test_%(extractor)s-%(id)s-%(format)s.%(ext)s', 'noplaylist' : True, 'logger': None}, options)

    # Initialize pp
    pp = XAttrMetadataPP(downloader)

    # Run pp
    pp.run

# Generated at 2022-06-22 09:27:38.353539
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .common import FileDownloader

    # Filesystem doesn't support extended attributes
    from .XAttrWriteError import XAttrWriteError
    def write_xattr_raises(filepath, xattrname, byte_value):
        raise XAttrWriteError(
            XAttrWriteError.NO_ATTRS, 'user.dublincore.description', 'test.txt')

    xattr_mapping = {
        'user.xdg.referrer.url': 'webpage_url',
        'user.dublincore.title': 'title',
        'user.dublincore.date': 'upload_date',
        'user.dublincore.description': 'description',
    }

    def xlogger(self, message):
        self.xlogger_messages.append

# Generated at 2022-06-22 09:27:42.070414
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..postprocessor.common import PostProcessor
    assert issubclass(XAttrMetadataPP, PostProcessor)
    xattrs = XAttrMetadataPP(downloader=object())
    assert xattrs.downloader is not None

# Generated at 2022-06-22 09:27:44.132266
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    #TODO
    pass

# Generated at 2022-06-22 09:27:45.632716
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    xattrs = XAttrMetadataPP()

    assert xattrs is not None

# Generated at 2022-06-22 09:27:53.229681
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..extractor import gen_extractors
    from .common import FileDownloader
    from ..utils import encodeFilename

    def test_XAttrMetadataPP_run_impl(filename, info):
        downloader = FileDownloader({})
        ie = gen_extractors(downloader, filename)[0](downloader, filename)
        with open(encodeFilename(filename), 'wb') as fh:
            ie.to_stdout = False
            ie.report_warning = lambda msg: fh.write(msg.encode('ascii'))
            ie.report_error = lambda msg: fh.write(msg.encode('ascii'))
            XAttrMetadataPP(downloader).run(info)
        return downloader._fake_output_file.getvalue()

    #
    # Check that

# Generated at 2022-06-22 09:27:59.880565
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    xattr_mapping = {
        'user.xdg.referrer.url': 'webpage_url',
        # 'user.xdg.comment':            'description',
        'user.dublincore.title': 'title',
        'user.dublincore.date': 'upload_date',
        'user.dublincore.description': 'description',
        'user.dublincore.contributor': 'uploader',
        'user.dublincore.format': 'format',
    }

# Generated at 2022-06-22 09:29:16.910633
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP(None)


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-22 09:29:21.060196
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from tempfile import NamedTemporaryFile
    from .download_pp import DownloadPreProcessor

    download_pp = DownloadPreProcessor('/tmp/')
    filename, info = download_pp.run()
    xattr_metadata_pp = XAttrMetadataPP(info)
    xattr_metadata_pp.run(info)

    return True

# Generated at 2022-06-22 09:29:32.547692
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    import os
    import tempfile

    fn = tempfile.mktemp(prefix='youtube-dl-test-xattr-')

    pp = XAttrMetadataPP()

    # Test writing a xattr on a file that doesn't exist
    try:
        pp.run({'filepath': fn, 'upload_date': '20150930'})
        assert False, 'Expected exception not raised'
    except OSError:
        pass

    # Test writing a xattr on a file that does exist
    with open(fn, 'w') as f:
        f.write('test')

    pp.run({'filepath': fn, 'upload_date': '20150930'})


# Generated at 2022-06-22 09:29:37.490250
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .common import FileDownloader
    from .xattr import get_xattr
    from ..utils import encodeFilename
    from ..compat import compat_etree_fromstring


# Generated at 2022-06-22 09:29:41.009738
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP(None)
    assert pp is not None

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-22 09:29:44.900037
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    xattrs_pp = XAttrMetadataPP()
    xattrs_pp.run(
        {
            'title': 'test_title',
            'upload_date': 'test_upload_date',
            'description': 'test_description',
            'uploader': 'test_uploader',
            'format': 'test_format',
            'webpage_url': 'test_webpage_url',
            'filepath': 'test_filepath',
        }
    )

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-22 09:29:47.222297
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-22 09:29:56.682811
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    xattr_metadata_pp = XAttrMetadataPP()
    assert xattr_metadata_pp is not None
    assert type(xattr_metadata_pp) == XAttrMetadataPP

if __name__ == '__main__':
    # cf. http://stackoverflow.com/questions/2582388/how-do-i-run-python-unit-tests-from-the-command-line
    print("Testing the module")
    import sys
    import unittest
    import doctest
    test_suite = doctest.DocTestSuite(__import__('xattr_metadata'))
    test_suite.addTest(unittest.defaultTestLoader.loadTestsFromTestCase(XAttrMetadataPP))
    result = unittest.TextTestRunner().run(test_suite)


# Generated at 2022-06-22 09:30:05.528305
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from .common import FileDownloader
    filename = 'dummy_filename'
    downloader = FileDownloader({'filepath': filename})
    downloader.to_screen = lambda msg: 'dummy to_screen(msg): {}'.format(msg)
    downloader.report_error = lambda msg: 'dummy report_error(msg): {}'.format(msg)
    downloader.report_warning = lambda msg: 'dummy report_warning(msg): {}'.format(msg)
    assert downloader.params['filepath'] == filename
    assert downloader.to_screen
    assert downloader.report_error
    assert downloader.report_warning
    info = {'filepath': filename}
    xattr_pp = XAttrMetadataPP(downloader)
    assert xattr_pp

# Generated at 2022-06-22 09:30:09.116222
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..compat import compat_xattr_supports_unicode

    x = XAttrMetadataPP()
    assert x
    assert x.available() == compat_xattr_supports_unicode()