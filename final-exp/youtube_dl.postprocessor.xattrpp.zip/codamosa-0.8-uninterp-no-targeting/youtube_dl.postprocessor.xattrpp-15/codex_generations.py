

# Generated at 2022-06-22 09:21:14.791563
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import os
    import unittest
    from .common import PostProcessorTestCaller

    class TestXAttrMetadataPP_run(PostProcessorTestCaller):

        def test_ok(self):
            # Create the file to be post-processed
            with open(self.filepath, 'wb') as f:
                f.write(bytes(10*1024))  # 10 kB

            # Set the xattr metadata
            write_xattr(self.filepath, 'user.xdg.referrer.url', 'http://example.org/')
            write_xattr(self.filepath, 'user.dublincore.title', 'Title')
            write_xattr(self.filepath, 'user.dublincore.description', 'Description')

# Generated at 2022-06-22 09:21:15.766704
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    assert True

# Generated at 2022-06-22 09:21:18.262257
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pass # This class is used as a base class. Should never be instantiated alone.

# Generated at 2022-06-22 09:21:28.354915
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    class Info:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    class Context:
        def to_screen(self, message):
            print(message)

        def report_error(self, message):
            print('ERROR: ' + message)

        def report_warning(self, message):
            print('WARNING: ' + message)

    from .common import FileDownloader

    # A proper downloader object is required for setting the xattrs (to get verbosity and error reporting)
    d = FileDownloader({})
    d.params = {}
    d.params['verbose'] = False
    d.params['nopart'] = False
    d.params['updatetime'] = False
    d.params['test'] = False
    d.params['writedescription']

# Generated at 2022-06-22 09:21:31.423511
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP('.', {}, {}, {}, {})._downloader



# Generated at 2022-06-22 09:21:33.818102
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert True

if __name__ == "__main__":
    test_XAttrMetadataPP()

# Generated at 2022-06-22 09:21:42.624100
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import tempfile
    import shutil
    import os
    import sys
    import re
    import json

    from ..downloader import YoutubeDL

    # Create a temp folder to test extended attributes
    folder = tempfile.mkdtemp()
    os.chdir(folder)

    class TestYDL(YoutubeDL):
        def to_screen(self, msg): print(msg)

    # Test normal execution
    testinfos = [{'filepath': os.path.join(folder, 'test1'), 'webpage_url': 'https://example.com/test1', 'title': 'Test 1', 'upload_date': '20180101', 'description': 'This is a test', 'uploader': 'Youtube-DL', 'format': 'best'}]
    test_ydl = TestYDL()
    pp = XAttr

# Generated at 2022-06-22 09:21:52.751722
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..ytdl_config import YtdlConfig
    from ..utils import get_xattr

    class FakeYdl:
        def __init__(self):
            self.params = YtdlConfig('--xattr')

    class FakeInfo:
        def __init__(self):
            self.filepath = b'a-file-to-test.mp4'
            self.webpage_url = 'http://www.youtube.com/watch?v=AH5RJZo6nxU'
            self.upload_date = '20130905'
            self.title = 'fake title'
            self.description = 'fake description'
            self.uploader = 'fake uploader'
            self.format = 'fake format'
            self.id = 'fakeid'

    fake_info = FakeInfo()
    fake

# Generated at 2022-06-22 09:21:54.055233
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP(None)._downloader is None

# Generated at 2022-06-22 09:22:05.832364
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import sys
    import os
    
    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
    
    from .common import PostProcessor
    from ..compat import compat_os_name
    from ..utils import (
        hyphenate_date,
        write_xattr,
        XAttrMetadataError,
        XAttrUnavailableError,
    )
    

# Generated at 2022-06-22 09:22:22.555713
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    TEST_FILEPATH = 'test.mp4'
    TEST_URL = 'http://test.com/test.mp4'
    TEST_TITLE = 'Test Title'
    TEST_FORMAT = 'Test Format'
    TEST_UPLOAD_DATE = '20160821'
    TEST_UPLOADER = 'Test Uploader'
    TEST_DESCRIPTION = 'Test Description'
    TEST_WEBPAGE_URL = 'http://test.com/test_webpage.html'


# Generated at 2022-06-22 09:22:34.350215
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .test_postprocessor import TestPostProcessor
    from ..utils import encodeFilename
    import os
    import sys

    info = {
        'filepath': './test',
        'webpage_url': 'http://www.website.com/video?v=123456789',
        'title': 'Lorem ipsum dolor sit amet',
        'upload_date': '20111111',
        'description': 'Maecenas euismod odio quis est ultricies, sed luctus enim pellentesque. ',
        'uploader': 'Auctor Glavrida',
        'format': 'mp4',
    }

    #
    # Enabled
    #
    postprocessor = XAttrMetadataPP()
    postprocessor.available = True

    # Write the metadata to the file

# Generated at 2022-06-22 09:22:45.105517
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import sys
    import shutil
    import tempfile
    import xattr
    import unittest
    import urllib2

    ############################################################
    # create a temporary file
    ############################################################
    tmpdir = tempfile.mkdtemp()
    tmpfile = tempfile.mkstemp(dir=tmpdir)
    tmppath = tmpfile[1]
    f = tmpfile[0]
    f.close()

    ############################################################
    # create a temporary fake file
    ############################################################
    # mimic the response of youtube-dl on a fake file
    fake_url = 'http://www.example.com/test.mp4'

# Generated at 2022-06-22 09:22:51.132626
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert issubclass(XAttrMetadataPP, PostProcessor)
    assert hasattr(XAttrMetadataPP, 'run')
    assert callable(XAttrMetadataPP.run)
    xattr_metadata_pp = XAttrMetadataPP(_downloader=None)
    assert xattr_metadata_pp is not None


# Generated at 2022-06-22 09:23:01.717442
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    import sys
    import os
    import pytest
    sys.path.append(os.path.join(os.path.dirname(__file__), ".."))
    from ytdl_server.youtube_dl.YoutubeDL import YoutubeDL
    from ytdl_server.youtube_dl.extractor.common import InfoExtractor
    from ytdl_server.youtube_dl.postprocessor.common import PostProcessor
    from ytdl_server.youtube_dl.compat import compat_os_name
    from ytdl_server.youtube_dl.utils import (
        hyphenate_date,
        write_xattr,
        XAttrMetadataError,
        XAttrUnavailableError,
    )


# Generated at 2022-06-22 09:23:04.033393
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    """
    Tests for XAttrMetadataPP contructor
    """
    from . import YoutubeDL
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    assert isinstance(XAttrMetadataPP(ydl), XAttrMetadataPP)

test_XAttrMetadataPP()

# Generated at 2022-06-22 09:23:12.789505
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():

    from ..downloader import FakeYDL
    from ..extractor import YoutubeIE
    from ..utils import DateRange

    dl = FakeYDL()


# Generated at 2022-06-22 09:23:17.240304
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
  from ..extractor import VideoExtractor

  class TestXAttrMetadataPP(XAttrMetadataPP):
    def __init__(self):
      super(TestXAttrMetadataPP, self).__init__()

  dummy = VideoExtractor()
  xattrpp = TestXAttrMetadataPP()
  assert dummy == xattrpp._downloader


# Generated at 2022-06-22 09:23:20.515672
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP.__doc__

    #
    # Call the constructor (without initializing the object)
    #
    x = XAttrMetadataPP(None)

# Generated at 2022-06-22 09:23:30.755834
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    
    import downloads

    # Assign argument
    d_argv = [
        '-f',
        'bestvideo[height<=?720]+bestaudio/best',
        '--write-thumbnail',
        '--write-info-json',
        '--output',
        '%(title)s-%(id)s.%(ext)s',
        'https://www.youtube.com/watch?v=BaW_jenozKc'
    ]
    
    # Create an instance of YoutubeDL
    y = downloads.YoutubeDL()
    y.process_ie_result = lambda a, b, c: {}

    # Create an instance of XAttrMetadataPP
    pp = XAttrMetadataPP()
    pp._downloader = y
    
    # Simulate the metadata information returned from YoutubeDL

# Generated at 2022-06-22 09:23:48.061912
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from . import _common_test_info

    info = _common_test_info

    class MockFileDownloader:
        def to_screen(self, message):
            pass
        def report_error(self, message):
            raise XAttrMetadataError(message)
        def report_warning(self, message):
            raise XAttrMetadataError(message)

    pp = XAttrMetadataPP(MockFileDownloader())
    pp.run(info)

if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-22 09:23:57.053952
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    metadata = {
        'title': 'test title',
        'webpage_url': 'http://google.com',
        'upload_date': '20130512',
        'description': 'test description',
        'uploader': 'test uploader',
        'format': 'test format',
    }

    filename = ""
    pp = XAttrMetadataPP(None)

    try:
        warnings, info = pp.run(metadata)
        assert len(warnings) == 0
        assert info == metadata
    except:
        warnings, info = [], {}

    # Return warnings, info as they will be
    return warnings, info

if __name__ == "__main__":
    test_XAttrMetadataPP_run()

# Generated at 2022-06-22 09:24:04.893797
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import pytest

    from .common import FileDownloader
    from ..extractor.common import InfoExtractor


    # Test empty info
    info = {}
    info_empty = {}
    pp = XAttrMetadataPP(FileDownloader(InfoExtractor()))
    pp.run(info)
    assert info == info_empty

    # Test full info
    info = {
        'webpage_url': 'http://original.url.webpage.com/video.html',
        'description': 'A video about foo, bar and some spam',
        'title': 'Title of the video © - ▶',
        'upload_date': '20140325',
        'uploader': 'Author of the video',
        'format': 'Format of the video',
    }

# Generated at 2022-06-22 09:24:06.628690
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP('metadata')
    assert pp is not None

# Generated at 2022-06-22 09:24:10.800146
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .test_utils import get_test_info
    info = get_test_info()
    from .compat import FakeFile

    info['webpage_url'] = 'http://www.youtube.com/'
    info['ext'] = 'mp4'
    info['title'] = 'A test title'
    info['upload_date'] = '20130125'
    info['description'] = 'A test description'
    info['uploader'] = 'A test uploader'
    info['format'] = 'A test format'
    info['filepath'] = 'test.mp4'


# Generated at 2022-06-22 09:24:22.840677
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os
    import shutil
    import tempfile
    import xattr

    from .mock import FileDownloader

    from .mock import mock_info_dict

    tmpdir = tempfile.mkdtemp()
    tempfilename = os.path.join(tmpdir, 'video.mp4')


# Generated at 2022-06-22 09:24:24.981005
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_pp = XAttrMetadataPP(None)

# Generated at 2022-06-22 09:24:25.779598
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pass

# Generated at 2022-06-22 09:24:36.804303
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import xattr_writable

    if not xattr_writable('.'):
        raise IOError('xattr is not supported')

    filename = "test.mp4"
    from ..extractor import YoutubeIE
    from ..extractor import YoutubePlaylistIE
    from ..utils import DateRange, Date


# Generated at 2022-06-22 09:24:40.680989
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from .support import FakeYDL
    ydl = FakeYDL()
    pp = XAttrMetadataPP(ydl)
    assert pp._downloader is ydl
    assert pp.name == 'xattr'

# Generated at 2022-06-22 09:25:11.979389
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import tempfile
    import codecs
    import os
    old_stderr, old_stdout = sys.stderr, sys.stdout
    sys.stderr = sys.stdout = codecs.open(os.devnull, 'w', 'utf-8')
    try:
        import youtube_dl
    finally:
        sys.stderr, sys.stdout = old_stderr, old_stdout
    # directory with a temporary file
    directory = tempfile.mkdtemp()
    # name of the temporary file
    mytempfile = os.path.join(directory, 'tempfile.txt')
    # definition of the data (empty)

# Generated at 2022-06-22 09:25:21.725906
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import sys
    import unittest

    class Test_XAttrMetadataPP_run(unittest.TestCase):

        def setUp(self):
            self.pp = XAttrMetadataPP(None)

        def test_1(self):
            from ..extractor import YoutubeIE

            # Create test dict with all valid metadata
            test_dict = dict(YoutubeIE()._WORKING_DEFAULT_INFO_DICT)
            test_dict['format'] = 'webm'

            # Valid metadata
            info = (
                [],
                test_dict
            )

            expected_output = (
                [],
                test_dict
            )

            output = self.pp.run(info)

            self.assertTrue(output == expected_output, msg=(test_dict, output, expected_output))

    suite

# Generated at 2022-06-22 09:25:31.543042
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP('test_XAttrMetadataPP', {})

    # Check if extended attributes is available
    try:
        write_xattr('/', 'user.test.foo', 'bar')
    except XAttrUnavailableError as e:
        print(str(e))
        assert False

    try:
        info = {}
        pp.run(info)
    except Exception as e:
        print(str(e))
        assert False

    # Check hyphenate_date function
    assert hyphenate_date('20100123') == '2010-01-23'
    assert hyphenate_date('2010123') == '2010-01-23'
    assert hyphenate_date('20101217') == '2010-12-17'

# Generated at 2022-06-22 09:25:40.151310
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # This function is NOT tested.
    # To be tested we need a filesystem and a system that supports xattrs,
    # and i don't know how to do so.

    # Probably, on linux, the following code could work
    # >>> from pyxattr import xattr
    # >>> with open('somefile.txt', 'wb') as f:
    # ...     pass
    # ...
    # >>> xattr.setxattr('somefile.txt', 'user.testattr', 'testvalue')
    # >>> xattr.getxattr('somefile.txt', 'testattr')
    # ...
    # KeyError: 'testattr'
    # >>> xattr.getxattr('somefile.txt', 'user.testattr')
    # ...
    # 'testvalue'

    assert (False)

# Generated at 2022-06-22 09:25:51.479025
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    from collections import namedtuple
    from ..utils import (
        xattr_set,
        xattr_get,
        XAttrMetadataError,
    )

    def get_result(pp, info):
        for ie in pp._ies:
            ie.set_downloader(None)
        pp._ies = []
        return pp.run(info)

    # This test requires that /tmp is a filesystem that supports xattrs
    # - use 'df -T' or 'mount' to check that /tmp is not tmpfs
    # - test on MacOS X 10.10 Yosemite: pass.
    # - test on MacOS X 10.11 El Capitan: pass.
    # - test on Debian 7: pass.
    # - test on Windows 10: fail.

    # prepare

    import os
    import tempfile

# Generated at 2022-06-22 09:25:52.765585
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    'Test method run of XAttrMetadataPP'
    assert False


# Generated at 2022-06-22 09:25:53.297132
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-22 09:25:57.415238
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-22 09:26:06.973129
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    filename = '../tests/files/45';
    xattr_mapping = [
        ('user.xdg.referrer.url', 'webpage_url'),
        ('user.xdg.comment', 'description'),
        ('user.dublincore.title', 'title'),
        ('user.dublincore.date', 'upload_date'),
        ('user.dublincore.description', 'description'),
        ('user.dublincore.contributor', 'uploader'),
        ('user.dublincore.format', 'format'),
    ]

# Generated at 2022-06-22 09:26:16.730907
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
  import sys

  test_downloader = sys.modules[__name__]
  pp = XAttrMetadataPP(test_downloader, sys.modules[__name__])

  test_downloader.to_screen = lambda x: ''
  test_downloader.report_warning = lambda x: ''
  test_downloader.report_error = lambda x: ''

  test_downloader.xattr_write = lambda x, y, z: {}

  pp.run({'title': 'A test', 'filepath': 'test.file'})

  test_downloader.xattr_write = lambda x, y, z: {'reason': 'NO_SPACE'}

  pp.run({'title': 'A test', 'filepath': 'test.file2'})

# Generated at 2022-06-22 09:26:59.745449
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pass

# Generated at 2022-06-22 09:27:03.017868
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    try:
        xatt = XAttrMetadataPP(None)
    except:
        print('ERROR: Unable to create an instance of XAttrMetadataPP!')
        return


# Generated at 2022-06-22 09:27:11.211286
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import io
    import os
    import sys
    import tempfile
    import unittest

    from . import FakeYDL
    from ..downloader.common import FileDownloader


    class TestXAttrMetadataPP(unittest.TestCase):
        """Unit tests for method run of class XAttrMetadataPP"""

        def setUp(self):
            self.fd, self.temp_filename = tempfile.mkstemp()
            # close the temp file so it can be opened by FileDownloader
            os.close(self.fd)
            self.fake_ydl = FakeYDL()
            self.ydl = FileDownloader(self.fake_ydl)

        def tearDown(self):
            os.remove(self.temp_filename)


# Generated at 2022-06-22 09:27:11.803526
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-22 09:27:14.278985
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_pp = XAttrMetadataPP(None)
    assert test_pp


if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-22 09:27:16.594624
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass


# TODO: implement unit tests for class XAttrMetadataPP

# Generated at 2022-06-22 09:27:26.958609
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # we need to use a real file to get the stat function (xattr.py) working
    import os
    # create a temporary file
    fn = '/tmp/youtubedl-test/' + os.urandom(16).encode('hex')
    folder = os.path.dirname(fn)
    if not os.path.exists(folder):
        os.makedirs(folder)
    open(fn, 'w').close()
    # now create the XAttrMetadataPP
    pp = XAttrMetadataPP({'filepath': fn})
    # we can now delete the temporary file
    os.remove(fn)
    os.rmdir(folder)

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-22 09:27:28.249048
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-22 09:27:38.813189
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    msg = 'Expected error message, but no error raised'

    pp = XAttrMetadataPP()
    pp._downloader = None

    def _report_error(msg):
        raise AssertionError('Reported error: ' + msg)

    pp._report_error = _report_error

    # Test without xattr support
    orig_write_xattr = write_xattr
    write_xattr = lambda _a, _b, _c: False

    info = {
        'webpage_url': 'url',
        'title': 'title',
        'upload_date': 'date',
        'description': 'description',
        'format': 'format',
        'uploader': 'uploader'
    }


# Generated at 2022-06-22 09:27:49.568780
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    def write_xattr(filename, xattrname, byte_value):
        assert filename == 'test_filename'
        assert byte_value.decode('utf-8') == {
            'user.xdg.referrer.url': 'test_webpage_url',
            'user.dublincore.title': 'test_title',
            'user.dublincore.date': '20130303',
            'user.dublincore.description': 'test_description',
            'user.dublincore.contributor': 'test_uploader',
            'user.dublincore.format': 'test_format',
        }[xattrname]

        return


# Generated at 2022-06-22 09:29:20.642327
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():

    import ydl_test

    # Create a PostProcessor object
    test_pp = XAttrMetadataPP(ydl_test.FakeYDL())

    # Test the object
    assert test_pp != None

# Test run method

# Generated at 2022-06-22 09:29:25.021592
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP(None).run({})[0] == []


# Generated at 2022-06-22 09:29:33.852838
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():       # pylint:disable=undefined-variable
    from .test_common import FakeYDL
    from .test_common import FakeInfoExtractor
    from .test_common import TEST_FILE

    class FakeXAttrMetadataPP(XAttrMetadataPP):

        def run(self, info):
            return super(FakeXAttrMetadataPP, self).run(info)

    ydl = FakeYDL()
    ie = FakeInfoExtractor()
    test_file_name = ydl.prepare_filename(ie.ie_key())

    # Copy a test file because unit tests should not change the original files.
    from shutil import copyfile
    copyfile(TEST_FILE, test_file_name)


# Generated at 2022-06-22 09:29:36.851360
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    """
    Does not test the constructor of class XAttrMetadataPP.
    """
    pass

# Generated at 2022-06-22 09:29:46.026583
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from .common import FileDownloader
    class FakeYDL(FileDownloader):
        def __init__(self):
            self.params = {'verbose': True}

    ydl = FakeYDL()
    pp = XAttrMetadataPP(ydl)

    # Test that a dummy file and its metadata are created OK.
    import os.path
    import tempfile
    import time
    tempdir = tempfile.mkdtemp()
    tempfilepath = os.path.join(tempdir, 'xattr-test-file.txt')
    tempf = open(tempfilepath, 'w')
    tempf.write('test file')
    tempf.close()
    info = {}
    info['filepath'] = os.path.join(tempfilepath)

# Generated at 2022-06-22 09:29:51.851571
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..YoutubeDL import YoutubeDL
    from ..extractor import YoutubeIE
    from ..postprocessor import FFmpegMetadataPP
    url = 'http://www.youtube.com/watch?v=WKsjaOqDXgg'
    info = YoutubeDL({}).extract_info(url, download=False)
    PP = XAttrMetadataPP()
    PP.run(info)

# Generated at 2022-06-22 09:30:00.217163
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..downloader import FileDownloader
    from ..extractor import YoutubeIE
    from ..utils import encodeFilename

    ydl = FileDownloader({
        'outtmpl': encodeFilename('test.%(ext)s'),
        'postprocessors': [{
            'key': 'XAttrMetadataPP',
        }],
        'geo_bypass': True
    })
    url = 'https://www.youtube.com/watch?v=Bg9r_yLk7VY'
    ydl.add_info_extractor(YoutubeIE())
    ydl.download([url])

# Generated at 2022-06-22 09:30:09.208142
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os

    #(info_dict, pp):
    import tempfile
    with tempfile.TemporaryDirectory() as tempdir:
        filename = os.path.join(tempdir, 'yt-dl.txt')
        info = {}
        pp = XAttrMetadataPP()
        pp._downloader = object()
        pp._downloader.report_warning = print
        pp._downloader.report_error = print
        pp._downloader.to_screen = print
        pp.run(info)


if __name__ == "__main__":
    test_XAttrMetadataPP_run()

# Generated at 2022-06-22 09:30:09.897971
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pass

# Generated at 2022-06-22 09:30:11.448070
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    xattr_pp = XAttrMetadataPP()
    assert xattr_pp is not None