

# Generated at 2022-06-22 09:21:15.599456
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..downloader import Downloader
    from ..extractor import YoutubeIE
    from .common import PostProcessorTest
    from .test_metadataFromTitlePP import test_metadataFromTitlePP

    dl = Downloader(params={'writedescription': True})

    dl.add_info_extractor(YoutubeIE(dl))


# Generated at 2022-06-22 09:21:27.074918
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():

    class FakeInfo(object):
        def __init__(self, data):
            self.data = data

        def get(self, key):
            return self.data.get(key)

        def __contains__(self, key):
            return key in self.data

    class FakeYDL(object):
        def __init__(self, data):
            self.data = data

        def to_screen(self, s):
            pass

        def report_warning(self, s):
            pass

        def report_error(self, s):
            pass

    print('Testing constructor of class XAttrMetadataPP')
    pp = XAttrMetadataPP()
    if pp.available:
        print('OK: the constructor of class XAttrMetadataPP works')

# Generated at 2022-06-22 09:21:39.252871
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # Test constructor of class XAttrMetadataPP
    file_name = ['Video.mp4']
    ydl_opts = {
        'outtmpl': '%(extractor)s-%(upload_date)s-%(id)s-%(title)s.%(ext)s',
        'format': "bestvideo[ext=mp4][height<=?1080]+bestaudio[ext=m4a]/best[ext=mp4]/best"
    }
    # Create an instance of class Downloader
    d = Downloader(ydl_opts)
    # Create an instance of class InfoExtractor
    ie = InfoExtractor()
    # Create an instance of class XAttrMetadataPP
    pp = XAttrMetadataPP(d, ie)

# Generated at 2022-06-22 09:21:41.639554
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-22 09:21:42.380025
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    return XAttrMetadataPP(None)

# Generated at 2022-06-22 09:21:43.250439
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-22 09:21:51.608609
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    """
    Test the XAttrMetadataPP. __init__ function.
    
    Test the __init__ function, making sure that if certain mandatory keyword arguemnts are
    not passed, we get an error. 
    """
    # We want to make sure that we get an error when we do not pass the mandatory keyword arguments
    # by passing in the kwargs in the wrong order and missing a keyword argument
    # assert_raises is a helper method to check that a specific exception gets thrown
    with assert_raises(TypeError):
        XAttrMetadataPP('test', 'testing', yt_dl=None, downloader=None)

# Generated at 2022-06-22 09:21:52.542874
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # No references to external resources
    pass

# Generated at 2022-06-22 09:21:54.237982
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass


if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-22 09:22:06.046165
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .common import FileDownloader
    from ..utils import (
        XAttrMetadataError,
        XAttrUnavailableError,
        read_xattr,
    )
    from sys import platform

    def set_xattr_mapping():
        xattr_mapping = {
            'user.xdg.referrer.url': 'webpage_url',
            # 'user.xdg.comment':            'description',
            'user.dublincore.title': 'title',
            'user.dublincore.date': 'upload_date',
            'user.dublincore.description': 'description',
            'user.dublincore.contributor': 'uploader',
            'user.dublincore.format': 'format',
        }
        return xattr_m

# Generated at 2022-06-22 09:22:22.037732
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import encodeFilename
    from ..compat import unicode_str
    from ..downloader.common import FileDownloader
    from ..downloader.http import HttpFD
    import os
    import tempfile

    # Create a temporary file
    video_data = b'\x00\x01\x02\x03'
    temp_dir = tempfile.mkdtemp()
    temp_file_name = encodeFilename(os.path.join(temp_dir, b'video.tmp'), True)
    with open(temp_file_name, 'wb') as temp_file:
        temp_file.write(video_data)

    # Create a temporary file downloader

# Generated at 2022-06-22 09:22:33.812944
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import os
    import shutil

    from tempfile import mkdtemp
    from .test_downloader import MockYoutubeDL

    class MockYoutubeDLXAttrMetadataPP(MockYoutubeDL):

        __options = {
            'outtmpl': '%(id)s.%(ext)s',
            'writedescription': True,
            'writeinfojson': True,
            'writeannotations': True,
            'write_all_thumbnails': True,
            'write_images': True,
            'writesubtitles': True,
        }

        def __init__(self):
            super(MockYoutubeDLXAttrMetadataPP, self).__init__(self.__options)
            self.tempdir = mkdtemp()

# Generated at 2022-06-22 09:22:40.295542
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    info = {
        'title': 'Video Title',
        'webpage_url': 'https://example.com/page',
        'description': 'Video Description',
        'upload_date': '20180705',
        'uploader': 'John Doe',
        'format': '3gp',
        'filepath': 'test.3gp',
    }
    XAttrMetadataPP(None).run(info)

# Generated at 2022-06-22 09:22:50.339327
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    from .common import FileDownloader
    from .common import prepare_mock_downloader

    # Test a real youtube video metadata
    downloader = FileDownloader(prepare_mock_downloader(params={
        'writethumbnail': True,
        'writedescription': True,
        'writeinfojson': True,
        'writeannotations': True,
        'writeautomaticsub': True,
        'writesubtitles': True,
        'prefer_free_formats': False,
    }))

# Generated at 2022-06-22 09:22:53.320343
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    xattr_metadata = XAttrMetadataPP()
    assert type(xattr_metadata) == XAttrMetadataPP

# Generated at 2022-06-22 09:23:01.437925
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    filename = '/tmp/video.mp4'
    info = {
        'filepath': filename,
        'webpage_url': 'http://example.com/video_url',
        'title': 'This is a title',
        'upload_date': '20170223',
        'description': 'This is a description of the video',
        'uploader': 'This is the uploader name',
        'format': 'This is the video format',
    }
    return XAttrMetadataPP().run(info)

if __name__ == '__main__':
    # Run unit test
    print(test_XAttrMetadataPP_run())

# Generated at 2022-06-22 09:23:03.370990
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    import sys
    import doctest
    doctest.testmod(sys.modules[__name__])

# class XAttrMetadataPP

# Generated at 2022-06-22 09:23:12.373646
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..downloader.common import FileDownloader
    from ..YoutubeDL import YoutubeDL
    from .getid import GetIDPP
    from .extract_title import TitlePP

    # Create a downloader object:
    ydl_opts = {}  # use default options
    dl = FileDownloader(ydl_opts)

    # Populate FileDownloader with info
    info = {}

    info['id'] = 'OEoXaMPEzfM'
    GetIDPP().pp_result(dl, info)

    info['title'] = 'Hail to the Victors'
    info['ext'] = 'mp3'
    TitlePP().pp_result(dl, info)

    info['url'] = 'http://www.youtube.com/watch?v=OEoXaMPEzfM'
    info

# Generated at 2022-06-22 09:23:21.520197
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    """
    Unit test for constructor of class XAttrMetadataPP
    """
    # Stub class that simulates a YoutubeIE
    from ..extractor import YoutubeIE
    from ..postprocessor import FFmpegMetadataPP
    class YoutubeDLE(YoutubeIE):
        def __init__(self, ydl):
            YoutubeIE.__init__(self, ydl)

    class YoutubePostProcessor(XAttrMetadataPP, FFmpegMetadataPP):
        def __init__(self, downloader=None):
            PostProcessor.__init__(self, downloader)
            FFmpegMetadataPP.__init__(self, downloader)
            XAttrMetadataPP.__init__(self, downloader)
        def run(self, info):
            return XAttrMetadataPP.run(self, info)



# Generated at 2022-06-22 09:23:24.103216
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    xattr_pp = XAttrMetadataPP()
    assert isinstance(xattr_pp, PostProcessor)


# Generated at 2022-06-22 09:23:43.054826
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..YoutubeDL import YoutubeDL
    from .common import FileDownloader
    from .get_filename import GetFileNameTest

    gfn_test = GetFileNameTest()
    gfn_test.test_get_basename()

    test_file = YoutubeDL(gfn_test.ydl).prepare_filename('http://www.youtube.com/watch?v=BaW_jenozKc')

    assert test_file == gfn_test.ydl.prepare_filename('https://example.com/watch?v=BaW_jenozKc')

# Generated at 2022-06-22 09:23:45.525378
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass


if __name__ == "__main__":
    test_XAttrMetadataPP_run()

# Generated at 2022-06-22 09:23:54.093856
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..downloader import Downloader

    downloader = Downloader()
    downloader.postprocessors = [XAttrMetadataPP]

    info = {
        'filepath': 'test.mp4',
        'webpage_url': 'https://www.youtube.com/watch?v=TlLbU6gvMeY',
        'title': 'Video title',
        'upload_date': '20150430',
        'description': 'Video description',
        'uploader': 'Uploader name',
        'format': 'Video format',
    }

    downloader.postprocessors[0].run(info)

# Generated at 2022-06-22 09:23:55.462139
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert isinstance(XAttrMetadataPP(), PostProcessor)

# Generated at 2022-06-22 09:23:58.497956
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor import gen_extractors

    x = XAttrMetadataPP(gen_extractors())
    x.run(None)

# Generated at 2022-06-22 09:24:01.722881
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..utils import s
    pp = XAttrMetadataPP(None)

    assert pp.run({'filepath': 'test.mp4', 'title': s('test title')}) == ([], {'filepath': 'test.mp4', 'title': s('test title')})

# Generated at 2022-06-22 09:24:03.530661
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # I'm not aware of a way to test this.
    pass



# Generated at 2022-06-22 09:24:14.008182
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import os
    import tempfile
    from .common import FileDownloader

    filename = tempfile.mkstemp(suffix='.mp4', prefix='test_ytdl_')[1]
    down = FileDownloader({'outtmpl': filename, 'quiet': True})

    from .extractor import YoutubeIE
    ie = YoutubeIE(down)

    # retrieve some info
    ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')

    pp = XAttrMetadataPP(down)

# Generated at 2022-06-22 09:24:24.395897
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    class FakeDownloader:
        def report_error(self, s):
            print('ERROR: %s' % s)

        def report_warning(self, s):
            print('WARNING: %s' % s)

        def to_screen(self, s):
            print('SCREEN %s' % s)

    class FakeInfo:
        def get(self, infoname):
            if infoname == 'webpage_url':
                return 'http://my_webpage_url'
            elif infoname == 'title':
                return 'my_title'
            elif infoname == 'upload_date':
                return '20101010'
            elif infoname == 'description':
                return 'my_description'
            elif infoname == 'uploader':
                return 'my_uploader'

# Generated at 2022-06-22 09:24:25.546636
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass
    

# Generated at 2022-06-22 09:24:55.067066
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..YoutubeDL import YoutubeDL

    def test_write_xattr(filename, xattrname, byte_value):
        print('Write to xattr: %r %r %r %r' % (filename, xattrname, byte_value, byte_value.decode('ascii')))

    ydl = YoutubeDL({})

    ydl.postprocessors = [{
        'key': 'XAttrMetadataPP',
    }]

    ydl.add_info_extractor(object())

    def _hook_progress(status):
        print(status)

    ydl.progress_hooks = [_hook_progress]

    write_xattr_old = YoutubeDL.write_xattr

# Generated at 2022-06-22 09:24:56.078448
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP({})

# Generated at 2022-06-22 09:25:03.923001
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    def fake_write_xattr(filename, xattrname, byte_value):
        """ Simulate the write_xattr function. """
        fake_write_xattr.called = True
        fake_write_xattr.filename = filename
        fake_write_xattr.xattrname = xattrname
        fake_write_xattr.byte_value = byte_value
        if xattrname == 'user.unknown':
            raise XAttrMetadataError('NO_SPACE')
        elif xattrname == 'user.dublincore.title':
            raise XAttrMetadataError('VALUE_TOO_LONG')


    # Test input data
    from ..postprocessor import FFmpegPostProcessor
    from ..postprocessor.ffmpeg import FFmpegPostProcessor

# Generated at 2022-06-22 09:25:06.548391
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP()
    assert pp is not None

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-22 09:25:07.610839
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass


# Generated at 2022-06-22 09:25:08.678839
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP({}) is not None

# Generated at 2022-06-22 09:25:09.714737
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP(None)

# Generated at 2022-06-22 09:25:10.324684
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-22 09:25:17.885242
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .common import TestDownloadYoutubeDL
    from ..utils import xattr_set

    dl = TestDownloadYoutubeDL({
        'outtmpl': '%(id)s.%(ext)s',
        'writedescription': True,
        'writeannotations': True,
        'forcefilename': True,
    })

    #
    # Test normal behaviour
    #
    info = {
        'id': 'test_id',
        'ext': 'test_ext',
        'webpage_url': 'test_webpage_url',
        'title': 'test_title',
        'description': 'test_description',
        'upload_date': 'test_upload_date',
        'uploader': 'test_uploader',
        'format': 'test_format',
    }

# Generated at 2022-06-22 09:25:22.190646
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..ytdl.YoutubeDL import YoutubeDL
    downloader = YoutubeDL({})
    pp = XAttrMetadataPP(downloader)
    downloader.add_post_processor(pp)
    assert(pp is not None)

# Generated at 2022-06-22 09:26:07.940811
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from .. import YoutubeDL
    from ..extractor.youtube import YoutubeIE
    from ..postprocessor.common import PostProcessor
    from ..downloader.common import FileDownloader
    from tempfile import mkstemp
    from .postprocessor_test import MockYDL
    from .postprocessor_test import add_default_extra_config
    add_default_extra_config()
    xattr_mock_info = dict(id='R4L_7r1Fv-8', title='sample-video')

    with MockYDL({'outtmpl': '%(id)s'}) as ydl:
        ydl.add_default_info_extractors()
        ydl.add_info_extractor(YoutubeIE())
        ydl.prepare_filename(xattr_mock_info)
        # run XAtt

# Generated at 2022-06-22 09:26:10.554274
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP({})
    assert pp._downloader is not None



# Generated at 2022-06-22 09:26:20.871393
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    class DummyDownloader:
        def to_screen(self, msg):
            print(msg)

        def report_error(self, msg):
            raise IOError(msg)

        def report_warning(self, msg):
            raise Warning(msg)

    dummy_downloader = DummyDownloader()
    xattr_pp = XAttrMetadataPP(dummy_downloader)

    info = {
        'webpage_url': 'http://www.example.com',
        'title': 'Test video title',
        'upload_date': '20110609',
        'description': 'Test video description',
        'uploader': 'Test uploader name',
        'format': 'Test video format',
        'filepath': 'test_video_path',
    }

    xattr_pp.run(info)


#

# Generated at 2022-06-22 09:26:27.663336
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    import sys
    import unittest
    import os

    # Todo: write this unit test
    unittest.skipIf(compat_os_name == 'nt', "XAttrMetadataPP.__init__(): Unit test for constructor of class XAttrMetadataPP not written yet for Windows.")
    if not os.path.exists('/etc/fstab'):
        unittest.skipIf(True, 'Test requires access to /etc/fstab')

    write_xattr(sys.executable, 'xyz', '123')

    

# Generated at 2022-06-22 09:26:38.769963
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    """ Test method run of class XAttrMetadataPP. """

    from ..extractor.generic import YoutubeIE
    from ..downloader.f4m import F4mFD
    from ..utils import write_xattr, read_xattr
    import tempfile
    import time
    import os

    # Create a temp file to test
    (tmp_fd, tmp_filepath) = tempfile.mkstemp()
    os.close(tmp_fd)

    test_url = 'https://www.youtube.com/watch?v=BaW_jenozKc'
    test_videoid = 'BaW_jenozKc'
    test_fixed_date = '20121002'
    test_format = '22'

# Generated at 2022-06-22 09:26:41.261095
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    return XAttrMetadataPP(Any())

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-22 09:26:44.156565
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    assert True

# Generated at 2022-06-22 09:26:53.782570
# Unit test for method run of class XAttrMetadataPP

# Generated at 2022-06-22 09:27:03.078968
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    YDL = YDL()
    # Testing ExtendedAttribute metadata extraction
    # Check if xattr is available
    if not has_write_xattr('./test.txt'):
        # If not available all the tests are skipped
        skip_all_tests()
    # Testing start
    pp = XAttrMetadataPP(YDL)
    # Testing normal functionality
    YDL.params['format'] = 'best[ext=mp4]'
    YDL.params['nooverwrites'] = True
    try:
        remove_file('./test.txt')
    except:
        pass
    assert not has_write_xattr('./test.txt')

# Generated at 2022-06-22 09:27:05.654194
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

if __name__ == "__main__":
    import nose
    nose.runmodule()

# Generated at 2022-06-22 09:28:31.651883
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    downloader = open('this_is_a_tricky_filename_and_path', 'w')
    downloader.extract_info = lambda *a, **k: {'filepath': 'this_is_a_tricky_filename_and_path'}
    downloader.report_error = lambda *a, **k: None
    downloader.report_warning = lambda *a, **k: None
    downloader.to_screen = lambda *a, **k: None
    pp = XAttrMetadataPP(downloader)
    assert pp is not None

# Generated at 2022-06-22 09:28:35.110904
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    """
    This is a test for XAttrMetadataPP
    """
    # Scenario: creation of XAttrMetadataPP
    # Given: I want to create XAttrMetadataPP
    # When: I create the XAttrMetadataPP
    # Then: no exception is raised
    PostProcessor()

# Generated at 2022-06-22 09:28:44.091937
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .common import FileDownloader
    from .f4mmanifest import F4MManifestPP
    from .hls_select import HLSSelectPP
    from .HTTPHeadPP import HTTPHeadPP
    from .http_chunk_download import HTTPChunkDownloadPP
    from .ismmanifest import ISMManifestPP
    from .recodevideo import RecodeVideoPP
    from .subtitles import SubtitlesPP
    from .writeannotations import WriteAnnotationsPP

    http_head_pp = HTTPHeadPP()
    http_chunk_download_pp = HTTPChunkDownloadPP(http_head_pp)
    http_head_pp.set_downloader(http_chunk_download_pp)
    f4m_pp = F4MManifestPP()
    ism_pp = ISMManifestPP()


# Generated at 2022-06-22 09:28:44.609545
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-22 09:28:50.619994
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor import YoutubeIE
    from .common import PostProcessorTestCase

    postprocessor = XAttrMetadataPP()

    # 'It should not fail for webpages without video info'
    result = postprocessor.run({
        'id': '1',
        'url': 'http://www.youtube.com/watch?v=BaW_jenozKc'
    })
    assert result == ([], {'id': '1', 'url': 'http://www.youtube.com/watch?v=BaW_jenozKc'})

    # 'It should not fail if xattr is not available on the filesystem'

# Generated at 2022-06-22 09:29:01.000437
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..utils import DEFAULT_OUTTMPL
    from ..extractor import gen_extractors
    extractors = gen_extractors()

# Generated at 2022-06-22 09:29:08.626009
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import preferredencoding
    from ..downloader import get_suitable_downloader

    # Note: we include only one video because there may be a limit on how many
    # xattrs we can store.

    # The unit test works as follows:
    # 1. Set up a fake info dict
    # 2. Create a postprocessor object
    # 3. Call its run(info) method
    # 4. Assert that xattrs were written correctly

    # 1. Set up a fake info dict

# Generated at 2022-06-22 09:29:18.094484
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    """
    Test of XAttrMetadataPP constructor.
    """
    import tempfile
    from .common import FileDownloader

    with tempfile.NamedTemporaryFile() as tmp_file:
        fd = FileDownloader({
            'outtmpl': tmp_file.name,
            'verbose': True,
            'quiet': True,
            'no_warnings': True,
        })
        xattr_pp = XAttrMetadataPP(fd)
        # Constructor sets name and priority of the postprocessor.
        assert xat

# Generated at 2022-06-22 09:29:20.684042
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP('foo', 'bar', 'baz')
    assert pp.downloader == 'foo'
    assert pp.download_result == 'bar'
    assert pp.info == 'baz'

# Generated at 2022-06-22 09:29:31.556011
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .test import t

    info = {
        'id': 'test',
        'webpage_url': 'http://example.com',
        'description': 'This is my test video',
        'title': 'Test Video',
        'upload_date': '2001-01-01',
        'uploader': 'John Doe',
        'format': 'mp4',
        'ext':     'mp4',
        'format_id': 'mp4',
        'filepath': '/tmp/test.mp4'
    }

    m = t.run_postprocessor(XAttrMetadataPP, info)

    assert m.decode('utf-8') == '[metadata] Writing metadata to file\'s xattrs\n'