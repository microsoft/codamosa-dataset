

# Generated at 2022-06-22 09:21:14.901891
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    from ..downloader import FakeYDL
    from ..extractor import YoutubeIE

    # Hard to test this one (xattrs are set on the filesystem...)
    # Just a quick smoke test for now
    # Maybe it would be a good idea to use a tmpfs for the test
    # (this would require to start a new python process, to really guaranty a clean filesystem)
    url = 'https://www.youtube.com/watch?v=yNkAuWzZyVg'

    dl = FakeYDL()
    ie = YoutubeIE(dl)

    info = ie.extract(url)
    ie._real_extract(url, info)

    p = XAttrMetadataPP(dl)
    p.run(info)


if __name__ == '__main__':
    test_XAttrMetadata

# Generated at 2022-06-22 09:21:20.248045
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    """ Testing constructor of class XAttrMetadataPP """
    print('Testing constructor of class XAttrMetadataPP')
    XAttrMetadataPP(None)
    print('Passed the test')


if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-22 09:21:29.921687
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    # Import the class we will test
    from ..postprocessor import XAttrMetadataPP

    # Imports for mocking
    from ..utils import XAttrUnavailableError, write_xattr

    def mock_write_xattr(filename, xattrname, value):

        # Check for any unexpected value
        if filename == 'filename':
            if xattrname == b'user.xdg.referrer.url':
                assert value == b'webpage_url'
            elif xattrname == b'user.dublincore.title':
                assert value == b'title'
            elif xattrname == b'user.dublincore.date':
                assert value == b'2012-12-21'
            elif xattrname == b'user.dublincore.description':
                assert value == b

# Generated at 2022-06-22 09:21:32.327312
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP({}).run({}) == ([], {})

# Generated at 2022-06-22 09:21:35.011702
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    """ Test that XAttrMetadataPP is correctly initialized """
    xattrdata = XAttrMetadataPP()


# Test run of XAttrMetadataPP

# Generated at 2022-06-22 09:21:36.058014
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert isinstance(XAttrMetadataPP({}), XAttrMetadataPP)

# Generated at 2022-06-22 09:21:38.183358
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP()
    assert isinstance(pp, PostProcessor)

    assert XAttrMetadataPP.__name__ == 'XAttrMetadataPP'
    assert XAttrMetadataPP.__doc__ != None


# Generated at 2022-06-22 09:21:42.909596
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..compat import compat_mock
    from ..utils import encodeFilename

    downloader = compat_mock.MagicMock()
    filename = encodeFilename("L'ombre du doute")
    filename = filename.encode('ascii')

# Generated at 2022-06-22 09:21:45.331869
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..YoutubeDL import YoutubeDL
    test_dl = YoutubeDL()
    XAttrMetadataPP(test_dl)

# Generated at 2022-06-22 09:21:55.637993
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    import json
    import os

    from tempfile import TemporaryDirectory

    from ..utils import (
        encodeFilename,
        xattr_get,
        xattr_available,
        XAttrMetadataError,
    )

    obj = XAttrMetadataPP()

    #
    # Testing that xattr.setxattr() throws an exception with a None filename
    #
    try:
        obj._write_xattrs('not_available', None, {})
    except ValueError:
        pass
    else:
        assert False, 'xattr.setxattr() doesn\'t throw an exception with a None filename'

    #
    # Testing that xattr.setxattr() throws an exception with a malformed filename
    #

# Generated at 2022-06-22 09:22:10.058183
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    """
    Returns:
            True if the unit test does not fail, otherwise returns False.
    """
    from .common import FileDownloader

    class FakeInfo:
        def __init__(self, filepath):
            self.filepath = filepath

    FAKE_FILEPATH = '/tmp/fake.mp4'
    # In case it exists from previous run
    import os
    if os.path.exists(FAKE_FILEPATH):
        os.remove(FAKE_FILEPATH)

    fd = FileDownloader(FakeInfo(FAKE_FILEPATH))
    fd.add_info_extractor(None)

    with open(FAKE_FILEPATH, 'w') as f:
        f.write('foo')

    pp = XAttrMetadataPP(fd)


# Generated at 2022-06-22 09:22:12.336625
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    """ Test the constructor of class XAttrMetadataPP. """
    pp = XAttrMetadataPP()
    assert isinstance(pp, XAttrMetadataPP)


# Generated at 2022-06-22 09:22:14.151007
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP()
    assert pp is not None


# Generated at 2022-06-22 09:22:24.869386
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..compat import compat_os_name
    from ..downloader import Downloader
    from ..utils import xattr_writable

    if not xattr_writable or compat_os_name == 'nt':
        return

    import tempfile
    filename = tempfile.mkstemp()[1]

    ydl = Downloader({})

    # Make sure all the xattrs are written
    xattrs = XAttrMetadataPP(ydl)

# Generated at 2022-06-22 09:22:27.908952
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    xattrs = XAttrMetadataPP()
    assert xattrs is not None

# vim: tabstop=8 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-22 09:22:30.491286
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP(None).run({'filepath': 'x'}) == ([], {'filepath': 'x'})

# Generated at 2022-06-22 09:22:38.825611
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    xattr_mapping = {
        'user.xdg.referrer.url': 'webpage_url',
        'user.dublincore.title': 'title',
        'user.dublincore.date': 'upload_date',
        'user.dublincore.description': 'description',
        'user.dublincore.contributor': 'uploader',
        'user.dublincore.format': 'format',
    }

    for xattrname, infoname in xattr_mapping.items():
        assert infoname == XAttrMetadataPP.xattrname_to_info_name(xattrname)


# Generated at 2022-06-22 09:22:40.814556
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-22 09:22:41.291619
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-22 09:22:52.295011
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import os

    # Mockup downloader
    class Downloader(object):

        def to_screen(self, msg):
            pass

        def report_warning(self, msg):
            pass

        def report_error(self, msg):
            pass

    filename = os.path.join('sample_dir', 'sample_file.mp4')

    # Mockup info dict

# Generated at 2022-06-22 09:23:03.117344
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x = XAttrMetadataPP()
    assert x is not None

# Generated at 2022-06-22 09:23:13.046235
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..compat import unittest
    import tempfile

    class TestXAttrMetadataPP(unittest.TestCase):

        def test_XAttrMetadataPP(self):
            tempdir = tempfile.gettempdir()
            pp = XAttrMetadataPP({'outtmpl': '%(title)s.%(ext)s', 'quiet': True})
            res, info = pp.run({
                'webpage_url': 'https://example.com',
                'title': 'test title',
                'upload_date': '2001-02-03',
                'description': 'test description',
                'uploader': 'test uploader',
                'format': 'test format',
                'filepath': tempdir + '/test.mp4',
            })
            self.assertEqual(res, [])

# Generated at 2022-06-22 09:23:24.826957
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import tempfile
    import unittest
    import shutil
    import os

    class TestError(Exception):
        pass

    class XAttrMetadataPP_runTest(unittest.TestCase):

        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.tempfilename = os.path.join(self.temp_dir, "test.txt")
            open(self.tempfilename, 'a').close()      # create empty file
            self.fake_downloader = FakeDownloader()

        def tearDown(self):
            if os.path.exists(self.tempfilename):
                os.remove(self.tempfilename)
            if os.path.exists(self.temp_dir):
                shutil.rmtree(self.temp_dir)


# Generated at 2022-06-22 09:23:26.256425
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x_attr = XAttrMetadataPP(None)
    assert x_attr

# Generated at 2022-06-22 09:23:37.717263
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from .common import FileDownloader
    from .extractor import YoutubeIE
    from ..compat import compat_opener

    # create a temporary file with a real youtube video in it
    (fd, filepath) = compat_opener(None, 'wb')(None, 'temp', 0)
    link = 'https://www.youtube.com/watch?v=BaW_jenozKc'
    try:
        ydl = FileDownloader({'format': 'best', 'outtmpl': filepath}, {})
        info_dict = YoutubeIE().extract(link)
        ydl.add_info_extractor(YoutubeIE())
        ydl.process_info(info_dict)
    finally:
        fd.close()

    # create a new XAttrMetadataPP object to read xattrs from file and write

# Generated at 2022-06-22 09:23:39.049875
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    xattr = XAttrMetadataPP()
    assert xattr is not None

# Generated at 2022-06-22 09:23:50.306012
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # Initialize
    import os.path
    from .test_downloads_common import FakeYDL
    from .test_common import (
            _create_test_file,
            _create_test_file_with_size,
            _create_test_data_dir,
    )

    def _create_aux_test_file(name, infoname, value, create_size=False):
        """ Creates a test file with xattrs support resulting in a download with some metadata. """
        # Create test directories
        tmp_dir = _create_test_data_dir()
        tmp_file = _create_test_file(tmp_dir, name)
        if create_size:
            _create_test_file_with_size(tmp_file, 1000)

        # Write xattrs to test file

# Generated at 2022-06-22 09:23:52.935891
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert(XAttrMetadataPP(None)._activate_via() == ['write_xattr', 'xattr_write_supported'])

# Generated at 2022-06-22 09:23:53.503162
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass



# Generated at 2022-06-22 09:23:56.749703
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({'writethumbnail': True})
    x = XAttrMetadataPP(ydl)

# Generated at 2022-06-22 09:24:25.515896
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    try:
        import xattr
    except ImportError:
        xattr = None

    if xattr is None:
        return

    from hashlib import sha1

    import io
    import os
    import tempfile

    from .common import InfoExtractor

    class TmpInfo(dict):
        filename = None
    info = TmpInfo({
        'id': 'fake video id',
        'webpage_url': 'https://www.youtube.com/watch?v=fake_video_id',
        'title': 'the real title',
        'description': 'the real description',
        'uploader': 'the real uploader',
        'upload_date': 'the real upload date',
        'format': 'the real format',
    })

# Generated at 2022-06-22 09:24:27.784782
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    xattrwrite = XAttrMetadataPP()


# Generated at 2022-06-22 09:24:30.517542
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    """
    Calling XAttrMetadataPP.run()
    """

    pass


if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-22 09:24:32.984367
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP('/tmp/dummy')
    assert pp is not None

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-22 09:24:35.448822
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP()
    assert isinstance(pp, PostProcessor)


if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-22 09:24:39.109128
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP()
    assert pp.supported is True

# Generated at 2022-06-22 09:24:46.812224
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    xattr_pp = XAttrMetadataPP()
    xattr_pp._downloader = object()
    info = {
        'webpage_url': 'http://www.youtube.com/watch?v=nfWlot6h_JM',
        'title': 'B-complex - Beautiful lies VIP',
        'upload_date': '20121002',
        'uploader': 'UKF Drum & Bass',
        'description': 'Buy now: http://ukf.me/tjvNuc\nBecome a fan of B-Complex: http://www.facebook.com/bcomplexdnb',
        'format': 'DASH video',
        'filepath': '/tmp/nfWlot6h_JM.mp4'
    }
    assert xattr_pp.run(info) == ([], info)

# Generated at 2022-06-22 09:24:47.988431
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-22 09:24:49.516180
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # Let's say run raises no exception (it should normally be the case)
    assert True

# Generated at 2022-06-22 09:24:58.139683
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..utils import XAttrSupport
    from ..downloader.common import FileDownloader

    d = FileDownloader({})
    d.params['extract_flat'] = 'm3u8'
    d.params['outtmpl'] = '%(id)s%(ext)s'
    d.params['writedescription'] = True
    d.params['writeannotations'] = True
    d.params['writeinfojson'] = True
    d.params['writethumbnail'] = True
    d.params['writesubtitles'] = True
    d.params['writeautomaticsub'] = True
    d.params['allsubtitles'] = True
    d.params['ignoreerrors'] = True

    if not XAttrSupport.have_xattr:
        return None

    xattrMetadataPP = XAtt

# Generated at 2022-06-22 09:25:44.489013
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import re

    # Test with the metadata already in the info dict
    info = {
        'filepath': '/tmp/test.file',
        'webpage_url': 'http://test.com/test.htm',
        # 'description': 'description test',
        'title': 'title test',
        'upload_date': '20140430',
        'description': 'description test',
        'uploader': 'uploader test',
        'format': 'format test',
    }

# Generated at 2022-06-22 09:25:55.348293
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..downloader import Downloader
    from ..utils import platform_name

    expected_output_filename = 'test.txt'
    expected_output_extension = 'mp4'
    expected_output_string = b''
    input_filename = 'test.' + expected_output_extension
    input_string = b'abcd'

    downloader = Downloader(params={})

    # Pretend this is a video file
    downloader.params['outtmpl'] = '%(id)s.' + expected_output_extension

    # Instantiate the class
    postprocessor = XAttrMetadataPP(downloader)

    # Create a file and use it as the input file
    from os.path import isfile, join
    from os import remove
    from tempfile import tempdir
    from .common import limit_len, _fix

# Generated at 2022-06-22 09:25:56.308511
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-22 09:26:00.510081
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    xattr_pp = XAttrMetadataPP({})
    assert isinstance(xattr_pp, PostProcessor)
    assert xattr_pp

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-22 09:26:01.944391
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP(None, None)
    return True

# Generated at 2022-06-22 09:26:03.484780
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    try:
        XAttrMetadataPP()
    except:
        assert False


# Generated at 2022-06-22 09:26:09.689790
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..ytdl.YoutubeDL import YoutubeDL
    from ..compat import compat_xattr
    import os
    import shutil
    import tempfile

    if not compat_xattr:
        return

    tempdir = tempfile.mkdtemp()
    os.chdir(tempdir)


# Generated at 2022-06-22 09:26:20.181512
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..utils import DateRange
    from ..compat import compat_str
    # We don't have a video to test with, but we can fake one.

# Generated at 2022-06-22 09:26:24.420695
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    try:
        import xattr
        xattr.setxattr('testfile', 'testname', 'testvalue')
    except:
        print('XAttrMetadataPP is not available.')
        return
    # Constructor should not throw an exception
    XAttrMetadataPP(None)

# Generated at 2022-06-22 09:26:34.093410
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .test_files import TESTFN, TESTFN_UNICODE

    try:
        import xattr
    except ImportError:
        return

    # Test basic functionality
    XAttrMetadataPP().run({
        'filepath': TESTFN,
        'webpage_url': 'url1',
        'title': 'title2',
        'upload_date': 'upload_date3',
        'description': 'description4',
        'uploader': 'uploader5',
        'format': 'format6',
    })

    assert xattr.getxattr(TESTFN, 'user.xdg.referrer.url').decode('utf-8') == 'url1'

# Generated at 2022-06-22 09:27:57.475417
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    processor = XAttrMetadataPP()
    info = {
        'webpage_url': 'http://www.youtube.com/watch?v=Iq3OeK1xUy8',
        'title': 'Le tour de la question',
        'upload_date': '20010101',
        'description': 'A song to sing when you think about life.',
        'uploader': 'GabberEleganza',
        'format': 'best',
    }
    result = processor.run(info)
    info = result[1]
    assert info['webpage_url'] == 'http://www.youtube.com/watch?v=Iq3OeK1xUy8'
    assert info['title'] == 'Le tour de la question'
    assert info['upload_date'] == '20010101'
   

# Generated at 2022-06-22 09:27:59.435287
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp_test = XAttrMetadataPP({})
    assert isinstance(pp_test, XAttrMetadataPP)


# Generated at 2022-06-22 09:28:09.783274
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..extractor import gen_extractors
    from .common import FileDownloader

    _downloader = FileDownloader({})
    downloader = FileDownloader({})
    info = {'fulltitle': 'test video',
            'webpage_url': 'test url',
            'description': 'test description',
            'uploader': 'test uploader',
            'format': 'test format',
            'ext': 'test ext',
            'filename': 'test filename',
            'format_id': 'test id',
            'upload_date': 'test date',
            'filepath': 'test filepath'}
    exts = gen_extractors()

    pp = XAttrMetadataPP(_downloader)


# Generated at 2022-06-22 09:28:20.396869
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..downloader import Downloader
    import sys
    import os
    from .mock_write_xattr import mock_write_xattr
    from ..compat import compat_os_name

    if compat_os_name == 'nt':
        print('Skipped: XAttrMetadataPP unit test')
        return
        
    print('Testing XAttrMetadataPP constructor')

    info = {}

    # negative test:
    #   xattr not available
    def mock_write_xattr(filename, xattrname, value):
        raise XAttrUnavailableError
    with mock_write_xattr:
        xattr_metadata_pp = XAttrMetadataPP(Downloader({}))
        try:
            xattr_metadata_pp.run(info)
        except XAttrUnavailableError:
            print

# Generated at 2022-06-22 09:28:31.535181
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .testutils import FakeYDL
    from .testutils import FakeFile as File
    from .testutils import FakeInfoExtractor

    ie = FakeInfoExtractor()

    ydl = FakeYDL()
    ydl.add_info_extractor(ie)
    ydl.params['writedescription'] = True
    ydl.params['writeinfojson'] = True
    ydl.params['writeannotations'] = True
    ydl.params['write-thumbnail'] = True

    pp = XAttrMetadataPP(ydl)

    # Correct xattrs

# Generated at 2022-06-22 09:28:42.362094
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import tempfile
    import os
    from types import ModuleType

    import pytest

    from ..utils import xattr_writable

    if not xattr_writable():
        pytest.skip("xattr not supported")

    p = XAttrMetadataPP()

    p._downloader = ModuleType('downloader')
    p._downloader.report_error = lambda x: print("ERROR:", x)
    p._downloader.report_warning = lambda x: print("WARNING:", x)
    p._downloader.to_screen = lambda x: print("INFO:", x)

    tf = tempfile.NamedTemporaryFile(delete=False)
    tf.close()


# Generated at 2022-06-22 09:28:46.219247
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from .. import YoutubeDL

    # Run PostProcessor without options
    ydl = YoutubeDL({'postprocessors': [{'key': 'XAttrMetadataPP'}]})

    pp = XAttrMetadataPP(ydl=ydl)

    assert pp.ydl is ydl


if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-22 09:28:46.735929
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pass

# Generated at 2022-06-22 09:28:53.072147
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import tempfile
    from ..utils import (
        encodeFilename,
        sanitize_open,
    )


# Generated at 2022-06-22 09:29:03.147962
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # Create a mock file
    import os
    import tempfile

    from .common import FileDownloader

    # Create a temporary file path
    fd, tmpfile = tempfile.mkstemp(prefix="pytest_")
    fh = os.fdopen(fd, 'wb')
    fh.close()

    dummy_info = {'filepath': tmpfile, 'webpage_url': 'https://ytdl-org.github.io/youtube-dl/', 'title': 'title', 'upload_date': '20160101', 'description': 'description', 'uploader': 'uploader', 'format': 'format'}
    xattr_metadata_pp = XAttrMetadataPP(FileDownloader({}))
    # No exception should be raised
    xattr_metadata_pp.run(dummy_info)
