

# Generated at 2022-06-22 09:21:06.806225
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# vim: tabstop=8 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-22 09:21:12.161192
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    info = {'title': 'test_title',
            'upload_date': 'test_upload_date',
            'description': 'test_description',
            'uploader': 'test_uploader',
            'format': 'test_format',
            'webpage_url': 'http://example.com/webpage_url',
            'filepath': '/path/to/file'}

    XAttrMetadataPP().run(info)

# Generated at 2022-06-22 09:21:22.391867
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import unittest
    import os
    from .postprocessor_test import (
        PPTest,
        info_dict_for_test_XAttrMetadataPP_run,
    )
    from ..utils import encodeFilename

    class TestDummyInst(object):

        def report_error(self, msg):
            pass

        def report_warning(self, msg):
            pass

        def to_screen(self, msg):
            pass

    class TestXAttrMetadataPP(unittest.TestCase):

        def test_all_metadata_is_written_into_xattrs(self):
            filename = encodeFilename('abc.mp4')
            with open(filename, 'wb') as f:  # Create the file
                f.write(b' ')


# Generated at 2022-06-22 09:21:23.317674
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass



# Generated at 2022-06-22 09:21:24.053138
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-22 09:21:26.492920
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    try:
        import xattr
        test = XAttrMetadataPP()
    except ImportError:
        pass

# Generated at 2022-06-22 09:21:28.691134
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # TODO: Write unit test
    assert True

# Generated at 2022-06-22 09:21:39.921126
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    class FakeInfo:
        def get(self, infoname):
            if infoname == 'filepath':
                return 'filename.mp4'
            elif infoname == 'mediatype':
                return 'video'
            elif infoname == 'webpage_url':
                return 'webpage_url'
            elif infoname == 'title':
                return 'title'
            elif infoname == 'upload_date':
                return '20140121'
            elif infoname == 'description':
                return 'description'
            elif infoname == 'uploader':
                return 'uploader'
            elif infoname == 'format':
                return 'format'

    x = XAttrMetadataPP()
    return x.run(FakeInfo())

# Generated at 2022-06-22 09:21:44.401203
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    XAttrMetadataPP('vid', 'video', 'http://www.youtube.com/watch?v=BaW_jenozKc')


# Generated at 2022-06-22 09:21:51.237288
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor import gen_extractors

    extractors = gen_extractors()

    for ie in extractors:
        info = ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')
        assert info['extractor'] == 'YoutubeIE'
        assert info['title'] == 'youtube-dl test video "\'/\\ä↭`"-'

        pp = XAttrMetadataPP()
        pp.run(info)

# Generated at 2022-06-22 09:22:08.843410
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor.common import InfoExtractor
    from ..utils import DateRange
    from ..compat import compat_str, compat_urlparse

    info = {
        'id': 'Test',
        'title': 'Test video',
        'description': 'This is a test video',
        'uploader': 'Author',
        'upload_date': '20120101',
        'webpage_url': 'http://example.com/?v=Test',
    }
    info['upload_date'] = DateRange(info['upload_date'])

    ie = InfoExtractor({})
    ie.ie_key = 'Test'
    ie.working_dir = '.'

    assert ie.working_path('Test') == '.Test'
    assert ie.cache_path('Test') == '.Test.cache'

    # Test file should not

# Generated at 2022-06-22 09:22:18.926328
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import unittest
    class FakeInfo(dict): pass
    class FakeOpts(dict):
        def __init__(self):
            self['writesubtitles'] = ''
            self['writeautomaticsub'] = ''
            self['allsubtitles'] = ''
            self['subtitleslangs'] = ''
    class FakeDownloader(object):
        def to_screen(self, msg):
            return msg
        def report_warning(self, msg):
            return msg
        def report_error(self, msg):
            return msg
    class Test(unittest.TestCase):
        def test(self):
            filename = 'video1.flv'
            info = FakeInfo()
            info['filepath'] = filename

# Generated at 2022-06-22 09:22:30.281956
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    from .common import PostProcessorTest
    from ..utils import xattr_supported

    pp = XAttrMetadataPP()
    pp_test = PostProcessorTest(pp)

    # Run empty test
    pp_test.run({})
    pp_test.assert_no_warnings()
    pp_test.assert_no_errors()
    pp_test.assert_no_matching_lines(['hasn\'t been tested', 'Metadata'])

    if xattr_supported():
        # Run test with some metadata
        pp_test.run({
            'description': 'description',
            'title': 'title',
            'upload_date': '20130620',
            'webpage_url': 'webpage_url',
            'uploader': 'uploader',
            'format': 'format',
        })


# Generated at 2022-06-22 09:22:39.149559
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import os
    import sys
    import tempfile
    import shutil

    tmpDir = tempfile.mkdtemp()
    tmpFile = os.path.join(tmpDir, 'test.file')

    with open(tmpFile, 'w') as f:
        f.write('test')


# Generated at 2022-06-22 09:22:40.864341
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-22 09:22:51.709563
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # Create a temporary file
    import tempfile
    import time
    import os
    import pytest
    from ..utils import xattr
    from ..compat import compat_os_name

# Generated at 2022-06-22 09:23:01.853159
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    xattr_mapping = {
        'user.xdg.referrer.url': 'webpage_url',
        # 'user.xdg.comment': 'description',
        'user.dublincore.title': 'title',
        'user.dublincore.date': 'upload_date',
        'user.dublincore.description': 'description',
        'user.dublincore.contributor': 'uploader',
        'user.dublincore.format': 'format',
    }


# Generated at 2022-06-22 09:23:06.691020
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor.common import InfoExtractor
    from ..downloader.http import HttpFD
    iie = InfoExtractor()
    ie = iie.get_info_extractor(extractor='Youtube')
    ie.set_downloader(HttpFD())

    #
    # basic reading test
    #

# Generated at 2022-06-22 09:23:14.372884
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from .. import YoutubeDL
    from .test import get_testcases

    ydl = YoutubeDL()
    ydl.params['writeautomaticsub'] = True

    testcases = get_testcases(XAttrMetadataPP, ydl)
    print('=== Testing XAttrMetadataPP ===')
    for tclass, inputs in testcases.items():
        for url, expected in inputs.items():
            print('{} for {}:'.format(tclass.__name__, url))
            tclass(ydl).run(inputs[url])
            print()

# Generated at 2022-06-22 09:23:16.110827
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-22 09:23:30.042110
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    p = XAttrMetadataPP(ydl)
    assert p is not None

# Generated at 2022-06-22 09:23:39.847726
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import encodeFilename

    from .common import FileDownloader

    from ..extractor.common import InfoExtractor

    from .test_utils import FakeYDL

    extractor = InfoExtractor()

# Generated at 2022-06-22 09:23:48.580238
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import sys
    import tempfile
    import pytest

    from io import BytesIO

    from ytdl_server.compat import compat_os_name

    if compat_os_name == 'nt':
        pytest.skip('extended attributes are not supported on windows')

    from .common import postprocessor, real_download, FakeYDL

    try:
        import extendedattributes
    except ImportError:
        pytest.skip('need native python xattr support (pip install extendedattributes)')

    class MockDownloader:
        to_screen = print
        report_error = print
        report_warning = print

    postprocessor.configure()

    with tempfile.NamedTemporaryFile(prefix='ytdl-server-', suffix='.mp4') as f:
        f.write(b'abc')
        f

# Generated at 2022-06-22 09:23:57.880053
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    """ test the postprocessor XAttrMetadataPP.run with a mocked object """

    import os
    import unittest
    from youtube_dl.utils import sanitized_Request
    from .test_utils_xattr import FakeXAttrFile, XAttrDisabledError

    class MockedXAttrFile(FakeXAttrFile):
        """ Mocked class for FakeXAttrFile """

        def __init__(self, filename, opts):
            super(MockedXAttrFile, self).__init__(filename, opts)


# Generated at 2022-06-22 09:23:58.570513
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # TODO
    pass

# Generated at 2022-06-22 09:24:00.216859
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP()
    return type(pp) is XAttrMetadataPP

# Generated at 2022-06-22 09:24:06.488051
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    info = {
        'webpage_url': 'https://www.youtube.com/watch?v=BaW_jenozKc',
        'description': 'md5:7c9019699acd9ec31b8c38f2f5c53ee0',
        'title': 'md5:7cc32a413d3f983d8e5d5df5ef447cd5',
        'upload_date': '20121002',
        'uploader': 'md5:aadb7c3adcdd1897b3d1c2f2f25d1c07',
        'format': 'md5:80a064519a1b7ea25c8fd2ca2f2fd595',
    }
    x = XAttrMetadataPP()
    result, info = x.run

# Generated at 2022-06-22 09:24:15.458628
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    from ..utils import sanitize_open
    from .common import FileDownloader
    from .common import PostProcessor
    from .common import FileDownloader
    d = FileDownloader(params={'cachedir': False, 'nooverwrites': False})
    d.params['logger'] = d.to_screen
    d.params['outtmpl'] = '%(title)s.%(ext)s'
    d.params['writedescription'] = True
    pp = XAttrMetadataPP(d)

# Generated at 2022-06-22 09:24:25.246147
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    from .common import TestPP
    from ..utils import (
        encodeFilename,
        encodeArgument,
        std_headers,
    )
    from ..youtube_dl.YoutubeDL import YoutubeDL
    import sys

    def my_write_xattr(filename, xattrname, value):
        global test_XAttrMetadataPP_run_result
        if xattrname == 'user.dublincore.date':
            test_XAttrMetadataPP_run_result['upload_date'] = value.decode('utf-8')
        elif xattrname == 'user.dublincore.title':
            test_XAttrMetadataPP_run_result['title'] = value.decode('utf-8')

# Generated at 2022-06-22 09:24:35.551743
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..downloader import FakeYDL
    pytest.importorskip('xattr')

    class TestXAttrMetadataPP(XAttrMetadataPP):
        def run(self, info):
            return super(TestXAttrMetadataPP, self).run(info)

    xmpp = TestXAttrMetadataPP(FakeYDL())
    info = {
        'filepath': __file__,
        'title': 'Foo',
        'upload_date': '20150101',
        'description': 'Foo bar',
        'uploader': 'Foo Bar',
        'format': 'mp4',
    }

    errors, new_info = xmpp.run(info)
    assert errors == []

# Generated at 2022-06-22 09:24:59.215764
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from .mock import MockYDL

    ydl = MockYDL()
    ydl.params = {}
    ydl.add_post_processor(XAttrMetadataPP(ydl))

# Generated at 2022-06-22 09:25:09.068261
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    xattr_filename = 'xattr_filename'
    xattr_data = b'xattr_data'

    class MockXAttr(object):
        @staticmethod
        def xattr(fd, name, value=None, options=0, position=0):
            if value is None:
                if fd == xattr_filename and name == 'user.xdg.url':
                    return xattr_data
                else:
                    raise IOError()
            else:
                return len(value)

    class MockOs(object):
        def __init__(self):
            self.open = lambda filepath, flags: filepath
            self.close = lambda fd: None
            self.path = MockPath()

    class MockPath(object):
        def __init__(self):
            self.exists = lambda path: True



# Generated at 2022-06-22 09:25:19.539102
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # Test 1
    # No xattr support
    # Input: an empty dictionary
    # Expected: no error and an empty dictionary
    test_dict = {}
    test_class = XAttrMetadataPP(None)
    test_tuple = test_class.run(test_dict)
    assert len(test_tuple) == 2
    assert test_tuple[0] == []
    assert test_dict == test_tuple[1]

    # Test 2
    # xattr support enabled
    # Input: a dictionary with some values
    # Expected: no error, the original dictionary is not modified and the
    # return value is a new dictionary

# Generated at 2022-06-22 09:25:29.422046
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..YoutubeDL import YoutubeDL
    from .common import FileDownloader
    from ..extractor import get_info_extractor

    ydl = YoutubeDL()
    ydl.add_info_extractor(get_info_extractor('Youtube'))
    fd = FileDownloader(ydl, {'format': 'best', 'outtmpl': '%(id)s.mp4', 'writethumbnail': True})
    msg = []
    def log(x):
        msg.append(x)
    fd.to_screen = log
    pp = XAttrMetadataPP(fd)
    with open(__file__) as f:
        pp.run({'filepath': f.name, 'title': 'test'})
    assert 'metadata' in ''.join(msg)



# Generated at 2022-06-22 09:25:35.442642
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..downloader import Downloader
    from ..utils import encodeFilename
    from ..extractor.common import InfoExtractor
    from ..extractor.youtube import YoutubeIE
    from .test import get_testcases

    class MockYoutubeIE(YoutubeIE):
        def _real_extract(self, url):
            id = self._match_id(url)

# Generated at 2022-06-22 09:25:43.045968
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():

    from ..utils import DateRange
    from ..extractor.youtube import YoutubeIE

    ie = YoutubeIE(downloader=None)


# Generated at 2022-06-22 09:25:52.878542
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    # Initialize downloader
    downloader = object()

    # Initialize postprocessor
    postprocessor = XAttrMetadataPP(downloader=downloader)

    # Initialize info
    info = {
        'filepath': 'file',
        'webpage_url': 'webpage_url',
        'description': 'description',
        'title': 'title',
        'upload_date': 'upload_date',
        'uploader': 'uploader',
        'format': 'format',
    }

    # Call method run
    postprocessor.run(info)

    # Expect writing metadata to file's xattrs
    downloader.to_screen.assert_called_with('[metadata] Writing metadata to file\'s xattrs')

    # Expect xattrs to be set

# Generated at 2022-06-22 09:26:05.666237
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os
    import xattr
    import shutil
    import tempfile
    import unittest

    # Create a tempfile in a temp folder and assign it the xattr key-value pair
    def create_tempfile_with_xattr(key, value):
        tempdir = tempfile.mkdtemp()
        tempfilepath = os.path.join(tempdir, 'tempfile')
        tempfileobj = open(tempfilepath, 'w')
        os.close(tempfileobj)
        xattr.setxattr(tempfilepath, key, value.encode())
        return tempdir, tempfilepath

    # Clean a temp file
    def cleanup_tempfile(path):
        shutil.rmtree(path)

    # Test if the run method set the key value as expected

# Generated at 2022-06-22 09:26:10.572094
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    downloader = type('Mock', (object,), {})()
    # Simulate empty filesystem
    downloader.to_screen = lambda x: None
    downloader.report_error = lambda x: None
    pp = XAttrMetadataPP(downloader)
    assert pp.run({'filepath': '/tmp/trash'}) == ([], {})

# Generated at 2022-06-22 09:26:13.733889
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    name = 'XAttrMetadataPP'
    pp = XAttrMetadataPP()

    # TODO

    # Test with empty info
    info = {
        'filepath': '',
    }
    res, info = pp.run(info)
    assert res == []
    assert info['filepath'] == ''

# Generated at 2022-06-22 09:26:55.545573
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass



# Generated at 2022-06-22 09:27:01.593222
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    metadata = {
        'webpage_url': 'https://example.com',
        'title': 'Example',
        'upload_date': '20181006',
        'description': 'Example description',
        'uploader': 'Example uploader',
        'format': 'Example format',
    }

    xattrmetadata = XAttrMetadataPP()
    xattrmetadata.run(metadata)

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-22 09:27:02.675511
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    XAttrMetadataPP.run(None)

# Generated at 2022-06-22 09:27:10.910678
# Unit test for constructor of class XAttrMetadataPP

# Generated at 2022-06-22 09:27:12.321842
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # Just call constructor
    XAttrMetadataPP(Downloader(None))

# Generated at 2022-06-22 09:27:21.128126
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from unittest import TestCase
    from .common import FileDownloader, PostProcessor

    class XAttrMetadataPP_run_test(TestCase):

        def setUp(self):
            self.fd = FileDownloader({'format': 'best'}, False)
            self.pp = PostProcessor(self.fd)
            self.pp.downld = self.fd


# Generated at 2022-06-22 09:27:21.792666
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP is not None

# Generated at 2022-06-22 09:27:26.999097
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import sys
    import os
    import unittest
    import tempfile
    from ..compat import compat_os_name

    if compat_os_name == 'nt':
        import ctypes

    class DummyInfoDict():
        def __init__(self, dict):
            self.__dict__ = dict

        def get(self, key):
            return self.__dict__.get(key)

    class XAttrMetadataPPDummyDownloader():
        def to_screen(self, text):
            print(text)

        def report_warning(self, text):
            print(text)

        def report_error(self, text):
            print(text)


# Generated at 2022-06-22 09:27:35.016957
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor import YoutubeIE
    from ..downloader.common import FileDownloader

    ydl = FileDownloader()
    ydl.add_info_extractor(YoutubeIE(ydl))

    ydl.add_post_processor(XAttrMetadataPP(ydl))

    # TODO: Use a downloadable video

    ydl.download(['http://www.youtube.com/watch?v=BaW_jenozKc'])

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-22 09:27:35.776689
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-22 09:29:05.067357
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor import info_dict
    filename = 'test_filename'
    info_dict[filename] = {'format': 'best', 'title': 'My Title', 'webpage_url': 'https://www.youtube.com/watch?v=Rlgjyhb7pDk', 'upload_date': '20180601', 'uploader': 'Uploader', 'description': 'This is the description'}
    xAttrMetadataPP = XAttrMetadataPP()
    xAttrMetadataPP.run(info_dict[filename])

# Generated at 2022-06-22 09:29:13.420825
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    info = {'webpage_url': 'https://www.youtube.com/watch?v=BaW_jenozKc',
            'title': 'youtube-dl test video',
            'upload_date': '20121002',
            'description': 'test description',
            'uploader': 'Philipp Hagemeister',
            'format': '1 - 140x140 (3gp small)',
            'ext': 'flv',
            'filepath': 'test/youtube-dl test video.flv'}

    import os
    pp = XAttrMetadataPP()


# Generated at 2022-06-22 09:29:14.545011
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass  # Nothing to test here ?

# Generated at 2022-06-22 09:29:23.212078
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ydl.postprocessor.ffmpeg import FFmpegMetadataPP
    from ydl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from ydl.postprocessor.xattrs import XAttrMetadataPP
    from ydl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from ydl.postprocessor.ffmpeg import FFmpegEmbedSubtitlePP
    from ydl.postprocessor.ffmpeg import FFmpegFixupM3u8PP
    from ydl.postprocessor.ffmpeg import FFmpegFixupM4aPP

    video_id = 'FzRH3iTQPrk'

# Generated at 2022-06-22 09:29:24.916814
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    xa = XAttrMetadataPP()
    assert xa is not None

# Generated at 2022-06-22 09:29:32.543484
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..utils import prepend_extension
    from ..compat import compat_urllib_request
    from .http import HttpFD

    HttpFD(None, compat_urllib_request.Request('http://www.youtube.com/watch?v=BaW_jenozKc'),
           prepend_extension('%(id)s.%(ext)s', {'id': 'BaW_jenozKc', 'ext': 'flv'}),
           {}).download()

# Generated at 2022-06-22 09:29:41.009628
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import os
    import shutil
    from ..utils import prepend_extension
    from ..compat import compat_etree_fromstring as ET

    from tests import FakeYDL

    class FakeXAttrUnavailableError(Exception):
        pass

    class FakeXAttrMetadataError(Exception):
        pass

    def fake_write_xattr(filename, xattrname, byte_value):
        """ Fake write_xattr. Keep fake_xattrs updated. """

        if not os.path.isfile(filename):
            raise FakeXAttrUnavailableError('Wrong file name')

        raise FakeXAttrMetadataError('Some error')

    fake_xattrs = {}
    original_write_xattr = write_xattr
    write_xattr = fake_write_xattr

    xattrmetadatapp = X

# Generated at 2022-06-22 09:29:42.656031
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    metadata = {}
    XAttrMetadataPP({}, {}, metadata)
    return metadata



# Generated at 2022-06-22 09:29:53.108913
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .test_downloader_common import _test_downloader
    from ..utils import xattr_supported
    if not xattr_supported:
        print('[metadata] XAttrMetadataPP.run() skipped because of missing xattr support')
        return

    def _submit_url(url, expected_filename=None, expected_status=200,
                    expected_content=False, **kwargs):
        info = {
            'id': '',
            'title': 'Test title',
            'description': 'Test description',
            'upload_date': '20180802',
            'uploader': 'Test uploader',
            'format': 'Test format',
            'webpage_url': 'http://example.com/test/',
            'filepath': '/non/existing/path.mp4',
            }
        return info



# Generated at 2022-06-22 09:30:02.474053
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    """
    Trivial test for XAttrMetadataPP.run()
    """

    #
    # Create a dictionary of info and a filepath to work with.
    #

    import tempfile

    tempdir = tempfile.gettempdir()
    filename = tempfile.mkstemp(dir=tempdir)[1]

    info = {
        'webpage_url': 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
        'title': 'Never Gonna Give You Up',
        'upload_date': '20010101',
        'description': 'This is a description',
        'uploader': 'Rick Astley',
        'format': 'flv',
        'filepath': filename,
    }

    #
    # Write the xattrs to the file.
