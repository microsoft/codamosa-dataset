

# Generated at 2022-06-22 09:21:05.990592
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP('youtube-dl')
    assert pp.name == 'xattrs'
    assert pp.description == (
        'Writes metadata to file\'s xattrs, if xattr support is found')



# Generated at 2022-06-22 09:21:15.073118
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from .. import YoutubeDL
    from .execafterdownload import ExecAfterDownloadPP
    from .metadatafromtitle import MetadataFromTitlePP

    ydl = YoutubeDL({
        'postprocessors': [
            {
                'key': 'XAttrMetadata',
                'enabled': True
            }
        ]
    })

    pp = ydl.get_post_processor(None, 'dummy.webm')

    assert isinstance(pp, XAttrMetadataPP)
    assert type(pp._pps) == list
    assert isinstance(pp._pps[0], ExecAfterDownloadPP)
    assert type(pp._pps[1]) == dict


# Generated at 2022-06-22 09:21:18.809244
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP(object)
    return True

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-22 09:21:28.769887
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import subprocess
    # https://github.com/ytdl-org/youtube-dl/pull/11334/files#diff-b84c73f3797df8edc1cb79a0a2b5bbb7R94
    info = {
        'formats': [],
        'filepath': __file__,
        'webpage_url': 'https://www.youtube.com/watch?v=BaW_jenozKc',
        'description': 'A video about a pen',
        'title': 'The Pen Ultimate Video',
        'upload_date': '20180101',
        'uploader': 'Penguin',
        'format': 'webm',
    }
    postprocessor = XAttrMetadataPP(None)
    errs, infos = postprocessor.run(info)

# Generated at 2022-06-22 09:21:32.521422
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    b = XAttrMetadataPP()
    assert b is not None

# vim:sw=4:ts=4:et:

# Generated at 2022-06-22 09:21:41.806103
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..downloader import YoutubeDL
    from .common import FileDownloader


# Generated at 2022-06-22 09:21:42.827515
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # TODO: unit test for method run of class XAttr
    pass

# Generated at 2022-06-22 09:21:44.970132
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP(None)
    assert pp.pp_name == 'MetadataFromXAttr'

# Generated at 2022-06-22 09:21:47.314783
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    metadataPP = XAttrMetadataPP()
    assert metadataPP is not None

# Generated at 2022-06-22 09:21:48.295761
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP()

# Generated at 2022-06-22 09:21:54.013074
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    PostProcessor('test').run(info={})

# Generated at 2022-06-22 09:22:03.702721
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import encodeFilename, encodeArgument

    pp = XAttrMetadataPP()
    pp.run({
        'webpage_url': 'http://www.youtube.com/watch?v=BaW_jenozKc',
        'title': 'Hitchhiker\'s Guide to the Galaxy',
        'upload_date': '20010115',
        'description': 'Second' + (' ' * 4000) + 'test',
        'uploader': 'douglas',
        'format': 'webm',
        'filepath': encodeFilename(encodeArgument('Hitchhiker\'s Guide to the Galaxy (2001).webm'))
    })

# Generated at 2022-06-22 09:22:12.989019
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..compat import compat_http_client
    compat_http_client.HTTPSConnection = FakeHTTPSConnection
    pp = XAttrMetadataPP(None)

    # Test with a file that has no headers
    info = {
        'webpage_url': 'https://www.youtube.com/watch?v=BaW_jenozKc',
        'title': 'youtube-dl test video "\'/\\ä↭𝕐',
        'ext': 'mp4',
        'format': 'test format',
        'thumbnail': 'test thumbnail',
        'description': 'test description',
        'upload_date': '20121002',
        'duration': 600,
        'uploader': 'ytdl test user',
    }
    res, info = pp.run(info)


# Generated at 2022-06-22 09:22:13.865059
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pass

# Generated at 2022-06-22 09:22:24.553808
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    import sys
    import warnings
    import unittest

    class FakeYDL():
        def __init__(self):
            self.params = {'prefer_free_formats': True, 'format': 'bestaudio/best'}
            self.to_screen = lambda x: sys.stderr.write(x + '\n')
            self.to_stdout = lambda x: sys.stdout.write(x)
            self.cache = False
            self.errorcount = 0

        def to_stderr(self, message):
            sys.stderr.write(message + '\n')

        def trouble(self, message, tb=None):
            if tb is None:
                self.to_stderr(message)

# Generated at 2022-06-22 09:22:35.467318
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from sets import Set
    def _check_xattr_mapped_to_info(xattr_mapping, info):
        for xattrname, infoname in xattr_mapping.items():
            value = info.get(infoname)
            if value:
                if infoname == 'upload_date':
                    value = hyphenate_date(value)
                byte_value = value.encode('utf-8')
                written_value = read_xattr(filename, xattrname)
                assert written_value == byte_value

    class MyDownloader():
        def report_error(self, msg):
            assert False

        def report_warning(self, msg):
            assert False


# Generated at 2022-06-22 09:22:45.675855
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    try:
        import xattr
        xattr  # silence pyflakes warning
    except ImportError:
        return

    import tempfile

    # write something to a tempfile and
    (dummy_fd, dummy_filename) = tempfile.mkstemp()

    x_attrs = {
        'user.xdg.referrer.url': 'webpage_url',
        # 'user.xdg.comment':            'description',
        'user.dublincore.title': 'title',
        'user.dublincore.date': 'upload_date',
        'user.dublincore.description': 'description',
        'user.dublincore.contributor': 'uploader',
        'user.dublincore.format': 'format',
    }

    pp = X

# Generated at 2022-06-22 09:22:56.633026
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import xattr_unavailable

    # We don't run the tests if the xattr are unsupported
    if xattr_unavailable:
        return

    import tempfile, shutil, os.path

    from ..YoutubeDL import YoutubeDL

    # Create a temporary directory
    tempdir = tempfile.mkdtemp(prefix='ytdl_temp')

    # Create a test file
    filename = os.path.join(tempdir, 'test_file')
    open(filename, 'w').close()

    # Create a YoutubeDL object
    ydl = YoutubeDL({})

    # Create a XAttrMetadataPP object
    xattrpp = XAttrMetadataPP(ydl)

    # Test the run method

# Generated at 2022-06-22 09:23:08.345103
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os
    import shutil
    import tempfile
    from .test_utils import FakeYDL

    tmpdir = tempfile.mkdtemp()
    filename = os.path.join(tmpdir, 'test_file.mp3')

# Generated at 2022-06-22 09:23:19.121533
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run(): # pylint: disable=invalid-name
    from ..utils import encodeFilename
    from ..compat import compat_os_name

    if compat_os_name == 'nt':
        return

    import tempfile
    import xattr
    import os

    pp = XAttrMetadataPP()

    #
    # When pp.run is called, it should write the metadata to the file's xattrs
    #

    # create a dummy ytdl info dict

# Generated at 2022-06-22 09:23:38.297143
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..downloader import FakeYDL
    from ..extractor import YoutubeIE
    from .execonfigpp import ExeConfigPP

    ydl = FakeYDL()
    ydl.add_info_extractor(YoutubeIE())
    ydl.add_post_processor(ExeConfigPP())
    ydl.add_post_processor(XAttrMetadataPP())
    ydl.params['outtmpl'] = 'foo.mp4'
    res = ydl.extract_info('https://www.youtube.com/watch?v=JNjUNXoLtkE', download=True)
    assert res['title'] == 'Mastering Professional Scrum'
    assert not ydl.has_warning()

# Generated at 2022-06-22 09:23:49.513145
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import io
    import ctypes
    import time
    import tempfile
    import shutil
    import os
    from .common import PostProcessorTest

    from ..extractor import gen_extractors

    def write_metadata(filename, info):
        """Return a PostProcessor for XAttrMetadata"""

        class FakeYDL:
            def report_error(self, msg):
                print(msg)

            def report_warning(self, msg):
                print(msg)

            def to_screen(self, msg):
                print(msg)

        pp = XAttrMetadataPP(FakeYDL())

        _, info = pp.run(info)

        return info

    def read_metadata(filename):
        """Return the xattr metadata (dict) of a filename"""

        metadata = {}


# Generated at 2022-06-22 09:23:50.950713
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # No exception expected
    XAttrMetadataPP(object)

# Generated at 2022-06-22 09:24:01.606966
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    #pylint: disable=R0904
    from .common import FileDownloader
    from ..utils import DateRange

    d = FileDownloader({})

    from .gettitle import GetTitlePP
    from .xattrfromtitle import XAttrFromTitlePP
    from .xattrfromformat import XAttrFromFormatPP

    pp1 = GetTitlePP(d)
    pp2 = XAttrFromTitlePP(d)
    pp3 = XAttrFromFormatPP(d)

    # Test a simple run
    infos = []

# Generated at 2022-06-22 09:24:12.292713
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # Input
    xattrs = [
        'user.xdg.referrer.url',
        'user.xdg.comment',
        'user.dublincore.title',
        'user.dublincore.date',
        'user.dublincore.description',
        'user.dublincore.format',
        'user.dublincore.contributor',
    ]

    # Expected output

# Generated at 2022-06-22 09:24:22.261960
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os
    import shutil
    import tempfile
    from .common import FileDownloader
    from ..compat import compat_os_name

    # Test only on compatible OS

# Generated at 2022-06-22 09:24:34.160134
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    """
    Given the following test data:
    - A file with xattr support enabled
    - A valid info dict
    When XAttrMetadataPP.run is called with the file and info dict as input
    Then the return should be a empty list

    :return:
    """
    python_files_dir = os.path.dirname(os.path.abspath(__file__))
    resources_dir = os.path.join(python_files_dir, '..', '..', '..', 'resources')
    files_dir = os.path.join(resources_dir, 'files')
    file_with_xattr_support = os.path.join(files_dir, 'file-with-xattr-support')


# Generated at 2022-06-22 09:24:43.919740
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor import gen_extractors
    import youtube_dl.YoutubeDL
    ydl = youtube_dl.YoutubeDL({'writethumbnail':True,'writeinfojson':True})
    ie = gen_extractors(ydl)["youtube"]()
    ydl.add_info_extractor(ie)
    url = "https://www.youtube.com/watch?v=BaW_jenozKc"
    info = ydl.extract_info(url, download=False)
    return info['description']

# Generated at 2022-06-22 09:24:54.340926
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from youtube_dl.downloader.FileDownloader import FileDownloader
    from youtube_dl.InfoExtractors import YoutubeIE
    from youtube_dl.YoutubeDL import YoutubeDL

    dl = YoutubeDL({
        'quiet': True,
        'simulate': True,
        'logger': None,
        'skip_download': True,
        'outtmpl': '%(id)s.%(ext)s',
    })
    dl._ie = YoutubeIE({})
    dl.add_post_processor(XAttrMetadataPP(dl))
    fd = FileDownloader({'id': 'test_id'}, dl)
    fd.add_info_extractor(dl._ie)
    info = fd.prepare_filename("test_id")

# Generated at 2022-06-22 09:25:02.824514
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import pytest
    from pytest_mock import mocker
    from ..utils import write_xattr
    from .common import PostProcessor
    from .xattr import XAttrMetadataPP


# Generated at 2022-06-22 09:25:30.912359
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    info = {
        'webpage_url': 'http://www.youtube.com/watch?v=BaW_jenozKc',
        'title': 'youtube-dl test video "\'/\\ä↭𝕐',
        'description': 'test chars:  "\'/\\ä↭𝕐\n\n---\n\nThis is a test video for youtube-dl.\n\nFor more information, visit http://rg3.github.com/youtube-dl/',
        'upload_date': '20121002',
        'uploader': 'HallyuBack',
        'format': '5 - 256x144 (flv)',
        'filepath': 'test_video__ä↭𝕐_BaW_jenozKc.f247.5.256x144.mp4',
    }

    post

# Generated at 2022-06-22 09:25:32.791153
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP()
    assert pp.get_name() == 'xattr'

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-22 09:25:37.178150
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x = XAttrMetadataPP(None)
    assert x != None


# vim:sw=4:ts=4:et:

# Generated at 2022-06-22 09:25:38.689756
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # TODO: Test not implemented
    assert False


# Generated at 2022-06-22 09:25:40.629849
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():  # skipcq: PYL-W0613
    downloader = object
    xattr = XAttrMetadataPP(downloader)
    assert xattr

# Generated at 2022-06-22 09:25:45.114345
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    class MockInfo:
        def get(self, key):
            if key == 'format':
                return '22'
            else:
                return None

    XAttrMetadataPP.run(MockInfo())

# Generated at 2022-06-22 09:25:48.987954
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():

    pp = XAttrMetadataPP('my_downloader')
    pp.run({'title': 'Video Title', 'description': 'Video Description', 'format': 'Video Format'})

# Generated at 2022-06-22 09:25:57.380930
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import json
    import os
    import sys


# Generated at 2022-06-22 09:26:04.937337
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from . import _common_test
    from ..utils import encodeFilename
    assert _common_test.test_runner(test_name='XAttrMetadataPP.run',
                                    method_obj=XAttrMetadataPP().run,
                                    method_args=[
                                        {'title': 'test', 'webpage_url': 'http://example.com'},
                                    ],
                                    expect_result=[
                                        [],
                                        {'title': 'test', 'webpage_url': 'http://example.com'},
                                    ],
                                    ).run_tests()

# Generated at 2022-06-22 09:26:06.610638
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP()
    assert pp is not None

# Generated at 2022-06-22 09:26:44.436853
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-22 09:26:54.025262
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..compat import xattr

    import tempfile
    import os
    import os.path

    # Looping because xattr has a limit on the number of times that extended
    # attribute support can be toggled.
    for i in range(0, 2):

        filename = os.path.join(tempfile.gettempdir(), 'XAttrMetadataPP_testfile')


# Generated at 2022-06-22 09:27:03.239987
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    # youtube_ie
    # NOTE: we don't test if the xattr is actually set, because it's not easily possible
    #       to check that without a fake filesystem; basically we just test the error handling
    #       and the proper escaping of special characters in the value passed to 'setxattr'

    # description test
    # description containing ' and "
    info_dict = {'filepath': 'fakepath', 'description': 'foo "bar" \'baz\''}
    result, info_ret = XAttrMetadataPP().run(info_dict)
    assert not result
    # description containing $ and & (should be escaped)
    info_dict = {'filepath': 'fakepath', 'description': '$foo&;'}
    result, info_ret = XAttrMetadataPP().run(info_dict)

# Generated at 2022-06-22 09:27:14.840521
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from .common import FileDownloader
    # This is a test, so if the xattr module is not installed,
    # just print a warning and let the test pass
    try:
        import xattr
    except ImportError:
        print('WARNING: xattr module is not installed')
        return
    # test an empty FileDownloader
    fd = FileDownloader({})
    fd.prepend_postprocessor(XAttrMetadataPP())
    try:
        fd.download([])
    except:
        import sys
        import traceback
        print(repr(sys.exc_info()[1]))
        traceback.print_tb(sys.exc_info()[2])
    # test a FileDownloader with (at least one) successfull download
    fd = FileDownloader({'test': True})


# Generated at 2022-06-22 09:27:26.177229
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    # Unit test disabled when xattr not available
    import sys
    if sys.version_info[0] == 2:
        from youtube_dl.utils import xattr_supported
    else:
        from youtube_dl.utils import xattr_unavailable
        xattr_supported = not xattr_unavailable

    if not xattr_supported:
        return

    import os
    import shutil

    from youtube_dl.downloader.common import FileDownloader

    # Create a dummy file
    dummy_filename = 'dummy.tmp'
    open(dummy_filename, 'wb').write(b'foo')

    # Actual test
    class DummyYDL(object):
        def __init__(self):
            self.params = dict()
            self.to_screen = DummyToScreen()
            self.report_warning = D

# Generated at 2022-06-22 09:27:38.137935
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..extractor import YoutubeIE
    from ..downloader.common import FileDownloader
    from ..utils import DateRange

    ie = YoutubeIE()
    yt_videos = ie._real_extract(DateRange('<2015-02-01', '<=2015-04-01'), 'ytsearch3', 'python')
    assert len(yt_videos) > 3
    yt_video_info = yt_videos[1]

    from ..extractor.youtube import YoutubeIE
    from ..utils import (
        DateRange,
    )
    info = ie._real_extract(DateRange('<2015-02-01', '<=2015-04-01'), 'ytsearch3', 'python')

    import json

# Generated at 2022-06-22 09:27:49.008197
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .common import FileDownloader

    pp = XAttrMetadataPP(FileDownloader({'format': 'xattrs'}))
    info = {
        'description': 'description',
        'webpage_url': 'http://youtube.com/watch?v=foobar',
        'title': 'title',
        'upload_date': '20120101',
        'uploader': 'uploader',
        'format': 'normal',
        'ext': 'mp4',
        'filepath': 'test_file',
        '_filename': 'test_file.mp4',
        '_forcefilename': True,
    }

    returncode, _ = pp.run(info)

    assert returncode == []

    # TODO: write some real unit tests
    # assert returncode == [('test_XAttrMetadata

# Generated at 2022-06-22 09:27:58.214298
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import WindowsError
    def raise_exception(e):
        raise e

    pp = XAttrMetadataPP(None)
    xattrs = {
        'filepath': 'file.mp4',
        'webpage_url': 'http://www.youtube.com/watch?v=9bZkp7q19f0',
        'title': 'PSY - GANGNAM STYLE (강남스타일) M/V',
        'upload_date': '20120715',
        'description': 'Test video',
        'uploader': 'officialpsy',
        'format': 'mp4',
    }

    pp.run(xattrs)
    assert True

    # Test XAttrUnavailableError
    pp.run = lambda o: raise_

# Generated at 2022-06-22 09:28:00.536437
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    """Tests the constructor of the class XAttrMetadataPP"""
    inst = XAttrMetadataPP()
    assert inst is not None


# Generated at 2022-06-22 09:28:09.385451
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from .. import YoutubeDL
    info = dict(title='a', webpage_url='b', description='c', uploader='d', upload_date='e', format='f')
    ydl_opts = dict(writedescription=True)
    ydl = YoutubeDL(ydl_opts)
    proc = XAttrMetadataPP(ydl, ydl_opts, info)
    assert proc.__class__.__name__ == 'XAttrMetadataPP'
    assert proc.ydl == ydl
    assert proc.ydl_opts == ydl_opts
    assert proc.info == info
    assert proc._downloader == ydl

# Generated at 2022-06-22 09:29:32.700438
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..extractor.common import InfoExtractor
    from ..downloader import Downloader


# Generated at 2022-06-22 09:29:41.393585
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..compat import compat_xattr
    from ..utils import encodeFilename
    from tempfile import TemporaryDirectory
    from xml.etree.ElementTree import fromstring as parse_xml
    from xml.etree.ElementTree import ElementTree
    import io
    import os
    import unittest

    class DummyYdl(object):
        def __init__(self):
            self.to_screen = print
            self.report_error = lambda msg: print('ERROR:', msg)
            self.report_warning = lambda msg: print('WARNING:', msg)

    class XAttrMetadataPP_Tester(XAttrMetadataPP):
        def __init__(self):
            self._downloader = DummyYdl()
            self._downloader.params = {}


# Generated at 2022-06-22 09:29:49.060370
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import prepend_extension
    import tempfile
    import os
    import xattr

    def get_keys(f):
        xattrs_map = xattr.xattr(f)
        keys = xattrs_map.list()
        xattrs_map.close()
        return keys

    info = {
            'filepath': 'test_video.mp4',
            'webpage_url': 'http://example.com/test_page.html',
            'title': 'test video',
            'upload_date': '20121112',
            'description': 'This is a test video, enjoy!',
            'uploader': 'Test Uploader',
            'format': 'unknown'
        }

    fd, f = tempfile.mkstemp()

# Generated at 2022-06-22 09:29:54.694231
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor import gen_extractors
    from ..downloader import gen_ytdl_objects

    from .common import PostProcessorTest

    postprocessor_test = PostProcessorTest('XAttrMetadataPP', gen_extractors(), gen_ytdl_objects())
    postprocessor_test.run('XAttrMetadataPP')

# Generated at 2022-06-22 09:29:58.312358
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    xattr_metadata_pp = XAttrMetadataPP()

    # Check that class is PostProcessor
    assert isinstance(xattr_metadata_pp, PostProcessor), 'XAttrMetadataPP should be a PostProcessor'

# Generated at 2022-06-22 09:30:06.867958
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    """ Unit test for method run of class XAttrMetadataPP """

    from ..YoutubeDL import YoutubeDL, FileDownloader

    def _check_xattrs(filename, checks):
        """ Check if xattrs of a specified file contain all specified values """

        for xattrname, value in checks.items():
            byte_value = value.encode('utf-8')
            real_value = read_xattr(filename, xattrname).decode('utf-8')
            if value != real_value:
                raise Exception('Extended attribute {0} doesn\'t have expected value ({1} != {2})'
                                .format(xattrname, value, real_value))

        return True


# Generated at 2022-06-22 09:30:08.478936
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # This is not a test
    pass

# Generated at 2022-06-22 09:30:08.930624
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-22 09:30:10.017482
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP()

# Generated at 2022-06-22 09:30:12.211041
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    """No unit test for XAttrMetadataPP.

    This is because the unit test framework does not provide an easy
    way to test for extended attributes on the filesystem.

    """