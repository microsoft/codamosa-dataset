

# Generated at 2022-06-22 09:21:13.081907
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os
    import stat
    import platform
    from .common import PostProcessorTestCase

    expected_results = {}
    if platform.system() != 'Windows':
        # FIXME: Write xattr tests on Windows
        from .conftest import XAttr
        expected_results = {
            'user.xdg.referrer.url': 'webpage_url',
            # 'user.xdg.comment':            'description',
            'user.dublincore.title': 'title',
            'user.dublincore.date': 'upload_date',
            'user.dublincore.description': 'description',
            'user.dublincore.contributor': 'uploader',
            'user.dublincore.format': 'format',
        }


# Generated at 2022-06-22 09:21:13.656510
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pass

# Generated at 2022-06-22 09:21:23.905102
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os
    import platform
    import shutil
    import tempfile
    import unittest

    # Skip this test if there is no extended attribute support.
    try:
        import xattr
    except ImportError:
        return

    class _MockFileDownloader(object):
        def __init__(self):
            self.temp_dir = None
            self.troubles = []
        def to_screen(self, msg):
            pass
        def report_warning(self, msg):
            self.troubles.append(msg)
        def report_error(self, msg):
            self.troubles.append(msg)
    class _MockInfoExtractor(object):
        def __init__(self, uploader, description):
            self.uploader = uploader
            self.description = description
            self

# Generated at 2022-06-22 09:21:32.680071
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    import tempfile
    def _test_with_touch(tmp_d):
        import os.path
        import shutil

        # Create file
        tmp_f = os.path.join(tmp_d, 'tmp_f')
        with open(tmp_f, 'wb'):
            pass

        pp = XAttrMetadataPP(None)
        pp.run({'filepath': tmp_f, 'webpage_url': 'http://example.com/video', 'duration': '43', 'title': 'Foo Bar'})
        shutil.rmtree(tmp_d)

    tmp_d = tempfile.mkdtemp()
    try:
        _test_with_touch(tmp_d)
    finally:
        import shutil
        shutil.rmtree(tmp_d)

# Generated at 2022-06-22 09:21:35.943760
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x = XAttrMetadataPP()
    assert isinstance(x, XAttrMetadataPP)

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-22 09:21:37.234642
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # Note: this should raise an exception
    pp = XAttrMetadataPP(None)

# Generated at 2022-06-22 09:21:38.159270
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    return XAttrMetadataPP({})

# Generated at 2022-06-22 09:21:44.899160
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os
    from io import BytesIO

    from .common import FileDownloader

    filename = os.path.join(os.path.dirname(__file__), __name__, 'xattr_metadata.test')


# Generated at 2022-06-22 09:21:55.297489
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import hashlib
    import os.path
    import tempfile

    filename = tempfile.mkstemp()[1]
    info = {
        'filepath': filename,
        'webpage_url': 'http://example.com',
        'title': 'The title of the video',
        'description': 'The description of the video',
        'upload_date': '20160724',
        'uploader': 'The uploader of the video',
        'format': 'The format of the video',
    }

    # Write extended attributes

# Generated at 2022-06-22 09:21:59.238357
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..downloader.common import FileDownloader

    ydl = FileDownloader({})
    pp = XAttrMetadataPP(ydl)

    assert pp.get_name() == 'xattrs'

# Generated at 2022-06-22 09:22:13.473391
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .common import FileDownloader

    dl = FileDownloader({})
    dl.params.update({
        'dump_single_json': True,
        'quiet': True,
        'format': 'bestaudio/best',
        'skip_download': True,
    })
    ie = dl.build_video_info_extractors()[0]
    ie_result = ie.extract('https://www.youtube.com/watch?v=J---aiyznGQ')

    assert ie_result['extractor'] == 'Youtube'
    assert ie_result['webpage_url'] == 'https://www.youtube.com/watch?v=J---aiyznGQ'
    assert ie_result['id'] == 'J---aiyznGQ'
    assert ie_result['extractor_key']

# Generated at 2022-06-22 09:22:16.414388
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # Arrange
    d = None
    # Act
    x = XAttrMetadataPP(d)
    # Assert
    assert x is not None
    return x


# Generated at 2022-06-22 09:22:27.579461
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    # no space left in the filesystem
    class ErrorXAttrUnavailableError(XAttrUnavailableError):
        def __init__(self): pass
        def reason(self): return 'NO_SPACE'
    # value given is too long
    class ErrorXAttrMetadataError(XAttrMetadataError):
        def __init__(self): pass
        def reason(self): return 'VALUE_TOO_LONG'

    #
    # Test case
    #

    class TestDownloader():

        def __init__(self):
            pass
        def to_screen(self, msg):
            print(msg)
        def report_warning(self, msg):
            print(msg)
        def report_error(self, msg):
            print(msg)


# Generated at 2022-06-22 09:22:28.657060
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    p = XAttrMetadataPP()

# Generated at 2022-06-22 09:22:40.031824
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .common import FileDownloader
    from ..compat import compat_os_name
    from ..utils import RemovalImpl

    class MockXAttrMetadataPP(XAttrMetadataPP):
        def __init__(self):
            self._downloader = FileDownloader({})

        def run(self, info):
            return super(MockXAttrMetadataPP, self).run(info)

    if compat_os_name != 'nt':
        ydl = MockXAttrMetadataPP()


# Generated at 2022-06-22 09:22:47.918902
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    class DummyInfoDict(dict):

        def __init__(self):
            self['filepath'] = '/file/name.mp4'

        def __setitem__(self, key, value):
            dict.__setitem__(self, key, value)
            setattr(self, key, value)


    class DummyYDL(object):

        def to_screen(self, msg):
            pass

        def report_error(self, msg):
            pass

        def report_warning(self, msg):
            pass


    info = DummyInfoDict()
    info['upload_date'] = '20100101'
    info['title'] = 'video title'
    info['description'] = 'video description'
    info['format'] = 'video format'


# Generated at 2022-06-22 09:22:53.385888
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # Test XAttrMetaDataPP instantiation
    pp = XAttrMetadataPP({})
    assert pp.name == 'xattrm'
    assert pp.description == 'Set extended attributes on downloaded file (if xattr support is found)'
    assert XAttrMetadataPP.run == XAttrMetadataPP({}).run

# Generated at 2022-06-22 09:23:03.320904
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # Import will be here to avoid importing `xattr` module for systems that
    # don't have it
    try:
        import xattr
    except ImportError:
        return

    class TestClass(object):
        def to_screen(self, value):
            print(value)

        def report_error(self, value):
            print(value)

        def report_warning(self, value):
            print(value)

    xattr_pp = XAttrMetadataPP(
        {'filepath': 'this_is_a_file_name', 'format': '2560x144'},
        TestClass())


# Generated at 2022-06-22 09:23:12.373814
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    """
    Unit test for method run of class XAttrMetadataPP
    """
    import datetime
    from .common import PostProcessorTest

    filename = PostProcessorTest.get_temp_file('temp.mp4')

# Generated at 2022-06-22 09:23:21.459455
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    """
    Test XAttrMetadataPP.run method
    """

    # Test XAttrMetadataPP.run() with successful XAttrMetadataPP.run()
    obj = XAttrMetadataPP(None)

# Generated at 2022-06-22 09:23:42.648612
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..ytdl.YoutubeDL import YoutubeDL
    from .common import FileDownloader
    from ..utils import DateRange

    ydl_opts = {
    }

    ydl = YoutubeDL(ydl_opts)
    dl = FileDownloader(ydl, ydl_opts)
    xattr_pp = XAttrMetadataPP(dl, ydl_opts)


# Generated at 2022-06-22 09:23:44.389167
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    XAttrMetadataPP(downloader=None)

# Generated at 2022-06-22 09:23:49.525795
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP(None)
    return pp is not None

if __name__ == '__main__':
    import sys, os
    print(test_XAttrMetadataPP())
    sys.exit(os.EX_OK)

# Generated at 2022-06-22 09:23:50.471029
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-22 09:23:51.080597
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():


    pass

# Generated at 2022-06-22 09:23:52.891240
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x = XAttrMetadataPP({})
    assert x

# Generated at 2022-06-22 09:23:59.254542
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP()
    for name in ['webpage_url', 'title', 'upload_date', 'description', 'uploader', 'format']:
        assert name in pp._xattr_mapping.values()
    # TODO: check that the keys are also in the mapping?
    # TODO: test that all the keys and values are XAttrMetadataPP.valid_xattrs
    return pp._xattr_mapping

# Generated at 2022-06-22 09:24:06.013354
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..youtube_dl.YoutubeDL import YoutubeDL
    from .common import FileDownloader
    from .xattr_write import *

    # Test files with no extended attributes
    try:
        os.remove(testfile_nominal)
    except:
        pass
    f = open(testfile_nominal, 'w')
    f.close()
    assert not has_xattr(testfile_nominal)

    # Test files with some extended attributes
    try:
        os.remove(testfile_nominal_xattr)
    except:
        pass
    f = open(testfile_nominal_xattr, 'w')
    f.close()
    set_xattr(testfile_nominal_xattr, b'user.test', b'test')

# Generated at 2022-06-22 09:24:06.632358
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-22 09:24:07.250358
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pass

# Generated at 2022-06-22 09:24:36.110721
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    from ytdl.YoutubeDL import YoutubeDL
    from tests.test_utils import FakeYDL

    ydl = YoutubeDL(FakeYDL({}))

    # With no info
    pp = XAttrMetadataPP(ydl)
    results = pp.run({})

    # Test with info
    pp = XAttrMetadataPP(ydl)

# Generated at 2022-06-22 09:24:46.161023
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    from ..extractor import common
    from ..extractor.youtube import YoutubeIE
    from ..utils import DateRange
    from .common import FileDownloader
    from .subtitles import SubtitlesPP
    from .xattr import XAttrMetadataPP

    URLS = (
        'https://www.youtube.com/watch?v=BaW_jenozKc',
    )

    for url in URLS:
        info = {}

        # Create a FileDownloader instance (needed for calling the process_ie_result method)
        # Note: it does not download the file
        fd = FileDownloader({})

        ie = YoutubeIE()
        info_dict = ie.extract(url)

        subtitles_filename = 'test.en.vtt'

# Generated at 2022-06-22 09:24:53.989170
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    import os
    import tempfile
    from .common import PostProcessor
    from ..utils import write_xattr, XAttrMetadataError, XAttrUnavailableError

    class FakeInfo:
        def __init__(self, filepath, webpage_url, title, upload_date, description, uploader, format):
            self.filepath = filepath
            self.webpage_url = webpage_url
            self.title = title
            self.upload_date = upload_date
            self.description = description
            self.uploader = uploader
            self.format = format

        def __getitem__(self, key):
            return self.__dict__[key]

    class FakeDownloader:
        def __init__(self):
            self.to_screen_called_with_messages = []


# Generated at 2022-06-22 09:24:55.696124
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    t = XAttrMetadataPP()
    assert t is not None


# Generated at 2022-06-22 09:24:56.277367
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-22 09:25:06.637891
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    import tempfile

    fd, fname = tempfile.mkstemp()
    os.write(fd, b'abc')
    os.close(fd)
    info = {'filepath': fname, 'format': 'mp3', 'thumbnail': 'a.jpg', 'title': 'A song',
            'upload_date': '20131112', 'uploader': 'Bob', 'description': 'a song',
            'webpage_url': 'http://example.com/bob/asong.mp3'}
    pp = XAttrMetadataPP()
    res, info = pp.run(info)
    assert os.path.exists(fname) and os.path.getsize(fname) == 3
    assert res == [] and info == info
    os.unlink(fname)


# Generated at 2022-06-22 09:25:15.722043
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    xa = XAttrMetadataPP(None)

    info = {
        'title': 'test title',
        'webpage_url': 'test webpage url',
        'upload_date': '19980222',
        'uploader': 'test uploader',
        'format': 'test format',
        'description': 'test description',
        'filepath': 'test filepath',
    }

    expected_output = ([], info)
    assert xa.run(info) == expected_output, 'XAttrMetadataPP gave unexpected output.'

if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-22 09:25:23.099614
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import inspect
    import os.path
    import platform
    import subprocess
    from tempfile import NamedTemporaryFile

    from . import EmbedThumbnailPP

    def get_xattr_test_filename(testfilename):
        # extend the test filename with the platform name to avoid conflicts
        return testfilename + '.' + str(os.getpid()) + '.' + platform.system()

    def get_xattr_test_filepath(testfilename):
        # extend the test filename with the platform name to avoid conflicts
        return os.path.join(os.path.dirname(__file__), 'xattr-metadata-tests', get_xattr_test_filename(testfilename))

    def start_tst_xattr_metadata(test_filepath):
        # Run the unit test in a subprocess
        import unittest

# Generated at 2022-06-22 09:25:31.299454
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    class FakeInfoDict(dict):
        """ Mocked class for info object returned by YoutubeDL """
        def __init__(self):
            self.filepath = 'test_XAttrMetadataPP_run'
        def __contains__(self, attrname):
            return self.get(attrname) is not None
    class FakeYDL(object):
        """ Mocked class for YoutubeDL object """
        def to_screen(self, s):
            pass
        def report_error(self, s):
            pass
        def report_warning(self, s):
            pass
    class FakeXAttr(object):
        """ Mocked class for xattr module """
        def __init__(self):
            self.listxattr_answer = []
        def listxattr(self, name):
            return self.listx

# Generated at 2022-06-22 09:25:36.310624
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import tempfile

    # Prepare files
    filename = tempfile.mktemp()
    open(filename, 'w').close()

    # Run the method run (with a fake downloader)
    XAttrMetadataPP().run({'filepath': filename, 'webpage_url': b'http://fake/'})
    # TODO: Check that the correct xattr has been written
    import os
    if os.path.exists(filename):
        os.remove(filename)

# Generated at 2022-06-22 09:26:24.724668
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import XAttrMetadataError
    from ..compat import compat_mock

    filename = 'mocked_file.mp4'
    info = {
        'webpage_url': 'http://www.youtube.com/watch?v=90AiXO1pAiA',
        'description': 'The first video in my "Learn to Ski" series, this video explains how to put your skis on -- both at home and on the hill, how to buckle your boots, and how to carry your skis. Stay tuned for more videos in the "Learn to Ski" series.',
        'title': 'Ski School -- How To Put On Ski Boots',
        'upload_date': '20071124',
        'uploader': 'epicski',
        'format': '18 - 640x360 (medium)',
    }


# Generated at 2022-06-22 09:26:34.147882
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .common import FileDownloader

    test_info = {'filepath': '/tmp/test.mp4'}

    with open('tests/testdata/test_XAttrMetadataPP_run.txt', 'r') as test_data_file:
        test_data = test_data_file.readlines()

    num_passed = 0

    # Testing downloader without xattr support
    downloader = FileDownloader({'xattr_set_filesize': True})
    pp = XAttrMetadataPP(downloader)
    for line in test_data:
        test_info['xattr_value'] = line.strip()
        retcode, test_info = pp.run(test_info)


# Generated at 2022-06-22 09:26:44.486726
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    import io
    # TODO: Write more robust test
    class TestFakeYDL:
        def __init__(self):
            self.to_screen_value = io.StringIO()
            self.params = {}
            self.to_screen_called = False
            self.report_error_called = False
            self.report_warning_called = False
        def to_screen(self, msg):
            assert(isinstance(msg, str))
            self.to_screen_called = True
        def report_error(self, msg):
            assert(isinstance(msg, str))
            self.report_error_called = True
        def report_warning(self, msg):
            assert(isinstance(msg, str))
            self.report_warning_called = True


# Generated at 2022-06-22 09:26:48.307047
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP(): # pylint: disable=missing-docstring
    metadatapp = XAttrMetadataPP(None)
    assert metadatapp.lookup_based_on_md5() == False, 'lookup_based_on_md5() default is False'

# Generated at 2022-06-22 09:26:57.961270
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import encode_data_uri
    p = XAttrMetadataPP()
    result = p.run({
        'filepath': '/test/test.mkv',
        'webpage_url': 'http://test.test',
        'title': 'test title \xef\xbf\xbd',
        'upload_date': '20150212',
        'uploader': 'test uploader',
        'description': 'test description',
        'format': 'mkv',
        'thumbnail': encode_data_uri('test thumbnail'),
        'resolution': '720p',
        'duration': '1234',
        'filesize': '9999999999',
        'fps': '1',
    })

# Generated at 2022-06-22 09:26:58.552426
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    return True

# Generated at 2022-06-22 09:27:01.056760
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    try:
        XAttrMetadataPP(None, None, None)
    except Exception:
        assert False, "Constructor of XAttrMetadataPP class should not return any exception"

# Generated at 2022-06-22 09:27:02.746472
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    tester = XAttrMetadataPP(None)
    assert isinstance(tester, XAttrMetadataPP)

# Generated at 2022-06-22 09:27:04.565400
# Unit test for method run of class XAttrMetadataPP

# Generated at 2022-06-22 09:27:16.261286
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    from .common import FileDownloader
    from ..compat import compat_HTTPError
    from ..utils import DateRange, sanitize_open
    
    # Prepare a test FileDownloader
    dl = FileDownloader({})
    dl.params = {
        'username': 'pepe',
        'password': 'pepe',
        'usenetrc': 'pepe',
        'verbose': True
    }

    # Insert a test PostProcessor
    pp_test = XAttrMetadataPP(dl)
    dl._postprocessors["test"] = [pp_test]

    # Prepare some test data

# Generated at 2022-06-22 09:28:37.562458
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-22 09:28:40.837491
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    """
    Create a XAttrMetadataPP object.
    :return:
    """
    # Call the constructor
    XAttrMetadataPP(downloader=None, ie=None, ie_key=None)


# Generated at 2022-06-22 09:28:48.555485
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    class FakeYDL:
        def to_screen(a, s):
            print(s)
        def report_error(a, s):
            print(s)
        def report_warning(a, s):
            print(s)

    info = {
        'webpage_url': 'http://this.is/an/url',
        'title': 'my video title',
        'upload_date': '2014-12-31',
        'description': 'The description of this video is quite cool.',
        'uploader': 'Foo Bar',
        'format': 'mp4',
        'ext': 'mp4',
        'filepath': '/tmp/video.mp4'
    }


# Generated at 2022-06-22 09:28:59.213697
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import os
    import tempfile
    import unittest
    from .common import FileDownloader

    class TestFileDownloader(FileDownloader):
        def to_screen(self, *args, **kwargs):
            pass

        def report_warning(self, *args, **kwargs):
            pass

        def report_error(self, *args, **kwargs):
            pass

        def temp_name(self, *args, **kwargs):
            return tempfile.NamedTemporaryFile(delete=False).name

    class TestXAttrMetadataPP_run(unittest.TestCase):
        def setUp(self):
            self.pp = XAttrMetadataPP()
            self.pp._downloader = TestFileDownloader()


# Generated at 2022-06-22 09:29:08.841892
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os
    import tempfile

    import pytest

    from ..utils import XAttrUnavailableError


# Generated at 2022-06-22 09:29:13.765824
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    """
    Test XAttrMetadataPP.run()
    """
    # FIXME:
    raise NotImplementedError()

# Generated at 2022-06-22 09:29:22.750705
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    filename = 'test.mp4'
    video_info = {
        'filepath': filename,
        'title': 'title',
        'upload_date': '20170523',
        'description': 'description',
        'uploader': 'uploader',
        'format': 'format',
    }

# Generated at 2022-06-22 09:29:25.270694
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    PP = XAttrMetadataPP("some-file")
    assert PP.filepath == "some-file"

# Generated at 2022-06-22 09:29:26.354009
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert not XAttrMetadataPP(None).run({})

# Generated at 2022-06-22 09:29:33.498845
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os
    import sys
    import tempfile
    import unittest

    from ..downloader import Downloader

    # Mockups
    class MockFD(object):
        def write(self, s):
            pass
        def close(self):
            pass

    class MockStdStream(object):
        def __init__(self, which):
            self.fd = MocFD()

        def fileno(self):
            return self.fd

    class MockYDL(object):

        def to_screen(self, message):
            pass

        def report_warning(self, message):
            pass

        def report_error(self, message):
            pass
