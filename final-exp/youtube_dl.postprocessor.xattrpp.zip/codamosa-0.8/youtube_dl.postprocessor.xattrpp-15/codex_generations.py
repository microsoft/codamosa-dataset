

# Generated at 2022-06-12 19:20:40.000840
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # Unit test for method run of class XAttrMetadataPP
    # We suppose that we have a debian system,
    # because there is a specific function (xdg-mime) to check
    # if the system supports extended attributes. On a non debian
    # system, this function isn't available, so we couldn't test

    # The tool xdg-mime is available on debian systems
    # For more information: https://packages.debian.org/fr/source/sid/xdg-utils
    if os.system('xdg-mime --version') != 0:
        print('Skip test on unsupported system: not a debian system')
        sys.exit()

    # Let's suppose that we are on a linux system, with the correct
    # configuration to set extended attributes

# Generated at 2022-06-12 19:20:51.668956
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .common import get_testdata_video_result
    from ..compat import is_py2

    info = get_testdata_video_result()
    info['webpage_url'] = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    info['format'] = '18 - 480x360 - 15.67 MiB - Flash Video - H.264/AVC (10.13)'
    info['thumbnail'] = "http://i.ytimg.com/vi/BaW_jenozKc/default.jpg"


# Generated at 2022-06-12 19:20:59.447612
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .common import FileDownloader
    from .test import get_testdata
    from .info import InfoExtractor
    from ..compat import compat_os_name
    from ..utils import XAttrUnavailableError
    import tempfile
    import os


# Generated at 2022-06-12 19:21:06.240912
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import platform
    import os
    import tempfile
    import xattr
    import shutil

    if platform.system() != 'Linux':
        print('Test skipped because your platform is not Linux')
        return

    downloader = None

    try:
        import youtube_dl
    except ImportError:
        # Installing youtube-dl is not a requirement with this package.
        pass
    else:
        downloader = youtube_dl.YoutubeDL()

    with tempfile.NamedTemporaryFile(delete=False) as tf:

        # Create a test file
        filename = tf.name

        # Run the test
        pp = XAttrMetadataPP(downloader)

# Generated at 2022-06-12 19:21:14.474203
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    import sys
    import os

    from .common import FileDownloader
    from ..utils import setup_dirs

    def test_XAttrMetadataPP_constructor(capfd):
        ydl = FileDownloader({})
        pp = XAttrMetadataPP(ydl)
        pp.run({})

    if sys.version_info >= (3, 3) and hasattr(os, 'setxattr'):
       test_XAttrMetadataPP_constructor()
    else:
        # Avoid "OSError: No such file or directory" exception
        (temp_dir,) = setup_dirs(None, force_metadata=True)
        os.chdir(temp_dir)
        test_XAttrMetadataPP_constructor(capfd=None)

# Generated at 2022-06-12 19:21:26.444831
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    import os
    import pytest
    import tempfile
    import time
    from ..compat import compat_os_name
    from ..utils import write_xattr

    # Check if we have support for xattrs
    from .common import PostProcessor
    from .xattrs import XAttrMetadataPP
    metadata_postprocessor = XAttrMetadataPP()
    if not metadata_postprocessor.available:
        # can't test, return
        return

    tmp_dir = tempfile.gettempdir()
    filename = os.path.join(tmp_dir, 'xattr_test.file')


# Generated at 2022-06-12 19:21:28.177610
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-12 19:21:28.716602
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pass

# Generated at 2022-06-12 19:21:35.856371
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os
    import tempfile
    import pytest

    # We need to write a test file to the filesystem
    with tempfile.NamedTemporaryFile(mode='wb', delete=False) as f:
        testfile = f.name
        f.write(b'Hello, test file.')

    # We need to create a PostProcessor instance and call run method
    from ..compat import compat_urlparse

# Generated at 2022-06-12 19:21:36.825990
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    XAttrMetadataPP(None, {})

# Generated at 2022-06-12 19:21:42.611572
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pass

# Generated at 2022-06-12 19:21:48.690626
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    info = {
        'webpage_url': 'test url',
        'description': 'test description',
        'title': 'test title',
        'upload_date': 'test upload date',
        'uploader': 'test uploader',
        'format': 'test format',
    }
    filepath = 'test filepath'

    # unused arguments
    PostProcessor.run(XAttrMetadataPP, {'filepath': filepath}, info)

# Generated at 2022-06-12 19:21:50.064108
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP(None)
    assert pp is not None

# Generated at 2022-06-12 19:21:57.023549
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..compat import is_py2

    if sys.platform == 'win32':
        assert False, 'This test is not supposed to run on Windows'

    from .common import FileDownloader
    from .common import FakeInfoExtractor

    class FakeIE(FakeInfoExtractor):
        def set_downloader(self, downloader):
            downloader.filename = '__test.txt'

    ydl = FileDownloader({'outtmpl': '%(id)s', 'download_archive': '__test.txt'})
    ydl.add_info_extractor(FakeIE())
    ydl.process_ie_result(ydl.extract_info('whatever', {'id': '__test.txt'}))

    # Some filesystems don't support XAttr (e.g. FAT32, VFAT)


# Generated at 2022-06-12 19:22:07.309265
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .utils import _prepare_test_download
    from .common import FileDownloader
    info = {'filepath': 'foo',
            'webpage_url': 'bar',
            'title': 'x%20y',
            'upload_date': '20170102',
            'description': 'qux',
            'uploader': 'quux',
            'format': 'quuux',
    }
    d = FileDownloader({'nopart': False, 'outtmpl': '%(id)s'})
    with _prepare_test_download(d, 'foo.f4v') as (f, _):
        pp_obj = XAttrMetadataPP()
        pp_obj.run(info)
        f.seek(0)
        xattrs = {}
        while True:
            k

# Generated at 2022-06-12 19:22:19.805761
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .common import InfoExtractor
    from .extractor import YoutubeIE
    from .extractor.common import InfoExtractor
    from .utils import DateRange
    from ..compat import compat_str


# Generated at 2022-06-12 19:22:30.880768
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from unittest import TestCase
    from .__main__ import YDL
    from ..extractor.common import InfoExtractor
    import sys
    import tempfile
    import shutil
    import os

    class DummyIE(InfoExtractor):
        _VALID_URL = '$'
        IE_DESC = False  # We don't want to be selected automatically
        def report_download_webpage(self, *args, **kargs):
            pass
    ie = DummyIE(YDL())

    class MockFD(object):
        def __init__(self):
            self.seek_called = False
            self.write_called = False
            self.tell_called = False
            self.close_called = False
            self._pos = 0
            self._size = 1


# Generated at 2022-06-12 19:22:41.208050
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import DateRange, fake_to_real_ext

    # TODO: add a test for actual writing of xattrs
    # TODO: test for more than one URL
    # TODO: test for more than one video
    # TODO: test for more than one video on a webpage
    # TODO: test with real webpage

    test_playlist = False  # set it to True to test a playlist

    # A webpage

# Generated at 2022-06-12 19:22:50.758669
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # Suppress stdout for clean output of unit test
    from io import StringIO
    import sys
    import unittest
    from unittest.mock import patch

    def _mock_write_xattr(filename, xattrname, byte_value):
        if not filename:
            raise XAttrMetadataError('This filesystem doesn\'t support extended attributes.')
        elif not xattrname:
            raise XAttrMetadataError('Unable to write extended attributes due to too long values.')
        elif xattrname == 'user.dublincore.date':
            raise XAttrMetadataError('NO_SPACE')
        elif xattrname == 'user.xdg.referrer.url':
            raise XAttrUnavailableError('Unable to write extended attributes', reason='NO_SPACE')



# Generated at 2022-06-12 19:22:53.920758
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x = XAttrMetadataPP(None)


if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-12 19:23:12.588589
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import pytest
    from ..extractor.youtube import YoutubeIE
    from ..utils import encodeFilename
    from .common import FileDownloader
    from .external import ExternalFD
    from .xattr import xattr_available


# Generated at 2022-06-12 19:23:13.124908
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-12 19:23:21.773854
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # Initializing objects
    test_XAttrMetadataPP = XAttrMetadataPP()

    #
    # Tests for this PostProcessor
    #

    # Testing run method when user.xdg.referrer.url is not available in *info*
    filename = '/tmp/some_filename'
    info = {'webpage_url': None,
            }
    assert test_XAttrMetadataPP._downloader.to_screen.called is None
    assert test_XAttrMetadataPP._downloader.report_warning.called is None
    assert test_XAttrMetadataPP._downloader.report_error.called is None
    assert test_XAttrMetadataPP.run(info) == ([], info)
    assert test_XAttrMetadataPP._downloader.to_screen.called is None


# Generated at 2022-06-12 19:23:31.910948
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import os
    import subprocess

    # creates the fake file, just a file with some bytes in it
    fake_filename = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'filename')
    f = open(fake_filename, 'w')
    f.write("\x00\x01\x02")
    f.close()

    # creates a fake downloader and a fake info
    from .common import FileDownloader
    from ..compat import compat_str
    from ..extractor import YoutubeIE
    from ..utils import FakeYDL
    d = FakeYDL()
    d.params = {'writethumbnail': True, 'writeinfojson': False}
    d.add_info_extractor(YoutubeIE())

# Generated at 2022-06-12 19:23:39.794416
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # pylint: disable=protected-access
    import os
    from tempfile import NamedTemporaryFile
    from .test_utils import TestPostProcessor

    f = NamedTemporaryFile(suffix='.flv', delete=False)
    f.close()

# Generated at 2022-06-12 19:23:45.948546
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..downloader.common import FileDownloader

    info = {
        'id': 'testid',
        'title': 'Test Title',
        'description': 'Test Description',
        'upload_date': '20121212',
        'uploader': 'Test Uploader',
        'format': 'Test Format',
        'webpage_url': 'http://example.com/video',
        'filepath': 'test.mp4',
    }
    downloader = FileDownloader({})
    pp = XAttrMetadataPP(downloader)
    pp.run(info)

# Generated at 2022-06-12 19:23:46.921611
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP(None)

# Generated at 2022-06-12 19:23:55.145631
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    filename = 'video_file.ext'

    #
    # Test the _do_write_xattrs method
    #
    # Simulate a failure while writing attributes
    def write_xattr_fake_failure(filename, attrname, value):
        raise XAttrUnavailableError('This is just a test')

    # mock the write_xattr module method with the fake_failure method
    import sys
    import types
    import youtube_dl.postprocessor.xattr_pp

    youtube_dl.postprocessor.xattr_pp.write_xattr = types.MethodType(write_xattr_fake_failure, youtube_dl.postprocessor.xattr_pp)

# Generated at 2022-06-12 19:23:56.753146
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    assert True;

if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-12 19:24:06.811060
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import os
    import unittest

    from tempfile import mkstemp
    from .common import PostProcessorTest
    from ..utils import sanitize_filename

    from .testutils import CallbackTest

    #
    # The mp4 test file has the following metadata:
    #
    #  duration=88        (1:28)
    #  major_brand=isom   (ISO base media file format)
    #  minor_version=512
    #  compatible_brands=isomiso2avc1mp41
    #  encoder=Lavf53.32.100
    #  language=und
    #  title=test video
    #  artist=foo bar
    #  copyright=copyright (c) 2014 foo bar
    #  date=2014-07-02
    #  description=test subtitles\n

# Generated at 2022-06-12 19:24:27.609348
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    xattr_pp = XAttrMetadataPP()

# Generated at 2022-06-12 19:24:28.199933
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-12 19:24:38.104668
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .test import yt_dummy
    filename = 'dummy_file'
    # Create file
    open(filename, 'a').close()
    # Write video info
    video = yt_dummy(filename, {'title': 'titl',
                                'webpage_url': 'web_url',
                                'description': 'desc',
                                'upload_date': '20160101',
                                'uploader': 'uploadr',
                                'format': 'mp4',
                                'filepath': filename})
    # Write metadata
    pp = XAttrMetadataPP()
    pp.run(video)
    # Read metadata

# Generated at 2022-06-12 19:24:39.883424
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass


if __name__ == '__main__':
    # Run unit tests
    import sys
    sys.exit(unittest.main())

# Generated at 2022-06-12 19:24:46.340970
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import tempfile
    import os
    test_file = tempfile.NamedTemporaryFile(bufsize=0, delete=False)

    test_input = [
        {'filepath': test_file.name, 'title': "Test title", 'description': 'Long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long description', 'upload_date': '20150203', 'uploader': 'Test uploader', 'format': 'MP4', 'webpage_url': 'http://www.youtube.com/watch?v=123456789'},
    ]


# Generated at 2022-06-12 19:24:56.149252
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    class PostProcessorTest:
        def to_screen(self, msg):
            pass
        def report_error(self, msg):
            pass
        def report_warning(self, msg):
            pass
    class DummyYDL:
        def __init__(self, pp):
            self.postprocessor = pp
    xattr_mapping = {
        'user.xdg.referrer.url': 'webpage_url',
        'user.dublincore.title': 'title',
        'user.dublincore.date': 'upload_date',
        'user.dublincore.description': 'description',
        'user.dublincore.contributor': 'uploader',
        'user.dublincore.format': 'format',
    }
    info = {}


# Generated at 2022-06-12 19:25:03.657462
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import tempfile
    import unittest
    from ..utils import write_string
    from .common import FileDownloader
    from .xattr import XAttrMetadataPP

    class FakeInfo(dict):

        def __init__(self, *args, **kwargs):
            super(FakeInfo, self).__init__(*args, **kwargs)
            self['filepath'] = 'testfile'

    class XAttrMetadataPPTest(unittest.TestCase):
        def setUp(self):
            self.__tmpdir = tempfile.mkdtemp(prefix='ytdl-test_XAttrMetadataPP')

# Generated at 2022-06-12 19:25:13.772267
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    # Test with no extended attributes
    if not compat_os_name.startswith('linux'):
        print('INFO: Skipping XAttrMetadataPP unit test in non-Linux OS.')
        return

    from ..jsinterp import JSInterpreter

    def js_to_json(code):
        return JSInterpreter(code).extract_functions()

    pp_input = {
        'title': 'test title',
        'webpage_url': 'test webpage_url',
        'description': 'test description',
        'uploader': 'test uploader',
        'upload_date': 'test upload_date',
        'format': 'test format',
    }

    pp = XAttrMetadataPP(None)

# Generated at 2022-06-12 19:25:15.586682
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP('a')
    assert pp.CHAPTER_ID == 'a'


# Generated at 2022-06-12 19:25:17.609007
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # Both parameters are necessary
    try:
        xattr = XAttrMetadataPP(None)
    except TypeError:
        xattr = XAttrMetadataPP(None,None)


# Generated at 2022-06-12 19:25:58.078335
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP({})

# Generated at 2022-06-12 19:26:06.825637
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .common import FileDownloader
    from .common import PostProcessingError
    from ..compat import compat_os_name

    def _decode(s):
        return s.decode('utf-8')

    info = {
        'webpage_url': 'http://youtu.be/BaW_jenozKc',
        'title': 'Hail to the Victors',
        'description': 'This is the description',
        'upload_date': '20121002',
        'uploader': 'UM Marching Band',
        'format': '22'
    }
    filename = 'test_video.ext'

    if compat_os_name == 'nt':
        expected_error = ('%s does not support extended attributes' % compat_os_name).encode('utf-8')
    else:
        expected_error

# Generated at 2022-06-12 19:26:07.385169
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass



# Generated at 2022-06-12 19:26:13.543009
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..compat import compat_urllib_request

    from .common import FileDownloader
    from .http import HttpFD
    from .http import HEADRequest

    # Set up the test downloader
    downloader = FileDownloader(params=dict(noprogress=True))
    downloader.httpfd = HttpFD(downloader)
    downloader.params['logger'] = None

    # Set up the test file

# Generated at 2022-06-12 19:26:20.548300
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import os
    import subprocess
    import sys
    import tempfile
    import unittest

    class MyYDL(object):

        def __init__(self, output_path, xattr_available, xattr_limit_reached, xattr_quota_exceeded):
            self.to_screen = lambda s: s
            self.report_warning = lambda s: s
            self.report_error = lambda s: s
            self.params = {'outtmpl': output_path}

            self.__xattr_available = xattr_available
            self.__xattr_limit_reached = xattr_limit_reached
            self.__xattr_quota_exceeded = xattr_quota_exceeded

        def get_real_url(self, url):
            return url


# Generated at 2022-06-12 19:26:21.971443
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # TODO
    pass

# Generated at 2022-06-12 19:26:30.580605
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    import unittest
    import sys
    import os
    test = unittest.TestCase()

    def _test_write_xattr(filename, xattrname, value):
        # Unfortunately, python-xattr doesn't allow a generic way to
        # check whether a single xattr exists or not...
        assert False, 'write_xattr() should not be called'

    def _test_report_error(msg):
        assert msg is not None, 'Expected a message'

    def _test_report_warning(msg):
        assert msg is not None, 'Expected a message'

    if sys.version_info < (3, 0):
        from StringIO import StringIO
    else:
        from io import StringIO


# Generated at 2022-06-12 19:26:37.578300
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    class FakeInfo:
        def __init__(self):
            self.info = {
                'webpage_url': 'http://webpage.url',
                'description': 'description',
                'title': 'title',
                'upload_date': 'upload_date',
                'uploader': 'uploader',
                'format': 'format'
            }

        def get(self, key):
            return self.info[key]

        def set(self, key, value):
            self.info[key] = value

    class FakeDownloader:
        def report_error(self, message):
            assert(message == 'This filesystem doesn\'t support extended attributes. (You may have to enable them in your /etc/fstab)')


# Generated at 2022-06-12 19:26:46.341376
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..YoutubeDL import YoutubeDL
    from ..compat import compat_shlex_quote
    from .common import PostProcessorTest
    from ..utils import encodeFilename

    # Test with "normal" filename
    testfilename = 'abcdefghijkl.mp4'
    testfilepath = '/video/' + testfilename

    # Test with unicode filename

# Generated at 2022-06-12 19:26:46.949188
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # object creation
    assert XAttrMetadataPP()

# Generated at 2022-06-12 19:28:15.500350
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    metadata_filename = 'test_XAttrMetadataPP_run.metadata'
    with open(metadata_filename, 'w') as f:
        f.write('[info]\n')
        f.write('webpage_url=https://www.youtube.com/watch?v=v1\n')
        f.write('title=t1\n')
        f.write('upload_date=20181211\n')
        f.write('description=d1\n')
        f.write('uploader=u1\n')
        f.write('format=f1\n')
        f.write('filepath=test_XAttrMetadataPP_run.mp4\n')


# Generated at 2022-06-12 19:28:25.004857
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    try:
        import xattr
    except ImportError:
        print('Before running this test, you must install the "xattr" package. See README.md for more info.')
        return False

    from os import mkdir, remove, rmdir
    from .common import PostProcessorTest
    from ..extractor.youtube import YoutubeIE
    from ..utils import xattr_set

    postprocessor = XAttrMetadataPP()

    # Create a temporary directory to work in, and remove it when done
    tempdir = os.path.join(tempfile.gettempdir(), 'metadata-test-dir')
    if not os.path.exists(tempdir):
        mkdir(tempdir)
    else:
        def remove_tempdir():
            rmdir(tempdir)
        atexit.register(remove_tempdir)

# Generated at 2022-06-12 19:28:25.814254
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass



# Generated at 2022-06-12 19:28:35.422754
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    metadatapp = XAttrMetadataPP(None)


# Generated at 2022-06-12 19:28:36.798855
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    testPP = XAttrMetadataPP('/dummy/file')
    assert(testPP.executable)

# Generated at 2022-06-12 19:28:41.663470
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor import gen_extractors
    from ..postprocessor import PostProcessor
    from ..downloader import FileDownloader

    info = {
        'filepath': 'filename',
        'webpage_url': 'webpage_url',
        'title': 'title',
        'upload_date': 'upload_date',
        'description': 'description',
        'uploader': 'uploader',
        'format': 'format',
    }

    post_processor = XAttrMetadataPP(FileDownloader(gen_extractors()))
    post_processor.run(info)

# Generated at 2022-06-12 19:28:42.764033
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-12 19:28:44.607429
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # No real test possible without xattr support
    pass

# Generated at 2022-06-12 19:28:45.181890
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-12 19:28:49.590832
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    xattmetadatapp = XAttrMetadataPP("")
    if not isinstance(xattmetadatapp, XAttrMetadataPP):
        xattmetadatapp = XAttrMetadataPP("")
    assert isinstance(xattmetadatapp, XAttrMetadataPP)

if __name__ == "__main__":
    test_XAttrMetadataPP()