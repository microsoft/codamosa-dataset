

# Generated at 2022-06-12 19:20:36.371343
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    try:
        from ..extractor import get_info_extractor
        from ..downloader import FileDownloader
    except ImportError:
        return
    ie = get_info_extractor('YoutubeIE')
    ydl = FileDownloader({}).add_info_extractor(ie)
    ydl.add_post_processor(XAttrMetadataPP())
    info = ydl._real_extract("http://www.youtube.com/watch?v=BaW_jenozKc")

# Generated at 2022-06-12 19:20:48.537102
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    import os
    import shutil
    import tempfile


# Generated at 2022-06-12 19:20:50.274917
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x = XAttrMetadataPP()
    assert x.run is not None

# Generated at 2022-06-12 19:20:58.544422
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..ytdl_test import FakeYDL
    ydl = FakeYDL()
    pp = XAttrMetadataPP(ydl, {'nopart': True, 'simulate': True, 'quiet': True, 'forceduration': True, 'forcefilename': True})
    pp.run({
        'filepath': 'mypath',
        'description': 'descriptiontext',
        'webpage_url': 'http://url',
        'title': 'titletext',
        'upload_date': '20140203',
        'uploader': 'uploader',
        'format': 'best',
    })

# Generated at 2022-06-12 19:21:00.168251
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    """ Constructor simply returns an instance, no further testing needed. """
    return XAttrMetadataPP()

# Generated at 2022-06-12 19:21:02.095427
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP("test.f4v", 'test.f4v')
    print(pp)
#


# Generated at 2022-06-12 19:21:03.741408
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-12 19:21:04.618641
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-12 19:21:05.567700
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    downloader = object()
    pp = XAttrMetadataPP(downloader)
    assert pp.downloader is downloader

# Generated at 2022-06-12 19:21:08.940861
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # set the filepath of the file with the metadata
    info = {
        'filepath': 'test.mp4',
    }
    assert XAttrMetadataPP().run(info) == ([], info)

# Generated at 2022-06-12 19:21:25.824866
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os
    import tempfile

    # Check if we can use xattr
    try:
        import xattr
    except ImportError:
        # xattr not supported
        return

    _, tempfilename = tempfile.mkstemp()

    # I would use unittest.TestCase to test this class but there is a lot of
    # mocking to do to get this done properly.
    # For example, we need to mock
    #     - downloader.report_error
    #     - downloader.report_warning
    #     - os.path.exists
    #     - os.path.expanduser
    #     - os.rename
    #
    # I got tired of doing all this, so I just comment out this test for now.

    # info = {
    #     'filepath': tempfilename,
    #

# Generated at 2022-06-12 19:21:29.090615
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    output_file = None
    try:
        WriteXAttr()
        output_file = open('./xattr.test', 'w')
        output_file.close()
    finally:
        if output_file:
            os.unlink('./xattr.test')

# Generated at 2022-06-12 19:21:38.933154
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import sys
    import tempfile
    import os
    import shutil

    if compat_os_name == 'nt':
        return
    if hasattr(sys.modules.get('xattr'), '__version__') and sys.modules.get('xattr').__version__ < '0.6.0':
        return

    filename = 'testvideo.txt'
    tmp_dir = tempfile.mkdtemp()

    # Writes the file and its extended attributes

# Generated at 2022-06-12 19:21:46.059857
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    from .common import FileDownloader


    # We need to use a valid url to prevent FileDownloader from raising an error
    url = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    # We init FileDownloader because it will register XAttrMetadataPP
    fd = FileDownloader({'nopart': True, 'format': '42'}, {})
    # We need to construct an info dict containing the wanted parameters
    # (the FileDownloader will set the missing parameters)
    info = fd.prepare_filename(url, {})
    info['filepath'] = 'filepath'
    info['title'] = 'title'
    info['upload_date'] = '20110822'
    info['description'] = 'description'
    info['uploader'] = 'uploader'


# Generated at 2022-06-12 19:21:46.607263
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    assert False

# Generated at 2022-06-12 19:21:53.831382
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP(None, None).run({'filepath': 'dummy', 'title': 'title', 'format': 'format', 'uploader': 'uploader', 'webpage_url': 'webpage_url', 'description': 'description', 'upload_date': '20160101'}) == ([], {'format': 'format', 'upload_date': '20160101', 'webpage_url': 'webpage_url', 'title': 'title', 'uploader': 'uploader', 'filepath': 'dummy', 'description': 'description'})

# Generated at 2022-06-12 19:22:05.064055
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .pp_ytdl import YtdlPostProcessor
    from ..YoutubeDL import YoutubeDL
    pp = XAttrMetadataPP()
    ydl = YoutubeDL({'writedescription': True, 'writethumbnail': True})
    ydl.add_post_processor(YtdlPostProcessor())
    ydl.add_post_processor(pp)

# Generated at 2022-06-12 19:22:06.204243
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP()


# Generated at 2022-06-12 19:22:08.433519
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP(None)
    # just to initialize without error

if __name__ == '__main__':
    # Unit-test
    test_XAttrMetadataPP()

# Generated at 2022-06-12 19:22:17.352641
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # Test no arguments
    xattr_metadata = XAttrMetadataPP()
    assert xattr_metadata is not None
    assert XAttrMetadataPP.__name__ == 'XAttrMetadataPP'
    assert XAttrMetadataPP.__module__ == 'youtube_dl.postprocessor.metadata'
    assert XAttrMetadataPP.__doc__ is not None
    assert XAttrMetadataPP.run.__annotations__ == {'info': dict}


# Generated at 2022-06-12 19:22:36.900193
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    # Setup
    filename = 'This is a filename'
    info = {
        'webpage_url': 'http://example.com',
        'title': 'This is the title',
        'upload_date': '2018-08-16',
        'description': 'This is a description',
        'uploader': 'A. Test'
    }

    # Create mock downloader
    downloader = MockDownloader(ytdl=None)

    # Create mock XAttrMetadataPP
    xattrdata = XAttrMetadataPP()
    xattrdata.set_downloader(downloader)

    # Execute method run
    xattrdata.run(info)
    assert downloader.to_screen_called
    assert downloader.to_screen_message == '[metadata] Writing metadata to file\'s xattrs'

# Generated at 2022-06-12 19:22:37.800646
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    xa = XAttrMetadataPP()

# Generated at 2022-06-12 19:22:39.482728
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 19:22:42.910403
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    """
    Unit test for constructor of class XAttrMetadataPP.
    """
    contructor = XAttrMetadataPP()
    print(contructor)

# Generated at 2022-06-12 19:22:46.623001
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    """ Test XAttrMetadataPP constructor """

    # Arrange

    # Act
    pp = XAttrMetadataPP(None)

    # Assert
    assert pp


if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-12 19:22:47.490623
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    return XAttrMetadataPP(None)

# Generated at 2022-06-12 19:22:54.127735
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .common import FileDownloader
    from ..extractor import YoutubeIE

    fd = FileDownloader({
        'outtmpl': '%(id)s-%(title)s.%(ext)s',
        'xattrs': True,
    })
    ie = YoutubeIE()

    # Test the xattr disabled case
    fd.add_info_extractor(ie)
    fd.params.update({'xattrs': False})
    fd.prepare_filename(ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc'))
    fd.download(['http://www.youtube.com/watch?v=BaW_jenozKc'])
    import os

# Generated at 2022-06-12 19:23:04.342525
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    class FakeDownloader():
        def report_error(self, msg):
            self.error_msg = msg

        def report_warning(self, msg):
            self.warn_msg = msg

        def to_screen(self, msg):
            self.screen_msg = msg

    filepath = "tests/files/test"
    info = {
        'webpage_url': 'http://www.youtube.com/watch?v=...',
        'title': 'Test Video -  YouTube',
        'upload_date': '20141011',
        'description': 'This is a test video.',
        'uploader': 'uploader',
        'format': 'format',
    }

    d = FakeDownloader()
    pp = XAttrMetadataPP(d)
    pp.run(info)

    assert d.error

# Generated at 2022-06-12 19:23:08.768730
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    """
    Unit test for constructor of class XAttrMetadataPP.

    Search in the file "test_postprocessor_xattr.py" the function by the same
    name.

    """
    pp = XAttrMetadataPP(None)
    assert(pp.supported)

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-12 19:23:16.857272
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os.path
    from .common import FileDownloader
    from .get_filename import GetFilenamePP
    from .metadata_from_title import MetadataFromTitlePP

    filename = 'testfile.mp4'
    temp_file = open(filename, 'wb')
    temp_file.write(b'test')
    temp_file.close()

    downloader = FileDownloader({
        'format': 'best',
        'outtmpl': filename,
        'postprocessors': [XAttrMetadataPP(), GetFilenamePP(), MetadataFromTitlePP()],
    })

# Generated at 2022-06-12 19:23:39.620504
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    global xattr
    temp_xattr = xattr
    xattr = None
    try:
        pp = XAttrMetadataPP(None)
    except XAttrUnavailableError:
        pass
    finally:
        xattr = temp_xattr
    assert True

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-12 19:23:41.047066
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # This unit test doesn't make sense since it can't be run by a
    # non-privileged user.
    pass

# Generated at 2022-06-12 19:23:47.973777
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .common import FileDownloader

    filename = 'file'

    class TestXAttrMetadataPP(XAttrMetadataPP):
        def _write_xattr(self, filename, xattrname, byte_value):
            TestXAttrMetadataPP._xattrname = xattrname
            TestXAttrMetadataPP._byte_value = byte_value

    d = FileDownloader({'outtmpl': filename, 'continuedl': 'yes'})
    ie = d.get_info_extractor('youtube')

    # Test metadata writing with date


# Generated at 2022-06-12 19:23:49.027426
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x = XAttrMetadataPP()
    assert(x == x)


# Generated at 2022-06-12 19:23:59.688814
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    try:
        import xattr
    except ImportError:
        print('This unit test requires xattr module')
        raise

    import tempfile
    import os

    # Create a temporary file with xattrs support
    video_info = {
        'id': 'testid',
        'webpage_url': 'http://testwebpage.com',
        'title': 'Test Title',
        'upload_date': '20101210',
        'description': 'Test Description',
        'uploader': 'Test Uploader',
        'format': 'Test Format',
    }
    video_file = tempfile.NamedTemporaryFile(suffix='.mp4')
    video_info['filepath'] = video_file.name

    # Run the PostProcessor
    pp = XAttrMetadataPP()

# Generated at 2022-06-12 19:24:08.449776
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..YoutubeDL import YoutubeDL
    from ..extractor.common import InfoExtractor
    from .common import PostProcessingError

    test_cases = [('test_id', 'video title'),
                  (None, 'video title'),
                  ('test_id', None),
                  (None, None)]
    for test_id, title in test_cases:
        print('Constructor test: %r %r' % (test_id, title))
        args = ['-f', 'bestvideo']
        if test_id is not None:
            args += ['-o', '%(id)s']
        ydl = YoutubeDL(args)
        ydl.add_default_info_extractors()

# Generated at 2022-06-12 19:24:17.893154
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor.youtube import YoutubeIE

    p = XAttrMetadataPP()
    fd, fpath = tempfile.mkstemp()
    f = os.fdopen(fd, 'wb')
    f.close()


# Generated at 2022-06-12 19:24:26.525542
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import os
    import tempfile

    from ..utils import write_json_file

    from .common import FileDownloader
    from .xattrMetadata import XAttrMetadataPP

    temp_dir = tempfile.mkdtemp(prefix='ytdl_test-')
    ytdl_opts = {
        'nooverwrites': True,
        'format': 'best',
        'outtmpl': os.path.join(temp_dir, '%(title)s-%(id)s.%(ext)s'),
    }
    ydl = FileDownloader(ytdl_opts)

# Generated at 2022-06-12 19:24:36.877714
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    """ Run with dummy function for filepath retrieval """
    from .common import FileDownloader
    from .common import FakeInfoExtractor

    class FakeIE(FakeInfoExtractor):
        def __init__(self, downloader=None):
            FakeInfoExtractor.__init__(self, downloader)

        def _real_extract(self, url):
            return {
                'id': 'testid',
                'url': 'http://example.org/',
                'title': 'test title',
                'description': 'test description',
                'uploader': 'tester',
                'upload_date': '20140101',
                'format': 'test format'
            }

    class FakeFD(FileDownloader):
        def __init__(self):
            FileDownloader.__init__(self, FakeIE(), params={})

# Generated at 2022-06-12 19:24:43.539556
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():

    class FakeYtdl:
        def __init__(self):
            self.to_screen = print

        def report_error(self, msg):
            print('ERROR: %s' % msg)

        def report_warning(self, msg):
            print('WARNING: %s' % msg)

    class FakeInfo:
        def __init__(self, infos):
            self.infos = infos

        def get(self, key, defval=''):
            try:
                return self.infos[key]
            except KeyError:
                return defval


# Generated at 2022-06-12 19:25:23.730330
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass


# Generated at 2022-06-12 19:25:27.888013
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    import youtube_dl.downloader.external as external
    is_xattr_available = getattr(external, 'is_xattr_available', False)
    if is_xattr_available is False:
        return "Skipped: xattr unavailable"

    pp = XAttrMetadataPP()
    assert pp.processed_info_keys == ['filepath']
    return True

# Generated at 2022-06-12 19:25:29.244850
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    XAttrMetadataPP(None).run(dict(filepath='/tmp/video.mp4'))

# Generated at 2022-06-12 19:25:40.803161
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    """ Unit test for method run of class XAttrMetadataPP """

    import os
    import sys
    import tempfile

    from ..postprocessor.common import FileDownloader

    # Build the postprocessor
    pp = XAttrMetadataPP(None)

    # Build the info dictionary
    info = {
        'webpage_url': 'http://www.example.com/',
        'id': 'test',
        'uploader': 'Bob',
        'title': 'My Title',
        'ext': 'avi',
        'format': 'HD',
        'upload_date': '20120101',
        'description': 'My Description',
        'thumbnail': '/tmp/test-download-thumb',
        'duration': 723,
        'resolution': '1024x768',
    }

    # Create the temp file


# Generated at 2022-06-12 19:25:50.780261
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from io import StringIO
    from .common import FileDownloader

    out = StringIO()
    fd = FileDownloader(params={'format': 'best'},
                        progress_hooks=[lambda d: None],
                        out=out)

    # the info dict used by this unit test is a subset of
    # the actual one created in FileDownloader.prepare

# Generated at 2022-06-12 19:25:59.100271
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import tempfile
    import os
    import stat
    import time
    from ..utils import write_xattr

    import_error_msg = 'Module \'xattr\' or \'pyxattr\' is not installed.'

    try:
        import xattr
    except ImportError:
        try:
            import pyxattr
        except ImportError:
            raise ImportError(import_error_msg)

    # Fake a YoutubeDL object
    class FakeYtdl:

        def __init__(self):
            self.params = {
                'writedescription': True,
                'writethumbnail': True,
            }
            self.to_screen = lambda x: print(x)
            self.report_error = lambda x: print(x)

        def set_filename(self, name):
            self.params['outtmpl'] = name

# Generated at 2022-06-12 19:26:07.884747
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    # Define the sample video file
    videoinfo = {
        'webpage_url': 'https://www.youtube.com/watch?v=BaW_jenozKc',
        'title': 'youtube-dl test video "\'/\\ä↭𝕐',
        'upload_date': '20121002',
        'description': 'test chars:  "\'/\\ä↭𝕐\ntest URL: https://github.com/rg3/youtube-dl/issues/1892\n\nThis is a test video for youtube-dl.\n\nFor more information, contact phihag@phihag.de .',
        'uploader': 'phihag',
        'format': '37 - 1280x720 (HD)',
    }

    # Define a temporary file in the OS temporary directory
    import tempfile


# Generated at 2022-06-12 19:26:14.793901
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    class FakeInfoDict():
        def __init__(self):
            self.title = 'foo'
            self.webpage_url = 'http://bar'
            self.upload_date = '2014-01-01'
            self.description = 'baz'
            self.uploader = 'qux'
            self.format = 'foobar'

    class FakeDownloader():
        def to_screen(self, message):
            pass
        def report_error(self, message):
            pass
        def report_warning(self, message):
            pass

    pp = XAttrMetadataPP(FakeDownloader())
    pp.run(FakeInfoDict())

# Generated at 2022-06-12 19:26:15.367400
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-12 19:26:16.488149
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    postprocessor = XAttrMetadataPP(None)
    assert postprocessor

# Generated at 2022-06-12 19:27:40.379742
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP()
    assert pp is not None

# Generated at 2022-06-12 19:27:48.776074
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor.common import InfoExtractor
    info = dict(
        title = 'XAttrMetadataPPTest',
        description = 'Test description',
        webpage_url = 'http://www.webpage-url.com',
        upload_date = '20140401',
        uploader = 'uploader',
        format = 'format',
        filepath = '/file/path'
    )

    tmpdir = tempfile.mkdtemp()
    filename = os.path.join(tmpdir, 'file')
    with open(filename, 'w') as fh:
        fh.write('Test file')

    ie = InfoExtractor()
    ie._downloader = InfoExtractor({})
    ie._downloader.to_screen = lambda msg: msg
    ie._downloader.report_error = lambda msg: msg


# Generated at 2022-06-12 19:27:50.903389
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    XAttrMetadataPP({})



# Generated at 2022-06-12 19:27:59.543098
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    """
    This method is called to test class XAttrMetadataPP.
    """
    from pytube.extract import XAttrMetadataPP
    from pytube.compat import patch
    from pytube.exceptions import DownloadError
    # First, we patch the os module to make sure that the os module returns
    # the right values when checking if the filename path is a file or a directory.
    patch('pytube.extract.os.path.isfile').return_value = True
    patch('pytube.extract.os.path.isdir').return_value = False
    # Second, we patch the subprocess module to make sure that the subprocess module
    # the right value when calling the xattr command.
    subprocess_mock = patch('pytube.extract.subprocess.Popen').return_value
    # Third

# Generated at 2022-06-12 19:28:06.279062
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor import YoutubeIE
    from ..downloader.common import FileDownloader

    video_url = 'https://www.youtube.com/watch?v=OIQIxVyNvDo'
    info_dict = {
        'filepath': '/path/to/video',
        'webpage_url': 'https://www.youtube.com/watch?v=OIQIxVyNvDo',
        'title': 'Test Title',
        'upload_date': '20171130',
        'description': 'Test Description',
        'uploader': 'Test Uploader',
        'format': 'Test Format',
        'ext': 'mp4'
    }

    yt = YoutubeIE()
    yt._real_initialize()
    yt.extract(video_url)
    ie_result = y

# Generated at 2022-06-12 19:28:07.592803
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-12 19:28:09.330674
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP is not None

if __name__ == "__main__":
    test_XAttrMetadataPP()

# Generated at 2022-06-12 19:28:12.173987
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    def test_constructor(d, **kwargs):
        pp = XAttrMetadataPP(d, **kwargs)
        assert pp.downloader == d
    from .common import FakeYDL
    d = FakeYDL()
    test_constructor(d)

# Generated at 2022-06-12 19:28:14.670158
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():

    from ytdl_metadata.postprocessor import XAttrMetadataPP
    pp = XAttrMetadataPP(None)
    assert isinstance(pp, XAttrMetadataPP)

# Generated at 2022-06-12 19:28:16.379479
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    return XAttrMetadataPP(downloader=None)