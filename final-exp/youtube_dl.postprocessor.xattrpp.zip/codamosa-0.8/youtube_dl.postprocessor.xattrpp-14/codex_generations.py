

# Generated at 2022-06-12 19:20:38.281590
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .testutils import FakeYDL
    from .testutils import _TEST_FILE

    def _test_run(test_item):
        ydl = FakeYDL()
        pp = XAttrMetadataPP()

        out_filename = 'single_output.mp4'
        ydl.prepare_filename = lambda filename: out_filename
        ydl.params['outtmpl'] = '%(id)s'
        ydl.params['writedescription'] = True

        try:
            pp.run(test_item)
            assert False
        except XAttrMetadataError as e:
            if e.reason == 'NO_SPACE':
                assert False
            elif e.reason == 'VALUE_TOO_LONG':
                assert False
            else:
                assert True
    test_item = _T

# Generated at 2022-06-12 19:20:50.060927
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import sys
    import os
    import tempfile
    import shutil
    import unittest

    sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

    from ydl.extractor import get_info_extractor

    # Fake downloader
    class FakeDownloader:
        def to_screen(self, msg):
            pass

        def report_error(self, msg):
            pass

        def report_warning(self, msg):
            pass

    # Test PP class
    class TestXAttrMetadataPP(XAttrMetadataPP):

        def __init__(self, downloader):
            self._downloader = downloader

    # Fake info dict

# Generated at 2022-06-12 19:20:52.411419
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    #
    # Constructor
    #

    # No parameters
    pp = XAttrMetadataPP()

    assert pp.filepath == None

# Generated at 2022-06-12 19:21:02.478286
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os.path
    import tempfile
    import xattr

    # create file
    f = tempfile.NamedTemporaryFile()
    f.close()

    # create PostProcessor instance
    xattr_metadata = XAttrMetadataPP()

    # fake 'info' dict
    info = {
            'filepath': f.name,
            'webpage_url': 'http://example.com/',
            'title': 'my title',
            'upload_date': '20160506',
            'description': 'my description',
            'uploader': 'uploader1',
            'format': 'format1',
            }

    # run method under test
    xattr_metadata.run(info)

    # asserts
    assert os.path.isfile(f.name)

# Generated at 2022-06-12 19:21:13.413666
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..downloader import Downloader
    from ..extractor import gen_extractors
    from ..utils import prepare_filename
    from .common import FileDownloader
    
    class FakeInfoExtractor(object):
        
        IE_NAME = 'fake'

        def __init__(self, downloader):
            self._downloader = downloader

    class FakeInfo(dict):

        def __init__(self):
            dict.__init__(self)
            self['url'] = 'http://www.youtube.com/watch?v=BaW_jenozKc'
            self['extractor_key'] = 'Youtube'
            self['extractor'] = 'Youtube'
            self['webpage_url'] = 'http://www.youtube.com/watch?v=BaW_jenozKc'

# Generated at 2022-06-12 19:21:17.187459
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    """Test for XAttrMetadataPP constructor."""
    pp = XAttrMetadataPP('XAttrMetadataPP', None)
    assert pp is not None

# Generated at 2022-06-12 19:21:28.866030
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os.path
    import tempfile
    from collections import OrderedDict
    from .common import FileDownloader

    # Test setup
    xattr_mapping = OrderedDict([
        ('user.xdg.referrer.url', 'webpage_url'),
        ('user.xdg.comment', 'description'),
        ('user.dublincore.title', 'title'),
        ('user.dublincore.date', 'upload_date'),
        ('user.dublincore.description', 'description'),
        ('user.dublincore.contributor', 'uploader'),
        ('user.dublincore.format', 'format'),
    ])

# Generated at 2022-06-12 19:21:38.761388
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import sys
    import unittest

    sys.path.insert(0, '..')  # set path to youtube_dl module

    class XAttrMetadataPP_runTest(unittest.TestCase):
        def setUp(self):
            self.info = { 'filepath': '/tmp/test',
                          'title': 'Title of the video',
                          'upload_date': '20140101',
                          'uploader': 'Uploader name',
                          'description': 'Video description',
                          'webpage_url': 'http://example.com',
                          'format': 'format'
                }

        def tearDown(self):
            pass


# Generated at 2022-06-12 19:21:45.951767
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import tempfile
    from .common import FileDownloader
    from .external import ExternalFD
    from ..compat import compat_os_name, compat_setenv
    from ..utils import (
        XAttrUnavailableError,
        get_xattr,
        has_xattr,
        remove_xattr,
        set_xattr,
    )

    assert compat_os_name != 'nt', "Tests don't work on Windows"

    #
    # We're testing this part of XAttrMetadataPP.run():
    #
    #         self._downloader.to_screen('[metadata] Writing metadata to file\'s xattrs')
    #
    #         filename = info['filepath']
    #
    #         try:
    #             xattr_mapping = {
    #                 'user.xdg

# Generated at 2022-06-12 19:21:57.076454
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})
    # Make sure all fields except for xattrs is set
    info = {
        'filepath': 'test_file',
        'webpage_url': 'test_url',
        # 'description': 'test_description',
        'title': 'test_title',
        'upload_date': 'test_date',
        'description': 'test_description',
        'uploader': 'test_uploader',
        'format': 'test_format',
        'thumbnail': 'test_thumb',
        'duration': 99,
        'resolution': '1280x720'
    }
    xattr_pp = XAttrMetadataPP(ydl)
    xattr_pp.run(info)

# Generated at 2022-06-12 19:22:03.182580
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-12 19:22:03.661064
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    xat

# Generated at 2022-06-12 19:22:05.895041
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert issubclass(XAttrMetadataPP, PostProcessor)
    ydl = MockYDL()
    pp = XAttrMetadataPP(ydl)
    assert pp.ydl is ydl

# Generated at 2022-06-12 19:22:07.418793
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 19:22:19.691747
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    headers = {'referrer': 'http://www.yammer.com/cp/videos/video-136933.html'}
    info = {
        'title': 'The New Yammer',
        'webpage_url': 'http://www.yammer.com/cp/videos/video-136933.html',
        'upload_date': '20120110',
        'format': '22 - 1280x720 (youtube)',
        'uploader': 'Krispin S. Creasey',
        'description': 'Yammer is a private, secure enterprise social network.',
        '_filename': 'The New Yammer.mp4',
        '_headers': headers,
    }
    pp = XAttrMetadataPP(None)
    pp.run(info)

# Generated at 2022-06-12 19:22:24.054430
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from sys import maxsize

    pp = XAttrMetadataPP(None)
    assert isinstance(pp, PostProcessor)
    assert pp.run({"filepath": "dummy.mp4"}) == ([], {"filepath": "dummy.mp4"})

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-12 19:22:26.408433
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP(None)

# Generated at 2022-06-12 19:22:35.929165
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # without warning
    XAttrMetadataPP()

    # with warning
    # write_xattr = Mock()
    # write_xattr.side_effect = XAttrMetadataError(item_name='filepath', reason='NO_SPACE')
    # logger.warning = Mock()
    # XAttrMetadataPP(write_xattr=write_xattr)
    # logger.warning.assert_called()

    # with error
    # write_xattr = Mock()
    # write_xattr.side_effect = XAttrUnavailableError(item_name='filepath', reason='NO_SPACE')
    # logger.error = Mock()
    # XAttrMetadataPP(write_xattr=write_xattr)
    # logger.error.assert_called()

# Generated at 2022-06-12 19:22:37.800874
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP(None).run({'filepath': 'blah.mp3'})

# Generated at 2022-06-12 19:22:46.223684
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ytdl.postprocessor.ffmpeg import FFmpegFixupPP
    from . import YoutubeDL
    ydl = YoutubeDL({
        'extract-audio': True,
        'audio-format': 'm4a',
        'embed-thumbnail': True,
    })
    ydl.params['writethumbnail'] = True
    ydl.add_post_processor(FFmpegFixupPP())
    ydl.add_post_processor(XAttrMetadataPP())
    ydl.download(['https://www.youtube.com/watch?v=BaW_jenozKc'])

# Generated at 2022-06-12 19:23:05.625059
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    '''
    Test if the XAttrMetadataPP postprocessor works as intended.
    Requires a filesystem that supports xattrs.
    '''
    import os.path
    import tempfile
    from ytdl.YoutubeDL import YoutubeDL
    from .test_helpers import TestDownloadYoutubeDL, TestFileDownloader


# Generated at 2022-06-12 19:23:14.625705
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    success = True

# Generated at 2022-06-12 19:23:20.237858
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    """Unit test for method run of class XAttrMetadataPP."""
    
    import os
    import shutil
    import tempfile
    import unittest
    
    from ydl.downloader.common import FileDownloader
    from ydl.postprocessor.metadata import XAttrMetadataPP
    from ydl.utils import XAttrUnavailableError, XAttrMetadataError
    
    from .common import FakeFileDownloader, FakeInfoExtractor
    
    # We don't use the real FileDownloader because some of its methods
    # (report_*()) raise a SystemExit exception
    class FakeXAttrFileDownloader(FakeFileDownloader):
        def report_warning(self, msg):
            pass
        def report_error(self, msg):
            pass
    

# Generated at 2022-06-12 19:23:21.711611
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP()
    return True

# Generated at 2022-06-12 19:23:31.806906
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    """
    Test for XAttrMetadataPP class, method run.
    """
    import pytest, os
    from ..utils import xattr_ok
    from ..extractor import gen_extractors

    if not xattr_ok():
        pytest.skip('xattr unavailable')

    test_cases = [
        # test_case[0] - Extractor name
        # test_case[1] - Url
        # test_case[2] - Expected result

        ['Generic', 'https://www.youtube.com/watch?v=rP7Kj8tY27E', True],

    ]


# Generated at 2022-06-12 19:23:39.723212
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    xattr_mapping = {
        'user.xdg.referrer.url': 'webpage_url',
        # 'user.xdg.comment':            'description',
        'user.dublincore.title': 'title',
        'user.dublincore.date': 'upload_date',
        'user.dublincore.description': 'description',
        'user.dublincore.contributor': 'uploader',
        'user.dublincore.format': 'format',
        }
    test_dict = {}
    for infoname, value in xattr_mapping.items():
        test_dict[infoname] = value
    test_dict['filepath'] = '/fake/path/of/file'


# Generated at 2022-06-12 19:23:40.514624
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pass

# Generated at 2022-06-12 19:23:47.600359
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import encoding

    class MockInfo(dict):
        def __init__(self, **kwargs):
            super(MockInfo, self).__init__()
            self.update(kwargs)

    class MockLogger(object):
        def __init__(self):
            self.to_screen_str = ''

        def to_screen(self, text):
            assert isinstance(text, str)
            self.to_screen_str += text
            self.to_screen_str += '\n'

        def report_warning(self, msg):
            assert isinstance(msg, str)
            self.to_screen_str += '[warn] '
            self.to_screen_str += msg
            self.to_screen_str += '\n'


# Generated at 2022-06-12 19:23:49.315989
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    a = XAttrMetadataPP('a', 'b')
    return a

# Generated at 2022-06-12 19:23:49.768298
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-12 19:24:21.911916
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    test_filename = 'test_file.mp4'

    # Delete test extended attributes

# Generated at 2022-06-12 19:24:23.228606
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    """ Run class constructor test. """
    XAttrMetadataPP({})

# Generated at 2022-06-12 19:24:33.643544
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from tempfile import NamedTemporaryFile
    from os import unlink, utime
    from time import time
    import logging
    logging.basicConfig(level=logging.DEBUG)
    if 1:
        # Create temporary file
        f = NamedTemporaryFile(mode='w', delete=False)
        f.close()

        # Make it looks like a video file
        utime(f.name, (time(), time()))

        # Run class method run
        info = {
            'filepath': f.name,
            'webpage_url': 'http://test.url',
            'title': 'test title',
            'upload_date': '20170101',
            'description': 'test description',
            'uploader': 'test uploader',
            'format': 'test format',
        }

        XAttrMetadata

# Generated at 2022-06-12 19:24:42.055182
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import os
    import tempfile

    filename = os.path.join(tempfile.mkdtemp(), 'test.mp3')
    with open(filename, 'wb') as outf:
        outf.write(b'test')

    pp = XAttrMetadataPP(None)
    pp.run({
        'filepath': filename,
        'title': 'Test',
        'webpage_url': 'http://example.com',
        'description': 'This is a test',
        'uploader': 'Somebody',
        'upload_date': '20160101',
        'format': 'mp3',
    })

    assert(b'Test' == read_xattr(filename, 'user.dublincore.title'))

# Generated at 2022-06-12 19:24:50.487862
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    filename = 'tests/files/testvideo.mp4'
    downloader = 'tests/files/downloader.log'

    info = {
        'filepath': filename,
        'webpage_url': 'http://www.example.com/videopage.html',
        'title': 'Test video title',
        'upload_date': '20131127',
        'description': 'This is a test video',
        'uploader': 'Test User',
        'format': 'mp4',
    }

    xattr_postprocessor = XAttrMetadataPP(downloader)
    xattr_postprocessor.run(info)

    assert True

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-12 19:24:52.084149
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    XAttrMetadataPP(None)


# Generated at 2022-06-12 19:24:53.738682
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .test_postprocessor import _test_run
    return _test_run(XAttrMetadataPP)

# Generated at 2022-06-12 19:25:02.396034
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .common import FileDownloader

    import os.path
    import tempfile


# Generated at 2022-06-12 19:25:02.945186
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-12 19:25:03.746260
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    XAttrMetadataPP(None)

# Generated at 2022-06-12 19:25:54.209958
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    print('Testing PostProcessor XAttrMetadataPP with None as infos')
    pp = XAttrMetadataPP()
    if pp.run(None) is not None:
        print('ERROR: returns not None')
        return

    print('Testing PostProcessor XAttrMetadataPP with infos that hasn\'t "filepath"')
    pp = XAttrMetadataPP()
    if pp.run({'other': None}) is not None:
        print('ERROR: returns not None')
        return

    print('Testing PostProcessor XAttrMetadataPP with infos that has "filepath"')
    pp = XAttrMetadataPP()
    if pp.run({'filepath': '/tmp/test'}) is not None:
        print('ERROR: returns not None')
        return


# Generated at 2022-06-12 19:26:01.358182
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # Initialization
    out = []
    def to_screen(message):
        out.append(message)
    def report_error(msg):
        out.append('ERROR: ' + msg)
    def report_warning(msg):
        out.append('WARNING: ' + msg)

    # Test error report on XAttrUnavailableError (unsupported filesystem)
    info = {}
    xattr_unavailable_error = XAttrUnavailableError('Test error')
    def write_xattr(filename, attrname, value):
        # pylint: disable=unused-argument
        if not isinstance(value, bytes):
            raise xattr_unavailable_error
    pp = XAttrMetadataPP({})

# Generated at 2022-06-12 19:26:09.593732
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import DateRange

    from .common import FileDownloader
    from .http import HttpFD

    from .cache import Cache
    from .external import ExternalFD
    from .ffmpeg import FFmpegPostProcessor
    from .postprocessor import PostProcessor
    from .xattrtomd import XAttrToMdPP
    from .xattrfromtitle import XAttrFromTitlePP

    import os
    import shutil
    import tempfile
    import unittest

    # Silence error output of HttpFD
    class SilentHttpFD(HttpFD):
        def to_screen(self, s, skip_eol=False):
            pass
        def to_stderr(self, s):
            pass

    # Helper method

# Generated at 2022-06-12 19:26:17.658058
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # create a instance of Downloader
    downloader = object()

    # create a instance of PostProcessor
    pp = XAttrMetadataPP(downloader)

    # test with empty info
    result1 = pp.run({})
    assert result1 == ([], {}), 'test_XAttrMetadataPP_run1 failed!'

    # test with `filepath` of info is None
    info = {
        'filepath': None,
    }
    result2 = pp.run(info)
    assert result2 == ([], info), 'test_XAttrMetadataPP_run2 failed!'

    # test with `filepath` of info is empty
    info.update({
        'filepath': '',
    })
    result3 = pp.run(info)

# Generated at 2022-06-12 19:26:19.761019
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass


# vim:sw=4:ts=4:et:

# Generated at 2022-06-12 19:26:21.580540
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # TODO: implement test case
    return


# Generated at 2022-06-12 19:26:23.448929
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-12 19:26:24.737817
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # This is just a constructor test
    XAttrMetadataPP(None)

# Generated at 2022-06-12 19:26:32.864034
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..downloader import Downloader
    from ..utils import encodeFilename

    # Test 1: test the case where extended attributes are not supported
    info = {
        'webpage_url': 'https://www.youtube.com/watch?v=aBQWejOegQM',
        'title': 'Example title',
        'upload_date': '20181012',
        'description': 'Example description',
        'uploader': 'Example uploader',
        'format': 'mp3',
    }
    xattrdl = postprocessor.XAttrMetadataPP(Downloader())

    # The filename doesn't matter
    filename = 'example.mp3'
    xattrdl.run(info)

# Generated at 2022-06-12 19:26:40.185536
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    pp = XAttrMetadataPP(None)

    info = {
        'filepath': 'file.mkv',
        'format': '720p',
        'title': 'Title',
        'webpage_url': 'http://youtube.com/watch?v=12345678901',
        'uploader': 'Author',
        'upload_date': '20140101',
        'description': 'Description'
    }

    assert pp.run(info) == ([], info)


if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-12 19:28:14.424682
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from .f4m import F4mPP
    from .ism import IsmppDownloadPP
    from .m3u8 import M3u8PP
    from .f4f import F4fPP
    from .hls import HlsPP
    from .dash import DashPP

    assert XAttrMetadataPP.suitable(f4m_only_info) is True
    assert XAttrMetadataPP.suitable(f4m_dash_info) is True
    assert XAttrMetadataPP.suitable(m3u8_only_info) is True
    assert XAttrMetadataPP.suitable(dash_only_info) is True
    assert XAttrMetadataPP.suitable(dash_seg_only_info) is True


# Generated at 2022-06-12 19:28:16.846991
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP(None)
    assert pp.name == 'xattrs'


# Generated at 2022-06-12 19:28:20.511982
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    '''
    Test constructor of class XAttrMetadataPP
    '''
    test_XAttrMetadataPP = XAttrMetadataPP('test_downloader', dict())
    assert test_XAttrMetadataPP is not None


# Generated at 2022-06-12 19:28:23.972223
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    import os
    import sys
    import unittest

    class XAttrMetadataPPUnit(unittest.TestCase):

        def setUp(self):
            self.temp_file = 'xattr_test.file'
            open(self.temp_file, 'w').close()

        def tearDown(self):
            os.remove(self.temp_file)

        @unittest.skipUnless(
            compat_os_name == 'posix' and sys.platform != 'darwin', 'xattr is not supported on this platform')
        def test_init(self):
            from ..downloader import Downloader
            from ..postprocessor import PostProcessor
            from ..utils import XAttrMetadataError
            from .common import PostProcessorError

            class FakeInfo:
                pass
            info = FakeInfo()

           

# Generated at 2022-06-12 19:28:30.877754
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import tempfile

    # TODO use mock objects
    class MockYDL:
        def __init__(self):
            self.screen_output = []

        def to_screen(self, msg):
            self.screen_output.append(msg)

        def report_error(self, msg):
            self.screen_output.append(msg)

        def report_warning(self, msg):
            self.screen_output.append(msg)

    # Mock 'info'
    class MockInfo:
        def __init__(self):
            self.filepath = tempfile.mkstemp()[1]
            self.webpage_url = 'webpage_url'
            self.description = 'description'
            self.title = 'title'
            self.upload_date = 'upload_date'

# Generated at 2022-06-12 19:28:32.460376
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # Test constructor of class XAttrMetadataPP
    pp = XAttrMetadataPP()
    if not pp:
        assert False, 'Failed to construct XAttrMetadataPP'

# Generated at 2022-06-12 19:28:36.727300
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # TODO: finish this unit test
    ydl_opts = {
        'writeinfojson': False,
        'writedescription': True,
    }
    ydl = FakeYDL()
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(FakeIE())
    pp = XAttrMetadataPP(ydl)
    result = pp.run({})
    print(result)

# Generated at 2022-06-12 19:28:40.355728
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    xattrPP = XAttrMetadataPP(None)
    assert xattrPP.last_download == None


if __name__ == '__main__':
    testObject = XAttrMetadataPP(None)

    print("[xattrMetadataPP] objeto criado")

    test_XAttrMetadataPP()

    print("[xattrMetadataPP] testes realizados")

# Generated at 2022-06-12 19:28:43.337723
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..downloader import YoutubeDL
    from ..utils import DateRange


# Generated at 2022-06-12 19:28:45.462504
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x = XAttrMetadataPP({})
    assert x.downloader is None