

# Generated at 2022-06-12 19:20:38.422972
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    #
    # Sample test to see functionality of method run.
    # This is not a full test, unless you have write permissions on current folder.
    #
    import tempfile
    from ..utils import encodeFilename
    from ..YoutubeDL import YoutubeDL

# Generated at 2022-06-12 19:20:42.922955
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pass


if __name__ == "__main__":
    import sys
    import doctest
    doctest.testmod(sys.modules[__name__])

    # if you want to run all available tests
    # import unittest
    # unittest.main()

# Generated at 2022-06-12 19:20:45.504471
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    DummyYtdl().download(['http://www.youtube.com/watch?v=BaW_jenozKc'])


# Generated at 2022-06-12 19:20:55.570205
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from .ytdl_dict import Dict

    info = Dict({
        'filepath': 'spam.mp4',
        'webpage_url': 'https://www.spam.egg/watch?v=spam',
        'title': 'A Spam Video',
        'upload_date': '2030-01-01',
        'description': 'Spam, more spam, even more spam ...',
        'uploader': 'Spammy Spamsson',
        'format': 'Foo Format',
    })
    pp = XAttrMetadataPP(None)

    # This will throw an XAttrMetadataError.
    # Catch it, so we can test the rest of the method.
    try:
        pp.run(info)
    except XAttrMetadataError:
        pass



# Generated at 2022-06-12 19:20:56.599747
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-12 19:20:58.131426
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP()
    # TODO: test pp

# Generated at 2022-06-12 19:21:02.771563
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    # This test is not executed if xattr support is not enabled
    from .common import XAttrMetadataPP_available

    if not XAttrMetadataPP_available:
        return

    from .common import get_test_cases
    for t in get_test_cases():
        postprocessor = XAttrMetadataPP()
        postprocessor.run(t['info'])



# Generated at 2022-06-12 19:21:13.449187
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    fake_info = {
        'filepath': 'F:\\Downloads\\test1.mp3',
        'filename': 'test1.mp3',
        'webpage_url': 'http://www.youtube.com/watch?v=WXoqXoz_cD0',
        'title': 'test title',
        'upload_date': '20120504',
        'description': 'test description',
        'uploader': 'test uploader',
        'format': 'test format',
        'thumbnail': 'test thumbnail',
        'ext': 'mp3',
        'id': 'WXoqXoz_cD0',
    }

    fake_pp = XAttrMetadataPP()

# Generated at 2022-06-12 19:21:25.274379
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    class TestDownloader:
        def __init__(self):
            self.to_screen_count = 0
            self.report_warning_count = 0
            self.report_error_count = 0

        def to_screen(self, message):
            self.to_screen_count += 1

        def report_warning(self, message):
            self.report_warning_count += 1

        def report_error(self, message):
            self.report_error_count += 1

    downloader = TestDownloader()
    xattr_metadata_pp = XAttrMetadataPP(downloader)

    # Test 1: no available xattr support

# Generated at 2022-06-12 19:21:30.318587
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    class Dummy_YoutubeDL:
        def report_error(self, text):
            return
        def report_warning(self, text):
            return
        def to_screen(self, text):
            return
    assert XAttrMetadataPP(Dummy_YoutubeDL())._downloader

# Generated at 2022-06-12 19:21:46.647047
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor.youtube import YoutubeIE

    import datetime

    DATE_FORMAT = '%Y%m%d'
    DATE_GMT = '20121023'
    DATE_LOCAL = datetime.datetime.strptime(DATE_GMT, DATE_FORMAT)


# Generated at 2022-06-12 19:21:47.787330
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass


# Generated at 2022-06-12 19:21:59.159796
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os
    os.environ['XATTR_ENABLED'] = 'False'
    from .common import FileDownloader
    from .XAttrMetadata import XAttrMetadataPP
    from ..extractor import YoutubeIE
    from ..downloader import TorrentFD
    from ..compat import compat_os_name, compat_urllib_request, compatibility_str, compat_basestring, compat_struct_pack

    def test_XAttrMetadataPP_run_helper(add_info, expected_count):
        filename = 'test'
        url = 'http://www.youtube.com/watch?v=BaW_jenozKc'
        ie = YoutubeIE(FileDownloader())
        info = ie.extract(url)
        info['filename'] = filename

# Generated at 2022-06-12 19:22:08.815057
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import pytest
    import tempfile
    import xattr
    from ..compat import compat_supports_xattr

    if not compat_supports_xattr:
        pytest.skip(message='xattr not supported')

    filename = None
    info = {'webpage_url': 'http://example.com/abc',
            'title': 'abc',
            'upload_date': '20160101',
            'description': 'abc',
            'uploader': 'abc',
            'format': 'abc',
            }

    with tempfile.NamedTemporaryFile(prefix='ydl_test_', delete=False) as f:
        filename = f.name


# Generated at 2022-06-12 19:22:09.398071
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pass

# Generated at 2022-06-12 19:22:20.891291
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from .common import FileDownloader

    class FakeYoutubedl(FileDownloader):
        def __init__(self):
            FileDownloader.__init__(self)
            self._ies = []

    ydl = FakeYoutubedl()
    ydl.add_info_extractor(FakeIE(ydl))
    ydl.add_post_processor(XAttrMetadataPP(ydl))

    # Test result from XAttrMetadataPP._run()
    # Post-processor runs only if it is a video.
    def _run_for_video(ydl, ie_result):
        ydl.extract_info(ie_result['url'], download=True)
        return ydl._ies[0].result

    #
    # Test for video (only)
    #

    # Create file

# Generated at 2022-06-12 19:22:21.396538
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    return True

# Generated at 2022-06-12 19:22:32.369392
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os

    # Define some variables
    info_dict = {
        'filepath': '/path/to/file',
        'webpage_url': 'http://www.youtube.com/watch?v=123456',
        'title': 'Awesome title',
        'upload_date': '20111231',
        'uploader': 'Some one',
        'description': 'This is a very long description.',
        'format': 'Long format string',
    }

    # Create the XAttrMetadataPP object
    xattr_pp = XAttrMetadataPP()

    def _write_xattr(filename, xattrname, xattrvalue):
        assert filename == info_dict['filepath']

# Generated at 2022-06-12 19:22:39.990422
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os
    import json
    import tempfile

    # Create a temporary file
    tmp_file = tempfile.NamedTemporaryFile(delete=False)

    # Create a postprocessor using this temporary file
    metadata_postprocessor = XAttrMetadataPP({}, None)

    # Create a metadata for this file
    metadata = {
        'title': 'This is a title',
        'upload_date': '20120101',
        'description': 'This is a description',
        'uploader': 'This is an uploader',
        'format': 'This is a format',
        'webpage_url': 'This is a webpage url',
        'filepath': tmp_file.name
    }


# Generated at 2022-06-12 19:22:41.486569
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP()
    assert pp is not None


# Generated at 2022-06-12 19:22:54.761405
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    XAttrMetadataPP()


if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-12 19:22:56.730299
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor.common import InfoExtractor

    return XAttrMetadataPP.suitable(InfoExtractor("test"))

# Generated at 2022-06-12 19:22:58.719391
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x = XAttrMetadataPP()
    assert x.name == 'xattrdata'

# Generated at 2022-06-12 19:23:03.760704
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    """ Unit tests for constructor of class XAttrMetadataPP """

    # Test XAttrMetadataPP constructor
    xattrm_pp = XAttrMetadataPP()
    assert xattrm_pp != None, 'XAttrMetadataPP constructor returned None'


# Generated at 2022-06-12 19:23:08.809545
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # constructor of class XAttrMetadataPP
    # with arguments (downloader, downloader_params)
    downloader = "my downloader"
    downloader_params = "my downloader_params"
    postprocessor = XAttrMetadataPP(downloader, downloader_params)
    assert postprocessor.downloader == "my downloader"
    assert postprocessor.downloader_params == "my downloader_params"



# Generated at 2022-06-12 19:23:10.066772
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    metadata_pp = XAttrMetadataPP(None)
    assert metadata_pp != None

# Generated at 2022-06-12 19:23:17.776299
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import sys
    import unittest

    from mock import patch
    from .common import PostProcessorTest

    class XAttrMetadataPPTest(PostProcessorTest):
        @patch.object(XAttrMetadataPP, 'run')
        def test_run(self, mock_method):
            p = XAttrMetadataPP(self.ydl)
            self.assertTrue(p.run(self.info))

    sys.exit(unittest.main())


# Generated at 2022-06-12 19:23:18.788368
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    return XAttrMetadataPP()

# Generated at 2022-06-12 19:23:19.479963
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP()
    return pp

# Generated at 2022-06-12 19:23:30.648437
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    print('Test method run of class XAttrMetadataPP')

    import tempfile
    import os.path
    import shutil
    import time

    try:
        os.system('xattr -h > /dev/null 2>&1') # check if xattr is available with 'attr' command
    except OSError:
        raise SystemExit('Cannot test XAttrMetadataPP: xattr is not available')

    from youtube_dl.YoutubeDL import YoutubeDL

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp(prefix='%s-' % __name__)
    print('Created temporary directory: %s' % temp_dir)

    # Create a file in the temporary directory
    temp_file = os.path.join(temp_dir, 'test.mp4')

# Generated at 2022-06-12 19:23:56.325172
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    xattr_pp = XAttrMetadataPP(None)
    assert isinstance(xattr_pp, XAttrMetadataPP)

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-12 19:24:05.881492
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .common import FileDownloader
    from ..extractor import YoutubeIE
    downloader = FileDownloader({})
    xattr_pp = XAttrMetadataPP(downloader)
    ie = YoutubeIE(downloader=downloader)
    test_video_id = 'r2xJyRiE0_4'
    info_dict = ie._real_extract(test_video_id)
    info_dict['filepath'] = 'filename.flv'
    xattr_pp._downloader.to_screen = lambda s: s
    xattr_pp._downloader.report_warning = lambda s: s
    xattr_pp._downloader.report_error = lambda s: s
    xattr_pp.run(info_dict)

# Generated at 2022-06-12 19:24:06.686183
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP()
    assert(pp is not None)

# Generated at 2022-06-12 19:24:07.879402
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP.__name__ == "XAttrMetadataPP"

# Generated at 2022-06-12 19:24:15.243712
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..utils import prepend_extension
    from .common import FileDownloader
    from ..extractor import YoutubeIE

    #
    # test 1: Test class section
    #
    try:
        assert isinstance(XAttrMetadataPP, type)
        assert issubclass(XAttrMetadataPP, PostProcessor)
    except AssertionError:
        raise AssertionError('metadata.XAttrMetadataPP is not a class')

    #
    # test 2: Test constructor keyword arguments
    #
    test2 = XAttrMetadataPP(downloader=None)

# Generated at 2022-06-12 19:24:17.243989
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    return

if __name__ == "__main__":
    test_XAttrMetadataPP_run()

# Generated at 2022-06-12 19:24:26.227919
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import atexit
    import os
    import shutil
    import tempfile

    def _create_file():
        f = open(filename, 'w')
        f.write('a')
        f.close()

    def _remove_temp_folder():
        shutil.rmtree(temp_folder)

    temp_folder = tempfile.mkdtemp(prefix=__package__ + '.')
    atexit.register(_remove_temp_folder)
    filename = os.path.join(temp_folder, 'test.file')
    _create_file()

    pp = XAttrMetadataPP(None)

    info = {}
    orig_num_written = 0

    num_written, info = pp.run(info)
    assert num_written == 0


# Generated at 2022-06-12 19:24:28.242780
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-12 19:24:29.300600
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass


# Generated at 2022-06-12 19:24:38.966718
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    def run(info):
        """ Set extended attributes on downloaded file (if xattr support is found). """

        # Write the metadata to the file's xattrs
        print ('[metadata] Writing metadata to file\'s xattrs')

        filename = info['filepath']


# Generated at 2022-06-12 19:25:22.627376
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pass

# Generated at 2022-06-12 19:25:23.753364
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    xattr_pp = XAttrMetadataPP()
    assert xattr_pp

# Generated at 2022-06-12 19:25:31.501234
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import pytest

    test_cases = [
        {
            'filename': '/tmp/yt-dl-postprocessor-test.mkv',
            'info': {
                'webpage_url': 'https://www.youtube.com/watch?v=k9qMf3UjSCk',
                'title': 'Peppa Pig Official Channel | Peppa Pig and George Pig Play Hide and Seek',
                'upload_date': '20181013',
                'description': 'Enjoy the videos and music you love, upload original content and share it all with friends, family and the world on YouTube.',
                'uploader': 'Peppa Pig - Official Channel',
                'format': '233 - audio only (tiny)',
                'ext': 'mkv',
            },
        },
    ]

    for test_data in test_cases:
        pp

# Generated at 2022-06-12 19:25:36.578034
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    """
    Unit test for constructor of class XAttrMetadataPP
    """

    # Successful constructor calls
    pp = XAttrMetadataPP()
    assert isinstance(pp, XAttrMetadataPP)
    pp = XAttrMetadataPP('test_XAttrMetadataPP', 4)
    assert isinstance(pp, XAttrMetadataPP)

# Generated at 2022-06-12 19:25:37.576461
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP

# Generated at 2022-06-12 19:25:41.114002
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    """ Run unit test for XAttrMetadataPP constructor """
    from ..YDL import YDL
    ydl = YDL()
    pp = XAttrMetadataPP(ydl)
    assert pp._downloader == ydl



# Generated at 2022-06-12 19:25:51.059711
# Unit test for constructor of class XAttrMetadataPP

# Generated at 2022-06-12 19:25:59.232692
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor import YoutubeIE


# Generated at 2022-06-12 19:25:59.888667
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-12 19:26:08.500834
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os.path
    from tempfile import gettempdir
    from ..compat import compat_xattr

    # Using a temp file to test the extended attributes because
    # it would be too much of a hassle to delete them afterwards.
    tmpfilename = os.path.join(gettempdir(), 'test_xattribute.txt')
    with open(tmpfilename, 'w') as f:
        f.write('test')


# Generated at 2022-06-12 19:27:42.070101
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP('', False)
    if pp is None:
        return False
    return True
if __name__ == '__main__':
    if test_XAttrMetadataPP() == True:
        print('Success')
        exit(0)
    else:
        print('Failure')
        exit(1)

# Generated at 2022-06-12 19:27:42.944008
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    return True

# Generated at 2022-06-12 19:27:43.638424
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass


# Generated at 2022-06-12 19:27:50.093238
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # monkey patched version of write_xattr to test its functionality
    test_download_url = 'https://www.youtube.com/watch?v=RK1K2bCg4J8'
    filename = 'test/test.mp3'

    def write_xattr(path, attrname, attrval):
        """ Monkey patched version of write_xattr used when this file is run as a unit test.
            It checks that the function writes the correct attributes and their corresponding
            values.
        """
        assert(path == filename)


# Generated at 2022-06-12 19:27:54.379552
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    """ """
    # class PostProcessor
    # def run(self, info):
    # def write_xattr(self, filename, info):
    #
    
    # TODO: write unit test
    pass

# Generated at 2022-06-12 19:28:02.678990
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from .. import YoutubeDL
    from ..postprocessor.xattr import XAttrMetadataPP

    def create_ytdl_object(opts):
        class MockYdl(YoutubeDL):
            def __init__(self, params):
                YoutubeDL.__init__(self, params)
                self.params = {}
                self.to_screen = lambda s: None

        return MockYdl({})

    ydl = create_ytdl_object({'writeinfojson': True})
    pp = XAttrMetadataPP(ydl)
    assert isinstance(pp, XAttrMetadataPP)
    pp.run({'filepath': 'some_file', 'title': 'some_title', 'webpage_url': 'some_url'})

# Generated at 2022-06-12 19:28:08.221579
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor.common import InfoExtractor
    from ..downloader.common import FileDownloader
    from ..compat import fake_filesystem_unavailable

    if fake_filesystem_unavailable:
        return

    # We need a FileDownloader for this test
    params = {
        'outtmpl': '%(id)s',
        'format': 'bestaudio/best',
        'postprocessors': [{
            'key': 'FFmpegExtractAudio',
            'preferredcodec': 'mp3',
            'preferredquality': '192',
        },
        {
            'key': 'XAttrMetadata'
        }],
    }
    params2 = dict(params)

# Generated at 2022-06-12 19:28:14.882085
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    class FakeDLLogger():
        def to_screen(self, msg):
            pass

        def report_error(self, msg):
            pass

        def report_warning(self, msg):
            pass

    class FakeFile():
        def __init__(self, filename, value):
            self.filename = filename
            self.value = value

        def __enter__(self):
            return self.value

        def __exit__(self, exc_type, exc_value, traceback):
            pass


# Generated at 2022-06-12 19:28:24.747197
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .test_common import Downloader
    ydl = Downloader()
    ydl.params['writethumbnail'] = False
    ydl.params['writeinfojson'] = False
    pp = XAttrMetadataPP(ydl)

    # Test that the xattrs are not written if there's no disk space.
    class FakeXattr(object):
        ENOTSUP = 45
        ENOSPC = 28
        ENOATTR = 61
        ERANGE = 34

        def list(this, filename):
            return []

        def set(this, filename, name, value, options=0, position=0):
            raise IOError(FakeXattr.ENOSPC, 'No space left on device', filename)

        def fget(this, fd, name, size=None, options=0, position=0):
            raise IO

# Generated at 2022-06-12 19:28:26.240739
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP().run({}) == ([], {})