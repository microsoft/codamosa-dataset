

# Generated at 2022-06-12 19:20:38.423612
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    filename = 'abc'
    info = {
        'filename': 'youtube-dl test video \'\'"\x01\x02.mp4',
        'webpage_url': 'http://www.youtube.com/watch?v=BaW_jenozKc',
        'uploader': 'Philipp Hagemeister',
        'upload_date': '20121002',
        'description': 'test chars: \"\'/\\\0\n\r\t\x01',
        'format': 'format',
        'title': 'youtube-dl test äÄüÜöÖ video',
    }
    write_xattr(filename, 'user.xdg.comment', info['description'])
    write_xattr(filename, 'user.xdg.referrer.url', info['webpage_url'])
   

# Generated at 2022-06-12 19:20:40.974063
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    xattr_metadata_pp = XAttrMetadataPP({})
    assert isinstance(xattr_metadata_pp, XAttrMetadataPP)

# Generated at 2022-06-12 19:20:43.616388
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP(None, None, None)


if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-12 19:20:50.656726
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    filename = "test.mp4"
    info = {
        'webpage_url': 'https://www.youtube.com/watch?v=5ZNlP9_NXcI',
        'title': 'Test file',
        'upload_date': '20160722',
        'description': 'test file description',
        'uploader': 'uploader',
        'format': 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best',
    }

# Generated at 2022-06-12 19:20:53.148784
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    filename = '/tmp/test.mp4'
    expected_result = b''
    metadata = {}
    instance = XAttrMetadataPP(filename, metadata)
    assert(instance.filename == expected_result)

# Generated at 2022-06-12 19:21:03.053788
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # NOTE: Although YoutubeDL is usually imported from ydl.py, in this
    # case we can't because this file is used in ydl.py, so we must import
    # from __main__.
    from .__main__ import YoutubeDL
    from .extractor.common import InfoExtractor
    from .utils import DateRange

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'fakie'
        _VALID_URL = r'https?://(?:www\.)?youtube\.com/'


# Generated at 2022-06-12 19:21:11.656271
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # Test JSON string (== info)
    test_info_json_string = u'{"title": "test_title", "upload_date": "test_upload_date", "description": "test_description", "uploader": "test_uploader", "format": "test_format"}'
    # test_XAttrMetadataPP_run()
    pp = XAttrMetadataPP()
    info = json.loads(test_info_json_string)
    results, info = pp.run(info)


if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-12 19:21:23.351449
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .common import FileDownloader
    from .xattr import GlobalXAttrMetadataPP as _GlobalXAttrMetadataPP

    # Mock FileDownloader object
    fd = FileDownloader(params={})
    fd.to_screen = lambda msg: True

    info = {
        'id': 'test_id',
        'url': 'test_url',
        'title': 'test_title',
        'webpage_url': 'test_webpage_url',
        'uploader': 'test_uploader',
        'ext': 'test_ext',
        'format': 'test_format',
        'upload_date': 'test_upload_date',
        'description': 'test_description',
    }
    pp = XAttrMetadataPP(fd)

#    # Mock filesystem xattrs support


# Generated at 2022-06-12 19:21:24.389144
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert(XAttrMetadataPP)

# Generated at 2022-06-12 19:21:28.173095
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    import pytest
    pp = XAttrMetadataPP()
    assert isinstance(pp, XAttrMetadataPP)
    # TODO: Add more test cases


# Generated at 2022-06-12 19:21:42.093861
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    filename = 'filename'
    info = {'title': 'video title', 'description': 'video description'}
    xattr_mapping = ['user.xdg.comment', 'user.dublincore.title', 'user.dublincore.description', 'user.dublincore.format']

    def write_xattr(filename, xattrname, byte_value):
        assert xattrname in xattr_mapping
        xattr_mapping.remove(xattrname)
        assert info[xattrname[5:]] == byte_value

    xattr_postprocessor = XAttrMetadataPP()
    xattr_postprocessor._downloader = object()

    xattr_postprocessor.run(info)
    assert not xattr_mapping

if __name__ == '__main__':
    test

# Generated at 2022-06-12 19:21:43.576964
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP(None).name() == 'xattr'

# Generated at 2022-06-12 19:21:54.611410
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    import tempfile
    import os
    import shutil

    test_dir = tempfile.mkdtemp()
    assert os.path.isdir(test_dir)

    test_file = os.path.join(test_dir, 'test_YoutubeDL_XAttrMetadataPP.txt')
    with open(test_file, 'w') as f:
        f.write('Hello World!')

    assert os.path.isfile(test_file)


# Generated at 2022-06-12 19:22:05.638300
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():

    import tempfile
    from .common import FileDownloader
    from ..utils import (
        xattr_writable,
        DEPRECATED_ERRORS,
    )

    # Create a temporary file
    tmpfd, tmpfname = tempfile.mkstemp()
    with open(tmpfname, 'wb') as f:
        f.write(b'0123456789')
    os.close(tmpfd)

    # Remove it at the end
    def remove_file(fname):
        try:
            os.remove(fname)
        except OSError as ose:
            if ose.errno != errno.ENOENT:
                raise
    atexit.register(remove_file, tmpfname)

    # Create the XAttrMetadataPP instance

# Generated at 2022-06-12 19:22:12.322268
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    import os
    try:
        os.remove('test.mp3')
    except:
        pass
    ydl_opts = {
        'format': 'bestaudio/best',
        'postprocessors': [{
            'key': 'FFmpegExtractAudio',
            'preferredcodec': 'mp3',
            'preferredquality': '192',
        }, {
            'key': 'XAttrMetadata'
        }],
        'outtmpl': 'test.%(ext)s',
    }
    ydl = YoutubeDL(ydl_opts)

# Generated at 2022-06-12 19:22:15.014692
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-12 19:22:20.924038
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    ''' Just testing that _XAttrMetadataPP constructor works '''
    from .common import FileDownloader
    from ..utils import get_extractor

    ydl = FileDownloader({'outtmpl': '%(id)s-%(upload_date)s'})
    ext = get_extractor('Some:URL:Here')
    pp = XAttrMetadataPP(ydl, ext)
    return pp

if __name__ == '__main__':
    # Run unit test
    print(test_XAttrMetadataPP())

# Generated at 2022-06-12 19:22:31.826130
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..extractor import common

    '''
    # Disabled: require root rights to run and xattr support on disk
    xattr_pp = XAttrMetadataPP()
    xattr_pp.run({
        'webpage_url': 'http://www.youtube.com/watch?v=BaW_jenozKc',
        'title': 'Horses & Ponies',
        'upload_date': '20121002',
        'description': 'Description',
        'uploader': 'Uploader',
        'format': 'mp4',
        })
    '''
    xattr_pp = XAttrMetadataPP()

# Generated at 2022-06-12 19:22:32.820739
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    return XAttrMetadataPP.run

# Generated at 2022-06-12 19:22:34.789864
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    """
    Unit test for class XAttrMetadataPP
    """
    pp = XAttrMetadataPP(None)
    print(pp)

# Generated at 2022-06-12 19:22:47.038191
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # Done
    pass

if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-12 19:22:48.537566
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from .XAttrMetadataPP import XAttrMetadataPP
    xattrs = XAttrMetadataPP()

# Generated at 2022-06-12 19:22:49.851491
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    metadata_processor = XAttrMetadataPP(None)
    assert metadata_processor


# Generated at 2022-06-12 19:23:01.896066
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .common import FileDownloader
    from ..extractor import YoutubeIE

    dl = FileDownloader(params={'writesubtitles': True, 'writeautomaticsub': True, 'allsubtitles': True})
    dl.add_info_extractor(YoutubeIE(dl))
    dl.params.update({
        'outtmpl': u'./test_XAttrMetadataPP_run-%(stitle)s-%(id)s.%(ext)s',
        'quiet': True,
    })
    ie = YoutubeIE(dl)
    ie.download(ie.url_result('https://www.youtube.com/watch?v=BaW_jenozKc'))

    # There shouldn't be any error
    from .test_postprocessor import assertMsg2

    assertMsg2

# Generated at 2022-06-12 19:23:11.460201
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from unittest.mock import patch, MagicMock

    with patch('youtube_dl.postprocessor.xattr.write_xattr', return_value=None) as mock_write_xattr:
        # xattr.write_xattr return value is None in the code above, so it is not possible
        # to tell whether it is called, but we can patch it anyway to prevent it from accessing file system
        with patch('youtube_dl.postprocessor.xattr.xattr', create=True) as mock_xattr:
            # xattr.xattr is not available on Windows and raises NotImplementedError
            # XAttrUnavailableError is not used if xattr.xattr is None, but instead an AttributeError is raised
            mock_xattr.__module__ = None

# Generated at 2022-06-12 19:23:13.174147
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    name = 'test'
    pp = XAttrMetadataPP(None)
    assert pp.name == name


# Generated at 2022-06-12 19:23:21.803120
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from .common import PostProcessor
    from .embedthumbnail import EmbedThumbnailPP
    from .execafterdownload import ExecAfterDownloadPP
    from .xattrmetadatabackup import XAttrMetadataBackupPP

    pp = XAttrMetadataPP()
    assert isinstance(pp, PostProcessor)

    pp = XAttrMetadataPP()
    pp.add_info_extractor(None)
    assert pp.ie is None

    pp = XAttrMetadataPP()
    pp.add_post_processor(EmbedThumbnailPP())
    assert isinstance(pp.pp, EmbedThumbnailPP)

    pp = XAttrMetadataPP()
    pp.add_post_processor(EmbedThumbnailPP())
    pp.add_post_processor(ExecAfterDownloadPP())

# Generated at 2022-06-12 19:23:31.910558
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    filename = "/path/to/file"
    info = {
        'webpage_url': "http://example.com/",
        'description': "description",
        'title': "title",
        'upload_date': "21 Feb 2017",
        'uploader': "uploader",
        'format': "format",
        'filepath': filename,
    }

    #
    # No exception
    #

    def _get_user_xattr(filename, attr):
        return "user.xdg.referrer.url: %s" % info['webpage_url']


# Generated at 2022-06-12 19:23:39.794435
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import os
    import tempfile

    xattr_mapping = {
        'user.xdg.referrer.url': 'webpage_url',
        # 'user.xdg.comment':            'description',
        'user.dublincore.title': 'title',
        'user.dublincore.date': 'upload_date',
        'user.dublincore.description': 'description',
        'user.dublincore.contributor': 'uploader',
        'user.dublincore.format': 'format',
    }


# Generated at 2022-06-12 19:23:49.239077
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    from ..utils import (
        make_temp_dir,
        set_temp_dir_and_clean_up_downloads,
        remove_dir,
    )

    from .common import FileDownloader

    from . import FFmpegPostProcessor

    from ..compat import (
        compat_os_name,
        compat_str,
    )

    from ..extractor import YoutubeIE


# Generated at 2022-06-12 19:24:11.191624
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP.name == 'xattr'
    assert XAttrMetadataPP.description == 'Write metadata to the file\'s xattrs'

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-12 19:24:11.915976
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-12 19:24:14.547953
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP()

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-12 19:24:18.204103
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # test run() with an empty info dict, to ensure no exception is thrown
    p = XAttrMetadataPP()
    p.run({})

if __name__ == '__main__':
    import nose
    nose.core.runmodule()

# Generated at 2022-06-12 19:24:26.683394
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    def t(info):
        pp = XAttrMetadataPP()
        pp._downloader = lambda: None
        pp.to_screen = lambda s: s
        pp.report_error = lambda s: s
        return pp.run(info)

    assert t({'filepath': '/tmp', 'webpage_url': 'url', 'format': 'format', 'to_screen': True}) == ([], {'filepath': '/tmp', 'webpage_url': 'url', 'format': 'format', 'to_screen': True})
    assert t({'filepath': '/tmp', 'webpage_url': 'url', 'format': 'format', 'to_screen': False}) == ([], {'filepath': '/tmp', 'webpage_url': 'url', 'format': 'format', 'to_screen': False})

# Unit test

# Generated at 2022-06-12 19:24:27.551087
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-12 19:24:37.524022
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import tempfile
    from .tests import get_testdata_dir

    info = {
        'filepath': get_testdata_dir() + '/test.mkv',
        'webpage_url': 'https://www.foo.com/',
        'title': 'Title string and -test.mkv',
        'upload_date': '20131205',
        'uploader': 'Uploader name string',
        'description': 'Description string',
        'format': 'format string',
    }

    postprocessor = XAttrMetadataPP()
    postprocessor._downloader = None


# Generated at 2022-06-12 19:24:40.261281
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    downloader = type('Downloader', (object, ), {'to_screen': lambda *args: True, 'report_warning': lambda *args: True})()
    pp = XAttrMetadataPP(downloader)
    assert pp is not None

# Generated at 2022-06-12 19:24:46.567212
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import os
    import time
    import tempfile
    import shutil
    import xml.dom.minidom

    import pytest

    try:
        import xattr
        xattr.setxattr(b'/', b'system.dont_care_about_this', b'', 0)
        xattr.getxattr(b'/', b'system.dont_care_about_this')
    except OSError:
        pytest.skip('xattr module not present')

    tempdir = tempfile.mkdtemp(prefix='youtubedl-test_XAttrMetadataPP_run')


# Generated at 2022-06-12 19:24:56.381979
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    import tempfile
    import os
    import shutil

    dummy_file = tempfile.mkstemp()[1]
    info = {
        'filepath': dummy_file,
        'title': 'Test title',
        'webpage_url': 'http://example.com',
        # 'description': 'Description',   # empty values are not set
        'upload_date': '20171207',
    }

    pp = XAttrMetadataPP()
    pp.run(info)

    # read back all xattrs
    xattrs = os.listxattr(dummy_file)
    assert(len(xattrs) == 3)
    assert(b'user.xdg.comment' not in xattrs)
    assert(b'user.xdg.referrer.url' in xattrs)


# Generated at 2022-06-12 19:25:37.804988
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    # TODO: implement method test_XAttrMetadataPP_run
    pass


# Generated at 2022-06-12 19:25:48.096856
# Unit test for constructor of class XAttrMetadataPP

# Generated at 2022-06-12 19:25:57.188999
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import tempfile
    import os

    xattr_mapping = {
        'user.xdg.referrer.url': 'webpage_url',
        # 'user.xdg.comment':            'description',
        'user.dublincore.title': 'title',
        'user.dublincore.date': 'upload_date',
        'user.dublincore.description': 'description',
        'user.dublincore.contributor': 'uploader',
        'user.dublincore.format': 'format',
    }

# Generated at 2022-06-12 19:25:57.820508
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass



# Generated at 2022-06-12 19:25:59.301366
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP()
    assert pp
    return pp


# Generated at 2022-06-12 19:26:00.617590
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass
    # TODO


if __name__ == '__main__':
    test_XAttrMetadataPP_run()

# Generated at 2022-06-12 19:26:01.523872
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-12 19:26:09.739871
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from pytube import Caption
    from pytube.extract import (
        apply_descrambler,
        apply_signature,
        get_ytplayer_config,
        get_video_info,
    )
    from pytube import CaptionQuery
    from pytube import YouTube

    #
    # Check if method run works as expected
    #
    yt = YouTube('https://youtu.be/BaW_jenozKc')

    video_info = apply_descrambler(
        get_video_info(yt.video_id, yt.js),
    )
    video_info = apply_signature(
        yt.js,
        video_info,
        get_ytplayer_config(yt.html),
        yt.video_id,
    )


# Generated at 2022-06-12 19:26:14.183113
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import FakeYDL
    ydl = FakeYDL()

    pp = XAttrMetadataPP(ydl)

    info = {}
    info['filepath'] = './file'
    info['format'] = 'video/mp4'

    assert pp.run(info) == ([], info)

    # TODO: Write a better test using mock (lib.tests.test_utils)

# Generated at 2022-06-12 19:26:20.849966
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    class MockYDL:
        def __init__(self):
            self.to_screen_calls = []
            self.report_warning_calls = []
            self.report_error_calls = []

        def report_warning(self, msg):
            self.report_warning_calls.append(msg)

        def report_error(self, msg):
            self.report_error_calls.append(msg)

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)

    def mock_write_xattr(fpath, name, value):
        mock_write_cmds.append((fpath, name, value))

    def mock_hyphenate_date(date_str):
        return date_str

    write_xattr_orig = XAttrMetadata

# Generated at 2022-06-12 19:27:51.986679
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os

    # We need to create a temporary file in order to test the write of xattrs
    # TODO: we should use tempfile.mkstemp()
    tmp_file = os.path.basename(os.path.abspath(__file__)) + '.test'
    f = open(tmp_file, 'a')
    f.close()


# Generated at 2022-06-12 19:27:53.623975
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP('http://example.com') is not None

# Generated at 2022-06-12 19:27:54.935016
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    ydl = YDL()
    x = XAttrMetadataPP(ydl)
    assert not x is None

# Generated at 2022-06-12 19:28:03.742726
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    from .test import TEST_CASES
    from ..downloader import YoutubeDL
    from ..utils import DateRange

    num_test_cases = 0
    num_passed = 0
    total_passed_tests = 0

    for (test_case, info) in TEST_CASES.items():

        status = True
        test_passed = False

        test_case_name = test_case.split(';')[0]
        url = test_case.split(';')[1].replace(' ', '%20')
        filename = test_case.split(';')[2]

        youtube_dl = YoutubeDL()
        youtube_dl.params['simulate'] = True
        youtube_dl.params['quiet'] = True
        youtube_dl.params['format'] = 'best'

# Generated at 2022-06-12 19:28:12.006419
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .common import PostProcessorTestCase

    class DummyInfoExtractor(object):
        def extract(self, url):
            return {
                'id': 'testid',
                'title': 'test video',
                'description': 'test descr',
                'format': 'test format',
                'uploader': 'test uploader',
                'webpage_url': 'http://test.url',
                'upload_date': '2013-12-28'
            }

    class TestXAttrMetadataPP(PostProcessorTestCase):
        def setUp(self):
            PostProcessorTestCase.setUp(self)
            self.test_filename = self.test_filename.encode(sys.getfilesystemencoding())

        def test_run_nix(self):
            self.pp.supported = True


# Generated at 2022-06-12 19:28:14.917417
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # Just create a XAttrMetadataPP
    pp = XAttrMetadataPP(None)
    assert isinstance(pp, XAttrMetadataPP)

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-12 19:28:24.751700
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # mock PostProcessor object
    pp = PostProcessor({})

    # mock Downloader object
    dl = object()
    dl.to_screen = print
    dl.report_error = print
    dl.report_warning = print
    pp._downloader = dl


# Generated at 2022-06-12 19:28:25.999303
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pass


# Generated at 2022-06-12 19:28:27.443506
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP is not None

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-12 19:28:32.311810
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    """
    Constructor test
    """
    pp = XAttrMetadataPP(None)
    assert pp.get_name() == 'xattrs'
    assert pp.get_description() == 'Sets metadata to media file\'s xattrs'