

# Generated at 2022-06-12 19:20:39.184336
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import encode_data_uri
    from .common import FileDownloader
    from .xattr import xattr

    # Set up
    fd = FileDownloader({})
    fd.params['writethumbnail'] = False
    fd.params['writeinfojson'] = False

    #
    # Write metadata to a file's xattrs.
    #

    # Create temporary file on which to test the metadata
    load_xattr = xattr.is_enabled()
    tmpfilename = fd._TEST_FILE_NAME
    fd.to_screen('[debug] Creating temporary file ' + tmpfilename)
    fd.try_rename(tmpfilename, tmpfilename)
    tmpfile = open(tmpfilename, 'wb')
    tmpfile.write(b'hi')
    tmpfile.close()

    # Create

# Generated at 2022-06-12 19:20:46.044258
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    filename = "test.mp4"
    info = {
        'webpage_url': 'http://example.com',
        'description': 'test description',
        'title': 'test title',
        'upload_date': '20120714',
        'uploader': 'test uploader',
        'format': 'test format',
    }
    pp = XAttrMetadataPP({})
    pp.run(filename, info)

# Generated at 2022-06-12 19:20:55.929181
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import tempfile
    import shutil

    # Set up a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a new post processor
    pp = XAttrMetadataPP()
    pp.desc = lambda: 'Test'
    pp._downloader = object()

    # Create a file within the temporary directory
    tmpfile = os.path.join(tmpdir, 'test.mp4')
    with open(tmpfile, 'w') as f:
        f.write('Test file\n')

    # Test on existing file

# Generated at 2022-06-12 19:21:02.354767
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import unittest
    import tempfile
    import os
    from shutil import rmtree
    from .common import FileDownloader
    from .get_thumbnail import GetThumbnailPP
    from .embedthumbnail import EmbedThumbnailPP
    from .get_description import GetDescriptionPP
    from .fixup import FixupPP
    from .geo_bypass import GeoRestrictionPP
    from .extract_audio import ExtractAudioPP
    from .write_info_json import WriteInfoJsonPP

    class TestXAttrMetadataPP(unittest.TestCase):

        @classmethod
        def setUpClass(cls):
            # Create a temporary directory
            cls.test_dir = tempfile.mkdtemp()

# Generated at 2022-06-12 19:21:04.377417
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # Test that constructor does not raise an exception
    assert True

# Generated at 2022-06-12 19:21:04.740237
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-12 19:21:09.654366
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pp = XAttrMetadataPP()
    logger = Mock()
    pp._downloader = Mock({'logger': logger})

    # Test exception
    # Raises XAttrUnavailableError
    pp.run({'filepath': '/dev/null'})
    pp._downloader.report_error.assert_called_with('xattr unavailable')

    # Test exception
    # Raises XAttrMetadataError
    filename = 'test'
    try:
        os.remove(filename)
    except OSError:
        pass
    pp.run({'filepath': filename})
    pp._downloader.report_error.assert_called_with('This filesystem doesn\'t support extended attributes.')

    # Test
    filename = 'test1'

# Generated at 2022-06-12 19:21:20.833548
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os
    import pwd
    import tempfile
    import xattr
    from ..utils import (
        urlhandle_detect_ext,
        sanitize_open,
    )
    from . common import FileDownloader
    from . xattr import XAttrMetadataError, XAttrUnavailableError
    from . subtitles import SkipSubtitlesPP

    with tempfile.NamedTemporaryFile(delete=False) as tf:
        filename = tf.name


# Generated at 2022-06-12 19:21:22.505058
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass
    # TODO: implement method test


# Generated at 2022-06-12 19:21:34.074475
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    from ..downloader import YoutubeDL

    xattrs_enabled = True

    def write_xattr(filename, xattrname, value):
        global xattrs_enabled
        if not xattrs_enabled:
            raise XAttrUnavailableError('XAttrs are not enabled')
        if len(value) > 100:
            raise XAttrMetadataError('VALUE_TOO_LONG')

    class FakeInfo:
        def __init__(self, info_dict):
            self.__dict__.update(info_dict)


# Generated at 2022-06-12 19:21:50.423819
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import tempfile
    from .common import FileDownloader
    from ..compat import compat_str

    tempdir = tempfile.mkdtemp()
    print('temp dir: %s' % tempdir)
    try:
        info = {
            'filepath': compat_str(tempdir) + '/f',
            'webpage_url': 'w',
            'title': 't',
            'upload_date': '2',
            'description': 'd',
            'uploader': 'u',
            'format': 'fo',
        }

        pp = XAttrMetadataPP()
        pp.add_info_extractor(None)
        pp.set_downloader(FileDownloader({}))
        pp.run(info)

    finally:
        import shutil

# Generated at 2022-06-12 19:21:53.085279
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # test without xattr support
    pp = XAttrMetadataPP()
    pp.run({})

    # TODO: test with xattr support

# Generated at 2022-06-12 19:21:57.878069
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    metadata = XAttrMetadataPP()
    url = 'https://example.com'
    download_info = {
        'title': 'foo',
        'webpage_url': 'example.com'
    }
    assert metadata.run(download_info) == ([], download_info)

# Generated at 2022-06-12 19:22:01.759235
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # Create an instance of XAttrMetadataPP
    xattr_metadata_pp = XAttrMetadataPP(None)

    # Assert that the instance of XAttrMetadataPP is not none
    assert xattr_metadata_pp is not None


# Generated at 2022-06-12 19:22:10.171442
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    # test XAttrMetadataPP.run()

    import os
    from .common import FileDownloader

    # mock
    fd = FileDownloader({
        'logger': None,
        'progress_hooks': [],
    })
    pp = XAttrMetadataPP(fd)

    # create a file to write metadata
    filepath = os.path.join(os.getcwd(), 'file')
    with open(filepath, 'w') as f:
        f.write('some junk\n')

    # add metadata for xattr

# Generated at 2022-06-12 19:22:11.588384
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP(None).template_fields == []
    assert XAttrMetadataPP(None).template_values == {}


# Generated at 2022-06-12 19:22:14.965204
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # TODO: Write better unit tests for the method run of class XAttrMetadataPP
    pass

# Generated at 2022-06-12 19:22:18.104343
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..downloader.common import FileDownloader

    class FakeInfo:
        pass

    downloader = FileDownloader(FakeInfo)
    postprocessor = XAttrMetadataPP(downloader)
    postprocessor.run(dict())

# Generated at 2022-06-12 19:22:22.050601
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..downloader import FileDownloader
    from ..utils import format_bytes

    # Create a FileDownloader object
    ydl = FileDownloader({})
    pp = XAttrMetadataPP(ydl)

    # Test run()
    # d = {'webpage_url': 'http://httpbin.org/'}
    # pp.run(d)
    # assert(d == {})

# Generated at 2022-06-12 19:22:33.143060
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import sys
    import os
    import tempfile
    from ..utils import get_xattr


# Generated at 2022-06-12 19:22:47.253582
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import os
    import sys
    import tempfile
    import unittest

    from .common import FileDownloader
    from ..compat import compat_os_name

    # Preparations
    _, filename = tempfile.mkstemp(prefix='youtube-dl_test_metadata_pp_', suffix='.mp3')
    info = {
        'id': 'abc123',
        'title': 'Example Video Title',
        'ext': 'mp3',
        'webpage_url': 'http://example.com/video?v=abc123',
        'upload_date': '20121001',
        'uploader': 'Example Uploader',
        'description': 'Example description',
        'format': 'MP3 128 Kbps (CBR)',
        'filepath': filename,
    }

# Generated at 2022-06-12 19:22:53.989024
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    #This test will only work when the user running it has enough rights to write xattr
    #If it fails, the test will fail
    #TO DO: find a proper way to test this
    from .common import FileDownloader
    try:
        from ..extractor import YoutubeIE
    except ImportError:
        from ..extractor import gen_extractors
        try:
            gen_extractors()
        except TypeError:  # gen_extractors() takes exactly 1 argument (2 given) when run from within test_XAttrMetadataPP_run()
            pass  # gen_extractors() is already registered

    # filepath is required for writing xattrs
    # title is required for xattr 'user.dublincore.title'
    # upload_date is required for xattr 'user.dublincore.date

# Generated at 2022-06-12 19:23:04.198044
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import sys
    import types

    if sys.version_info.major < 3:
        import StringIO
    else:
        StringIO = types.SimpleNamespace(StringIO=io.StringIO)

    from mock import patch

    return_value = ('', None)
    mock_write_xattr = patch('youtube_dl.postprocessor.xattrpp.write_xattr', return_value=return_value).start()

    info = {
        'filepath': 'foo/bar.mp3',
        'webpage_url': 'https://foo/bar.mp3',
        'title': 'title',
        'upload_date': '20111231',
        'description': 'description',
        'uploader': 'uploader',
        'format': 'format',
    }

    pp = XAttrMetadataPP()


# Generated at 2022-06-12 19:23:05.419567
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # Basic instantiation
    XAttrMetadataPP(None)

# Generated at 2022-06-12 19:23:06.373192
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # TODO
    pass

# Generated at 2022-06-12 19:23:15.157947
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..YoutubeDL import YoutubeDL
    from ..extractor.common import InfoExtractor
    from ..utils import DateRange
    from ..postprocessor import PostProcessor

    class FakeExtractor(InfoExtractor):
        def __init__(self, *args, **kwargs):
            self.info = {
                'upload_date': DateRange('20120902', '20120904'),
            }

        def _real_extract(self, *args, **kwargs):
            return self.info

    ie = FakeExtractor({})
    pp = XAttrMetadataPP()

    # Test that xattr aren't writen on windows
    if compat_os_name == 'nt':
        return True

# Generated at 2022-06-12 19:23:22.071315
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..utils import is_xattribute_supported
    if not is_xattribute_supported():
        return

    from .. import YoutubeDL

    class FakeYoutubeDL(YoutubeDL):
        def report_warning(self, msg, *args):
            self._report_warning_called = msg
            self._YoutubeDL__report_warning(msg, *args)

        def report_error(self, msg, *args):
            self._report_error_called = msg
            self._YoutubeDL__report_error(msg, *args)

    FakeYoutubeDL(params={}).add_post_processor(XAttrMetadataPP)

# Generated at 2022-06-12 19:23:31.416596
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .test_utils import make_test_lib

    lib = make_test_lib()

    filename = 'file.mp4'
    pp = XAttrMetadataPP(lib)
    info = {
        'filepath': filename,
        'webpage_url': 'https://www.youtube.com/watch?v=zx2exZHc8ZU',
        'title': 'The Windows 8 UI',
        'upload_date': '20121128',
        'description': 'video description',
        'uploader': 'uploader',
        'format': 'format',
    }
    results = pp.run(info)

    assert results[0] == []
    assert results[1] == info



# Generated at 2022-06-12 19:23:33.202818
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 19:23:36.345965
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP(None)
    print(pp)

# Generated at 2022-06-12 19:24:06.548275
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import tempfile
    import os
    import sys
    import shutil

    # Make sure we have extended attributes support.
    if compat_os_name == 'nt':
        import win32file
        try:
            win32file.GetFileAttributesEx('C:\\')
        except:
            raise unittest.SkipTest('Missing XAttr support')
    else:
        try:
            assert write_xattr('.', 'user.foo', '')
        except XAttrUnavailableError:
            raise unittest.SkipTest('Missing XAttr support')

    from ..YoutubeDL import YoutubeDL
    from .pp_test import pp_test


# Generated at 2022-06-12 19:24:14.456372
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..downloader.common import FileDownloader
    from ..compat import compat_os_name

    # Use a FileDownloader object to setup a XAttrMetadataPP object and call its run function
    downloader = FileDownloader({})
    downloader.params = {}
    pp = XAttrMetadataPP(downloader)

    # Currently, there's no unit test on 'nt' system because it's hard to setup a NTFS file system
    if compat_os_name != 'nt':
        # Test case 1: test with a dummy filepath
        info = {'filepath': '/tmp/dummy_video_file.mp4', 'title': 'Testing title'}
        errors, _ = pp.run(info)
        assert (len(errors) == 1)

# Generated at 2022-06-12 19:24:18.906539
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor.common import InfoExtractor

    # The simplest constructor test:
    #     simply creates an instance of XAttrMetadataPP class and
    #     checks its type
    pp = XAttrMetadataPP(InfoExtractor())
    assert isinstance(pp, XAttrMetadataPP)


# Generated at 2022-06-12 19:24:21.921955
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # This function is only run if xattr library is available
    metadatapp = XAttrMetadataPP(None)
    assert metadatapp



# Generated at 2022-06-12 19:24:23.496555
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    """Test constructor of class XAttrMetadataPP"""
    # TODO: Add unit test
    pass


# Generated at 2022-06-12 19:24:33.988406
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    filename = 'file'

    info = {
        'filepath': filename,
        'webpage_url': 'http://www.test.com',
        # 'description': 'Description of test',
        'title': 'Title',
        'upload_date': '2005-01-01',
        'description': 'Description of test',
        'uploader': 'Uploader name',
        'format': 'Format'
    }


# Generated at 2022-06-12 19:24:42.301773
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .common import FileDownloader
    from .testutils import TestPP

    filename = None
    info = {
        'upload_date': '20100114',
        'title': 'Example -- Title',
        'webpage_url': 'http://example.org/example.html',
        'description': 'Example -- Description',
        'uploader': 'Example -- Uploader',
        'format': 'Example -- Format',
    }
    pp = XAttrMetadataPP()


# Generated at 2022-06-12 19:24:43.790620
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    return XAttrMetadataPP().run({'filepath': '/path/to/file.mkv'})

# Generated at 2022-06-12 19:24:53.486221
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os
    import shutil
    import tempfile
    from .testcommon import FakeYDL

    orig_write_xattr = XAttrMetadataPP.write_xattr
    orig_exists_xattr = XAttrMetadataPP.exists_xattr

    def mock_write_xattr(self, name, value):
        if compat_os_name == 'nt':
            original_filename = name
        else:
            original_filename = b'.' + name

        self.files_written.append((original_filename, value))

    def mock_exists_xattr(self, name):
        if compat_os_name == 'nt':
            original_filename = name
        else:
            original_filename = b'.' + name


# Generated at 2022-06-12 19:25:02.185854
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import os
    import tempfile


# Generated at 2022-06-12 19:25:51.558487
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    f = open('test_XAttrMetadataPP', 'wb')
    f.close()

    # Test 1: xattrs are supported and present
    try:
        from .. import XAttrMetadataPP
        from .common import FileDownloader
        downloader = FileDownloader({
            'username': 'test',
            'title': 'title',
            'id': 'test',
            'url': 'url',
            'format': 'format',
            'uploader': 'uploader',
            'upload_date': '20121010',
            'description': 'description',
        }, 'test_XAttrMetadataPP', {})
        xattr_pp = XAttrMetadataPP(downloader)
        xattr_pp.run({})
    except:
        return False
    finally:
        import os
       

# Generated at 2022-06-12 19:25:59.576386
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from .common import FileDownloader
    from ..extractor import gen_extractors
    from ..utils import NULL_LOGGER


# Generated at 2022-06-12 19:26:08.242504
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import encodeFilename


# Generated at 2022-06-12 19:26:08.763297
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pass

# Generated at 2022-06-12 19:26:16.924467
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # Test that XAttrMetadataPP.run raises an error an fails on platforms
    # that don't support Extended Attributes.
    import pytest
    PP = XAttrMetadataPP(None)

    class fake_downloader:
        def report_error(self, msg):
            assert msg =="This filesystem doesn't support extended attributes. (You may have to enable them in your /etc/fstab)"

    PP._downloader = fake_downloader()

# Generated at 2022-06-12 19:26:27.587903
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import tempfile
    from ..extractor.common import InfoExtractor
    from ..extractor.youtube import YoutubeIE
    from ..postprocessor import FFmpegMetadataPP

    # Get a test video
    info_dict = YoutubeIE()._real_extract('QP-G0JvKxpc')

    # Save video to a temporary file
    path = tempfile.NamedTemporaryFile().name
    YoutubeIE()._real_download(info_dict['url'], path)

    # Remove unwanted keys
    for k in ['webpage_url_basename', 'relevant_yt_api_config', 'fulltitle']:
        if k in info_dict:
            del info_dict[k]

    # Get metadata
    info_dict = FFmpegMetadataPP().run(info_dict)[1]

    # Write metadata to file's

# Generated at 2022-06-12 19:26:35.310112
# Unit test for method run of class XAttrMetadataPP

# Generated at 2022-06-12 19:26:37.686242
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    xattr_pp = XAttrMetadataPP(None)
    assert xattr_pp != None


# Generated at 2022-06-12 19:26:46.414067
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os
    import tempfile
    from ..compat import compat_xattr
    from ..utils.__read_xattrs import read_xattrs

    tmp_file = tempfile.NamedTemporaryFile(prefix='xattr_metadata_pp_', suffix='.webm', delete=False)
    tmp_file.close()

    _info = {
        'filepath': tmp_file.name,
        'webpage_url': 'http://www.youtube.com/watch?v=BaW_jenozKc',
        'upload_date': '20121002',
        'description': 'test 123',
        'title': 'BaW_jenozKc',
        'format': 'webm',
        'uploader': 'test'
    }

    xattr_metadata_pp = XAttrMetadataPP()

# Generated at 2022-06-12 19:26:47.033082
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass
    # TODO

# Generated at 2022-06-12 19:28:14.823943
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..utils import FakeYDL
    ydl = FakeYDL()
    pp = XAttrMetadataPP(ydl)
    assert pp._downloader == ydl


# Generated at 2022-06-12 19:28:16.937221
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    PP = XAttrMetadataPP()
    assert PP is not None

# Generated at 2022-06-12 19:28:20.073871
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    """
    Makes sure the class can be created and doesn't throw an exception.
    """
    pp = XAttrMetadataPP()
    return pp

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-12 19:28:28.176341
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    input_path = 'tests/test.webm'
    output_path = 'tmp-output'

    dl = FakeInfoExtractor()
    pp = XAttrMetadataPP()

    try:
        import xattr  # NOQA
        if not hasattr(xattr, '__version__') or xattr.__version__ < '0.6.4':
            pytest.skip('Old xattr version')
    except ImportError:
        pytest.skip('Missing xattr module')


# Generated at 2022-06-12 19:28:31.974704
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP('test')
    assert not pp.xattrname_mapping

# Generated at 2022-06-12 19:28:33.284504
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    xc = XAttrMetadataPP()

    assert xc.version() is not None
    assert xc.version() != ""

# Generated at 2022-06-12 19:28:34.939905
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP('youtube-dl')
    assert pp
    assert pp.name == 'XAttrMetadataPP'

# Generated at 2022-06-12 19:28:35.424614
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-12 19:28:36.444761
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP.__name__ == "XAttrMetadataPP"


# Generated at 2022-06-12 19:28:41.557054
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .common import FileDownloader

    downloader = FileDownloader({})
    downloader.to_screen = lambda s: None
    downloader._download_retcode = lambda *a, **k: 0
    downloader.params.update({
        'outtmpl': '%(title)s.%(ext)s'
    })
