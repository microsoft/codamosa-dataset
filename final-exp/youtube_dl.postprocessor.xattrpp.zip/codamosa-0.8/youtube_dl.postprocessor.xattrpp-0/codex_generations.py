

# Generated at 2022-06-12 19:20:32.001654
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # pylint: disable=no-member
    info = {'uploader': 'GPLv3', 'extractor': 'github.com/pliablepixels', 'filepath': '/tmp/test_xattr_metadata.avi', 'title': 'did-you-know'}
    pp = XAttrMetadataPP()
    pp.run(info)

# Generated at 2022-06-12 19:20:34.691714
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    (xattrMetadataPP, _) = XAttrMetadataPP.get_info(downloader=None)
    assert xattrMetadataPP is XAttrMetadataPP

# Generated at 2022-06-12 19:20:36.005082
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # TODO: unit test
    pass

# Generated at 2022-06-12 19:20:44.876723
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    filename = './test.mp4'
    info = {
            'webpage_url': 'https://www.youtube.com/watch?v=pcB_rYrJ824',
            'description': 'description',
            'title': 'title',
            'format': 'format',
            'upload_date': '2006-01-02',
            'uploader': 'uploader',
    }
    pp = XAttrMetadataPP()
    retval = pp.run(info)
    assert retval == ([], info)

# Generated at 2022-06-12 19:20:55.265812
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # Intantiate a XAttrMetadataPP object
    pp = XAttrMetadataPP()

    # Set its private attribute _downloader
    class DummyDownloader:

        def to_screen(self, s):
            "Dummy function that does nothing and returns True"
            return True

        def report_warning(self, s):
            "Dummy function that does nothing and returns True"
            return True

        def report_error(self, s):
            "Dummy function that does nothing and returns True"
            return True

    pp._downloader = DummyDownloader()

    # Call its method run with the following inputs

# Generated at 2022-06-12 19:20:56.976608
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x = XAttrMetadataPP()


# Generated at 2022-06-12 19:20:58.543419
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP({}, {}, None, None, None)

# Generated at 2022-06-12 19:21:02.882653
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    import platform
    from ..compat import shlex_split
    from ..postprocessor import run_postprocessors
    from ..extractor import gen_extractors
    from ..downloader import YoutubeDL
    from ..utils import DateRange

    class MockExtractor(object):
        def __init__(self, info):
            self.info = info

    class MockInfo(dict):
        def __init__(self, *args, **kwargs):
            self['_type'] = 'url'
            self['url'] = 'http://example.com/foo.mp4'
            self['playlist'] = None
            self['playlist_index'] = None
            super(MockInfo, self).__init__(*args, **kwargs)


# Generated at 2022-06-12 19:21:13.485583
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    import os
    import shutil
    import tempfile
    import xattr

    from ..utils import (
        prepend_extension,
        video_extensions,
    )

    temp_dir = tempfile.mkdtemp()
    test_file = os.path.join(temp_dir, 'test.mp4')
    open(test_file, 'a').close()

    class FakeDownloader():

        def __init__(self):
            self.to_screen = None
            self.to_stderr = None
            self.to_console_title = None

        def report_warning(self, msg):
            pass

        def report_error(self, msg):
            pass

    downloader = FakeDownloader()

    class DummyIE():
        pass

    ie = DummyIE()
    ie.playlist

# Generated at 2022-06-12 19:21:25.275903
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    def check_xattrs(filename, xattr_mapping):
        for xattrname, infoname in xattr_mapping.items():
            try:
                value = read_xattr(filename, xattrname)
                value = value.decode('utf-8')
            except XAttrMetadataError:
                value = None

            if infoname == 'upload_date':
                value = value[0:4] + '-' + value[4:6] + '-' + value[6:8]

            if value is None:
                return False

        return True

    import tempfile
    import os

    file_descriptor, filename = tempfile.mkstemp(prefix='yt-dl-test_', suffix='.mkv')
    os.close(file_descriptor)

# Generated at 2022-06-12 19:21:36.482328
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():

    # Test a string that contains a UTF-8 char
    teststr = 'This is a test string with UTF-8 chars: åäöÅÄÖ'
    teststr_byte = teststr.encode('utf-8')
    assert len(teststr) == len(teststr_byte)

    # Try to encode the test string
    value = XAttrMetadataPP._encode(teststr)
    assert value == teststr_byte

# Generated at 2022-06-12 19:21:37.011727
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-12 19:21:44.382413
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..downloader.common import FileDownloader
    from ..compat import compat_os_name

    downloader = FileDownloader(None, None)
    xattr_metadata_pp = XAttrMetadataPP(downloader)
    assert xattr_metadata_pp.downloader is downloader

    # No xattr support
    if not compat_os_name == 'nt':
        try:
            write_xattr(b'.', 'user.xdg.comment', b'foobar')
        except XAttrUnavailableError as e:
            print('caught %r, e.args[0] = %r' % (e, e.args[0]))
            assert e.args[0] == 'xattr support not available'


# Generated at 2022-06-12 19:21:46.254254
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
  XAttrMetadataPP(None)

# Generated at 2022-06-12 19:21:47.307335
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass


# Generated at 2022-06-12 19:21:58.689631
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    from ..utils import realpath
    from .common import FileDownloader

    import os
    import re
    import shutil
    import tempfile

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Save the current directory path
    old_current_dir_path = os.getcwd()

    # Change the current directory to the temporary directory
    os.chdir(temp_dir)

    # Create an instance of FileDownloader
    downloader = FileDownloader({})

    # At first it runs without parameters
    result = XAttrMetadataPP.run(downloader, {})

    # Check the returned values for assert
    _, info = result

    assert info == {}

    # ------------
    # VIDEO
    # ------------

    # Create a info dictionary

# Generated at 2022-06-12 19:22:04.732049
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..downloader import YoutubeDL
    ydl_opts = {
        'writethumbnail': True,
        'writeinfojson': True,
        'writedescription': True,
        'writeannotations': True,
        'prefer_ffmpeg': True,
    }
    ydl = YoutubeDL(ydl_opts)
    xattr_postprocessor = XAttrMetadataPP(ydl)
    assert xattr_postprocessor is not None

# Generated at 2022-06-12 19:22:11.714947
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    # Construct test data
    info = {
        'webpage_url': 'http://www.keep-tube.com/MzW8Vu9gAjA',
        'fulltitle': 'video title',
        'upload_date': '20151013',
        'description': 'video description',
        'uploader': 'uploader name',
        'format': 'MP4',
    }


# Generated at 2022-06-12 19:22:16.251777
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import tempfile
    import os
    import sys
    import io
    import posix1e
    import xattr

    # create temp file
    tmpd = tempfile.mkdtemp()
    testfile = os.path.join(tmpd, "test.file")
    with open(testfile, 'wb') as f:
        f.write(b'some data')


# Generated at 2022-06-12 19:22:17.520887
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP(None, {}, None)

# Generated at 2022-06-12 19:22:32.069157
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    '''
    Unit test for constructor of class XAttrMetadataPP
    '''

    pp = XAttrMetadataPP()
    pp.run(None)

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-12 19:22:33.006934
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    x = XAttrMetadataPP()
    assert True

# Generated at 2022-06-12 19:22:33.943871
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pass


# Generated at 2022-06-12 19:22:34.742014
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    assert True

# Generated at 2022-06-12 19:22:36.332667
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    xattr_metadata_pp = XAttrMetadataPP()
    assert(xattr_metadata_pp != None)

# Generated at 2022-06-12 19:22:37.801073
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    postprocessor = XAttrMetadataPP()
    return postprocessor

# Generated at 2022-06-12 19:22:48.209395
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import sys
    if sys.version_info < (3, 0):
        import codecs
        sys.stdout = codecs.getwriter('utf-8')(sys.stdout)

    # setup
    test_file_name = 'foo bar'
    test_file_path = '/tmp/' + test_file_name
    test_file_url = 'http://foo.bar'

    from .test_postprocessor import _TestPostProcessor
    x = XAttrMetadataPP(_TestPostProcessor())

# Generated at 2022-06-12 19:22:48.948851
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-12 19:23:01.112918
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import tempfile, os, xattr
    
    class MockYDL(object):
        def to_screen(self, message):
            pass
        def report_error(self, message):
            raise Exception('report_error: ' + message)
        def report_warning(self, message):
            raise Exception('report_warning: ' + message)
    
    # Prepare a temporary file
    temp_fd, temp_path = tempfile.mkstemp()
    temp_file = os.fdopen(temp_fd, 'w+b')
    temp_file.close()

    # Mimic a successful result

# Generated at 2022-06-12 19:23:01.529261
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    return

# Generated at 2022-06-12 19:23:26.854260
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    xattr = XAttrMetadataPP(None)
    assert isinstance(xattr, XAttrMetadataPP), 'Constructor of class XAttrMetadataPP does not work'

if __name__ == '__main__':
    print('Testing class XAttrMetadataPP')
    # test_XAttrMetadataPP()
    # print('Testing class XAttrMetadataPP completed')

# Generated at 2022-06-12 19:23:30.603471
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    """ Test for constructor of class XAttrMetadataPP """
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    ydl.post_processors['XAttrMetadataPP'] = XAttrMetadataPP(ydl)
    ydl.post_processors['XAttrMetadataPP'].run({})

# Generated at 2022-06-12 19:23:38.989330
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from tempfile import mktemp
    from .common import FileDownloader
    from .common import FakeYDL as FakeYDLBase
    from ..utils import encodeFilename, mk_temp_file

    class FakeYDL(FakeYDLBase):
        """ Fake YouTubeDL class for initializing FileDownloader.
        """

        def __init__(self):
            FakeYDLBase.__init__(self)
            self.params = {'writethumbnail': True}

        def to_screen(self, msg):
            """ Fake to_screen(). """
            pass

        def report_error(self, msg):
            """ Fake report_error(). """
            raise RuntimeError(msg)

        def report_warning(self, msg):
            """ Fake report_warning(). """
            raise RuntimeError(msg)


# Generated at 2022-06-12 19:23:43.942974
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    info = dict(
        webpage_url = u'http://www.youtube.com/watch?v=BaW_jenozKc',
        title = u'title',
        upload_date = u'20130101',
        description = u'description',
        uploader = u'uploader',
        format = u'3gp',
    )

    # If the code doesn't throw an exception, the constructor works
    XAttrMetadataPP(None).run(info)

# Generated at 2022-06-12 19:23:54.043424
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # Test that xattrs are set and then removed
    import tempfile
    import os
    import xattr
    from ..utils import DateRange

    d = {}

    d['webpage_url'] = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    d['title'] = 'test_title'
    d['description'] = 'test_description'
    d['uploader'] = 'uploader'
    # d['keywords'] = ['keyword1', 'keyword2']
    d['upload_date'] = '20121001'
    d['location'] = 'location'
    d['format'] = 'best'
    d['player_url'] = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    d['duration'] = '60'

# Generated at 2022-06-12 19:24:04.294757
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..utils import prepare_mock_downloader
    from ..downloader import VideoInfo
    from ..compat import compat_os_name

    d = prepare_mock_downloader(XAttrMetadataPP)
    d.postprocessors.append(XAttrMetadataPP(d))

    # let's generate a new temp file
    filename = d.temp_name('test.flv')
    info = VideoInfo(filename, {'title': 'Titel', 'upload_date': '2014-11-07', 'webpage_url': 'http://www.youtube.com/watch?v=BaW_jenozKc', 'uploader': 'Hans Wurst', 'description': 'Dies ist ein Test.', 'format': 'flv'})

    # just generate the list of sucessful tasks, but don

# Generated at 2022-06-12 19:24:07.590956
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    # Test for method run of XAttrMetadataPP
    #
    # Arguments:
    #  (none)
    #
    # Return:
    #  (none)
    #
    # Assertions:
    #  (none)
    #


    # The tests are not made to test the functionality of the method run of class XAttrMetadataPP
    # as the class relies on external packages to be available.
    return True



# Generated at 2022-06-12 19:24:10.734421
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    """ Unit test for constructor of class XAttrMetadataPP """

    # Create an object (and not a downloader)
    postprocessor = XAttrMetadataPP('/tmp/')

    # Just test if the object is

# Generated at 2022-06-12 19:24:13.710627
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # run() is not testable without a file (and we don't want to create a file)
    XAttrMetadataPP({})

# Generated at 2022-06-12 19:24:23.894913
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    downloader = DummyYoutubeDL({})

    xattrs = {}

    def mock_write_xattr(filename, xattrname, byte_value):
        xattrs[xattrname] = byte_value

    # Attach mock method to the class
    temp = XAttrMetadataPP.write_xattr
    XAttrMetadataPP.write_xattr = mock_write_xattr

    # Test without any information
    info = {}
    XAttrMetadataPP(downloader).run(info)
    assert xattrs == {}

    # Test with all the information passed

# Generated at 2022-06-12 19:25:07.733510
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    assert XAttrMetadataPP(None).get_name() == 'xattr'


# Generated at 2022-06-12 19:25:10.459193
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    import sys
    x = XAttrMetadataPP({'outtmpl': '%(id)s'})
    assert x != None

if __name__ == '__main__':
    test_XAttrMetadataPP()

# Generated at 2022-06-12 19:25:18.287618
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    a = XAttrMetadataPP()
    info = {
        'webpage_url': 'http://foo.bar',
        'upload_date': '20150823',
        'title': 'This is the title',
        'description': 'This is the description',
        'format': 'best',
        'uploader': 'Author'}
    filename = 'file.ext'
    info['filepath'] = filename
    ret, info = a.run(info)

    # Verify that we return an empty list
    if ret != []:
        raise ValueError("Expected empty list, got %s" % ret)

    # Verify that the file exists
    if not os.path.isfile(filename):
        raise IOError("File %s does not exists" % filename)

    # Verify that the expected xattrs were written
    #

# Generated at 2022-06-12 19:25:18.975713
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pass


# Generated at 2022-06-12 19:25:24.609543
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from .common import FileDownloader

    class MockExtractor:

        def __init__(self, expected_results):
            self.expected_results = expected_results

        def extract(self, url):
            for res in self.expected_results:
                if res[0] == url:
                    return res[1]
            raise Exception('Unexpected URL: %r' % url)


# Generated at 2022-06-12 19:25:25.395863
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    pp = XAttrMetadataPP('blah')
    assert pp


# Generated at 2022-06-12 19:25:26.200544
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    # TODO: Implement...
    pass

# Generated at 2022-06-12 19:25:31.500987
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    filename = 'file.flv'
    filename_mkv = 'file.mkv'
    info = {
        'filepath': filename,
        'webpage_url': 'www.mypage.html',
        'title': 'title',
        'upload_date': '2013-04-27',
        'description': 'description',
        'uploader': 'uploader',
        'format': 'format',
        'unwanted_key': 'ignored',
    }

    pp = XAttrMetadataPP()
    pp.run(info)

    return True

# Generated at 2022-06-12 19:25:42.248722
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import os
    import tempfile
    import xattr

    # Create a temporary file
    with tempfile.NamedTemporaryFile() as tempfile:
        filename = tempfile.name
        filename_bytes = filename.encode('utf-8')

    # Write some metadata to the file
    info = {
        'webpage_url': 'https://github.com/rg3/youtube-dl',
        'title': 'Readme - youtube-dl',
        'upload_date': '20150402',
        'description': 'youtube-dl is a command-line program to download videos',
        'uploader': 'Ricardo Garcia',
        'format': 'webm',
    }

    # Set expected xattrs

# Generated at 2022-06-12 19:25:51.719592
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    # Skipped if not have root privileges
    from .utils import skip_if_rootless

    skip_if_rootless()

    from .common import FileDownloader
    from .utils import prepend_extension

    filename = prepend_extension('/tmp/__yt_dl_test', 'mkv')

    class Dummy_FD(FileDownloader):
        def __init__(self):
            self.params = {}

        def to_screen(self, s):
            pass

        def report_warning(self, msg):
            pass

        def report_error(self, msg):
            pass

    d = Dummy_FD()


# Generated at 2022-06-12 19:27:17.424991
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass


# Generated at 2022-06-12 19:27:18.717652
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    postprocessor = XAttrMetadataPP(None)
    assert postprocessor is not None

# Generated at 2022-06-12 19:27:19.061407
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass

# Generated at 2022-06-12 19:27:23.877536
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from . import _common_test
    from .common import PostProcessor
    from .xattrpp import XAttrMetadataPP
    from ..compat import compat_os_name

    ct = _common_test.CommonTest()

    def _test_constructor():
        print("\n# Running __init__() test for xattrpp.py")
        postprocessor = XAttrMetadataPP(ct.ydl)
        if not isinstance(postprocessor, PostProcessor):
            raise Exception("xattrpp.py __init__() test failed")
        if compat_os_name != 'nt':
            # works only on non MS-Windows
            if not hasattr(postprocessor, 'get_xattr'):
                raise Exception("xattrpp.py __init__() test failed")


# Generated at 2022-06-12 19:27:31.514676
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    import unittest
    import tempfile
    import os
    import getpass

    # make a dir
    dir_location = tempfile.TemporaryDirectory()
    dir_name = os.path.join(dir_location.name, 'testing_dir')

    # make a file
    file_location = tempfile.NamedTemporaryFile(dir=dir_location.name)
    file_name = file_location.name

    # init XAttrMetadataPP
    pp_run = XAttrMetadataPP().run

    # test with empty dict
    assert pp_run({}) == ([], {})

    # test with an xattr that needs to be written

# Generated at 2022-06-12 19:27:32.581816
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    pass
    # TODO: unit test for method run of class XAttrMetadataPP

# Generated at 2022-06-12 19:27:39.584917
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    xattrdict = XAttrMetadataPP()
    assert xattrdict.name == 'set-xattr'


# Note: This is a quick temporary testing tool
# TODO: Remove it completely from youtube-dl
#
if __name__ == '__main__':
    import sys

    if len(sys.argv) < 2 or len(sys.argv) % 2 == 0:
        sys.stderr.write('Description: Writes metadata as extended attributes to a file\n')
        sys.stderr.write('Usage: ' + sys.argv[0] + ' <inputfile> [<xattrname> <value> [...]]\n')
        sys.exit(1)

    filename = sys.argv[1]


# Generated at 2022-06-12 19:27:40.380963
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():

    pass

# Generated at 2022-06-12 19:27:45.555831
# Unit test for constructor of class XAttrMetadataPP
def test_XAttrMetadataPP():
    from ..extractor import YoutubeIE

    def create_extractor(url):
        ie = YoutubeIE(YoutubeIE._WORKER_CLASS(), {}, None)
        ie.initialize()
        ie.set_progress_hooks(lambda *args: None, lambda *args: None)
        return ie

    xattr = XAttrMetadataPP(create_extractor(''), {})
    assert xattr is not None

# Generated at 2022-06-12 19:27:51.590325
# Unit test for method run of class XAttrMetadataPP
def test_XAttrMetadataPP_run():
    from ..downloader import Downloader
    from ..extractor.common import InfoExtractor
    from ..compat import compat_str

    class FakeExtractor(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': '1234',
                'title': 'Test video',
                'ext': 'mp4',
                'duration': 80,
                'upload_date': '20150101',
                'thumbnail': 'https://example.com/thumbnail.jpg',
                'webpage_url': 'https://example.com',
                'description': 'Video description',
                'uploader': 'uploader',
                'uploader_id': 'uploader',
                'format': '360p',
                'resolution': '640x360',
            }

    ie = FakeExtractor()
