

# Generated at 2022-06-20 19:01:41.698203
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """ Run a test for CmdLineFactCollector.collect() """

    def _get_file_content(input_file):
        """ Stub _get_file_content method """
        return input_file

    input_data = "/usr/sbin/netd init 0.0.0.0 --android-system-data-directory=/data/system --no-encrypt-tpm-disk-encryption"

# Generated at 2022-06-20 19:01:44.520023
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd = CmdLineFactCollector()
    assert cmd.name == 'cmdline'
    assert isinstance(cmd._fact_ids, set)



# Generated at 2022-06-20 19:01:56.363983
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    def create_collector():
        return CmdLineFactCollector(None)

    # Test for existence of class
    do_test_instance_exists(create_collector)

    # Test for expected methods
    do_test_expected_methods(create_collector, [
        '_get_proc_cmdline',
        '_parse_proc_cmdline',
        '_parse_proc_cmdline_facts',
        'collect',
    ])

    # Test for expected attributes
    do_test_expected_class_attributes_exist(create_collector, [
        'name',
        '_fact_ids',
    ])

    # Test for expected attributes

# Generated at 2022-06-20 19:02:02.447503
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.utils import get_file_content
    CmdLineFactCollector._get_proc_cmdline = lambda s: to_bytes("ip=192.0.2.2 ro")
    collector = Collector('linux')
    cmdline_facts = CmdLineFactCollector().collect(collected_facts=collector.collect())
    assert cmdline_facts == {
        'cmdline': {
            'ro': True,
            'ip': '192.0.2.2'
        },
        'proc_cmdline': {
            'ro': 'True',
            'ip': '192.0.2.2'
        }
    }

# Unit test

# Generated at 2022-06-20 19:02:15.424227
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import os
    import tempfile
    from ansible.module_utils.facts.collector.cmdline import CmdLineFactCollector
    file_content = 'rootfstype=ext4 root=/dev/mapper/sys-root resume=UUID=821aad95-65fb-4766-9e99-9b44c91b10d0 elevator=noop'
    (fd, tmp_file) = tempfile.mkstemp()
    fd = os.fdopen(fd, 'w')
    fd.write(file_content)
    fd.close()

    cmdline_collector = CmdLineFactCollector()
    cmdline_collector.collectors.pop('/proc/cmdline', None)
    cmdline_collector.collectors['/proc/cmdline'] = tmp_file



# Generated at 2022-06-20 19:02:17.478586
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector is not None


# Generated at 2022-06-20 19:02:25.877291
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import re
    from ansible.module_utils._text import to_text

    def get_file_content(filename):
        return 'ro root=UUID=64d52c63-6a97-450c-9d81-8c482b37f2ae rd.lvm.lv=fedora/root rd.lvm.lv=fedora/swap rhgb quiet'

    class DummyModule(object):
        pass

    module = DummyModule()
    module.params = {}
    module.run_command = lambda x: (0, '', '')

    collector = CmdLineFactCollector(module=module)
    facts = collector.collect()


# Generated at 2022-06-20 19:02:28.527661
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert c._fact_ids == set()


# Generated at 2022-06-20 19:02:31.842749
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()

    assert cmdline_fact_collector.name == 'cmdline'

    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:02:35.250849
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert not c._fact_ids

# Generated at 2022-06-20 19:02:55.777170
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Test for case when /proc/cmdline is empty
    cmdline = set()
    cmdline_dict = {}
    cmdline_facts_empty = {'cmdline': cmdline_dict, 'proc_cmdline': cmdline_dict}
    cmdline_collector = CmdLineFactCollector()

    cmdline_collector._get_proc_cmdline = lambda: ''
    assert cmdline_collector.collect() == cmdline_facts_empty

    # Test for case when /proc/cmdline is not empty
    cmdline = {'BOOT_IMAGE=/kernel-3.10.0-957.el7.x86_64 root=/dev/mapper/rhel-root ro crashkernel=auto rhgb quiet audit=0 LANG=en_US.UTF-8 systemd.unit=multi-user.target'}


# Generated at 2022-06-20 19:03:01.398956
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == "cmdline"
    assert len(cmdline_fact_collector._fact_ids) == 0
    assert cmdline_fact_collector._get_proc_cmdline() == ""


# Generated at 2022-06-20 19:03:10.353502
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """
    Unit test for method collect of class CmdLineFactCollector
    """
    from ansible.module_utils.facts.collector import BaseFactCollector
    import ansible.module_utils.facts.collectors.cmdline as cmdline_module

    class MockCmdLineFactCollector(BaseFactCollector):
        name = 'cmdline'
        _fact_ids = set()

        def _get_proc_cmdline(self):
            return "root=/dev/sda1 console=tty0 console=ttyS0,115200n8 console=tty0"

    cmdline_fact_collector = MockCmdLineFactCollector()
    cmdline_facts = cmdline_fact_collector.collect()

# Generated at 2022-06-20 19:03:11.821311
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = CmdLineFactCollector()
    assert cmdline_facts.name == 'cmdline'
    assert cmdline_facts.collect()

# Generated at 2022-06-20 19:03:13.146110
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()

# Generated at 2022-06-20 19:03:24.997376
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline = CmdLineFactCollector()
    data = cmdline._get_proc_cmdline()
    assert data == "BOOT_IMAGE=(hd0,gpt2)/vmlinuz-4.4.0-72-generic root=/dev/mapper/ubuntu--vg-root ro quiet splash"
    data = cmdline._parse_proc_cmdline_facts(data)
    assert len(data) == 6
    assert data['BOOT_IMAGE'] == "(hd0,gpt2)/vmlinuz-4.4.0-72-generic"
    assert data['root'] == "/dev/mapper/ubuntu--vg-root"
    assert data['ro'] == True
    assert data['quiet'] == True
    assert data['splash'] == True
    data = cmdline._parse_proc_cmdline(data)


# Generated at 2022-06-20 19:03:37.702002
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible_collections.ansible.community.plugins.module_utils.facts.collectors import CmdLineFactCollector
    from ansible.module_utils.facts.collector import FactCollector
    import pytest

    # unit testing CmdLineFactCollector
    test_obj = CmdLineFactCollector()
    # test normal case

# Generated at 2022-06-20 19:03:48.221749
# Unit test for method collect of class CmdLineFactCollector

# Generated at 2022-06-20 19:03:59.578307
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # test with empty command line
    platform_obj = CmdLineFactCollector()
    collected_facts = platform_obj.collect()
    assert collected_facts == {}

    # test with non-empty command line
    file_obj = open('/proc/cmdline', 'w')
    file_obj.write('ansible=foo bar=baz bing=')
    file_obj.close()
    collected_facts = platform_obj.collect()
    assert collected_facts == {'cmdline': {'ansible': 'foo', 'bar': 'baz', 'bing': True}, 'proc_cmdline': {'ansible': 'foo', 'bar': 'baz', 'bing': True}}

    # test with non-empty command line with duplicate key
    file_obj = open('/proc/cmdline', 'w')
    file_

# Generated at 2022-06-20 19:04:03.148784
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()

    assert (collector.name == 'cmdline')
    assert (collector._fact_ids == set())



# Generated at 2022-06-20 19:04:23.152476
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line = CmdLineFactCollector()
    assert cmd_line.name == 'cmdline'
    assert cmd_line._fact_ids == set()

# Generated at 2022-06-20 19:04:30.858145
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    def test_func_get_proc_cmdline():
        return 'root=/dev/sda2 ro'

    test_cmdline = 'root=/dev/sda2 ro'
    test_cmdline_dict = {'root': '/dev/sda2', 'ro': True}
    test_proc_cmdline_facts = {'ro': True}

    fact_collector = CmdLineFactCollector()
    fact_collector._get_proc_cmdline = test_func_get_proc_cmdline

    assert fact_collector.collect() == {
        'cmdline': test_cmdline_dict,
        'proc_cmdline': test_proc_cmdline_facts,
    }

# Generated at 2022-06-20 19:04:39.139790
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_dict = {'foo': 'bar', 'baz': True}
    cmdline_facts = {
        'cmdline': cmdline_dict,
        'proc_cmdline': {
            'foo': 'bar',
            'baz': True,
        }
    }

    cmdline_collector = CmdLineFactCollector()
    cmdline_collector.get_file_content = lambda x: "foo=bar baz"
    result = cmdline_collector.collect()

    assert result == cmdline_facts


# Generated at 2022-06-20 19:04:43.856981
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    data = collector._get_proc_cmdline()
    cmdline_facts = collector._parse_proc_cmdline_facts(data)
    assert type(cmdline_facts) is dict

# Generated at 2022-06-20 19:04:44.819461
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector()


# Generated at 2022-06-20 19:04:57.674262
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = {}
    data = """
    ansible_facts=yes
    ansible_facts=yes
    ansible_facts=yes
    """

    def _get_proc_cmdline():
        return data

    def _parse_proc_cmdline(data):
        return data

    def _parse_proc_cmdline_facts(data):
        return data

    CmdLineFactCollector._get_proc_cmdline = _get_proc_cmdline
    CmdLineFactCollector._parse_proc_cmdline = _parse_proc_cmdline
    CmdLineFactCollector._parse_proc_cmdline_facts = _parse_proc_cmdline_facts

    cmdline_facts = CmdLineFactCollector().collect()

    assert cmdline_facts.get('cmdline') == data
    assert cmdline

# Generated at 2022-06-20 19:05:01.858971
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts.collectors.cmdline import CmdLineFactCollector
    from ansible.module_utils.facts.collectors.cmdline import _get_proc_cmdline as get_content
    from ansible.module_utils.facts.collectors.cmdline import _parse_proc_cmdline as parse
    from ansible.module_utils.facts.collectors.cmdline import _parse_proc_cmdline_facts as parse_facts
    import os
    import pytest
    # Populate the class variables
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector.name = "cmdline"
    cmdline_collector._fact_ids = set

# Generated at 2022-06-20 19:05:05.386936
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact = CmdLineFactCollector()
    assert cmdline_fact.name == 'cmdline'
    assert 'cmdline' in cmdline_fact._fact_ids
    assert 'proc_cmdline' in cmdline_fact._fact_ids

# Generated at 2022-06-20 19:05:17.597893
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    import datetime

    sample_output = '''
BOOT_IMAGE=/vmlinuz-3.2.0-4-amd64 root=UUID=d18a2d76-fafb-4b70-bb11-db6e7d965b85 ro quiet
'''
    sample_output = sample_output.strip()

    # build expected output

# Generated at 2022-06-20 19:05:26.260511
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert c._fact_ids == set()

    data = c._get_proc_cmdline()
    assert isinstance(data, str)

    cmdline_dict = c._parse_proc_cmdline(data)
    assert isinstance(cmdline_dict, dict)

    cmdline_dict = c._parse_proc_cmdline_facts(data)
    assert isinstance(cmdline_dict, dict)

    cmdline_facts = c.collect()
    assert isinstance(cmdline_facts, dict)

    for k, v in cmdline_facts.items():
        assert isinstance(k, str)
        assert isinstance(v, dict) or isinstance(v, list)

# Generated at 2022-06-20 19:05:51.013899
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    # Create a fake Ansible module
    module = basic.AnsibleModule(argument_spec={}, supports_check_mode=True)
    # Create a fake AnsibleModuleUtils
    module_utils = basic.AnsibleModuleUtils(module)
    # Create a fake AnsibleModuleUtilsFacts with the created module utils
    module_utils_facts = module.AnsibleModuleUtils.facts(module_utils)

    # Create a fake CmdLineFactCollector object
    c = CmdLineFactCollector(module_utils, module_utils_facts)
    # Create a fake CollectedFacts object
    collected_facts = collector.CollectedFacts(module_utils_facts)
    # Collect the facts
    c

# Generated at 2022-06-20 19:05:53.346997
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    c = CmdLineFactCollector()
    assert c.collect() == {}


# Generated at 2022-06-20 19:06:01.961710
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()

    assert cmdline_fact_collector._get_proc_cmdline() == "root=/dev/mapper/fedora-root ro rd.lvm.lv=fedora/swap rd.lvm.lv=fedora/root rhgb quiet LANG=en_US.UTF-8"


# Generated at 2022-06-20 19:06:02.777578
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    pass

# Generated at 2022-06-20 19:06:05.532638
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector.__class__.name == 'CmdLineFactCollector'


# Generated at 2022-06-20 19:06:15.353693
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_fact = CmdLineFactCollector()
    cmdline_fact._get_proc_cmdline = MagicMock(return_value="foo=bar ansible=awesome")
    cmdline_dict = { 'foo':'bar', 'ansible':'awesome' }
    cmdline_facts = { 'cmdline':cmdline_dict, 'proc_cmdline':cmdline_dict }
    assert(cmdline_facts == cmdline_fact.collect())

# Generated at 2022-06-20 19:06:20.060907
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert 'cmdline' in c.collect()
    assert 'proc_cmdline' in c.collect()

# Generated at 2022-06-20 19:06:24.937778
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Create CmdLineFactCollector object
    obj = CmdLineFactCollector()

    # Check fact_ids
    assert isinstance(obj._fact_ids, set)

# Generated at 2022-06-20 19:06:30.979222
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cm = CmdLineFactCollector()
    data = cm._get_proc_cmdline()
    cmdline_facts = {}
    cmdline_facts['cmdline'] = cm._parse_proc_cmdline(data)
    cmdline_facts['proc_cmdline'] = cm._parse_proc_cmdline_facts(data)
    if 'cmdline' in cmdline_facts and cmdline_facts['cmdline'] is None:
        cmdline_facts.update({'cmdline': {}})
    if 'proc_cmdline' in cmdline_facts and cmdline_facts['proc_cmdline'] is None:
        cmdline_facts.update({'proc_cmdline': {}})
    fact_list = cm.collect()
    assert fact_list == cmdline_facts

# Generated at 2022-06-20 19:06:40.631924
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import tempfile


# Generated at 2022-06-20 19:07:08.924240
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible_collections.netapp.ontap.tests.unit.compat import unittest
    from ansible_collections.netapp.ontap.tests.unit.compat.mock import patch

    mock_file_content = {'/proc/cmdline': 'ansible=true ansible_version=2.7.0 ansible_playbook=setup'
                                         ' ansible_collections=netapp.ontap'}

    class TestCmdLineFactCollector(CmdLineFactCollector):
        def _get_proc_cmdline(self):
            return mock_file_content['/proc/cmdline']


# Generated at 2022-06-20 19:07:17.061235
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    module = {}
    collected_facts = {}
    fake_cmdline = "BOOT_IMAGE=/boot/vmlinuz-2.6.32-358.el6.x86_64 root=UUID=25c21ecf-e5cf-4a74-9eb1-7e0a07b8e8d6 ro crashkernel=auto rhgb quiet LANG=en_US.UTF-8 SYSFONT=latarcyrheb-sun16 KEYBOARDTYPE=pc KEYTABLE=us"

# Generated at 2022-06-20 19:07:23.457245
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    print('+++ unit test for method collect of class CmdLineFactCollector')
    cmdline_fact_collector = CmdLineFactCollector()
    cmdline_facts = cmdline_fact_collector.collect()
    print(cmdline_facts)


# Generated at 2022-06-20 19:07:31.582090
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Create an instance of CmdLineFactCollector
    CmdLineFactCollector_instance = CmdLineFactCollector()
    # Unit test for collect method
    proc_cmdline_result = "console=ttyS0,115200 panic=1 boot_delay=5 loglevel=0"
    CmdLineFactCollector_instance._get_proc_cmdline = lambda: proc_cmdline_result
    # Call the method
    result = CmdLineFactCollector_instance.collect()
    # Verify the results
    assert result['proc_cmdline'] == {'console': 'ttyS0,115200', 'panic': '1', 'boot_delay': '5', 'loglevel': '0'}

# Generated at 2022-06-20 19:07:39.101409
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect(module=None, collected_facts=None)
    assert cmdline_facts.get('proc_cmdline').get('root') == '/dev/disk/by-label/ALTLinux'
    assert cmdline_facts.get('cmdline').get('root') == '/dev/disk/by-label/ALTLinux'

# Generated at 2022-06-20 19:07:41.108104
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_fact_collector = CmdLineFactCollector()
    cmdline_facts = cmdline_fact_collector.collect()
    print(cmdline_facts)


# Generated at 2022-06-20 19:07:48.610915
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()

    # Test no data
    cmdline_collector._get_proc_cmdline = lambda x=None, y=None: ''
    assert cmdline_collector.collect() == {}

    # Test normal gathering
    cmdline_collector._get_proc_cmdline = lambda x=None, y=None: 'foo bar'
    assert cmdline_collector.collect() == {'cmdline': {'foo': True, 'bar': True}, 'proc_cmdline': {'foo': 'bar'}}



# Generated at 2022-06-20 19:07:49.008467
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    pass

# Generated at 2022-06-20 19:07:50.963022
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert not cmd_line_fact_collector._fact_ids
    assert cmd_line_fact_collector.name == 'cmdline'


# Generated at 2022-06-20 19:07:55.637781
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    """Return a CmdLineFactCollector"""
    obj1 = CmdLineFactCollector()
    assert obj1.name == 'cmdline'
    assert obj1._fact_ids == set()
    assert obj1._get_proc_cmdline() == ''
    assert obj1._parse_proc_cmdline('') == {}
    assert obj1._parse_proc_cmdline_facts('') == {}
    assert obj1.collect() == {}

# Generated at 2022-06-20 19:08:39.852986
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'
    assert obj._fact_ids == set()

# Generated at 2022-06-20 19:08:49.657948
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    collected_facts = {}

    # To test CmdLineFactCollector, it needs 2 mocks.
    # Mock get_file_content
    import mock
    mock_get_file_content = mock.Mock()
    mock_get_file_content.return_value = "root=/dev/sda1 ro quiet"
    CmdLineFactCollector._get_proc_cmdline = mock_get_file_content

    # Mock parse_proc_cmdline_facts
    mock_parse_proc_cmdline_facts = mock.Mock()
    mock_parse_proc_cmdline_facts.return_value = {'root': '/dev/sda1', 'ro': True, 'quiet': True}
    CmdLineFactCollector._parse_proc_cmdline_facts = mock_parse_proc_cmdline_facts

    #

# Generated at 2022-06-20 19:08:51.918673
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert isinstance(c._fact_ids, set)

# Generated at 2022-06-20 19:08:54.018237
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'
    assert collector._fact_ids == set()


# Generated at 2022-06-20 19:09:04.862153
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # input data
    cmd_line = "BOOT_IMAGE=/vmlinuz-4.4.0-87-generic root=/dev/mapper/ubuntu--vg-root ro crashkernel=384M-2G:64M,2G-:128M"

    # output data

# Generated at 2022-06-20 19:09:12.151332
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import os
    import json
    from ansible.module_utils.facts import collector

    module_mock = {}
    class_name = 'CmdLineFactCollector'
    cmdline_data = 'BOOT_IMAGE=/vmlinuz-3.2.0-60-generic root=UUID=d1d8f8b9-f979-4dd3-8dbd-f93c27e57b7f ro quiet'
    if collector.FactsCollector.show_deprecation_warning(class_name):
        assert False
    else:
        fixture = os.path.join(os.path.dirname(__file__), 'fixtures')
        files_mock = {'/proc/cmdline': cmdline_data}
        cmdline_collector = CmdLineFactCollector()
        facts_

# Generated at 2022-06-20 19:09:21.356523
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts import dict_to_facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.collectors.cmdline import CmdLineFactCollector
    import textwrap

    CmdLineFactCollector._get_proc_cmdline = lambda self: textwrap.dedent('''\
        BOOT_IMAGE=/vmlinuz-3.13.0-24-generic root=/dev/mapper/ubuntu-root ro quiet splash vt.handoff=7
    ''')
    result = CmdLineFactCollector().collect()
    assert isinstance(result, dict)

# Generated at 2022-06-20 19:09:26.370580
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    ccmdline_fact_collector = CmdLineFactCollector()
    assert isinstance(ccmdline_fact_collector.name, str)
    assert isinstance(ccmdline_fact_collector._fact_ids, set)


# Generated at 2022-06-20 19:09:29.275090
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    fact_collector = CmdLineFactCollector()
    assert fact_collector.name == 'cmdline'
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:09:32.188836
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'


# Generated at 2022-06-20 19:11:06.740904
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_data = 'BOOT_IMAGE=/vmlinuz-3.10.0-693.el7.x86_64 console=ttyS0,115200n8 crashkernel=auto console=ttyS0,115200n8 console=ttyS0,115200n8 crashkernel=256M@64M crashkernel=auto crashkernel=auto fips=1 audit=1'
    c1 = CmdLineFactCollector()
    c1._get_proc_cmdline = lambda: cmdline_data

# Generated at 2022-06-20 19:11:15.929779
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import sys
    import os.path
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collector import BaseFactCollector

    get_file_content_original = get_file_content

    class CmdLineFactCollector(BaseFactCollector):
        name = 'cmdline'
        _fact_ids = set()

        def _get_proc_cmdline(self):
            return get_file_content('/proc/cmdline')

        def _parse_proc_cmdline(self, data):
            cmdline_dict = {}

# Generated at 2022-06-20 19:11:26.498874
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_fact_collector = CmdLineFactCollector()
    cmdline_fact_collector._get_proc_cmdline = lambda: "BOOT_IMAGE=Linux-4.13.0-15-generic-x86_64-with-Ubuntu-16.04-xenial\nro\n"
    cmdline_fact_collector._parse_proc_cmdline = lambda data: data
    cmdline_fact_collector._parse_proc_cmdline_facts = lambda data: data