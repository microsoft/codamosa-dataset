

# Generated at 2022-06-20 19:01:33.830589
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible_collections.ansible.community.tests.unit.modules.utils import set_module_args
    set_module_args({})

    mocker, cmdline_collector = get_cmdline_collector_mock()

    cmdline_collector.collect()

    assert mocker.call_count == 1


# Generated at 2022-06-20 19:01:40.185580
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Get an instance of CmdLineFactCollector
    cmd_line_fact_collector = CmdLineFactCollector()
    cmd_line_fact_collector.collect()

    # Test if an instance of CmdLineFactCollector
    assert isinstance(cmd_line_fact_collector, CmdLineFactCollector)

# Generated at 2022-06-20 19:01:50.496712
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_parser = CmdLineFactCollector()

# Generated at 2022-06-20 19:01:51.522205
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'

# Generated at 2022-06-20 19:01:59.592691
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Test with proc_cmdline
    expected_result = {'proc_cmdline': {'ro': True, 'root': '/dev/mapper/fedora-root',
                                        'rw': True, 'rhgb': True, 'quiet': True}}
    test_data = 'ro root=/dev/mapper/fedora-root rw rhgb quiet'
    cmdline_fact_collector = CmdLineFactCollector()
    assert expected_result == cmdline_fact_collector._parse_proc_cmdline_facts(test_data)

    # Test with cmdline
    expected_result = {'cmdline': {'ro': True, 'root': '/dev/mapper/fedora-root',
                                   'rw': True, 'rhgb': True, 'quiet': True}}

# Generated at 2022-06-20 19:02:09.445857
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """
    Test method collect of class CmdLineFactCollector
    """
    cmdline_fact_collector = CmdLineFactCollector()
    # test collection with content of /proc/cmdline
    cmdline_content = 'root=LABEL=cloudimg-rootfs\n console=ttyS0\n ro intel_iommu=on\n iommu=pt\n net.ifnames=0\n biosdevname=0\n systemd.journald.forward_to_console=1\n console=ttyS0\n console=tty0\n audit=0'
    cmdline_fact_collector._get_proc_cmdline = lambda: cmdline_content
    cmdline_facts = cmdline_fact_collector.collect()

# Generated at 2022-06-20 19:02:10.840156
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector()

# Generated at 2022-06-20 19:02:11.622367
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    pass

# Generated at 2022-06-20 19:02:23.349797
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    proc_cmdline = 'root=UUID=6468aeba-aa6c-47ff-b516-f8fe22bbb803 ro crashkernel=auto resume=/dev/mapper/vg_osp103-lv_swap console=tty0 console=ttyS0,115200n8'
    with open('/proc/cmdline', 'w') as fp:
        fp.write(proc_cmdline)


# Generated at 2022-06-20 19:02:30.493945
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    module = None
    collector = CmdLineFactCollector(module=module)
    collected_facts = {'ansible_os_family': 'RedHat'}
    collector.collect(module=module, collected_facts=collected_facts)
    if not collected_facts['cmdline']:
        raise AssertionError("Failed test_CmdLineFactCollector_collect")

# Generated at 2022-06-20 19:02:37.498865
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = CmdLineFactCollector()
    assert cmdline_facts.collect() == {}

# Generated at 2022-06-20 19:02:40.854233
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cfc = CmdLineFactCollector()
    assert cfc.name == 'cmdline'
    assert cfc._fact_ids == set()

# Generated at 2022-06-20 19:02:50.598106
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    cmdline_facts = collector.collect()

# Generated at 2022-06-20 19:02:54.689498
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector()
    result = cmdline_facts.collect()
    assert result['cmdline'] == {'foo': 'bar', 'baz': True}
    assert result['proc_cmdline'] == {'foo': 'bar', 'baz': True}

# Generated at 2022-06-20 19:02:58.229295
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    test_cmdline = CmdLineFactCollector()
    assert test_cmdline.name == "cmdline"
    assert test_cmdline._fact_ids == set()


# Generated at 2022-06-20 19:03:03.122148
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    """
    Unit test for constructor of class CmdLineFactCollector

    """
    cmdline_facts = CmdLineFactCollector()

    assert 'cmdline' == cmdline_facts.name



# Generated at 2022-06-20 19:03:16.042189
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_mock = 'a=1 b=2 c=3 ansible_concat_files=False ansible_concat_files=True'

    class mock_get_file_content():
        def __init__(self, value):
            self.value = value

        def __call__(self, path):
            return self.value

    module = None
    collected_facts = None
    cl_collector = CmdLineFactCollector()
    assert isinstance(cl_collector, BaseFactCollector)

    cl_collector._get_proc_cmdline = mock_get_file_content(cmdline_mock)

# Generated at 2022-06-20 19:03:25.803375
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector.get_file_content = lambda x: 'rd.neednet=1 ip=192.168.1.1::192.168.1.254:255.255.255.0:testhost:eth0:none BOOTIF=02-00-00-00-00-01'
    cmdline_facts = cmdline_collector.collect()

# Generated at 2022-06-20 19:03:36.565739
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    def _mock_get_file_content(pathname):
        return "rw quiet rootfstype=ext4"

    module = None
    collected_facts = {}

    collector = CmdLineFactCollector(module=module, collected_facts=collected_facts)
    collector._get_proc_cmdline = _mock_get_file_content

    assert collector.collect() == {'cmdline': {'rw': True, 'quiet': True, 'rootfstype': 'ext4'}, 'proc_cmdline': {'rw': True, 'quiet': True, 'rootfstype': 'ext4'}}



# Generated at 2022-06-20 19:03:47.774075
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible_collections.notmintest.not_a_real_collection.tests.unit import ModuleTestCase

    class DummyModule:
        def __init__(self, params):
            self.params = params

    class DummyFiles:
        def __init__(self, files):
            self.files = files

        def __getitem__(self, item):
            return self.files[item]

    class DummyFacts:
        def __init__(self, facts):
            self.facts = facts

        def _collect_subset(self, collector):
            return collector.collect(DummyModule(self.facts[collector.name]))

    # CmdLineFactCollector._get_proc_cmdline() should be able to access
    # proc_cmdline file in order to return its content

# Generated at 2022-06-20 19:04:08.217135
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils import basic

    collected_facts = {
        'cmdline': {
            'foo': 'bar',
            'bar': True,
            'baz': 'True'
        },
        'proc_cmdline': {
            'foo': 'bar',
            'bar': True,
            'baz': ['True', 'True']
        }
    }

    mocked_module = basic.AnsibleModule({})
    mocked_cmdline_content = b'foo=bar bar baz=True baz=True'

    def mocked_get_file_content(path):
        return mocked_cmdline_content

    cmdline_collector = CmdLineFactCollector()
    cmdline_collector.get_file_content = mocked_get_file_content


# Generated at 2022-06-20 19:04:10.033008
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    """Unit test for constructor of class CmdLineFactCollector"""
    assert CmdLineFactCollector().name == "cmdline"


# Generated at 2022-06-20 19:04:13.279116
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    Collector = CmdLineFactCollector()
    assert Collector.name == 'cmdline'
    assert Collector._fact_ids == set()

# Generated at 2022-06-20 19:04:14.840981
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    result = CmdLineFactCollector()
    assert result.name == 'cmdline'

# Generated at 2022-06-20 19:04:27.355953
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import os
    import tempfile
    content = 'var1=foo var2="bar baz" var3 bar=baz'

    file_object = tempfile.NamedTemporaryFile()
    file_object.write(content)
    file_object.flush()

    # pylint: disable=protected-access
    CmdLineFactCollector._fact_ids.clear()
    c = CmdLineFactCollector()
    c._get_proc_cmdline = lambda: file_object.name
    result = c.collect()


# Generated at 2022-06-20 19:04:39.600740
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import sys
    import os
    import pytest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.cmdline import CmdLineFactCollector
    ansible_module = pytest.importorskip('ansible.modules.system.setup')
    from ansible.module_utils.facts.collector import FactsCollector

    collector = CmdLineFactCollector()

# Generated at 2022-06-20 19:04:46.895321
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()

    with open('/proc/cmdline') as file:
        for line in file:
            test_data = line
    collector.content = {
        '/proc/cmdline': test_data,
    }

    test_facts = collector.collect()


    assert type(test_facts) == dict
    assert type(test_facts['cmdline']) == dict
    assert type(test_facts['proc_cmdline']) == dict

# Generated at 2022-06-20 19:04:57.057066
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Create an instance of CmdLineFactCollector and assign it to a local variable
    cmd_line_fact_collector = CmdLineFactCollector()

    cmdline_facts = {}

    data = cmd_line_fact_collector._get_proc_cmdline()

    if not data:
        return cmdline_facts

    cmdline_facts['cmdline'] = cmd_line_fact_collector._parse_proc_cmdline(data)
    cmdline_facts['proc_cmdline'] = cmd_line_fact_collector._parse_proc_cmdline_facts(data)

    return cmdline_facts


# Generated at 2022-06-20 19:05:00.561918
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector is not None
    assert cmdline_collector.name == 'cmdline'

# Generated at 2022-06-20 19:05:08.574782
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """Test whether method collect of class CmdLineFactCollector works."""

    cmdline_fact_collector = CmdLineFactCollector()

    data = CmdLineFactCollector._get_proc_cmdline(cmdline_fact_collector)
    result = CmdLineFactCollector._parse_proc_cmdline(cmdline_fact_collector, data)

# Generated at 2022-06-20 19:05:29.252720
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    x = CmdLineFactCollector()
    assert x.name == 'cmdline'
    assert x._fact_ids == set()


# Generated at 2022-06-20 19:05:37.970161
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    '''
    Test method collect of class CmdLineFactCollector.
    '''
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import FactCollectorCache
    from ansible.module_utils.facts.collector import _get_collector_object

    collector_data = FactCollectorCache(collectors={'TestCollector': 'ansible.module_utils.facts.collector_test.TestFactCollector'})
    facts_data = FactCollector(collector_data)
    facts_data._populate()
    data = _get_collector_object(facts_data, 'cmdline')


# Generated at 2022-06-20 19:05:42.098664
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-20 19:05:43.376929
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()

# Generated at 2022-06-20 19:05:47.052489
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'

# Generated at 2022-06-20 19:05:49.633360
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'
    obj._fact_ids = set()
    assert not obj._fact_ids


# Generated at 2022-06-20 19:05:58.229881
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    from sys import version_info
    if version_info[0] == 2:
        from mock import patch, MagicMock
    else:
        from unittest.mock import patch, MagicMock

    # mock module
    module = MagicMock()

    # mock facts
    collected_facts = {'ansible_collector': 'CmdLineFactCollector'}

    # mock data
    data = 'console=tty0 console=ttyS0,115200 initrd=ansible.img ' \
           'crashkernel=auto LANG=en_US.UTF-8 console=tty0 ' \
           'console=ttyS0,115200 initrd=ansible.img ' \
           'crashkernel=auto LANG=en_US.UTF-8'

    # mock _get_proc_cmdline method

# Generated at 2022-06-20 19:06:07.292747
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    collected_facts = collector.collect()
    # sample collected_facts:
    # {'proc_cmdline': {'i8042.nomux': True, 'i8042.reset': True,
    #                   'i8042.noloop': True, 'BOOT_IMAGE': '/vmlinuz-3.10.0-123.el7.x86_64',
    #                   'LANG': 'en_US.UTF-8', 'BOOTIF': '00-0C-29-66-02-61-D6', 'quiet': True,
    #                   'net.ifnames': '0', 'nofb': True, 'vga': '0x31a', 'initrd': '/initramfs-3.10.0-123.el7.x86_64

# Generated at 2022-06-20 19:06:17.858854
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()
    assert cmdline_fact_collector._get_proc_cmdline() == 'BOOT_IMAGE=/vmlinuz-3.10.0-123.el7.x86_64 root=/dev/mapper/rhel-root ro crashkernel=auto rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet LANG=en_US.UTF-8'


# Generated at 2022-06-20 19:06:21.728756
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()


# Generated at 2022-06-20 19:06:57.447903
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    a = CmdLineFactCollector()
    assert a.name == 'cmdline'


# Generated at 2022-06-20 19:07:00.898452
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdlinefactcollector = CmdLineFactCollector()
    assert cmdlinefactcollector is not None

# Generated at 2022-06-20 19:07:02.886997
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd = CmdLineFactCollector()
    cmd.collect()

# Generated at 2022-06-20 19:07:05.920386
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert cmdline.name == 'cmdline'
    assert cmdline._fact_ids == set()

# Generated at 2022-06-20 19:07:11.546900
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Instantiate CmdLineFactCollector class
    cmdline_fact_collector = CmdLineFactCollector()
    # Check if class variables are initialized properly
    assert cmdline_fact_collector.name == "cmdline"
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:07:14.714758
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    expected = ['cmdline', 'proc_cmdline']
    assert c.collect().keys() == expected

# Generated at 2022-06-20 19:07:16.196904
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'

# Generated at 2022-06-20 19:07:28.829344
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = {}

    # Test data set 1
    data = """
    rw intel_iommu=on
    rd.lvm.lv=fedora/root rd.lvm.lv=fedora/swap rhgb quiet quiet_success=false
    """
    CmdLineFactCollector._parse_proc_cmdline(data)
    cmdline_facts['cmdline'] = CmdLineFactCollector._parse_proc_cmdline(data)
    cmdline_facts['proc_cmdline'] = CmdLineFactCollector._parse_proc_cmdline_facts(data)

# Generated at 2022-06-20 19:07:32.521877
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_fact_collector = CmdLineFactCollector()
    assert len(cmdline_fact_collector.collect()['cmdline']) > 0


# Generated at 2022-06-20 19:07:36.942443
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = CmdLineFactCollector()
    assert cmdline_facts.name == "cmdline"
    assert cmdline_facts._fact_ids == set()


# Generated at 2022-06-20 19:09:07.810890
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ..utils.file import generate_file_content

    collector = CmdLineFactCollector()
    data = 'root=/dev/sda1 ro console=ttyS0,9600n8 console=tty2'

    generate_file_content('/proc/cmdline', data)

    result = collector.collect()

    assert result['cmdline'] == {'root': '/dev/sda1', 'ro': True, 'console': 'tty2'}
    assert result['proc_cmdline'] == {'root': '/dev/sda1', 'ro': True, 'console': ['ttyS0,9600n8', 'tty2']}

# Generated at 2022-06-20 19:09:20.180504
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """ unit tests for function CmdLineFactCollector.collect """
    """
    mock the following files:
    /proc/cmdline
    """
    cmdline_content = 'root=/dev/mapper/vg-root ro rootflags=subvol=@/boot'

    def mock_get_proc_cmdline():
        return cmdline_content

    def mock_parse_proc_cmdline(data):
        cmdline_dict = {}
        for piece in cmdline_content.split(' '):
            item = piece.split('=', 1)
            if len(item) == 1:
                cmdline_dict[item[0]] = True
            else:
                cmdline_dict[item[0]] = item[1]

        return cmdline_dict


# Generated at 2022-06-20 19:09:31.609982
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import os
    import copy
    import json
    import sys
    import stat

    # Build the command line content
    cmdline_value = "ro root=LABEL=/console=tty1 console=ttyS0,115200n8 audit=0 selinux=0 LANG=en_US.UTF-8"

    # Build the expected value of facts

# Generated at 2022-06-20 19:09:40.229231
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """
    Make sure we get a cmdline fact of type dict.
    """
    collector = CmdLineFactCollector()
    cmdline_facts = collector.collect()
    assert isinstance(cmdline_facts, dict)
    assert 'proc_cmdline' in cmdline_facts
    assert 'cmdline' in cmdline_facts
    assert isinstance(cmdline_facts['proc_cmdline'], dict)
    assert isinstance(cmdline_facts['cmdline'], dict)
    for cmdline_fact in cmdline_facts['proc_cmdline']:
        assert isinstance(cmdline_fact, str)
    for cmdline_fact in cmdline_facts['cmdline']:
        assert isinstance(cmdline_fact, str)

# Generated at 2022-06-20 19:09:45.445187
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_collector = CmdLineFactCollector()
    assert cmd_line_collector.name == 'cmdline'
    assert set() == cmd_line_collector._fact_ids



# Generated at 2022-06-20 19:09:49.129172
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd = CmdLineFactCollector()
    assert cmd.name == 'cmdline'
    assert cmd._fact_ids == set(['cmdline', 'proc_cmdline'])

# Generated at 2022-06-20 19:09:53.967626
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    result = collector.collect()

    assert result['cmdline']
    assert result['proc_cmdline']

# Generated at 2022-06-20 19:09:58.101996
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    c = CmdLineFactCollector()
    # Test with valid data
    data = 'root=/dev/mapper/VolGroup00-LogVol00 ro sysrq=1 LANG=en_US.UTF-8 KEYTABLE=us'

# Generated at 2022-06-20 19:10:03.836695
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    '''
    Test case to check if the function returns valid data
    '''
    # Arrange
    cmd_line = CmdLineFactCollector()

    # Act
    cmd_line_facts = cmd_line.collect()

    # Assert
    assert isinstance(cmd_line_facts, dict)
    assert isinstance(cmd_line_facts['cmdline'], dict)
    assert isinstance(cmd_line_facts['proc_cmdline'], dict)

# Generated at 2022-06-20 19:10:05.993354
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert 'cmdline' == cmdline_fact_collector.name
    assert id(set()) == id(cmdline_fact_collector._fact_ids)