

# Generated at 2022-06-20 19:01:29.582325
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_obj = CmdLineFactCollector()
    assert cmdline_obj.name() == 'cmdline'
    assert cmdline_obj.name == 'cmdline'


# Generated at 2022-06-20 19:01:37.905263
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    mocked_cmdline = """
BOOT_IMAGE=/vmlinuz-3.13.0-32-generic
root=/dev/mapper/ubuntu--vg-root ro crashkernel=384M-:128M
quiet splash vt.handoff=7
"""
    mocked_get_file_content = lambda path: mocked_cmdline
    mocked_open = lambda path, mode: open(path, mode)
    mocked_open_context = lambda path, mode: open(path, mode)

    class MockedModule(object):
        pass

    module = MockedModule()

    cmdline_fact_collector = CmdLineFactCollector()
    cmdline_fact_collector._get_proc_cmdline = mocked_get_file_content
    cmdline_fact_collector._open = mocked_open
    cmdline_fact_collect

# Generated at 2022-06-20 19:01:41.465514
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    objCmdLineFactCollector = CmdLineFactCollector()

    # Check instance class
    assert isinstance(objCmdLineFactCollector, BaseFactCollector)

# Generated at 2022-06-20 19:01:51.346613
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    m = CmdLineFactCollector()
    cmdline_facts = m.collect()
    assert cmdline_facts['cmdline'] == {'rd.lvm.lv': 'root', 'console': True, 'ro': True, 'LANG': 'en_US.UTF-8', 'crashkernel': 'auto', 'rd': True, 'rhgb': True, 'root': '/dev/mapper/vg_jamielouis-lv_root', 'quiet': True, 'resume': '/dev/mapper/vg_jamielouis-lv_swap', 'rd.shell': True}

# Generated at 2022-06-20 19:01:59.485434
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # given
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector._get_proc_cmdline = lambda: "BOOT_IMAGE=/vmlinuz-4.4.0-36-generic root=UUID=7fceb2eb-7c8d-4dab-b1f1-bdc7d824b9a9 ro quiet splash vt.handoff=7"

    # when
    cmdline_facts = cmdline_collector.collect()

    # then

# Generated at 2022-06-20 19:02:02.201880
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    test_collector = CmdLineFactCollector()
    assert isinstance(test_collector.name, str)
    assert isinstance(test_collector._fact_ids, set)

# Generated at 2022-06-20 19:02:15.259148
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = dict()
    cmdline_facts['ansible_test_run'] = False

# Generated at 2022-06-20 19:02:22.067366
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    file_data = ''
    with open('/proc/cmdline', 'r') as f:
        file_data = f.read()

    collector = CmdLineFactCollector()
    cmdline_facts = collector.collect()

    assert cmdline_facts['cmdline'] == collector._parse_proc_cmdline(file_data)
    assert cmdline_facts['proc_cmdline'] == collector._parse_proc_cmdline_facts(file_data)


# Generated at 2022-06-20 19:02:33.353010
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import json
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors import CmdLineFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Mock class BaseFactCollector
    class BaseFactCollector(object):
        def __init__(self):
            pass

        def collect(self):
            return {}

    # Mock function get_file_content
    class get_file_content(object):
        def __init__(self):
            pass

        def __call__(self, path):
            return to_bytes('a=5 b=2 c=3')

    # Save references to mocked objects / methods
    BaseFactCollector._collectors

# Generated at 2022-06-20 19:02:35.765568
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'

# Generated at 2022-06-20 19:02:44.211098
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from . import CmdLineFactCollector as CFact

    data = ""
    fact = CFact()
    test_result = fact._parse_proc_cmdline(data)
    assert test_result == {}

    data = "alice=bob"
    test_result = fact._parse_proc_cmdline(data)
    assert test_result == {"alice": "bob"}


# Generated at 2022-06-20 19:02:47.498822
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cl = CmdLineFactCollector()
    assert cl.name == 'cmdline'
    assert len(cl._fact_ids) == 0

# Generated at 2022-06-20 19:02:54.372217
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    module = {}
    collected_facts = {}
    cmdlinefactcollector = CmdLineFactCollector(module, collected_facts)
    assert cmdlinefactcollector.fact_class == 'hardware'
    assert cmdlinefactcollector.fact_subdir == 'cmdline'
    assert cmdlinefactcollector.name == 'cmdline'
    assert cmdlinefactcollector._fact_ids == set()

# Generated at 2022-06-20 19:03:03.322080
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()
    assert cmdline_collector._get_proc_cmdline() == ''
    assert cmdline_collector._parse_proc_cmdline('') == {}
    assert cmdline_collector._parse_proc_cmdline_facts('') == {}
    assert cmdline_collector.collect() == {}
    assert cmdline_collector.collect(collected_facts={}) == {}


# Generated at 2022-06-20 19:03:16.071983
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    with open("test/unit/ansible_collections/k8s/azure/facts/test_data/cmdline_test_data", "r") as file_obj:
        data = file_obj.read()
        with open("/proc/cmdline", "w") as cmdline_obj:
            cmdline_obj.write(data)
    fact_collector = CmdLineFactCollector()
    facts = fact_collector.collect()

# Generated at 2022-06-20 19:03:19.534143
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_dict = cmdline_collector.collect()
    assert cmdline_dict['cmdline']['selinux'] == '0'
    assert cmdline_dict['cmdline']['rd.lvm.lv'] == 'rhel/swap'
    assert cmdline_dict['cmdline']['rd.lvm.lv'] == 'rhel/root'
    assert cmdline_dict['proc_cmdline']['selinux'] == '0'
    assert cmdline_dict['proc_cmdline']['rd.lvm.lv'] == ['rhel/swap', 'rhel/root']

# Generated at 2022-06-20 19:03:26.663406
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    result = collector.collect()

# Generated at 2022-06-20 19:03:27.859720
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    assert 'initrd' in CmdLineFactCollector().collect()['cmdline']

# Generated at 2022-06-20 19:03:31.390505
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert isinstance(CmdLineFactCollector._fact_ids, set)


# Generated at 2022-06-20 19:03:34.481779
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'

# Generated at 2022-06-20 19:03:48.456351
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Load module
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    # Prepare collector
    module.params = {}
    collector = CmdLineFactCollector(module=module)
    # Run collection
    result = collector.collect()
    # Assert results

# Generated at 2022-06-20 19:03:51.042931
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdLineFactCollector = CmdLineFactCollector()
    cmdLineFactCollector.collect()

# Generated at 2022-06-20 19:03:55.530239
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    tf = CmdLineFactCollector()
    assert tf.name == 'cmdline', "Name of the Fact Collector is Incorrect"
    assert tf._fact_ids == set(), "_fact_ids is not empty"
    assert tf._fact_ids == tf.collect()

# Generated at 2022-06-20 19:04:08.030835
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    C = CmdLineFactCollector()
    # Test default case when no kernel arguments are passed and the content of /proc/cmdline is empty
    ret = C.collect()
    assert ret == {'cmdline': {}, 'proc_cmdline': {}}, "Failed to parse /proc/cmdline when it is empty"

    # Test case when kernel arguments are passed
    C._get_proc_cmdline = C._get_proc_cmdline = lambda: 'ro root=/dev/mapper/fedora-root'
    ret = C.collect()

# Generated at 2022-06-20 19:04:14.273457
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # mock facts
    collected_facts = {'ansible_facts': {'ansible_local': {'*': {}}}}

    # mock module
    class Module(object):
        def __init__(self):
            self.params = {}

        def _is_ansible_exit_exception(self, result):
            pass

        def get_bin_path(self, arg, required=True, opt_dirs=[]):
            return 'mock-get-bin-path'

    # mock /proc/cmdline content

# Generated at 2022-06-20 19:04:15.920784
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'


# Generated at 2022-06-20 19:04:19.908454
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector(None)
    assert obj.name == 'cmdline'
    assert obj._fact_ids == set()


# Generated at 2022-06-20 19:04:24.526958
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()

# Generated at 2022-06-20 19:04:29.098276
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    f = CmdLineFactCollector()
    assert f.collect() == f.collect(collected_facts={})
    assert f.collect() == f.collect(collected_facts=None)
    assert f.collect(collected_facts={}) == f.collect(collected_facts=None)


# Generated at 2022-06-20 19:04:37.725891
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    module = CmdLineFactCollector()
    test_data1 = module._get_proc_cmdline()
    test_data2 = module._parse_proc_cmdline_facts(test_data1)
    test_data3 = module._parse_proc_cmdline(test_data1)
    assert test_data2 == test_data3
    test_data4 = module.collect()
    assert test_data4 == {'cmdline': test_data3, 'proc_cmdline': test_data2}

# Generated at 2022-06-20 19:04:47.522403
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    module_args = {'gather_subset': ['cmdline']}
    result_dict = {'ansible_facts': {'cmdline': {'ip': '192.168.73.236'}, 'proc_cmdline': {'ip': '192.168.73.236'}}}
    # mock the update_facts method, but do not call it
    m = mock.patch.object(CmdLineFactCollector, 'collect')
    m.start()
    CmdLineFactCollector.collect(module=None, collected_facts=None)
    assert m.called
    m.stop()

# Generated at 2022-06-20 19:04:58.974173
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    with open('/proc/cmdline', 'r') as f:
        proc_cmdline = f.read()

    cmdline_dict = {}
    proc_cmdline_dict = {}

    try:
        for piece in shlex.split(proc_cmdline, posix=False):
            item = piece.split('=', 1)
            if len(item) == 1:
                cmdline_dict[item[0]] = True
            else:
                cmdline_dict[item[0]] = item[1]
    except ValueError:
        pass


# Generated at 2022-06-20 19:05:05.767410
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # arrange
    module_mock, CmdLineFactCollector_mock = get_CmdLineFactCollector_mock()

    # act
    collector = CmdLineFactCollector_mock(module=module_mock)
    facts = collector.collect()

    # assert
    assert facts['cmdline'] == {'rw': True}
    assert facts['proc_cmdline'] == {'rw': True}

# get mocks for class CmdLineFactCollector

# Generated at 2022-06-20 19:05:09.899296
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert cmdline.name == 'cmdline'
    assert cmdline._fact_ids == set()

# Generated at 2022-06-20 19:05:19.196255
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    test_param = {
        'module': None,
        'collected_facts': None,
    }

    test_return = {
        'cmdline': {'console': 'ttyS0,115200', 'nfsroot': '/nfsroot'},
        'proc_cmdline': {'console': 'ttyS0,115200', 'nfsroot': '/nfsroot'}
    }

    test_object = CmdLineFactCollector()

    def get_file_content_fake(path):
        return 'console=ttyS0,115200 nfsroot=/nfsroot'

    def get_file_content_fake_case2(path):
        return 'console=ttyS0,115200 nfsroot=/nfsroot console=ttyS1,115200'


# Generated at 2022-06-20 19:05:26.844760
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    fact = collector.collect()
    assert fact == {
        'cmdline': {
            u'sysrq': True,
            u'ro': True,
            u'init': u'/usr/lib/systemd/systemd',
            u'root': u'/dev/mapper/centos-root',
            u'rhgb': True,
            u'quiet': True
        },
        'proc_cmdline': {
            u'sysrq': True,
            u'ro': True,
            u'init': u'/usr/lib/systemd/systemd',
            u'root': [u'/dev/mapper/centos-root', u'/dev/sda1'],
            u'rhgb': True,
            u'quiet': True
        }
    }

# Generated at 2022-06-20 19:05:37.218418
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils._text import to_bytes
    import platform
    import PortablePython
    import sys
    import sysconfig

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestCmdLineFactCollector(unittest.TestCase):
        def _get_test_data(self, filename):
            from os.path import dirname, join
            data_path = join(dirname(__file__), "unit", "ansible_facts", "data", filename)
            return open(data_path, "rb").read()


# Generated at 2022-06-20 19:05:39.105465
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'

# Generated at 2022-06-20 19:05:47.892584
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_fact = CmdLineFactCollector()
    assert cmdline_fact.collect() == {
        'cmdline': {'root': '/dev/sda4', 'ro': True, 'vga': 'normal', 'initrd': '/boot/initramfs-linux-fallback.img', 'linux': '/boot/vmlinuz-linux-lts', 'nomodeset': True},
        'proc_cmdline': {'root': '/dev/sda4', 'ro': True, 'vga': 'normal', 'initrd': '/boot/initramfs-linux-fallback.img', 'linux': '/boot/vmlinuz-linux-lts', 'nomodeset': True}
    }

# Generated at 2022-06-20 19:05:53.595015
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Initialize the object
    cmdline_obj = CmdLineFactCollector()
    # Run the collect method
    result = cmdline_obj.collect()
    # Check if the result is a dict
    assert isinstance(result, dict) == True
    # Check if the result is empty
    assert not result

# Generated at 2022-06-20 19:06:02.556089
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line = CmdLineFactCollector()
    assert cmd_line.name == "cmdline"
    assert cmd_line._fact_ids == set(['cmdline', 'proc_cmdline'])


# Generated at 2022-06-20 19:06:04.789500
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.collect_fn
    assert c.name == 'cmdline'

# Generated at 2022-06-20 19:06:18.103467
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Mock the get_file_content method of BaseFactCollector
    get_file_content_orig = BaseFactCollector.get_file_content
    BaseFactCollector.get_file_content = lambda _, path: b'\x00foo=bar baz=quux'

    # Mock the shlex.split method.
    shlex_split_orig = shlex.split

    def mock_shlex_split(data, posix=False):
        """
        This test-specific method splits the input data by space into a list
        of key-value pairs.
        """
        pairs = data.split(b' ')

        # Return the list of pairs
        return pairs

    shlex.split = mock_shlex_split

    # Instantiate the collector class.
    collector = CmdLineFactCollector()

    # Collect

# Generated at 2022-06-20 19:06:29.246423
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Build test data 
    test_data = "BOOT_IMAGE=/boot/vmlinuz-3.13.0-61-generic.efi.signed root=UUID=c25b7728-d304-4063-afb1-667557ea742e ro quiet splash vt.handoff=7"

    # Build expected result

# Generated at 2022-06-20 19:06:31.656625
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    facts = CmdLineFactCollector()
    assert facts.name == 'cmdline'


# Generated at 2022-06-20 19:06:34.141532
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'


# Generated at 2022-06-20 19:06:39.451241
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line = """key1=value1 key2=value2 key3 key4= """
    cmd_line_facts = CmdLineFactCollector().collect()
    assert cmd_line_facts['cmdline'] == {'key1': 'value1', 'key2': 'value2', 'key3': True, 'key4': ''}
    assert cmd_line_facts['proc_cmdline'] == {'key1': 'value1', 'key2': 'value2', 'key3': True, 'key4': ''}

# Generated at 2022-06-20 19:06:43.807551
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-20 19:06:48.884935
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert cmdline.name == 'cmdline'
    assert cmdline._fact_ids == set()

    cmdline = CmdLineFactCollector({'my_option': 'my_value'})
    assert cmdline.name == 'cmdline'
    assert cmdline._fact_ids == set()

# Generated at 2022-06-20 19:06:52.939949
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-20 19:07:04.900498
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector.priority == 190

# Generated at 2022-06-20 19:07:16.898574
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import tempfile
    temp_file = tempfile.NamedTemporaryFile()
    temp_file.write('BOOT_IMAGE=/vmlinuz-3.10.0-957.1.3.el7.x86_64 root=/dev/mapper/centos-root ro rd.lvm.lv=centos/root rd.lvm.lv=centos/swap console=ttyS0,115200n8 LANG=en_US.UTF-8 vconsole.font=latarcyrheb-sun16 vconsole.keymap=us audit=1')
    temp_file.seek(0)

    from ansible.module_utils.facts import ModuleUtilsLegacyFacts
    from ansible.module_utils.facts import FactsCollector
    from ansible.module_utils.facts.collectors import C

# Generated at 2022-06-20 19:07:29.770916
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    #
    # Create a mock module and an instance of CmdLineFactCollector.
    #
    cmdline_collector = CmdLineFactCollector()

    #
    # Override the _get_proc_cmdline method of CmdLineFactCollector to return
    # a known value to avoid depending on the content of /proc/cmdline.
    #
    def mocked_get_proc_cmdline(self):
        return "foo=bar root=/dev/mapper/vg_redhat-lv_root ro quiet LANG=en_US.UTF-8 audit=1"

    cmdline_collector._get_proc_cmdline = mocked_get_proc_cmdline

    #
    # Call the collect method of CmdLineFactCollector and check the result.
    #
    result = cmdline_collector.collect()


# Generated at 2022-06-20 19:07:34.609612
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    from ansible.module_utils.facts import collector

    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert isinstance(c, collector.BaseFactCollector)


# Generated at 2022-06-20 19:07:38.452578
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Given a CmdLineFactCollector instance
    c = CmdLineFactCollector()

    # When I run the collect method
    # Then I should get a cmdline facts
    assert c.collect()['cmdline']['root'] == '/dev/sda1'

# Generated at 2022-06-20 19:07:49.728120
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Test with non-existent /proc/cmdline file
    mock_module = Mock(params={})
    mock_collected_facts = {'ansible_architecture': 'mock_architecture'}
    cmdline_collector = CmdLineFactCollector(mock_module, mock_collected_facts)

    mock_get_file_content = Mock(return_value="")
    cmdline_collector._get_proc_cmdline = mock_get_file_content

    assert cmdline_collector.collect() == {'cmdline': {}, 'proc_cmdline': {}}

    # Test with existing /proc/cmdline file
    # Note: Below sample data is collected on a Ubuntu machine.
    # This data is not syntactically correct.
    # The method shlex.split() is used to parse data in

# Generated at 2022-06-20 19:07:50.893953
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'

# Generated at 2022-06-20 19:07:57.784007
# Unit test for method collect of class CmdLineFactCollector

# Generated at 2022-06-20 19:08:00.612204
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    _cmdline_fact_collector = CmdLineFactCollector()
    assert _cmdline_fact_collector.name == 'cmdline'


# Generated at 2022-06-20 19:08:09.971399
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    proc_cmdline_facts = {'BOOT_IMAGE': '/kernel',
                          'param1': 'value1',
                          'param2': 'value2',
                          'param3': 'value3',
                          'param4': 'value4',
                          'param5': 'value5',
                          'param6': 'value6',
                          'param7': 'value7',
                          'param8': 'value8',
                          'param9': 'value9',
                          'param10': 'value10',
                          'param11': 'value11'}

# Generated at 2022-06-20 19:08:39.482245
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Instantiate CmdLineFactCollector
    cf = CmdLineFactCollector()
    # The following call can't be mocked in tests, but in the real world it is
    # mocked by Ansible because this method will be called when we run ansible
    # cmdline, so that's ok.
    cmdline_facts = cf.collect()

    assert cmdline_facts['cmdline']['rd.md.uuid'] == 'ee62e07a:43b2f260:b8c9a079:bde6f2d7'
    assert cmdline_facts['cmdline']['ro']
    assert cmdline_facts['cmdline']['root'] == '/dev/mapper/vg_test-lv_root'


# Generated at 2022-06-20 19:08:42.179854
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector is not None

# Unit test to test _get_proc_cmdline()

# Generated at 2022-06-20 19:08:44.094255
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert cmdline is not None

# Test class CmdLineFactCollector

# Generated at 2022-06-20 19:08:46.616356
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert(c.name == 'cmdline')
    assert('cmdline' not in c._fact_ids)

# Generated at 2022-06-20 19:08:50.236837
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    cmdline_facts = cmdline_fact_collector.collect()
    assert 'cmdline' in cmdline_facts
    assert 'proc_cmdline' in cmdline_facts


# Generated at 2022-06-20 19:08:52.520333
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    fact_collector = CmdLineFactCollector()
    assert fact_collector.name == 'cmdline'
    assert isinstance(fact_collector._fact_ids, set)

# Generated at 2022-06-20 19:08:59.258851
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    import os
    import mock
    import base64
    import tempfile
    from ansible.module_utils.facts import collector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.utils

    # Set up a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, mode='w')

    # Set the contents of the temporary file
    temp_file.write('temp_content')
    temp_file.flush()

    # Mock the is_file method
    with mock.patch('os.path.isfile') as mock_is_file:
        mock_is_file.return_value = True

# Generated at 2022-06-20 19:09:01.723962
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
   x=CmdLineFactCollector()
   assert x.name == 'cmdline'



# Generated at 2022-06-20 19:09:10.007043
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    from ansible.module_utils.facts.collector.cmdline import CmdLineFactCollector

    cmdline_data = b"""ro root=/dev/sda1 biosdevname=0 net.ifnames=0 ipv6.disable=1 consoleblank=0 cgroup_enable=memory swaps= partition=LABEL=ROOT nouveau.modeset=0 rhgb quiet LANG=en_US.UTF-8 net.ifnames=0 biosdevname=0"""

    cmdline_facts = {}

# Generated at 2022-06-20 19:09:13.293683
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'
    assert collector.collect()


# Generated at 2022-06-20 19:10:02.387793
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdLineFactCollector_obj = CmdLineFactCollector()
    assert callable(getattr(cmdLineFactCollector_obj, 'collect', None)), "CmdLineFactCollector does not implement method 'collect'"

# Generated at 2022-06-20 19:10:11.783806
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    cmdline_facts = collector.collect()
    assert cmdline_facts['cmdline']['BOOT_IMAGE'] == '/boot/vmlinuz-4.4.0-31-generic'
    assert cmdline_facts['cmdline']['root'] == '/dev/mapper/sda1_crypt'
    assert cmdline_facts['proc_cmdline']['BOOT_IMAGE'] == '/boot/vmlinuz-4.4.0-31-generic'
    assert cmdline_facts['proc_cmdline']['root'] == '/dev/mapper/sda1_crypt'

# Generated at 2022-06-20 19:10:16.865814
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """Unit test for method collect of class CmdLineFactCollector.
    """

    from ansible.module_utils.facts.collector import TestFactCollector

    TestFactCollector.test_collect(CmdLineFactCollector, 'cmdline')

# Generated at 2022-06-20 19:10:25.232026
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Fake class
    class FakeCmdLineFactCollector():
        name = 'cmdline'
        _fact_ids = set()
        def _get_proc_cmdline(self):
            return 'BOOT_IMAGE=/boot/vmlinuz-3.10.0-327.18.2.el7.x86_64 root=UUID=c0358dbe-28e0-4f1e-98d2-8a49c0e9e09a ro crashkernel=auto rhgb quiet LANG=en_US.UTF-8'

        def _parse_proc_cmdline(self, data):
            cmdline_dict = {}

# Generated at 2022-06-20 19:10:33.298357
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    c = CmdLineFactCollector()
    cmdline_facts = c.collect()

    assert cmdline_facts is not None and isinstance(cmdline_facts, dict)
    assert len(cmdline_facts) == 2
    assert cmdline_facts['cmdline'] is not None and isinstance(cmdline_facts['cmdline'], dict)
    assert len(cmdline_facts['cmdline']) > 0
    assert cmdline_facts['proc_cmdline'] is not None and isinstance(cmdline_facts['proc_cmdline'], dict)
    assert len(cmdline_facts['proc_cmdline']) == len(cmdline_facts['cmdline'])


# Generated at 2022-06-20 19:10:43.652710
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()

    content = b"BOOT_IMAGE=/vmlinuz-3.10.0-862.14.4.el7.x86_64 root=/dev/mapper/rhel-root ro crashkernel=auto rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet LANG=en_US.UTF-8"


# Generated at 2022-06-20 19:10:46.535146
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    my_obj = CmdLineFactCollector()
    assert my_obj.name == 'cmdline'


# Generated at 2022-06-20 19:10:54.463374
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    test_obj = CmdLineFactCollector()
    test_obj._get_proc_cmdline = lambda: 'option random=true option2=more random'
    test_obj._parse_proc_cmdline = lambda x: {'random': 'true', 'option2': 'more'}
    test_obj._parse_proc_cmdline_facts = lambda x: {'random': 'true', 'option2': 'more'}
    result = test_obj.collect()
    assert result == {
        'cmdline': {'random': 'true', 'option2': 'more'},
        'proc_cmdline': {'random': 'true', 'option2': 'more'},
    }


# Generated at 2022-06-20 19:10:58.243658
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    factcollector = CmdLineFactCollector()
    assert factcollector.name == 'cmdline'
    assert factcollector._fact_ids == set()


# Generated at 2022-06-20 19:11:06.631313
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    class MockModule(object):
        pass

    module = MockModule()
    module.params = {}

    cmdline_facts = CmdLineFactCollector().collect(module=module, collected_facts={})

    assert 'cmdline' in cmdline_facts
    assert 'proc_cmdline' in cmdline_facts

    assert isinstance(cmdline_facts['cmdline'], dict)
    assert isinstance(cmdline_facts['proc_cmdline'], dict)

    # This is the content of /proc/cmdline on a system without any kernel
    # parameter defined.
    assert cmdline_facts['cmdline'] == {}
    assert cmdline_facts['proc_cmdline'] == {}

    # Test command line with the following parameters:
    #
    # root=/dev/mapper/vg0-root ro centos.automount