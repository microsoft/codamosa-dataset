

# Generated at 2022-06-20 19:01:34.423208
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()

    collector.get_file_content = lambda path: 'vga=0 some_param=value some_param=value2'

    res = collector.collect()

    assert res == {'cmdline': {'vga': '0', 'some_param': 'value2'}, 'proc_cmdline': {'vga': '0', 'some_param': ['value', 'value2']}}

# Generated at 2022-06-20 19:01:36.978626
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = CmdLineFactCollector()
    assert cmdline_facts is not None

# Generated at 2022-06-20 19:01:38.334834
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()

# Generated at 2022-06-20 19:01:41.591253
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    theCmdLineFactCollector = CmdLineFactCollector()
    print(theCmdLineFactCollector)


# Generated at 2022-06-20 19:01:43.340161
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'

# Generated at 2022-06-20 19:01:55.903608
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import io
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collectors.cmdline import CmdLineFactCollector

    # Mock class for get_file_content
    class MockFileInput:
        def __init__(self, data):
            self.data = data

        def read(self):
            return self.data

    # Create a mock and replace the original get_file_content
    def mock_get_file_content(filename):
        return MockFileInput('foo=bar biz=boz somearg')

    # Replace the original
    get_file_content = mock_get_file_content

    # Add this collector to the module
    fact_collector = CmdLineFactCollector()

# Generated at 2022-06-20 19:01:57.259685
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cfc = CmdLineFactCollector()
    assert cfc.name == 'cmdline'

# Generated at 2022-06-20 19:02:02.913660
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Expected data
    data = """
    root=/dev/sda1 rootflags=subvol=@ \
    BOOT_IMAGE=/vmlinuz-3.10.0-327.el7.x86_64 \
    root=/dev/mapper/rhel-root ro crashkernel=auto rd.lvm.lv=rhel/root \
    rd.lvm.lv=rhel/swap rhgb quiet LANG=en_US.UTF-8 \
    MODE=4
    """

# Generated at 2022-06-20 19:02:06.072427
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'

# Generated at 2022-06-20 19:02:07.418462
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()


# Generated at 2022-06-20 19:02:16.075894
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert isinstance(collector, BaseFactCollector)
    assert collector.name == 'cmdline'
    assert collector._fact_ids == set()


# Generated at 2022-06-20 19:02:18.826785
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()

# Generated at 2022-06-20 19:02:21.989061
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert not cmdline_collector._fact_ids


# Generated at 2022-06-20 19:02:24.704427
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collect_method = CmdLineFactCollector().collect
    assert collect_method({}, {}) == {}

# Generated at 2022-06-20 19:02:32.466504
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    data1 = 'root=/dev/mapper/vg-lv quiet componentfoo=bar componentbar=baz'

    f = CmdLineFactCollector()
    f.collect() == {
        'cmdline': {'componentbar': 'baz', 'componentfoo': 'bar', 'quiet': True, 'root': '/dev/mapper/vg-lv'},
        'proc_cmdline': {'componentbar': 'baz', 'componentfoo': 'bar', 'quiet': True, 'root': '/dev/mapper/vg-lv'}
    }

# Generated at 2022-06-20 19:02:44.172812
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = {
                   "cmdline": {
                       "BOOT_IMAGE": "/vmlinuz-4.4.0-53-generic.efi.signed",
                       "console": "console=tty1 initrd=/install/initrd.gz"
                       },
                   "proc_cmdline": {
                       "BOOT_IMAGE": ["/vmlinuz-4.4.0-53-generic.efi.signed", "/vmlinuz-4.4.0-53-generic.efi.signed.1"],
                       "console": ["console=tty1", "console=tty7", "console=tty1 initrd=/install/initrd.gz"]
                       }
                   }

    cmdline_collector = CmdLineFactCollector()

# Generated at 2022-06-20 19:02:56.324163
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """
    generate an instance of the CmdLineFactCollector.
    This instance will be called with its collect method
    in order to test its behaviour
    """
    CFL=CmdLineFactCollector()
    # Here you have the oportunity to insert code needed for
    # your tests
    #
    # The following examples are provided:
    #
    # retrieve contents of /proc/cmdline and print it out
    #   data = CFL._get_proc_cmdline()
    #   print('data: %s' % data)
    #
    # parse the contents of /proc/cmdline and print out the
    # data structure returned using the _parse_proc_cmdline method
    #   data = CFL._get_proc_cmdline()
    #   cmdline_dict = CFL._parse_proc_cmdline(data)
   

# Generated at 2022-06-20 19:02:57.945477
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert cmdline.name == 'cmdline'
    assert cmdline._fact_ids == set()


# Generated at 2022-06-20 19:03:00.794864
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    CmdLineFactCollector().collect()

# Generated at 2022-06-20 19:03:02.680456
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert(collector.name == 'cmdline')

# Generated at 2022-06-20 19:03:14.646386
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    """Test constructor of class CmdLineFactCollector."""

    cmdline_fact_collector = CmdLineFactCollector()

    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:03:19.635002
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:03:22.630702
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'
    assert collector._fact_ids == set()

# Generated at 2022-06-20 19:03:24.709262
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert isinstance(CmdLineFactCollector(), CmdLineFactCollector)


# Generated at 2022-06-20 19:03:37.589533
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    # Create a test instance of the class
    test_collector = CmdLineFactCollector()

    # Create a mock content for /proc/cmdline
    cmdline = 'root=/dev/hda1 ro quiet splash'

    # Mock the get_file_content method of the test instance to return the mock
    # content.
    test_collector.get_file_content = lambda path: cmdline

    # Execute the collect method
    facts = test_collector.collect()

    # Assert the facts returned have the expected content
    assert facts['cmdline'] == {'root': '/dev/hda1', 'ro': True, 'quiet': True,
                                'splash': True}

# Generated at 2022-06-20 19:03:48.189108
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    '''
    Test class CmdLineFactCollector
    '''
    test_system = 'mytest'
    test_module = 'mymodule'
    test_facts = {'kernel': 'Linux', 'system': test_system}

    test_collector = CmdLineFactCollector('test', {}, test_system, test_module, test_facts)
    test_data = test_collector.collect()

    assert test_data['cmdline'] == {'BOOT_IMAGE': '/boot/kernel-4.19.2', 'rd.driver.pre': 'vboxdrv', 'console': 'tty1', 'vt.handoff': '7', 'quiet': True}

# Generated at 2022-06-20 19:03:59.588337
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    from ansible.module_utils.facts import collector

    collector._COLLECTORS['cmdline'] = CmdLineFactCollector

    modules_mock = {}
    collected_facts_mock = {}
    cmdline_collector = CmdLineFactCollector()

    cmdline_collector._get_proc_cmdline = lambda: "BOOT_IMAGE=/vmlinuz-3.10.0-693.17.1.el7.x86_64 root=/dev/mapper/centos_myos-root ro crashkernel=auto rd.lvm.lv=centos_myos/root rd.lvm.lv=centos_myos/swap  rhgb quiet LANG=en_US.UTF-8"

# Generated at 2022-06-20 19:04:00.919586
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector().name == 'cmdline'

# Generated at 2022-06-20 19:04:06.985958
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Method collect will return the content of /proc/cmdline
    cfg = CmdLineFactCollector()
    with open('/proc/cmdline', 'r') as f:
        cmd_line = f.read()
    assert cfg.collect().get('proc_cmdline') == CmdLineFactCollector()._parse_proc_cmdline_facts(cmd_line)


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-20 19:04:11.291698
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """
    Unit test for method collect
    """
    cmdline_collector = CmdLineFactCollector()

    cmdline_facts = cmdline_collector.collect()

    # unit tests will be added in future

# Generated at 2022-06-20 19:04:32.332391
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'
    assert obj._fact_ids == set()

# Generated at 2022-06-20 19:04:41.299765
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():

    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance

    cmdline_facts = AnsibleCollector(CmdLineFactCollector('cmdline'), None)
    assert isinstance(cmdline_facts, AnsibleCollector)
    assert isinstance(cmdline_facts, BaseFactCollector)
    assert isinstance(cmdline_facts, CmdLineFactCollector)

    data = cmdline_facts._get_proc_cmdline()
    assert isinstance(data, str)

    cmdline_dict = cmdline_facts._parse_proc_cmdline(data)
    assert isinstance(cmdline_dict, dict)

    cmdline_dict_facts

# Generated at 2022-06-20 19:04:48.230478
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    cmdline_file_content = '''
BOOT_IMAGE=/boot/vmlinuz-4.14.35-1-lts root=UUID=168d0b71-7968-4c0b-9457-bbebd2a3380b ro quiet console=tty0 console=ttyS0,115200n8
'''

    cmd_line_instance = CmdLineFactCollector()

    def mock_get_file_content(file_path):
        return cmdline_file_content

    cmd_line_instance._get_proc_cmdline = mock_get_file_content


# Generated at 2022-06-20 19:04:49.891842
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    assert not CmdLineFactCollector.collect()

# Generated at 2022-06-20 19:04:54.862058
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """
    Unit test for method collect of class CmdLineFactCollector
    """
    # cmdline_out contains  a string with kernel command line output
    # This can be saved to a temporary file and mocked by set_until_return
    # from ansible.module_utils.facts.utils.get_file_content
    cmdline_out = ("BOOT_IMAGE=/boot/kernel root=UUID=4a65ffc6-5c86-4fc6-924d-5d2dacf1c2b6"
                   " ro rhgb quiet")
    cmdline_facts = CmdLineFactCollector().collect()

    assert cmdline_facts['cmdline']['BOOT_IMAGE'] == '/boot/kernel'

# Generated at 2022-06-20 19:04:58.219254
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    instance = CmdLineFactCollector({})
    assert instance is not None


# Generated at 2022-06-20 19:05:05.773819
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts import Facts

    ans_module = None
    ans_collected_facts = Facts({})
    ans_cmdline_facts = {}

    data = """root=UUID=4aa850b6-4440-4451-b4e1-694a9f947b6a   rootflags=rw,relatime,data=ordered  rd.lvm.lv=vg0/swap_1  rd.lvm.lv=vg0/root  rhgb  quiet  LANG=en_US.UTF-8   selinux=0  """

    cmdline_facts = CmdLineFactCollector().collect(ans_module, ans_collected_facts)

# Generated at 2022-06-20 19:05:15.579050
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    FACT_DATA = {'cmdline': {'BOOT_IMAGE': '/vmlinuz-2.6.32-5-amd64', 'console': 'console=tty0 console=ttyS0,115200n8'}, 'proc_cmdline': {'BOOT_IMAGE': '/vmlinuz-2.6.32-5-amd64', 'console': 'console=tty0 console=ttyS0,115200n8'}}
    f = CmdLineFactCollector()
    assert f.collect() == FACT_DATA


# Generated at 2022-06-20 19:05:25.788159
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    class my_module:
        pass

    class my_collected_facts:
        pass

    my_collected_facts.ansible_cmdline = my_module()

    class TestFactory(object):
        def __init__(self, *args, **kargs):
            pass

        def load_module(self, mod_name, module_path):
            assert mod_name == 'shlex'
            assert module_path == '/usr/lib/python2.7/shlex.pyc'
            return shlex

    my_module.__name__ = 'ansible.module_utils.facts.linux.system.CmdLineFactCollector'
    my_module.TestFactory = TestFactory

    def get_file_content(path):
        assert path == '/proc/cmdline'

# Generated at 2022-06-20 19:05:29.254258
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    instance = CmdLineFactCollector()
    assert isinstance(instance, CmdLineFactCollector)


# Generated at 2022-06-20 19:06:08.304335
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()
    assert isinstance(CmdLineFactCollector._fact_ids, set)

# Generated at 2022-06-20 19:06:11.529205
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.__name__ == 'CmdLineFactCollector'

# Generated at 2022-06-20 19:06:15.916479
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline = CmdLineFactCollector()

    cmdline._get_proc_cmdline = lambda : "BOOT_IMAGE=/boot/vmlinuz-4.4.0-1020-aws root=LABEL=cloudimg-rootfs ro console=ttyS0 net.ifnames=0 biosdevname=0"


# Generated at 2022-06-20 19:06:19.986654
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector._get_proc_cmdline() == ''

# Generated at 2022-06-20 19:06:23.261507
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'
    assert collector._fact_ids == set()


# Generated at 2022-06-20 19:06:30.807164
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Create a mock object (C) for class CmdLineFactCollector
    class C:
        # This is the mocked method for method _get_proc_cmdline of class CmdLineFactCollector
        def _get_proc_cmdline(self):
            return 'abc=123'

        # This is the mocked method for method _parse_proc_cmdline of class CmdLineFactCollector
        def _parse_proc_cmdline(self, data):
            return data

        # This is the mocked method for method _parse_proc_cmdline_facts of class CmdLineFactCollector
        def _parse_proc_cmdline_facts(self, data):
            return data

    # Instantiate the mock object
    c = C()

    # Instantiate the class CmdLineFactCollector
    actual = CmdLineFactCollector().collect

# Generated at 2022-06-20 19:06:34.345278
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    a = CmdLineFactCollector()
    assert a._fact_ids == set()
    assert a.name == 'cmdline'
    assert a.collect() == {}

# Generated at 2022-06-20 19:06:36.350033
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'

# Generated at 2022-06-20 19:06:48.781606
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts import gather_subset

    class CmdLineCollector(object):
        def __init__(self, content):
            self.content = content

        def get_file_content(self, path):
            return self.content

        def get_cmdline_facts(self):
            return {}

        def get_subset(self, subset):
            return gather_subset(subset)

        def update_facts(self, facts):
            return facts

    def if_err_then_ret(cmd, ret):
        # We do not want to limit this unit test to the data of the local
        # machine, so here we always return given ret
        return ret


# Generated at 2022-06-20 19:06:53.437952
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert isinstance(cmdline_fact_collector, CmdLineFactCollector)


# Generated at 2022-06-20 19:08:12.117680
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    fc = CmdLineFactCollector()
    output = fc.collect()
    assert output == {'cmdline': {'quiet': True, 'ro': True, 'splash': True, 'vga': '0x318'},
                      'proc_cmdline': {'quiet': True, 'ro': True, 'splash': True, 'vga': '0x318'}}

# Generated at 2022-06-20 19:08:15.792334
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    result = cmdline_collector.collect()
    assert isinstance(result, dict)

    assert 'cmdline' in result
    assert 'proc_cmdline' in result

# Generated at 2022-06-20 19:08:18.227088
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_coll = CmdLineFactCollector()
    assert cmdline_coll.name == 'cmdline'

# Generated at 2022-06-20 19:08:19.317096
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector().name == 'cmdline'

# Generated at 2022-06-20 19:08:20.039165
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector()

# Generated at 2022-06-20 19:08:26.266900
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import os
    from ansible.module_utils.facts.utils import FactsFiles

    test_data = 'root=/dev/sda1 console=ttyS0,9600'
    test_file = FactsFiles().get_file_path('/proc/cmdline')
    open(test_file, 'w').close()

# Generated at 2022-06-20 19:08:28.489107
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    a = CmdLineFactCollector()

# Generated at 2022-06-20 19:08:29.263366
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    pass

# Generated at 2022-06-20 19:08:31.547558
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()

    assert obj.name == 'cmdline'
    assert isinstance(obj, CmdLineFactCollector)


# Generated at 2022-06-20 19:08:38.757063
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    fc = CmdLineFactCollector()
    # set the /proc/cmdline content.
    fc._get_proc_cmdline = lambda: "BOOT_IMAGE=/vmlinuz-4.4.0-133-generic.efi.signed " \
                                   "root=/dev/mapper/ubuntu--vg-root ro " \
                                   "quiet splash vt.handoff=7"

    data = fc.collect()
