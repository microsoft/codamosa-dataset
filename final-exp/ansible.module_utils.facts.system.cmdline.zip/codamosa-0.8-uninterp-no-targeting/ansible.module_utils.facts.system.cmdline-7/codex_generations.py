

# Generated at 2022-06-20 19:01:32.142445
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'
    assert collector._fact_ids == set()


# Generated at 2022-06-20 19:01:36.216592
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    c = CmdLineFactCollector()
    output = c.collect()
    assert output == {'cmdline': {'key1': 'value1'}, 'proc_cmdline': {'key1': 'value1'}}

# Generated at 2022-06-20 19:01:45.807513
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector is not None
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids is not None
    assert cmdline_collector._fact_ids == set()
    assert cmdline_collector._get_proc_cmdline()
    assert cmdline_collector._parse_proc_cmdline('root=LABEL=cloudimg-rootfs ro console=tty0 console=ttyS0,115200n8') == {'root': 'LABEL=cloudimg-rootfs', 'ro': True, 'console': 'ttyS0,115200n8'}

# Generated at 2022-06-20 19:01:49.992801
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
        obj = CmdLineFactCollector()
        cmdline_facts = obj.collect(collected_facts=None)
        return cmdline_facts


# Generated at 2022-06-20 19:01:58.863316
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_facts = cmdline_collector.collect()

    assert cmdline_facts['cmdline']['ro'] == True
    assert cmdline_facts['cmdline']['root'] == '/dev/mapper/centos-root'
    assert cmdline_facts['cmdline']['rhgb'] == True
    assert cmdline_facts['cmdline']['quiet'] == True
    assert cmdline_facts['cmdline']['initrd'] == '/initramfs-3.10.0-862.el7.x86_64.img'
    assert cmdline_facts['cmdline']['LANG'] == 'en_US.UTF-8'
    assert cmdline_facts['cmdline']['crashkernel'] == 'auto'


# Generated at 2022-06-20 19:02:01.945188
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    collected_facts = collector.collect()
    assert collected_facts == {'cmdline': {},
                               'proc_cmdline': {}}

# Generated at 2022-06-20 19:02:05.398742
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact = CmdLineFactCollector()
    assert cmdline_fact.name == 'cmdline'

# Generated at 2022-06-20 19:02:08.478843
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """Unit test for method collect of class CmdLineFactCollector"""
    collector = CmdLineFactCollector()

    collector.collect()

# Generated at 2022-06-20 19:02:17.231959
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import os
    import textwrap
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils import basic

    def write_file(path, content):
        with open(path, 'w') as f:
            f.write(content)

    def remove_file(path):
        os.remove(path)

    path = "/proc/cmdline"
    data = "test=test ansible_test=test"

    write_file(path, data)

    cmdline_fact_collector = CmdLineFactCollector()
    cmdline_facts = cmdline_fact_collector.collect()

    assert isinstance(cmdline_fact_collector, BaseFactCollector)

# Generated at 2022-06-20 19:02:17.809671
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    pass

# Generated at 2022-06-20 19:02:33.297210
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import unittest
    import tempfile
    from ansible.module_utils.facts.collector import TestCollector

    class TestCmdLineFactCollector(unittest.TestCase):
        def setUp(self):
            TestCollector.setUp(self)

        def tearDown(self):
            TestCollector.tearDown(self)

        def test_cmdline_is_none(self):
            """
            Test if cmdline fact is not returned when /proc/cmdline is empty.
            """
            collector = CmdLineFactCollector()
            result = collector.collect()
            self.assertIsNone(result)

        def test_cmdline_is_not_none(self):
            """
            Test if cmdline fact is returned when /proc/cmdline has content.
            """
            collector = CmdLine

# Generated at 2022-06-20 19:02:38.824600
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:02:45.659237
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.utils import FactsCollector
    from ansible.module_utils.facts.collectors.cmdline import CmdLineFactCollector
    from ansible.module_utils._text import to_bytes

    # Test with no data.
    CmdLineFactCollector._get_proc_cmdline = lambda self: ''
    facts_collector = FactsCollector(None, None)
    cmdline_collector = CmdLineFactCollector(facts_collector)
    assert cmdline_collector._get_proc_cmdline() == ''
    assert cmdline_collector.collect() == {}

    # Test with real data (with some arguments without "=").

# Generated at 2022-06-20 19:02:56.824024
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    data = 'BOOT_IMAGE=/vmlinux-4.4.0-59-generic root=/dev/mapper/docker-202:1-340734-dynamic-vg-docker--202--340734--01f3c6eb2f8e53c6a978b95d9c6a44b6c19b6b14d6a3815e1df642c8b39d52fb-cow ro console=ttyS0,38400n8 console=tty0 net.ifnames=0 biosdevname=0 elevator=noop systemd.unit=docker-202-install.scope boot=wily'


# Generated at 2022-06-20 19:02:57.945537
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cf = CmdLineFactCollector()
    assert cf.name == 'cmdline'
    assert cf.collect()

# Generated at 2022-06-20 19:03:04.750179
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():

    from ansible.module_utils.facts import CmdLineFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # create instance of CmdLineFactCollector
    cmd_line = CmdLineFactCollector()

    assert cmd_line._name == "cmdline"
    assert cmd_line._fact_ids == set()

    assert isinstance(cmd_line, BaseFactCollector) is True
    assert isinstance(cmd_line, CmdLineFactCollector) is True


# Generated at 2022-06-20 19:03:16.505748
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collectors import collector_module

    fake_file_content = 'ro root=UUID=70c2a063-d3c5-4bf4-bf45-69d3d3dc1c16 console=hvc0 console=tty0 systemd.journald.forward_to_console=yes console=ttyS0 earlyprintk=ttyS0 net.ifnames=0 isolcpus=1-2 nohz_full=1-2 rcu_nocbs=1-2 hugepagesz=2M hugepages=12 elevator=noop rootfstype=ext4'

    def fake_get_file_content(path):
        return fake_file_content


# Generated at 2022-06-20 19:03:20.664248
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.cmdline import CmdLineFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    # This is the content of the file /proc/cmdline
    proc_content = 'BOOT_IMAGE=/vmlinuz-3.13.0-24-generic root=UUID=85678f17-6e82-45be-96e6-228c6d2f1b31 ro quiet splash'

    # Setting the globals to their default.
    FactsCollector._fact_cache = {}
    FactsCollector._collectors = []

    # Setting the file /proc/cmdline content
   

# Generated at 2022-06-20 19:03:28.903489
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Arrange
    call = {
        "module_utils.facts.utils.get_file_content.return_value": "a=b c=d"
    }
    cmdline_facts = CmdLineFactCollector()

    # Act
    result = cmdline_facts.collect(call)

    # Assert
    assert result == {
        'cmdline': {'a': 'b', 'c': 'd'},
        'proc_cmdline': {'a': 'b', 'c': 'd'}
    }

# Generated at 2022-06-20 19:03:33.679521
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()
    assert type(CmdLineFactCollector._fact_ids) == set


# Generated at 2022-06-20 19:03:44.788388
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdLine = CmdLineFactCollector()
    assert cmdLine.name == 'cmdline'
    assert cmdLine._fact_ids == set()

# Generated at 2022-06-20 19:03:47.823411
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'

# Generated at 2022-06-20 19:03:50.324508
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # create instance of class
    ccmdline = CmdLineFactCollector()
    # check if instance is created
    assert ccmdline != None
    assert ccmdline.name == 'cmdline'
    assert ccmdline._fact_ids == set()


# Generated at 2022-06-20 19:03:54.603125
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():

    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()
    assert CmdLineFactCollector.name in CmdLineFactCollector._fact_ids

# Generated at 2022-06-20 19:03:58.710996
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdLineFactCollector = CmdLineFactCollector()
    assert cmdLineFactCollector.name == 'cmdline'



# Generated at 2022-06-20 19:04:01.717811
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    f = CmdLineFactCollector()
    assert f.name == 'cmdline'
    assert f._fact_ids == set()


# Generated at 2022-06-20 19:04:03.761564
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    '''
    Unit test for method collect of class CmdLineFactCollector
    '''
    pass

# Generated at 2022-06-20 19:04:10.988930
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_fact_collector = CmdLineFactCollector()
    cmdline_facts = cmdline_fact_collector.collect()

    assert cmdline_facts['cmdline'] == {'abcd': True, 'efgh': 'ijkl'}
    assert cmdline_facts['proc_cmdline'] == {'abcd': True, 'efgh': 'ijkl'}


# Generated at 2022-06-20 19:04:14.468977
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    test_collector = CmdLineFactCollector()
    test_collector._get_proc_cmdline = lambda: 'an=1 bo=2 an=3'
    cmdline_facts = test_collector.collect()
    assert cmdline_facts['cmdline'] == {'an': '3', 'bo': '2'}
    assert cmdline_facts['proc_cmdline'] == {'an': ['1', '3'], 'bo': '2'}

# Generated at 2022-06-20 19:04:18.216507
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()

    assert cmdline_fact_collector.name == 'cmdline'


# Generated at 2022-06-20 19:04:38.648756
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    factCollector = CmdLineFactCollector()
    assert factCollector.name == 'cmdline'
    assert factCollector._fact_ids == set()

# Generated at 2022-06-20 19:04:46.308810
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    module = None
    collected_facts = {}

    cmdline_fact_collector = CmdLineFactCollector()

    cmdline_facts = cmdline_fact_collector.collect(module, collected_facts)

    assert isinstance(cmdline_facts, dict)
    assert len(cmdline_facts) == 2
    assert 'cmdline' in cmdline_facts
    assert isinstance(cmdline_facts['cmdline'], dict)
    assert 'proc_cmdline' in cmdline_facts
    assert isinstance(cmdline_facts['proc_cmdline'], dict)

# Generated at 2022-06-20 19:04:58.176770
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """
    Run collect of class CmdLineFactCollector and test output
    :return:
    """
    cmdline_facts = dict()
    cmdline_data = "selinux=0 console=ttyS0,115200n8 intel_iommu=on iommu=pt intel_idle.max_cstate=0 processor.max_cstate=1"
    collector = CmdLineFactCollector()
    cmdline_facts = collector._parse_proc_cmdline_facts(cmdline_data)
    assert len(cmdline_facts) == 5
    assert "selinux" in cmdline_facts
    assert "console" in cmdline_facts
    assert "intel_iommu" in cmdline_facts
    assert "iommu" in cmdline_facts

# Generated at 2022-06-20 19:05:07.549833
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    fc = CmdLineFactCollector()
    fc.__class__.resolve = lambda x: "test"
    fc.__class__._get_proc_cmdline = lambda x: "test=test test2 test3=test3"
    assert fc.collect() == {'proc_cmdline': {'test': 'test', 'test3': 'test3', 'test2': True}, 'cmdline': {'test': 'test', 'test3': 'test3', 'test2': True}}
    fc.__class__._get_proc_cmdline = lambda x: "test=test test=test2"
    assert fc.collect() == {'proc_cmdline': {'test': ['test', 'test2']}, 'cmdline': {'test': 'test2'}}


# Generated at 2022-06-20 19:05:09.149059
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()

# Generated at 2022-06-20 19:05:18.944322
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from contextlib import contextmanager
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.cmdline import CmdLineFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    @contextmanager
    def _mocked_get_file_content(mock_content):
        """Mock get_file_content function to return the given content."""
        with Collector.temporarily_unbound('get_file_content'):
            Collector.bind_method(CmdLineFactCollector, 'get_file_content',
                                  lambda path: str(mock_content),
                                  method_name_suffix='_cmdline')
            yield


# Generated at 2022-06-20 19:05:20.247797
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    assert {} == collector.collect()

# Generated at 2022-06-20 19:05:23.899854
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert c._fact_ids == set()


# Generated at 2022-06-20 19:05:28.488849
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()

    assert collector is not None
    assert collector.name == 'cmdline'
    assert collector._fact_ids == set()

# Generated at 2022-06-20 19:05:37.754631
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """Test method collect of class CmdLineFactCollector."""

    # Create CmdLineFactCollector instance
    cmdline_fact_collector = CmdLineFactCollector()

    # Create cmdline sample
    cmdline = 'rd.auto rd.lvm.lv=vg/swap rd.lvm.lv=vg/root rhgb quiet LANG=en_US.UTF-8 module_blacklist=nouveau'

    # Create mock method _get_proc_cmdline
    def mock_get_proc_cmdline():
        return cmdline

    # Set the method _get_proc_cmdline to be the mock_get_proc_cmdline method
    cmdline_fact_collector._get_proc_cmdline = mock_get_proc_cmdline

    # Create facts dict sample

# Generated at 2022-06-20 19:06:17.888821
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_collector = CmdLineFactCollector.__new__(CmdLineFactCollector)
    assert isinstance(cmd_line_collector, CmdLineFactCollector)
    assert cmd_line_collector.name == 'cmdline'

# Generated at 2022-06-20 19:06:29.191291
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """
    Testing with mock data, the items present in cmdline, proc_cmdline
    and cmdline_dict.
    """
    from ansible.module_utils.facts.collector.cmdline import CmdLineFactCollector
    from ansible.module_utils._text import to_bytes
    data = "BOOT_IMAGE=/boot/vmlinuz-3.10.0-1127.el7.x86_64 root=UUID=3aa3a9a5-f0e7-468e-9a68-6d5c6b5d6a2f ro crashkernel=auto rhgb quiet LANG=en_US.UTF-8"
    cmdline_obj = CmdLineFactCollector()
    cmdline_obj._get_proc_cmdline = lambda: data
    cmdline_dict = cmdline

# Generated at 2022-06-20 19:06:32.126019
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'
    assert obj._fact_ids == set()

# Generated at 2022-06-20 19:06:34.072872
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()


# Generated at 2022-06-20 19:06:36.780833
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    collected_facts = collector.collect()
    assert collected_facts['cmdline']
    assert collected_facts['proc_cmdline']

# Generated at 2022-06-20 19:06:39.730986
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector().name == 'cmdline'

# Generated at 2022-06-20 19:06:46.721890
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """Test the collect method of class CmdLineFactCollector."""
    c = CmdLineFactCollector()
    data = c._get_proc_cmdline()

    cmdline_facts = c.collect()

    assert bool(cmdline_facts['cmdline']) == bool(data)
    assert bool(cmdline_facts['proc_cmdline']) == bool(data)

# Generated at 2022-06-20 19:06:58.537354
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Create an instance of class CmdLineFactCollector without arguments
    cmdline_fact_collector = CmdLineFactCollector()

    # Define the content of the file existing at path "/proc/cmdline"
    proc_cmdline_content = 'BOOT_IMAGE=/boot/vmlinuz-3.10.0-123.el7.x86_64 root=UUID=14a4f4c4-4e4e-4b5d-b5cd-b5ba532f4b4e ro rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet LANG=en_US.UTF-8'

    # Create a mock function to replace method _get_proc_cmdline of class CmdLineFactCollector

# Generated at 2022-06-20 19:07:02.093968
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    factory = CmdLineFactCollector()
    assert factory.name == 'cmdline'
    assert not factory._fact_ids

# Generated at 2022-06-20 19:07:05.227479
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'

# Generated at 2022-06-20 19:08:30.024205
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'
    assert isinstance(obj._fact_ids, set)


# Generated at 2022-06-20 19:08:32.646678
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    print(cmdline_fact_collector.name)
    print(cmdline_fact_collector._fact_ids)


# Generated at 2022-06-20 19:08:39.781864
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    proc_cmdline = 'ansible_test=true --console=ttyS0,115200'
    instance = CmdLineFactCollector()
    instance._get_proc_cmdline = lambda: proc_cmdline

    cmdline_facts = instance.collect()

    assert cmdline_facts['cmdline']['ansible_test'] == 'true'
    assert cmdline_facts['cmdline']['--console'] == 'ttyS0,115200'
    assert cmdline_facts['proc_cmdline']['ansible_test'] == 'true'
    assert cmdline_facts['proc_cmdline']['console'] == 'ttyS0,115200'


# Generated at 2022-06-20 19:08:42.391882
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    fc = CmdLineFactCollector()
    fc._get_proc_cmdline = lambda: 'root=xxx ro'
    fc.collect()


# Generated at 2022-06-20 19:08:46.288584
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect(None, None)
    assert isinstance(cmdline_facts, dict)
    assert isinstance(cmdline_facts['cmdline'], dict)
    assert isinstance(cmdline_facts['proc_cmdline'], dict)

# Generated at 2022-06-20 19:08:48.841800
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    test_collector = CmdLineFactCollector()
    try:
        assert test_collector.collect()
    except TypeError as e:
        assert e


# Generated at 2022-06-20 19:08:57.366013
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    data = "a=b c=d e f=g h= i=j k=l m= n=o p=q r=s s=t u=v w=x y=z"

# Generated at 2022-06-20 19:09:08.028544
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    import platform
    import sys
    import os

    # Get the platform and distribution name.
    dist_name = platform.dist()[0]
    plat_name = platform.system()

    # Unit test that works on most RedHat based Linux distributions.

# Generated at 2022-06-20 19:09:13.293159
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # In python 2.6, we need instantiate the base class.
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector != None


# Generated at 2022-06-20 19:09:15.330746
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
