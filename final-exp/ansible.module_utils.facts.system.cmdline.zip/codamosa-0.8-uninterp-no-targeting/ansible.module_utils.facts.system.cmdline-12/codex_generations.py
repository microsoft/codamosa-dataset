

# Generated at 2022-06-20 19:01:37.168825
# Unit test for constructor of class CmdLineFactCollector

# Generated at 2022-06-20 19:01:38.709375
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = CmdLineFactCollector()
    assert cmdline_facts.name == "cmdline"

# Generated at 2022-06-20 19:01:41.547240
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'

# Generated at 2022-06-20 19:01:43.669376
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert not c._fact_ids

# Generated at 2022-06-20 19:01:48.165987
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-20 19:01:58.220562
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Constructor
    cmd = CmdLineFactCollector()

    # Set class variable /proc/cmdline
    cmd._get_proc_cmdline = lambda: 'root=/dev/sda1 ip=192.168.0.1 ssh'

    result = cmd._parse_proc_cmdline(cmd._get_proc_cmdline())
    expected = {'ip': '192.168.0.1', 'root': '/dev/sda1', 'ssh': True}

    assert result == expected

    result = cmd._parse_proc_cmdline_facts(cmd._get_proc_cmdline())
    expected = {'ip': '192.168.0.1', 'root': '/dev/sda1', 'ssh': True}

    assert result == expected

    result = cmd.collect()

# Generated at 2022-06-20 19:02:05.058203
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    c = CmdLineFactCollector()

    # With empty data
    assert c.collect() == {}

    # With real data

# Generated at 2022-06-20 19:02:16.039591
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """
    Test method collect in the class CmdLineFactCollector
    """
    # Test with valid proc_cmdline
    # Create a class object
    cmd_line_obj = CmdLineFactCollector()
    # Call the method collect with validParameters
    cmd_line_dict = cmd_line_obj.collect()
    # Check the value of cmd_line_dict

# Generated at 2022-06-20 19:02:20.401764
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()
    assert issubclass(CmdLineFactCollector, BaseFactCollector)
    assert isinstance(CmdLineFactCollector(), BaseFactCollector)

# Generated at 2022-06-20 19:02:33.097048
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # This is the data that will be returned by the method _get_proc_cmdline
    data = "BOOT_IMAGE=/boot/vmlinuz-4.4.0-177-generic root=UUID=f8e4d3d3-c105-4f7a-8f73-d7fdb6e75a6b ro quiet splash vt.handoff=7"

    # Dictionary of expected facts to be returned by the collect method

# Generated at 2022-06-20 19:02:42.032626
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c1 = CmdLineFactCollector()
    assert c1.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()
    assert isinstance(c1, BaseFactCollector)


# Generated at 2022-06-20 19:02:45.595216
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'
    assert obj._fact_ids == set()


# Generated at 2022-06-20 19:02:56.799959
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible_fact_collector.utils import command_exists

    # command exists
    if not command_exists("/proc/cmdline"):
        print("Can't find /proc/cmdline, skip this test")
        return

    # get data
    data = get_file_content("/proc/cmdline")

    # parse data
    cmdline_facts = {}
    cmdline_facts['cmdline'] = {}
    cmdline_facts['proc_cmdline'] = {}

    cmdline_dict = {}

# Generated at 2022-06-20 19:02:57.695707
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector

# Generated at 2022-06-20 19:03:05.433184
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_data = 'ro root=201:0 rootflags=subvol=@ printk.devkmsg=on'
    cc = CmdLineFactCollector()
    cc._get_proc_cmdline = lambda: cmdline_data

    cc_facts = cc.collect()

    assert cc_facts == {
        'cmdline': {
            'ro': True,
            'root': '201:0',
            'rootflags': 'subvol=@',
            'printk.devkmsg': 'on'
        },
        'proc_cmdline': {
            'ro': True,
            'root': '201:0',
            'rootflags': 'subvol=@',
            'printk.devkmsg': 'on'
        }
    }



# Generated at 2022-06-20 19:03:08.867277
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Instantiate class CmdLineFactCollector()
    instance = CmdLineFactCollector()
    assert instance.name == 'cmdline'

# Generated at 2022-06-20 19:03:17.815974
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    fake_content = 'CDBOOT=no CDBOOTAPPEND= CDBOOTAPPEND2=a=b CDBOOTAPPEND3=a=b=c console=tty0 console=ttyS0,115200n8'


# Generated at 2022-06-20 19:03:19.399275
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector()
    result = cmdline_facts.collect()
    assert len(result) == 2

# Generated at 2022-06-20 19:03:20.766944
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()

# Generated at 2022-06-20 19:03:31.151335
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()

    # Mock the method _get_proc_cmdline and returns a string
    def _get_proc_cmdline():
        return 'ansible_ssh_host=192.168.0.1'

    cmdline_collector._get_proc_cmdline = _get_proc_cmdline

    # Mock the method _parse_proc_cmdline_facts and returns a dict
    def _parse_proc_cmdline_facts(data):
        return {'ansible_ssh_host': '192.168.0.1'}

    cmdline_collector._parse_proc_cmdline_facts = _parse_proc_cmdline_facts

    # Execute the method collect
    result = cmdline_collector.collect()

    # Check the result

# Generated at 2022-06-20 19:03:44.639152
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-20 19:03:48.707071
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()


# Generated at 2022-06-20 19:03:50.123603
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()

# Generated at 2022-06-20 19:03:53.325604
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector().name == 'cmdline'
    assert CmdLineFactCollector()._fact_ids == set()


# Generated at 2022-06-20 19:03:56.630612
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()

    c.collect(None, None)
    assert 'ansible_cmdline' not in c._fact_ids
    assert 'cmdline' in c._fact_ids
    assert 'proc_cmdline' in c._fact_ids

# Generated at 2022-06-20 19:04:02.603918
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_dict = {
        'root': '/dev/sda',
        'ro': True
    }

    c = CmdLineFactCollector()
    c.collect()

    # assert
    assert c.cache[c.name] == cmdline_dict

# Generated at 2022-06-20 19:04:11.082452
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """Test CmdLineFactCollector.collect()"""
    cmdline_facts = {}

    class FakeModule(object):
        def __init__(self, name, fail_json, **kwargs):
            self.name = name
            self.fail_json = fail_json
    class FakeFailJson(object):
        def __init__(self, msg, **kwargs):
            pass

    cmdline_fact = CmdLineFactCollector()
    cmdline_fact._get_proc_cmdline = lambda: 'foo=bar test=a b c=d'
    result = cmdline_fact.collect(module=FakeModule("test module", FakeFailJson), collected_facts=cmdline_facts)

# Generated at 2022-06-20 19:04:16.288496
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact = CmdLineFactCollector()
    assert cmdline_fact.name == 'cmdline'
    assert cmdline_fact._fact_ids == set()
    assert cmdline_fact._get_proc_cmdline() == 'BOOT_IMAGE=/boot/vmlinuz-3.10.0-862.2.3.el7.x86_64 root=UUID=921b9cbe-7e0d-4e4b-8666-d4f7e0cd95c0 ro crashkernel=auto rhgb quiet LANG=en_US.UTF-8'

# Generated at 2022-06-20 19:04:27.726144
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import unittest
    from ansible.module_utils.facts import collector

    class mock_BaseFactCollector(object):
        def collect(self, module=None, collected_facts=None):
            return dict()


# Generated at 2022-06-20 19:04:39.814536
# Unit test for method collect of class CmdLineFactCollector

# Generated at 2022-06-20 19:05:00.129353
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Create instance of CmdLineFactCollector class
    cmdline_fact_collector = CmdLineFactCollector()

    collected_facts = {}
    cmdline_facts = cmdline_fact_collector.collect(collected_facts=collected_facts)

    # Assert for items in dictionary
    assert 'cmdline' in cmdline_facts
    assert 'proc_cmdline' in cmdline_facts

    assert isinstance(cmdline_facts['cmdline'], dict)
    assert isinstance(cmdline_facts['proc_cmdline'], dict)

    # Assert value of dict items
    cmdline_items = cmdline_facts['cmdline']
    proc_cmdline_items = cmdline_facts['proc_cmdline']


# Generated at 2022-06-20 19:05:06.633685
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts import ModuleStub
    from ansible.module_utils.facts.collector.cmdline import CmdLineFactCollector

    cmdline_fact_collector = CmdLineFactCollector()

    # Test for /proc/cmdline does not have any data
    module = ModuleStub({})
    collected_facts = {}
    result = cmdline_fact_collector.collect(module, collected_facts)
    assert result == {}, 'module_utils.facts.collector.cmdline.CmdLineFactCollector.collect() collects empty data even when no data is present in /proc/cmdline'

    # Test for /proc/cmdline has data
    module = ModuleStub({}, get_file_content=lambda path: 'a=b')

# Generated at 2022-06-20 19:05:07.427405
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()


# Generated at 2022-06-20 19:05:10.115938
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert not c._fact_ids

# Generated at 2022-06-20 19:05:19.269411
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    content = "root=/dev/sda1 ro crashkernel=auto rhgb quiet"
    input_data = {
        'ansible_cmdline': {
            'cmdline': {
                "root": "/dev/sda1",
                "ro": True,
                "crashkernel": "auto",
                "rhgb": True,
                "quiet": True
            },
            'proc_cmdline': {
                "root": "/dev/sda1",
                "ro": True,
                "crashkernel": "auto",
                "rhgb": True,
                "quiet": True
            }
        },
        'content': content
    }
    collector = CmdLineFactCollector()
    result = collector._get_proc_cmdline()
    assert result == content
    result = collector._parse_proc_cmdline

# Generated at 2022-06-20 19:05:30.153149
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    c = CmdLineFactCollector()
    cmdline = "BOOT_IMAGE=/boot/vmlinuz-4.4.0-31-generic root=UUID=a6dc7ae6-f748-4102-a707-fc6f7a53f9c8 ro quiet splash vt.handoff=7\n"
    cmdline_facts = c.collect(None, None)

    assert cmdline_facts['cmdline']['BOOT_IMAGE'] == '/boot/vmlinuz-4.4.0-31-generic'
    assert cmdline_facts['proc_cmdline']['BOOT_IMAGE'] == '/boot/vmlinuz-4.4.0-31-generic'

# Generated at 2022-06-20 19:05:31.655442
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector()
    assert cmdline_facts.collect()

# Generated at 2022-06-20 19:05:37.312802
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.cmdline import CmdLineFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    import shlex

    def _get_proc_cmdline(self):
        return get_file_content('/proc/cmdline')

    def _parse_proc_cmdline(self, data):
        cmdline_dict = {}

# Generated at 2022-06-20 19:05:38.298386
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector.priority == 30

# Generated at 2022-06-20 19:05:48.366096
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import collectors

    # initialization
    Collector.clear_extend()
    Collector.add_callback(collectors.CmdLineFactCollector)

    # collect data
    facts = Collector.collect()
    cmdline_facts = facts['cmdline']

    # verify data
    data = get_file_content('/proc/cmdline')
    if not data:
        assert cmdline_facts == {}
        return


# Generated at 2022-06-20 19:06:19.499465
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    basepath = '../data/'

# Generated at 2022-06-20 19:06:29.568025
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector

    test_files = {
        '/proc/cmdline': 'console=tty0 console=ttyS1,9600n8 elevator=noop root=/dev/hda1 ro'
    }

    CmdLineFactCollector.parse_proc_cmdline_facts = lambda self, data: {'console': 'tty0'}
    CmdLineFactCollector.parse_proc_cmdline = lambda self, data: {'console': ['tty0', 'ttyS1,9600n8']}
    CmdLineFactCollector.get_file_content = lambda self, filename: test_files[filename]

    obj_cmdline = CmdLineFactCollector()

    obj_cmdline.collect()


# Generated at 2022-06-20 19:06:37.543391
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    f = CmdLineFactCollector()
    cmdline_facts = f.collect()

    # validate that returned dict is not empty
    assert cmdline_facts
    # validate that both keys are in dict
    assert 'cmdline' in cmdline_facts
    assert 'proc_cmdline' in cmdline_facts
    # validate that type of cmdline is dict
    assert isinstance(cmdline_facts['cmdline'], dict)
    # validate that type of proc_cmdline is dict
    assert isinstance(cmdline_facts['proc_cmdline'], dict)

# Generated at 2022-06-20 19:06:40.587203
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact=CmdLineFactCollector()
    cmd_line_fact.collect()

# Generated at 2022-06-20 19:06:44.988812
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_data = 'ansible_test=True C=3 ipv6.disable=1'

    collector = CmdLineFactCollector(None)
    collector._get_proc_cmdline = lambda: cmdline_data

    cmdline_facts = collector.collect()

    assert cmdline_facts['cmdline'] == {'ansible_test': 'True', 'C': '3',
                                        'ipv6.disable': '1'}
    assert cmdline_facts['proc_cmdline'] == {'ansible_test': 'True',
                                             'C': '3',
                                             'ipv6.disable': '1'}

# Generated at 2022-06-20 19:06:48.192248
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdLineFactCollector = CmdLineFactCollector()
    assert cmdLineFactCollector.name == 'cmdline'
    assert cmdLineFactCollector._fact_ids == set()


# Generated at 2022-06-20 19:06:59.047800
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'
    assert obj._fact_ids == set()
    assert obj._get_proc_cmdline() == '/proc/cmdline'
    assert obj._parse_proc_cmdline_facts('foo=bar') == {'foo': 'bar'}
    assert obj._parse_proc_cmdline_facts('foo=bar=test') == {'foo': 'bar=test'}
    assert obj._parse_proc_cmdline_facts('foo bar=test') == {'foo': True, 'bar': 'test'}
    assert obj._parse_proc_cmdline_facts('foo=bar test') == {'foo': 'bar', 'test': True}

# Generated at 2022-06-20 19:07:04.208719
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    collected_facts = cmdline_collector.collect()
    assert collected_facts['proc_cmdline'].has_key('rd')

# Generated at 2022-06-20 19:07:07.015706
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert cmdline.name == 'cmdline'
    assert not cmdline._fact_ids

# Generated at 2022-06-20 19:07:10.530202
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    '''
    Testing the constructor of class CmdLineFactCollector
    '''
    collector = CmdLineFactCollector()
    assert 'proc_cmdline' == collector.name

# Generated at 2022-06-20 19:07:54.518841
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-20 19:07:55.514703
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    test_obj = CmdLineFactCollector()
    assert test_obj.name == 'cmdline'

# Generated at 2022-06-20 19:07:56.855964
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert cmdline is not None
    assert cmdline.name == 'cmdline'
    assert len(cmdline._fact_ids) == 0


# Generated at 2022-06-20 19:07:59.367009
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector is not None

# Generated at 2022-06-20 19:08:00.125687
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()

# Generated at 2022-06-20 19:08:03.842762
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    result = collector.collect()
    assert result is not None
    assert result['cmdline'] is not None
    assert result['proc_cmdline'] is not None

# Generated at 2022-06-20 19:08:05.880768
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector.collect()
    assert cmdline_collector.name == 'cmdline'

# Generated at 2022-06-20 19:08:10.144590
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    result = collector.collect()['proc_cmdline']
    assert 'quiet' in result
    assert result['quiet'] == 'True'
    assert 'initrd' in result
    assert result['initrd'] == '/boot/initrd.img-4.4.0-96-generic'
    assert 'ro' in result
    assert result['ro'] == 'True'

# Generated at 2022-06-20 19:08:15.337479
# Unit test for method collect of class CmdLineFactCollector

# Generated at 2022-06-20 19:08:18.739134
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-20 19:10:05.637434
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cf = CmdLineFactCollector()
    assert cf
    assert cf.name == 'cmdline'

# Generated at 2022-06-20 19:10:13.254345
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import sys

    module = sys.modules[__name__]
    cmdlinecollector = CmdLineFactCollector(module=module)
    cmdline_facts = cmdlinecollector.collect()

    proc_cmdline_facts = cmdline_facts['proc_cmdline']
    assert type(proc_cmdline_facts) is dict
    # Manual check on the output to make sure it's reasonable.
    # How to parse the output depends on the actual test setup.
    assert 'BOOT_IMAGE' in proc_cmdline_facts

    cmdline_facts = cmdline_facts['cmdline']
    assert type(cmdline_facts) is dict
    # Manual check on the output to make sure it's reasonable.
    # How to parse the output depends on the actual test setup.
    assert 'BOOT_IMAGE' in cmdline_facts

# Generated at 2022-06-20 19:10:23.758703
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    f_cmdline_facts = CmdLineFactCollector()

# Generated at 2022-06-20 19:10:33.648722
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    data = "rd.lvm.lv=cl/root rd.lvm.lv=cl/swap rhgb quiet"
    cmdline_dict = {
        "rd.lvm.lv": "cl/swap",
        "quiet": True,
        "rhgb": True
    }
    proc_cmdline_dict = {
        "rd.lvm.lv": ['cl/root', "cl/swap"],
        "quiet": True,
        "rhgb": True
    }
    collector = CmdLineFactCollector(None)
    collector._get_proc_cmdline = lambda: data
    assert (collector.collect() == {
        'cmdline': cmdline_dict,
        'proc_cmdline': proc_cmdline_dict
    })



# Generated at 2022-06-20 19:10:43.785265
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts_collector = CmdLineFactCollector()
    test_data = b'root=UUID=01234567-89ab-cdef-0123-456789abcdef ro selinux=0 ip=dhcp audiosocket=auto'
    cmdline_facts_collector._get_proc_cmdline = lambda: test_data
    cmdline_facts = cmdline_facts_collector.collect()
    assert cmdline_facts['cmdline'] == {
        'root': 'UUID=01234567-89ab-cdef-0123-456789abcdef',
        'ro': True,
        'selinux': '0',
        'ip': 'dhcp',
        'audiosocket': 'auto'
    }

# Generated at 2022-06-20 19:10:47.731743
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    curr = CmdLineFactCollector()
    assert curr.name == 'cmdline'
    assert curr._fact_ids == set()


# Generated at 2022-06-20 19:10:52.758802
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    ansible_facts = {}
    fact_collector = CmdLineFactCollector()
    result = fact_collector.collect(collected_facts=ansible_facts)
    assert result.keys() == {'cmdline', 'proc_cmdline'}
    assert result['cmdline'] is not None
    assert result['proc_cmdline'] is not None

# Generated at 2022-06-20 19:10:57.108644
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    clf = CmdLineFactCollector()
    assert clf.name == 'cmdline'
    assert clf._fact_ids == set()

# Generated at 2022-06-20 19:11:06.216471
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_file_content = "rhel.product.variant=Server rhel.product.version=7.1 rhel.product.name=Red Hat Enterprise Linux rhel.product.id=RHEL rhel.product.sku_variant_id=Server rhel.product.sku=None"

# Generated at 2022-06-20 19:11:10.232652
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = CmdLineFactCollector()
    assert cmdline_facts.name == 'cmdline'
    assert isinstance(cmdline_facts.collect(), dict)