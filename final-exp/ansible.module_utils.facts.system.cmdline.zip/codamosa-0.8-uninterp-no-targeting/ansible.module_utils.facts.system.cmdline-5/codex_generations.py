

# Generated at 2022-06-20 19:01:37.584755
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector._get_proc_cmdline = lambda: ''' BOOT_IMAGE=/vmlinuz-3.10.0-862.14.4.el7.x86_64 ro root=UUID=6e5f5b5d-c5e6-4f6b-8591-0ce6d4389a63 rd_NO_LUKS  KEYBOARDTYPE=pc KEYTABLE=us rd_NO_MD rd_LVM_LV=rhel/swap SYSFONT=latarcyrheb-sun16 rhgb quiet LANG=en_US.UTF-8'''
    cmdline_collector._parse_proc_cmdline = lambda data: {}
    cmdline_collector._parse_proc_cmdline

# Generated at 2022-06-20 19:01:48.926895
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import sys
    import os
    import tempfile
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.cmdline import CmdLineFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    test_fact_data = "test_1=data_1 test_2=data_2 test_3=data_3"

    # Override file_exists method in BaseFactCollector
    def file_exists(self, path):
        return True

    # Override get_file_content method in BaseFactCollector
    def get_file_content(self, path):
        return test_fact_data

    # Override CmdLineFactCollector to be able to use the test data

# Generated at 2022-06-20 19:01:58.484765
# Unit test for method collect of class CmdLineFactCollector

# Generated at 2022-06-20 19:02:03.884694
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    print("Testing CmdLineFactCollector class")
    print("Testing CmdLineFactCollector constructor")
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()

# Generated at 2022-06-20 19:02:05.922268
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()


# Generated at 2022-06-20 19:02:11.615495
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    # This is a stub class
    class Module(object):
        pass

    # Initialize the class CmdLineFactCollector
    cmdline_collector = CmdLineFactCollector(Module())

    # Use the dummy file /proc/cmdline to test
    cmdline_content = """
    LANG=C KEYTABLE=us SYSFONT=latarcyrheb-sun16 crashkernel=auto  rhgb  quiet KEYBOARDTYPE=pc KEYTABLE=us rd.lvm.lv=vg_root/lv_root rd.lvm.lv=vg_root/lv_swap 
    """

# Generated at 2022-06-20 19:02:23.349739
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    module = AnsibleModuleMock()
    cmdLineFactCollector = CmdLineFactCollector()
    cmdLineFactCollector._get_proc_cmdline = lambda: 'BOOT_IMAGE=/vmlinuz-4.4.0-57-generic root=UUID=15f3bc4a-3966-4e90-9e2c-05d829a48a79 ro quiet splash vt.handoff=7'
    collected_facts = {}
    collected_facts['cmdline'] = cmdLineFactCollector.collect(module, collected_facts)['cmdline']


# Generated at 2022-06-20 19:02:25.585746
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'

# Generated at 2022-06-20 19:02:28.235861
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()



# Generated at 2022-06-20 19:02:29.915115
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    ret = CmdLineFactCollector()
    assert ret
    assert ret._fact_ids == set()

# Generated at 2022-06-20 19:02:35.764119
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector is not None

# Generated at 2022-06-20 19:02:39.142911
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'
    assert isinstance(collector._fact_ids, set)

# Generated at 2022-06-20 19:02:44.210292
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert isinstance(collector, CmdLineFactCollector)
    assert isinstance(collector._fact_ids, set)
    assert collector.name == 'cmdline'
    assert len(collector._fact_ids) == 0
    assert collector._get_proc_cmdline() == get_file_content('/proc/cmdline')


# Generated at 2022-06-20 19:02:49.381648
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_obj = CmdLineFactCollector()
    cmdline = cmdline_obj.collect()
    print(cmdline)


if __name__ == '__main__':
    test_CmdLineFactCollector_collect()

# Generated at 2022-06-20 19:02:52.705021
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert isinstance(cmdline_collector, CmdLineFactCollector)

# Generated at 2022-06-20 19:03:04.165928
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # No value
    print("test_CmdLineFactCollector_collect")
    collector = CmdLineFactCollector()
    cmdline_facts = collector.collect()
    assert('cmdline' not in cmdline_facts.keys())
    assert('proc_cmdline' not in cmdline_facts.keys())

    # Test if function return a dict
    assert(isinstance(cmdline_facts, dict))

    # Test if function return a dict with the correct cmdline key
    assert('cmdline' in cmdline_facts.keys())

    # Test if cmdline key has the correct value
    assert(cmdline_facts['cmdline'] == {'BOOT_IMAGE': '/vmlinuz-3.13.0-85-generic'})


# Generated at 2022-06-20 19:03:09.650879
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:03:19.281246
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    class ModuleMock:
        def __init__(self):
            self.params = {}

    class CollectedFactsMock:
        def __init__(self):
            self.values = {}

    module = ModuleMock()
    collected_facts = CollectedFactsMock()

    # Verify that it is working with no cmdline
    get_file_content = lambda x: None
    collector = CmdLineFactCollector()
    results = collector.collect(module, collected_facts)
    assert results == {}

    # Verify it works with a single value
    get_file_content = lambda x: 'foo=bar'
    collector = CmdLineFactCollector()
    results = collector.collect(module, collected_facts)

# Generated at 2022-06-20 19:03:22.269035
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    result = CmdLineFactCollector()
    assert result.name == 'cmdline'
    assert result._fact_ids == set()


# Generated at 2022-06-20 19:03:24.748183
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector().name == 'cmdline'
    assert CmdLineFactCollector()._fact_ids == set()


# Generated at 2022-06-20 19:03:33.992558
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    test_obj = CmdLineFactCollector('', '', '')
    assert test_obj.name == 'cmdline'
    assert test_obj._fact_ids == set()


# Generated at 2022-06-20 19:03:41.382643
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from . import TestAnsibleModule
    from ansible.module_utils.facts import FactCache
    from ansible.module_utils.facts.collector.cmdline import CmdLineFactCollector
    import ansible.module_utils.facts.collector
    import os
    import sys

    # Set up test environment
    obj_test_module = TestAnsibleModule({})
    obj_facts_cache = FactCache()

    # Make a clean start
    ansible.module_utils.facts.collector.FACT_CACHE.clear()
    if os.path.exists('/proc/cmdline'):
        os.path.remove('/proc/cmdline')
    if os.path.exists('/proc/cmdline1'):
        os.path.remove('/proc/cmdline1')

# Generated at 2022-06-20 19:03:47.314439
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()

    assert cmdline_facts['cmdline']['ansible_test_mode']
    assert cmdline_facts['cmdline']['ansible_managed']
    assert cmdline_facts['proc_cmdline']['ansible_test_mode']
    assert cmdline_facts['proc_cmdline']['ansible_managed']


# Generated at 2022-06-20 19:03:51.619778
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = CmdLineFactCollector()
    assert cmdline_facts.name == 'cmdline'
    assert cmdline_facts._fact_ids is not None


# Generated at 2022-06-20 19:04:01.412771
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """Test method collect of class CmdLineFactCollector."""
    # Get a CmdLineFactCollector object
    cmd_line_fact_collector = CmdLineFactCollector()
    # Call method collect
    cmdline_facts = cmd_line_fact_collector.collect()
    # Check returned data
    assert isinstance(cmdline_facts['proc_cmdline'], dict)
    assert isinstance(cmdline_facts['cmdline'], dict)
    assert 'root' in cmdline_facts['cmdline']
    assert 'root' in cmdline_facts['proc_cmdline']
    assert 'ro' in cmdline_facts['cmdline']
    assert 'ro' in cmdline_facts['proc_cmdline']
    assert 'rootfstype' in cmdline_facts['cmdline']

# Generated at 2022-06-20 19:04:03.967912
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    fc = CmdLineFactCollector()
    result = fc.collect()
    assert isinstance(result['proc_cmdline'], dict)

# Generated at 2022-06-20 19:04:07.316281
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cfact = CmdLineFactCollector()
    assert cfact.name == 'cmdline'
    assert cfact._fact_ids == set()


# Generated at 2022-06-20 19:04:09.777470
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'



# Generated at 2022-06-20 19:04:13.062900
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert 'cmdline' in CmdLineFactCollector._fact_ids


# Generated at 2022-06-20 19:04:14.413956
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()

# Generated at 2022-06-20 19:04:29.836843
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    proc_data = 'BOOT_IMAGE=/boot/vmlinuz-2.6.32-696.3.2.el6.x86_64 root=UUID=0bdf1cdf-8b55-4d80-ad49-a0c3e3d65eec ro crashkernel=auto rd_LVM_LV=rhel/swap rd_LVM_LV=rhel/root rd_NO_LUKS rd_NO_MD rd_NO_DM LANG=en_US.UTF-8 SYSFONT=latarcyrheb-sun16 KEYBOARDTYPE=pc KEYTABLE=us rhgb quiet initcall_debug'


# Generated at 2022-06-20 19:04:32.712710
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'

# Generated at 2022-06-20 19:04:36.204330
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # test the constructor
    test_collector = CmdLineFactCollector()
    assert test_collector.name == 'cmdline'
    assert test_collector._fact_ids == set()


# Generated at 2022-06-20 19:04:46.816890
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    # Tests Parse cmdline
    test_data = 'root=/dev/mapper/vg_oracle19c-lv_root rd_NO_LUKS rd_NO_MD rd_NO_DM LANG=en_US.UTF-8 SYSFONT=latarcyrheb-sun16 crashkernel=auto rhgb quiet rd_NO_DM'

# Generated at 2022-06-20 19:04:48.334519
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()


# Generated at 2022-06-20 19:04:51.832765
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    Collector = CmdLineFactCollector()
    assert isinstance(Collector, CmdLineFactCollector)
    assert Collector.name == 'cmdline'

# Generated at 2022-06-20 19:04:53.287100
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()

# Generated at 2022-06-20 19:04:54.048326
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    pass

# Generated at 2022-06-20 19:04:55.421266
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    c = CmdLineFactCollector()
    assert c.collect() == {}

# Generated at 2022-06-20 19:04:59.429069
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
	assert CmdLineFactCollector.name == 'cmdline'
	assert CmdLineFactCollector._fact_ids == set()


# Generated at 2022-06-20 19:05:17.223753
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'

# Generated at 2022-06-20 19:05:19.218752
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'

# Generated at 2022-06-20 19:05:30.153263
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    module = object()
    collected_facts = {}
    fact_collector = CmdLineFactCollector(module=module, collected_facts=collected_facts)

    fact_collector._get_proc_cmdline = lambda: 'unknown_param=1 root=/dev/vda vga=0x314'
    assert fact_collector.collect() == {
        'cmdline': {
            u'unknown_param': u'1',
            u'root': u'/dev/vda',
            u'vga': u'0x314'
        },
        'proc_cmdline': {
            u'unknown_param': u'1',
            u'root': u'/dev/vda',
            u'vga': u'0x314'
        }
    }

    fact_collector._get_proc_cmd

# Generated at 2022-06-20 19:05:38.263203
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    proc_cmdline_data="root=/dev/ram1 console=ttyS0 BOOT_IMAGE=/vmlinuz-2.6.32-431.17.1.el6.x86_64 initrd=/initramfs-2.6.32-431.17.1.el6.x86_64.img ro crashkernel=auto LANG=en_US.UTF-8 rd_NO_DM rd_NO_MD rd_LVM_LV=vg00/lv01 rd_LVM_LV=vg00/lv02 rd_LVM_LV=vg00/lv03 rd_NO_LUKS rd_NO_LVM rd_NO_MD rd_NO_MULTIPATH rd_NO_DM rhgb quiet"


# Generated at 2022-06-20 19:05:41.817707
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    clfc = CmdLineFactCollector()
    assert isinstance(clfc,BaseFactCollector)
    assert clfc.name == 'cmdline'


# Generated at 2022-06-20 19:05:44.382716
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert isinstance(cmdline_collector.collect(), dict)

# Generated at 2022-06-20 19:05:46.981960
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()

    assert collector.name == 'cmdline'

# Generated at 2022-06-20 19:05:50.214779
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'
    assert obj._fact_ids == set()



# Generated at 2022-06-20 19:05:52.008647
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact = CmdLineFactCollector()
    assert cmdline_fact.name == 'cmdline'
    assert cmdline_fact._fact_ids == set()


# Generated at 2022-06-20 19:05:59.019083
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    class MockRunner():
        def __init__(self):
            self.runner_results = ''

# Generated at 2022-06-20 19:06:41.646675
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import tempfile
    import os
    import json

    facts = {
        '/proc/cmdline': 'root=LABEL=cloudimg-rootfs console=tty1 console=ttyS0'
    }

    result = {
        'cmdline': {
            'root': 'LABEL=cloudimg-rootfs',
            'console': True,
            'tty1': True,
            'ttyS0': True
        },
        'proc_cmdline': {
            'root': 'LABEL=cloudimg-rootfs',
            'console': ['tty1', 'ttyS0']
        }
    }

    root = tempfile.mkdtemp()
    os.chdir(root)
    for (n,d) in facts.items():
        os.makedirs(os.path.dirname(n))

# Generated at 2022-06-20 19:06:49.523471
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts import ModuleStub

    class CollectorStub(CmdLineFactCollector):
        _fact_ids = set()

        def _get_proc_cmdline(self):
            return 'a=b a=c c=d'

    module = ModuleStub()
    collector = CollectorStub()

    cmdline_facts = collector.collect(module)

    assert cmdline_facts['cmdline']['a'] == 'c'
    assert cmdline_facts['cmdline']['c'] == True
    assert cmdline_facts['proc_cmdline']['a'] == ['b', 'c']
    assert cmdline_facts['proc_cmdline']['c'] == 'd'

# Generated at 2022-06-20 19:06:54.911035
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline', "Name is not cmdline"
    assert obj._fact_ids == set(), "_fact_ids should be empty"

# Generated at 2022-06-20 19:07:01.141708
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Test with cmdline parameters not in the command line
    data = ""
    cmdline_facts = CmdLineFactCollector()
    result = cmdline_facts._parse_proc_cmdline(data)
    expected_result = {}
    assert result == expected_result

    result = cmdline_facts._parse_proc_cmdline_facts(data)
    assert result == expected_result

    # Test with one cmdline parameter in the command line
    data = "parameter_1"
    cmdline_facts = CmdLineFactCollector()
    result = cmdline_facts._parse_proc_cmdline(data)
    expected_result = {
        'parameter_1': True
    }
    assert result == expected_result

    result = cmdline_facts._parse_proc_cmdline_facts(data)
    expected_result

# Generated at 2022-06-20 19:07:03.170247
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert (CmdLineFactCollector.name, set()) == CmdLineFactCollector()

# Generated at 2022-06-20 19:07:06.147541
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    x = CmdLineFactCollector()
    assert x.name == "cmdline"
    assert x._fact_ids == set()


# Generated at 2022-06-20 19:07:17.742869
# Unit test for method collect of class CmdLineFactCollector

# Generated at 2022-06-20 19:07:29.867318
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    '''Unit test for method collect of class CmdLineFactCollector'''
    cmdline_collector = CmdLineFactCollector()

    # Get the content of the cmdline file
    def mock_get_file_content(filename):
        return "a=1 b c=2 d= e=3 f=g h i=j=k l=m=n=o"

    # Unit test object with patched function
    cmdline_collector.get_file_content = mock_get_file_content


# Generated at 2022-06-20 19:07:40.473822
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    class Options():
        pass

    cmdline_collector = CmdLineFactCollector(Options())

    data = 'root=UUID=1cdae9c8-a131-4cdd-8330-a4815bf2236f ro console=tty1 console=ttySAC3,115200n8 audit=0 SELINUX=disabled'
    cmdline = cmdline_collector._parse_proc_cmdline(data)
    assert cmdline['console'] == 'tty1'
    assert cmdline['audit'] == '0'

    cmdline = cmdline_collector._parse_proc_cmdline_facts(data)
    assert cmdline['root'] == 'UUID=1cdae9c8-a131-4cdd-8330-a4815bf2236f'

# Generated at 2022-06-20 19:07:49.599178
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fc = CmdLineFactCollector()
    conf = cmdline_fc.get_config()
    assert conf.name == "cmdline"
    assert conf.factid is None
    assert conf.collection_timeout == 60 # Default - not overridden by set_config
    assert conf.cacheable is True
    assert conf.cache_type == 'memory' # Default - not overridden by set_config
    assert conf.cache_key_prefix is None # Default - not overridden by set_config
    assert conf.cache_key is None # Default - not overridden by set_config
    assert conf.timeout == 5 # Default - not overridden by set_config

# Generated at 2022-06-20 19:09:31.363887
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    CmdLineFactCollector = CmdLineFactCollector()
    data = "BOOT_IMAGE=/vmlinuz-3.10.0-327.28.3.el7.x86_64 root=/dev/mapper/rhel-root ro crashkernel=auto rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet LANG=en_US.UTF-8 initrd=/initramfs-3.10.0-327.28.3.el7.x86_64.img"
    result_dict = CmdLineFactCollector._parse_proc_cmdline(data)
    assert result_dict['BOOT_IMAGE'] == '/vmlinuz-3.10.0-327.28.3.el7.x86_64'
    assert result_dict

# Generated at 2022-06-20 19:10:11.782160
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    file_handle = open('/proc/cmdline', 'w')
    cmdline = 'hostname=foo\nroot=/dev/sdf1\n'
    file_handle.write(cmdline)
    file_handle.close()

    cmdline_fact_collector = CmdLineFactCollector()
    result = cmdline_fact_collector.collect()

    assert result['cmdline'] == {'hostname': 'foo', 'root': '/dev/sdf1'}
    assert result['proc_cmdline'] == {'hostname': 'foo', 'root': '/dev/sdf1'}

# Generated at 2022-06-20 19:10:19.764164
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector_obj = CmdLineFactCollector()
    assert cmdline_collector_obj is not None, "Failed to create object for CmdLineFactCollector"
    assert cmdline_collector_obj.name == 'cmdline', "Failed for cmdline"
    assert cmdline_collector_obj._fact_ids != 'cmdline', "Failed for cmdline"


# Generated at 2022-06-20 19:10:26.124429
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import os
    import platform
    import pickle
    import pytest
    import re
    import shlex
    import sys
    import tempfile

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    from ansible.module_utils._text import to_text

    # Note: we are importing the real CmdLineFactCollector class in order to
    #       test its collect() method
    from ansible.module_utils.facts.collectors.cmdline import CmdLineFactCollector

    # Initialising test environment
    temp_dir = tempfile.mkdtemp()
    proc_cmdline_path = os.path.join(temp_dir, 'proc_cmdline')

# Generated at 2022-06-20 19:10:34.358738
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    import tempfile

    with tempfile.NamedTemporaryFile('r+') as f:
        data = """
rdinit=/sbin/init
rd.break
rd.udev.log_priority=3
rd.shell=0
rd.debug
rd.systemd.show_status=auto
rd.udev.log-priority=3
root=/dev/ram0 rw
systemd.log_level=debug
systemd.log_target=console
"""
        f.write(data)
        f.flush()

        cm = CmdLineFactCollector()

        Collector.add_collection_method(cm._collect_subset_from_command, 'cmdline')
        cm.collect(collected_facts={})

# Generated at 2022-06-20 19:10:39.652919
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    import pytest
    from ansible.module_utils.facts import collector

    collector_instance = collector.get_collector('cmdline')
    assert isinstance(collector_instance, CmdLineFactCollector)


# Generated at 2022-06-20 19:10:45.258076
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    # Assigns a string to variable data
    data = 'root=LABEL=MOULINETTE ro console=ttyS0,115200n8 console=tty0 vga=792 splash=silent quiet showopts LANG=fr_FR.UTF-8'

    # Creates a Mock object named m_CmdLineFactCollector
    m_CmdLineFactCollector = CmdLineFactCollector()

    # Assigns a the Mock object m_CmdLineFactCollector to variable c
    c = m_CmdLineFactCollector

    # Creates dictionary named cmd_line_facts
    cmd_line_facts = {}

    # Assigns the string 'cmdline' to the key 'cmdline' of the dictionary named cmd_line_facts
    cmd_line_facts['cmdline'] = 'cmdline'

    # Assigns the

# Generated at 2022-06-20 19:10:46.107869
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()


# Generated at 2022-06-20 19:10:53.837859
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    expected_cmdline = {'vda2': '/', 'ro': True, 'vda1': '/boot', 'rhgb': True, 'quiet': True}
    expected_proc_cmdline = {'vda2': '/', 'ro': True, 'vda1': '/boot', 'rhgb': True, 'quiet': True}

    actual = collector.collect()
    assert 'cmdline' in actual
    assert expected_cmdline == actual['cmdline']
    assert 'proc_cmdline' in actual
    assert expected_proc_cmdline == actual['proc_cmdline']

# Generated at 2022-06-20 19:11:04.248957
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collectors.cmdline import CmdLineFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    module_mock = object()
    collected_facts = object()
    data = object()
    collector = CmdLineFactCollector()

    with FactCollector._get_module_mock(module_mock, collected_facts):
        with FactCollector._get_file_content_mock(data):
            with FactCollector._get_cmdline_dict_mock(data):
                collector.collect(module_mock, collected_facts)