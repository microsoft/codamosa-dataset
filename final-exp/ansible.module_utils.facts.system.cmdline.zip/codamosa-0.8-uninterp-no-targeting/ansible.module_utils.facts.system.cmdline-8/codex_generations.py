

# Generated at 2022-06-20 19:01:36.805830
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    proc_cmdline_contents = ('BOOT_IMAGE=/vmlinuz-3.10.0-123.el7.x86_64'
                             ' root=/dev/mapper/centos_centos7-root ro'
                             ' crashkernel=auto rd.lvm.lv=centos_centos7/root'
                             ' rd.lvm.lv=centos_centos7/swap LANG=en_US.UTF-8'
                             ' console=tty0 console=ttyS0,115200n8'
                             ' systemd.show_status=1'
                             ' initcall_debug=0')
    with open('test/files/proc_cmdline', 'w') as f:
        f.write(proc_cmdline_contents)


# Generated at 2022-06-20 19:01:39.453301
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()


# Generated at 2022-06-20 19:01:42.000276
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector is not None


# Generated at 2022-06-20 19:01:46.756877
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    resolve_list = [
    ]

    resolved_list = [
    ]

    identifiers = [
    ]

    import module_utils.facts.collectors.cmdline as cmdline_collector

    collector = cmdline_collector.CmdLineFactCollector()

    assert collector is not None


# Generated at 2022-06-20 19:01:57.516750
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    
    # test with a file content
    data = "BOOT_IMAGE=/vmlinuz-3.10.0-862.3.2.el7.x86_64 root=/dev/mapper/cl-root ro crashkernel=auto rd.lvm.lv=cl/root rd.lvm.lv=cl/swap  rhgb quiet LANG=en_US.UTF-8"

# Generated at 2022-06-20 19:02:07.637918
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    CmdLineFactCollector._get_proc_cmdline = lambda x: 'foo=bar key1 key2=value2 key3=val3=3 key4=val4key5'
    assert CmdLineFactCollector().collect() == {
        'cmdline': {'foo': 'bar', 'key1': True, 'key2': 'value2', 'key3': 'val3=3', 'key4': 'val4key5'},
        'proc_cmdline': {'foo': 'bar', 'key1': True, 'key2': 'value2', 'key3': 'val3=3', 'key4': 'val4key5'}
    }

# Generated at 2022-06-20 19:02:16.953795
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    import pytest
    from ansible.module_utils.facts.collector import CollectedFacts
    from ansible.module_utils.facts import collectors

    # This will test the constructor.
    # There are two ways to instantiate the class.
    #     1. With no parameter (i.e. pass in None)
    #     2. With an instance of CollectedFacts class.
    #
    # The constructor will assign an empty CollectedFacts object to
    # the self.collected_facts if no CollectedFacts object is given.
    #
    # Since the constructor is tested implicitly, this test will focus
    # on the case of given CollectedFacts object.
    #
    # This test will do the following things to test the constructor:
    #     1. Instantiate a CollectedFacts object.
    #     2

# Generated at 2022-06-20 19:02:25.525739
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """ Test for collect method of CmdLineFactCollector class """
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.utils import get_file_content

    with open('/proc/cmdline', 'r') as f:
        get_file_content.cache_attempts['/proc/cmdline'] = f.read()

    cmdline_collector = FactCollector.fetch_collector('CmdLineFactCollector')

    collected_facts = cmdline_collector.collect()

    assert collected_facts['cmdline'] == {
        "BOOT_IMAGE": "/kernel",
        "BOOTIF": "01-54-27-00-78-22-e2"
    }

# Generated at 2022-06-20 19:02:34.529604
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    def mock_get_file_content(path):
        return "/bin/systemd vmname=vm-01 nf_conntrack.hashsize=262144"

    CmdLineFactCollector.get_file_content = mock_get_file_content

    cmdline_facts = CmdLineFactCollector().collect()
    cmdline_expected = {
            'proc_cmdline': {'vmname': 'vm-01', 'nf_conntrack.hashsize': '262144', '/bin/systemd': True},
            'cmdline': {'vmname': 'vm-01', 'nf_conntrack.hashsize': '262144'}
            }

    assert cmdline_facts == cmdline_expected


# Generated at 2022-06-20 19:02:38.436252
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert 'cmdline' == CmdLineFactCollector().name
    assert 'CmdLineFactCollector' == CmdLineFactCollector().__class__.__name__


# Generated at 2022-06-20 19:02:55.489684
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import collector_registry
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    
    # Mock Collector class
    Collector_mock = MagicMock(spec_set=Collector)
    collector_registry.popitem() # Pop the last items of the collector_registry dictionary
    collector_registry['cmdline'] = Collector_mock # Add a new item to the collector_registry dictionary

    # Mock BaseFactCollector class
    BaseFactCollector_mock = MagicMock(spec_set=BaseFactCollector)

# Generated at 2022-06-20 19:03:05.006484
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible_collections.ansible.community.plugins.module_utils.facts.collectors.cmdline import CmdLineFactCollector
    command_line_collector = CmdLineFactCollector()

    data = 'rd.peerdist=1'
    result = command_line_collector._parse_proc_cmdline(data)
    assert result == {'rd.peerdist':'1'}
    result = command_line_collector._parse_proc_cmdline_facts(data)
    assert result == {'rd.peerdist':'1'}

    data = 'rd.peerdist=1 rd.peerdist=2'
    result = command_line_collector._parse_proc_cmdline(data)
    assert result == {'rd.peerdist':'2'}
    result = command_line_collect

# Generated at 2022-06-20 19:03:16.558987
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_content

    class CmdLineMock(CmdLineFactCollector):
        def _get_proc_cmdline(self):
            return _proc_cmdline
        def _parse_proc_cmdline_facts(self, data):
            return _parse_proc_cmdline_facts(data)

    fake_data = 'cmdline_fake_data'
    _proc_cmdline = fake_data
    _parse_proc_cmdline_facts = {}

    fact_collectors = [CmdLineFactCollector()]
    test_collectors = [CmdLineMock()]

# Generated at 2022-06-20 19:03:18.472967
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    class_instance = CmdLineFactCollector()
    assert class_instance.name == 'cmdline'
    assert class_instance._fact_ids == set()


# Generated at 2022-06-20 19:03:24.725374
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    module = AnsibleModuleMock()
    cmdline_dict = CmdLineFactCollector(module).collect()
    assert cmdline_dict is not None
    assert cmdline_dict['cmdline'] is not None
    assert cmdline_dict['cmdline']['BOOT_IMAGE'] is not None
    assert cmdline_dict['proc_cmdline'] is not None
    assert cmdline_dict['proc_cmdline']['BOOT_IMAGE'] is not None

# Generated at 2022-06-20 19:03:32.974448
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    data = 'BOOT_IMAGE=/boot/vmlinuz-3.10.0-514.26.2.el7.x86_64 root=UUID=2614d01a-a6e2-4c1e-873f-2cedd6ed0f6a ro crashkernel=auto rd.lvm.lv=centos/root rd.lvm.lv=centos/swap rhgb quiet intel_iommu=on iommu=pt vconsole.font=latarcyrheb-sun16 vconsole.keymap=us'
    cmdline_facts = CmdLineFactCollector()._parse_proc_cmdline(data)

# Generated at 2022-06-20 19:03:33.565139
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()

# Generated at 2022-06-20 19:03:37.772667
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import CollectedFacts
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils._text import to_bytes
    import platform

    if platform.system() == 'Darwin':
        expected_proc_cmdline = 'rootless=0 -v'
    else:
        expected_proc_cmdline = 'BOOT_IMAGE=/vmlinuz-3.10.0-229.el7.x86_64 root=/dev/mapper/rhel-root ro crashkernel=auto rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet LANG=en_US.UTF-8'


# Generated at 2022-06-20 19:03:38.843147
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    pass

# Generated at 2022-06-20 19:03:48.594637
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    c = CmdLineFactCollector()

    cmdline_facts = c.collect()

    assert cmdline_facts['cmdline']['BOOT_IMAGE'] == '/boot/vmlinuz-3.10.0-327.el7.x86_64'
    assert cmdline_facts['cmdline']['ro']
    assert cmdline_facts['cmdline']['root'] == '/dev/mapper/VolGroup-lv_root'
    assert cmdline_facts['cmdline']['crashkernel'] == 'auto'
    assert cmdline_facts['cmdline']['rhgb']['quiet']
    assert cmdline_facts['cmdline']['LANG'] == 'en_US.UTF-8'

# Generated at 2022-06-20 19:04:00.275083
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    CmdLineFactCollector()

# Generated at 2022-06-20 19:04:03.840135
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    o = CmdLineFactCollector() # This invokes the default constructor.
    assert o.name == 'cmdline'
    assert o._fact_ids == set()

# Generated at 2022-06-20 19:04:06.037348
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    """Test constructor of class CmdLineFactCollector."""

    # Create an object by invoking the constructor
    cmdline_fc = CmdLineFactCollector()

    assert cmdline_fc

# Generated at 2022-06-20 19:04:17.351201
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    proc_cmdline_data = """BOOT_IMAGE=(hd0,msdos1)/boot/vmlinuz-4.2.0-23-generic root=UUID=4ab4b4ec-4614-4bdf-87e6-99c6e11d95af ro quiet splash vt.handoff=7"""
    assert CmdLineFactCollector()._get_proc_cmdline() == proc_cmdline_data

# Generated at 2022-06-20 19:04:20.654992
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector().name == 'cmdline'
    assert CmdLineFactCollector()._fact_ids == set()


# Generated at 2022-06-20 19:04:23.738442
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()


# Generated at 2022-06-20 19:04:26.363605
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'


# Generated at 2022-06-20 19:04:28.707519
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    ccmdlinefc = CmdLineFactCollector()
    assert ccmdlinefc.name == 'cmdline'
    assert ccmdlinefc._fact_ids == set()


# Generated at 2022-06-20 19:04:32.556942
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()

# Generated at 2022-06-20 19:04:41.342258
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils import basic

    class AnsibleExitJson(Exception):
        """Exception class to be raised by module.exit_json and caught by the test case"""
        pass

    class AnsibleFailJson(Exception):
        """Exception class to be raised by module.fail_json and caught by the test case"""
        pass

    class ModuleMock(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs


# Generated at 2022-06-20 19:05:07.231481
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()

# Generated at 2022-06-20 19:05:10.464787
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'

# Generated at 2022-06-20 19:05:13.545475
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()

# Generated at 2022-06-20 19:05:16.403250
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert cmdline
    assert cmdline.name == 'cmdline'
    assert 'cmdline' in cmdline._fact_ids
    assert 'proc_cmdline' in cmdline._fact_ids

# Generated at 2022-06-20 19:05:19.425368
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()


# Generated at 2022-06-20 19:05:24.174470
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    from ansible.module_utils.facts.collector import CmdLineFactCollector

    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'
    assert isinstance(obj._fact_ids, set) and len(obj._fact_ids) == 0


# Generated at 2022-06-20 19:05:29.472463
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'
    assert collector._fact_ids == set(['cmdline', 'proc_cmdline'])



# Generated at 2022-06-20 19:05:31.346311
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    assert isinstance(CmdLineFactCollector().collect(), dict)

# Generated at 2022-06-20 19:05:35.676456
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    collected_facts = collector.collect()
    assert 'cmdline' in collected_facts
    assert 'proc_cmdline' in collected_facts
    assert isinstance(collected_facts['cmdline'], dict)
    assert isinstance(collected_facts['proc_cmdline'], dict)

# Generated at 2022-06-20 19:05:42.871531
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.__module__ == 'ansible.module_utils.facts.system.cmdline'
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector is not None
    assert cmdline_fact_collector.name == 'cmdline'
    assert not cmdline_fact_collector._fact_ids

# Generated at 2022-06-20 19:06:22.847233
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert isinstance(cmdline_collector, CmdLineFactCollector)

# Test the _get_proc_cmdline method

# Generated at 2022-06-20 19:06:30.672635
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    data = """\
    BOOT_IMAGE=/vmlinuz-xxxxxx-generic root=/dev/mapper/ubuntu--vg-root ro console=tty0 console=ttyS1,115200n8
    """


# Generated at 2022-06-20 19:06:34.208933
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    v = CmdLineFactCollector()
    assert v.name == 'cmdline'
    assert not v._fact_ids
    assert v.collect() == {}

# Generated at 2022-06-20 19:06:41.318987
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()
    cmdline_fact_collector = CmdLineFactCollector('')
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()
    cmdline_fact_collector = CmdLineFactCollector('name')
    assert cmdline_fact_collector.name == 'name'
    assert cmdline_fact_collector._fact_ids == set()



# Generated at 2022-06-20 19:06:42.606036
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert cmdline.name == 'cmdline'
    assert cmdline._fact_ids == set()

# Generated at 2022-06-20 19:06:50.342314
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector.get_file_content = lambda value: 'ro root=UUID=6b8be7bd-09d5-4c0e-b5bc-8e3315fc49a2 rd.luks.uuid=luks-6b8be7bd-09d5-4c0e-b5bc-8e3315fc49a2 rd.lvm.lv=fedora_vol1/root rd.lvm.lv=fedora_vol1/swap rhgb quiet'
    result = cmdline_collector.collect()

# Generated at 2022-06-20 19:06:57.342306
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts_collector = CmdLineFactCollector()
    expected_cmdline_facts = {
        'cmdline': {'root': '/dev/sda1', 'ro': True},
        'proc_cmdline': {'root': '/dev/sda1', 'ro': True}
    }
    cmdline_facts = cmdline_facts_collector.collect()
    assert cmdline_facts == expected_cmdline_facts

# Generated at 2022-06-20 19:07:07.772371
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts import FactCollector

    collected_facts = {'cmdline': {'console': 'ttyS0', 'foo': True, 'vga': '0x317'},
                       'proc_cmdline': {'console': 'ttyS0', 'foo': True, 'vga': ['0x317']}}

    with open("/proc/cmdline", "r") as f:
        cmdline = f.read()

    collector = FactCollector.fetch_collector("cmdline")
    result = collector.collect({'cmdline_data': cmdline})

    assert result == collected_facts


# Generated at 2022-06-20 19:07:18.414939
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    '''
    Unit tests for method collect of class CmdLineFactCollector
    '''
    # Test with no cmdline content
    CmdLineFactCollector._get_proc_cmdline = lambda x: ""
    collector = CmdLineFactCollector(None)
    cmdline_facts = collector.collect()

    assert not cmdline_facts

    # Test with proc_cmdline content
    CmdLineFactCollector._get_proc_cmdline = lambda x: "vmlinuz"
    collector = CmdLineFactCollector(None)
    cmdline_facts = collector.collect()

    assert cmdline_facts == {
        'cmdline': {'vmlinuz': True},
        'proc_cmdline': {'vmlinuz': True}
    }

    # Test with proc_cmdline content
    CmdLineFact

# Generated at 2022-06-20 19:07:21.081122
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'


# Generated at 2022-06-20 19:08:44.410089
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector_object = CmdLineFactCollector()
    assert cmdline_collector_object.name == 'cmdline'
    assert cmdline_collector_object._fact_ids == set()


# Generated at 2022-06-20 19:08:47.007158
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()


# Generated at 2022-06-20 19:08:56.350877
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Init CmdLineFactCollector
    cfc = CmdLineFactCollector()

    # Fetch content of test script
    with open('tests/unit/module_utils/facts/fixtures/cmdline.txt', 'r') as f:
        data = f.read()

    # Returned values of method _parse_proc_cmdline
    expected = {"bar": "valbar",
                "foo": "valfoo",
                "qux": "valqux",
                "verbose": True}

    # Returned values of method _parse_proc_cmdline_facts
    expected_facts = {"bar": "valbar",
                      "foo": "valfoo",
                      "qux": ["valqux", "valqux2"],
                      "verbose": True}

    # Test _parse_proc_cmdline


# Generated at 2022-06-20 19:08:58.922520
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()

    assert cmdline_fact_collector is not None


# Generated at 2022-06-20 19:09:04.445998
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.collect()['cmdline']['root'] == '/dev/mapper/fedora-root root=/dev/mapper/fedora-root'
    assert cmdline_collector.collect()['proc_cmdline']['console'] == ['ttyS0', 'ttyS1']

# Generated at 2022-06-20 19:09:07.739923
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'

# Generated at 2022-06-20 19:09:20.123571
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Load proc_cmdline file
    with open('tests/unit/module_utils.facts/files/proc_cmdline', 'r') as data_fh:
        data = data_fh.read()

    ccmdline_facts = CmdLineFactCollector(None)

    cmdline_facts_dict = ccmdline_facts.collect(None, None)

    cmdline_dict = {
        'ro': True,
        'root': '/dev/sdb1',
        'rdinit': '/init'
    }


# Generated at 2022-06-20 19:09:22.708401
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert cmdline

# Generated at 2022-06-20 19:09:29.813581
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline = CmdLineFactCollector() 
    assert cmdline.collect() == {
        'proc_cmdline': {'root': '/dev/sda1 ro', 'quiet': True, 'console': 'ttyS0,9600n8'},
        'cmdline': {'root': '/dev/sda1', 'quiet': True, 'console': 'ttyS0,9600n8', 'ro': True}
    }

# Generated at 2022-06-20 19:09:39.953026
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    mock_module = MockModule()
    mock_module.params = {}
    cmdline_facts_collector = CmdLineFactCollector(mock_module)
    cmdline_facts_collector._get_proc_cmdline = lambda: ''
    result = cmdline_facts_collector.collect()
    assert result == {}

    mock_module = MockModule()
    mock_module.params = {}
    cmdline_facts_collector = CmdLineFactCollector(mock_module)
    cmdline_facts_collector._get_proc_cmdline = lambda: 'a=b c d=e'
    result = cmdline_facts_collector.collect()