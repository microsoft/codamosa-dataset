

# Generated at 2022-06-20 19:01:37.881755
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import tempfile
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.utils

    tempdir = tempfile.mkdtemp()

    def get_file_content(filename):
        # test, we only have one file
        return ("BOOT_IMAGE=/boot/vmlinuz-3.16.0-30-generic "
                "root=UUID=e2025b85-c2f2-48fa-8b18-d6e36448c9a9 ro "
                "quiet splash vt.handoff=7", None)


# Generated at 2022-06-20 19:01:38.674286
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector()

# Generated at 2022-06-20 19:01:42.380456
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    test_cmdline = CmdLineFactCollector()
    assert test_cmdline.name == 'cmdline'
    assert test_cmdline._fact_ids == set()


# Generated at 2022-06-20 19:01:46.882266
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    result = collector.collect()

    # TODO: use a better test given that the output of
    # collector.collect() depends on the system executing it
    expected = {'cmdline': {}, 'proc_cmdline': {}}

    assert(result == expected)



# Generated at 2022-06-20 19:01:50.497081
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline = CmdLineFactCollector()
    result = cmdline.collect()

    assert 'cmdline' in result
    assert 'proc_cmdline' in result
    assert isinstance(result['cmdline'], dict)
    assert isinstance(result['proc_cmdline'], dict)

# Generated at 2022-06-20 19:01:53.238653
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_fact_collector = CmdLineFactCollector()
    cmdline_fact_collector.collect()
    # TODO: check result

# Generated at 2022-06-20 19:01:56.439226
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert isinstance(obj, CmdLineFactCollector)
    assert obj.name == 'cmdline'

# Generated at 2022-06-20 19:02:04.597720
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline = 'root=UUID=91be3e3c-2685-4d2e-9239-b7ecee58348c ro video='
    cmdline += 'vga=normal rhgb quiet'

# Generated at 2022-06-20 19:02:06.503446
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'

# Generated at 2022-06-20 19:02:09.088445
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    t = CmdLineFactCollector()
    assert t.name == 'cmdline'

# Generated at 2022-06-20 19:02:20.208212
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collectors.cmdline import CmdLineFactCollector
    cmdline = CmdLineFactCollector('')
    ret = cmdline.collect()
    assert(ret['cmdline'].get('BOOT_IMAGE', False))
    assert(ret['proc_cmdline'].get('BOOT_IMAGE', False))

# Generated at 2022-06-20 19:02:27.285700
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    '''Test constructor of class CmdLineFactCollector.'''
    assert CmdLineFactCollector.name == 'cmdline', 'cmdline should be the name of class CmdLineFactCollector'
    assert CmdLineFactCollector._fact_ids == set(), '_fact_ids should be empty'


# Generated at 2022-06-20 19:02:28.074728
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    pass

# Generated at 2022-06-20 19:02:34.774534
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    c = CmdLineFactCollector()
    c._get_proc_cmdline = lambda: 'foo=bar bar=baz lol=1 lama=1 lama=2 lama=3 bof=bof bof=baf'
    cmdline_facts = c.collect()
    assert cmdline_facts == {'cmdline': {'foo': 'bar', 'bar': 'baz', 'lol': True, 'lama': '3', 'bof': 'baf'},
                             'proc_cmdline': {'foo': 'bar', 'bar': 'baz', 'lol': True, 'lama': [1, 2, 3], 'bof': ['bof', 'baf']}}

# Generated at 2022-06-20 19:02:41.071871
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    result = CmdLineFactCollector().collect()
    cmdline_facts = result.get('cmdline')
    if cmdline_facts:
        if 'console=tty0' in cmdline_facts:
            res = result.get('proc_cmdline').get('console')
            if res:
                return True

# Generated at 2022-06-20 19:02:47.742003
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    result = collector.collect()
    assert isinstance(result, dict)
    assert 'cmdline' in result
    assert 'proc_cmdline' in result
    for key in result['cmdline']:
        value = result['cmdline'][key]
        if isinstance(value, bool):
            assert key in result['proc_cmdline'] and isinstance(result['proc_cmdline'][key], bool)
        else:
            assert key in result['proc_cmdline'] and result['proc_cmdline'][key] == value

# Generated at 2022-06-20 19:02:48.619688
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    pass

# Generated at 2022-06-20 19:02:52.988959
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()
    assert isinstance(CmdLineFactCollector._fact_ids, set)


# Generated at 2022-06-20 19:02:56.896145
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    result = CmdLineFactCollector()
    assert result.name == 'cmdline'
    assert result._fact_ids == set()


# Generated at 2022-06-20 19:03:00.940345
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-20 19:03:17.849981
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    real_func_get_file_content = get_file_content

# Generated at 2022-06-20 19:03:20.056236
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()



# Generated at 2022-06-20 19:03:25.139750
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert c._fact_ids == set()

if __name__ == '__main__':
    print(__doc__)
    print(test_CmdLineFactCollector.__doc__)

# Generated at 2022-06-20 19:03:38.054075
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # initialize the object
    cmdline_mod = CmdLineFactCollector()
    # for mocking and testing purpose creating dictionary of above method
    cmdline_dict = {}
    cmdline_dict["_get_proc_cmdline"] = cmdline_mod._get_proc_cmdline()
    cmdline_dict["_parse_proc_cmdline"] = cmdline_mod._parse_proc_cmdline(cmdline_mod._get_proc_cmdline())
    cmdline_dict["_parse_proc_cmdline_facts"] = cmdline_mod._parse_proc_cmdline_facts(cmdline_mod._get_proc_cmdline())
    cmdline_dict["name"] = str(cmdline_mod.name)

    # testing method returnd the dictionary
    assert isinstance(cmdline_mod.collect(), dict)
    #

# Generated at 2022-06-20 19:03:40.534156
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert cmdline.name == 'cmdline'


# Generated at 2022-06-20 19:03:49.349094
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    # Get instance of CmdLineFactCollector
    obj = CmdLineFactCollector()

    # Get the content of the /proc/cmdline file
    proc_cmdline = get_file_content('/proc/cmdline') or ''

    # Configure returned value for private method _get_proc_cmdline
    obj._get_proc_cmdline = lambda: proc_cmdline

    # Call method collect of class CmdLineFactCollector
    res_collect = obj.collect()

    # Get the content of the cmdline.txt file
    cmdline_txt = get_file_content('tests/unit/ansible_collections/ansible/community/files/facts/cmdline.txt')


# Generated at 2022-06-20 19:03:54.810202
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    '''Test the collect() method of the CmdLineFactCollector class'''

    def get_file_content_mock(filename):
        '''Method to mock get_file_content()'''
        if filename == '/proc/cmdline':
            return '/boot/vmlinuz-5.0.5-200.fc29.x86_64 BOOT_IMAGE=/boot/vmlinuz-5.0.5-200.fc29.x86_64 ro root=UUID=c976b3ed-3e3f-472a-ac2c-be98a1c8e81b rhgb quiet LANG=en_US.UTF-8 rd.driver.blacklist=nouveau rd.lvm.lv=fedora/root rd.lvm.lv=fedora/swap'
        return

# Generated at 2022-06-20 19:03:57.648589
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert isinstance(obj, CmdLineFactCollector)

# Generated at 2022-06-20 19:04:03.559004
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    """
    Constructor of CmdLineFactCollector class
    """

    cmdline_obj = CmdLineFactCollector()

    assert cmdline_obj.name == 'cmdline'
    assert cmdline_obj._fact_ids == set()



# Generated at 2022-06-20 19:04:16.129788
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    fact_collector = CmdLineFactCollector()

    # Test collect method when file is empty
    collected_facts = fact_collector.collect()
    assert collected_facts == {}

    # Test collect method when file contains data
    data = "ROOTDEV=/dev/sda1 BOOT_IMAGE=/boot/vmlinuz-3.10.0-327.el7.x86_64 root=UUID=cde36701-a7c1-4cb0-8744-0b13d4ffba60"
    fact_collector._get_file_content = lambda x: data

    collected_facts = fact_collector.collect()

# Generated at 2022-06-20 19:04:41.315348
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    cmdline_facts = collector.collect()
    assert isinstance(cmdline_facts, dict)
    assert cmdline_facts['cmdline']['root'] == '/dev/sda1'
    assert cmdline_facts['proc_cmdline']['root'] == '/dev/sda1'

    # Test for RHEL7.4 and EL7 sysctl facts
    assert cmdline_facts['proc_cmdline']['BOOT_IMAGE'] == '/boot/vmlinuz-3.10.0-862.2.3.el7.x86_64'
    assert cmdline_facts['proc_cmdline']['console'] == '/dev/tty1'
    assert cmdline_facts['proc_cmdline']['crashkernel'] == 'auto'
    assert cmd

# Generated at 2022-06-20 19:04:44.562636
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    o = CmdLineFactCollector()
    assert o is not None
    assert o.name == 'cmdline'
    assert o._fact_ids == set()


# Generated at 2022-06-20 19:04:57.540080
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # First execute the collect() method for the class under test.
    # This is a test for "cmdline" fact
    fact = CmdLineFactCollector()
    cmdline = fact.collect()
    # This is a test for "proc_cmdline" fact
    proc_cmdline = fact.collect()

    # Return values of collect() method can be different depending on the
    # environment that is being tested. It is therefore necessary to
    # verify the returned values
    assert cmdline['cmdline'] is not None
    assert proc_cmdline['proc_cmdline'] is not None

    # Create a sample content for /proc/cmdline file

# Generated at 2022-06-20 19:05:05.625678
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    data = 'root=/dev/sda1 rw quiet vga=normal console=ttyS0'
    _cmdline_facts = CmdLineFactCollector()
    cmdline_facts = _cmdline_facts._parse_proc_cmdline(data)
    assert cmdline_facts['root'] == '/dev/sda1'
    assert cmdline_facts['rw'] is True
    assert cmdline_facts['quiet'] is True
    assert cmdline_facts['vga'] == 'normal'
    assert cmdline_facts['console'] == 'ttyS0'

# Generated at 2022-06-20 19:05:11.565622
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    facts = collector.collect()
    assert 'cmdline' in facts
    assert 'proc_cmdline' in facts
    assert 'proc_cmdline' in facts['proc_cmdline']

# Generated at 2022-06-20 19:05:14.371784
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert cmdline.name == 'cmdline'
    assert cmdline._fact_ids == set()

# Generated at 2022-06-20 19:05:16.072529
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'
    assert obj._fact_ids == set()

# Generated at 2022-06-20 19:05:25.966684
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Create an instance of CmdLineFactCollector
    CmdLineFactCollector_obj = CmdLineFactCollector()

    # Data to be returned by CmdLineFactCollector._get_proc_cmdline()
    data = 'BOOT_IMAGE=/vmlinuz-4.4.0-112-generic root=UUID=f6fb49c6-a90f-4dee-b0e7-c6f3e3c97717 ro quiet splash'

    # Specify the return value of CmdLineFactCollector._get_proc_cmdline
    CmdLineFactCollector_obj._get_proc_cmdline = lambda: data

    # Collect the facts
    cmdline_fact = CmdLineFactCollector_obj.collect()


# Generated at 2022-06-20 19:05:28.132403
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()

# Generated at 2022-06-20 19:05:37.631578
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline = """rd.rdshell=0 rd.live.check rd.liveimg rd.luks=0 rd.luks.uuid=luks-9fd9c281-f4a4-4dc4-bfa6-15f6ba88f892 rd.lvm.vg=rhel rd.lvm.lv=root rd.lvm.lv=swap rhgb quiet console=tty0 console=ttyS0,115200n8
    """
    cmdline_dict = {}

# Generated at 2022-06-20 19:06:12.241474
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    a = CmdLineFactCollector()
    assert a.name == 'cmdline'
    assert a._fact_ids == set()

# Generated at 2022-06-20 19:06:15.851668
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline']['root'] == '/dev/disk/by-uuid/d889f6a8-1a68-408b-b1c3-b3c8beb9ece9'
    assert cmdline_facts['cmdline']['ro'] == True
    assert cmdline_facts['proc_cmdline']['root'] == 'd889f6a8-1a68-408b-b1c3-b3c8beb9ece9'
    assert cmdline_facts['proc_cmdline']['ro'] == True

# Generated at 2022-06-20 19:06:22.915383
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Set up
    def test_get_file_content(filename):
        return 'one=1'

    # Run
    test_collector = CmdLineFactCollector()

    # Verify
    assert test_collector.name == 'cmdline'
    assert test_collector._fact_ids == set()

# Generated at 2022-06-20 19:06:29.925014
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """
    Method to test collect method of class CmdLineFactCollector
    """
    try:
        from ansible.module_utils._text import to_native
    except ImportError:
        from ansible.module_utils.basic import to_native
    try:
        import ansible.module_utils.facts.collector
    except ImportError:
        import lib.ansible.module_utils.facts.collector
    try:
        import ansible.module_utils.facts.utils
    except ImportError:
        import lib.ansible.module_utils.facts.utils

    fake_module = {}
    fake_module.get_bin_path = lambda x: x
    # Setting file permission as read only
    fake_module.set_fs_attributes = lambda x, y: (True, '', '')


# Generated at 2022-06-20 19:06:40.124351
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """Test the collect() method of CmdLineFactCollector."""
    cmdlc = CmdLineFactCollector()
    cmdline_facts = cmdlc.collect()
    assert cmdline_facts is not None, 'Failed to collect any cmdline facts.'

    assert 'cmdline' in cmdline_facts, 'Did not find cmdline property.'
    assert 'proc_cmdline' in cmdline_facts, 'Did not find proc_cmdline property.'
    assert cmdline_facts['cmdline'] is not None, 'Failed to collect cmdline.'
    assert cmdline_facts['proc_cmdline'] is not None, 'Failed to collect proc_cmdline.'
    cmdline = cmdline_facts['cmdline']
    proc_cmdline = cmdline_facts['proc_cmdline']


# Generated at 2022-06-20 19:06:44.698175
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.utils import get_file_content

    cmdline_facts = CmdLineFactCollector().collect()
    
    assert cmdline_facts is not None
    assert len(cmdline_facts) == 2
    assert 'cmdline' in cmdline_facts
    assert 'proc_cmdline' in cmdline_facts
    for key in cmdline_facts['cmdline']:
        assert isinstance(cmdline_facts['cmdline'][key], str)
    for key in cmdline_facts['proc_cmdline']:
        assert isinstance(cmdline_facts['proc_cmdline'][key], str)

# Generated at 2022-06-20 19:06:52.091671
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector1 = CmdLineFactCollector()
    data1 = "root=/dev/sda2 net.ifnames=0 biosdevname=0 elevator=deadline"
    collector1.get_file_content = lambda x: data1
    assert collector1.collect() == {'cmdline': {'root': '/dev/sda2', 'net.ifnames': '0', 'biosdevname': '0', 'elevator': 'deadline'}, 'proc_cmdline': {'root': '/dev/sda2', 'net.ifnames': '0', 'biosdevname': '0', 'elevator': 'deadline'}}

    collector2 = CmdLineFactCollector()

# Generated at 2022-06-20 19:06:55.531871
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector is not None
    assert collector._name == 'cmdline'
    assert collector._fact_ids is not None

# Generated at 2022-06-20 19:07:01.308364
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    # Initial setup for method call
    class MockCmdLineFactCollector(CmdLineFactCollector):
        def _get_proc_cmdline(self):
            return "root=/dev/mapper/os-root ro console=ttyS0,115200 panic=1"

    # Create CmdLineFactCollector object
    cmd_line_fact_collector = MockCmdLineFactCollector()

    # Call method collect
    test_cmdline_facts = cmd_line_fact_collector.collect()

    # Expected result: Two keys, cmdline and proc_cmdline
    # cmdline key should have a value of a dict of 7 elements
    # proc_cmdline key should have a value of a dict of 7 elements
    assert len(test_cmdline_facts) == 2

# Generated at 2022-06-20 19:07:11.170496
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    class MockModule():
        def __init__(self):
            self.params = {}


# Generated at 2022-06-20 19:08:29.377454
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_collector = CmdLineFactCollector()
    assert cmd_collector is not None

# Generated at 2022-06-20 19:08:37.356066
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Test with an empty file
    c = CmdLineFactCollector()
    data = c._get_proc_cmdline_mock
    data.return_value = ''
    result = c.collect()
    assert result == {}

    # Test with a valid string
    data.return_value = 'foo=bar baz=fizz boff=boz'
    result = c.collect()
    assert result['cmdline'] == {'foo': 'bar', 'baz': 'fizz', 'boff': 'boz'}
    assert result['proc_cmdline'] == {'foo': 'bar', 'baz': 'fizz', 'boff': 'boz'}

    # Test with a valid string and several options of the same type

# Generated at 2022-06-20 19:08:39.077015
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'

# Generated at 2022-06-20 19:08:49.094240
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import os
    import tempfile
    import stat

    # Create the cmdline file
    (fd, fileName) = tempfile.mkstemp(prefix='cmdline_test_', text=True)
    os.write(fd, "ip=192.168.0.10  ip=192.168.0.11  foo=bar  test_lsb_distributor_id=TEST_DISTRIBUTOR_ID  test_lsb_distributor_id=TEST_DISTRIBUTOR_ID  test_lsb_release=TEST_LSB_RELEASE  test_is_virtual=TEST_IS_VIRTUAL  test_is_container=TEST_IS_CONTAINER\n")
    os.write(fd, "ip=192.168.0.12\n")
    os.write

# Generated at 2022-06-20 19:08:51.572407
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.collect() == {'cmdline': {}, 'proc_cmdline': {}}

# Generated at 2022-06-20 19:08:54.356318
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdlinefactcollector = CmdLineFactCollector()
    cmdlinefactcollector.collect()
    assert cmdlinefactcollector.collect()['cmdline']['console'] == 'ttyS0,115200'

# Generated at 2022-06-20 19:08:58.409325
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts import FactsCollector
    collector = CmdLineFactCollector()
    collected_facts = FactsCollector()

    result = collector.collect(collected_facts=collected_facts)

    assert 'cmdline' in result

    assert len(result['cmdline'].keys()) != 0

# Generated at 2022-06-20 19:09:08.854662
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_dict = CmdLineFactCollector()._parse_proc_cmdline('BOOT_IMAGE=/boot/vmlinuz-2.6.32-573.el6.x86_64 root=UUID=9fc9b5f6-5d59-4bc6-a3c1-28a86bfbf6bb ro rd_NO_PLYMOUTH crashkernel=auto rd_NO_PLYMOUTH rhgb quiet LANG=en_US.UTF-8')
    assert cmdline_dict['root'] == 'UUID=9fc9b5f6-5d59-4bc6-a3c1-28a86bfbf6bb'
    assert cmdline_dict['crashkernel'] == 'auto'

# Generated at 2022-06-20 19:09:10.798555
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()



# Generated at 2022-06-20 19:09:13.830772
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()
