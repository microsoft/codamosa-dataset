

# Generated at 2022-06-20 19:01:30.527053
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert cmdline.name == 'cmdline'
    assert cmdline._fact_ids == set()

# Generated at 2022-06-20 19:01:36.215723
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    assert CmdLineFactCollector.collect({}) == {
        'cmdline': {
            'console': 'tty1',
            'ro': True,
            'root': '/dev/sda3',
            'rootdelay': '10'
        },
        'proc_cmdline': {
            'console': 'tty1',
            'ro': True,
            'root': '/dev/sda3',
            'rootdelay': '10'
        }
    }


# Generated at 2022-06-20 19:01:37.816543
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert c._fact_ids == set()

# Generated at 2022-06-20 19:01:40.689349
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    test_collector = CmdLineFactCollector()
    result = test_collector.collect()
    assert isinstance(result, dict)
    assert 'cmdline' in result
    assert isinstance(result['cmdline'], dict)
    assert 'proc_cmdline' in result
    assert isinstance(result['proc_cmdline'], dict)
# End unit test

# Generated at 2022-06-20 19:01:43.152762
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    expected_name = 'cmdline'
    c = CmdLineFactCollector()
    assert c.name == expected_name
    

# Generated at 2022-06-20 19:01:55.199143
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Given
    class Mocked(object):
        def __init__(self):
            self.value = None

        def read(self):
            return "foo=bar baz=quz one_word"

    CmdLineFactCollector._get_proc_cmdline = lambda self: Mocked()

    cmdline_facts = {'cmdline': {'foo': 'bar', 'baz': 'quz', 'one_word': True},
                     'proc_cmdline': {'foo': 'bar', 'baz': 'quz', 'one_word': 'True'}}

    # When
    actual_cmdline_facts = CmdLineFactCollector().collect()

    # Then
    assert actual_cmdline_facts == cmdline_facts

# Generated at 2022-06-20 19:02:00.277280
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    proc_cmdline_data = 'BOOT_IMAGE=/vmlinuz-4.4.0-53-generic'
    f = CmdLineFactCollector()
    f._get_proc_cmdline = lambda: proc_cmdline_data
    cmdline_facts = f.collect()
    expected_dict = {'BOOT_IMAGE': '/vmlinuz-4.4.0-53-generic'}
    assert cmdline_facts['cmdline'] == expected_dict
    assert cmdline_facts['proc_cmdline'] == expected_dict


# Generated at 2022-06-20 19:02:04.499022
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collectors.cmdline import CmdLineFactCollector
    cmd_line_fact_collector = CmdLineFactCollector()
    lst_cmdline_facts = cmd_line_fact_collector.collect()
    assert lst_cmdline_facts


# Generated at 2022-06-20 19:02:11.313122
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # check that all cmdline parameters are added to cmdline dictionary
    fact_collector = CmdLineFactCollector(None, None)
    cmdline_result = fact_collector._parse_proc_cmdline_facts("BOOT_IMAGE=3.10.0-229.14.1.el7.x86_64 root=/dev/mapper/rhel-root ro crashkernel=auto rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet LANG=en_US.UTF-8")

# Generated at 2022-06-20 19:02:16.317932
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    
    assert cmdline_fact_collector.name == "cmdline"
    assert isinstance(cmdline_fact_collector._fact_ids, set)


# Generated at 2022-06-20 19:02:26.146513
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'
    assert isinstance(obj._fact_ids, set)
    assert obj._fact_ids == set()


# Generated at 2022-06-20 19:02:28.626409
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'


# Generated at 2022-06-20 19:02:29.772711
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    assert CmdLineFactCollector().collect()

# Generated at 2022-06-20 19:02:37.695718
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collectors.cmdline import CmdLineFactCollector

    fact_collector = CmdLineFactCollector()

    # Define the test data
    test_data = b"\
    BOOT_IMAGE=/vmlinuz-4.4.0-72-generic.efi.signed root=/dev/mapper/ubuntu--vg-root ro \
    quiet zswap.enabled=1 zswap.compressor=lz4 zswap.max_pool_percent=10 zswap.zpool=z3fold \
    resume=/dev/mapper/ubuntu--vg-swap_1 hpet=disable"

    # Define the expected data

# Generated at 2022-06-20 19:02:40.414373
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'


# Generated at 2022-06-20 19:02:42.858375
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert(collector.name == 'cmdline')
    assert(collector._fact_ids == set())

# Generated at 2022-06-20 19:02:44.932467
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    fact_collector = CmdLineFactCollector()
    fact_collector.collect()

# Generated at 2022-06-20 19:02:46.968030
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector().name == 'cmdline'

# Generated at 2022-06-20 19:02:50.906369
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    result = collector.collect()
    assert result.get('cmdline')
    assert result.get('proc_cmdline')

# Generated at 2022-06-20 19:02:52.588505
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()


# Generated at 2022-06-20 19:03:10.882096
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Setting up the test variables
    CmdLineFactCollector._fact_ids.clear()
    exp_cmdline_facts = {'cmdline': {'ro': True, 'root': '/dev/sda1'},
                         'proc_cmdline': {'ro': True, 'root': '/dev/sda1'}
                         }
    test_proc_cmdline = '/dev/sda1 ro'

    # Creating the instance of the class
    cmdline_collector = CmdLineFactCollector()

    # Overriding the method _get_proc_cmdline to return the test string
    def test_get_proc_cmdline(self):
        return test_proc_cmdline


# Generated at 2022-06-20 19:03:12.127092
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector


# Generated at 2022-06-20 19:03:15.367856
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()

    assert cmdline_fact_collector 
    assert cmdline_fact_collector.name == 'cmdline'


# Generated at 2022-06-20 19:03:16.938012
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()

# Generated at 2022-06-20 19:03:26.058642
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import os
    import ansible.module_utils.facts.collectors.cmdline.cmdline as cmd_f

    # Tests are run on linux Debian 9
    # First get the kernel version of the OS to be able to get a proc/cmdline file
    kernel_version_test = os.uname()[2]

    # Get proc/cmdline file and content
    cmdline_test_file = "/boot/config-%s" % kernel_version_test
    cmdline_test_data = None
    with open(cmdline_test_file) as cmdline_test:
        cmdline_test_data = cmdline_test.read()

    # Create a fake module to pass to the method collect
    module = type('', (object,), dict(params=dict()))

    # Get the expected results from collect method
    cmdline_

# Generated at 2022-06-20 19:03:38.229331
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """
    Unit test for method collect of class CmdLineFactCollector
    """

    class MockModule:
        def __init__(self, params):
            self.params = params

    class FakeCmdLineCollector(CmdLineFactCollector):
        def __init__(self):
            self._fact_ids = set()

        def _get_proc_cmdline(self):
            return "BOOT_IMAGE=/vmlinuz-4.4.0-64-generic root=/dev/mapper/ubuntu--vg-root ro quiet splash vt.handoff=7"


# Generated at 2022-06-20 19:03:48.340341
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    CmdLineFactCollector.COLLECT_METHOD = 'collect'
    cmdline_collector = CmdLineFactCollector()
    cmdline_data = cmdline_collector.collect()
    assert 'cmdline' and 'proc_cmdline' in cmdline_data

    CmdLineFactCollector.COLLECT_METHOD = 'setup'
    cmdline_collector = CmdLineFactCollector()
    cmdline_data = cmdline_collector.collect()
    assert 'cmdline' and 'proc_cmdline' in cmdline_data

    CmdLineFactCollector.COLLECT_METHOD = 'default'
    cmdline_collector = CmdLineFactCollector()
    cmdline_data = cmdline_collector.collect()

# Generated at 2022-06-20 19:03:50.548273
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    instance = CmdLineFactCollector()
    assert instance.name == 'cmdline'
    assert type(instance._fact_ids) is set

# Unit test to check if the correct value is returned by method _parse_proc_cmdline

# Generated at 2022-06-20 19:03:52.501383
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
   assert CmdLineFactCollector.name == 'cmdline'

# Generated at 2022-06-20 19:04:00.721124
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    def mock_get_proc_cmdline(a,b):
        return 'test_key=test_value'

    class MockCmdLineFactCollector(CmdLineFactCollector):
        def _get_proc_cmdline(self):
            return mock_get_proc_cmdline(None, None)

    fact_collector = MockCmdLineFactCollector()

    expected_result = {
        'cmdline': {
            'test_key': 'test_value'
        },
        'proc_cmdline': {
            'test_key': 'test_value'
        }
    }

    actual_result = fact_collector.collect()
    assert actual_result == expected_result

# Generated at 2022-06-20 19:04:13.350213
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert isinstance(CmdLineFactCollector(), CmdLineFactCollector)


# Generated at 2022-06-20 19:04:19.478110
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts import ModuleStub

    # create instance of class CmdLineFactCollector
    fact_collector = CmdLineFactCollector()

    # create instance of class ModuleStub
    module_stub = ModuleStub()

    # call method collect of class ProcCmdlineFactCollector
    data = fact_collector.collect(module_stub.module)

    if data:
        assert data['cmdline']

    cmdline_facts = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}

    if data:
        assert data['proc_cmdline'] == cmdline_facts

# Generated at 2022-06-20 19:04:28.821121
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_data = """root=UUID=2a2aa75c-4e4b-4e4b-4e4b-4e4ba75c4e4b ro audit=0 rd.lvm.lv=centos/swap crashkernel=auto  rd.lvm.lv=centos/root  rhgb quiet LANG=en_US.UTF-8"""    # noqa
    expected_dict = dict(root='UUID=2a2aa75c-4e4b-4e4b-4e4b-4e4ba75c4e4b', audit='0', rd_lvm_lv='centos/swap', crashkernel='auto', rd_lvm_lv='centos/root', rhgb=True, quiet=True, LANG='en_US.UTF-8')

# Generated at 2022-06-20 19:04:36.362089
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    result = CmdLineFactCollector().collect()

    assert result is not None
    assert set(result.keys()) == set(['cmdline', 'proc_cmdline'])
    assert result['cmdline'] is not None
    assert isinstance(result['cmdline'], dict)
    assert result['proc_cmdline'] is not None
    assert isinstance(result['proc_cmdline'], dict)

# Generated at 2022-06-20 19:04:37.709943
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()

# Generated at 2022-06-20 19:04:40.759678
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    assert isinstance(collector.collect(), dict)

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-20 19:04:43.726287
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'

# Generated at 2022-06-20 19:04:50.657929
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()


# Generated at 2022-06-20 19:04:54.471943
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    fact_collector = CmdLineFactCollector()
    assert fact_collector.name == 'cmdline'
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:04:58.648783
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj_cmdline_fact_collector = CmdLineFactCollector()
    command_line_facts = obj_cmdline_fact_collector.collect()
    # Assign a boolean TRUE to a variable if the command_line_facts is not null
    cmdline_bool = bool(command_line_facts)
    # Test if the value of the boolean is True
    assert cmdline_bool is True

# Generated at 2022-06-20 19:05:27.121155
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()

    cmdline_collector._get_proc_cmdline = lambda : 'ansible_fact=True'
    cmdline_collector._parse_proc_cmdline = lambda : 'ansible_fact=True'
    cmdline_collector._parse_proc_cmdline_facts = lambda : 'ansible_fact=True'

    assert cmdline_collector.collect() == {'cmdline': {'ansible_fact': 'True'}, 'proc_cmdline': {'ansible_fact': 'True'}}

# Generated at 2022-06-20 19:05:37.246101
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Test process initialization
    # Ensure below code can work in any environment
    # For example, some environment only has parsed cmdline data
    CmdLineFactCollector._fact_ids = set()
    CmdLineFactCollector._fact_ids.add('cmdline')
    CmdLineFactCollector._fact_ids.add('proc_cmdline')

    # Define a mock class so that original class can be override
    class MockContent:
        def __init__(self, data):
            self._data = data

        def content(self):
            return self._data

    class MockGetFileContent:
        def __init__(self, data):
            self._data = data

        def get_file_content(self, file_path):
            return MockContent(self._data)


# Generated at 2022-06-20 19:05:41.658368
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import os
    import tempfile
    import textwrap

    (osf, osff) = tempfile.mkstemp(text=True)

# Generated at 2022-06-20 19:05:43.093360
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact = CmdLineFactCollector()
    assert cmdline_fact.name == CmdLineFactCollector.name
    assert cmdline_fact._fact_ids == CmdLineFactCollector._fact_ids

# Generated at 2022-06-20 19:05:51.419247
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Return value for method _get_proc_cmdline
    proc_cmdline_data = 'BOOT_IMAGE=/vmlinuz-4.9.0-6-amd64 root=/dev/mapper/cl-root \
 ro quiet intel_iommu=off amd_iommu=off nd_iov=0 \
 crashkernel=128M@16M crashkernel=256M@32M iommu=pt \
 docker/1=name=systemd/1 ds=nocloud-net'
    cmdline_facts = {}
    # Return value for method _parse_proc_cmdline

# Generated at 2022-06-20 19:05:58.816754
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # data = 'ansible_python_interpreter=/usr/bin/python\n'
    # data = 'BOOT_IMAGE=/vmlinuz-3.10.0-327.10.1.el7.x86_64\n'
    # data = 'ro root=/dev/mapper/rhel-root\n'
    data = 'rw root=/dev/mapper/rhel-root\n'

    # data = ['rw root=/dev/mapper/rhel-root', 'ro root=/dev/mapper/rhel-root']
    # data = get_file_content('/proc/cmdline')
    # data_repr = repr(data)
    cmdline_facts = {}
    collector = CmdLineFactCollector()

    cmdline_facts['cmdline'] = collector._parse_proc_

# Generated at 2022-06-20 19:06:07.333448
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import TestFactCollector

    TestFactCollector.add_collector(CmdLineFactCollector())

    fake_cmdline_data = ('root=/dev/sda1 ro net.ifnames=0 biosdevname=0 '
                         'rootdelay=300 noapic')
    test_collected_facts = TestFactCollector(
        ansible_facts=dict(proc_cmdline=fake_cmdline_data)
    )
    ansible_facts = test_collected_facts.collect(
        module=None, collected_facts=None,
    )

    cmdline_facts = ansible_facts['cmdline']
    assert cmdline_facts['root'] == '/dev/sda1'
    assert cmdline_facts['ro'] is True

# Generated at 2022-06-20 19:06:13.222363
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact = CmdLineFactCollector()
    assert cmdline_fact.collector == 'CmdLineFactCollector'
    assert cmdline_fact.collect() == {'cmdline': {}, 'proc_cmdline': {}}

# Generated at 2022-06-20 19:06:20.634688
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    '''
    Test collect method of class CmdLineFactCollector
    '''

    # Arrange
    CmdLineFactCollector._fact_ids = set()


# Generated at 2022-06-20 19:06:21.905858
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = CmdLineFactCollector()
    assert (hasattr(cmdline_facts, 'name'))
    assert (hasattr(cmdline_facts, 'collect'))

# Generated at 2022-06-20 19:07:11.388478
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # initialize
    cmdline_facts = {}
    # make a test
    data = 'foo=bar param1=one param2=two param3=three'
    cmdline_facts['cmdline'] = {'foo': 'bar', 'param1': 'one', 'param2': 'two', 'param3': 'three'}
    cmdline_facts['proc_cmdline'] = {'foo': 'bar', 'param1': 'one', 'param2': ['two', 'three']}
    # test result
    assert CmdLineFactCollector()._parse_proc_cmdline(data) == cmdline_facts['cmdline']
    assert CmdLineFactCollector()._parse_proc_cmdline_facts(data) == cmdline_facts['proc_cmdline']
    assert CmdLineFactCollector().collect() == cmdline_

# Generated at 2022-06-20 19:07:20.761880
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector(module=None)

    CmdLineCollector = CmdLineFactCollector(module=None)

    with open('/proc/cmdline', 'r') as f:
        proc_cmdline = f.read()

    proc_cmdline_facts = {}

    for piece in shlex.split(proc_cmdline, posix=False):
        item = piece.split('=', 1)
        if len(item) == 1:
            proc_cmdline_facts[item[0]] = True
        else:
            proc_cmdline_facts[item[0]] = item[1]

    #print("Returned is: ")
    #print(collector.collect())

    #print("Expected is: ")
    #print({'cmdline': proc_cmdline_facts, '

# Generated at 2022-06-20 19:07:30.794623
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Returned value of _get_proc_cmdline()
    get_proc_cmdline_value = 'BOOT_IMAGE=/vmlinuz-4.4.0-62-generic root=UUID=4e726337-11c4-4ae3-9c3d-6a8cb6c434a6 ro console=ttyS2'

    # Returned value of _parse_proc_cmdline()
    parse_proc_cmdline_value = {'BOOT_IMAGE': '/vmlinuz-4.4.0-62-generic',
                                'root': 'UUID=4e726337-11c4-4ae3-9c3d-6a8cb6c434a6',
                                'ro': True,
                                'console': 'ttyS2'}

    # Returned value

# Generated at 2022-06-20 19:07:40.738686
# Unit test for method collect of class CmdLineFactCollector

# Generated at 2022-06-20 19:07:53.184651
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    input_data_dict = {'cmdline':'BOOT_IMAGE=/vmlinuz-3.10.0-693.5.2.el7.x86_64 root=/dev/mapper/rhel-root ro crashkernel=auto rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet LANG=en_US.UTF-8'}
    input_data = 'BOOT_IMAGE=/vmlinuz-3.10.0-693.5.2.el7.x86_64 root=/dev/mapper/rhel-root ro crashkernel=auto rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet LANG=en_US.UTF-8'

    test_obj = CmdLineFact

# Generated at 2022-06-20 19:07:58.777316
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline = """
BOOT_IMAGE=/vmlinuz-3.10.0-693.21.1.el7.x86_64 root=/dev/mapper/rhel-root ro crashkernel=auto rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet LANG=en_US.UTF-8
    """.strip()

    with open('/proc/cmdline', 'w') as proc_cmdline:
        proc_cmdline.write(cmdline)

    results = CmdLineFactCollector().collect()


# Generated at 2022-06-20 19:08:01.559099
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-20 19:08:05.476974
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    module = 'ansible.module_utils.facts.cmdline'
    name = 'cmdline'
    collected_facts = None
    cmdlinefactcollector = CmdLineFactCollector()
    assert cmdlinefactcollector.name == name


# Generated at 2022-06-20 19:08:07.140300
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = CmdLineFactCollector()
    assert cmdline_facts.name == 'cmdline'



# Generated at 2022-06-20 19:08:10.246086
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance

    collector = get_collector_instance(CmdLineFactCollector)

    assert collector.collect() == {'cmdline': {}, 'proc_cmdline': {}}


# Generated at 2022-06-20 19:10:04.191974
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts import FactsEngine
    from ansible.module_utils.facts.collector.cmdline import CmdLineFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import set_file_content
    path = '/tmp/ansible_test_cmdline'
    data = 'cmdline1=1 cmdline2=2'
    set_file_content(path, data)
    facts_engine = FactsEngine()
    setattr(facts_engine, '_module', None)
    setattr(facts_engine, '_collected_facts', None)
    ccmdline_fact_collector = CmdLineFactCollector()

# Generated at 2022-06-20 19:10:06.958701
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert hasattr(CmdLineFactCollector, '_get_proc_cmdline')
    assert hasattr(CmdLineFactCollector, '_parse_proc_cmdline')
    assert hasattr(CmdLineFactCollector, '_parse_proc_cmdline_facts')
    assert hasattr(CmdLineFactCollector, 'collect')

# Generated at 2022-06-20 19:10:11.899530
# Unit test for method collect of class CmdLineFactCollector

# Generated at 2022-06-20 19:10:14.206099
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'

# Generated at 2022-06-20 19:10:24.056447
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collectors import CmdLineFactCollector
    import json

    def get_file_content(path):
        file_content = {}
        file_content['/proc/cmdline'] = 'BOOT_IMAGE=/boot/vmlinuz-3.10.0-327.36.3.el7.x86_64 root=UUID=8fe4797e-e1d0-4f59-a879-60be94abd5e1 ro crashkernel=auto rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet LANG=en_US.UTF-8'

       

# Generated at 2022-06-20 19:10:27.879407
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    expected = {'cmdline': {'BOOT_IMAGE': '/boot/kernel-i686',
                            'root': '/dev/mapper/vg00-lv00',
                            'ro': True},
                'proc_cmdline': {'BOOT_IMAGE': ['/boot/kernel-i686',
                                                '/boot/kernel-i686'],
                                 'root': '/dev/mapper/vg00-lv00',
                                 'ro': True}}
    assert CmdLineFactCollector().collect() == expected

# Generated at 2022-06-20 19:10:34.869379
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """
    Unit test of collect method of class CmdLineFactCollector
    """
    class MockFileType(object):
        """
        Class to represent the file handler of a file.
        This class will be returned by the mocked function open
        """
        def __init__(self, content):
            self.content = content

        def read(self):
            return self.content

    # we need to mock the open function here
    def open(file, mode):
        """
        Mock of the open function
        """
        # we need to test the content of the file /proc/cmdline
        # this file contains one line and this line has the format
        # param1=value1 param2=value2
        # we can test different values using this file
        content = "param1=value1 param2=value2"
        return MockFile

# Generated at 2022-06-20 19:10:44.032984
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts import processor
    from ansible.module_utils.facts.collectors.system.cmdline import CmdLineFactCollector

    def get_proc_cmdline(self):
        return "BOOT_IMAGE=/vmlinuz-3.13.0-66-generic root=/dev/mapper/vg0-root ro quiet splash vt.handoff=7"

    cmdline_collector = CmdLineFactCollector()

    cmdline_collector_get_proc_cmdline = getattr(cmdline_collector, '_get_proc_cmdline')
    setattr(cmdline_collector, '_get_proc_cmdline', get_proc_cmdline)
    cmdline_facts = cmdline_collector.collect()

# Generated at 2022-06-20 19:10:47.797901
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    result = CmdLineFactCollector().collect()
    assert result['cmdline']['ro'] == True
    assert result['proc_cmdline']['ro'] == True

# Generated at 2022-06-20 19:10:53.671496
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()

    data = cmdline_collector._get_proc_cmdline()
    cmdline_facts = {}
    cmdline_facts['cmdline'] = cmdline_collector._parse_proc_cmdline(data)
    cmdline_facts['proc_cmdline'] = cmdline_collector._parse_proc_cmdline_facts(data)

    assert cmdline_collector.collect() == cmdline_facts