

# Generated at 2022-06-20 19:01:29.917679
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert cmdline.name == 'cmdline'
    assert cmdline._fact_ids == set()

# Generated at 2022-06-20 19:01:32.590914
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline=CmdLineFactCollector()
    assert cmdline.name == 'cmdline'
    assert cmdline._fact_ids == set()


# Generated at 2022-06-20 19:01:33.684351
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert isinstance(CmdLineFactCollector(), dict)


# Generated at 2022-06-20 19:01:35.301886
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'
    assert obj._fact_ids == set()


# Generated at 2022-06-20 19:01:36.643419
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'

# Generated at 2022-06-20 19:01:38.538446
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj



# Generated at 2022-06-20 19:01:40.339588
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    pass

# Generated at 2022-06-20 19:01:50.561588
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.cmdline import CmdLineFactCollector
    import os
    import tempfile
    test_data = 'ro root=UUID=53a8a927-93e6-4d42-8af6-78e0befcc6b3 quiet console=tty0 console=ttyS0,115200n8'

# Generated at 2022-06-20 19:01:51.381864
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    pass

# Generated at 2022-06-20 19:01:56.576812
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    fact_collector = CmdLineFactCollector()
    fact_collector._get_proc_cmdline = lambda: 'console=ttyS0 acpi=off'
    cmdline_facts = fact_collector.collect()
    assert cmdline_facts['cmdline'] == {'console': 'ttyS0', 'acpi': 'off'}
    assert cmdline_facts['proc_cmdline'] == {'console': 'ttyS0', 'acpi': 'off'}


# Generated at 2022-06-20 19:02:03.698456
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    m = CmdLineFactCollector()
    c = m._get_proc_cmdline()
    d = m._parse_proc_cmdline(c)
    f = m._parse_proc_cmdline_facts(c)
    cmdline = m.collect()
    print(cmdline)

test_CmdLineFactCollector_collect()

# Generated at 2022-06-20 19:02:08.700206
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Initialize the class
    cmdline_test = CmdLineFactCollector()

    # Get the facts
    facts = cmdline_test.collect()

    # Assert the result from collect
    assert facts['cmdline']['root'] == '/dev/mapper/ubuntu--vg-root'
    assert facts['proc_cmdline']['root'] == '/dev/mapper/ubuntu--vg-root'

# Generated at 2022-06-20 19:02:11.264075
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c
    assert c.name == 'cmdline'

# Generated at 2022-06-20 19:02:13.073168
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert cmdline.name == 'cmdline'

# Generated at 2022-06-20 19:02:24.048321
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    tmp_collector = CmdLineFactCollector()

    tmp_collector._get_proc_cmdline = lambda: 'root=/dev/sda2 ro'
    tmp_collector._parse_proc_cmdline = lambda x: None
    tmp_collector._parse_proc_cmdline_facts = lambda x: None

    assert tmp_collector.collect() == {}

    tmp_collector._get_proc_cmdline = lambda: None
    tmp_collector._parse_proc_cmdline = lambda x: None
    tmp_collector._parse_proc_cmdline_facts = lambda x: None

    assert tmp_collector.collect() == {}

    tmp_collector._get_proc_cmdline = lambda: 'root=/dev/sda2 ro'

# Generated at 2022-06-20 19:02:25.107029
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = CmdLineFactCollector()
    assert 'cmdline' in cmdline_facts.collect()

# Generated at 2022-06-20 19:02:28.593555
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:02:30.328261
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_cmdline = CmdLineFactCollector()

    assert(cmdline_cmdline.name == 'cmdline')

# Generated at 2022-06-20 19:02:31.350805
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'

# Generated at 2022-06-20 19:02:43.877628
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_obj = CmdLineFactCollector()
    cmdline_obj._get_proc_cmdline = lambda: ' \n'.join(['root=UUID=2d5e6c96-2b5f-4a67-bd78-fa59d0e0f8fd',
                                                        'rw',
                                                        'boot=UUID=6d5e6c96-2b5f-4a67-bd78-fa59d0e0f8fd',
                                                        'someother=option',
                                                        'ipv6.disable=1',
                                                        'ipv6.disable=2',
                                                        'loglevel=7'])
    result = cmdline_obj.collect()

# Generated at 2022-06-20 19:03:04.507778
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Test when /proc/cmdline does not exist
    try:
        # Mock return value for method get_file_content of class CmdLineFactCollector
        def mock_get_file_content_proc_cmdline():
            return None

        # Mock method get_file_content of class CmdLineFactCollector
        CmdLineFactCollector.get_file_content = mock_get_file_content_proc_cmdline

        # Test that method collect of class CmdLineFactCollector returns an empty dict
        cmdline_fact_collector = CmdLineFactCollector()
        result = cmdline_fact_collector.collect()
        assert isinstance(result, dict)
        assert len(result) == 0
    finally:
        CmdLineFactCollector.get_file_content = get_file_content

    # Test

# Generated at 2022-06-20 19:03:07.695078
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdlineFactCollector = CmdLineFactCollector()
    assert cmdlineFactCollector is not None

# Generated at 2022-06-20 19:03:17.441631
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    class ClsMod(object):
        def __init__(self, name=None, category=None, collection=None, safe=True,
                     version=None, deprecated=False, extended=None, tree=None,
                     subclass=None, type=None, implementation=None, docs=None):
            self.name = name
            self.category = category
            self.collection = collection
            self.safe = safe
            self.version = version
            self.deprecated = deprecated
            self.extended = extended
            self.tree = tree
            self.subclass = subclass
            self.type = type
            self.implementation = implementation
            self.docs = docs


# Generated at 2022-06-20 19:03:20.055282
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    expected = {'cmdline': {'1': '2', '3': True}, 'proc_cmdline': {'1': '2', '3': True}}
    actual = CmdLineFactCollector().collect()
    assert expected == actual

# Generated at 2022-06-20 19:03:24.063014
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()

# Generated at 2022-06-20 19:03:28.603722
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert cmdline.name == 'cmdline'
    assert type(cmdline._fact_ids) is set
    assert cmdline._fact_ids == set()


# Generated at 2022-06-20 19:03:30.452636
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    fac = CmdLineFactCollector()
    assert fac.name == 'cmdline'
    assert fac._fact_ids == set()

# Generated at 2022-06-20 19:03:33.915705
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'
    assert obj._fact_ids == set()


# Generated at 2022-06-20 19:03:41.331597
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    test_collector = CmdLineFactCollector(None, None)

    test_dict = test_collector._parse_proc_cmdline("a=b c=d")
    assert(test_dict == {'a': 'b', 'c': 'd'})
    test_dict = test_collector._parse_proc_cmdline("a=b c=d test=1234")
    assert(test_dict == {'a': 'b', 'c': 'd', 'test': '1234'})
    test_dict = test_collector._parse_proc_cmdline("a=b c=d test=1234=5678")
    assert(test_dict == {'a': 'b', 'c': 'd', 'test': '1234=5678'})
    test_dict = test_collector._parse_

# Generated at 2022-06-20 19:03:45.512168
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector_obj = CmdLineFactCollector()
    assert cmdline_fact_collector_obj.name == "cmdline"


# Generated at 2022-06-20 19:04:04.859803
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    ob = CmdLineFactCollector()
    assert ob.collect() is not None

# Generated at 2022-06-20 19:04:09.371353
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    ts = CmdLineFactCollector()
    assert ts.name == "cmdline"
    assert ts.collect() == {'cmdline': {}, 'proc_cmdline': {}}


# Generated at 2022-06-20 19:04:13.205559
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact = CmdLineFactCollector()
    assert cmdline_fact.name == 'cmdline'
    assert cmdline_fact._fact_ids == set()


# Generated at 2022-06-20 19:04:14.729765
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_fact_collector = CmdLineFactCollector()
    cmdline_fact_collector.collect()
    assert cmdline_fact_collector.name == 'cmdline'

# Generated at 2022-06-20 19:04:19.192761
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline = CmdLineFactCollector()
    all_facts = cmdline.collect()
    assert 'cmdline' in all_facts
    assert 'proc_cmdline' in all_facts

# Generated at 2022-06-20 19:04:28.744501
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils._text import to_bytes
    fact_collector = CmdLineFactCollector()
    file_content = to_bytes('root=/dev/sda1 selinux=0 net.ifnames=0')
    cmdline_facts = dict(proc_cmdline=dict(root='/dev/sda1', selinux='0', net_ifnames='0'),
                         cmdline=dict(root=True, selinux='0', net_ifnames='0'))
    assert cmdline_facts == fact_collector._parse_proc_cmdline_facts(file_content)
    assert dict(cmdline=dict(root=True, selinux=True, net_ifnames=True)) == fact_collector._parse_proc_cmdline(file_content)

# Generated at 2022-06-20 19:04:29.896047
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert c._fact_ids == set()


# Generated at 2022-06-20 19:04:40.392828
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Create class
    c = CmdLineFactCollector()

    # Create a fake module
    class FakeModule():
        def __init__(self, module_name=None, module_path=None, check_mode=None, params=None):
            self.module_name = module_name
            self.module_path = module_path
            self.check_mode = check_mode
            self.params = params

    module = FakeModule()

    # Create a fake proc/cmdline file
    class FakeCmdlineFile():
        def __init__(self, file_path=None, data=None):
            self.file_path = file_path
            self.data = data

    # Create a fake file_exists function

# Generated at 2022-06-20 19:04:44.230095
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector.name == 'cmdline'


# Generated at 2022-06-20 19:04:46.086233
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert c._fact_ids == set()

# Generated at 2022-06-20 19:05:30.884884
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_sample = "BOOT_IMAGE=/boot/vmlinuz-4.15.0-64-generic root=UUID=25b69376-e7c6-4d8f-98e0-3b20de23a919 ro quiet splash vt.handoff=1 "

# Generated at 2022-06-20 19:05:33.347006
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    instance = CmdLineFactCollector()
    assert instance.name == 'cmdline'


# Generated at 2022-06-20 19:05:38.715398
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    # Test the collect method of CmdLineFactCollector to be able to
    # collect cmdline dictionary of the system.

    # To test the collect method of class CmdLineFactCollector we need to create
    # an instance of the class with a mock of the _get_proc_cmdline method
    cmdline_fact_collector = CmdLineFactCollector()
    cmdline_fact_collector._get_proc_cmdline = lambda: 'cmdline = value1'

    # Invoke the collect method
    cmdline_fact_collector.collect()

    # Check that the cmdline fact is placed into the cmdline dictionary
    assert 'cmdline' in cmdline_fact_collector.collect()
    assert 'cmdline' in cmdline_fact_collector.collect()['cmdline']



# Generated at 2022-06-20 19:05:43.681722
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    '''
    Unit test for method collect of class CmdLineFactCollector
    '''
    # Initializing an object of class CmdLineFactCollector
    cmdline_collector = CmdLineFactCollector()

    assert cmdline_collector.collect()

# Generated at 2022-06-20 19:05:56.119910
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    data = (b'BOOT_IMAGE=/vmlinuz-3.10.0-1062.18.1.el7.x86_64 root=UUID=b95d23d2-a2e7-41c8-aac0-c5f48e9128f1 ro crashkernel=auto'
            b' resume=UUID=b8c2f650-54a5-4a9a-ad55-5a5ea760d5e5 rhgb quiet LANG=en_US.UTF-8 keymap=us nofb')

    cmdline_facts = {}

# Generated at 2022-06-20 19:06:00.198869
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdobj = CmdLineFactCollector()
    assert cmdobj.name == 'cmdline'

    _fact_ids = set()
    assert cmdobj._fact_ids == _fact_ids

# Generated at 2022-06-20 19:06:07.692325
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    c = CmdLineFactCollector()
    c._get_proc_cmdline = MagicMock(return_value="BOOT_IMAGE=/@/vmlinuz-3.18.26-1.vz7.47.37 BOOTIF=01-00-17-1b-7b-d6-05 ip=:::::eth0:dhcp audit=1")
    c._parse_proc_cmdline = MagicMock(return_value={"BOOT_IMAGE": "/@/vmlinuz-3.18.26-1.vz7.47.37", "BOOTIF": "01-00-17-1b-7b-d6-05", "ip": ":::::eth0:dhcp", "audit": "1"})

# Generated at 2022-06-20 19:06:10.528027
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert c.collect() == {}

# Generated at 2022-06-20 19:06:11.480249
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    o = CmdLineFactCollector()
    assert o.name == 'cmdline'
    assert o._fact_ids == set()


# Generated at 2022-06-20 19:06:20.251074
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    expected_cmdline = {'DEFAULT_RUNLEVEL': '2',
                        'LANG': 'en_US.UTF-8',
                        'BOOT_IMAGE': '/vmlinuz-3.10.0-327.36.3.el7.x86_64',
                        'crashkernel': '128M',
                        'audit=1': True}

    expected_proc_cmdline = {'DEFAULT_RUNLEVEL': '2',
                             'LANG': 'en_US.UTF-8',
                             'BOOT_IMAGE': '/vmlinuz-3.10.0-327.36.3.el7.x86_64',
                             'crashkernel': ['128M', '256M'],
                             'audit': ['1', '0']}

    proc_cmdline

# Generated at 2022-06-20 19:07:40.281767
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline = CmdLineFactCollector()
    cmdline._get_proc_cmdline = lambda: 'console=ttyS0,115200 rdinit=/sbin/init'

    cmdline_facts = cmdline.collect()

    assert cmdline_facts == {
        'cmdline': {
            'console': 'ttyS0,115200',
            'rdinit': '/sbin/init'
        },
        'proc_cmdline': {
            'console': 'ttyS0,115200',
            'rdinit': '/sbin/init'
        }
    }

# Generated at 2022-06-20 19:07:47.304840
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = {'cmdline': {'console': 'ttyS0'}, 'proc_cmdline': {'console': 'ttyS0'}}

    cmdline_fact_collector = CmdLineFactCollector()
    cmdline_fact_collector._get_proc_cmdline = lambda: cmdline_facts['cmdline']['console'] + "=" + cmdline_facts['proc_cmdline']['console']
    assert cmdline_fact_collector.collect() == cmdline_facts


# Generated at 2022-06-20 19:07:56.085975
# Unit test for method collect of class CmdLineFactCollector

# Generated at 2022-06-20 19:07:57.702498
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdlineFactCollector = CmdLineFactCollector()
    assert cmdlineFactCollector.name == 'cmdline'

# Generated at 2022-06-20 19:08:00.021037
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    cmdline_facts = collector.collect()


# Generated at 2022-06-20 19:08:03.731978
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.test.test_cmdline import TestCmdLineFactCollector
    test_instance = TestCmdLineFactCollector()
    test_instance.collect()

# Generated at 2022-06-20 19:08:08.276643
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cf = CmdLineFactCollector()
    data = cf._get_proc_cmdline()
    cmdline_facts = cf._parse_proc_cmdline(data)
    proc_cmdline_facts = cf._parse_proc_cmdline_facts(data)

    assert isinstance(cmdline_facts, dict)
    assert isinstance(proc_cmdline_facts, dict)
    assert isinstance(cf.collect(), dict)

# Generated at 2022-06-20 19:08:11.335415
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector_obj = CmdLineFactCollector()
    assert cmdline_fact_collector_obj
    assert cmdline_fact_collector_obj.name == 'cmdline'
    assert cmdline_fact_collector_obj._fact_ids == set()


# Generated at 2022-06-20 19:08:13.804834
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Arrange
    CmdLineFactCollector(None)


# Generated at 2022-06-20 19:08:23.141387
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    data = 'BOOT_IMAGE=/boot/vmlinuz-3.13.0-46-generic root=UUID=9e9d4cd4-d8c0-4c3b-afd3-d253d8a9b9a9 ro ro quiet splash vt.handoff=7'
    data = data.encode('utf-8')

    cmdline_dict = {
        'BOOT_IMAGE': '/boot/vmlinuz-3.13.0-46-generic',
        'root': 'UUID=9e9d4cd4-d8c0-4c3b-afd3-d253d8a9b9a9',
        'ro': True,
        'quiet': True,
        'splash': True,
        'vt.handoff': '7'
    }