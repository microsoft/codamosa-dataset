

# Generated at 2022-06-20 19:01:37.653751
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import os
    import subprocess
    import sys

    # Initialize
    cmdline_facts={}

    # Setup
    # Create temporary file
    tmpfile_name = 'ansible_test_file_0'
    tmpfile = open(tmpfile_name,'w')
    tmpfile.close()

    # Create temporary file
    tmpfile2_name = 'ansible_test_file_1'
    tmpfile2 = open(tmpfile2_name,'w')
    tmpfile2.close()

    # Testing for python >= 2.7 and <= 3.5

# Generated at 2022-06-20 19:01:40.662867
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()


# Generated at 2022-06-20 19:01:44.236393
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    cmdline_facts = collector.collect()
    assert isinstance(cmdline_facts['cmdline'], dict)
    assert isinstance(cmdline_facts['proc_cmdline'], dict)

# Generated at 2022-06-20 19:01:45.300540
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    pass

# Generated at 2022-06-20 19:01:56.784304
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """
    test_CmdLineFactCollector_collect:
    This function tests the collect function of class CmdLineFactCollector.
    """
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.cmdline import CmdLineFactCollector

    # Initialise the CmdLineFactCollector object
    cmdline_collector = CmdLineFactCollector()
    # Execute the collect method of the CmdLineFactCollector and check if the result
    # matches the expected result or not

# Generated at 2022-06-20 19:02:02.676549
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    data = """
    BOOT_IMAGE=/boot/vmlinuz-2.6.32-279.el6.x86_64 root=UUID=a28d8c6b-3c3e-44bc-a6df-bf6a9a75c924 ro console=tty0 console=ttyS0,9600 rd_NO_PLYMOUTH
    """

# Generated at 2022-06-20 19:02:15.532966
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    file = open('/proc/cmdline', 'w')
    file.write('BOOT_IMAGE=/boot/vmlinuz-4.4.0-87-generic root=UUID=a9a89a1c-f3fe-4d62-b2b2-f5ae01d39e61 ro rootwait console=ttyS0 quiet')
    file.close()

    cmdline_facts_collector = CmdLineFactCollector()
    result = cmdline_facts_collector.collect()

    assert(isinstance(result, dict))
    assert(len(result) == 2)
    assert('cmdline' in result)
    assert('proc_cmdline' in result)
    assert(isinstance(result['cmdline'], dict))
    assert(len(result['cmdline']) == 5)

# Generated at 2022-06-20 19:02:24.774640
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    CmdLineFactCollector = imp.load_source('CmdLineFactCollector', 'ansible/module_utils/facts/cmdline.py').CmdLineFactCollector
    # empty lines
    CmdLineFactCollector._get_proc_cmdline = lambda x=None,y=None:''
    assert {} == CmdLineFactCollector().collect()
    # minimalistic cmdline
    CmdLineFactCollector._get_proc_cmdline = lambda x=None,y=None:'minimal'
    assert {
        'proc_cmdline': {'minimal': True},
        'cmdline':      {'minimal': True}
    } == CmdLineFactCollector().collect()
    # multiple pairs

# Generated at 2022-06-20 19:02:33.871185
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector({}).collect()

    assert cmdline_facts['cmdline']['rd.znet']
    assert cmdline_facts['cmdline']['rd.znet={{ rd.znet }}']
    assert cmdline_facts['cmdline']['root=UUID=031e4b05-8e4b-4f4a-8908-f813a0b0aee2']
    assert cmdline_facts['cmdline']['rootflags=rw,data=ordered']
    assert cmdline_facts['cmdline']['ro']
    assert cmdline_facts['cmdline']['initrd=initrd.img']
    assert cmdline_facts['cmdline']['systemd.unit=systemd-networkd.service']
    assert cmdline_

# Generated at 2022-06-20 19:02:37.695673
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collect = CmdLineFactCollector()
    assert type(collect.name) == str
    assert type(collect._fact_ids) == set

# Generated at 2022-06-20 19:02:50.011235
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts import collector
    collector.collectors['cmdline'] = CmdLineFactCollector()
    collected_facts = collector.collect(
        gather_subset=['!all', 'cmdline'],
        gather_timeout=10,
        filter_spec=['ansible_cmdline'],
    )
    assert collected_facts['ansible_cmdline']

# Generated at 2022-06-20 19:02:52.746319
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'

# Generated at 2022-06-20 19:02:57.460020
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    from ansible.module_utils.facts.collector import FactCollector

    facts = FactCollector()
    result = facts.get_facts()

    assert 'cmdline' in result

# Generated at 2022-06-20 19:02:58.201518
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()

# Generated at 2022-06-20 19:02:59.494925
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()

# Generated at 2022-06-20 19:03:03.673636
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    fact_collector_obj = CmdLineFactCollector()

    assert fact_collector_obj.name == 'cmdline'
    assert fact_collector_obj._fact_ids == set()
    assert fact_collector_obj.collect() == {}

# Generated at 2022-06-20 19:03:07.470554
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert set(CmdLineFactCollector._fact_ids) == set()


# Generated at 2022-06-20 19:03:12.589721
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line = CmdLineFactCollector()
    assert cmd_line.name == 'cmdline'
    assert cmd_line._fact_ids == set()

# Test _get_proc_cmdline method of CmdLineFactCollector class

# Generated at 2022-06-20 19:03:18.742095
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils._text import to_bytes

    CmdLineCollector = CmdLineFactCollector()
    data = 'root=/dev/sda2 ro console=tty0 console=ttyS0,115200n8 ipv6.disable=1'
    CmdLineCollector._get_proc_cmdline = lambda self: data

    # unit test for method _parse_proc_cmdline
    ret = CmdLineCollector._parse_proc_cmdline(data)

# Generated at 2022-06-20 19:03:19.741492
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cf = CmdLineFactCollector()
    assert cf.name == 'cmdline'

# Generated at 2022-06-20 19:03:34.254697
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector.name == 'cmdline'
    assert not cmd_line_fact_collector._fact_ids
    assert cmd_line_fact_collector.collect is not None

# Generated at 2022-06-20 19:03:40.463953
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Test with success
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert len(cmdline_fact_collector._fact_ids) == 0


# Generated at 2022-06-20 19:03:49.327178
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    # cmdline with no key value pairs
    test_cmdline = "rhgb crashkernel=auto quiet"
    # cmdline with multiple key value pairs
    test_cmdline_facts = "root=/dev/mapper/VolGroup-lv_root ro" \
                         " rhgb crashkernel=auto quiet"
    # cmdline with single key value pair
    test_cmdline_keyvalue = "root=/dev/mapper/VolGroup-lv_root"

    # Creating object of CmdLineFactCollector class
    cmdline = CmdLineFactCollector()

    # Overriding the _get_proc_cmdline method of CmdLineFactCollector
    # class to return the test_cmdline
    def _get_proc_cmdline(self):
        return test_cmdline

    cmdline._get_proc_cmdline = _get

# Generated at 2022-06-20 19:03:54.788763
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    file_contents = """
        root=/dev/mapper/system-root ro quiet consoleblank=0 net.ifnames=0 biosdevname=0 elevator=mq
    """

    def return_file_content_mock(file_name):
        return file_contents

    mock_collector = CmdLineFactCollector(None)
    mock_collector.get_file_content = return_file_content_mock

    result = mock_collector.collect()

    assert result['cmdline'] == {'root': '/dev/mapper/system-root', 'ro': True, 'quiet': True, 'consoleblank': '0', 'net.ifnames': '0', 'biosdevname': '0', 'elevator': 'mq'}

# Generated at 2022-06-20 19:03:57.026486
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj


# Generated at 2022-06-20 19:04:00.755158
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert not c._fact_ids


# Generated at 2022-06-20 19:04:04.786896
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert isinstance(collector, CmdLineFactCollector)
    assert collector.name == 'cmdline'
    assert collector._fact_ids == set()


# Generated at 2022-06-20 19:04:13.420285
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    module = object()
    collected_facts = object()

    instance = CmdLineFactCollector()
    cmdline_facts = instance.collect(module=module, collected_facts=collected_facts)
    assert 'cmdline' in cmdline_facts
    assert isinstance(cmdline_facts['cmdline'], dict)
    assert 'proc_cmdline' in cmdline_facts
    assert isinstance(cmdline_facts['proc_cmdline'], dict)

# Generated at 2022-06-20 19:04:14.729445
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    """
    Tests the constructor of class CmdLineFactCollector
    """
    CmdLineFactCollector()


# Generated at 2022-06-20 19:04:19.181344
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'
    assert len(collector._fact_ids) == 0


# Generated at 2022-06-20 19:04:46.176851
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_data = "elevator=noop ipv6.disable=1 quiet"
    class_cmdline = CmdLineFactCollector()
    class_cmdline._get_proc_cmdline = lambda: cmdline_data
    cmdline_facts = class_cmdline.collect()
    assert cmdline_facts['cmdline'] == {'elevator': 'noop', 'ipv6.disable': '1', 'quiet': True}
    assert cmdline_facts['proc_cmdline'] == {'elevator': 'noop', 'ipv6.disable': '1', 'quiet': True}


# Generated at 2022-06-20 19:04:48.894541
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'

# Generated at 2022-06-20 19:04:55.114732
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    CmdLineFactCollectorObj = CmdLineFactCollector()

    mocker_get_file_content = mocker.patch.object(CmdLineFactCollectorObj, '_get_file_content')
    mocker_get_file_content.return_value = 'foo=bar foo2=bar2'

    mocker_parse_proc_cmdline = mocker.patch.object(CmdLineFactCollectorObj, '_parse_proc_cmdline')
    mocker_parse_proc_cmdline.return_value = {'foo': 'bar', 'foo2': 'bar2'}

    mocker_parse_proc_cmdline_facts = mocker.patch.object(CmdLineFactCollectorObj, '_parse_proc_cmdline_facts')

# Generated at 2022-06-20 19:05:06.765491
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_set = CmdLineFactCollector()
    assert isinstance(cmdline_set, CmdLineFactCollector)
    assert cmdline_set.name == 'cmdline'
    assert isinstance(cmdline_set._fact_ids, set)
    assert cmdline_set._fact_ids == set()
    assert cmdline_set._get_proc_cmdline() == ''
    assert cmdline_set._parse_proc_cmdline(cmdline_set._get_proc_cmdline()) == {}
    assert cmdline_set._parse_proc_cmdline_facts(cmdline_set._get_proc_cmdline()) == {}
    assert cmdline_set.collect() == {'cmdline': {}, 'proc_cmdline': {}}
    assert isinstance(cmdline_set.collect(), dict)
    assert cmdline

# Generated at 2022-06-20 19:05:18.115941
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    # Test the case when facts have multiple run of a given fact
    test_data = "key1=value1 key2=key3=value3 key1=value2 key3=value4 key5=value5"
    collector = CmdLineFactCollector()
    my_facts = collector._parse_proc_cmdline_facts(test_data)

    assert (my_facts['cmdline'] == {'key1': 'value1', 'key2': True, 'key3': 'value3', 'key5': 'value5'})
    assert (my_facts['proc_cmdline'] == {'key1': ['value1', 'value2'], 'key2': True, 'key3': ['value3', 'value4'], 'key5': 'value5'})

    # Test the case when facts are in a single line
    test_

# Generated at 2022-06-20 19:05:19.129309
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert cmdline.name == 'cmdline'

# Generated at 2022-06-20 19:05:30.152845
# Unit test for constructor of class CmdLineFactCollector

# Generated at 2022-06-20 19:05:31.410988
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector().name == 'cmdline'

# Generated at 2022-06-20 19:05:34.565432
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_fact_collector = CmdLineFactCollector()
    cmdline_facts = cmdline_fact_collector.collect()

    assert 'cmdline' in cmdline_facts
    assert isinstance(cmdline_facts['cmdline'], dict)
    assert 'proc_cmdline' in cmdline_facts
    assert isinstance(cmdline_facts['proc_cmdline'], dict)


# Generated at 2022-06-20 19:05:35.384276
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()

# Generated at 2022-06-20 19:06:20.420952
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import mock
    import sys

    this_module = sys.modules[__name__]

    mock_basefact = mock.MagicMock(spec=BaseFactCollector)
    mock_basefact_instance = mock_basefact.return_value
    mock_basefact_instance.get_file_content.return_value = 'foo=bar'

    mock_module = mock.MagicMock(name='testModule')

    cmdline_fact = this_module.CmdLineFactCollector()
    cmdline_fact._get_file_content = mock_basefact_instance.get_file_content

    cmdline_fact.collect(module=mock_module)
    output = {'cmdline': {'foo': 'bar'}, 'proc_cmdline': {'foo': 'bar'}}

# Generated at 2022-06-20 19:06:24.966996
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_content = 'root=UUID=058a5da5-4e84-4a0f-8588-4a9d9d7ccd54 ro crashkernel=auto vconsole.font=latarcyrheb-sun16 vconsole.keymap=us rhgb quiet'
    cmdline_dict = {
        'root': 'UUID=058a5da5-4e84-4a0f-8588-4a9d9d7ccd54',
        'ro': True,
        'crashkernel': 'auto',
        'vconsole.font': 'latarcyrheb-sun16',
        'vconsole.keymap': 'us',
        'rhgb': True,
        'quiet': True,
        }

# Generated at 2022-06-20 19:06:26.764456
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert cmdline.name == 'cmdline'


# Generated at 2022-06-20 19:06:30.720967
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    cmdline_facts = collector.collect()

    assert len(cmdline_facts) != 0, "cmdline_facts shouldn't be empty"

# Generated at 2022-06-20 19:06:40.508092
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts import collector
    import pytest

    with open('/proc/cmdline', 'w') as cmdline:
        cmdline.write('BOOT_IMAGE=/vmlinuz-4.4.0-38-generic root=UUID=f8d05d98-0ab0-49e5-97b8-52d98258a5cd ro quiet splash '
                      'vt.handoff=7 rhgb')

    cmdline_collector = collector.get_collector('cmdline')

    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()

# Generated at 2022-06-20 19:06:45.655783
# Unit test for method collect of class CmdLineFactCollector

# Generated at 2022-06-20 19:06:47.665889
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert(collector.name == 'cmdline')

# Generated at 2022-06-20 19:06:49.932705
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c is not None


# Generated at 2022-06-20 19:06:59.498647
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    # create instance of CmdLineFactCollector
    from ansible.module_utils.facts.collectors import collector_module
    collector = collector_module['cmdline'](None)

    # create mock for class BaseFactCollector

    class MockBaseFactCollector(object):
        name = 'cmdline'
        _fact_ids = set()

    collector.__class__.__bases__ = (MockBaseFactCollector,)

    # create mock for method _get_proc_cmdline

    def mock__get_proc_cmdline(self):
        return 'BOOT_IMAGE=/vmlinuz-3.13.0-32-generic root=/dev/mapper/ubuntu--vg-root ro quiet splash vt.handoff=7'

    # attach method _get_proc_cmdline to
    # ansible.module_utils

# Generated at 2022-06-20 19:07:01.951097
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector().name == 'cmdline'

# Generated at 2022-06-20 19:08:33.301667
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    content = "ip=... ro quiet"
    cmdline_facts = {
        'cmdline': {
            'ip': '...',
            'ro': True,
            'quiet': True
        },
        'proc_cmdline': {
            'ip': '...',
            'ro': True,
            'quiet': True
        }
    }

    obj = CmdLineFactCollector()
    obj._get_proc_cmdline = lambda: content

    assert obj.collect() == cmdline_facts

# Generated at 2022-06-20 19:08:36.413540
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    c = CmdLineFactCollector()

    # Test with a valid /proc/cmdline
    with open('/proc/cmdline', 'r') as cmdline_file:
        cmdline = cmdline_file.readline().strip()
        assert c.collect()['cmdline'] == c._parse_proc_cmdline(cmdline)

    # Test with a non-existent /proc/cmdline
    with open('/proc/cmdline', 'r') as cmdline_file:
        cmdline_file.close()
        assert c.collect() == {}

# Generated at 2022-06-20 19:08:41.711458
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    module = mock.Mock()
    processor = mock.Mock()

    file_content = 'ro root=UUID=9fb1d6ef-0501-4790-ab5e-b1d92d8586a2 LANG=en_GB.UTF-8'
    file_content += 'rootflags=subvol=@ ROOTFLAGS=subvol=@console=tty1 console=ttyS0,115200n8 console=tty0 ks=http://10.0.2.2:8888/centos-7.ks'
    file_content += 'BOOT_IMAGE=/Image initrd=initrd.img crashkernel=auto ip=dhcp'

    with patch.object(CmdLineFactCollector, '_get_proc_cmdline') as proc:
        proc.return_value = file_content
       

# Generated at 2022-06-20 19:08:43.954441
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # create an instance of class CmdLineFactCollector
    my_obj = CmdLineFactCollector()
    assert isinstance(my_obj, CmdLineFactCollector)

# Generated at 2022-06-20 19:08:46.413302
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert c._fact_ids == set()

# Generated at 2022-06-20 19:08:49.250130
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert isinstance(c._fact_ids, set)
    assert len(c._fact_ids) == 0

# Generated at 2022-06-20 19:08:57.020947
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Initialize the class and setup required parameters
    CmdLineFactCollector_test = CmdLineFactCollector()

    # Read value from the file
    def get_proc_cmdline():
        with open("test_data/ansible_facts/cmdline/cmdline", "r") as cmdline:
            return cmdline.read()

    # Replace the read file method
    CmdLineFactCollector_test._get_proc_cmdline = get_proc_cmdline

    # Execute collect method
    cmdline_facts = CmdLineFactCollector_test.collect()

    # Verify the results
    assert cmdline_facts['cmdline'] is not None
    assert cmdline_facts['proc_cmdline'] is not None

# Generated at 2022-06-20 19:09:07.967941
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    def test_get_file_content():
        assert test_get_file_content.content is not None
        return test_get_file_content.content

    test_get_file_content.content = b"rd.shell\0rhgb\0quiet\0"
    c = CmdLineFactCollector()
    c._get_proc_cmdline = test_get_file_content

    assert c.collect() == {'cmdline': {'quiet': True, 'rd.shell': True, 'rhgb': True},
                           'proc_cmdline': {'quiet': True, 'rd.shell': True, 'rhgb': True}}

    test_get_file_content.content = b"rd.shell\0rhgb\0quiet=\0"
    c = CmdLineFactCollector()
    c._get_proc

# Generated at 2022-06-20 19:09:20.245042
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdlineCollector = CmdLineFactCollector()
    cmdlineCollector._get_proc_cmdline = lambda: 'rd.lvm.lv=vg1/root rd.lvm.lv=vg1/swap rd.lvm.lv=vg1/tmp ' \
                                                 'ro rd.lvm.lv=vg0/usr rd.lvm.lv=vg0/opt ' \
                                                 'SYSFONT=latarcyrheb-sun16 crashkernel=auto  ' \
                                                 'rd.lvm.lv=vg0/var rhgb quiet LANG=en_US.UTF-8 ' \
                                                 'rd.lvm.lv=vg0/home rd.lvm.lv=vg0/var/log'
    cmdlineCollector._parse_proc_

# Generated at 2022-06-20 19:09:31.611101
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import os
    import shutil
    import tempfile

    def _generate_cmdline_content(data):
        # Encodes our data the way Linux does it
        cmdline_content = ''
        for key in data:
            cmdline_content += ' {0}={1}'.format(key, data[key]).strip()

        return cmdline_content

    class FakeModule(object):
        def __init__(self, tmpdir):
            self.tmpdir = tmpdir

        def get_bin_path(self, cmd, required=False, opt_dirs=[]):
            if cmd in ('cat', 'ls'):
                return cmd

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs