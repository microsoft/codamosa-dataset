

# Generated at 2022-06-24 23:42:17.519428
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    test_case_0()


# Generated at 2022-06-24 23:42:20.800880
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector._fact_ids == set()


# Generated at 2022-06-24 23:42:25.740056
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    collected_facts = None

    collected_facts = cmd_line_fact_collector_1.collect()
    assert collected_facts is not None
    assert collected_facts['ansible_cmdline'] is not None

# Generated at 2022-06-24 23:42:36.901050
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()

    get_file_content_orig = cmd_line_fact_collector_0._get_file_content
    def _get_file_content(filename):
        if filename == '/proc/cmdline':
            return 'quiet initrd=/install/initrd.gz BOOT_IMAGE=/install/vmlinuz-3.10.0-327.el7.x86_64'
        else:
            return get_file_content_orig('/proc/cmdline')
    cmd_line_fact_collector_0._get_file_content = _get_file_content

    cmdline_facts = cmd_line_fact_collector_0.collect()


# Generated at 2022-06-24 23:42:38.291130
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # cmd_line_fact_collector_1 = CmdLineFactCollector()
    assert True == True

# Generated at 2022-06-24 23:42:39.129450
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    assert callable(CmdLineFactCollector.collect)

# Generated at 2022-06-24 23:42:47.990803
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    with open('/proc/cmdline', 'w') as f_cmdline:
        f_cmdline.write('ansible_test=test_cmdline quiet root=LABEL=RHEL7-root ro crashkernel=auto rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet')

    cmd_line_fact_collector = CmdLineFactCollector()
    cmd_line_collector_facts = cmd_line_fact_collector.collect()

    assert cmd_line_collector_facts['cmdline']['ansible_test'] == 'test_cmdline'
    assert cmd_line_collector_facts['proc_cmdline']['ansible_test'] == 'test_cmdline'

# Generated at 2022-06-24 23:42:49.333666
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    cmd_line_fact_collector_1.collect()


# Generated at 2022-06-24 23:42:51.008609
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector.name == "cmdline"


# Generated at 2022-06-24 23:42:55.071294
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector is not None


# Generated at 2022-06-24 23:43:06.056986
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    data = CmdLineFactCollector.get_file_content(None, '/proc/cmdline')

    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    assert var_0['cmdline']["BOOT_IMAGE"] == "/vmlinuz-2.6.32-279.1.1.el6.x86_64"
    assert var_0['proc_cmdline']["BOOT_IMAGE"] == "/vmlinuz-2.6.32-279.1.1.el6.x86_64"


# Generated at 2022-06-24 23:43:15.966047
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector

    cmd_line_fact_collector_0 = CmdLineFactCollector()
    cmd_line_fact_collector_0.collect()
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert cmd_line_fact_collector_0.priority == 80
    assert cmd_line_fact_collector_0.facts == {}
    assert isinstance(cmd_line_fact_collector_0.facts, dict)
    assert cmd_line_fact_collector_0.collected_facts == {}
    assert isinstance(cmd_line_fact_collector_0.collected_facts, dict)
    assert cmd_line_fact_collector_0.fact_ids == set()

# Generated at 2022-06-24 23:43:18.625201
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector.name == 'cmdline'
    assert cmd_line_fact_collector._fact_ids == set()


# Generated at 2022-06-24 23:43:22.140862
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    assert cmd_line_fact_collector_1.name == 'cmdline'
    assert cmd_line_fact_collector_1._fact_ids == set()


# Generated at 2022-06-24 23:43:26.560457
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'

test_case_0()

# Generated at 2022-06-24 23:43:27.932565
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    instance_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:43:35.988657
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0._get_proc_cmdline()
    var_1 = cmd_line_fact_collector_0._parse_proc_cmdline(var_0)
    var_2 = cmd_line_fact_collector_0._parse_proc_cmdline_facts(var_0)
    var_3 = cmd_line_fact_collector_0.collect()

# Generated at 2022-06-24 23:43:41.030293
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    # Test of the existence of the facts
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    var_1 = cmd_line_fact_collector_1.collect()
    cmd_line_fact_collector_1.name in var_1

# Generated at 2022-06-24 23:43:43.317846
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_obj = CmdLineFactCollector()
    # Call the method to collect facts
    cmd_line_fact_collector_obj.collect()

# Generated at 2022-06-24 23:43:44.860267
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:43:56.767510
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:43:58.407377
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:44:00.591966
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:44:08.286576
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    var_name = 'ansible_cmdline'
    var_name_1 = 'ansible_proc_cmdline'

    cmd_line_fact_collector_obj_0 = CmdLineFactCollector()
    cmd_line_fact_collector_obj_1 = CmdLineFactCollector()
    cmd_line_fact_collector_obj_1.name = var_name

    assert cmd_line_fact_collector_obj_0.name != cmd_line_fact_collector_obj_1.name
    assert cmd_line_fact_collector_obj_0.name == 'cmdline'
    assert cmd_line_fact_collector_obj_1.name == var_name


# Generated at 2022-06-24 23:44:15.308359
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    collected_facts_0 = {}
    expected_result_0 = {}
    var_0 = cmd_line_fact_collector_0.collect(None, collected_facts_0)
    assert var_0 == expected_result_0



# Generated at 2022-06-24 23:44:19.251398
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    try:
        cmd_line_fact_collector_0 = CmdLineFactCollector()
    except NameError as err:
        print("NameError: " + str(err), file=sys.stderr)


# Generated at 2022-06-24 23:44:22.436390
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    # fact_ids property
    var_1 = cmd_line_fact_collector_0.fact_ids
    assert var_1


# Generated at 2022-06-24 23:44:29.640030
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    assert isinstance(var_0, dict)
    assert 'proc_cmdline' in var_0
    assert isinstance(var_0['proc_cmdline'], dict)
    assert 'cmdline' in var_0
    assert isinstance(var_0['cmdline'], dict)
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert 'ansible_cmdline' in var_0['proc_cmdline']
    assert 'ansible_cmdline' in var_0['cmdline']

# Generated at 2022-06-24 23:44:35.029241
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()


# Generated at 2022-06-24 23:44:39.460262
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'


# Generated at 2022-06-24 23:45:06.129024
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()

    assert isinstance(var_0, dict)
    assert 'cmdline' in var_0
    assert 'proc_cmdline' in var_0

# Generated at 2022-06-24 23:45:09.146523
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector = CmdLineFactCollector()
    var = cmd_line_fact_collector.collect()


# Generated at 2022-06-24 23:45:15.291943
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Instance creation
    instance_0 = CmdLineFactCollector()

    # Check attributes
    assert isinstance(instance_0, CmdLineFactCollector)
    assert instance_0.cmdline == None
    assert instance_0.proc_cmdline == None

    # Instance creation
    instance_1 = CmdLineFactCollector()

    # Check attributes
    assert isinstance(instance_1, CmdLineFactCollector)
    assert instance_1.cmdline == None
    assert instance_1.proc_cmdline == None


# Generated at 2022-06-24 23:45:17.473711
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'


# Generated at 2022-06-24 23:45:18.265736
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    test_case_0()


# Generated at 2022-06-24 23:45:23.241086
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    assert cmd_line_fact_collector_1.name == 'cmdline'


# Generated at 2022-06-24 23:45:24.928351
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert isinstance(CmdLineFactCollector(), CmdLineFactCollector)

# Generated at 2022-06-24 23:45:25.832613
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:45:27.085155
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()


# Generated at 2022-06-24 23:45:31.492327
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Calling method collect of the class CmdLineFactCollector
    test_case_0()

# Generated at 2022-06-24 23:46:29.296439
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0


# Generated at 2022-06-24 23:46:30.496548
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector is not None


# Generated at 2022-06-24 23:46:35.237916
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert cmd_line_fact_collector_0._fact_ids == set()


# Generated at 2022-06-24 23:46:36.010348
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    test_case_0()


# Generated at 2022-06-24 23:46:40.107140
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()


# Generated at 2022-06-24 23:46:46.263199
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import FactCollector

    cmd_line_fact_collector_0 = CmdLineFactCollector()
    cmd_line_fact_collector_1 = CmdLineFactCollector()

    # Test case with argument - module = None and collected_facts = None
    # Test case with argument - module = None and collected_facts = {'local': {}}
    # Test case with argument - module = None and collected_facts = {'local': {}, 'ansible_cmdline': {}}
    # Test case with argument - module = None and collected_facts = {'local': {}, 'ansible_cmdline': {}, 'ansible_proc_cmdline': {}}
    # Test case with argument - module = None and collected_facts = {

# Generated at 2022-06-24 23:46:46.914322
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
	test_case_0()

# Generated at 2022-06-24 23:46:51.859866
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert cmd_line_fact_collector_0._fact_ids == set()


# Generated at 2022-06-24 23:46:55.263284
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert str(type(cmd_line_fact_collector_0)) == "<class 'ansible.module_utils.facts.cmdline.CmdLineFactCollector'>"


# Generated at 2022-06-24 23:46:57.415132
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector is not None


# Generated at 2022-06-24 23:48:56.978902
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert CmdLineFactCollector._fact_ids == set(), "Failed to create CmdLineFactCollector object"


# Generated at 2022-06-24 23:48:57.919237
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # ToDo: Unit test collect
    test_case_0()



# Generated at 2022-06-24 23:49:02.222979
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    cmd_line_fact_collector_1 = CmdLineFactCollector(cmd_line_fact_collector_0)
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert cmd_line_fact_collector_0._fact_ids == set()


# Generated at 2022-06-24 23:49:04.281586
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    # test case 0
    test_case_0()

    # test case 1
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    var_1 = cmd_line_fact_collector_1.collect()

# Generated at 2022-06-24 23:49:14.763102
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_1 = cmd_line_fact_collector_0.collect()
    assert var_1['cmdline']['ro'] == True
    assert var_1['cmdline']['LANG'] == 'en_US.UTF-8'
    assert var_1['cmdline']['rd_NO_DM'] == True
    assert var_1['cmdline']['rhgb'] == True
    assert var_1['cmdline']['quiet'] == True
    assert var_1['cmdline']['initrd'] == '/initramfs-3.10.0-327.el7.x86_64.img'
    assert var_1['cmdline']['rd_LVM_LV'] == 'TestVolGroup-root'


# Generated at 2022-06-24 23:49:15.876444
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    assert cmd_line_fact_collector_1


# Generated at 2022-06-24 23:49:17.345553
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # No parametrization needed
    var_0 = CmdLineFactCollector()
    var_0.collect()

# Generated at 2022-06-24 23:49:19.701898
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():

    cmd_line_fact_collector_0 = CmdLineFactCollector()

    assert cmd_line_fact_collector_0._fact_ids == set()
    assert cmd_line_fact_collector_0.name == 'cmdline'


# Generated at 2022-06-24 23:49:20.742998
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()

# Generated at 2022-06-24 23:49:23.640243
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()