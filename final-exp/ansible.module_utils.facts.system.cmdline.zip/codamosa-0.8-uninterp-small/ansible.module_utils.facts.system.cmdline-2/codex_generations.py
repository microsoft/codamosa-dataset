

# Generated at 2022-06-24 23:42:20.033807
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:42:23.058152
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    assert CmdLineFactCollector().collect()


# Generated at 2022-06-24 23:42:25.313898
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    assert cmd_line_fact_collector_1


# Generated at 2022-06-24 23:42:29.472486
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()

    # Testing whether exceptions raised in method collect (of class CmdLineFactCollector) are caught or not
    # This test case is covered by the existing test cases
    assert cmd_line_fact_collector_0 is not None

# Generated at 2022-06-24 23:42:31.764250
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert type(obj).__name__ == 'CmdLineFactCollector'


# Generated at 2022-06-24 23:42:32.326217
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    pass

# Generated at 2022-06-24 23:42:36.631923
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():

    # Fail: missing input parameter
    try:
        cmd_line_fact_collector_0 = CmdLineFactCollector()
        assert 0 == 1
    except:
        assert 1 == 1


# Generated at 2022-06-24 23:42:42.416255
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    # Setup the mocks
    data = 'vmlinuz-3.10.0-862.14.4.el7.x86_64 root=/dev/mapper/rhel-root ro crashkernel=auto rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet LANG=en_US.UTF-8'
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    cmd_line_fact_collector_0._get_proc_cmdline = lambda: data
    result = cmd_line_fact_collector_0.collect()

    # Setup the expected results

# Generated at 2022-06-24 23:42:45.347282
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # cmd_line_fact_collector_0 = CmdLineFactCollector()

    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()


# Generated at 2022-06-24 23:42:54.214999
# Unit test for method collect of class CmdLineFactCollector

# Generated at 2022-06-24 23:43:01.818426
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0._fact_ids == set()


# Generated at 2022-06-24 23:43:03.362562
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector = CmdLineFactCollector()
    cmd_line_fact_collector.collect()

# Generated at 2022-06-24 23:43:11.823873
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    var_1 = CmdLineFactCollector()
    var_2 = var_1.collect()

    try:
        if (isinstance(var_2, dict)):
            assert len(var_2) == 2
        else:
            assert False
    except AssertionError:
        raise AssertionError('Expected value: ' + str(2) + ' got value: ' + str(len(var_2)))

    try:
        if (isinstance(var_2['cmdline'], dict)):
            assert (len(var_2['cmdline']) >= 0)
        else:
            assert False
    except AssertionError:
        raise AssertionError('Expected value: ' + str(0) + ' got value: ' + str(len(var_2['cmdline'])))


# Generated at 2022-06-24 23:43:19.642741
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    assert var_0 == {'proc_cmdline': {'BOOT_IMAGE': '/vmlinuz-2.6.32-5-686', 'ro': True, 'root': '/dev/sda2', 'quiet': True, 'initrd': '/initrd.img-2.6.32-5-686'}, 'cmdline': {'BOOT_IMAGE': '/vmlinuz-2.6.32-5-686', 'ro': True, 'root': '/dev/sda2', 'quiet': True, 'initrd': '/initrd.img-2.6.32-5-686'}}

# Generated at 2022-06-24 23:43:21.474867
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert not CmdLineFactCollector()._fact_ids


# Generated at 2022-06-24 23:43:22.995532
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()

# Generated at 2022-06-24 23:43:29.009033
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector.cmdline import CmdLineFactCollector
    cmd_line_fact_collector = CmdLineFactCollector()
    var = cmd_line_fact_collector.collect()
    assert var is not None
    import datetime
    assert isinstance(var, dict)
    assert isinstance(var, object)


# Generated at 2022-06-24 23:43:30.515488
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    instance = CmdLineFactCollector()
    assert instance.name == 'cmdline'


# Generated at 2022-06-24 23:43:34.195897
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0._fact_ids == set()
    assert cmd_line_fact_collector_0.name == 'cmdline'



# Generated at 2022-06-24 23:43:39.541221
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    # get_file_content is not mocked
    var_0 = cmd_line_fact_collector_0.collect()

    assert var_0 == {}


# Generated at 2022-06-24 23:43:51.054327
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector().name == 'cmdline'
    assert CmdLineFactCollector()._fact_ids == set()


# Generated at 2022-06-24 23:43:53.828808
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert cmd_line_fact_collector_0._fact_ids == set()


# Generated at 2022-06-24 23:43:54.701292
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    var = CmdLineFactCollector().collect()
    assert True


# Generated at 2022-06-24 23:43:57.172958
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    var_1 = cmd_line_fact_collector_1.collect()



# Generated at 2022-06-24 23:43:59.321932
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()

# Generated at 2022-06-24 23:44:01.482623
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()

    assert isinstance(cmd_line_fact_collector_1.collect(), dict)

    assert cmd_line_fact_collector_1.collect() == cmd_line_fact_collector_1.collect()



# Generated at 2022-06-24 23:44:02.646493
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()

# Generated at 2022-06-24 23:44:04.728436
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert(CmdLineFactCollector in globals())
    assert(isinstance(cmd_line_fact_collector_0, CmdLineFactCollector))


# Generated at 2022-06-24 23:44:05.895180
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector is not None


# Generated at 2022-06-24 23:44:07.461493
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    var_1 = cmd_line_fact_collector_1.collect()

# Generated at 2022-06-24 23:44:27.160267
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'


# Generated at 2022-06-24 23:44:29.939835
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Testing expected behavior
    # cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert True == True


test_case_0()
test_CmdLineFactCollector_collect()

# Generated at 2022-06-24 23:44:31.532016
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj._fact_ids == {'cmdline', 'proc_cmdline'}


# Generated at 2022-06-24 23:44:35.515383
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Arrange
    cmd_line_fact_collector = CmdLineFactCollector()

    # Act
    var = cmd_line_fact_collector.collect()

    # Assert
    assert var


# Generated at 2022-06-24 23:44:40.538908
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    var_1 = cmd_line_fact_collector_1.collect()


if __name__ == '__main__':
    test_case_0()
    test_CmdLineFactCollector_collect()

# Generated at 2022-06-24 23:44:42.132511
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    assert isinstance(var_0, dict)


# Generated at 2022-06-24 23:44:45.470501
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector.priority == 80
    assert CmdLineFactCollector._fact_ids is not None


# Generated at 2022-06-24 23:44:48.091874
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    assert var_0 == {}

# Generated at 2022-06-24 23:44:53.217005
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    assert(var_0['cmdline'])
    assert(var_0['proc_cmdline'])


# Generated at 2022-06-24 23:44:54.344974
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()

# Generated at 2022-06-24 23:45:33.027748
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    cmd_line_fact_collector_0.collect()

# Generated at 2022-06-24 23:45:36.019227
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    collected_facts = {}
    var_0 = cmd_line_fact_collector_0.collect(collected_facts=collected_facts)
    assert var_0 == {'cmdline':{'root':'LABEL=containers'}, 'proc_cmdline':{'root':'LABEL=containers'}}


# Generated at 2022-06-24 23:45:36.863146
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()



# Generated at 2022-06-24 23:45:39.616073
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0._fact_ids
    assert (var_0 == set())
    var_1 = cmd_line_fact_collector_0.name
    assert (var_1 == 'cmdline')



# Generated at 2022-06-24 23:45:41.295690
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    assert cmd_line_fact_collector_1.collect() == {'proc_cmdline': {}, 'cmdline': {}}

# Generated at 2022-06-24 23:45:46.007757
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert isinstance(cmd_line_fact_collector_0, CmdLineFactCollector)



# Generated at 2022-06-24 23:45:49.939557
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_obj_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_obj_0._fact_ids == set()


# Generated at 2022-06-24 23:45:51.158846
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:45:52.560301
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    assert cmd_line_fact_collector_1 is not None


# Generated at 2022-06-24 23:45:54.311509
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert type(cmd_line_fact_collector_0) is CmdLineFactCollector


# Generated at 2022-06-24 23:47:25.361282
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    assert not CmdLineFactCollector().collect().keys()


# Generated at 2022-06-24 23:47:33.993025
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import collect_subset
    from ansible.module_utils.facts.collector import CmdLineFactCollector

    host_0 = {}


# Generated at 2022-06-24 23:47:35.464130
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_1 = cmd_line_fact_collector_0.collect()
#    print(var_1)


# Generated at 2022-06-24 23:47:38.694785
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:47:43.448836
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert hasattr(CmdLineFactCollector, '_get_proc_cmdline')
    assert hasattr(CmdLineFactCollector, '_parse_proc_cmdline')
    assert hasattr(CmdLineFactCollector, '_parse_proc_cmdline_facts')
    assert hasattr(CmdLineFactCollector, 'collect')

    cmd_line_fact_collector_1 = CmdLineFactCollector()
    assert cmd_line_fact_collector_1.name == 'cmdline'



# Generated at 2022-06-24 23:47:45.662151
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'


# Generated at 2022-06-24 23:47:48.686242
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0 is not None


# Generated at 2022-06-24 23:47:51.188801
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    var_1 = cmd_line_fact_collector_1.collect()
    assert isinstance(var_1, dict)

# Generated at 2022-06-24 23:47:52.594054
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:47:56.098790
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()

## Check the class variable _fact_ids
    assert cmd_line_fact_collector_0._fact_ids == set()

## Check the class variable name
    assert cmd_line_fact_collector_0.name == 'cmdline'


# Generated at 2022-06-24 23:51:49.824865
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_1 = CmdLineFactCollector()


# Generated at 2022-06-24 23:51:50.416077
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()


# Generated at 2022-06-24 23:51:51.222076
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # TODO: add unit test logic
    assert True


# Generated at 2022-06-24 23:51:54.471219
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Constructor test case
    assert issubclass(CmdLineFactCollector, BaseFactCollector)
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector.priority == 80
    # _get_proc_cmdline() test case
    # _parse_proc_cmdline() test case
    # _parse_proc_cmdline_facts() test case
    # collect() test case
    test_case_0()

# Generated at 2022-06-24 23:51:57.155241
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()

# Generated at 2022-06-24 23:52:00.965649
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:52:05.186980
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    assert var_0['cmdline'] == {'root': '/dev/mapper/fedora-root', 'ro': True, 'rw': True, 'console': 'tty1', 'crashkernel': 'auto'}
    assert var_0['proc_cmdline'] == {'root': '/dev/mapper/fedora-root', 'ro': True, 'rw': True, 'console': 'tty1', 'crashkernel': 'auto'}

# Generated at 2022-06-24 23:52:08.000534
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()

# Generated at 2022-06-24 23:52:08.694746
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    pass

# Generated at 2022-06-24 23:52:13.477753
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()

    collected_facts_0 = {}

    var_0 = cmd_line_fact_collector_0.collect(collected_facts_0)


if __name__ == "__main__":
    test_case_0()