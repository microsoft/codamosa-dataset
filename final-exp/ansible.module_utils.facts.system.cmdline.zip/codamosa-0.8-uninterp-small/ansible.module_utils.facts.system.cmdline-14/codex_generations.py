

# Generated at 2022-06-24 23:42:20.800964
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0 is not None


# Generated at 2022-06-24 23:42:31.981632
# Unit test for method collect of class CmdLineFactCollector

# Generated at 2022-06-24 23:42:36.632098
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector.name == 'cmdline'
    assert cmd_line_fact_collector._fact_ids == set()



# Generated at 2022-06-24 23:42:38.004829
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()



# Generated at 2022-06-24 23:42:39.120494
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert not obj.content


# Generated at 2022-06-24 23:42:40.239944
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()

# Generated at 2022-06-24 23:42:41.520445
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector = CmdLineFactCollector()
    cmd_line_fact_collector.collect()

# Generated at 2022-06-24 23:42:43.029076
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    try:
        assert cmd_line_fact_collector_0
    except NameError:
        assert test_case_0()


# Generated at 2022-06-24 23:42:43.751755
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector



# Generated at 2022-06-24 23:42:46.888405
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector.collect() == {}
    # assert cmd_line_fact_collector.collect() == \
    #     {'cmdline': {'foo': 'bar', 'baz': True}, 'proc_cmdline': {'foo': 'bar', 'baz': True}}

# Generated at 2022-06-24 23:42:55.370391
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    cmd_line_fact_collector_0._get_proc_cmdline = lambda: "var_0"
    cmd_line_fact_collector_0._parse_proc_cmdline = lambda data: "var_1"
    cmd_line_fact_collector_0._parse_proc_cmdline_facts = lambda data: "var_2"
    var_0 = cmd_line_fact_collector_0.collect(module="var_1")
    assert var_0 == {}


# Generated at 2022-06-24 23:42:56.467973
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector().name == 'cmdline'
    assert CmdLineFactCollector()._fact_ids == set()


# Generated at 2022-06-24 23:43:01.291486
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    '''
    Test to get a dictionary of facts for the cmdline of the running process.
    '''
    cmd_line_fact_collector_2 = CmdLineFactCollector()
    var_2 = cmd_line_fact_collector_2.collect()

# Generated at 2022-06-24 23:43:04.302995
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    assert 'cmdline' in var_0
    assert 'proc_cmdline' in var_0


# Generated at 2022-06-24 23:43:05.833067
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector is not None

# Generated at 2022-06-24 23:43:07.607871
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    t_CmdLineFactCollector = CmdLineFactCollector()
    assert t_CmdLineFactCollector.name == 'cmdline'


# Generated at 2022-06-24 23:43:10.600170
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    var_0 = cmd_line_fact_collector.CmdLineFactCollector()


# Generated at 2022-06-24 23:43:13.235543
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert type(cmd_line_fact_collector_0) == CmdLineFactCollector


# Generated at 2022-06-24 23:43:14.797415
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert isinstance(CmdLineFactCollector(), CmdLineFactCollector)


# Generated at 2022-06-24 23:43:19.694246
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.collector == {'system': set(['cmdline']), 'virtual': set()}
    assert cmd_line_fact_collector_0.min_collection_interval == 86400



# Generated at 2022-06-24 23:43:32.007074
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    assert 'cmdline' in var_0
    assert 'proc_cmdline' in var_0


# Generated at 2022-06-24 23:43:34.230914
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()

# Generated at 2022-06-24 23:43:37.797789
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:43:39.236154
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert cmd_line_fact_collector_0._fact_ids == set()



# Generated at 2022-06-24 23:43:41.626334
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    assert var_0 == {}

# Generated at 2022-06-24 23:43:43.232360
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:43:44.776283
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert isinstance(obj, CmdLineFactCollector)


# Generated at 2022-06-24 23:43:52.419124
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()

# Generated at 2022-06-24 23:43:58.087038
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Create object of class CmdLineFactCollector
    cmd_line_fact_collector_1 = CmdLineFactCollector()

    # Call method collect of class CmdLineFactCollector
    var_1 = cmd_line_fact_collector_1.collect()


# Generated at 2022-06-24 23:44:00.235830
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    class_0 = CmdLineFactCollector()
    assert class_0 is not None


# Generated at 2022-06-24 23:44:27.275733
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    cmd_line_fact_collector_1._get_proc_cmdline = lambda: "root=UUID=5b5e5b5a-8f2b-4e0a-9b4e-59b20fc5a0a5 ro quiet nmi_watchdog=0 consoleblank=300 intel_idle.max_cstate=1 processor.max_cstate=1"
    cmd_line_fact_collector_1._parse_proc_cmdline = lambda x: x
    cmd_line_fact_collector_1._parse_proc_cmdline_facts = lambda x: x
    var_1 = cmd_line_fact_collector_1.collect()

# Generated at 2022-06-24 23:44:29.309237
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert not hasattr(CmdLineFactCollector, '_fact_ids')


# Generated at 2022-06-24 23:44:34.333001
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()

# Generated at 2022-06-24 23:44:42.386228
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():

    # Test a valid instance of CmdLineFactCollector
    _fact_collector = CmdLineFactCollector()

    assert _fact_collector is not None
    assert isinstance(_fact_collector, BaseFactCollector)

    # Test name
    assert _fact_collector.name == 'cmdline'

    # Test the collect method
    assert isinstance(_fact_collector.collect(), dict)
    assert _fact_collector.collect().get('cmdline') is not None
    assert _fact_collector.collect().get('proc_cmdline') is not None

    _fact_collector = CmdLineFactCollector(module=None, collected_facts=None)
    assert isinstance(_fact_collector.collect(), dict)
    assert _fact_collector.collect().get('cmdline') is not None

# Generated at 2022-06-24 23:44:44.729405
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()

# Generated at 2022-06-24 23:44:47.679275
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'


# Generated at 2022-06-24 23:44:51.705670
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    var_0 = CmdLineFactCollector()
    var_1 = var_0.collect()

# Generated at 2022-06-24 23:45:01.108911
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()

# Generated at 2022-06-24 23:45:07.484878
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline', 'Incorrect value for CmdLineFactCollector.name'
    assert cmd_line_fact_collector_0._fact_id == 'ansible_cmdline', 'Incorrect value for CmdLineFactCollector._fact_id'
    assert cmd_line_fact_collector_0._fact_ids == set(['ansible_cmdline']), 'Incorrect value for CmdLineFactCollector._fact_ids'


# Generated at 2022-06-24 23:45:10.602520
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()


# Generated at 2022-06-24 23:45:54.307709
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0 is not None
    assert cmd_line_fact_collector_0.name  == 'cmdline'
    assert cmd_line_fact_collector_0._fact_ids == set()


# Generated at 2022-06-24 23:45:58.172240
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    pass


# Generated at 2022-06-24 23:45:59.694299
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_1 = CmdLineFactCollector()


# Generated at 2022-06-24 23:46:03.689447
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    var_1 = cmd_line_fact_collector_1.collect()



# Generated at 2022-06-24 23:46:05.534290
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    assert cmd_line_fact_collector_1.name == 'cmdline'
    assert cmd_line_fact_collector_1._fact_ids == set()


# Generated at 2022-06-24 23:46:06.476919
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    var_11 = CmdLineFactCollector()


# Generated at 2022-06-24 23:46:10.486711
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()

# Generated at 2022-06-24 23:46:14.432709
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert  cmd_line_fact_collector_0._fact_ids == set()


# Generated at 2022-06-24 23:46:16.466539
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    try:
        cmd_line_fact_collector_1 = CmdLineFactCollector()
        assert True
    except:
        assert False


# Generated at 2022-06-24 23:46:19.318661
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'



# Generated at 2022-06-24 23:47:50.719014
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert cmd_line_fact_collector_0._fact_ids == {'ansible_cmdline'}



# Generated at 2022-06-24 23:47:53.234540
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'

# unit tests for CmdLineFactCollector.collect

# Generated at 2022-06-24 23:47:55.630576
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert isinstance(cmd_line_fact_collector_0, CmdLineFactCollector)


# Generated at 2022-06-24 23:48:03.533978
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    # On OpenShift, we don't have a '/proc/cmdline' file (only a '/proc/cmdline_pod' file).
    # If no '/proc/cmdline' file is found, return an empty dict:
    assert cmd_line_fact_collector_0._get_proc_cmdline() == {}
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert cmd_line_fact_collector_0._fact_ids == set()
    assert cmd_line_fact_collector_0.collect() == {}
    assert cmd_line_fact_collector_0.collect(module=None, collected_facts=None) == {}


# Generated at 2022-06-24 23:48:05.039385
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector is not None

# Tests for function _get_proc_cmdline

# Generated at 2022-06-24 23:48:10.468783
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    # Get a reference to the instance of CmdLineFactCollector
    cmd_line_fact_collector_0 = CmdLineFactCollector()

    # Call method to get the facts
    var_0 = cmd_line_fact_collector_0.collect()

    # Check if there is a proc_cmdline key in the dict returned
    assert('proc_cmdline' in var_0)

    # Check if there is a cmdline key in the dict returned
    assert('cmdline' in var_0)

# Generated at 2022-06-24 23:48:14.466504
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector.cmdline import CmdLineFactCollector
    cmd_line_fact_collector_obj = CmdLineFactCollector()
    cmd_line_fact_collector_obj.collect()

# Generated at 2022-06-24 23:48:20.889963
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    test_case_0()

## For more information on the following, see
## https://www.python.org/dev/peps/pep-0263/
# vim: tabstop=8 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-24 23:48:26.831270
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()

    # Assert set(_fact_ids) == set([ name ])
    assert(cmd_line_fact_collector_0._fact_ids == {'cmdline'})

    # Assert name == 'cmdline'
    assert(cmd_line_fact_collector_0.name == 'cmdline')


# Generated at 2022-06-24 23:48:30.988428
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    assert var_0 == {
        'cmdline': {
            'ansible_facts': True,
            'collection': True,
            'module_setup': True,
            'setup': True
        },
        'proc_cmdline': {
            'ansible_facts': True,
            'collection': True,
            'module_setup': True,
            'setup': True
        }
    }



# Generated at 2022-06-24 23:52:04.460791
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector.collect()
    var_1 = cmd_line_fact_collector.collect()

# Generated at 2022-06-24 23:52:13.707916
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Test case for method collect of class CmdLineFactCollector.
    # Instantiate objects for CmdLineFactCollector class
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector != None
    assert isinstance(cmd_line_fact_collector, CmdLineFactCollector) == True
    assert isinstance(cmd_line_fact_collector, BaseFactCollector) == True
    # Inbuilt assert to verify that the method returns the expected value.