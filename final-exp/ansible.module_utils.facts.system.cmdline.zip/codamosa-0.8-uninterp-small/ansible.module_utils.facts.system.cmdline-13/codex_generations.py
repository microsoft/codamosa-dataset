

# Generated at 2022-06-24 23:42:19.994281
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # This is a test example
    test_case_0()

if __name__ == "__main__":
    test_CmdLineFactCollector()

# Generated at 2022-06-24 23:42:23.016116
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # https://github.com/ansible/ansible/issues/14229
    pass

# Generated at 2022-06-24 23:42:32.019414
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    str_0 = '='
    cmd_line_fact_collector_0 = CmdLineFactCollector(str_0)
    cmd_line_fact_collector_0._get_proc_cmdline()
    str_0 = u'!\x1cg\x0cQ[G'
    cmd_line_fact_collector_0._parse_proc_cmdline(str_0)
    cmd_line_fact_collector_0._parse_proc_cmdline_facts(str_0)
    cmd_line_fact_collector_0.collect()

if __name__ == '__main__':
    test_case_0()
    test_CmdLineFactCollector()

# Generated at 2022-06-24 23:42:38.852960
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    str_0 = 'TqT!D\x0c;P\x0c'
    cmd_line_fact_collector_0 = CmdLineFactCollector(str_0)
    # Test CmdLineFactCollector.name = 
    # Test CmdLineFactCollector.__name__ = 
    str_0 = ')\x19!\x1b'
    cmd_line_fact_collector_0 = CmdLineFactCollector(str_0)


# Generated at 2022-06-24 23:42:41.620534
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    str_0 = 'K'
    cmd_line_fact_collector_0 = CmdLineFactCollector(str_0)
    collected_facts_1 = cmd_line_fact_collector_0.collect()
    assert collected_facts_1 == {}


# Generated at 2022-06-24 23:42:47.873845
# Unit test for constructor of class CmdLineFactCollector

# Generated at 2022-06-24 23:42:48.523066
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    pass


# Generated at 2022-06-24 23:42:54.590825
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    str_0 = '~*)I\x0cw=PJtX&N#9>agb'
    cmd_line_fact_collector_0 = CmdLineFactCollector(str_0)

    str_0 = 'G\x1a\x1d'
    str_1 = '\x1f\x02\x1a'
    cmd_line_fact_collector_0.get_file_content(str_0, str_1)

    str_0 = '~*)I\x0cw=PJtX&N#9>agb'
    str_1 = '\x1f\x02\x1a'
    cmd_line_fact_collector_0.parse_proc_cmdline(str_0, str_1)


# Generated at 2022-06-24 23:42:57.656185
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector("value")
    assert cmd_line_fact_collector_0.collect("module", "collected_facts") is None
    assert cmd_line_fact_collector_0.collect("module") == {}


# Generated at 2022-06-24 23:43:02.505288
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    module = ''
    collected_facts = ''
    cmd_line_fact_collector_0 = CmdLineFactCollector(module, collected_facts)
    assert cmd_line_fact_collector_0.collect() == {}


# Generated at 2022-06-24 23:43:08.101568
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    try:
        CmdLineFactCollector()
    except NameError:
        raise AssertionError('Failed to create an instance of class CmdLineFactCollector')


# Generated at 2022-06-24 23:43:16.549873
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    assert var_0
    assert isinstance(var_0, dict)
    assert len(var_0) == 2
    assert var_0['cmdline']
    assert isinstance(var_0['cmdline'], dict)
    assert var_0['proc_cmdline']
    assert isinstance(var_0['proc_cmdline'], dict)
    assert len(var_0['proc_cmdline']) >= len(var_0['cmdline'])


# Generated at 2022-06-24 23:43:18.282308
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()

# Generated at 2022-06-24 23:43:22.340280
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Values
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    collected_facts_0 = {}

    # Invocation
    ret_val_0 = cmd_line_fact_collector_0.collect(collected_facts_0)

    # Tests
    assert ret_val_0 == {}



# Generated at 2022-06-24 23:43:26.424183
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()

    assert True == cmd_line_fact_collector_0.collect()


# Generated at 2022-06-24 23:43:35.175818
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    proc_cmdline = 'BOOT_IMAGE=(hd0,msdos1)/boot/vmlinuz-4.18.6-200.fc28.x86_64 root=UUID=d7ff77f0-35f4-4e4b-8bbd-d8eb79c2059f ro rd.lvm.lv=fedora/root rd.lvm.lv=fedora/swap rhgb quiet LANG=en_US.UTF-8'
    cmd_line_fact_collector = CmdLineFactCollector()
    result_proc_cmdline_dict = cmd_line_fact_collector._parse_proc_cmdline_facts(proc_cmdline)

# Generated at 2022-06-24 23:43:39.592149
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    assert False

# Generated at 2022-06-24 23:43:40.513508
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    assert 1 == 1


# Generated at 2022-06-24 23:43:42.807530
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Test for constructor with no argument
    assert CmdLineFactCollector().name == 'cmdline'
    assert CmdLineFactCollector()._fact_ids == set()


# Generated at 2022-06-24 23:43:45.025258
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'


# Generated at 2022-06-24 23:43:57.909591
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    var_1 = cmd_line_fact_collector_1.collect()
    assert isinstance(var_1, dict)


# Generated at 2022-06-24 23:44:02.017488
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    print('[*] Testing constructor of class CmdLineFactCollector...')

    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.name

    assert var_0 == 'cmdline'


# Generated at 2022-06-24 23:44:02.778009
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Test ID 0
    test_case_0()


# Generated at 2022-06-24 23:44:04.884793
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    try:
        assert test_case_0()
    except:
        assert False

if __name__ == '__main__':
    test_CmdLineFactCollector()

# Generated at 2022-06-24 23:44:06.002351
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:44:07.794789
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'


# Generated at 2022-06-24 23:44:10.842806
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    try:
        cmd_line_fact_collector_1 = CmdLineFactCollector()
    except:
        print('Constructor of class CmdLineFactCollector has error!')
        exit(1)
    else:
        print('Constructor of class CmdLineFactCollector has no error!')
    finally:
        cmd_line_fact_collector_1 = None


# Generated at 2022-06-24 23:44:13.894722
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()

# Generated at 2022-06-24 23:44:15.626994
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()


# Generated at 2022-06-24 23:44:26.085433
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # _get_proc_cmdline() is tested in test_case_0
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    cmd_line_fact_collector_0._get_proc_cmdline = lambda: 'rhgb quiet'
    # _parse_proc_cmdline() is tested in test_case_0
    cmd_line_fact_collector_0._parse_proc_cmdline = lambda self, data: {'rhgb': True, 'quiet': True}
    # _parse_proc_cmdline_facts() is tested in test_case_0
    cmd_line_fact_collector_0._parse_proc_cmdline_facts = lambda self, data: {'rhgb': True, 'quiet': True}
    var_1 = cmd_line_fact_collector_0.collect

# Generated at 2022-06-24 23:44:49.974884
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    var_1 = cmd_line_fact_collector_1.collect()
    assert var_1 == {'cmdline': {'BOOT_IMAGE': '/vmlinuz', 'net.ifnames': '0', 'selinux': '0', 'quiet': True, 'initrd': '/initrd.img', 'ro': True, 'root': '/dev/mapper/centos-root'}}



# Generated at 2022-06-24 23:44:51.655213
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    var_1 = cmd_line_fact_collector_1.collect()


# Generated at 2022-06-24 23:44:56.341965
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_obj = CmdLineFactCollector()
    # cmd_line_fact_collector_obj.collect()



# Generated at 2022-06-24 23:44:56.772776
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    pass

# Generated at 2022-06-24 23:44:57.473948
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    assert True


# Generated at 2022-06-24 23:45:03.015840
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert cmd_line_fact_collector_0._fact_ids == set()


# Generated at 2022-06-24 23:45:05.938099
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0._fact_ids == set()
    assert cmd_line_fact_collector_0.name == 'cmdline'


# Generated at 2022-06-24 23:45:10.777951
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    var_0 = CmdLineFactCollector()
    var_0.collect()
    assert(var_0.name == 'cmdline')
    assert('cmdline' in var_0.collect())
    assert('proc_cmdline' in var_0.collect())

test_case_0()
test_CmdLineFactCollector_collect()

# Generated at 2022-06-24 23:45:18.265247
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Mock /proc/cmdline
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    cmd_line_fact_collector_0._get_file_content = lambda self, x: b"quiet foo=bar bar=foo=baz=spam"
    var_0 = cmd_line_fact_collector_0.collect()
    assert var_0['cmdline'] == {'quiet': True, 'foo': 'bar', 'bar': 'foo=baz=spam'}
    assert var_0['proc_cmdline'] == {'quiet': True, 'foo': 'bar', 'bar': 'foo=baz=spam'}


# Generated at 2022-06-24 23:45:22.952771
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()

# Generated at 2022-06-24 23:46:04.274902
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    x = CmdLineFactCollector()
    assert type(x) == CmdLineFactCollector


# Generated at 2022-06-24 23:46:05.942099
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    assert var_0 == {}

# Generated at 2022-06-24 23:46:13.183824
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector = CmdLineFactCollector()
    cmd_line_facts = cmd_line_fact_collector.collect()

    assert cmd_line_facts
    assert 'cmdline' in cmd_line_facts
    assert 'proc_cmdline' in cmd_line_facts

    cmd_line = cmd_line_facts['cmdline']
    assert cmd_line
    assert 'root' in cmd_line
    assert cmd_line['root'].startswith('/dev/')

    proc_cmd_line = cmd_line_facts['proc_cmdline']
    assert proc_cmd_line
    assert 'root' in proc_cmd_line
    assert proc_cmd_line['root'].startswith('/dev/')

# Generated at 2022-06-24 23:46:16.899295
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector is not None
    assert cmd_line_fact_collector.name == 'cmdline'
    assert cmd_line_fact_collector._fact_ids == set()


# Generated at 2022-06-24 23:46:26.088615
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Prepare test environment
    cmd_line_fact_collector_0 = CmdLineFactCollector()

    # Call method collect of cmd_line_fact_collector_0
    var_0 = cmd_line_fact_collector_0.collect()

    # Check assertions
    assert var_0 == {'cmdline': {}, 'proc_cmdline': {}}

    # Reset test environment
    cmd_line_fact_collector_0 = CmdLineFactCollector()

    # Call method collect of cmd_line_fact_collector_0
    var_0 = cmd_line_fact_collector_0.collect()

    # Check assertions
    assert var_0 == {'cmdline': {}, 'proc_cmdline': {}}



# Generated at 2022-06-24 23:46:29.978187
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0 is not None


# Generated at 2022-06-24 23:46:33.920125
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector.name == "cmdline"
    assert cmd_line_fact_collector._fact_ids == set()

# Generated at 2022-06-24 23:46:36.653082
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_obj = CmdLineFactCollector()
    assert cmd_line_fact_collector_obj._fact_ids == set()
    assert cmd_line_fact_collector_obj.name == 'cmdline'


# Generated at 2022-06-24 23:46:40.759383
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'


# Generated at 2022-06-24 23:46:43.279951
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert cmd_line_fact_collector_0._fact_ids == set()



# Generated at 2022-06-24 23:48:08.683363
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'
    assert len(obj._fact_ids) == 0



# Generated at 2022-06-24 23:48:11.471265
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()


# Generated at 2022-06-24 23:48:14.525784
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    if not isinstance(cmd_line_fact_collector_0._fact_ids, set):
        assert False
    else:
        assert True


# Generated at 2022-06-24 23:48:20.055034
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    #assert var_0 == {}

# Generated at 2022-06-24 23:48:20.987183
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:48:24.690626
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector.name == 'cmdline'
    assert cmd_line_fact_collector._fact_ids == set()


# Generated at 2022-06-24 23:48:26.496703
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector()


# Generated at 2022-06-24 23:48:28.397674
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    assert isinstance(var_0, dict)

# Generated at 2022-06-24 23:48:30.541742
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
  cmd_line_fact_collector_0 = CmdLineFactCollector()
  assert cmd_line_fact_collector_0._fact_ids == set()
  assert cmd_line_fact_collector_0.name == 'cmdline'


# Generated at 2022-06-24 23:48:31.706294
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector is not None


# Generated at 2022-06-24 23:51:49.264724
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    assert callable(CmdLineFactCollector.collect)


# Generated at 2022-06-24 23:51:51.250662
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Create instance of CmdLineFactCollector
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    # Call collect method of CmdLineFactCollector
    var_0 = cmd_line_fact_collector_0.collect()


# Generated at 2022-06-24 23:51:56.372941
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    command_line = '/usr/lib/systemd/systemd root=UUID=c0583421-2f43-4c4c-9434-8b0dece7f9e6 rw quiet'
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    # fill the value of /proc/cmdline
    cmd_line_fact_collector_0._get_proc_cmdline = lambda: command_line
    # unit test
    var_0 = cmd_line_fact_collector_0.collect()
    print(var_0)
    #assert var_0 == {'cmdline': {'quiet': True, 'root': 'UUID=c0583421-2f43-4c4c-9434-8b0dece7f9e6', 'rw':

# Generated at 2022-06-24 23:52:01.517032
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
  cmd_line_fact_collector_0 = CmdLineFactCollector()
  assert type(cmd_line_fact_collector_0).__name__ == 'CmdLineFactCollector'

# Generated at 2022-06-24 23:52:03.672848
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    
    assert isinstance(CmdLineFactCollector(), CmdLineFactCollector)

# Generated at 2022-06-24 23:52:05.920132
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    assert cmd_line_fact_collector_1.name == 'cmdline'
    assert cmd_line_fact_collector_1._fact_ids == set()


# Generated at 2022-06-24 23:52:13.643595
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.name
    assert var_0 == "cmdline"
    var_1 = cmd_line_fact_collector_0._fact_ids
    var_2 = cmd_line_fact_collector_1._fact_ids
    assert var_1 == var_2
