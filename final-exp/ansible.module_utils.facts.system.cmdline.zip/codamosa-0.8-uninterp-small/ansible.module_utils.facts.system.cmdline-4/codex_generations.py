

# Generated at 2022-06-24 23:42:17.027091
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'


# Generated at 2022-06-24 23:42:20.453958
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    fact_collector = CmdLineFactCollector()
    assert fact_collector.name == 'cmdline'
    assert not fact_collector._fact_ids


# Generated at 2022-06-24 23:42:25.647089
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert cmd_line_fact_collector_0._fact_ids == set()


# Generated at 2022-06-24 23:42:36.862839
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    assert cmd_line_fact_collector_1.name == 'cmdline'
    assert cmd_line_fact_collector_1._fact_ids == set()

# Generated at 2022-06-24 23:42:37.675678
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    cmd_line_fact_collector_0.collect()

# Generated at 2022-06-24 23:42:39.989390
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    actual = cmd_line_fact_collector_1.collect()
    expected = actual
    assert expected == actual


# Generated at 2022-06-24 23:42:40.985756
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # TODO: implement unit test for method collect of class CmdLineFactCollector
    pass

# Generated at 2022-06-24 23:42:46.779203
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()

    data = 'ro rootfstype=rootfs root=/dev/ram0 rw'
    cmdline_facts = {'cmdline': {'ro': True, 'rootfstype': 'rootfs', 'root': '/dev/ram0', 'rw': True},
                     'proc_cmdline': {'ro': True, 'rootfstype': 'rootfs', 'root': '/dev/ram0', 'rw': True}}

    cmd_line_fact_collector_0._get_proc_cmdline = lambda: data
    assert cmd_line_fact_collector_0.collect() == cmdline_facts


# Generated at 2022-06-24 23:42:48.516369
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert hasattr(CmdLineFactCollector, 'collect')

# Generated at 2022-06-24 23:42:49.423727
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector().name == 'cmdline'


# Generated at 2022-06-24 23:42:54.699231
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:42:58.984181
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    file_call_result_0 = {'contents': 'net.ifnames=0 biosdevname=0', 'path': '/proc/cmdline'}
    file_call_result_1 = {'contents': 'root=UUID=3dd3d3c7-a2af-4b10-a1e8-d7f118198325 ro recovery nomodeset', 'path': '/proc/cmdline'}

# Generated at 2022-06-24 23:43:02.927838
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    assert ('cmdline' in var_0)
    assert ('proc_cmdline' in var_0)

# Generated at 2022-06-24 23:43:10.041803
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert cmd_line_fact_collector_0._fact_ids == set()
    assert isinstance(cmd_line_fact_collector_0.name, str)
    assert isinstance(cmd_line_fact_collector_0._fact_ids, set)


# Generated at 2022-06-24 23:43:12.348693
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()



# Generated at 2022-06-24 23:43:14.267484
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector


# Generated at 2022-06-24 23:43:17.017128
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector.name == 'cmdline'
    assert cmd_line_fact_collector._fact_ids == set()


# Generated at 2022-06-24 23:43:20.970078
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_1.collect(collected_facts=var_0)

# Generated at 2022-06-24 23:43:22.531089
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0


# Generated at 2022-06-24 23:43:24.238880
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:43:34.639256
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    name_0 = cmd_line_fact_collector.name
    assert name_0 == 'cmdline'

# Generated at 2022-06-24 23:43:39.455099
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    cmd_line_fact_collector.collect()
    var = cmd_line_fact_collector._collect()


# Generated at 2022-06-24 23:43:41.117254
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:43:43.443966
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    assert cmd_line_fact_collector_1 is not None


# Generated at 2022-06-24 23:43:44.322906
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    assert callable(CmdLineFactCollector.collect)

# Generated at 2022-06-24 23:43:46.677001
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0 is not None


# Generated at 2022-06-24 23:43:48.193570
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    var_0 = CmdLineFactCollector()
    assert isinstance(var_0, CmdLineFactCollector)


# Generated at 2022-06-24 23:43:50.291089
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert type(cmd_line_fact_collector_0) is CmdLineFactCollector


# Generated at 2022-06-24 23:43:52.593387
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()



# Generated at 2022-06-24 23:43:54.729197
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    var_1 = cmd_line_fact_collector_1.collect()

    assert isinstance(var_1, dict) == True


# Generated at 2022-06-24 23:44:15.521134
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()

    # test class variable name

    assert cmd_line_fact_collector.name == 'cmdline'

    # test class variable _fact_ids

    assert cmd_line_fact_collector._fact_ids == set()

# Generated at 2022-06-24 23:44:18.051888
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()

    var_1 = cmd_line_fact_collector_0.collect() # This line is here to prevent a PyFlakes error.


# Generated at 2022-06-24 23:44:21.402550
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()


# Generated at 2022-06-24 23:44:24.513798
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert cmd_line_fact_collector_0._fact_ids == set()



# Generated at 2022-06-24 23:44:34.315054
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()

# Generated at 2022-06-24 23:44:35.621637
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector.collect()

# Generated at 2022-06-24 23:44:40.628524
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Test instantiation of CmdLineFactCollector class
    cmd_line_fact_collector = CmdLineFactCollector()
    # Test name field of CmdLineFactCollector class
    assert cmd_line_fact_collector.name == 'cmdline'


# Generated at 2022-06-24 23:44:43.077603
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert isinstance(cmd_line_fact_collector_0.name, str)
    assert cmd_line_fact_collector_0._fact_ids == set()
    assert isinstance(cmd_line_fact_collector_0._fact_ids, set)


# Generated at 2022-06-24 23:44:45.847514
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    var_0 = CmdLineFactCollector()

    var_1 = var_0.collect()

    assert isinstance(var_1, dict)

# Generated at 2022-06-24 23:44:48.150969
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector = CmdLineFactCollector()
    var = cmd_line_fact_collector.collect()

# Generated at 2022-06-24 23:45:27.006609
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector.name == 'cmdline'
    

# Generated at 2022-06-24 23:45:31.744742
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    var_0 = CmdLineFactCollector()
    assert var_0 is not None


# Generated at 2022-06-24 23:45:33.355086
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    pass


# Generated at 2022-06-24 23:45:35.512954
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    var_1 = cmd_line_fact_collector_1.collect()
    assert 'cmdline' in var_1
    assert 'proc_cmdline' in var_1

# Generated at 2022-06-24 23:45:38.436267
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert callable(CmdLineFactCollector)


# Generated at 2022-06-24 23:45:41.141566
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert cmd_line_fact_collector_0._fact_ids == set()


# Generated at 2022-06-24 23:45:45.805564
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    print("Testing CmdLineFactCollector.collect")
    generator_0 = CmdLineFactCollector()
    var_0 = generator_0.collect()


# Generated at 2022-06-24 23:45:46.633855
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:45:53.016380
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    cmd_line_fact_collector_0.name = "ansible_cmdline"
    cmd_line_fact_collector_0._fact_ids.add("ansible_cmdline")
    
    var_0 = cmd_line_fact_collector_0.collect()
    assert var_0.keys() == {'ansible_cmdline', 'ansible_proc_cmdline'}
    assert var_0["ansible_cmdline"].keys() == {"ansible_cmdline"}
    
    

# Generated at 2022-06-24 23:45:54.266692
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()

# Generated at 2022-06-24 23:47:27.052243
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.collect() == {'cmdline': {}, 'proc_cmdline': {}}

# Generated at 2022-06-24 23:47:30.730151
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    assert var_0 == dict(cmdline=dict(rd_NO_DM='rd_NO_DM'), proc_cmdline=dict(rd_NO_DM=True))


# Generated at 2022-06-24 23:47:33.442007
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    assert len(var_0) == 2

# Generated at 2022-06-24 23:47:34.574622
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector('localhost', 1, 20) is not None


# Generated at 2022-06-24 23:47:39.352389
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_1 = cmd_line_fact_collector_0.collect()


# Generated at 2022-06-24 23:47:41.361590
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    assert cmd_line_fact_collector_1


# Generated at 2022-06-24 23:47:44.853474
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # This will run the code in the above function
    test_case_0()

# Generated at 2022-06-24 23:47:45.598271
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()

# Stub function to return factdata

# Generated at 2022-06-24 23:47:51.686108
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    assert var_0 == {'proc_cmdline': {'ip': '192.168.0.253', 'quiet': True, 'root': '/dev/nfs'}, 'cmdline': {'ip': '192.168.0.253', 'quiet': True, 'root': '/dev/nfs'}}

# Generated at 2022-06-24 23:47:52.820499
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    instance = CmdLineFactCollector()


# Generated at 2022-06-24 23:51:41.320338
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()



# Generated at 2022-06-24 23:51:42.874666
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:51:44.325468
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    var_1 = cmd_line_fact_collector_1.collect()


# Generated at 2022-06-24 23:51:48.752056
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_1 = CmdLineFactCollector()


# Generated at 2022-06-24 23:51:50.941821
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0._fact_ids == set([])
    assert cmd_line_fact_collector_0.name == 'cmdline'


# Generated at 2022-06-24 23:51:56.181820
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Create an object of CmdLineFactCollector
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    # Assert that the object created is an instance of CmdLineFactCollector as expected
    assert isinstance(cmd_line_fact_collector_0, CmdLineFactCollector)
    # Assert that the attribute _fact_ids is empty as expected
    assert cmd_line_fact_collector_0._fact_ids == set()
    # Assert that the attribute name is cmdline as expected
    assert cmd_line_fact_collector_0.name == 'cmdline'
    # Assert that the class attribute _fact_ids is empty as expected
    assert CmdLineFactCollector._fact_ids == set()
    # Assert that the class attribute name is cmdline as expected
    assert C

# Generated at 2022-06-24 23:52:02.374625
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert cmd_line_fact_collector_0._fact_ids == set()

# Generated at 2022-06-24 23:52:04.793373
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector._fact_ids == {'ansible_cmdline'}


# Generated at 2022-06-24 23:52:11.376059
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = {'cmdline': {'console': 'ttyS0', 'ro': True}, 'proc_cmdline': {'ro': True, 'console': 'ttyS0'}}
    var = {'cmdline': {'console': 'ttyS0', 'ro': True}, 'proc_cmdline': {'ro': True, 'console': 'ttyS0'}}
    assert var == cmdline_facts
