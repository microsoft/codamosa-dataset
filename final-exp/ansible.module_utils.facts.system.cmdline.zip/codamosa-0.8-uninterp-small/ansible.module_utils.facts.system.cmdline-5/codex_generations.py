

# Generated at 2022-06-24 23:42:21.145979
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert (cmd_line_fact_collector_0.collect() == {'proc_cmdline': {},
                                                    'cmdline': {}})



# Generated at 2022-06-24 23:42:32.019367
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    test_data = "root=/dev/mapper/fedora-root ro rd.lvm.lv=fedora/root rd.lvm.lv=fedora/swap rhgb quiet LANG=en_US.UTF-8"
    cmd_line_fact_collector_collect = CmdLineFactCollector()
    result = cmd_line_fact_collector_collect._get_proc_cmdline()
    assert result == test_data
    result = cmd_line_fact_collector_collect._parse_proc_cmdline(test_data)

# Generated at 2022-06-24 23:42:32.976187
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector()


# Generated at 2022-06-24 23:42:36.863168
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    tmp = cmd_line_fact_collector_0.collect()

# Generated at 2022-06-24 23:42:38.694912
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()

    #cmdline = cmd_line_fact_collector_0.collect()
    #print(cmdline)

# Generated at 2022-06-24 23:42:39.194837
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    pass

# Generated at 2022-06-24 23:42:41.653867
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert cmd_line_fact_collector_0._fact_ids == set()



# Generated at 2022-06-24 23:42:47.896038
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    cmd_line_fact_collector_1.parsed = False
    cmd_line_fact_collector_1.fact_ids = cmd_line_fact_collector_1._fact_ids

    data = cmd_line_fact_collector_1._get_proc_cmdline()
    parsed_data = cmd_line_fact_collector_1._parse_proc_cmdline_facts(data)

    cmd_line_fact_collector_1.collected_facts = {}
    cmd_line_fact_collector_1.collected_facts['cmdline'] = {}
    cmd_line_fact_collector_1.collected_facts['cmdline']['boot'] = parsed_data
    cmd_line_fact_collector

# Generated at 2022-06-24 23:42:49.962726
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector.name == 'cmdline'
    assert cmd_line_fact_collector._fact_ids == set()


# Generated at 2022-06-24 23:42:51.731251
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    ret = cmd_line_fact_collector_0.collect()
    assert type(ret) is dict


# Generated at 2022-06-24 23:42:57.517046
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0._fact_ids == set()
    assert cmd_line_fact_collector_0.name == 'cmdline'


# Generated at 2022-06-24 23:43:03.363676
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    # Check class variables
    assert cmd_line_fact_collector_0._fact_ids == {}, 'Check _fact_ids'
    assert cmd_line_fact_collector_0.name == 'cmdline', 'Check name'



# Generated at 2022-06-24 23:43:09.273111
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Create an instance of CmdLineFactCollector
    cmd_line_fact_collector_0 = CmdLineFactCollector()

    # Call method collect of CmdLineFactCollector
    return_value = cmd_line_fact_collector_0.collect()
    assert return_value == {}



# Generated at 2022-06-24 23:43:18.131902
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect(cmd_line_fact_collector_0)

# Generated at 2022-06-24 23:43:21.193525
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector.name == 'cmdline'
    assert cmd_line_fact_collector._fact_ids == set()


# Generated at 2022-06-24 23:43:25.861189
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Variables initialization
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    # Testing if an exception is raised
    with pytest.raises(Exception):
        cmd_line_fact_collector_0.collect()



# Generated at 2022-06-24 23:43:29.172604
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_1 = CmdLineFactCollector('CmdLineFactCollector', 'cmdline', 'cmdline')
    assert cmd_line_fact_collector_1._fact_ids == set()


# Generated at 2022-06-24 23:43:32.977189
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert cmd_line_fact_collector_0._fact_ids == set()


# Generated at 2022-06-24 23:43:35.515439
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect(cmd_line_fact_collector_0)
    print(var_0)
    return var_0

# Generated at 2022-06-24 23:43:40.250332
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect(cmd_line_fact_collector_0)


# Generated at 2022-06-24 23:43:54.877375
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # noinspection PyUnresolvedReferences
    from ansible.module_utils.facts.collector import BaseFactCollector
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    # Save CmdLineFactCollector.collect to a variable.
    func = cmd_line_fact_collector_0.collect
    # Check the function signature is correct.
    func.__annotations__.pop('return')
    # The return type annotation is wrong.
    assert callable(func)
    # Check it yields something of the correct type.
    assert isinstance(func(cmd_line_fact_collector_0), dict)

# The following test is erroneous, it tests the wrong thing.

# Generated at 2022-06-24 23:44:04.525620
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect(cmd_line_fact_collector_0)
    var_1 = {}

# Generated at 2022-06-24 23:44:05.638045
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector() # Should not raise any exceptions


# Generated at 2022-06-24 23:44:11.598350
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    var_1 = cmd_line_fact_collector_1.collect(cmd_line_fact_collector_1)

    assert var_1['proc_cmdline']['BOOT_IMAGE'] == '/boot/vmlinuz-3.10.0-514.el7.x86_64'
    assert var_1['proc_cmdline']['LANG'] == 'en_US.UTF-8'
    assert var_1['proc_cmdline']['crashkernel'] == 'auto'
    assert var_1['proc_cmdline']['rd.lvm.lv'] == 'centos/root'
    assert var_1['proc_cmdline']['rd.lvm.lv'] == 'centos/swap'

# Generated at 2022-06-24 23:44:15.308178
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert type(cmd_line_fact_collector_0).__name__ == 'CmdLineFactCollector'
    assert cmd_line_fact_collector_0.name == 'cmdline'


# Generated at 2022-06-24 23:44:16.675603
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    dummy_cmd_line_fact_collector = CmdLineFactCollector()
    assert not dummy_cmd_line_fact_collector.name == ""


# Generated at 2022-06-24 23:44:19.602631
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:44:21.710152
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    cmd_line_fact_collector_1.collect()

# Generated at 2022-06-24 23:44:24.507666
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect(cmd_line_fact_collector_0)
    assert var_0 == {}

# Generated at 2022-06-24 23:44:28.036707
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Test case 0
    test_case_0()

# Generated at 2022-06-24 23:44:51.616267
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    print("Testing the constructor of class CmdLineFactCollector")


# Generated at 2022-06-24 23:44:54.224753
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    var_1 = {}
    var_2 = cmd_line_fact_collector_1.collect(cmd_line_fact_collector_1)
    assert sorted(var_1.keys()) == sorted(var_2.keys())

# Generated at 2022-06-24 23:44:55.327918
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    try:
        CmdLineFactCollector()
    except NameError:
        assert False


# Generated at 2022-06-24 23:44:57.253479
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    print("Test collect method of class CmdLineFactCollector")
    print("### Case 0 - Collect CmdLine Facts ###")
    test_case_0()

# test_CmdLineFactCollector_collect()

# Generated at 2022-06-24 23:45:02.654893
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    print('Testing CmdLineFactCollector()')
    test_case_0()

if __name__ == '__main__':
    print('Testing AnsibleModuleUtilsCmdLineFactCollector')
    test_CmdLineFactCollector()

# Generated at 2022-06-24 23:45:05.128371
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect(cmd_line_fact_collector_0)
    assert var_0 == None


# Generated at 2022-06-24 23:45:06.461249
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector().name == 'cmdline', 'Test Failed'



# Generated at 2022-06-24 23:45:11.038609
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    cmd_line_fact_collector_0.collect(cmd_line_fact_collector_0)
    assert cmd_line_fact_collector_0.get_fact_names() == set()


# Generated at 2022-06-24 23:45:13.942416
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect(cmd_line_fact_collector_0)

# Generated at 2022-06-24 23:45:15.251480
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()


# Generated at 2022-06-24 23:45:58.613865
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    print('Running test_CmdLineFactCollector...\n')
    obj_0 = CmdLineFactCollector()
    #Test_case0
    test_case_0()
    print('\nTest_Case 0 Success\n')



# Generated at 2022-06-24 23:45:59.687054
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    try:
        test_case_0()
        test_case_1()
    except:
        raise AssertionError("Exception in unit test")


# Generated at 2022-06-24 23:46:04.955666
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    assert cmd_line_fact_collector_1._fact_ids == set()
    assert cmd_line_fact_collector_1.name == 'cmdline'


# Generated at 2022-06-24 23:46:08.231764
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Assume
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect(cmd_line_fact_collector_0)
    # Verify
    assert var_0 == {}

# Generated at 2022-06-24 23:46:11.561774
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    try:
        cmd_line_fact_collector = CmdLineFactCollector()
    except Exception as ex:
        assert False, 'Error in constructor of CmdLineFactCollector'
    else:
        assert True


# Generated at 2022-06-24 23:46:17.501199
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    print("Testing CmdLineFactCollector.collect.")

    # Test case # 0
    print("Test case # 0")
    test_case_0()

if __name__ == '__main__':
    print("Starting tests for CmdLineFactCollector class.")
    test_CmdLineFactCollector_collect()
    print("Done!")
    print("")
    print("")

# Generated at 2022-06-24 23:46:21.019489
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    # match the __init__ method of the class
    assert set(['name', '_fact_ids']) == set(dir(cmd_line_fact_collector))


# Generated at 2022-06-24 23:46:28.464924
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    cmd_line_content = cmd_line_fact_collector_0._get_proc_cmdline()
    cmd_line_fact_collector_0._parse_proc_cmdline(cmd_line_content)
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    cmd_line_content = cmd_line_fact_collector_1._get_proc_cmdline()
    cmd_line_fact_collector_1._parse_proc_cmdline_facts(cmd_line_content)
    var_2 = cmd_line_fact_collector_0.collect()
    cmd_line_fact_collector_0.collect(cmd_line_fact_collector_0)


# Generated at 2022-06-24 23:46:29.535502
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()

if __name__ == "__main__":
    test_Case_0()

# Generated at 2022-06-24 23:46:35.711100
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_1 = True
    var_1 = True
    var_1 = True
    var_1 = True
    var_1 = True
    var_1 = True
    var_1 = True
    var_1 = True
    var_1 = True
    var_1 = True
    var_1 = True
    var_1 = True
    var_1 = True


# Generated at 2022-06-24 23:48:06.740088
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()


# Generated at 2022-06-24 23:48:09.297889
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    assert cmd_line_fact_collector_1 is not None


# Generated at 2022-06-24 23:48:13.110832
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_instance = CmdLineFactCollector()
    assert isinstance(cmd_line_fact_collector_instance, CmdLineFactCollector)


# Generated at 2022-06-24 23:48:15.016759
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector = CmdLineFactCollector()
    var = cmd_line_fact_collector.collect(cmd_line_fact_collector)


test_case_0()

# Generated at 2022-06-24 23:48:16.343914
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    var_0 = CmdLineFactCollector()
    var_1 = var_0.collect(var_0)
    del var_0, var_1


# Generated at 2022-06-24 23:48:25.286455
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()

    # get_file_content: '/proc/cmdline'
    # _parse_proc_cmdline: 'BOOT_IMAGE=/vmlinuz-3.10.0-327.el7.x86_64 root=/dev/mapper/rhel-root ro crashkernel=auto LANG=en_US.UTF-8 rhgb quiet'
    # _parse_proc_cmdline_facts: 'BOOT_IMAGE=/vmlinuz-3.10.0-327.el7.x86_64 root=/dev/mapper/rhel-root ro crashkernel=auto LANG=en_US.UTF-8 rhgb quiet'

    var_1 = cmd_line_fact_collector_1.collect()

# Generated at 2022-06-24 23:48:31.372835
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()

    #  Tries to collect facts from an invalid file path
    #  Ensures that an exception is raised
    cmd_line_fact_collector_0.name = 'invalid_file.txt'
    cmd_line_fact_collector_0.get_file_content = lambda x: None
    with pytest.raises(IOError) as cm:
        cmd_line_fact_collector_0.collect(cmd_line_fact_collector_0)
    assert("Could not read file {0}: ".format(cmd_line_fact_collector_0.name) in str(cm.value))

    #  Tries to collect facts from an empty file.
    #  Ensures that an empty dict is returned.
    cmd_line_fact

# Generated at 2022-06-24 23:48:32.333182
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    result = CmdLineFactCollector()
    assert isinstance(result, CmdLineFactCollector)


# Generated at 2022-06-24 23:48:32.903025
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    test_case_0()

# Generated at 2022-06-24 23:48:34.210556
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector = CmdLineFactCollector()
    var = cmd_line_fact_collector.collect(cmd_line_fact_collector)



# Generated at 2022-06-24 23:52:10.999346
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    assert True

# Generated at 2022-06-24 23:52:14.421320
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
	
    # 1/Call method collect of CmdLineFactCollector, with no parameters
    assert cmd_line_fact_collector_0.collect() == {}

test_case_0()
test_CmdLineFactCollector_collect()