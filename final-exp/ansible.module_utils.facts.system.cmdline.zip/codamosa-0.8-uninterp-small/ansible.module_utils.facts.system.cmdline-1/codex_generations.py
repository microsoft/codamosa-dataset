

# Generated at 2022-06-24 23:42:20.073554
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert cmd_line_fact_collector_0._fact_ids == set()


# Generated at 2022-06-24 23:42:31.847918
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:42:40.588299
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    cmd_line_data = cmd_line_fact_collector_0._get_proc_cmdline()
    cmd_line_dict = cmd_line_fact_collector_0._parse_proc_cmdline(cmd_line_data)
    assert cmd_line_dict['BOOT_IMAGE'] == '/vmlinuz-3.10.0-327.3.1.el7.x86_64'
    assert cmd_line_dict['root'] == '/dev/mapper/rhel-root'
    assert cmd_line_dict['ro']
    assert not cmd_line_dict['crashkernel']
    assert not cmd_line_dict['net.ifnames']

# Generated at 2022-06-24 23:42:41.055813
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    pass

# Generated at 2022-06-24 23:42:46.610509
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # test for command line arguments passing in a string
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    # test for command line arguments passing in a list
    cmd_line_fact_collector_2 = CmdLineFactCollector()
    # test for command line arguments passing in a dictionary
    cmd_line_fact_collector_3 = CmdLineFactCollector()
    # test for command line arguments without passing any
    cmd_line_fact_collector_4 = CmdLineFactCollector()
    # test for command line arguments passing in a list and dictionary
    cmd_line_fact_collector_5 = CmdLineFactCollector()


# Generated at 2022-06-24 23:42:53.602189
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    print("Testing the constructor of class CmdLineFactCollector")
    try:
        # PROCS_CMDLINE_FILE_PATH is defined in module_utils/facts/utils
        # test case with empty file
        with open(PROCS_CMDLINE_FILE_PATH, 'w') as f:
            f.write("")
        f.close()
        test_case_0()
        print("Test case passed")
    except Exception as e:
        print("Test case failed: " + str(e))


# Generated at 2022-06-24 23:42:54.466443
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()


# Generated at 2022-06-24 23:43:00.672839
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()

    data = '''root=UUID=044b44c6-48e9-48df-8d7f-e1fef608ec0b
ro
rd.lvm.lv=fedora/swap
rd.lvm.lv=fedora/root
rhgb
quiet
'''

    result = cmd_line_fact_collector_0.collect(data)


# Generated at 2022-06-24 23:43:02.240324
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:43:11.046866
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()

    # Verify if instance 'cmd_line_fact_collector_0' is created successfully
    # assert isinstance(cmd_line_fact_collector_0, CmdLineFactCollector) == True
    assert isinstance(cmd_line_fact_collector_0, CmdLineFactCollector)

    # Verify the attributes of instance 'cmd_line_fact_collector_0'
    assert cmd_line_fact_collector_0._fact_ids == set()
    assert cmd_line_fact_collector_0.name == 'cmdline'



# Generated at 2022-06-24 23:43:17.214159
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:43:20.125651
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()


if __name__ == '__main__':
    pass
    # test_case_0()
    # test_CmdLineFactCollector_collect()

# Generated at 2022-06-24 23:43:26.812881
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    if 'cmdline' in var_0:
        assert var_0['cmdline'] == {'ro': True, 'boot': True, 'root': True, 'selinux': True, 'enforcing': True, 'splash': True, 'verbose': True, 'quiet': True, 'rhgb': True}, 'The value of cmdline failed to match'


# Generated at 2022-06-24 23:43:28.162055
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # FIXME: change the following line to test expected values
    assert False


# Generated at 2022-06-24 23:43:29.062608
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:43:33.507810
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()



# Generated at 2022-06-24 23:43:35.201302
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_1 = CmdLineFactCollector()


# Generated at 2022-06-24 23:43:40.685394
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector = CmdLineFactCollector()
    collected_facts = None
    cmd_line_fact_collector_collect = cmd_line_fact_collector.collect(collected_facts=collected_facts)



# Generated at 2022-06-24 23:43:48.024453
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    var_0 = CmdLineFactCollector()
    var_1 = CmdLineFactCollector()
    var_2 = var_1.collect()
    assert isinstance(var_0, var_1)
    assert isinstance(var_0, CmdLineFactCollector)
    assert isinstance(var_0, BaseFactCollector)
    assert isinstance(var_0, object)
    assert isinstance(var_1, CmdLineFactCollector)
    assert isinstance(var_1, BaseFactCollector)
    assert isinstance(var_1, object)
    assert isinstance(var_2, dict)
    assert isinstance(var_2, object)


# Generated at 2022-06-24 23:43:49.622550
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    global cmd_line_fact_collector_0
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:44:01.534313
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert isinstance(CmdLineFactCollector(), CmdLineFactCollector)
    assert isinstance(CmdLineFactCollector(), BaseFactCollector)


# Generated at 2022-06-24 23:44:05.357742
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()

    # Test the method collect of class CmdLineFactCollector
    test_case_0()

if __name__ == '__main__':
    # Unit test for constructor of class CmdLineFactCollector
    test_CmdLineFactCollector()

# Generated at 2022-06-24 23:44:07.832622
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    var_1 = cmd_line_fact_collector_1.collect()


# Generated at 2022-06-24 23:44:11.889947
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    try:
        cmd_line_fact_collector_0 = CmdLineFactCollector()
    except Exception as e:
        var_0 = False
        print("Exception in constructor of class CmdLineFactCollector")
    var_1 = False
    if (cmd_line_fact_collector_0.name == "cmdline"):
        var_1 = True
    var_2 = True
    if (cmd_line_fact_collector_0._fact_ids != set()):
        var_2 = False
    assert (var_1 and var_2 and var_0)


# Generated at 2022-06-24 23:44:13.545338
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    check_collector_test_results(test_case_0)



# Generated at 2022-06-24 23:44:14.451322
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():

    cmd_line_fact_collector = CmdLineFactCollector()


# Generated at 2022-06-24 23:44:15.938649
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    (output, return_value, exception) = test_case_0()

# Unit test wrapper for test_CmdLineFactCollector_collect

# Generated at 2022-06-24 23:44:16.877452
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert hasattr(CmdLineFactCollector) is True


# Generated at 2022-06-24 23:44:21.559163
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    assert True


# Generated at 2022-06-24 23:44:23.772226
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    cmd_line_fact_collector_0.collect()


# Generated at 2022-06-24 23:44:51.522117
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    with open('/proc/cmdline') as data_0:
        var_0 = data_0.read()
    var_1 = cmd_line_fact_collector_0._parse_proc_cmdline_facts(var_0)
    var_2 = cmd_line_fact_collector_0._parse_proc_cmdline(var_0)
    var_3 = cmd_line_fact_collector_0.collect()
    assert var_3['cmdline'] == var_2
    assert var_3['proc_cmdline'] == var_1

# Generated at 2022-06-24 23:44:52.976484
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    var_0 = CmdLineFactCollector()
    var_1 = var_0.collect()

# Generated at 2022-06-24 23:44:57.833857
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    cmd_line_fact_collector_0.collect()
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    cmd_line_fact_collector_1.collect()


# Generated at 2022-06-24 23:45:02.242978
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var = cmd_line_fact_collector_0.collect()


# Generated at 2022-06-24 23:45:06.554767
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()

# Test case for method collect

# Generated at 2022-06-24 23:45:09.359953
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:45:10.445596
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    var_1 = CmdLineFactCollector()


# Generated at 2022-06-24 23:45:12.643605
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert not CmdLineFactCollector()._fact_ids

# Unit test to make sure cmdline_facts is returned as a dict

# Generated at 2022-06-24 23:45:15.563582
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    var_1 = cmd_line_fact_collector_1.collect(module=None, collected_facts=None)

    assert isinstance(var_1, dict)

# Generated at 2022-06-24 23:45:16.697847
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # There is no way to test the function get_file_content
    pass

# Generated at 2022-06-24 23:46:05.972339
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    print(cmd_line_fact_collector_0)
    print(cmd_line_fact_collector_0._fact_ids)


# Generated at 2022-06-24 23:46:10.479214
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.collect() is not None

# Generated at 2022-06-24 23:46:12.020239
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Create new instance
    cmd_line_fact_collector = CmdLineFactCollector()


# Generated at 2022-06-24 23:46:17.899426
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    var_0 = CmdLineFactCollector()

    # Call method collect with parameter module=None, collected_facts=None
    var_0.collect()

    # Call method collect with parameter module=None, collected_facts=None
    var_0.collect()

    # Call method collect with parameter module=None, collected_facts=None
    var_0.collect()


# Generated at 2022-06-24 23:46:22.926339
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert cmd_line_fact_collector_0._fact_ids == set()



# Generated at 2022-06-24 23:46:25.885501
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    # Testing whether instance variable name is correctly set
    assert cmd_line_fact_collector_0.name == 'cmdline'


# Generated at 2022-06-24 23:46:28.677301
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    pass

# Generated at 2022-06-24 23:46:30.101607
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector = CmdLineFactCollector()
    var = cmd_line_fact_collector.collect()
    assert var is not None

# Generated at 2022-06-24 23:46:35.029557
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Create an instance of class CmdLineFactCollector
    cmd_line_fact_collector = CmdLineFactCollector()

    # Invoke method collect
    return_value = cmd_line_fact_collector.collect()

    # Check the value of return_value
    assert(return_value == {})

# Generated at 2022-06-24 23:46:36.797957
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()


# Generated at 2022-06-24 23:48:08.326620
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    pass

# Generated at 2022-06-24 23:48:09.458970
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert (CmdLineFactCollector().name == 'cmdline')
    assert (CmdLineFactCollector()._fact_ids == set())



# Generated at 2022-06-24 23:48:13.344792
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    # Constructor element should analyze 'cmdline' feature
    assert cmd_line_fact_collector_0.name == 'cmdline'



# Generated at 2022-06-24 23:48:20.396499
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    cmd_line_fact_collector_1 = CmdLineFactCollector(name='cmdline')
    cmd_line_fact_collector_2 = CmdLineFactCollector(name='cmdline', fact_ids=[])
    assert cmd_line_fact_collector_1.name == 'cmdline'


# Generated at 2022-06-24 23:48:22.345872
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert cmd_line_fact_collector_0._fact_ids == set()


# Generated at 2022-06-24 23:48:24.690609
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    case_0 = test_case_0()

# Generated at 2022-06-24 23:48:26.840394
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Collected facts should not be empty
    assert not test_case_0()


# Generated at 2022-06-24 23:48:28.575908
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert isinstance(cmd_line_fact_collector_0.name, str)
    assert isinstance(cmd_line_fact_collector_0._fact_ids, set)


# Generated at 2022-06-24 23:48:29.870868
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    cmd_line_fact_collector_0.collect()

# Generated at 2022-06-24 23:48:35.935609
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Set up test environment
    cmd_line_fact_collector_0 = CmdLineFactCollector()

    # Test function collect of class CmdLineFactCollector
    var_0 = cmd_line_fact_collector_0.collect()

    # Test function _get_proc_cmdline of class CmdLineFactCollector
    var_1 = cmd_line_fact_collector_0._get_proc_cmdline()

    # Test function _parse_proc_cmdline of class CmdLineFactCollector
    var_2 = cmd_line_fact_collector_0._parse_proc_cmdline(var_1)

    # Test function _parse_proc_cmdline_facts of class CmdLineFactCollector