

# Generated at 2022-06-24 23:42:19.224795
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert isinstance(cmd_line_fact_collector_0.collect(), dict)


# Generated at 2022-06-24 23:42:20.933940
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert isinstance(cmd_line_fact_collector, BaseFactCollector)

# Generated at 2022-06-24 23:42:29.975241
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector = CmdLineFactCollector()

    cmd_line_fact_collector._get_proc_cmdline = lambda x: 'foo=bar baz=qux'

    expected_fact_data = {
            'cmdline': {
                'foo': 'bar',
                'baz': 'qux'
            },
            'proc_cmdline': {
                'foo': 'bar',
                'baz': 'qux'
            }
        }

    generated_fact_data = cmd_line_fact_collector.collect()

    assert generated_fact_data == expected_fact_data


# Generated at 2022-06-24 23:42:39.215396
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Test case 0
    cmd_line_fact_0 = CmdLineFactCollector()
    print(cmd_line_fact_0)
    # Test case 1
    cmd_line_fact_1 = CmdLineFactCollector()
    print(cmd_line_fact_1)
    # Test case 2
    cmd_line_fact_2 = CmdLineFactCollector()
    print(cmd_line_fact_2)
    # Test case 3
    cmd_line_fact_3 = CmdLineFactCollector()
    print(cmd_line_fact_3)
    # Test case 4
    cmd_line_fact_4 = CmdLineFactCollector()
    print(cmd_line_fact_4)



# Generated at 2022-06-24 23:42:41.952519
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert test_case_0() == None


# Generated at 2022-06-24 23:42:44.352432
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    
    # testing response of collect - success
    ret = cmd_line_fact_collector_0.collect()
    assert ret is not None
    

# Generated at 2022-06-24 23:42:44.994397
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    pass

# Generated at 2022-06-24 23:42:50.649846
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    result = CmdLineFactCollector().collect()
    assert isinstance(result, dict)
    assert result.get('cmdline')
    assert isinstance(result.get('cmdline'), dict)
    assert result.get('proc_cmdline')
    assert isinstance(result.get('proc_cmdline'), dict)

# Generated at 2022-06-24 23:42:55.335733
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector = CmdLineFactCollector()

    ansible_facts = {}

    cmd_line_fact_collector._get_proc_cmdline = lambda: 'root=UUID=6ed0e0b2-6b47-4b5e-b997-e9b2c82e7190 ro'

    cmd_line_fact_collector.collect()

    if not ansible_facts['cmdline']:
        raise RuntimeError("cmdline fact should be present")

    if not ansible_facts['proc_cmdline']:
        raise RuntimeError("proc_cmdline fact should be present")

# Generated at 2022-06-24 23:42:56.743490
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    cmd_line_fact_collector_0.collect()


# Generated at 2022-06-24 23:43:02.424031
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    assert True == True


# Generated at 2022-06-24 23:43:09.245524
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    print("")
    cmd_line_fact_collector = CmdLineFactCollector()
    result = cmd_line_fact_collector.collect()
    print("Result = "+str(result))
    assert "cmdline" in result
    assert "proc_cmdline" in result


# Generated at 2022-06-24 23:43:11.972952
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    if (var_0 == cmd_line_fact_collector_0):
        print("The initialization of CmdLineFactCollector is successful!")


# Generated at 2022-06-24 23:43:13.519155
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:43:15.083615
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    var_0 = CmdLineFactCollector()
    var_0.collect()


# Generated at 2022-06-24 23:43:17.173146
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    try:
        assert True
    except AssertionError:
        raise AssertionError(str(AssertionError) + ' (cmdline_facts.py)')

# Generated at 2022-06-24 23:43:20.544916
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert cmd_line_fact_collector_1.name == 'cmdline'


# Generated at 2022-06-24 23:43:22.105784
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0 != None

# Generated at 2022-06-24 23:43:23.902079
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:43:29.452424
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    class_inst = CmdLineFactCollector()
    result = class_inst.collect()
    print("Result for method 'collect' of CmdLineFactCollector:")
    print(result)
    assert result is not None
    assert result['cmdline'] is not None
    assert result['proc_cmdline'] is not None



# Generated at 2022-06-24 23:43:47.588336
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    input_data = {
        'cmdline': """root=UUID=3fefc978-f6eb-4b16-8b7a-63e2e99cfe66 ro quiet""",
    }
    expected = {
        'cmdline': {
            'root': 'UUID=3fefc978-f6eb-4b16-8b7a-63e2e99cfe66',
            'ro': True,
            'quiet': True
        },
        'proc_cmdline': {
            'root': 'UUID=3fefc978-f6eb-4b16-8b7a-63e2e99cfe66',
            'ro': 'True',
            'quiet': 'True'
        }
    }
#     print json.dumps(expected, indent=5

# Generated at 2022-06-24 23:43:50.700678
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0 is not None
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert cmd_line_fact_collector_0._fact_ids == set([])


# Generated at 2022-06-24 23:43:53.455110
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()


if __name__ == '__main__':
    test_case_0()
    test_CmdLineFactCollector_collect()

# Generated at 2022-06-24 23:43:58.442112
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    # Create an instance of class CmdLineFactCollector
    cmd_line_fact_collector_0 = CmdLineFactCollector()

    # Invoke method collect with appropriate arguments
    cmd_line_fact_collector_0.collect(module=None, collected_facts=None)

# Generated at 2022-06-24 23:44:00.630763
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:44:03.080496
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    var_1 = cmd_line_fact_collector_1.collect()


# Generated at 2022-06-24 23:44:06.588195
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_1 = cmd_line_fact_collector_0.collect()

# Generated at 2022-06-24 23:44:08.447022
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert isinstance(cmd_line_fact_collector_0, CmdLineFactCollector)


# Generated at 2022-06-24 23:44:14.586323
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Scenario when exception raises
    # Expected result: instance of class CmdLineFactCollector is created
    try:
        CmdLineFactCollector()
    except Exception:
        assert False
    else:
        assert True


# Generated at 2022-06-24 23:44:15.780410
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    assert var_0 is None

# Generated at 2022-06-24 23:44:37.950854
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:44:46.836675
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    mocker.patch("ansible.module_utils.facts.collector.BaseFactCollector._get_file_content", return_value="Foo")
    mocker.patch("ansible.module_utils.facts.collector.shlex.split", return_value=["Foo"])
    cmd_line_fact_collector_2 = CmdLineFactCollector()
    assert cmd_line_fact_collector_2.collect() == {'cmdline': {'Foo': True}, 'proc_cmdline': {'Foo': True}}
    mocker.patch("ansible.module_utils.facts.collector.shlex.split", return_value=["Foo=Bar"])

# Generated at 2022-06-24 23:44:54.248417
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Case 0:
    # output1 = CmdLineFactCollector()._parse_proc_cmdline('a=1 b c=d e=')
    # output2 = CmdLineFactCollector()._parse_proc_cmdline_facts('a=1 b c=d e=')
    # print('output1 : %s' % output1)
    # print('output2 : %s' % output2)
    # test_case_0()
    pass

# Generated at 2022-06-24 23:45:00.138111
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    print()
    print("# Unit test for constructor of class CmdLineFactCollector")
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    print('cmd_line_fact_collector_0: ' + str(cmd_line_fact_collector_0))
    var_0 = cmd_line_fact_collector_0.collect()
    print('collect: ' + str(var_0))


# Generated at 2022-06-24 23:45:09.647104
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    cmd_line_facts_0 = {}
    var_0 = get_file_content('/proc/cmdline')
    cmdline_dict_0 = {}
    try:
        for piece in shlex.split(var_0, posix=False):
            item = piece.split('=', 1)
            if len(item) == 1:
                cmdline_dict_0[item[0]] = True
            else:
                cmdline_dict_0[item[0]] = item[1]
    except ValueError:
        pass
    cmd_line_facts_0['cmdline'] = cmdline_dict_0
    cmdline_dict_1 = {}


# Generated at 2022-06-24 23:45:13.739336
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    module_0 = AnsibleModuleStub()
    collected_facts_0 = {}
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect(module_0, collected_facts_0)
    assert var_0 == {}



# Generated at 2022-06-24 23:45:22.493008
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    var_1 = cmd_line_fact_collector_1.collect()

# Generated at 2022-06-24 23:45:30.626134
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    cmd_line_fact_collector_2 = CmdLineFactCollector()
    cmd_line_fact_collector_3 = CmdLineFactCollector()
    cmd_line_fact_collector_4 = CmdLineFactCollector()
    cmd_line_fact_collector_5 = CmdLineFactCollector()

    with pytest.raises(TypeError, match="collect() missing 1 required positional argument: 'collected_facts'"):
        cmd_line_fact_collector_0.collect(collected_facts={'test': 'test'})


# Generated at 2022-06-24 23:45:37.253421
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()


# Generated at 2022-06-24 23:45:39.779902
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    assert var_0 == {'cmdline': {}, 'proc_cmdline': {}}

# Test the methods of the class CmdLineFactCollector

# Generated at 2022-06-24 23:46:42.642440
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Filesystem.
    mock_collector_0 = {
        '_get_proc_cmdline': '',
        '_parse_proc_cmdline': {
            'ro': True,
            'rhel_virtio_root': True
        },
        '_parse_proc_cmdline_facts': {
            'ro': True,
            'rhel_virtio_root': True
        }
    }
    mock_collector_1 = {
        '_get_proc_cmdline': '',
        '_parse_proc_cmdline': {
            'ro': True,
            'rhel_virtio_root': True
        },
        '_parse_proc_cmdline_facts': {
            'ro': True,
            'rhel_virtio_root': True
        }
    }
   

# Generated at 2022-06-24 23:46:47.260267
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0 is not None


# Generated at 2022-06-24 23:46:51.958850
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    cmd_line_fact_collector.collect()
    cmd_line_fact_collector.collect(module='module', collected_facts='collected_facts')

# Generated at 2022-06-24 23:46:58.656831
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    assert var_0['cmdline'] == {'root': '/dev/mapper/fedora-root', 'ro': True, 'quiet': True}
    assert var_0['proc_cmdline'] == {'root': '/dev/mapper/fedora-root', 'ro': True, 'quiet': True}
    assert cmd_line_fact_collector_0.name == 'cmdline'

test_case_0()
test_CmdLineFactCollector()

# Generated at 2022-06-24 23:47:01.308241
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert cmd_line_fact_collector_0._fact_ids == set()



# Generated at 2022-06-24 23:47:06.009218
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    try:
        test_case_0()
    except:
        import traceback
        error = traceback.format_exc()
        print(error)

# Generated at 2022-06-24 23:47:10.842390
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    global name, _fact_ids
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert cmd_line_fact_collector_0._fact_ids == set()

# Generated at 2022-06-24 23:47:11.666516
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    assert True


# Generated at 2022-06-24 23:47:18.702369
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0._parse_proc_cmdline_facts('')
    assert isinstance(var_0, dict)
    assert len(var_0) == 0
    var_1 = cmd_line_fact_collector_0._parse_proc_cmdline_facts('abc')
    assert isinstance(var_1, dict)
    assert len(var_1) == 1
    assert var_1['abc'] == True
    var_2 = cmd_line_fact_collector_0._parse_proc_cmdline_facts('abc def')
    assert isinstance(var_2, dict)
    assert len(var_2) == 2
    assert var_2['abc'] == True
    assert var

# Generated at 2022-06-24 23:47:22.563037
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert 'name' in dir(cmd_line_fact_collector_0)
    assert '_fact_ids' in dir(cmd_line_fact_collector_0)
    assert cmd_line_fact_collector_0._fact_ids == set()
    assert cmd_line_fact_collector_0.name == 'cmdline'


# Generated at 2022-06-24 23:49:25.111445
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    var_1 = cmd_line_fact_collector_1.collect()

# Generated at 2022-06-24 23:49:29.917826
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_1 = CmdLineFactCollector()


# Generated at 2022-06-24 23:49:35.898791
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    result = cmd_line_fact_collector_0.collect()
    assert type(result) == dict
    assert 'cmdline' in result
    assert type(result['cmdline']) == dict
    assert 'proc_cmdline' in result
    assert type(result['proc_cmdline']) == dict



# Generated at 2022-06-24 23:49:38.680906
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()


if __name__ == "__main__":
    test_case_0()
    test_CmdLineFactCollector_collect()

# Generated at 2022-06-24 23:49:44.664529
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert cmd_line_fact_collector_0._fact_ids == {'cmdline', 'proc_cmdline'}


# Generated at 2022-06-24 23:49:48.120233
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    assert cmd_line_fact_collector_1.name == 'cmdline'
    assert cmd_line_fact_collector_1._fact_ids == set()


# Generated at 2022-06-24 23:49:49.502288
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:49:51.521762
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():

    # Start of test cases.
    test_case_0()


# End of unit test cases.

if __name__ == '__main__':
    test_CmdLineFactCollector()

# Generated at 2022-06-24 23:49:55.982431
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector = CmdLineFactCollector()
    cmd_line_fact_collector.collect()


# Generated at 2022-06-24 23:49:59.428529
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'

