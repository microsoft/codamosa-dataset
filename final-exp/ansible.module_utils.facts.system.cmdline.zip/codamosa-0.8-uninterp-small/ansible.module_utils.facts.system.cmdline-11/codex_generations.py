

# Generated at 2022-06-24 23:42:20.287255
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert cmd_line_fact_collector_0._fact_ids == set()



# Generated at 2022-06-24 23:42:24.346793
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()

    assert cmd_line_fact_collector.__class__.__name__ == "CmdLineFactCollector"

# Generated at 2022-06-24 23:42:28.304620
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Run command dos2unix to convert file encoding.
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert repr(cmd_line_fact_collector_0) == "<CmdLineFactCollector 'cmdline'>"


# Generated at 2022-06-24 23:42:29.171053
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    cmd_line_fact_collector_0.collect()


# Generated at 2022-06-24 23:42:31.013177
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:42:31.979744
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    test_case_0()


# Generated at 2022-06-24 23:42:33.972841
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector = CmdLineFactCollector()
    cmd_line_fact_collector.collect()

# Generated at 2022-06-24 23:42:38.409587
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:42:40.100890
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()


# Generated at 2022-06-24 23:42:46.724277
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    data = 'BOOT_IMAGE=/boot/vmlinuz-3.13.0-74-generic root=UUID=8f9dbc9d-a3c3-4bfe-96e6-f096e1c6d8b6 ro quiet'
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    cmd_line_fact_collector_0._get_proc_cmdline = lambda: data

    cmd_line_facts = cmd_line_fact_collector_0.collect()


# Generated at 2022-06-24 23:43:00.487639
# Unit test for method collect of class CmdLineFactCollector

# Generated at 2022-06-24 23:43:04.249980
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # read file /proc/cmdline
    with open('tests/unit/module_utils/ansible_test/_data/cmdline_facts/proc_cmdline', 'r') as file:
        data = file.read()
        cmd_line_fact_collector = CmdLineFactCollector()
        cmd_line_fact_collector._get_proc_cmdline = lambda: data

    # assert not data
    assert cmd_line_fact_collector.collect() == {}

    # assert data

# Generated at 2022-06-24 23:43:06.709465
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()

    assert cmd_line_fact_collector.name == 'cmdline'
    assert cmd_line_fact_collector._fact_ids == set()


# Generated at 2022-06-24 23:43:09.641949
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    assert (CmdLineFactCollector().collect()['cmdline'] == {'ro': True, 'rdinit': '/sbin/init', 'quiet': True})

# Generated at 2022-06-24 23:43:13.848610
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():

    cmd_line_fact_collector_1 = CmdLineFactCollector()
    assert cmd_line_fact_collector_1.name == 'cmdline'
    assert cmd_line_fact_collector_1._fact_ids == set()
    assert cmd_line_fact_collector_1._priority == 60


# Generated at 2022-06-24 23:43:15.408567
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    test_case_0()


# Generated at 2022-06-24 23:43:24.239243
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    fact_collector = CmdLineFactCollector()

    # set up test values for method collect
    module = "module"
    collected_facts = "collected_facts"
    expected_result = "expected_result"

    # set up the mock object
    fact_collector.get_file_content = Mock(return_value="")
    fact_collector.parse_proc_cmdline = Mock(return_value="")
    fact_collector.parse_proc_cmdline_facts = Mock(return_value="")

    # perform the test
    actual_result = fact_collector.collect(module, collected_facts)

    # validate the results
    assert actual_result == expected_result


# Generated at 2022-06-24 23:43:28.472897
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector._fact_ids == set()
    assert cmd_line_fact_collector.name == 'cmdline'

# Generated at 2022-06-24 23:43:32.247683
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert cmd_line_fact_collector_0._fact_ids == set()


# Generated at 2022-06-24 23:43:35.490191
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0 is not None
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert cmd_line_fact_collector_0._fact_ids == set()


# Generated at 2022-06-24 23:43:53.623704
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c_f_c = CmdLineFactCollector()
    assert c_f_c.name == 'cmdline'
    assert c_f_c._fact_ids == set()


# Generated at 2022-06-24 23:43:54.266729
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:43:55.302449
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector = CmdLineFactCollector()
    cmd_line_fact_collector.collect()

# Generated at 2022-06-24 23:43:56.473184
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector().name == 'cmdline'


# Generated at 2022-06-24 23:43:59.757511
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector = CmdLineFactCollector()
    cmdline_facts = cmd_line_fact_collector.collect()
    print(cmdline_facts)


# Generated at 2022-06-24 23:44:08.400162
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.collect() == {'cmdline': {'root': '/dev/mapper/vg_sys1-lv_root',
                                                               'ro': True, 'boot': '/dev/sda2',
                                                               'rhgb': True, 'console': ['/dev/ttyS0', '115200n8']},
                                                   'proc_cmdline': {'root': '/dev/mapper/vg_sys1-lv_root',
                                                                    'ro': True, 'boot': '/dev/sda2',
                                                                    'rhgb': True, 'console': ['/dev/ttyS0', '115200n8']}}


# Generated at 2022-06-24 23:44:17.668907
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Return values
    cmd_line_fact_collector = CmdLineFactCollector()
    res = cmd_line_fact_collector.collect()
    assert res == {'cmdline': {'BOOT_IMAGE': '/vmlinuz-4.4.0-101-generic', 'btrfs': True, 'quiet': True},
                   'proc_cmdline': {'BOOT_IMAGE': '/vmlinuz-4.4.0-101-generic', 'btrfs': True, 'quiet': True}}
    cmd_line_fact_collector_get_proc_cmdline = cmd_line_fact_collector._get_proc_cmdline()

# Generated at 2022-06-24 23:44:20.589017
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    assert CmdLineFactCollector().collect() == {'cmdline': {}, 'proc_cmdline': {}}

# Generated at 2022-06-24 23:44:23.471340
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()

    assert cmd_line_fact_collector.name == 'cmdline'
    assert cmd_line_fact_collector._fact_ids == set()


# Generated at 2022-06-24 23:44:25.419130
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:45:06.180098
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():

    assert cmd_line_fact_collector_0 != None



# Generated at 2022-06-24 23:45:10.461265
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert cmd_line_fact_collector_0._fact_ids == set()


# Generated at 2022-06-24 23:45:20.528479
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector = CmdLineFactCollector()

    result = cmd_line_fact_collector.collect()

# Generated at 2022-06-24 23:45:23.159032
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert True == cmd_line_fact_collector_0.collect()

# Generated at 2022-06-24 23:45:24.537794
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()


# Generated at 2022-06-24 23:45:27.993945
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    result = cmd_line_fact_collector_0.collect()
    assert result["cmdline"]["S"] is True
    assert ''.join(result["proc_cmdline"]["S"]) == "1"

# Generated at 2022-06-24 23:45:31.577923
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    fact_collector_0 = CmdLineFactCollector()
    

# Generated at 2022-06-24 23:45:33.457281
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    retval_0 = CmdLineFactCollector.collect()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 23:45:33.930021
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    assert True is True

# Generated at 2022-06-24 23:45:39.525376
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector= CmdLineFactCollector()
    assert cmd_line_fact_collector
    assert cmd_line_fact_collector.name == 'cmdline'


# Generated at 2022-06-24 23:46:30.231633
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert isinstance(cmd_line_fact_collector_0, CmdLineFactCollector)


# Generated at 2022-06-24 23:46:34.397814
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    collected_facts_0 = None
    var_1 = cmd_line_fact_collector_1.collect(collected_facts_0)

# Generated at 2022-06-24 23:46:36.298807
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()


# Generated at 2022-06-24 23:46:40.551049
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()

# Generated at 2022-06-24 23:46:43.063724
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert cmd_line_fact_collector_0._fact_ids == set()


# Generated at 2022-06-24 23:46:46.102327
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    pass


# Generated at 2022-06-24 23:46:47.511452
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0 is not None


# Generated at 2022-06-24 23:46:48.204852
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:46:51.857628
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:46:54.099108
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    var = cmd_line_fact_collector.collect()
# test_CmdLineFactCollector()

# Generated at 2022-06-24 23:48:26.496434
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # case 0
    test_case_0()

# Generated at 2022-06-24 23:48:28.612975
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    var_1 = cmd_line_fact_collector_1.collect()

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 23:48:31.895150
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    print('from UnitTest.test_CmdLine import test_CmdLineFactCollector')
    cmd_line_fact_collector = CmdLineFactCollector()
    # test if the returned container is valid
    if not isinstance(cmd_line_fact_collector, CmdLineFactCollector):
        print('ERROR: CmdLineFactCollector class constructor failed')
    else:
        print('SUCCESS: CmdLineFactCollector class constructor succeeded')


# Generated at 2022-06-24 23:48:33.375842
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert isinstance(cmd_line_fact_collector_0, CmdLineFactCollector)


# Generated at 2022-06-24 23:48:34.421920
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()

    assert obj.name == 'cmdline'
    assert obj._fact_ids == set()


# Generated at 2022-06-24 23:48:35.996150
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    assert isinstance(var_0, dict)


# Generated at 2022-06-24 23:48:41.064493
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    assert var_0 == dict()


# Generated at 2022-06-24 23:48:42.779058
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    var_1 = cmd_line_fact_collector_1.collect()
    assert type(var_1) == dict


# Generated at 2022-06-24 23:48:46.915481
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    # Get an instance of CmdLineFactCollector
    cmd_line_fact_collector = CmdLineFactCollector()

    # Call the collect method of CmdLineFactCollector
    result = cmd_line_fact_collector.collect()

    # Check if the result is empty
    assert not result


if __name__ == '__main__':
    test_CmdLineFactCollector_collect()

# Generated at 2022-06-24 23:48:51.256485
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    var = "foo"
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    cmd_line_fact_collector_0.collect(module=var)
