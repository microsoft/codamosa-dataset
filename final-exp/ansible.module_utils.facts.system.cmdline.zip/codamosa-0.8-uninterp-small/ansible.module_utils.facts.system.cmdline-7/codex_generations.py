

# Generated at 2022-06-24 23:42:21.095573
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert cmd_line_fact_collector_0._fact_ids == set()


# Generated at 2022-06-24 23:42:24.650418
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()

    assert cmd_line_fact_collector.name == 'cmdline'


# Generated at 2022-06-24 23:42:33.064693
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()

    data = cmd_line_fact_collector_0._get_proc_cmdline()
    cmdline_facts = {}

    if not data:
        assert cmdline_facts == {}, "cmdline facts empty dict mismatch"

    cmdline_facts['cmdline'] = cmd_line_fact_collector_0._parse_proc_cmdline(data)
    cmdline_facts['proc_cmdline'] = cmd_line_fact_collector_0._parse_proc_cmdline_facts(data)
    assert cmdline_facts == cmd_line_fact_collector_0.collect()


# Generated at 2022-06-24 23:42:37.536054
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    res = cmd_line_fact_collector_1.collect()
    if res == None:
        pass
    else:
        assert res == None


# Generated at 2022-06-24 23:42:39.539909
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    cmd_line_fact_collector_1.collect()


# Generated at 2022-06-24 23:42:46.300318
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Function that mocks the return of function _parse_proc_cmdline()
    def mock_proc_cmdline(data):
        return {'ro': True, 'root': '/dev/mmcblk0p1', 'rw': True, 'init': '/sbin/init'}

    # Function that mocks the return of function _parse_proc_cmdline_facts()
    def mock_proc_cmdline_facts(data):
        return {'ro': True, 'root': '/dev/mmcblk0p1', 'rw': True, 'init': '/sbin/init'}

    # Function that mocks the return of function _get_proc_cmdline()
    def mock_get_proc_cmdline():
        return 'ro root=/dev/mmcblk0p1 rw init=/sbin/init'

   

# Generated at 2022-06-24 23:42:49.641745
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()

    retrieved_cmdline_facts = cmd_line_fact_collector_1.collect()
    assert retrieved_cmdline_facts
    assert isinstance(retrieved_cmdline_facts, dict) == True
    assert isinstance(retrieved_cmdline_facts['cmdline'], dict) == True
    assert isinstance(retrieved_cmdline_facts['proc_cmdline'], dict) == True

# Generated at 2022-06-24 23:42:51.268321
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Create an instance of a class
    cmd_line_fact_collector = CmdLineFactCollector()


# Generated at 2022-06-24 23:42:52.029196
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    test_case_0()

# Generated at 2022-06-24 23:42:52.667978
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:43:07.283683
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    p_0 = CmdLineFactCollector()
    p_1 = {}
    p_2 = CmdLineFactCollector()
    v_0 = p_2.collect(collected_facts=p_1)
    v_1 = False
    if (v_0 == v_1):
        print('Test 0 Failed')

    p_0 = CmdLineFactCollector()
    p_1 = {}
    p_2 = CmdLineFactCollector()
    v_0 = p_2.collect(collected_facts=p_1)
    v_1 = False
    if (v_0 == v_1):
        print('Test 1 Failed')

    p_0 = CmdLineFactCollector()
    p_1 = {'collected_facts': 'collected_facts'}
    p_2

# Generated at 2022-06-24 23:43:12.349113
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0._fact_ids == {'cmdline', 'proc_cmdline'}
    assert cmd_line_fact_collector_0.name == 'cmdline'


# Generated at 2022-06-24 23:43:12.895751
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()

# Generated at 2022-06-24 23:43:20.764201
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_1 = cmd_line_fact_collector_0.collect(module=None, collected_facts=None)


# Generated at 2022-06-24 23:43:22.300902
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    try:
        CmdLineFactCollector()
    except NameError as e:
        assert False


# Generated at 2022-06-24 23:43:26.358362
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector = CmdLineFactCollector()
    try:
        cmd_line_fact_collector.collect()
    except:
        pass


# Generated at 2022-06-24 23:43:29.009354
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    var_1 = cmd_line_fact_collector_1.collect()

    assert(var_1)


# Generated at 2022-06-24 23:43:32.763960
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert cmd_line_fact_collector_0._fact_ids == set()

# Generated at 2022-06-24 23:43:34.673028
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector.name == 'cmdline'



# Generated at 2022-06-24 23:43:39.093831
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    ansible_0 = CmdLineFactCollector()
    pass


if __name__ == '__main__':
    test_case_0()
    test_CmdLineFactCollector()

# Generated at 2022-06-24 23:43:51.129366
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert isinstance(cmd_line_fact_collector_0, CmdLineFactCollector)


# Generated at 2022-06-24 23:43:53.888479
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    cmd_line_fact_collector_1 = CmdLineFactCollector()

    assert(cmd_line_fact_collector_0.name == cmd_line_fact_collector_1.name)

# Generated at 2022-06-24 23:43:55.377006
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector.name == 'cmdline'


# Generated at 2022-06-24 23:44:04.801224
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_1 = False
    var_2 = """foo bar=yes variable=42"""
    cmd_line_fact_collector_0._get_proc_cmdline = lambda: var_2
    var_3 = cmd_line_fact_collector_0.collect()
    assert var_3['cmdline']['foo'] is True
    assert var_3['cmdline']['bar'] == 'yes'
    assert var_3['cmdline']['variable'] == '42'
    assert var_3['proc_cmdline']['foo'] == 'True'
    assert var_3['proc_cmdline']['bar'] == ['True', 'yes']

# Generated at 2022-06-24 23:44:06.159772
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_obj = CmdLineFactCollector()
    assert cmd_line_fact_collector_obj.name == 'cmdline'


# Generated at 2022-06-24 23:44:07.732707
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()

# Generated at 2022-06-24 23:44:08.783332
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    var_1 = CmdLineFactCollector()


# Generated at 2022-06-24 23:44:16.112836
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    #
    # Init test object.
    #
    cmd_line_fact_collector = CmdLineFactCollector()

    #
    # Run method 'collect' with all parameters.
    #
    var_1 = cmd_line_fact_collector.collect()

    #
    # Assertions
    #
    assert isinstance(var_1, dict)
    assert var_1 == {'cmdline': {}, 'proc_cmdline': {}}

# Generated at 2022-06-24 23:44:26.704661
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert isinstance(cmd_line_fact_collector_0, BaseFactCollector)
    assert isinstance(cmd_line_fact_collector_0, CmdLineFactCollector)
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert isinstance(cmd_line_fact_collector_0._fact_ids, set)
    assert not (cmd_line_fact_collector_0._fact_ids)
    #assert cmd_line_fact_collector_0._get_proc_cmdline()
    #assert cmd_line_fact_collector_0._parse_proc_cmdline('ro root=UUID=8eb50992-b81a-4dce-8a8d-a0c

# Generated at 2022-06-24 23:44:27.586655
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Test case 0
    test_case_0()

# Generated at 2022-06-24 23:44:52.568249
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()

# Generated at 2022-06-24 23:44:56.763336
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    test_case_0()

if __name__ == "__main__":
    test_CmdLineFactCollector()

# Generated at 2022-06-24 23:44:57.441603
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    test_case_0()



# Generated at 2022-06-24 23:45:01.617755
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()

    cmd_line_fact_collector = 0


# Generated at 2022-06-24 23:45:07.083081
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()


# Generated at 2022-06-24 23:45:10.299289
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0 is not None



# Generated at 2022-06-24 23:45:11.452183
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert callable(CmdLineFactCollector)


# Generated at 2022-06-24 23:45:13.699509
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()

# Generated at 2022-06-24 23:45:17.585750
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
  cmd_line_fact_collector = CmdLineFactCollector()
  assert isinstance(cmd_line_fact_collector, CmdLineFactCollector)
  assert hasattr(cmd_line_fact_collector, 'name') == True
  assert cmd_line_fact_collector.name == 'cmdline'


# Generated at 2022-06-24 23:45:20.034021
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector = CmdLineFactCollector()
    cmd_line_fact_collector.collect()

# Generated at 2022-06-24 23:46:16.085223
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert isinstance(cmd_line_fact_collector, CmdLineFactCollector)


# Generated at 2022-06-24 23:46:25.613739
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    cmd_line_fact_collector_0._get_proc_cmdline = MagicMock(return_value='')
    var_0 = cmd_line_fact_collector_0.collect()
    assert len(var_0) == 0
    del cmd_line_fact_collector_0._get_proc_cmdline

    cmd_line_fact_collector_1 = CmdLineFactCollector()
    cmd_line_fact_collector_1._get_proc_cmdline = MagicMock(return_value='param_0=val_0 param_1="val_1" param_2=val_2')
    var_0 = cmd_line_fact_collector_1.collect()

# Generated at 2022-06-24 23:46:30.723585
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    print("Testing method collect of class CmdLineFactCollector")

    #Test case 0
    try:
        test_case_0()
    except Exception as exp:
        assert False, "Test case 0 failed for method collect of class CmdLineFactCollector - Exception: {0}".format(exp)


# Generated at 2022-06-24 23:46:39.083362
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()
    assert CmdLineFactCollector.name.__doc__ == None
    assert CmdLineFactCollector._fact_ids.__doc__ == None
    assert CmdLineFactCollector._get_proc_cmdline.__doc__ == None
    assert CmdLineFactCollector._parse_proc_cmdline.__doc__ == None
    assert CmdLineFactCollector._parse_proc_cmdline_facts.__doc__ == None
    assert CmdLineFactCollector.collect.__doc__ == None


# Generated at 2022-06-24 23:46:41.042403
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()


# Generated at 2022-06-24 23:46:43.298139
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    data = b'the quick brown fox jumps over the lazy dog'
    cmd_line_fact_collector_0 = CmdLineFactCollector(data)
    var_1 = cmd_line_fact_collector_0.collect()


# Generated at 2022-06-24 23:46:47.325380
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    var_0 = CmdLineFactCollector()


if __name__ == '__main__':
    test_case_0()
    test_CmdLineFactCollector()

# Generated at 2022-06-24 23:46:51.281238
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'


# Generated at 2022-06-24 23:46:54.594959
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect(var_0=get_file_content('/proc/cmdline'))

# Generated at 2022-06-24 23:46:57.299777
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    assert not var_0


# Generated at 2022-06-24 23:48:44.820413
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()


# Generated at 2022-06-24 23:48:49.942662
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    var_1 = cmd_line_fact_collector_0.collect()
    var_2 = cmd_line_fact_collector_0.collect()
    assert not var_2.get('cmdline').get('debug')



# Generated at 2022-06-24 23:48:56.374181
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'
    try:
        assert hasattr(cmd_line_fact_collector_0, '_fact_ids')
    except AssertionError:
        print("Problem with asserting that cmd_line_fact_collector_0 has attribute '_fact_ids'")
    try:
        assert cmd_line_fact_collector_0._fact_ids == set()
    except AssertionError:
        print("Problem with asserting that cmd_line_fact_collector_0._fact_ids equals the value of set()")


# Generated at 2022-06-24 23:48:57.763846
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0


# Generated at 2022-06-24 23:48:59.466716
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    myCmdLineFactCollector = CmdLineFactCollector()


# Generated at 2022-06-24 23:49:01.814866
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert not cmd_line_fact_collector_0._fact_ids


# Generated at 2022-06-24 23:49:02.957304
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector().collect() == {'cmdline': {}, 'proc_cmdline': {}}

# Generated at 2022-06-24 23:49:06.720168
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # cmd_line_fact_collector_1 and cmd_line_fact_collector_2 are the instances of class CmdLineFactCollector
    # Generated by Ansible cmdline module
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    cmd_line_fact_collector_2 = CmdLineFactCollector()
    # No assert statements.


# Generated at 2022-06-24 23:49:14.503674
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_1 = cmd_line_fact_collector_0.collect()
    assert var_1 == {'cmdline': {'BOOT_IMAGE': '/boot/vmlinuz-4.9.0-2-amd64', 'quiet': '', 'ro': '', 'root': '/dev/sda1', 'splash': True}, 'proc_cmdline': {'BOOT_IMAGE': '/boot/vmlinuz-4.9.0-2-amd64', 'ro': '', 'root': '/dev/sda1', 'splash': True}}
    assert cmd_line_fact_collector_0._fact_ids == set()


# Generated at 2022-06-24 23:49:20.186646
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # The return value of method should be a dictionary.
    cmd_line_fact_collector = CmdLineFactCollector()
    var = cmd_line_fact_collector.collect()
    assert isinstance(var, dict)
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    # This test case is not supposed to have a static return value
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    var_1 = cmd_line_fact_collector_1.collect()
    # This test case is not supposed to have a static return value
    cmd_line_fact_collector_2 = CmdLineFactCollector()
    var_2 = cmd_line_fact_collector_2