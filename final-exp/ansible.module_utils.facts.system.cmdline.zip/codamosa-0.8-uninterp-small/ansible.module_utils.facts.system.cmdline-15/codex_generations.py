

# Generated at 2022-06-24 23:42:18.785822
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    cmd_line_fact_collector_1.collect()

# Generated at 2022-06-24 23:42:19.912989
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector()

# Generated at 2022-06-24 23:42:25.406078
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    cmd_line_fact_collector_0.collect()

if __name__ == '__main__':
    test_case_0()
    test_CmdLineFactCollector_collect()

# Generated at 2022-06-24 23:42:29.795830
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector.name == 'cmdline'
    assert cmd_line_fact_collector._fact_ids == set()
    assert cmd_line_fact_collector.name not in cmd_line_fact_collector._fact_ids


# Generated at 2022-06-24 23:42:31.663795
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    


# Generated at 2022-06-24 23:42:36.362541
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    cmd_line_fact_collector_1.collect()
    assert cmd_line_fact_collector_1.collect()


# Generated at 2022-06-24 23:42:38.776908
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    cmd_line_fact_collector_result = cmd_line_fact_collector.collect()
    assert isinstance(cmd_line_fact_collector_result, dict)

# Generated at 2022-06-24 23:42:41.814446
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    assert cmd_line_fact_collector_1
    assert cmd_line_fact_collector_1._fact_ids == set()
    assert cmd_line_fact_collector_1.name == 'cmdline'



# Generated at 2022-06-24 23:42:42.799491
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert cmd_line_fact_collector_0 is not None


# Generated at 2022-06-24 23:42:43.865618
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector.name == 'cmdline'


# Generated at 2022-06-24 23:42:48.937194
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    pass


# Generated at 2022-06-24 23:42:50.122161
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:42:51.858796
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()


# Generated at 2022-06-24 23:42:53.344979
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert cmd_line_fact_collector_0._fact_ids == set()


# Generated at 2022-06-24 23:42:53.964644
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector() is not None

# Generated at 2022-06-24 23:42:54.761035
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()


# Generated at 2022-06-24 23:42:56.841077
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    cmd_line_fact_collector_0.collect()


# Generated at 2022-06-24 23:43:01.342509
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0


# Generated at 2022-06-24 23:43:04.095161
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector.name == 'cmdline'
    assert cmd_line_fact_collector._fact_ids == set()


# Generated at 2022-06-24 23:43:08.132954
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    #  Make sure the CmdLineFactCollector class can collect the /proc/cmdline data
    assert True


# Generated at 2022-06-24 23:43:15.886491
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert cmd_line_fact_collector_0.priority == 30


# Generated at 2022-06-24 23:43:17.938490
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Setup
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    # Procedure
    var_0 = cmd_line_fact_collector_0.collect()

# Generated at 2022-06-24 23:43:20.669728
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == "cmdline"
    assert cmd_line_fact_collector_0._fact_ids == set()


# Generated at 2022-06-24 23:43:22.471458
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert isinstance(cmd_line_fact_collector_0, CmdLineFactCollector)

# Generated at 2022-06-24 23:43:33.417520
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    assert isinstance(var_0, dict)
    assert 'proc_cmdline' in var_0
    assert isinstance(var_0['proc_cmdline'], dict)
    assert var_0['proc_cmdline']['BOOT_IMAGE'] == ' /vmlinuz-3.10.0-327.el7.x86_64'
    assert isinstance(var_0, dict)
    assert 'cmdline' in var_0
    assert isinstance(var_0['cmdline'], dict)

# Generated at 2022-06-24 23:43:34.739131
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_1 = CmdLineFactCollector()


# Generated at 2022-06-24 23:43:38.316914
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()



# Generated at 2022-06-24 23:43:39.740864
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()


# Generated at 2022-06-24 23:43:41.371908
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:43:46.243097
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()

    collected_facts_0 = {}
    # Put additional test code here. It will be executed only if the test case is enabled.
    var_0 = cmd_line_fact_collector_0.collect(collected_facts_0)

    # Test cases
    assert (var_0 == {})


# Generated at 2022-06-24 23:44:04.157571
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert isinstance(cmd_line_fact_collector._get_proc_cmdline(), str)
    assert isinstance(cmd_line_fact_collector._parse_proc_cmdline(cmd_line_fact_collector._get_proc_cmdline()), dict)
    assert isinstance(cmd_line_fact_collector._parse_proc_cmdline_facts(cmd_line_fact_collector._get_proc_cmdline()), dict)
    assert isinstance(cmd_line_fact_collector.collect(), dict)



# Generated at 2022-06-24 23:44:06.641477
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert isinstance(cmd_line_fact_collector_0, CmdLineFactCollector)
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert cmd_line_fact_collector_0._fact_ids == set()


# Generated at 2022-06-24 23:44:09.768719
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    assert var_0 == {'cmdline': {'foo': 'bar', 'baz': True},
                     'proc_cmdline': {'foo': 'bar', 'baz': True}}



# Generated at 2022-06-24 23:44:11.496656
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert getattr(CmdLineFactCollector, '_fact_ids', None) is not None
    assert getattr(CmdLineFactCollector, 'name', None) is not None


# Generated at 2022-06-24 23:44:14.912096
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    print("test_CmdLineFactCollector_collect")
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    result = cmd_line_fact_collector_0.collect()
    print("result of CmdLineFactCollector.collect: {0}".format(result))
    assert result is not None

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 23:44:17.797258
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.name
    assert var_0 == 'cmdline'
    var_1 = cmd_line_fact_collector_0._fact_ids
    assert var_1 == set()


# Generated at 2022-06-24 23:44:20.968722
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()

# Generated at 2022-06-24 23:44:22.194341
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    var_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:44:25.952591
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert callable(getattr(cmd_line_fact_collector, 'collect', None))

if __name__ == '__main__':

    test_case_0()
    test_CmdLineFactCollector_collect()

# Generated at 2022-06-24 23:44:28.518780
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:44:53.949169
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    if isinstance(cmd_line_fact_collector_0.collect(), dict):
        print("\nTest PASSED.")
    else:
        print("\nTest FAILED.")


# Generated at 2022-06-24 23:44:57.029586
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()

# Generated at 2022-06-24 23:45:01.173768
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0


# Generated at 2022-06-24 23:45:02.858051
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # cmd_line_fact_collector_0 = CmdLineFactCollector()
    pass


# Generated at 2022-06-24 23:45:11.079734
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    #
    # Test if constructor works
    #

    # Test with class CmdLineFactCollector
    try:
        cmd_line_fact_collector_0 = CmdLineFactCollector()
    except Exception as e:
        raise Exception(e)

    # Test with class BaseFactCollector
    try:
        base_fact_collector_0 = BaseFactCollector()
    except Exception as e:
        raise Exception(e)

# Generated at 2022-06-24 23:45:13.983165
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert isinstance(cmd_line_fact_collector_0, CmdLineFactCollector)


# Generated at 2022-06-24 23:45:22.652450
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    var_1 = cmd_line_fact_collector_0.collect()
    var_2 = cmd_line_fact_collector_0.collect()
    var_3 = cmd_line_fact_collector_0.collect()
    var_4 = cmd_line_fact_collector_0.collect()
    var_5 = cmd_line_fact_collector_0.collect()
    var_6 = cmd_line_fact_collector_0.collect()
    var_7 = cmd_line_fact_collector_0.collect()
    var_8 = cmd_line_fact_collector_0.collect()
    var_9 = cmd_line

# Generated at 2022-06-24 23:45:23.428810
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # TODO: implement test
    assert True

# Generated at 2022-06-24 23:45:26.186633
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    print('Test constructor of CmdLineFactCollector')
    cmd_line_fact_collector = CmdLineFactCollector()


# Generated at 2022-06-24 23:45:30.324909
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    var = cmd_line_fact_collector.collect()
    assert var['cmdline']['build_id'] == '10e9ee9c7d93d65bacc2f0e8e0894b28e23f644a'
    assert var['cmdline']['root'] == '/dev/mapper/centos-root'
    assert var['proc_cmdline'] == var['cmdline']

# Generated at 2022-06-24 23:46:30.704570
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.name
    assert var_0 == 'cmdline'

    var_1 = cmd_line_fact_collector_0.fact_ids
    assert var_1 == set()


# Generated at 2022-06-24 23:46:40.627778
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    print('Testing method collect of class CmdLineFactCollector')

    # Create an instance of CmdLineFactCollector called cmd_line_fact_collector_0
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    # Call method collect of cmd_line_fact_collector_0
    var_0 = cmd_line_fact_collector_0.collect()
    # Assert for cmd_line_fact_collector_0.collect() == {}
    assert var_0 == {}
    
    # Create an instance of CmdLineFactCollector called cmd_line_fact_collector_1
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    # Call method collect of cmd_line_fact_collector_1
    var_1 = cmd_line_fact_

# Generated at 2022-06-24 23:46:46.664687
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import copy
    cmd_line_fact_collector_0 = CmdLineFactCollector()

    var_0 = copy.deepcopy(cmd_line_fact_collector_0)
    var_1 = cmd_line_fact_collector_0.collect()
    var_1 = None

    var_0.collect()

    var_2 = copy.deepcopy(cmd_line_fact_collector_0)

# Generated at 2022-06-24 23:46:51.522982
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0._fact_ids == set()
    assert cmd_line_fact_collector_0.name == 'cmdline'


# Generated at 2022-06-24 23:46:53.274015
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:46:55.402816
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert isinstance(cmd_line_fact_collector, CmdLineFactCollector)

# Generated at 2022-06-24 23:46:57.813714
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    var_1 = cmd_line_fact_collector_1.collect()


# Generated at 2022-06-24 23:47:03.850711
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()

    # Test if cmd_line_fact_collector is an instance of BaseFactCollector
    assert isinstance(cmd_line_fact_collector, BaseFactCollector)

    # Test if the class attribute 'name' is correctly set to 'cmdline'
    assert cmd_line_fact_collector.name == 'cmdline'

    # Test if the class attribute '_fact_ids' is correctly set to set()
    assert cmd_line_fact_collector._fact_ids == set()

    # Verify that the type of 'cmd_line_fact_collector._fact_ids' is set
    assert isinstance(cmd_line_fact_collector._fact_ids, set)


# Generated at 2022-06-24 23:47:09.630700
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == "cmdline"
    assert cmd_line_fact_collector_0._fact_ids == set()
    assert cmd_line_fact_collector_0._fact_ids == set()
    assert cmd_line_fact_collector_0.name == "cmdline"


# Generated at 2022-06-24 23:47:10.290210
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    var_0 = CmdLineFactCollector()

# Generated at 2022-06-24 23:49:04.013242
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Constructor test case of CmdLineFactCollector
    try:
        cmd_line_fact_collector_0 = CmdLineFactCollector()
        test_case_0()
    except Exception as inst:
        print(inst)
        return False
    return True


# Generated at 2022-06-24 23:49:05.294006
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    test_case_0()

test_CmdLineFactCollector()

# Generated at 2022-06-24 23:49:07.684671
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    try:
        cmd_line_fact_collector_0 = CmdLineFactCollector()
        var_0 = cmd_line_fact_collector_0.collect()
        assert var_0 == {}
    except AttributeError:
        pass


# Generated at 2022-06-24 23:49:10.252176
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0 != None


# Generated at 2022-06-24 23:49:11.499581
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert isinstance(CmdLineFactCollector(), CmdLineFactCollector)


# Generated at 2022-06-24 23:49:14.560248
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.name
    assert var_0 == 'cmdline'
    var_1 = set(cmd_line_fact_collector_0._fact_ids)
    assert var_1 == set()

# Generated at 2022-06-24 23:49:15.530410
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:49:17.613615
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()

# Generated at 2022-06-24 23:49:24.631243
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert cmd_line_fact_collector_0._fact_ids == set()
    assert isinstance(cmd_line_fact_collector_0._fact_ids, set)


# Generated at 2022-06-24 23:49:26.260361
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
