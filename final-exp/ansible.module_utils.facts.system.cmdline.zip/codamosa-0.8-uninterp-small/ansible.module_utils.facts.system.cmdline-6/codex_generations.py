

# Generated at 2022-06-24 23:42:20.423431
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    assert cmd_line_fact_collector_1.name == 'cmdline'
    assert cmd_line_fact_collector_1._fact_ids == set()


# Generated at 2022-06-24 23:42:22.417675
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    pass

# Generated at 2022-06-24 23:42:24.253983
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    test_case_0()

if __name__ == '__main__':
    test_CmdLineFactCollector()

# Generated at 2022-06-24 23:42:27.880760
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    cmdline_facts = cmd_line_fact_collector_0.collect()
    assert len(cmdline_facts.keys()) > 0


# Generated at 2022-06-24 23:42:37.828531
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    result = cmd_line_fact_collector_1.collect()
    assert result['proc_cmdline']['BOOT_IMAGE'] == '/boot/vmlinuz-3.10.0-514.21.1.el7.x86_64'
    assert result['proc_cmdline']['console'] == 'ttyS0,38400n8'
    assert result['cmdline']['BOOT_IMAGE'] == '/boot/vmlinuz-3.10.0-514.21.1.el7.x86_64'
    assert result['cmdline']['console'] == 'ttyS0,38400n8'

# Generated at 2022-06-24 23:42:44.902214
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    class MockModule(object):
        def fail_json(self, *args, **kwargs):
            self.fail_json_args = args
            self.fail_json_kwargs = kwargs

    m = MockModule()

    cmd_line_fact_collector = CmdLineFactCollector()

    cmd_line_fact_collector._get_proc_cmdline = lambda: None
    assert cmd_line_fact_collector.collect(m) == {}

    cmd_line_fact_collector._get_proc_cmdline = lambda: 'root=/dev/mapper/vg_lovelace-lv_root ro'

# Generated at 2022-06-24 23:42:46.327806
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()


# Generated at 2022-06-24 23:42:55.927926
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    res = cmd_line_fact_collector_1.collect()
    #assert res['cmdline']['rd.lvm.lv'] set to False
    #assert res['cmdline']['ro'] set to True
    #assert res['cmdline']['rhgb'] set to True
    #assert res['cmdline']['quiet'] set to True
    #assert res['cmdline']['console'] set to 'ttyS0,115200'
    #assert res['cmdline']['console'] set to 'ttyS0,115200'
    #assert res['cmdline']['console'] set to 'ttyS0,115200'
    #assert res['cmdline']['net.ifnames'] set to True
    #assert res

# Generated at 2022-06-24 23:42:57.299608
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.collect() == {'cmdline': {}, 'proc_cmdline': {}}

# Generated at 2022-06-24 23:43:07.318609
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()

    data = cmd_line_fact_collector_0._get_proc_cmdline()
    cmdline_dict = cmd_line_fact_collector_0._parse_proc_cmdline(data)
    assert "quiet" in cmdline_dict
    assert cmdline_dict["quiet"] == True
    assert "rd.lvm.lv=centos/root" in cmdline_dict
    assert cmdline_dict["rd.lvm.lv=centos/root"] == True
    assert "crashkernel=auto" in cmdline_dict
    assert cmdline_dict["crashkernel=auto"] == True
    assert "rd.lvm.lv=centos/swap" in cmdline_dict

# Generated at 2022-06-24 23:43:13.202276
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:43:14.756277
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_1 = CmdLineFactCollector()


# Generated at 2022-06-24 23:43:20.386202
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Check if _get_proc_cmdline method returns the value None when the file /proc/cmdline does not exists
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    cmd_line_fact_collector_0.file_exists = lambda file: False
    assert cmd_line_fact_collector_0._get_proc_cmdline() == None
    # Check if the method collect returns the value None when the file /proc/cmdline does not exists
    assert cmd_line_fact_collector_0.collect() == None



# Generated at 2022-06-24 23:43:21.064184
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    assert True


# Generated at 2022-06-24 23:43:24.597117
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()

    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert isinstance(cmd_line_fact_collector_0._fact_ids, set) == True


# Generated at 2022-06-24 23:43:29.412118
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    assert var_0 == {'cmdline': {'ro': True}, 'proc_cmdline': {'ro': True}}

# Generated at 2022-06-24 23:43:30.863442
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:43:34.072995
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert cmd_line_fact_collector_0._fact_ids == set()


# Generated at 2022-06-24 23:43:42.551523
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    _method_space = 'CmdLineFactCollector.collect'
    _call_name = 'collect'
    _call_args = []
    _call_kwargs = {}
    callback = lambda method, args, kwargs: method(*args, **kwargs)

    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    assert var_0 == dict(cmdline=dict(), proc_cmdline=dict())


# Generated at 2022-06-24 23:43:47.184926
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert cmd_line_fact_collector_0._fact_ids == set()


# Generated at 2022-06-24 23:44:03.293764
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()

    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()



# Generated at 2022-06-24 23:44:04.858476
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj._fact_ids == set()


# Generated at 2022-06-24 23:44:06.911880
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert isinstance(cmd_line_fact_collector_0._fact_ids, set)


# Generated at 2022-06-24 23:44:12.325394
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    assert var_0['cmdline'] == {"intel_iommu": True,
                                "biosdevname": "0",
                                "rootdelay": "10",
                                "noalpic": True,
                                "rhgb": True,
                                "nomodeset": True,
                                "root": "/dev/mapper/fedora-root",
                                "ro": True,
                                "quiet": True,
                                "console": "tty0",
                                "console": "ttyS0,115200n8"}

# Generated at 2022-06-24 23:44:14.289625
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector


# Generated at 2022-06-24 23:44:16.033730
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()


# Generated at 2022-06-24 23:44:17.224670
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    print("Running test for method collect of class CmdLineFactCollector")
    test_case_0()

# Generated at 2022-06-24 23:44:19.257833
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    pass

# Generated at 2022-06-24 23:44:23.113414
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    assert isinstance(var_0, dict)

# Testing of private method _get_proc_cmdline of class CmdLineFactCollector

# Generated at 2022-06-24 23:44:26.425103
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert isinstance(cmd_line_fact_collector, BaseFactCollector)
    assert isinstance(cmd_line_fact_collector, CmdLineFactCollector)


# Generated at 2022-06-24 23:44:51.983025
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()

# Generated at 2022-06-24 23:44:56.685313
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0 is not None


# Generated at 2022-06-24 23:45:00.602818
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()

# Generated at 2022-06-24 23:45:02.951031
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()

    # call the method
    var_1 = cmd_line_fact_collector_1.collect()

# Generated at 2022-06-24 23:45:04.128122
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    ret_val = None
    assert (ret_val == test_case_0())

# Generated at 2022-06-24 23:45:13.704278
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    import os
    import tempfile
    import unittest

    from ansible.module_utils.facts.system.cmdline import CmdLineFactCollector

    class TestCmdLineFactCollector(unittest.TestCase):
        def setUp(self):
            self.content = 'root=/dev/disk/by-uuid/0c3a7d55-4bbc-4bc8-9b0f-e4460d8e691e'
            self.tempfile = tempfile.mktemp()
            with open(self.tempfile, 'w') as f:
                f.write(self.content)
            self.cmdline = CmdLineFactCollector()

        def tearDown(self):
            os.remove(self.tempfile)


# Generated at 2022-06-24 23:45:18.990175
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()

    var_0 = cmd_line_fact_collector_0.collect()

    assert not var_0

    # Test with a test file

if __name__ == "__main__":
    import ansible_unittest
    ansible_unittest.main()
    #test_case_0()
    #test_CmdLineFactCollector_collect()

# Generated at 2022-06-24 23:45:25.125716
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()
    # This is how we start
    assert CmdLineFactCollector.is_required == False

# Unit tests for collect method of class CmdLineFactCollector

# Generated at 2022-06-24 23:45:29.566920
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    module = AnsibleModule(argument_spec={})
    cmd_line_fact_collector = CmdLineFactCollector()
    var = cmd_line_fact_collector.get_fact_names()
    for x in var:
        assert x == 'cmdline'
    assert cmd_line_fact_collector.get_fact_names() == [
        'cmdline',
        'proc_cmdline',
    ]


# Generated at 2022-06-24 23:45:31.473872
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector._fact_ids == set()

test_case_0()
test_CmdLineFactCollector()

# Generated at 2022-06-24 23:46:21.798151
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    var = CmdLineFactCollector()
    var.collect()



# Generated at 2022-06-24 23:46:24.948549
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    dict_0 = cmd_line_fact_collector_0.collect()
    assert dict_0 == {}

# Generated at 2022-06-24 23:46:29.434394
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_1 = CmdLineFactCollector()


# Generated at 2022-06-24 23:46:33.715700
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    try:
        CmdLineFactCollector()
    except Exception as exception_0:
        print(exception_0)
try:
    test_case_0()
except Exception as exception_0:
    print(exception_0)
    raise exception_0

# Generated at 2022-06-24 23:46:36.266919
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector = CmdLineFactCollector()
    var = cmd_line_fact_collector.collect()
    assert type(var) is dict

# vim: set ts=4 sw=4 et:

# Generated at 2022-06-24 23:46:40.736927
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'


# Generated at 2022-06-24 23:46:46.777509
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    var_1 = cmd_line_fact_collector_1.collect()
    assert var_1['cmdline'] == {'ro': True, 'root': '/dev/sda1', 'rhgb': True, 'quiet': True, 'LANG': 'en_US.UTF-8', 'rootflags': 'subvol=__active/root'}
    assert var_1['proc_cmdline'] == {'ro': True, 'root': '/dev/sda1', 'rhgb': True, 'quiet': True, 'LANG': ['en_US.UTF-8', 'en_US.UTF-8'], 'rootflags': ['subvol=__active/root', 'subvol=__active/root']}


# Generated at 2022-06-24 23:46:48.511743
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    print(var_0)

# Generated at 2022-06-24 23:46:52.741315
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_2 = CmdLineFactCollector()
    cmd_line_fact_collector_2.collect()


# Generated at 2022-06-24 23:46:57.026031
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.collect() is not None
    assert cmd_line_fact_collector_0.collect()['cmdline'] is not None
    assert cmd_line_fact_collector_0.collect()['proc_cmdline'] is not None

# Generated at 2022-06-24 23:48:41.090919
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    assert(not var_0)


# Generated at 2022-06-24 23:48:42.476358
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector is not None


# Generated at 2022-06-24 23:48:45.283283
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:48:47.544660
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0._fact_ids == set()
    assert cmd_line_fact_collector_0.name == 'cmdline'


# Generated at 2022-06-24 23:48:50.407449
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # TODO: auto detect the facts to compare for Python 2 and 3
    assert var_0 == expected_var_0

# Generated at 2022-06-24 23:48:57.424786
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()

# Generated at 2022-06-24 23:48:59.119125
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()


# Generated at 2022-06-24 23:49:03.507678
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()

# Generated at 2022-06-24 23:49:05.151602
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_1 = CmdLineFactCollector()


# Generated at 2022-06-24 23:49:08.452617
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert isinstance(CmdLineFactCollector(), CmdLineFactCollector)