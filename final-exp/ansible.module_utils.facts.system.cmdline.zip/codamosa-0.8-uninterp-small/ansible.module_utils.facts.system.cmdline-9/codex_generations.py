

# Generated at 2022-06-24 23:42:20.893128
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
        obj = CmdLineFactCollector()
        if isinstance(obj, BaseFactCollector):
            print('Test case 0 passed')
        else:
            print('Test case 0 failed')


# Generated at 2022-06-24 23:42:28.216992
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    cmd_line_fact_dict_1 = cmd_line_fact_collector_1.collect()
    # check if it is a dict
    assert isinstance(cmd_line_fact_dict_1, dict)
    # check for the keys
    assert 'cmdline' in cmd_line_fact_dict_1
    assert 'proc_cmdline' in cmd_line_fact_dict_1

# Generated at 2022-06-24 23:42:38.614019
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    data = ' '
    ret = cmd_line_fact_collector_0._parse_proc_cmdline(data)
    assert ret == {}, 'Failed to assert that {} == {}.'.format(
        ret, {})

    ret = cmd_line_fact_collector_0._parse_proc_cmdline_facts(data)
    assert ret == {}, 'Failed to assert that {} == {}.'.format(
        ret, {})

    data = 'foo'
    ret = cmd_line_fact_collector_0._parse_proc_cmdline(data)
    assert ret == {'foo': True}, 'Failed to assert that {} == {}.'.format(
        ret, {'foo': True})

    ret = cmd_line

# Generated at 2022-06-24 23:42:43.803132
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert hasattr(CmdLineFactCollector, '_fact_ids')
    assert hasattr(CmdLineFactCollector, 'name')
    assert hasattr(CmdLineFactCollector, '_get_proc_cmdline')
    assert hasattr(CmdLineFactCollector, '_parse_proc_cmdline')
    assert hasattr(CmdLineFactCollector, '_parse_proc_cmdline_facts')
    assert hasattr(CmdLineFactCollector, 'collect')
    assert hasattr(CmdLineFactCollector, '__init__')

    test_case_0()

# Generated at 2022-06-24 23:42:49.228431
# Unit test for method collect of class CmdLineFactCollector

# Generated at 2022-06-24 23:42:51.924052
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    collected_facts = {}
    returned_facts = cmd_line_fact_collector_0.collect(collected_facts=collected_facts)
    assert 'cmdline' in returned_facts
    assert 'proc_cmdline' in returned_facts

# Generated at 2022-06-24 23:42:54.099437
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    cmdline = cmd_line_fact_collector_0.collect()
    assert cmdline['cmdline'] is not None
    assert cmdline['proc_cmdline'] is not None

# Generated at 2022-06-24 23:43:00.046557
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector = CmdLineFactCollector()
    collected_facts = cmd_line_fact_collector.collect()
    assert collected_facts['cmdline'] == {'BOOT_IMAGE': '/boot/vmlinuz-3.10.0-327.el7.x86_64', 'ro': True, 'crashkernel': 'auto', 'console': 'tty0', 'console': 'ttyS0', 'root': '/dev/mapper/rhel-root', 'rd.lvm.lv': 'rhel/root', 'LANG': 'en_US.UTF-8', 'rd.lvm.lv': 'rhel/swap', 'rhgb': True, 'quiet': True}
    return


# Generated at 2022-06-24 23:43:03.113181
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector.name == 'cmdline'
    assert cmd_line_fact_collector._fact_ids == {'cmdline', 'proc_cmdline'}


# Generated at 2022-06-24 23:43:08.803325
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector.name == 'cmdline'
    assert cmd_line_fact_collector._fact_ids == set()


# Generated at 2022-06-24 23:43:18.195388
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()

    cmd_line_fact_collector_0.collect()

# Generated at 2022-06-24 23:43:20.385971
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.collect() == {'cmdline': {}, 'proc_cmdline': {}}

# Generated at 2022-06-24 23:43:21.273692
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    pass

# Generated at 2022-06-24 23:43:32.740680
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    test_case = [
        {
            'name': 'test_case_0',
            'obj': [],
            'expected_result': None,
            'error': None,
            'test_function': test_case_0,
        }
    ]
    for case in test_case:
        try:
            print('\nRunning Test: {}'.format(case['name']))
            result = case['test_function'](*case['obj'])
            error = None
        except AssertionError as e:
            result = None
            error = str(e)
        print(' Expected Result: {}'.format(case['expected_result']))
        print('   Actual Result: {}'.format(result))
        assert result == case['expected_result'] and error == case['error']

# Generated at 2022-06-24 23:43:43.568015
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()

    data = cmd_line_fact_collector_0._get_proc_cmdline()

    cmdline_facts = cmd_line_fact_collector_0._parse_proc_cmdline(data)
    assert 'rd.lvm.lv' in cmdline_facts.keys() and 'vg_centos00-lv_root' == cmdline_facts['rd.lvm.lv']

    proc_cmdline_facts = cmd_line_fact_collector_0._parse_proc_cmdline_facts(data)
    assert 'ro' in proc_cmdline_facts.keys() and proc_cmdline_facts['ro'] == True

    proc_cmdline_facts_1 = cmd_line_fact_collector_0.collect()

# Generated at 2022-06-24 23:43:45.112827
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'


# Generated at 2022-06-24 23:43:48.678551
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = {}

    cmd_line_fact_collector_0 = CmdLineFactCollector()
    cmdline_facts = cmd_line_fact_collector_0.collect()

    print(cmdline_facts)

# Generated at 2022-06-24 23:43:54.744998
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()

# Generated at 2022-06-24 23:43:56.092818
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector.name == 'cmdline'


# Generated at 2022-06-24 23:44:02.061459
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert(cmd_line_fact_collector is not None)
    # test attribute name
    assert(cmd_line_fact_collector.name == 'cmdline')
    # test attribute _fact_ids
    assert(isinstance(cmd_line_fact_collector._fact_ids, set))
    assert(len(cmd_line_fact_collector._fact_ids) == 0)


# Generated at 2022-06-24 23:44:13.458616
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:44:19.244876
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    command_line_facts = CmdLineFactCollector()

    # Test with /proc/cmdline file containing command line parameters with =, without =, and = without value
    command_line = "ansible_facts=test_facts_1 root=/dev/mapper/root ro"

# Generated at 2022-06-24 23:44:21.106565
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    try:
        test_case_0()
    except Exception as e:
        assert False, str(e)

# Generated at 2022-06-24 23:44:25.345587
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    fact_ids = set()
    cmd_line_fact_collector_0 = CmdLineFactCollector(fact_ids)
    # TODO: Don't understand why the test script tests against a
    # return value of None.
    # I suspect that this is bug in the test script
    assert cmd_line_fact_collector_0.collect() is None

# Generated at 2022-06-24 23:44:28.096319
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    pass


# Generated at 2022-06-24 23:44:33.941303
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    # Case 1: {'rhgb': '', 'selinux': '1'}

    cmd_line_fact_collector_0 = CmdLineFactCollector()

    cmd_line_fact_collector_0._get_proc_cmdline = lambda: ''

    var_0 = cmd_line_fact_collector_0.collect()

    assert 'cmdline' in var_0

    var_1 = var_0['cmdline']
    assert var_1 == None

    assert 'proc_cmdline' in var_0

    var_2 = var_0['proc_cmdline']
    assert var_2 == None

    # Case 2: {'quiet': '', 'selinux': '1'}

    cmd_line_fact_collector_0 = CmdLineFactCollector()

    cmd_line_fact

# Generated at 2022-06-24 23:44:39.297237
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert isinstance(cmd_line_fact_collector_0, CmdLineFactCollector),\
        "`cmd_line_fact_collector_0` cannot be instantiated as `CmdLineFactCollector` class."


# Generated at 2022-06-24 23:44:46.350151
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Test data (mocked)
    data = ''

    cmd_line_fact_collector_0 = CmdLineFactCollector()

    # Boundary test: Test that the _get_proc_cmdline has the expected output
    with mock.patch('ansible.module_utils.facts.collectors.cmdline.CmdLineFactCollector._get_proc_cmdline') as mock_get_proc_cmdline:
        mock_get_proc_cmdline.return_value = data
        var_0 = cmd_line_fact_collector_0.collect()
        # Test that the method call had the desired result
        assert var_0 == dict()

# Generated at 2022-06-24 23:44:51.585430
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:44:53.057525
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_1 = CmdLineFactCollector()


# Generated at 2022-06-24 23:45:11.576114
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


if __name__ == '__main__':
    test_case_0()
    test_CmdLineFactCollector()

# Generated at 2022-06-24 23:45:13.739296
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    tmp_CmdLineFactCollector_0 = CmdLineFactCollector()
    tmp_CmdLineFactCollector_0.collect()


# Generated at 2022-06-24 23:45:16.116963
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    cmd_line_fact_collector_1.collect()


# Generated at 2022-06-24 23:45:22.624981
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    var_1 = CmdLineFactCollector()
    assert var_1.collect() == {'cmdline': {'BOOT_IMAGE': '/kernel', 'root': '/dev/sda1', 'rd.lvm.lv': 'centos/root', 'rd.lvm.lv': 'centos/swap', 'ro': True, 'quiet': True}, 'proc_cmdline': {'BOOT_IMAGE': '/kernel', 'root': '/dev/sda1', 'rd.lvm.lv': ['centos/root', 'centos/swap'], 'ro': True, 'quiet': True}}

# Generated at 2022-06-24 23:45:25.670584
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector is not None
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector.name == 'cmdline'


# Generated at 2022-06-24 23:45:29.433819
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0._get_proc_cmdline()

    cmd_line_fact_collector_1 = CmdLineFactCollector()
    var_1 = cmd_line_fact_collector_1.collect()

    return var_1


# Generated at 2022-06-24 23:45:31.107363
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.name


# Generated at 2022-06-24 23:45:36.115743
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    collector_0 = Collector()
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    cmd_line_fact_collector_0.fact_ids = set()
    var_0 = cmd_line_fact_collector_0.collect(None, collector_0.collected_facts)
    assert isinstance(var_0, dict)

    # Test if I can pass some invalid data
    assert cmd_line_fact_collector_0.collect({},{}) == {}

# Generated at 2022-06-24 23:45:37.197129
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:45:38.332798
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:46:30.659228
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    collected_facts_0 = {}
    collected_facts_0 = cmd_line_fact_collector_0.collect(collected_facts=collected_facts_0)
    return collected_facts_0


# Generated at 2022-06-24 23:46:34.627092
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    try:
        test_case_0()
    except Exception as exception:
        print(exception)
        assert True == False
    else:
        # When assertion failed
        assert True == False



# Generated at 2022-06-24 23:46:35.122042
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    pass

# Generated at 2022-06-24 23:46:36.623542
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()

# Generated at 2022-06-24 23:46:46.496013
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.name
    var_1 = cmd_line_fact_collector_0._fact_ids
    var_2 = cmd_line_fact_collector_0._get_proc_cmdline()

# Generated at 2022-06-24 23:46:47.354758
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:46:53.306283
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    with pytest.raises(AttributeError) as pytest_wrapped_e:
        cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert pytest_wrapped_e.type == AttributeError
    assert pytest_wrapped_e.value.args[0] == "can't set attribute"


# Generated at 2022-06-24 23:46:56.778847
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert cmd_line_fact_collector_0._fact_ids == set()


# Generated at 2022-06-24 23:47:03.358415
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    expected_cmdline_facts = {}
    expected_cmdline_facts["proc_cmdline"] = {'BOOT_IMAGE': '/boot/vmlinuz-4.15.0-38-generic',
                                              'root': '/dev/mapper/ubuntu--vg-root',
                                              'ro': '', 'quiet': '',
                                              'splash': '', 'console': 'console=tty1',
                                              'initrd': '/boot/initrd.img-4.15.0-38-generic'}


# Generated at 2022-06-24 23:47:12.157126
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    collected_facts_0 = {u'cmdline': {u'BOOT_IMAGE': u'/vmlinuz-3.10.0-327.el7.x86_64'},
                         u'proc_cmdline': {u'BOOT_IMAGE': [u'/vmlinuz-3.10.0-123.el7.x86_64',
                                                           u'/vmlinuz-3.10.0-327.el7.x86_64']}}
    assert cmd_line_fact_collector_0.collect(collected_facts_0=collected_facts_0) == collected_facts_0

    cmd_line_fact_collector_1 = CmdLineFactCollector()

# Generated at 2022-06-24 23:48:51.963100
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert isinstance(cmd_line_fact_collector_0, CmdLineFactCollector)
    assert hasattr(cmd_line_fact_collector_0, 'name')


# Generated at 2022-06-24 23:48:55.635359
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Test function Body
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    #
    var_1 = cmd_line_fact_collector_0.name
    #
    var_2 = cmd_line_fact_collector_0._fact_ids

# Generated at 2022-06-24 23:48:58.011831
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Create object of class CmdLineFactCollector
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    # Call method collect of class CmdLineFactCollector
    var_0 = cmd_line_fact_collector_0.collect()

# Generated at 2022-06-24 23:49:02.116489
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    ccmdlinefacts = CmdLineFactCollector()
    data = ccmdlinefacts._get_proc_cmdline()

    arg1 = ccmdlinefacts._parse_proc_cmdline(data)
    assert arg1
    arg2 = ccmdlinefacts._parse_proc_cmdline_facts(data)
    assert arg2
    result = ccmdlinefacts.collect()
    assert result

# Generated at 2022-06-24 23:49:03.489041
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector = CmdLineFactCollector()
    var = cmd_line_fact_collector.collect()

# Generated at 2022-06-24 23:49:07.788118
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()


# Generated at 2022-06-24 23:49:08.978756
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.collect() is not None

# Generated at 2022-06-24 23:49:13.897236
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert isinstance(CmdLineFactCollector._fact_ids, set)
    assert callable(CmdLineFactCollector.collect)
    assert CmdLineFactCollector.__dict__['name'] == 'cmdline'
    assert CmdLineFactCollector.__dict__['_fact_ids'] is CmdLineFactCollector._fact_ids
    assert CmdLineFactCollector.__dict__['collect'] is CmdLineFactCollector.collect


# Generated at 2022-06-24 23:49:19.379516
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Test with a value for module and collected_facts
    # The following call to CmdLineFactCollector
    # CmdLineFactCollector() produces an instance of CmdLineFactCollector with default values for args
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    # Test with a value for module
    module_1 = 'ansible_mitogen__via'
    # Test with a value for collected_facts
    collected_facts_1 = 'ansible_mitogen__context'
    var_1 = cmd_line_fact_collector_0.collect(module=module_1, collected_facts=collected_facts_1)
    assert var_1 == ['ansible_mitogen__via', 'ansible_mitogen__context']
    # The following call to CmdLineFactCollector
    #

# Generated at 2022-06-24 23:49:24.542583
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    var_0 = CmdLineFactCollector()
    assert isinstance(var_0, CmdLineFactCollector)
    var_1 = var_0.collect(module=None, collected_facts=None)
    assert isinstance(var_1, dict)
    assert not var_1