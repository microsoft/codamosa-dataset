

# Generated at 2022-06-24 23:42:17.876861
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    print(cmd_line_fact_collector.name)


# Generated at 2022-06-24 23:42:23.427930
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    collected_facts = {}
    res = cmd_line_fact_collector_0.collect(collected_facts=collected_facts)
    assert type(res) == dict
    assert 'cmdline' in res
    assert type(res['cmdline']) == dict
    assert 'proc_cmdline' in res
    assert type(res['proc_cmdline']) == dict

# Generated at 2022-06-24 23:42:25.126711
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    test_case_0()

if __name__ == '__main__':
    test_CmdLineFactCollector()

# Generated at 2022-06-24 23:42:28.009030
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    cmd_line_fact_collector_1 = CmdLineFactCollector()

# Generated at 2022-06-24 23:42:31.990928
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector(
        module=None,
        collected_facts={}
    )
    result = cmd_line_fact_collector_0.collect()
    assert result == {'cmdline': {}, 'proc_cmdline': {}}

# Generated at 2022-06-24 23:42:36.322330
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    try:
        assert test_case_0() is None
        print("Unit test for CmdLineFactCollector successful")
    except:
        print("Unit test for CmdLineFactCollector not successful")

# Generated at 2022-06-24 23:42:38.278891
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert isinstance(cmd_line_fact_collector_0.collect(), dict)

# Generated at 2022-06-24 23:42:39.675321
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:42:44.138424
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector = CmdLineFactCollector()

    # Testing for case 0, when file /proc/cmdline does not exists
    cmd_line_fact_collector._get_proc_cmdline = lambda: None
    cmd_line_fact_collector.collect()

    # Testing for case 1, when file /proc/cmdline is empty
    cmd_line_fact_collector._get_proc_cmdline = lambda: ""
    cmd_line_fact_collector.collect()


# Generated at 2022-06-24 23:42:47.822639
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    cmd_line_fact_collector_2 = CmdLineFactCollector()

    # Testing initialization of private member variable '_fact_ids'
    assert isinstance(cmd_line_fact_collector_1._fact_ids, set)
    assert not cmd_line_fact_collector_1._fact_ids
    assert len(cmd_line_fact_collector_1._fact_ids) == 0

# Generated at 2022-06-24 23:42:57.774972
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    pass


# Generated at 2022-06-24 23:43:01.409043
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.collection_key == 'ansible_cmdline'
    assert CmdLineFactCollector.name == 'cmdline'

# Generated at 2022-06-24 23:43:03.574010
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    cmd_line_fact_collector_1.collect()


# Generated at 2022-06-24 23:43:09.299267
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()


# Generated at 2022-06-24 23:43:11.645156
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    cmd_line_fact_collector_0.collect()

# Generated at 2022-06-24 23:43:13.847325
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    print(cmd_line_fact_collector_0.collect())


# Generated at 2022-06-24 23:43:18.196787
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'


# Generated at 2022-06-24 23:43:19.434158
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:43:21.831094
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector is not None


# Generated at 2022-06-24 23:43:23.618436
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:43:33.060419
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:43:39.493546
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # test CmdLineFactCollector object is created
    cmd_line_fact_collector_obj = CmdLineFactCollector()
    assert cmd_line_fact_collector_obj is not None
    # test _fact_ids field is correct type
    assert type(cmd_line_fact_collector_obj._fact_ids) is set


# Generated at 2022-06-24 23:43:40.325353
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert(isinstance(CmdLineFactCollector(), CmdLineFactCollector))


# Generated at 2022-06-24 23:43:42.551149
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0 is not None



# Generated at 2022-06-24 23:43:43.960084
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:43:44.820973
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    assert True is True


# Generated at 2022-06-24 23:43:47.927843
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector = CmdLineFactCollector()
    var = cmd_line_fact_collector.collect()
    assert var != None


# Generated at 2022-06-24 23:43:48.958787
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()

# Generated at 2022-06-24 23:43:50.712266
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    test_case_0()

if __name__ == '__main__':
    test_CmdLineFactCollector_collect()

# Generated at 2022-06-24 23:43:52.306119
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    fact_collector_0 = CmdLineFactCollector()
    fact_collector_0.collect()


# Generated at 2022-06-24 23:44:14.718127
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector.name == 'cmdline'
    assert cmd_line_fact_collector._fact_ids == set()


# Generated at 2022-06-24 23:44:15.854720
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert isinstance(cmd_line_fact_collector, CmdLineFactCollector)


# Generated at 2022-06-24 23:44:17.472758
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()



# Generated at 2022-06-24 23:44:21.900282
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector.name == "cmdline"
    assert cmd_line_fact_collector._fact_ids == set()


# Generated at 2022-06-24 23:44:23.432044
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:44:25.382408
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:44:28.505422
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert (isinstance(CmdLineFactCollector(), CmdLineFactCollector))


# Generated at 2022-06-24 23:44:29.998446
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    var_1 = CmdLineFactCollector()
    var_2 = var_1.collect()
    assert var_2 == {}

# Generated at 2022-06-24 23:44:31.309813
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:44:35.515364
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    # Test if the constructor of CmdLineFactCollector returns an object
    assert isinstance(cmd_line_fact_collector_0, object)


# Generated at 2022-06-24 23:45:17.772903
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    assert var_0 == {'cmdline': {}, 'proc_cmdline': {}}

# Generated at 2022-06-24 23:45:25.371264
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_2 = CmdLineFactCollector()
    var_2 = cmd_line_fact_collector_2.collect()
    assert isinstance(var_2, dict)
    assert var_2 == {}
    cmd_line_fact_collector_3 = CmdLineFactCollector()
    var_3 = cmd_line_fact_collector_3.collect()
    assert isinstance(var_3, dict)
    assert var_3 == {}
    cmd_line_fact_collector_4 = CmdLineFactCollector()
    var_4 = cmd_line_fact_collector_4.collect()
    assert isinstance(var_4, dict)
    assert var_4 == {}
    cmd_line_fact_collector_5 = CmdLineFactCollector()
    var

# Generated at 2022-06-24 23:45:26.596216
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_1 = CmdLineFactCollector()

# Generated at 2022-06-24 23:45:28.347330
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    cmd_line_fact_collector_0.collect()


# Generated at 2022-06-24 23:45:37.491505
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    # Mock the method _get_proc_cmdline, return a static response
    cmd_line_fact_collector_1._get_proc_cmdline = lambda: 'BOOT_IMAGE=/vmlinuz-3.10.0-514.10.2.el7.x86_64 root=/dev/mapper/cl-root ro crashkernel=auto rd.lvm.lv=cl/root rd.lvm.lv=cl/swap rhgb quiet LANG=en_US.UTF-8 rd.lvm.lv=cl/var'
    # Mock the method _parse_proc_cmdline, return a static response

# Generated at 2022-06-24 23:45:38.184243
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()


# Generated at 2022-06-24 23:45:40.361047
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    cmd_line_fact_collector_1 = CmdLineFactCollector()



# Generated at 2022-06-24 23:45:50.323393
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    data = get_file_content('ansible/test/data/facts/cmdline')
    assert isinstance(data, str), 'isinstance(data, str)'
    cmdline_dict = {}

# Generated at 2022-06-24 23:45:51.877730
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    cmd_line_fact_collector_0.collect()


# Generated at 2022-06-24 23:45:54.037057
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert cmd_line_fact_collector_0._fact_ids == set()


# Generated at 2022-06-24 23:47:21.393681
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    cmd_line_fact_collector_0.collect()


# Generated at 2022-06-24 23:47:23.334258
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # 1
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()



# Generated at 2022-06-24 23:47:25.531271
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()


# Generated at 2022-06-24 23:47:26.681590
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    pass

# Generated at 2022-06-24 23:47:34.578934
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()

    # Class containing '_get_proc_cmdline' method
    class Mock_Class_0:
        def _get_proc_cmdline(self):
            return 'foo'

    # Class containing '_get_proc_cmdline' method
    class Mock_Class_1:
        def _get_proc_cmdline(self):
            return 'bar'

    var_0 = cmd_line_fact_collector_0.collect(module=Mock_Class_0())
    var_1 = cmd_line_fact_collector_0.collect(module=Mock_Class_1())

    assert var_0 == {'cmdline': {'foo': True}, 'proc_cmdline': {'foo': True}}

# Generated at 2022-06-24 23:47:44.422602
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # cmd_line_fact_collector_0 is an instance of class CmdLineFactCollector
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    cmd_line_fact_collector_0.name = "cmdline"
    cmd_line_fact_collector_0._fact_ids = set()
    cmd_line_fact_collector_0._fact_ids.add(u"cmdline")
    cmd_line_fact_collector_0._fact_ids.add(u"proc_cmdline")
    var_0 = cmd_line_fact_collector_0.collect()
    # Assert the values of attributes
    assert var_0.get(u"cmdline").get(u"libata.dma") == u"0"

# Generated at 2022-06-24 23:47:45.426001
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj._fact_ids == set()



# Generated at 2022-06-24 23:47:47.610185
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == "cmdline"


# Generated at 2022-06-24 23:47:50.225143
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()


# Generated at 2022-06-24 23:47:52.003911
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    assert var_0 == None

# Generated at 2022-06-24 23:51:42.092743
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # cmd_line_fact_collector_0 is instance of class 
    # CmdLineFactCollector
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    # var_0 is instance of class dict
    var_0 = cmd_line_fact_collector_0.collect()
    # AssertionError raised if the first argument (actual value) is not equal
    # to the second argument (expected value).
    # assertEqual(first_arg, second_arg)
    assert type(var_0) == dict

# Generated at 2022-06-24 23:51:46.371145
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    var_1 = cmd_line_fact_collector_1.collect()
    assert var_1['cmdline']['ro'] == True
    assert var_1['cmdline']['root'] == '/dev/sda8'
    assert var_1['cmdline']['quiet'] == True
    assert var_1['proc_cmdline']['ro'] == True
    assert var_1['proc_cmdline']['root'] == '/dev/sda8'
    assert var_1['proc_cmdline']['quiet'] == True

# Generated at 2022-06-24 23:51:48.915637
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_2 = CmdLineFactCollector()
    var_1 = (None, {})
    var_2 = cmd_line_fact_collector_2.collect()
    assert var_1 == var_2


# Generated at 2022-06-24 23:51:50.512069
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'


# Generated at 2022-06-24 23:51:52.584875
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert cmd_line_fact_collector_0._fact_ids == {'cmdline', 'proc_cmdline'}

# Generated at 2022-06-24 23:52:00.642614
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.name
    var_1 = cmd_line_fact_collector_0._fact_ids
    var_2 = cmd_line_fact_collector_1.name
    var_3 = cmd_line_fact_collector_1._fact_ids

    strCompare_0 = var_0 == var_2
    strCompare_1 = var_1 == var_3
    assert strCompare_0
    assert strCompare_1


# Generated at 2022-06-24 23:52:07.131561
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()

    # Creating an empty dictionary
    var_0 = {}

    # Getting the data from file '/proc/cmdline'
    var_1 = get_file_content('/proc/cmdline')

    # Assigning value to variable 'var_2'
    var_2 = None

    # Assigning value to variable 'var_1'
    var_1 = var_2

    # Getting the data from file '/proc/cmdline'
    var_3 = get_file_content('/proc/cmdline')

    # Assigning value to variable 'var_4'
    var_4 = None

    # Assigning value to variable 'var_3'
    var_3 = var_4

    # Assigning value to variable 'data'
    data = var_3