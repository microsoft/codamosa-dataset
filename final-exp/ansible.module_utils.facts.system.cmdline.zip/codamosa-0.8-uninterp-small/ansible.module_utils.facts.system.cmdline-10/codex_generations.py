

# Generated at 2022-06-24 23:42:24.730869
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()

# Generated at 2022-06-24 23:42:26.207113
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:42:30.262484
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()

    res = collector.collect()
    assert isinstance(res, dict)
    assert 'cmdline' in res
    assert isinstance(res['cmdline'], dict)

    assert 'proc_cmdline' in res
    assert isinstance(res['proc_cmdline'], dict)

# Generated at 2022-06-24 23:42:36.283305
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    assert cmd_line_fact_collector_1.collect() == {'cmdline': {}, 'proc_cmdline': {}}

if __name__ == '__main__':
    test_case_0()
    test_CmdLineFactCollector_collect()

# Generated at 2022-06-24 23:42:38.587602
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_1 = CmdLineFactCollector()


# Generated at 2022-06-24 23:42:41.387060
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == ('cmdline')
    assert isinstance(cmd_line_fact_collector_0._fact_ids, set)


# Generated at 2022-06-24 23:42:43.159661
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert isinstance(cmd_line_fact_collector_0, BaseFactCollector)

# Generated at 2022-06-24 23:42:43.884484
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    test_case_0()

# Generated at 2022-06-24 23:42:48.112308
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector = CmdLineFactCollector()

    data = "rd.boot=sda console=ttyS0,115200n8 console=tty0 console=ttyS0,115200"
    cmdline_facts = cmd_line_fact_collector._parse_proc_cmdline_facts(data)
    assert 'console' in cmdline_facts
    assert cmdline_facts['console'] == ["ttyS0,115200n8", "tty0", "ttyS0,115200"]
    assert 'rd.boot' in cmdline_facts
    assert cmdline_facts['rd.boot'] == "sda"

# Generated at 2022-06-24 23:42:54.201284
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector = CmdLineFactCollector()
    output = cmd_line_fact_collector.collect()

# Generated at 2022-06-24 23:43:07.139762
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():

    test_case_0()

# Generated at 2022-06-24 23:43:10.763363
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()


# Generated at 2022-06-24 23:43:19.103637
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()

# Generated at 2022-06-24 23:43:20.090739
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()



# Generated at 2022-06-24 23:43:21.272112
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    pass

# Generated at 2022-06-24 23:43:23.711409
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()

    # Test with an existing /proc/cmdline
    cmd_line_fact_collector_0.collect()

# Generated at 2022-06-24 23:43:27.742087
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector.name == 'cmdline'



# Generated at 2022-06-24 23:43:29.533647
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()


# Generated at 2022-06-24 23:43:36.933777
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector

    cmd_line_fact_collector_1 = CmdLineFactCollector()
    assert cmd_line_fact_collector_1.collect() == {'cmdline': {'ro': True, 'root': '/dev/mapper/centos-root'}, 'proc_cmdline': {'ro': True, 'root': '/dev/mapper/centos-root'}}

    cmd_line_fact_collector_2 = CmdLineFactCollector()
    assert cmd_line_fact_collector_2.collect() == {'cmdline': {'ro': True, 'root': '/dev/mapper/centos-root'}, 'proc_cmdline': {'ro': True, 'root': '/dev/mapper/centos-root'}}

    cmd_

# Generated at 2022-06-24 23:43:40.022334
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector()
    assert cmd_line_fact_collector_1.collect()


# Generated at 2022-06-24 23:43:49.572177
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0


# Generated at 2022-06-24 23:43:51.280140
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert type(cmd_line_fact_collector_0) == CmdLineFactCollector

# Generated at 2022-06-24 23:43:52.520734
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()

# Generated at 2022-06-24 23:44:04.329235
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    var_1 = CmdLineFactCollector()

# Generated at 2022-06-24 23:44:10.162079
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()

# Generated at 2022-06-24 23:44:12.785955
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    assert type(CmdLineFactCollector().collect()) == dict

# Generated at 2022-06-24 23:44:15.572736
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_1 = CmdLineFactCollector(['/bin/ls'])
    var_1 = cmd_line_fact_collector_1.collect()
    assert var_1 is not None and '===' in var_1


# Generated at 2022-06-24 23:44:16.772287
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    o = CmdLineFactCollector()
    assert o._fact_ids == set()


# Generated at 2022-06-24 23:44:27.276191
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Define test inputs and expected outputs for method collect of class CmdLineFactCollector
    _input = None

# Generated at 2022-06-24 23:44:29.541516
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0 is not None

# Generated at 2022-06-24 23:44:51.426541
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector

# Generated at 2022-06-24 23:44:56.244546
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()

# Generated at 2022-06-24 23:45:01.984777
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    var_0 = CmdLineFactCollector()
    var_1 = var_0.collect()

    assert isinstance(var_0, CmdLineFactCollector) is True
    assert isinstance(var_1, dict) is True


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 23:45:04.538889
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    assert isinstance(var_0, dict)



# Generated at 2022-06-24 23:45:06.528682
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector = CmdLineFactCollector()
    var = cmd_line_fact_collector.collect()
    assert True



# Generated at 2022-06-24 23:45:16.620604
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    assert 'cmdline' in var_0
    assert 'proc_cmdline' in var_0
    assert var_0['cmdline']['console'] == 'ttyS0'
    assert var_0['cmdline']['consoleblank'] == '0'
    assert var_0['cmdline']['crashkernel'] == 'auto'
    assert var_0['cmdline']['elevator'] == 'noop'
    assert var_0['cmdline']['init'] == '/sbin/init'
    assert var_0['cmdline']['root'] == '/dev/mapper/vg_proxy-lv_root'

# Generated at 2022-06-24 23:45:17.641261
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()

# Generated at 2022-06-24 23:45:25.313978
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    data = "root=/dev/mapper/fedora-root ro rd.lvm.lv=fedora/root rd.lvm.lv=fedora/swap rhgb quiet LANG=en_US.UTF8 LANGUAGE=en_US.en_US"
    mock_fact = CmdLineFactCollector()
    mock_fact._get_proc_cmdline = lambda: data
    result = mock_fact.collect()

# Generated at 2022-06-24 23:45:26.901510
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()


# Generated at 2022-06-24 23:45:32.848501
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert isinstance(cmd_line_fact_collector_0._fact_ids, set)


# Generated at 2022-06-24 23:46:23.667496
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    result = CmdLineFactCollector.collect()
    assert result is not None

# Generated at 2022-06-24 23:46:26.802503
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == 'cmdline'
    assert cmd_line_fact_collector_0._fact_ids == set()



# Generated at 2022-06-24 23:46:27.753459
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:46:29.124584
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    var_1 = CmdLineFactCollector()
    assert isinstance(var_1, CmdLineFactCollector)

# Generated at 2022-06-24 23:46:34.510880
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_1 = cmd_line_fact_collector_0.collect()
    assert var_1 == {"cmdline": {"quiet": True, "rd.udev.log_priority": "info"}, "proc_cmdline": {"quiet": True, "rd.udev.log_priority": "info"}}


# Generated at 2022-06-24 23:46:38.838599
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    logger = logging.getLogger()
    logging.basicConfig(level=logging.DEBUG)
    log_level = logger.getEffectiveLevel()
    logger.setLevel(logging.DEBUG)

    test_case_0()

    logger.setLevel(log_level)

if __name__ == "__main__":
    test_CmdLineFactCollector()

# Generated at 2022-06-24 23:46:42.182929
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.name
    assert var_0 == 'cmdline'
    var_1 = cmd_line_fact_collector_0._fact_ids
    assert var_1 == set()



# Generated at 2022-06-24 23:46:47.983346
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0._fact_ids == set()
    assert cmd_line_fact_collector_0.name == 'cmdline'


# Generated at 2022-06-24 23:46:51.517930
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:46:59.861346
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector = CmdLineFactCollector()
    my_content = "BOOT_IMAGE=/vmlinuz-3.10.0-693.el7.x86_64 root=/dev/mapper/cl-root ro crashkernel=auto rd.lvm.lv=cl/root rd.lvm.lv=cl/swap rhgb quiet LANG=en_US.UTF-8"
    with open("/proc/cmdline", "w") as f:
        f.write(my_content)
    var = cmd_line_fact_collector.collect()
    assert isinstance(var, dict)

# Generated at 2022-06-24 23:48:41.365897
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    obj = CmdLineFactCollector()
    obj.collect()


# Generated at 2022-06-24 23:48:51.056822
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    root_dir = "/home/fra/devstack"
    data_dir = "/home/fra/devstack/data"
    test_dir = data_dir + "/test"
    loader_dir = test_dir + "/test_data/test_modules/test_ansible_source/test_module_utils/test_facts/test_collector"
    test_file = data_dir + "/test/test_data/test_modules/test_ansible_source/test_module_utils/test_facts/test_collector/test_file.txt"
    test_ansible_module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    # testing with test_file.txt
    get_file_content(test_file)
    if os.path.isfile(test_file):
        test

# Generated at 2022-06-24 23:48:53.386369
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    assert type(var_0) is dict


# Generated at 2022-06-24 23:48:57.481883
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    assert cmd_line_fact_collector_0.name == "cmdline"

# Generated at 2022-06-24 23:48:59.435314
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()


# Generated at 2022-06-24 23:49:04.087933
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    print('Unit test for constructor of class CmdLineFactCollector')
    try:
        print('\tCase 1: Initialize the class')
        cmd_line_fact_collector_0 = CmdLineFactCollector()
        print('\t\tCase 1.1: Object created successfully')
    except Exception as err:
        print('\t\tCase 1.2: Failed to create object')
        print('\t\t\tERROR: ', err)
    else:
        print('\t\tCase 1.2: Passed')


# Generated at 2022-06-24 23:49:07.764315
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    var_0 = cmd_line_fact_collector_0.collect()
    assert isinstance(var_0, dict) or isinstance(var_0, NoneType)
    assert isinstance(var_0['cmdline'], dict)
    assert isinstance(var_0['proc_cmdline'], dict)


# Generated at 2022-06-24 23:49:10.046124
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
    cmd_line_fact_collector_0.collect()

# Generated at 2022-06-24 23:49:10.865973
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()



# Generated at 2022-06-24 23:49:11.907849
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector_0 = CmdLineFactCollector()
