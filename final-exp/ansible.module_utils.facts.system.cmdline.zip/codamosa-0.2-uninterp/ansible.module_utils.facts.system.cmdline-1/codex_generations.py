

# Generated at 2022-06-17 01:45:20.273980
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:45:21.705591
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector.collect()

# Generated at 2022-06-17 01:45:32.669827
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_content

    # Create a mock for get_file_content
    get_file_content_mock = get_file_content
    get_file_content_mock.return_value = 'ansible_test=True'

    # Create a mock for Collector
    collector_mock = Collector()

    # Create a mock for CmdLineFactCollector
    cmdline_fact_collector_mock = CmdLineFactCollector()

    # Call method collect of class CmdLineFactCollector
    cmdline_facts = cmdline_fact_collector_mock.collect(collected_facts=collector_mock)

    # Assert that the method collect of class CmdLineFactCollector returns a

# Generated at 2022-06-17 01:45:39.243180
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-17 01:45:48.256399
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector._get_proc_cmdline = lambda: 'foo=bar baz=qux'
    cmdline_collector._parse_proc_cmdline = lambda x: x
    cmdline_collector._parse_proc_cmdline_facts = lambda x: x
    assert cmdline_collector.collect() == {'cmdline': 'foo=bar baz=qux', 'proc_cmdline': 'foo=bar baz=qux'}

# Generated at 2022-06-17 01:45:50.669308
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector()
    assert cmdline_facts.collect() == {}

# Generated at 2022-06-17 01:45:53.818941
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:46:03.062064
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()

# Generated at 2022-06-17 01:46:08.100534
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:46:13.102519
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector._get_proc_cmdline = lambda: 'foo=bar baz=qux'
    cmdline_facts = cmdline_collector.collect()
    assert cmdline_facts['cmdline'] == {'foo': 'bar', 'baz': 'qux'}
    assert cmdline_facts['proc_cmdline'] == {'foo': 'bar', 'baz': 'qux'}

# Generated at 2022-06-17 01:46:25.071293
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:46:28.920461
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:46:32.797352
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:46:36.091087
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-17 01:46:46.573476
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector

    # Create a mock module
    module = MagicMock()

    # Create a mock Collector
    collector = MagicMock(spec=Collector)

    # Create a mock BaseFactCollector
    base_fact_collector = MagicMock(spec=BaseFactCollector)

    # Create a CmdLineFactCollector object
    cmdline_fact_collector = CmdLineFactCollector()

    # Create a mock file content

# Generated at 2022-06-17 01:46:54.841291
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector._get_proc_cmdline = lambda: 'BOOT_IMAGE=/vmlinuz-3.10.0-327.el7.x86_64 root=/dev/mapper/rhel-root ro crashkernel=auto rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet LANG=en_US.UTF-8'
    cmdline_facts = cmdline_collector.collect()

# Generated at 2022-06-17 01:47:03.192705
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline'] == {'BOOT_IMAGE': '/vmlinuz-3.10.0-327.el7.x86_64', 'ro': True, 'root': '/dev/mapper/rhel-root', 'rhgb': True, 'quiet': True}
    assert cmdline_facts['proc_cmdline'] == {'BOOT_IMAGE': '/vmlinuz-3.10.0-327.el7.x86_64', 'ro': True, 'root': '/dev/mapper/rhel-root', 'rhgb': True, 'quiet': True}

# Generated at 2022-06-17 01:47:07.969524
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-17 01:47:14.423113
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:47:16.784085
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:47:48.311760
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline'] == {'BOOT_IMAGE': '/vmlinuz-3.10.0-327.el7.x86_64', 'ro': True, 'root': '/dev/mapper/rhel-root', 'rhgb': True, 'quiet': True, 'LANG': 'en_US.UTF-8', 'crashkernel': 'auto', 'rd.lvm.lv': 'rhel/root', 'rd.lvm.lv': 'rhel/swap'}

# Generated at 2022-06-17 01:47:57.433983
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance

    # Create a fake module object
    module = type('', (), {})()

    # Create a fake Collector object
    collector = Collector()

    # Create a fake BaseFactCollector object
    base_fact_collector = BaseFactCollector()

    # Create a fake CmdLineFactCollector object
    cmdline_fact_collector = CmdLineFactCollector()

    # Create a fake get_collector_instance object
    get_collector_instance = get_collector_instance()

    # Create a fake collected_facts object
    collected_facts = {}

    # Create a fake _get_proc

# Generated at 2022-06-17 01:48:01.601591
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()


# Generated at 2022-06-17 01:48:05.784653
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()
    assert CmdLineFactCollector.collect() == {}

# Generated at 2022-06-17 01:48:10.481300
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:48:17.213442
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline'] == {'BOOT_IMAGE': '/vmlinuz-3.10.0-327.el7.x86_64', 'ro': True, 'root': '/dev/mapper/rhel-root', 'rhgb': True, 'quiet': True}
    assert cmdline_facts['proc_cmdline'] == {'BOOT_IMAGE': '/vmlinuz-3.10.0-327.el7.x86_64', 'ro': True, 'root': '/dev/mapper/rhel-root', 'rhgb': True, 'quiet': True}

# Generated at 2022-06-17 01:48:24.282012
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    cmdline_facts = collector.collect()
    assert cmdline_facts['cmdline']['root'] == '/dev/mapper/vg_centos-lv_root'
    assert cmdline_facts['proc_cmdline']['root'] == '/dev/mapper/vg_centos-lv_root'

# Generated at 2022-06-17 01:48:26.409452
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-17 01:48:28.446470
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-17 01:48:33.218244
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()


# Generated at 2022-06-17 01:48:55.343586
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:48:57.903102
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:49:03.728447
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-17 01:49:10.080944
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline']['ro'] == True
    assert cmdline_facts['proc_cmdline']['ro'] == True
    assert cmdline_facts['cmdline']['root'] == '/dev/mapper/centos-root'
    assert cmdline_facts['proc_cmdline']['root'] == '/dev/mapper/centos-root'
    assert cmdline_facts['cmdline']['rhgb'] == True
    assert cmdline_facts['proc_cmdline']['rhgb'] == True
    assert cmdline_facts['cmdline']['quiet'] == True
    assert cmdline_facts['proc_cmdline']['quiet'] == True

# Generated at 2022-06-17 01:49:21.589237
# Unit test for method collect of class CmdLineFactCollector

# Generated at 2022-06-17 01:49:28.849561
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert isinstance(cmdline_facts, dict)
    assert 'cmdline' in cmdline_facts
    assert 'proc_cmdline' in cmdline_facts
    assert isinstance(cmdline_facts['cmdline'], dict)
    assert isinstance(cmdline_facts['proc_cmdline'], dict)

# Generated at 2022-06-17 01:49:34.431727
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:49:43.544117
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector._get_proc_cmdline = lambda: 'BOOT_IMAGE=/vmlinuz-3.10.0-327.el7.x86_64 root=/dev/mapper/rhel-root ro crashkernel=auto rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet LANG=en_US.UTF-8'
    cmdline_facts = cmdline_collector.collect()

# Generated at 2022-06-17 01:49:46.460308
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:49:55.270861
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Test with empty data
    data = ''
    cmdline_facts = CmdLineFactCollector()._parse_proc_cmdline(data)
    assert cmdline_facts == {}

    # Test with data
    data = 'BOOT_IMAGE=/vmlinuz-3.10.0-693.21.1.el7.x86_64 root=/dev/mapper/rhel-root ro crashkernel=auto rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet LANG=en_US.UTF-8'
    cmdline_facts = CmdLineFactCollector()._parse_proc_cmdline(data)

# Generated at 2022-06-17 01:50:49.298194
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names

    # Get the list of available collectors
    collector_names = get_collector_names()

    # Get the instance of the CmdLineFactCollector
    cmdline_collector = get_collector_instance('CmdLineFactCollector')

    # Get the instance of the Collector
    collector = Collector()

    # Add the CmdLineFactCollector to the Collector
    collector.add_collector(cmdline_collector)

    # Collect the facts
    facts = collector.collect(module=None, collected_facts=None)

    # Check if the CmdLineFactCollector is in the list of

# Generated at 2022-06-17 01:50:51.092780
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:50:55.803033
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Create a CmdLineFactCollector object
    cmdline_collector = CmdLineFactCollector()

    # Create a mock module object
    module = type('module', (object,), {})()

    # Create a mock collected_facts object
    collected_facts = type('collected_facts', (object,), {})()

    # Call method collect of class CmdLineFactCollector
    cmdline_facts = cmdline_collector.collect(module, collected_facts)

    # Assert that the cmdline_facts dictionary is not empty
    assert cmdline_facts

# Generated at 2022-06-17 01:51:01.209013
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline'] == {'BOOT_IMAGE': '/vmlinuz-3.10.0-327.el7.x86_64', 'root': '/dev/mapper/centos-root', 'ro': True, 'crashkernel': 'auto', 'rhgb': True, 'quiet': True}
    assert cmdline_facts['proc_cmdline'] == {'BOOT_IMAGE': '/vmlinuz-3.10.0-327.el7.x86_64', 'root': '/dev/mapper/centos-root', 'ro': True, 'crashkernel': 'auto', 'rhgb': True, 'quiet': True}

# Generated at 2022-06-17 01:51:05.490693
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:51:14.516686
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Create a CmdLineFactCollector object
    cmdline_fact_collector = CmdLineFactCollector()

    # Create a test file
    test_file = open('/tmp/test_file', 'w')
    test_file.write('test_key=test_value test_key2=test_value2')
    test_file.close()

    # Create a test method to replace the original method _get_proc_cmdline
    def _get_proc_cmdline():
        return get_file_content('/tmp/test_file')

    # Replace the original method _get_proc_cmdline with the test method
    cmdline_fact_collector._get_proc_cmdline = _get_proc_cmdline

    # Call method collect of class CmdLineFactCollector
    cmdline_facts = cmdline_fact

# Generated at 2022-06-17 01:51:18.954284
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:51:22.433571
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-17 01:51:25.985606
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:51:32.960977
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:53:20.759191
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline']['ro'] == True
    assert cmdline_facts['proc_cmdline']['ro'] == True

# Generated at 2022-06-17 01:53:23.066670
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-17 01:53:24.448887
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert c._fact_ids == set()


# Generated at 2022-06-17 01:53:32.457371
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_fact_collector = CmdLineFactCollector()
    cmdline_fact_collector._get_proc_cmdline = lambda: 'BOOT_IMAGE=/vmlinuz-3.10.0-327.el7.x86_64 root=/dev/mapper/rhel-root ro crashkernel=auto rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet LANG=en_US.UTF-8'
    cmdline_facts = cmdline_fact_collector.collect()
    assert cmdline_facts['cmdline']['BOOT_IMAGE'] == '/vmlinuz-3.10.0-327.el7.x86_64'

# Generated at 2022-06-17 01:53:34.835268
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-17 01:53:43.781944
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    cmdline_facts = collector.collect()
    assert cmdline_facts['cmdline'] == {'BOOT_IMAGE': '/vmlinuz-3.10.0-327.el7.x86_64', 'root': '/dev/mapper/rhel-root', 'ro': True, 'crashkernel': 'auto', 'rhgb': True, 'quiet': True, 'rd.lvm.lv': 'rhel/root', 'rd.lvm.lv': 'rhel/swap', 'LANG': 'en_US.UTF-8'}

# Generated at 2022-06-17 01:53:47.354209
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-17 01:53:52.828848
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline']['ro'] == True
    assert cmdline_facts['proc_cmdline']['ro'] == True
    assert cmdline_facts['proc_cmdline']['root'] == '/dev/sda1'
    assert cmdline_facts['proc_cmdline']['console'] == ['ttyS0', 'tty0']

# Generated at 2022-06-17 01:53:56.555235
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:54:06.854072
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline']['root'] == '/dev/mapper/centos-root'
    assert cmdline_facts['cmdline']['ro'] == True
    assert cmdline_facts['cmdline']['crashkernel'] == 'auto'
    assert cmdline_facts['cmdline']['rd.lvm.lv'] == 'centos/root'
    assert cmdline_facts['cmdline']['rhgb'] == True
    assert cmdline_facts['cmdline']['quiet'] == True
    assert cmdline_facts['cmdline']['LANG'] == 'en_US.UTF-8'
    assert cmdline_facts['cmdline']['rd.lvm.lv'] == 'centos/root'
    assert cmd