

# Generated at 2022-06-17 01:45:20.510616
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:45:22.960785
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline']['root'] == '/dev/sda1'
    assert cmdline_facts['proc_cmdline']['root'] == '/dev/sda1'

# Generated at 2022-06-17 01:45:26.961789
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:45:29.614516
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()


# Generated at 2022-06-17 01:45:36.055816
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:45:39.417712
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:45:45.416902
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline']['root'] == '/dev/sda1'
    assert cmdline_facts['proc_cmdline']['root'] == '/dev/sda1'

# Generated at 2022-06-17 01:45:54.115028
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector

    # Create a new instance of CmdLineFactCollector
    cmdline_collector = CmdLineFactCollector()

    # Create a new instance of Collector
    collector = Collector()

    # Add the CmdLineFactCollector instance to the Collector instance
    collector.add_collector(cmdline_collector)

    # Create a new instance of BaseFactCollector
    base_fact_collector = BaseFactCollector()

    # Collect facts
    facts = base_fact_collector.collect(collector=collector)

    # Assert that the facts are equal to the expected facts

# Generated at 2022-06-17 01:45:59.166750
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:46:04.600571
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-17 01:46:11.038530
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline']
    assert cmdline_facts['proc_cmdline']

# Generated at 2022-06-17 01:46:16.920996
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:46:23.064365
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:46:25.070909
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()
    assert CmdLineFactCollector.collect() == {}

# Generated at 2022-06-17 01:46:28.921382
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:46:39.526591
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline'] == {'BOOT_IMAGE': '/vmlinuz-3.10.0-327.el7.x86_64', 'root': '/dev/mapper/rhel-root', 'ro': True, 'crashkernel': 'auto', 'rhgb': True, 'quiet': True, 'LANG': 'en_US.UTF-8'}

# Generated at 2022-06-17 01:46:49.677334
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector._get_proc_cmdline = lambda: 'BOOT_IMAGE=/vmlinuz-3.10.0-327.el7.x86_64 root=UUID=f3e8c8b3-a7d0-4c9b-8c0a-9f9a9e9c8f8a ro crashkernel=auto rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet LANG=en_US.UTF-8'

# Generated at 2022-06-17 01:47:00.455602
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector

    class TestCollector(Collector):
        def __init__(self, collectors=None, namespace=None):
            super(TestCollector, self).__init__(collectors, namespace)

        def collect(self, module=None, collected_facts=None):
            return collected_facts

    class TestBaseFactCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set()

        def collect(self, module=None, collected_facts=None):
            return collected_facts

    test_collector = TestCollector(collectors=[TestBaseFactCollector()])
    test_collector.collect()


# Generated at 2022-06-17 01:47:13.595733
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """
    Unit test for method collect of class CmdLineFactCollector
    """
    cmdline_fact_collector = CmdLineFactCollector()
    cmdline_fact_collector._get_proc_cmdline = lambda: 'BOOT_IMAGE=/vmlinuz-3.10.0-327.el7.x86_64 root=/dev/mapper/rhel-root ro crashkernel=auto rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet LANG=en_US.UTF-8'
    cmdline_facts = cmdline_fact_collector.collect()
    assert cmdline_facts['cmdline']['BOOT_IMAGE'] == '/vmlinuz-3.10.0-327.el7.x86_64'
    assert cmd

# Generated at 2022-06-17 01:47:19.903222
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Create a CmdLineFactCollector object
    cmdline_fact_collector = CmdLineFactCollector()

    # Create a mock module
    mock_module = type('module', (object,), {})()

    # Create a mock collected_facts
    mock_collected_facts = {}

    # Call method collect of CmdLineFactCollector object
    cmdline_facts = cmdline_fact_collector.collect(mock_module, mock_collected_facts)

    # Assert method collect returns a dictionary
    assert isinstance(cmdline_facts, dict)

    # Assert method collect returns a dictionary with keys 'cmdline' and 'proc_cmdline'
    assert 'cmdline' in cmdline_facts
    assert 'proc_cmdline' in cmdline_facts

    # Assert method collect returns a dictionary with keys '

# Generated at 2022-06-17 01:47:34.817508
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline']
    assert cmdline_facts['proc_cmdline']

# Generated at 2022-06-17 01:47:39.190510
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:47:44.042134
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:47:56.134651
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline']['root'] == '/dev/sda1'
    assert cmdline_facts['proc_cmdline']['root'] == '/dev/sda1'
    assert cmdline_facts['proc_cmdline']['ro'] == True
    assert cmdline_facts['proc_cmdline']['quiet'] == True
    assert cmdline_facts['proc_cmdline']['splash'] == True
    assert cmdline_facts['proc_cmdline']['vga'] == '0x31a'
    assert cmdline_facts['proc_cmdline']['initrd'] == '/boot/initrd.img-3.13.0-32-generic'

# Generated at 2022-06-17 01:48:01.479466
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:48:06.926580
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:48:12.591693
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector._get_proc_cmdline = lambda: 'foo=bar baz=qux'
    cmdline_facts = cmdline_collector.collect()
    assert cmdline_facts['cmdline'] == {'foo': 'bar', 'baz': 'qux'}
    assert cmdline_facts['proc_cmdline'] == {'foo': 'bar', 'baz': 'qux'}

# Generated at 2022-06-17 01:48:18.532502
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:48:25.777198
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector._get_proc_cmdline = lambda: 'foo=bar baz=qux'
    cmdline_facts = cmdline_collector.collect()
    assert cmdline_facts['cmdline'] == {'foo': 'bar', 'baz': 'qux'}
    assert cmdline_facts['proc_cmdline'] == {'foo': 'bar', 'baz': 'qux'}


# Generated at 2022-06-17 01:48:28.123262
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:48:47.580479
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:48:49.552563
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-17 01:48:52.110657
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-17 01:48:55.261110
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-17 01:48:57.304882
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline']
    assert cmdline_facts['proc_cmdline']

# Generated at 2022-06-17 01:49:09.505533
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collectors.cmdline import CmdLineFactCollector

    # Mock the get_file_content method
    Collector.get_file_content = get_file_content

    # Create a CmdLineFactCollector object
    cmdline_fact_collector = CmdLineFactCollector()

    # Create a test string
    test_string = 'root=UUID=12345678-1234-1234-1234-123456789012 ro quiet splash'

    # Mock the _get_proc_cmdline method
    cmdline_fact_collector._get_proc_cmdline = lambda: test_string

    # Call the collect method
    cmd

# Generated at 2022-06-17 01:49:21.479148
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector

    # Create a mock for class BaseFactCollector
    mock_BaseFactCollector_class = type('MockBaseFactCollectorClass', (BaseFactCollector,), {
        'name': 'cmdline',
        '_fact_ids': set()
    })

    # Create a mock for class CmdLineFactCollector

# Generated at 2022-06-17 01:49:27.170433
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:49:29.710421
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:49:34.503197
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:50:26.102636
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:50:28.683989
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:50:32.786486
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:50:39.274684
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline'] == {'ro': True, 'root': '/dev/sda1', 'quiet': True, 'init': '/sbin/init'}
    assert cmdline_facts['proc_cmdline'] == {'ro': True, 'root': '/dev/sda1', 'quiet': True, 'init': '/sbin/init'}

# Generated at 2022-06-17 01:50:45.194710
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:50:51.070338
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-17 01:50:56.574235
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline'] == {'BOOT_IMAGE': '/vmlinuz-4.4.0-31-generic', 'root': '/dev/mapper/ubuntu--vg-root', 'ro': True, 'quiet': True, 'splash': True, 'vt.handoff': '7'}
    assert cmdline_facts['proc_cmdline'] == {'BOOT_IMAGE': '/vmlinuz-4.4.0-31-generic', 'root': '/dev/mapper/ubuntu--vg-root', 'ro': True, 'quiet': True, 'splash': True, 'vt.handoff': '7'}

# Generated at 2022-06-17 01:51:02.340580
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import CmdLineFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    import shlex

    # Mock get_file_content
    get_file_content_mock = get_file_content
    get_file_content_mock.return_value = 'root=/dev/mapper/vg_test-lv_root ro rd.lvm.lv=vg_test/lv_root rd.lvm.lv=vg_test/lv_swap rhgb quiet LANG=en_US.UTF-8'

    # Mock shlex.split
    shlex_split_mock = sh

# Generated at 2022-06-17 01:51:13.539495
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Create a CmdLineFactCollector object
    cmdline_fact_collector = CmdLineFactCollector()

    # Create a mock module object
    module = type('', (), {})()

    # Create a mock collected_facts object
    collected_facts = type('', (), {})()

    # Call the collect method
    cmdline_facts = cmdline_fact_collector.collect(module, collected_facts)

    # Assert that the cmdline_facts is a dict
    assert isinstance(cmdline_facts, dict)

    # Assert that the cmdline_facts contains the key 'cmdline'
    assert 'cmdline' in cmdline_facts

    # Assert that the cmdline_facts contains the key 'proc_cmdline'
    assert 'proc_cmdline' in cmdline_facts

    # Assert that the cmd

# Generated at 2022-06-17 01:51:25.424073
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector._get_proc_cmdline = lambda: 'root=/dev/sda1 ro console=ttyS0,115200n8'
    cmdline_collector._parse_proc_cmdline = lambda data: data
    cmdline_collector._parse_proc_cmdline_facts = lambda data: data
    cmdline_facts = cmdline_collector.collect()
    assert cmdline_facts['cmdline'] == 'root=/dev/sda1 ro console=ttyS0,115200n8'
    assert cmdline_facts['proc_cmdline'] == 'root=/dev/sda1 ro console=ttyS0,115200n8'


# Generated at 2022-06-17 01:53:05.781883
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:53:10.454117
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-17 01:53:16.395364
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:53:26.623039
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Create a CmdLineFactCollector object
    cmdline_fact_collector = CmdLineFactCollector()

    # Create a test file
    test_file = open('/proc/cmdline', 'w')
    test_file.write('root=/dev/sda1 ro quiet')
    test_file.close()

    # Call method collect
    cmdline_facts = cmdline_fact_collector.collect()

    # Check the result
    assert cmdline_facts['cmdline']['root'] == '/dev/sda1'
    assert cmdline_facts['cmdline']['ro'] == True
    assert cmdline_facts['cmdline']['quiet'] == True
    assert cmdline_facts['proc_cmdline']['root'] == '/dev/sda1'

# Generated at 2022-06-17 01:53:33.279021
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector._get_proc_cmdline = lambda: 'BOOT_IMAGE=/vmlinuz-3.10.0-327.el7.x86_64 root=/dev/mapper/rhel-root ro crashkernel=auto rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet LANG=en_US.UTF-8'
    cmdline_facts = cmdline_collector.collect()


# Generated at 2022-06-17 01:53:39.974281
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector._get_proc_cmdline = lambda: 'foo=bar baz=qux'
    cmdline_facts = cmdline_collector.collect()
    assert cmdline_facts['cmdline'] == {'foo': 'bar', 'baz': 'qux'}
    assert cmdline_facts['proc_cmdline'] == {'foo': 'bar', 'baz': 'qux'}

    cmdline_collector = CmdLineFactCollector()
    cmdline_collector._get_proc_cmdline = lambda: 'foo=bar baz=qux baz=quux'
    cmdline_facts = cmdline_collector.collect()

# Generated at 2022-06-17 01:53:45.328538
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-17 01:53:48.362388
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:53:51.688955
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:53:56.143773
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()
