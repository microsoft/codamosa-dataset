

# Generated at 2022-06-17 01:45:18.487387
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_fact_collector = CmdLineFactCollector()
    cmdline_facts = cmdline_fact_collector.collect()
    assert cmdline_facts['cmdline']['BOOT_IMAGE'] == '/vmlinuz-3.10.0-327.el7.x86_64'
    assert cmdline_facts['proc_cmdline']['BOOT_IMAGE'] == '/vmlinuz-3.10.0-327.el7.x86_64'

# Generated at 2022-06-17 01:45:22.141616
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert isinstance(cmdline_facts, dict)
    assert 'cmdline' in cmdline_facts
    assert 'proc_cmdline' in cmdline_facts
    assert isinstance(cmdline_facts['cmdline'], dict)
    assert isinstance(cmdline_facts['proc_cmdline'], dict)

# Generated at 2022-06-17 01:45:26.556184
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:45:34.855141
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline'] == {'BOOT_IMAGE': '/vmlinuz-3.10.0-327.10.1.el7.x86_64', 'root': '/dev/mapper/rhel-root', 'ro': True, 'crashkernel': 'auto', 'rhgb': True, 'quiet': True}
    assert cmdline_facts['proc_cmdline'] == {'BOOT_IMAGE': '/vmlinuz-3.10.0-327.10.1.el7.x86_64', 'root': '/dev/mapper/rhel-root', 'ro': True, 'crashkernel': 'auto', 'rhgb': True, 'quiet': True}

# Generated at 2022-06-17 01:45:38.042660
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:45:43.918307
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Create a CmdLineFactCollector object
    cmdline_fact_collector = CmdLineFactCollector()

    # Create a mock module
    module = Mock()

    # Create a mock collected_facts
    collected_facts = Mock()

    # Call method collect of class CmdLineFactCollector
    cmdline_facts = cmdline_fact_collector.collect(module, collected_facts)

    # Assert that the cmdline_facts is not empty
    assert cmdline_facts


# Generated at 2022-06-17 01:45:47.803205
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:45:55.880937
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline']['ro'] == True
    assert cmdline_facts['cmdline']['root'] == '/dev/mapper/rhel-root'
    assert cmdline_facts['cmdline']['rd.lvm.lv'] == 'rhel/root'
    assert cmdline_facts['cmdline']['rd.lvm.lv'] == 'rhel/root'
    assert cmdline_facts['cmdline']['rhgb'] == True
    assert cmdline_facts['cmdline']['quiet'] == True
    assert cmdline_facts['cmdline']['crashkernel'] == 'auto'
    assert cmdline_facts['cmdline']['rd.lvm.lv'] == 'rhel/root'

# Generated at 2022-06-17 01:45:59.077096
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-17 01:46:12.370781
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline'] == {'BOOT_IMAGE': '/vmlinuz-3.10.0-327.el7.x86_64', 'root': '/dev/mapper/rhel-root', 'ro': True, 'crashkernel': 'auto', 'rd.lvm.lv': 'rhel/root', 'rhgb': True, 'quiet': True, 'LANG': 'en_US.UTF-8'}

# Generated at 2022-06-17 01:46:23.805292
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()
    assert CmdLineFactCollector.collect() == {}

# Generated at 2022-06-17 01:46:29.771120
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status

    # Get all the collectors
    collectors = get_collector_names()

    # Get the status of all the collectors
    status = get_collector_status()

    # Get the instance of the CmdLineFactCollector
    cmdline_collector = get_collector_instance('cmdline')

    # Get the facts from the CmdLineFactCollector
    cmdline_facts = cmdline_collector.collect()

    # Assert that the CmdLineFactCollector is in the list of collectors
    assert 'cmdline' in collectors

    # Assert that the Cmd

# Generated at 2022-06-17 01:46:33.026214
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:46:36.675621
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:46:47.754637
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline'] == {'BOOT_IMAGE': '/vmlinuz-3.10.0-693.21.1.el7.x86_64', 'root': '/dev/mapper/rhel-root', 'ro': True, 'crashkernel': 'auto', 'rhgb': True, 'quiet': True, 'LANG': 'en_US.UTF-8', 'rd.lvm.lv': 'rhel/root', 'rd.lvm.lv': 'rhel/swap', 'initrd': '/initramfs-3.10.0-693.21.1.el7.x86_64.img'}

# Generated at 2022-06-17 01:47:00.068887
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_facts = cmdline_collector.collect()
    assert cmdline_facts['cmdline'] == {'BOOT_IMAGE': '/vmlinuz-4.4.0-31-generic', 'root': '/dev/mapper/ubuntu--vg-root', 'ro': True, 'quiet': True, 'splash': True, 'vt.handoff': '7'}
    assert cmdline_facts['proc_cmdline'] == {'BOOT_IMAGE': '/vmlinuz-4.4.0-31-generic', 'root': '/dev/mapper/ubuntu--vg-root', 'ro': True, 'quiet': True, 'splash': True, 'vt.handoff': '7'}

# Generated at 2022-06-17 01:47:06.534163
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline']['root'] == '/dev/sda1'
    assert cmdline_facts['proc_cmdline']['root'] == '/dev/sda1'

# Generated at 2022-06-17 01:47:15.404746
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector._get_proc_cmdline = lambda: 'BOOT_IMAGE=/vmlinuz-3.10.0-327.el7.x86_64 root=/dev/mapper/rhel-root ro crashkernel=auto rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet LANG=en_US.UTF-8'
    cmdline_facts = cmdline_collector.collect()

# Generated at 2022-06-17 01:47:22.621659
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:47:32.104656
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()

    assert cmdline_facts['cmdline'] == {'BOOT_IMAGE': '/boot/vmlinuz-4.4.0-31-generic',
                                        'root': '/dev/mapper/ubuntu--vg-root',
                                        'ro': True,
                                        'quiet': True,
                                        'splash': True,
                                        'vt.handoff': '7'}


# Generated at 2022-06-17 01:47:44.636243
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:47:51.107112
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils._text import to_text

    # Mock the get_file_content function
    def mock_get_file_content(file_name):
        return 'root=UUID=1a2b3c4d-5e6f-7a8b-9c0d-1e2f3a4b5c6d ro quiet'

    # Mock the Collector class
    class MockCollector(Collector):
        def __init__(self):
            self.collectors = []

    # Mock the CmdLineFactCollector class
    class MockCmdLineFactCollector(CmdLineFactCollector):
        def __init__(self):
            self.name

# Generated at 2022-06-17 01:47:59.204512
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline']['ro']
    assert cmdline_facts['proc_cmdline']['ro']
    assert cmdline_facts['proc_cmdline']['root'] == '/dev/sda1'
    assert cmdline_facts['proc_cmdline']['LANG'] == 'en_US.UTF-8'
    assert cmdline_facts['proc_cmdline']['SYSFONT'] == 'latarcyrheb-sun16'
    assert cmdline_facts['proc_cmdline']['rhgb']
    assert cmdline_facts['proc_cmdline']['quiet']
    assert cmdline_facts['proc_cmdline']['rd_NO_LUKS']

# Generated at 2022-06-17 01:48:12.366352
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors import CmdLineFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Create a mock module
    mock_module = type('AnsibleModule', (object,), {'params': {}})()

    # Create a mock collected_facts
    mock_collected_facts = {}

    # Create a mock get_file_content

# Generated at 2022-06-17 01:48:15.393808
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:48:18.663052
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-17 01:48:23.547457
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:48:27.832832
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-17 01:48:34.064716
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:48:39.747559
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline'] == {'BOOT_IMAGE': '/vmlinuz-3.10.0-327.el7.x86_64', 'ro': True, 'root': '/dev/mapper/rhel-root', 'rhgb': True, 'quiet': True}
    assert cmdline_facts['proc_cmdline'] == {'BOOT_IMAGE': '/vmlinuz-3.10.0-327.el7.x86_64', 'ro': True, 'root': '/dev/mapper/rhel-root', 'rhgb': True, 'quiet': True}

# Generated at 2022-06-17 01:48:52.186285
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact = CmdLineFactCollector()
    assert cmdline_fact.name == 'cmdline'
    assert cmdline_fact._fact_ids == set()


# Generated at 2022-06-17 01:48:55.686784
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:49:06.286506
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import CmdLineFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size

# Generated at 2022-06-17 01:49:09.970028
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:49:16.367997
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:49:21.652923
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-17 01:49:27.362344
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:49:38.449682
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline']['root'] == '/dev/mapper/vg_test-lv_root'
    assert cmdline_facts['proc_cmdline']['root'] == '/dev/mapper/vg_test-lv_root'
    assert cmdline_facts['proc_cmdline']['selinux'] == '0'
    assert cmdline_facts['proc_cmdline']['crashkernel'] == 'auto'
    assert cmdline_facts['proc_cmdline']['rd_NO_LUKS'] == True
    assert cmdline_facts['proc_cmdline']['rd_NO_MD'] == True
    assert cmdline_facts['proc_cmdline']['rd_NO_DM'] == True
    assert cmdline

# Generated at 2022-06-17 01:49:45.265259
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:49:47.232015
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:50:16.066451
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-17 01:50:17.881630
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline']['root'] == '/dev/sda1'
    assert cmdline_facts['proc_cmdline']['root'] == '/dev/sda1'

# Generated at 2022-06-17 01:50:20.120839
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-17 01:50:22.737358
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline']
    assert cmdline_facts['proc_cmdline']

# Generated at 2022-06-17 01:50:32.850134
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors import CmdLineFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Create a mock module
    mock_module = type('AnsibleModule', (object,), {'params': {}})()

    # Create a mock get_file_content function
    mock_get_file_content = type('get_file_content', (object,), {'__call__': lambda self, path: 'root=/dev/sda1 ro'})()

    # Create a mock BaseFactCollector

# Generated at 2022-06-17 01:50:37.467422
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:50:43.112448
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline']['root'] == '/dev/mapper/vg_centos6-lv_root'
    assert cmdline_facts['proc_cmdline']['root'] == '/dev/mapper/vg_centos6-lv_root'
    assert cmdline_facts['cmdline']['ro'] == True
    assert cmdline_facts['proc_cmdline']['ro'] == True
    assert cmdline_facts['cmdline']['crashkernel'] == 'auto'
    assert cmdline_facts['proc_cmdline']['crashkernel'] == 'auto'
    assert cmdline_facts['cmdline']['rhgb'] == True
    assert cmdline_facts['proc_cmdline']['rhgb'] == True

# Generated at 2022-06-17 01:50:49.856359
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector._get_proc_cmdline = lambda: 'BOOT_IMAGE=/vmlinuz-3.10.0-327.el7.x86_64 root=/dev/mapper/rhel-root ro crashkernel=auto rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet LANG=en_US.UTF-8'
    cmdline_collector._parse_proc_cmdline = lambda x: x
    cmdline_collector._parse_proc_cmdline_facts = lambda x: x
    cmdline_facts = cmdline_collector.collect()

# Generated at 2022-06-17 01:50:59.642529
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Create a CmdLineFactCollector object
    cmdline_fact_collector = CmdLineFactCollector()

    # Create a test file
    test_file = open('/proc/cmdline', 'w')
    test_file.write('BOOT_IMAGE=/boot/vmlinuz-3.10.0-327.el7.x86_64 root=UUID=f9e9c9e2-f0c3-4e3f-8a3a-f1d9e7f9a1b9 ro crashkernel=auto rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet LANG=en_US.UTF-8')
    test_file.close()

    # Call method collect
    cmdline_facts = cmdline_fact_collect

# Generated at 2022-06-17 01:51:13.119811
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.cmdline import CmdLineFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_file_uid
    from ansible.module_utils.facts.utils import get_file_gid

# Generated at 2022-06-17 01:52:02.879026
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-17 01:52:06.127639
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:52:13.128744
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:52:14.838464
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:52:19.752790
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:52:25.142191
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:52:28.223419
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:52:30.173770
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-17 01:52:33.537709
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:52:42.265735
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Test with empty data
    cmdline_collector = CmdLineFactCollector()
    cmdline_facts = cmdline_collector.collect()
    assert cmdline_facts == {}

    # Test with valid data
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector._get_proc_cmdline = lambda: 'BOOT_IMAGE=/vmlinuz-3.10.0-327.el7.x86_64 root=/dev/mapper/cl-root ro crashkernel=auto rd.lvm.lv=cl/root rd.lvm.lv=cl/swap rhgb quiet LANG=en_US.UTF-8'
    cmdline_facts = cmdline_collector.collect()

# Generated at 2022-06-17 01:54:24.081943
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:54:34.831395
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Test with empty data
    collector = CmdLineFactCollector()
    data = ''
    result = collector._parse_proc_cmdline(data)
    assert result == {}

    # Test with data
    collector = CmdLineFactCollector()
    data = 'BOOT_IMAGE=/vmlinuz-3.10.0-327.el7.x86_64 root=/dev/mapper/rhel-root ro crashkernel=auto rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet LANG=en_US.UTF-8'
    result = collector._parse_proc_cmdline(data)
    assert result['BOOT_IMAGE'] == '/vmlinuz-3.10.0-327.el7.x86_64'

# Generated at 2022-06-17 01:54:40.749593
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline']['root'] == '/dev/mapper/centos-root'
    assert cmdline_facts['proc_cmdline']['root'] == '/dev/mapper/centos-root'
    assert cmdline_facts['proc_cmdline']['ro'] == True
    assert cmdline_facts['proc_cmdline']['rd.lvm.lv'] == 'centos/root'
    assert cmdline_facts['proc_cmdline']['rd.lvm.lv'] == 'centos/root'
    assert cmdline_facts['proc_cmdline']['LANG'] == 'en_US.UTF-8'

# Generated at 2022-06-17 01:54:48.645847
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline']['root'] == '/dev/sda1'
    assert cmdline_facts['proc_cmdline']['root'] == '/dev/sda1'
    assert cmdline_facts['proc_cmdline']['root'] == '/dev/sda1'
    assert cmdline_facts['proc_cmdline']['root'] == '/dev/sda1'

# Generated at 2022-06-17 01:54:50.270201
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:54:52.821980
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:54:54.614286
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:54:56.258514
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-17 01:55:03.133718
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:55:07.742672
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = CmdLineFactCollector()
    assert cmdline_facts.name == 'cmdline'
    assert cmdline_facts._fact_ids == set()
