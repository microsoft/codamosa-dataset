

# Generated at 2022-06-17 01:45:18.539869
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector._get_proc_cmdline = lambda: 'foo=bar baz=qux'
    cmdline_facts = cmdline_collector.collect()
    assert cmdline_facts['cmdline'] == {'foo': 'bar', 'baz': 'qux'}
    assert cmdline_facts['proc_cmdline'] == {'foo': 'bar', 'baz': 'qux'}


# Generated at 2022-06-17 01:45:22.450094
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline']['root'] == '/dev/mapper/centos-root'
    assert cmdline_facts['proc_cmdline']['root'] == '/dev/mapper/centos-root'
    assert cmdline_facts['proc_cmdline']['ro'] == True

# Generated at 2022-06-17 01:45:30.861875
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector._get_proc_cmdline = lambda: 'foo=bar baz=qux'
    cmdline_facts = cmdline_collector.collect()
    assert cmdline_facts['cmdline'] == {'foo': 'bar', 'baz': 'qux'}
    assert cmdline_facts['proc_cmdline'] == {'foo': 'bar', 'baz': 'qux'}


# Generated at 2022-06-17 01:45:36.188509
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:45:39.530352
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:45:45.069674
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:45:52.889955
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    result = collector.collect()
    assert result['cmdline'] == {'BOOT_IMAGE': '/vmlinuz-3.13.0-24-generic', 'root': '/dev/mapper/ubuntu--vg-root', 'ro': True, 'quiet': True, 'splash': True, 'vt.handoff': '7'}
    assert result['proc_cmdline'] == {'BOOT_IMAGE': '/vmlinuz-3.13.0-24-generic', 'root': '/dev/mapper/ubuntu--vg-root', 'ro': True, 'quiet': True, 'splash': True, 'vt.handoff': '7'}

# Generated at 2022-06-17 01:45:54.601562
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-17 01:45:56.995233
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Create a CmdLineFactCollector object
    cmdline_fact_collector = CmdLineFactCollector()

    # Create a dictionary of facts
    collected_facts = {}

    # Call method collect of CmdLineFactCollector
    cmdline_facts = cmdline_fact_collector.collect(collected_facts=collected_facts)

    # Assert that the returned dictionary of facts is not empty
    assert cmdline_facts

# Generated at 2022-06-17 01:46:02.574781
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline']['ro'] == True
    assert cmdline_facts['cmdline']['root'] == '/dev/sda1'
    assert cmdline_facts['cmdline']['rw'] == True
    assert cmdline_facts['cmdline']['quiet'] == True
    assert cmdline_facts['cmdline']['init'] == '/sbin/init'
    assert cmdline_facts['cmdline']['rd_NO_PLYMOUTH'] == True
    assert cmdline_facts['cmdline']['LANG'] == 'en_US.UTF-8'
    assert cmdline_facts['cmdline']['SYSFONT'] == 'latarcyrheb-sun16'
    assert cmdline_facts

# Generated at 2022-06-17 01:46:16.772344
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:46:18.979619
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:46:24.785783
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Create a CmdLineFactCollector object
    cmdline_fact_collector = CmdLineFactCollector()
    # Create a dict object
    collected_facts = {}
    # Call method collect of class CmdLineFactCollector
    cmdline_facts = cmdline_fact_collector.collect(collected_facts=collected_facts)
    # Assert that the dict object is not empty
    assert cmdline_facts

# Generated at 2022-06-17 01:46:28.217545
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:46:39.339072
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import CmdLineFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_content

# Generated at 2022-06-17 01:46:42.116411
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:46:51.432854
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Test with empty data
    collector = CmdLineFactCollector()
    assert collector.collect() == {}

    # Test with valid data
    collector = CmdLineFactCollector()
    collector._get_proc_cmdline = lambda: 'BOOT_IMAGE=/vmlinuz-3.10.0-327.el7.x86_64 root=/dev/mapper/rhel-root ro crashkernel=auto rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet LANG=en_US.UTF-8'

# Generated at 2022-06-17 01:47:00.964861
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline']['root'] == '/dev/mapper/vg_centos-lv_root'
    assert cmdline_facts['cmdline']['ro'] == True
    assert cmdline_facts['cmdline']['crashkernel'] == 'auto'
    assert cmdline_facts['cmdline']['rd_NO_LUKS'] == True
    assert cmdline_facts['cmdline']['rd_NO_LVM'] == True
    assert cmdline_facts['cmdline']['rd_NO_MD'] == True
    assert cmdline_facts['cmdline']['rd_NO_DM'] == True
    assert cmdline_facts['cmdline']['LANG'] == 'en_US.UTF-8'
   

# Generated at 2022-06-17 01:47:09.277760
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()

    assert isinstance(cmdline_facts, dict)
    assert 'cmdline' in cmdline_facts
    assert 'proc_cmdline' in cmdline_facts
    assert isinstance(cmdline_facts['cmdline'], dict)
    assert isinstance(cmdline_facts['proc_cmdline'], dict)

# Generated at 2022-06-17 01:47:14.523713
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:47:26.007414
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:47:33.138499
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector._get_proc_cmdline = lambda: 'BOOT_IMAGE=/vmlinuz-4.4.0-72-generic root=UUID=f7c6e9e6-8c6a-4b1e-b1c0-9c8d3d9a9c7b ro quiet splash vt.handoff=7'
    cmdline_collector._parse_proc_cmdline = lambda data: data
    cmdline_collector._parse_proc_cmdline_facts = lambda data: data

    cmdline_facts = cmdline_collector.collect()


# Generated at 2022-06-17 01:47:43.564655
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Create a CmdLineFactCollector object
    cmdline_fact_collector = CmdLineFactCollector()

    # Create a dictionary of expected facts

# Generated at 2022-06-17 01:47:48.785514
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = CmdLineFactCollector()
    assert cmdline_facts.name == 'cmdline'
    assert cmdline_facts._fact_ids == set()


# Generated at 2022-06-17 01:47:57.620678
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import CmdLineFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['!all', 'cmdline']
            self.params['gather_timeout'] = 10

    class MockCollector(Collector):
        def __init__(self, module):
            super(MockCollector, self).__init__(module)
            self.collectors = [CmdLineFactCollector(module)]


# Generated at 2022-06-17 01:48:06.646303
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import CmdLineFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_content

# Generated at 2022-06-17 01:48:17.527493
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_fact_collector = CmdLineFactCollector()
    cmdline_fact_collector._get_proc_cmdline = lambda: 'BOOT_IMAGE=/vmlinuz-3.10.0-327.el7.x86_64 root=/dev/mapper/rhel-root ro crashkernel=auto rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet LANG=en_US.UTF-8'
    cmdline_facts = cmdline_fact_collector.collect()
    assert cmdline_facts['cmdline']['BOOT_IMAGE'] == '/vmlinuz-3.10.0-327.el7.x86_64'

# Generated at 2022-06-17 01:48:23.058003
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-17 01:48:27.808155
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-17 01:48:34.064606
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:48:55.489441
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:49:00.958177
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector._get_proc_cmdline = lambda: 'foo=bar baz=qux'
    cmdline_facts = cmdline_collector.collect()
    assert cmdline_facts == {
        'cmdline': {
            'foo': 'bar',
            'baz': 'qux',
        },
        'proc_cmdline': {
            'foo': 'bar',
            'baz': 'qux',
        },
    }

# Generated at 2022-06-17 01:49:12.500473
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline']['root'] == '/dev/sda1'
    assert cmdline_facts['proc_cmdline']['root'] == '/dev/sda1'
    assert cmdline_facts['proc_cmdline']['ro'] == True
    assert cmdline_facts['proc_cmdline']['console'] == 'ttyS0,115200n8'
    assert cmdline_facts['proc_cmdline']['console'] == 'ttyS0,115200n8'
    assert cmdline_facts['proc_cmdline']['console'] == 'ttyS0,115200n8'
    assert cmdline_facts['proc_cmdline']['console'] == 'ttyS0,115200n8'
    assert cmdline

# Generated at 2022-06-17 01:49:13.414998
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector.collect()

# Generated at 2022-06-17 01:49:16.922379
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:49:19.576804
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline']
    assert cmdline_facts['proc_cmdline']

# Generated at 2022-06-17 01:49:23.564581
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline']['root'] == '/dev/mapper/vg_centos-lv_root'
    assert cmdline_facts['proc_cmdline']['root'] == '/dev/mapper/vg_centos-lv_root'

# Generated at 2022-06-17 01:49:28.820198
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:49:34.126051
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-17 01:49:38.496473
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-17 01:50:32.153881
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline']['root'] == '/dev/mapper/vg_centos-lv_root'
    assert cmdline_facts['proc_cmdline']['root'] == '/dev/mapper/vg_centos-lv_root'

# Generated at 2022-06-17 01:50:41.259436
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline'] == {'BOOT_IMAGE': '/vmlinuz-3.10.0-327.el7.x86_64', 'root': '/dev/mapper/rhel-root', 'ro': True, 'crashkernel': 'auto', 'rhgb': True, 'quiet': True}
    assert cmdline_facts['proc_cmdline'] == {'BOOT_IMAGE': '/vmlinuz-3.10.0-327.el7.x86_64', 'root': '/dev/mapper/rhel-root', 'ro': True, 'crashkernel': 'auto', 'rhgb': True, 'quiet': True}

# Generated at 2022-06-17 01:50:45.105338
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-17 01:50:50.273461
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()


# Generated at 2022-06-17 01:50:52.836484
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:50:57.606890
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:51:03.150573
# Unit test for method collect of class CmdLineFactCollector

# Generated at 2022-06-17 01:51:12.019198
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector._get_proc_cmdline = lambda: 'foo=bar baz=qux'
    cmdline_facts = cmdline_collector.collect()
    assert cmdline_facts['cmdline'] == {'foo': 'bar', 'baz': 'qux'}
    assert cmdline_facts['proc_cmdline'] == {'foo': 'bar', 'baz': 'qux'}


# Generated at 2022-06-17 01:51:17.612417
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline'] == {'BOOT_IMAGE': '/vmlinuz-4.4.0-31-generic', 'root': '/dev/mapper/ubuntu--vg-root', 'ro': True, 'quiet': True, 'splash': True, 'vt.handoff': '7'}
    assert cmdline_facts['proc_cmdline'] == {'BOOT_IMAGE': '/vmlinuz-4.4.0-31-generic', 'root': '/dev/mapper/ubuntu--vg-root', 'ro': True, 'quiet': True, 'splash': True, 'vt.handoff': '7'}

# Generated at 2022-06-17 01:51:22.390529
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:52:58.223591
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert isinstance(cmdline_facts, dict)
    assert 'cmdline' in cmdline_facts
    assert 'proc_cmdline' in cmdline_facts
    assert isinstance(cmdline_facts['cmdline'], dict)
    assert isinstance(cmdline_facts['proc_cmdline'], dict)

# Generated at 2022-06-17 01:52:59.794259
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline']['ro'] == True
    assert cmdline_facts['proc_cmdline']['ro'] == True

# Generated at 2022-06-17 01:53:05.492373
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:53:14.330927
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline'] == {'BOOT_IMAGE': '/vmlinuz-3.10.0-327.el7.x86_64', 'ro': True, 'root': '/dev/mapper/rhel-root', 'rhgb': True, 'quiet': True}
    assert cmdline_facts['proc_cmdline'] == {'BOOT_IMAGE': '/vmlinuz-3.10.0-327.el7.x86_64', 'ro': True, 'root': '/dev/mapper/rhel-root', 'rhgb': True, 'quiet': True}

# Generated at 2022-06-17 01:53:17.228385
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-17 01:53:20.719774
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector()
    cmdline_facts.collect()

# Generated at 2022-06-17 01:53:27.604063
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import set_collector_status
    from ansible.module_utils.facts.collector import set_collectors
    from ansible.module_utils.facts.utils import get_file_content

    # Test with empty file
    def get_file_content_empty(path):
        return ''

    # Test with file with content

# Generated at 2022-06-17 01:53:38.683415
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.cmdline import CmdLineFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_content

# Generated at 2022-06-17 01:53:45.494846
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:53:51.301186
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()
