

# Generated at 2022-06-17 01:45:15.557712
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:45:20.733898
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:45:24.318611
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline']['ro'] == True
    assert cmdline_facts['proc_cmdline']['ro'] == True

# Generated at 2022-06-17 01:45:33.676769
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()

# Generated at 2022-06-17 01:45:43.637273
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collectors.cmdline import CmdLineFactCollector

    # Create a mock module
    module = MagicMock()

    # Create a mock Collector
    collector = MagicMock(spec=Collector)
    collector.get_file_content = get_file_content

    # Create a CmdLineFactCollector object
    cmdline_fact_collector = CmdLineFactCollector(module=module, collector=collector)

    # Create a mock collected_facts
    collected_facts = {}

    # Test when /proc/cmdline is empty

# Generated at 2022-06-17 01:45:47.584662
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:45:52.247741
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-17 01:45:54.234777
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:45:59.196494
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:46:12.005789
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline'] == {'BOOT_IMAGE': '/vmlinuz-3.10.0-327.el7.x86_64', 'root': '/dev/mapper/centos-root', 'ro': True, 'crashkernel': 'auto', 'rhgb': True, 'quiet': True}
    assert cmdline_facts['proc_cmdline'] == {'BOOT_IMAGE': '/vmlinuz-3.10.0-327.el7.x86_64', 'root': '/dev/mapper/centos-root', 'ro': True, 'crashkernel': ['auto', 'auto'], 'rhgb': True, 'quiet': True}

# Generated at 2022-06-17 01:46:23.920556
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline']
    assert cmdline_facts['proc_cmdline']

# Generated at 2022-06-17 01:46:29.920354
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector._get_proc_cmdline = lambda: 'BOOT_IMAGE=/vmlinuz-3.10.0-327.el7.x86_64 root=/dev/mapper/rhel-root ro crashkernel=auto rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet LANG=en_US.UTF-8'
    cmdline_facts = cmdline_collector.collect()
    assert cmdline_facts['cmdline']['BOOT_IMAGE'] == '/vmlinuz-3.10.0-327.el7.x86_64'
    assert cmdline_facts['cmdline']['LANG'] == 'en_US.UTF-8'
    assert cmdline

# Generated at 2022-06-17 01:46:39.817323
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockCollector(Collector):
        def __init__(self):
            self.collectors = [CmdLineFactCollector()]

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = [CmdLineFactCollector()]

    class MockCmdLineFactCollector(CmdLineFactCollector):
        def __init__(self):
            self.collectors = [CmdLineFactCollector()]

    # Test Collector class
    collector = MockCollector()

# Generated at 2022-06-17 01:46:49.866737
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline'] == {'BOOT_IMAGE': '/vmlinuz-3.10.0-327.el7.x86_64', 'root': '/dev/mapper/rhel-root', 'ro': True, 'LANG': 'en_US.UTF-8', 'crashkernel': 'auto', 'rd.lvm.lv': 'rhel/root', 'rhgb': True, 'quiet': True}

# Generated at 2022-06-17 01:46:51.768583
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:46:55.913789
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:46:58.722216
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-17 01:47:00.917593
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:47:06.760385
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:47:07.912487
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = CmdLineFactCollector()
    assert cmdline_facts.name == 'cmdline'
    assert cmdline_facts._fact_ids == set()


# Generated at 2022-06-17 01:47:30.028624
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:47:42.340272
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector._get_proc_cmdline = lambda: 'BOOT_IMAGE=/vmlinuz-3.10.0-327.el7.x86_64 root=/dev/mapper/rhel-root ro crashkernel=auto rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet LANG=en_US.UTF-8'
    cmdline_facts = cmdline_collector.collect()
    assert cmdline_facts['cmdline']['BOOT_IMAGE'] == '/vmlinuz-3.10.0-327.el7.x86_64'
    assert cmdline_facts['cmdline']['root'] == '/dev/mapper/rhel-root'
    assert cmd

# Generated at 2022-06-17 01:47:43.996546
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_fact_collector = CmdLineFactCollector()
    cmdline_fact_collector.collect()

# Generated at 2022-06-17 01:47:52.521273
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Create a CmdLineFactCollector object
    cmdline_fact_collector = CmdLineFactCollector()

    # Create a mock module
    module = type('', (), {})()

    # Create a mock collected_facts
    collected_facts = {}

    # Call method collect of CmdLineFactCollector
    cmdline_facts = cmdline_fact_collector.collect(module, collected_facts)

    # Assert that cmdline_facts is not empty
    assert cmdline_facts

# Generated at 2022-06-17 01:47:55.736586
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:48:03.922385
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_fact_collector = CmdLineFactCollector()
    cmdline_facts = cmdline_fact_collector.collect()
    assert cmdline_facts['cmdline']['BOOT_IMAGE'] == '/vmlinuz-3.10.0-327.el7.x86_64'
    assert cmdline_facts['proc_cmdline']['BOOT_IMAGE'] == '/vmlinuz-3.10.0-327.el7.x86_64'

# Generated at 2022-06-17 01:48:13.275361
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_fact_collector = CmdLineFactCollector()
    cmdline_fact_collector._get_proc_cmdline = lambda: 'BOOT_IMAGE=/vmlinuz-4.4.0-21-generic root=UUID=f5b5f5b5-f5b5-f5b5-f5b5-f5b5f5b5f5b5 ro quiet splash vt.handoff=7'

# Generated at 2022-06-17 01:48:20.634774
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector._get_proc_cmdline = lambda: 'foo=bar baz=qux'
    cmdline_facts = cmdline_collector.collect()
    assert cmdline_facts['cmdline'] == {'foo': 'bar', 'baz': 'qux'}
    assert cmdline_facts['proc_cmdline'] == {'foo': 'bar', 'baz': 'qux'}


# Generated at 2022-06-17 01:48:23.766930
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:48:26.174842
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:49:12.145826
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline']['root'] == '/dev/sda1'
    assert cmdline_facts['proc_cmdline']['root'] == '/dev/sda1'
    assert cmdline_facts['proc_cmdline']['ro'] == True
    assert cmdline_facts['proc_cmdline']['quiet'] == True
    assert cmdline_facts['proc_cmdline']['console'] == 'ttyS0,115200'
    assert cmdline_facts['proc_cmdline']['console'] == 'ttyS0,115200'
    assert cmdline_facts['proc_cmdline']['console'] == 'ttyS0,115200'

# Generated at 2022-06-17 01:49:16.696295
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:49:18.283178
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()


# Generated at 2022-06-17 01:49:22.158696
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline']['root'] == '/dev/sda1'
    assert cmdline_facts['proc_cmdline']['root'] == '/dev/sda1'
    assert cmdline_facts['proc_cmdline']['console'] == ['ttyS0', 'tty0']

# Generated at 2022-06-17 01:49:28.085276
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()

# Generated at 2022-06-17 01:49:38.510118
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline'] == {'ro': True, 'root': '/dev/mapper/vg_ansible-lv_root', 'rd_NO_LUKS': True, 'rd_NO_MD': True, 'rd_NO_DM': True, 'LANG': 'en_US.UTF-8', 'SYSFONT': 'latarcyrheb-sun16', 'rhgb': True, 'quiet': True, 'rd_LVM_LV': 'vg_ansible/lv_root', 'rd_LVM_LV': 'vg_ansible/lv_swap', 'initrd': '/initramfs-2.6.32-358.el6.x86_64.img'}
    assert cmdline_facts['proc_cmdline']

# Generated at 2022-06-17 01:49:48.445529
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector._get_proc_cmdline = lambda: 'BOOT_IMAGE=/vmlinuz-3.10.0-327.el7.x86_64 root=/dev/mapper/rhel-root ro crashkernel=auto rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet LANG=en_US.UTF-8'
    cmdline_collector._parse_proc_cmdline = lambda x: x
    cmdline_collector._parse_proc_cmdline_facts = lambda x: x
    cmdline_facts = cmdline_collector.collect()

# Generated at 2022-06-17 01:49:52.277450
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:50:03.007239
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Create a CmdLineFactCollector object
    cmdline_fact_collector = CmdLineFactCollector()

    # Create a test file
    test_file = open("/tmp/test_file", "w")
    test_file.write("test_key=test_value test_key2=test_value2")
    test_file.close()

    # Create a test module
    test_module = type('test_module', (object,), {'_get_file_content': lambda self, path: open(path, "r").read()})

    # Collect facts
    facts = cmdline_fact_collector.collect(module=test_module)

    # Assert facts
    assert facts['cmdline'] == {'test_key': 'test_value', 'test_key2': 'test_value2'}
   

# Generated at 2022-06-17 01:50:08.741739
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:50:57.606020
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:51:07.912778
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline']['BOOT_IMAGE'] == '/vmlinuz-4.4.0-72-generic'
    assert cmdline_facts['proc_cmdline']['BOOT_IMAGE'] == '/vmlinuz-4.4.0-72-generic'
    assert cmdline_facts['proc_cmdline']['root'] == '/dev/mapper/ubuntu--vg-root'
    assert cmdline_facts['proc_cmdline']['ro'] == True
    assert cmdline_facts['proc_cmdline']['quiet'] == True
    assert cmdline_facts['proc_cmdline']['splash'] == True
    assert cmdline_facts['proc_cmdline']['vt.handoff'] == '7'

# Generated at 2022-06-17 01:51:10.839757
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-17 01:51:15.843172
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.cmdline import CmdLineFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_status
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_status

# Generated at 2022-06-17 01:51:19.852468
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact = CmdLineFactCollector()
    assert cmdline_fact.name == 'cmdline'
    assert cmdline_fact._fact_ids == set()


# Generated at 2022-06-17 01:51:29.268224
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import CmdLineFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # create a mock module
    module = Mock()

    # create a mock Collector
    collector = Mock(Collector)

    # create a mock BaseFactCollector
    base_fact_collector = Mock(BaseFactCollector)

    # create a CmdLineFactCollector object
    cmdline_fact_collector = CmdLineFactCollector()

    # create a mock get_file_content

# Generated at 2022-06-17 01:51:35.165745
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:51:41.050816
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:51:51.284809
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline'] == {'BOOT_IMAGE': '/vmlinuz-3.10.0-693.el7.x86_64', 'ro': True, 'root': '/dev/mapper/rhel-root', 'rhgb': True, 'quiet': True, 'LANG': 'en_US.UTF-8', 'rd.lvm.lv': 'rhel/root', 'rd.lvm.lv': 'rhel/swap', 'crashkernel': 'auto', 'rd.lvm.lv': 'rhel/home'}

# Generated at 2022-06-17 01:51:58.581760
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Create a CmdLineFactCollector object
    cmdline_fact_collector = CmdLineFactCollector()

    # Create a mock module
    module = type('module', (object,), {'params': {'gather_subset': ['!all', 'cmdline']}})

    # Create a mock collected_facts
    collected_facts = {}

    # Call method collect of CmdLineFactCollector
    cmdline_facts = cmdline_fact_collector.collect(module=module, collected_facts=collected_facts)

    # Assert that method collect returned a dictionary
    assert isinstance(cmdline_facts, dict)

    # Assert that method collect returned a dictionary with keys cmdline and proc_cmdline
    assert 'cmdline' in cmdline_facts
    assert 'proc_cmdline' in cmdline_facts



# Generated at 2022-06-17 01:52:56.324792
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:52:57.979688
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert 'cmdline' in cmdline_facts
    assert 'proc_cmdline' in cmdline_facts

# Generated at 2022-06-17 01:53:00.886666
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert isinstance(cmdline_facts, dict)
    assert 'cmdline' in cmdline_facts
    assert isinstance(cmdline_facts['cmdline'], dict)
    assert 'proc_cmdline' in cmdline_facts
    assert isinstance(cmdline_facts['proc_cmdline'], dict)

# Generated at 2022-06-17 01:53:06.471632
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:53:11.078303
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-17 01:53:16.206976
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-17 01:53:21.626129
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-17 01:53:27.911010
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:53:37.183744
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector._get_proc_cmdline = lambda: 'foo=bar baz=qux'
    cmdline_collector._parse_proc_cmdline = lambda data: data
    cmdline_collector._parse_proc_cmdline_facts = lambda data: data
    result = cmdline_collector.collect()
    assert result == {'cmdline': 'foo=bar baz=qux', 'proc_cmdline': 'foo=bar baz=qux'}

# Generated at 2022-06-17 01:53:39.973797
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()
