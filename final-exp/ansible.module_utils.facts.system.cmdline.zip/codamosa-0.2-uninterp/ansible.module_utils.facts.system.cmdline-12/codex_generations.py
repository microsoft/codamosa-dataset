

# Generated at 2022-06-17 01:45:16.995887
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:45:20.658619
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-17 01:45:24.828393
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.cmdline import CmdLineFactCollector

    # Create a Collector object
    collector = Collector()

    # Create a CmdLineFactCollector object
    cmdline_collector = CmdLineFactCollector()

    # Add the CmdLineFactCollector object to the Collector object
    collector.add_collector(cmdline_collector)

    # Collect facts
    facts = collector.collect(module=None, collected_facts=None)

    # Test if the facts are empty
    assert facts == {}

# Generated at 2022-06-17 01:45:28.268631
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:45:30.862313
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector.collect()

# Generated at 2022-06-17 01:45:42.212788
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Initialize the class
    cmdline_fact_collector = CmdLineFactCollector()

    # Create a mock module
    module = type('', (), {})()

    # Create a mock collected_facts
    collected_facts = type('', (), {})()

    # Call the method collect of the class CmdLineFactCollector
    result = cmdline_fact_collector.collect(module, collected_facts)

    # Check the result

# Generated at 2022-06-17 01:45:45.984607
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:45:49.198515
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:45:52.597241
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:45:57.090870
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline'] == {'BOOT_IMAGE': '/boot/vmlinuz-3.10.0-327.el7.x86_64',
                                        'crashkernel': 'auto',
                                        'rd.lvm.lv': 'rhel/root',
                                        'rhgb': 'quiet',
                                        'root': '/dev/mapper/rhel-root',
                                        'ro': True,
                                        'rootflags': 'defaults',
                                        'rw': True,
                                        'selinux': '0',
                                        'systemd.debug-shell': '0',
                                        'systemd.log_level': 'debug',
                                        'systemd.unit': 'emergency.target'}
    assert cmd

# Generated at 2022-06-17 01:46:11.175052
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:46:22.248015
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Create a CmdLineFactCollector object
    cmdline_fact_collector = CmdLineFactCollector()

    # Create a mock module
    module = type('', (), {})()

    # Create a mock collected_facts
    collected_facts = {}

    # Call method collect of CmdLineFactCollector
    cmdline_facts = cmdline_fact_collector.collect(module, collected_facts)

    # Assert that the cmdline_facts is not empty
    assert cmdline_facts

    # Assert that the cmdline_facts is a dict
    assert isinstance(cmdline_facts, dict)

    # Assert that the cmdline_facts contains the keys 'cmdline' and 'proc_cmdline'
    assert 'cmdline' in cmdline_facts
    assert 'proc_cmdline' in cmdline_facts

   

# Generated at 2022-06-17 01:46:27.959101
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline'] == {'BOOT_IMAGE': '/vmlinuz-3.10.0-327.el7.x86_64', 'ro': True, 'root': '/dev/mapper/rhel-root', 'rhgb': True, 'quiet': True}
    assert cmdline_facts['proc_cmdline'] == {'BOOT_IMAGE': '/vmlinuz-3.10.0-327.el7.x86_64', 'ro': True, 'root': '/dev/mapper/rhel-root', 'rhgb': True, 'quiet': True}

# Generated at 2022-06-17 01:46:34.080705
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert isinstance(cmdline_facts, dict)
    assert 'cmdline' in cmdline_facts
    assert 'proc_cmdline' in cmdline_facts
    assert isinstance(cmdline_facts['cmdline'], dict)
    assert isinstance(cmdline_facts['proc_cmdline'], dict)

# Generated at 2022-06-17 01:46:37.648265
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:46:47.828663
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline'] == {'BOOT_IMAGE': '/vmlinuz-3.10.0-327.el7.x86_64', 'root': '/dev/mapper/centos-root', 'ro': True, 'crashkernel': 'auto', 'rhgb': True, 'quiet': True}
    assert cmdline_facts['proc_cmdline'] == {'BOOT_IMAGE': '/vmlinuz-3.10.0-327.el7.x86_64', 'root': '/dev/mapper/centos-root', 'ro': True, 'crashkernel': 'auto', 'rhgb': True, 'quiet': True}

# Generated at 2022-06-17 01:46:54.276071
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:46:57.398933
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-17 01:47:03.601628
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector._get_proc_cmdline = lambda: 'foo=bar baz=qux'
    cmdline_facts = cmdline_collector.collect()
    assert cmdline_facts['cmdline'] == {'foo': 'bar', 'baz': 'qux'}
    assert cmdline_facts['proc_cmdline'] == {'foo': 'bar', 'baz': 'qux'}

# Generated at 2022-06-17 01:47:11.609854
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector._get_proc_cmdline = lambda: 'foo=bar baz=qux'
    assert cmdline_collector.collect() == {
        'cmdline': {'foo': 'bar', 'baz': 'qux'},
        'proc_cmdline': {'foo': 'bar', 'baz': 'qux'},
    }


# Generated at 2022-06-17 01:47:35.441216
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:47:39.675360
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:47:48.626664
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector._get_proc_cmdline = lambda: 'BOOT_IMAGE=/vmlinuz-3.10.0-327.el7.x86_64 root=/dev/mapper/rhel-root ro crashkernel=auto rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet LANG=en_US.UTF-8'
    cmdline_collector._parse_proc_cmdline = lambda x: x
    cmdline_collector._parse_proc_cmdline_facts = lambda x: x
    cmdline_facts = cmdline_collector.collect()

# Generated at 2022-06-17 01:47:52.144556
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:47:54.702425
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline']
    assert cmdline_facts['proc_cmdline']

# Generated at 2022-06-17 01:48:05.763605
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Create a CmdLineFactCollector object
    cmdline_collector = CmdLineFactCollector()

    # Create a mock module object
    class MockModule(object):
        def __init__(self):
            self.params = {}

    module = MockModule()

    # Create a mock collected_facts object
    collected_facts = {}

    # Call method collect of CmdLineFactCollector
    cmdline_facts = cmdline_collector.collect(module=module, collected_facts=collected_facts)

    # Assert that the cmdline_facts is not empty
    assert cmdline_facts

    # Assert that the cmdline_facts is a dict
    assert isinstance(cmdline_facts, dict)

    # Assert that the cmdline_facts has the key 'cmdline'
    assert 'cmdline' in cmdline

# Generated at 2022-06-17 01:48:10.329959
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline']['root'] == '/dev/mapper/centos-root'
    assert cmdline_facts['proc_cmdline']['root'] == '/dev/mapper/centos-root'
    assert cmdline_facts['proc_cmdline']['ro'] == True
    assert cmdline_facts['proc_cmdline']['quiet'] == True
    assert cmdline_facts['proc_cmdline']['console'] == 'tty0'
    assert cmdline_facts['proc_cmdline']['console'] == 'ttyS0'
    assert cmdline_facts['proc_cmdline']['net.ifnames'] == '0'

# Generated at 2022-06-17 01:48:15.800435
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Create a CmdLineFactCollector object
    cmdline_fact_collector = CmdLineFactCollector()

    # Create a mock module
    module = type('', (), {})()

    # Create a mock collected_facts
    collected_facts = type('', (), {})()

    # Call method collect of class CmdLineFactCollector
    cmdline_facts = cmdline_fact_collector.collect(module, collected_facts)

    # Assert that the result is not empty
    assert cmdline_facts

# Generated at 2022-06-17 01:48:22.241561
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline'] == {'BOOT_IMAGE': '/vmlinuz-3.10.0-327.el7.x86_64', 'root': '/dev/mapper/rhel-root', 'ro': True, 'crashkernel': 'auto', 'rhgb': True, 'quiet': True}
    assert cmdline_facts['proc_cmdline'] == {'BOOT_IMAGE': '/vmlinuz-3.10.0-327.el7.x86_64', 'root': '/dev/mapper/rhel-root', 'ro': True, 'crashkernel': 'auto', 'rhgb': True, 'quiet': True}

# Generated at 2022-06-17 01:48:29.327910
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors import CmdLineFactCollector

    # Create a new instance of CmdLineFactCollector
    cmdline_fact_collector = CmdLineFactCollector()

    # Create a new instance of FactCollector
    fact_collector = FactCollector()

    # Add the CmdLineFactCollector instance to the FactCollector instance
    fact_collector.add_collector(cmdline_fact_collector)

    # Create a new instance of BaseFactCollector
    base_fact_collector = BaseFactCollector()

    # Create a new instance of CmdLineFactCollector
    cmdline_fact_collector = CmdLineFact

# Generated at 2022-06-17 01:48:53.019588
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_fact_collector = CmdLineFactCollector()
    cmdline_fact_collector._get_proc_cmdline = lambda: 'BOOT_IMAGE=/vmlinuz-3.10.0-327.el7.x86_64 root=/dev/mapper/rhel-root ro crashkernel=auto rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet LANG=en_US.UTF-8'
    cmdline_facts = cmdline_fact_collector.collect()
    assert cmdline_facts['cmdline']['BOOT_IMAGE'] == '/vmlinuz-3.10.0-327.el7.x86_64'

# Generated at 2022-06-17 01:49:03.008622
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline'] == {'BOOT_IMAGE': '/vmlinuz-3.10.0-327.el7.x86_64', 'ro': True, 'root': '/dev/mapper/rhel-root', 'rhgb': True, 'quiet': True, 'LANG': 'en_US.UTF-8', 'crashkernel': 'auto'}

# Generated at 2022-06-17 01:49:08.013346
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:49:11.555911
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:49:13.151164
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-17 01:49:16.477672
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-17 01:49:19.115461
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:49:29.236118
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline'] == {'BOOT_IMAGE': '/boot/vmlinuz-4.15.0-20-generic', 'root': '/dev/mapper/ubuntu--vg-root', 'ro': True, 'quiet': True, 'splash': True, 'vt.handoff': '1'}
    assert cmdline_facts['proc_cmdline'] == {'BOOT_IMAGE': '/boot/vmlinuz-4.15.0-20-generic', 'root': '/dev/mapper/ubuntu--vg-root', 'ro': True, 'quiet': True, 'splash': True, 'vt.handoff': '1'}

# Generated at 2022-06-17 01:49:37.906342
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector

    class TestCollector(Collector):
        def __init__(self, module=None, collected_facts=None):
            super(TestCollector, self).__init__(module=module, collected_facts=collected_facts)
            self.collectors = [CmdLineFactCollector(module=module, collected_facts=collected_facts)]

    test_collector = TestCollector()
    test_collector.collect()
    assert 'cmdline' in test_collector.collected_facts
    assert 'proc_cmdline' in test_collector.collected_facts

# Generated at 2022-06-17 01:49:45.170850
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:50:41.161939
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = {}

# Generated at 2022-06-17 01:50:45.070817
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-17 01:50:55.539399
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Create a CmdLineFactCollector object
    cmdline_fact_collector = CmdLineFactCollector()

    # Create a test file
    test_file = open('/proc/cmdline', 'w')
    test_file.write('root=/dev/sda1 ro console=ttyS0,115200n8 console=tty0')
    test_file.close()

    # Call method collect of CmdLineFactCollector object
    cmdline_facts = cmdline_fact_collector.collect()

    # Check if the result is correct
    assert cmdline_facts['cmdline'] == {'root': '/dev/sda1', 'ro': True, 'console': 'ttyS0,115200n8'}

# Generated at 2022-06-17 01:51:01.387981
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_fact_collector = CmdLineFactCollector()
    cmdline_fact_collector._get_proc_cmdline = lambda: 'BOOT_IMAGE=/vmlinuz-3.10.0-327.el7.x86_64 root=/dev/mapper/rhel-root ro crashkernel=auto rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet LANG=en_US.UTF-8'
    cmdline_facts = cmdline_fact_collector.collect()

# Generated at 2022-06-17 01:51:05.490335
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:51:10.389096
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:51:15.746986
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()

# Generated at 2022-06-17 01:51:27.725893
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors

    # Create a new instance of the CmdLineFactCollector class
    cmdline_collector = CmdLineFactCollector()

    # Check that the name of the CmdLineFactCollector class is CmdLineFactCollector
    assert cmdline_collector.name == 'cmdline'

    # Check that the CmdLineFactCollector class is registered in the list of
    # available collectors
    assert cmdline_collector.name in list_collectors()

    # Check that the CmdLineFactCollector class can

# Generated at 2022-06-17 01:51:33.085781
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:51:36.557824
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:53:15.674860
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline'] == {'BOOT_IMAGE': '/vmlinuz-3.10.0-327.el7.x86_64', 'ro': True, 'root': '/dev/mapper/rhel-root', 'rhgb': True, 'quiet': True, 'LANG': 'en_US.UTF-8', 'crashkernel': 'auto'}

# Generated at 2022-06-17 01:53:21.773200
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:53:32.273468
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.cmdline import CmdLineFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    import os

    # Create a Collector object
    collector = Collector()

    # Create a CmdLineFactCollector object
    cmdline_collector = CmdLineFactCollector()

    # Add the CmdLineFactCollector object to the Collector object
    collector.add_collector(cmdline_collector)

    # Create a file with the content of /proc/cmdline
    file_name = 'test_cmdline'

# Generated at 2022-06-17 01:53:41.790826
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector._get_proc_cmdline = lambda: 'BOOT_IMAGE=/vmlinuz-3.10.0-327.el7.x86_64 root=/dev/mapper/rhel-root ro crashkernel=auto rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet LANG=en_US.UTF-8'
    cmdline_facts = cmdline_collector.collect()

# Generated at 2022-06-17 01:53:46.522827
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:53:51.358848
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-17 01:53:59.264468
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline'] == {'BOOT_IMAGE': '/vmlinuz-3.10.0-327.el7.x86_64', 'root': '/dev/mapper/rhel-root', 'ro': True, 'crashkernel': 'auto', 'rd.lvm.lv': 'rhel/root', 'rhgb': True, 'quiet': True}

# Generated at 2022-06-17 01:54:11.857512
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline'] == {'BOOT_IMAGE': '/vmlinuz-3.10.0-327.el7.x86_64', 'root': '/dev/mapper/rhel-root', 'ro': True, 'crashkernel': 'auto', 'rd.lvm.lv': 'rhel/root', 'rhgb': True, 'quiet': True}

# Generated at 2022-06-17 01:54:13.816205
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-17 01:54:17.740947
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector.collect()