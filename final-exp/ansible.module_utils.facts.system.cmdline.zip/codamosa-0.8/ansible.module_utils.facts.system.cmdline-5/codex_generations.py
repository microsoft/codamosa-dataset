

# Generated at 2022-06-11 04:17:50.625370
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert c._fact_ids == set()


# Generated at 2022-06-11 04:18:00.116848
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact = CmdLineFactCollector()
    cmd_line_fact._get_proc_cmdline = lambda: ' BOOT_IMAGE=/vmlinuz-3.10.0-514.6.1.el7.x86_64 root=UUID=6d075f39-a608-423f-96d1-51bb2b0de042 ro crashkernel=auto rd.lvm.lv=rhel/swap rd.lvm.lv=rhel/root rhgb quiet'

# Generated at 2022-06-11 04:18:02.404642
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    #
    # Constructor
    #
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert c._fact_ids == set()

# Generated at 2022-06-11 04:18:04.430789
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    a = CmdLineFactCollector()
    assert a.name == 'cmdline'
    assert a._fact_ids == set()

# Generated at 2022-06-11 04:18:14.432326
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """
    Unit test to verify that the collect method of class CmdLineFactCollector
    returns the expected result if /proc/cmdline exists and it is in the
    expected format.
    """
    # Expected data

# Generated at 2022-06-11 04:18:23.743825
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    mock_output = 'root=UUID=9414e1d3-3e0f-4ece-8bdb-7a21d2e9c824 rhgb quiet elevator=noop selinux=0'
    mock_cmd = 'cat /proc/cmdline'

    # This will fail if the file /proc/cmdline is not found
    # but it is constructed this way to provide a test

# Generated at 2022-06-11 04:18:33.044946
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = {}
    cmdline_facts['cmdline'] = {'root': '/dev/mapper/rhel-root',
                                'ro': True,
                                'rhgb': True,
                                'quiet': True,
                                'no_timer_check': True,
                                'initrd': '/boot/initramfs-3.10.0-327.13.1.el7.x86_64.img'}


# Generated at 2022-06-11 04:18:33.974035
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()

# Generated at 2022-06-11 04:18:38.244338
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from collections import namedtuple
    import json

    MockModule = namedtuple('MockModule', ['params'])
    module = MockModule(params=dict())

    collector = CmdLineFactCollector()
    results = collector.collect(module=module, collected_facts=dict())

    assert isinstance(results, dict)



# Generated at 2022-06-11 04:18:40.315815
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cl = CmdLineFactCollector()
    assert cl.name == 'cmdline'


# Generated at 2022-06-11 04:18:46.394971
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    test_obj = CmdLineFactCollector()
    assert(test_obj.name == 'cmdline')


# Generated at 2022-06-11 04:18:55.992286
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    c = CmdLineFactCollector()
    assert c.collect() == {}

    c._get_proc_cmdline = lambda: 'foo bar=spam'
    collected_facts = c.collect()
    assert collected_facts['cmdline'] == {'foo': True, 'bar': 'spam'}
    assert collected_facts['proc_cmdline'] == {'foo': True, 'bar': 'spam'}

    c._get_proc_cmdline = lambda: 'foo bar=spam bar=eggs'
    collected_facts = c.collect()
    assert collected_facts['cmdline'] == {'foo': True, 'bar': 'eggs'}
    assert collected_facts['proc_cmdline'] == {'foo': True, 'bar': ['spam', 'eggs']}

# Generated at 2022-06-11 04:19:02.744064
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    class MockModule:
        def __init__(self):
            self.params = {}

    class MockFile:
        def __init__(self):
            self.content = ""

    class MockFact:
        def __init__(self):
            self.data = {}

    module = MockModule()
    mock_file = MockFile()
    mock_file.content = "console=ttyS0"
    proc_cmdline_file = "/proc/cmdline"
    mock_fact = MockFact()

    cl = CmdLineFactCollector(module=module, collected_facts=mock_fact)
    cl._get_file_content = lambda x, y=None: mock_file.content
    cl._get_file_content = lambda x, y=None: mock_file.content
    cl.collect()


# Generated at 2022-06-11 04:19:08.393255
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """Test CmdLineFactCollector.collect
    """
    import collections

    mock_module = collections.namedtuple("mock_module", ['params'])()
    mock_module.params = dict()
    mock_collector = CmdLineFactCollector('', '', '')
    mock_collector.collect(mock_module)
    mock_collector.read_cache()
    assert mock_collector.get_facts()['cmdline'] == dict()
    assert mock_collector.get_facts()['proc_cmdline'] == dict()

# Generated at 2022-06-11 04:19:08.990711
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    assert True

# Generated at 2022-06-11 04:19:11.964051
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Create object of class CmdLineFactCollector
    cmdline_fact_collector = CmdLineFactCollector()

    # Check that the object was created successfully
    assert cmdline_fact_collector is not None


# Generated at 2022-06-11 04:19:12.312894
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    pass

# Generated at 2022-06-11 04:19:13.578673
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector(None).name == 'cmdline'

# Generated at 2022-06-11 04:19:23.055190
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    proc_cmdline_data = 'ansible_connection=jail ssh_host=192.168.1.1 ssh_port=1222 debug=False'
    cmdline_data = 'ansible_connection=jail ssh_host=192.168.1.1 ssh_port=1222'
    def _get_proc_cmdline(self):
        return proc_cmdline_data
    def _get_cmdline(self):
        return cmdline_data
    CmdLineFactCollector._get_proc_cmdline = _get_proc_cmdline.__get__(CmdLineFactCollector)
    CmdLineFactCollector._get_cmdline = _get_cmdline.__get__(CmdLineFactCollector)
    cmdline_facts = CmdLineFactCollector()
    result = cmdline_facts.collect()

# Generated at 2022-06-11 04:19:32.620209
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.collect() == {}

    # test with a non-empty /proc/cmdline file
    cmdline_fact_collector._get_proc_cmdline = lambda: 'a=b c d=e'
    cmdline_facts = cmdline_fact_collector.collect()
    assert cmdline_facts['cmdline'] == {'a': 'b', 'c': True, 'd': 'e'}
    assert cmdline_facts['proc_cmdline'] == {'a': 'b', 'c': True, 'd': 'e'}

    # test with a non-empty /proc/cmdline file

# Generated at 2022-06-11 04:19:38.130800
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == "cmdline"
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-11 04:19:47.945468
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector._get_proc_cmdline = lambda : ''
    result = cmdline_collector.collect()
    assert result == {}

    cmdline_collector._get_proc_cmdline = lambda : ' '
    result = cmdline_collector.collect()
    assert result == {}

    cmdline_collector._get_proc_cmdline = lambda : 'test=testvalue'
    result = cmdline_collector.collect()
    assert result == {'cmdline': {'test': 'testvalue'}, 'proc_cmdline': {'test': 'testvalue'}}

    cmdline_collector._get_proc_cmdline = lambda : 'test= test1=abc'
    result = cmdline_collector.collect()

# Generated at 2022-06-11 04:19:49.970983
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == "cmdline"

# Generated at 2022-06-11 04:19:58.621367
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Dummy content for /proc/cmdline
    data = """BOOT_IMAGE=/vmlinuz-2.6.32-431.el6.x86_64 root=/dev/mapper/VolGroup-lv_root
 ro rd_NO_LUKS KEYBOARDTYPE=pc KEYTABLE=us rd_NO_MD SYSFONT=latarcyrheb-sun16
 rhgb crashkernel=auto  rd_LVM_LV=VolGroup/lv_root rd_LVM_LV=VolGroup/lv_swap
  LANG=en_US.UTF-8
  """
    test_obj = CmdLineFactCollector()
    test_obj._get_proc_cmdline = lambda: data

    # Call collect of class SystemUptimeFactCollector

# Generated at 2022-06-11 04:20:02.164947
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert 'cmdline' == cmd_line_fact_collector.name
    assert {'cmdline', 'proc_cmdline'} == cmd_line_fact_collector.fact_ids

# Generated at 2022-06-11 04:20:12.976254
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """
    Returns unit test results for method collect of class CmdLineFactCollector
    """
    cmdline_collector = CmdLineFactCollector()

    # Test with None module argument

# Generated at 2022-06-11 04:20:23.010923
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    CmdLineFactCollector._get_proc_cmdline = lambda: 'BOOT_IMAGE=/vmlinuz-3.10.0-327.el7.x86_64 root=UUID=d7f68fff-a1fa-40c8-a18a-2d8547c72f94 ro no_timer_check console=ttyS0,115200 console=tty0 crashkernel=auto rd.lvm.lv=rpool/root rd.lvm.lv=rpool/swap rhgb quiet LANG=en_US.UTF-8'  # noqa
    cmdline_facts = CmdLineFactCollector()

# Generated at 2022-06-11 04:20:24.766955
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()

    assert collector.name == 'cmdline'
    assert collector._fact_ids == set()

# Generated at 2022-06-11 04:20:28.032554
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    # Test if __init__ adds correct keys to set of fact ids
    assert c._fact_ids == set(['cmdline', 'proc_cmdline'])

# Generated at 2022-06-11 04:20:29.021067
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()

# Generated at 2022-06-11 04:20:45.765525
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_fact_collector = CmdLineFactCollector()
    
    with patch.object(CmdLineFactCollector, '_get_proc_cmdline') as mock_get_proc_cmdline:
        mock_get_proc_cmdline.return_value = 'foo=bar fred=1 john=2'
        result = cmdline_fact_collector.collect()
        assert result['cmdline'] == {'foo': 'bar', 'fred': '1', 'john': '2'}
        assert result['proc_cmdline'] == {'foo': 'bar', 'fred': '1', 'john': '2'}
        mock_get_proc_cmdline.assert_called_once()

# Generated at 2022-06-11 04:20:54.683454
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = CmdLineFactCollector()

    # assert type of cmdline_facts
    assert isinstance(cmdline_facts, CmdLineFactCollector)

    # assert name attribute
    assert cmdline_facts.name == 'cmdline'

    # assert that fact_ids attribute is empty
    assert cmdline_facts._fact_ids == set()


# # Unit test for static method of class CmdLineFactCollector
# def test_parse_proc_cmdline_facts():
#     data = 'foo=bar boo=far'  # example of /proc/cmdline data
#
#     # assert if data has been parsed correctly
#     parsed_data = CmdLineFactCollector._parse_proc_cmdline_facts(data)
#     assert parsed_data == {'foo': 'bar', 'boo': 'far

# Generated at 2022-06-11 04:21:03.617490
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """ Test the method collect of class CmdLineFactCollector """
    # Test for the case when /proc/cmdline exists
    gather_subset = ['all']

    instance = CmdLineFactCollector

    content = "ro root=UUID=3f3e2d1c-5f5a-4b86-bffd-22870f08eac2 rd.md=0 rd.lvm=0 rd.dm=0 systemd.unit=basic.target console=tty1 console=ttyS0"

# Generated at 2022-06-11 04:21:05.531793
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert isinstance(c._fact_ids, set)

# Generated at 2022-06-11 04:21:06.327083
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    pass


# Generated at 2022-06-11 04:21:08.245597
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()

# Generated at 2022-06-11 04:21:15.672908
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    data = 'foo=bar baz="qux" ansible_coo\'kie ansible_foo[0]=bar ansible_foo[1]=baz ansible_foo[2]=qux'
    expected_result = {'cmdline': {'ansible_cookie': True, 'foo': 'bar', 'baz': 'qux', 'ansible_foo': ['bar', 'baz', 'qux']}, 'proc_cmdline': {'ansible_cookie': True, 'foo': 'bar', 'baz': 'qux', 'ansible_foo': ['bar', 'baz', 'qux']} }
    assert CmdLineFactCollector().collect() == expected_result

# Generated at 2022-06-11 04:21:26.344322
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    # Create an instance of CmdLineFactCollector
    cmdline_fact_collector = CmdLineFactCollector()

    # Create a mock for method get_file_content of CmdLineFactCollector
    def mock_get_file_content(*args, **kwargs):
        return "root=UUID=2b6f0cc9-93b7-4da1-912d-cc86e3b88ced ro quiet splash vt.handoff=1"

    cmdline_fact_collector._get_proc_cmdline = mock_get_file_content

    # Call method collect of CmdLineFactCollector
    cmdline_facts = cmdline_fact_collector.collect()

    # Check if returned value is expected one

# Generated at 2022-06-11 04:21:28.738435
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdlineFactCollector = CmdLineFactCollector()
    if cmdlineFactCollector:
        print("The cmdline fact collector has been initialized successfully")
    else:
        print("The cmdline fact collector failed initialization")

# Generated at 2022-06-11 04:21:29.793253
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'


# Generated at 2022-06-11 04:21:50.213333
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    for _ in range(0, 10):
        assert('cmdline' in CmdLineFactCollector().collect())

# Generated at 2022-06-11 04:21:53.228565
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    """This will test the constructor of the class CmdLineFactCollector.
    """
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-11 04:21:54.952117
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()

# Generated at 2022-06-11 04:21:57.036386
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector(None, None)
    assert obj.name == "cmdline"
    assert obj._fact_ids == set()

# Generated at 2022-06-11 04:22:05.688780
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Make mock object available to CmdLineFactCollector class
    global shlex
    import mock
    import __builtin__
    shlex = mock.Mock()
    __builtin__.open = mock.Mock()
    get_file_content = mock.Mock(return_value='key1=value1 key2=value2 key3=value3 key4')
    # Instantiate class
    testcollector = CmdLineFactCollector()
    testcollector.get_file_content = get_file_content
    # Test for True
    assert testcollector.get_file_content('test') == get_file_content('test')

# Generated at 2022-06-11 04:22:13.050225
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    data = """
    BOOT_IMAGE=/boot/vmlinuz-3.16.0-0.bpo.4-amd64 root=UUID=28f55d0f-fd3e-49f9-b939-6348c7d5032b ro quiet
    """

# Generated at 2022-06-11 04:22:15.536601
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_obj = CmdLineFactCollector()
    assert cmdline_obj.name == 'cmdline'
    assert cmdline_obj._fact_ids == set()


# Generated at 2022-06-11 04:22:18.750184
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    results = collector.collect()
    assert isinstance(results, dict)
    assert results['cmdline']['console'] == 'ttyS0'
    assert results['proc_cmdline']['console'] == 'ttyS0'

# Generated at 2022-06-11 04:22:22.320727
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert type(cmdline_facts) is dict
    assert 'cmdline' in cmdline_facts
    assert 'proc_cmdline' in cmdline_facts
    assert cmdline_facts['cmdline'] == {}
    assert cmdline_facts['proc_cmdline'] == {}


# Generated at 2022-06-11 04:22:23.373379
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    CmdLineFactCollector().collect(collected_facts=None)

# Generated at 2022-06-11 04:23:06.351840
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == "cmdline"


# Generated at 2022-06-11 04:23:07.999810
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'
    assert collector.collect() == {}

# Generated at 2022-06-11 04:23:10.041318
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Test default input params
    c = CmdLineFactCollector()
    assert c.name == 'cmdline', 'Name of CmdLineFactCollector instance is not cmdline'

# Generated at 2022-06-11 04:23:15.128260
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():

    # test with empty data
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert c._fact_ids == set()
    assert c.collect() == {}

    # test with valid data
    c = CmdLineFactCollector()
    c._get_proc_cmdline = lambda: 'test=testvalue'
    expected = {'cmdline': {'test': 'testvalue'}, 'proc_cmdline': {'test': 'testvalue'}}
    assert c.collect() == expected


# Generated at 2022-06-11 04:23:23.677471
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # The mock_module.params return value controls what the
    # module_utils.basic.AnsibleModule.run_command() method will return
    mock_module = MagicMock()

    # Create a simple dictionary that contains the key and value pairs we want
    # to validate in the CmdLineFactCollector._parse_proc_cmdline() method.
    # The key names in this dictionary MUST be the same as the key names in the
    # cmdline dictionary returned by the CmdLineFactCollector._parse_proc_cmdline()
    # method.

# Generated at 2022-06-11 04:23:31.956944
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    CmdLineFactCollector.fetch_cache = {}
    collector = CmdLineFactCollector()

    data = 'BOOT_IMAGE=/boot/vmlinuz-3.10.0-957.27.2.el7.x86_64 root=UUID=769ae706-c0e7-4037-8c61-3f1c02dd1fae ro crashkernel=auto resume=/dev/mapper/cl-root rd.lvm.lv=cl/root rd.lvm.lv=cl/swap rhgb quiet LANG=en_US.UTF-8'
    cmdline_facts = {}

# Generated at 2022-06-11 04:23:39.710650
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()

    # Add some fake content that has been retrieved from /proc/cmdline
    # file.
    fake_content = 'a=1 b=2 c=3 a=4'

    with open('/proc/cmdline', 'w') as f:
        f.write(fake_content)

    # Invoke the collect method.
    result = collector.collect()

    # Make sure that the expected data structure is returned.
    assert result == {
        'cmdline': {'a': '4', 'b': '2', 'c': '3'},
        'proc_cmdline': {'a': ['1', '4'], 'b': '2', 'c': '3'},
    }


# Generated at 2022-06-11 04:23:41.440116
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == "cmdline"
    assert obj._fact_ids == set()

# Generated at 2022-06-11 04:23:48.498869
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # pylint: disable=protected-access

    mock_data = {
        'cmdline': 'ro root=UUID=90abcd67-cdef-1234-5678-a5d5aeaae132' \
                   ' console=tty1 quiet'
    }


# Generated at 2022-06-11 04:23:51.592930
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    from ansible.module_utils.facts import FactsCollector
    from ansible.module_utils.facts.collector import Collector
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert isinstance(c, Collector)
    assert isinstance(c, FactsCollector)

# Generated at 2022-06-11 04:25:24.313208
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()

    assert c.name == 'cmdline'

# Generated at 2022-06-11 04:25:26.779509
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    my_collector = CmdLineFactCollector
    assert my_collector.name == 'cmdline'

    my_collector = CmdLineFactCollector()
    assert my_collector.name == 'cmdline'


# Generated at 2022-06-11 04:25:35.149926
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    x = CmdLineFactCollector()
    expected_result = {'cmdline': {'ansible_cmdline': {'test_1': 'value_1',
                                                       'test_2': 'value_2',
                                                       'test_3': 'value_3',
                                                       'test_4': 'value_4'}},
                       'proc_cmdline': {'ansible_proc_cmdline': {'test_1': 'value_1',
                                                                 'test_2': ['value_2', 'value_2'],
                                                                 'test_3': 'value_3',
                                                                 'test_4': 'value_4'}}}
    assert x.collect() == expected_result

# Generated at 2022-06-11 04:25:36.970103
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.freebsd.cmdline import CmdLineFactCollec

# Generated at 2022-06-11 04:25:37.671681
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert callable(CmdLineFactCollector)

# Generated at 2022-06-11 04:25:39.175818
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    """Test constructor of class."""
    c = CmdLineFactCollector()
    assert c is not None

# Generated at 2022-06-11 04:25:47.310925
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    def mock_get_file_content(path):
        return r'ansible_user=test_user_name ansible_password=test_password ansible_become_pass=test_become_pass ansible_become_user=test_become_user'

    mock_module = Mock()
    mock_collected_facts = Mock()
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector.get_file_content = mock_get_file_content
    returned_facts = cmdline_collector.collect(mock_module, mock_collected_facts)


# Generated at 2022-06-11 04:25:54.265448
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Empty cmdline
    assert CmdLineFactCollector().collect() == {}

    # Populated cmdline
    assert CmdLineFactCollector().collect(data="var1=foo var2=bar") == \
        {'cmdline': {'var1': 'foo', 'var2': 'bar'},
         'proc_cmdline': {'var1': 'foo', 'var2': 'bar'}}

    # cmdline with repeated arguments
    assert CmdLineFactCollector().collect(data="var1=foo var2=bar var1=baz") == \
        {'cmdline': {'var1': 'baz', 'var2': 'bar'},
         'proc_cmdline': {'var1': ['foo', 'baz'], 'var2': 'bar'}}

    # Malformed cmdline

# Generated at 2022-06-11 04:25:55.724593
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    result = CmdLineFactCollector()
    assert result.name == 'cmdline'


# Generated at 2022-06-11 04:26:01.826244
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_fact = CmdLineFactCollector()

    # Test Short option
    cmdline_content = 'ip=172.16.1.1::172.16.1.254:255.255.255.0:rhel:eth0:none root=UUID=6d1b7a1b-9d13-4b72-a0d6-c5ba20dcb7a1 rd.lvm.lv=vgus-root/lvus-root ro rd.lvm.lv=vgus-swap/lvus-swap rhgb quiet'

    cmdline_facts = cmdline_fact.collect()

    assert cmdline_facts['cmdline'] == cmdline_fact._parse_proc_cmdline(cmdline_content)