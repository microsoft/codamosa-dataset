

# Generated at 2022-06-11 04:17:55.498361
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    class TestModule(object):
        def __init__(self, name, state=False):
            self.name = name
            self.state = state

        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            pass

    # Create instance of class CmdLineFactCollector
    clfc = CmdLineFactCollector()

    # If /proc/cmdline file does not exist then function collect must return empty dict
    assert clfc.collect(TestModule('test')) == {}

    # If /proc/cmdline file exists then function collect must return dict with values

# Generated at 2022-06-11 04:17:56.811151
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'

# Generated at 2022-06-11 04:17:58.534221
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = CmdLineFactCollector()
    assert cmdline_facts.name == 'cmdline'

# Generated at 2022-06-11 04:18:00.881045
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdlineFactCollector = CmdLineFactCollector()
    assert 'cmdline' == cmdlineFactCollector.name
    assert 'cmdline' in cmdlineFactCollector._fact_ids

# Generated at 2022-06-11 04:18:09.574045
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # prepare env
    module = AnsibleModuleMock()
    collected_facts = {'ansible_facts':{'cmdline':{}}}

    # run module code to be tested
    cmdline_fact_collector = CmdLineFactCollector()
    facts = cmdline_fact_collector.collect(module, collected_facts)

    # assert results
    assert 'cmdline' in facts
    assert 'proc_cmdline' in facts
    assert 'ansible_facts' in collected_facts
    assert 'cmdline' in collected_facts['ansible_facts']
    for key, value in facts.items():
        assert key in collected_facts['ansible_facts']
        assert collected_facts['ansible_facts'][key] == value


# Generated at 2022-06-11 04:18:15.377570
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """
    Unit test for the method 'collect' of class CmdLineFactCollector.
    """
    # Create a CmdLineFactCollector object
    collector = CmdLineFactCollector('TestCmdLineFactCollector')

    # Execute the method collect of class CmdLineFactCollector
    result = collector.collect()

    # Check the result
    assert 'cmdline' in result
    assert 'proc_cmdline' in result

# Generated at 2022-06-11 04:18:24.608299
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # instantiate collector
    collector = CmdLineFactCollector()

    # set _get_proc_cmdline to return a predefined string
    def _get_proc_cmdline():
        return "a=b c d=e=f g h=m n=o=p"
    collector._get_proc_cmdline = _get_proc_cmdline

    # call method collect and assert results
    result = collector.collect()


# Generated at 2022-06-11 04:18:30.999968
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    fact_collector = CmdLineFactCollector()
    cmdline_facts = fact_collector.collect()

    assert isinstance(cmdline_facts, dict)
    assert 'cmdline' in cmdline_facts
    assert 'proc_cmdline' in cmdline_facts
    assert isinstance(cmdline_facts['cmdline'], dict)
    assert isinstance(cmdline_facts['proc_cmdline'], dict)
    assert 'BOOT_IMAGE' in cmdline_facts['cmdline']



# Generated at 2022-06-11 04:18:32.537013
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert isinstance(obj, CmdLineFactCollector)

# Generated at 2022-06-11 04:18:34.178734
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    facts = collector.collect()
    assert isinstance(facts, dict)

# Generated at 2022-06-11 04:18:43.665092
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()


# Generated at 2022-06-11 04:18:53.614320
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """Unit test for `CmdLineFactCollector.collect`"""
    cmdline_facts = CmdLineFactCollector().collect()
    # From Fedora 31 /proc/cmdline

# Generated at 2022-06-11 04:19:01.981578
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_data = """BOOT_IMAGE=/vmlinuz-3.13.0-32-generic.efi.signed \
root=/dev/mapper/ubuntu--vg-root ro \
recovery-mode=reboot quiet splash \
BOOTIF=01-00-27-00-32-c2-33-b4-83-86"""

    cmdline_facts = {}

# Generated at 2022-06-11 04:19:04.117004
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    """
    Test CmdLineFactCollector
    """
    collect = CmdLineFactCollector()
    assert isinstance(collect, BaseFactCollector)
    assert isinstance(collect._fact_ids, set)

# Generated at 2022-06-11 04:19:06.991599
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()

    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()



# Generated at 2022-06-11 04:19:11.704225
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    '''Test that the collect method of the CmdLineFactCollector returns the
    expected data.
    '''
    # Initialize the CmdLineFactCollector and set proc_cmdline_content to
    # a string that is expected to be stored in the dictionary of cmdline
    # facts.
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector._get_proc_cmdline = lambda: 'ansible_test=test'

    # Test that the data returned by the collect method has the expected
    # dictionary structure
    cmdline_facts = cmdline_collector.collect()
    assert 'cmdline' in cmdline_facts
    assert 'proc_cmdline' in cmdline_facts

    cmdline_dict = cmdline_facts['cmdline']

    # Test that the cmdline dictionary contains the expected key

# Generated at 2022-06-11 04:19:20.965363
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Test for get_file_content() method of class CmdLineFactCollector unit test
    from ansible.module_utils.facts.collector import CmdLineFactCollector
    from ansible.module_utils.facts import utils
    from ansible.module_utils.facts.utils import get_file_content
    from unittest.mock import patch

# Generated at 2022-06-11 04:19:30.729850
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    '''Test method collect of class CmdLineFactCollector'''

    from ansible.module_utils.facts import ModuleArgsParser
    from ansible.module_utils.facts import Facts

    # Setup the test
    test_module_arguments = dict(
        gather_subset=['cmdline']
    )

    test_module = AnsibleModule(
        argument_spec=test_module_arguments,
        supports_check_mode=False
    )

    test_module.exit_json = Mock(return_value=dict(changed=False))
    test_module.fail_json = Mock(return_value=dict(failed=True))

    module_args = test_module.params
    module_parser = ModuleArgsParser(module_args)

    # Create an instance of the class
    cmdline_fact_collector = C

# Generated at 2022-06-11 04:19:40.273731
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline = 'BOOT_IMAGE=/vmlinuz-4.4.0-139-generic root=UUID=3f3b053a-6d0b-4c25-ace3-0cde3a9acf9b ro quiet splash'
    collector = CmdLineFactCollector(None)
    collector._get_proc_cmdline = lambda: cmdline
    data = collector.collect()


# Generated at 2022-06-11 04:19:41.493314
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    x = CmdLineFactCollector()
    assert x


# Generated at 2022-06-11 04:19:51.501753
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    print(cmdline.name)
    print(cmdline.collect())

# Generated at 2022-06-11 04:19:53.561627
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    x = CmdLineFactCollector()
    assert x.name == 'cmdline'
    assert x._fact_ids == set()


# Generated at 2022-06-11 04:19:55.052062
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    test_collector = CmdLineFactCollector()
    assert test_collector


# Generated at 2022-06-11 04:20:03.963309
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert cmdline.name == 'cmdline'
    assert cmdline._fact_ids == set()
    assert cmdline._get_proc_cmdline() is not None
    data = cmdline._get_proc_cmdline()
    assert cmdline._parse_proc_cmdline(data) is not None
    assert cmdline._parse_proc_cmdline_facts(data) is not None
    assert cmdline.collect() is not None
    assert cmdline.collect()['cmdline']['root'] is not None
    assert cmdline.collect()['cmdline']['net.ifnames'] is not None
    assert cmdline.collect()['proc_cmdline']['root'] is not None

# Generated at 2022-06-11 04:20:07.420865
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = CmdLineFactCollector()
    assert cmdline_facts.name == 'cmdline'
    assert isinstance(cmdline_facts._fact_ids, set)
    assert cmdline_facts._fact_ids == set()

# Generated at 2022-06-11 04:20:13.118089
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    c = CmdLineFactCollector()
    collected_facts = {}

    expected_facts = {'cmdline': {u'a': u'b', u'c': True}, 'proc_cmdline': {u'a': u'b', u'c': True}}

    actual_facts = c.collect(collected_facts=collected_facts)
    assert expected_facts == actual_facts

# Generated at 2022-06-11 04:20:13.720271
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    pass

# Generated at 2022-06-11 04:20:15.151379
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    c = CmdLineFactCollector()
    c.collect()

# Generated at 2022-06-11 04:20:19.289948
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    c = CmdLineFactCollector()
    facts = c.collect()

    assert isinstance(facts, dict)
    assert 'cmdline' in facts
    assert isinstance(facts['cmdline'], dict)
    assert 'proc_cmdline' in facts
    assert isinstance(facts['proc_cmdline'], dict)

# Generated at 2022-06-11 04:20:26.092310
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # run collect method
    cmdline_fact_collector = CmdLineFactCollector()
    cmdline_facts = cmdline_fact_collector.collect()

    # test if the result is correct
    test_result = cmdline_fact_collector._parse_proc_cmdline_facts(
        cmdline_fact_collector._get_proc_cmdline())
    assert cmdline_facts['proc_cmdline'] == test_result

    test_result = cmdline_fact_collector._parse_proc_cmdline(
        cmdline_fact_collector._get_proc_cmdline())
    assert cmdline_facts['cmdline'] == test_result

# Generated at 2022-06-11 04:20:44.716057
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    result = CmdLineFactCollector()
    assert isinstance(result, BaseFactCollector)

# Generated at 2022-06-11 04:20:47.634383
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = {'proc_cmdline': {'/usr/sbin/mysqld': True},
                     'cmdline': {'/usr/sbin/mysqld': True}}

    def get_file_content(path):
        if path == '/proc/cmdline':
            return '/usr/sbin/mysqld'

    collector = CmdLineFactCollector()
    collector._get_proc_cmdline = get_file_content

    assert collector.collect() == cmdline_facts

# Generated at 2022-06-11 04:20:49.360790
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector is not None
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-11 04:20:52.969078
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """Unit test for method collect of class CmdLineFactCollector."""
    cmdline_str = 'root=/dev/sda1 ro crashkernel=auto rd.lvm.lv=fedora/root rd.lvm.lv=fedora/swap rhgb quiet'
    cmdline_dic = {'root': '/dev/sda1', 'ro': True, 'crashkernel': 'auto',
                   'rd.lvm.lv': ['fedora/root', 'fedora/swap'], 'rhgb': True,
                   'quiet': True}

    cmdline_facts_collected = {'cmdline': cmdline_dic, 'proc_cmdline': cmdline_dic}

    cmdline_fact_collector = CmdLineFactCollector()
    cmdline_facts = cmdline_fact_collector

# Generated at 2022-06-11 04:21:01.579274
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector(None)
    result = collector.collect()

    proc_cmdline = '/proc/cmdline'
    data = 'BOOT_IMAGE=/vmlinuz-3.10.0-327.13.1.el7.x86_64 root=/dev/mapper/luks-9a11dbeb-7b0c-45a8-b84f-c62ed4cb4dc4 ro crashkernel=auto rhgb quiet LANG=en_US.UTF-8'

    if data:
        proc_cmdline_dict = {}
        proc_cmdline_dict['BOOT_IMAGE'] = '/vmlinuz-3.10.0-327.13.1.el7.x86_64'

# Generated at 2022-06-11 04:21:02.531548
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    facts = collector.collect()
    assert 'cmdline' in facts
    assert 'proc_cmdline' in facts

# Generated at 2022-06-11 04:21:11.344151
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    proc_cmdline = """ BOOT_IMAGE=/vmlinuz-3.10.0-327.el7.x86_64 root=/dev/mapper/rhel-root ro crashkernel=auto  rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet LANG=en_US.UTF-8  selinux=0 KEYTABLE=us rd.luks.uuid=luks-f5a595f5-5e5c-4e4c-ac97-854a919e9d7a rd.lvm.lv=rhel/root """

# Generated at 2022-06-11 04:21:12.879346
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector is not None

# Generated at 2022-06-11 04:21:18.540431
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.cmdline import CmdLineFactCollector

    # Stub out BaseFactCollector.collect() - return value will be ignored
    def collect(self, module=None, collected_facts=None):
        pass
    collector.BaseFactCollector.collect = collect

    obj = CmdLineFactCollector()

    assert obj.name == 'cmdline'
    assert obj._fact_ids == set()


# Generated at 2022-06-11 04:21:29.105244
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts import Namespace, FactManager
    import sys

    # sys.modules must be modified in this way for the 'import module_utils.facts.collector' statement to work
    sys.modules['ansible.module_utils.facts'] = Namespace()
    from ansible.module_utils.facts.collector import CmdLineFactCollector


# Generated at 2022-06-11 04:22:07.139817
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()

# Generated at 2022-06-11 04:22:08.763448
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()

# Generated at 2022-06-11 04:22:10.989264
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-11 04:22:18.895271
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_fact_collector = CmdLineFactCollector()

    # Mock method _get_proc_cmdline
    with patch.object(CmdLineFactCollector, '_get_proc_cmdline') as mock_get_proc_cmdline:
        mock_get_proc_cmdline.return_value = "ro root=UUID=1360a7a8-7301-40b6-a9d0-b8b0359df23a"
        cmdline_facts = cmdline_fact_collector.collect()

    assert cmdline_facts['cmdline']['root'] == 'UUID=1360a7a8-7301-40b6-a9d0-b8b0359df23a'

# Generated at 2022-06-11 04:22:20.599376
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector is not None


# Generated at 2022-06-11 04:22:24.874106
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    fact_collector = CmdLineFactCollector()

    with open('/proc/cmdline', 'r') as f:
        data = f.read()

    fact_data = fact_collector.collect()

    assert fact_data['cmdline'] == fact_collector._parse_proc_cmdline(data)
    assert fact_data['proc_cmdline'] == fact_collector._parse_proc_cmdline_facts(data)

# Generated at 2022-06-11 04:22:27.021387
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'
    assert collector.priority == 50
    assert collector._fact_ids == set()


# Generated at 2022-06-11 04:22:35.187004
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Create an instance of FakeModule to generate dummy facts
    fake_module = FakeModule()

    # Create an instance of FakeFile to generate dummy content in /proc/cmdline
    fake_file_instance = FakeFile()

    # Create an instance of the CmdLineFactCollector class
    cmdline_instance = CmdLineFactCollector()

    # Set the cmdline_facts attribute of the CmdLineFactCollector instance
    cmdline_instance._cmdline_facts = {'cmdline': {},
                                       'proc_cmdline': {}}

    # Assign a validated fake file content to 
    # the content attribute of the fake file to be returned by get_file_content

# Generated at 2022-06-11 04:22:40.366547
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = {
        'cmdline': {
            'rhel7.0': True,
            'ro': True,
            'console': 'tty0'
        },
        'proc_cmdline': {
            'rhel7.0': [True],
            'ro': [True],
            'console': ['tty0'],
        }
    }

    class MockModule(object):
        pass

    module = MockModule()

    CmdLineFactCollector(module=module).collect()

# Generated at 2022-06-11 04:22:42.968448
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector_obj = CmdLineFactCollector()
    assert cmdline_fact_collector_obj.name == 'cmdline'
    assert cmdline_fact_collector_obj._fact_ids == set()


# Generated at 2022-06-11 04:24:15.155315
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    CmdLineFactCollector.collect()

# Generated at 2022-06-11 04:24:22.820982
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """
    Test the CmdLineFactCollector.collect function
    """
    result = {}

    def mock__get_proc_cmdline():
        return ""

    def mock__parse_proc_cmdline(data):
        return data

    def mock__parse_proc_cmdline_facts(data):
        return data

    class mock_CmdLineFactCollector(CmdLineFactCollector):
        def __init__(self):
            pass

        def _get_proc_cmdline(self):
            return mock__get_proc_cmdline()

        def _parse_proc_cmdline(self, data):
            return mock__parse_proc_cmdline(data)

        def _parse_proc_cmdline_facts(self, data):
            return mock__parse_proc_cmdline_facts(data)

    mock_collector

# Generated at 2022-06-11 04:24:25.388547
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    """Test CmdLineFactCollector constructor"""
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()


# Generated at 2022-06-11 04:24:26.176283
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()

# Generated at 2022-06-11 04:24:29.132415
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == "cmdline"
    assert len(cmdline_fact_collector.options) == 0
    assert cmdline_fact_collector.options == []

# Generated at 2022-06-11 04:24:30.909789
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    """Unit test for constructor of class CmdLineFactCollector"""
    collector = CmdLineFactCollector()
    assert collector


# Generated at 2022-06-11 04:24:37.103731
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    assert CmdLineFactCollector().collect() == {
        'cmdline': {'root': '/dev/sda1', 'ro': True, 'mtdparts': 'orion_nand:1M(u-boot),4M(uImage),32M(rootfs),-(data)'},
        'proc_cmdline': {
            'root': '/dev/sda1',
            'ro': True,
            'mtdparts': ['orion_nand:1M(u-boot)', '4M(uImage)', '32M(rootfs)', '-(data)']
        }
    }

# Generated at 2022-06-11 04:24:38.770052
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    result = CmdLineFactCollector.collect()
    assert 'cmdline' in result
    assert 'proc_cmdline' in result

# Generated at 2022-06-11 04:24:40.126222
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert cmdline.name == 'cmdline'


# Generated at 2022-06-11 04:24:41.701531
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    me = CmdLineFactCollector()
    assert me.name == 'cmdline'
    assert me._fact_ids == set()
