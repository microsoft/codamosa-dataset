

# Generated at 2022-06-11 04:17:48.080189
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector is not None


# Generated at 2022-06-11 04:17:57.417402
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    a = CmdLineFactCollector()

# Generated at 2022-06-11 04:18:02.551828
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    data = collector._get_proc_cmdline()
    collected_facts = collector.collect(collected_facts=None)
    cmdline_dict = collector._parse_proc_cmdline(data)
    cmdline_facts = collector._parse_proc_cmdline_facts(data)
    assert collected_facts['cmdline'] == cmdline_dict
    assert collected_facts['proc_cmdline'] == cmdline_facts

# Generated at 2022-06-11 04:18:03.486066
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()

# Generated at 2022-06-11 04:18:05.436946
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()


# Generated at 2022-06-11 04:18:15.548383
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collector import BaseFactCollector

    # Mock the BaseFactCollector class in order to test the CmdLineFactCollector.collect
    # method
    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self, *args, **kwargs):
            self.test_data = args[0]
            super(MockBaseFactCollector, self).__init__(*args, **kwargs)

        def _get_proc_cmdline(self):
            return get_file_content(self.test_data)

    # Test CmdLineFactsCollector.collect method with default '/proc/cmdline' file
    collector = CmdLineFactCollector()

# Generated at 2022-06-11 04:18:17.549915
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'


# Generated at 2022-06-11 04:18:26.840453
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    # Required imports
    import ansible.module_utils.facts.collector

    # Create a CmdLineFactCollector object
    cmdline_collector = CmdLineFactCollector(None, None)

    # Create a "file" object containing valid data to the file
    # /proc/cmdline
    import io
    file_data = io.StringIO('''quiet BOOT_IMAGE=/vmlinuz-4.4.0-87-generic root=/dev/mapper/ubuntu--vg-root ro acpi=force
    ''')

    # Apply the method _get_proc_cmdline to the variable "file_data"
    cmdline_collector.get_file_content = lambda filename, default='': file_data.read()

    # Perform the collect method of the CmdLineFactCollector object
    cmdline

# Generated at 2022-06-11 04:18:29.618588
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_f = CmdLineFactCollector()

    assert cmdline_f.name == "cmdline"
    assert cmdline_f._fact_ids == set()

# Generated at 2022-06-11 04:18:35.760856
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    with open('/proc/cmdline') as f:
        content = f.read()

    with open('/proc/cmdline', 'w') as f:
        f.write('vga=791 ')

    assert len(CmdLineFactCollector().collect()['proc_cmdline']) == 2

    with open('/proc/cmdline', 'w') as f:
        f.write('BOOT_IMAGE=some-linux-kernel')

    assert len(CmdLineFactCollector().collect()['proc_cmdline']) == 1

    with open('/proc/cmdline', 'w') as f:
        f.write('BOOT_IMAGE=some-linux-kernel ')

    assert len(CmdLineFactCollector().collect()['proc_cmdline']) == 1


# Generated at 2022-06-11 04:18:44.304000
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()


# Generated at 2022-06-11 04:18:47.247549
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = CmdLineFactCollector()
    assert cmdline_facts.name == 'cmdline'
    assert len(cmdline_facts._fact_ids) == 0


# Generated at 2022-06-11 04:18:48.555030
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts

# Generated at 2022-06-11 04:18:50.620744
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'
    assert obj._fact_ids == set()


# Generated at 2022-06-11 04:18:59.717275
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    exp_cmdline = {'console': '/dev/ttyS0',
             'console_loglevel': '5',
             'ro': '',
             'splash': '',
             'vga': '0x314'}
    exp_proc_cmdline = {'console': 'ttyS0',
             'console_loglevel': '5',
             'ro': True,
             'splash': True,
             'vga': '314'}
    exp_result = {'cmdline': exp_cmdline,
             'proc_cmdline': exp_proc_cmdline}

# Generated at 2022-06-11 04:19:07.481236
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    '''
    Test whether the collect method of class CmdLineFactCollector returns
    a data structure as expected.
    '''

    class MockModule:
        pass

    class MockFactCollector(BaseFactCollector):
        pass

    # Set up an instance of CmdLineFactCollector for testing
    cmdline = CmdLineFactCollector()
    mock_module = MockModule()
    known_facts = {}
    mock_module.params = {'gather_subset': ['cmdline'],
                          'filter': '*cmdline*'}
    result = cmdline.collect(mock_module, known_facts)

    # Check if the result is expected

# Generated at 2022-06-11 04:19:13.848529
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    module = CmdLineFactCollector()
    cmdline_facts = module.collect()
    assert cmdline_facts == {'cmdline': {'BOOT_IMAGE': '/boot/vmlinuz-3.13.0-32-generic', 'root': '/dev/sda1', 'ro': True, 'quiet': True}, 'proc_cmdline': {'BOOT_IMAGE': '/boot/vmlinuz-3.13.0-32-generic', 'root': '/dev/sda1', 'ro': True, 'quiet': True}}


# Generated at 2022-06-11 04:19:21.889538
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    data = "ro quiet console=ttyS0 rd_NO_PLYMOUTH"
    mock_get_file_content = lambda x: data
    facts = CmdLineFactCollector().collect(get_file_content=mock_get_file_content)

    expected = {u'cmdline': {u'ro': True, u'quiet': True, u'console': u'ttyS0', u'rd_NO_PLYMOUTH': True},
                u'proc_cmdline': {u'ro': True, u'quiet': True, u'console': True, u'rd_NO_PLYMOUTH': True}}
    assert facts == expected

# Generated at 2022-06-11 04:19:22.830087
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()

# Generated at 2022-06-11 04:19:25.380694
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = CmdLineFactCollector()
    assert cmdline_facts.name == 'cmdline'
    assert cmdline_facts._fact_ids == set()


# Generated at 2022-06-11 04:19:41.725184
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line = CmdLineFactCollector()
    assert cmd_line.name == 'cmdline'


# Generated at 2022-06-11 04:19:45.269147
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()

    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-11 04:19:46.419158
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()

# Generated at 2022-06-11 04:19:48.219275
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline', 'name should match'
    

# Generated at 2022-06-11 04:19:56.617975
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_data = get_cmdline()
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_data == cmdline_fact_collector._get_proc_cmdline()
    assert isinstance(cmdline_fact_collector._parse_proc_cmdline(cmdline_data), dict)
    assert 'cmdline' in cmdline_fact_collector.collect()
    assert isinstance(cmdline_fact_collector.collect()['cmdline'], dict)
    assert 'proc_cmdline' in cmdline_fact_collector.collect()
    assert isinstance(cmdline_fact_collector.collect()['proc_cmdline'], dict)

# Generate test data from file or from /proc/cmdline

# Generated at 2022-06-11 04:20:01.509244
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    '''Unit test for constructor of class CmdLineFactCollector'''
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'
    assert obj._fact_ids == set()


TEST_DATA = 'root=/dev/mapper/vg0-root ro quiet amd_iommu=on vfio_iommu_type1.allow_unsafe_interrupts=1'

# Generated at 2022-06-11 04:20:04.257238
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    """
    Unit test to test constructor of class CmdLineFactCollector
    """
    cmd = CmdLineFactCollector()
    assert cmd.name == 'cmdline'


# Generated at 2022-06-11 04:20:06.006003
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'

# Generated at 2022-06-11 04:20:08.752592
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == "cmdline"
    assert set(collector._fact_ids) == set()


# Generated at 2022-06-11 04:20:19.714988
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    data = 'BOOT_IMAGE=/vmlinuz-linux root=/dev/sda2 ro vga=791 ipv6.disable=1 '\
           'quiet resume=/dev/sda1 elevator=deadline test=test video=vesafb:ywrap,mtrr:3 '\
           'volume=test:'


# Generated at 2022-06-11 04:20:43.256877
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    try:
        from ansible.module_utils.facts import collector
    except ImportError:
        pytest.skip("ansible.module_utils.facts not found.")

    data = '''BOOT_IMAGE=/boot/vmlinuz-3.13.0-24-generic root=UUID=bf5b5c5e-67b7-4db2-9b1c-9d6c1845e8a2 ro console=ttyS0 console=tty1 selinux=0'''

# Generated at 2022-06-11 04:20:48.695671
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    CmdLineFactCollector._get_proc_cmdline = lambda self: ''
    assert {} == CmdLineFactCollector().collect()

    CmdLineFactCollector._get_proc_cmdline = lambda self: 'foo=bar'
    assert {'cmdline': {'foo': 'bar'}, 'proc_cmdline': {'foo': 'bar'}} == \
        CmdLineFactCollector().collect()


# Generated at 2022-06-11 04:20:53.228380
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    my_collector = CmdLineFactCollector()
    assert my_collector.name == 'cmdline'
    assert my_collector._fact_ids == set()

    my_collector = CmdLineFactCollector(name='cmdline')
    assert my_collector.name == 'cmdline'
    assert my_collector._fact_ids == set()

# Generated at 2022-06-11 04:20:54.413829
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'

# Generated at 2022-06-11 04:20:59.209342
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    test_data = "ro BOOT_IMAGE=vmlinuz-3.13.0-86-generic"
    cmdline_collector._get_proc_cmdline = lambda: test_data

    facts = cmdline_collector.collect()

    assert facts['proc_cmdline']['BOOT_IMAGE'] == 'vmlinuz-3.13.0-86-generic'

# Generated at 2022-06-11 04:21:03.528426
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert isinstance(CmdLineFactCollector._fact_ids, set)

    collector = CmdLineFactCollector()

    assert collector.name == 'cmdline'
    assert isinstance(collector._fact_ids, set)

    assert collector.collect() == {}

# Generated at 2022-06-11 04:21:06.069038
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdLine_instance = CmdLineFactCollector()
    assert cmdLine_instance.name == 'cmdline'
    assert len(cmdLine_instance._fact_ids) == 0



# Generated at 2022-06-11 04:21:07.615188
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == "cmdline"

# Generated at 2022-06-11 04:21:16.376959
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    class TestModule:
        def fail_json(self, msg):
            self.fail_json_called = True
            self.fail_json_msg = msg

    cfs = CmdLineFactCollector()
    cfs.read_file = lambda path: 'foo=bar myvar=foobar'
    res = cfs.collect(TestModule())

    assert res
    assert 'cmdline' in res
    assert 'proc_cmdline' in res
    cmdline = res['proc_cmdline']
    assert 'foo' in cmdline
    assert cmdline['foo'] == 'bar'
    assert 'myvar' in cmdline
    assert cmdline['myvar'] == 'foobar'

    cfs.read_file = lambda path: 'foo=bar myvar=foobar myvar=another_foobar'
    res = c

# Generated at 2022-06-11 04:21:17.567430
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    inst = CmdLineFactCollector()
    assert inst



# Generated at 2022-06-11 04:21:53.478909
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert not cmdline_fact_collector._fact_ids

# Generated at 2022-06-11 04:21:55.243470
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert 'ansible.module_utils.facts.system.cmdline.CmdLineFactCollector'\
               .replace('.', r'\.') == CmdLineFactCollector.__module__ + '\.' + CmdLineFactCollector.__name__

# Generated at 2022-06-11 04:21:58.536735
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'
    assert obj._fact_ids == set()       # pylint: disable=protected-access


# Generated at 2022-06-11 04:22:01.037331
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():

    # Test: create object
    cmdline_fact_collector = CmdLineFactCollector()

    # Test: test object name
    assert cmdline_fact_collector.name == 'cmdline'

# Generated at 2022-06-11 04:22:03.243316
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():

    cmdline_cmd = CmdLineFactCollector()
    assert cmdline_cmd is not None
    assert cmdline_cmd._fact_ids == set()


test_CmdLineFactCollector()

# Generated at 2022-06-11 04:22:10.889148
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    with open('tests/unit/output/mkisofs_cmdline') as f:
        mkisofs_cmdline = f.readlines()

    mkisofs_cmdline_as_string = ''.join(mkisofs_cmdline)

    # Create a mock module to pass to the CmdLineFactCollector constructor
    # set necessary values for the constructor
    mock_module = type('MockModule', (), {'params':{}})

    # Initialize the collector object
    cmdline_collector = CmdLineFactCollector(mock_module)

    # Call the collect method of the collector object
    cmdline_facts = cmdline_collector.collect()

    # The returned value is a dict, so we need to iterate over it

# Generated at 2022-06-11 04:22:16.726349
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """Test CmdLineFactCollector.collect()"""
    from ansible.module_utils.facts.collector import TestCollector
    from ansible_collections.community.general.plugins.module_utils.facts.collectors import FactsCollector

    # test empty proc_cmdline
    TestCollector.before_import()
    TestCollector.set_facts(dict(proc_cmdline=""))
    collector = FactsCollector(module=None)
    data = collector.collect(module=None)
    facts = dict(ansible_facts=dict(cmdline=dict(), proc_cmdline=dict()))
    assert data == facts

    # test proc_cmdline with a single key
    TestCollector.before_import()
    TestCollector.set_facts(dict(proc_cmdline="ansible_test=val"))
   

# Generated at 2022-06-11 04:22:17.221590
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    pass

# Generated at 2022-06-11 04:22:24.982442
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    '''
    Test cmdline collect method
    '''

    from ansible.module_utils.facts.collector import BaseFactCollector

    class MockFactCollector(BaseFactCollector):
        '''
        Mock class for testing
        '''
        def __init__(self):
            self.test1_count = 0
            self.test2_count = 0

        def _test1(self, module=None, collected_facts=None):
            self.test1_count += 1

            self.test1_module = module
            self.test1_collected_facts = collected_facts

        def _test2(self, module=None, collected_facts=None):
            self.test2_count += 1

            self.test2_module = module
            self.test2_collected_facts = collected_facts

   

# Generated at 2022-06-11 04:22:27.136599
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == "cmdline"
    assert cmdline_collector._fact_ids == set()

# Generated at 2022-06-11 04:23:48.651852
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collected_facts = dict()
    cmdline_collector = CmdLineFactCollector()
    cmdline_facts = cmdline_collector.collect(collected_facts=collected_facts)

    assert 'proc_cmdline' in cmdline_facts
    assert 'cmdline' in cmdline_facts

# Generated at 2022-06-11 04:23:54.767020
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """
    This is unit test function for method collect of class CmdLineFactCollector
    """
    # Arrange
    # Create mocked class
    test_class = create_autospec(CmdLineFactCollector)

    # Act
    # Call the method
    result = test_class.collect()

    # Assert
    assert result is not None, "The method collect failed"
    assert isinstance(result, dict), "The method collect failed"
    assert isinstance(result.get('cmdline'), dict), "The method collect failed"
    assert isinstance(result.get('proc_cmdline'), dict), "The method collect failed"

# Generated at 2022-06-11 04:23:57.164472
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector.instance()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-11 04:24:05.294779
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    system_facts = {'kernel': {'name': 'Linux'}}
    cmdline_collector = CmdLineFactCollector()

    test_cmdline = """
        BOOT_IMAGE=/vmlinuz-3.10.0-123.20.1.el7.x86_64
        root=/dev/mapper/rhel-root ro rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap
        rhgb quiet LANG=en_US.UTF-8
        cgroup_enable=memory swapaccount=1
    """

    test_ansible_cmdline = """
        ansible_ssh_port=22
        ansible_connection=local
        ansible_ssh_private_key_file=/path/to/private/key/file
    """

    expected_cmd

# Generated at 2022-06-11 04:24:11.327457
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_fact_collector = CmdLineFactCollector()
    result = cmdline_fact_collector.collect()
    assert result == {
        'cmdline': {
            'BOOT_IMAGE': '/boot/vmlinuz-3.10.0-327.el7.x86_64',
            'console': 'tty0',
            'console': 'ttyS0,115200'
        },
        'proc_cmdline': {
            'BOOT_IMAGE': '/boot/vmlinuz-3.10.0-327.el7.x86_64',
            'console': ['tty0', 'ttyS0,115200']
        }
    }

# Generated at 2022-06-11 04:24:12.337596
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector is not None

# Generated at 2022-06-11 04:24:16.650850
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    CmdLineFactCollector._get_proc_cmdline = classmethod(lambda cls: 'elevator=deadline loglevel=7 user_debug=31')
    assert CmdLineFactCollector.collect() == {'cmdline': {'elevator': 'deadline', 'loglevel': '7', 'user_debug': '31'}, 'proc_cmdline': {'elevator': 'deadline', 'loglevel': '7', 'user_debug': '31'}}

# Generated at 2022-06-11 04:24:24.146860
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import pytest
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collectors.system import CmdLineFactCollector

    collector = CmdLineFactCollector()

    with open('/proc/cmdline', 'r') as f:
        data = f.read()
        test_cmdline_facts = collector._parse_proc_cmdline(data)
        test_proc_cmdline_facts = collector._parse_proc_cmdline_facts(data)

    # test if method collect has returned the desired dict
    assert isinstance(collector.collect(), dict)
    assert collector.collect()['cmdline'] == test_cmdline_facts
    assert collector.collect()['proc_cmdline'] == test_proc_cmdline_facts

# Generated at 2022-06-11 04:24:26.010079
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'
    assert collector._fact_ids == set()


# Generated at 2022-06-11 04:24:27.760748
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import pytest

    # Method collect of class CmdLineFactCollector
    pytest.raises(SystemExit, CmdLineFactCollector().collect)

# Generated at 2022-06-11 04:27:32.025804
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c


# Generated at 2022-06-11 04:27:35.108171
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    from ansible.module_utils.facts.collector import CollectorsFactory
    from ansible.module_utils.facts import collectors
    CollectorsFactory.add_collector(CmdLineFactCollector)
    cmdline_collector_object = collectors.get_collector('cmdline')
    assert isinstance(cmdline_collector_object, CmdLineFactCollector)

# Generated at 2022-06-11 04:27:36.004114
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert isinstance(CmdLineFactCollector, type)


# Generated at 2022-06-11 04:27:42.814323
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector.cmdline import CmdLineFactCollector
    from ansible.module_utils._text import to_bytes

    # In case for unit test, we don't have a real /proc/cmdline file
    # We could create a real file so that CmdLineFactCollector.collect() could
    # read it. But that's a lot of work.
    # The data of fact collecotr is generated via:
    #   /bin/sh -c 'cat /proc/cmdline
    #   | sed "s/memtune.limit_in_bytes=[0-9]*//g"'
    #   | sed "s/user_namespace.enable=[0-9]*//g"'
    #   | sed "s/net.core.rmem_default=[0-9]*