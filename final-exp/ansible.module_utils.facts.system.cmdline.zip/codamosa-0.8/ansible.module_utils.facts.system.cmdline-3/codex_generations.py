

# Generated at 2022-06-11 04:17:50.853727
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    fact_collector = CmdLineFactCollector()

    assert fact_collector.collect().get('cmdline', {}).get('ipv6.disable') == "1"
    assert fact_collector.collect().get('cmdline', {}).get('console') == "tty0"

# Generated at 2022-06-11 04:17:53.762321
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = CmdLineFactCollector()
    assert dict == type(cmdline_facts.collect())
    assert dict == type(cmdline_facts.collect()['proc_cmdline'])



# Generated at 2022-06-11 04:18:02.983241
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """Unit tests for the ansible.module_utils.facts.cmdline.CmdLineFactCollector._collect()"""

    # Test a few possibilities
    #   1. File appears to exist, but is empty
    #   2. File appears to exist, but is malformed
    #   3. File appears to exist, is good
    #   4. File does not appear to exist
    #   5. All above, with unicode characters

    from ansible.module_utils.facts.cmdline import CmdLineFactCollector
    from ansible.module_utils.facts.utils import AnsibleFactCollector
    from ansible.module_utils.facts.utils import get_file_content, get_file_lines


# Generated at 2022-06-11 04:18:07.096965
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Test:
    #   get_file_content('/proc/cmdline')
    #   raise ValueError
    #   raise TypeError
    #   _parse_proc_cmdline()
    #   _parse_proc_cmdline_facts()
    #   collect()
    #   _get_proc_cmdline()
    pass

# Generated at 2022-06-11 04:18:09.422822
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert 'cmdline' == CmdLineFactCollector.name
    assert 'cmdline' in CmdLineFactCollector._fact_ids


# Generated at 2022-06-11 04:18:12.382704
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    obj = CmdLineFactCollector()

    r = obj.collect()

    assert isinstance(r, dict)
    assert 'cmdline' in r
    assert 'proc_cmdline' in r

# Generated at 2022-06-11 04:18:15.088139
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = CmdLineFactCollector()
    assert cmdline_facts.name == 'cmdline'
    assert cmdline_facts._fact_ids == set()


# Generated at 2022-06-11 04:18:17.103253
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    test_cmdline_collector = CmdLineFactCollector()
    assert test_cmdline_collector.name == 'cmdline'

# Generated at 2022-06-11 04:18:21.589307
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    # Test the actual instance of the class. Not the __init__
    assert isinstance(cmdline, CmdLineFactCollector)
    # Test the name of the collector
    assert cmdline.name == 'cmdline'
    # Test the fact ids
    assert cmdline._fact_ids == set()


# Generated at 2022-06-11 04:18:31.286489
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    cmdline_dict = {}
    cmdline_dict['test1'] = True
    cmdline_dict['test2'] = 'test3'
    cmdline_dict['test4'] = 'test5'
    cmdline_dict['test6'] = ['test7', 'test8']
    cmdline_dict['test9'] = 'test10'
    cmdline_dict['test11'] = 'test12'

    class MockModule:

        def __init__(self, cmdline):
            self.params = {'filter': 'cmdline'}
            self.cmdline = cmdline

        def get_bin_path(self, arg, default=None, opt_dirs=None):
            return '/bin/sh'

        def get_module_path(self):
            return '/etc/ansible/facts.d/'

   

# Generated at 2022-06-11 04:18:37.605152
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'
    assert obj._fact_ids == set()


# Generated at 2022-06-11 04:18:41.678482
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert isinstance(cmdline_collector._fact_ids, set)
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-11 04:18:51.492554
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    data = "BOOT_IMAGE=/vmlinuz-3.10.0-693.el7.x86_64 root=UUID=b0a8e83a-59ad-439a-a2d7-8b0fefb7a671 ro crashkernel=auto rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet LANG=en_US.UTF-8"
    cmdline_facts = {}

# Generated at 2022-06-11 04:18:54.415379
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()
    assert isinstance(CmdLineFactCollector._fact_ids, set)


# Generated at 2022-06-11 04:18:56.212604
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_col = CmdLineFactCollector()
    assert cmdline_col.name == 'cmdline'
    assert len(cmdline_col._fact_ids) == 0


# Generated at 2022-06-11 04:19:03.172819
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Test if cmdline is empty, no facts
    cmdline_facts = {}

    def _get_proc_cmdline():
        return ''

    CmdLineFactCollector._get_proc_cmdline = _get_proc_cmdline
    result = CmdLineFactCollector.collect({}, {})

    assert result == cmdline_facts

    # Test if proc_cmdline is malformed; no facts
    def _get_proc_cmdline():
        malformed_cmdline = 'malformed_cmdline'
        return malformed_cmdline

    CmdLineFactCollector._get_proc_cmdline = _get_proc_cmdline
    result = CmdLineFactCollector.collect({}, {})

    assert result == cmdline_facts

    # Test if empty key=value pairs in proc_cmdline; no facts
   

# Generated at 2022-06-11 04:19:05.527400
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()

    assert cmdline_fact_collector.name == 'cmdline'

if __name__ == '__main__':
    test_CmdLineFactCollector()

# Generated at 2022-06-11 04:19:14.057709
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    '''
    Method collect of class CmdLineFactCollector
    '''
    # test for success - /proc/cmdline exists and not empty
    (ret_value, ret_data) = CmdLineFactCollector.collect(None)
    assert ret_value == 0
    assert ret_data['cmdline']['ro'] == 'True'
    assert ret_data['cmdline']['root'] == '/dev/sda1'
    assert ret_data['proc_cmdline']['ro'] == 'True'
    assert ret_data['proc_cmdline']['root'] == '/dev/sda1'

    # test for failure - /proc/cmdline exists and empty
    CmdLineFactCollector._get_proc_cmdline = lambda x: ''
    (ret_value, ret_data) = Cmd

# Generated at 2022-06-11 04:19:17.590607
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Run test
    cmdline_fact_collector = CmdLineFactCollector()
    # Check results
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()
    

# Generated at 2022-06-11 04:19:20.016663
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()

# Generated at 2022-06-11 04:19:29.966424
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
   c = CmdLineFactCollector()
   assert c.name == 'cmdline'
   assert c._fact_ids == set()

# Generated at 2022-06-11 04:19:31.631869
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fd = CmdLineFactCollector()
    assert cmdline_fd.name == 'cmdline'

# Generated at 2022-06-11 04:19:40.847692
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    my_object = CmdLineFactCollector()

    content = 'ro root=LABEL=/ console=ttyS0,9600'
    my_object._get_proc_cmdline = lambda: content

    my_object.collect()
    # Test command line
    assert len(my_object._fact_ids) == 0
    assert my_object.collect()['cmdline'] == {'ro': True, 'root': 'LABEL=/', 'console': 'ttyS0,9600'}

    # Test /proc/cmdline
    assert len(my_object._fact_ids) == 0
    assert my_object.collect()['proc_cmdline'] == {'ro': True, 'root': 'LABEL=/', 'console': 'ttyS0,9600'}

# Generated at 2022-06-11 04:19:42.575906
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'
    assert collector.collect() == {}

# Generated at 2022-06-11 04:19:50.265410
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    file_stream = ['ansible-test-1=bob\n', 'ansible-test-2=true\n']
    mock_collector = CmdLineFactCollector(file_stream)

    test_ansible_facts = {'cmdline': {'ansible-test-1': 'bob',
                                      'ansible-test-2': True},
                          'proc_cmdline': {'ansible-test-1': 'bob',
                                           'ansible-test-2': True}}

    assert mock_collector.collect() == test_ansible_facts
    return

# Generated at 2022-06-11 04:19:52.329635
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_factcollector = CmdLineFactCollector()
    assert cmdline_factcollector.name == 'cmdline'


# Generated at 2022-06-11 04:19:54.868909
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector.collect(None, None)
    assert cmdline_facts.get('cmdline')
    assert cmdline_facts.get('proc_cmdline')

# Generated at 2022-06-11 04:19:57.620161
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_fact = CmdLineFactCollector()
    cmdline_facts = cmdline_fact.collect()

    assert 'cmdline' not in cmdline_facts and 'proc_cmdline' not in cmdline_facts


# Generated at 2022-06-11 04:20:07.267948
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector()

# Generated at 2022-06-11 04:20:08.749039
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'

# Generated at 2022-06-11 04:20:34.625569
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    data = '''
BOOT_IMAGE=/boot/vmlinuz-3.16.0-30-generic.efi.signed root=UUID=17faa7d0-d00d-418e-a02f-5859fbb88fc3 ro quiet splash vt.handoff=7
'''
    test = CmdLineFactCollector()

    assert test._get_proc_cmdline() == data
    assert test._parse_proc_cmdline('foo bar baz') == {'foo': True, 'bar': True, 'baz': True}
    assert test._parse_proc_cmdline('foo "spaced string"') == {'foo': 'spaced string'}
    assert test._parse_proc_cmdline('') == {}


# Generated at 2022-06-11 04:20:35.182105
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    pass

# Generated at 2022-06-11 04:20:38.836500
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_facts = cmdline_collector.collect()
    assert isinstance(cmdline_facts, dict)
    assert isinstance(cmdline_facts['cmdline'], dict)
    assert isinstance(cmdline_facts['proc_cmdline'], dict)

# Generated at 2022-06-11 04:20:39.843481
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    assert(CmdLineFactCollector().collect() == {})

# Generated at 2022-06-11 04:20:40.788480
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert isinstance(CmdLineFactCollector, object)

# Generated at 2022-06-11 04:20:45.240034
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_facts = cmdline_collector.collect()

    if not cmdline_facts:
        assert False

    if not cmdline_facts.get('cmdline'):
        assert False

    if not cmdline_facts.get('proc_cmdline'):
        assert False

    assert True

# Generated at 2022-06-11 04:20:46.453371
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'

# Generated at 2022-06-11 04:20:52.863426
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Instantiate CmdLineFactCollector
    obj = CmdLineFactCollector()

    # Check that the object is an instance of BaseFactCollector
    assert isinstance(obj, BaseFactCollector)

    # Check that the object is an instance of CmdLineFactCollector
    assert isinstance(obj, CmdLineFactCollector)

    # Check name of object
    assert obj.name == 'cmdline'

    # Check that _fact_ids is set to an empty set
    assert obj._fact_ids == set()


# Generated at 2022-06-11 04:20:55.331637
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    cmdline_facts = collector.collect()

    assert cmdline_facts['proc_cmdline']['console'] == 'ttyS0'


# Generated at 2022-06-11 04:20:56.522519
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector().name == 'cmdline'


# Generated at 2022-06-11 04:21:31.361938
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cf = CmdLineFactCollector()
    assert cf.name == 'cmdline'
    assert cf._fact_ids == set()


# Generated at 2022-06-11 04:21:33.559168
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector_obj = CmdLineFactCollector()
    if cmdline_collector_obj is not None:
        print("Unit test for CmdLineFactCollector.__init__() passed.")



# Generated at 2022-06-11 04:21:35.293385
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'
    assert obj._fact_ids == None



# Generated at 2022-06-11 04:21:36.764871
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name
    assert obj._fact_ids

# Generated at 2022-06-11 04:21:42.590481
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Create a fake ansible module
    class AnsibleModuleFake:
        def __init__(self):
            self.params = {}

    fact_collector = CommandLineFactCollector()
    ansible_module = AnsibleModuleFake()

    # Call the collect method of fact_collector
    result = fact_collector.collect(ansible_module)

    # Check the result
    assert result == {'cmdline': {}, 'proc_cmdline': {}}

# Generated at 2022-06-11 04:21:51.233599
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import os
    import tempfile
    import shutil

    (fd, path) = tempfile.mkstemp()
    with os.fdopen(fd, 'w') as tmp:
        tmp.write("rd.shell rd.break=pre-mount LANG=en_US.UTF-8")

    collector = CmdLineFactCollector()

    result = collector.collect(path=path)

    os.remove(path)


# Generated at 2022-06-11 04:21:53.588815
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = CmdLineFactCollector()
    assert cmdline_facts.name == 'cmdline'
    assert len(cmdline_facts._fact_ids) == 0
 

# Generated at 2022-06-11 04:21:57.588657
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    f = open("/proc/cmdline")
    cmdline_data = f.read()
    f.close()
    f = open("/proc/cmdline", "w")
    f.write("test=test1 test=test2 test1=test2 test2=\"test\"")
    f.close()
    facts = collector.collect()
    f = open("/proc/cmdline", "w")
    f.write(cmdline_data)
    f.close()
    assert 'cmdline' in facts
    assert facts['cmdline']['test1'] == 'test2'
    assert facts['cmdline']['test2'] == 'test'
    assert 'proc_cmdline' in facts

# Generated at 2022-06-11 04:22:06.075332
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_valid = 'BOOT_IMAGE=/boot/vmlinuz-3.10.0-1062.el7.x86_64 root=UUID=db2a4a0b-4f45-4e4d-8ffd-e1abf0a6f4d6 ro crashkernel=auto rd.lvm.lv=centos/root rd.lvm.lv=centos/swap rhgb quiet LANG=en_US.UTF-8'

    c = CmdLineFactCollector()

    def get_file_content_mock(path):
        return cmdline_valid

    c._get_proc_cmdline = get_file_content_mock

    r = c.collect(None, None)


# Generated at 2022-06-11 04:22:07.762054
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline', cmdline_collector.name

# Generated at 2022-06-11 04:23:32.058149
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    result = CmdLineFactCollector.collect()
    assert result.get('cmdline')
    assert result.get('proc_cmdline')

# Generated at 2022-06-11 04:23:33.638543
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert c._fact_ids == set()


# Generated at 2022-06-11 04:23:35.401617
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'
    assert collector._fact_ids == set()


# Generated at 2022-06-11 04:23:43.585614
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    '''
    /proc/cmdline content:
    BOOT_IMAGE=/vmlinuz-3.19.0-15-generic root=/dev/mapper/ubuntu--vg-root ro quiet splash vt.handoff=7
    '''
    import json
    import os

    # Output of shlex.split
    expected_proc_cmdline_answer = ['BOOT_IMAGE=/vmlinuz-3.19.0-15-generic', 'root=/dev/mapper/ubuntu--vg-root', 'ro', 'quiet', 'splash', 'vt.handoff=7']
    # Dict({'BOOT_IMAGE': '/vmlinuz-3.19.0-15-generic', 'root': '/dev/mapper/ubuntu--vg-root', 'ro': True, 'quiet': True, 'splash': True,

# Generated at 2022-06-11 04:23:44.838592
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()

    cmdline_collector.collect()

# Generated at 2022-06-11 04:23:50.243067
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    new_CmdLineFactCollector = CmdLineFactCollector()
    assert new_CmdLineFactCollector.name == 'cmdline'
    assert new_CmdLineFactCollector._fact_ids == set()
    assert isinstance(new_CmdLineFactCollector._get_proc_cmdline(), str)
    assert isinstance(new_CmdLineFactCollector._parse_proc_cmdline("a"), dict)
    assert isinstance(new_CmdLineFactCollector._parse_proc_cmdline_facts("a"), dict)
    assert isinstance(new_CmdLineFactCollector.collect(), dict)

# Generated at 2022-06-11 04:23:54.021302
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():

    # Case: instantiation
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert c._fact_ids == set()
    assert c._get_proc_cmdline() == ''
    assert c._parse_proc_cmdline('') == {}
    assert c._parse_proc_cmdline_facts('') == {}

# Generated at 2022-06-11 04:23:56.073126
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert not cmdline_collector._fact_ids

# Generated at 2022-06-11 04:23:57.096236
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert isinstance(CmdLineFactCollector(), CmdLineFactCollector)

# Generated at 2022-06-11 04:23:58.212463
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()

# Generated at 2022-06-11 04:27:23.144922
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    # We need the following data to be returned from _get_proc_cmdline.
    get_proc_cmdline_data = '''\
DEFAULT_HOSTNAME=ansible DEFAULT_USER=ansible
'''

    # Data returned by _parse_proc_cmdline.
    parse_proc_cmdline_data = {
        'DEFAULT_HOSTNAME': 'ansible',
        'DEFAULT_USER': 'ansible',
    }

    # Data returned by _parse_proc_cmdline_facts.
    parse_proc_cmdline_facts_data = {
        'DEFAULT_HOSTNAME': 'ansible',
        'DEFAULT_USER': 'ansible',
    }

    # Data returned by collect.

# Generated at 2022-06-11 04:27:24.730093
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'
    assert collector._fact_ids == set()


# Generated at 2022-06-11 04:27:26.266926
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'


# Generated at 2022-06-11 04:27:29.818803
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector

test = CmdLineFactCollector()
test_data = test._get_proc_cmdline()
test_dict = test._parse_proc_cmdline(test_data)
test_dict_facts = test._parse_proc_cmdline_facts(test_data)


# Generated at 2022-06-11 04:27:33.242919
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    assert CmdLineFactCollector().collect() == {
        'cmdline': {
            'foo': 'bar',
            'baz': True,
            'asdf': 'ff'
        },
        'proc_cmdline': {
            'foo': 'bar',
            'baz': True,
            'asdf': ['ff', 'ff']
        }
    }



# Generated at 2022-06-11 04:27:34.417804
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    a = CmdLineFactCollector()
    import types
    assert isinstance(a.collect(), types.DictType)

# Generated at 2022-06-11 04:27:35.108047
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()

# Generated at 2022-06-11 04:27:36.456730
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    f = CmdLineFactCollector()
    assert f.name == 'cmdline'
    assert not f._fact_ids


# Generated at 2022-06-11 04:27:38.339486
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert cmdline.name == 'cmdline'
    assert cmdline._fact_ids == set()


# Generated at 2022-06-11 04:27:40.581836
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()
