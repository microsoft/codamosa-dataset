

# Generated at 2022-06-11 04:17:49.040927
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # We can't test this class as it depends on a file.
    pass

# Generated at 2022-06-11 04:17:50.664849
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdlineFactCollector = CmdLineFactCollector()
    assert cmdlineFactCollector is not None


# Generated at 2022-06-11 04:17:52.880378
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()

# Generated at 2022-06-11 04:18:02.114087
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    '''
    Test CmdLineFactCollector.collect
    '''
    c = CmdLineFactCollector()
    test_values = ('a=1', 'b', 'c=2', 'c=3', 'd', 'e=1', 'e=2')
    test_cmdline = ' '.join(test_values)
    exp_result_dict = {
        'a': '1',
        'b': True,
        'c': '3',
        'd': True,
        'e': '2'
    }
    exp_result_list = [
        '1',
        True,
        '3',
        True,
        '2'
    ]
    c.get_file_content = lambda x: test_cmdline
    res = c.collect()

# Generated at 2022-06-11 04:18:03.063726
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()


# Generated at 2022-06-11 04:18:12.733636
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils import basic
    import ansible.module_utils.facts.collector

    cmdline = 'root=UUID=e85621e4-78a7-4c4b-a8ec-3c4f4bf4c730 ro rootflags=compress=zstd'
    cmdline_dict = {'compress': 'zstd', 'rootflags': 'compress=zstd', 'ro': True, 'root': 'UUID=e85621e4-78a7-4c4b-a8ec-3c4f4bf4c730'}

    cmdline_facts = {'cmdline': cmdline_dict, 'proc_cmdline': cmdline_dict}

    cmdline_fact_collector = CmdLineFactCollector()


# Generated at 2022-06-11 04:18:14.322371
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert isinstance(CmdLineFactCollector(), BaseFactCollector)

# Generated at 2022-06-11 04:18:17.471753
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdLineFactCollector = CmdLineFactCollector()
    assert cmdLineFactCollector is not None
    assert cmdLineFactCollector.name == 'cmdline'
    assert cmdLineFactCollector._fact_ids == set()


# Generated at 2022-06-11 04:18:26.749257
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    c = CmdLineFactCollector()

    # No data
    c._get_proc_cmdline = lambda: ''
    assert not c.collect()

    # Simple data
    c._get_proc_cmdline = lambda: 'root=/dev/sda1'
    assert c.collect() == {
        'cmdline': {
            'root': '/dev/sda1',
        },
        'proc_cmdline': {
            'root': '/dev/sda1',
        },
    }

    # Real data

# Generated at 2022-06-11 04:18:27.787888
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()


# Generated at 2022-06-11 04:18:41.873064
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.utils import create_file, remove_file

    data = "  ansible_test1   =   1 ansible_test2 = 2 ansible_test3 = 3"
    path = "/proc/cmdline"
    create_file(path=path, data=data)


# Generated at 2022-06-11 04:18:51.769122
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    # Case when parse_proc_cmdline_facts works properly
    class TestCmdLineFactCollector(CmdLineFactCollector):
        def _get_proc_cmdline(self):
            return 'BOOT_IMAGE=/vmlinuz-3.13.0-36-generic root=UUID=845ac8b2-9b33-4dab-b8f7-c72916c0b7d8 ro quiet splash rd.blacklist=nouveau rd.blacklist=i915 rd.blacklist=i2c_i801'
        def _parse_proc_cmdline_facts(self, data):
            cmdline_facts = {}
            for item in data.split():
                item = item.split('=', 1)

# Generated at 2022-06-11 04:18:53.234491
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    c = CmdLineFactCollector()
    assert c.collect() == {}

# Generated at 2022-06-11 04:19:01.686796
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert isinstance(cmdline_facts, dict)
    assert cmdline_facts['cmdline']['root'] == '/dev/sda1'
    assert cmdline_facts['proc_cmdline']['root'] == '/dev/sda1'
    assert isinstance(cmdline_facts['proc_cmdline']['loglevel'], list) == True
    assert cmdline_facts['proc_cmdline']['loglevel'][0] == '3'
    assert cmdline_facts['proc_cmdline']['loglevel'][1] == '7'
    assert cmdline_facts['proc_cmdline']['x'][0] == '0'
    assert cmdline_facts['proc_cmdline']['x'][1]

# Generated at 2022-06-11 04:19:02.484473
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cfc = CmdLineFactCollector()

# Generated at 2022-06-11 04:19:05.187629
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdlineFactCollector = CmdLineFactCollector()
    assert cmdlineFactCollector.name == 'cmdline'
    assert cmdlineFactCollector._fact_ids == set()

# Test for function parse_proc_cmdline of class CmdLineFactCollector

# Generated at 2022-06-11 04:19:06.653649
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'

# Generated at 2022-06-11 04:19:15.452394
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    module = None
    collected_facts = None

    # good data:
    #
    # format: name=value
    #
    # format: name1=value1\0name2=value2
    cmdline_data = 'name1=value1\0name2=value2'
    proc_cmdline_data = 'name1=value1\0name2=value2\0name3=val=ue3'

    # Expected result
    result = {
        'cmdline': {
            'name1': 'value1',
            'name2': 'value2',
        },
        'proc_cmdline': {
            'name1': 'value1',
            'name2': ['value2', 'val', 'ue3'],
        },
    }

    # When 'get_file_content' returns the good

# Generated at 2022-06-11 04:19:25.060674
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    module = None
    collected_facts = None
    cmdline = CmdLineFactCollector()

    cmdline_facts = cmdline.collect(module, collected_facts)

    assert cmdline_facts['cmdline']['root'] == '/dev/disk/by-uuid/9f4d4179-0a46-4a0f-8cb6-06b638caf10f'
    assert cmdline_facts['proc_cmdline']['root'] == '/dev/disk/by-uuid/9f4d4179-0a46-4a0f-8cb6-06b638caf10f'
    assert cmdline_facts['proc_cmdline']['ro'] == True
    assert cmdline_facts['proc_cmdline']['quiet'] == True

# Generated at 2022-06-11 04:19:34.595624
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import json

    with open('/proc/cmdline') as f:
        lines = f.readlines()
    cmdline_data = lines[0]

    fc = CmdLineFactCollector()
    fc.populate()
    cmdline_facts = fc.collect()

    cmdline_dict = {}
    try:
        for piece in shlex.split(cmdline_data, posix=False):
            item = piece.split('=', 1)
            if len(item) == 1:
                cmdline_dict[item[0]] = True
            else:
                cmdline_dict[item[0]] = item[1]
    except ValueError:
        pass

    assert cmdline_dict == cmdline_facts['cmdline']


# Generated at 2022-06-11 04:19:47.572622
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_object = CmdLineFactCollector()

    assert cmdline_object.name == 'cmdline'

    assert 'cmdline' in cmdline_object._fact_ids


# Generated at 2022-06-11 04:19:48.129650
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    pass

# Generated at 2022-06-11 04:19:56.849987
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
  module = None
  collected_facts = None

# Generated at 2022-06-11 04:19:59.536498
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    cmdline.collect()
    assert (cmdline.name == 'cmdline')
    assert isinstance(cmdline.collect(), dict)

# Generated at 2022-06-11 04:20:00.908684
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert len(c._fact_ids) == 0


# Generated at 2022-06-11 04:20:11.198870
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Create a CmdLineFactCollector object
    cmdline_collector = CmdLineFactCollector()
    # Create a test proc_cmdline string
    test_string = "BOOT_IMAGE=/vmlinuz-3.10.0-123.el7.x86_64  root=/dev/mapper/rhel-root ro rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet LANG=en_US.UTF-8 rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet LANG=en_US.UTF-8"
    # Set proc_cmdline string to test_string
    cmdline_collector._get_proc_cmdline = lambda: test_string
    # Execute method collect

# Generated at 2022-06-11 04:20:21.741953
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    # mocks
    class FakeModule:
        pass

    class FakeCollectedFacts:
        pass

    class FakeCmdLineFactCollector(CmdLineFactCollector):

        def _get_proc_cmdline(self):
            return 'BOOT_IMAGE=\(0\) APPLY_FLG=1'

    # arrange
    fake_module = FakeModule()
    fake_collected_facts = FakeCollectedFacts()

    # act
    returned_cmdline_facts = FakeCmdLineFactCollector().collect(fake_module, fake_collected_facts)

    # assert
    assert 'cmdline' in returned_cmdline_facts
    assert 'proc_cmdline' in returned_cmdline_facts
    assert returned_cmdline_facts['cmdline']['BOOT_IMAGE'] == ''
    assert returned

# Generated at 2022-06-11 04:20:28.181070
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    proc_cmdline_dataset = {}

    proc_cmdline_dataset['/proc/cmdline_without_initrd_empty'] = ''
    proc_cmdline_dataset['/proc/cmdline_without_initrd'] = 'BOOT_IMAGE=/types.cpio.xz root=UUID=56e35c99-8f87-4b82-b9c0-c7f8d9d79b66'
    proc_cmdline_dataset['/proc/cmdline_without_initrd_with_param'] = 'BOOT_IMAGE=/types.cpio.xz root=UUID=56e35c99-8f87-4b82-b9c0-c7f8d9d79b66 param1=param1_value param2=param2_value'

# Generated at 2022-06-11 04:20:37.480938
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # To test the above method of class CmdLineFactCollector, we need to make use
    # of the class itself (& its methods). So we will import it first.
    from ansible.module_utils.facts.system.cmdline import CmdLineFactCollector

    # Creating a class object of CmdLineFactCollector
    cmdline_collector = CmdLineFactCollector()

    # Creating a mock data to be used in place of the data in the "/proc/cmdline"
    mock_data = "BOOT_IMAGE=/boot/vmlinuz-4.4.0-64-generic root=UUID=7946b2e4-4d96-4d4d-b9b9-a86bc533a2e3 ro quiet splash"

    # Here we are mocking the "get_file_content" method to return our

# Generated at 2022-06-11 04:20:39.457545
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector(None)
    assert collector.name == 'cmdline'
    assert 'cmdline' in collector._fact_ids

# Generated at 2022-06-11 04:21:04.885371
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    cmdline_facts = collector.collect()

    if not isinstance(cmdline_facts, dict):
        raise AssertionError('cmdline_facts is {}, should be a dict')

    if not ('proc_cmdline' in cmdline_facts and 'cmdline' in cmdline_facts):
        raise AssertionError('{} does not have the keys proc_cmdline and cmdline')

if __name__ == '__main__':
    import sys
    test_CmdLineFactCollector_collect()
    sys.exit(0)

# Generated at 2022-06-11 04:21:06.033692
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdLineFactCollector = CmdLineFactCollector()
    assert cmdLineFactCollector

# Generated at 2022-06-11 04:21:14.699844
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import unittest.mock as mock
    real_get_file_content = get_file_content
    mock_get_file_content = mock.MagicMock()
    mock_get_file_content.return_value = """cmd3=val3 cmd1=val1 cmd2=val2"""
    get_file_content = mock_get_file_content
    collector = CmdLineFactCollector()
    result = collector.collect()
    mock_get_file_content.assert_has_calls([])

# Generated at 2022-06-11 04:21:15.713283
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()

# Generated at 2022-06-11 04:21:26.379667
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    collector._get_proc_cmdline = lambda: 'BOOT_IMAGE=/boot/vmlinuz-4.14.25-200.fc26.x86_64 ro root=UUID=9bfcdc1d-51ae-4bb8-a0a0-dac7a21ecdda rd.lvm.lv=fedora/swap crashkernel=auto rhgb quiet LANG=en_US.UTF-8'
    cmdline_facts = collector.collect()
    assert 'cmdline' in cmdline_facts
    assert 'proc_cmdline' in cmdline_facts

# Generated at 2022-06-11 04:21:27.235270
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()

# Generated at 2022-06-11 04:21:29.509920
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-11 04:21:35.515043
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    c = CmdLineFactCollector()

# Generated at 2022-06-11 04:21:36.988598
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert not c._fact_ids

# Generated at 2022-06-11 04:21:46.068111
# Unit test for method collect of class CmdLineFactCollector

# Generated at 2022-06-11 04:22:29.841210
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_facts = cmdline_collector.collect()
    assert cmdline_facts is not None
    assert 'cmdline' in cmdline_facts
    assert 'proc_cmdline' in cmdline_facts

# Generated at 2022-06-11 04:22:37.941995
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import popen

    # Set up a stub for popen
    def mocked_popen(data):
        class MockedPopen:
            def __init__(self, data):
                self.data = data

            def read(self):
                return self.data
        return MockedPopen(data)

    popen_data = 'test=test_value other_test'
    popen.popen = mocked_popen(popen_data)

    # Create an instance of the collector
    collector = Collector.collectors['cmdline']()
    # Run the collect method
    actual_cmdline_facts = collector.collect()

# Generated at 2022-06-11 04:22:45.777985
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    def get_file_content(arg):
        return '''root=/dev/sde1 console=tty1 console=ttyS0,115200n8'''

    original_get_file_content = CmdLineFactCollector._get_file_content
    CmdLineFactCollector._get_file_content = get_file_content

    cmdline_facts = CmdLineFactCollector().collect()

    expected_cmdline_facts = {
        'cmdline': {
            'root': '/dev/sde1',
            'console': 'ttyS0,115200n8'
        },
        'proc_cmdline': {
            'root': '/dev/sde1',
            'console': ['tty1', 'ttyS0,115200n8']
        }
    }
    assert cmdline_facts == expected_

# Generated at 2022-06-11 04:22:47.152147
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    result = collector.collect()
    assert result == {}


# Generated at 2022-06-11 04:22:49.298903
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'
    assert isinstance(obj._fact_ids, set)


# Generated at 2022-06-11 04:22:51.323777
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    """
    create an instance of CmdLineFactCollector
    """
    cmdline_facts = CmdLineFactCollector()
    assert isinstance(cmdline_facts.name, str)

# Generated at 2022-06-11 04:22:53.518267
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector is not None
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector.collect() == {}

# Generated at 2022-06-11 04:23:01.671513
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.utils import FactsCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.system.cmdline import CmdLineFactCollector
    facts_collector = FactsCollector(module=None, collected_facts={})
    cmdline_collector = CmdLineFactCollector(module=None, collected_facts={})
    assert isinstance(facts_collector, FactsCollector)
    assert isinstance(cmdline_collector, CmdLineFactCollector)
    assert isinstance(cmdline_collector, Collector)
    assert isinstance(cmdline_collector, BaseFactCollector)
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_

# Generated at 2022-06-11 04:23:04.035715
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = CmdLineFactCollector()
    assert cmdline_facts.name == 'cmdline'

    # Unit test for function _get_proc_cmdline of class CmdLineFactCollector

# Generated at 2022-06-11 04:23:12.383602
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """
    Test facts returned by the collect method of module_util.facts.cmdline.CmdLineFactCollector
    Test both dictionary of key, value and dictionary of key, List values of cmdline
    Test only keys with multi-value cmdline parameters
    """
    # Test 1 with different keys with multi-value cmdline parameters
    data = "root=/dev/mapper/vg_vm191-lv_root ro elevator=noop rootflags=alloc console='tty0 console=ttyS0,115200n8'"

# Generated at 2022-06-11 04:24:49.183203
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert c._fact_ids == set()


# Generated at 2022-06-11 04:24:50.204588
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'

# Generated at 2022-06-11 04:24:57.576712
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    result = CmdLineFactCollector().collect()
    assert result['cmdline'] == {'quiet': True, 'selinux=0': True, 'splash': True, 'ipv6.disable=1': True, 'rd.md=0': True, 'rhgb': True, 'ro': True, 'root=UUID=a844f36d-2e2f-43eb-823b-3a7f4a4b9f4b': True, 'vconsole.keymap=uk': True, 'rd.luks=0': True, 'rd.lvm.lv=fedora/swap': True, 'rd.lvm.lv=fedora/root': True, 'LANG=en_US.UTF-8': True}

# Generated at 2022-06-11 04:24:59.310089
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector(None, None)
    assert collector.name == 'cmdline'
    assert collector._fact_ids == set()

# Generated at 2022-06-11 04:25:06.438312
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    data = ''' CONSOLE=/dev/hvc0 TERM=linux ehci_hcd.park=3 compcache=12288@0x00000000,2097152@0x70000000,2097152@0x80000000,2097152@0x90000000 ip=::::::dhcp iscsi_firmware iscsi_mod.def_login_timeout=120 dm_multipath.map_flush_interval=100 rootdelay=60 net.ifnames=0 biosdevname=0 cgroup_enable=memory swapaccount=1 devfssetup.devtmpfs_do=yes root=/dev/vda2 rw
USER_GID=500 USER_UID=500'''


# Generated at 2022-06-11 04:25:13.306924
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    c = CmdLineFactCollector()
    data = b"root=UUID=asdf verbose rhgb crashkernel=auto   quiet"
    with c.get_file_content_mock(data):
        assert c.collect() == {
            'cmdline': {'root': 'UUID=asdf', 'verbose': True, 'rhgb': True, 'crashkernel': 'auto', 'quiet': True},
            'proc_cmdline': {'root': 'UUID=asdf', 'verbose': True, 'rhgb': True, 'crashkernel': 'auto', 'quiet': True}
        }

# Generated at 2022-06-11 04:25:14.604067
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Constructor test
    cmdline_facts = CmdLineFactCollector()
    assert cmdline_facts

# Generated at 2022-06-11 04:25:18.490280
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Create a CmdLineFactCollector object and collect cmdline facts
    collector = CmdLineFactCollector()
    cmdline_facts = collector.collect()

    assert isinstance(cmdline_facts, dict)
    assert 'cmdline' in cmdline_facts
    assert 'proc_cmdline' in cmdline_facts
    assert isinstance(cmdline_facts['cmdline'], dict)
    assert isinstance(cmdline_facts['proc_cmdline'], dict)

# Generated at 2022-06-11 04:25:25.305086
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """Unit test for method collect of class CmdLineFactCollector"""

    def get_file_content(filename):
        return 'foo=bar ro'

    class MockModule(object):
        def __init__(self):
            self.params = dict()

    cmdline_fact_collector = CmdLineFactCollector()
    cmdline_fact_collector.get_file_content = get_file_content
    facts = cmdline_fact_collector.collect(MockModule())
    assert facts['cmdline']['foo'] == 'bar'
    assert facts['cmdline']['ro']

    assert facts['proc_cmdline']['foo'] == 'bar'
    assert facts['proc_cmdline']['ro']

# Generated at 2022-06-11 04:25:29.622874
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_fact_collector = CmdLineFactCollector()

    cmdline_facts = cmdline_fact_collector.collect()

    assert "cmdline" in cmdline_facts
    assert "proc_cmdline" in cmdline_facts

    assert isinstance(cmdline_facts["cmdline"], dict)
    assert isinstance(cmdline_facts["proc_cmdline"], dict)