

# Generated at 2022-06-11 04:17:53.557155
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # mock facts module
    facts_module_mock = Mock()

    # create instance of class CmdLineFactCollector
    fact_collector = CmdLineFactCollector()

    # test method collect
    fact_collector.collect(facts_module_mock)

# Generated at 2022-06-11 04:17:55.598327
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert c._fact_ids == set()


# Generated at 2022-06-11 04:17:58.086097
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_obj = CmdLineFactCollector()
    assert cmdline_obj is not None

# Unit test to check _get_proc_cmdline()

# Generated at 2022-06-11 04:18:07.144014
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts import Collector
    # test data
    td = [
        {
            "name": "cmdline",
            "proc_cmdline": {
                "ansible": "test_value",
                "ansible2": [
                    "test_value1",
                    "test_value2",
                ],
                "ansible3": True,
            },
            "cmdline": {
                "ansible": "test_value",
                "ansible2": "test_value1",
                "ansible3": True,
            }
        }
    ]
    # create and init Collector
    collector = Collector()
    collector.collect_cmdline_facts = True
    # mock _get_proc_cmdline

# Generated at 2022-06-11 04:18:17.216101
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.cmdline import CmdLineFactCollector

    Collector._instance = None

    collector = CmdLineFactCollector()


# Generated at 2022-06-11 04:18:19.197635
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    aCmdLineFactCollector = CmdLineFactCollector()
    assert aCmdLineFactCollector is not None


# Generated at 2022-06-11 04:18:24.855043
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    test_obj = CmdLineFactCollector()
    # get_file_content() returns random values
    data = test_obj._get_proc_cmdline()
    assert isinstance(data, str)
    assert '=' in data

    result = test_obj._parse_proc_cmdline(data)
    assert isinstance(result, dict)

    result = test_obj._parse_proc_cmdline_facts(data)
    assert isinstance(result, dict)

# Generated at 2022-06-11 04:18:26.930586
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    '''
    Unit test for the `CmdLineFactCollector` class.
    '''
    CmdLineFactCollector()

# Generated at 2022-06-11 04:18:29.618136
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    ccmdline_obj = CmdLineFactCollector()
    assert ccmdline_obj.name == 'cmdline' #test the object name and initialization


# Generated at 2022-06-11 04:18:30.872295
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.collect()


# Generated at 2022-06-11 04:18:42.154532
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line = CmdLineFactCollector()

    # Verify that the name member is set to 'cmdline' as expected
    assert cmd_line.name == 'cmdline'

# Generated at 2022-06-11 04:18:43.133059
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector


# Generated at 2022-06-11 04:18:48.048355
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert isinstance(c._collection_warnings, list)
    assert isinstance(c._fact_ids, set)
    assert c._fact_ids == set()
    assert isinstance(c._collected_facts, dict)
    assert c._collected_facts == {}


# Generated at 2022-06-11 04:18:48.998712
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()

# Generated at 2022-06-11 04:18:50.703838
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = CmdLineFactCollector()
    assert cmdline_facts.name == 'cmdline'

# Generated at 2022-06-11 04:18:59.716455
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Create an instance of class CmdLineFactCollector
    collector = CmdLineFactCollector()

    # Create a proc cmdline
    data = 'BOOT_IMAGE=/vmlinuz-3.10.0-327.el7.x86_64 root=UUID=3a7f98c1-fcbb-4faa-a1a7-9c049c93b315 rw ro'

    # Create a cmdline
    cmdline = 'BOOT_IMAGE=/vmlinuz-3.10.0-327.el7.x86_64 root=UUID=3a7f98c1-fcbb-4faa-a1a7-9c049c93b315 rw ro'

    # Create a proc_cmdline

# Generated at 2022-06-11 04:19:00.611996
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert True, "constructor can be executed"

# Generated at 2022-06-11 04:19:04.464970
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    fact_collector = CmdLineFactCollector()
    print(fact_collector)
    # assert fact_collector == "name"
    print(fact_collector.name)
    # assert fact_collector.name =="cmdline"
    print(fact_collector._fact_ids)
    # assert fact_collector._fact_ids == set()


# Generated at 2022-06-11 04:19:06.567109
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-11 04:19:07.863130
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert c._fact_ids == set()


# Generated at 2022-06-11 04:19:18.250285
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'

# Generated at 2022-06-11 04:19:27.908946
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = {}
    cmdline_facts['proc_cmdline'] = {
        'console': 'ttyS0',
        'earlyprintk': 'ttyS0',
        'ro': True,
        'root': 'LABEL=SLES-VHD-15SP1-12.2-0',
        'vga': 'text',
        'x11': True
    }
    cmdline_facts['cmdline'] = {
        'console': 'ttyS0',
        'earlyprintk': 'ttyS0',
        'ro': True,
        'root': 'LABEL=SLES-VHD-15SP1-12.2-0',
        'vga': 'text',
        'x11': True
    }


# Generated at 2022-06-11 04:19:37.622099
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector

    CmdLineFactCollector._fact_ids.clear()

    # Test with no module or collected_facts
    result = CmdLineFactCollector().collect()

    assert result == {}

    # Test with empty /proc/cmdline file
    CmdLineFactCollector._fact_ids.clear()

    class TestObj(object):
        def __init__(self):
            self.path = 'cmdline_test'
            self.content = ''

    mock_file = TestObj()
    current_file = BaseFactCollector.FILE_MAPPING['/proc/cmdline']


# Generated at 2022-06-11 04:19:38.648873
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()

# Generated at 2022-06-11 04:19:40.583241
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd = CmdLineFactCollector()
    assert cmd.name == 'cmdline'
    assert cmd._fact_ids == set()

# Generated at 2022-06-11 04:19:43.367407
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()

# Generated at 2022-06-11 04:19:44.965720
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == "cmdline"

# Generated at 2022-06-11 04:19:54.401788
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_data = """
BOOT_IMAGE=/vmlinuz-4.4.0-17134-Microsoft root=/dev/sda1 ro rootflags=subvol=@ rootfstype=btrfs initrd=/initramfs.img initrd=/initramfs-4.4.0-17134-Microsoft.img
"""
    collector = CmdLineFactCollector()
    cmdline_facts = collector._parse_proc_cmdline_facts(cmdline_data)

    assert cmdline_facts['BOOT_IMAGE'] == '/vmlinuz-4.4.0-17134-Microsoft'
    assert cmdline_facts['root'] == '/dev/sda1'
    assert cmdline_facts['ro'] == True
    assert cmdline_facts['rootflags'] == 'subvol=@'
    assert cmdline_

# Generated at 2022-06-11 04:19:55.565183
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cf = CmdLineFactCollector()
    assert cf.name == 'cmdline'

# Generated at 2022-06-11 04:19:56.386640
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()

# Generated at 2022-06-11 04:20:16.147723
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():

    # Test instantiation of CmdLineFactCollector
    test_collector = CmdLineFactCollector()
    assert test_collector is not None

# Generated at 2022-06-11 04:20:25.355959
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    my_cmdline_data = """root=/dev/mapper/vg_host01-root
        ro crashkernel=auto rd.lvm.lv=vg_host01/root
        rd.lvm.lv=vg_host01/swap
        LANG=en_US.UTF-8 console=tty0 console=ttyS0,115200
        """

    collector = CmdLineFactCollector()
    collector._get_proc_cmdline = lambda: my_cmdline_data
    collector._parse_proc_cmdline = CmdLineFactCollector._parse_proc_cmdline
    collector._parse_proc_cmdline_facts = CmdLineFactCollector._parse_proc_cmdline_facts

    cmdline_facts = collector.collect()

    assert len(cmdline_facts) == 2
    assert cmdline_facts

# Generated at 2022-06-11 04:20:34.950242
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Constructor - passes
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()

    # Constructor - fails
    try:
        cmdline_collector = CmdLineFactCollector(name='example_name')
        assert cmdline_collector.name == 'example_name'
    except Exception as e:
        assert e.args[0] == 'The fact collecting module example_name is not supported.'

    try:
        cmdline_collector = CmdLineFactCollector(name=['example'])
        assert cmdline_collector.name == 'example'
    except Exception as e:
        assert e.args[0] == 'The fact collecting module example is not supported.'

# Tests for

# Generated at 2022-06-11 04:20:36.929145
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdLine = CmdLineFactCollector()
    assert 'cmdline' == cmdLine.name
    assert not cmdLine._fact_ids

# Generated at 2022-06-11 04:20:39.921201
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.__class__.__name__ == 'CmdLineFactCollector'
    assert cmdline_fact_collector._fact_ids == set()

# Generated at 2022-06-11 04:20:43.341560
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """
    Unit test for method collect of class CmdLineFactCollector
    """
    cmdline_fact_collector = CmdLineFactCollector()
    actual_result = cmdline_fact_collector.collect()

    assert isinstance(actual_result, dict)

# Generated at 2022-06-11 04:20:47.447733
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """ Unit test for method collect of class CmdLineFactCollector """
    #pylint: disable=no-member
    cmdline = CmdLineFactCollector()
    cmdline_facts = cmdline.collect()
    assert 'cmdline' in cmdline_facts
    assert 'proc_cmdline' in cmdline_facts

# Generated at 2022-06-11 04:20:49.265331
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()


# Generated at 2022-06-11 04:20:50.155077
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert c.collect() == {}

# Generated at 2022-06-11 04:20:55.962810
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import ansible.module_utils.facts.collectors.cmdline
    from ansible.module_utils.facts.collectors import get_collector_status
    from ansible.module_utils.facts.collectors.cmdline import CmdLineFactCollector

    CmdLineFactCollector.collect(None, None)
    print(CmdLineFactCollector.name, get_collector_status(CmdLineFactCollector))
    CmdLineFactCollector.collect(None, None)



# Generated at 2022-06-11 04:21:40.885805
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    ''' Unit test for method collect of class CmdLineFactCollector '''

# Generated at 2022-06-11 04:21:49.499421
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Cannot test this on a Jenkins slave.
    import os
    if os.environ.get('JENKINS_URL', False):
        pass
    else:
        from ansible.module_utils.facts.collector.cmdline import CmdLineFactCollector

        # For this test case, the content of /proc/cmdline is "BOOT_IMAGE=/vmlinuz-3.13.0-88-generic root=UUID=61d25872-fae6-4f6b-9061-5536bf5f6b71 ro vt.handoff=7"

# Generated at 2022-06-11 04:21:58.577769
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    data_ = collector.collect()

# Generated at 2022-06-11 04:22:00.490029
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector is not None


# Generated at 2022-06-11 04:22:01.916775
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_obj = CmdLineFactCollector()
    assert cmdline_obj.name == 'cmdline'

# Generated at 2022-06-11 04:22:03.209180
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fc = CmdLineFactCollector()
    assert cmdline_fc.name == 'cmdline'


# Generated at 2022-06-11 04:22:04.075865
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()

# Generated at 2022-06-11 04:22:05.473918
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fc = CmdLineFactCollector()
    assert cmdline_fc is not None


# Generated at 2022-06-11 04:22:06.952414
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    
    cmdline = CmdLineFactCollector()
    assert cmdline.name == 'cmdline'

# Generated at 2022-06-11 04:22:09.465409
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    """Unit test for constructor of class CmdLineFactCollector"""
    my_obj = CmdLineFactCollector()
    assert hasattr(my_obj, 'name')
    assert type(my_obj._fact_ids) is set

# Generated at 2022-06-11 04:23:41.611144
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'
    assert obj._fact_ids == set()


# Generated at 2022-06-11 04:23:48.649835
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.system.cmdline import CmdLineFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    collector = CmdLineFactCollector()
    assert isinstance(collector, CmdLineFactCollector)
    assert isinstance(collector, Collector)

    collector.get_file_content = get_file_content
    setattr(collector, '_get_proc_cmdline', lambda: 'rd.lvm.lv=system/root rhgb quiet' )
    collected_facts = collector.collect()
    assert 'cmdline' in collected_facts
    assert 'proc_cmdline' in collected_facts

    assert isinstance(collected_facts['cmdline'], dict)

# Generated at 2022-06-11 04:23:49.385952
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()

# Generated at 2022-06-11 04:23:56.838556
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts import collector

    # Test data
    test_data = [{'cmdline': 'ansible_module_generated_test_cmdline', 'proc_cmdline': {'ansible_module_generated_test_proc_cmdline': True}}]

    # CmdLineFactCollector object
    cmd_line_fact_collector = CmdLineFactCollector()

    # test method collect of class CmdLineFactCollector
    def test_collect(test_data):
        test_cmd_line_fact_collector = CmdLineFactCollector()

        # Generate test data
        with open('/proc/cmdline', 'w') as f:
            f.write(test_data['cmdline'])

        # Get cmdline facts
        cmdline_facts = test_cmd_line_fact

# Generated at 2022-06-11 04:24:04.723043
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_dict = dict()
    cmdline_dict['root'] = '/dev/mapper/cl-root'
    cmdline_dict['ro'] = True
    cmdline_dict['vmalloc.iommu_merge'] = '1'
    cmdline_dict['selinux=1'] = True
    cmdline_dict['crashkernel=auto'] = True
    cmdline_dict['console=ttyS0,115200n8'] = True
    cmdline_dict['console=tty0'] = True
    cmdline_dict['no_timer_check'] = True
    cmdline_dict['numa_mempolicy=interleave'] = True
    cmdline_dict['noapic'] = True
    cmdline_dict['loglevel=3'] = True

# Generated at 2022-06-11 04:24:05.600432
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    pass


# Generated at 2022-06-11 04:24:07.792916
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    with open('module_utils/facts/cmdline.py') as f:
        assert(f.read() == c.content)


# Generated at 2022-06-11 04:24:13.736928
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    # testing the method when data is empty
    cmd_line = CmdLineFactCollector()
    assert cmd_line.collect() == {}

    # testing the method when data is not empty
    data = 'BOOT_IMAGE=/bzImage-3.10.0-862.3.3.el7.x86_64 root=UUID=4eb4c4b4-c5b5-4f5d-b5b5-5b5e5d5b5eb5 ro crashkernel=auto rd.lvm.lv=centos/root rd.lvm.lv=centos/swap'

# Generated at 2022-06-11 04:24:15.948463
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert isinstance(obj, BaseFactCollector)
    assert obj.name == 'cmdline'
    assert not obj._fact_ids


# Generated at 2022-06-11 04:24:23.658155
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_data = 'BOOT_IMAGE=/vmlinuz-3.10.0-327.10.1.el7.x86_64 root=/dev/mapper/rhel-root ro crashkernel=auto rhgb quiet console=tty0 console=ttyS0,115200n8'