

# Generated at 2022-06-11 04:17:58.614855
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    test_system_facts = dict()
    cmdline_fact_collector = CmdLineFactCollector(None, test_system_facts)
    cmdline_fact_collector._get_proc_cmdline = lambda: '# \tcomment \t!=/= test \\'
    cmdline_fact_collector._parse_proc_cmdline = lambda data: dict(data)
    cmdline_fact_collector._parse_proc_cmdline_facts = lambda data: dict(data)
    expected_cmdline_facts = {'cmdline': {'#': '\\', 'comment': '\\', '!': '=', '/': '=', 'test': '\\\\'}, 'proc_cmdline': {'#': '\\', 'comment': '\\', '!': '=', '/': '=', 'test': '\\\\'}}


# Generated at 2022-06-11 04:18:01.303111
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_collector = CmdLineFactCollector()

    assert 'cmdline' == cmd_line_collector.name
    assert 'cmdline' == CmdLineFactCollector.name

# Generated at 2022-06-11 04:18:03.668455
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    fc = CmdLineFactCollector()
    assert fc.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()


# Generated at 2022-06-11 04:18:04.939782
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'

# Generated at 2022-06-11 04:18:06.960832
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert 'cmdline' == collector.name
    assert set() == collector._fact_ids


# Generated at 2022-06-11 04:18:17.066018
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    proc_cmdline_txt = '''BOOT_IMAGE=/vmlinuz-4.8.6-300.fc25.x86_64 root=/dev/mapper/fedora-root ro rd.lvm.lv=fedora/root rd.lvm.lv=fedora/swap rhgb quiet LANG=en_US.UTF-8'''
    setattr(CmdLineFactCollector, '_get_proc_cmdline', lambda self: proc_cmdline_txt)

    collector = CmdLineFactCollector()
    facts = collector.collect()

    assert facts['cmdline']['BOOT_IMAGE'] == '/vmlinuz-4.8.6-300.fc25.x86_64'
    assert facts['cmdline']['root'] == '/dev/mapper/fedora-root'


# Generated at 2022-06-11 04:18:26.335295
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline = CmdLineFactCollector()

    cmdline._get_proc_cmdline = lambda: 'root=/dev/mapper/vg_vm0-lv_root ro console=ttyS0'
    cmdline_facts = cmdline.collect()
    assert cmdline_facts['cmdline'] == {'root': '/dev/mapper/vg_vm0-lv_root', 'ro': True, 'console': 'ttyS0'}

    cmdline._get_proc_cmdline = lambda: 'root=/dev/mapper/vg_vm0-lv_root ro console=ttyS0'
    cmdline_facts = cmdline.collect()

# Generated at 2022-06-11 04:18:27.693443
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    c = CmdLineFactCollector()
    c.collect()

# Generated at 2022-06-11 04:18:35.323207
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """Test that the class CmdLineFactCollector properly collects cmdline
    facts.
    """
    class MockFile:
        def __init__(self, data):
            self.data = data
            self.called = False

        def read(self):
            self.called = True
            return self.data

    # Test when /proc/cmdline exists and is not empty
    cmdline_data = 'root=/dev/sda1 ro console=ttyS0,38400n8'
    current_file = MockFile(cmdline_data)
    mock_file = {'get_file_content': current_file.read}
    cmdline_facts = CmdLineFactCollector(None, mock_file).collect()
    assert current_file.called

# Generated at 2022-06-11 04:18:45.538734
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    fact_collector = CmdLineFactCollector()
    facts = fact_collector.collect()

# Generated at 2022-06-11 04:18:56.138864
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert len(CmdLineFactCollector._fact_ids) == 0


# Generated at 2022-06-11 04:18:57.717846
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()

# Generated at 2022-06-11 04:18:59.621470
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    fact_collector = CmdLineFactCollector()

    assert fact_collector.name == 'cmdline'
    assert fact_collector._fact_ids == set()


# Generated at 2022-06-11 04:19:00.424803
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    pass


# Generated at 2022-06-11 04:19:07.415334
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    from ansible.module_utils.facts.collectors import get_collector_instance
    from ansible.module_utils.facts.collectors.cmdline import CmdLineFactCollector
    from ansible.module_utils.facts.collectors import base_collector

    # Instantiate CmdLineFactCollector object using get_collector_instance() method
    obj = get_collector_instance(CmdLineFactCollector.__name__)

    # Check instance is created or not
    assert isinstance(obj, CmdLineFactCollector)

    # Check instance is created of right class or not
    assert isinstance(obj, base_collector.BaseFactCollector)

    # Check object obj._name data attribute is properly set or not
    assert obj._name == 'cmdline'

    # Check object obj._fact_ids data attribute is properly

# Generated at 2022-06-11 04:19:16.324557
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.utils import get_file_content

    def fake_get_file_content(path):
        if path == '/proc/cmdline':
            return ('this=is root=/dev/mapper/centos_myhostname-root'
                    ' ro crashkernel=auto  quiet LANG=en_US.UTF-8'
                    ' rd_NO_LUKS KEYBOARDTYPE=pc KEYTABLE=us'
                    ' rd_NO_MD rd_NO_DM rhgb'
                    ' console=tty0 console=ttyS0,115200n8 net.ifnames=0 biosdevname=0')
        return None


# Generated at 2022-06-11 04:19:17.994242
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdLineFactCollectorObj = CmdLineFactCollector()
    assert cmdLineFactCollectorObj is not None

# Generated at 2022-06-11 04:19:21.566030
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector_obj = CmdLineFactCollector()
    assert cmdline_fact_collector_obj
    assert cmdline_fact_collector_obj.name == 'cmdline'
    assert cmdline_fact_collector_obj._fact_ids == set()

# Generated at 2022-06-11 04:19:23.358126
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    print('Test method collect of class CmdLineFactCollector')
    print('Not yet implemented')

# Generated at 2022-06-11 04:19:32.871829
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import re
    import json

    # Test invalid /proc/cmdline
    fake_data = "invalid cmdline"
    collector = CmdLineFactCollector()
    cmdline_facts = collector._parse_proc_cmdline(fake_data)
    assert cmdline_facts == {}

    # Test valid /proc/cmdline
    fake_data = "loglevel=3 console=ttyS0,9600n8 quiet SYSFONT=latarcyrheb-sun16 BOOT_IMAGE=vmlinuz-3.10.0-229.14.1.el7.x86_64"
    with open('test_Output/test_CmdLineFactCollector_collect.json', 'rt') as fh:
        test_data = json.load(fh)
    collector = CmdLineFactCollector()


# Generated at 2022-06-11 04:19:43.782808
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'
    assert obj._fact_ids == set()


# Generated at 2022-06-11 04:19:46.673870
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = CmdLineFactCollector()
    assert cmdline_facts.name == 'cmdline'
    assert cmdline_facts._fact_ids == set()


# Generated at 2022-06-11 04:19:47.759413
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()

# Generated at 2022-06-11 04:19:49.800274
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'


# Generated at 2022-06-11 04:19:58.409708
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Create a test instance of class CmdLineFactCollector
    test = CmdLineFactCollector(None)
    # Add a file /tmp/test_cmdline with a random text in it
    with open('/tmp/test_cmdline', 'w') as f:
        f.write("test_key test_value test_key=test_value")
    # Call the collect method of test instance
    facts = test.collect()
    # Get the content of the file
    file_content = get_file_content('/tmp/test_cmdline')
    # Make the comparison
    assert facts['proc_cmdline'] == {'test_key': ['test_value', 'test_value']}
    assert facts['cmdline'] == {'test_key': 'test_value'}
    assert facts['cmdline'] == test._parse

# Generated at 2022-06-11 04:20:08.232247
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    """ Unit test for class CmdLineFactCollector """
    cmdline_fact_collector = CmdLineFactCollector()
    _proc_cmdline = "root=/dev/sda2 ro crashkernel=auto rd.lvm.lv=fedora/root rd.lvm.lv=fedora/swap rhgb quiet LANG=en_US.UTF-8"
    _cmdline_facts = cmdline_fact_collector._parse_proc_cmdline_facts(_proc_cmdline)

# Generated at 2022-06-11 04:20:09.437799
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()

# Generated at 2022-06-11 04:20:20.273711
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    fake_data_proc_cmdline = 'BOOT_IMAGE=/vmlinuz-3.10.0-327.el7.x86_64 root=UUID=9c5a8bb5-6cf0-4d5b-b140-6337dda60adc ro console=tty0 console=ttyS0,115200n8 biosdevname=0 net.ifnames=0'
    fake_cmdline_dict = {'BOOT_IMAGE': '/vmlinuz-3.10.0-327.el7.x86_64', 'root': 'UUID=9c5a8bb5-6cf0-4d5b-b140-6337dda60adc', 'ro': True, 'console': 'tty0', 'biosdevname': '0', 'net.ifnames': '0'}

# Generated at 2022-06-11 04:20:22.013644
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj
    assert obj.name == 'cmdline'


# Generated at 2022-06-11 04:20:23.542546
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'


# Generated at 2022-06-11 04:20:48.996785
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    mock_module = {}
    mock_collected_facts = {}

    cmdline_collector = CmdLineFactCollector

    expected_cmdline_facts = {'cmdline': {'BOOT_IMAGE': '/kernel', 'root': '/dev/mapper/root'}, 'proc_cmdline': {'BOOT_IMAGE': '/kernel', 'root': '/dev/mapper/root'}}

    actual_cmdline_facts = CmdLineFactCollector.collect(mock_module, mock_collected_facts)

    assert actual_cmdline_facts == expected_cmdline_facts


# Generated at 2022-06-11 04:20:52.928910
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    import sys
    sys.path.append('/Users/zengjf/Documents/github/ansible/ansible/module_utils/facts')
    print(sys.path)

    cmdline_fact_collector = CmdLineFactCollector()
    print(cmdline_fact_collector.collect())

# Generated at 2022-06-11 04:20:54.414476
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()

# Unit tests for methods of class CmdLineFactCollector

# Generated at 2022-06-11 04:21:03.312594
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    '''
    We need to mock the method _get_proc_cmdline of class CmdLineFactCollector

    The mock is needed because the method _get_proc_cmdline calls
    get_file_content method of class utils.get_file_content
    '''
    CmdLineFactCollector._get_proc_cmdline = lambda x: "root=/dev/sda1 rw quiet splash"

    cmdline_facts = CmdLineFactCollector().collect()

    assert cmdline_facts['cmdline'] == {'root': '/dev/sda1', 'rw': True, 'quiet': True, 'splash': True}
    assert cmdline_facts['proc_cmdline'] == {'root': '/dev/sda1', 'rw': True, 'quiet': True, 'splash': True}

# Generated at 2022-06-11 04:21:10.571899
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """
    Test the collect method of CmdLineFactCollector
    """
    proc_cmdline_data = "cmdline1=value1 cmdline2=value2 cmdline3"
    c = CmdLineFactCollector()
    c._get_proc_cmdline = lambda: proc_cmdline_data
    cmdline_facts = c.collect()

    assert(cmdline_facts['cmdline'] == {'cmdline1': 'value1', 'cmdline2': 'value2', 'cmdline3': True})
    assert(cmdline_facts['proc_cmdline'] == {'cmdline1': 'value1', 'cmdline2': 'value2', 'cmdline3': True})

# Generated at 2022-06-11 04:21:13.067599
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert CmdLineFactCollector is c.__class__

if __name__ == '__main__':
    test_CmdLineFactCollector()

# Generated at 2022-06-11 04:21:14.654730
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collected_facts = {}
    
    CmdLineFactCollector().collect(collected_facts=collected_facts)

# Generated at 2022-06-11 04:21:15.172960
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    pass

# Generated at 2022-06-11 04:21:20.126932
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Test: create object and verify it has all the required methods
    cmdline_obj = CmdLineFactCollector()
    assert cmdline_obj.name == 'cmdline'
    methods = dir(cmdline_obj)
    assert 'collect' in methods
    assert '_get_proc_cmdline' in methods
    assert '_parse_proc_cmdline' in methods
    assert '_parse_proc_cmdline_facts' in methods

# Generated at 2022-06-11 04:21:23.973333
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact = CmdLineFactCollector()
    assert cmdline_fact.name == 'cmdline'
    print('Construction success!')


# Generated at 2022-06-11 04:22:11.222837
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    # Given
    _fact_ids = set()
    _module = None
    _collected_facts = None
    _collector = CmdLineFactCollector()
    _collector._get_proc_cmdline = lambda: "quiet rd.auto=1 intel_iommu=on rd.lvm.lv=fedora/swap rd.lvm.lv=fedora/root rhgb"
    _collector._parse_proc_cmdline = lambda x: {'quiet': True, 'rd.auto': '1', 'intel_iommu': 'on', 'rd.lvm.lv': 'fedora/root', 'rhgb': True}

# Generated at 2022-06-11 04:22:19.220852
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    def _get_proc_cmdline():
        return 'BOOT_IMAGE=/vmlinuz-4.4.0-31-generic root=UUID=e27b7241-35d4-4259-bab4-47a7a698b9a9 ro quiet splash ipv6.disable=1'

    def _parse_proc_cmdline(data):
        return {'BOOT_IMAGE': '/vmlinuz-4.4.0-31-generic',
                'root': 'UUID=e27b7241-35d4-4259-bab4-47a7a698b9a9',
                'ro': True,
                'quiet': True,
                'splash': True,
                'ipv6.disable': '1'}


# Generated at 2022-06-11 04:22:26.865231
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.cmdline import CmdLineFactCollector

    cur_cmdline_Collector = CmdLineFactCollector('/proc/cmdline')

    # Tests for version 7.x
    version_7_facts = {
        'BOOT_IMAGE': '/vmlinuz-4.9.0-6-amd64',
        'root': '/dev/mapper/debian--vg-root',
        'ro': True,
        'init': '/lib/systemd/systemd'
    }

# Generated at 2022-06-11 04:22:28.040271
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()

    assert c is not None

# Generated at 2022-06-11 04:22:29.767950
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    facts = collector.collect()
    assert 'cmdline' in facts
    assert 'proc_cmdline' in facts

# Generated at 2022-06-11 04:22:36.955491
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # TestCase1: if not data then return empty dict
    fact_collector = CmdLineFactCollector()
    assert fact_collector.collect() == {}

    # TestCase2: if data then return parsed dict
    data = "a=1 b=2 c"
    fact_collector = CmdLineFactCollector()

    assert fact_collector._get_proc_cmdline() == data
    assert fact_collector._parse_proc_cmdline(data) == {'a': '1', 'b': '2', 'c': True}
    assert fact_collector._parse_proc_cmdline_facts(data) == {'a': '1', 'b': '2', 'c': True}

# Generated at 2022-06-11 04:22:39.688773
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()

    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()

    cmdline_fact_collector.collect()

# Generated at 2022-06-11 04:22:41.128479
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()

if __name__ == '__main__':
    test_CmdLineFactCollector()

# Generated at 2022-06-11 04:22:42.255746
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    # Initialize
    CmdLineFactCollector.collect()

# Generated at 2022-06-11 04:22:43.364299
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    x = CmdLineFactCollector()
    assert x.name == 'cmdline'

# Generated at 2022-06-11 04:24:20.205722
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    c = get_collector_instance(CmdLineFactCollector)
    c.collect()
    assert c.name == 'cmdline'

# Generated at 2022-06-11 04:24:24.952814
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible_collections.ansible.community.plugins.module_utils.facts import collector

    cmdline_facts = collector.get_collector('cmdline').collect()
    required = {
        'cmdline': {'ansible_test': 'myvalue', 'ansible_cmdline': True},
        'proc_cmdline': {'ansible_test': ['myvalue', 'othervalue']}
    }
    assert cmdline_facts == required

# Generated at 2022-06-11 04:24:26.755003
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == "cmdline"
    assert c._fact_ids == set()

# Generated at 2022-06-11 04:24:29.470047
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-11 04:24:37.506040
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()

    # Test 1: No data returned
    # Expected result: {}
    data = ''
    assert cmdline_collector._parse_proc_cmdline(data) == {}
    assert cmdline_collector._parse_proc_cmdline_facts(data) == {}

    # Test 2: All data returned are seperated by spaces
    # Expected result: {'a':True, 'b':True, 'c':True}
    data = 'a b c'
    assert cmdline_collector._parse_proc_cmdline(data) == {'a': True, 'b': True, 'c': True}
    assert cmdline_collector._parse_proc_cmdline_facts(data) == {'a': True, 'b': True, 'c': True}

   

# Generated at 2022-06-11 04:24:42.435540
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Get the cmdline contents
    cmdline_1 = CmdLineFactCollector()._get_proc_cmdline()
    # Get the parsed data
    data = CmdLineFactCollector()._parse_proc_cmdline(cmdline_1)
    data1 = CmdLineFactCollector()._parse_proc_cmdline_facts(cmdline_1)
    # Pass the parsed data to collect method
    data2 = CmdLineFactCollector().collect(None, data)
    # Test to assert True
    assert data2 is not None

# Generated at 2022-06-11 04:24:44.421340
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cf = CmdLineFactCollector()
    assert not cf.limit
    assert not cf.conditions
    assert cf.name == 'cmdline'

# Generated at 2022-06-11 04:24:51.700407
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Create an instance of CmdLineFactCollector
    cmdline_fact_collector = CmdLineFactCollector()

    # Check the instance is a subclass of BaseFactCollector
    assert issubclass(type(cmdline_fact_collector), BaseFactCollector)
    # Check the instance is a CmdLineFactCollector type
    assert isinstance(cmdline_fact_collector, CmdLineFactCollector)
    # Check the instance has the correct name
    assert cmdline_fact_collector.name == 'cmdline'
    # Check the instance has the correct fact_ids
    assert len(cmdline_fact_collector._fact_ids) == 0
    # Check the instance has the correct mandatory_facts
    assert len(cmdline_fact_collector.mandatory_facts) == 0


# Generated at 2022-06-11 04:24:53.185938
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    actual = CmdLineFactCollector()
    assert actual is not None
    assert actual.name == 'cmdline'

# Generated at 2022-06-11 04:24:54.944547
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'
    assert collector._fact_ids == set()
