

# Generated at 2022-06-11 04:17:51.401444
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Check if required parameters are present
    x = CmdLineFactCollector()
    assert x.name == 'cmdline'
    assert isinstance(x._fact_ids, set)



# Generated at 2022-06-11 04:17:54.602667
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    instance_of_CmdLineFactCollector = CmdLineFactCollector()
    assert instance_of_CmdLineFactCollector.name == 'cmdline'
    assert instance_of_CmdLineFactCollector._fact_ids == set()


# Generated at 2022-06-11 04:17:58.522047
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    result = cmdline_collector.collect()
    fact_key = 'cmdline'
    assert fact_key in result
    fact_key = 'proc_cmdline'
    assert fact_key in result
    assert result[fact_key] != ''

# Generated at 2022-06-11 04:18:00.882122
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdlinefactcollector = CmdLineFactCollector()
    assert cmdlinefactcollector.name == "cmdline"
    assert cmdlinefactcollector._fact_ids == set()

# Generated at 2022-06-11 04:18:08.241710
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_fact_collector = CmdLineFactCollector()
    # test data
    cmdline_data = "modprobe.blacklist=bcm43xx cmdline=this is a test"
    # run module
    cmdline_facts = cmdline_fact_collector.collect()
    #validate results
    assert cmdline_facts['cmdline']['cmdline'] == 'this is a test'
    assert cmdline_facts['proc_cmdline']['modprobe.blacklist'] == 'bcm43xx'
    assert cmdline_facts['proc_cmdline']['cmdline'] == 'this is a test'



# Generated at 2022-06-11 04:18:09.773678
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()


# Generated at 2022-06-11 04:18:19.475090
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import os
    from ansible.module_utils.facts import collector

    local_collector = collector.get('CmdLineFactCollector')

    # When /proc/cmdline has data
    local_collector._get_proc_cmdline = lambda: 'cmd1=1 cmd2=value1 cmd3=value2 cmd4 cmd5=value3'

    # Call method collect
    cmdline_facts = local_collector.collect()

    # Assert method collect works properly
    assert cmdline_facts['cmdline'] == {'cmd1': '1', 'cmd2': 'value1', 'cmd3': 'value2', 'cmd4': True, 'cmd5': 'value3'}

# Generated at 2022-06-11 04:18:29.127638
# Unit test for method collect of class CmdLineFactCollector

# Generated at 2022-06-11 04:18:30.787386
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector is not None

# Generated at 2022-06-11 04:18:36.632531
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Create and instance of CmdLineFactCollector
    CmdLineFactCollector = CmdLineFactCollector()

    # Remove the file /proc/cmdline if it exists
    import os, errno

# Generated at 2022-06-11 04:18:46.837793
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    c = CmdLineFactCollector()
    assert c.collect()

# Generated at 2022-06-11 04:18:56.463770
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_fact_collector = CmdLineFactCollector(None, None)

    def get_file_content(path):
        return "   selinux=0  intel_iommu=off root=UUID=d6b08c6b-cc6f-49cd-a80f-bffc08b9a20a   "

    cmdline_fact_collector._get_proc_cmdline = get_file_content

    cmdline_facts = cmdline_fact_collector.collect()

# Generated at 2022-06-11 04:19:04.333511
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    proc_cmdline_content = 'BOOT_IMAGE=/vmlinuz-3.10.0-229.14.1.el7.x86_64 root=/dev/mapper/rhel-root ro crashkernel=auto rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet LANG=en_US.UTF-8'
    mock_get_file_content = lambda x: proc_cmdline_content
    module = None
    collected_facts = None
    test_obj = CmdLineFactCollector()
    test_obj._get_proc_cmdline = mock_get_file_content

# Generated at 2022-06-11 04:19:12.957048
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    _cmdline_collector = CmdLineFactCollector()
    _cmdline_collector._get_proc_cmdline = lambda: '''
                                                    BOOT_IMAGE=/vmlinuz-4.4.0-92-generic.efi.signed
                                                    root=UUID=d98abce6-c651-4a82-b8ea-f735b1a374b7 
                                                    ro quiet splash vt.handoff=7
                                                    '''
    cmdline_facts = _cmdline_collector.collect()


# Generated at 2022-06-11 04:19:15.315634
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert cmdline.name == 'cmdline'
    assert cmdline._fact_ids == set()


# Generated at 2022-06-11 04:19:17.724093
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():

    assert CmdLineFactCollector()
    assert CmdLineFactCollector().name == 'cmdline'
    assert CmdLineFactCollector()._fact_ids == set()

# Generated at 2022-06-11 04:19:19.129829
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.uuid is None

# Generated at 2022-06-11 04:19:28.814059
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import tempfile
    from ansible.module_utils.facts.collector import collector_registry


# Generated at 2022-06-11 04:19:31.933750
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-11 04:19:34.721108
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert cmdline.name == 'cmdline'
    assert cmdline._fact_ids == set()


# Generated at 2022-06-11 04:19:52.563987
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    import ansible.module_utils.facts.collector
    ansible.module_utils.facts.collector.BaseFactCollector = BaseFactCollector

    from ansible.module_utils.facts.collector.cmdline import CmdLineFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class CmdLineFactCollectorTest(CmdLineFactCollector):
        def _get_proc_cmdline(self):
            return "a=b a=c a=d"

    data = CmdLineFactCollectorTest().collect()
    assert {'cmdline': {'a': 'd'}, 'proc_cmdline': {'a': ['b', 'c', 'd']}} == data

# Generated at 2022-06-11 04:20:01.343326
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_content = 'ansible_managed=true ansible_command_timeout=60'
    ansible_mock = AnsibleMock(content=cmdline_content)
    module_mock = Mock()
    module_mock.get_bin_path.return_value = 'true'
    collected_facts = Mock()
    c = CmdLineFactCollector()
    c._get_proc_cmdline = ansible_mock.get_file_content
    result = c.collect(module=module_mock, collected_facts=collected_facts)
    assert result == {'cmdline': {'ansible_managed': 'true', 'ansible_command_timeout': '60'}, 'proc_cmdline': {'ansible_managed': 'true', 'ansible_command_timeout': '60'}}

#

# Generated at 2022-06-11 04:20:02.588256
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():

    c = CmdLineFactCollector()
    assert c.name == 'cmdline'

# Generated at 2022-06-11 04:20:13.469710
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import pytest

    from ansible.module_utils.facts.collector import BaseFactCollector

    class TestCmdLineFactCollector(CmdLineFactCollector):
        def _get_proc_cmdline(self):
            return 'a=b b c=d=e d=f'

    cmdline_facts = {
        'cmdline': {
            'a': 'b',
            'b': True,
            'c': 'd=e',
            'd': 'f'
        },
        'proc_cmdline': {
            'a': 'b',
            'b': True,
            'c': ['d=e', 'd=f']
        }
    }
    result_facts = TestCmdLineFactCollector().collect()

    assert isinstance(result_facts, dict)

# Generated at 2022-06-11 04:20:15.698232
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = CmdLineFactCollector()
    assert cmdline_facts.name == 'cmdline'


# Generated at 2022-06-11 04:20:25.056894
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_fact_collector = CmdLineFactCollector()

    # Test output if empty /proc/cmdline
    returned_facts = cmdline_fact_collector._get_proc_cmdline()
    assert returned_facts == ''

    # Test output if /proc/cmdline is populated
    returned_facts = cmdline_fact_collector._parse_proc_cmdline('root=UUID=f121e32a-c452-4040-8e2c-ceb1e325f0c0 ro rhgb quiet')
    assert returned_facts == {'root': 'UUID=f121e32a-c452-4040-8e2c-ceb1e325f0c0', 'ro': True, 'rhgb': True, 'quiet': True}

    # Test output if /proc/cmdline has duplicate key

# Generated at 2022-06-11 04:20:33.361600
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    output = collector.collect()
    assert output['cmdline']['BOOT_IMAGE'] == 'vmlinuz-2.6.32-4-amd64'
    assert output['cmdline']['root'] == '/dev/mapper/root-root'
    assert len(output['cmdline']) == 10
    assert output['proc_cmdline']['BOOT_IMAGE'] == 'vmlinuz-2.6.32-4-amd64'
    assert output['proc_cmdline']['root'] == '/dev/mapper/root-root'
    assert len(output['proc_cmdline']) == 10

# Generated at 2022-06-11 04:20:34.852659
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert_equals(obj.name, "cmdline")

# Generated at 2022-06-11 04:20:35.381806
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    pass

# Generated at 2022-06-11 04:20:38.337800
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline', \
        "Command line facts already registered."
    assert obj._fact_ids == set(), \
        "Command line facts already registered."


# Generated at 2022-06-11 04:20:59.879333
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Create an instance of class CmdLineFactCollector 
    collector = CmdLineFactCollector()

    # Assert that the name of the class is set to 'cmdline'
    assert collector.name == 'cmdline'

    # Assert that the _fact_ids for the class is set
    assert len(collector._fact_ids) > 0

# Generated at 2022-06-11 04:21:01.928063
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    fact_collector = CmdLineFactCollector()
    assert fact_collector.collect(module=None, collected_facts=None) == {}

# Generated at 2022-06-11 04:21:05.398635
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    test_data = 'BOOT_IMAGE=/vmlinuz-3.16.0-2-amd64 root=UUID=2e9277eb-29e9-477c-8b03-ddd5e23e6788 ro quiet'

    c = CmdLineFactCollector()
    c._get_proc_cmdline = lambda: test_data

    cmdline_facts = c.collect()


# Generated at 2022-06-11 04:21:14.022754
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import pytest
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector.cmdline import CmdLineFactCollector

    test_obj = CmdLineFactCollector()

    with pytest.raises(IOError):
        test_obj._get_proc_cmdline()
    with pytest.raises(ValueError):
        test_obj._parse_proc_cmdline_facts('-abc=1 def')
    test_obj._parse_proc_cmdline_facts('-abc=1 def=')
    assert test_obj.collect() == {'proc_cmdline': {}, 'cmdline': {}}

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import default_collectors

    ansible = Ansible

# Generated at 2022-06-11 04:21:17.266055
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import ansible.module_utils.facts.collectors.cmdline as cmdline

    data = cmdline._get_proc_cmdline()

    cmdline_facts = cmdline._parse_proc_cmdline_facts(data)

    print(cmdline_facts)

# Generated at 2022-06-11 04:21:27.890331
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    data = (
        "BOOT_IMAGE=/vmlinuz-4.9.0-8-amd64 "
        "root=/dev/mapper/debian--vg-root ro "
        "nouveau.modeset=0 "
        "SYSFONT=latarcyrheb-sun16 "
        "console=tty1 "
        "console=ttyS0,115200n8"
    )

# Generated at 2022-06-11 04:21:34.538153
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    fake_cmdline_content = b"""
BOOT_IMAGE=/vmlinuz-4.4.0-53-generic.efi.signed root=/dev/mapper/ubuntu--vg-root ro rootflags=subvol=@ quiet splash vt.handoff=7
"""

# Generated at 2022-06-11 04:21:38.849001
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    module = mock.Mock()
    cmd_line_fact_collector = CmdLineFactCollector(module)
    assert cmd_line_fact_collector.name == 'cmdline'
    assert cmd_line_fact_collector.module == module
    assert cmd_line_fact_collector._fact_ids == set()

# Generated at 2022-06-11 04:21:40.766406
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert cmdline.name == 'cmdline'
    assert cmdline._fact_ids == set()

# Generated at 2022-06-11 04:21:42.032355
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == "cmdline"

# Generated at 2022-06-11 04:22:28.965744
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_dict = {'console': 'ttyS0,115200',
                    'ro': True,
                    'root': '/dev/mmcblk0p2'}

    path = 'ansible/module_utils/facts/collector/cmdline.py'
    CmdLineFactCollector_obj = CmdLineFactCollector(file_path=path)
    CmdLineFactCollector_obj._get_proc_cmdline = lambda : 'console=ttyS0,115200 ro root=/dev/mmcblk0p2'
    assert CmdLineFactCollector_obj.collect() == {'cmdline': cmdline_dict, 'proc_cmdline': cmdline_dict}


# Generated at 2022-06-11 04:22:37.065228
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    module = None
    collected_facts = None
    data = 'console=ttyS0 root=/dev/sda3 mtdparts=phys_mapped_flash:640K(boot0)ro,640K(boot1)ro,3136K(linux),896K(root),5120K(app),-(config)'

    with open('/proc/cmdline', 'w') as f:
        f.write(data)

    cmdline = CmdLineFactCollector()
    cmdline_facts = cmdline.collect(module, collected_facts)


# Generated at 2022-06-11 04:22:44.949171
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import CmdLineFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines

    import re

    # Check the case when /proc/cmdline is not defined
    cmdline_data = ''
    get_file_content_original = get_file_content

    def get_file_content_mock(path):
        return cmdline_data

    get_file_content.get_file_content = get_file_content_mock

    cmdline_collector = CmdLineFactCollector()
    fact = cmdline_collector.collect()

    get_file_content.get_file_content = get_file_content_original

    assert fact == {}

   

# Generated at 2022-06-11 04:22:51.594573
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    
    # When proc_cmdline is empty
    collector.get_file_content = lambda path: ' '
    assert collector.collect() == {'cmdline': {}, 'proc_cmdline': {}}
    
    # When proc_cmdline is not empty
    collector.get_file_content = lambda path: 'a=a b=b c=c c=c'
    assert collector.collect() == {'cmdline': {'a': 'a', 'b': 'b', 'c': 'c'}, 'proc_cmdline': {'a': 'a', 'b': 'b', 'c': ['c', 'c']}}

# Generated at 2022-06-11 04:22:59.269876
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()

    cmdline_data = """\
BOOT_IMAGE=/boot/vmlinuz-2.6.32-573.el6.x86_64 root=UUID=6a037fd0-a163-4040-b3a6-f9c3e1ce2b2c ro rd_NO_LUKS rd_NO_LVM LANG=en_US.UTF-8 rd_NO_MD rd_NO_DM KEYBOARDTYPE=pc KEYTABLE=us SYSFONT=latarcyrheb-sun16 crashkernel=auto rhgb quiet rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap"""

# Generated at 2022-06-11 04:23:07.008938
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector.read_file = MagicMock(return_value='root=/dev/sda1 console=ttyS0 edd=off elevator=deadline')
    cmdline_collector.data = {}

    data = cmdline_collector.collect()

    assert data == { 'cmdline': {'root': '/dev/sda1', 'console': 'ttyS0', 'edd': True, 'elevator': 'deadline'},
                     'proc_cmdline': {'root': '/dev/sda1', 'console': 'ttyS0', 'edd': True, 'elevator': 'deadline'},
                   }


# Generated at 2022-06-11 04:23:09.522104
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()

# Generated at 2022-06-11 04:23:11.238584
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    """
    This function unit tests the constructor of class CmdLineFactCollector
    """
    results = CmdLineFactCollector()
    assert results == None

# Generated at 2022-06-11 04:23:18.805315
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Setup Test
    cmdline = "ro root=UUID=f8e2c0da-d805-49b9-9ba9-3a677f71f3c0 rd.lvm.lv=zerombr/swap rd.lvm.lv=zerombr/root rhgb quiet"

    # Make a fact collector for the 'cmdline' fact, and execute it
    cmdline_fc = CmdLineFactCollector()
    cmdline_fc_results = cmdline_fc.collect(collected_facts=None)

    # Test collection output

# Generated at 2022-06-11 04:23:21.090148
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector(None)
    assert cmdline_collector.name == "cmdline"
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-11 04:24:58.933162
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert 'cmdline' == cmdline_fact_collector.name

# Generated at 2022-06-11 04:25:02.320760
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    fact_collector = CmdLineFactCollector()
    result = fact_collector._collect()
    assert 'cmdline' in result
    assert isinstance(result['cmdline'], dict)
    assert 'proc_cmdline' in result
    assert isinstance(result['proc_cmdline'], dict)


# Generated at 2022-06-11 04:25:09.510113
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    m_open = mock_open(read_data='ro quiet')
    with patch('ansible.module_utils.facts.collector.os.access', return_value=True), \
         patch('ansible.module_utils.facts.collector.open', m_open, create=True):
        cmdline_facts = CmdLineFactCollector().collect()

        assert 'cmdline' in cmdline_facts
        assert isinstance(cmdline_facts['cmdline'], dict)
        assert cmdline_facts['cmdline'] == {'ro': True, 'quiet': True}
        assert 'proc_cmdline' in cmdline_facts
        assert isinstance(cmdline_facts['proc_cmdline'], dict)
        assert cmdline_facts['proc_cmdline'] == {'ro': True, 'quiet': True}

# Generated at 2022-06-11 04:25:16.741065
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # given
    collector = CmdLineFactCollector()
    collector._get_proc_cmdline = lambda: 'foo=bar baz abc.def=xyz'

    # when
    result = collector.collect()

    # then
    assert result['cmdline']['foo'] == 'bar'
    assert result['cmdline']['baz'] == True
    assert result['cmdline']['abc.def'] == 'xyz'

    assert result['proc_cmdline']['foo'] == 'bar'
    assert result['proc_cmdline']['baz'] == True
    assert result['proc_cmdline']['abc.def'] == 'xyz'

# Generated at 2022-06-11 04:25:17.676891
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'

# Generated at 2022-06-11 04:25:24.985425
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    lc = CmdLineFactCollector()
    lc.get_file_content = lambda path: 'BOOT_IMAGE=/vmlinuz-2.6.32-431.el6.x86_64 root=UUID=c6fbe2ec-2e6c-44db-8694-cf12acb82a60 ro crashkernel=auto rd.lvm.lv=vg_prv/lv_swap rd.lvm.lv=vg_prv/lv_root LANG=en_US.UTF-8 rhgb console=ttyS0,115200'
    result = lc.collect()

# Generated at 2022-06-11 04:25:26.742268
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert c._fact_ids == set()


# Generated at 2022-06-11 04:25:28.816961
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'
    assert obj._fact_ids == set()



# Generated at 2022-06-11 04:25:31.681311
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector._fact_ids == set()
    assert cmdline_fact_collector.name == "cmdline"



# Generated at 2022-06-11 04:25:39.745255
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """
    Unit test for method CmdLineFactCollector._get_proc_cmdline
    """