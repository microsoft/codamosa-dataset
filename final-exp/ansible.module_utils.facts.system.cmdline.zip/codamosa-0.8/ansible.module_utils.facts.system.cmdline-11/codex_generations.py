

# Generated at 2022-06-11 04:17:51.865721
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdlinefact_obj = CmdLineFactCollector()
    assert cmdlinefact_obj is not None

# Generated at 2022-06-11 04:17:53.256564
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector() is not None


# Generated at 2022-06-11 04:17:56.011612
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():

   # Create new instance of class CmdLineFactCollector
   obj = CmdLineFactCollector()
   assert obj

   # Test value of name attribute
   assert obj.name == 'cmdline'

# Generated at 2022-06-11 04:17:57.402612
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cf = CmdLineFactCollector()
    assert cf.collect()

# Generated at 2022-06-11 04:17:59.768470
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c1 = CmdLineFactCollector()
    assert c1.name == 'cmdline'
    assert c1._fact_ids == set()



# Generated at 2022-06-11 04:18:01.396330
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    fact_collector = CmdLineFactCollector()
    assert fact_collector.name == 'cmdline'

# Generated at 2022-06-11 04:18:02.279718
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()

# Generated at 2022-06-11 04:18:04.340189
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cf = CmdLineFactCollector()
    assert cf.name == 'cmdline'
    assert cf._fact_ids == set()


# Generated at 2022-06-11 04:18:07.007545
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    cmdline_facts = collector.collect()
    assert 'proc_cmdline' in cmdline_facts
    assert 'cmdline' in cmdline_facts

# Generated at 2022-06-11 04:18:14.915415
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    fact_collector = CmdLineFactCollector()
    response = fact_collector._get_proc_cmdline()
    cmdline_facts = fact_collector.collect(collected_facts=response)
    assert len(cmdline_facts) == 2
    assert cmdline_facts['cmdline']['BOOT_IMAGE'] == '/vmlinuz-3.10.0-327.el7.x86_64'
    assert cmdline_facts['proc_cmdline']['BOOT_IMAGE'] == '/vmlinuz-3.10.0-327.el7.x86_64'

# Generated at 2022-06-11 04:18:33.009282
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    cmdline_facts = collector.collect()

# Generated at 2022-06-11 04:18:34.615755
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()

    assert cmdline_collector.name == 'cmdline'

# Generated at 2022-06-11 04:18:39.313692
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    """
    This function is used to test the constructor of class CmdLineFactCollector
    :return: None
    """
    cmd_line_fact_collector = CmdLineFactCollector()
    expected_values = "cmdline"
    assert expected_values == cmd_line_fact_collector.name
    assert not cmd_line_fact_collector._fact_ids

# Generated at 2022-06-11 04:18:41.920837
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert hasattr(collector, '_fact_ids')
    assert collector.name == 'cmdline'

# Generated at 2022-06-11 04:18:51.754987
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    fact_collector = CmdLineFactCollector()

    # Test case with valid data
    def get_file_content_mock(filename):
        if filename == "/proc/cmdline":
            return "BOOT_IMAGE=bootimage BOOTIF="
        else:
            raise Exception('Unexpected filename')

    fact_collector.get_file_content = get_file_content_mock
    data = fact_collector.collect()
    assert data == {'cmdline': {'BOOTIF': True, 'BOOT_IMAGE': 'bootimage'},
                    'proc_cmdline': {'BOOTIF': True, 'BOOT_IMAGE': 'bootimage'}}

    # Test case with empty data

# Generated at 2022-06-11 04:19:00.463379
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    file_content = "cmdline1=value1 cmdline2=value2 cmdline3 cmdline4=value4=1 cmdline5=value5 cmdline6= value6 = cmdline7 =value7"
    def mocked__get_proc_cmdline():
        return file_content

    collector = CmdLineFactCollector()
    collector._get_proc_cmdline = mocked__get_proc_cmdline
    cmdline_facts = collector.collect()

    assert 'cmdline' in cmdline_facts
    assert 'proc_cmdline' in cmdline_facts

    assert cmdline_facts['cmdline']['cmdline1'] == 'value1'
    assert cmdline_facts['cmdline']['cmdline2'] == 'value2'
    assert cmdline_facts['cmdline']['cmdline3'] == True
   

# Generated at 2022-06-11 04:19:05.654884
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    with open('/proc/cmdline', 'w') as cmdline_file:
        cmdline_file.write('foo=bar baz=bar')

    collector = CmdLineFactCollector()

    cmdline_facts = collector.collect()

    assert cmdline_facts.get('proc_cmdline') == {'foo': 'bar', 'baz': 'bar'}
    assert cmdline_facts.get('cmdline') == {'foo': 'bar', 'baz': 'bar'}

    cmdline_file.close()

# Generated at 2022-06-11 04:19:07.403497
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'
    assert collector._fact_ids == set()

# Generated at 2022-06-11 04:19:09.319193
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    f = CmdLineFactCollector()
    assert f.name == 'cmdline'
    assert f._fact_ids == set()


# Generated at 2022-06-11 04:19:12.617227
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    result = collector.collect()

    # If a file does not exist, we return empty dictionary.
    assert result == {}, \
            "test_CmdLineFactCollector_collect(): by default it should return an empty dictionary"

# Generated at 2022-06-11 04:19:39.794303
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert c._fact_ids == set()
    assert c._get_proc_cmdline() == 'ro root=/dev/mapper/vg-lv_root crashkernel=128M rd.lvm.lv=vg/lv_root rd.lvm.lv=vg/lv_swap rd.lvm.lv=vg/lv_home quiet SYSFONT=latarcyrheb-sun16 LANG=en_US.UTF-8'

# Generated at 2022-06-11 04:19:49.675585
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    CmdLineFactCollector._get_proc_cmdline = lambda x: 'BOOT_IMAGE=/vmlinuz-4.4.0-36-generic root=/dev/sda1 ro console=ttyS0 root=LABEL=cloudimg-rootfs'
    cmdline_facts = CmdLineFactCollector().collect()

    assert cmdline_facts['cmdline'] == {'BOOT_IMAGE': '/vmlinuz-4.4.0-36-generic',
                                        'root': '/dev/sda1', 
                                        'ro': True,
                                        'console': 'ttyS0',
                                        'root=LABEL': 'cloudimg-rootfs'}


# Generated at 2022-06-11 04:19:52.015136
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_obj = CmdLineFactCollector()
    assert cmd_obj.name == 'cmdline'
    assert cmd_obj._fact_ids == set()


# Generated at 2022-06-11 04:20:00.665238
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import collect_subset_list
    from ansible.module_utils.facts.collector import collect_subset
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts.utils import get_file_content

    def get_file_content_mock(filename):
        return b"I-am-the-proc-cmdline"

    class Check(object):
        def __init__(self, cmdline='I-am-the-proc-cmdline'):
            self.cmdline = cmdline
            self.cmdline_dict = {}
            self.proc_cmdline_facts_dict = {}
            self.collect_subset_list = {}
            self.collect_subset = {}
            self.get_all_

# Generated at 2022-06-11 04:20:02.379184
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line = CmdLineFactCollector()
    assert cmd_line.name == 'cmdline'


# Generated at 2022-06-11 04:20:04.503745
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    x = CmdLineFactCollector()
    assert x.name == 'cmdline'
    assert len(x._fact_ids) == 0

# Generated at 2022-06-11 04:20:07.470161
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()

# Generated at 2022-06-11 04:20:17.182156
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()

    assert collector.collect() == {
        'cmdline': {
            'BOOT_IMAGE': 'kernel',
            'PCI': 1,
            'ro': True,
            'root': '/dev/sda1',
            'somekey': 'somevalue',
            'somekey2': 'somevalue,anothervalue'
        },
        'proc_cmdline': {
            'BOOT_IMAGE': 'kernel',
            'PCI': '1',
            'ro': True,
            'root': '/dev/sda1',
            'somekey': 'somevalue',
            'somekey2': ['somevalue', 'anothervalue']
        }
    }

# Generated at 2022-06-11 04:20:26.066316
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import AnsibleModule
    cmdline_collector = CmdLineFactCollector()
    module = AnsibleModule.AnsibleModule(
      argument_spec={},
      supports_check_mode=True
    )

# Generated at 2022-06-11 04:20:29.435532
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()

    assert c.name == 'cmdline', 'test_CmdLineFactCollector assert #1 has failed.'
    assert c._fact_ids == set(), 'test_CmdLineFactCollector assert #2 has failed.'

# Generated at 2022-06-11 04:20:50.242452
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert hasattr(cmdline, 'name')
    assert cmdline.name == 'cmdline'
    assert hasattr(cmdline, '_fact_ids')
    assert isinstance(cmdline._fact_ids, set)


# Generated at 2022-06-11 04:20:59.051421
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # default return value for get_file_content
    def mock_get_file_content(path):
        return '/usr/sbin/sshd -D'

    class myClass(object):
        def __init__(self, cmdline):
            self.cmdline = cmdline

    class myCollector(CmdLineFactCollector):
        def __init__(self, module=None, collected_facts=None):
            CmdLineFactCollector.__init__(self, module=module, collected_facts=collected_facts)
            self.get_file_content = mock_get_file_content

    my_collector = myCollector()
    my_collector.collect()

# Generated at 2022-06-11 04:21:00.764594
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'


# Generated at 2022-06-11 04:21:01.928446
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'

# Generated at 2022-06-11 04:21:04.502851
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = CmdLineFactCollector()
    assert cmdline_facts.name == 'cmdline'
    assert cmdline_facts._fact_ids == set()


# Generated at 2022-06-11 04:21:13.030724
# Unit test for method collect of class CmdLineFactCollector

# Generated at 2022-06-11 04:21:15.753320
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    lfc = CmdLineFactCollector()
    assert lfc.name == CmdLineFactCollector.name
    assert lfc._fact_ids == CmdLineFactCollector._fact_ids

# Generated at 2022-06-11 04:21:26.466744
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """Test CmdLineFactCollector.collect()"""
    mock_module = "mock module"

    # test 1
    mock_collected_fact = "mock collected fact"
    expected = {'cmdline': {'one': 'two', 'three': True, 'four': True},
                'proc_cmdline': {'one': 'two', 'three': True, 'four': True}
                }

    # create mock objects
    mock_instance = CmdLineFactCollector()
    mock_instance._get_proc_cmdline = lambda: "one=two three four"
    mock_instance._parse_proc_cmdline = lambda x: {'one': 'two', 'three': True, 'four': True}

# Generated at 2022-06-11 04:21:33.640405
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    data = 'cmdline=test with spaces b=c a=d t=True r=False f=/tmp/ansible_test.txt'
    data2 = 'cmdline=test with spaces i=3 r=False f=/tmp/ansible_test.txt i=4 i=5'

    cmdline_facts = {}
    cmdline_facts['cmdline'] = {'cmdline': 'test with spaces', 'b': 'c', 'a': 'd', 't': True, 'r': 'False', 'f': '/tmp/ansible_test.txt'}
    cmdline_facts['proc_cmdline'] = {'cmdline': 'test with spaces', 'b': 'c', 'a': 'd', 't': True, 'r': False, 'f': '/tmp/ansible_test.txt'}

    cmdline_facts

# Generated at 2022-06-11 04:21:36.687040
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    #arrange
    cmdline_fact_collector = CmdLineFactCollector()
    #act
    result = cmdline_fact_collector.collect()
    #assert
    assert 'cmdline' in result
    assert 'proc_cmdline' in result

# Generated at 2022-06-11 04:22:18.749482
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector(None).name == 'cmdline'
    assert CmdLineFactCollector(None)._fact_ids == frozenset()
    assert CmdLineFactCollector(None)._cache == {}


# Generated at 2022-06-11 04:22:26.349325
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import ansible_collector

    base_collector = ansible_collector.BaseFileCollector()
    cmdline_collector = CmdLineFactCollector()

    base_collector.cache = cache.FactCache()
    cmdline_collector.cache = base_collector.cache

    cmdline_collector._get_proc_cmdline = lambda: 'abc'
    facts = cmdline_collector.collect()

    assert facts['cmdline']['abc'] == True
    assert facts['proc_cmdline']['abc'] == True

    cmdline_collector._get_proc_cmdline = lambda: 'abc=hello'
    facts = cmdline_collector.collect()


# Generated at 2022-06-11 04:22:28.855512
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-11 04:22:30.268965
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.collect() == {}

# Generated at 2022-06-11 04:22:33.173057
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    facts = CmdLineFactCollector()
    # Ensure collector is initialized
    assert facts.name == 'cmdline'
    assert 'cmdline' in facts._fact_ids
    assert 'proc_cmdline' in facts._fact_ids

# Generated at 2022-06-11 04:22:35.185944
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = CmdLineFactCollector()
    assert cmdline_facts.name is not None
    assert cmdline_facts._fact_ids is not None


# Generated at 2022-06-11 04:22:36.536928
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'

# Generated at 2022-06-11 04:22:39.310254
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():

    # Test cluster_setup
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-11 04:22:41.057054
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector is not None
    assert collector.name == 'cmdline'


# Generated at 2022-06-11 04:22:41.819133
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # No tests for constructor since no constructor
    pass

# Generated at 2022-06-11 04:24:20.446277
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert c._fact_ids == set()
    assert c._get_proc_cmdline() == 'BOOT_IMAGE=/boot/vmlinuz-4.4.0-62-generic root=UUID=9a4ea0af-6d43-4cff-a408-68f3ff5c5a83 ro quiet splash vt.handoff=7'

# Generated at 2022-06-11 04:24:20.902837
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    pass

# Generated at 2022-06-11 04:24:22.819834
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'
    assert len(obj._fact_ids) == 0


# Generated at 2022-06-11 04:24:23.366984
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    pass

# Generated at 2022-06-11 04:24:31.530421
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """
    Unit test for method collect of class CmdLineFactCollector
    """
    import platform

    kub_cmdline_str = (
        "swapaccount=1 BOOT_IMAGE=(hd0,msdos1)/boot/vmlinuz-"
        "3.10.0-514.16.1.el7.x86_64 root=UUID=593a7a60-d3e3-4d64-a27f"
        "-9dd5554fdbfc ro crashkernel=auto rd.lvm.lv=centos/root"
        " rd.lvm.lv=centos/swap rhgb quiet LANG=en_US.UTF-8"
        " console=ttyS0,115200n8"
    )

# Generated at 2022-06-11 04:24:34.066249
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    '''
    Add description of test here
    '''
    facts = CmdLineFactCollector().collect()
    assert 'cmdline' in facts
    assert 'proc_cmdline' in facts

# Generated at 2022-06-11 04:24:39.014826
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()

    assert isinstance(cmdline_facts['cmdline'], dict)
    assert isinstance(cmdline_facts['proc_cmdline'], dict)

    assert cmdline_facts['proc_cmdline']['rd.driver.blacklist'] == 'nouveau,i915' and \
           cmdline_facts['cmdline']['rd.driver.blacklist'] == 'nouveau,i915'



# Generated at 2022-06-11 04:24:41.204572
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    result = collector.collect()
    assert isinstance(result, dict)
    assert 'cmdline' in result
    assert isinstance(result['cmdline'], dict)

# Generated at 2022-06-11 04:24:49.018202
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # import has to be done here to avoid import cycle problems
    from ansible.module_utils.facts.collectors import collector_module

    # create our fake module
    fake_module = collector_module.AnsibleModuleStub()

    # get the Class which shall be tested
    clazz = collector_module.get_collector_class('cmdline')
    assert clazz == CmdLineFactCollector

    # init the class
    obj = clazz(fake_module)

    # test the call
    cmdline_facts = obj.collect()
    assert isinstance(cmdline_facts, dict)
    assert 'cmdline' in cmdline_facts
    assert isinstance(cmdline_facts['cmdline'], dict)
    assert 'proc_cmdline' in cmdline_facts

# Generated at 2022-06-11 04:24:50.022661
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    x = CmdLineFactCollector()
    assert x.name == 'cmdline'