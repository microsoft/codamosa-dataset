

# Generated at 2022-06-11 04:17:48.418265
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()


# Generated at 2022-06-11 04:17:49.997920
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    print ("Constructor of class CmdLineFactCollector")
    instance = CmdLineFactCollector()
    assert instance

# Generated at 2022-06-11 04:17:52.120609
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    module = AnsibleModule(argument_spec={})
    assert isinstance(CmdLineFactCollector(module=module), CmdLineFactCollector)

# Generated at 2022-06-11 04:18:01.479481
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Create object of class CmdLineFactCollector
    cmdline_fact_collector = CmdLineFactCollector()

    # Create dummy data
    data = 'BOOT_IMAGE=/vmlinuz-3.13.0-165-generic root=/dev/mapper/vg_centos-lv_root ro crashkernel=auto rd.lvm.lv=vg_centos/lv_root rd.lvm.lv=vg_centos/lv_swap rhgb quiet LANG=en_US.UTF-8'

    # Create expected result

# Generated at 2022-06-11 04:18:03.851999
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert cmdline.name == 'cmdline'
    assert cmdline._fact_ids == set()


# Generated at 2022-06-11 04:18:05.768412
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'
    assert collector._fact_ids == set()


# Generated at 2022-06-11 04:18:07.826994
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert cmdline.name == 'cmdline'
    assert cmdline._fact_ids == set()

# Generated at 2022-06-11 04:18:17.785310
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    print('Test collecting nothing')
    cmdcollector1 = CmdLineFactCollector()
    assert {} == cmdcollector1.collect()

    print('Test collecting cmdline')
    cmdcollector2 = CmdLineFactCollector()
    cmdcollector2._get_proc_cmdline = lambda: 'BOOT_IMAGE=/vmlinuz-4.4.0-83-generic root=UUID=d21f5b5e-4f56-4eb8-8b1a-f03a6e1e6c8e ro quiet splash vt.handoff=7'

# Generated at 2022-06-11 04:18:20.577753
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Create the class object
    c = CmdLineFactCollector()

    # test with /proc/cmdline file empty
    def get_empty_cmdline(self):
        return ''

# Generated at 2022-06-11 04:18:30.284040
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    coll = CmdLineFactCollector()

    # Test no proc cmdline file
    coll._get_proc_cmdline = lambda: ''
    facts = coll._get_proc_cmdline()
    assert not facts

    # Test with valid proc cmdline file contents
    coll._get_proc_cmdline = lambda: 'a=1 b=2'
    facts = coll._get_proc_cmdline()
    assert facts == 'a=1 b=2'

    # Test with invalid proc cmdline file contents
    coll._get_proc_cmdline = lambda: 'a=1 b'
    facts = coll._get_proc_cmdline()
    assert facts == 'a=1 b'

    # Test parsing with valid proc cmdline file
    parsed = coll._parse_proc_cmdline_facts(facts)

# Generated at 2022-06-11 04:18:36.391921
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert cmdline is not None


# Generated at 2022-06-11 04:18:46.796229
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    command_line_dict = {
        'BOOT_IMAGE': '/vmlinuz-2.6.32-573.el6.x86_64',
        'ro': True,
        'root': '/dev/mapper/vg_xxxxxxxxxxxxx-lv_root',
        'rhgb': True,
        'quiet': True}

    proc_cmdline_dict = {
        'BOOT_IMAGE': '/vmlinuz-2.6.32-573.el6.x86_64',
        'ro': True,
        'root': '/dev/mapper/vg_xxxxxxxxxxxxx-lv_root',
        'rhgb': True,
        'quiet': True}

    collector = CmdLineFactCollector()

    result = collector._get_proc_cmdline()

    assert result is not None

    assert collector

# Generated at 2022-06-11 04:18:51.587498
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    fact_collector = CmdLineFactCollector()
    collected_facts = CmdLineFactCollector.collect(fact_collector)
    assert 'cmdline' in collected_facts
    assert 'proc_cmdline' in collected_facts
    assert isinstance(collected_facts['cmdline'], dict)
    assert isinstance(collected_facts['proc_cmdline'], dict)

# Generated at 2022-06-11 04:18:54.153558
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    fact_collector = CmdLineFactCollector()
    assert fact_collector.name == 'cmdline'
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-11 04:18:59.340585
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector()
    data = cmdline_facts._get_proc_cmdline()

    if not data:
        return

    cmdline_dict = cmdline_facts._parse_proc_cmdline(data)
    proc_cmdline_dict = cmdline_facts._parse_proc_cmdline_facts(data)

    assert isinstance(cmdline_dict, dict)
    assert isinstance(proc_cmdline_dict, dict)

# Generated at 2022-06-11 04:19:00.534148
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    collector.collect()

# Generated at 2022-06-11 04:19:02.374383
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'
    assert collector._fact_ids == set()

# Generated at 2022-06-11 04:19:06.702799
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd = "a=b c=d e=f"
    data = CmdLineFactCollector()
    data._get_proc_cmdline = lambda: cmd
    ret = data.collect()
    assert(ret['cmdline'] == {'a' : 'b', 'c' : 'd', 'e' : 'f'})
    assert(ret['proc_cmdline'] == {'a' : 'b', 'c' : 'd', 'e' : 'f'})


# Generated at 2022-06-11 04:19:09.528041
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    my_cmdline = CmdLineFactCollector()
    assert(my_cmdline.name == 'cmdline')
    assert(set(my_cmdline._fact_ids) == set(['cmdline', 'proc_cmdline']))


# Generated at 2022-06-11 04:19:11.851727
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    collected_facts = {}
    cmdline_facts = collector.collect(collected_facts)
    assert cmdline_facts is not None

# Generated at 2022-06-11 04:19:22.517817
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'


# Generated at 2022-06-11 04:19:31.167421
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import collector_repository
    from ansible.module_utils.facts.collector import BaseFactCollector

    clc = CmdLineFactCollector()

    test_file = '/tmp/test.file'
    test_data = "root=UUID=12345-67890    ro  quiet   user=test-user"

    with open(test_file, 'w') as f:
        f.write(test_data)

    clc._get_proc_cmdline = lambda: test_data

    clc.collect()

    assert type(clc.collect) is type(BaseFactCollector.collect)
    assert clc.name == "cmdline"

# Generated at 2022-06-11 04:19:40.728951
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    my_module = mock.MagicMock()
    my_module.warn = mock.MagicMock()
    my_collector = CmdLineFactCollector(module=my_module)
    my_get_file_content = my_collector._get_proc_cmdline

    my_get_file_content.return_value = "foo=bar "
    result = my_collector.collect()
    my_module.fail_json.assert_not_called()
    my_module.warn.assert_not_called()
    assert type(result['cmdline']) is dict
    assert type(result['proc_cmdline']) is dict
    assert len(result['cmdline']) == 1
    assert len(result['proc_cmdline']) == 1
    assert result['cmdline']['foo'] == 'bar'


# Generated at 2022-06-11 04:19:43.535298
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    cmdline_facts = collector.collect()

    assert 'cmdline' in cmdline_facts
    assert 'proc_cmdline' in cmdline_facts

# Generated at 2022-06-11 04:19:46.419153
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():

    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'
    assert len(collector._fact_ids) == 0


# Generated at 2022-06-11 04:19:47.855931
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    m = None
    c = CmdLineFactCollector()
    assert c is not None

# Generated at 2022-06-11 04:19:49.885029
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'

# Generated at 2022-06-11 04:19:51.501230
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_list = CmdLineFactCollector()
    assert cmdline_list.name == 'cmdline'

# Generated at 2022-06-11 04:19:54.202462
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    test_collector = CmdLineFactCollector()
    assert(test_collector.name == "cmdline")
    assert(test_collector.collect_fn == test_collector.collect)

# Generated at 2022-06-11 04:19:55.683864
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'

# Generated at 2022-06-11 04:20:21.682137
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline = CmdLineFactCollector()

    text = 'first=hey second=you'
    result = cmdline._parse_proc_cmdline(text)
    assert result == {'first': 'hey', 'second': 'you'}, "parse_proc_cmdline returned incorrect results"

    text = 'first=hey second=you second=my'
    result = cmdline._parse_proc_cmdline_facts(text)
    assert result == {'first': 'hey', 'second': ['you', 'my']}, "parse_proc_cmdline_facts returned incorrect results"


# Generated at 2022-06-11 04:20:28.395986
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    class Module:
        def __init__(self, params):
            self.params = params

    class CollectedFacts:
        def __init__(self, data):
            self.ansible_facts = data

    class FakeCommand(object):
        def __init__(self, output, returncode):
            self.output = output
            self.returncode = returncode

    class DoctestCmdLineFactCollector(CmdLineFactCollector):
        def __init__(self, module):
            super(DoctestCmdLineFactCollector, self).__init__(module=module)

        def _get_proc_cmdline(self):
            return self.cmdline

    test_data = {
        'cmdline': '/bin/true',
        'cmdline_returncode': 0
    }

# Generated at 2022-06-11 04:20:37.670013
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_fact_collector = CmdLineFactCollector()
    cmdline_facts_result = cmdline_fact_collector.collect()

    assert 'cmdline' in cmdline_facts_result
    assert 'proc_cmdline' in cmdline_facts_result

    assert 'root=UUID=' in cmdline_facts_result['cmdline']
    assert cmdline_facts_result['cmdline']['root'] == 'UUID=f93a2a6f-3949-4a01-b9bf-14e4a0dbe4f4'
    assert cmdline_facts_result['cmdline']['ro'] == True
    assert cmdline_facts_result['cmdline']['console'] == 'ttyS0'

    assert 'root' in cmdline_facts_result['proc_cmdline']


# Generated at 2022-06-11 04:20:40.743496
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    CmdLineFactCollector = CmdLineFactCollector()
    cmdline_facts = CmdLineFactCollector.collect()
    assert cmdline_facts['cmdline']
    assert cmdline_facts['proc_cmdline']

# Generated at 2022-06-11 04:20:47.015828
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    open_name = 'ansible.module_utils.facts.collector.open'
    with patch(open_name, mock_open(read_data='test=test')):
        cmdline_facts = CmdLineFactCollector()

    res = cmdline_facts.collect()

    assert res == {
        'cmdline': {
            'test': 'test'
        },
        'proc_cmdline': {
            'test': 'test'
        }
    }


# Generated at 2022-06-11 04:20:54.488560
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import json

    test_data = """root=/dev/mapper/cl-root ro var_set=test"""

    expected_data = {
        'cmdline': {'var_set': 'test', 'root': '/dev/mapper/cl-root'},
        'proc_cmdline': {'var_set': 'test', 'root': '/dev/mapper/cl-root'}
    }

    cmdlinefactcollector = CmdLineFactCollector('', '', '')
    cmdlinefactcollector._get_proc_cmdline = lambda: test_data

    actual_data = cmdlinefactcollector.collect()

    assert actual_data == expected_data

# Generated at 2022-06-11 04:21:03.390711
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    fact_collector = CmdLineFactCollector()
    func = getattr(fact_collector, '_get_proc_cmdline')
    func.return_value = 'ro root=LABEL=ROOT console=ttyS0,115200 console=tty0 console=hvc0'
    cmdline_facts = fact_collector._parse_proc_cmdline_facts('ro root=LABEL=ROOT console=ttyS0,115200 console=tty0 console=hvc0')
    assert cmdline_facts
    assert not isinstance(cmdline_facts['console'], list)
    assert cmdline_facts['console'] == 'hvc0'
    cmdline_facts = fact_collector._parse_proc_cmdline_facts('console=ttyS0 console=tty0 console=tty1 console=hvc0')

# Generated at 2022-06-11 04:21:05.006905
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == "cmdline"


# Generated at 2022-06-11 04:21:13.558305
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_data = """BOOT_IMAGE=/vmlinuz-3.10.0-693.11.1.el7.x86_64 \
    root=/dev/mapper/rhel-root ro rd.lvm.lv=rhel/root \
    rd.lvm.lv=rhel/swap rhgb quiet LANG=en_US.UTF-8 \
    console=tty0 console=ttyS0,115200n8 crashkernel=auto consoleblank=0"""
    cmdline = CmdLineFactCollector()
    # This method sets a class variable, so we run it once
    cmdline.collect()

    # First test cmdline dict

# Generated at 2022-06-11 04:21:15.631861
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Test instantiation of a CmdLineFactCollector object
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'

# Generated at 2022-06-11 04:22:05.052458
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.collect() == {
        'cmdline': {
            'BOOT_IMAGE': '/boot/vmlinuz-4.15.0-43-generic',
            'console': 'tty1',
            'quiet': True,
            'ro': True
        },
        'proc_cmdline': {
            'BOOT_IMAGE': ['/boot/vmlinuz-4.15.0-43-generic'],
            'console': ['/dev/tty1', 'tty1'],
            'quiet': [True],
            'ro': [True]
        }
    }

# Generated at 2022-06-11 04:22:12.481221
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    file_content = 'root=UUID=a30b08e2-c2d1-11e9-9e8f-7421a31b64e7 ' \
                   'ro quiet splash intel_iommu=on loglevel=0 vt.handoff=1'
    expected_cmdline = {'root': 'UUID=a30b08e2-c2d1-11e9-9e8f-7421a31b64e7',
                        'ro': True,
                        'quiet': True,
                        'splash': True,
                        'intel_iommu': 'on',
                        'loglevel': '0',
                        'vt.handoff': '1'}

# Generated at 2022-06-11 04:22:12.942382
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    pass

# Generated at 2022-06-11 04:22:15.127819
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert c._fact_ids == set()

# Generated at 2022-06-11 04:22:23.133527
# Unit test for method collect of class CmdLineFactCollector

# Generated at 2022-06-11 04:22:25.252195
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.__name__ == 'CmdLineFactCollector'
    assert CmdLineFactCollector.name == 'cmdline'
    assert isinstance(CmdLineFactCollector._fact_ids, set)

# Generated at 2022-06-11 04:22:30.530463
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Instantiate class
    cmdline_fc = CmdLineFactCollector()

    # Retrieve data from method _get_proc_cmdline
    data = cmdline_fc._get_proc_cmdline()

    # Collect facts
    result = cmdline_fc.collect()

    assert result
    assert result['cmdline']
    assert result['proc_cmdline']
    assert all(key in result['cmdline'].keys() for key in result['proc_cmdline'].keys())


# Generated at 2022-06-11 04:22:38.563140
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Prepare test
    module = None
    collected_facts = None
    collector = CmdLineFactCollector()

    # Test with proc_cmdline containing only a single key=value pair
    collector._get_proc_cmdline = lambda: 'foo=bar'
    assert collector.collect(module, collected_facts) == {
        'cmdline': {'foo': 'bar'},
        'proc_cmdline': {'foo': 'bar'}
    }

    # Test with proc_cmdline containing only a key-only pair
    collector._get_proc_cmdline = lambda: 'foo'
    assert collector.collect(module, collected_facts) == {
        'cmdline': {'foo': True},
        'proc_cmdline': {'foo': True}
    }

    # Test with proc_cmdline containing multiple key=

# Generated at 2022-06-11 04:22:46.383316
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    data = 'BOOT_IMAGE=/vmlinuz-4.4.0-128-generic root=UUID=0144e890' \
           '-ffc4-4fc4-b4f4-17c04198d3b3 ro quiet splash vt.handoff=7'
    cmdline_facts = {}

    cmdline_facts['cmdline'] = {'BOOT_IMAGE': '/vmlinuz-4.4.0-128-generic',
                                'root': 'UUID=0144e890-ffc4-4fc4-b4f4-17c04198d3b3',
                                'ro': True,
                                'quiet': True,
                                'splash': True,
                                'vt.handoff': '7'}

# Generated at 2022-06-11 04:22:47.953572
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    factCollector = CmdLineFactCollector()
    assert factCollector.name == 'cmdline'

# Generated at 2022-06-11 04:23:42.634510
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()

    assert cmdline_collector.name == 'cmdline'

# Generated at 2022-06-11 04:23:44.146237
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()

# Generated at 2022-06-11 04:23:51.349735
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils._text import to_bytes
    CmdLineFactCollector._get_proc_cmdline = lambda: to_bytes('\n'.join(['GRUB_DISABLE_SUBMENU=y',
                                                                         'console=tty0',
                                                                         'console=ttyS0,9600n8',
                                                                         'root=LABEL=cloudimg-rootfs']))

# Generated at 2022-06-11 04:23:57.360636
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    '''
    Create instance of CmdLineFactCollector and validate it's
    properties
    '''
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert isinstance(c._fact_ids, set)
    assert c._get_proc_cmdline() == ''
    fact_dict = c._parse_proc_cmdline('foo=bar one')
    assert fact_dict == {'foo': 'bar', 'one': True}
    fact_dict = c._parse_proc_cmdline_facts('foo=bar one')
    assert fact_dict == {'foo': 'bar', 'one': True}

# Generated at 2022-06-11 04:23:59.229055
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert len(c._fact_ids) == 0

# Generated at 2022-06-11 04:24:04.199160
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_dict = {}
    try:
        for piece in shlex.split("root=/dev/hda1 ro", posix=False):
            item = piece.split('=', 1)
            if len(item) == 1:
                cmdline_dict[item[0]] = True
            else:
                cmdline_dict[item[0]] = item[1]
    except ValueError:
        pass

    data = {"cmdline": cmdline_dict}

    assert CmdLineFactCollector().collect() == data

# Generated at 2022-06-11 04:24:06.329274
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert c._fact_ids is not None
    assert len(c._fact_ids) == 0

# Generated at 2022-06-11 04:24:07.654910
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    assert CmdLineFactCollector.collect() == {'cmdline': {}, 'proc_cmdline': {}}

# Generated at 2022-06-11 04:24:11.869654
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    # Setup
    from ansible.module_utils.facts.collectors.cmdline import CmdLineFactCollector

    # Execute
    test_cmdline_collector = CmdLineFactCollector()
    cmdline_facts = test_cmdline_collector.collect()

    # Validate
    assert cmdline_facts['cmdline']['root'] == '/dev/sda1'
    assert cmdline_facts['proc_cmdline']['root'] == '/dev/sda1'

# Generated at 2022-06-11 04:24:13.224586
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert 'cmdline' in str(type(c))

# Generated at 2022-06-11 04:26:09.650358
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    c = CmdLineFactCollector()
    result = c._parse_proc_cmdline('a foo=bar b foo=bar c')
    assert result == {'a': True, 'b': True, 'c': True, 'foo': 'bar'}
    result = c._parse_proc_cmdline_facts('a foo=bar b foo=bar c')
    assert result == {'a': True, 'b': True, 'c': True, 'foo': ['bar', 'bar']}
    result = c._get_proc_cmdline()
    assert result is not None

    c.collect(collected_facts=dict())
    cmdline_facts = c.collect(collected_facts=dict())
    assert isinstance(cmdline_facts, dict)
    assert 'cmdline' in cmdline_facts

# Generated at 2022-06-11 04:26:11.427466
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    a = CmdLineFactCollector()
    assert a.name == 'cmdline'
    assert isinstance(a._fact_ids, set)
    assert not a._fact_ids


# Generated at 2022-06-11 04:26:12.742493
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector().name == 'cmdline'
    assert CmdLineFactCollector()._fact_ids == set()


# Generated at 2022-06-11 04:26:14.029037
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert c._fact_ids == set()

# Generated at 2022-06-11 04:26:16.175387
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()

    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set(['cmdline', 'proc_cmdline'])

# Generated at 2022-06-11 04:26:22.827271
# Unit test for method collect of class CmdLineFactCollector

# Generated at 2022-06-11 04:26:24.422911
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == "cmdline"
    assert CmdLineFactCollector._fact_ids == set()


# Generated at 2022-06-11 04:26:31.803037
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import os
    import json
    import tempfile

    # Test with normal data
    data = ' key1=val1 key2=val2 key3  key4=val4  key5=val5=val6'

    # Mock the get_file_content() function to return the above test data
    CmdLineFactCollector._get_proc_cmdline = lambda self: data

    # Call the collect() method
    cmdline_facts = CmdLineFactCollector().collect()

    # Check the result
    assert cmdline_facts['cmdline'] == {'key1': 'val1', 'key2': 'val2', 'key3': True,
                                        'key4': 'val4', 'key5': 'val5=val6'}

# Generated at 2022-06-11 04:26:36.414034
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Test case:
    # If a collect method of a class which inherits
    # from BaseFactCollector class has a docstring
    # then the docstring should be printed
    #
    # This test uses the class CmdLineFactCollector
    # to verify the print of a docstring of the
    # method collect from BaseFactCollector class
    #
    # Hence the test uses the same class, but asserts
    # that the docstring has been printed
    c = CmdLineFactCollector()
    assert c.collect.__doc__ is not None

# Generated at 2022-06-11 04:26:37.743292
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    my_collector = CmdLineFactCollector()
    assert 'cmdline' not in my_collector.collect()