

# Generated at 2022-06-11 04:17:56.509104
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.collectors.cmdline import CmdLineFactCollector
    module = {}
    collected_facts = {}
    cmdline_collector = CmdLineFactCollector(module=module, collected_facts=collected_facts)
    cmdline_facts = cmdline_collector.collect()
    assert cmdline_facts['cmdline']['ro'] == True
    assert cmdline_facts['proc_cmdline']['ro'] == True
    assert cmdline_facts['cmdline']['root'] == '/dev/sda1'
    assert cmdline_facts['proc_cmdline']['root'] == '/dev/sda1'
    assert cmdline_facts['cmdline']['baz'] == 'baz1'


# Generated at 2022-06-11 04:18:05.605763
# Unit test for method collect of class CmdLineFactCollector

# Generated at 2022-06-11 04:18:15.717018
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    class FakeModule(object):
        def __init__(self, *args):
            self.args = args

    with open('/tmp/cmdline', 'w') as f:
        f.write('\n')

    with open('/tmp/cmdline_with_data', 'w') as f:
        f.write('hs=serial console=ttyS0\n')

    collector = CmdLineFactCollector()

    # Test reading from /proc/cmdline when it's empty
    fake_module = FakeModule()
    cmdline_facts = collector.collect(module=fake_module)
    assert cmdline_facts['cmdline'] == {}
    assert cmdline_facts['proc_cmdline'] == {}

    # Test reading from /proc/cmdline with data
    fake_module = FakeModule()

# Generated at 2022-06-11 04:18:24.939038
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline = CmdLineFactCollector()
    cmdline._get_proc_cmdline = lambda: 'BOOT_IMAGE=/vmlinuz-4.1.6-200.fc22.x86_64 root=/dev/mapper/fedora-root ro rhgb quiet LANG=en_US.UTF-8'
    cmdline_facts = cmdline.collect()
    assert cmdline_facts['cmdline']['BOOT_IMAGE'] == '/vmlinuz-4.1.6-200.fc22.x86_64'
    assert cmdline_facts['cmdline']['root'] == '/dev/mapper/fedora-root'
    assert cmdline_facts['cmdline']['rhgb']
    assert cmdline_facts['cmdline']['quiet']

# Generated at 2022-06-11 04:18:26.285667
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'

# Generated at 2022-06-11 04:18:30.197539
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector.priority == 100
    assert cmdline_fact_collector._fact_ids == set()

# Generated at 2022-06-11 04:18:33.238906
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    result = CmdLineFactCollector.collect()
    assert result.get('cmdline') is not None and len(result.get('cmdline')) > 0
    assert result.get('proc_cmdline') is not None and len(result.get('proc_cmdline')) > 0

# Generated at 2022-06-11 04:18:34.496825
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj._fact_ids == set()

# Generated at 2022-06-11 04:18:44.681975
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector_object = CmdLineFactCollector()

# Generated at 2022-06-11 04:18:46.844367
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd = CmdLineFactCollector()
    assert cmd.name == 'cmdline'
    assert cmd._fact_ids == set()

# Generated at 2022-06-11 04:18:58.000400
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    my_collector = CmdLineFactCollector()
    assert my_collector.name == 'cmdline'
    assert my_collector._fact_ids == set()

# Generated at 2022-06-11 04:18:59.454015
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert isinstance(CmdLineFactCollector(), CmdLineFactCollector)



# Generated at 2022-06-11 04:19:00.805465
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector.collect()

# Generated at 2022-06-11 04:19:05.588642
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    c = CmdLineFactCollector()

    cmdline_data = c._get_proc_cmdline()
    cmdline_data = c._parse_proc_cmdline(cmdline_data)
    proc_cmdline_data = c._parse_proc_cmdline_facts(cmdline_data)

    cmdline_facts_data = c.collect()

    assert cmdline_facts_data['cmdline'] == cmdline_data
    assert cmdline_facts_data['proc_cmdline'] == proc_cmdline_data

# Generated at 2022-06-11 04:19:14.178767
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Create a instance of class CmdLineFactCollector
    my_cmdline = CmdLineFactCollector()
    # Create a dictionary for testing
    cmdline_facts = {}

    # Test for method _get_proc_cmdline
    def test_get_file_content(path):
        if path == '/proc/cmdline':
            return 'BOOT_IMAGE=/vmlinuz-3.13.0-137-generic root=UUID=6a2b8a76-0f40-4c0b-a106-64f69e51a0b0 ro console=tty1 console=ttyS0'
        else:
            return ''

    my_cmdline._get_proc_cmdline = test_get_file_content

    # Test for method _parse_proc_cmdline

# Generated at 2022-06-11 04:19:23.751553
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # arrange
    def mock_get_file_content(path):
        return 'key1=value1 key2=value2 key3'

    mock_module = None
    mock_facts = None
    cmdline_facts_collector = CmdLineFactCollector()
    cmdline_facts_collector._get_proc_cmdline = mock_get_file_content

    # act
    result = cmdline_facts_collector.collect(mock_module, mock_facts)

    # assert
    assert 'cmdline' in result
    assert 'proc_cmdline' in result
    assert result['proc_cmdline']['key1'] == 'value1'
    assert result['proc_cmdline']['key2'] == 'value2'
    assert result['proc_cmdline']['key3'] is True

# Generated at 2022-06-11 04:19:25.858135
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdLineFactCollector = CmdLineFactCollector()
    assert cmdLineFactCollector.name == 'cmdline'


# Generated at 2022-06-11 04:19:28.815070
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert not hasattr(CmdLineFactCollector, '_fact_ids')
    assert CmdLineFactCollector._fact_ids is None
    assert CmdLineFactCollector.name == 'cmdline'


# Generated at 2022-06-11 04:19:30.906699
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    obj = CmdLineFactCollector()
    result = obj.collect()
    assert 'cmdline' in result
    assert 'proc_cmdline' in result

# Generated at 2022-06-11 04:19:32.492458
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector.collect()

# Generated at 2022-06-11 04:19:59.153436
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Test for non-existent /proc/cmdline
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector._get_proc_cmdline = lambda: None

    cmdline_facts = cmdline_collector.collect()
    assert cmdline_facts == {}

    # Test for empty /proc/cmdline
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector._get_proc_cmdline = lambda: ''

    cmdline_facts = cmdline_collector.collect()
    assert cmdline_facts == {}

    # Test for valid data in /proc/cmdline
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector._get_proc_cmdline = lambda: 'rw quiet elevator=noop'

    cmdline_facts = cmdline

# Generated at 2022-06-11 04:19:59.591708
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()

# Generated at 2022-06-11 04:20:01.041080
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    fact = CmdLineFactCollector()
    assert fact.name == 'cmdline'
    assert isinstance(fact._fact_ids, set)


# Generated at 2022-06-11 04:20:01.595342
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    pass

# Generated at 2022-06-11 04:20:12.182182
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line = 'BOOT_IMAGE=/boot/vmlinuz-4.4.0-2-amd64 root=UUID=8cc3f04a-f906-4d10-bfdc-b56e35aed672 ro quiet acpi_enforce_resources=lax acpi_osi='
    collector = CmdLineFactCollector()

    def mock_get_file_content(path):
        return cmd_line

    data = collector._get_proc_cmdline = mock_get_file_content
    result = collector.collect()

    assert result['cmdline']['BOOT_IMAGE'] == '/boot/vmlinuz-4.4.0-2-amd64'

# Generated at 2022-06-11 04:20:19.761912
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    c = CmdLineFactCollector()
    assert c.collect() == {'cmdline': {'BOOT_IMAGE': '/boot/vmlinuz-3.10.0-327.el7.x86_64', 'ro': True, 'root': '/dev/mapper/rhel-root'}, 'proc_cmdline': {'BOOT_IMAGE': ['/boot/vmlinuz-3.10.0-327.el7.x86_64'], 'ro': [True], 'root': ['/dev/mapper/rhel-root']}}

# Generated at 2022-06-11 04:20:22.259613
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == "cmdline"
    assert c.collect() == {}
    assert c._get_proc_cmdline() == ""

# Generated at 2022-06-11 04:20:22.805976
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    pass

# Generated at 2022-06-11 04:20:28.636520
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts import FactsCollector

    # Define fake values for files
    fake_cmdline_content = 'a=b c=d e f g=h i=j i=k l=m=n o p=q=r'

    # Execute collect method of CmdLineFactCollector class with faked files
    cmdline_fact_collector = CmdLineFactCollector()
    cmdline_facts = cmdline_fact_collector.collect(FactsCollector())


# Generated at 2022-06-11 04:20:30.476348
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    os_family = 'Linux'
    assert(CmdLineFactCollector().os_family == os_family)

# Generated at 2022-06-11 04:20:50.318611
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    fact_collector = CmdLineFactCollector(None)
    assert fact_collector.name == 'cmdline'

# Generated at 2022-06-11 04:20:52.584008
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'

# Generated at 2022-06-11 04:20:53.681385
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert isinstance(CmdLineFactCollector(), CmdLineFactCollector)

# Generated at 2022-06-11 04:20:56.207276
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-11 04:20:57.069308
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert not CmdLineFactCollector().collect()

# Generated at 2022-06-11 04:20:59.918330
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert(cmdline_fact_collector.name == 'cmdline')
    assert(cmdline_fact_collector._fact_ids == set())


# Generated at 2022-06-11 04:21:08.723963
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    test_dict = {
        'cmdline': {
            'BOOT_IMAGE': '/boot/vmlinuz-3.2.0-3-amd64',
            'root': '/dev/sda1'
        },
        'proc_cmdline': {
            'BOOT_IMAGE': [
                '/boot/vmlinuz-3.2.0-3-amd64',
                '/boot/vmlinuz-3.2.0-2-amd64',
                '/boot/vmlinuz-3.2.0-1-amd64'
            ],
            'root': '/dev/sda1'
        }
    }
    cmd = CmdLineFactCollector('test')
    cmd.collect()
    assert(cmd.collect() == test_dict)

# Generated at 2022-06-11 04:21:10.572368
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdlineFactCollector = CmdLineFactCollector()
    assert cmdlineFactCollector.name.lower() == 'cmdline'

# Generated at 2022-06-11 04:21:12.488894
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cf = CmdLineFactCollector()
    assert cf.name == 'cmdline'
    assert cf._fact_ids == set()


# Generated at 2022-06-11 04:21:15.585555
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = CmdLineFactCollector()
    assert isinstance(cmdline_facts, CmdLineFactCollector)

    assert cmdline_facts.name == 'cmdline'
    assert cmdline_facts._fact_ids == set()

# Generated at 2022-06-11 04:21:55.632466
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    pass

# Generated at 2022-06-11 04:21:56.809307
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd = CmdLineFactCollector()
    assert cmd is not None


# Generated at 2022-06-11 04:21:58.699685
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'

# Generated at 2022-06-11 04:22:00.310159
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd = CmdLineFactCollector()
    assert cmd.name == 'cmdline'


# Generated at 2022-06-11 04:22:07.977583
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts import FactsCollector

    test_collector = CmdLineFactCollector()
    __get_file_content = get_file_content
    get_file_content_cache = {}

    def __get_file_content_side_effect(file_path):
        return get_file_content_cache[file_path]

    get_file_content.side_effect = __get_file_content_side_effect
    facts_collector = FactsCollector()
    facts = facts_collector.collect(module=None, collected_facts=None)


# Generated at 2022-06-11 04:22:09.356934
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    clfc = CmdLineFactCollector()
    assert clfc.name == 'cmdline'

# Generated at 2022-06-11 04:22:15.781310
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()

    cmdline_collector._get_proc_cmdline = print_fakefile
    cmdline_collector.facts_dir = '/dir/fakefactsdir'

    fake_collector_facts = {}


# Generated at 2022-06-11 04:22:18.066119
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    fact_collector = CmdLineFactCollector()
    assert fact_collector._fact_ids == set()
    assert fact_collector.name == 'cmdline'


# Generated at 2022-06-11 04:22:22.537417
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Test for collect method of class CmdLineFactCollector
    # Test for method collect of class CmdLineFactCollector
    # Test successful execution
    c = CmdLineFactCollector()
    c.collect()

    # Test for method collect of class CmdLineFactCollector
    # Test with invalid data
    c = CmdLineFactCollector()
    c._get_proc_cmdline = lambda: "foo=bar"
    c.collect()

# Generated at 2022-06-11 04:22:24.088083
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdlineFactCollector = CmdLineFactCollector()
    assert cmdlineFactCollector.name == 'cmdline'


# Generated at 2022-06-11 04:24:02.438220
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    # Create test data.
    test_proc_cmdline = 'rd.break=cmdline selinux=0 rd.udev.log_priority=debug systemd.unit=multi-user.target'
    cmdline_collector._get_proc_cmdline = lambda: test_proc_cmdline
    # Run unit test.
    results = cmdline_collector.collect()
    # Check results.

# Generated at 2022-06-11 04:24:09.806339
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    fixture_data = dict()
    fixture_data['cmdline'] = [
        "BOOT_IMAGE=/vmlinuz-4.13.0-46-generic "
        "root=UUID=b97e7d12-d425-4507-ac0f-3990fd800fd8 "
        "ro quiet splash vt.handoff=7 "
        "rootflags=subvol=@/crashkernel=384M-:64M apparmor=1 security=apparmor "
        "nouveau.modeset=0"]
    fixture_data['proc_cmdline'] = dict()
    fixture_data['proc_cmdline']['BOOT_IMAGE'] = '/vmlinuz-4.13.0-46-generic'

# Generated at 2022-06-11 04:24:10.809733
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    fact_collector = CmdLineFactCollector()

    assert fact_collector.name == 'cmdline'

# Generated at 2022-06-11 04:24:12.866057
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Instantiate CmdLineFactCollector
    cmdline_fact_collector = CmdLineFactCollector()
    assert isinstance(cmdline_fact_collector, CmdLineFactCollector)
    assert cmdline_fact_collector.name == 'cmdline'

# Generated at 2022-06-11 04:24:14.110759
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = CmdLineFactCollector().collect()

    assert 'cmdline' in cmdline_facts

# Generated at 2022-06-11 04:24:21.746209
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    # /proc/cmdline file exists
    cmdline_collector._get_proc_cmdline = lambda: "BOOT_IMAGE=/boot/vmlinuz-4.15.0-33-generic root=/dev/mapper/ubuntu--vg-root ro quiet splash vt.handoff=1"
    cmdline_collector._parse_proc_cmdline = lambda x: x
    cmdline_collector._parse_proc_cmdline_facts = lambda x: x
    result = cmdline_collector.collect()
    assert result['cmdline'] == result['proc_cmdline']

    # /proc/cmdline file does not exists
    cmdline_collector._get_proc_cmdline = lambda: None
    result = cmdline_collector.collect()

# Generated at 2022-06-11 04:24:24.111696
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector.collect() == {}



# Generated at 2022-06-11 04:24:26.317921
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = CmdLineFactCollector()

    assert 'cmdline' == cmdline_facts.name
    assert set() == cmdline_facts._fact_ids

# Generated at 2022-06-11 04:24:34.550482
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    actual_cmdline_facts = None
    actual_proc_cmdline_facts = None
    expected_cmdline_facts = {'cmdline': {'key': 'value', 'key2' : 'value2', 'key3': True, 'key4' : True}}
    expected_proc_cmdline_facts = {'proc_cmdline': {'key': 'value', 'key2' : ['value2', 'value2'], 'key3': True, 'key4' : True}}

    # Mock method get_file_content
    def mock_get_file_content(file):
        return 'key=value key2=value2 key2=value2 key3 key4'

    collector = CmdLineFactCollector()
    collector.get_file_content = mock_get_file_content

    # Test collect method

# Generated at 2022-06-11 04:24:35.972314
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    m = CmdLineFactCollector()
    assert m.name == 'cmdline'
    del m
