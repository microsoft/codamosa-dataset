

# Generated at 2022-06-11 04:17:51.985936
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()

    assert cmdline_collector is not None
    assert cmdline_collector.name == 'cmdline'


# Generated at 2022-06-11 04:18:01.352050
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    c = CmdLineFactCollector(None)

    # Test with no data
    assert c._get_proc_cmdline() is None
    assert c.collect() == {}

    # Test with data
    data = "kernel_option1=foo kernel_option2=bar"
    assert c._get_proc_cmdline() == data

    cmdline_facts = c.collect()
    assert cmdline_facts['cmdline'] == {'kernel_option1': 'foo', 'kernel_option2': 'bar'}
    assert cmdline_facts['proc_cmdline'] == {'kernel_option1': 'foo', 'kernel_option2': 'bar'}

    # Test values with spaces
    data = "kernel_option1=\"foo bar\" kernel_option2=bar"
    assert c._get_proc_cmdline() == data



# Generated at 2022-06-11 04:18:10.964926
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import timestamp

    timestamp.epoch = 1491391750.77
    timestamp.float_info = (53, 15, 1065353216.0)
    timestamp.info = {
        'days': 3,
        'hours': 3,
        'microseconds': 770000,
        'minutes': 26,
        'months': 5,
        'seconds': 50,
        'years': 2017
    }
    timestamp.iso8601 = '2017-04-03T03:29:10.770000'
    timestamp.iso8601_micro = '2017-04-03T03:29:10.770000'
    timestamp.tz_offset = -18000
    timestamp.tz_name = 'EST'
    timestamp

# Generated at 2022-06-11 04:18:16.947399
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """
    The method collect should return a dict with cmdline and proc_cmdline.
    """
    fact_collector = CmdLineFactCollector()
    cmdline_facts = fact_collector.collect()
    assert isinstance(cmdline_facts, dict)
    assert 'cmdline' in cmdline_facts
    assert isinstance(cmdline_facts['cmdline'], dict)
    assert isinstance(cmdline_facts['proc_cmdline'], dict)



# Generated at 2022-06-11 04:18:18.522248
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert cmdline.name == 'cmdline'

# Generated at 2022-06-11 04:18:27.216560
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Get data from /proc/cmdline
    cmdline_collector = CmdLineFactCollector()
    cmdline_facts = cmdline_collector.collect()

    proc_cmdline_file = '/proc/cmdline'
    data = get_file_content(proc_cmdline_file)

    # Verify that the module is able to parse the data from /proc/cmdline
    assert('cmdline' in cmdline_facts)
    assert(cmdline_facts['cmdline'] == cmdline_collector._parse_proc_cmdline(data))

    assert('proc_cmdline' in cmdline_facts)
    assert(cmdline_facts['proc_cmdline'] == cmdline_collector._parse_proc_cmdline_facts(data))

# Generated at 2022-06-11 04:18:32.299409
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    '''Unit test for constructor of class CmdLineFactCollector'''
    cmdline_obj = CmdLineFactCollector()
    assert(hasattr(cmdline_obj, 'name'))
    assert(hasattr(cmdline_obj, '_fact_ids'))
    assert(cmdline_obj.name == 'cmdline')
    assert(cmdline_obj._fact_ids == set())

# Generated at 2022-06-11 04:18:34.305974
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()

    assert c.name == 'cmdline'
    assert c._fact_ids == set()


# Generated at 2022-06-11 04:18:35.934227
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert isinstance(cmdline_facts, dict)

# Generated at 2022-06-11 04:18:46.256325
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_fact_collector = CmdLineFactCollector()
    root_device_data = 'root=UUID=6edc8f71-2dca-49e0-a439-5e8ecbe9c645'
    root_device_data_list = 'root=UUID=6edc8f71-2dca-49e0-a439-5e8ecbe9c645 ro'
    # Create a test instance of CmdLineFactCollector with mocked method _get_proc_cmdline
    class TestCmdLineFactCollector(CmdLineFactCollector):
        def _get_proc_cmdline(self):
            return root_device_data

    test_cmdline_fact_collector = TestCmdLineFactCollector()

    # Test that the cmdline_facts dictionary is created and returned
    cmd

# Generated at 2022-06-11 04:19:02.629343
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector.cmdline import CmdLineFactCollector
    import os
    import tempfile
    tmpfile = tempfile.NamedTemporaryFile(delete=False)

# Generated at 2022-06-11 04:19:03.486744
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()


# Generated at 2022-06-11 04:19:04.314025
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()

# Generated at 2022-06-11 04:19:05.632519
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert issubclass(CmdLineFactCollector, BaseFactCollector)

# Generated at 2022-06-11 04:19:07.370491
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    result = CmdLineFactCollector()
    assert result.name == "cmdline"
    assert result._fact_ids == set()


# Generated at 2022-06-11 04:19:16.147502
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    fake_cmdline_content = u"BOOT_IMAGE=/vmlinuz-3.2.0-28-generic root=/dev/mapper/ubuntu-root ro quiet splash vt.handoff=7"
    fake_proc_cmdline_content = u"BOOT_IMAGE=/vmlinuz root=/dev/mapper/ubuntu-root ro quiet splash"

# Generated at 2022-06-11 04:19:25.769142
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    with open('/proc/cmdline') as fp:
        data = fp.read()

    cmdline_facts = {}
    cmdline_facts['cmdline'] = {}
    cmdline_facts['proc_cmdline'] = {}
    for piece in shlex.split(data, posix=False):
        item = piece.split('=', 1)
        if len(item) == 1:
            cmdline_facts['cmdline'][item[0]] = True
            cmdline_facts['proc_cmdline'][item[0]] = True
        else:
            cmdline_facts['cmdline'][item[0]] = item[1]
            cmdline_facts['proc_cmdline'][item[0]] = item[1]

    print(CmdLineFactCollector().collect())


# Generated at 2022-06-11 04:19:29.867943
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    from ansible.module_utils.facts.collector import Collector
    collector = Collector()
    assert len(collector.fact_classes) == 8, "Invalid number of facts classes, expecting 8"
    assert collector.fact_classes[7].name == 'cmdline', "Invalid order of facts classes"


# Generated at 2022-06-11 04:19:39.492376
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import BaseFactCollector

    class TestCmdLineFactCollector(CmdLineFactCollector):
        name = 'test'

        def _get_proc_cmdline(self):
            return 'param1=test1 param2=test2 param3'

    class TestModule(object):
        def __init__(self, exit_json_arg=None, fail_json_arg=None):
            self.exit_json_arg = exit_json_arg
            self.fail_json_arg = fail_json_arg
            self.results = {}


# Generated at 2022-06-11 04:19:49.352480
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collected_facts = {}
    cmdline_facts = CmdLineFactCollector().collect(collected_facts=collected_facts)

# Generated at 2022-06-11 04:19:59.943747
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    sc = CmdLineFactCollector()
    assert sc.collect() == {'cmdline': {}, 'proc_cmdline': {}}

# Generated at 2022-06-11 04:20:02.378352
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert len(c._fact_ids) == 0


# Generated at 2022-06-11 04:20:13.214730
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """Unit test for method collect of class CmdLineFactCollector"""

    # Test with some dummy data
    # Format is <item>,<expected result>

# Generated at 2022-06-11 04:20:15.053361
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'



# Generated at 2022-06-11 04:20:24.585110
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    from ansible.module_utils.facts.collector import CmdLineFactCollector
    clfc = CmdLineFactCollector()
    assert clfc.name == 'cmdline'
    cmdline_facts = clfc.collect()
    assert 'cmdline' in cmdline_facts
    assert 'proc_cmdline' in cmdline_facts
    assert cmdline_facts['cmdline']['root'] == '/dev/mapper/luks-7f9d5771-592a-40ae-8cc6-d1fcb77cfcd6'
    assert cmdline_facts['cmdline']['ro']
    assert cmdline_facts['cmdline']['rd.lvm.lv'] == 'fedora_ch1f11z1/root'

# Generated at 2022-06-11 04:20:25.873523
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector().name == 'cmdline'


# Generated at 2022-06-11 04:20:27.064142
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c is not None

# Generated at 2022-06-11 04:20:36.683721
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    from ansible.module_utils.facts.utils import get_file_content

    def mock_get_file_content(filename):
        return 'foo=bar baz=qux'

    get_file_content_old = get_file_content
    get_file_content = mock_get_file_content


# Generated at 2022-06-11 04:20:40.744417
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    class MockModule(object):
        pass

    mock_module = MockModule()

    collector = CmdLineFactCollector(mock_module, {})

    cmdline_facts = collector.collect()

    assert {'cmdline', 'proc_cmdline'}.issubset(cmdline_facts.keys())



# Generated at 2022-06-11 04:20:41.995013
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()


# Generated at 2022-06-11 04:21:00.684566
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert not c._fact_ids

# Generated at 2022-06-11 04:21:09.533878
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    fact_collector = CmdLineFactCollector(None, None)

    result = fact_collector.collect()
    assert result is not None
    assert 'cmdline' in result
    assert 'proc_cmdline' in result
    assert isinstance(result['cmdline'], dict)
    assert isinstance(result['proc_cmdline'], dict)
    assert result['cmdline'] is not result['proc_cmdline']

    # Looks like cmdline dictionary has more items than proc_cmdline dictionary

# Generated at 2022-06-11 04:21:16.259437
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts import FactCollector

    test_module = type('module', (object,), dict(params={}))()
    test_fact_list = {'cmdline', 'proc_cmdline'}

    for test_fact in FactCollector.get_fact_names(test_fact_list):
        test_collector = CmdLineFactCollector(test_module)
        test_result = test_collector.collect()

        if test_fact in test_result:
            assert isinstance(test_result[test_fact], (dict, list))
        else:
            assert False

# Generated at 2022-06-11 04:21:26.978775
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Create a mock for the collect function of CmdLineFactCollector class
    c = CmdLineFactCollector()
    # Fake data for the unit test
    c.data = 'root=/dev/mapper/vg00-lv_root ro crashkernel=auto rd_NO_LUKS rd_LVM_LV=vg00/lv_swap rd_NO_MD SYSFONT=latarcyrheb-sun16 rhgb quiet LANG=en_US.UTF-8'
    # Run the unit test
    output_dict = c.collect()
    # Assertions

# Generated at 2022-06-11 04:21:28.664294
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'
    assert obj._fact_ids == set()


# Generated at 2022-06-11 04:21:34.463683
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Test if /proc/cmdline does not exist
    cmdline_no_data = CmdLineFactCollector()

    cmdline_no_data._get_proc_cmdline = lambda:None

    res = cmdline_no_data.collect()
    assert res == {}

    cmdline_with_data = CmdLineFactCollector()

    cmdline_with_data._get_proc_cmdline = lambda:"a_test=a_test_value"

    res = cmdline_with_data.collect()

    assert res == {'cmdline': {'a_test': 'a_test_value'}, 'proc_cmdline': {'a_test': 'a_test_value'}}

# Generated at 2022-06-11 04:21:36.178629
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'

# Generated at 2022-06-11 04:21:45.337212
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Get current bits to decide which testing dictionary to use
    # 64-bit: "/proc/cmdline:BOOT_IMAGE=/vmlinuz-3.16.0-4-amd64 root=UUID=157e8a2a-a1b6-4d6b-aba6-14f6a428b6ef ro quiet"
    # 32-bit: "/proc/cmdline:BOOT_IMAGE=/vmlinuz-3.16.0-4-586 root=UUID=8454c82e-16b6-4130-a8a6-e59d2b2e8721 ro quiet"
    bits = 64 if '64' in __file__ else 32
    cmdline_facts = None

    ####################################
    # 64-bit Testing Dictionary
    ####################################
    if bits == 64:
        cmd

# Generated at 2022-06-11 04:21:46.483254
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    a = CmdLineFactCollector()


# Generated at 2022-06-11 04:21:51.794389
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    test_object = CmdLineFactCollector()

    # Get the expected result of _parse_proc_cmdline_facts method
    data = test_object._get_proc_cmdline()
    parsed_data = test_object._parse_proc_cmdline_facts(data)

    # Get the actual result of _parse_proc_cmdline_facts method
    actual = test_object._parse_proc_cmdline_facts(data)

    assert actual == parsed_data

# Generated at 2022-06-11 04:22:31.305120
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd = CmdLineFactCollector()
    assert cmd is not None

# Test for method collect of class CmdLineFactCollector

# Generated at 2022-06-11 04:22:39.423890
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.utils import get_file_content, has_file

    # Setup
    fact_collector = FactCollector()
    fact_collector.collectors.append(CmdLineFactCollector())

    test_cmdline = 'root=/dev/sda1 console=ttyS0,9600 console=tty0 ip=dhcp'
    test_filename = 'test_cmdline'
    if has_file(test_filename):
        get_file_content(test_filename, boolean=True, follow=False)

    with open(test_filename, 'w') as test_file:
        test_file.write(test_cmdline)

        test_file.flush()

    # Exercise
    ansible_cmdline = fact_collector

# Generated at 2022-06-11 04:22:41.720756
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    my_collector = CmdLineFactCollector()
    assert not my_collector.collect()

#Unit test for method _get_proc_cmdline of class CmdLineFactCollector

# Generated at 2022-06-11 04:22:44.181917
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'
    assert obj._fact_ids == set()

# Unit tests for module_utils.facts.cmdline.get_file_content

# Generated at 2022-06-11 04:22:48.284794
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert c._fact_ids == set()
    assert hasattr(c, '_get_proc_cmdline')
    assert hasattr(c, '_parse_proc_cmdline')
    assert hasattr(c, '_parse_proc_cmdline_facts')
    assert hasattr(c, 'collect')


# Generated at 2022-06-11 04:22:50.032853
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.collect() == {'cmdline': {}, 'proc_cmdline': {}}

# Generated at 2022-06-11 04:22:51.805601
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert c._fact_ids == set()



# Generated at 2022-06-11 04:22:53.442899
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'
    assert collector._fact_ids == set()


# Generated at 2022-06-11 04:22:55.156654
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cf = CmdLineFactCollector()
    assert cf.name == 'cmdline'
    assert cf._fact_ids == set()


# Generated at 2022-06-11 04:22:57.706356
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    C = CmdLineFactCollector()
    facts = C.collect()

    assert 'cmdline' in facts
    assert facts['cmdline']
    assert 'proc_cmdline' in facts
    assert facts['proc_cmdline']

# Generated at 2022-06-11 04:24:30.797095
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import sys
    sys.modules['shutil'] = None
    collector = CmdLineFactCollector()
    cmdline_facts = collector.collect()
    assert not cmdline_facts
    sys.modules.pop('shutil')

# Generated at 2022-06-11 04:24:38.824551
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    c = CmdLineFactCollector()
    c._get_proc_cmdline = lambda: 'biosdevname=0 BOOT_IMAGE=/boot/vmlinuz-3.2.0-4-amd64 root=UUID=d8fd469c-22bf-4149-88f4-54a29d35a9cd ro quiet'
    result = c.collect()

    assert result.get('proc_cmdline') == {'biosdevname': '0', 'BOOT_IMAGE': '/boot/vmlinuz-3.2.0-4-amd64',
                                          'root': 'UUID=d8fd469c-22bf-4149-88f4-54a29d35a9cd', 'ro': True, 'quiet': True}

# Generated at 2022-06-11 04:24:39.857064
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.__doc__


# Generated at 2022-06-11 04:24:45.103013
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = {}

    collector = CmdLineFactCollector()

    data = "root=/dev/mapper/rhel-root ro crashkernel=auto rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet"
    cmdline_facts['cmdline'] = collector._parse_proc_cmdline(data)
    cmdline_facts['proc_cmdline'] = collector._parse_proc_cmdline_facts(data)

    assert cmdline_facts == collector.collect()

# Generated at 2022-06-11 04:24:46.518774
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert(cmdline)


# Generated at 2022-06-11 04:24:48.174043
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector().name == 'cmdline'
    assert CmdLineFactCollector()._fact_ids == set()


# Generated at 2022-06-11 04:24:54.193322
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    module = None
    collected_facts = None
    cmdline_fact = CmdLineFactCollector()
    cmdline_fact_dict = cmdline_fact.collect(module, collected_facts)
    cmdline_dict = cmdline_fact_dict.get('cmdline')
    proc_cmdline_dict = cmdline_fact_dict.get('proc_cmdline')
    assert cmdline_dict.get('BOOT_IMAGE') == '/vmlinuz-4.4.0-149-generic'
    assert proc_cmdline_dict.get('BOOT_IMAGE') == '/vmlinuz-4.4.0-149-generic'

# Generated at 2022-06-11 04:25:00.984049
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    class MockModule(object):
        def __init__(self):
            self.params = {}

    class MockFactCollector(object):
        def __init__(self):
            self.data = {'ansible_facts': {}}
            self.collected_facts = self.data['ansible_facts']

    mock_module = MockModule()
    mock_fact_collector = MockFactCollector()

    cmdline_collector = CmdLineFactCollector()
    cmdline_collector.collect(mock_module, mock_fact_collector)

    expected_data = {'ansible_facts': {'cmdline': {}, 'proc_cmdline': {}}}
    assert mock_fact_collector.data == expected_data

# Generated at 2022-06-11 04:25:02.994803
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert cmdline.name == 'cmdline'
    assert cmdline._fact_ids == set()


# Generated at 2022-06-11 04:25:04.162824
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'

# Generated at 2022-06-11 04:26:51.298057
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'

# Generated at 2022-06-11 04:26:55.060918
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    test_obj = CmdLineFactCollector()
    assert test_obj.name == 'cmdline'
    assert isinstance(test_obj._fact_ids, set)
    assert test_obj._fact_ids == set()

# Unit tests for functions _get_proc_cmdline, _parse_cmdline, and
# _parse_cmdline_facts

# Generated at 2022-06-11 04:27:02.887074
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    from ansible.module_utils.facts import collector

    collector.collectors._initialize_plugins(collector.collectors.module_finder,
                                             collector.collectors.get_all_plugin_loaders())

    cmdline_collector = collector.collectors.get_collector('cmdline')

    result = cmdline_collector.collect()
    assert result['proc_cmdline']['root'] == '/dev/mapper/centos-root'
    assert result['proc_cmdline']['ro'] is True
    assert result['proc_cmdline']['pm'] == 'ondemand'
    assert result['proc_cmdline']['nomodeset'] is True
    assert result['proc_cmdline']['console'] == 'tty0'

# Generated at 2022-06-11 04:27:04.622273
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert isinstance(CmdLineFactCollector(), CmdLineFactCollector)


# Generated at 2022-06-11 04:27:06.713986
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'

if __name__ == "__main__":
    test_CmdLineFactCollector()

# Generated at 2022-06-11 04:27:09.240636
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-11 04:27:16.810555
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Get CmdLineFactCollector object
    cmdline_ins = CmdLineFactCollector()

    # Mock proc_cmdline file with some facts
    mock_file_name = '/proc/cmdline'
    mock_file_content = b'cgroup_enable=memory swapaccount=1 ' \
                        b'net.ifnames=0 biosdevname=0 ' \
                        b'console=tty0 isolcpus=1,2 ' \
                        b'console=ttyS0,115200 iommu=pt intel_iommu=on ' \
                        b'console=tty0 console=ttyS0,115200'


# Generated at 2022-06-11 04:27:17.309295
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    pass

# Generated at 2022-06-11 04:27:20.657586
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # mock module input parameters
    collected_facts = dict()

    # initialize the target class
    cmdline_collector = CmdLineFactCollector()

    # invoke the target method
    returned_facts = cmdline_collector.collect(None, collected_facts)
    assert not returned_facts
    assert returned_facts == collected_facts

# Generated at 2022-06-11 04:27:22.099447
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector =  CmdLineFactCollector()
    assert (collector.name == 'cmdline')