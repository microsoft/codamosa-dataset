

# Generated at 2022-06-11 04:17:54.905255
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    CmdLineFactCollector._get_proc_cmdline = lambda x: "foo=bar baz qux=quux"
    assert CmdLineFactCollector.collect() == {'cmdline': {'foo': 'bar', 'baz': True, 'qux': 'quux'}, 'proc_cmdline': {'foo': 'bar', 'baz': True, 'qux': 'quux'}}

# Generated at 2022-06-11 04:17:56.995298
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()


# Generated at 2022-06-11 04:18:06.060603
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    bash_cmdline_fact_collector = CmdLineFactCollector()
    with open("./test_data/proc/cmdline", 'r') as proc_cmdline:
        cmdline_file_data = proc_cmdline.read()

    bash_cmdline_fact_collector._get_proc_cmdline = lambda: cmdline_file_data

    actual_data = bash_cmdline_fact_collector.collect()

# Generated at 2022-06-11 04:18:16.197037
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """Test if command line is parsed corretly"""
    source = CmdLineFactCollector()

# Generated at 2022-06-11 04:18:18.103866
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'
    assert collector._fact_ids == set()


# Generated at 2022-06-11 04:18:20.206006
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()

# Generated at 2022-06-11 04:18:22.120314
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector_obj = CmdLineFactCollector()
    assert cmdline_collector_obj.name == 'cmdline'

# Generated at 2022-06-11 04:18:23.576312
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'

# Generated at 2022-06-11 04:18:32.916951
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = {}

    data = """root=UUID=d4908a7d-a8e0-4826-9e65-a44aa8508faf ro xencommons=1 xencons=tty0 console=hvc0 xencons=tty1 nofb debug
console=hvc0"""

    cmdline_facts['cmdline'] = {'root': 'UUID=d4908a7d-a8e0-4826-9e65-a44aa8508faf',
                                'ro': True,
                                'xencommons': '1',
                                'xencons': 'tty1',
                                'nofb': True,
                                'debug': True,
                                'console': 'hvc0'}

# Generated at 2022-06-11 04:18:42.901351
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # cmdline_collector_path is a variable in module_utils/facts/cmdline.py
    cmdline_collector_path = 'ansible.module_utils.facts.cmdline'
    class FakeModule(object):
        pass

    class FakeCollector(object):
        def collect(self, module=None, collected_facts=None):
            return {}

    module = FakeModule()
    cmdline_collector = CmdLineFactCollector(module=module)
    assert cmdline_collector.collect() == {}, 'Test no cmdline is collected'

    module.params = {'gather_subset': list(cmdline_collector._valid_subsets)}
    # patch method 'get_file_content'

# Generated at 2022-06-11 04:18:48.605275
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'

# Generated at 2022-06-11 04:18:50.661520
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    res = CmdLineFactCollector()
    assert res.name == 'cmdline'
    assert isinstance(res._fact_ids, set)

# Generated at 2022-06-11 04:18:51.354212
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    pass

# Generated at 2022-06-11 04:19:00.178867
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collectors.cmdline import CmdLineFactCollector

    # Setup a minimal Ansible module object
    class AnsibleModule(object):
        def __init__(self):
            self.params = {}

    # Setup a CmdLineFactCollector
    c = CmdLineFactCollector(AnsibleModule())

    # Setup a minimal collected_facts
    collected_facts = {}
    collected_facts['cmdline'] = 'BOOT_IMAGE=/vmlinuz-3.19.0-32-generic.efi.signed root=UUID=abc123  ro quiet splash vt.handoff=7'

    # Call CmdLineFactCollector.collect
    ret = c.collect(collected_facts)

    # Assert that the results were as expected

# Generated at 2022-06-11 04:19:07.966896
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector({})
    cmdline_collector._get_proc_cmdline = lambda: 'BOOT_IMAGE=/boot/vmlinuz-3.13.0-24-generic root=UUID=cc8bb8e2-a2e3-4be9-9ed8-cadcd73b68c6 ro console=tty1 console=ttyS0'
    cmdline_facts = cmdline_collector.collect()['cmdline']
    assert cmdline_facts['BOOT_IMAGE'] == '/boot/vmlinuz-3.13.0-24-generic'
    assert cmdline_facts['root'] == 'UUID=cc8bb8e2-a2e3-4be9-9ed8-cadcd73b68c6'
    assert cmdline_

# Generated at 2022-06-11 04:19:16.997917
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector({'gather_subset': 'all'})
    cmdline_collector._get_proc_cmdline = lambda: 'console=ttyS0,9600n8 root=/dev/sda3 showopts rd_NO_PLYMOUTH resume=UUID=b0af6b12-ed42-4d7a-a65a-b772463c631a elevator=deadline loglevel=7'
    result = cmdline_collector.collect()

# Generated at 2022-06-11 04:19:18.761003
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'


# Generated at 2022-06-11 04:19:21.610486
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == "cmdline"
    assert cmdline_fact_collector._fact_ids == set()

# Generated at 2022-06-11 04:19:22.873761
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'

# Generated at 2022-06-11 04:19:24.312993
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector(None).name == 'cmdline'

# Generated at 2022-06-11 04:19:37.845061
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Constructor must accept only module and collected_facts as arguments
    CmdLineFactCollector(module=None, collected_facts=None)

    # Test on proc/cmdline with empty file
    with open("data/proc_cmdline_empty", 'r') as file_handler:
        cmdline_facts = CmdLineFactCollector()._parse_proc_cmdline(file_handler.read())
        assert cmdline_facts == {}

    # Test on proc/cmdline with no args
    with open("data/proc_cmdline_no_args", 'r') as file_handler:
        cmdline_facts = CmdLineFactCollector()._parse_proc_cmdline(file_handler.read())
        assert cmdline_facts == {}

    # Test on proc/cmdline with empty arg

# Generated at 2022-06-11 04:19:39.869390
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'

# Generated at 2022-06-11 04:19:49.759511
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Test when the file '/proc/cmdline' does not exist.
    # This is the normal case on a Windows system.
    collector = CmdLineFactCollector()

    collected_facts = collector.collect()

    assert 'cmdline' not in collected_facts
    assert 'proc_cmdline' not in collected_facts


    # Test when the file '/proc/cmdline' contains the following data:
    # 'console=ttyS0 elevator=cfq initrd=initram.img'
    collector = CmdLineFactCollector()

    cmdline_dict = {
        'console': 'ttyS0',
        'elevator': 'cfq',
        'initrd': 'initram.img'
    }

# Generated at 2022-06-11 04:19:52.514078
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert c._fact_ids == set()
    assert type(c._fact_ids) is set


# Generated at 2022-06-11 04:19:54.358458
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    """
    Checks if class is callable.
    """
    cmdline = CmdLineFactCollector()
    assert cmdline is not None

# Generated at 2022-06-11 04:20:03.203115
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    input = 'BOOT_IMAGE=/boot/vmlinuz-3.10.0-693.11.1.el7.x86_64 root=UUID=bc44cebe-b570-46b0-b7dc-33f9f8e92311 ro crashkernel=auto rd.lvm.lv=centos/root rd.lvm.lv=centos/swap rhgb quiet LANG=en_US.UTF-8'

# Generated at 2022-06-11 04:20:14.250651
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    def __init__(self):
        self.name = 'cmdline'
        self._fact_ids = set()

    def _get_proc_cmdline(self):
        return '/data/proc/cmdline'

    def _parse_proc_cmdline(self, data):
        cmdline_dict = {}
        try:
            for piece in shlex.split(data, posix=False):
                item = piece.split('=', 1)
                if len(item) == 1:
                    cmdline_dict[item[0]] = True
                else:
                    cmdline_dict[item[0]] = item[1]
        except ValueError:
            pass

        return cmdline_dict

    def _parse_proc_cmdline_facts(self, data):
        cmdline_dict = {}

# Generated at 2022-06-11 04:20:15.249933
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()

# Generated at 2022-06-11 04:20:24.729154
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import cache

    # create test environment
    facts_cache = cache.FactCache()
    facts_collector = collector.get_collector('CmdLineFactCollector', facts_cache=facts_cache)


# Generated at 2022-06-11 04:20:26.691921
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()

# Generated at 2022-06-11 04:20:43.618846
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    test_data = 'root=/dev/mapper/rhel-root ro crashkernel=auto rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet'
    collector = CmdLineFactCollector()
    cmdline = collector._parse_proc_cmdline(test_data)

    assert cmdline['root'].startswith('/dev')
    assert cmdline['rd.lvm.lv'].startswith('rhel')
    assert cmdline['rhgb'] == True
    assert cmdline['quiet'] == True

    cmdline_fact = collector._parse_proc_cmdline_facts(test_data)

    assert cmdline_fact['root'].startswith('/dev')
    assert cmdline_fact['rd.lvm.lv'][0].startswith

# Generated at 2022-06-11 04:20:45.891666
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.collect() == {}

# Generated at 2022-06-11 04:20:47.909204
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert cmdline.name == 'cmdline'
    assert cmdline._fact_ids == set()

# Generated at 2022-06-11 04:20:52.776337
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    cmdline_facts = collector.collect()

    print(cmdline_facts)

    assert 'cmdline' in cmdline_facts
    assert isinstance(cmdline_facts['cmdline'], dict)
    assert 'proc_cmdline' in cmdline_facts
    assert isinstance(cmdline_facts['proc_cmdline'], dict)

# Generated at 2022-06-11 04:20:53.894709
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    print(cmdline)

# Generated at 2022-06-11 04:20:55.409484
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cfc = CmdLineFactCollector()
    assert cfc.name == 'cmdline'


# Generated at 2022-06-11 04:20:59.918286
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    test_fixture = CmdLineFactCollector()
    assert test_fixture
    assert test_fixture.name == 'cmdline'
    assert len(test_fixture._fact_ids) == 0
    assert len(test_fixture.collect()) == 2
    assert test_fixture.collect().get('cmdline')
    assert test_fixture.collect().get('proc_cmdline')

# Generated at 2022-06-11 04:21:09.010219
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import ansible.module_utils.facts.collector.cmdline as module

    # Test if /proc/cmdline is empty
    content = ''
    result = module._get_proc_cmdline(content)
    assert result == ''

    # Test if valid proc/cmdline
    content = "user=u1 ro"
    result = module._get_proc_cmdline()
    assert result != ''

    # Test parse_proc_cmdline function
    data = "user=u1 ro"
    result = module._parse_proc_cmdline(data)
    assert result == {'user': 'u1', 'ro': True}

    # Test parse_proc_cmdline_facts function
    data = "user=u1 ro"
    result = module._parse_proc_cmdline_facts(data)

# Generated at 2022-06-11 04:21:10.531714
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector(None)
    assert collector.name == 'cmdline'

# Generated at 2022-06-11 04:21:11.384017
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()

# Generated at 2022-06-11 04:21:34.077006
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector.cmdline import CmdLineFactCollector
    cmdline_collector = CmdLineFactCollector()
    cmdline = cmdline_collector.collect()
    # cmdline_collector returns a dict with keys cmdline and proc_cmdline.
    assert (isinstance(cmdline, dict))
    assert ('cmdline' in cmdline)
    assert ('proc_cmdline' in cmdline)
    # Check that the data from /proc/cmdline is used to populate the dict.
    assert (cmdline['cmdline'] is not None)
    assert ('ro' in cmdline['cmdline'])
    # Check that the data from /proc/cmdline is used to populate the dict.
    assert (cmdline['proc_cmdline'] is not None)

# Generated at 2022-06-11 04:21:34.880952
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    assert CmdLineFactCollector().collect() is not None

# Generated at 2022-06-11 04:21:43.987695
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    with mock.patch('ansible.module_utils.facts.collector.get_file_content') as m_get_file_content:
        m_get_file_content.return_value = 'BOOT_IMAGE=/kernel-3.10.0-514.el7.x86_64 ec2=True ec2_opts="console=ttyS0" cgroup_enable=cpuset cgroup_memory=1 cgroup_enable=memory swapaccount=1 rhgb quiet LANG=en_US.UTF-8'
        # Case 1: No value
        cmdline_facts = CmdLineFactCollector().collect()

# Generated at 2022-06-11 04:21:52.513734
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
        proc_cmdline = ('ip=192.168.131.200::192.168.131.254:255.255.255.0:pl1:'
                        ':none:eth0:off::: panic=1 initcall_debug init=/sbin/init '
                        'console=tty1 console=ttyS1,115200n8')
        data = {'ip': '192.168.131.200::192.168.131.254:255.255.255.0:pl1:'
                ':none:eth0:off:::',
                'panic': '1',
                'initcall_debug': True,
                'init': '/sbin/init',
                'console': ['tty1', 'ttyS1,115200n8']}
        cmdline_facts = {}

# Generated at 2022-06-11 04:21:55.215837
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()

    assert cmdline_fact_collector.name == 'cmdline'

    # by default, all the attributes are set to none
    assert cmdline_fact_collector._fact_ids is None

# Generated at 2022-06-11 04:21:56.224918
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()


# Generated at 2022-06-11 04:22:04.923397
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import CollectorsRegistry
    from ansible.module_utils._text import to_bytes

    collector = CmdLineFactCollector()
    CollectorsRegistry._check_collectors(collector)

    # Just check that we can get the facts for the main class
    # We do not test the other classes because we would need to
    # mock things to not have to deal with /proc/*, testing the
    # other classes is done in their unittests
    facts = {'cmdline': {}}
    expected_facts = {'cmdline': {'ansible_facts': {'cmdline': {'BOOT_IMAGE': 'a'}}}}


# Generated at 2022-06-11 04:22:12.346534
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    class mock_BaseFactCollector(BaseFactCollector):

        def __init__(self):
            self.data = None

        def _get_file_content(self, filename):
            return self.data

    cmdline_collector = CmdLineFactCollector()
    base_cmdline_collector = cmdline_collector.__class__.__bases__[0]

    data = 'root=UUID=2d1f3787-2b7e-4eb8-a7d5-f87aaa53dcf0 rw  quiet font=latarcyrheb-sun16 crashkernel=auto rhgb quiet'

    base_cmdline_collector._get_file_content = mock_BaseFactCollector()._get_file_content
    base_cmdline_collector._get_file_content.data

# Generated at 2022-06-11 04:22:13.069557
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()


# Generated at 2022-06-11 04:22:16.506240
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector
    assert cmd_line_fact_collector.name == 'cmdline'
    assert cmd_line_fact_collector._fact_ids == set()


# Generated at 2022-06-11 04:23:01.394519
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import datetime
    import json
    import tempfile
    with tempfile.NamedTemporaryFile('w') as tmp:
        with open(tmp.name, 'w') as tmp2:
            tmp2.write('ro')
        fc = CmdLineFactCollector()
        cmdline_facts = fc.collect()
        assert 'cmdline' in cmdline_facts
        assert 'proc_cmdline' in cmdline_facts
        assert isinstance(cmdline_facts['cmdline'], dict)
        assert isinstance(cmdline_facts['proc_cmdline'], dict)
        #todo
        assert 'ro' in cmdline_facts['cmdline']
        assert 'ro' in cmdline_facts['proc_cmdline']

# Generated at 2022-06-11 04:23:09.270331
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector._get_proc_cmdline = lambda: 'ansible_ssh_host=10.1.1.1'
    cmdline_collector._parse_proc_cmdline = lambda data: data
    cmdline_collector._parse_proc_cmdline_facts = lambda data: data

    actual_results = cmdline_collector.collect()

    assert actual_results['cmdline'] == 'ansible_ssh_host=10.1.1.1'
    assert actual_results['proc_cmdline'] == 'ansible_ssh_host=10.1.1.1'

if __name__ == '__main__':
    test_CmdLineFactCollector_collect()

# Generated at 2022-06-11 04:23:10.329356
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector().name == 'cmdline'

# Generated at 2022-06-11 04:23:11.143295
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()

# Generated at 2022-06-11 04:23:13.024659
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    inst = CmdLineFactCollector()
    assert isinstance(inst, CmdLineFactCollector)
    assert isinstance(inst._fact_ids, set)

# Generated at 2022-06-11 04:23:14.018482
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'

# Generated at 2022-06-11 04:23:19.359957
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Arrange
    cmd_line_fact_collector = CmdLineFactCollector()

    # Act
    result = cmd_line_fact_collector.collect()

    # Assert
    assert isinstance(result, dict)
    assert 'cmdline' in result
    assert isinstance(result['cmdline'], dict)
    assert 'proc_cmdline' in result
    assert isinstance(result['proc_cmdline'], dict)
    assert (result['cmdline']) == (result['proc_cmdline'])


# Generated at 2022-06-11 04:23:20.737904
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    fact = CmdLineFactCollector()
    assert fact.name == 'cmdline'


# Generated at 2022-06-11 04:23:22.314806
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdLineFactCollector = CmdLineFactCollector()
    assert cmdLineFactCollector


# Generated at 2022-06-11 04:23:31.256141
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # /proc/cmdline content written as a single line
    proc_cmdline_content = 'BOOT_IMAGE=/kernel/vmlinux-4.18.0-80.el8.x86_64 console=ttyS0,115200n8 net.ifnames=0 crashkernel=auto crashkernel=auto rd.lvm.lv=rhel/swap rd.lvm.lv=rhel/root biosdevname=0 root=/dev/mapper/rhel-root ro LANG=en_US.UTF-8'

    # expected dictionary returned by method _parse_proc_cmdline

# Generated at 2022-06-11 04:25:01.218121
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline = CmdLineFactCollector()
    cmdline._get_proc_cmdline = lambda: ' test1=1  test2=2 test3 '
    assert cmdline.collect() == {'cmdline': {'test1': '1', 'test2': '2', 'test3': True},
                                 'proc_cmdline': {'test1': '1', 'test2': '2', 'test3': True}}

    cmdline._get_proc_cmdline = lambda: ' test1=1  test2=2  test1=3 '
    assert cmdline.collect() == {'cmdline': {'test1': '1', 'test2': '2', 'test1': '3'},
                                 'proc_cmdline': {'test1': ['1', '3'], 'test2': '2'}}

# Generated at 2022-06-11 04:25:08.691957
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    expected_cmdline_facts = {
        'cmdline': {'elevator': 'deadline',
                    'foo': 'bar',
                    'rootfstype': 'ext4'},
        'proc_cmdline': {'bootopt': '1',
                         'console': 'ttyS0,115200n8',
                         'elevator': 'deadline',
                         'foo': ['bar', 'baz', 'qux'],
                         'kernelopt': ['crashkernel=auto', 'rd.shell'],
                         'root': '/dev/mapper/vg-root',
                         'rootfstype': ['ext4', 'ext2']}
    }

    collector = CmdLineFactCollector(None, {}, {}, None, {})

# Generated at 2022-06-11 04:25:13.963145
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """
    Test the method collect when /proc/cmdline file is empty

    """
    # Create a new instance of CmdLineFactCollector
    cmd_line_collector = CmdLineFactCollector()
    # Set the /proc/cmdline to empty
    cmd_line_collector._get_proc_cmdline = lambda: ""
    # Test run collect method
    assert cmd_line_collector.collect() == {}


# Generated at 2022-06-11 04:25:20.516710
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = {}

    data = "BOOT_IMAGE=/vmlinuz-3.10.0-514.21.2.el7.x86_64 root=/dev/mapper/rhel-root ro rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap crashkernel=auto rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap crashkernel=auto vconsole.font=latarcyrheb-sun16 rhgb quiet LANG=en_US.UTF-8"


# Generated at 2022-06-11 04:25:22.902845
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert type(cmdline_fact_collector) is CmdLineFactCollector
    assert cmdline_fact_collector.name == 'cmdline'


# Generated at 2022-06-11 04:25:24.545925
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'


# Generated at 2022-06-11 04:25:25.909046
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = CmdLineFactCollector()
    assert cmdline_facts.name == 'cmdline'


# Generated at 2022-06-11 04:25:33.456594
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    test_obj = CmdLineFactCollector()

    data = 'idevname=test_idevname ip=test_ip idevid=test_idevid'
    test_obj._get_proc_cmdline = lambda: data

    expected_collect_results = {
        "cmdline": {
            "idevname": "test_idevname",
            "ip": "test_ip",
        },
        "proc_cmdline": {
            "idevname": ["test_idevname"],
            "ip": "test_ip",
            "idevid": "test_idevid",
        },
    }
    assert expected_collect_results == test_obj.collect()


# Generated at 2022-06-11 04:25:37.906767
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()

    assert isinstance(cmdline_facts, dict)
    assert 'cmdline' in cmdline_facts
    assert 'proc_cmdline' in cmdline_facts
    assert 'ansible_net_hostname' in cmdline_facts['proc_cmdline']
    assert 'ansible_net_version' in cmdline_facts['proc_cmdline']

# Generated at 2022-06-11 04:25:41.082363
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_fact_collector = CmdLineFactCollector()
    result = cmdline_fact_collector.collect()
    assert isinstance(result, dict)
    assert 'cmdline' in result
    assert isinstance(result['cmdline'], dict)
    assert 'proc_cmdline' in result