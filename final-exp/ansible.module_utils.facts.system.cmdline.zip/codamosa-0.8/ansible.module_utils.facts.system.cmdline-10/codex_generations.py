

# Generated at 2022-06-11 04:17:57.770009
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors import CmdLineFactCollector
    from io import StringIO

    collected_facts = Collector(sets=['cmdline'])
    c = CmdLineFactCollector()
    c.collect(collected_facts=collected_facts)

    assert isinstance(c, BaseFactCollector)
    assert isinstance(collected_facts['cmdline'], dict)

# Generated at 2022-06-11 04:17:58.694481
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector()


# Generated at 2022-06-11 04:18:06.702739
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    import os
    import tempfile

    with tempfile.NamedTemporaryFile(mode="w+") as f:
        cmdline = "This is my cmdline"
        f.write(cmdline)
        f.seek(0)

        collector = Collector()
        collector.set_read_file('/proc/cmdline', f.name)

        cmdline_collector = CmdLineFactCollector(collector)
        cmdline_facts = cmdline_collector.collect()

        assert cmdline_facts['cmdline'] == {cmdline: True}
        assert cmdline_facts['proc_cmdline'] == {cmdline: None}

# Generated at 2022-06-11 04:18:09.372271
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Initialize CmdLineFactCollector class
    cmd_line_collector = CmdLineFactCollector()

    assert cmd_line_collector.name == "cmdline"

# Generated at 2022-06-11 04:18:10.814409
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'

# Generated at 2022-06-11 04:18:20.413769
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.collect() == {'cmdline': {}, 'proc_cmdline': {}}
    cmdline_fact_collector._get_proc_cmdline = lambda: 'parameter1=value1 parameter2=value2 parameter3=value3'
    assert cmdline_fact_collector.collect() == {'cmdline': {'parameter1': 'value1', 'parameter2': 'value2', 'parameter3': 'value3'}, 'proc_cmdline': {'parameter1': 'value1', 'parameter2': 'value2', 'parameter3': 'value3'}}

# Generated at 2022-06-11 04:18:30.113974
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Get "facts" object
    import ansible.module_utils.facts.facts as facts
    fact_collector = CmdLineFactCollector(facts)

    # Get "module" object
    import ansible.module_utils.facts.utils as utils
    from ansible.module_utils import basic

    orig_get_file_content = utils.get_file_content
    utils.get_file_content = lambda f: 'console=ttyS0,38400n8r'
    module = basic.AnsibleModule(argument_spec={})

    cmdline_facts = fact_collector.collect(module)
    utils.get_file_content = orig_get_file_content

    # Test expected result

# Generated at 2022-06-11 04:18:31.001024
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    print(CmdLineFactCollector().collect())

# Generated at 2022-06-11 04:18:33.078840
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    fact_collector = CmdLineFactCollector()

    assert fact_collector.name == 'cmdline'
    assert not fact_collector._fact_ids


# Generated at 2022-06-11 04:18:35.760456
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    CmdLineFactCollector = CmdLineFactCollector()
    result = CmdLineFactCollector.collect()
    assert 'cmdline' in result
    assert 'proc_cmdline' in result

# Generated at 2022-06-11 04:18:42.898044
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()

# Generated at 2022-06-11 04:18:47.393150
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector

    facts_collector = FactsCollector()

    cmdline_collector = CmdLineFactCollector()
    cmdline_collector.collect(collected_facts=facts_collector)

    assert facts_collector.get_fact('cmdline') is not None


# Generated at 2022-06-11 04:18:48.692699
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'

# Generated at 2022-06-11 04:18:50.743540
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    _c = CmdLineFactCollector()
    assert _c.name == 'cmdline'
    assert len(_c.collect()) == 2

# Generated at 2022-06-11 04:18:59.753740
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import os

    # Test with no cmdline file
    CmdLineFactCollector._get_proc_cmdline = lambda x: None
    cmdline_facts = CmdLineFactCollector().collect()
    assert not cmdline_facts, "Found cmdline facts for non-existent cmdline file"

    # Test with cmdline file
    proc_cmdline_file = os.path.join(os.path.dirname(__file__), '../../unit/ansible_test/_data/proc_cmdline')
    CmdLineFactCollector._get_proc_cmdline = lambda x: get_file_content(proc_cmdline_file)
    cmdline_facts = CmdLineFactCollector().collect()
    assert 'cmdline' in cmdline_facts, "cmdline facts are missing 'cmdline' dictionary"

# Generated at 2022-06-11 04:19:04.284926
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    result = cmdline_collector.collect()

    assert result['cmdline']
    assert result['cmdline']['ro']
    assert result['proc_cmdline']['root']
    assert result['proc_cmdline']['ro']
    assert result['proc_cmdline']['root'].startswith('/dev/mapper/VolGroup-lv_root')


# Generated at 2022-06-11 04:19:06.544822
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = CmdLineFactCollector()
    assert cmdline_facts.name == 'cmdline'
    assert cmdline_facts._fact_ids == set()


# Generated at 2022-06-11 04:19:08.431218
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector().name == 'cmdline'
    assert isinstance(CmdLineFactCollector()._fact_ids, set) == True
    assert CmdLineFactCollector()._fact_ids == set()


# Generated at 2022-06-11 04:19:10.362774
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    print('''
======= Test output =======
{}
===========================
'''.format(CmdLineFactCollector().collect()))


# Generated at 2022-06-11 04:19:12.949219
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # create object of class CmdLineFactCollector
    cmd_line_object = CmdLineFactCollector()
    # check if the object is created
    assert cmd_line_object is not None


# Generated at 2022-06-11 04:19:30.729843
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    data = 'BOOT_IMAGE=(hd0,gpt3)/vmlinuz-3.10.0-123.el7.x86_64'
    data += 'ro '
    data += 'root=UUID=6b0efcc7-b6f2-46d9-8f60-c72481'
    data += '0cde4e crashkernel=auto rhgb quiet LANG=en_US.UTF-8 '
    data += 'initrd=initrd-3.10.0-123.el7.x86_64.img'

    cmdline_fact = CmdLineFactCollector

    cmdline_facts = cmdline_fact.collect(cmdline_fact, {'ansible_cmdline': data})


# Generated at 2022-06-11 04:19:40.273743
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from . import MockFactsParams
    from ansible_collections.ansible.community.plugins.module_utils.facts import collector

    test_params = MockFactsParams()
    mock_dir = test_params.collector['cmdline']['files']['proc_cmdline']
    cmdline_data = "console=ttyS0,9600n8 noinitrd panic=10 consoleblank=0"
    cmdline_dict = {'console': "ttyS0,9600n8", 'noinitrd': True,
                    'panic': '10', 'consoleblank': '0'}
    proc_cmdline_dict = {'console': ['ttyS0,9600n8'], 'noinitrd': True,
                         'panic': '10', 'consoleblank': ['0']}
    test_params.collector

# Generated at 2022-06-11 04:19:42.218222
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()


# Generated at 2022-06-11 04:19:52.239159
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts import ansible_collections 
    from ansible.module_utils.facts.collectors import base
    from ansible.module_utils.facts.collectors.cmdline import CmdLineFactCollector
    
    # Create a new instance of the object to test
    cmdline_obj = CmdLineFactCollector()
    # Create a new instance of an object to test
    base_obj = base.BaseFactCollector()
    # Create a new instance of an object to test
    ans_coll_obj = ansible_collections.ansible_collections.all

    # Create a new subclass of the object to test
    class NewCmdLineFactsSubclass(CmdLineFactCollector):
        name = 'new_cmdline'
        _fact_ids = set()

# Generated at 2022-06-11 04:19:53.846636
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'


# Generated at 2022-06-11 04:19:55.959999
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = CmdLineFactCollector()

    assert cmdline_facts.name == 'cmdline'
    assert cmdline_facts._fact_ids == set()

# Generated at 2022-06-11 04:19:57.075636
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    assert CmdLineFactCollector.collect()


# Generated at 2022-06-11 04:19:59.443157
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector is not None
    assert cmdline_collector.name == 'cmdline'

# Generated at 2022-06-11 04:20:01.554111
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cf = CmdLineFactCollector()
    assert cf.name == 'cmdline'
    assert cf._fact_ids == set()


# Generated at 2022-06-11 04:20:02.460673
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    CmdLineFactCollector.collect()

# Generated at 2022-06-11 04:20:26.511517
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from collections import namedtuple
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils._text import to_bytes
    import ansible.module_utils.facts.collectors.cmdline

    data = '''root=UUID=FDD8-92B1 net.ifnames=0 biosdevname=0 rhgb quiet LANG=en_US.UTF-8
initrd=initrd-3.10.0-862.2.3.el7.x86_64.img'''
    collector = None
    fake_file = '''
#!/bin/bash
echo -n %s
    '''
    with open('/tmp/faketcmdline', 'w') as f:
        f.write(to_bytes(fake_file % data))


# Generated at 2022-06-11 04:20:30.087475
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()

    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-11 04:20:30.670938
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    pass

# Generated at 2022-06-11 04:20:34.036492
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = CmdLineFactCollector()
    assert cmdline_facts.name == 'cmdline'
    assert "_fact_ids" in cmdline_facts.__dict__
    assert cmdline_facts._fact_ids == set()


# Generated at 2022-06-11 04:20:42.953026
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    test_object = CmdLineFactCollector(None)

    obj1 = CmdLineFactCollector(None)
    obj2 = CmdLineFactCollector(None)

    # Test for empty string
    cmdline_file = ""
    test_object._get_proc_cmdline = lambda: cmdline_file
    result = test_object.collect()
    assert result == {}

    # Test for invalid string
    cmdline_file = "a=b=c"
    test_object._get_proc_cmdline = lambda: cmdline_file
    result = test_object.collect()
    assert result == {"cmdline": {}, "proc_cmdline": {}}

    # Test for valid string

# Generated at 2022-06-11 04:20:52.547763
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """Unit test for method collect of class CmdLineFactCollector"""
    #
    collector = CmdLineFactCollector()
    #
    cmdline_facts = collector.collect()
    #assert cmdline_facts == {'cmdline': {'BOOT_IMAGE': '/vmlinuz-3.10.0-1127.el7.x86_64', 'rw': 'root=/dev/mapper/rhel-root', 'console': 'ttyS0,115200n8', 'crashkernel': 'auto', 'rd.lvm.lv': 'rhel/root', 'rd.lvm.lv': 'rhel/swap', 'rhgb': 'quiet'}, 'proc_cmdline': {'BOOT_IMAGE': '/vmlinuz-3.10.0-1127.el7.x86_64', '

# Generated at 2022-06-11 04:20:54.935904
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    """:type: CmdLineFactCollector"""
    assert c.name == 'cmdline'
    assert c._fact_ids == set()


# Generated at 2022-06-11 04:20:56.523820
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert not CmdLineFactCollector._fact_ids

# Generated at 2022-06-11 04:20:58.004323
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'

# Generated at 2022-06-11 04:21:06.981017
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """
    Unit test for method collect of class CmdLineFactCollector
    """
    import os
    from ansible.module_utils.facts import Collector

    def get_file_stub(file_name):
        """
        Stub method to get file content
        """
        test_data = {
            '/proc/cmdline': 'BOOT_IMAGE=/vmlinuz-4.4.0-81-generic root=/dev/mapper/ubuntu1604-root ro console=ttyS0,9600 net.ifnames=0 biosdevname=0'
        }

        return test_data[file_name]

    _collector = Collector.create_collector('cmdline', {})
    collector = CmdLineFactCollector(_collector)

    # Set get_file_content to our stub
    collector.get_file_

# Generated at 2022-06-11 04:21:42.704530
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert isinstance(cmdline_fact_collector, BaseFactCollector)
    assert 'cmdline' == cmdline_fact_collector.name
    assert cmdline_fact_collector._fact_ids == set()



# Generated at 2022-06-11 04:21:44.264597
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == "cmdline"

# Generated at 2022-06-11 04:21:46.670497
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert len(cmdline_collector._fact_ids) == 0


# Generated at 2022-06-11 04:21:48.601885
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    res = CmdLineFactCollector()
    assert res.name == 'cmdline'
    assert res._fact_ids == set()

# Generated at 2022-06-11 04:21:50.952460
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Given
    instance = CmdLineFactCollector()
    # When
    facts = instance.collect()
    # Then
    assert isinstance(facts, dict)

# Generated at 2022-06-11 04:22:00.131796
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    '''
    Unit test for method collect of class CmdLineFactCollector
    '''
    cmdline_facts = {}

    data = """\
root=/dev/mapper/vg_test-lv_root ro rd.lvm.lv=vg_test/lv_root rd.md=0 rd.dm=0 vconsole.keymap=us rd.luks=0 LANG=en_US.UTF-8 SYSFONT=latarcyrheb-sun16 crashkernel=auto rd.lvm.lv=vg_test/lv_swap rhgb quiet vconsole.font=latarcyrheb-sun16
"""

# Generated at 2022-06-11 04:22:07.799317
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Set up class and function parameters
    cmdline_file = ['ro', 'root=/dev/mapper/vg_fedora_localhost--live-root', 'init=/usr/lib/systemd/systemd', 'LANG=en_US.UTF-8', 'initrd=initramfs-3.12.6-200.fc20.x86_64.img']
    # Create instance of CmdLineFactCollector
    cmdline_collector = CmdLineFactCollector()
    # Unit test _get_proc_cmdline() of class CmdLineFactCollector
    cmdline_collector.get_file_content = lambda file, the_type: cmdline_file
    assert cmdline_collector._get_proc_cmdline() == cmdline_file
    # Unit test _parse_proc_cmdline() of class Cmd

# Generated at 2022-06-11 04:22:14.671208
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import os
    import shutil
    import tempfile
    from ansible.module_utils.facts.collector import BaseFactCollector

    test_collector = CmdLineFactCollector()

    assert isinstance(test_collector, BaseFactCollector)

    # Create temporary directory and a temporary file
    tempFile = tempfile.NamedTemporaryFile(mode='w+t', dir=tempfile.mkdtemp())
    tempFile.write('foo=bar\n')
    tempFile.write('baz=foobar\n')
    tempFile.flush()

    # Test if file /proc/cmdline exists
    os.remove('/proc/cmdline')

    # Add temporary file to one more location
    shutil.copy(tempFile.name, '/proc/cmdline')

    result = test_collector.collect()

# Generated at 2022-06-11 04:22:17.406668
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    facts = CmdLineFactCollector()
    assert isinstance(facts, CmdLineFactCollector)
    assert isinstance(facts.name, str)
    assert isinstance(facts._fact_ids, set)


# Generated at 2022-06-11 04:22:19.884828
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cf = CmdLineFactCollector()
    results = cf.collect()
    assert isinstance(results, dict)
    assert 'cmdline' in results
    assert 'proc_cmdline' in results

# Generated at 2022-06-11 04:23:47.435699
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    result = CmdLineFactCollector().collect()

    assert result['cmdline']['quiet'] is True


# Generated at 2022-06-11 04:23:49.534168
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    c = CmdLineFactCollector()
    cmdline_facts = c.collect()
    assert cmdline_facts['cmdline']
    assert cmdline_facts['proc_cmdline']


# Generated at 2022-06-11 04:23:52.402857
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    class_name = 'CmdLineFactCollector'
    # Instantiate the class
    obj = CmdLineFactCollector()
    # Test the method with good and bad parameters
    assert isinstance(obj.collect(), dict)
    assert isinstance(obj.collect('module', 'facts'), dict)

# Generated at 2022-06-11 04:23:56.140346
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    cmdline_facts = collector.collect()
    assert isinstance(cmdline_facts['proc_cmdline'], dict)
    assert isinstance(cmdline_facts['cmdline'], dict)
    assert set(cmdline_facts['proc_cmdline'].keys()) == set(cmdline_facts['cmdline'].keys())

# Generated at 2022-06-11 04:24:01.668172
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    c = CmdLineFactCollector()
    collected_facts = dict()
    x = c.collect(collected_facts=collected_facts)
    assert isinstance(x, dict)
    assert isinstance(x['cmdline'], dict)
    assert x['cmdline']['ansible_test_key'] == 'my_test_value'
    assert isinstance(x['proc_cmdline'], dict)
    assert x['proc_cmdline']['ansible_test_key'] == ['value_1', 'value_2']

# Generated at 2022-06-11 04:24:09.176789
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts_collector = CmdLineFactCollector()
    data = cmdline_facts_collector._get_proc_cmdline()
    cmdline_facts = cmdline_facts_collector._parse_proc_cmdline(data)
    assert cmdline_facts['ro'], 'ro=True'
    assert cmdline_facts['rd.dm.uuid'], 'rd.dm.uuid=cr_MPB--R33DiuJv5BF'
    assert cmdline_facts['console'], 'console=ttyS0,115200n81'
    assert cmdline_facts['rw'], 'rw=True'
    assert cmdline_facts['loglevel'], 'loglevel=7'

# Generated at 2022-06-11 04:24:10.344886
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    fc = CmdLineFactCollector()
    assert fc.name == 'cmdline'


# Generated at 2022-06-11 04:24:15.256452
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    from ansible.module_utils.facts.collectors.cmdline import CmdLineFactCollector

    data = 'root=/dev/sda1 ro rootfstype=ext4 rootflags=rw_barrier'

    cmdline_facts = {}

    cmdline_facts['cmdline'] = CmdLineFactCollector()._parse_proc_cmdline(data)
    cmdline_facts['proc_cmdline'] = CmdLineFactCollector()._parse_proc_cmdline_facts(data)

    assert cmdline_facts['cmdline'] == {'root': '/dev/sda1', 'ro': True, 'rootfstype':'ext4', 'rootflags': 'rw_barrier'}

# Generated at 2022-06-11 04:24:22.923165
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    # unit test compatible cmdline
    cmdline = "BOOT_IMAGE=/vmlinuz-3.13.0-86-generic.efi.signed " \
              "root=UUID=4e23b4d4-949d-47b1-81bc-000001aa0000 ro " \
              "quiet splash vt.handoff=7"

    # unit test compatible response

# Generated at 2022-06-11 04:24:31.067886
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    class Args:
        def __init__(self, config):
            self.config = config

    class AnsibleModule:
        def __init__(self, args):
            self.params = args

    config = {}
    module = AnsibleModule(Args(config))
    instance = CmdLineFactCollector(module)
    result = instance.collect()