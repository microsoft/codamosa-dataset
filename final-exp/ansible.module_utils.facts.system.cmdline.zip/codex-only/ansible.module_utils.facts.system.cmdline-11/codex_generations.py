

# Generated at 2022-06-23 00:47:56.830342
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'
    assert collector._fact_ids == set()

# Generated at 2022-06-23 00:48:08.184545
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Input data
    cmdline_cmdline_dict = {'foo': True,
        'bar': 'baz',
        'boo': True}

    cmdline_proc_cmdline_dict = {'foo': True,
        'bar': 'baz',
        'boo': ['bar', 'baz']}

    # Expected result
    expected_result = {'cmdline': cmdline_cmdline_dict,
        'proc_cmdline': cmdline_proc_cmdline_dict}

    # Expected cmdline data
    cmdline_data = ''.join(['foo ',
        'bar=baz ',
        'boo ',
        'boo=bar ',
        'boo=baz'])

    # Mocking get_file_content

# Generated at 2022-06-23 00:48:16.153385
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdLineFactCollector = CmdLineFactCollector()
    cmdLineFactCollector._get_proc_cmdline = lambda: 'root=LABEL=cloudimg-rootfs ro console=ttyS0'
    cmdLineDict = cmdLineFactCollector.collect()
    assert cmdLineDict
    assert cmdLineDict['cmdline']['root'] == 'LABEL=cloudimg-rootfs'
    assert cmdLineDict['proc_cmdline']['ro'] == True
    assert cmdLineDict['proc_cmdline']['console'] == 'ttyS0'

# Generated at 2022-06-23 00:48:21.638737
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    collector = CmdLineFactCollector()

    collector.content = {'proc_cmdline': 'SOME_ARG=some_value LINUX_CMDLINE= linux_cmdline_value'}

    cmdline_facts = collector.collect()

    assert cmdline_facts == {'cmdline': {'LINUX_CMDLINE': 'linux_cmdline_value', 'SOME_ARG': 'some_value'},
                             'proc_cmdline': {'LINUX_CMDLINE': 'linux_cmdline_value', 'SOME_ARG': 'some_value'}}

# Generated at 2022-06-23 00:48:28.069852
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline = cmdline_collector._get_proc_cmdline()
    proc_cmdline = cmdline_collector._parse_proc_cmdline(cmdline)
    proc_cmdline_facts = cmdline_collector._parse_proc_cmdline_facts(cmdline)

    assert CmdLineFactCollector.name == 'cmdline'
    assert proc_cmdline == proc_cmdline_facts

# Generated at 2022-06-23 00:48:38.132448
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    from ansible.module_utils.facts import processor

    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.processors import CmdLineFactProcessor

    from ansible.module_utils.facts.collectors.cmdline import CmdLineFactCollector

    processor.add_callback(CmdLineFactProcessor())
    Collector.add_callback(CmdLineFactCollector())

    facts = processor.collect(module=None, collected_facts=None)

    assert 'proc_cmdline' in facts
    assert 'cmdline' in facts

    assert len(facts['proc_cmdline']) > 0
    assert len(facts['cmdline']) > 0


# Generated at 2022-06-23 00:48:48.748822
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = {}

    data = get_file_content('/proc/cmdline')

    if not data:
        return cmdline_facts

    cmdline_facts['cmdline'] = {}
    cmdline_facts['proc_cmdline'] = {}

    try:
        for piece in shlex.split(data, posix=False):
            item = piece.split('=', 1)

            if len(item) == 1:
                cmdline_facts['cmdline'][item[0]] = True
                cmdline_facts['proc_cmdline'][item[0]] = True
            else:
                cmdline_facts['cmdline'][item[0]] = item[1]
                cmdline_facts['proc_cmdline'][item[0]] = item[1]
    except ValueError:
        pass

    print

# Generated at 2022-06-23 00:49:02.565216
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    # Expected result
    _EXPECTED_RESULT = {'proc_cmdline': {'ansible': 'is_cool', 'swap': True},
                        'cmdline': {'ansible': 'is_cool', 'swap': True}}

    # Create an instance of class CmdLineFactCollector
    cmdline_fact_collector = CmdLineFactCollector()

    # Mock method _get_proc_cmdline so that it returns the expected value
    cmdline_fact_collector._get_proc_cmdline = lambda: \
        'ansible=is_cool swap'

    # Call method collect
    result = cmdline_fact_collector.collect()

    # Assert that result is equal to the expected value
    assert result == _EXPECTED_RESULT

# Generated at 2022-06-23 00:49:07.905981
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from __main__ import collect_facts
    # run the class method collect
    cl_fact = CmdLineFactCollector()
    cl_fact_list = cl_fact.collect()

    # get the results of the module collect_facts
    module_list = collect_facts
    module_dict = module_list['ansible_facts']

    assert cl_fact_list == module_dict

# Generated at 2022-06-23 00:49:09.492876
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    tester = CmdLineFactCollector()
    assert tester.name == 'cmdline'


# Generated at 2022-06-23 00:49:19.890948
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    fake_module = []
    fake_collected_facts = []

    # TEST-CASE 1: successful execution
    # Test the execution of method collect with valid parameters
    cmdline_data = "BOOT_IMAGE=/boot/vmlinuz-4.18.0-147.5.1.el8_1.x86_64"\
        " root=/dev/mapper/cl-root ro crashkernel=auto rd.lvm.lv=cl/root"\
        " rd.lvm.lv=cl/swap rhgb quiet LANG=en_US.UTF-8 net.ifnames=0"\
        " biosdevname=0 ipv6.disable=1"

    class MockCmdLineFactCollector(CmdLineFactCollector):
        def _get_proc_cmdline(self):
            return cmdline

# Generated at 2022-06-23 00:49:30.232336
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import os
    from ansible.module_utils._text import to_bytes
    test_proc_content = to_bytes('''
    linux
    mem=1G
    cgroup_enable=memory
    cgroup.memory=nokmem
    ''')

    # Set up a test filesystem tree with a proc "cmdline" file in it
    # for CmdLineFactCollector to read.
    import shutil
    import tempfile
    tempdir = tempfile.mkdtemp()
    test_cmdline_path = os.path.join(tempdir, "proc", "cmdline")
    os.makedirs(os.path.dirname(test_cmdline_path))

# Generated at 2022-06-23 00:49:32.462248
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = CmdLineFactCollector()
    assert cmdline_facts.name == 'cmdline'


# Generated at 2022-06-23 00:49:34.555393
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    data = CmdLineFactCollector()
    assert data.name == 'cmdline'
    assert data._fact_ids == set()

# Generated at 2022-06-23 00:49:38.265748
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert 'cmdline' in cmdline_facts
    assert 'proc_cmdline' in cmdline_facts
    assert 'root' in cmdline_facts['cmdline']
    assert isinstance(cmdline_facts['proc_cmdline'], dict)

# Generated at 2022-06-23 00:49:42.563852
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Constructor of class CmdLineFactCollector should be initialized
    # with no arguments and no exception thrown.
    cf = CmdLineFactCollector()
    assert cf

# Generated at 2022-06-23 00:49:52.477735
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    open_mock = MagicMock(return_value='/dev/root rw rootdelay=90 no_timer_check console=tty0 console=ttyS0,9600n8')
    with patch.object(get_file_content, 'open', open_mock):
        collector = CmdLineFactCollector()

    assert collector.collect() == {'cmdline': {'console': 'ttyS0,9600n8', 'rootdelay': '90', '/dev/root': True, 'rw': True, 'no_timer_check': True, 'console/tty0': True}, 'proc_cmdline': {'console': True, 'rootdelay': '90', '/dev/root': True, 'rw': True, 'no_timer_check': True, 'console/tty0': True}}

# Generated at 2022-06-23 00:49:59.784542
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    cfc = FactCollector('cmdline', [])
    data = cfc.collect()
    assert data['cmdline'] == {u'root': u'/dev/sda1', u'console': u'console=ttyS0,115200n8', u'ro': True}
    assert data['proc_cmdline'] == {u'root': u'/dev/sda1', u'console': u'console=ttyS0,115200n8', u'ro': True}

# Generated at 2022-06-23 00:50:02.144211
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    result = CmdLineFactCollector()
    assert result.name == 'cmdline'

# Generated at 2022-06-23 00:50:14.073364
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    assert CmdLineFactCollector().collect() == {
        'cmdline': {
            'ro': True, 'root': '/gen_initramfs/x86_64/36', 'quiet': True
        },
        'proc_cmdline': {
            'ro': True, 'root': '/gen_initramfs/x86_64/36', 'quiet': True
        }
    }

    # Failing test case
    assert CmdLineFactCollector().collect() != {
        'cmdline': {
            'ro': True, 'root': '/gen_initramfs/x86_64/36', 'quiet': False
        },
        'proc_cmdline': {
            'ro': True, 'root': '/gen_initramfs/x86_64/36', 'quiet': False
        }
    }

# Generated at 2022-06-23 00:50:16.781986
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector is not None
    assert collector.name == 'cmdline'
    assert collector.collect() != None

# Generated at 2022-06-23 00:50:23.450067
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline', c.name
    assert c._fact_ids == set(), c._fact_ids
    assert c._get_proc_cmdline()
    assert isinstance(c._parse_proc_cmdline(c._get_proc_cmdline()), dict), c._parse_proc_cmdline(c._get_proc_cmdline())
    assert c._parse_proc_cmdline_facts(c._get_proc_cmdline())
    print(c.collect())

# Generated at 2022-06-23 00:50:24.622481
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == "cmdline"

# Generated at 2022-06-23 00:50:26.267782
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == "cmdline"

# Generated at 2022-06-23 00:50:28.252997
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    assert 'cmdline' in CmdLineFactCollector().collect()

# Generated at 2022-06-23 00:50:28.894216
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    pass

# Generated at 2022-06-23 00:50:31.517609
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert cmdline.name == 'cmdline'
    assert cmdline._fact_ids == set()


# Generated at 2022-06-23 00:50:40.911416
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    class MockModule:
        params = {}

    class MockFacts:
        ansible_facts = {}

    mock_module = MockModule
    mock_facts = MockFacts

    # creating CmdLineFactCollector object
    cmdline = CmdLineFactCollector()

    # calling the collect method of class CmdLineFactCollector
    cmdline_facts = cmdline.collect(mock_module, mock_facts)
    assert cmdline_facts == {'cmdline': {'ansible_collections': 'test', 'crashkernel': 'auto'},
                             'proc_cmdline': {'ansible_collections': 'test', 'crashkernel': ['auto']}}

# Generated at 2022-06-23 00:50:51.318479
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.utils.shlex import shlex_split
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    collector = CmdLineFactCollector()

    result = collector.collect()
    assert isinstance(result['cmdline'], dict)
    assert isinstance(result['proc_cmdline'], dict)

    result = result['cmdline']
    assert 'BOOT_IMAGE' in result
    assert isinstance(result['BOOT_IMAGE'], AnsibleUnsafeText)
    assert '/vmlinuz-3.10.0-327.36.3.el7.x86_64' in shlex_split(result['BOOT_IMAGE'])
    assert isinstance(result['BOOT_IMAGE'], AnsibleUnsafeText)
    assert 'ro' in result
    assert result

# Generated at 2022-06-23 00:50:53.679609
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline'] == dict(cmdline_facts['proc_cmdline']) and cmdline_facts['cmdline'] != {}

# Generated at 2022-06-23 00:50:58.175273
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert 'cmdline' in cmdline_facts
    assert 'proc_cmdline' in cmdline_facts

# Generated at 2022-06-23 00:51:07.634976
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Setup
    cmdline_facts = CmdLineFactCollector()

    with open('test/unit/ansible_collections/ansible/community/plugins/module_utils/facts/files/proc_cmdline', 'r') as f:
        proc_cmdline = f.read()

    # Mock
    class Mock:
        def get_file_content(file):
            return proc_cmdline

    cmdline_facts._get_proc_cmdline = Mock.get_file_content

    result = cmdline_facts.collect()

    assert result['cmdline']['console'] == 'tty0'
    assert result['cmdline']['nokaslr'] == '1'

# Generated at 2022-06-23 00:51:10.581288
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fc = CmdLineFactCollector()
    assert cmdline_fc.name == 'cmdline'
    assert cmdline_fc._fact_ids == set()


# Generated at 2022-06-23 00:51:19.463033
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()

    # Create a test data with same format of /proc/cmdline
    test_data = 'BOOT_IMAGE=(hd0,gpt1)/vmlinuz-3.10.0-693.21.1.el7.x86_64 root=UUID=c0dd69f7-d922-47ff-a76b-18b6e5279bbb ro crashkernel=auto rd.lvm.lv=centos/swap crashkernel=auto rhgb quiet'
    actual_data = cmdline_collector._parse_proc_cmdline(test_data)

    # Convert the dict to str to compare with the known result
    actual_data_str = '{'

# Generated at 2022-06-23 00:51:21.524967
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == "cmdline"


# Generated at 2022-06-23 00:51:25.084171
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector_obj = CmdLineFactCollector()
    assert cmdline_collector_obj.name == 'cmdline'



# Generated at 2022-06-23 00:51:34.977504
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Test collect.
    # Command line contains multiple arguments.
    mock_data = 'BOOT_IMAGE=/boot/vmlinuz-4.4.0-92-generic root=UUID=e1e41fac-7a5f-4103-a15b-f55cd3507d04 ro console=tty1 console=ttyS0'

    cmdline_facts = {}
    cmdline_facts['cmdline'] = {'BOOT_IMAGE': '/boot/vmlinuz-4.4.0-92-generic', 'root': 'UUID=e1e41fac-7a5f-4103-a15b-f55cd3507d04', 'ro': True, 'console': 'ttyS0'}

# Generated at 2022-06-23 00:51:43.911507
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.utils import get_file_content

    def mock_get_file_content(file_name):
        return to_bytes(file_name)

    get_file_content.side_effect = mock_get_file_content

    cmdline_fact_collector = CmdLineFactCollector()
    result = cmdline_fact_collector.collect()

    assert(result['cmdline']['/proc/cmdline'] is True)
    assert(result['proc_cmdline']['/proc/cmdline'] == '/proc/cmdline')

# Generated at 2022-06-23 00:51:54.597191
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector()
    # Proc cmdline is set to a non-empty string
    cmdline_facts._get_proc_cmdline = lambda: "rd.md.uuid=5dd2289b:a58b1b3e:e6af3ec6:9c6d8f44 rd.md.uuid=50d2d2b2:3526e83b:1f9c03ed:8b4ba4b4 rd.lvm.lv=vg_rhel7/rhel7_root rd.lvm.lv=vg_rhel7/rhel7_swap crashkernel=auto rd.lvm.lv=vg_rhel7/rhel7_home rhgb quiet"
    collected_facts = cmdline_facts.collect()
    # Check some

# Generated at 2022-06-23 00:52:04.564536
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_fact_collector = CmdLineFactCollector()

    # Test the case where no data from /proc/cmdline exists
    with patch("ansible.module_utils.facts.collectors.cmdline.CmdLineFactCollector._get_proc_cmdline") as mocked_method:
        mocked_method.return_value = None
        assert cmdline_fact_collector.collect() == {}

    # Test the case where /proc/cmdline exists but is empty
    with patch("ansible.module_utils.facts.collectors.cmdline.CmdLineFactCollector._get_proc_cmdline") as mocked_method:
        mocked_method.return_value = ""
        assert cmdline_fact_collector.collect() == {}

    # Test the case where /proc/cmdline exists and has data

# Generated at 2022-06-23 00:52:08.817705
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    for fact in cmdline_facts:
        assert type(cmdline_facts[fact]) is dict
        assert len(cmdline_facts[fact]) > 0


# Generated at 2022-06-23 00:52:16.877298
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """Unit test for function _parse_proc_cmdline of class CmdLineFactCollector
    This test class is used in order to test the collect method of CmdLineFactCollector
    """

    CmdLineFactCollector._get_proc_cmdline = lambda x: "ro quiet splash init=/sbin/upstart"

    assert CmdLineFactCollector().collect() == {'cmdline': {'ro': True, 'quiet': True, 'splash': True, 'init': '/sbin/upstart'}, 'proc_cmdline': {'ro': True, 'quiet': True, 'splash': True, 'init': '/sbin/upstart'}}


# Generated at 2022-06-23 00:52:18.905210
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert c._fact_ids == set()

# Generated at 2022-06-23 00:52:27.477902
# Unit test for method collect of class CmdLineFactCollector

# Generated at 2022-06-23 00:52:31.856117
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    o = CmdLineFactCollector()
    assert o.name == 'cmdline'
    assert o._fact_ids == set()
    assert o._fact_ids.__class__.__name__ == 'set'


# Generated at 2022-06-23 00:52:42.375347
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector

    def test_get_file_content(path):
        return '/dev/mapper/vg_test-lv_root / xfs defaults 0 0\n'


# Generated at 2022-06-23 00:52:43.326477
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector is not None

# Generated at 2022-06-23 00:52:45.963047
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()

    assert obj.name == 'cmdline'
    assert len(obj._fact_ids) == 0


# Generated at 2022-06-23 00:52:50.726380
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    inst = CmdLineFactCollector()

    inst._get_proc_cmdline = lambda: 'a=b c=d e'
    inst._parse_proc_cmdline = lambda x: {}
    inst._parse_proc_cmdline_facts = lambda x: {}

    assert inst.collect() == {
        'cmdline': {},
        'proc_cmdline': {},
    }
    

# Generated at 2022-06-23 00:52:54.550584
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    #assert c.priority == 80
    assert c._fact_ids == set()


# Generated at 2022-06-23 00:52:57.081032
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line = CmdLineFactCollector()
    assert cmd_line
    assert isinstance(cmd_line, CmdLineFactCollector)

# Generated at 2022-06-23 00:53:00.785641
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()

    assert cmdline._get_proc_cmdline() is None
    assert cmdline._parse_proc_cmdline('<no value>') == {}
    assert cmdline._parse_proc_cmdline_facts('<no value>') == {}

# Generated at 2022-06-23 00:53:04.962787
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    fact_collector = CmdLineFactCollector()
    result = fact_collector.collect()
    assert isinstance(result, dict)
    if result:
        assert isinstance(result['cmdline'], dict)
        assert 'proc_cmdline' in result
        assert isinstance(result['proc_cmdline'], dict)
    else:
        assert result == {}

# Generated at 2022-06-23 00:53:11.306165
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_line_fact_collector = CmdLineFactCollector()
    file_object = open('/proc/cmdline', 'r')
    proc_cmdline_data = file_object.read()
    file_object.close()
    proc_cmdline_data = proc_cmdline_data.replace('\n', '')
    cmdline_facts = cmd_line_fact_collector.collect()
    assert proc_cmdline_data == cmdline_facts['cmdline']

# Generated at 2022-06-23 00:53:12.168821
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()

# Generated at 2022-06-23 00:53:17.208688
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    fake_module = None
    fake_collected_facts = None
    fact_collector = CmdLineFactCollector()
    cmdline_facts = fact_collector.collect(fake_module, fake_collected_facts)

    assert isinstance(cmdline_facts, dict)
    assert 'cmdline' in cmdline_facts
    assert isinstance(cmdline_facts['cmdline'], dict)
    assert 'proc_cmdline' in cmdline_facts
    assert isinstance(cmdline_facts['proc_cmdline'], dict)

# Generated at 2022-06-23 00:53:25.693129
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert type(cmdline_collector._fact_ids) == set
    assert cmdline_collector._get_proc_cmdline() is not None
    assert cmdline_collector._parse_proc_cmdline(cmdline_collector._get_proc_cmdline()) is not None
    assert cmdline_collector._parse_proc_cmdline_facts(cmdline_collector._get_proc_cmdline()) is not None
    assert cmdline_collector.collect() is not None



# Generated at 2022-06-23 00:53:32.042583
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c == {'cmdline': {'rd.lvm.lv=fedora/root': True,
                          'rd.lvm.lv=fedora/swap': True,
                          'rhgb': True,
                          'quiet': True},
             'proc_cmdline': {'rd.lvm.lv': ['fedora/root', 'fedora/swap'],
                          'rhgb': True,
                          'quiet': True}}



# Generated at 2022-06-23 00:53:39.845273
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector.cmdline import CmdLineFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils._text import to_text
    collector = CmdLineFactCollector()

    # test empty cmdline
    get_file_content_mock = get_file_content
    data = ''
    get_file_content_mock.side_effect = lambda x: data if x == '/proc/cmdline' else None
    result = collector.collect()
    assert result == {}

    # test empty cmdline and facts
    data = ''
    result = collector.collect()
    assert result == {}
    data = 'ansible_fact=test'
    result = collector.collect()
    assert result == {}

# Generated at 2022-06-23 00:53:42.710376
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()

# Generated at 2022-06-23 00:53:43.735423
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    c = CmdLineFactCollector()
    c.collect()

# Generated at 2022-06-23 00:53:51.420829
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    # Create empty mock_ansible_module
    mock_ansible_module = type('AnsibleModule')
    mock_ansible_module.params = {}

    FC = CmdLineFactCollector(mock_ansible_module)
    facts_dict = FC.collect()

    assert type(facts_dict) is dict
    assert 'cmdline' in facts_dict

    cmdline = facts_dict['cmdline']
    assert type(cmdline) is dict
    assert 'root' in cmdline
    assert cmdline['root'] == '/dev/sda1'

# Generated at 2022-06-23 00:53:56.312321
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Create instance of class AnsibleCollector
    # TODO: Inject facts from module
    ansible_collector = CmdLineFactCollector()

    # Invoke the method collect
    facts = ansible_collector.collect()
    assert 'cmdline' in facts
    assert facts['cmdline']['BOOT_IMAGE'] == '/boot/vmlinuz-4.9.0-6-amd64'

# Generated at 2022-06-23 00:54:00.194141
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line = CmdLineFactCollector()
    assert cmd_line.name == "cmdline"

# Generated at 2022-06-23 00:54:02.094513
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'

# Generated at 2022-06-23 00:54:04.619929
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    class_instance = CmdLineFactCollector()

    assert('cmdline' in class_instance.collect().keys())
    assert('proc_cmdline' in class_instance.collect().keys())

# Generated at 2022-06-23 00:54:06.563193
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert not hasattr(CmdLineFactCollector, '_fact_ids')
    assert not hasattr(CmdLineFactCollector, 'name')

# Generated at 2022-06-23 00:54:18.107872
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_fact = CmdLineFactCollector()

    # /proc/cmdline is not empty
    cmdline_fact._get_proc_cmdline = lambda: 'BOOT_IMAGE=/vmlinuz-2.6.32-754.el6.x86_64 root=UUID=9e10c856-b5c7-4fc1-ad27-7fd8447d5c5a ro crashkernel=auto LANG=en_US.UTF-8'

    cmdline_fact_dict = cmdline_fact.collect()


# Generated at 2022-06-23 00:54:18.732374
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
  pass

# Generated at 2022-06-23 00:54:27.681828
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = {}
    file_data = "ro root=/dev/sda1 rd_NO_LUKS rd_NO_LVM rd_NO_MD rd_NO_DM LANG=en_US.UTF-8 SYSFONT=latarcyrheb-sun16 KEYBOARDTYPE=pc KEYTABLE=us rhgb quiet rd.luks=0 rd.lvm=0 rd.md=0 rd.dm=0"

# Generated at 2022-06-23 00:54:35.802919
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_data = """first=1 second second_list=one second_list=two third_list=three=3 fourth_list=four=4 fifth_list=five=5=five"""
    cmdline_facts = {}

    cmdline_facts['cmdline'] = {'first': '1',
                                'second': True,
                                'third_list': 'three=3',
                                'fourth_list': 'four=4',
                                'fifth_list': 'five=5=five',
                                'second_list': ['one', 'two']}


# Generated at 2022-06-23 00:54:42.033503
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    # create an instance of the CmdLineFactCollector class
    cmdline_fact_collector_instance = CmdLineFactCollector()

    # get the collected "cmdline" facts of the CmdLineFactCollector instance
    cmdline_facts = cmdline_fact_collector_instance.collect()

    # validate that the "cmdline" facts are non empty
    assert cmdline_facts['cmdline']
    assert cmdline_facts['proc_cmdline']

# Generated at 2022-06-23 00:54:50.017563
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts import UnitTestModule

    # Test input data
    test_data_in = 'root=/dev/sda1 rd.lvm.lv=fedora/root rd.lvm.lv=fedora/swap rhgb quiet'
    cmdline_collector = CmdLineFactCollector()

    # mocking the read file method
    def mock_get_file_content(file_name):
        return test_data_in

    # mocking the utils get_file_content method
    cmdline_collector.get_file_content = mock_get_file_content

    # Test output data

# Generated at 2022-06-23 00:54:59.425442
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """ Unit test for class CmdLineFactCollector """

    cmdline_dict = {'splash': True,
                    'console': 'ttyS0',
                    'console_to_ring': 'no',
                    'numvcpus': '1',
                    'root': '/dev/sda1',
                    'SEBOOT': '0x1',
                    'mem': '3426M',
                    'initrd': '/boot/initrd'}

# Generated at 2022-06-23 00:55:04.716141
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = CmdLineFactCollector()
    assert cmdline_facts.name == 'cmdline'
    assert 'cmdline' not in cmdline_facts._fact_ids
    assert 'proc_cmdline' not in cmdline_facts._fact_ids

# Generated at 2022-06-23 00:55:07.195057
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.collect() == {'proc_cmdline' : {}, 'cmdline': {}}

# Generated at 2022-06-23 00:55:11.749269
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # check return attributes
    cmdline_coll = CmdLineFactCollector()
    assert cmdline_coll.name == 'cmdline'
    assert not cmdline_coll._fact_ids


# Generated at 2022-06-23 00:55:20.461374
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.windows.cmdline import CmdLineFactCollector

    # Set answer for subprocess.Popen.communicate
    setattr(subprocess, 'Popen', MockPopen)
    stdoutdata = ''
    stderrdata = 'Error'
    setattr(subprocess.Popen, 'communicate', Mock(return_value=(stdoutdata, stderrdata)))

    # Set answer for get_file_content
    setattr(get_file_content, 'cache', {})
    get_file_content.cache['/proc/cmdline'] = 'fake-data'

    cmdline_fct_coll = CmdLineFactCollector()

# Generated at 2022-06-23 00:55:31.820263
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    proc_cmdline_sample_data = 'BOOT_IMAGE=/vmlinuz-4.4.0-104-generic root=/dev/mapper/ubuntu--vg-root ro quiet splash'
    with open('/proc/cmdline', 'w') as cmd_line_file:
        cmd_line_file.write(proc_cmdline_sample_data)

    cmd_line_collector = CmdLineFactCollector()
    cmd_line_facts = cmd_line_collector.collect()
    
    assert(cmd_line_facts['cmdline'] == {u'BOOT_IMAGE': u'/vmlinuz-4.4.0-104-generic', u'root': u'/dev/mapper/ubuntu--vg-root', u'ro': True, u'quiet': True, u'splash': True})

# Generated at 2022-06-23 00:55:33.828123
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'
    assert hasattr(collector, 'collect')

# Generated at 2022-06-23 00:55:34.629177
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()

# Generated at 2022-06-23 00:55:43.444845
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """
    Test that the collect method returns:
      - the expected facts when /proc/cmdline contains items
      - an empty dict when /proc/cmdline is empty
    (This test is a bit limited because it does not take into account unexpected exceptions)
    """
    # Get a CmdLineFactCollector:
    collector = CmdLineFactCollector()

    # Make the collect method return a dummy /proc/cmdline when called:

    # Return an empty /proc/cmdline
    def _get_proc_cmdline_return_empty():
        return ''
    collector._get_proc_cmdline = _get_proc_cmdline_return_empty
    # Test we get an empty dict when /proc/cmdline is empty:
    assert collector.collect() == {}

    # Return a dummy /proc/cmdline

# Generated at 2022-06-23 00:55:45.266570
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'
    assert collector._fact_ids == set()

# Generated at 2022-06-23 00:55:48.058566
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert isinstance(cmdline, BaseFactCollector)
    assert cmdline.name == 'cmdline'

# Generated at 2022-06-23 00:55:52.544734
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fc = CmdLineFactCollector()
    assert isinstance(cmdline_fc, CmdLineFactCollector)
    assert cmdline_fc.name == 'cmdline'
    assert cmdline_fc._fact_ids == set()


# Generated at 2022-06-23 00:56:03.305472
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import os
    import json

    # Create a temporary directory to store the test data
    tmp_dir = os.path.realpath(os.path.join(os.path.dirname(__file__), '../..', '__tmp'))
    if not os.path.isdir(tmp_dir):
        os.mkdir(tmp_dir)

    fd_path = os.path.join(tmp_dir, 'fact_file')

    # Create a test file for /proc/cmdline
    with open(fd_path, 'w') as cmdline_file:
        cmdline_file.write('root=/dev/sda1 ro rhgb quiet net.ifnames=0 biosdevname=0')

    collected_facts = None
    module = None

    # Create an instance of CmdLineFactCollector
    cmdline_

# Generated at 2022-06-23 00:56:09.040090
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert isinstance(cmdline_facts, dict)
    assert 'cmdline' in cmdline_facts
    assert 'proc_cmdline' in cmdline_facts
    assert 'ansible_cmdline' not in cmdline_facts
    assert isinstance(cmdline_facts['cmdline'], dict)
    assert isinstance(cmdline_facts['proc_cmdline'], dict)

# Generated at 2022-06-23 00:56:18.526253
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = {}
    data = "test_file"

    with open("/proc/cmdline", "w") as fh:
        fh.write("BOOT_IMAGE=/vmlinuz-4.18.0-80.11.2.el8_0.x86_64 root=UUID=6acf2fd8-97c5-4699-a7c5-23b8e7bf689b ro crashkernel=auto console=tty0 console=ttyS0,115200n8 net.ifnames=0 biosdevname=0 ipv6.disable=1 ")


# Generated at 2022-06-23 00:56:22.909941
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()

    cmd_line_facts = collector.collect()

    assert cmd_line_facts['cmdline'] == {'BOOT_IMAGE': '/vmlinuz-4.1.10-17.31-default', 'not_working': True}
    assert cmd_line_facts['proc_cmdline'] == {'BOOT_IMAGE': '/vmlinuz-4.1.10-17.31-default', 'not_working': True}

# Generated at 2022-06-23 00:56:23.780334
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    result = cmdline_collector._get_proc_cmdline()
    print(result)

# Generated at 2022-06-23 00:56:29.460540
# Unit test for method collect of class CmdLineFactCollector

# Generated at 2022-06-23 00:56:40.300473
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    content = '''BOOT_IMAGE=/boot/vmlinuz-2.6.32-573.el6.x86_64 root=UUID=f7b0e2a9-d7af-4090-a0c5-d1c3485f846b ro crashkernel=auto rhgb quiet LANG=en_US.UTF-8 LANGUAGE=en_US:en cgconfig.service crash.service cgred.service smartd.service'''
    m_get_file_content = 'ansible.module_utils.facts.utils.get_file_content'
    m_cmdline_fact_collector = 'ansible.module_utils.facts.system.cmdline.CmdLineFactCollector'

# Generated at 2022-06-23 00:56:44.228310
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c_facts = CmdLineFactCollector()
    assert c_facts.name == 'cmdline'
    assert isinstance(c_facts._fact_ids, set)


# Generated at 2022-06-23 00:56:53.913585
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_fact_collector = CmdLineFactCollector()
    proc_cmdline = "console=ttyAMA0,115200 elevator=deadline root=/dev/mmcblk0p2 rootwait rootfstype=ext4 rw"

    with open("/proc/cmdline", "w") as f:
        f.write(proc_cmdline)
        f.close()

    cmdline_facts = cmdline_fact_collector.collect()

    # cmdline
    assert "cmdline" in cmdline_facts
    assert isinstance(cmdline_facts['cmdline'], dict)
    assert "console" in cmdline_facts['cmdline']
    assert "elevator" in cmdline_facts['cmdline']
    assert "root" in cmdline_facts['cmdline']

# Generated at 2022-06-23 00:57:03.314177
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import ModuleStub

    collector = Collector()
    c = CmdLineFactCollector(collector=collector)
    module_stub = ModuleStub(collector=collector)

    cmdline_facts = c.collect(module=module_stub)

    assert cmdline_facts is not None
    assert 'cmdline' in cmdline_facts
    assert 'proc_cmdline' in cmdline_facts
    assert isinstance(cmdline_facts['cmdline'], dict)
    assert isinstance(cmdline_facts['proc_cmdline'], dict)

# Generated at 2022-06-23 00:57:11.017352
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_object = CmdLineFactCollector()
    cmdline_object._get_proc_cmdline = lambda: "A=1 B=2 C=3 D"
    cmdline_object._parse_proc_cmdline = lambda x: {'cmdline': x}
    cmdline_object._parse_proc_cmdline_facts = lambda x: {'proc_cmdline': x}
    result = cmdline_object.collect()
    assert result['cmdline'] == 'A=1 B=2 C=3 D'
    assert result['proc_cmdline'] == 'A=1 B=2 C=3 D'

# Generated at 2022-06-23 00:57:19.092217
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    mock_module = type('module', (object,), {'exit_json': lambda self, ansible_facts: True})()

    # simple test
    cmdline1 = 'root=/dev/mapper/centos-root ro crashkernel=auto  rhgb quiet LANG=en_US.UTF-8'

# Generated at 2022-06-23 00:57:20.015932
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()

# Generated at 2022-06-23 00:57:21.256538
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    obj = CmdLineFactCollector()
    assert isinstance(obj.collect(), dict)

# Generated at 2022-06-23 00:57:30.941040
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from .test_utils import AnsibleExitJson
    module = AnsibleExitJson(dict(proc_cmdline='console=ttyS1,115200 console=tty0 root=/dev/mmcblk0p2'))
    CmdLineFactCollector(module).collect(module=module)
    assert module.exit_args['stdout'] == dict(
        cmdline=dict(console='ttyS1,115200', root='/dev/mmcblk0p2'),
        proc_cmdline=dict(console=['ttyS1,115200', 'tty0'], root='/dev/mmcblk0p2')
    )
    assert module.exit_args['stdout_lines'] == []

# Generated at 2022-06-23 00:57:40.000538
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts import default_collectors
    collector = default_collectors['cmdline']
    output = collector.collect()
    assert isinstance(output, dict)
    assert 'cmdline' in output
    assert isinstance(output['cmdline'], dict)
    assert 'proc_cmdline' in output
    assert isinstance(output['proc_cmdline'], dict)

    # Test cmdline

# Generated at 2022-06-23 00:57:51.021649
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Arrange
    cmdline_facts = {}
    get_file_content = lambda x: 'rd.md.uuid=0fbd6739a6d926d0 rd.md.uuid=038feab2e1f466d0 rd.lvm.vg=rhel rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet'
    shlex_split = lambda x, y: ['rd.md.uuid=0fbd6739a6d926d0', 'rd.md.uuid=038feab2e1f466d0', 'rd.lvm.vg=rhel', 'rd.lvm.lv=rhel/root', 'rd.lvm.lv=rhel/swap', 'rhgb', 'quiet']

# Generated at 2022-06-23 00:57:53.497280
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert c._fact_ids == set()

# Generated at 2022-06-23 00:57:58.514533
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    f = CmdLineFactCollector()
    try:
        f._parse_proc_cmdline(None)
        assert False
    except AttributeError:
        assert True

    try:
        f._parse_proc_cmdline_facts(None)
        assert False
    except AttributeError:
        assert True