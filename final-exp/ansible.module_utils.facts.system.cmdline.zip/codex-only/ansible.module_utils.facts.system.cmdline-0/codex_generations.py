

# Generated at 2022-06-23 00:48:01.292800
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """Test the return of collect()"""
    cmdline_fact_collector = CmdLineFactCollector()

    cmdline = cmdline_fact_collector._get_proc_cmdline()
    cmdline_parsed = cmdline_fact_collector._parse_proc_cmdline(cmdline)
    proc_cmdline_parsed = cmdline_fact_collector._parse_proc_cmdline_facts(cmdline)

    result = cmdline_fact_collector.collect()
    assert result['cmdline'] == cmdline_parsed
    assert result['proc_cmdline'] == proc_cmdline_parsed

# Generated at 2022-06-23 00:48:03.724743
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector_obj = CmdLineFactCollector()
    assert cmdline_fact_collector_obj is not None


# Generated at 2022-06-23 00:48:06.104992
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()

# Generated at 2022-06-23 00:48:09.813785
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdlinefactcollector = CmdLineFactCollector()
    assert cmdlinefactcollector.name == "cmdline"
    assert cmdlinefactcollector.collect() == {'cmdline': {}, 'proc_cmdline': {}}

# Generated at 2022-06-23 00:48:18.722248
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Create class instance for testing
    clc = CmdLineFactCollector()

    proc_cmdline = '''BOOT_IMAGE=/vmlinuz-4.15.0-45-generic root=/dev/mapper/ubuntu--vg-root ro quiet splash vt.handoff=1'''

    # Create mock functions
    def mock__get_proc_cmdline(self):
        return proc_cmdline

    # Apply mock functions
    clc._get_proc_cmdline = mock__get_proc_cmdline

    # Call method collect
    result = clc.collect()

    # Check result
    assert isinstance(result, dict)
    assert 'cmdline' in result
    assert isinstance(result['cmdline'], dict)
    assert 'proc_cmdline' in result

# Generated at 2022-06-23 00:48:28.762455
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import pytest

    test_cases = [
        ['''test=test1''', {'test': 'test1'}],
        ['''test=test1 test2=test3''', {'test': 'test1', 'test2': 'test3'}],
        ['''test1=test2 test1=test3''', {'test1': ['test2', 'test3']}],
        [''' test1=test2 test1=test3 ''', {'test1': ['test2', 'test3']}],
        [''' test1= test2 test1= test3''', {'test1': ['test2', 'test3']}],
    ]

    for cmdline, res in test_cases:
        cmdline_facts = {}
        data = cmdline


# Generated at 2022-06-23 00:48:31.042837
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()

# Generated at 2022-06-23 00:48:32.492042
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # read proc cmdline and generate the facts
    CmdLineFactCollector().collect()

# Generated at 2022-06-23 00:48:35.171457
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    fact_collector = CmdLineFactCollector()
    assert fact_collector.name == 'cmdline'
    assert fact_collector._fact_ids == set()


# Generated at 2022-06-23 00:48:41.764497
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # get fake data
    data = get_file_content("./ansible/module_utils/facts/cmdline.data")

    # init collector
    collector = CmdLineFactCollector()

    # get result
    cmdline_facts = collector.collect(data)

    # check result
    assert cmdline_facts['cmdline']['root'] == '/dev/sda1'
    assert cmdline_facts['cmdline']['BOOT_IMAGE'] == '/boot/vmlinuz-4.6.0-1-cloud-amd64'
    assert cmdline_facts['cmdline']['ro'] == True
    assert cmdline_facts['cmdline']['console'] == 'tty1'

# Generated at 2022-06-23 00:48:51.139041
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    '''Unit test method collect'''

    ##############################################################################
    # Initial test data
    ##############################################################################

    # Content of command line
    test_cmdline_content = 'rd.md=0 rd.lvm=0 initrd=/initramfs-4.18.0-193.1.1.el8_2.x86_64.img root=UUID=16b2f3c3-1f2a-4b85-ac9e-c9a95a4c4b52 ro console=ttyS1 console=tty0 crashkernel=auto console=ttyS1,115200n8 net.ifnames=0 biosdevname=0 rhgb quiet'
    # Expected content of the dictionary returned by _parse_proc_cmdline_facts

# Generated at 2022-06-23 00:48:56.493711
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    """
    This method checks the CmdLine FactCollector.
    """

    cmd_line = CmdLineFactCollector()
    assert cmd_line

# Generated at 2022-06-23 00:49:00.190939
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == "cmdline"
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-23 00:49:03.862806
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector is not None


# Generated at 2022-06-23 00:49:07.481609
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c1 = CmdLineFactCollector()

    assert c1.name == 'cmdline'

    c2 = CmdLineFactCollector()

    assert c2.name == 'cmdline'

    assert c1 == c2

# Generated at 2022-06-23 00:49:18.440304
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_dict = {
        'cmdline': {
            'a': True,
            'b': '2',
            'c': '3',
            'd': '4'
        },
        'proc_cmdline': {
            'a': True,
            'b': '2',
            'c': ['3', '3'],
            'd': '4'
        }
    }

    def _get_proc_cmdline():
        return "a b=2 c=3 c=3 d=4"

    x = CmdLineFactCollector()
    #x._get_proc_cmdline = _get_proc_cmdline
    data = x.collect()
    assert data['cmdline'] == cmdline_dict['cmdline']

# Generated at 2022-06-23 00:49:29.092450
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    result = CmdLineFactCollector()
    assert isinstance(result, CmdLineFactCollector)
    assert result.name == 'cmdline'
    assert result.__class__._fact_ids == set()
    assert result._get_proc_cmdline() == 'BOOT_IMAGE=/vmlinuz-3.10.0-229.14.1.el7.x86_64 root=/dev/mapper/rhel_swarm-root ro crashkernel=auto rd.lvm.lv=rhel_swarm/root rd.lvm.lv=rhel_swarm/swap rhgb quiet LANG=en_US.UTF-8 audit_backlog_limit=8192'

# Generated at 2022-06-23 00:49:31.513751
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdlinefact_collector = CmdLineFactCollector()
    assert cmdlinefact_collector.name == 'cmdline'
    assert cmdlinefact_collector._fact_ids == set()


# Generated at 2022-06-23 00:49:38.418462
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline = CmdLineFactCollector()
    cmdline._get_proc_cmdline = lambda: 'BOOT_IMAGE=/vmlinuz-3.10.0-229.el7.x86_64 root=UUID=b5f23b29-7a53-4fae-b76d-459cfcae7f89 ro crashkernel=auto rhgb quiet LANG=en_US.UTF-8'
    result = cmdline.collect()
    assert(result['cmdline']['root'] == 'UUID=b5f23b29-7a53-4fae-b76d-459cfcae7f89')
    assert(result['cmdline']['LANG'] == 'en_US.UTF-8')
    assert(result['cmdline']['rhgb'] is True)

# Generated at 2022-06-23 00:49:42.067796
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c is not None

# Unit tests for _parse_proc_cmdline

# Generated at 2022-06-23 00:49:47.627252
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import CollectedFact
    path = 'ansible.module_utils.facts.collectors.cmdline.CmdLineFactCollector'
    cmdline = CmdLineFactCollector()
    collected_facts = {'cmdline': CollectedFact(path=path)}
    result = cmdline.collect(collected_facts=collected_facts)
    assert result == {'cmdline': {}, 'proc_cmdline': {}}

# Generated at 2022-06-23 00:49:54.283576
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    proc_file = open('/proc/cmdline', 'w')
    proc_file.write(u'root=/dev/sda1 ro console=ttyS0,9600n8')
    proc_file.close()
    cmdline_collector.collect()
    assert cmdline_collector._fact_ids == set(['cmdline', 'proc_cmdline'])

# Generated at 2022-06-23 00:49:55.980756
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()

    assert cmdline_collector is not None

# Generated at 2022-06-23 00:50:02.044417
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    fact_collector = CmdLineFactCollector()
    data = fact_collector._get_proc_cmdline()
    cmdline_facts = fact_collector._parse_proc_cmdline_facts(data)

    assert isinstance(cmdline_facts, dict)
    assert len(cmdline_facts.keys()) > 0
    assert cmdline_facts.has_key('elevator')
    assert cmdline_facts.has_key('resume')

# Generated at 2022-06-23 00:50:14.073326
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    testobj = CmdLineFactCollector()
    assert testobj._get_proc_cmdline() == 'ro root=/dev/mapper/vg_test-lv_root rd_NO_LUKS rd_LVM_LV=vg_test/lv_root LANG=en_US.UTF-8 rd_LVM_LV=vg_test/lv_swap rd_NO_MD SYSFONT=latarcyrheb-sun16 crashkernel=128M rhgb quiet rd_NO_DM vconsole.font=latarcyrheb-sun16 vconsole.keymap=us'

# Generated at 2022-06-23 00:50:21.981291
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """Method collect of class CmdLineFactCollector
    """
    ############################################################################
    # Dummy unit test for method collect of class CmdLineFactCollector

    class DummyFactCollector(CmdLineFactCollector):
        def _get_proc_cmdline(self):
            return "key1=val1 key2 key3=val3"

    fact_collector = DummyFactCollector()

    # We are using assertEqual instead of assertDictEqual because
    # ansible.module_utils.facts.collector.BaseFactCollector._result is
    # always returned as a Python 2.6+ style ordered dictionary and
    # we want to make sure values are the same regardless of the
    # order of the items.


# Generated at 2022-06-23 00:50:23.289780
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
   cmdLineTest = CmdLineFactCollector()

# Generated at 2022-06-23 00:50:25.111820
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_fact_collector = CmdLineFactorCollector()
    assert cmdline_fact_collector.name == "cmdline"

# Generated at 2022-06-23 00:50:28.442072
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()



# Generated at 2022-06-23 00:50:29.095089
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    pass

# Generated at 2022-06-23 00:50:34.829935
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    class MockModule(object):
        def fail_json(self, *args):
            self.exit_args = args
            self.exit_called = True

    module = MockModule()
    test_obj = CmdLineFactCollector()
    test_obj.collect(module=module)
    assert 'cmdline' in test_obj.fact_list

# Generated at 2022-06-23 00:50:42.928524
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    _collector = CmdLineFactCollector()

    collected_facts = {'cmdline': {'ro': True, 'quiet': True, 'LANG': 'en_US.UTF-8', 'root': '/dev/mapper/rhel-root', 'console': 'tty0 console=ttyS0,19200n8'}}

    # Happy path
    cmdline_facts = _collector._get_proc_cmdline()
    assert cmdline_facts == 'ro quiet LANG=en_US.UTF-8 root=/dev/mapper/rhel-root console=tty0 console=ttyS0,19200n8'

# Generated at 2022-06-23 00:50:47.443610
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'

    # set() is not hashable
    assert cmdline_collector._fact_ids == set()
    assert cmdline_collector.priority == 95
    assert cmdline_collector.collected_facts is None


# Generated at 2022-06-23 00:50:48.226558
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert type(collector) == CmdLineFactCollector


# Generated at 2022-06-23 00:50:53.833339
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector.cmdline import CmdLineFactCollector
    from ansible.module_utils.facts.utils import MockModule

    module = MockModule(ansible_facts={})
    cmdline_fact = CmdLineFactCollector(module=module, collected_facts={})
    cmdline = cmdline_fact.collect()

    assert 'cmdline' in cmdline
    assert isinstance(cmdline['cmdline'], dict)
    assert 'proc_cmdline' in cmdline
    assert isinstance(cmdline['proc_cmdline'], dict)

# Generated at 2022-06-23 00:50:56.810034
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()
    assert CmdLineFactCollector.collect() == {}

# Generated at 2022-06-23 00:51:00.484781
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    a = CmdLineFactCollector()
    assert a.name == 'cmdline'
    assert a._fact_ids == set()


# Generated at 2022-06-23 00:51:01.767025
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'

# Generated at 2022-06-23 00:51:04.166633
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == "cmdline"

# Generated at 2022-06-23 00:51:09.177162
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    module = None
    collected_facts = {}
    cmdline_facts = CmdLineFactCollector().collect(module, collected_facts)

    assert isinstance(cmdline_facts['cmdline'], dict)
    assert isinstance(cmdline_facts['proc_cmdline'], dict)
    assert 'ro root' in cmdline_facts['cmdline'].values()
    assert 'ro' in cmdline_facts['proc_cmdline'].keys()

# Generated at 2022-06-23 00:51:11.332488
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    fc = CmdLineFactCollector()
    assert fc.name == 'cmdline', 'Name of CmdLineFactCollector should be cmdline'

# Generated at 2022-06-23 00:51:14.751945
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdLineFactCollector = CmdLineFactCollector(None)
    output = cmdLineFactCollector.collect()
    print(output)

if __name__ == '__main__':
    test_CmdLineFactCollector_collect()

# Generated at 2022-06-23 00:51:17.257086
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.collect() == {}

# Generated at 2022-06-23 00:51:17.764202
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    pass

# Generated at 2022-06-23 00:51:19.832443
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector is not None

# Generated at 2022-06-23 00:51:31.565472
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    c = CmdLineFactCollector()

    assert c.collect({}) == {}

    assert c.collect({'ansible_facts': {'proc_cmdline': 'foo=bar one=1'}}) == {'cmdline': {'foo': 'bar', 'one': '1'},
                                                                               'proc_cmdline': {'foo': 'bar', 'one': '1'}}

    assert c.collect({'ansible_facts': {'proc_cmdline': 'foo=bar one=1 one=2 one=3'}}) == {'cmdline': {'foo': 'bar', 'one': '3'},
                                                                                             'proc_cmdline': {'foo': 'bar', 'one': ['1', '2', '3']}}


# Generated at 2022-06-23 00:51:32.990368
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert isinstance(CmdLineFactCollector(), CmdLineFactCollector)

# Generated at 2022-06-23 00:51:34.819324
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert c._fact_ids == set()


# Generated at 2022-06-23 00:51:40.640350
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    a = CmdLineFactCollector()
    assert a.name == 'cmdline'
    assert a._fact_ids == set()
    assert a._get_proc_cmdline()
    assert a._parse_proc_cmdline(a._get_proc_cmdline())
    assert a._parse_proc_cmdline_facts(a._get_proc_cmdline())
    assert a.collect()

# Generated at 2022-06-23 00:51:51.472167
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    n = CmdLineFactCollector()
    assert n.name == 'cmdline'
    assert n._fact_ids == set()
    assert n.collect() == {}
    assert n.collect(collected_facts={}) == {}
    assert n.collect(collected_facts=None) == {}
    assert n.collect(collected_facts=None, module=None) == {}
    assert n.collect(collected_facts=None, module=None, cmdline_data='root=UUID=123-456-789 ro quiet') == {'cmdline': {'root': 'UUID=123-456-789', 'ro': True, 'quiet': True}}

# Generated at 2022-06-23 00:51:52.916369
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert isinstance(CmdLineFactCollector(), BaseFactCollector)

# Generated at 2022-06-23 00:52:03.422662
# Unit test for method collect of class CmdLineFactCollector

# Generated at 2022-06-23 00:52:14.710969
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    module = None
    collected_facts = None
    cmdline_facts = {}

    collector = CmdLineFactCollector()

    cmdline_facts['cmdline'] = collector._parse_proc_cmdline('BOOT_IMAGE=/vmlinuz-3.10.0-327.el7.x86_64 root=/dev/mapper/rhel-root ro crashkernel=auto rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet LANG=en_US.UTF-8')

# Generated at 2022-06-23 00:52:17.170611
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    localCollector = CmdLineFactCollector
    assert localCollector.name == 'cmdline'
    assert localCollector._fact_ids == set()


# Generated at 2022-06-23 00:52:26.038008
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    sys_modules_save = dict(sys.modules)

    # Setup mock module objects
    class MockModule(object):
        def __init__(self, *args, **kwargs):
            self.params = {}

    class MockConnection(object):
        def __init__(self, *args, **kwargs):
            pass

        def get_file_content(self, path):
            test_data = 'rd.lvm.lv=rhel/swap rd.lvm.lv=rhel/root  KEYBOARDTYPE=pc KEYTABLE=us rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap'
            return test_data

    mock_module = MockModule()


# Generated at 2022-06-23 00:52:29.546866
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'
    assert not obj._fact_ids


# Generated at 2022-06-23 00:52:30.215172
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    pass

# Generated at 2022-06-23 00:52:31.309127
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector()


# Generated at 2022-06-23 00:52:33.302674
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert not c._fact_ids

# Generated at 2022-06-23 00:52:37.030063
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    """Unit test method for testing constructor of class CmdLineFactCollector.
    """
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector.name == 'cmdline'

# Generated at 2022-06-23 00:52:40.951614
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert isinstance(CmdLineFactCollector(), CmdLineFactCollector)
    assert isinstance(CmdLineFactCollector().name, str)
    assert isinstance(CmdLineFactCollector().collect, object)

# Generated at 2022-06-23 00:52:51.095227
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # mock the get_file_content function
    module = 'ansible.module_utils.facts.collectors.cmdline.get_file_content'
    CmdLineFactCollector.get_file_content = lambda self: 'ansible_become=true ansible_become_method=sudo'
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline']['ansible_become'] == 'true'
    assert cmdline_facts['cmdline']['ansible_become_method'] == 'sudo'
    assert 'proc_cmdline' in cmdline_facts
    assert cmdline_facts['proc_cmdline']['ansible_become'] == 'true'

# Generated at 2022-06-23 00:52:58.426561
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import re

    cmdline_fact_collector = CmdLineFactCollector()
    cmdline_facts = cmdline_fact_collector.collect()

    assert cmdline_facts
    assert cmdline_facts.get('cmdline')
    assert cmdline_facts.get('proc_cmdline')

    assert len(cmdline_facts['cmdline']) == len(cmdline_facts['proc_cmdline'])

    for key in cmdline_facts['cmdline']:
        assert cmdline_facts['proc_cmdline'].get(key) == cmdline_facts['cmdline'].get(key)

    assert re.match(r'\w+', cmdline_facts['cmdline']['root'])

# Generated at 2022-06-23 00:53:00.455785
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd = CmdLineFactCollector()
    assert cmd.name == 'cmdline'
    assert cmd._fact_ids == set()

# Generated at 2022-06-23 00:53:09.559993
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = {}
    data = "BOOT_IMAGE=/boot/vmlinuz-3.10.0-327.el7.x86_64 root=UUID=0a0adb4e-d9ee-4a1e-8d7f-c9613a551a2a ro crashkernel=auto rhgb quiet LANG=en_US.UTF-8"


# Generated at 2022-06-23 00:53:16.454889
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    def test_func(data):
        return data

    # Dummy data for testing
    data = [
        {
            'ansible_processor_cores': 4,
            'ansible_processor_count': 2,
            'ansible_processor_threads_per_core': 2
        },
        {
            'ansible_processor_cores': [1, 2],
            'ansible_processor_count': 1,
            'ansible_processor_threads_per_core': [1, 2]
        }
    ]

    # Test successful creation of CmdLineFactCollector instance
    assert CmdLineFactCollector(test_func, data[0]) is not None
    assert CmdLineFactCollector(test_func, data[1]) is not None

    # Test unsuccessful creation of CmdLineFactCollector instance

# Generated at 2022-06-23 00:53:27.381467
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    test_collector = CmdLineFactCollector()

    # Test when file content is not empty
    test_collector._get_proc_cmdline = lambda: 'BOOT_IMAGE=/vmlinuz-4.18.0-193.el8.x86_64 root=/dev/mapper/cl-root ro crashkernel=auto resume=/dev/mapper/cl-swap rd.lvm.lv=cl/root rd.lvm.lv=cl/swap rhgb quiet LANG=en_US.UTF-8'

    res_cmdl_facts = test_collector.collect()
    assert res_cmdl_facts['proc_cmdline']['BOOT_IMAGE'] == '/vmlinuz-4.18.0-193.el8.x86_64'

# Generated at 2022-06-23 00:53:35.359619
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts import Collector


# Generated at 2022-06-23 00:53:39.174220
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_facts = cmdline_collector.collect()

    assert cmdline_facts['cmdline'] is not None
    assert cmdline_facts['proc_cmdline'] is not None

# Generated at 2022-06-23 00:53:44.532546
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert isinstance(c._fact_ids, set)


# Generated at 2022-06-23 00:53:47.174595
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact = CmdLineFactCollector()
    assert cmdline_fact.name == 'cmdline'
    assert cmdline_fact._fact_ids == set()


# Generated at 2022-06-23 00:53:49.413023
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()

# Generated at 2022-06-23 00:53:51.420692
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdLineFactCollector = CmdLineFactCollector()

    assert cmdLineFactCollector is not None

# Generated at 2022-06-23 00:54:00.415057
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.cmdline import CmdLineFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils._text import to_bytes
    o = CmdLineFactCollector()
    # Data to be returned by the mocked method
    data = 'stuff=things otherthings=otherotherthings'
    # Mocked get_file_content method
    o._get_file_content = lambda x: data
    assert o.collect() == {'cmdline': {'stuff': 'things', 'otherthings': 'otherotherthings'}, 'proc_cmdline': {'stuff': 'things', 'otherthings': ['otherotherthings']}}
    data = 'stuff=things otherthings=otherotherthings otherthings=other1things'
    o._get

# Generated at 2022-06-23 00:54:07.352425
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    fact_collector = CmdLineFactCollector()
    assert fact_collector.collect() == {"cmdline": {"foo": True, "bar": "baz", "quux": True},
                                        "proc_cmdline": {"foo": True, "bar": "baz", "quux": True}}

if __name__ == '__main__':
    # Unit test
    fc = CmdLineFactCollector()
    fc.collect()
    fc._parse_proc_cmdline("foo bar")

    # Print out all the collected facts for debugging
    for fact in fc.collect():
        print(fact)

# vim: set ts=4 sw=4 et :

# Generated at 2022-06-23 00:54:12.881430
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert isinstance(cmdline_facts, dict)
    assert set(cmdline_facts.keys()) == set(('cmdline','proc_cmdline'))
    assert isinstance(cmdline_facts['cmdline'], dict)
    assert isinstance(cmdline_facts['proc_cmdline'], dict)

# Generated at 2022-06-23 00:54:21.693334
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # This module_utils function is mocked in unit test
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts.collector import BaseFactCollector

    mocker = Mocker()
    fake_ansible_module = mocker.mock()
    fake_ansible_module.params = {}
    fake_ansible_module.fail_json = mocker.Mock()
    fake_ansible_module.get_bin_path = mocker.Mock(return_value='/path/to/file')
    mocker.replay()


# Generated at 2022-06-23 00:54:32.689442
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import sys
    sys.path.append(".") # noqa: E402
    from ansible.module_utils.facts.utils import get_file_content

    def _get_proc_cmdline():
        return get_file_content('unit/modules/utils/facts/fixture/proc_cmdline_2')

    cmdline = CmdLineFactCollector()
    cmdline.collect(None)
    cmdline.get_facts()
    cmdline.get_fact('cmdline')
    cmdline.get_fact('proc_cmdline')
    cmdline._get_proc_cmdline = _get_proc_cmdline
    cmdline.collect(None)
    cmdline.get_facts()
    cmdline.get_fact('cmdline')
    cmdline.get_fact('proc_cmdline')

# Unit test

# Generated at 2022-06-23 00:54:39.914199
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    content = CmdLineFactCollector().collect()
    assert content == {'cmdline': {'quiet': True, 'selinux=0': True, 'ro': True, 'video=1152x864': True,
                                   'root=LABEL=/': True},
                       'proc_cmdline': {'quiet': True, 'selinux=0': True, 'ro': True, 'video=1152x864': True,
                                        'root=LABEL=/': True}}

# Generated at 2022-06-23 00:54:41.086108
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    collector.collect()

# Generated at 2022-06-23 00:54:47.371084
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import FactCollector

    my_collector = FactCollector()

    assert isinstance(my_collector, FactCollector)

    assert isinstance(my_collector.list_collectors(), list)

    assert isinstance(my_collector.fact_classes(), list)

    collector = CmdLineFactCollector(module=None)

    tmp_collection = collector.collect(module=None, collected_facts=None)

    assert isinstance(tmp_collection, dict)

# Generated at 2022-06-23 00:54:48.978514
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    x = CmdLineFactCollector()


# Generated at 2022-06-23 00:54:53.018990
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    assert collector.collect() == {'cmdline': {}, 'proc_cmdline': {}}

# Generated at 2022-06-23 00:55:04.013171
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Testing the functionality of method collect of class CmdLineFactCollector
    # Positive test case
    import sys
    import os
    import mock

    class DummyException(Exception):
        pass

    class DummyClass(object):
        def __init__(self, *args, **kwargs):
            self.f_contents = None

        def read(self):
            return self.f_contents

    def mock_fopen(filename, mode='rb', *args, **kwargs):
        dummy_obj = DummyClass()
        dummy_obj.f_contents = "root=LABEL=cloudimg-rootfs rw console=hvc0 rootfstype=ext4"
        return dummy_obj

    module = mock.Mock()
    cmdline_fact_collector = CmdLineFactCollector()
   

# Generated at 2022-06-23 00:55:06.498658
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'
    assert collector._fact_ids == set()


# Generated at 2022-06-23 00:55:10.272431
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Test whether the constructor of the class CmdLineFactCollector is implemented correctly
    CmdLineFactCollector()

# Generated at 2022-06-23 00:55:19.385673
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_data = """
    BOOT_IMAGE=/boot/vmlinuz-4.15.0-30-generic root=UUID=2eb86eec-bf48-4a4a-a1d9-d40cf2d2b890 ro quiet splash vt.handoff=1
    """
    cmdline_file = 'test_file'

    fixture = CmdLineFactCollector(module=None)

    mock_open = fixture.mock_open(cmdline_data, mock_open_name=cmdline_file)

    with mock_open as m:
        cmdline_facts = fixture.collect()

    assert isinstance(cmdline_facts, dict)
    assert isinstance(cmdline_facts['cmdline'], dict)

# Generated at 2022-06-23 00:55:31.140431
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts import FactCache

    fact_collector = FactsCollector()

    fact_collector.collect(module=None, collected_facts=None)
    fact_cache = FactCache().fact_cache

    # Check if file /proc/cmdline exists
    data = CmdLineFactCollector()._get_proc_cmdline()
    assert data

    # Check if the method _parse_proc_cmdline parses the cmdline
    # and returns a correct parsed cmdline
    cmdline_dict = CmdLineFactCollector()._parse_proc_cmdline(data)
    assert cmdline_dict

    # Check if the method _parse_proc_cmdline parses the cmdline
    # and returns a correct parsed cmdline
   

# Generated at 2022-06-23 00:55:38.702289
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    fact_collector = CmdLineFactCollector()

    data = 'BOOT_IMAGE=/boot/vmlinuz-2.6.18-308.11.1.el5.centos.plus ' \
           'root=UUID=5d5e5c6b-a6a5-40e7-8dcf-09396ac99b91 ' \
           'ro crashkernel=auto rhgb quiet '


# Generated at 2022-06-23 00:55:50.934685
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.cmdline import CmdLineFactCollector
    from ansible.module_utils._text import to_text
    import ansible.module_utils.basic
    import json

    class FakeModule(ansible.module_utils.basic.AnsibleModule):
        def __init__(self):
            argument_spec = dict()
            super(FakeModule, self).__init__(argument_spec=argument_spec)

    module = FakeModule()
    module._ansible_initialized = True
    module.run_command = lambda *arg: ['mem=1G,mem_auto=false', None, 0]
    cmdline_collector = CmdLineFactCollector(module=module)

    cmdline_facts = cmd

# Generated at 2022-06-23 00:56:02.093348
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    proc_cmdline_data = 'ROOTDEV=/dev/mapper/rootvol GRUB_CMDLINE_LINUX_DEFAULT="verbose nokaslr rd.driver.blacklist=nouveau rd.driver.blacklist=amdgpu nomodeset" GRUB_CMDLINE_LINUX=" crashkernel=auto rhgb quiet"'
    with open('/proc/cmdline', 'w') as f:
        f.write(proc_cmdline_data)


# Generated at 2022-06-23 00:56:11.613416
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    module = None
    collected_facts = None

    # Create a instance of CmdLineFactCollector
    cmdline_fact_collector = CmdLineFactCollector()

    # Define the 'get_file_content' function
    def get_file_content(path):
        return 'rd.luks.uuid=luks-e6b93d29-8c11-4fdd-a149-30887a1a9829'

    # Define our patched module
    import ansible.module_utils.facts.utils
    ansible.module_utils.facts.utils.get_file_content = get_file_content

    # Execute collect method
    collected_facts = cmdline_fact_collector.collect(module, collected_facts)

    # Now we can test for the value of our facts
    assert collected_

# Generated at 2022-06-23 00:56:14.958232
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Module and facts should be none for the constructor to work
    assert CmdLineFactCollector.__init__(None, None) is None

# Generated at 2022-06-23 00:56:17.868965
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdLineFactCollector_object = CmdLineFactCollector()
    assert cmdLineFactCollector_object.name == 'cmdline'
    assert cmdLineFactCollector_object.collect() != {}

# Generated at 2022-06-23 00:56:27.368099
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    cmdline_fact_collector = CmdLineFactCollector()

    assert cmdline_fact_collector._get_proc_cmdline() is not None

    output = cmdline_fact_collector._parse_proc_cmdline("ansible_test=test1 ansible_test=test2 ansible_test2=test3")
    assert output['ansible_test'] == 'test2'
    assert output['ansible_test2'] == 'test3'

    output = cmdline_fact_collector._parse_proc_cmdline_facts("ansible_test=test1 ansible_test=test2 ansible_test2=test3")
    assert output['ansible_test'] == ['test1', 'test2']
    assert output['ansible_test2'] == 'test3'


# Generated at 2022-06-23 00:56:30.920271
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts_collector = CmdLineFactCollector()

    assert 'cmdline' in cmdline_facts_collector.collect()
    assert 'proc_cmdline' in cmdline_facts_collector.collect()

# Generated at 2022-06-23 00:56:33.056473
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    from pytest import raises

    with raises(TypeError):
        CmdLineFactCollector(1)

# Generated at 2022-06-23 00:56:41.608155
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    facts = {}
    Path('/proc/cmdline').touch()
    Path('/proc/cmdline').write_text(u'BOOT_IMAGE=test_image')
    cmd_line_fact_collector = CmdLineFactCollector()
    result = cmd_line_fact_collector.collect(collected_facts=facts)
    assert type(result) is dict
    assert 'cmdline' in result
    assert 'proc_cmdline' in result
    assert type(result['cmdline']) is dict
    assert 'BOOT_IMAGE' in result['cmdline']
    assert 'BOOT_IMAGE' in result['proc_cmdline']
    assert result['proc_cmdline']['BOOT_IMAGE'] == 'test_image'

# Generated at 2022-06-23 00:56:44.172366
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    myCollector = CmdLineFactCollector()
    assert 'cmdline' in myCollector.collect()

# Generated at 2022-06-23 00:56:46.240871
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert cmdline.name == 'cmdline'

# Generated at 2022-06-23 00:56:53.394061
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == "cmdline"
    assert obj._fact_ids == set()
    assert obj._get_proc_cmdline() == b'BOOT_IMAGE=(hd0,gpt1)/vmlinuz-4.4.0-87-generic root=/dev/mapper/ubuntu-root ro quiet splash vt.handoff=7'

# Generated at 2022-06-23 00:56:56.522856
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector.cacheable == False

# Generated at 2022-06-23 00:57:01.121245
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == "cmdline"
    assert cmdline_fact_collector._fact_ids == set()
    assert cmdline_fact_collector.__dict__['_fact_id_cache'] == {}

# Generated at 2022-06-23 00:57:12.583021
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    class TestFactsCollectorModule:
        def __init__(self):
            self.params = {}

    class TestFactsCollected:
        def __init__(self):
            self.data = {
                'cmdline': {'a': True, 'b': True, 'c': '', 'd': '=xyz', 'e': 'abc'},
                'proc_cmdline': {'a': True, 'b': True, 'c': '', 'd': '=xyz', 'e': 'abc'}
            }

    def get_file_content(path):
        return 'a b= c d=xyz e=abc'


# Generated at 2022-06-23 00:57:14.670658
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    a = CmdLineFactCollector()
    assert a.name == 'cmdline'

# Generated at 2022-06-23 00:57:24.861666
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Check if data contains valid information required to generate
    # the desired output
    data = 'root=/dev/mapper/vg_rhel7-lv_root rd_NO_LUKS  KEYBOARDTYPE=pc KEYTABLE=us rd_LVM_LV=vg_rhel7/lv_root rd_LVM_LV=vg_rhel7/lv_swap crashkernel=auto  rhgb quiet LANG=en_US.UTF-8 console=tty0 console=ttyS0,115200n8 systemd.unit=multi-user.target'

    cmdline_facts = CmdLineFactCollector().collect(collected_facts=dict())

# Generated at 2022-06-23 00:57:28.377171
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    assert isinstance(cmdline_collector, CmdLineFactCollector)

    cmdline_collector.collect()

# Generated at 2022-06-23 00:57:33.878292
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    try:
        cmdline_fact_collector = CmdLineFactCollector()
        cmdline_facts = cmdline_fact_collector.collect()
        # if /proc/cmdline exist and is not empty, cmdline_facts should be a dictionary
        assert isinstance(cmdline_facts, dict)

    except Exception as e:
        print('Failed: ' + repr(e))
        assert False

    return True

# Generated at 2022-06-23 00:57:35.669281
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'
    assert obj._fact_ids == set()


# Generated at 2022-06-23 00:57:36.824083
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'

# Generated at 2022-06-23 00:57:44.859179
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_test_data = "BOOT_IMAGE=/kernel-3.10.0-327.22.2.el7.x86_64/vmlinuz-3.10.0-327.22.2.el7.x86_64 root=/dev/mapper/rhel-root ro rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap crashkernel=auto  rhgb quiet LANG=en_US.UTF-8 ip=10.10.10.10::10.10.10.1:255.255.255.0:jenkins.example.com:eth0:none"

    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts is None

    CmdLineFactCollector._get_proc_cmdline = lambda : cmdline_

# Generated at 2022-06-23 00:57:48.303115
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert isinstance(obj, BaseFactCollector)
    assert obj.name == "cmdline"
    assert obj._fact_ids == set()


# Generated at 2022-06-23 00:57:51.505368
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    x = CmdLineFactCollector()
    assert isinstance(x.name, str)
    assert isinstance(x._fact_ids, set)


# Generated at 2022-06-23 00:57:56.511312
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    facts = collector.collect(collected_facts={})
    data = collector._get_proc_cmdline()
    cmdline_facts = collector._parse_proc_cmdline_facts(data)
    assert cmdline_facts == facts['proc_cmdline']