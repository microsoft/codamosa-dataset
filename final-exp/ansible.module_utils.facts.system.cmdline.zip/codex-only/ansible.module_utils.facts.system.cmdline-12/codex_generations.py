

# Generated at 2022-06-23 00:48:04.031212
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    data = ("BOOT_IMAGE=/boot/vmlinuz-3.10.0-957.5.1.el7.x86_64 root=UUID=4e4c8e52-b7f9-4e2d-9b8a-f65fd6a8b85e ro crashkernel=auto resume=UUID=b8feb2a2-bcc9-4e9d-8cc5-0e92b3d7558d rhgb quiet LANG=en_US.UTF-8 MODULE_NAMES=pci_stub,vfio,vfio_iommu_type1,vfio_virqfd MODULE_PARAMS=vfio_iommu_type1.allow_unsafe_interrupts=1 MODULES=modules")

# Generated at 2022-06-23 00:48:12.492825
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import sys
    import StringIO
    class Module(object):
        pass
    module = Module()
    module.params = {}
    collector = CmdLineFactCollector()
    if sys.platform == "linux":
        capturedOutput = StringIO.StringIO()
        sys.stdout = capturedOutput
        collector.collect(module=None, collected_facts=None)
        sys.stdout = sys.__stdout__
        assert 'linux' in capturedOutput.getvalue()
        assert 'cmdline' in capturedOutput.getvalue()
        assert 'proc_cmdline' in capturedOutput.getvalue()

# Generated at 2022-06-23 00:48:21.662730
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Given
    data = 'root=UUID=c728d9ef-9198-4c8a-a6a2-01d1f94a1a8b ro nomodeset elevator=noop rd.systemd.show_status=auto rd.udev.log_priority=3 vconsole.font=latarcyrheb-sun16 vconsole.keymap=us crashkernel=auto resume=UUID=a87cd543-3c82-4444-b795-b0d2b2f465c5'
    fact_collector = CmdLineFactCollector()
    fact_collector._get_proc_cmdline = lambda: data

    # When
    collected_facts = fact_collector.collect()

    # Then

# Generated at 2022-06-23 00:48:30.745106
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()

    # Test case where get_file_content returns None (i.e. /proc/cmdline is empty)
    cmdline_collector._get_file_content = lambda path: None

    # Asser that cmdline facts are empty since /proc/cmdline is empty
    assert cmdline_collector.collect()['cmdline'] == {}
    assert cmdline_collector.collect()['proc_cmdline'] == {}

    # Test case where get_file_content returns content of /proc/cmdline
    cmdline_collector._get_file_content = lambda path: 'foo=bar foo'

    # Assert that cmdline facts are not empty and have the correct values

# Generated at 2022-06-23 00:48:34.608909
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    c = CmdLineFactCollector()
    d = c.collect()
    assert 'proc_cmdline' in d
    assert 'cmdline' in d
    assert 'root' in d['proc_cmdline']
    assert 'root' in d['cmdline']

# Generated at 2022-06-23 00:48:38.804443
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    """
    This function will be used for unit test of
    constructor of class CmdLineFactCollector
    """
    cmdline_facts = CmdLineFactCollector()
    assert cmdline_facts.name == "cmdline"
    assert cmdline_facts._fact_ids == set()


# Generated at 2022-06-23 00:48:43.867446
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    c = CmdLineFactCollector()
    facts = c.collect()
    assert 'cmdline' in facts
    assert facts['cmdline']['rd.lvm.lv=centos/root'] == True
    assert 'proc_cmdline' in facts
    assert facts['proc_cmdline']['ro'] == True
    assert facts['proc_cmdline']['rhelv7'] == True

# Generated at 2022-06-23 00:48:45.783992
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert c._fact_ids == set()


# Generated at 2022-06-23 00:48:54.192691
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # For testing run this module as a standalone script.
    import sys
    import json
    from ansible.module_utils.facts import ansible_collector

    # Create a dummy module object
    class module():
        def __init__(self):
            self.params = {}

    mymodule = module()
    mymodule.params['gather_subset'] = ['all']

    # Create a dummy ansible_collector object
    class ansible_facts():
        def __init__(self):
            self.collectors = []

    ansible_collector = ansible_collector()

    # Create a dummy args object
    class Args():
        def __init__(self):
            self.module_args = []

    args = Args()
    args.module_args = mymodule.params

    ansible_collector

# Generated at 2022-06-23 00:48:56.799831
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    cmdline_facts = collector._get_proc_cmdline()
    assert cmdline_facts is not None


# Generated at 2022-06-23 00:49:06.359664
# Unit test for method collect of class CmdLineFactCollector

# Generated at 2022-06-23 00:49:08.705934
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    x = CmdLineFactCollector()
    assert x.name == 'cmdline'
    assert not x._fact_ids


# Generated at 2022-06-23 00:49:11.320583
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    fact = CmdLineFactCollector()
    assert fact == {'name': 'cmdline', '_fact_ids': set()}

# Generated at 2022-06-23 00:49:15.509538
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    my_collector = CmdLineFactCollector()
    print(my_collector.name)
    assert my_collector.name == 'cmdline'
    assert len(my_collector._fact_ids) == 0


# Generated at 2022-06-23 00:49:16.524842
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert len(CmdLineFactCollector.collect()) != 0

# Generated at 2022-06-23 00:49:19.692928
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdlineFact = CmdLineFactCollector()
    assert cmdlineFact.name == 'cmdline'
    assert cmdlineFact._fact_ids == set()

# Generated at 2022-06-23 00:49:30.110772
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # We need to mock the _get_proc_cmdline method.
    # We also need to import it locally because we need to mock it before
    # importing CmdLineFactCollector
    from ansible.module_utils.facts.collectors.cmdline import CmdLineFactCollector

    def mocked__get_proc_cmdline():
        return "BOOT_IMAGE=(hd0,gpt1)/vmlinuz-3.10.0-229.el7.x86_64 root=UUID=295283b6-9663-4742-b1c3-fa5baeee7f24 ro crashkernel=auto rd.lvm.lv=vg_centos7/lv_root rd.lvm.lv=vg_centos7/lv_swap rhgb quiet LANG=en_US.UTF-8"



# Generated at 2022-06-23 00:49:32.005642
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert cmdline.name == 'cmdline'


# Generated at 2022-06-23 00:49:40.700577
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """
    Test CmdLineFactCollector.collect method
    """
    cmdline_facts = {'cmdline': {u'BOOT_IMAGE': u'/vmlinuz-3.10.0-327.28.2.el7.x86_64',
                                 u'ro': True, u'rhgb': True, u'quiet': True},
                     'proc_cmdline': {u'BOOT_IMAGE': u'/vmlinuz-3.10.0-327.28.2.el7.x86_64',
                                      u'ro': True, u'rhgb': True, u'quiet': True}}

    cl = CmdLineFactCollector()

# Generated at 2022-06-23 00:49:49.609991
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    from ansible.module_utils.facts.utils import FactsCollector
    from ansible.module_utils.facts.utils import EXECUTION_CACHE_FOLDER

    answer = {}
    output = 'foo=bar bar=baz'
    open(EXECUTION_CACHE_FOLDER + '/cmdline', 'w').write(output)
    mc = FactsCollector()
    mc.collector['cmdline'] = CmdLineFactCollector(mc)
    result = mc.collector['cmdline'].collect()
    assert isinstance(result, dict)
    assert result == answer, 'incorrect output: {} != {}'.format(result, answer)

# Generated at 2022-06-23 00:49:51.686758
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'

# Generated at 2022-06-23 00:49:54.336046
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = CmdLineFactCollector()

    expected = 'cmdline'
    actual = cmdline_facts.name
    assert expected == actual


# Generated at 2022-06-23 00:50:04.171381
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    from ansible.module_utils.facts import ansible_collector

    ansible_collector.add_collector(CmdLineFactCollector())

    # We need to find the actual module_utils dir to test the collection properly
    # We will use basic module to find the actual dir
    module_utils_dir = basic._ANSIBLE_MODULE_UTILS_PATH

    # Create a fake module_utils dir with a fake cmdline
    fake_module_utils_dir = '{0}/fake_module_utils'.format(module_utils_dir)
    fake_cmdline_path = '{0}/fake_module_utils/fake_cmdline'.format(module_utils_dir)

# Generated at 2022-06-23 00:50:09.210457
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert c._fact_ids == set()
    assert all([x in c.collect().keys() for x in ('cmdline', 'proc_cmdline')])
    assert set(c._fact_ids) == set()

# Generated at 2022-06-23 00:50:13.584295
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = CmdLineFactCollector()
    assert cmdline_facts.name == 'cmdline'
    assert cmdline_facts._fact_ids == set()
    assert cmdline_facts.collect() == {}



# Generated at 2022-06-23 00:50:16.740561
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdlineFactCollector = CmdLineFactCollector()
    assert cmdlineFactCollector.name == 'cmdline'
    assert cmdlineFactCollector._fact_ids == set()


# Generated at 2022-06-23 00:50:26.404661
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """ Unit test for method collect of class CmdLineFactCollector
    """

    # test input1

# Generated at 2022-06-23 00:50:35.726953
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    fact_collector = CmdLineFactCollector()
    assert fact_collector.name == 'cmdline'
    assert fact_collector.collect() == {}
    assert fact_collector._fact_ids == set()
 
#def test_CmdLineFactCollector_get_proc_cmdline():
#    fact_collector = CmdLineFactCollector()
#    assert fact_collector.name == 'cmdline'
#    assert fact_collector._get_proc_cmdline() == ''
#    assert fact_collector._fact_ids == set()

#def test_CmdLineFactCollector_parse_proc_cmdline():
#    fact_collector = CmdLineFactCollector()
#    assert fact_collector.name == 'cmdline'
#    data = 'root=UUID=39b45

# Generated at 2022-06-23 00:50:38.744686
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    col = CmdLineFactCollector()
    assert col.name == "cmdline", "the name has to be cmdline"
    assert col._fact_ids == set(), "the _fact_ids has to be an empty set"

# Generated at 2022-06-23 00:50:40.560217
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    my_cmdline_collector_obj = CmdLineFactCollector()
    assert CmdLineFactCollector != None

# Generated at 2022-06-23 00:50:42.710432
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert len(CmdLineFactCollector._fact_ids) == 0


# Generated at 2022-06-23 00:50:48.257799
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    class TestModule:
        pass

    test_module = TestModule()
    test_module.params = {}
    test_module.params['gather_subset'] = ['all']

    test_module.params['gather_timeout'] = 10
    test_module.params['filter'] = '*'

    test_module.exit_json = exit_json

    ccf = CmdLineFactCollector(test_module)

    ccf.collect()


# Generated at 2022-06-23 00:50:50.119465
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    x = CmdLineFactCollector()
    assert x.name == "cmdline"
    assert x._fact_ids == set()


# Generated at 2022-06-23 00:50:57.061983
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Prepare
    from ansible.module_utils.facts.utils import get_file_content
    old_get_file_content = get_file_content
    def new_get_file_content(path):
        if path == '/proc/cmdline':
            return 'BOOT_IMAGE=/boot/vmlinuz-3.17.1-1-ARCH\n'
        return old_get_file_content(path)
    get_file_content = new_get_file_content

    # Execute
    cmdline_fact_collector = CmdLineFactCollector()
    collected_facts = cmdline_fact_collector.collect()

    # Assert

# Generated at 2022-06-23 00:51:02.740442
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    cmdline_facts = collector.collect()

    assert 'cmdline' in cmdline_facts
    assert 'proc_cmdline' in cmdline_facts
    assert 'root' in cmdline_facts['cmdline']
    assert 'root' in cmdline_facts['proc_cmdline']



# Generated at 2022-06-23 00:51:04.951919
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert type(cmdline_fact_collector) == CmdLineFactCollector


# Generated at 2022-06-23 00:51:08.243528
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert 'cmdline' in CmdLineFactCollector.name
    assert 'cmdline' not in CmdLineFactCollector._fact_ids


# Generated at 2022-06-23 00:51:09.475778
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()

# Generated at 2022-06-23 00:51:17.002727
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    class CmdLineFactCollectorTest(CmdLineFactCollector):
        def _get_proc_cmdline(self):
            return 'root=/dev/sda2 ro rhgb quiet'

    collector = CmdLineFactCollectorTest()

    expected_result = {'cmdline': {'root': '/dev/sda2', 'ro': True,
                       'rhgb': True, 'quiet': True},
                       'proc_cmdline': {'root': '/dev/sda2', 'ro': True,
                       'rhgb': True, 'quiet': True}}

    result = collector.collect()
    assert result == expected_result

# Generated at 2022-06-23 00:51:23.116302
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    c = CmdLineFactCollector()

    facts_dict = c.collect()

    assert facts_dict, "CmdLineFactCollector.collect returned an empty dict"
    assert 'cmdline' in facts_dict, "cmdline not found in CmdLineFactCollector.collect facts"
    assert 'proc_cmdline' in facts_dict, "proc_cmdline not found in CmdLineFactCollector.collect facts"

# Generated at 2022-06-23 00:51:33.781295
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Dummy class to be used in this test
    class DummyModule(object):
        def __init__(self, params):
            self.params = params

    # Create a dummy module with parameters
    dummy_module = DummyModule({})

    # Create a dummy data to be returned to test the fact values
    dummy_data = b"""\
root=UUID=a0f6a5d8-3180-4b7d-bae6-c813a09c6e9e ro  persistent net.ifnames=0 biosdevname=0 rhgb quiet sda_udma=33
"""

    # Create dummy object for CmdLineFactCollector
    cmd_line_fact_collector = CmdLineFactCollector()

    # Create a dummy object of class FakeFile to be used in this test

# Generated at 2022-06-23 00:51:38.784218
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_content

    # Do not run the test if /proc/cmdline is unavailable
    if get_file_content('/proc/cmdline') is None:
        return

    collector = Collector(None, None, CmdLineFactCollector)
    cmdline_facts = collector.collect()
    assert 'cmdline' in cmdline_facts
    assert 'proc_cmdline' in cmdline_facts

# Generated at 2022-06-23 00:51:45.511569
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    data = 'root=UUID=b7a3b3d3-9f2f-4912-b8c5-9e9f1ae62f2a ro crashkernel=auto'
    cmdline_collector = CmdLineFactCollector()
    result = cmdline_collector._parse_proc_cmdline_facts(data)
    assert result.get('root') == 'UUID=b7a3b3d3-9f2f-4912-b8c5-9e9f1ae62f2a'

# Generated at 2022-06-23 00:51:46.959421
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    instance = CmdLineFactCollector()
    assert instance.name == 'cmdline'

# Generated at 2022-06-23 00:51:57.773521
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils._text import to_bytes

    # Return a object on a module
    class fake_module():
        exception = None
        params = {}
        tmpdir = "/tmp/ansible_facts"

    # Return a fake anwser from method get_file_content of module_utils.facts.utils
    def fake_get_file_content(filename):
        if filename == "/proc/cmdline":
            return to_bytes('root=UUID=93345cad-aae0-4034-b7c1-f243c67257f2 ro crashkernel=auto rhgb quiet')
        elif filename == "/proc/cmdline2":
            return False
        else:
            return filename

    # Make a fake module
   

# Generated at 2022-06-23 00:52:05.458867
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector._get_proc_cmdline()
    assert CmdLineFactCollector._parse_proc_cmdline("one=two three=four")
    assert CmdLineFactCollector._parse_proc_cmdline_facts("one=two three=four")
    assert CmdLineFactCollector._parse_proc_cmdline_facts("one=two three=four three=five")

# Generated at 2022-06-23 00:52:16.337473
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    '''
    Test the collect method of CmdLineFactCollector
    '''

    # Mock out the methods used by collect
    def mock_get_proc_cmdline(self):
        # Return a fake proc cmdline
        fake_proc_cmdline = "BOOT_IMAGE=/vmlinuz-3.10.0-327.el7.x86_64 root=/dev/mapper/centos-root ro rd.lvm.lv=centos/root rd.lvm.lv=centos/swap rhgb quiet LANG=en_US.UTF-8"
        return fake_proc_cmdline

    # Mock out the method
    from ansible.module_utils.facts.collectors.system import CmdLineFactCollector
    CmdLineFactCollector._get_proc_cmdline = mock_get_proc

# Generated at 2022-06-23 00:52:21.745411
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert 'cmdline' in cmdline_facts
    assert 'proc_cmdline' in cmdline_facts
    assert 'ro' in cmdline_facts['cmdline']
    assert 'ro' in cmdline_facts['proc_cmdline']
    assert cmdline_facts['proc_cmdline']['ro'] == True
    assert cmdline_facts['cmdline']['ro'] == True

# Generated at 2022-06-23 00:52:23.946345
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    cmdline_facts = collector.collect()

    assert cmdline_facts == {'cmdline': {}, 'proc_cmdline': {}}

# Generated at 2022-06-23 00:52:28.103767
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector = get_CmdLineFactCollector_class()
    assert(CmdLineFactCollector.name == 'cmdline')
    assert(CmdLineFactCollector._fact_ids == set())
    assert(CmdLineFactCollector.__module__.endswith('ansible.module_utils.facts.cmdline'))


# Generated at 2022-06-23 00:52:31.036553
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    x = CmdLineFactCollector()
    assert x.name == "cmdline"
    assert x._fact_ids == set()


# Generated at 2022-06-23 00:52:32.622894
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'

# Generated at 2022-06-23 00:52:43.021755
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # get_file_content() returns a string containing the content of file
    # /proc/cmdline, which is a string of null-terminated strings, separated
    # by spaces, that contains the command line that the linux kernel was given
    # when it was booted.
    def get_file_content(filename):
        if filename == '/proc/cmdline':
            return 'root=UUID=1234567890 ro'

    # Create a CmdLineFactCollector object
    cmdline_collector = CmdLineFactCollector()

    # Get the collect method for CmdLineFactCollector object
    collect_method = cmdline_collector.collect

    # Get the method for getting the contents of the file /proc/cmdline
    cmdline_collector._get_proc_cmdline = get_file_content

    # Call the collect method

# Generated at 2022-06-23 00:52:48.356444
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    f = CmdLineFactCollector()
    f._get_proc_cmdline = lambda: 'fake_cmdline'
    f._parse_proc_cmdline = lambda data: data
    f._parse_proc_cmdline_facts = lambda data: data

    assert f.collect() == {'cmdline': 'fake_cmdline', 'proc_cmdline': 'fake_cmdline'}


# Generated at 2022-06-23 00:52:53.062459
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():

    # Test with valid values for ansible_collections
    obj = CmdLineFactCollector(ansible_collections='collection1')
    assert len(obj._fact_ids) == 0


# Generated at 2022-06-23 00:53:03.505177
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline = CmdLineFactCollector()

# Generated at 2022-06-23 00:53:05.411130
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collect_cmdline_facts = CmdLineFactCollector()
    assert isinstance(collect_cmdline_facts, CmdLineFactCollector)

# Generated at 2022-06-23 00:53:06.836574
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'

# Generated at 2022-06-23 00:53:08.995829
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector().name == 'cmdline'
    assert CmdLineFactCollector()._fact_ids == set()

# Generated at 2022-06-23 00:53:16.095073
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import get_collector_facts

    cmdline_data = 'BOOT_IMAGE=/vmlinuz-3.10.0-327.el7.x86_64 \
                    root=/dev/mapper/rhel-root ro rd.lvm.lv=rhel/root \
                    rd.lvm.lv=rhel/swap console=tty0 console=ttyS0,9600 \
                    console=tty0'

    with open('/proc/cmdline', 'w') as openfileobject:
        openfileobject.write(cmdline_data)
    collector = FactsCollector()
    cmdline_fact_collector = CmdLineFactCollector()
    collector.add_collector

# Generated at 2022-06-23 00:53:19.209767
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert isinstance(collector, CmdLineFactCollector)


# Generated at 2022-06-23 00:53:23.730631
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts.get('cmdline')
    assert cmdline_facts.get('proc_cmdline')


if __name__ == "__main__":
    test_CmdLineFactCollector_collect()

# Generated at 2022-06-23 00:53:30.068787
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import CmdLineFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Unit test: CmdLineFactCollector.collect()
    # Interface: call method collect of class CmdLineFactCollector and evaluate result.

    # Nothing to test.
    # Method CmdLineFactCollector.collect() calls get_file_content which can not be tested without
    # patching a real file.

# Generated at 2022-06-23 00:53:31.478846
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    assert isinstance(collector.collect(), dict)


# Generated at 2022-06-23 00:53:33.183362
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert isinstance(CmdLineFactCollector._fact_ids, set)



# Generated at 2022-06-23 00:53:35.724414
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    _fact_ids = set()
    collector = CmdLineFactCollector(_fact_ids)
    assert collector.name == 'cmdline'
    assert collector._fact_ids == set()


# Generated at 2022-06-23 00:53:44.564571
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    data = 'BOOT_IMAGE=/vmlinuz-2.6.32-279.el6.x86_64 ro root=UUID=89d1f5a5-5f5c-4f1f-8a3f-d3e49b9d0b9d rd_NO_LUKS rd_NO_'\
           'LVM LANG=en_US.UTF-8 rd_NO_MD SYSFONT=latarcyrheb-sun16 crashkernel=auto KEYBOARDTYPE=pc KEYTABLE=us rd_NO_DM se'\
           'linux=0 audit=1 biosdevname=0 rd_NO_DM rhgb quiet'

    collector = CmdLineFactCollector()
    collector._get_proc_cmdline = lambda: data
    facts = collector.collect()

# Generated at 2022-06-23 00:53:54.874900
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    a = """
    selinux=1
    key1=1
    key1=2
    key2=3
    key3
    """

    cmdline_facts = {}
    cmdline_facts['cmdline'] = {'selinux': '1', 'key1': '2', 'key2': '3', 'key3': True}
    cmdline_facts['proc_cmdline'] = {'selinux': '1', 'key1': ['1', '2'], 'key2': '3', 'key3': True}

    p = CmdLineFactCollector()
    assert p._parse_proc_cmdline(a) == cmdline_facts['cmdline']
    assert p._parse_proc_cmdline_facts(a) == cmdline_facts['proc_cmdline']
    assert cmdline_facts == p

# Generated at 2022-06-23 00:53:57.186794
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'
    assert isinstance(obj._fact_ids, set)
    assert not obj._fact_ids

# Generated at 2022-06-23 00:54:00.344809
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'

# Generated at 2022-06-23 00:54:01.120363
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()

# Generated at 2022-06-23 00:54:08.447045
# Unit test for method collect of class CmdLineFactCollector

# Generated at 2022-06-23 00:54:19.491594
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    data = """
BOOT_IMAGE=/vmlinuz-3.16.0-4-amd64 root=/dev/mapper/debian-root ro acpi_enforce_resources=lax net.ifnames=0
"""
    fc = CmdLineFactCollector()
    # set self._get_proc_cmdline method of class CmdLineFactCollector to lambda
    # to return mock data as a temporary patch
    fc._get_proc_cmdline = lambda: data

# Generated at 2022-06-23 00:54:25.511751
# Unit test for method collect of class CmdLineFactCollector

# Generated at 2022-06-23 00:54:28.030287
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = CmdLineFactCollector()
    assert cmdline_facts.name == 'cmdline'

# Generated at 2022-06-23 00:54:30.963245
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert isinstance(cmdline_facts['cmdline'], dict)
    assert isinstance(cmdline_facts['proc_cmdline'], dict)

# Generated at 2022-06-23 00:54:33.156752
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cfg = CmdLineFactCollector()
    assert cfg.name == 'cmdline'

# Generated at 2022-06-23 00:54:36.464773
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert sorted(c._fact_ids) == ['cmdline', 'proc_cmdline']

# Generated at 2022-06-23 00:54:43.749208
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    data = collector._get_proc_cmdline()

    # test the _parse_proc_cmdline method
    collector._parse_proc_cmdline(data)
    output = collector._parse_proc_cmdline(data)
    assert isinstance(output, dict)

    # test the _parse_proc_cmdline_facts method
    collector._parse_proc_cmdline_facts(data)
    output = collector._parse_proc_cmdline_facts(data)
    assert isinstance(output, dict)

# Generated at 2022-06-23 00:54:45.408623
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    fact_collector = CmdLineFactCollector()
    assert fact_collector.name == 'cmdline'
    assert fact_collector._fact_ids == set()


# Generated at 2022-06-23 00:54:57.452686
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    '''Unit test for method collect of class CmdLineFactCollector'''
    
    cmdline_from_file = 'BOOT_IMAGE=/vmlinuz-4.4.0-104-generic.efi.signed root=UUID=616d9f51-b9e8-4c87-8741-93d3d3a33c8a ro quiet splash vt.handoff=7'
    cmdline_facts_from_file = {'BOOT_IMAGE': '/vmlinuz-4.4.0-104-generic.efi.signed', 'root': 'UUID=616d9f51-b9e8-4c87-8741-93d3d3a33c8a', 'ro': True, 'quiet': True, 'splash': True, 'vt.handoff': '7'}

# Generated at 2022-06-23 00:54:58.416823
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert issubclass(CmdLineFactCollector, BaseFactCollector)

# Generated at 2022-06-23 00:55:00.219231
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    result = CmdLineFactCollector()
    assert result.__class__.__name__ == "CmdLineFactCollector"

# Generated at 2022-06-23 00:55:09.597618
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Test init
    test = CmdLineFactCollector()

    # Test get_proc_cmdline
    test._get_proc_cmdline = lambda: 'BOOT_IMAGE=/boot/vmlinuz-5.3.3-200.fc31.x86_64 root=UUID=ca7f6858-d1c7-4c23-b4a4-4f9173757b13 ro rootflags=subvol=@ quiet' # noqa

# Generated at 2022-06-23 00:55:11.844746
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'

# Generated at 2022-06-23 00:55:12.986202
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    CmdLineFactCollector.collect()

# Generated at 2022-06-23 00:55:18.867463
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdLineFactCollector = CmdLineFactCollector()
    cmdLineFactCollector._get_proc_cmdline = lambda x: 'foo=bar baz=quux'
    cmdLineFactCollector._parse_proc_cmdline = lambda x: x
    cmdLineFactCollector._parse_proc_cmdline_facts = lambda x: x
    collected_facts = cmdLineFactCollector.collect()
    assert collected_facts == {'cmdline': 'foo=bar baz=quux', 'proc_cmdline': 'foo=bar baz=quux'}

# Generated at 2022-06-23 00:55:22.765867
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    fact_collector = CmdLineFactCollector()
    assert fact_collector.name == 'cmdline'
    assert fact_collector._fact_ids == set()



# Generated at 2022-06-23 00:55:24.970003
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector is not None


# Generated at 2022-06-23 00:55:27.642403
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_obj = CmdLineFactCollector()
    assert cmdline_obj.name == 'cmdline'
    assert cmdline_obj._fact_ids == set()

# Generated at 2022-06-23 00:55:29.809082
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'

# Generated at 2022-06-23 00:55:36.934966
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.cmdline import CmdLineFactCollector

    c = CmdLineFactCollector()
    assert isinstance(c, BaseFactCollector)
    assert isinstance(c, CmdLineFactCollector)
    assert c.name == 'cmdline'
    facts = c.collect()
    assert 'cmdline' in facts.keys()
    assert isinstance(facts['cmdline'], dict)
    assert 'proc_cmdline' in facts.keys()
    assert isinstance(facts['proc_cmdline'], dict)

# Generated at 2022-06-23 00:55:39.711048
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdlineCollector = CmdLineFactCollector()

    assert cmdlineCollector._fact_ids == set()
    assert cmdlineCollector.name == 'cmdline'

# Generated at 2022-06-23 00:55:51.928982
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    from ansible.module_utils.facts import ansible_facts

    ansible_facts_data = ansible_facts(None, {})

    # generate an original set of facts
    CmdLineFactCollector().populate(ansible_facts_data)

    # generate a copy of those facts for comparison
    CmdLineFactCollector().populate(ansible_facts_data)

    # bytes.decode() is a noop in python3
    if hasattr(ansible_facts_data['ansible_cmdline']['proc_cmdline']['console'], 'decode'):
        ansible_facts_data['ansible_cmdline']['proc_cmdline']['console'] = ansible_facts_data['ansible_cmdline']['proc_cmdline']['console'].decode()



# Generated at 2022-06-23 00:56:02.863770
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import os
    from tempfile import NamedTemporaryFile

    from ansible.module_utils.facts import Collector

    # Setup a temporary file to simulate the content of /proc/cmdline
    cmdline_content = 'BOOT_IMAGE=/vmlinuz-4.11.0-3-amd64 root=UUID=XXXX ro vt.handoff=7'
    cmdline_file = NamedTemporaryFile(delete=False)
    with cmdline_file as fh:
        fh.write(cmdline_content)

    # Create a new collector object
    cmdline_collector = Collector.get_collector(module='fake',
                                                collected_facts={},
                                                fact_list=[],
                                                collectors=['cmdline'])

    # Create the temporary file and rename it
    cmdline_file.close

# Generated at 2022-06-23 00:56:05.696312
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = CmdLineFactCollector()
    assert cmdline_facts.name == 'cmdline'
    assert cmdline_facts._fact_ids == set()


# Generated at 2022-06-23 00:56:09.832116
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'

# Generated at 2022-06-23 00:56:17.652918
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    from ansible_collections.ansible.community.tests.unit.modules.software_facts.test_cmdline import test_get_file_content

    class DummyModule(object):
        def __init__(self):
            self.params = {}

    class DummyAnsibleModule(object):
        def __init__(self):
            self.module = DummyModule()

    module = DummyAnsibleModule()

    collected_facts = {}

    collector = CmdLineFactCollector

    collector._get_proc_cmdline = test_get_file_content

    result = collector.collect(module, collected_facts)

    assert result != {}

# Generated at 2022-06-23 00:56:19.439774
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'

# Generated at 2022-06-23 00:56:29.281291
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    # Mock the module CmdLineFactCollector
    class Mock_CmdLineFactCollector(BaseFactCollector):
        name = 'cmdline'
        _fact_ids = set()
        def _get_proc_cmdline(self):
            return 'BOOT_IMAGE = (hd1,gpt2)/@/boot/vmlinuz-4.4.0-74-generic \
                root = UUID = fb44a5e7-d4bf-4eb7-8e4f-56f6f9c6e4e4 ro quiet'
        def _parse_proc_cmdline(self, data):
            cmdline_dict = {}

# Generated at 2022-06-23 00:56:30.884937
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()

    assert obj.name == 'cmdline'

# Generated at 2022-06-23 00:56:41.284544
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    content_file = 'rd.lvm.lv=vg0/root rd.lvm.lv=vg0/swap rhgb quiet'
    content_file_bad_syntax = 'rd.lvm.lv=vg0/root=swap rd.lvm.lv=vg0/swap rhgb quiet'

    cmdline_facts = {
        'cmdline': {
            'rd.lvm.lv': 'vg0/root',
            'rhgb': True,
            'quiet': True
        },
        'proc_cmdline': {
            'rd.lvm.lv': ['vg0/root', 'vg0/swap'],
            'rhgb': True,
            'quiet': True
        }
    }

# Generated at 2022-06-23 00:56:52.312779
# Unit test for method collect of class CmdLineFactCollector

# Generated at 2022-06-23 00:56:57.348185
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    try:
        cmdline = CmdLineFactCollector()
    except Exception as e:
        print("Constructor of CmdLineFactCollector throws exception %s" % str(e))
        assert False
    assert True

# Test _get_proc_cmdline() function of class CmdLineFactCollector

# Generated at 2022-06-23 00:57:04.373197
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    attrs = {'_get_proc_cmdline.return_value': 'ro,net.ifnames=0,quiet root=/dev/mapper/rhel-root rd.lvm.lv=rhel/root'}
    mock_object = type('obj', (object,), attrs)
    collector_object = CmdLineFactCollector(mock_object)

    assert collector_object.name == 'cmdline'
    assert collector_object._fact_ids == set()


# Generated at 2022-06-23 00:57:14.152992
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """ Unit test for method collect of class CmdLineFactCollector in module ansible.module_utils.facts.linux.system.cmdline """

    from ansible.module_utils.facts.linux.system.cmdline import CmdLineFactCollector

    orig_cmdline = '/usr/bin/systemd -i  - "--log-level=debug"  --system  --skip-fsck  -r'
    cmdline_dict = {'--log-level': 'debug', '--skip-fsck': True,
                    '--system': True, '-r': True}
    proc_cmdline_dict = {'--log-level': 'debug', '--skip-fsck': True,
                         '--system': True, '-r': True}

    def _proc_cmdline(self):
        return orig_cmdline

   

# Generated at 2022-06-23 00:57:24.533891
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    c = CmdLineFactCollector()

    with patch.object(c, '_get_proc_cmdline', return_value='a=b c=d'):
        assert c._get_proc_cmdline() == 'a=b c=d'
        assert c.collect() == {'cmdline': {'a': 'b', 'c': 'd'}, 'proc_cmdline': {'a': 'b', 'c': 'd'}}

    with patch.object(c, '_get_proc_cmdline', return_value='a=b b=d'):
        assert c.collect() == {'cmdline': {'a': 'b', 'b': 'd'}, 'proc_cmdline': {'a': 'b', 'b': ['b', 'd']}}

# Unit test class for class CmdLine

# Generated at 2022-06-23 00:57:27.400041
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-23 00:57:33.101131
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    t = CmdLineFactCollector()
    cmd_line_facts = t.collect()
    assert isinstance(cmd_line_facts['cmdline'], dict)
    assert isinstance(cmd_line_facts['proc_cmdline'], dict)
    assert 'BOOT_IMAGE' in cmd_line_facts['cmdline']
    assert 'rootwait' in cmd_line_facts['cmdline']


# Generated at 2022-06-23 00:57:36.359250
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()

    assert isinstance(cmd_line_fact_collector, CmdLineFactCollector)
    assert isinstance(cmd_line_fact_collector, BaseFactCollector)

# Generated at 2022-06-23 00:57:37.551486
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'

# Generated at 2022-06-23 00:57:48.980941
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_dict = {}
    cmdline_dict['BOOT_IMAGE'] = '/vmlinuz-2.6.38-8-server'
    cmdline_dict['root'] = '/dev/mapper/vg-root'
    cmdline_dict['ro'] = True
    cmdline_dict['quiet'] = True
    cmdline_dict['splash'] = True
    cmdline_dict['vt.handoff'] = '7'

    cmdline_dict2 = cmdline_dict.copy()
    cmdline_dict2['root'] = '/dev/mapper/vg-root'
    cmdline_dict2['ro'] = True
    cmdline_dict2['rw'] = True
    cmdline_dict2['rootflags'] = '/dev/mapper/vg-root'

    result = CmdLineFactCollector._

# Generated at 2022-06-23 00:57:57.155065
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    data = '''
        console=tty0 console=ttyS0,9600n8 firmware=0x8086:0xda1e
        console=ttyS0,9600n8 biosdevname=1 net.ifnames=0
    '''
    testobj = CmdLineFactCollector()
    testobj._get_proc_cmdline = lambda: data
    result = testobj._parse_proc_cmdline(data)
    assert result == {
        'console': 'ttyS0,9600n8',
        'firmware': '0x8086:0xda1e',
        'biosdevname': '1',
        'net.ifnames': '0',
    }

    result = testobj._parse_proc_cmdline_facts(data)