

# Generated at 2022-06-23 00:48:01.892911
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    result = CmdLineFactCollector().collect()
    assert isinstance(result['cmdline'], dict)
    assert isinstance(result['proc_cmdline'], dict)
    assert isinstance(result['cmdline']['console'], str)
    assert isinstance(result['proc_cmdline']['console'], str)
    assert isinstance(result['proc_cmdline']['net'], str)
    assert isinstance(result['proc_cmdline']['rd'], list)
    assert isinstance(result['proc_cmdline']['rd'][0], str)
    assert isinstance(result['proc_cmdline']['rd'][1], str)
    assert isinstance(result['proc_cmdline']['ip4.addr'], str)

# Generated at 2022-06-23 00:48:08.636634
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts import collector

    # We need to register the fact collector first.
    collector.register(CmdLineFactCollector)

    facts_instance = collector.get_facts()
    cmdline_facts = facts_instance.collect()

    assert type(cmdline_facts) is dict and len(cmdline_facts) > 0
    assert cmdline_facts.get('cmdline') is not None
    assert cmdline_facts.get('proc_cmdline') is not None

# Generated at 2022-06-23 00:48:19.051725
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import os
    import stat
    import tempfile

    content = 'BOOT_IMAGE=/vmlinuz-3.13.0-32-generic root=/dev/mapper/ubuntu--vg-root ro user_namespace.enable=1'

    fd, fn = tempfile.mkstemp()
    with os.fdopen(fd, 'w') as fh:
        fh.write(content)
    os.chmod(fn, stat.S_IRUSR | stat.S_IRGRP | stat.S_IROTH)

    c = CmdLineFactCollector()
    c.collector = c
    c.collector.get_file_content = lambda x: content


# Generated at 2022-06-23 00:48:20.676868
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector is not None


# Generated at 2022-06-23 00:48:23.202891
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    assert isinstance(collector, CmdLineFactCollector)


# Generated at 2022-06-23 00:48:24.951397
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdLineFactCollector = CmdLineFactCollector()
    assert cmdLineFactCollector.name == 'cmdline'

# Generated at 2022-06-23 00:48:27.870673
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert not cmdline_collector._fact_ids

# Generated at 2022-06-23 00:48:35.575059
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts_collector = CmdLineFactCollector()
    cmdline_facts = cmdline_facts_collector.collect()
    assert 'cmdline' in cmdline_facts
    assert 'proc_cmdline' in cmdline_facts
    assert 'BOOT_IMAGE' in cmdline_facts['cmdline']
    assert not cmdline_facts['cmdline']['BOOT_IMAGE']
    assert 'BOOT_IMAGE' in cmdline_facts['proc_cmdline']

# Generated at 2022-06-23 00:48:36.402092
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()

# Generated at 2022-06-23 00:48:43.916986
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    data = 'BOOTIF=enp0s3 console=tty0 console=ttyS0,9600 net.ifnames=0 biosdevname=0'
    cmdline_facts = {'cmdline': {'BOOTIF': 'enp0s3', 'console': 'tty0', 'net.ifnames': True, 'biosdevname': True},
                     'proc_cmdline': {'BOOTIF': 'enp0s3', 'console': ['tty0', 'ttyS0,9600'], 'net.ifnames': True, 'biosdevname': True}}

    c = CmdLineFactCollector()

    c._get_proc_cmdline = lambda: data

    assert c.collect() == cmdline_facts


# Generated at 2022-06-23 00:48:52.884974
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()

    assert cmdline_facts['cmdline']['ansible_managed'] == True
    assert cmdline_facts['cmdline']['ro'][0] == 'root=UUID=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx'
    assert cmdline_facts['cmdline']['console'] == 'tty0 console=ttyS0,115200'
    assert cmdline_facts['cmdline']['vga_delay'] == '1'
    assert cmdline_facts['cmdline']['rootwait'][0] == 'rootwait'
    assert cmdline_facts['proc_cmdline']['vga'] == '0x314'

# Generated at 2022-06-23 00:48:56.705258
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()

# Generated at 2022-06-23 00:49:06.327140
# Unit test for method collect of class CmdLineFactCollector

# Generated at 2022-06-23 00:49:09.718221
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_obj = CmdLineFactCollector()
    assert cmdline_obj.name == 'cmdline'
    assert cmdline_obj._fact_ids == set()
    assert 'Collector' in cmdline_obj.__str__()
    cmdline_obj.collect()
    cmdline_obj.get_facts()

# Generated at 2022-06-23 00:49:13.292325
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    facts = collector.collect(None, None)

    assert facts.get('cmdline')
    assert facts.get('proc_cmdline')

# Generated at 2022-06-23 00:49:15.270613
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert len(c._fact_ids) == 0

# Generated at 2022-06-23 00:49:26.521164
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collectors import CmdLineFactCollector
    from ansible.module_utils.facts.collectors.cmdline import get_file_content
    from ansible.module_utils.facts.collectors.cmdline import test_get_file_content
    from ansible.module_utils.facts.utils import supplant_vars
    from ansible.module_utils.facts.utils import get_file_lines
    import os
    import shutil

    # create test files
    supplant_data = {'test': 'OK'}
    test_data  = supplant_vars(u'foo=bar test={{ test }}\n', supplant_data)

# Generated at 2022-06-23 00:49:29.090801
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert c._fact_ids == set()


# Generated at 2022-06-23 00:49:38.502436
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    class_inst = CmdLineFactCollector()


# Generated at 2022-06-23 00:49:50.318161
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    module_name = 'mock_ansible_module'
    module_args = {}

    try:
        from ansible.modules.system import mock_ansible_module
    except ImportError:
        module_utils = 'ansible.module_utils.facts.collector.base'
        mock_ansible_module = imp.load_module(module_name, *imp.find_module(module_utils))

    module = mock_ansible_module.AnsibleModule(argument_spec=module_args)

    cmd_line_collector = CmdLineFactCollector(module)

# Generated at 2022-06-23 00:50:00.643467
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # test input
    data = 'root=/dev/sda1 rw console=tty1 console=ttyS0'
    # expected output
    output = dict(cmdline=dict(root='/dev/sda1', rw=True, console='ttyS0'),
                  proc_cmdline=dict(root=['/dev/sda1'], rw=[True], console=['tty1', 'ttyS0']))

    # initialize the CmdLineFactCollector class
    cmdline_obj = CmdLineFactCollector(module=None, collected_facts=None)
    # initialize mocked method
    cmdline_obj._get_proc_cmdline = lambda: data

    cmdline_facts = cmdline_obj.collect()

    assert cmdline_facts == output

# Generated at 2022-06-23 00:50:04.355706
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    fact_collector = CmdLineFactCollector()
    assert fact_collector.name == 'cmdline'
    assert fact_collector._fact_ids == set()
    assert isinstance(fact_collector, BaseFactCollector)


# Generated at 2022-06-23 00:50:14.900566
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_file_content = b'BOOT_IMAGE=/boot/vmlinuz-3.10.0-957.el7.x86_64 root=UUID=0fa06c33-1d2f-42f2-9b08-9418a9b23e1b ro crashkernel=auto rhgb quiet LANG=en_US.UTF-8'
    mock_module = Mock()
    mock_module.get_bin_path = Mock(return_value=None)
    mock_module.get_file_content = Mock(return_value=cmdline_file_content)
    collector = CmdLineFactCollector(mock_module)
    result = collector.collect()
    assert result is not None
    assert result['cmdline'] is not None

# Generated at 2022-06-23 00:50:24.836597
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    ''' This will test the method collect of class CmdLineFactCollector '''
    def test_get_file_content(file_name):
        ''' This will return content of file '''
        return 'BOOT_IMAGE=/vmlinuz-3.10.0-327.36.1.el7.x86_64 root=/dev/mapper/rhel-root ro crashkernel=auto rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet LANG=en_US.UTF-8'

    CmdLineFactCollector._get_proc_cmdline = test_get_file_content
    cmdline_facts = CmdLineFactCollector().collect()

# Generated at 2022-06-23 00:50:28.268187
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    ansible_module = AnsibleModule(argument_spec={})
    ansible_module.exit_json(ansible_facts=dict(ansible_processor_facts=collector.collect(ansible_module)))


# Generated at 2022-06-23 00:50:30.219599
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdLineFactCollector = CmdLineFactCollector()
    assert cmdLineFactCollector.name == 'cmdline'

# Generated at 2022-06-23 00:50:32.580061
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()


# Generated at 2022-06-23 00:50:35.104961
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    o = CmdLineFactCollector()
    assert o.name == "cmdline"
    assert o._fact_ids == set()


# Generated at 2022-06-23 00:50:37.365106
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts_collector = CmdLineFactCollector()
    assert cmdline_facts_collector.name == 'cmdline'

# Generated at 2022-06-23 00:50:47.379879
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cm = CmdLineFactCollector()

# Generated at 2022-06-23 00:50:56.087471
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    with open('/proc/cmdline', 'r') as file:
        data = file.read()
        assert cmdline_collector.collect() == {'proc_cmdline': {'root': '/dev/mapper/rhel-root', 'ro': True, 'rhgb': True, 'quiet': True, 'initrd': '/boot/initramfs-3.10.0-327.10.1.el7.x86_64.img'}, 'cmdline': {'root': '/dev/mapper/rhel-root', 'ro': True, 'rhgb': True, 'quiet': True, 'initrd': '/boot/initramfs-3.10.0-327.10.1.el7.x86_64.img'}}

# Generated at 2022-06-23 00:51:00.280853
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert not c._fact_ids


# Generated at 2022-06-23 00:51:03.526737
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    facts = CmdLineFactCollector()
    assert isinstance(facts, BaseFactCollector)
    assert 'cmdline' == facts.name

# Generated at 2022-06-23 00:51:14.511664
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline = CmdLineFactCollector()
    # Tests for first use case
    cmdline.content = 'console=ttyS0,115200 root=LABEL=/'
    cmdline._get_proc_cmdline  = lambda: cmdline.content
    assert cmdline.collect() == {'cmdline': {'console': 'ttyS0,115200', 'root': 'LABEL=/'},
                                 'proc_cmdline': {'console': 'ttyS0,115200', 'root': 'LABEL=/'}}
    # Tests for second use case

# Generated at 2022-06-23 00:51:26.436979
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_dict = {
        'cmdline': {
            'BOOT_IMAGE': '/vmlinuz-3.13.0-57-generic',
            'console': 'ttyS0',
            'quiet': True,
            'splash': True,
            'vt.handoff': '7'
        },
        'proc_cmdline': {
            'BOOT_IMAGE': ['/vmlinuz-3.13.0-57-generic', 'root=/dev/mapper/ubuntu--vg-root'],
            'console': 'ttyS0',
            'quiet': True,
            'splash': True,
            'vt.handoff': '7'
        }
    }


# Generated at 2022-06-23 00:51:36.212602
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    data = 'cluster=rhel7 zswap.enabled=1 zswap.max_pool_percent=25 zswap.zpool=z3fold crashkernel=auto rhgb quiet audit=1 net.ifnames=0 biosdevname=0'
    fact_collector = CmdLineFactCollector()
    # override _get_proc_cmdline() with the unit test data
    fact_collector._get_proc_cmdline = lambda: data
    test_facts = fact_collector.collect()

# Generated at 2022-06-23 00:51:39.516665
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c
    assert c.name == "cmdline"
    assert c._fact_ids == set()


# Generated at 2022-06-23 00:51:50.367404
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    class MockModule:
        def __init__(self):
            pass

    class MockCollectedFacts:
        def __init__(self):
            pass

    cmd_line_collector = CmdLineFactCollector()
    cmd_line_collector._get_proc_cmdline = lambda self: 'BOOT_IMAGE=/boot/vmlinuz-3.19.0-15-generic.efi.signed root=UUID=a37c7940-dbea-43ff-8b3e-2b27d9b2e8df ro quiet splash vt.handoff=7'

# Generated at 2022-06-23 00:51:59.187075
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import add_collector, list_collectors
    from ansible.module_utils.facts.utils import get_file_content

    # Add CmdLineFactCollector to ansible.module_utils.facts.collector
    add_collector(CmdLineFactCollector)

    # Check if CmdLineFactCollector is in ansible.module_utils.facts.collector
    collectors = list_collectors()
    assert CmdLineFactCollector.name in collectors

    # Create instance of CmdLineFactCollector
    cmdline_collector = CmdLineFactCollector()

    # Create test data file
    test_data = 'a=1 c=3 b=2 d=4'
    fhandle, fname = tempfile.mkstemp()

# Generated at 2022-06-23 00:52:04.775593
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    result = collector.collect({'gather_subset': ['!all', 'cmdline']})
    assert type(result['cmdline']) == dict
    assert type(result['proc_cmdline']) == dict


# Generated at 2022-06-23 00:52:08.660463
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-23 00:52:12.670389
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    #Testing _get_proc_cmdline()
    cmd_string = CmdLineFactCollector()
    assert(cmd_string.name == 'cmdline')
    assert(isinstance(cmd_string._fact_ids, set))
    assert(isinstance(cmd_string.collect(), dict))

# Generated at 2022-06-23 00:52:21.144950
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    # Constructor test
    cmdline_collector = CmdLineFactCollector()

    # Unit test for 'collect' method
    cmdline_collector._get_proc_cmdline = Mock(return_value='arg1=true arg2=false arg3 arg4=one arg5=two arg4=three arg5')
    assert cmdline_collector.collect() == {'cmdline': {'arg1': 'true', 'arg2': 'false', 'arg3': True, 'arg4': 'one', 'arg5': 'two'},
                                           'proc_cmdline': {'arg1': 'true', 'arg2': 'false', 'arg3': True, 'arg4': ['one', 'three'], 'arg5': ['two', True]}}

# Generated at 2022-06-23 00:52:23.993416
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert isinstance(CmdLineFactCollector._fact_ids, set)

# Generated at 2022-06-23 00:52:25.762832
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cf = CmdLineFactCollector()

    assert cf.name == 'cmdline'
    assert cf._fact_ids == set()

# Generated at 2022-06-23 00:52:30.481818
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-23 00:52:34.588693
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    coll_cmdline = CmdLineFactCollector()
    assert coll_cmdline._get_proc_cmdline()
    assert coll_cmdline._parse_proc_cmdline('ro root=LABEL=/')
    assert coll_cmdline._parse_proc_cmdline_facts('ro root=LABEL=/')
    assert coll_cmdline.collect()

# Generated at 2022-06-23 00:52:39.829327
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    fact_collector = CmdLineFactCollector()
    result = fact_collector.collect()

    if 'cmdline' not in result:
        raise KeyError("Expected key 'cmdline' in CmdLineFactCollector result")

    if 'proc_cmdline' not in result:
        raise KeyError("Expected key 'proc_cmdline' in CmdLineFactCollector result")

# Generated at 2022-06-23 00:52:42.871472
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'
    assert collector._fact_ids == set()

# Generated at 2022-06-23 00:52:51.062460
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # create class object
    cmdline = CmdLineFactCollector()

    # call method collect
    result = cmdline.collect()

    # check if result is initialized
    assert result is not None

    # check if result has key cmdline and proc_cmdline
    assert 'cmdline' in result
    assert 'proc_cmdline' in result

    # check if proc_cmdline has key ansible_fact_cmdline
    assert 'ansible_fact_cmdline' in result['proc_cmdline']

    # check if proc_cmdline has value True for key ansible_fact_cmdline
    assert result['proc_cmdline']['ansible_fact_cmdline'] is True


# Generated at 2022-06-23 00:52:53.727320
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    fake_ansible_module = object()
    actual_fact_collector = CmdLineFactCollector(fake_ansible_module)
    assert actual_fact_collector.name == 'cmdline'
    assert actual_fact_collector._fact_ids == set()


# Generated at 2022-06-23 00:52:56.055687
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'

# Generated at 2022-06-23 00:53:05.565407
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collection import FactsCollectionManager
    from ansible.module_utils.facts.collector import CommandLine
    from ansible.module_utils.facts.collector import CmdLineFactCollector
    from ansible.module_utils.facts.utils import FactCollector

    g = globals()
    g.update(locals())
    fcm = FactsCollectionManager(g, CommandLine)
    cmdline_facts = CmdLineFactCollector(g, fcm).collect()
    assert cmdline_facts['cmdline']['root'] == '/dev/sda3'
    assert cmdline_facts['cmdline']['console'] == 'tty0'
    assert cmdline_facts['proc_cmdline']['root'] == '/dev/sda3'

# Generated at 2022-06-23 00:53:14.567871
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """
    Make sure the `/proc/cmdline' file is parsed correctly.
    """
    # Test empty cmdline
    data = CmdLineFactCollector()._parse_proc_cmdline('')
    assert len(data) == 0

    # Test one item with no value
    data = CmdLineFactCollector()._parse_proc_cmdline('foo')
    assert data['foo'] is True

    # Test one item with value
    data = CmdLineFactCollector()._parse_proc_cmdline('foo=bar')
    assert data['foo'] == 'bar'

    # Test two items with no value separated by space
    data = CmdLineFactCollector()._parse_proc_cmdline('foo bar')
    assert data['foo'] is True
    assert data['bar'] is True

    # Test two items with

# Generated at 2022-06-23 00:53:26.288603
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """Unit test for method collect of class CmdLineFactCollector."""
    # Create instance of class CmdLineFactCollector
    cmdline_fact_collector = CmdLineFactCollector()

    # Mock method _get_proc_cmdline
    cmdline_fact_collector._get_proc_cmdline = lambda: 'BOOT_IMAGE=/vmlinuz-3.10.0-327.el7.x86_64.efi.signed root=/dev/mapper/cl-root ro rd.lvm.lv=cl/root rd.lvm.lv=cl/swap crashkernel=auto rd.lvm.lv=cl/tmp rd.lvm.lv=cl/var  rhgb quiet LANG=en_US.UTF-8'

    # Call method collect
    result = cmdline_fact_

# Generated at 2022-06-23 00:53:29.273483
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'

    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector._fact_ids == set()



# Generated at 2022-06-23 00:53:37.840044
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import mock

    # Mock values used in test
    mock_module = mock.Mock()
    mock_collected_facts = mock.Mock()
    mock_data = mock.Mock()
    mock_cmdline = mock.Mock()
    mock_proc_cmdline = mock.Mock()

    # Mock object that is used as parameter of method collect
    mock_CmdLineFactCollector_object = mock.Mock(spec=CmdLineFactCollector)

    # Mocking method _get_proc_cmdline
    mock_CmdLineFactCollector_object.configure_mock(**{'_get_proc_cmdline.return_value': mock_data})

    # Mocking method _parse_proc_cmdline

# Generated at 2022-06-23 00:53:40.972256
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    pass

# Generated at 2022-06-23 00:53:52.446806
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    data = """test_parameter_1=test_value_1 test_parameter_2=test_value_2 test_parameter_3=test_value_3"""

    cmdline_facts = CmdLineFactCollector().collect()

    assert cmdline_facts['cmdline']['test_parameter_1'] == 'test_value_1'
    assert cmdline_facts['cmdline']['test_parameter_2'] == 'test_value_2'
    assert cmdline_facts['cmdline']['test_parameter_3'] == 'test_value_3'
    assert cmdline_facts['proc_cmdline']['test_parameter_1'] == 'test_value_1'

# Generated at 2022-06-23 00:53:53.873622
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'

# Generated at 2022-06-23 00:54:02.379276
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    cmdline_data = """
      BOOT_IMAGE=/boot/vmlinuz-2.6.32-279.el6.x86_64 root=UUID=bc395c2e-b5cc-4f4e-8a48-7ff552cb5cb9 ro
      rhgb quiet LANG=en_US.UTF-8  KEYTABLE=us
    """

# Generated at 2022-06-23 00:54:04.792436
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    fact_collector = CmdLineFactCollector()

    assert fact_collector.name == 'cmdline'
    assert isinstance(fact_collector._fact_ids, set)

# Generated at 2022-06-23 00:54:16.124115
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    mock_module = Mock(params="")
    mock_collector = CmdLineFactCollector()
    mock_collector._get_proc_cmdline = MagicMock(return_value="mock_cmdline")
    mock_collector._parse_proc_cmdline = MagicMock(return_value="cmdline")
    mock_collector._parse_proc_cmdline_facts = MagicMock(return_value="proc_cmdline_facts")
    mock_facts = {}
    result = mock_collector.collect(mock_module, mock_facts)
    assert "cmdline" in result and result["cmdline"] == "cmdline"
    assert "proc_cmdline" in result and result["proc_cmdline"] == "proc_cmdline_facts"


# Generated at 2022-06-23 00:54:25.185971
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Setup test fixtures
    class Module():
        def __init__(self):
            self.params = {'gather_subset': ['cmdline']}

    with open('/proc/cmdline', 'w') as f:
        f.write('a=b c=d e')

    # Run test
    cmdline_facts = CmdLineFactCollector().collect(Module())

    # Assert test results
    assert cmdline_facts['cmdline']['a'] == 'b'
    assert cmdline_facts['cmdline']['c'] == 'd'
    assert cmdline_facts['cmdline']['e']
    assert cmdline_facts['proc_cmdline']['a'] == 'b'
    assert cmdline_facts['proc_cmdline']['c'] == 'd'
    assert cmdline

# Generated at 2022-06-23 00:54:28.322946
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cm = CmdLineFactCollector()
    assert cm.name == 'cmdline'
    assert len(cm._fact_ids) == 0

# Generated at 2022-06-23 00:54:33.646881
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    cm = CmdLineFactCollector()
    assert cm.name == 'cmdline'
    assert 'does_not_exist' not in cm._fact_ids
    assert 'cmdline' in cm._fact_ids
    assert 'proc_cmdline' in cm._fact_ids
    assert isinstance(cm.collect(), dict)
    assert not isinstance(cm.collect(collected_facts=dict()), dict)

# Generated at 2022-06-23 00:54:36.275029
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_fact_collector = CmdLineFactCollector()
    assert isinstance(cmdline_fact_collector.collect(), dict)

# Generated at 2022-06-23 00:54:38.685931
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector.name == 'cmdline'


# Generated at 2022-06-23 00:54:41.323176
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == "cmdline"
    assert cmdline_collector._fact_ids == set()



# Generated at 2022-06-23 00:54:44.245694
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert 'cmdline' not in c._fact_ids
    assert 'proc_cmdline' not in c._fact_ids


# Generated at 2022-06-23 00:54:46.036946
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()


# Generated at 2022-06-23 00:54:57.753510
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    import sys
    if sys.version_info[:2] == (2, 6):
        import unittest2 as unittest
    else:
        import unittest
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collectors import cmdline

    class TestCmdLineFactCollector(unittest.TestCase):

        @unittest.skipIf(cmdline.sys.version_info[:2] != (2, 7), 'Test only for python 2.7')
        def test_collect(self):

            testcmdline = 'root=UUID=824c9b9c-3df3-4ee2-8a3c-b7e2f129a413 ro'

            fake_module = None


# Generated at 2022-06-23 00:54:59.537946
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert isinstance(obj, BaseFactCollector)



# Generated at 2022-06-23 00:55:09.990280
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():

    # Test that _get_proc_cmdline() returns empty string if file
    # '/proc/cmdline' does not exist
    cmd_line_collector = CmdLineFactCollector()
    assert cmd_line_collector._get_proc_cmdline() == ''

    # Test that _parse_proc_cmdline() returns a dict
    # that contains key-value pairs split on '='
    data = 'ansible_python_interpreter=/usr/bin/python'
    assert cmd_line_collector._parse_proc_cmdline(data) == \
        {'ansible_python_interpreter': '/usr/bin/python'}

    # Test that _parse_proc_cmdline() does not fail if the string
    # cannot be split
    data = 'foobar'
    assert cmd_line_collector._parse

# Generated at 2022-06-23 00:55:18.176032
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    # Define a mock for the base class
    class MockFactsCollector(object):
        class MockBaseFactCollector(object):
            def __init__(self):
                self.name = None
                self._fact_ids = set()

        def __init__(self):
            self.collectors = None
            self.collector_classes = [self.MockBaseFactCollector]
            self.cache = { 'collectors': {}, 'fact_cache': {} }

    # Define a fake content of file '/proc/cmdline'

# Generated at 2022-06-23 00:55:29.860763
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    assert collector.collect() == {'cmdline': {'root': '/dev/sda2', 'BOOT_IMAGE': '/vmlinuz-linux'},
                                   'proc_cmdline': {'root': '/dev/sda2', 'BOOT_IMAGE': '/vmlinuz-linux'}}

# Generated at 2022-06-23 00:55:38.479968
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    # Values used by both mocked _get_proc_cmdline and _parse_proc_cmdline
    data = "value1 value2=value2b value3=value3b value3=value3c"

    # Values used by _parse_proc_cmdline_facts only
    dict_data_1 = {
        "cmdline": {
            "value1": True,
            "value2": "value2b",
            "value3": "value3c"
        },
        "proc_cmdline": {
            "value1": True,
            "value2": "value2b",
            "value3": ["value3b", "value3c"]
        }
    }

    # Values used by _parse_proc_cmdline_facts only

# Generated at 2022-06-23 00:55:40.023091
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector.collector == 'CmdLineFactCollector'

# Generated at 2022-06-23 00:55:43.608302
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-23 00:55:45.194531
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():

    # No arguments
    CmdLineFactCollector()



# Generated at 2022-06-23 00:55:48.001153
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()


# Generated at 2022-06-23 00:55:50.114813
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    test_collector = CmdLineFactCollector()
    assert test_collector.name == 'cmdline'

# Generated at 2022-06-23 00:55:56.851716
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    sample_data = "root=/dev/mapper/rhel-root ro crashkernel=auto rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet LANG=en_US.UTF-8"
    collector = CmdLineFactCollector()
    collector._get_proc_cmdline = lambda: sample_data
    collector.collect()

    assert collector.name == 'cmdline'


# Generated at 2022-06-23 00:55:58.525740
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'

# Generated at 2022-06-23 00:56:08.871908
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    with mock.patch('ansible.module_utils.facts.collector.cmdline.CmdLineFactCollector._get_proc_cmdline', mock.MagicMock(return_value='bar=foo')):
        with mock.patch('ansible.module_utils.facts.collector.cmdline.CmdLineFactCollector._parse_proc_cmdline', mock.MagicMock(return_value=['foo', 'bar'])):
            with mock.patch('ansible.module_utils.facts.collector.cmdline.CmdLineFactCollector._parse_proc_cmdline_facts', mock.MagicMock(return_value=['baz', 'bar'])):
                cmdline_facts = CmdLineFactCollector().collect()

# Generated at 2022-06-23 00:56:18.436427
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()

# Generated at 2022-06-23 00:56:27.519588
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.cmdline import CmdLineFactCollector
    from ansible.module_utils.facts.utils import AnsibleFactCollector
    from __main__ import display
    cmd_line_fact_collector = CmdLineFactCollector()
    ansible_fact_collector = AnsibleFactCollector()
    ansible_fact_collector.add_collector(cmd_line_fact_collector)
    ansible_facts = ansible_fact_collector.collect(module=None, collected_facts=None)
    display.display(ansible_facts, verbosity=2)
    # Test failed if the ansible_facts is empty
    assert ansible_facts


# Generated at 2022-06-23 00:56:30.742493
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert isinstance(cmdline_fact_collector, CmdLineFactCollector)


# Generated at 2022-06-23 00:56:33.447206
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c is not None and c.name == 'cmdline'


# Generated at 2022-06-23 00:56:35.814173
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector().name == 'cmdline'
    assert CmdLineFactCollector()._fact_ids == set()

# Generated at 2022-06-23 00:56:45.836899
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    proc_cmdline = 'BOOT_IMAGE=/vmlinuz-4.4.0-21-generic.efi.signed root=UUID=6f5a8f5c-e5d7-4c1b-aa8e-d0d4f2c9dcb6 ro quiet splash vt.handoff=7'
    c = CmdLineFactCollector()
    c._get_proc_cmdline = MagicMock(return_value=proc_cmdline)

    # test correct extraction of proc_cmdline content
    facts = c.collect()

# Generated at 2022-06-23 00:56:48.059829
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd = CmdLineFactCollector()
    assert cmd.name == 'cmdline'
    assert cmd._fact_ids == set()

# Generated at 2022-06-23 00:56:59.701439
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    module = MockModule()
    collected_facts = {'ansible_facts': {}}

    line = 'BOOT_IMAGE=/boot/vmlinuz-1-1.x86_64 root=/dev/mapper/vg_root-lv_root ro nofb no_console_suspend'

# Generated at 2022-06-23 00:57:06.536921
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    '''
    Unit test for method collect of class CmdLineFactCollector
    '''
    cmdline_collector = CmdLineFactCollector()
    cmdline_dict = cmdline_collector._get_proc_cmdline()
    data = cmdline_collector._parse_proc_cmdline(cmdline_dict)
    proc_cmdline = cmdline_collector._parse_proc_cmdline_facts(cmdline_dict)

    assert data
    assert proc_cmdline

# Generated at 2022-06-23 00:57:08.376537
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert cmdline.name == 'cmdline'

# Generated at 2022-06-23 00:57:12.447396
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdlineFactCollector = CmdLineFactCollector()

    cmdline = cmdlineFactCollector._get_proc_cmdline()
    assert cmdline != None

    cmdline_dict = cmdlineFactCollector._parse_proc_cmdline(cmdline)
    assert cmdline_dict != None



# Generated at 2022-06-23 00:57:23.753871
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    class MockModule():
        def __init__(self):
            self.params = {}

    class MockCollected_facts():
        def __init__(self):
            self.data = {}


    cmdline_collector = CmdLineFactCollector(MockModule(), MockCollected_facts())

    cmdline_collector._get_proc_cmdline = lambda: 'root=/dev/sda1 rd.lvm.lv=centos/root rd.lvm.lv=centos/swap crashkernel=auto  rhgb quiet LANG=en_US.UTF-8'

    cmdline_facts = cmdline_collector.collect()


# Generated at 2022-06-23 00:57:28.753356
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import CmdLineFactCollector
    import mock

    (differences, identical) = CmdLineFactCollector().compare(
        CmdLineFactCollector().collect()
        )

    assert len(differences) == 0
    assert len(identical) == 2

# Generated at 2022-06-23 00:57:31.518760
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd = CmdLineFactCollector()
    # name
    assert cmd.name == 'cmdline'
    # _fact_ids
    assert cmd._fact_ids == set()

# Generated at 2022-06-23 00:57:40.109110
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()

    # method collect should return a dictionary
    assert isinstance(cmdline_facts, dict)

    # method collect should return a dictionary with key cmdline
    assert 'cmdline' in cmdline_facts

    # method collect should return a dictionary with key cmdline with value type
    # boolean, string or integer
    assert isinstance(cmdline_facts['cmdline'], dict)

    # method collect should return a dictionary with key proc_cmdline
    assert 'proc_cmdline' in cmdline_facts

    # method collect should return a dictionary with key proc_cmdline with value type
    # boolean, string or list of strings
    assert isinstance(cmdline_facts['proc_cmdline'], dict)


# Generated at 2022-06-23 00:57:42.798566
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c is not None, 'CmdLineFactCollector cannot be instantiated!'


# Generated at 2022-06-23 00:57:47.407557
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    """This is a test for the module CmdLineFactCollector.
    """
    _CmdLineFactCollector = CmdLineFactCollector()
    assert _CmdLineFactCollector.name == 'cmdline'
    assert _CmdLineFactCollector._fact_ids == set()


# Generated at 2022-06-23 00:57:56.941227
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    from ansible.module_utils.facts import CommandLineFactCollector
    cfg = CommandLineFactCollector()
    assert cfg.name == 'cmdline'
    assert not cfg._fact_ids
    assert cfg._get_proc_cmdline == CmdLineFactCollector._get_proc_cmdline
    assert cfg._parse_proc_cmdline == CmdLineFactCollector._parse_proc_cmdline
    assert cfg._parse_proc_cmdline_facts == CmdLineFactCollector._parse_proc_cmdline_facts
    assert cfg.collect == CmdLineFactCollector.collect