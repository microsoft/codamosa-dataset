

# Generated at 2022-06-23 00:47:57.047149
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert c._fact_ids == set()


# Generated at 2022-06-23 00:48:03.845691
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    """
    Unit test for the constructor CmdLineFactCollector of the class CmdLineFactCollector
    """
    assert CmdLineFactCollector.name == 'cmdline'
    assert isinstance(CmdLineFactCollector._fact_ids, set)
    assert isinstance(CmdLineFactCollector.collect(), dict)
    assert CmdLineFactCollector.collect() == {'cmdline': {}, 'proc_cmdline': {}}

# Generated at 2022-06-23 00:48:14.817805
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    CmdLineFactCollector = CmdLineFactCollector()

    # Testing with proc_cmdline file that's not present
    with patch("ansible.module_utils.facts.collector.get_file_content",
               return_value=None):
        assert CmdLineFactCollector.collect() == {}

    # Testing with proc_cmdline file that's present

# Generated at 2022-06-23 00:48:17.432034
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector is not None


# Generated at 2022-06-23 00:48:18.823498
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == "cmdline"
    assert obj.collect()

# Generated at 2022-06-23 00:48:19.988825
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    pass

# Generated at 2022-06-23 00:48:24.053896
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    from ansible.module_utils.facts import BaseFactModule
    from ansible.module_utils.facts import CommandLineFactModule

    fact_module = BaseFactModule()
    commandline_fact_module = CommandLineFactModule(fact_module)
    assert commandline_fact_module is not None

# Generated at 2022-06-23 00:48:28.256542
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    test_obj = CmdLineFactCollector()
    assert isinstance(test_obj, CmdLineFactCollector)
    assert isinstance(test_obj._parse_proc_cmdline(''), dict)
    assert isinstance(test_obj._parse_proc_cmdline_facts(''), dict)
    assert 'cmdline' in test_obj.collect()

# Generated at 2022-06-23 00:48:35.973714
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    import ansible.module_utils.facts.collector.cmdline

    assert issubclass(ansible.module_utils.facts.collector.cmdline.CmdLineFactCollector, BaseFactCollector), \
        "class CmdLineFactCollector should be subclass of BaseFactCollector"
    assert ansible.module_utils.facts.collector.cmdline.CmdLineFactCollector.__name__ == "CmdLineFactCollector", \
        "class CmdLineFactCollector should be named CmdLineFactCollector"

# Generated at 2022-06-23 00:48:44.179318
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    ansible_module = {}
    ansible_module['ansible_facts'] = {}
    ansible_module['ansible_facts']['cmdline'] = {'ansible': True}
    ansible_module['ansible_facts']['proc_cmdline'] = {'ansible': True}

    collector = CmdLineFactCollector()
    collector.collect(module=ansible_module, collected_facts=ansible_module['ansible_facts'])
    assert 'cmdline' in ansible_module['ansible_facts']
    assert 'proc_cmdline' in ansible_module['ansible_facts']
    assert type(ansible_module['ansible_facts']['cmdline']) == dict
    assert type(ansible_module['ansible_facts']['proc_cmdline']) == dict


# Generated at 2022-06-23 00:48:46.096399
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    result = CmdLineFactCollector()
    assert isinstance(result, BaseFactCollector)
    assert result.name == 'cmdline'

# Generated at 2022-06-23 00:48:47.495832
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'

# Generated at 2022-06-23 00:48:49.356580
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_fact_collector = CmdLineFactCollector()
    result = cmdline_fact_collector.collect()

    assert result

# Generated at 2022-06-23 00:48:52.707431
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    c = CmdLineFactCollector()

    cmdline_facts = c.collect()
    assert cmdline_facts is not None

# Generated at 2022-06-23 00:48:58.427621
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
        obj = CmdLineFactCollector()
        assert obj, 'Cannot create CmdLineFactCollector instance.'
        assert obj.name == 'cmdline', 'cmdline collector name is incorrect.'

# Generated at 2022-06-23 00:49:03.463262
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts import enable_test_collection
    enable_test_collection()

    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.collect() == {
        'cmdline': {
            'ansible_cmdline': True
        },
        'proc_cmdline': {
            'ansible_cmdline': True
        }
    }

# Generated at 2022-06-23 00:49:04.838602
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'

# Generated at 2022-06-23 00:49:07.151206
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    x = CmdLineFactCollector()
    assert x.name == 'cmdline'
    assert x._fact_ids == set()


# Generated at 2022-06-23 00:49:10.315925
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert isinstance(c._fact_ids, set)
    assert len(c._fact_ids) == 0

# Generated at 2022-06-23 00:49:20.296878
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    module_cmdline = CmdLineFactCollector()

    fake_proc_cmdline_return = b'splash vga=788 acpi=off rd.shell=1 rd.driver.blacklist=nouveau modprobe.blacklist=nouveau nouveau.modeset=0 rd.luks=0 rd.md=0 rd.dm=0 BOOT_IMAGE=/vmlinuz-3.10.0-123.el7.x86_64 root=/dev/mapper/rhel-root ro rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet LANG=en_US.UTF-8 quiet'


# Generated at 2022-06-23 00:49:22.159343
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'

# Generated at 2022-06-23 00:49:23.550089
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector().name == 'cmdline'


# Generated at 2022-06-23 00:49:25.408920
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'


# Generated at 2022-06-23 00:49:27.568221
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.collect() == {}


# Generated at 2022-06-23 00:49:28.938644
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cp = CmdLineFactCollector()
    assert cp.name == 'cmdline'

# Generated at 2022-06-23 00:49:38.385636
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Test class CmdLineFactCollector
    obj = CmdLineFactCollector()

    # test method _get_proc_cmdline
    data = obj._get_proc_cmdline()
    assert data == ''

    # test method _parse_proc_cmdline
    data = obj._parse_proc_cmdline('')
    assert data == {}

    data = obj._parse_proc_cmdline('a=b')
    assert data == {'a': 'b'}

    data = obj._parse_proc_cmdline(' a = b ')
    assert data == {'a': 'b'}

    data = obj._parse_proc_cmdline(' a = b = c = d = e ')
    assert data == {'a': 'b = c = d = e'}

    data = obj._parse_proc_

# Generated at 2022-06-23 00:49:41.620641
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'


# Generated at 2022-06-23 00:49:52.124886
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Build a sample data
    test_data = "BOOT_IMAGE=kernel root=LABEL=ROOT  quiet"

    # Instantiate a CmdLineFactCollector object
    cmdline_collector = CmdLineFactCollector()

    # Define a mock for the collect method of class CmdLineFactCollector
    def mock_get_proc_cmdline(self):
        return test_data

    # Set the mocked method as the default one
    cmdline_collector._get_proc_cmdline = mock_get_proc_cmdline

    # Call the collect method
    actual_cmdline_facts = cmdline_collector.collect()

    # Assert expected results
    assert actual_cmdline_facts['cmdline']['BOOT_IMAGE'] == 'kernel'

# Generated at 2022-06-23 00:50:00.689240
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['proc_cmdline']['BOOT_IMAGE']
    assert cmdline_facts['proc_cmdline']['BOOT_IMAGE'].startswith('/vmlinuz-')
    assert cmdline_facts['cmdline']['BOOT_IMAGE'].startswith('/vmlinuz-')
    assert cmdline_facts['proc_cmdline']['BOOT_IMAGE'].endswith('.efi')
    assert cmdline_facts['cmdline']['BOOT_IMAGE'].endswith('.efi')

# Generated at 2022-06-23 00:50:04.355428
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Create a new instance of class CmdLineFactCollector
    cmdline_collector = CmdLineFactCollector()

    # Test _fact_ids
    fact_ids = cmdline_collector._fact_ids
    assert fact_ids == set()

# Generated at 2022-06-23 00:50:05.232063
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()

# Generated at 2022-06-23 00:50:15.279055
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    c = CmdLineFactCollector()
    c._get_proc_cmdline = lambda: 'BOOT_IMAGE=/boot/vmlinuz-3.10.0-514.el7.x86_64/vmlinuz-3.10.0-514.el7.x86_64 root=UUID=a446fcfa-e83e-4415-8232-d9907d00e2c1 ro crashkernel=auto rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet  console=ttyS1,115200n8 console=tty0'
    facts = c.collect()

# Generated at 2022-06-23 00:50:17.241274
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
   cmdline_fact_collector = CmdLineFactCollector()
   assert cmdline_fact_collector is not None


# Generated at 2022-06-23 00:50:19.649120
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    x = CmdLineFactCollector()
    assert x.name == 'cmdline'
    assert x._fact_ids == set()

# Generated at 2022-06-23 00:50:20.635633
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    CmdLineFactCollector.collect()

# Generated at 2022-06-23 00:50:22.389126
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    test_object = CmdLineFactCollector()
    assert test_object.name == 'cmdline'

# Generated at 2022-06-23 00:50:26.808989
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector()

    data = cmdline_facts._get_proc_cmdline()

    cmdline_dict = cmdline_facts._parse_proc_cmdline(data)
    proc_cmdline_dict = cmdline_facts._parse_proc_cmdline_facts(data)

    print(cmdline_dict)
    print(proc_cmdline_dict)

# Generated at 2022-06-23 00:50:30.414055
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-23 00:50:32.762001
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'

# Generated at 2022-06-23 00:50:35.655223
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == "cmdline", "Test constructor of class CmdLineFactCollector failed"


# Generated at 2022-06-23 00:50:38.958806
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """
    Unit test for method collect of class CmdLineFactCollector
    """
    cmdline_facts = {}
    cmdline_facts = CmdLineFactCollector().collect()
    assert 'cmdline' in cmdline_facts


# Generated at 2022-06-23 00:50:41.629061
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    test_collector = CmdLineFactCollector()

    result = test_collector.collect()
    assert result['cmdline'] != None
    assert result['proc_cmdline'] != None

# Generated at 2022-06-23 00:50:51.576560
# Unit test for method collect of class CmdLineFactCollector

# Generated at 2022-06-23 00:50:52.417165
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    CmdLineFactCollector().collect()

# Generated at 2022-06-23 00:51:00.290867
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """
    Tests if module_utils.facts.cmdline.CmdLineFactCollector.collect returns
    the correct dictionary object.
    """

    test_object = CmdLineFactCollector()

    result = test_object.collect()

    assert set(result.keys()) == set(['cmdline', 'proc_cmdline'])
    assert result['cmdline']['root'] == '/dev/mapper/VolGroup-lv_root'
    assert result['proc_cmdline']['root'] == '/dev/mapper/VolGroup-lv_root'
    assert result['proc_cmdline']['quiet'] == True

# Generated at 2022-06-23 00:51:01.224091
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()

# Generated at 2022-06-23 00:51:05.261275
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    fact = {}

    collector.collect(fact)
    assert 'cmdline' in fact
    assert 'proc_cmdline' in fact
    assert isinstance(fact['cmdline'], dict)
    assert isinstance(fact['proc_cmdline'], dict)

# Generated at 2022-06-23 00:51:12.334593
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import sys
    from ansible.module_utils.facts import __get_module_path

    sys.path.append(__get_module_path('ansible.module_utils.facts.collectors.cmdline'))
    sys.modules['ansible.module_utils.facts.collectors.cmdline.get_file_content'] = get_file_content
    sys.modules['ansible.module_utils.facts.collectors.cmdline.shlex'] = shlex

    collect_cmdline = CmdLineFactCollector().collect

# Generated at 2022-06-23 00:51:14.559431
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()

# Generated at 2022-06-23 00:51:18.407219
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    fact_collector = CmdLineFactCollector()
    assert fact_collector.name == CmdLineFactCollector.name
    assert fact_collector._fact_ids == set()


# Generated at 2022-06-23 00:51:20.734282
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector is not None

# Generated at 2022-06-23 00:51:32.996834
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Creating an instance of a CmdLineFactCollector
    c = CmdLineFactCollector()
    # Testing the collect method and asserting equality with the
    # expected output

# Generated at 2022-06-23 00:51:34.400951
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd_line_fact_collector = CmdLineFactCollector()
    assert cmd_line_fact_collector.name == 'cmdline'

# Generated at 2022-06-23 00:51:45.432894
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import json
    import os
    import sys

    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
    import lib.facts.utils

    test_file = os.path.join(os.path.dirname(__file__), '..', '..', 'test_data', 'cmdline.txt')

    test_data = open(test_file, 'r').read().strip()


# Generated at 2022-06-23 00:51:49.006869
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_dict = {'root': '/dev/sda2', 'net.ifnames': True}
    c = CmdLineFactCollector()
    c.collect()
    assert cmdline_dict == c.collect()['cmdline']

# Generated at 2022-06-23 00:51:50.877267
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    result = CmdLineFactCollector()
    assert result.name == 'cmdline'
    assert isinstance(result._fact_ids, set)

# Generated at 2022-06-23 00:51:59.559355
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    # Test empty file
    collector = CmdLineFactCollector
    open('/proc/cmdline', 'w').close()
    collected_facts = {'cmdline': {}, 'proc_cmdline': {}}
    assert collector.collect(None, collected_facts) == collected_facts

    # Test non-empty file
    with open('/proc/cmdline', 'w') as f:
        f.write('foo bar=baz=bat')
        f.close()

    collected_facts = {'cmdline': {'foo': True, 'bar': 'baz=bat'},
                       'proc_cmdline': {'foo': True, 'bar': 'baz=bat'}}
    assert collector.collect(None, collected_facts) == collected_facts

    # Test non-empty file with multiple values

# Generated at 2022-06-23 00:52:09.238410
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector.cmdline import CmdLineFactCollector
    file_data = "root=/dev/sda1 rd_NO_LUKS rd_NO_MD quiet LANG=en_US.UTF-8 rd_NO_DM quiet"
    obj = CmdLineFactCollector()
    obj._get_proc_cmdline = lambda : file_data
    obj.collect()
    cmdline_facts = obj.collect()
    assert cmdline_facts['cmdline']['root'] == '/dev/sda1'
    assert cmdline_facts['cmdline']['quiet'] is True
    assert cmdline_facts['cmdline']['LANG'] == 'en_US.UTF-8'

# Generated at 2022-06-23 00:52:11.707234
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'

# Generated at 2022-06-23 00:52:20.418831
# Unit test for method collect of class CmdLineFactCollector

# Generated at 2022-06-23 00:52:22.766415
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    test_obj = CmdLineFactCollector()
    assert test_obj.name == "cmdline"
    assert test_obj._fact_ids == set()


# Generated at 2022-06-23 00:52:30.436926
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import unittest.mock as mock

    # Test for missing /proc/cmdline file
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector._get_proc_cmdline = mock.MagicMock(return_value=None)

    facts = cmdline_collector.collect()

    cmdline_collector._get_proc_cmdline.assert_called_once_with()
    assert facts == {}

    # Test for presence of /proc/cmdline file
    cmdline_collector = CmdLineFactCollector()

# Generated at 2022-06-23 00:52:41.202552
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    cmdline_dict = {'ro': True, 'quiet': True, 'splash': True, 'initrd': '/boot/initrd.img-3.11.0-15-generic', 'BOOT_IMAGE': '/boot/vmlinuz-3.11.0-15-generic', 'root': '/dev/mapper/ubuntu--vg-root', 'module': '/lib/firmware', 'init': '/sbin/init', 'MODULES': 'dep'}

# Generated at 2022-06-23 00:52:45.628269
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()

    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()
    assert isinstance(cmdline_collector, BaseFactCollector)

# Generated at 2022-06-23 00:52:47.871117
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'


# Generated at 2022-06-23 00:52:50.966982
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()


# Generated at 2022-06-23 00:53:02.424523
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    '''
    Test CmdLineFactCollector.collect
    '''

    import StringIO

    # prep the mock
    proc_cmdline_data = "root=/dev/vda1 ro console=ttyS0,115200n8 selinux=0 nokaslr"

    mocked_get_file_content = StringIO.StringIO(proc_cmdline_data)

    saved_get_file_content = fact_collector.get_file_content

    fact_collector.get_file_content = lambda x: mocked_get_file_content.read()

    # execute the method
    result = fact_collector.collect()

    # Make assertions

# Generated at 2022-06-23 00:53:10.594407
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_dict = {}
    cmdline_dict['cmdline'] = {'root': '/dev/sda1', 'rootdelay': '10', 'quiet': 'True', 'rd_NO_LUKS': 'True', 'rd_NO_MD': 'True', 'rd_NO_DM': 'True', 'LANG': 'en_US.UTF-8', 'SYSFONT': 'latarcyrheb-sun16'}


# Generated at 2022-06-23 00:53:11.041114
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    pass

# Generated at 2022-06-23 00:53:15.229551
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    '''Test CmdLineFactCollector.collect method.
    '''

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import collector


# Generated at 2022-06-23 00:53:26.448445
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    c = CmdLineFactCollector()

    output_data = 'root=/dev/mapper/vg_root-lv_root rd_NO_LUKS rd_NO_MD rd_NO_DM LANG=en_US.UTF-8 SYSFONT=latarcyrheb-sun16 KEYBOARDTYPE=pc KEYTABLE=us crashkernel=auto  rhgb quiet'

# Generated at 2022-06-23 00:53:35.763525
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    module = None
    collected_facts = None

    fake_content = 'BOOT_IMAGE=/vmlinuz-3.10.0-514.21.1.el7.x86_64 ' + \
                   'root=/dev/mapper/rhel-root ro rd.lvm.lv=rhel/root ' + \
                   'rd.lvm.lv=rhel/swap crashkernel=auto rd.lvm.lv=rhel/tmp ' + \
                   'rd.lvm.lv=rhel/var ' + \
                   'rhgb quiet LANG=en_US.UTF-8 console=ttyS0,19200n8'

    facts = collector.collect(module, collected_facts)

# Generated at 2022-06-23 00:53:37.506967
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'

# Generated at 2022-06-23 00:53:44.582236
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_fact_collector = CmdLineFactCollector()
    cmdline_facts = cmdline_fact_collector.collect()
    assert cmdline_facts['cmdline']
    assert cmdline_facts['proc_cmdline']

# Generated at 2022-06-23 00:53:47.232513
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    myCmdLineFactCollector = CmdLineFactCollector()
    assert myCmdLineFactCollector

# Generated at 2022-06-23 00:53:48.187705
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector()


# Generated at 2022-06-23 00:53:49.659285
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert cmdline


# Generated at 2022-06-23 00:53:52.066252
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert cmdline.name is not None
    assert cmdline._fact_ids is not None

# Generated at 2022-06-23 00:53:53.497401
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'

# Generated at 2022-06-23 00:54:00.914837
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Get a CmdLineFactCollector instance
    cmdline_fact_collector = CmdLineFactCollector()

    # Read content of /proc/cmdline
    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = lambda: None
        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            return executable

    fake_module = FakeModule()
    content = cmdline_fact_collector._get_proc_cmdline()

    # Get cmdline facts
    cmdline_facts = cmdline_fact_collector.collect(module=fake_module)

    # Parse content of /proc/cmdline for proc_cmdline and cmdline
    proc_cmdline = cmdline_fact_collector._parse_proc_

# Generated at 2022-06-23 00:54:03.931611
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Positive test case
    assert CmdLineFactCollector.name == 'cmdline'

    # Negative test case
    assert CmdLineFactCollector.name != 'cmdline1'


# Generated at 2022-06-23 00:54:08.568825
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts_collector = CmdLineFactCollector()
    cmdline_facts = cmdline_facts_collector.collect()
    assert 'cmdline' in cmdline_facts
    assert 'proc_cmdline' in cmdline_facts
    assert isinstance(cmdline_facts['cmdline'], dict)
    assert isinstance(cmdline_facts['proc_cmdline'], dict)

# Generated at 2022-06-23 00:54:19.584271
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """Unit test for the CmdLineFactCollector.collect function"""
    def test_cases(cmdline_data, expected_cmdline, expected_proc_cmdline):
        """Test cases to be run against the test method"""

# Generated at 2022-06-23 00:54:30.384697
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    import os

    class TestCmdLineFactCollector(CmdLineFactCollector):
        def _get_proc_cmdline(self):
            return "biosdevname=0 net.ifnames=0 ip=192.168.1.151::192.168.1.1:255.255.255.0:test-rocky-a-2-a-2.3.4.5.6.7.8.9.unittest.invalid:enp2s0f0:off ipv6.disable_ipv6=1 initrd=initrd.img-4.4.0-1032-gcp quiet"

    x = TestCmdLineFactCollector()
    expected = {}


# Generated at 2022-06-23 00:54:33.820819
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    fact_collector = CmdLineFactCollector(None)
    fact_collector.collect()

# Generated at 2022-06-23 00:54:40.275056
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    class DummyModule():
        def __init__(self):
            self.params = {}
    class DummyFacts():
        def __init__(self):
            self.facts = {}

    cmdline_facts = CmdLineFactCollector().collect(DummyModule(), DummyFacts())
    assert isinstance(cmdline_facts['cmdline'], dict)
    assert isinstance(cmdline_facts['proc_cmdline'], dict)

# Generated at 2022-06-23 00:54:48.425619
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    temp_test_data = \
        'root=UUID=1f8b96a7-ce5c-43cb-adcc-9aa6f7bbfd84 ro tsc=reliable'
    CmdLineFactCollector._get_proc_cmdline = \
        lambda x: temp_test_data
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline'] == {'root': 'UUID=1f8b96a7-ce5c-43cb-'
                                        'adcc-9aa6f7bbfd84', 'ro': True,
                                        'tsc': 'reliable'}

# Generated at 2022-06-23 00:54:58.477892
# Unit test for method collect of class CmdLineFactCollector

# Generated at 2022-06-23 00:55:03.605201
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.fact_cache import FactCache
    Collector.initialize()

    collector = FactCache().get_collector('CmdLineFactCollector')

    collected_facts = collector.collect()

    assert collected_facts['cmdline'] == {}
    assert collected_facts['proc_cmdline'] == {}


# Generated at 2022-06-23 00:55:06.360696
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'
    assert obj._fact_ids == set()

# Generated at 2022-06-23 00:55:10.269760
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cf = CmdLineFactCollector
    assert cf.name == 'cmdline'
    assert not cf._fact_ids

# Generated at 2022-06-23 00:55:13.084227
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.path == '/proc/cmdline'
    assert c.name == 'cmdline'


# Generated at 2022-06-23 00:55:21.077220
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Create object of class CmdLineFactCollector
    cmdline_fact_collector_instance = CmdLineFactCollector()
    # Create the data of file to load
    data = 'abc=1234 def test'
    # To replace the method _get_proc_cmdline by a mock
    cmdline_fact_collector_instance._get_proc_cmdline = lambda: data
    # To replace the method _parse_proc_cmdline by a mock
    cmdline_fact_collector_instance._parse_proc_cmdline = lambda data: {'test': True}
    # To replace the method _parse_proc_cmdline_facts by a mock
    cmdline_fact_collector_instance._parse_proc_cmdline_facts = lambda data: {'abc': '1234', 'def': True, 'test': True}



# Generated at 2022-06-23 00:55:32.188392
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collectors.base import collect_all
    from ansible.module_utils.facts.collectors.cmdline import CmdLineFactCollector
    from ansible.module_utils._text import to_bytes
    import json

    # create a fake Collector class with a _get_file_content method that returns a string
    cmdline_content = 'fake_data'
    class FakeCollector(Collector):
        def _get_file_content(self, key):
            if key == 'cmdline':
                return cmdline_content
            return super(FakeCollector, self)._get_file_content(key)

    # reset the CmdLineFact

# Generated at 2022-06-23 00:55:35.164032
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    with open('/proc/cmdline','w') as f:
        f.write('a=1 b=2 c=3')
    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'


# Generated at 2022-06-23 00:55:41.796817
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    test_cmdline = 'cmdline_test1 cmdline_test2=test3 cmdline_test4 cmdline_test5=test6 cmdline_test7=test8'
    test_cmdline_dict = {'cmdline_test1': True, 'cmdline_test2': 'test3', 'cmdline_test4': True,
        'cmdline_test5': 'test6', 'cmdline_test7': 'test8'}
    test_fact_dict = {'cmdline': test_cmdline_dict,
        'proc_cmdline': {'cmdline_test1': True, 'cmdline_test2': 'test3', 'cmdline_test4': True,
        'cmdline_test5': ['test6', 'test8'], 'cmdline_test7': ['test8']}}

    collector = C

# Generated at 2022-06-23 00:55:50.699942
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_fact_collector = CmdLineFactCollector()
    cmdline_facts = cmdline_fact_collector.collect()
    assert 'cmdline' in cmdline_facts
    assert 'proc_cmdline' in cmdline_facts
    assert isinstance(cmdline_facts['cmdline'], dict)
    assert isinstance(cmdline_facts['proc_cmdline'], dict)
    assert isinstance(cmdline_facts['proc_cmdline']['root'], str)
    assert isinstance(cmdline_facts['proc_cmdline']['ro'], bool)

# Generated at 2022-06-23 00:55:54.783058
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    output = collector.collect()
    # As mentioned in docs, classname attribute isn't available for instantiated classes
    assert output['cmdline']['classname'] == 'CmdLineFactCollector'

# Generated at 2022-06-23 00:55:56.487051
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector.collect()

# Generated at 2022-06-23 00:55:58.846497
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert cmdline.name == 'cmdline'
    assert cmdline._fact_ids == set()

# Generated at 2022-06-23 00:56:08.784764
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # For testing purpose, create a class containing the method collect
    class TestClass:
        def collect(self):
            return {
                'cmdline': { 'rhel': 7, 'ro': True, 'quiet': True, 'audit=0': True, 'S': True },
                'proc_cmdline': { 'rhel': 7, 'ro': True, 'quiet': True, 'audit=0': True, 'S': True },
            }

    # Create an instance of the class
    test_class_instance = TestClass()

    # Create an instance of the collector class
    cmdline_fact_collector = CmdLineFactCollector(None)

    # Check if the result is as expected
    assert cmdline_fact_collector.collect() == test_class_instance.collect()

# Generated at 2022-06-23 00:56:12.113694
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts import FactCollector

    fact_collector = FactCollector(None)
    fact_collector._load_collectors()
    fact_collector.collect(None, None)


# Generated at 2022-06-23 00:56:16.187328
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    """
        Unit test for constructor of class CmdLineFactCollector.
    """
    cmdline_fact_collector = CmdLineFactCollector()
    assert(cmdline_fact_collector is not None)

# Generated at 2022-06-23 00:56:18.721544
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    """Check initialization of the instance of class CmdLineFactCollector."""
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector is not None

# Generated at 2022-06-23 00:56:24.818876
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import FactCollector
    import sys
    import json

    CmdLineFactCollector.collect()

    collected_facts = CmdLineFactCollector.collect()
    if sys.version_info[0] < 3:
        print(json.dumps(collected_facts))
    else:
        print(json.dumps(collected_facts,indent=2, sort_keys=True))



# Generated at 2022-06-23 00:56:29.110761
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fc = CmdLineFactCollector()
    assert cmdline_fc.name == 'cmdline'


# Generated at 2022-06-23 00:56:31.198826
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector != None

# Generated at 2022-06-23 00:56:42.380319
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """ Test method collect for the class CmdLineFactCollector """

    from ansible.module_utils.facts.utils import FactsParams

    params = FactsParams()
    facts_collector = CmdLineFactCollector(params)

    collected_facts = facts_collector.collect()

    cmdline_content = get_file_content('/proc/cmdline')
    cmdline_dict = {}
    proc_cmdline_facts = {}

# Generated at 2022-06-23 00:56:45.291008
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'


# Generated at 2022-06-23 00:56:48.682533
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = CmdLineFactCollector()
    assert cmdline_facts.name == 'cmdline'
    assert cmdline_facts._fact_ids == set()

    assert not cmdline_facts.collect()


# Generated at 2022-06-23 00:56:49.188145
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    pass

# Generated at 2022-06-23 00:56:50.946477
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'

# Generated at 2022-06-23 00:56:58.805660
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    cmdline_facts = {}
    cmdline_facts['cmdline'] = {}
    cmdline_facts['proc_cmdline'] = {}

    proc_cmdline = ""
    cmdline = ""
    split_proc_cmdline = [""]

    _collector = CmdLineFactCollector()
    _collector._get_proc_cmdline = lambda : get_file_content(proc_cmdline)
    _collector._parse_proc_cmdline = lambda data : shlex.split(data, posix=False)
    _collector._parse_proc_cmdline_facts = lambda data : shlex.split(data, posix=False)

    # Test case with no cmdline data
    collected_facts = _collector.collect()
    assert collected_facts == cmdline_facts

    # Test case with no cmdline data


# Generated at 2022-06-23 00:57:04.847310
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    c = CmdLineFactCollector()
    result = c.collect()
    assert isinstance(result, dict)
    assert 'cmdline' in result
    assert isinstance(result['cmdline'], dict)
    assert 'proc_cmdline' in result
    assert isinstance(result['proc_cmdline'], dict)

# Generated at 2022-06-23 00:57:14.467085
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import os
    import stat
    import shutil
    import tempfile
    import pytest
    import ansible.module_utils.facts.collectors.cmdline as cmdline

    tempdir = tempfile.mkdtemp()

    # No proc cmdline
    test_obj = cmdline.CmdLineFactCollector()
    assert test_obj.collect() == {}

    # Create proc cmdline file
    cmdline_file = os.path.join(tempdir, 'cmdline')

# Generated at 2022-06-23 00:57:19.458927
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_fact_collector = CmdLineFactCollector()
    ret = cmdline_fact_collector.collect(collected_facts={})
    assert ret['cmdline'] == {'console': 'ttyS0,4'}
    assert ret['proc_cmdline'] == {'console': 'ttyS0,4'}

# Generated at 2022-06-23 00:57:26.057558
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    proc_cmdline_data = 'ansible_test=hi ansible_test=true'
    expected_collect = {'cmdline': {'ansible_test': 'true'},
                        'proc_cmdline': {'ansible_test': ['hi', 'true']}}
    test_obj = CmdLineFactCollector()
    test_obj._get_proc_cmdline = lambda: proc_cmdline_data
    ret_val = test_obj.collect()
    assert ret_val == expected_collect


# Generated at 2022-06-23 00:57:28.914528
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector(None)
    assert obj.name == "cmdline"
    assert obj._fact_ids == set()

# Generated at 2022-06-23 00:57:38.595469
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """The cmdline collector collect method returns a dict with cmdline and proc_cmdline keys."""
    fake_module = None
    fake_collected_facts = None

    fake_data = "foo=bar baz=ansible"

    class FakeCmdLineFactCollector(CmdLineFactCollector):
        def _get_proc_cmdline(self):
            return fake_data

    c = FakeCmdLineFactCollector(fake_module)
    cmdline_facts = c.collect(fake_module, fake_collected_facts)
    assert 'cmdline' in cmdline_facts
    assert cmdline_facts['cmdline']['foo'] == 'bar'
    assert cmdline_facts['cmdline']['baz'] == 'ansible'
    assert 'proc_cmdline' in cmdline_facts
    assert cmdline_

# Generated at 2022-06-23 00:57:49.729867
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.cmdline import CmdLineFactCollector

    class MockModule:
        class params:
            pass

        def fail_json(self, msg):
            pass
        def set_fact(self, key, value):
            pass

    class MockFactCollector(BaseFactCollector):
        def __init__(self, collector_name, module, collected_facts=None):
            super(MockFactCollector, self).__init__(collector_name, module, collected_facts=collected_facts)
        def collect(self, module=None, collected_facts=None):
            return {}


# Generated at 2022-06-23 00:58:01.098695
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts.utils import AnsibleFallbackNotFound

    # test1: no data
    data = None
    cmdline_facts = CmdLineFactCollector().collect(None, None)
    assert len(cmdline_facts) == 0

    # test2: data
    data = 'rootwait root=/dev/sda1 rw  quiet LANG=en_US.UTF-8  KEYTABLE=us SYSFONT=latarcyrheb-sun16 console=tty5 console=ttyS1,115200n8 console=tty0'
    cmdline_facts = CmdLineFactCollector().collect(None, None)
    assert len(cmdline_facts) == 2
    assert cmdline_facts['cmdline'] == CmdLineFactCollector()._parse_proc_cmdline(data)
