

# Generated at 2022-06-23 00:48:04.238121
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    with open('/proc/cmdline', 'w') as f:
        f.write('metric=5 gram=9\n')
    assert(CmdLineFactCollector()._get_proc_cmdline() == 'metric=5 gram=9\n')
    assert(CmdLineFactCollector()._parse_proc_cmdline_facts('metric=5 gram=9') == {'metric': '5', 'gram': '9'})
    assert(CmdLineFactCollector()._parse_proc_cmdline('metric=5 gram=9') == {'metric': '5', 'gram': '9'})

# Generated at 2022-06-23 00:48:15.242073
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    # Simulate /proc/cmdline content
    test_proc_cmdline_content = 'BOOT_IMAGE=/vmlinuz-3.10.0-514.26.2.el7.x86_64 root=/dev/mapper/rhel-root ro crashkernel=auto rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet LANG=en_US.UTF-8'

    class ModuleMock:
        def __init__(self, arg):
            pass

    class TestCmdLineFactCollector(CmdLineFactCollector):
        def _get_proc_cmdline(self):
            return test_proc_cmdline_content

    test_collector = TestCmdLineFactCollector(ModuleMock(None))


# Generated at 2022-06-23 00:48:24.581154
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # mock collector instance
    collector = CmdLineFactCollector()

    # mock parse_proc_cmdline
    def mock_parse_proc_cmdline(data):
        cmdline_dict = {}
        try:
            for piece in shlex.split(data, posix=False):
                item = piece.split('=', 1)
                if len(item) == 1:
                    cmdline_dict[item[0]] = True
                else:
                    cmdline_dict[item[0]] = item[1]
        except ValueError:
            pass

        return cmdline_dict

    collector._parse_proc_cmdline = mock_parse_proc_cmdline

    # mock parse_proc_cmdline_facts
    def mock_parse_proc_cmdline_facts(data):
        cmdline_dict = {}

# Generated at 2022-06-23 00:48:27.197948
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    """This function can be used to test the constructor of class CmdLineFactCollector."""
    clfc = CmdLineFactCollector()
    assert clfc.name == 'cmdline'



# Generated at 2022-06-23 00:48:31.788258
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector_instance = CmdLineFactCollector()
    assert cmdline_collector_instance.name == 'cmdline'
    assert len(cmdline_collector_instance._fact_ids) == 0



# Generated at 2022-06-23 00:48:33.996937
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()

    assert collector.name == 'cmdline'
    assert collector._fact_ids == set()


# Generated at 2022-06-23 00:48:37.853704
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids is not None
    _CmdLineFactCollector = CmdLineFactCollector()
    assert isinstance(_CmdLineFactCollector, CmdLineFactCollector)

# Generated at 2022-06-23 00:48:48.609469
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    '''
    Test return of collect method of class CmdLineFactCollector
    '''

    # Test successful collect
    cmdline_facts = {'cmdline':{'BOOT_IMAGE':'/vmlinuz-4.4.0-62-generic','console':'ttyS0'},
                     'proc_cmdline':{'BOOT_IMAGE':'/vmlinuz-4.4.0-62-generic','console':['ttyS0','ttyS1']}
                     }
    c = CmdLineFactCollector()
    assert c.collect() == cmdline_facts

    # Test unsuccessful collect
    with open('/proc/cmdline', 'w') as f:
        f.write('BOOT_IMAGE=/vmlinuz-4.4.0-62-generic console=ttyS0,ttyS1')


# Generated at 2022-06-23 00:48:51.551852
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'
    assert obj._fact_ids == set()


# Generated at 2022-06-23 00:48:58.665076
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    test_object = CmdLineFactCollector()
    assert test_object
    assert isinstance(test_object, BaseFactCollector)
    assert test_object.name == 'cmdline'
    assert test_object._fact_ids == set()


# Generated at 2022-06-23 00:49:04.031376
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    cmdline_facts = cmdline_collector.collect()
    assert isinstance(cmdline_facts, dict)
    assert cmdline_facts['cmdline'] is not None
    assert isinstance(cmdline_facts['cmdline'], dict)
    assert cmdline_facts['proc_cmdline'] is not None
    assert isinstance(cmdline_facts['proc_cmdline'], dict)

# Generated at 2022-06-23 00:49:06.322043
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'
    assert collector.priority == 8
    assert collector._fact_ids == set()

# Generated at 2022-06-23 00:49:08.650532
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'

# Unit test to check _get_proc_cmdline() method

# Generated at 2022-06-23 00:49:13.051123
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector_obj = CmdLineFactCollector()
    result = cmdline_fact_collector_obj.collect()
    assert result.keys() == ['cmdline', 'proc_cmdline']


# Generated at 2022-06-23 00:49:13.886342
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert True

# Generated at 2022-06-23 00:49:25.206827
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    with open("../../../lib/ansible/module_utils/facts/proc_cmdline.txt") as f:
        cmdline_collector._get_proc_cmdline = lambda: f.read()

    cmdline_facts = cmdline_collector.collect()


# Generated at 2022-06-23 00:49:35.473425
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    c = CmdLineFactCollector()
    get_file_content_mock = c._get_proc_cmdline
    get_file_content_mock.return_value = 'BOOT_IMAGE=vmlinuz-4.2.0-1.fc23.x86_64 root=/dev/mapper/fedora-root ro rd.lvm.lv=fedora/root rd.lvm.lv=fedora/swap rhgb quiet LANG=en_US.UTF-8'

# Generated at 2022-06-23 00:49:46.114832
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    module = None
    collected_facts = None
    cmdline_facts = None

    # Testing with empty output
    cmdline_collector.get_file_content = lambda: ''
    cmdline_facts = cmdline_collector.collect(module, collected_facts)
    assert cmdline_facts == {}

    # Testing with non-empty output
    cmdline_collector.get_file_content = lambda: 'test_arg=test_val'
    cmdline_facts = cmdline_collector.collect(module, collected_facts)
    assert cmdline_facts == {'cmdline': {'test_arg': 'test_val'}, 'proc_cmdline': {'test_arg': 'test_val'}}


# Collect cmdline
cmdline_collector = CmdLineFactCollector()

# Generated at 2022-06-23 00:49:49.430601
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts_collector = CmdLineFactCollector()
    assert cmdline_facts_collector.name == "cmdline"
    assert cmdline_facts_collector._fact_ids == set()


# Generated at 2022-06-23 00:49:55.438716
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cf = CmdLineFactCollector()
    collected_facts = cf.collect(module=None, collected_facts=None)
    assert collected_facts['cmdline']['root'] == '/dev/sda2', "cmdline['root'] == '/dev/sda2' failed"
    assert collected_facts['proc_cmdline']['root'] == '/dev/sda2', "proc_cmdline['root'] == '/dev/sda2' failed"

# Generated at 2022-06-23 00:49:56.954107
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()

# Generated at 2022-06-23 00:50:00.055528
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    cmdline_facts = collector.collect()
    assert isinstance(cmdline_facts, dict)
    assert 'cmdline' in cmdline_facts
    assert isinstance(cmdline_facts['cmdline'], dict)
    assert 'proc_cmdline' in cmdline_facts
    assert isinstance(cmdline_facts['proc_cmdline'], dict)


# Generated at 2022-06-23 00:50:10.776265
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    with open('test/cmdline', 'r') as test_file:
        cmdline_content = test_file.read().strip()

    class MockFile(object):
        def read(self, *args, **kwargs):
            return cmdline_content

    cmdline_collector = CmdLineFactCollector()
    cmdline_collector.get_file_content = lambda *args, **kwargs: MockFile().read()

    cmdline_facts = cmdline_collector.collect()


# Generated at 2022-06-23 00:50:22.331045
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = {}
    data = 'root=LABEL=/ console=ttyS1,38400n8 console=tty0 ipv6.disable=1'
    cmdline_facts['cmdline'] = {'root': 'LABEL=/', 'console': True, 'ipv6.disable': '1'}
    cmdline_facts['proc_cmdline'] = {'root': 'LABEL=/', 'console': ['ttyS1', '38400n8', 'tty0'], 'ipv6.disable': '1'}

    collector = CmdLineFactCollector()
    cmdline = collector._parse_proc_cmdline(data)
    cmdline_with_dup = collector._parse_proc_cmdline_facts(data)

    assert cmdline == cmdline_facts['cmdline']
    assert cmdline_with_

# Generated at 2022-06-23 00:50:24.419192
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    f = CmdLineFactCollector()
    assert f.collect() is not None, "CmdLineFactCollector did not return data"

# Generated at 2022-06-23 00:50:26.823011
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert cmdline.name == 'cmdline'
    assert cmdline._fact_ids == set()


# Generated at 2022-06-23 00:50:37.900987
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    # Import libs, setup mocks for this test
    import os
    import random
    import unittest.mock as mock
    import ansible.module_utils.facts.utils as utils

    # Mock the following methods of class CmdLineFactCollector
    @mock.patch.object(CmdLineFactCollector, '_get_proc_cmdline', autospec=True)
    def test_collect(self, get_proc_cmdline_mock):
        # Setup test values
        fake_module = random.choice(['/proc/cmdline', 'fake file path'])
        fake_facts = {}
        fake_cmdline_facts_keys = ['cmdline', 'proc_cmdline']
        fake_cmdline_facts = {}

        # Generate fake data

# Generated at 2022-06-23 00:50:47.658802
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    def test_file_content(path):
        if path == '/proc/cmdline':
            return 'root=UUID=281f6a8f-7f26-49bf-b180-3f2e8de1c41b ro console=tty1 console=ttyS0,115200n8'
        return
    c = CmdLineFactCollector()
    c.get_file_content = test_file_content
    result = c.collect()

# Generated at 2022-06-23 00:50:49.242769
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c
    assert c.name == 'cmdline'

# Generated at 2022-06-23 00:50:51.004725
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    c = CmdLineFactCollector()
    assert c.collect()['proc_cmdline']['dns'] == ['10.0.0.1']

# Generated at 2022-06-23 00:51:03.320978
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    collected_facts = {}

    # Testing empty file
    with open('/tmp/cmdline_test_empty', 'w+') as cmdline_test_empty:
        cmdline_test_empty.write("")
    cmdline_collector._get_proc_cmdline = lambda: get_file_content('/tmp/cmdline_test_empty')
    cmdline_facts = cmdline_collector.collect(collected_facts=collected_facts)
    assert not cmdline_facts

    # Testing some parameters
    with open('/tmp/cmdline_test_some_params', 'w+') as cmdline_test_some_params:
        cmdline_test_some_params.write(" param1=abc param2=def param3=ghi")
    cmd

# Generated at 2022-06-23 00:51:04.576780
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()

# Generated at 2022-06-23 00:51:11.714565
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    cmdline_fact_collector = CmdLineFactCollector()

    collected_facts = {'ansible_architecture': 'x86_64'}
    
    # test cmdline facts
    cmdline_facts = cmdline_fact_collector.collect(collected_facts=collected_facts)
    assert cmdline_facts['cmdline'] == {'acpi_enforce_resources': 'lax'}

# Generated at 2022-06-23 00:51:20.132742
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    proc_cmdline_actual = {
        'BOOT_IMAGE': 'vmlinuz-4.2.0-42-generic',
        'console': True,
        'cryptopts': 'target=luks,source=/dev/sda1',
        'elevator': 'noop',
        'initrd': 'initrd.img-4.2.0-42-generic',
        'ip': '169.254.179.241:::255.255.255.0:vagrant-ubuntu-trusty-64:eth0:none',
        'ipv6.disable': True,
        'net.ifnames': True,
        'quiet': True,
        'ro': True,
        'signal': True,
        'splash': True,
        'vga': '0x317'
    }

   

# Generated at 2022-06-23 00:51:23.894564
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cf = CmdLineFactCollector()
    assert cf.name == 'cmdline'


# Generated at 2022-06-23 00:51:28.450330
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids is not None
    assert len(CmdLineFactCollector._fact_ids) == 0
    assert isinstance(CmdLineFactCollector._fact_ids, set)


# Generated at 2022-06-23 00:51:39.222014
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """Test CmdLineFactCollector._parse_proc_cmdline"""
    data = 'rw ipv6.disable=1 BOOT_IMAGE=/vmlinuz-4.4.0-81-generic ' \
           'root=/dev/mapper/ubuntu--vg-root ro quiet splash ' \
           'vconsole.keymap=us vconsole.font=latarcyrheb-sun16 ' \
           '$vt_handoff'

# Generated at 2022-06-23 00:51:41.668659
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'
    assert collector._fact_ids == set()


# Generated at 2022-06-23 00:51:43.911071
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'
    assert collector._fact_ids == set()


# Generated at 2022-06-23 00:51:44.933391
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()


# Generated at 2022-06-23 00:51:48.511943
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    collected_facts = collector.collect()
    assert isinstance(collected_facts['cmdline'], dict)
    assert isinstance(collected_facts['proc_cmdline'], dict)

# Generated at 2022-06-23 00:51:59.197685
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    content_cmdline = 'resume1=UUID=b14ef4e4-3d2e-4ccc-a0cb-8c3de2107a5e resume2=UUID=0c0488c9-71d7-41c1-8037-26b0953aec0e rhgb quiet'
    content_proc_cmdline = 'resume1=UUID=b14ef4e4-3d2e-4ccc-a0cb-8c3de2107a5e resume2=UUID=0c0488c9-71d7-41c1-8037-26b0953aec0e rhgb quiet'

    obj = CmdLineFactCollector(module=None, collected_facts=None)
    obj._get_proc_cmdline = lambda: content_cmdline

# Generated at 2022-06-23 00:52:04.085067
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdlinefact = CmdLineFactCollector()
    assert cmdlinefact.name == 'cmdline'
    assert cmdlinefact.priority == 30
    assert cmdlinefact._fact_ids == set()


# Generated at 2022-06-23 00:52:15.175925
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    class Module(object):
        def __init__(self, params=None):
            self.params = params

    import json

    # are we working on Linux?
    # skip this test if not
    import platform
    if platform.system() != 'Linux':
        print('test_CmdLineFactCollector_collect was skipped because it only runs on Linux')
        return

    # fake test data
    cmdline = "BOOT_IMAGE=/vmlinuz-4.14.15-200.fc26.x86_64 root=/dev/mapper/fedora-root ro rd.lvm.lv=fedora/root rd.lvm.lv=fedora/swap rhgb quiet LANG=en_US.UTF-8"

    # create a CmdLineFactCollector object to test
    tester = CmdLineFactCollect

# Generated at 2022-06-23 00:52:18.715711
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'
    assert obj._fact_ids == set()

# Unit test to ensure object of class CmdLineFactCollector
# returns empty dictionary as /proc/cmdline file is not available

# Generated at 2022-06-23 00:52:20.414606
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdLineFactCollector = CmdLineFactCollector()
    assert cmdLineFactCollector is not None

# Generated at 2022-06-23 00:52:22.822866
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert isinstance(obj, CmdLineFactCollector)

# Generated at 2022-06-23 00:52:31.639090
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    ansible_facts = {}

# Generated at 2022-06-23 00:52:33.158574
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    c = CmdLineFactCollector()

    assert c.collect() == {}

# Generated at 2022-06-23 00:52:34.717728
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    x = CmdLineFactCollector()
    assert x.name == 'cmdline'

# Generated at 2022-06-23 00:52:41.439197
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """Unit test for method collect of class CmdLineFactCollector"""

    # Use a mock for the _get_proc_cmdline method
    def __get_proc_cmdline():
        return 'root=/dev/mapper/VolGroup00-LogVol00 ro rhgb quiet'

    # Set the mock
    CmdLineFactCollector._get_proc_cmdline = __get_proc_cmdline

    # Call the tested method
    cmdline_facts = CmdLineFactCollector().collect()

    # Check results

# Generated at 2022-06-23 00:52:45.294692
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-23 00:52:46.824706
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdLine=CmdLineFactCollector()
    assert cmdLine is not None

# Generated at 2022-06-23 00:52:54.449487
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    data = '''
BOOT_IMAGE=/boot/vmlinuz-4.9.16-202.fc25.x86_64 root=UUID=6a8f6180-16ca-4e5f-9a9a-a082eebae50d ro quiet SYSFONT=latarcyrheb-sun16 rhgb crashkernel=auto LANG=en_US.UTF-8
'''

# Generated at 2022-06-23 00:53:00.332906
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts_collector = CmdLineFactCollector()
    cmdline_facts = cmdline_facts_collector.collect()
    assert isinstance(cmdline_facts, dict)
    assert isinstance(cmdline_facts['cmdline'], dict)
    assert isinstance(cmdline_facts['proc_cmdline'], dict)

# Generated at 2022-06-23 00:53:09.460478
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    ''' Unit test for method collect of class CmdLineFactCollector '''
    cmdline_collector = CmdLineFactCollector()
    cmdline_collector._get_proc_cmdline = lambda: 'BOOT_IMAGE=/vmlinuz-4.4.0-36-generic root=UUID=81f94b7e-1424-4b7a-bf2c-cf7d80acd5a5 ro quiet splash vt.handoff=7'

# Generated at 2022-06-23 00:53:11.797988
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    print ("Executing Test Constructor of Class CmdLineFactCollector")
    obj = CmdLineFactCollector()
    assert(obj.name == "cmdline")



# Generated at 2022-06-23 00:53:13.915472
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == "cmdline"
    assert cmdline_collector._fact_ids == set()

# Generated at 2022-06-23 00:53:25.694557
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collectorclass_instances
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import CmdLineFactCollector

    collector._COLLECTORS.update({
        'cmdline': ('ansible.module_utils.facts.cmdline', 'CmdLineFactCollector')
    })

    collector._COLLECTOR_BASE_DIRS.append(
        '/Users/chua/git/ansible_for_dev/ansible/module_utils/facts')

    get_collectorclass_instances()


# Generated at 2022-06-23 00:53:28.365963
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert cmdline.name == 'cmdline'
    assert cmdline._fact_ids == set()


# Generated at 2022-06-23 00:53:29.824943
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector is not None

# Generated at 2022-06-23 00:53:31.253720
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert cmdline is not None


# Generated at 2022-06-23 00:53:34.701562
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    """
    Constructor of class CmdLineFactCollector shall initialize the
    attributes as per the arguments given.
    """
    assert CmdLineFactCollector().name == 'cmdline'
    assert CmdLineFactCollector()._fact_ids == set()


# Generated at 2022-06-23 00:53:38.327656
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    # Creating instance
    cmdline_module = CmdLineFactCollector()

    # Call method collect
    cmdline_module.collect()

# Unit test

# Generated at 2022-06-23 00:53:43.691546
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cf = CmdLineFactCollector()
    assert isinstance(cf, BaseFactCollector)

# Generated at 2022-06-23 00:53:48.776682
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collect = CmdLineFactCollector()

    result = collect._get_proc_cmdline()
    assert result is not None

    result = collect._parse_proc_cmdline(result)
    assert result is not None

    result = collect._parse_proc_cmdline_facts(result)
    assert result is not None

    result = collect.collect()
    assert result is not None

# Generated at 2022-06-23 00:53:58.152148
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    cmdline_facts1 = CmdLineFactCollector()
    assert cmdline_facts1.collect({}) == {}

    cmdline_facts2 = CmdLineFactCollector()
    cmdline_facts2._get_proc_cmdline = lambda: "foo=bar"
    assert cmdline_facts2.collect({}) == {
        'cmdline': {'foo': 'bar'},
        'proc_cmdline': {'foo': 'bar'}
    }

    cmdline_facts3 = CmdLineFactCollector()
    cmdline_facts3._get_proc_cmdline = lambda: "foo=bar foo=baz"

# Generated at 2022-06-23 00:54:07.573448
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    data = 'root=/dev/sda rw console=tty0 console=ttyS0,9600n8'

    cmdline_expected = {
        'root': '/dev/sda',
        'rw': True,
        'console': 'ttyS0,9600n8'
    }

    cmdline_proc_expected = {
        'root': '/dev/sda',
        'rw': True,
        'console': ['tty0', 'ttyS0,9600n8']
    }

    cmdline_collector = CmdLineFactCollector()
    cmdline_collector._get_proc_cmdline = lambda: data
    cmdline_collector.collect()
    cmdline_facts = cmdline_collector.collect_facts()

    assert cmdline_facts['cmdline'] == cmdline_expected
   

# Generated at 2022-06-23 00:54:08.664397
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()

# Generated at 2022-06-23 00:54:11.370736
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert not CmdLineFactCollector._fact_ids
    assert CmdLineFactCollector._fact_ids.__class__ == set

# Generated at 2022-06-23 00:54:22.044765
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts import collector
    collected_facts = {}
    CmdLineFactCollector_instance = collector.CmdLineFactCollector()
    with pytest.raises(Exception):
        CmdLineFactCollector_instance.collect()
    with pytest.raises(Exception):
        CmdLineFactCollector_instance.collect(collected_facts=collected_facts)
    get_file_content_value = 'ansible ansible_user_id=my_user'
    get_file_content_return_value = {'ansible': True,
                                     'ansible_user_id': 'my_user'}

# Generated at 2022-06-23 00:54:24.038879
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    fc = CmdLineFactCollector()
    fc.collect()

# Generated at 2022-06-23 00:54:28.650876
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collect_cmdline = CmdLineFactCollector()
    assert collect_cmdline.name == 'cmdline'
    assert collect_cmdline.collect() == {}
    assert repr(collect_cmdline) == '<CmdLineFactCollector {}>'


# Generated at 2022-06-23 00:54:37.831226
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()

    # Testing that we find at least some of the expected keys
    assert 'cmdline' in cmdline_facts
    assert 'proc_cmdline' in cmdline_facts

    # Simply test that the cmdline key has some content in
    assert len(cmdline_facts['cmdline']) > 1
    assert len(cmdline_facts['proc_cmdline']) > 1

# Generated at 2022-06-23 00:54:40.119109
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert not c._fact_ids


# Generated at 2022-06-23 00:54:42.033000
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert cmdline.name == 'cmdline'

# Generated at 2022-06-23 00:54:44.549460
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    fact_collector_instance = CmdLineFactCollector()
    result = fact_collector_instance.collect()

    assert result['cmdline']
    assert result['proc_cmdline']

# Generated at 2022-06-23 00:54:49.139090
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import os
    import tempfile
    import unittest

    from ansible.module_utils.facts.collector import BaseFactCollector

    class CmdLineTestCase(unittest.TestCase):
        def setUp(self):
            self.tmp_file_fd, self.tmp_file_name = tempfile.mkstemp()

            # Create instance of CmdLineFactCollector
            self.cmdline_collector = CmdLineFactCollector()

            self.proc_cmdline_content_01 = "option01=value01 option02=value02 option03 option04=value04 option05"
            self.proc_cmdline_content_02 = "option01=value01 option02=value02 option03 option04=value04 option05=value05"


# Generated at 2022-06-23 00:54:53.565141
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c is not None
    assert c.name == 'cmdline'
    assert c._fact_ids == set()


# Generated at 2022-06-23 00:54:58.654059
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_obj = CmdLineFactCollector()
    assert cmdline_obj.name == 'cmdline'
    assert cmdline_obj.required_facts == set()
    assert cmdline_obj.priority == 10
    assert cmdline_obj._fact_ids == set()

# Generated at 2022-06-23 00:55:00.457743
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdlinefact = CmdLineFactCollector()
    assert isinstance(cmdlinefact, BaseFactCollector) == True

# Generated at 2022-06-23 00:55:01.445013
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector


# Generated at 2022-06-23 00:55:03.516168
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'
    assert obj._fact_ids == set()


# Generated at 2022-06-23 00:55:10.889401
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Arrange
    def get_proc_cmdline(self):
        return "ansible_facts=ansible_facts"

    def _parse_proc_cmdline(self, data):
        return data

    CmdLineFactCollector.get_proc_cmdline = get_proc_cmdline

    # Act
    cmdline_facts = CmdLineFactCollector._parse_proc_cmdline(None, "ansible_facts=ansible_facts")

    # Assert
    assert cmdline_facts['cmdline'] == "ansible_facts=ansible_facts"
    assert cmdline_facts['proc_cmdline'] == "ansible_facts=ansible_facts"

# Generated at 2022-06-23 00:55:19.847786
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    result = collector.collect(collected_facts=None)

# Generated at 2022-06-23 00:55:23.925960
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector.collect() == {}


# Generated at 2022-06-23 00:55:34.090038
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    '''Unit test for method collect of class CmdLineFactCollector'''
    CmdLineFactCollector._get_proc_cmdline = lambda: 'key1=val1 key2=val2 key3=val3'

    expected_result = {
        "cmdline": {
            "key1": "val1",
            "key2": "val2",
            "key3": "val3",
        },
        "proc_cmdline": {
            "key1": ["val1"],
            "key2": ["val2"],
            "key3": ["val3"],
        }
    }

    class FakeModule(object):
        def __init__(self):
            self.params = {}

    obj = CmdLineFactCollector(module=FakeModule())
    result = obj.collect()
    assert result == expected

# Generated at 2022-06-23 00:55:41.900917
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.cmdline import CmdLineFactCollector

    def mock_get_file_content(path):
        return 'rootwait\n'

    old_gfc = BaseFactCollector.get_file_content
    BaseFactCollector.get_file_content = mock_get_file_content

    actual = CmdLineFactCollector().collect()
    expected = {
        'cmdline': {
            'rootwait': True
        },
        'proc_cmdline': {
            'rootwait': True
        },
    }

    assert actual == expected

    BaseFactCollector.get_file_content = old_gfc

# Generated at 2022-06-23 00:55:43.050745
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()

# Generated at 2022-06-23 00:55:47.044989
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()

    cmdline_facts = collector.collect()

    if not cmdline_facts:
        print("cmdline_facts is empty")

    print("cmdline_facts = {}".format(cmdline_facts))

# Generated at 2022-06-23 00:55:55.107150
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    data = obj._get_proc_cmdline()
    assert data == 'BOOT_IMAGE=/foo/bar/baz '
    cmdline_dict = obj._parse_proc_cmdline(data)
    assert cmdline_dict['BOOT_IMAGE'] == '/foo/bar/baz'
    cmdline_dict = obj._parse_proc_cmdline_facts(data)
    assert cmdline_dict['BOOT_IMAGE'] == '/foo/bar/baz'

# Generated at 2022-06-23 00:55:56.731636
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert isinstance(obj, CmdLineFactCollector)

# Generated at 2022-06-23 00:56:01.807004
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """Test CmdLineFactCollector.collect()"""
    # Create instance of class under test
    cmd_line_facts_collector = CmdLineFactCollector()

    # Test collect method
    cmd_line_facts = cmd_line_facts_collector.collect()
    assert 'cmdline' in cmd_line_facts
    assert 'proc_cmdline' in cmd_line_facts

# Generated at 2022-06-23 00:56:04.373552
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = CmdLineFactCollector()
    assert cmdline_facts.name == 'cmdline'
    assert cmdline_facts._fact_ids == set()


# Generated at 2022-06-23 00:56:15.214356
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Disable pylint's invalid name test as the test names don't match the
    # required pylint test style.
    # pylint: disable=C0103
    test_base_path = os.path.join(os.path.dirname(__file__), 'unit', 'test_data', 'data_source')
    source_data = {
        'cmdline': {
            'test_data_file_1': 'cmdline_test_data_file_1',
            'test_data_file_2': 'cmdline_test_data_file_2',
            'test_data_file_3': 'cmdline_test_data_file_3',
            'test_data_file_4': 'cmdline_test_data_file_4'
        }
    }


# Generated at 2022-06-23 00:56:17.334883
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdLine = CmdLineFactCollector()
    assert cmdLine.name == "cmdline"
    assert cmdLine._fact_ids == set()

# Generated at 2022-06-23 00:56:19.170175
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """
    Compares hashes of proc_cmdline and cmdline
    """
    CmdLineFactCollector.collect()

# Generated at 2022-06-23 00:56:26.224543
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'
    assert obj._fact_ids == set()

    assert isinstance(obj._get_proc_cmdline(), str)
    assert isinstance(obj._parse_proc_cmdline('ansible=True'), dict)
    assert isinstance(obj._parse_proc_cmdline_facts('ansible=True'), dict)

    data = 'ansible=True'
    obj.collect(collected_facts={'cmdline': data})
    obj.collect(collected_facts={'proc_cmdline': data})

# Generated at 2022-06-23 00:56:32.535376
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Make sure we get a CmdLineFactCollector object.
    x = CmdLineFactCollector()
    assert isinstance(x, CmdLineFactCollector)

    # Examine the private dictionary, _fact_ids.
    assert x._fact_ids == set()
    x._fact_ids.add('foo')
    assert x._fact_ids == set(['foo'])


# Generated at 2022-06-23 00:56:35.856969
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'
    assert collector._fact_ids == set()

# Unit test calling the collect method of class CmdLineFactCollector

# Generated at 2022-06-23 00:56:42.129066
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd = CmdLineFactCollector()
    isinstance(cmd, CmdLineFactCollector)

# Generated at 2022-06-23 00:56:52.742238
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_dict = {u'BOOT_IMAGE': u'/boot/vmlinuz-4.4.0-43-generic',
                    u'console': u'console=tty1',
                    u'root': u'/dev/mapper/ubuntu--vg-root',
                    u'ro': u'ro',
                    u'vbios.vga': u'aperture_size=32',
                    u'rhgb': u'quiet'}


# Generated at 2022-06-23 00:57:03.633544
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible_collections.community.general.tests.unit.compat import unittest
    from ansible_collections.community.general.tests.unit.compat.mock import patch

    class TestCmdLineFactCollector(unittest.TestCase):
        ''' Unit test for method collect of class CmdLineFactCollector '''


# Generated at 2022-06-23 00:57:12.931774
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    proc_cmdline = CmdLineFactCollector()
    cmdline_facts = proc_cmdline.collect()

    assert isinstance(cmdline_facts, dict)
    assert len(cmdline_facts) == 2
    assert isinstance(cmdline_facts['cmdline'], dict)
    assert isinstance(cmdline_facts['proc_cmdline'], dict)
    assert cmdline_facts['cmdline'] == cmdline_facts['proc_cmdline']
    assert 'quiet' in cmdline_facts['cmdline']
    assert 'ro' in cmdline_facts['cmdline']
    assert 'root' in cmdline_facts['cmdline']
    assert 'BOOT_IMAGE' in cmdline_facts['cmdline']


# Generated at 2022-06-23 00:57:19.736008
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    test_collector = CmdLineFactCollector()
    test_cmdline = test_collector.collect()
    assert test_cmdline['proc_cmdline']['rd.vconsole.font'] == "latarcyrheb-sun16"
    assert test_cmdline['cmdline'] == {'console': 'ttyS0', 'rd.vconsole.font': 'latarcyrheb-sun16'}


# Generated at 2022-06-23 00:57:27.291908
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline = 'console=tty0 \
console=ttyS1,115200n8 serial'

    lines = cmdline.splitlines()
    cmdline = ' '.join(lines)

    mock_get_file_content = lambda x: cmdline

    kwargs = {}

    new_collector = CmdLineFactCollector(**kwargs)
    new_collector._get_proc_cmdline = mock_get_file_content
    new_collector.collect()

    assert new_collector.collect() == {
        'cmdline': {'console': 'ttyS1,115200n8',
                    'serial': True},
        'proc_cmdline': {'console': ['tty0', 'ttyS1,115200n8'],
                         'serial': True}}

# Generated at 2022-06-23 00:57:29.841111
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'

# Generated at 2022-06-23 00:57:34.302481
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    expected_name = 'cmdline'
    expected_id = 'cmdline'
    expected_fact_ids = set()

    cmdline = CmdLineFactCollector()

    assert cmdline.name == expected_name
    assert cmdline.id == expected_id
    assert cmdline._fact_ids == expected_fact_ids

# Generated at 2022-06-23 00:57:41.555581
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """Test the method collect of class CmdLineFactCollector"""
    # Create an instance of CmdLineFactCollector
    collector = CmdLineFactCollector()
    # Create an instance of AnsibleModule
    # Trying to mock an AnsibleModule
    # https://github.com/ansible/ansible/blob/devel/lib/ansible/module_utils/basic.py
    # Don't know how to mock a basic AnsibleModule with no params
    # Mock the method collect
    collector.collect = MagicMock(return_value={'cmdline': 'foo=bar'})
    # Execute the method
    cmdline_facts = collector.collect()
    # Assert the result
    assert cmdline_facts == {'cmdline': 'foo=bar'}


# Generated at 2022-06-23 00:57:52.875005
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts['cmdline'] == {}
    assert cmdline_facts['proc_cmdline'] == {}

    class TestModule(object):
        def __init__(self, data):
            self.data = data
            self.check_mode = False

        def read_file(self, filename):
            return self.data

        def fail_json(self, *args, **kwargs):
            raise Exception("fail_json called")

    module = TestModule("foo=bar")
    cmdline_facts = CmdLineFactCollector(module=module).collect()
    assert cmdline_facts['cmdline'] == {'foo': 'bar'}
    assert cmdline_facts['proc_cmdline'] == {'foo': 'bar'}

    module = Test