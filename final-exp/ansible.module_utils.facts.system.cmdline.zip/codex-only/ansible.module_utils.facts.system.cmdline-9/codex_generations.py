

# Generated at 2022-06-23 00:47:55.187031
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()

# Generated at 2022-06-23 00:48:06.362556
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    o = CmdLineFactCollector()
    cmdline_facts = o.collect()

    # Check that the key cmdline is in fact, and that is a dict
    assert 'cmdline' in cmdline_facts
    assert isinstance(cmdline_facts['cmdline'], dict)
    # Check that the key proc_cmdline is in fact, and that is a dict
    assert 'proc_cmdline' in cmdline_facts
    assert isinstance(cmdline_facts['proc_cmdline'], dict)

    # Check that a few keys are in both cmdline and proc_cmdline
    assert 'ro' in cmdline_facts['cmdline']
    assert cmdline_facts['cmdline']['ro'] == True
    assert 'ro' in cmdline_facts['proc_cmdline']

# Generated at 2022-06-23 00:48:07.886071
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector(None).name == 'cmdline'

# Generated at 2022-06-23 00:48:09.865830
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert cmdline.name == 'cmdline'

# Generated at 2022-06-23 00:48:19.997244
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    # Arrange
    # Assume that cmdline_facts is empty
    cmdline_facts = {}

    # Assume that data is empty
    data = ''

    # Assume that raw_cmdline_facts is empty
    raw_cmdline_facts = []

    # Assume that fact_ids is empty
    fact_ids = set()

    # Assume that module is none
    module = None

    # Assume that collected_facts is none
    collected_facts = None

    # Run the method collect of CmdLineFactCollector
    # by calling the unit test for the method _get_proc_cmdline
    # The following is used to mock the data variable
    class TestClass:
        def test_get_proc_cmdline(self):
            return data


# Generated at 2022-06-23 00:48:25.678403
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """
    This unit test function tests method collect of class CmdLineFactCollector
    """
    from ansible.module_utils.facts.collectors.cmdline import CmdLineFactCollector
    CmdLineFactCollectorTest = CmdLineFactCollector()
    ret = CmdLineFactCollectorTest.collect()
    assert 'cmdline' in ret
    assert 'proc_cmdline' in ret

# Generated at 2022-06-23 00:48:37.312927
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    '''
    Unit test for method collect of class CmdLineFactCollector
    '''
    cmdline_facts = {}
    cmdline_facts['proc_cmdline'] = {'quiet': True, 'root': '/dev/disk/by-id/scsi-0QEMU_QEMU_HARDDISK_drive-virtio-disk0', 'console': 'ttyS0', 'console': 'tty1'}
    cmdline_facts['cmdline'] = {'quiet': True, 'root': '/dev/disk/by-id/scsi-0QEMU_QEMU_HARDDISK_drive-virtio-disk0', 'console': 'tty1'}


# Generated at 2022-06-23 00:48:39.788845
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    facts = collector.collect()

    assert isinstance(facts, dict)
    assert 'cmdline' in facts
    assert facts['cmdline']

# Generated at 2022-06-23 00:48:42.284773
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = CmdLineFactCollector()
    assert cmdline_facts.name == 'cmdline'
    assert cmdline_facts._fact_ids == set()


# Generated at 2022-06-23 00:48:44.623192
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline = CmdLineFactCollector()
    assert cmdline


# Generated at 2022-06-23 00:48:48.298291
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    module = None
    collected_facts = None
    cmdline = CmdLineFactCollector(module=module, collected_facts=collected_facts)
    out = cmdline.collect(module=module, collected_facts=collected_facts)
    assert out['cmdline']['root'] == '/dev/sda1'
    assert out['proc_cmdline']['root'] == '/dev/sda1'
    assert out['proc_cmdline']['verbose'] == True

# Generated at 2022-06-23 00:48:51.498427
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    try:
        CmdLineFactCollector()
    except NameError as e:
        print(e)
        return False

    return True


# Generated at 2022-06-23 00:48:55.867843
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    f = CmdLineFactCollector()
    f.collect()
    pass

# Generated at 2022-06-23 00:49:05.856946
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Create an instance of CmdLineFactCollector
    cmdline_fact_collector = CmdLineFactCollector()

    # Setup test data
    data = 'foo=bar baz=bam'

    # Get parsed contents of cmdline file
    cmdline_result = cmdline_fact_collector._parse_proc_cmdline(data)
    assert cmdline_result == {'foo': 'bar', 'baz': 'bam'}

    # Get parsed contents of cmdline file
    proc_cmdline_result = cmdline_fact_collector._parse_proc_cmdline_facts(data)
    assert proc_cmdline_result == {'foo': 'bar', 'baz': 'bam'}

    # Collect facts using method collect of class CmdLineFactCollector
    cmdline_facts = cmdline_fact_

# Generated at 2022-06-23 00:49:08.650548
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cf = CmdLineFactCollector()
    assert cf.name == "cmdline"
    assert sorted(cf._fact_ids) == sorted(["cmdline"])

# Generated at 2022-06-23 00:49:16.764407
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # We'll just test with the existence of cmdline and proc_cmdline
    collector = CmdLineFactCollector()
    cmdline_facts = collector.collect()
    assert isinstance(cmdline_facts, dict)
    assert isinstance(cmdline_facts.get('cmdline'), dict)
    assert isinstance(cmdline_facts.get('proc_cmdline'), dict)
    assert "BOOT_IMAGE" in cmdline_facts.get('cmdline').keys()
    assert "BOOT_IMAGE" in cmdline_facts.get('proc_cmdline').keys()

# Generated at 2022-06-23 00:49:21.446860
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    """This is a test of the constructor of class CmdLineFactCollector"""
    # Make sure correct parameters are used
    assert CmdLineFactCollector().name == 'cmdline', "Collection name should be cmdline. It is " + CmdLineFactCollector().name


# Generated at 2022-06-23 00:49:23.647780
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()

# Generated at 2022-06-23 00:49:26.284105
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()

    assert c is not None
    assert c.name == 'cmdline'
    assert c._fact_ids == set()

# Generated at 2022-06-23 00:49:34.890159
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_fact_collector = CmdLineFactCollector()


# Generated at 2022-06-23 00:49:45.305268
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    from ansible.module_utils import basic

    from ansible.module_utils.facts.collector.internal import InternalFactCollector
    from ansible.module_utils.facts.collector.cmdline import CmdLineFactCollector
    from ansible.module_utils.facts.collector.caching import CachingFactCollector
    from ansible.module_utils.facts.collector.parsers import parse_proc_cmdline

    import os
    import pytest
    import shutil
    import tempfile

    facts = {}

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-23 00:49:48.780816
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fc = CmdLineFactCollector()
    assert cmdline_fc.name == 'cmdline'
    assert cmdline_fc._fact_ids == set(['cmdline', 'proc_cmdline'])
    assert cmdline_fc

# Generated at 2022-06-23 00:49:51.428668
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    fact = CmdLineFactCollector()
    assert fact.name == 'cmdline'
    assert fact._fact_ids == set()

# Generated at 2022-06-23 00:49:55.618863
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    result = collector.collect()
    assert isinstance(result, dict)
    assert result['cmdline']
    assert result['proc_cmdline']
    assert isinstance(result['cmdline'], dict)
    assert isinstance(result['proc_cmdline'], dict)

# Generated at 2022-06-23 00:50:05.188962
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    fact_collector = CmdLineFactCollector()

    # Test with no file
    with open('/proc/cmdline', 'w') as f:
        f.write('')
    assert {} == fact_collector.collect()

    # Test with one line
    with open('/proc/cmdline', 'w') as f:
        f.write('test_cmdline')
    assert {'proc_cmdline': {'test_cmdline': True}, 'cmdline': {'test_cmdline': True}} == fact_collector.collect()

    # Test with one line and one value
    with open('/proc/cmdline', 'w') as f:
        f.write('test_cmdline=value')

# Generated at 2022-06-23 00:50:15.228030
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """Test to check the output of collect method of class CmdLineFactCollector"""


    # Order of message to be passed to cmd_line_collector_collect method
    input_data = 'BOOT_IMAGE=/vmlinuz-linux root=UUID=fe2a3524-6452-4e54-8c74-b6cdf0a22908 ro resume=/dev/mapper/ubuntu--vg-swap_1'

    class Module:
        pass

    module = Module()

    # Calling collect method with input message
    cmd_line_facts = CmdLineFactCollector().collect(module, {})
    assert cmd_line_facts.get('cmdline').get('root') == 'UUID=fe2a3524-6452-4e54-8c74-b6cdf0a22908'

   

# Generated at 2022-06-23 00:50:17.559219
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()


# Generated at 2022-06-23 00:50:20.491090
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdLineFactCollector = CmdLineFactCollector()
    assert cmdLineFactCollector.name == 'cmdline'
    assert cmdLineFactCollector._fact_ids == set()


# Generated at 2022-06-23 00:50:29.736052
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmd_collector = CmdLineFactCollector()
    cmd_collector._get_proc_cmdline = lambda: ' key1=val1 key2val2 key3=val3 '
    cmd_collector._parse_proc_cmdline = lambda x: cmd_collector._parse_proc_cmdline_facts(x)

    facts = cmd_collector.collect()
    assert 'cmdline' in facts
    assert 'proc_cmdline' in facts

    for cmd_type in ('cmdline', 'proc_cmdline'):
        assert 'key1' in facts[cmd_type]
        assert facts[cmd_type].get('key1') == 'val1'
        assert 'key2val2' in facts[cmd_type]
        assert facts[cmd_type].get('key2val2') is True

# Generated at 2022-06-23 00:50:39.483112
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import os
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import collector

    # Example content of /proc/cmdline
    contents = [
        'BOOT_IMAGE=/vmlinuz-4.4.0-112-generic root=/dev/mapper/ubuntu-root ro quiet splash vt.handoff=7',
        'BOOT_IMAGE=/vmlinuz-4.4.0-112-generic BOOTIF=01-00-1a-a0-48-10-07 root=/dev/mapper/ubuntu-root ro quiet splash vt.handoff=7',
    ]

    module = None
    collector_ = Collector()


# Generated at 2022-06-23 00:50:41.727636
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdLine = CmdLineFactCollector()
    assert cmdLine.name == 'cmdline'
    assert isinstance(cmdLine._fact_ids, set)

# Generated at 2022-06-23 00:50:47.147443
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    myCmdLine = CmdLineFactCollector()
    assert myCmdLine.name == 'cmdline'
    assert myCmdLine._fact_ids == set()
    assert myCmdLine.collect()['cmdline']['root'] == '/dev/mapper/centos_bogon-root'
    #print('Test Constructor CmdLineFactCollector PASS!')


# Generated at 2022-06-23 00:50:55.009407
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    class Module(object):
        def __init__(self):
            self.params = {}
            self.params['gather_timeout'] = 5

    class CollectedFacts(object):
        def __init__(self):
            self.namespace = 'ansible_cmdline'
            self.data = {}

    module = Module()
    collected_facts = CollectedFacts()

    collector = CmdLineFactCollector(module=module, collected_facts=collected_facts)

    result = collector.collect()
    assert isinstance(result, dict) is True
    assert len(result) == 2
    assert 'cmdline' in result.keys()
    assert isinstance(result['cmdline'], dict)
    assert 'proc_cmdline' in result.keys()

# Generated at 2022-06-23 00:51:00.164629
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Fields
    cmdline_collector = CmdLineFactCollector()

    # Methods
    cmdline_facts = cmdline_collector.collect()
    assert(type(cmdline_facts) is dict)
    assert(cmdline_facts['cmdline']['ro'] is True)
    assert(cmdline_facts['proc_cmdline']['ro'] is True)


# Generated at 2022-06-23 00:51:01.496711
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector().name == 'cmdline'


# Generated at 2022-06-23 00:51:09.176629
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Do not collect facts if there is no proc cmdline file
    collector = CmdLineFactCollector()
    collector.get_file_content = lambda x: ''
    assert collector.collect() == {}

    # Return the facts as they were read from the proc cmdline file
    collector = CmdLineFactCollector()
    collector.get_file_content = lambda x: 'foo bar=baz test=1 test=2'
    assert collector.collect() == {'cmdline': {'foo': True, 'bar': 'baz', 'test': '2'},
                                   'proc_cmdline': {'foo': True, 'bar': 'baz', 'test': ['1', '2']}}

# Generated at 2022-06-23 00:51:11.320911
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert(CmdLineFactCollector.name == 'cmdline')
    assert(CmdLineFactCollector._fact_ids == set())

# Generated at 2022-06-23 00:51:13.103424
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector().collect()
    assert cmdline_facts is not None

# Generated at 2022-06-23 00:51:14.891614
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_info = CmdLineFactCollector()

    assert cmdline_info.name == 'cmdline'

# Generated at 2022-06-23 00:51:17.889194
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'

# Generated at 2022-06-23 00:51:19.946684
# Unit test for method collect of class CmdLineFactCollector

# Generated at 2022-06-23 00:51:24.284939
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()

    assert cmdline_fact_collector is not None
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-23 00:51:27.026038
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c = CmdLineFactCollector()
    assert c.name == 'cmdline'
    assert c._fact_ids == set()

# Generated at 2022-06-23 00:51:33.194571
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import os
    os.environ["ANSIBLE_COLLECTORS"] = "cmdline"

    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collectors.cmdline import CmdLineFactCollector

    collector_obj = CmdLineFactCollector()
    result = collector_obj.collect()

    assert 'cmdline' in result
    assert 'proc_cmdline' in result
    # TODO(aarefiev): Write more tests

# Generated at 2022-06-23 00:51:40.736554
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_data = 'console=ttyS0,9600 console=tty0 root=/dev/sda1 elevator=noop'
    # cmdline_data = 'root=UUID=0e1efb8a-b17c-4016-9f85-a8e8b30896bf ro console=hvc0 console=tty0 rhgb quiet rd.luks.uuid=luks-43a85619-1d12-4eaa-a19f-8b16f2eb15f4 rd.md=0:4 rd.lvm=0:4 crashkernel=auto rd.dm=0 LANG=en_US.UTF-8'
    class MyClass:
        def __init__(self):
            self.path = '/proc/cmdline'
            self.content = cmdline_data

# Generated at 2022-06-23 00:51:51.591173
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    c = CmdLineFactCollector()


# Generated at 2022-06-23 00:51:58.284527
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = {
        'cmdline': {
            'crashkernel': '128M@16M',
            'rhgb': True,
            'quiet': True
        },
        'proc_cmdline': {
            'crashkernel': '128M@16M',
            'rhgb': '',
            'quiet': True
        }
    }

    collector = CmdLineFactCollector()
    assert cmdline_facts == collector.collect()

# Generated at 2022-06-23 00:52:02.392063
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert isinstance(cmdline_fact_collector._fact_ids, set)
    assert cmdline_fact_collector._fact_ids is not None


# Generated at 2022-06-23 00:52:10.201382
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    # Create a CmdLineFactCollector object and mock the variable __get_proc_cmdline()
    def _get_proc_cmdline():
        return 'PRETEND_CMDLINE'

    cmdline_collector = CmdLineFactCollector()
    cmdline_collector._get_proc_cmdline = _get_proc_cmdline

    # Create mocks for _parse_proc_cmdline() and _parse_proc_cmdline_facts()
    def _parse_proc_cmdline(data):
        return "PRETEND_PROC_CMDLINE"

    def _parse_proc_cmdline_facts(data):
        return "PRETEND_PROC_CMDLINE_FACTS"

    cmdline_collector._parse_proc_cmdline = _parse_proc_cmdline
    cmdline_collect

# Generated at 2022-06-23 00:52:20.733573
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    with open('/proc/cmdline', 'w') as fw:
        fw.write("console=ttyS0 xencons=ttyS1 root=/dev/sda1 ro quiet noresume elevator=noop")
    cf = CmdLineFactCollector()
    assert cf.collect() == {'cmdline': {'console': 'ttyS0', 'elevator': 'noop', 'quiet': True, 'noresume': True, 'ro': True, 'root': '/dev/sda1', 'xencons': 'ttyS1'},
                            'proc_cmdline': {'console': 'ttyS0', 'elevator': 'noop', 'quiet': True, 'noresume': True, 'ro': True, 'root': '/dev/sda1', 'xencons': 'ttyS1'}}

# Generated at 2022-06-23 00:52:23.382620
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert cmdline_collector._fact_ids == set()


# Generated at 2022-06-23 00:52:26.419047
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = CmdLineFactCollector()
    assert cmdline_facts.name == 'cmdline'
    assert isinstance(cmdline_facts, BaseFactCollector)


# Generated at 2022-06-23 00:52:29.937779
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector is not None


# Generated at 2022-06-23 00:52:33.684778
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    """
    Test the constructor for CmdLineFactCollector
    """

    cmdline_facts = CmdLineFactCollector()
    assert cmdline_facts.name == "cmdline"
    assert cmdline_facts._fact_ids == set()


# Generated at 2022-06-23 00:52:36.111042
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    c2 = CmdLineFactCollector('')

    assert c2.name == 'cmdline'
    assert c2._fact_ids == set()

# Generated at 2022-06-23 00:52:39.548181
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    Module = type('', (object,), {'exit_json': lambda x: None})
    module = Module()
    CmdLineFactCollector.collect(module)

# Generated at 2022-06-23 00:52:50.160254
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """ Unit test for method collect of class CmdLineFactCollector """
    col = CmdLineFactCollector()
    # None as output
    assert col.collect() == {}
    # empty string as output
    assert col.collect(collected_facts={'cmdline': ""}) == {}
    # test parsing function
    assert col._parse_proc_cmdline('foo') == {'foo': True}
    assert col._parse_proc_cmdline('foo=bar') == {'foo': 'bar'}
    assert col._parse_proc_cmdline('foo=bar baz=') == {'foo': 'bar', 'baz': True}
    assert col._parse_proc_cmdline('foo=bar baz') == {'foo': 'bar', 'baz': True}

# Generated at 2022-06-23 00:53:00.536960
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import Collector
    cmdline_fact_instance = CmdLineFactCollector()
    cmdline_fact_instance._get_proc_cmdline = lambda: to_bytes(u'ro root=/dev/mapper/fedora-root')

    actual_result = cmdline_fact_instance.collect()
    expected_result = dict(
        cmdline=dict(ro=True, root=u'/dev/mapper/fedora-root'),
        proc_cmdline=dict(ro=True, root=u'/dev/mapper/fedora-root')
    )
    assert actual_result == expected_result


# Generated at 2022-06-23 00:53:02.303271
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector().name == 'cmdline'


# Generated at 2022-06-23 00:53:10.558942
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import mock
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import CmdLineFactCollector
    from ansible.module_utils.facts.utils import AnsibleFactCollector, get_file_content

    BaseFactCollector.collect = mock.Mock(return_value={'cmdline': {}})
    get_file_content = mock.Mock(return_value="first_key=first_value second_key")

    ansible_fact_collector = AnsibleFactCollector()
    cmdline_fact_collector = CmdLineFactCollector()

    base_fact_result = BaseFactCollector.collect()
    get_file_content_result = get_file_content('')


# Generated at 2022-06-23 00:53:12.124615
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = CmdLineFactCollector()
    assert cmdline_facts.collect()

# Generated at 2022-06-23 00:53:13.916462
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert not CmdLineFactCollector()._fact_ids
    assert CmdLineFactCollector.name == 'cmdline'


# Generated at 2022-06-23 00:53:16.875879
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'


# Generated at 2022-06-23 00:53:20.695903
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Basic constructor
    cmdline_fact_collector = CmdLineFactCollector()

    # Constructor with invalid type
    cmdline_fact_collector = CmdLineFactCollector(1)

# Generated at 2022-06-23 00:53:31.072915
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    module = type("module", (object,), {})

    fact_collector = CmdLineFactCollector(module=module, collected_facts=dict())
    fact_collector._get_proc_cmdline = lambda: 'rd.md=0 rd.lvm=0 rd.dm=0 SYSFONT=latarcyrheb-sun16 crashkernel=auto  rhgb quiet LANG=en_US.UTF-8'
    fact_collector._parse_proc_cmdline = CmdLineFactCollector._parse_proc_cmdline
    fact_collector._parse_proc_cmdline_facts = CmdLineFactCollector._parse_proc_cmdline_facts
    cmdline_facts = fact_collector.collect()


# Generated at 2022-06-23 00:53:32.720850
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector.name == 'cmdline'
    assert CmdLineFactCollector._fact_ids == set()



# Generated at 2022-06-23 00:53:40.675936
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    '''
    Unit test for method collect of class CmdLineFactCollector
    '''
    cmdline_str = 'console=ttyS0,115200n8'
    cmdline_facts = CmdLineFactCollector().collect(None, None)
    assert cmdline_facts['cmdline']['console'] == 'ttyS0,115200n8'
    assert cmdline_facts['proc_cmdline']['console'] == 'ttyS0,115200n8'


# Generated at 2022-06-23 00:53:52.412024
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """Unit test for `CmdLineFactCollector.collect()` method"""
    # Initialize the test instances
    mock_class = CmdLineFactCollector()

    # Generate mock test data
    data = ' selinux=1 enforcing=1 biosdevname=0 net.ifnames=0 quiet vconsole.font=latarcyrheb-sun16 vconsole.keymap=us ipv6.disable=1  consoleblank=0 elevator=noop '

    # Set the return value of the mocked method
    mock_class._get_proc_cmdline = lambda: data

    # Execute the test
    result = mock_class.collect()

    # Assert the executed result

# Generated at 2022-06-23 00:53:54.919167
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_facts = CmdLineFactCollector()
    assert cmdline_facts.name == 'cmdline'
    assert cmdline_facts._fact_ids == set()



# Generated at 2022-06-23 00:53:59.454188
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    

# Generated at 2022-06-23 00:54:02.471282
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_obj = CmdLineFactCollector()
    assert cmdline_obj.name == 'cmdline'
    assert cmdline_obj._fact_ids == set()


# Generated at 2022-06-23 00:54:05.721324
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    obj = CmdLineFactCollector()
    assert obj.name == 'cmdline'
    assert obj._fact_ids == set()


# Generated at 2022-06-23 00:54:17.405870
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    import os

    test_lines = 'foo bar=baz foo=qux bla bla' # with simple values
    test_lines2 = 'foo=bar bla=foo foo=qux bla bla' # with multiple values for a key
    test_lines3 = 'page_size=4096 page_size=2048 page_size=1024' # with multiple values for a key, all the same

    open('/tmp/cmdline', 'w').write(test_lines)

    # test if it doesn't fail
    c = CmdLineFactCollector()
    returned_data = c.collect()
    assert returned_data['cmdline'] == {'foo': True, 'bla': True, 'bar': 'baz', 'foo': 'qux'}

    # test if it doesn't fail when a key is supplied several times

# Generated at 2022-06-23 00:54:26.609645
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    fact_collector = CmdLineFactCollector()
    fact_collector._get_proc_cmdline = lambda : 'BOOT_IMAGE=/kernel-3.10.0-123.el7.x86_64 root=UUID=a0dfd93c-5f91-4c8e-81f1-f7d925441eb3 ro crashkernel=auto rhgb quiet LANG=en_US.UTF-8'

# Generated at 2022-06-23 00:54:28.178833
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    for line in CmdLineFactCollector().collect():
        line


# Generated at 2022-06-23 00:54:30.794236
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert(collector.name == 'cmdline')
    assert(collector._fact_ids == set())


# Generated at 2022-06-23 00:54:39.104557
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    with open('/proc/cmdline', 'w') as fd:
        fd.write('ro console=tty1 console=ttyS0')
    cmdline_facts = CmdLineFactCollector().collect()

    assert cmdline_facts['cmdline'] == {'ro': True, 'console': 'ttyS0'}
    assert cmdline_facts['proc_cmdline'] == {'ro': True, 'console': ['tty1', 'ttyS0']}

# Generated at 2022-06-23 00:54:42.626284
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():

    # test the constructor of class CmdLineFactCollector
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector.name == 'cmdline'
    assert isinstance(cmdline_collector, BaseFactCollector)

# Generated at 2022-06-23 00:54:44.361862
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    fact_collector = CmdLineFactCollector()
    assert fact_collector.name == 'cmdline'

# Generated at 2022-06-23 00:54:49.188003
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_collector = CmdLineFactCollector()
    collected_facts = cmdline_collector.collect()
    assert type(collected_facts['cmdline']) is dict
    assert type(collected_facts['proc_cmdline']) is dict
    assert len(collected_facts['cmdline']) > 0
    assert len(collected_facts['proc_cmdline']) > 0

# Generated at 2022-06-23 00:54:52.074217
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert isinstance(cmdline_fact_collector._fact_ids, set)


# Generated at 2022-06-23 00:55:02.984158
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector.cmdline import CmdLineFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockData(object):
        def __init__(self, data):
            self.data = data

        def read(self):
            return self.data

    module, collected_facts = None, None
    cmdline_facts_collector = CmdLineFactCollector(module, collected_facts)


# Generated at 2022-06-23 00:55:08.588805
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts import facts
    from ansible.module_utils.facts.utils import set_module_args

    args = dict(
        gather_subset='cmdline',
    )
    set_module_args(args)

    fc = CmdLineFactCollector()

    result = fc.collect(module=facts)

    assert 'cmdline' in result
    assert 'proc_cmdline' in result

# Generated at 2022-06-23 00:55:16.618547
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    fc = CmdLineFactCollector()

    fc.__dict__['_get_proc_cmdline'] = lambda: 'a=b c=d e'
    fc.__dict__['_parse_proc_cmdline'] = lambda s: s
    fc.__dict__['_parse_proc_cmdline_facts'] = lambda s: s
    
    expected = {'cmdline': 'a=b c=d e', 'proc_cmdline': 'a=b c=d e'}
    assert fc.collect() == expected


# Generated at 2022-06-23 00:55:20.535481
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # This method is needed only to instantiate the class CmdLineFactCollector
    # and check that it is instance of BaseFactCollector
    collector = CmdLineFactCollector()
    assert isinstance(collector, BaseFactCollector)



# Generated at 2022-06-23 00:55:31.078285
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    module_args = dict(
        content='foo=bar bar=baz baz=qux',
    )
    result = dict(
        ansible_facts=dict(
            cmdline=dict(
                foo='bar',
                bar='baz',
                baz='qux'
            ),
            proc_cmdline=dict(
                foo=['bar'],
                bar=['baz'],
                baz=['qux']
            )
        )
    )

    collection_mock = CmdLineFactCollector(module_args, None)
    collection_mock._get_proc_cmdline = lambda: module_args['content']

    assert collection_mock.collect() == result


# Generated at 2022-06-23 00:55:39.353783
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """Test class CmdLineFactCollector, module_utils/facts/cmdline.py"""

    # Define module argument key-values
    tested_class = CmdLineFactCollector()

    # Define some test data
    proc_cmdline_content = '"foo bar baz" arg1=arg2 arg3 arg4="foo bar" arg5=arg6 arg7= arg8 arg9 arg10=foo'

# Generated at 2022-06-23 00:55:51.567974
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Command line parameters 
    module = None
    collected_facts = None
    cmdline_dict = {}

    # Create instance of CmdLineFactCollector
    cmdline_collector = CmdLineFactCollector()
   
    # Mock method _get_proc_cmdline
    def _get_proc_cmdline():
        return "BOOT_IMAGE=/vmlinuz-3.10.0-327.el7.x86_64 root=UUID=a77530e2-eb55-4d85-b837-5a5a5a5a5a5a ro crashkernel=auto"
    cmdline_collector._get_proc_cmdline = _get_proc_cmdline

    # Call method collect
    cmdline_dict = cmdline_collector.collect()

    # Check the result

# Generated at 2022-06-23 00:56:02.594286
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    from ansible.module_utils.facts import collector
    data = '''root=/dev/mapper/fedora_localhost--live-root ro rd.lvm.lv=fedora/root rd.lvm.lv=fedora/swap rhgb quiet LANG=en_US.UTF-8'''
    with open("/proc/cmdline", 'w') as f:
        f.write("%s" % data)

    cmdline_collector = CmdLineFactCollector()
    cmdline_collector.collect()
    result = collector.collector.get_fact('cmdline')

# Generated at 2022-06-23 00:56:12.265953
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    data = '''
BOOT_IMAGE=/vmlinuz-3.10.0-229.el7.x86_64 root=/dev/mapper/rhel-root ro crashkernel=auto rd.lvm.lv=rhel/root rd.lvm.lv=rhel/swap rhgb quiet LANG=en_US.UTF-8
'''

    with open('/proc/cmdline', 'w') as f:
        f.write(data)


# Generated at 2022-06-23 00:56:14.763421
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector().name == 'cmdline'


# Generated at 2022-06-23 00:56:20.039752
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """Test for method CmdLineFactCollector.collect."""
    o = CmdLineFactCollector()

    assert o.collect() == {'cmdline': {}, 'proc_cmdline': {}}
    assert o.collect() == {'cmdline': {}, 'proc_cmdline': {}}
    assert o.collect() == {'cmdline': {}, 'proc_cmdline': {}}

# Generated at 2022-06-23 00:56:21.786962
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Check if instance of BaseFactCollector
    assert isinstance(CmdLineFactCollector(), BaseFactCollector)

# Generated at 2022-06-23 00:56:24.496086
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    fact_collector = CmdLineFactCollector()
    assert fact_collector.name == 'cmdline'
    assert fact_collector._fact_ids == set()


# Generated at 2022-06-23 00:56:30.483021
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    '''Test method collect of class CmdLineFactCollector'''
    collector = CmdLineFactCollector()
    cmdline_facts = collector.collect()
    assert 'cmdline' in cmdline_facts
    assert 'proc_cmdline' in cmdline_facts

# Generated at 2022-06-23 00:56:33.757536
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdLineCollector = CmdLineFactCollector()
    assert cmdLineCollector.name == 'cmdline'
    assert cmdLineCollector._fact_ids == set()


# Generated at 2022-06-23 00:56:44.136831
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # collect should return an empty dict on a missing file
    assert CmdLineFactCollector.collect() == {}


# Generated at 2022-06-23 00:56:46.190404
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    assert CmdLineFactCollector().collect()
    assert CmdLineFactCollector().collect()

# Generated at 2022-06-23 00:56:48.060138
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_collector = CmdLineFactCollector()
    assert cmdline_collector is not None


# Generated at 2022-06-23 00:56:49.716119
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert collector.name == 'cmdline'
    assert collector._fact_ids == set()


# Generated at 2022-06-23 00:56:52.507467
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    cmdline_facts = dict(ansible_command_line='echo hi')
    cmd = CmdLineFactCollector()
    assert cmd.collect() == cmdline_facts

# Test get_file_content

# Generated at 2022-06-23 00:56:56.467309
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmdline_fact_collector = CmdLineFactCollector()
    assert cmdline_fact_collector.name == 'cmdline'
    assert cmdline_fact_collector._fact_ids == set()


# Generated at 2022-06-23 00:56:58.464836
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    cmd = CmdLineFactCollector()
    assert cmd.name == "cmdline"
    assert cmd.collect()

# Generated at 2022-06-23 00:57:02.022141
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    test_collector = CmdLineFactCollector()
    assert test_collector is not None
    assert test_collector.name == 'cmdline'
    assert test_collector._fact_ids == set()


# Generated at 2022-06-23 00:57:11.064124
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # create CmdLineFactCollector object
    cmdline_collector = CmdLineFactCollector()
    # get facts
    fact = cmdline_collector.collect()
    # assert if fact['cmdline'] returned valid value
    assert fact['cmdline']
    # Unit test for method collect of class CmdLineFactCollector
    def test_CmdLineFactCollector_collect():
        # create CmdLineFactCollector object
        cmdline_collector = CmdLineFactCollector()
        # get facts
        fact = cmdline_collector.collect()
        # assert if fact['cmdline'] returned valid value
        assert fact['cmdline']


# Generated at 2022-06-23 00:57:12.004860
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    collector = CmdLineFactCollector()
    assert collector.collect()

# Generated at 2022-06-23 00:57:19.024648
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    # Verify object creation
    cmdline = CmdLineFactCollector()

    # Get the name of the object
    name = cmdline.name

    # Get the set of fact names provided by the object
    fact_ids = cmdline.collect()

    # Verify the name of the object
    assert name == 'cmdline'

    # Verify the set of fact names
    assert fact_ids == {
        "cmdline",
        "proc_cmdline",
    }

# Generated at 2022-06-23 00:57:29.395846
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():

    # Mocking get_file_content
    from unittest.mock import patch
    from ansible.module_utils.facts.utils import get_file_content

    testdata = 'BOOT_IMAGE=/kernel-3.10.0-229.el7.x86_64 ro root=UUID=a462aabf-4e8c-4ec7-a947-57a7d37fa8cd rd.lvm.lv=centos/root rd.lvm.lv=centos/swap rhgb quiet'

    with patch.object(CmdLineFactCollector, '_get_proc_cmdline', return_value=testdata):
        # Create an instance
        x = CmdLineFactCollector()

        # Call method
        ret = x.collect()


# Generated at 2022-06-23 00:57:30.591915
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    CmdLineFactCollector()

# Generated at 2022-06-23 00:57:32.763524
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()

    assert collector.name == 'cmdline'
    assert collector._fact_ids == set()


# Generated at 2022-06-23 00:57:34.150688
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    collector = CmdLineFactCollector()
    assert 'cmdline' == collector.name

# Generated at 2022-06-23 00:57:35.532500
# Unit test for constructor of class CmdLineFactCollector
def test_CmdLineFactCollector():
    assert CmdLineFactCollector().name == 'cmdline'

# Generated at 2022-06-23 00:57:43.744737
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    # Initialize CmdLineFactCollector object
    obj = CmdLineFactCollector()
    # Assign value for param collected_facts
    collected_facts = {}
    # expected value for cmdline_facts

# Generated at 2022-06-23 00:57:47.166046
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    """
    This method is not tested with the usual unit test syntax.
    It is directly tested at the end of this file using function
    test_module_utils_facts_collector
    """
    pass



# Generated at 2022-06-23 00:57:52.091307
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    fact_collector = CmdLineFactCollector({})
    assert fact_collector is not None
    assert fact_collector.collect() is not None
    assert 'cmdline' in fact_collector.collect()
    assert 'proc_cmdline' in fact_collector.collect()

# Generated at 2022-06-23 00:57:57.101216
# Unit test for method collect of class CmdLineFactCollector
def test_CmdLineFactCollector_collect():
    class MockModule():
        pass
    module = MockModule()
    cmdline_collector = CmdLineFactCollector()
    result = cmdline_collector.collect(module=None, collected_facts=None)
    assert 'cmdline' in result.keys()
    assert 'proc_cmdline' in result.keys()