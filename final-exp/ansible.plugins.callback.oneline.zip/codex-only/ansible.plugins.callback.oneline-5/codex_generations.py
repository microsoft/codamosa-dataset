

# Generated at 2022-06-23 09:44:47.001350
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Mock display
    import unittest.mock
    mock_display = unittest.mock.MagicMock()

    # Mock host
    import unittest.mock
    mock_host = unittest.mock.MagicMock()

    mock_host.get_name.return_value = 'host1'

    # Mock result
    import unittest.mock
    mock_result = unittest.mock.MagicMock()

    mock_result._host = mock_host
    mock_result._result = {"changed": True}

    # Test
    callback = CallbackModule(mock_display)
    callback.v2_runner_on_ok(mock_result)


# Generated at 2022-06-23 09:44:56.596866
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    # Setup
        result = Mock()
        result._host = Mock()
        result._host.get_name.return_value = "host1"
        result._result = {"msg": "test message"}
        plugin = CallbackModule()
        plugin._display = Mock()

    # Execute
        plugin.v2_runner_on_unreachable(result)

    # Assert
        assert not plugin._display.display.call_args[0][1]
        assert "UNREACHABLE!" == plugin._display.display.call_args[0][0].split(" | ")[2]
        assert "test message" == plugin._display.display.call_args[0][0].split(" | ")[3]


# Generated at 2022-06-23 09:45:01.601599
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    m = CallbackModule()
    m.runner = True
    m.v2_runner_on_unreachable()


# Generated at 2022-06-23 09:45:10.135635
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Test fake data
    error = "error message"
    obj = CallbackModule()
    class fake:
        def get_name():
            return "fake_name"
    result = fake()
    result._result = {'exception': error}
    class fake_display:
        def display(msg, color=""):
            return
    obj._display = fake_display()
    C.MODULE_NO_JSON = ["fake_action"]
    result._task = fake()
    result._task.action = "fake_action"
    result._host = fake()
    res = obj.v2_runner_on_failed(result)
    assert(res == None)


# Generated at 2022-06-23 09:45:18.320549
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():

    module = CallbackModule()
    test_result = {'rc': 1}
    test_result['exception'] = None
    result = type('test_result', (object,), test_result)
    result._task = type('test_task', (object,), {'action': 'shell'})
    result._host = type('test_host', (object,), {'get_name': lambda: 'localhost'})
    module._display.verbosity = 1
    expected_result = 'localhost | FAILED! => {'

    out = module.v2_runner_on_failed(result)

    assert out == expected_result

# Generated at 2022-06-23 09:45:27.685070
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    from ansible.plugins.callback import CallbackBase

    class TestCallbackBase(CallbackBase):
        def v2_runner_on_skipped(self, result):
            msg = "TestCallbackBase was called"
            assert result._host.get_name() == "127.0.0.1"
            assert result._result.get('msg', '') == ""
            return msg

    callback = TestCallbackBase(display=None)

    fake_host = FakeHost()
    fake_result = FakeResult(msg="", host=fake_host)

    rval = callback.v2_runner_on_skipped(result=fake_result)
    assert rval == "TestCallbackBase was called"



# Generated at 2022-06-23 09:45:35.204715
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    cc = CallbackModule()
    import ansible.utils.display
    cc._display = ansible.utils.display.Display()
    result = ansible.utils.display.Display().colors.unwrap_braces("{'skipped': True,'msg': True, '_ansible_verbosity': 0, '_ansible_no_log': False, 'invocation': {'module_args': {}, 'module_name': 'setup'}}")
    cc.v2_runner_on_skipped(result)

# Generated at 2022-06-23 09:45:43.314136
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    result = dict()
    result['_host'] = dict()
    result['_host']['get_name'] = lambda: 'TEST'
    result['_result'] = dict()
    result['_result']['msg'] = 'SKIPPED'
    result['_display'] = dict()
    result['_display']['display'] = lambda a: a
    cb = CallbackModule()
    cb._display = dict()
    cb._display['display'] = lambda a, color: a
    msg = cb.v2_runner_on_skipped(result)
    assert msg == 'TEST | SKIPPED'

# Generated at 2022-06-23 09:45:49.927110
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
  from callback_plugins.oneline import CallbackModule
  cb = CallbackModule()
  cb.__dict__
  assert(hasattr(cb, 'CALLBACK_VERSION'))
  assert(hasattr(cb, 'CALLBACK_TYPE'))
  assert(hasattr(cb, 'CALLBACK_NAME'))


# Generated at 2022-06-23 09:45:57.348528
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    cm = CallbackModule()

# Generated at 2022-06-23 09:46:07.687781
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C

    class FakeDisplay(object):
        def __init__(self):
            self.data = None
            self.color = None

        def display(self, data, color):
            self.data = data
            self.color = color

    class FakeResult(object):
        def __init__(self):
            self._host = FakeHost()

    class FakeHost(object):
        def __init__(self):
            self.name = 'fake_host'

    callback = CallbackModule()
    callback._display = FakeDisplay()
    callback.v2_runner_on_skipped(FakeResult())

    assert callback._display.data == 'fake_host | SKIPPED'
    assert callback._display.color == C.COLOR_SKIP

# Generated at 2022-06-23 09:46:09.510630
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    display = CallbackModule()
    assert display.CALLBACK_TYPE == 'stdout'

# Generated at 2022-06-23 09:46:10.718823
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback = CallbackModule()

# Generated at 2022-06-23 09:46:17.352901
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    # Init
    result = dict()
    result["_host"] = dict()
    result["_host"]["get_name"] = dict()
    result["_host"]["get_name"] = "host"
    callbackModule = CallbackModule()
    callbackModule._display = dict()
    callbackModule._display["display"] = dict()
    def mocked_display(a, b):
        return True
    callbackModule._display["display"] = mocked_display
    # Run test
    callbackModule.v2_runner_on_skipped(result)

# Generated at 2022-06-23 09:46:23.392588
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    result = {}
    hostname = ''
    result['msg'] = 'skipped results'
    result['skipped'] = True
    obj = CallbackModule()
    result._host = hostname
    obj.v2_runner_on_skipped(result)



# Generated at 2022-06-23 09:46:28.429495
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    ansible_mock = mock.Mock()
    ansible_mock.get_name.return_value = "mock_host"
    callback_module = CallbackModule()
    callback_module._display = mock.Mock()
    callback_module.v2_runner_on_skipped(ansible_mock)
    callback_module._display.display.assert_called_once_with("mock_host | SKIPPED", mock.ANY)

# Generated at 2022-06-23 09:46:32.595432
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callbackModule = CallbackModule()
    result = {}
    ignore_errors = False

    # test with stdout
    result['stdout'] = 'stdout'

    # test with stderr
    result['stderr'] = 'stderr'

    # test with stdout and stderr
    result['stdout'] = 'stdout'
    result['stderr'] = 'stderr'

    callbackModule.v2_runner_on_failed(result, ignore_errors)

# Generated at 2022-06-23 09:46:37.166729
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    module = CallbackModule()
    assert module.CALLBACK_VERSION == 2.0
    assert module.CALLBACK_TYPE == 'stdout'
    assert module.CALLBACK_NAME == 'oneline'


# Generated at 2022-06-23 09:46:41.136165
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    sut = CallbackModule()
    sut.v2_runner_on_unreachable("test result")
    print("Test v2_runner_on_unreachable")


# Generated at 2022-06-23 09:46:42.335258
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule.CALLBACK_VERSION == 2.0


# Generated at 2022-06-23 09:46:51.555479
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible import context
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.loader import callback_loader
    setattr(context, 'CLIARGS', {'verbosity': 0, 'one_line': True})
    result = {}
    result['changed'] = True
    result['failed'] = False
    result['rc'] = 0
    result['_ansible_parsed'] = True
    result['invocation'] = None
    result['module_name'] = "test_module"
    result['module_lang'] = None
    result['module_args'] = "test_module_args"
    result['module_stdout'] = "/usr/sbin/test_module_stdout"

# Generated at 2022-06-23 09:47:03.042696
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    # Setup test variables
    host = {"foo": "bar"}
    result = {"msg": "msg1", "foo": "bar"}
    runner_result = {"msg": "msg2", "foo": "bar"}

    # Setup mock class
    class FakeDisplay:
        def display(self, s, color=None):
            print(s)

    class FakeAnsibleRunner:
        def __init__(self):
            self._host = host
            self._result = runner_result


    # Setup class to be tested
    class MyClass(CallbackModule):
        def __init__(self):
            self._display = FakeDisplay

    # Setup mocks
    myClass = MyClass()
    myAnsibleRunner = FakeAnsibleRunner()
    myAnsibleRunner._result = result

    # Test!
    myClass

# Generated at 2022-06-23 09:47:07.573657
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Test with result._result["changed"] is False
    result = MagicMock()
    result.result = {
        'changed': False
    }
    
    callback = CallbackModule()
    callback.v2_runner_on_ok(result)
    assert callback.buffer == '127.0.0.1 | SUCCESS => {\n    "changed": false\n}\n'

# Generated at 2022-06-23 09:47:12.999061
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # mock object representing result
    result = type('Result', (object,), {'_host': {'get_name': lambda: 'localhost'}, '_result':{'exception':'An exception occurred during task execution', 'rc': 1}, '_task':{'action':'not in C.MODULE_NO_JSON'}})

    # mock object representing callback
    display = type('Display', (object,), {'display': lambda x, color: '%s' % (x)})
    callback = type('Callback', (object,), {'_display': display, '_dump_results': lambda x, indent: '%s' % (x['exception'].replace('\n', ''))})()

    # default _display.verbosity = 1
    display.verbosity = 1
    assert callback.v2_runner_on_failed

# Generated at 2022-06-23 09:47:22.968202
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    import ansible
    from ansible.plugins.callback import _oneline_host_line
    runner = ansible.runner.Runner(
        pattern='localhost', forks=10, module_name='setup', module_args='',
        transport='local',
        )

    results_ascii = {}
    callback = CallbackModule()
    callback.v2_runner_on_ok(runner, runner.results_raw)
    results_ascii.update(runner.results_raw)

    # Make sure the output is what we expected

# Generated at 2022-06-23 09:47:23.779187
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    pass


# Generated at 2022-06-23 09:47:29.653461
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    # Initializing test environment
    from ansible.plugins.callback.default import CallbackModule
    from ansible import constants as C
    from ansible.display import Display
    from ansible.plugins.loader import callback_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    import io
    import json
    import six

    display = Display()
    callback = CallbackModule(display)
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = [Host("localhost")]
    playbook = Play()
    task = Task()
    task.set_loader(loader)
    result = {}


# Generated at 2022-06-23 09:47:39.253731
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    # Create test case
    hostname = 'example.com'
    task_name = 'test task'
    play_name = 'test play'
    remote_user = 'testuser'
    result = {'changed': False, 'skipped': True, 'skipped_reason': 'skip test', 'invocation': {'module_name': 'test', 'module_args': 'args'}}

# Generated at 2022-06-23 09:47:40.597172
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    c = CallbackModule()
    print(c)

test_CallbackModule()

# Generated at 2022-06-23 09:47:41.974621
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    pass


# Generated at 2022-06-23 09:47:52.078920
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    import io
    import unittest
    from ansible.plugins.callback import CallbackBase
    class TestDir(unittest.TestCase):
        def setUp(self):
            self.connection = Connection()
            self.play_context = PlayContext()

            # Runner is an internal, undocumented object.
            runner = Runner(self.connection, self.play_context, display=None)

            # Task is an internal, undocumented object.
            task = Task()
            task.name = 'test_task'

            self.runner_result = RunnerResult(host=None, task=task, return_data=None, runner=runner)
            self.runner_result._host = Host(name='test_host')
            self.runner_result._result = dict(msg='test_msg')

            self.inventory = Inventory()
            self.loader

# Generated at 2022-06-23 09:47:59.190004
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role import IncludeRole
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.host import Host, Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge

# Generated at 2022-06-23 09:48:10.554407
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.executor.task_result import TaskResult
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader

    # Set some initial values
    hostname = 'server'
    res = { 'exception' : "Exception message" }

    # Create a new task
    my_task = TaskResult(host=hostname, task=None, return_data=res, result=res)
    my_task._host = hostname
    my_task._task = None
    my_task._result = res
    my_task._return_data = res

    # Create new variable manager, inventory manager and play context
    variable_manager = VariableManager()
   

# Generated at 2022-06-23 09:48:19.003574
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():

    class TestResult:

        def __init__(self, host, data):
            self._host = host
            # _result is the data that would normally be returned by the module
            self._result = data


# Generated at 2022-06-23 09:48:23.157468
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Arrange
    obj = CallbackModule()
    result_dict = {'exception': 'Exception'}
    result = gen_v2_result(result_dict, 'localhost')
    # Act
    obj.v2_runner_on_failed(result)
    # Assert



# Generated at 2022-06-23 09:48:30.016064
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    print("Testing method v2_runner_on_unreachable of class CallbackModule")
    callbackModule = CallbackModule()
    result = object()
    result._host = object()
    result._host.get_name = lambda: "test"
    result._result = {}
    result._result["msg"] = "Test message"
    callbackModule.v2_runner_on_unreachable(result)

# Generated at 2022-06-23 09:48:30.734024
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    pass

# Generated at 2022-06-23 09:48:35.643110
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    host_name = "localhost"
    result = {"msg": "Unable to connect to the remote host", "_host": {"get_name": lambda: host_name}}
    cb = CallbackModule()
    cb.v2_runner_on_skipped(result)


# Generated at 2022-06-23 09:48:46.502750
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from six.moves.builtins import str
    import sys

    result = sys.modules['ansible.plugins.callback.oneline'].CallbackModule.v2_runner_on_ok({
        '_host': {
            'get_name': lambda: 'test'
        },
        '_result': {
            'stdout': '',
            'rc': 0,
            'changed': False
        },
        '_task': {
            'action': ''
        }
    })

    # assert the correct color code is returned
    assert str(result) == '\x1b[0mtest | SUCCESS => { }\x1b[0m'



# Generated at 2022-06-23 09:48:57.639208
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback import CallbackBase

    callbackBase = CallbackBase()
    callbackBase._display.verbosity = 3
    callbackBase._dump_results = lambda x, y: '[dump_results]'
    callbackBase._command_generic_msg = lambda a, b, c: '[command_generic_msg]'
    callbackBase.v2_runner_on_failed({'exception': 'dummy'})

    callbackBase = CallbackBase()
    callbackBase._display.verbosity = 2
    callbackBase._dump_results = lambda x, y: '[dump_results]'
    callbackBase._command_generic_msg = lambda a, b, c: '[command_generic_msg]'
    callbackBase.v2_runner_on_failed({'exception': 'dummy'})


# Generated at 2022-06-23 09:49:00.889716
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    cb = CallbackModule()
    cb.v2_runner_on_unreachable(result="This is a result")
    assert True

# Generated at 2022-06-23 09:49:02.443815
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    cb = CallbackModule()
    assert cb is not None

# Generated at 2022-06-23 09:49:13.315255
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.vars.manager import VariableManager

    pc = PlayContext()
    pc.network_os = 'ios'
    t = TaskResult(host=None, task=None, task_fields=dict(action=dict(name='ignore_errors')))
    show_custom_stats = dict()
    show_custom_stats['skipped_reason'] = 'reason_for_skip'
    t._result = dict(skipped=True, msg='skipped msg', show_custom_stats=show_custom_stats)
    vm = VariableManager()

    output = '''
    FAILED! => skipped msg
    '''
    c = CallbackModule()
    c._display = FakeDisplay()
   

# Generated at 2022-06-23 09:49:24.803353
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    # Create instance of a class CallbackModule
    cb = CallbackModule()
    # Create instance of class HostVars
    host = HostVars()
    host.set_name('test_name')
    # Create instance of class TaskResult
    task_result = TaskResult()
    task_result.set_host(host)
    # Create instance of class Task
    task = Task()
    task.set_action('test_action')
    # Create instance of class Result
    result = Result()
    result.set_task(task)
    result.set_host(host)
    # Create instance of class Msg
    msg = Msg()
    msg.set_msg('test_msg')
    result.set_msg(msg)
    task_result.set_result(result)
    # Run method v2_runner_

# Generated at 2022-06-23 09:49:28.884232
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    res = {}
    res['msg'] = 'test message'
    res['_host'] = 'test-host'
    res['_result'] = 'test-unreachable'
    c = CallbackModule()
    c.v2_runner_on_unreachable(res)

# Generated at 2022-06-23 09:49:38.563490
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # mocking CallbackModule class
    class callback_module_mock:
        CALLBACK_VERSION = 2.0
        CALLBACK_TYPE = 'stdout'
        CALLBACK_NAME = 'oneline'
        def __init__(self):
            pass

    test_instance = callback_module_mock()
    test_instance.__setattr__('_display', True)

    class result_mock:
        def __init__(self):
            self._result = {'changed': False}
            self._task = True
            self._host = True
            self._host.__setattr__('get_name', 'test')

    test_instance.v2_runner_on_ok(result_mock())


# Generated at 2022-06-23 09:49:45.505149
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():

    import sys
    import test_utils

    class DummyPlugin:
        def v2_runner_on_failed(self, result, ignore_errors=False):
            assert result is not None
            assert result._result is not None
            assert result._result['msg'] == "boom"

    dummy_plugin = DummyPlugin()
    callback_module = CallbackModule(display=test_utils.DummyDisplay())
    callback_module.callbacks.insert(0, dummy_plugin)

    fake_result = type('', (object,), {'_result': {'msg': 'boom'}, '_task': type('', (object,), {'action': 'command'})})
    callback_module.v2_runner_on_failed(fake_result)


# Generated at 2022-06-23 09:49:55.233189
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    class MockDisplay:
        def __init__(self):
            self.message = ""
            self.color = ""
        def display(self, message, color):
            self.message = message
            self.color = color
    class MockResult:
        def __init__(self):
            self._host = MockResult()
            self._result = dict()
        def get_name(self):
            return "foo"

    result = MockResult()
    result._result['msg'] = "Foo message"
    display = MockDisplay()
    oneline_plugin = CallbackModule()
    oneline_plugin._display = display
    oneline_plugin.v2_runner_on_unreachable(result)
    assert display.message == "foo | UNREACHABLE!: Foo message"
    assert display.color == C.COLOR_UN

# Generated at 2022-06-23 09:50:03.588583
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    import mock
    import json
    import sys
    from .test_utils import AnsibleExitJson
    from .test_utils import AnsibleFailJson

    from ansible.module_utils._text import to_bytes
    if sys.version_info >= (3, 0):
        from io import StringIO
    else:
        from StringIO import StringIO

    display_in = StringIO()
    display_out = StringIO()

    class Display:
        def __init__(self, out, err):
            self.out = out
            self.err = err

        def display(self, msg, color=None, stderr=False, screen_only=False, log_only=False):
            msg = msg.rstrip()
            if stderr:
                self.err.write(msg)
            else:
                self

# Generated at 2022-06-23 09:50:14.278612
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    # Initialize test resources
    class MockDisplay:
        def __init__(self):
            self.display_result = ''
        def display(self, string, color=None):
            self.display_result = string
    class MockHost:
        def __init__(self):
            self.name = 'host1'
    class MockResult:
        def __init__(self):
            self.host = MockHost()
            self.result = {'msg': "msg1"}

    # Step 1: Test when msg key is missing in result
    callback = CallbackModule()
    callback._display = MockDisplay()
    mock_result = MockResult()
    del mock_result.result['msg']
    callback.v2_runner_on_unreachable(mock_result)

# Generated at 2022-06-23 09:50:15.153804
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    pass

# Generated at 2022-06-23 09:50:18.973256
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule.CALLBACK_VERSION == 2.0
    assert CallbackModule.CALLBACK_TYPE == 'stdout'
    assert CallbackModule.CALLBACK_NAME == 'oneline'

# Generated at 2022-06-23 09:50:21.207790
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    mock_display = Mock()
    callback_module = CallbackModule(display=mock_display)

# Generated at 2022-06-23 09:50:29.696079
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    
    # Initialize instance of class with test paramters
    test_callback = CallbackModule(display=None)

    # Create test object for AnsibleTaskResult
    result = AnsibleTaskResult(task=None, host=None, task_fields={}, result={})
    result._result={}
    result._result['changed']=False
    # Execute method v2_runner_on_skipped of class CallbackModule
    test_callback.v2_runner_on_skipped(result=result)
    
    # Assertion whether the result given as output is correct or not
    assert result._result['changed'] == False


# Generated at 2022-06-23 09:50:33.349813
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    obj = CallbackModule()
    assert obj.CALLBACK_VERSION == 2.0
    assert obj.CALLBACK_TYPE == 'stdout'
    assert obj.CALLBACK_NAME == 'oneline'

# Generated at 2022-06-23 09:50:41.449583
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    import sys
    import os

    os.environ['ANSIBLE_CONFIG'] = './callback_plugins/config'
    callback = CallbackModule()

    C.DISPLAY_OK_HOSTS = False
    C.DISPLAY_SKIPPED_HOSTS = False
    C.DISPLAY_FAILED_STDERR = False

    callback.v2_runner_on_failed(result=None, ignore_errors=True)
    callback.v2_runner_on_ok(result=None)
    callback.v2_runner_on_unreachable(result=None)
    callback.v2_runner_on_skipped(result=None)

if __name__ == '__main__':
    test_CallbackModule

# Generated at 2022-06-23 09:50:50.391396
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    result = dict()

    # exception exists in result
    result['exception'] = "this is an exception"

    # verbosity < 3
    stdout_instance = ((sys.stdout, CallbackModule, True),)
    with mock.patch.object(builtins, 'print', side_effect=print, create=True) as mock_stdout:
        with mock.patch.object(callback, '_display', stdout_instance):
            callback.v2_runner_on_failed(result)
            expected = "An exception occurred during task execution. To see the full traceback, use -vvv. The error was: this is an exception"
            assert mock_stdout.called
            assert mock_stdout.call_args[0] == (expected,)
            # assert mock_stdout.called_once_with(expected)

    #

# Generated at 2022-06-23 09:50:57.187078
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    ans = Ansible()
    playbook_path = os.path.join(os.getcwd(), 'playbooks', 'simple.yml')
    playbook = ans.playbook.Playbook.load(playbook_path)
    callback = ans.playbook.Callbacks.default_callback(verbose=True)
    res = ans._run_play(playbook, callback,
                        C.DEFAULT_HOST_LIST,
                        ["v2_runner_on_unreachable"],
                        "all", 1, None, None, [])
    assert res.status == 'unreachable'

# Generated at 2022-06-23 09:51:06.421754
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    msg1 = "localhost | FAILED! => {'rebooted': True, 'failed': True, 'msg': 'Non-zero return code 1', 'rc': 1}"
    msg2 = "localhost | FAILED! => {'rebooted': True, 'failed': True, 'msg': 'Non-zero return code 1', 'rc': 1, 'stderr': 'std error'}"
    msg3 = "localhost | FAILED! => {'rebooted': True, 'failed': True, 'msg': 'Non-zero return code 1', 'rc': 1, 'stderr': 'std error', 'stdout': 'std out'}"
    class TestResult(object):
        def __init__(self):
            self._host = MockHost()

# Generated at 2022-06-23 09:51:10.194943
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    result = MockResult()
    result._result = {'changed': False}
    runner_on_ok_class = CallbackModule()
    runner_on_ok_class.set_options(verbosity=3)
    runner_on_ok_class.v2_runner_on_ok(result)

# Generated at 2022-06-23 09:51:13.422977
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    """
    This function will be used as unittest for constructor of class CallbackModule
    """
    obj = CallbackModule()
    assert obj is not None

# Generated at 2022-06-23 09:51:15.812297
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert 'CallbackModule' == CallbackModule.__name__
    assert 'stdout' == CallbackModule.CALLBACK_TYPE

# Generated at 2022-06-23 09:51:25.766555
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Test with correct data
    result_value_1 = {'exception': 'An exception occurred during task execution. The full traceback is:\n Traceback (most recent call last):\n  File "/usr/lib/python2.7/dist-packages/ansible/plugins/callback/oneline.py", line 10, in <module>\n    from ansible.plugins.callback import CallbackBase\n  File "/usr/lib/python2.7/dist-packages/ansible/plugins/callback/__init__.py", line 28, in <module>\n    from ansible.plugins.action.network import ActionModule as ActionNetwork\nImportError: No module named network\n\nThe error was: No module named network', 'rc': -1}

# Generated at 2022-06-23 09:51:30.933796
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    # Setup an instance of CallbackModule to test
    oneline_callback = CallbackModule()
    result = type('DummyResult', (object,), {})
    result.hostname = "dummy_hostname"

    # Test the function
    oneline_callback.v2_runner_on_skipped(result)

# Generated at 2022-06-23 09:51:35.205997
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    """
    Unit test for method v2_runner_on_unreachable of class CallbackModule
    """
    # Params
    p_result = None
    p_verbosity = 2

    # Call the method
    x = CallbackModule()
    x.set_options(verbosity=p_verbosity)
    x.v2_runner_on_unreachable(p_result)

# Generated at 2022-06-23 09:51:39.794619
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    cm = CallbackModule()
    assert cm.CALLBACK_VERSION == 2.0
    assert cm.CALLBACK_TYPE == 'stdout'
    assert cm.CALLBACK_NAME == 'oneline'


# Generated at 2022-06-23 09:51:44.141053
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    ansible.callbacks.oneline = CallbackModule()
    ansible.callbacks.oneline.v2_runner_on_failed(result='', ignore_errors=False)


# Generated at 2022-06-23 09:51:53.455106
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    from ansible.playbook.task import Task
    from ansible.vars.hostvars import HostVars

    callback = CallbackModule()
    runner_result = dict(host=dict(name="localhost"))
    runner_result['task'] = Task()
    runner_result['task'].action = 'setup'
    runner_result['_host'] = HostVars(runner_result['host'])
    runner_result['_result'] = dict(msg="test")

    callback.v2_runner_on_skipped(runner_result)

    #TODO: test stdout is correct

# Generated at 2022-06-23 09:51:54.181167
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    assert False


# Generated at 2022-06-23 09:52:01.175854
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    host = 'some_hostname'
    msg = 'A message about some unreachable host'
    result = {}
    result['msg'] = msg
    result['_host'] = host
    result['_result'] = {}
    result['_result']['msg'] = msg
    c = CallbackModule()
    c.v2_runner_on_unreachable(result)

# Generated at 2022-06-23 09:52:09.441699
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.module_utils._text import to_native

    class AnsibleV1Call:
        def __init__(self, result):
            self._result = result
            self._task = AnsibleV1Task()
            self._task.action = 'command'
            self._host = AnsibleV1Host()
            self._host.get_name = lambda: 'testhost'
    class AnsibleV1Task:
        def __init__(self):
            self.action = None
    class AnsibleV1Host:
        def __init__(self):
            self.name = 'testhost'
    class Display:
        def __init__(self):
            self.verbosity = 0
        def display(self, message, color=None):
            print(message)

    test_result = dict()
    test_result

# Generated at 2022-06-23 09:52:15.755013
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    # Test CallbackModule.v2_runner_on_unreachable with no 'msg' argument.
    cb = CallbackModule()
    cb._display.verbosity = 3
    cb.v2_runner_on_unreachable(result=object())
    # Test CallbackModule.v2_runner_on_unreachable with 'msg' argument.
    cb.v2_runner_on_unreachable(result=object())

# Generated at 2022-06-23 09:52:16.500157
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    CallbackModule()

# Generated at 2022-06-23 09:52:26.584844
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    from ansible.plugins.callback import CallbackBase
    from ansible.plugins.callback.default import CallbackModule
    from ansible import constants as C

    mocked_display = CallbackBase()
    mocked_display.verbosity = 0
    mocked_result = CallbackBase()
    mocked_result._host = CallbackBase()
    mocked_result._host.get_name = lambda: 'test_host'

    test_module = CallbackModule()
    test_module.set_options(direct={'verbosity': 0})
    test_module._display = mocked_display

    test_module.v2_runner_on_skipped(mocked_result)

# Generated at 2022-06-23 09:52:33.011866
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    result = type('result', (object,), { '_result' : {
        'exception' : ''
    }, '_task' : type('task', (object,), { 'action' : '' })})
    obj = type('', (object,), { '_display' : type('display', (object,), { 'verbosity' : 1 }),
                                '_dump_results' : lambda x, y: '' })
    callback_module = CallbackModule(None)
    callback_module.__class__.__bases__ = (obj,)
    callback_module.v2_runner_on_failed(result)


# Generated at 2022-06-23 09:52:41.912514
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    m = CallbackModule()
    m.C = C
    m.C.COLOR_ERROR = False

# Generated at 2022-06-23 09:52:42.864898
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    return CallbackModule()

# Generated at 2022-06-23 09:52:47.361516
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    result = type('obj', (object,), {'_host':'test', '_result':{}})
    module = CallbackModule()
    expected = "%s | SKIPPED" % result._host
    assert module.v2_runner_on_skipped(result) == expected


# Generated at 2022-06-23 09:52:47.876959
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    pass

# Generated at 2022-06-23 09:52:49.638359
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    """Test constructing CallbackModule object"""
    callback = CallbackModule()
    assert callback is not None

# Generated at 2022-06-23 09:53:00.958816
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    from ansible.plugins.loader import callback_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.helpers import load_list_of_tasks
    from ansible.playbook.task import Task
    import ansible.constants as C
    import json


# Generated at 2022-06-23 09:53:09.814405
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    callback = CallbackModule()
    class Result:
        class Host:
            def __init__(self):
                self.name = "host"

            def get_name(self):
                return self.name
        def __init__(self, host, result):
            self._host = host
            self._result = result
    host = Result.Host()
    result = {
        'msg' : "error message"
    }
    result = Result(host, result)
    expected = "host | UNREACHABLE!: error message"
    assert callback.v2_runner_on_unreachable(result) == expected

# Generated at 2022-06-23 09:53:21.596178
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    import json
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from shutil import copy
    import os
    from ansible.config.manager import ConfigManager
    from ansible.errors import AnsibleError, AnsibleOptionsError
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play 
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import merge_hash
    import logging
    import pprint
    #from ansible.plugins.callback import CallbackModule
    
    # Setup logging
    logging.basicConfig(level=logging.DEBUG)
    
    # Read config file to get configuration

# Generated at 2022-06-23 09:53:32.109798
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Unit test for method v2_runner_on_failed of class CallbackModule
    #
    # ABSTRACT:
    #  The method v2_runner_on_failed of class CallbackModule is used to print the results of a failed command execution.
    #  These results can be in several formats:
    #   - 'module_stdout'
    #   - 'module_stderr'
    #   - 'exception'
    #
    #
    # SETUP:
    #   Define the Test Class
    class TestClass(CallbackModule):
        def __init__(self):
            super(TestClass, self).__init__()
            self._display = Display()
    
    

# Generated at 2022-06-23 09:53:36.889187
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    def test_callback_module_can_be_imported():
        import ansible.plugins.callback.oneline
        print("SUCC: ansible.plugins.callback.oneline is importable.")

    test_callback_module_can_be_imported()

if __name__ == "__main__":
    test_CallbackModule()

# Generated at 2022-06-23 09:53:44.224358
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    """
    Unit test for method v2_runner_on_skipped.
    """
    callbackModule = CallbackModule()
    result = type('result', (object,), {'_host': type('host', (object,), {'get_name': 'hostname'}), '_task': type('task', (object,), {})})
    result._result = {'msg': 'msg'}
    callbackModule.v2_runner_on_skipped(result)

# Generated at 2022-06-23 09:53:45.410239
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    cbm = CallbackModule()
    assert cbm


# Generated at 2022-06-23 09:53:52.093042
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase

    class TestCallbackModule(CallbackBase):
        """
        A test class for testing v2_runner_on_ok.
        """
        CALLBACK_VERSION = 2.0
        CALLBACK_TYPE = 'stdout'
        CALLBACK_NAME = 'oneline'

        def __init__(self):
            super(CallbackModule, self).__init__()
            self.notify_called_with = None

        def v2_runner_on_ok(self, result):
            self.runner_on_ok_called = True
            self.runner_on_ok_called_with = result

    # new object
    tcm = TestCallbackModule()

    # the object should be type of CallbackModule
    assert(isinstance(tcm, CallbackBase))

    # the notify

# Generated at 2022-06-23 09:53:53.242130
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert type(CallbackModule) == type

# Generated at 2022-06-23 09:54:02.493382
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    c = CallbackModule()
    c.CALLBACK_NAME = "oneline"
    c.CALLBACK_TYPE = "stdout"
    c.CALLBACK_VERSION = 2.0
    # Must have same structure as result._result
    result_result = {
            "changed": True,
            "results": []
            }
    # Must have same structure as result._host
    result_host = {
            "get_name": lambda: "hostname"
            }
    # Must have same structure as result
    result = {
            "_host": result_host,
            "_result": result_result
            }
    c.v2_runner_on_ok(result)

# Generated at 2022-06-23 09:54:14.087830
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    class FakeResult:
        def __init__(self, host, exception):
            self._host = host
            self._result = {}
            self._result['exception'] = exception
            self._task = None
            self._result['stderr'] = "Some STDERR"
    result = FakeResult("localhost", "Some error message")

    # Test for the display message when verbosity is less than 3
    callback = CallbackModule()
    callback._display.verbosity = 2 # verbosity is hardcoded to 2
    expected_result = "An exception occurred during task execution. To see the full traceback, use -vvv. The error was: Some error message"
    assert (callback.v2_runner_on_failed(result) == expected_result)

    # Test for the display message when verbosity is greater than 2
    callback = CallbackModule

# Generated at 2022-06-23 09:54:16.865310
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():

    test_result = dict()
    test_result['msg'] = 'test message'

    cm = CallbackModule()
    oneline = cm.v2_runner_on_unreachable(test_result)

    assert oneline == "test_runner_on_unreachable | UNREACHABLE!: test message"



# Generated at 2022-06-23 09:54:24.531169
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Create an instance of CallbackModule
    callback_module = CallbackModule()

    # Create a fake result 
    result = object()
    setattr(result, '_result', {'changed': False})

    # Create an instance of Host
    host = object()
    setattr(result, '_host', host)
    setattr(host, 'get_name', lambda: 'n1.example.com')

    # Create an instance of Display
    display = object()
    setattr(callback_module, '_display', display)
    setattr(display, 'display', lambda x, y: print(x))

    callback_module.v2_runner_on_ok(result)
    assert True

# Generated at 2022-06-23 09:54:28.181522
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    class Options():
        show_custom_stats = True
        skip_tags = []
        start_at_task = None
        step = None
        subset = None
        tags = []
        verbosity = 1
        extra_vars = []
        inventory = 'ansible/inventory/hosts'
        listhosts = False
        modules_path = None
        forks = 5
        remote_user = 'root'
        remote_port = 22
        private_key_file = None
        ssh_common_args = ''
        ssh_extra_args = ''
        sftp_extra_args = ''
        scp_extra_args = ''
        become = False
        become_method = None
        become_user = None
        become_ask_pass = False
        ask_pass = False
        ask_become_pass = False

# Generated at 2022-06-23 09:54:37.755263
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create instance of class being tested
    test_obj = CallbackModule()

    # Create mock object of ansible.plugins.callback.CallbackBase
    mock_CallbackBase = mock.create_autospec(CallbackBase)

    # Create mock object of __builtin__.dict
    mock_dict = mock.create_autospec(dict)
    # Set values of instance attributes of mock_dict
    mock_dict.__dict__ = {'_result': {'exception': 'mock_exception'}}

    # Perform the test
    test_result = test_obj.v2_runner_on_failed(mock_dict, ignore_errors=False)

    # Assertions
    assert test_result == None
