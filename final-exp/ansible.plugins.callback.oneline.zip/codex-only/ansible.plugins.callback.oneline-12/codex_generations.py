

# Generated at 2022-06-23 09:44:40.979504
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Test when with exception in result
    pass


# Generated at 2022-06-23 09:44:44.407833
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    result = {'changed': False}
    msg = "localhost | SUCCESS => %s"%(result)
    assert msg == CallbackModule.v2_runner_on_ok(result).display()


# Generated at 2022-06-23 09:44:47.362424
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

    # Create the class object
    c = CallbackModule()

    # Call the method with a test result
    result = {
        '_result': {
            'changed': False,
        },
        '_task': {
            'action': 'my_action'
        },
        '_host': {
            'get_name': lambda: 'my_hostname'
        },
    }
    c.v2_runner_on_ok(result)

# Generated at 2022-06-23 09:44:57.192654
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    # GIVEN
    result = {'_host': {'get_name': Mock()}}
    result['_host']['get_name'].return_value = 'localhost'

    class MockDisplay:
        def display(self, msg, color):
            print('DISPLAY %s %s' % (msg, color))
    display = MockDisplay()

    oneline = CallbackModule()
    oneline._display = display

    # WHEN
    oneline.v2_runner_on_skipped(result)

    # THEN
    assert(display.display.call_args[0][0] == 'localhost | SKIPPED')
    assert(display.display.call_args[1] == {'color': 'skip'})


# Generated at 2022-06-23 09:44:57.989837
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert type(CallbackModule()) == CallbackModule

# Generated at 2022-06-23 09:45:03.718836
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    # Test for the case where all the data has already been collected
    # in a single collection
    c = CallbackModule()
    #mock the result object
    class result_obj:
        _host = None
        _result = {'msg': ''}
    #mock the host object
    class host_obj:
        def get_name(self):
            return 'localhost'
    ro = result_obj()
    ro._host = host_obj()
    c.v2_runner_on_unreachable(ro)

    # Test for the case where the data is collected over multiple collections
    # in a single collection
    c = CallbackModule()
    #mock the result object
    class result_obj:
        _host = None
        _result = {'msg': ''}
    #mock the host object

# Generated at 2022-06-23 09:45:07.713088
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    pass

# Generated at 2022-06-23 09:45:08.514596
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    pass

# Generated at 2022-06-23 09:45:13.934381
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible import context
    from ansible.utils.plugins import plugin_loader
    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        passwords=None,
        stdout_callback=None,
    )
    cb = CallbackModule()
    cb.v2_runner_on_skipped(result=None)



# Generated at 2022-06-23 09:45:15.084660
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert not CallbackModule()

# Generated at 2022-06-23 09:45:15.673167
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
  assert True

# Generated at 2022-06-23 09:45:25.408349
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
  """
  Tests that CallbackModule.v2_runner_on_skipped() displays a SKIPPED
  message with color C.COLOR_SKIP.
  """

  # Create a mock display to use for testing.
  class MockDisplay():
    def __init__(self):
      self.display_items = []

    def display(self, msg, color):
      self.display_items.append((msg, color))

  # Create a message to use for testing.
  class MockMessage():
    def __init__(self):
      self.name = "test_host"

  # Create a mock result to use for testing.
  class MockResult():
    def __init__(self):
      self._host = MockMessage()

  # Create an instance of CallbackModule to use for testing.
  mock_callback_module = Callback

# Generated at 2022-06-23 09:45:32.413425
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    class Result:
        def __init__(self):
            self._host = "host"
            self._task = "task"
            self._result = {"changed":True, "invocation": {"module_args": {"key":"value"}}}

    result = Result()
    outcome = "host | CHANGED => {'changed': True, 'invocation': {'module_args': {'key': 'value'}}, '_ansible_no_log': False}"
    assert(CallbackModule().v2_runner_on_ok(result)).strip() == outcome


# Generated at 2022-06-23 09:45:36.477998
# Unit test for constructor of class CallbackModule
def test_CallbackModule():

    assert(CallbackModule.CALLBACK_VERSION == 2.0)
    assert(CallbackModule.CALLBACK_TYPE == 'stdout')
    assert(CallbackModule.CALLBACK_NAME == 'oneline')
    assert(CallbackModule.__dict__['_CallbackModule_._options'] == {})

    callback = CallbackModule()


# Generated at 2022-06-23 09:45:40.096773
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C

    callback = CallbackModule()
    result = 'unreachable'
    callback.v2_runner_on_unreachable(result)

# Generated at 2022-06-23 09:45:44.085831
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # Test the constructor
    plugin = CallbackModule()
    assert plugin is not None

    # Test that missing CallbackBase methods raise exceptions
    exceptionCaught = False
    try:
        plugin.v2_runner_on_failed(None)
    except NotImplementedError:
        exceptionCaught = True
    assert exceptionCaught

# Generated at 2022-06-23 09:45:44.741066
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert True

# Generated at 2022-06-23 09:45:51.354219
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    """
    v2_runner_on_ok(result)
    """
    # Setup the test CallbackModule
    t = CallbackModule()

    # Setup test case inputs
    result = {}

    # Call onelineCallback.v2_runner_on_ok with the test inputs
    t.v2_runner_on_ok(result)


# Generated at 2022-06-23 09:46:06.013344
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
   # Given
   from ansible.plugins.callback import CallbackBase
   from ansible import constants as C
   import os
   import sys

   class MockDisplay():
     def display(self, buffer, color, stderr=False, screen_only=False, log_only=False):
       print(buffer)

   class MockResult():
     def __init__(self):
       self._result = dict(exception='test exception')
       self._task = dict(action='test action')
       self._host = dict(get_name=lambda: 'test.com')

   callback = CallbackModule()
   callback.set_options(dict(verbosity=0))
   callback._display = MockDisplay()

   # When
   try:
     callback.v2_runner_on_failed(MockResult())
   except:
     pass

# Generated at 2022-06-23 09:46:11.713103
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Arrange
    testcmd = CallbackModule()
    res = type('object', (object,), {"_result":{"ansible_job_id":"1"}})

    # Act
    testcmd.v2_runner_on_ok(res)

    # Assert



# Generated at 2022-06-23 09:46:19.923308
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    import json
    import re 
    callbackModule = CallbackModule()
    result = {}
    result['changed'] = False
    result['_ansible_verbose_always'] = True
    result['_ansible_no_log'] = False
    result['_ansible_verbosity'] = 2
    result['_ansible_parsed'] = False
    result['_ansible_debug'] = False
    result['_ansible_item_result'] = False
    result['_ansible_ignore_errors'] = False
    result['_ansible_delegate_to'] = None
    result['_ansible_diff'] = False
    result['_ansible_select_hosts'] = ['localhost']
    result['_ansible_check_mode'] = False

# Generated at 2022-06-23 09:46:24.811441
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()._command_generic_msg('hostname', {'stdout': 'stdout', 'rc': 0, 'stderr': 'stderr'}, 'caption') == 'hostname | caption | rc=0 | (stdout) stdout\\n (stderr) stderr'

# Generated at 2022-06-23 09:46:27.990801
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback = CallbackModule()
    assert callback is not None
    assert isinstance(callback, CallbackModule)
    assert callback.CallBackVersion == 2.0
    assert callback.CallBackType == 'stdout'
    assert callback.CallBackName == 'oneline'

# Generated at 2022-06-23 09:46:28.825812
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    pass


# Generated at 2022-06-23 09:46:37.018547
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():

    class FakeDisplay:
        def __init__(self):
            self.output = ''

        def display(self, msg, color):
            self.output = self.output + msg

    class FakeResult:

        def __init__(self):
            self._result = dict(msg='failed to connect to remote host')
            self._host = 'dummy'

    callback = CallbackModule(FakeDisplay())
    callback.v2_runner_on_unreachable(FakeResult())

    assert u' | UNREACHABLE!: failed to connect to remote host' == callback._display.output

# Generated at 2022-06-23 09:46:47.959084
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback.oneline import CallbackModule
    class MockHost:
        def get_name(self):
            return "test-host"
    class MockResult:
        def __init__(self, changed=False, _task="test-task", _result="test-result"):
            self._result = {"changed": changed, "test": "result"}
            self._task = _task
            self._host = MockHost()
    class MockDisplay:
        def __init__(self):
            self.displayed = []
        def display(self, text, color):
            self.displayed.append(text)
    display = MockDisplay()
    result = MockResult()
    callback = CallbackModule(display)
    callback.v2_runner_on_ok(result)

# Generated at 2022-06-23 09:46:48.884007
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    cls = CallbackModule()

# Generated at 2022-06-23 09:46:53.954781
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    callback = CallbackModule()
    callback._display = object
    callback._display.display = test_display
    class Result:
        _host = object
        _host.get_name = test_host
        _result = object
        _result.get = test_get_msg
        _result.update = test_update
    callback.v2_runner_on_unreachable(Result)
    assert callback._display.unreachable_msg == 'Host | UNREACHABLE!: message'



# Generated at 2022-06-23 09:47:04.293767
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    import json
    import os

    # test constructor
    res_callback = CallbackModule()

    # test method v2_runner_on_failed
    results = json.loads(open(os.path.join(os.path.dirname(__file__), 'mock', 'results.json')).read())

    # no.1 test
    print(res_callback.v2_runner_on_failed(results[0]))

    # no.2 test
    print(res_callback.v2_runner_on_failed(results[1]))

    # no.2 test
    print(res_callback.v2_runner_on_failed(results[1], ignore_errors=True))

    # test method v2_runner_on_ok
    # no.1 test

# Generated at 2022-06-23 09:47:13.162217
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    class TestClass(CallbackBase):
        def __init__(self):
            self.success_msg = []
            self.fail_msg = []

        def display(self, msg, color=None, stderr=False, screen_only=False, log_only=False):
            self.success_msg.append(str(msg))

        def v2_runner_on_ok(self, result):
            self.v2_runner_on_ok_msg = "%s | %s => %s" % (result._host.get_name(), 'SUCCESS', self._dump_results(result._result, indent=0).replace('\n', ''))

    class TestSuccessClass(object):
        _result = {'changed': True}


# Generated at 2022-06-23 09:47:14.540148
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    global cb
    cb = CallbackModule()
    assert cb is not None

# Generated at 2022-06-23 09:47:24.827256
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():

    import mock
    import copy
    import json

    def _strip_ansible_result(result_dict):
        ''' this function is useful to strip Ansible result specific
        attributes '''
        result_dict_copy = copy.deepcopy(result_dict)
        if 'invocation' in result_dict_copy:
            del result_dict_copy['invocation']
        if 'diff' in result_dict_copy:
            del result_dict_copy['diff']
        return result_dict_copy


# Generated at 2022-06-23 09:47:34.544359
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    test_model = {
        "_result": {
            "_ansible_parsed": True,
            "_ansible_no_log": False,
            "skipped": True
        },
        "_task": {
            "action": "debug",
            "loop_control": {},
            "name": "Gathering Facts"
        },
        "_host": {
            "name": "127.0.1.1"
        }
    }

    m = CallbackModule()

    m.v2_runner_on_skipped(test_model)



# Generated at 2022-06-23 09:47:49.500532
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # mock result
    result = {}
    result['_result'] = {}
    result['_task'] = {}
    result['_result']['exception'] = 'An error occurred'
    result['_task']['action'] = 'ping'
    result._host = MockHost()

    # run v2_runner_on_failed
    display = MockDisplay()
    display.verbosity = 1
    cm = CallbackModule(display)
    cm.v2_runner_on_failed(result)

    # check result
    assert display.result[0] == 'test_host | FAILED! => {\'exception\': \'An error occurred\'}'
    assert display.result[1] == 'An exception occurred during task execution. To see the full traceback, use -vvv. The error was: An error occurred'



# Generated at 2022-06-23 09:47:56.230140
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    test_result = {
        "_host": "127.0.0.1",
        "_result": {
            "changed": False,
            "skipped": True,
            "skip_reason": "Conditional result was False",
            "invocation": {
                "module_args": {
                    "name": "Test_Output"
                },
                "module_name": "win_shell"
            }
        }
    }

    assert CallbackModule().v2_runner_on_skipped(test_result) == True

# Generated at 2022-06-23 09:48:07.724154
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # By testing the return value of the method, we are actually testing the output of the method
    # i.e the print statement
    result = {}
    result['exception'] = 'exception raised'
    result['_result'] = {'exception': 'exception raised', 'failed_when_result': 'error'}
    result['_result']['ansible_job_id'] = 'not-null'
    callbackModule = CallbackModule()
    result['_task'] = {'action': 'copy'}
    result['_host'] = {'get_name': lambda: 'ansible'}

# Generated at 2022-06-23 09:48:15.904537
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    # Prepare test objects
    ansible_runner_result = unittest.mock.MagicMock()
    ansible_runner_result.host = unittest.mock.MagicMock()
    ansible_runner_result.host.get_name = unittest.mock.MagicMock(return_value='testhost')
    ansible_runner_result._result = unittest.mock.MagicMock(return_value='test message')
    callback = CallbackModule()
    # Test v2_runner_on_unreachable
    callback.v2_runner_on_unreachable(ansible_runner_result)



# Generated at 2022-06-23 09:48:18.930425
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule.CALLBACK_VERSION == 2.0
    assert CallbackModule.CALLBACK_TYPE == 'stdout'
    assert CallbackModule.CALLBACK_NAME == 'oneline'

# Generated at 2022-06-23 09:48:28.224044
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    # Prepare a callback module
    cm = CallbackModule()

    # Prepare a result object
    ro = ResultObject()

    # Prepare a dummy host
    h = Host()
    h.get_name = MagicMock(return_value='foo')

    # Prepare a display
    d = Display()
    d.display = MagicMock(return_value=None)

    # Set the display of the callback module
    cm._display = d

    # Set a host for the result object
    ro._host = h

    # Execute callback
    cm.v2_runner_on_skipped(ro)

    # Check
    d.display.assert_called_once_with("foo | SKIPPED", color='yellow')


# Generated at 2022-06-23 09:48:33.338051
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    callbackModule = CallbackModule()
    result = {'_host': {'get_name': 'test_hostname'}, '_result': {'msg': 'test_msg'}}
    callbackModule._display.display = MagicMock()
    callbackModule.v2_runner_on_skipped(result)
    callbackModule._display.display.assert_called_with("test_hostname | SKIPPED", color=C.COLOR_SKIP)


# Generated at 2022-06-23 09:48:36.799960
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    #print(CallbackModule)
    module = CallbackModule()
    #print(module)
    #pass

if __name__ == '__main__':
    test_CallbackModule()

# Generated at 2022-06-23 09:48:47.123870
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module = CallbackModule()
    cmd = 'ls /hoge'

# Generated at 2022-06-23 09:48:57.916443
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    assert CallbackModule.CALLBACK_VERSION == 2.0
    assert CallbackModule.CALLBACK_TYPE == 'stdout'
    assert CallbackModule.CALLBACK_NAME == 'oneline'
    test_CallBackModuleInstance = CallbackModule()    
    

# Generated at 2022-06-23 09:49:00.337031
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    cb = CallbackModule()
    assert(type(cb) is CallbackModule)

# Generated at 2022-06-23 09:49:11.107523
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    result = {
        '_host': {
            'get_name': lambda: 'hostname'
        },
        '_result': {
            'changed': False
        },
        '_task': {
            'action': 'setup'
        }
    }
    c = CallbackModule()
    c.v2_runner_on_skipped(result)
    assert c._display.display.call_count == 1
    assert result == {
        '_host': {
            'get_name': lambda: 'hostname'
        },
        '_result': {
            'changed': False
        },
        '_task': {
            'action': 'setup'
        }
    }
    assert c._display.display.call_args_list[0][0][0] == '%s | SKIPPED'


# Generated at 2022-06-23 09:49:16.694155
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    my_module = CallbackModule()
    result = type('', (), {'_host': type('', (), {'get_name': lambda self: 'localhost'}), '_result': {'msg': 'unreachable!'}})
    my_module.v2_runner_on_unreachable(result)


# Generated at 2022-06-23 09:49:20.752291
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    result = dict(msg='test')
    host = dict(name='test')
    res = dict(result=result, _host=host)
    m = CallbackModule()
    assert m.v2_runner_on_unreachable(res) == 'test | UNREACHABLE!: test'


# Generated at 2022-06-23 09:49:26.313943
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    result = {
            "_host": {
                "get_name": lambda: "localhost"
            },
    }

    class Display:
        def display(self, msg, color=None):
            print(msg)

    display = Display()
    cb = CallbackModule(display=display)
    cb.v2_runner_on_unreachable(result)



# Generated at 2022-06-23 09:49:27.702185
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    c = CallbackModule()
    assert c



# Generated at 2022-06-23 09:49:34.936579
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    cb = CallbackModule()

# Generated at 2022-06-23 09:49:41.789656
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Arrange
    import sys
    import json

    # Action
    result = {'failed': True, 'verbose_override': True, 'msg': 'Unexpected failure during module execution', 'stderr': '', 'stdout': '', 'rc': 0}
    if sys.version_info[0] > 2:
        result = json.dumps(result)
    cb = CallbackModule()
    cb.v2_runner_on_failed(result)

    # Assert
    assert True

# Generated at 2022-06-23 09:49:51.679565
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    from ansible.plugins.callback import CallbackModule
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.inventory.host import Host
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.text.converters import to_bytes
    import json
    from io import String

# Generated at 2022-06-23 09:50:02.357462
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    import json
    import mock
    import sys
    from ansible.utils.color import colorize
    from ansible.plugins.callback import CallbackBase

    class TestCallbackModule(CallbackBase):
        CALLBACK_VERSION = 2.0
        CALLBACK_TYPE = 'stdout'
        CALLBACK_NAME = 'oneline'

        def __init__(self):
            self.__output = ''

        def _display(self, msg, color=None, stderr=False, screen_only=False, log_only=False):
            # Record output for verification
            self.__output += msg + '\n'

        def _dump_results(self, result):
            # Make a string of the results for display.  Note: the
            # indirection in the result is to protect against result
            # being modified in place.
            return

# Generated at 2022-06-23 09:50:13.924587
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Testing with expected output
    class TestCallback(CallbackModule):
        def __init__(self, result):
            CallbackModule.__init__(self)
            self.result = result

        def display(self, msg, color=None, stderr=False, screen_only=False, log_only=False):
            self.msg = msg

    cb = TestCallback({'changed':False})
    cb.v2_runner_on_ok(cb.result)

    # Testing with unexpected output
    class TestCallback(CallbackModule):
        def __init__(self, result):
            CallbackModule.__init__(self)
            self.result = result

        def display(self, msg, color=None, stderr=False, screen_only=False, log_only=False):
            self.msg = msg



# Generated at 2022-06-23 09:50:25.574058
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    oneline = CallbackModule()

    task = {
        'id': '12345',
        'version': 1,
        'vars': {
            'key': 'value'
        }
    }

    action = 'gather_facts'


# Generated at 2022-06-23 09:50:34.812760
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # set up 
    import ansible
    ansible.constants.ANSIBLE_LOG_PATH = "ansible_playbook.log"
    callback = CallbackModule()  
    host = MockHost("host1")
    result = MockRunnerResult(host, 'failed')

    # run test
    callback.v2_runner_on_failed(result)

    # expected result
    assert callback._display.display.call_count == 2
    assert callback._display.display.call_args_list[0][0][0].startswith("host1")
    assert callback._display.display.call_args_list[0][0][0].endswith(": FAILED! => None")
    assert callback._display.display.call_args_list[0][0][1] == "dark red"

# Generated at 2022-06-23 09:50:42.860089
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    result = {'changed': False, 'result': {'foo': 'bar'}, '_ansible_no_log': False, '_ansible_item_result': False, '_ansible_verbose_always': True, '_ansible_verbose_override': False, '_ansible_ignore_errors': None, '_ansible_item_label': None, 'invocation': {'module_args': {'src': '/root/.ssh/id_rsa', 'owner': 'root', 'path': '/home/demo/.ssh/id_rsa', 'state': 'link', 'group': 'demo'}}, '_ansible_parsed': True, 'item': None}
    result_obj = ''
    c = CallbackModule(display=result_obj)

# Generated at 2022-06-23 09:50:51.087908
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    import sys
    import pdb
    import os
    import importlib

    # Create environment to test the method
    # load the example library and class under test
    path_name = os.path.dirname(__file__)
    cwd, tail = os.path.split(path_name)
    sys.path.append(os.path.join(cwd, '..', 'lib'))
    lib_name = 'ansible.plugins.callback'
    lib_mod = importlib.import_module(lib_name)

    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C

    # reload the CallbackModule class from the example library
    mod_name = 'CallbackModule'
    mod_class = getattr(lib_mod, mod_name)
    callback_obj = mod_class()



# Generated at 2022-06-23 09:50:54.060489
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    import pytest
    call = CallbackModule()
    result = {'_host': {'get_name':lambda: 'test'}, '_result': {'msg': 'test msg'}}
    with pytest.raises(SystemExit) as p:
        call.v2_runner_on_unreachable(result)

# Generated at 2022-06-23 09:50:57.923440
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    '''
    Unit test for constructor of class CallbackModule
    :return:
    '''
    obj = CallbackModule()
    assert obj



# Generated at 2022-06-23 09:51:00.583884
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    fakeResult = object()
    fakeDisplay = object()
    m = CallbackModule(load_options=dict(), display=fakeDisplay)
    m.v2_runner_on_skipped(fakeResult)

# Generated at 2022-06-23 09:51:11.551827
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Tests for the method v2_runner_on_failed of class CallbackModule
    # with its specific input and expected output
    # Input 1
    from ansible.plugins.callback.oneline import CallbackModule
    from ansible.utils.color import ANSIBLE_COLOR, stringc
    from ansible.plugins.callback import CallbackBase

    display = CallbackModule.CallbackModule()
    file = open('./mylog4', 'a+')

    result = {}
    result['_result'] = {}
    result['_result']['exception'] = '''UnexpectedException: 'dict' object has no attribute 'check_mode'''
    result['_result']['changed'] = False
    result['_task'] = {'action': None}
    display.verbosity = 3

    display.display = ''
    display

# Generated at 2022-06-23 09:51:16.461285
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    r = None
    result = MockResult({"msg": "Foo"})
    result._host = MockHost("server1")
    c = CallbackModule()
    assert 'server1 | UNREACHABLE!: Foo' == c.v2_runner_on_unreachable(result)


# Generated at 2022-06-23 09:51:20.867283
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    callback = CallbackModule()
    result = {'msg': 'msg'}
    host = {'get_name': lambda: 'hostname'}
    assert callback.v2_runner_on_unreachable({'_result': result, '_host': host}) == 'hostname | UNREACHABLE!: msg'

# Generated at 2022-06-23 09:51:25.040178
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    c = CallbackModule()
    assert c.CALLBACK_VERSION == 2.0
    assert c.CALLBACK_TYPE == 'stdout'
    assert c.CALLBACK_NAME == 'oneline'

# Generated at 2022-06-23 09:51:25.699511
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    pass

# Generated at 2022-06-23 09:51:30.376743
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    result = {'msg': 'test message'}
    result = type('', (object,), {'_host': result, '_result': result})
    cb = CallbackModule()
    cb.v2_runner_on_unreachable(result)


# Generated at 2022-06-23 09:51:32.959391
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    cbm = CallbackModule()
    cbm.v2_runner_on_failed(None)
    cbm.v2_runner_on_failed(None, ignore_errors=True)


# Generated at 2022-06-23 09:51:35.941293
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    mod = CallbackModule()
    mod.v2_runner_on_ok({'_result': {'changed': False}})
    mod.v2_runner_on_ok({'_result': {'changed': True}})

# Generated at 2022-06-23 09:51:38.224263
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # TODO -- this 'test' is a stub
    assert True

# Generated at 2022-06-23 09:51:46.264739
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    #Should print the same value
    value = "test_host | SUCCESS => {'test_result':True}"
    result = MockResult()
    result._host = MockHost()
    result._host.get_name = Mock(return_value="test_host")
    result._task = MockTask()
    result._result = {'test_result':True}
    callback = CallbackModule()
    callback._dump_results = Mock(return_value="{'test_result':True}")
    callback._display = Mock()
    callback.v2_runner_on_ok(result)
    callback._display.display.assert_called_once_with(value)

# Generated at 2022-06-23 09:51:56.671869
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    class Test_Runner_on_ok:
        def get_name(self):
            return "hostname"

    class Test_Task:
        def __init__(self, action):
            self.action = action

    class Test_Display:
        def __init__(self):
            self.displayCalled = False
            self.returnValue = ""
            self.callCount = 0

        def display(self, text, color):
            self.callCount += 1
            self.returnValue = text
            return self.displayCalled

    class Test_Result:
        def __init__(self, host, task, result):
            self._host = host
            self._task = task
            self._result = result

    callback_module = CallbackModule()
    callback_module._display = Test_Display()

    # Successful task -

# Generated at 2022-06-23 09:52:02.288719
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    result = DummyResult()
    result._host.get_name.return_value = 'node01'
    result._result['msg'] = 'host unreachable'
    cb = CallbackModule()
    cb.v2_runner_on_unreachable(result)


# Generated at 2022-06-23 09:52:03.787693
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_obj = CallbackModule()
    assert callback_obj.v2_runner_on_ok(result) == None

# Generated at 2022-06-23 09:52:07.127847
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule.CALLBACK_VERSION == 2.0
    assert CallbackModule.CALLBACK_TYPE == 'stdout'
    assert CallbackModule.CALLBACK_NAME == 'oneline'


# Unit tests for methods of class CallbackModule

# Generated at 2022-06-23 09:52:10.162689
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    Cm = CallbackModule()
    Cm.v2_runner_on_failed(result='test result')


# Generated at 2022-06-23 09:52:17.570244
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Arrange
    result = [{'msg': 'test one'}, {'msg': 'test two'}, {'msg': 'test three'}]
    module = CallbackModule()

    # Act
    results = [module.v2_runner_on_failed(x) for x in result]

    # Assert
    expectResults = [
        "test one | FAILED! => None",
        "test two | FAILED! => None",
        "test three | FAILED! => None"
        ]
    assert expectResults == results


# Generated at 2022-06-23 09:52:26.393374
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    callbackModule = CallbackModule()
    class Host:
        def __init__(self):
            self.name = 'test'
            self.vars = {}
        def get_name(self):
            return self.name
    class Result:
        def __init__(self):
            self._result = {}
            self._host = Host()
            self.task_name = ''
            self.item_label = ''
            self.task_action = ''
            self.meta = {}
    result = Result()
    callbackModule.v2_runner_on_skipped(result)

# Generated at 2022-06-23 09:52:32.247566
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    # Test_v2_runner_on_skipped is the pytest test function, result is the object passed by set_runner()
    result = Test_v2_runner_on_skipped()
    #result.set_runner('v2_runner_on_skipped')
    result.set_runner(result, 'v2_runner_on_ok')
    result.dump_results()
    # test_v2_runner_on_skipped()
    # print("result is %s" % result)


# Generated at 2022-06-23 09:52:40.589853
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    results = {
        "status": {
            "rc": 0,
            "msg": "Command run successfully"
        },
        "requests": [
            {
                "endpoint": "/login",
                "method": "POST",
                "path": "/login",
                "action": "add",
                "status_code": 201
            },
            {
                "endpoint": "/v1/user",
                "method": "POST",
                "path": "/v1/user",
                "action": "modify",
                "status_code": 201
            }
        ]
    }

    plugin = CallbackModule()
    plugin.v2_runner_on_ok(results)

# Generated at 2022-06-23 09:52:44.961911
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback import CallbackModule
    assert 'An exception occurred during task execution.' in CallbackModule.v2_runner_on_failed(CallbackModule, result={'exception': 'An exception occurred during task execution.'}, ignore_errors=False)


# Generated at 2022-06-23 09:52:47.954056
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    print("\n")
    print(">> Begin test_CallbackModule_v2_runner_on_skipped:")
    c = CallbackModule()
    c.v2_runner_on_skipped(result)


# Generated at 2022-06-23 09:52:55.211569
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    # verify before
    assert result._host.get_name() == 'justatest'
    assert result._result.get('msg', '') == 'Test Message'
    
    
    Module = CallbackModule()
    Module.v2_runner_on_unreachable(result)
    
    # verify after
    assert result._host.get_name() == 'justatest'
    assert result._result.get('msg', '') == 'Test Message'

# Generated at 2022-06-23 09:53:00.755385
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    result = dict()
    result['_host'] = dict()
    result['_host']['get_name'] = lambda: 'test'
    result['_result'] = dict()
    result['_result']['msg'] = 'message'
    callback = CallbackModule()
    assert callback.v2_runner_on_unreachable(result)=='test | UNREACHABLE!: message'

# Generated at 2022-06-23 09:53:06.808295
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    print("Testing function CallbackModule_v2_runner_on_unreachable()")

    class FakeResult(object):
        def __init__(self, host_name, result):
            self._host = object()
            self._host.get_name = lambda *a, **kw: host_name
            self._result = result

    class FakeDisplay(object):
        def __init__(self):
            self.log = list()

        def display(self, msg, color):
            self.log.append(msg)


    if __name__ == '__main__':
        import mock

        callback = CallbackModule()
        callback._display = FakeDisplay()

# Generated at 2022-06-23 09:53:14.119092
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    test_host = 'host'
    test_result = {}
    test_result['msg'] = 'test_message'
    test_result2 = {}
    test_result2['msg'] = None
    c = CallbackModule()
    c._display = DummyDisplay()

    # check for message
    c.v2_runner_on_unreachable(test_result, test_host)
    assert c._display.color == '\x1b[31m'
    assert c._display.msg == 'host | UNREACHABLE!: test_message'

    # check for no message
    c.v2_runner_on_unreachable(test_result2, test_host)
    assert c._display.color == '\x1b[31m'

# Generated at 2022-06-23 09:53:23.950319
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    import json
    import salt.version
    import os
    import sys
    import datetime
    import time
    import copy
    from ansible.utils.color import colorize, hostcolor
    from ansible.utils.unicode import to_unicode

    fake_gateway = '10.4.0.1'
    fake_result = {}
    fake_result['_ansible_no_log'] = False
    fake_result['_ansible_verbose_always'] = True
    fake_result['_ansible_item_label'] = None
    fake_result['_ansible_parsed'] = True
    fake_result['_ansible_no_log'] = False
    fake_result['_ansible_item_label'] = None
    fake_result['_ansible_parsed'] = True
    fake

# Generated at 2022-06-23 09:53:33.920717
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # create instance of class CallbackModule
    # use test_callback to force the display_failed_stderr = True
    oneline = CallbackModule()

    # create a result
    result = type('Result', (object,), {'_host':None, '_result': {'exception': 'mock exception'},
                                 '_task': type('MockTask', (object,), {'action': 'mock_action'})})()

    # test verbosity is 3
    oneline._display.verbosity = 3
    assert oneline.v2_runner_on_failed(result) == 'An exception occurred during task execution. The full traceback is:\nmock exception'

    # test verbosity is less than 3
    oneline._display.verbosity = 1

# Generated at 2022-06-23 09:53:37.486003
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    test_obj = CallbackModule()
    assert test_obj.CALLBACK_NAME == 'oneline'
    assert test_obj.CALLBACK_TYPE == 'stdout'
    assert test_obj.CALLBACK_VERSION == 2.0

# Generated at 2022-06-23 09:53:43.142298
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    ansible_result = {'changed': False, 'stdout': 'hello world'}
    host = 'test_host'
    fake_display = 'fake_display'
    result = CallbackModule(fake_display)
    assert result._command_generic_msg(host, ansible_result, 'SUCCESS') == "test_host | SUCCESS | rc=-1 | (stdout) hello world"

# Generated at 2022-06-23 09:53:51.636853
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():

    # Create a mock result object for test
    result = MockResult(host='host', task_name='task_name', action='action', result={'exception': 'exception'})

    # Create a mock display object for test
    display = MockDisplay()

    # Create a mock module no json object for test
    module_no_json = C.MODULE_NO_JSON

    # Create a test object
    test_obj = CallbackModule(display)

    # Test for verbosity < 3
    test_obj._display.verbosity = 2
    test_obj.v2_runner_on_failed(result)

    # Test for verbosity >= 3
    test_obj._display.verbosity = 3
    test_obj.v2_runner_on_failed(result)

    # Test for action in C.MODULE_NO_JSON


# Generated at 2022-06-23 09:54:02.603859
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping

    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.block import Block

    from collections import namedtuple
    import sys

    import logging
    logging.basicConfig(level=logging.DEBUG)

    # https://stackoverflow.com/a/15498573
    class Capturing(list):
        def __enter__(self):
            self._stdout = sys.stdout
            sys.stdout = self._stringio = StringIO()
            return self

# Generated at 2022-06-23 09:54:14.222692
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule().CALLBACK_VERSION == 2.0
    assert CallbackModule().CALLBACK_TYPE == 'stdout'
    assert CallbackModule().CALLBACK_NAME == 'oneline'
    assert CallbackModule()._command_generic_msg('hostname', 'result', 'caption') == "hostname | caption | rc=-1 | (stdout) result (stderr) None"
    assert CallbackModule()._command_generic_msg('hostname', {'stdout': 'result'}, 'caption') == "hostname | caption | rc=-1 | (stdout) result (stderr) None"

# Generated at 2022-06-23 09:54:18.406864
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    import ansible.plugins.callback.oneline
    result = ansible.plugins.callback.oneline.CallbackModule()
    result.v2_runner_on_skipped({'_host': {'get_name': lambda: '10.10.10.10'}})

# Generated at 2022-06-23 09:54:26.414344
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    cli_args = {'verbosity': '3', 'ask_pass': False, 'private_key_file': '', 'ask_sudo_pass': False, 'ask_su_pass': False, 'inventory': ['localhost'], 'subset': ','}
    callback_plugins = ['/root/.ansible/plugins/callback/oneline.py']
    play_context = {'become': False, 'become_method': 'sudo', 'become_user': None, 'diff': False, 'remote_addr': '127.0.0.1', 'remote_user': 'root', 'password': None, 'port': 22}
    test_plugin = CallbackModule(cli_args=cli_args, display=None, options=None, plugin_options=None, play_context=play_context)

# Generated at 2022-06-23 09:54:36.954766
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Test #1
    ansible_result = "{'msg': 'The conditional result was False'}"
    html_result = "(stdout) {'msg': 'The conditional result was False'}"
    result = CallbackModule()
    ansible_result = result._command_generic_msg("server.example.com", ansible_result, "FAILED")
    assert ansible_result == html_result

    # Test #2
    ansible_result = "{'stderr': 'The conditional result was False'}"
    html_result = "(stderr) {'stderr': 'The conditional result was False'}"
    result = CallbackModule()
    ansible_result = result._command_generic_msg("server.example.com", ansible_result, "FAILED")
    assert ansible_result == html_result



# Generated at 2022-06-23 09:54:46.213416
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    test_result = type('', (), {})
    test_result._host = type('', (), {})
    test_result._host.get_name = lambda x: 'test_host'
    test_result._task = type('', (), {})
    test_result._task.__getitem__ = lambda x, y: ''
    test_result._task.no_log = lambda x: ''
    test_result._task.action = ''
    test_result._result = {}

    fake_display = type('', (), {})
    fake_display.display = lambda x, y: x


    cb = CallbackModule()
    cb._display = fake_display
    test = cb.v2_runner_on_skipped(test_result)
    assert test == None