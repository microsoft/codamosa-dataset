

# Generated at 2022-06-21 04:09:16.087227
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    from ansible.module_utils.dummy import AnsibleModule
    from ansible import constants as C
    import sys
    from ansible.plugins.callback import CallbackBase
    from contextlib import contextmanager
    import io
    import sys

    class TestCallbackModule:

        CALLBACK_VERSION = 2.0
        CALLBACK_TYPE = 'stdout'
        CALLBACK_NAME = 'oneline'

        def _dump_results(self, result, indent=None, sort_keys=True, keep_invocation=False):
            return result['msg']

        def v2_runner_on_failed(self, result, ignore_errors=False):
            pass

        def v2_runner_on_ok(self, result):
            pass

        def v2_runner_on_unreachable(self, result):
            self._display

# Generated at 2022-06-21 04:09:24.788736
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    result = dict()
    result['_result'] = dict()
    result['_result']['exception'] = 'exception'
    result['_result']['exception'] = 'stderr'
    result['_result']['rc'] = 0
    result['_task'] = dict()
    result['_task']['action'] = 'No'
    result['_host'] = dict()
    result['_host']['get_name'] = 'AcutualFunc'
    test = CallbackModule()
    test.v2_runner_on_failed({})
    test.v2_runner_on_failed(result)

# Generated at 2022-06-21 04:09:31.920886
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    # Test case 1
    #  Here we are testing if the _display.display method is being called with correct arguments
    #  in v2_runner_on_unreachable method.
    instance = CallbackModule()
    result = Mock()
    result._host = Mock()
    result._host.get_name = Mock(return_value = 'foo')
    result._result = {'msg': ''}
    instance._display = Mock()
    instance.v2_runner_on_unreachable(result)
    instance._display.display.assert_called_with("foo | UNREACHABLE!: ", color='lightred')
    assert instance._display.display.call_count == 1

    # Test case 2
    # Here we are testing if the _display.display method is being called with correct arguments
    # in v2_runner_on_

# Generated at 2022-06-21 04:09:40.065665
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Given
    hostname = 'hostname'
    result = {}
    ignore_errors = False
    callbackModule = CallbackModule()
    callbackModule._display.verbosity = 3
    result['exception'] = "An exception occurred during task execution.\nThe full traceback is:\n"
    excepted_output = "An exception occurred during task execution. The full traceback is:\n"

    # When
    callbackModule.v2_runner_on_failed(result, ignore_errors)

    # Then
    assert callbackModule._display.display.called
    args, kwargs = callbackModule._display.display.call_args
    assert args == (excepted_output, 'red')


# Generated at 2022-06-21 04:09:52.209985
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    from ansible.plugins.callback import CallbackBase
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_include import TaskInclude
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.hostvars import HostVars

    display = Display()
    context = PlayContext()
    task = Task()
    task_vars = TaskVars(
        hostvars=HostVars(
            variable_manager=VariableManager(),
            loader=None
        )
    )

# Generated at 2022-06-21 04:10:02.458479
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.utils.color import stringc
    from ansible.plugins.callback.oneline import CallbackModule

    cb = CallbackModule()
    cb._display.verbosity = 3
    cb._display.colors = False

    runner_on_failed = CallbackModule.v2_runner_on_failed

    # Test without an exception
    result = dict()
    result['_result'] = dict(changed=False, msg="")
    result['_host'] = dict(get_name=lambda: "test_hostname")
    result_str = runner_on_failed(cb, result)
    assert result_str == "test_hostname | FAILED! => {}"

    # Test with an exception
    result = dict()
    result['_result'] = dict(changed=True, exception="test exception")


# Generated at 2022-06-21 04:10:09.198559
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Arrange
    CALLBACK_NAME = 'oneline'
    config = {
        'callback_whitelist': CALLBACK_NAME
    }

# Generated at 2022-06-21 04:10:13.786489
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
   # Test with empty result
   test = CallbackModule()
   result = dict()
   test.v2_runner_on_unreachable(result)
   # Test with missing _host attribute
   result = dict()
   result['_host'] = None
   test.v2_runner_on_unreachable(result)

# Generated at 2022-06-21 04:10:23.541415
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Create a mock object of class CallbackBase()
    mock_CallbackBase = CallbackBase()

    # Create a mock object of class Result()
    mock_result = type('', (), {
        '_result': {
            'changed': False
        },
        '_task': {
            'action': 'test'
        },
        '_host': {
            'get_name': lambda: 'test host'
        }
    })()

    # Create a mock object of class CallbackModule
    mock_CallbackModule = CallbackModule(mock_CallbackBase._display)
    mock_CallbackModule.v2_runner_on_ok(mock_result)

# Generated at 2022-06-21 04:10:33.440490
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    import sys
    import io
    class TestCallback(CallbackBase):
        def __init__(self):
            super(TestCallback, self).__init__()
            self.called = {}
        def v2_runner_on_ok(self, result):
            super(TestCallback, self).v2_runner_on_ok(result)
            self.called['v2_runner_on_ok'] = True
            self.called['result'] = result
    out = io.BytesIO()
    sys.stdout = out
    callback = TestCallback()
    result = {
        'invocation': {
            'module_args': {},
        },
        'changed': False
    }
    callback.v2_runner_on_ok(result)
    sys.stdout

# Generated at 2022-06-21 04:10:47.139518
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Creating objects and assign values to them
    r = CallbackModule()
    result = {'exception': '', '_result': {'_host': {'_name': '', 'get_name': 'test'}, '_result': {}, '_task': {'action': ''}}}
    # Testing method v2_runner_on_failed
    # Testing with strings
    result['_result']['_host']['_name'] = 'test'
    result['exception'] = 'test'
    result['_result']['_task']['action'] = 'test'
    r.v2_runner_on_failed(result, ignore_errors=False)

# Generated at 2022-06-21 04:10:50.918973
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert (CallbackModule.CALLBACK_NAME == 'oneline')

# Generated at 2022-06-21 04:10:59.575207
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    import sys
    import mock
    import unittest

    # Create mock objects
    _display = mock.MagicMock()
    _display.display.return_value = ''
    _result = mock.MagicMock()
    _result._host = mock.MagicMock()
    _result._host.get_name.return_value = 'test_name'

    # Create an instance of CallbackModule
    cm = CallbackModule()
    cm._display = _display

    # Unit test for method v2_runner_on_skipped with no parameter
    cm.v2_runner_on_skipped(_result)
    _display.display.assert_called_once_with('test_name | SKIPPED', color='green')

    # Reset mock object
    _display.reset_mock()
    _result.reset_mock

# Generated at 2022-06-21 04:11:11.073209
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C

    class MockDisplay:
        def display(self, message, color):
            assert color == C.COLOR_SKIP
            assert message == "localhost | SKIPPED"

    class MockRunnerResult:
        def __init__(self):
            self._host = MockHost()
            self._task = MockTask()
            self._result = {
                "parsed": True,
                "_ansible_item_result": True
            }

    class MockTask:
        def __init__(self):
            self.action = 'debug'
            self.action_args = {
                'msg': 'testing'
            }

    class MockHost:
        def __init__(self):
            self.get_name = lambda: 'localhost'

   

# Generated at 2022-06-21 04:11:20.382076
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    print("### Testing v2_runner_on_unreachable")
    #Setup
    import ansible.executor
    import ansible.plugins
    import ansible.playbook.play
    import ansible.executor.task_queue_manager
    import ansible.executor.playbook_executor
    import ansible.inventory.manager
    import ansible.parsing.dataloader
    import ansible.playbook._load_list_of_blocks
    import ansible.playbook.task
    import ansible.vars.manager
    import ansible.utils.vars

    cbc = CallbackModule()
    loader = ansible.parsing.dataloader.DataLoader()
    variable_manager = ansible.vars.manager.VariableManager()
    result = ansible.executor.task_

# Generated at 2022-06-21 04:11:31.651926
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    from collections import namedtuple
    Options = namedtuple('Options', ['listtags', 'listtasks', 'listhosts', 'syntax', 'connection','module_path', 'forks', 'remote_user', 'private_key_file', 'ssh_common_args', 'ssh_extra_args', 'sftp_extra_args', 'scp_extra_args', 'become', 'become_method', 'become_user', 'verbosity', 'check', 'diff', 'gathering', 'log_path', 'one_line', 'poll_interval', 'module_path'])

# Generated at 2022-06-21 04:11:34.298506
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    module = CallbackModule()
    assert module.CALLBACK_VERSION == 2.0
    assert module.CALLBACK_TYPE == 'stdout'
    assert module.CALLBACK_NAME == 'oneline'

# Generated at 2022-06-21 04:11:41.800716
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    from ansible.plugins.callback import CallbackBase
    from ansible.plugins.callback import CallbackModule
    
    # Test that callback_type and callback_name is set for class CallbackModule
    #  and that the class is created using the CallbackBase as a baseclass
    assert CallbackModule.CALLBACK_TYPE == 'stdout'
    assert CallbackModule.CALLBACK_NAME == 'oneline'
    assert isinstance(CallbackModule(), CallbackBase)
    
    
# Unit tests for methods of class CallbackModule

# Generated at 2022-06-21 04:11:55.247513
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Set up test
    #
    # This class is a helper for tests for Ansible playbooks.
    # It provides some convenient methods to validate the host lists,
    # the tasks list, and results.
    from ansible.utils.display import Display
    display = Display()

    # This module will request a cache plugin (if specified) to cache a result.
    from ansible.plugins.cache import FactCache
    fact_cache = FactCache(display)

    # This module is for controlling various aspects of Ansible's logging.
    from ansible.plugins.logger import Logger
    logger = Logger(display)

    # This module is a helper class for becoming a different user.
    from ansible.plugins.become import Become
    become = Become(display)

    # This class will be used to collect information from executions of Ansible tasks.


# Generated at 2022-06-21 04:12:05.540301
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    import ansible.plugins.loader
    import ansible.plugins.callback
    import ansible.plugins.callback.oneline

# Generated at 2022-06-21 04:12:14.577316
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    class result:
        _host = 'host'
        _result = dict( rc=1, stdout='stdout', stderr='stderr' )
    callback = CallbackModule()
    callback.v2_runner_on_failed(result)



# Generated at 2022-06-21 04:12:18.139666
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    result = Result()
    test_callbackmodule = CallbackModule()
    test_callbackmodule.v2_runner_on_unreachable(result)

    assert result.get_name() == None
    assert result.get_name() != 'something'


# Generated at 2022-06-21 04:12:19.572555
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    assert True

# Generated at 2022-06-21 04:12:21.948654
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback = CallbackModule()
    assert callback.CALLBACK_TYPE == 'stdout'
    assert callback.CALLBACK_VERSION == 2.0
    assert callback.CALLBACK_NAME == 'oneline'



# Generated at 2022-06-21 04:12:25.666037
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    cb = CallbackModule()
    emptyresult = ""
    result = cb.v2_runner_on_skipped(emptyresult)
    assert result == None

# Generated at 2022-06-21 04:12:30.770184
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    cb = CallbackModule()

# Generated at 2022-06-21 04:12:40.428379
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # see: https://stackoverflow.com/questions/28035170/why-is-pythons-unittest-testcase-execution-order-non-deterministic
    from unittest import TestCase
    from pprint import pprint

    class MyTestCase(TestCase):
        def test_constructor(self):
            """
            Make sure the CallbackModule class is constructed properly.
            """
            CallbackModule()

    #    MyTestCase.test_constructor()
    obj = MyTestCase
    attrs = [ attr for attr in dir(obj) if not attr.startswith("_") and callable(getattr(obj, attr)) ]
    for attr in attrs:
        print("\n#########################################################")
        print("Testing: " + attr)
       

# Generated at 2022-06-21 04:12:44.728373
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    fake_display = FakeDisplay()
    callback = CallbackModule(display=fake_display)
    result = FakeResult('localhost')
    callback.v2_runner_on_skipped(result)
    assert fake_display.messages[-1] == 'localhost | SKIPPED'
    assert fake_display.colors[-1] == 'SKIP'


# Generated at 2022-06-21 04:12:47.551817
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    c = CallbackModule()

    assert c.CALLBACK_VERSION == 2.0
    assert c.CALLBACK_TYPE == 'stdout'
    assert c.CALLBACK_NAME == 'oneline'

# To test private method

# Generated at 2022-06-21 04:12:59.426081
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    
    from ansible.plugins.callback.oneline import CallbackModule
    from ansible.playbook.task import Task
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars, load_options_vars
    from ansible.utils.display import Display

# Generated at 2022-06-21 04:13:19.435844
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback = CallbackModule()
    class resultClass:
        changed = False
        class _host:
            class get_name:
                pass
    result = resultClass()
    result._host.get_name.return_value = 'localhost'
    result._result = ''
    class taskClass:
        action = 'shell'
    result._task = taskClass()
    callback.v2_runner_on_ok(result)
    result.changed = True
    callback.v2_runner_on_ok(result)
    result._task.action = 'module'
    callback.v2_runner_on_ok(result)
    result._task.action = 'rubbish'
    callback.v2_runner_on_ok(result)

# Generated at 2022-06-21 04:13:29.455227
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    """
    Unit test for method v2_runner_on_failed of class CallbackModule
    """
    print("INLINE: test_CallbackModule_v2_runner_on_failed()")
    import sys, json
    from io import StringIO
    from ansible.plugins.callback.oneline import CallbackModule
    from ansible.executor import task_result
    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
   

# Generated at 2022-06-21 04:13:38.794397
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    """
    Unit test for method v2_runner_on_unreachable of class CallbackModule
    """
    result = {"msg": "test message"}
    result_obj = DummyResultObj(result)
    display = DummyDisplay()
    cbmod = CallbackModule()

    cbmod.v2_runner_on_unreachable(result_obj)

    assert display.output == "%s | UNREACHABLE!: %s" % (result_obj._host.get_name(), result["msg"])



# Generated at 2022-06-21 04:13:47.245576
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    '''
    This method tests the functionality of method v2_runner_on_ok of class CallbackModule
    '''

    import ansible.plugins.callback.oneline as oneline

    # Create a instance of the class CallbackModule
    test_instance = oneline.CallbackModule()

    # Create a variable of structure of class Result
    result = type('Result', (object,),{'_result':{'changed':False,'ansible_facts':{'changed':False}}, '_task':{'action':'test'},'_host':{'get_name':lambda x: 'localhost'}})

    # Perform test
    test_instance.v2_runner_on_ok(result)


# Generated at 2022-06-21 04:13:52.802294
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    cb = CallbackModule()
    cb.display = Mock(return_value=None)
    cb.v2_runner_on_unreachable({'_host': {'get_name': Mock()}})
    for method in cb.display.method_calls:
        assert cb.display.method_calls[method][0][0] == '%s | UNREACHABLE!' % method


# Generated at 2022-06-21 04:13:59.080009
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackModule
    from ansible.compat.tests import unittest

    class TestV2RunnerOnOk(unittest.TestCase):
        mod = CallbackModule()

        # Inputs
        result = {
            "_host": {
                "get_name": lambda: "test.example.com",
            },
            "_result": {
                "changed": "True",
            },
            "_task": {
                "action": "test",
            },
        }
        result_no_change = {
            "_host": {
                "get_name": lambda: "test.example.com",
            },
            "_result": {
                "changed": "False",
            },
            "_task": {
                "action": "test",
            },
        }

        # Outputs

# Generated at 2022-06-21 04:14:09.445651
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    from ansible.module_utils._text import to_bytes

    c = CallbackModule()
    assert c

    C.stdout_callback = 'oneline'
    c = CallbackModule()
    assert c

    if sys.version_info >= (3, 0):
        return
    elif sys.version_info >= (2, 7):
        assert to_bytes(c) == b'<ansible.plugins.callback.oneline.CallbackModule object at 0x1093b5f90>'
    else:
        assert str(c) == "<ansible.plugins.callback.oneline.CallbackModule object at 0x10c865f90>"

    c = CallbackModule()
    assert c

    C.stdout_callback = 'json'
    c = CallbackModule()
    assert to_bytes(c) == b

# Generated at 2022-06-21 04:14:13.488511
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    result = {
        '_result': {
            'rc': 1,
            'stdout': 'test stdout',
            'stderr': 'test stderr',
            'exception': 'test exception'
        }
    }
    c = CallbackModule()
    c.v2_runner_on_failed(result)

# Generated at 2022-06-21 04:14:20.428660
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert not CallbackModule()
    assert not CallbackModule()._display
    assert not CallbackModule()._dump_results
    assert CallbackModule.CALLBACK_VERSION == 2.0
    assert CallbackModule.CALLBACK_TYPE == 'stdout'
    assert CallbackModule.CALLBACK_NAME == 'oneline'


# Generated at 2022-06-21 04:14:22.148325
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    obj = CallbackModule()
    assert obj
    assert obj.CALLBACK_NAME == 'oneline'

# Generated at 2022-06-21 04:14:42.665573
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    module = CallbackModule()
    result = {'msg':'test_msg'}
    module.v2_runner_on_unreachable(result)

# Generated at 2022-06-21 04:14:45.804549
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    try:
        CallbackModule()
        print('test_CallbackModule: ok')
    except Exception as e:
        print('test_CallbackModule: fail')
        print(vars(e))

test_CallbackModule()

# Generated at 2022-06-21 04:14:55.058275
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    from ansible.utils.display import Display
    module = CallbackModule()
    module.set_options({'verbosity': 0})
    module.set_play_context(play_context=None)
    display = Display()
    display.verbosity = 2
    module.set_display(display)
    
    # Unit test function v2_runner_on_unreachable with no errors
    result = FakeResult()
    module.v2_runner_on_unreachable(result)
    assert True


# Generated at 2022-06-21 04:14:57.200723
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    from ansible.utils.display import Display
    display = Display()
    return CallbackModule(display)

# Generated at 2022-06-21 04:15:07.595001
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    result = {'_result': {'exception': 'An exception occurred during task execution.','changed': False, 'failed': True}}
    class Host(object):
        def __init__(self):
            self.get_name = lambda : 'Test Host'
    class Result(object):
        def __init__(self):
            self._task = None
            self._host = Host()
            self._result = result
    verbosity = 3
    class Display(object):
        def __init__(self):
            self.COLOR_ERROR = C.COLOR_ERROR
            self.COLOR_OK = C.COLOR_OK
            self.verbosity = verbosity
        def display(self, msg, color=None):
            pass
    class Runner(object):
        def __init__(self):
            self._tqm = None
           

# Generated at 2022-06-21 04:15:18.061500
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    m = CallbackModule()
    import mock
    import json
    class A:
        def __init__(self, _get_name_return_val):
            self.mock_get_name = mock.Mock()
            self.mock_get_name.return_value = _get_name_return_val
        def get_name(self):
            return self.mock_get_name()
    class B:
        def __init__(self, _host, _result):
            self._host = _host
            self._result = _result
    class C:
        def __init__(self, _display):
            self._display = _display
    m._display = C(mock.Mock())
    # first test

# Generated at 2022-06-21 04:15:20.022446
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    c = CallbackModule()
    c.__str__()

# Generated at 2022-06-21 04:15:23.836075
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    module = CallbackModule()
    result = {
        'changed': True,
        'ansible_job_id': '1200'
    }
    display = 'localhost | CHANGED => {changed=True, ansible_job_id=1200}'
    assert module.v2_runner_on_ok(result) == display


# Generated at 2022-06-21 04:15:29.758419
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    result = {'failed'}
    instance = CallbackModule()
    msg = "%s | UNREACHABLE!: %s" % (result._host.get_name(), result._result.get('msg', ''))
    assert msg == instance.v2_runner_on_unreachable(result)


# Generated at 2022-06-21 04:15:43.378465
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    import mock
    import ansible.plugins.callback
    import ansible.plugins.callback.default
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    # ansible.plugins.callback.default.CallabckModule is an old-style class
    # so we have to use the __metaclass__ and __new__ trick to instantiate it
    old_style_class_attrs = {
        '__module__': ansible.plugins.callback.default.CallbackModule.__module__,
        '__doc__': ansible.plugins.callback.default.CallbackModule.__doc__
    }
    CallbackModule = type

# Generated at 2022-06-21 04:16:23.087971
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    return CallbackModule()


# Generated at 2022-06-21 04:16:26.830236
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    obj = CallbackModule()
    assert obj.CALLBACK_VERSION == 2.0
    assert obj.CALLBACK_TYPE == 'stdout'
    assert obj.CALLBACK_NAME == 'oneline'


test_CallbackModule()

# Generated at 2022-06-21 04:16:27.965403
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    assert(CallbackModule.v2_runner_on_skipped(1) == None)

# Generated at 2022-06-21 04:16:34.977295
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    _result = { "msg" : "Test failed" }
    _result_task = {  }
    _result_host = { "get_name" : "localhost" }

    # Create the CallbackModule class object
    callbackmodule = CallbackModule()

    # Call the v2_runner_on_unreachable method
    callbackmodule.v2_runner_on_unreachable( result = _result, result_task=_result_task, result_host = _result_host)

# Generated at 2022-06-21 04:16:41.363859
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.parsing.plugin_docs import read_docstring

    results = {
        '_result': {
            'changed': False,
        },
        '_task': {},
        '_host': {
            'get_name': lambda: "localhost",
        },
    }

    c = CallbackModule()
    c._dump_results = lambda x, y: "test"
    c._display = lambda x, y: True

    c.v2_runner_on_ok(results)


# Generated at 2022-06-21 04:16:52.267163
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.callbacks import CallbackBase
    from ansible.plugins.callback import CallbackModule

    CallbackModule.CALLBACK_TYPE = 'stdout'
    CallbackModule.CALLBACK_NAME = 'oneline'
    cb = CallbackModule()

    # test with display.verbosity = 1
    cb._display = CallbackBase()
    cb._display.verbosity = 1
    result = type('', (), {})()
    result._result = type('', (), {})()
    result._result.get = lambda x, y: ''
    result._result.__setitem__ = lambda x, y: True
    result._result.__contains__ = lambda x: False
    result._host = type('', (), {})()
    result._host.get_name = lambda: 'host'
    result

# Generated at 2022-06-21 04:16:53.585184
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-21 04:17:01.517570
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    callbackmodule = CallbackModule()
    result = {
        '_host' :
        {
            'get_name' : 'localhost'
        },
        '_result': {
            'msg' : 'Test message'
        }
    }
    ret = callbackmodule.v2_runner_on_unreachable(result)

    assert ret is None
    assert callbackmodule._display.display.call_args[0][0] == 'localhost | UNREACHABLE!: Test message'
    assert callbackmodule._display.display.call_args[0][1] == C.COLOR_UNREACHABLE

# Generated at 2022-06-21 04:17:07.721294
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    class AnsibleModuleMock:
        class RunnerMock:
            def __init__(self):
                self.host = 'host'
                self.result = {
                    'msg': 'msg'
                }
        def __init__(self):
            self.runner = self.RunnerMock()

    class DisplayMock:
        def __init__(self):
            self.skipped_msg = ''
        def display(self, msg, color=None):
            self.skipped_msg = msg
    ansible_module = AnsibleModuleMock()
    display_mock = DisplayMock()
    callback_module = CallbackModule()
    callback_module._display = display_mock
    callback_module.v2_runner_on_skipped(ansible_module.runner)

# Generated at 2022-06-21 04:17:10.874685
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    caModule = CallbackModule()
    result = type("test_result", (object,), {'_host': type("test_host", (object,), {'get_name': lambda self: "host name"})()})()
    caModule.v2_runner_on_skipped(result)



# Generated at 2022-06-21 04:18:56.033316
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    from ansible.plugins.callback import CallbackModule
    from ansible import constants as C

    # Create dummy object containing the result object
    class Result:
        def __init__(self, hostname, result):
            self._host = hostname
            self._result = result

    # Create dummy object containing the hostname
    class Host:
        def __init__(self, hostname):
            self.name = hostname

    # Create dummy object containing the ansible constants
    class Constants:
        color_unreachable = "COLOR_UNREACHABLE"
    C = Constants()

    # Create dummy object containing the display object
    class Display:
        def __init__(self, verbosity, display):
            self.verbosity = verbosity
            self.display = display

    # Create dummy display object for verbosity 5
    display

# Generated at 2022-06-21 04:19:04.542730
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

    # Create an instance of CallbackModule class
    cm = CallbackModule()

    # Create an instance of RunnerResult class
    result = RunnerResult()

    # Create an instance of ActionResult class
    actions_results = ActionResult()

    # Create an instance of Host class
    host = Host()
    host.set_name("10.0.0.1")

    # Create an instance of Task class
    task = Task()
    task.action = "file"
    
    result._task = task
    result._result = actions_results
    result._host = host

    # Set the value of variable changed to False
    actions_results.changed = False 

    # Add an entry in the result map
    actions_results["invocation"] = { "module_args" : {} }

    # Invoke the v2_runner_on_ok method