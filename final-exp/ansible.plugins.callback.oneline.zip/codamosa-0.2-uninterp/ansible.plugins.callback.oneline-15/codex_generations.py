

# Generated at 2022-06-17 10:51:51.634466
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback = CallbackModule()
    assert callback.CALLBACK_VERSION == 2.0
    assert callback.CALLBACK_TYPE == 'stdout'
    assert callback.CALLBACK_NAME == 'oneline'

# Generated at 2022-06-17 10:52:01.236262
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.utils.unicode import to_unicode
    from ansible.utils.unicode import to_bytes
    from ansible.utils.unicode import to_str
    from ansible.utils.unicode import to_text
    from ansible.utils.unicode import to_native
    from ansible.utils.unicode import to_bytes
    from ansible.utils.unicode import to_unicode
    from ansible.utils.unicode import to_str
    from ansible.utils.unicode import to_text
    from ansible.utils.unicode import to_native
    from ansible.utils.unicode import to_

# Generated at 2022-06-17 10:52:09.664830
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.utils.unicode import to_unicode
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler

# Generated at 2022-06-17 10:52:13.202327
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    cb = CallbackModule()
    assert cb.CALLBACK_VERSION == 2.0
    assert cb.CALLBACK_TYPE == 'stdout'
    assert cb.CALLBACK_NAME == 'oneline'

# Generated at 2022-06-17 10:52:23.081154
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash

# Generated at 2022-06-17 10:52:34.587528
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    import sys
    import io
    import unittest

    class TestDisplay(Display):
        def __init__(self):
            self.stdout = io.StringIO()
            self.stderr = io.StringIO()
            self.verbosity = 0
            self.color = 'light'
            self.columns = 80

        def display(self, msg, color=None, stderr=False, screen_only=False, log_only=False):
            if stderr:
                self.stderr.write(msg)
            else:
                self.stdout.write(msg)


# Generated at 2022-06-17 10:52:35.459120
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:52:43.053737
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Arrange
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    import sys
    import io
    import sys
    import os
    import json
    import pytest
    import mock
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-17 10:52:55.141145
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc

    class TestCallbackModule(CallbackBase):
        CALLBACK_VERSION = 2.0
        CALLBACK_TYPE = 'stdout'
        CALLBACK_NAME = 'oneline'

        def _command_generic_msg(self, hostname, result, caption):
            stdout = result.get('stdout', '').replace('\n', '\\n').replace('\r', '\\r')
            if 'stderr' in result and result['stderr']:
                stderr = result.get('stderr', '').replace('\n', '\\n').replace('\r', '\\r')

# Generated at 2022-06-17 10:52:56.049593
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:53:10.676675
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.utils.unicode import to_unicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.utils.unsafe_proxy import wrap_unsafe_text
    from ansible.utils.unsafe_proxy import wrap_unsafe_bytes
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import wrap_ansible_attr
    from ansible.utils.unsafe_proxy import wrap_

# Generated at 2022-06-17 10:53:11.299809
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:53:12.094164
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:53:22.419940
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge

# Generated at 2022-06-17 10:53:23.421114
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:53:35.247037
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a mock object for the result
    result = Mock()
    result._result = {'exception': 'exception'}
    result._task = Mock()
    result._task.action = 'action'
    result._host = Mock()
    result._host.get_name = Mock(return_value='hostname')

    # Create a mock object for the display
    display = Mock()
    display.verbosity = 3

    # Create a mock object for the callback
    callback = CallbackModule()
    callback._display = display

    # Call the method
    callback.v2_runner_on_failed(result)

    # Check the results
    display.display.assert_called_with("An exception occurred during task execution. The full traceback is:\nexception", color='red')


# Generated at 2022-06-17 10:53:36.573006
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:53:48.306694
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    import json
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.utils.unicode import to_unicode
    from ansible.plugins.callback.oneline import CallbackModule
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

# Generated at 2022-06-17 10:53:54.509539
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a test object of class CallbackModule
    test_obj = CallbackModule()
    # Create a test result object
    test_result = {'_result': {'exception': 'An exception occurred during task execution. To see the full traceback, use -vvv. The error was: %s'}}
    # Call method v2_runner_on_failed of class CallbackModule
    test_obj.v2_runner_on_failed(test_result)


# Generated at 2022-06-17 10:54:00.913435
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a mock object of class CallbackBase
    mock_CallbackBase = CallbackBase()

    # Create a mock object of class CallbackModule
    mock_CallbackModule = CallbackModule()

    # Create a mock object of class Host
    mock_Host = Host()

    # Create a mock object of class Task
    mock_Task = Task()

    # Create a mock object of class Result
    mock_Result = Result()

    # Create a mock object of class Display
    mock_Display = Display()

    # Create a mock object of class C
    mock_C = C()

    # Set the attribute '_display' of the mock object of class CallbackModule to the mock object of class Display
    mock_CallbackModule._display = mock_Display

    # Set the attribute 'verbosity' of the mock object of class Display to the value 3
    mock_Display

# Generated at 2022-06-17 10:54:18.538164
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    import sys
    import io
    import unittest

    class TestCallbackModule(CallbackModule):
        def __init__(self):
            self.display = Display()

    class Display(object):
        def __init__(self):
            self.stdout = io.StringIO()
            self.verbosity = 0

        def display(self, msg, color=None):
            if color:
                msg = stringc(msg, color)
            self.stdout.write(msg)

    class TestHost(object):
        def __init__(self, name):
            self.name = name

        def get_name(self):
            return self.name


# Generated at 2022-06-17 10:54:24.288967
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Test with verbosity < 3
    callback = CallbackModule()
    callback._display = type('Display', (object,), {'verbosity': 2})
    result = type('Result', (object,), {'_result': {'exception': 'An exception occurred during task execution. To see the full traceback, use -vvv. The error was: error'}, '_task': type('Task', (object,), {'action': 'action'}), '_host': type('Host', (object,), {'get_name': lambda self: 'hostname'})})
    callback.v2_runner_on_failed(result)
    # Test with verbosity >= 3
    callback = CallbackModule()
    callback._display = type('Display', (object,), {'verbosity': 3})

# Generated at 2022-06-17 10:54:25.364243
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:54:37.995806
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    import ansible.plugins.callback.oneline
    import ansible.plugins.callback.default
    import ansible.plugins.callback.json
    import ansible.plugins.callback.yaml
    import ansible.plugins.callback.minimal
    import ansible.plugins.callback.profile_roles
    import ansible.plugins.callback.profile_tasks
    import ansible.plugins.callback.tree
    import ansible.plugins.callback.debug
    import ansible.plugins.callback.actionable
    import ansible.plugins.callback.log_plays
    import ansible.plugins.callback.log_plays_verbose
    import ansible.plugins.callback.log_plays_debug
    import ansible.plugins.callback.log_plays_debug_verbose
    import ansible.plugins.callback.log_plays_extended
   

# Generated at 2022-06-17 10:54:47.955092
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a mock object of class CallbackBase
    mock_CallbackBase = CallbackBase()
    # Create a mock object of class CallbackModule
    mock_CallbackModule = CallbackModule()
    # Create a mock object of class Result
    mock_Result = Result()
    # Create a mock object of class Host
    mock_Host = Host()
    # Create a mock object of class Task
    mock_Task = Task()
    # Create a mock object of class Display
    mock_Display = Display()
    # Create a mock object of class TaskResult
    mock_TaskResult = TaskResult()
    # Create a mock object of class TaskResult
    mock_TaskResult = TaskResult()
    # Create a mock object of class TaskResult
    mock_TaskResult = TaskResult()
    # Create a mock object of class TaskResult
    mock_TaskResult = Task

# Generated at 2022-06-17 10:54:59.814589
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a mock object for the result
    result = MockResult()
    result._result = {'exception': 'An exception occurred during task execution. The full traceback is:\n'}
    result._task = MockTask()
    result._task.action = 'shell'
    result._host = MockHost()
    result._host.get_name.return_value = 'localhost'

    # Create a mock object for the display
    display = MockDisplay()

    # Create a callback object
    callback = CallbackModule()
    callback._display = display

    # Call the method
    callback.v2_runner_on_failed(result)

    # Check the result
    assert display.display.call_count == 1
    assert display.display.call_args[0][0] == 'localhost | FAILED! => {}'

# Generated at 2022-06-17 10:55:00.561020
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:55:10.503170
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.plugins.callback.oneline import CallbackModule
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-17 10:55:10.955143
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:55:22.391528
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback.oneline import CallbackModule
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-17 10:55:49.225603
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a mock object for the result
    result = Mock()
    result._result = {'exception': 'An exception occurred during task execution. To see the full traceback, use -vvv. The error was: %s'}
    result._task = Mock()
    result._task.action = 'action'
    result._host = Mock()
    result._host.get_name.return_value = 'hostname'

    # Create a mock object for the display
    display = Mock()
    display.verbosity = 3
    display.display.return_value = 'An exception occurred during task execution. The full traceback is:\n' + result._result['exception'].replace('\n', '')

    # Create a mock object for the constants
    constants = Mock()
    constants.MODULE_NO_JSON = ['action']

# Generated at 2022-06-17 10:55:57.566588
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine

# Generated at 2022-06-17 10:55:58.073067
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:56:05.368563
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    import sys
    import io
    import unittest
    import ansible.plugins.callback.oneline
    import ansible.plugins.callback.default
    import ansible.plugins.callback.json
    import ansible.plugins.callback.yaml
    import ansible.plugins.callback.minimal
    import ansible.plugins.callback.profile_roles
    import ansible.plugins.callback.profile_tasks
    import ansible.plugins.callback.tree
    import ansible.plugins.callback.actionable
    import ansible.plugins.callback.log_plays
    import ansible.plugins.callback.log_plays_verbose
    import ansible.plugins.callback.log_plays_

# Generated at 2022-06-17 10:56:15.106448
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Test with verbosity < 3
    callback = CallbackModule()
    callback._display = MockDisplay()
    callback._display.verbosity = 2
    result = MockResult()
    result._result = {'exception': 'An exception occurred during task execution. To see the full traceback, use -vvv. The error was: error'}
    callback.v2_runner_on_failed(result)
    assert callback._display.display_called == True
    assert callback._display.display_msg == 'An exception occurred during task execution. To see the full traceback, use -vvv. The error was: error'
    assert callback._display.display_color == 'red'
    # Test with verbosity >= 3
    callback = CallbackModule()
    callback._display = MockDisplay()
    callback._display.verbosity = 3
    result = Mock

# Generated at 2022-06-17 10:56:23.341964
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a mock object for the result
    result = Mock()
    result._result = {'exception': 'An exception occurred during task execution. To see the full traceback, use -vvv. The error was: %s'}
    result._task = Mock()
    result._task.action = 'action'
    result._host = Mock()
    result._host.get_name.return_value = 'hostname'
    # Create a mock object for the display
    display = Mock()
    display.verbosity = 3
    # Create a mock object for the callback
    callback = CallbackModule()
    callback._display = display
    # Call the method
    callback.v2_runner_on_failed(result)
    # Assert that the display.display method was called with the correct parameters

# Generated at 2022-06-17 10:56:36.801076
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a mock object for the result parameter
    class MockResult:
        def __init__(self, host, result):
            self._host = host
            self._result = result
    # Create a mock object for the host parameter
    class MockHost:
        def __init__(self, name):
            self.name = name
        def get_name(self):
            return self.name
    # Create a mock object for the display parameter
    class MockDisplay:
        def __init__(self):
            self.display_string = ""
        def display(self, string, color):
            self.display_string = string
    # Create a mock object for the task parameter
    class MockTask:
        def __init__(self, action):
            self.action = action
    # Create a mock object for the C parameter

# Generated at 2022-06-17 10:56:48.205273
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.plugins.callback.oneline import CallbackModule
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-17 10:56:48.715372
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:56:56.606059
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.utils.unicode import to_unicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.unsafe_proxy import wrap_var

# Generated at 2022-06-17 10:57:41.759471
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Create a test object
    test_obj = CallbackModule()

    # Create a test result object
    test_result = type('', (), {})()
    test_result._host = type('', (), {})()
    test_result._host.get_name = lambda: 'test_host'
    test_result._result = {'changed': False}
    test_result._task = type('', (), {})()
    test_result._task.action = 'test_action'

    # Create a test display object
    test_display = type('', (), {})()
    test_display.display = lambda x, y: print(x)

    # Set the display object
    test_obj._display = test_display

    # Call the method
    test_obj.v2_runner_on_ok(test_result)

    #

# Generated at 2022-06-17 10:57:48.457566
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.plugins.callback.oneline import CallbackModule
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-17 10:57:52.445875
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 10:57:54.653436
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:57:55.362325
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:57:57.984427
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:57:58.502321
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:58:05.626377
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Test with changed=False
    result = {'changed': False}
    callback = CallbackModule()
    callback.v2_runner_on_ok(result)
    assert callback._display.display.call_count == 1
    assert callback._display.display.call_args[0][0] == ' | SUCCESS => '
    assert callback._display.display.call_args[0][1] == C.COLOR_OK

    # Test with changed=True
    result = {'changed': True}
    callback = CallbackModule()
    callback.v2_runner_on_ok(result)
    assert callback._display.display.call_count == 1
    assert callback._display.display.call_args[0][0] == ' | CHANGED => '
    assert callback._display.display.call_args[0][1]

# Generated at 2022-06-17 10:58:15.903390
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback.oneline import CallbackModule
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_

# Generated at 2022-06-17 10:58:28.497045
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    import sys
    import io
    import unittest

    class TestCallbackModule(CallbackBase):
        CALLBACK_VERSION = 2.0
        CALLBACK_TYPE = 'stdout'
        CALLBACK_NAME = 'oneline'

        def __init__(self):
            self.output = io.StringIO()
            super(TestCallbackModule, self).__init__()

        def _display(self, msg, color=None, stderr=False, screen_only=False, log_only=False):
            self.output.write(msg)

    class TestResult:
        def __init__(self, host, result):
            self._host = host
            self._result = result
            self._task = TestTask()


# Generated at 2022-06-17 10:59:59.828399
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 11:00:05.690072
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C

    class TestCallbackModule(CallbackBase):
        CALLBACK_VERSION = 2.0
        CALLBACK_TYPE = 'stdout'
        CALLBACK_NAME = 'oneline'

        def v2_runner_on_ok(self, result):
            if result._result.get('changed', False):
                color = C.COLOR_CHANGED
                state = 'CHANGED'
            else:
                color = C.COLOR_OK
                state = 'SUCCESS'


# Generated at 2022-06-17 11:00:06.180991
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 11:00:06.722263
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 11:00:15.130524
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.utils.unicode import to_unicode

    display = Display()
    display.verbosity = 3
    display.columns = 80
    display.colorize = True

    class TestCallbackModule(CallbackBase):
        CALLBACK_VERSION = 2.0
        CALLBACK_TYPE = 'stdout'
        CALLBACK_NAME = 'oneline'

        def _command_generic_msg(self, hostname, result, caption):
            stdout = result.get('stdout', '').replace('\n', '\\n').replace('\r', '\\r')

# Generated at 2022-06-17 11:00:26.397445
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    import sys
    import io
    import unittest

    class TestCallbackModule(CallbackBase):
        CALLBACK_VERSION = 2.0
        CALLBACK_TYPE = 'stdout'
        CALLBACK_NAME = 'oneline'

        def __init__(self):
            self.output = io.StringIO()
            self.display = self.output.write

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.test_callback = TestCallbackModule()

        def test_v2_runner_on_ok(self):
            result = {'changed': False}
            self.test_callback.v2_runner_on_ok(result)

# Generated at 2022-06-17 11:00:36.865664
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C

    class CallbackModule(CallbackBase):

        '''
        This is the default callback interface, which simply prints messages
        to stdout when new callback events are received.
        '''

        CALLBACK_VERSION = 2.0
        CALLBACK_TYPE = 'stdout'
        CALLBACK_NAME = 'oneline'

        def _command_generic_msg(self, hostname, result, caption):
            stdout = result.get('stdout', '').replace('\n', '\\n').replace('\r', '\\r')
            if 'stderr' in result and result['stderr']:
                stderr = result.get('stderr', '').replace('\n', '\\n').replace('\r', '\\r')

# Generated at 2022-06-17 11:00:46.517689
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.plugins.callback.oneline import CallbackModule
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-17 11:00:53.897133
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Test with verbosity < 3
    callback = CallbackModule()
    callback._display = Display()
    callback._display.verbosity = 2
    result = Result()

# Generated at 2022-06-17 11:00:54.485962
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()