

# Generated at 2022-06-17 10:52:01.635241
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.utils.unicode import to_unicode
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsVarsVars
    from ansible.vars.hostvars import HostVarsVarsVarsVars
    from ansible.vars.hostvars import HostVarsVarsVarsVarsVars

# Generated at 2022-06-17 10:52:06.678871
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    result = {'_result': {'exception': 'An exception occurred during task execution. To see the full traceback, use -vvv. The error was: error'}}
    result['_host'] = {'get_name': lambda: 'hostname'}
    result['_task'] = {'action': 'action'}
    callback = CallbackModule()
    callback.v2_runner_on_failed(result)


# Generated at 2022-06-17 10:52:12.361946
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.plugins.callback.oneline import CallbackModule

    display = Display()
    callback = CallbackModule(display)

    # Test with changed=True
    result = CallbackBase.Result(host=CallbackBase.Host(name='localhost'), task=CallbackBase.Task(action='test'), result={'changed': True})
    callback.v2_runner_on_ok(result)
    assert display.display.call_count == 1
    assert display.display.call_args[0][0] == stringc("localhost | CHANGED => {}", C.COLOR_CHANGED)

    # Test with changed=False
    result = Callback

# Generated at 2022-06-17 10:52:22.357717
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    import sys
    import io
    import unittest

    class TestCallbackModule(CallbackBase):
        CALLBACK_VERSION = 2.0
        CALLBACK_TYPE = 'stdout'
        CALLBACK_NAME = 'oneline'

        def __init__(self):
            super(TestCallbackModule, self).__init__()
            self.display = Display()


# Generated at 2022-06-17 10:52:33.795769
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.utils.unicode import to_unicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import wrap_text
    from ansible.utils.unsafe_proxy import unwrap_text
    from ansible.utils.unsafe_proxy import ANSIBLE_VARS_CACHE
    import json
    import sys
    import os
    import tempfile
    import shutil
    import pytest

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create

# Generated at 2022-06-17 10:52:42.644668
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.color import colorize, hostcolor
    from ansible.utils.plugin_docs import get_docstring
    from ansible.utils.sentinel import Sentinel

# Generated at 2022-06-17 10:52:55.099346
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.utils.unicode import to_unicode
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.stats import AggregateStats
    from ansible.playbook.block import Block

# Generated at 2022-06-17 10:53:05.801902
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a mock object of class CallbackModule
    callback_module = CallbackModule()
    # Create a mock object of class Result
    result = Result()
    # Set the attribute '_host' of result to a mock object of class Host
    result._host = Host()
    # Set the attribute '_task' of result to a mock object of class Task
    result._task = Task()
    # Set the attribute '_result' of result to a mock object of class dict
    result._result = dict()
    # Set the attribute '_result' of result to a mock object of class dict
    result._result['exception'] = 'An exception occurred during task execution. The full traceback is:\n'
    # Set the attribute '_result' of result to a mock object of class dict

# Generated at 2022-06-17 10:53:15.788564
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Test with changed=False
    result = {'changed': False}
    callback = CallbackModule()
    callback.v2_runner_on_ok(result)
    assert callback._display.display.call_args[0][0] == 'SUCCESS'
    assert callback._display.display.call_args[0][1] == C.COLOR_OK

    # Test with changed=True
    result = {'changed': True}
    callback = CallbackModule()
    callback.v2_runner_on_ok(result)
    assert callback._display.display.call_args[0][0] == 'CHANGED'
    assert callback._display.display.call_args[0][1] == C.COLOR_CHANGED

# Generated at 2022-06-17 10:53:16.451038
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:53:24.491024
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    cb = CallbackModule()
    assert cb.CALLBACK_VERSION == 2.0
    assert cb.CALLBACK_TYPE == 'stdout'
    assert cb.CALLBACK_NAME == 'oneline'

# Generated at 2022-06-17 10:53:35.870926
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_from

# Generated at 2022-06-17 10:53:47.919278
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.plugins.callback.oneline import CallbackModule
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host

# Generated at 2022-06-17 10:53:48.476106
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:53:51.454204
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    c = CallbackModule()
    assert c.CALLBACK_VERSION == 2.0
    assert c.CALLBACK_TYPE == 'stdout'
    assert c.CALLBACK_NAME == 'oneline'

# Generated at 2022-06-17 10:53:59.450885
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    import sys
    class TestDisplay(object):
        def __init__(self):
            self.verbosity = 0
            self.columns = 80
        def display(self, msg, color=None, stderr=False, screen_only=False, log_only=False):
            if stderr:
                out = sys.stderr
            else:
                out = sys.stdout
            if color:
                msg = stringc(msg, color)
            out.write(msg)
            out.write("\n")
            out.flush()
    class TestCallbackModule(CallbackModule):
        def __init__(self):
            self._display = TestDisplay()

# Generated at 2022-06-17 10:54:09.876592
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine

# Generated at 2022-06-17 10:54:21.836337
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.module_utils._text import to_text
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.utils.unicode import to_unicode
    from ansible.plugins.callback.oneline import CallbackModule
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

# Generated at 2022-06-17 10:54:36.091219
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Test 1
    result = {'exception': 'An exception occurred during task execution. To see the full traceback, use -vvv. The error was: error'}
    assert CallbackModule().v2_runner_on_failed(result) == 'An exception occurred during task execution. To see the full traceback, use -vvv. The error was: error'

    # Test 2
    result = {'exception': 'An exception occurred during task execution. The full traceback is: traceback'}
    assert CallbackModule().v2_runner_on_failed(result) == 'An exception occurred during task execution. The full traceback is: traceback'

    # Test 3
    result = {'exception': 'An exception occurred during task execution. The full traceback is: traceback', 'rc': 1}
    assert CallbackModule().v2_

# Generated at 2022-06-17 10:54:47.737624
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.utils.unicode import to_unicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import unwrap_var
    from ansible.utils.unsafe_proxy import unsafe_proxy_plugin
    from ansible.utils.unsafe_proxy import unsafe_text
    from ansible.utils.unsafe_proxy import wrap_unsafe_proxy
    from ansible.utils.unsafe_proxy import unwrap_unsafe_proxy
    from ansible.utils.unsafe_proxy import AnsibleUn

# Generated at 2022-06-17 10:55:04.385924
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a mock object for the result
    class MockResult:
        def __init__(self):
            self._result = {'exception': 'exception'}
            self._task = {'action': 'action'}
            self._host = {'get_name': lambda: 'hostname'}
    result = MockResult()
    # Create a mock object for the display
    class MockDisplay:
        def __init__(self):
            self.verbosity = 3
        def display(self, msg, color):
            pass
    display = MockDisplay()
    # Create a mock object for the callback
    class MockCallback:
        def __init__(self):
            self._display = display
    callback = MockCallback()
    # Call the method
    callback.v2_runner_on_failed(result)

# Unit test

# Generated at 2022-06-17 10:55:12.750204
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback.oneline import CallbackModule
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.utils.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

# Generated at 2022-06-17 10:55:21.173112
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    import sys
    import io
    import unittest

    class TestCallbackModule(CallbackBase):
        CALLBACK_VERSION = 2.0
        CALLBACK_TYPE = 'stdout'
        CALLBACK_NAME = 'oneline'

        def __init__(self):
            self.test_stdout = io.StringIO()
            self.test_stderr = io.StringIO()
            self.test_stdout_write = self.test_stdout.write
            self.test_stderr_write = self.test_stderr.write
            self.test_stdout.write = self.test_stderr.write = self.test_write
            self.test_stdout.isatty = self.test_st

# Generated at 2022-06-17 10:55:25.235128
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:55:35.733353
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Create a mock object for the result
    result = Mock()
    result._result = {'changed': False}
    result._task = Mock()
    result._task.action = 'command'
    result._host = Mock()
    result._host.get_name.return_value = 'localhost'

    # Create a mock object for the display
    display = Mock()

    # Create a mock object for the callback module
    callback_module = CallbackModule()
    callback_module._display = display

    # Call the method
    callback_module.v2_runner_on_ok(result)

    # Check the result
    display.display.assert_called_once_with('localhost | SUCCESS => {}', color=C.COLOR_OK)


# Generated at 2022-06-17 10:55:45.411318
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible.plugins.callback.oneline import CallbackModule
    from ansible.playbook.task import Task
    from ansible.executor.task_result import TaskResult
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-17 10:55:55.934581
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    import json
    import sys
    import unittest

    class TestCallbackModule(unittest.TestCase):

        def setUp(self):
            self.callback = CallbackModule()
            self.callback.display = Display()
            self.callback.display.verbosity = 0

        def test_v2_runner_on_ok_with_changed_result(self):
            result = Result()
            result._result = {'changed': True}
            result._host = Host()
            result._host.get_name = lambda: 'hostname'
            result._task = Task()
            result._task.action = 'action'
            self.callback.v2_runner_on_ok(result)
            self.assertEqual(self.callback.display.messages, ['hostname | CHANGED => {}'])


# Generated at 2022-06-17 10:55:56.421025
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:56:03.651414
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.plugins.callback.oneline import CallbackModule
    display = Display()
    callback = CallbackModule(display)
    result = CallbackBase()
    result._host = CallbackBase()
    result._host.get_name = lambda: 'test_host'
    result._result = {'changed': True}
    result._task = CallbackBase()
    result._task.action = 'test_action'
    callback.v2_runner_on_ok(result)

# Generated at 2022-06-17 10:56:13.660129
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.utils.unicode import to_unicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import unwrap_var

    display = Display()
    display.verbosity = 3
    display.columns = 80
    display.colorize = True

    callback = CallbackModule()
    callback._display = display


# Generated at 2022-06-17 10:56:37.550730
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    import sys
    import json

    class TestCallbackModule(CallbackBase):
        def __init__(self):
            self.display = Display()
            super(TestCallbackModule, self).__init__()

    class Display:
        def __init__(self):
            self.verbosity = 0
            self.color = 'YELLOW'

        def display(self, msg, color=None):
            if color:
                msg = stringc(msg, color)
            print(msg)

    class Host:
        def __init__(self, name):
            self.name = name

        def get_name(self):
            return self.name


# Generated at 2022-06-17 10:56:38.074886
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:56:49.274164
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Create a mock object of class CallbackModule
    mock_CallbackModule = CallbackModule()
    # Create a mock object of class Result
    mock_result = Result()
    # Create a mock object of class Host
    mock_host = Host()
    # Create a mock object of class Task
    mock_task = Task()
    # Create a mock object of class Display
    mock_display = Display()
    # Create a mock object of class DumpResults
    mock_dump_results = DumpResults()

    # Set attribute '_result' of mock object 'mock_result' to a dictionary
    mock_result._result = {'changed': False}
    # Set attribute 'action' of mock object 'mock_task' to a string
    mock_task.action = 'MODULE_NO_JSON'
    # Set attribute '_task' of

# Generated at 2022-06-17 10:56:57.182337
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Create a mock object of class CallbackModule
    callback_module = CallbackModule()
    # Create a mock object of class Result
    result = Result()
    # Set the attribute '_result' of the mock object 'result'
    result._result = {'changed': False}
    # Set the attribute '_task' of the mock object 'result'
    result._task = Task()
    # Set the attribute 'action' of the mock object 'result._task'
    result._task.action = 'command'
    # Set the attribute '_host' of the mock object 'result'
    result._host = Host()
    # Set the attribute 'get_name' of the mock object 'result._host'
    result._host.get_name = lambda: 'hostname'
    # Call the method 'v2_runner_on_ok' of the

# Generated at 2022-06-17 10:56:57.715102
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:57:00.361238
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # test constructor
    c = CallbackModule()
    assert c.CALLBACK_VERSION == 2.0
    assert c.CALLBACK_TYPE == 'stdout'
    assert c.CALLBACK_NAME == 'oneline'

# Generated at 2022-06-17 10:57:02.077549
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:57:13.339264
# Unit test for method v2_runner_on_ok of class CallbackModule

# Generated at 2022-06-17 10:57:22.635246
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a mock object for the class CallbackModule
    mock_CallbackModule = CallbackModule()
    # Create a mock object for the class Result
    mock_result = Result()
    # Create a mock object for the class Host
    mock_host = Host()
    # Create a mock object for the class Task
    mock_task = Task()
    # Create a mock object for the class TaskResult
    mock_task_result = TaskResult()
    # Create a mock object for the class Play
    mock_play = Play()
    # Create a mock object for the class PlayContext
    mock_play_context = PlayContext()
    # Create a mock object for the class Playbook
    mock_playbook = Playbook()
    # Create a mock object for the class PlaybookExecutor
    mock_playbook_executor = PlaybookExecutor()
    #

# Generated at 2022-06-17 10:57:36.149989
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    import json
    import sys
    import unittest
    from ansible.plugins.callback import CallbackBase
    from ansible.plugins.callback.oneline import CallbackModule

    class TestCallbackModule(unittest.TestCase):
        def setUp(self):
            self.callback = CallbackModule()
            self.callback._display = Display()

        def test_v2_runner_on_failed(self):
            result = Result()
            result._result = {'exception': 'exception'}
            result._task = Task()
            result._task.action = 'action'
            result._host = Host()
            result._host.get_name = lambda: 'hostname'
            self.callback.v2_runner_on_failed(result)

# Generated at 2022-06-17 10:58:14.780761
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback.oneline import CallbackModule
    from ansible.utils.color import stringc
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import Task

# Generated at 2022-06-17 10:58:21.011166
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.plugins.callback.oneline import CallbackModule
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role

# Generated at 2022-06-17 10:58:32.879766
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C

    class CallbackModule(CallbackBase):

        '''
        This is the default callback interface, which simply prints messages
        to stdout when new callback events are received.
        '''

        CALLBACK_VERSION = 2.0
        CALLBACK_TYPE = 'stdout'
        CALLBACK_NAME = 'oneline'

        def _command_generic_msg(self, hostname, result, caption):
            stdout = result.get('stdout', '').replace('\n', '\\n').replace('\r', '\\r')
            if 'stderr' in result and result['stderr']:
                stderr = result.get('stderr', '').replace('\n', '\\n').replace('\r', '\\r')

# Generated at 2022-06-17 10:58:41.527240
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Test with a result that has no exception
    result = {
        '_host': {
            'get_name': lambda: 'test_host'
        },
        '_result': {
            'rc': 1,
            'stdout': 'test_stdout',
            'stderr': 'test_stderr'
        },
        '_task': {
            'action': 'test_action'
        }
    }
    callback = CallbackModule()
    callback.v2_runner_on_failed(result)
    assert callback._display.display.call_count == 1
    assert callback._display.display.call_args[0][0] == 'test_host | FAILED! => {"rc": 1, "stdout": "test_stdout", "stderr": "test_stderr"}'


# Generated at 2022-06-17 10:58:49.743816
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Create an instance of the CallbackModule class
    callback = CallbackModule()
    # Create an instance of the Result class
    result = Result()
    # Set the result._host attribute
    result._host = "localhost"
    # Set the result._result attribute
    result._result = {'changed': False}
    # Set the result._task attribute
    result._task = "task"
    # Call the v2_runner_on_ok method of the CallbackModule class
    callback.v2_runner_on_ok(result)


# Generated at 2022-06-17 10:58:58.804980
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.playbook.task import Task
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude

# Generated at 2022-06-17 10:59:09.174323
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine

# Generated at 2022-06-17 10:59:19.162690
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    import json
    import sys
    import unittest
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C

    class TestCallbackModule(CallbackBase):
        CALLBACK_VERSION = 2.0
        CALLBACK_TYPE = 'stdout'
        CALLBACK_NAME = 'oneline'

        def _command_generic_msg(self, hostname, result, caption):
            stdout = result.get('stdout', '').replace('\n', '\\n').replace('\r', '\\r')
            if 'stderr' in result and result['stderr']:
                stderr = result.get('stderr', '').replace('\n', '\\n').replace('\r', '\\r')

# Generated at 2022-06-17 10:59:29.503825
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    import json
    import sys
    from ansible.plugins.callback.oneline import CallbackModule
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block


# Generated at 2022-06-17 10:59:33.455571
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule().CALLBACK_VERSION == 2.0
    assert CallbackModule().CALLBACK_TYPE == 'stdout'
    assert CallbackModule().CALLBACK_NAME == 'oneline'

# Generated at 2022-06-17 11:00:52.245950
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Test with changed=True
    result = {'changed': True}
    callback = CallbackModule()
    assert callback.v2_runner_on_ok(result) == " | CHANGED => {}"

    # Test with changed=False
    result = {'changed': False}
    callback = CallbackModule()
    assert callback.v2_runner_on_ok(result) == " | SUCCESS => {}"


# Generated at 2022-06-17 11:01:03.356299
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    import sys
    import io

    class TestCallbackModule(CallbackModule):
        def __init__(self):
            self.color = False
            self.verbosity = 0
            self.display = CallbackBase()
            self.display.verbosity = 0
            self.display.color = False
            self.display.columns = 80
            self.display.stdout = io.StringIO()
            self.display.stderr = io.StringIO()
            self.display.stdout_lines = []
            self.display.stderr_lines = []


# Generated at 2022-06-17 11:01:14.140214
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.plugins.callback.oneline import CallbackModule
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-17 11:01:22.043860
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.utils.unicode import to_unicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.unsafe_proxy import wrap_var
   

# Generated at 2022-06-17 11:01:22.883597
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 11:01:24.960108
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 11:01:25.960544
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 11:01:35.963013
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.playbook.task import Task
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display
    from ansible.utils.color import stringc
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.loader import callback_loader
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-17 11:01:37.906395
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 11:01:38.433732
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()