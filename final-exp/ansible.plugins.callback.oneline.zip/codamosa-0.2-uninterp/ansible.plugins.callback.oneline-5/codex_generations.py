

# Generated at 2022-06-17 10:51:57.754313
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    import ansible.plugins.callback.oneline
    import ansible.playbook.task
    import ansible.executor.task_result
    import ansible.vars.manager
    import ansible.inventory.host
    import ansible.inventory.group
    import ansible.inventory.manager
    import ansible.utils.vars
    import ansible.parsing.dataloader
    import ansible.playbook.play
    import ansible.playbook.play_context
    import ansible.executor.playbook_executor
    import ansible.executor.task_queue_manager
    import ansible.plugins.loader
    import ansible.plugins.strategy
    import ansible.plugins.action
    import ansible.plugins.connection
    import ansible.plugins.shell
    import ansible.plugins.connection

# Generated at 2022-06-17 10:52:04.305202
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.color import stringc
    from ansible.utils.sentinel import Sentinel
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

# Generated at 2022-06-17 10:52:04.777846
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:52:09.207704
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a CallbackModule object
    cb = CallbackModule()

    # Create a result object
    result = {'exception': 'An exception occurred during task execution. To see the full traceback, use -vvv. The error was: error'}

    # Call method v2_runner_on_failed
    cb.v2_runner_on_failed(result)


# Generated at 2022-06-17 10:52:10.220444
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:52:20.323860
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.plugins.callback.oneline import CallbackModule
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
   

# Generated at 2022-06-17 10:52:23.092825
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    c = CallbackModule()
    assert c.CALLBACK_VERSION == 2.0
    assert c.CALLBACK_TYPE == 'stdout'
    assert c.CALLBACK_NAME == 'oneline'

# Generated at 2022-06-17 10:52:33.859869
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Test with verbosity < 3
    callback = CallbackModule()
    callback._display = MockDisplay()
    callback._display.verbosity = 2
    result = MockResult()
    result._result = {'exception': 'An exception occurred during task execution. To see the full traceback, use -vvv. The error was: An error message'}
    result._task = MockTask()
    result._task.action = 'command'
    result._host = MockHost()
    result._host.get_name = Mock(return_value='localhost')
    callback.v2_runner_on_failed(result)
    assert callback._display.msg == 'An exception occurred during task execution. To see the full traceback, use -vvv. The error was: An error message'
    assert callback._display.color == 'red'
    # Test with verb

# Generated at 2022-06-17 10:52:40.041711
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    import sys
    import os
    import tempfile
    import shutil
    import json
    import pytest

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, output_path = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create a file object
    output_file = open(output_path, 'w')

    # Save a pointer to the original file object
    saved_stdout = sys.stdout

    # Replace the standard output with our own file object
    sys.stdout = output_file

    # Create a CallbackModule object
    callback = CallbackModule()



# Generated at 2022-06-17 10:52:46.674140
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a mock object for the class CallbackModule
    mock_CallbackModule = CallbackModule()
    # Create a mock object for the class Result
    mock_Result = Result()
    # Create a mock object for the class Host
    mock_Host = Host()
    # Create a mock object for the class Task
    mock_Task = Task()
    # Create a mock object for the class Play
    mock_Play = Play()
    # Create a mock object for the class PlayContext
    mock_PlayContext = PlayContext()
    # Create a mock object for the class Display
    mock_Display = Display()
    # Create a mock object for the class Options
    mock_Options = Options()
    # Create a mock object for the class VariableManager
    mock_VariableManager = VariableManager()
    # Create a mock object for the class Inventory

# Generated at 2022-06-17 10:53:01.673410
# Unit test for method v2_runner_on_ok of class CallbackModule

# Generated at 2022-06-17 10:53:12.516614
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    import unittest
    import sys
    import io
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.plugins.callback.oneline import CallbackModule
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

# Generated at 2022-06-17 10:53:23.086044
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a mock object of class CallbackModule
    mock_CallbackModule = CallbackModule()
    # Create a mock object of class Result
    mock_result = Result()
    # Create a mock object of class Host
    mock_host = Host()
    # Set the hostname of the host object
    mock_host.name = "test_host"
    # Set the host object of the result object
    mock_result._host = mock_host
    # Set the result object of the result object
    mock_result._result = {'exception': 'An exception occurred during task execution. The full traceback is:\n'}
    # Set the task object of the result object
    mock_result._task = Task()
    # Set the action of the task object
    mock_result._task.action = 'shell'
    # Set the verbosity of the display

# Generated at 2022-06-17 10:53:35.363092
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.plugins.callback.oneline import CallbackModule
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
   

# Generated at 2022-06-17 10:53:47.841330
# Unit test for method v2_runner_on_ok of class CallbackModule

# Generated at 2022-06-17 10:53:52.141337
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Test with changed=True
    result = {'changed': True}
    callback = CallbackModule()
    assert callback.v2_runner_on_ok(result) == 'SUCCESS => {}'

    # Test with changed=False
    result = {'changed': False}
    callback = CallbackModule()
    assert callback.v2_runner_on_ok(result) == 'SUCCESS => {}'


# Generated at 2022-06-17 10:53:52.654073
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:54:00.173306
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.utils.unicode import to_unicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import wrap_text
    from ansible.utils.unsafe_proxy import unwrap_text
    from ansible.utils.unsafe_proxy import unwrap_var
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import wrap_text

# Generated at 2022-06-17 10:54:01.421295
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:54:10.277094
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.color import colorize, hostcolor
    from ansible.utils.plugin_docs import get_docstring
    from ansible.utils.sentinel import Sentinel

# Generated at 2022-06-17 10:54:26.655289
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    import json
    import sys
    import os
    import tempfile
    import shutil
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.plugins.callback.oneline import CallbackModule
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options

# Generated at 2022-06-17 10:54:38.408031
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

# Generated at 2022-06-17 10:54:47.995278
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar

# Generated at 2022-06-17 10:54:59.810830
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block

# Generated at 2022-06-17 10:55:05.300988
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create an instance of CallbackModule
    callbackModule = CallbackModule()

    # Create a mock result
    result = Mock()
    result._result = {'exception': 'An exception occurred during task execution. The full traceback is:\n'}
    result._task = Mock()
    result._task.action = 'action'
    result._host = Mock()
    result._host.get_name = Mock(return_value='hostname')

    # Call the method v2_runner_on_failed
    callbackModule.v2_runner_on_failed(result)


# Generated at 2022-06-17 10:55:12.827251
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.utils.unicode import to_unicode
    from ansible.plugins.callback.oneline import CallbackModule
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.process.worker import WorkerProcess
    from ansible.executor.stats import AggregateStats
   

# Generated at 2022-06-17 10:55:21.218512
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.plugins.callback.oneline import CallbackModule
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 10:55:25.235616
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:55:36.206352
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Test with verbosity < 3
    callback = CallbackModule()
    callback._display = MockDisplay()
    callback._display.verbosity = 2
    result = MockResult()
    result._result = {'exception': 'An exception occurred during task execution. To see the full traceback, use -vvv. The error was: error'}
    callback.v2_runner_on_failed(result)
    assert callback._display.display_args[0] == 'An exception occurred during task execution. To see the full traceback, use -vvv. The error was: error'
    assert callback._display.display_args[1] == {'color': '\x1b[31m'}
    assert callback._display.display_args[2] == '\x1b[0m'
    assert callback._display.display_args[3]

# Generated at 2022-06-17 10:55:45.772304
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Test data
    result = {'exception': 'An exception occurred during task execution. To see the full traceback, use -vvv. The error was: error message'}
    # Test execution
    callback = CallbackModule()
    callback.v2_runner_on_failed(result)
    # Test assertion
    assert callback._display.display == 'An exception occurred during task execution. To see the full traceback, use -vvv. The error was: error message'


# Generated at 2022-06-17 10:56:07.276667
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C

    class CallbackModule(CallbackBase):

        '''
        This is the default callback interface, which simply prints messages
        to stdout when new callback events are received.
        '''

        CALLBACK_VERSION = 2.0
        CALLBACK_TYPE = 'stdout'
        CALLBACK_NAME = 'oneline'

        def _command_generic_msg(self, hostname, result, caption):
            stdout = result.get('stdout', '').replace('\n', '\\n').replace('\r', '\\r')
            if 'stderr' in result and result['stderr']:
                stderr = result.get('stderr', '').replace('\n', '\\n').replace('\r', '\\r')

# Generated at 2022-06-17 10:56:15.708101
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine

# Generated at 2022-06-17 10:56:23.681222
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 2
    callback = CallbackModule()
    callback._display = display
    result = CallbackBase()
    result._host = 'localhost'
    result._result = {'changed': True}
    result._task = CallbackBase()
    result._task.action = 'command'
    callback.v2_runner_on_ok(result)
    assert callback._display.display.call_count == 1
    assert callback._display.display.call_args[0][0] == stringc(u'localhost | CHANGED => {}', C.COLOR_CHANGED)
    assert callback._display.display

# Generated at 2022-06-17 10:56:28.833763
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule().CALLBACK_VERSION == 2.0
    assert CallbackModule().CALLBACK_TYPE == 'stdout'
    assert CallbackModule().CALLBACK_NAME == 'oneline'

# Generated at 2022-06-17 10:56:33.472349
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    module = CallbackModule()
    assert module.CALLBACK_VERSION == 2.0
    assert module.CALLBACK_TYPE == 'stdout'
    assert module.CALLBACK_NAME == 'oneline'

# Generated at 2022-06-17 10:56:39.575186
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Create a mock object for the result
    class MockResult:
        def __init__(self):
            self._result = {'changed': False}
            self._host = MockHost()
            self._task = MockTask()

    # Create a mock object for the host
    class MockHost:
        def __init__(self):
            self.get_name = lambda: 'test_host'

    # Create a mock object for the task
    class MockTask:
        def __init__(self):
            self.action = 'test_action'

    # Create a mock object for the display
    class MockDisplay:
        def __init__(self):
            self.display = lambda x, y: x

    # Create a mock object for the callback
    class MockCallback:
        def __init__(self):
            self._display = Mock

# Generated at 2022-06-17 10:56:50.296259
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Test with changed=True
    result = {'changed': True}
    callback = CallbackModule()
    callback.v2_runner_on_ok(result)
    assert callback._display.display.call_count == 1
    assert callback._display.display.call_args[0][0] == ' | CHANGED => '
    assert callback._display.display.call_args[0][1] == C.COLOR_CHANGED

    # Test with changed=False
    result = {'changed': False}
    callback = CallbackModule()
    callback.v2_runner_on_ok(result)
    assert callback._display.display.call_count == 1
    assert callback._display.display.call_args[0][0] == ' | SUCCESS => '

# Generated at 2022-06-17 10:56:57.863404
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.utils.unicode import to_unicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import VariableManager
   

# Generated at 2022-06-17 10:57:05.876058
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    import json
    import sys
    import unittest
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.plugins.callback.oneline import CallbackModule

    class FakeResult(object):
        def __init__(self, host, result):
            self._host = host
            self._result = result

    class FakeHost(object):
        def __init__(self, name):
            self.name = name

        def get_name(self):
            return self.name

    class FakeDisplay(Display):
        def __init__(self):
            self.verbosity = 3
            self.displayed = []


# Generated at 2022-06-17 10:57:09.685388
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:57:48.069673
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    import sys
    import io
    import unittest
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.plugins.callback.oneline import CallbackModule

    class TestCallbackModule(unittest.TestCase):
        def setUp(self):
            self.capturedOutput = io.StringIO()
            sys.stdout = self.capturedOutput

        def tearDown(self):
            sys.stdout = sys.__stdout__

        def test_v2_runner_on_ok(self):
            result = {'changed': False}
            result_host = {'get_name': lambda: 'test_host'}
            result_task = {'action': 'test_action'}

# Generated at 2022-06-17 10:57:57.432362
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.plugins.callback.oneline import CallbackModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role

# Generated at 2022-06-17 10:58:06.286482
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback.oneline import CallbackModule
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 10:58:12.600074
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback.oneline import CallbackModule
    from ansible.playbook.task import Task
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.color import stringc
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_text
    import json
    import sys
    import os

# Generated at 2022-06-17 10:58:23.643088
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Test with verbosity < 3
    callback = CallbackModule()
    callback._display = Display()
    callback._display.verbosity = 2
    result = Result()

# Generated at 2022-06-17 10:58:36.327783
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine

# Generated at 2022-06-17 10:58:36.750302
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:58:43.911259
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    import sys
    import io
    import unittest

    class TestCallbackModule(CallbackBase):
        CALLBACK_VERSION = 2.0
        CALLBACK_TYPE = 'stdout'
        CALLBACK_NAME = 'oneline'

        def __init__(self):
            self.output = io.StringIO()
            super(TestCallbackModule, self).__init__()

        def _write_stdout(self, msg):
            self.output.write(msg)

        def _display(self, msg, color=None, stderr=False, screen_only=False, log_only=False):
            self._write_stdout(msg)


# Generated at 2022-06-17 10:58:51.063045
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

# Generated at 2022-06-17 10:58:53.628574
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule().CALLBACK_VERSION == 2.0
    assert CallbackModule().CALLBACK_TYPE == 'stdout'
    assert CallbackModule().CALLBACK_NAME == 'oneline'

# Generated at 2022-06-17 11:00:34.823896
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Create a mock object for the display class
    display = Display()

    # Create a mock object for the result class
    result = Result()

    # Create a mock object for the host class
    host = Host()

    # Create a mock object for the task class
    task = Task()

    # Create a mock object for the callback class
    callback = CallbackModule(display)

    # Set the host name
    host.name = "localhost"

    # Set the result
    result._result = {'changed': False}
    result._host = host
    result._task = task

    # Set the task action
    task.action = "command"

    # Call the method v2_runner_on_ok
    callback.v2_runner_on_ok(result)

    # Check the result

# Generated at 2022-06-17 11:00:36.832332
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    cb = CallbackModule()
    assert cb.CALLBACK_VERSION == 2.0
    assert cb.CALLBACK_TYPE == 'stdout'
    assert cb.CALLBACK_NAME == 'oneline'

# Generated at 2022-06-17 11:00:46.478849
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

# Generated at 2022-06-17 11:00:53.875376
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    import json
    import sys
    import unittest
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.plugins.callback.oneline import CallbackModule

    class TestCallbackModule(unittest.TestCase):
        def setUp(self):
            self.display = Display()
            self.callback = CallbackModule(display=self.display)
            self.callback._display = self.display
            self.callback._dump_results = CallbackBase._dump_results
            self.callback._command_generic_msg = CallbackModule._command_generic_msg


# Generated at 2022-06-17 11:01:04.533995
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a mock object of class CallbackModule
    mock_CallbackModule = CallbackModule()
    # Create a mock object of class Result
    mock_result = Result()
    # Create a mock object of class Host
    mock_host = Host()
    # Create a mock object of class Task
    mock_task = Task()
    # Create a mock object of class Action
    mock_action = Action()
    # Create a mock object of class Display
    mock_display = Display()
    # Create a mock object of class C
    mock_C = C()
    # Create a mock object of class Result
    mock_result = Result()
    # Create a mock object of class Result
    mock_result = Result()
    # Create a mock object of class Result
    mock_result = Result()
    # Create a mock object of class Result
    mock_result

# Generated at 2022-06-17 11:01:15.380766
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Test with verbosity < 3
    callback = CallbackModule()
    callback._display = MockDisplay()
    callback._display.verbosity = 2
    result = MockResult()

# Generated at 2022-06-17 11:01:22.945476
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a callback module object
    cb = CallbackModule()
    # Create a result object

# Generated at 2022-06-17 11:01:35.037660
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Create a mock object for the result
    result = Mock()
    result._host = Mock()
    result._host.get_name.return_value = "test_host"
    result._result = {'changed': True}
    result._task = Mock()
    result._task.action = "test_action"

    # Create a mock object for the display
    display = Mock()

    # Create a mock object for the callback
    callback = CallbackModule()
    callback._display = display

    # Call the method
    callback.v2_runner_on_ok(result)

    # Check the results
    display.display.assert_called_with("test_host | CHANGED => {}", color=C.COLOR_CHANGED)


# Generated at 2022-06-17 11:01:44.131461
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Test with verbosity < 3
    callback = CallbackModule()
    callback._display = MagicMock()
    result = MagicMock()