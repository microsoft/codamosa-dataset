

# Generated at 2022-06-17 10:51:59.346350
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 3
    callback = CallbackModule()
    callback.set_options(display=display)
    result = CallbackBase()
    result._task = CallbackBase()
    result._task.action = 'shell'
    result._host = CallbackBase()
    result._host.get_name = lambda: 'localhost'

# Generated at 2022-06-17 10:52:08.181999
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    import ansible.plugins.callback.oneline as oneline
    import ansible.plugins.callback.default as default
    import ansible.plugins.callback.json as json
    import ansible.plugins.callback.yaml as yaml
    import ansible.plugins.callback.minimal as minimal
    import ansible.plugins.callback.profile_roles as profile_roles
    import ansible.plugins.callback.profile_tasks as profile_tasks
    import ansible.plugins.callback.tree as tree
    import ansible.plugins.callback.actionable as actionable
    import ansible.plugins.callback.log_plays as log_plays
    import ansible.plugins.callback.log_plays_verbose as log_plays_verbose
    import ansible.plugins.callback.log_plays_compact as log_plays_compact


# Generated at 2022-06-17 10:52:19.524940
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.utils.unicode import to_unicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.playbook.task import Task
   

# Generated at 2022-06-17 10:52:27.282142
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Arrange
    result = {'exception': 'An exception occurred during task execution. The full traceback is:\n'}
    result['exception'] += 'Traceback (most recent call last):\n'
    result['exception'] += '  File "/home/vagrant/.ansible/tmp/ansible-tmp-1489749071.03-24554855145529/command", line 1, in <module>\n'

# Generated at 2022-06-17 10:52:28.150310
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:52:37.511817
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a mock object for the result
    result = Mock()
    result._result = {'exception': 'An exception occurred during task execution. The full traceback is:\n'}
    result._task = Mock()
    result._task.action = 'test'
    result._host = Mock()
    result._host.get_name.return_value = 'test'

    # Create a mock object for the display
    display = Mock()
    display.verbosity = 3
    display.display.return_value = None

    # Create a mock object for the constants
    constants = Mock()
    constants.MODULE_NO_JSON = ['test']
    constants.COLOR_ERROR = 'test'

    # Create a mock object for the callback
    callback = Mock()
    callback._display = display
    callback._dump_results = Mock()
    callback

# Generated at 2022-06-17 10:52:45.760696
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.plugins.callback.oneline import CallbackModule
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

# Generated at 2022-06-17 10:52:57.357054
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    import sys
    import io
    import unittest

    class TestDisplay:
        def __init__(self):
            self.verbosity = 3
            self.color = 'yes'

# Generated at 2022-06-17 10:53:09.052339
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    import sys
    import io
    import unittest

    class TestCallbackModule(CallbackModule):
        def __init__(self):
            self._display = Display()
            self._display.verbosity = 3
            self._display.columns = 80
            self._display.colorize_errors = True
            self._display.colorize_verbosity = True
            self._display.colorize_ok = True
            self._display.colorize_skipped = True
            self._display.colorize_unreachable = True
            self._display.colorize_changed = True
            self._display.colorize_warnings = True
            self._display

# Generated at 2022-06-17 10:53:17.956311
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.utils.unicode import to_unicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.errors import AnsibleError
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping

# Generated at 2022-06-17 10:53:35.099911
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a mock object for the result
    class MockResult:
        def __init__(self):
            self._result = {'exception': 'An exception occurred during task execution. To see the full traceback, use -vvv. The error was: error'}
            self._task = {'action': 'action'}
            self._host = {'get_name': 'hostname'}
    result = MockResult()
    # Create a mock object for the display
    class MockDisplay:
        def __init__(self):
            self.verbosity = 3
        def display(self, msg, color):
            pass
    display = MockDisplay()
    # Create a mock object for the callback
    class MockCallback:
        def __init__(self):
            self._display = display
    callback = MockCallback()
    # Call the method

# Generated at 2022-06-17 10:53:41.665439
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Initialize a CallbackModule object
    cm = CallbackModule()
    # Initialize a result object
    result = {'exception': 'An exception occurred during task execution. To see the full traceback, use -vvv. The error was: %s'}
    # Call method v2_runner_on_failed of class CallbackModule
    cm.v2_runner_on_failed(result)
    # Check if the result is as expected
    assert result == {'exception': 'An exception occurred during task execution. To see the full traceback, use -vvv. The error was: %s'}


# Generated at 2022-06-17 10:53:46.178604
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback = CallbackModule()
    assert callback.CALLBACK_VERSION == 2.0
    assert callback.CALLBACK_TYPE == 'stdout'
    assert callback.CALLBACK_NAME == 'oneline'

# Generated at 2022-06-17 10:53:51.269035
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.utils.unicode import to_unicode
    from ansible.plugins.callback.oneline import CallbackModule
    import json
    import sys
    import unittest

    class TestDisplay(Display):
        def __init__(self):
            self.display_data = []

        def display(self, msg, color=None, stderr=False, screen_only=False, log_only=False):
            self.display_data.append(msg)

    class TestCallbackModule(CallbackModule):
        def __init__(self):
            self._display = TestDisplay()


# Generated at 2022-06-17 10:53:51.835011
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:54:02.947339
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a mock object of class CallbackBase
    mock_display = CallbackBase()
    # Create a mock object of class CallbackModule
    mock_callback = CallbackModule()
    # Set the display attribute of mock_callback to mock_display
    mock_callback.set_options(display=mock_display)
    # Create a mock object of class Host
    mock_host = Host()
    # Create a mock object of class TaskResult
    mock_result = TaskResult()
    # Set the _host attribute of mock_result to mock_host
    mock_result._host = mock_host
    # Set the _result attribute of mock_result to {'exception': 'An exception occurred during task execution. To see the full traceback, use -vvv. The error was: error'}

# Generated at 2022-06-17 10:54:03.359898
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:54:10.357630
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Create a mock object for the result
    result = Mock()
    result._result = {'changed': False}
    result._task = Mock()
    result._task.action = 'ping'
    result._host = Mock()
    result._host.get_name.return_value = 'localhost'

    # Create a mock object for the display
    display = Mock()

    # Create a callback module
    callback = CallbackModule(display)

    # Call the method
    callback.v2_runner_on_ok(result)

    # Check the result
    display.display.assert_called_once_with("localhost | SUCCESS => {}", color=C.COLOR_OK)


# Generated at 2022-06-17 10:54:11.452247
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:54:22.730328
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C

    class TestCallbackModule(CallbackBase):
        CALLBACK_VERSION = 2.0
        CALLBACK_TYPE = 'stdout'
        CALLBACK_NAME = 'oneline'

        def v2_runner_on_ok(self, result):
            if result._result.get('changed', False):
                color = C.COLOR_CHANGED
                state = 'CHANGED'
            else:
                color = C.COLOR_OK
                state = 'SUCCESS'

            self._display.display("%s | %s => %s" % (result._host.get_name(), state, self._dump_results(result._result, indent=0).replace('\n', '')),
                                  color=color)


# Generated at 2022-06-17 10:54:39.475287
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.unicode import to_unicode
    from ansible.utils.display import Display
    from ansible.plugins.callback.oneline import CallbackModule
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

# Generated at 2022-06-17 10:54:48.627306
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.plugins.callback.oneline import CallbackModule
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block

# Generated at 2022-06-17 10:55:00.518417
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Test 1
    result = {'changed': True}
    callback = CallbackModule()
    callback.v2_runner_on_ok(result)

# Generated at 2022-06-17 10:55:03.153558
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:55:09.293172
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Test with a result that has changed
    result = {'changed': True}
    cb = CallbackModule()
    cb.v2_runner_on_ok(result)
    assert cb.v2_runner_on_ok(result) == " | CHANGED => "
    # Test with a result that has not changed
    result = {'changed': False}
    cb = CallbackModule()
    cb.v2_runner_on_ok(result)
    assert cb.v2_runner_on_ok(result) == " | SUCCESS => "


# Generated at 2022-06-17 10:55:19.147509
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a mock object for the callback module
    callback = CallbackModule()

    # Create a mock object for the result
    result = Mock()
    result._result = {'exception': 'exception'}
    result._task = Mock()
    result._task.action = 'action'
    result._host = Mock()
    result._host.get_name.return_value = 'hostname'

    # Call the method v2_runner_on_failed
    callback.v2_runner_on_failed(result)

    # Check if the method display was called with the expected parameters
    callback._display.display.assert_called_with('An exception occurred during task execution. To see the full traceback, use -vvv. The error was: exception', color='red')


# Generated at 2022-06-17 10:55:19.658909
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:55:20.149632
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:55:25.724449
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.color import colorize, hostcolor
    from ansible.plugins.loader import callback_loader
    from ansible.errors import AnsibleError

# Generated at 2022-06-17 10:55:26.877862
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:55:45.347273
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule() is not None

# Generated at 2022-06-17 10:55:45.950025
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:55:50.618307
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule.CALLBACK_VERSION == 2.0
    assert CallbackModule.CALLBACK_TYPE == 'stdout'
    assert CallbackModule.CALLBACK_NAME == 'oneline'

# Generated at 2022-06-17 10:55:52.851204
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Test for method v2_runner_on_failed(self, result, ignore_errors=False)
    # of class CallbackModule
    pass


# Generated at 2022-06-17 10:56:00.795928
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.utils.unicode import to_unicode
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.hostvars import HostVars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

# Generated at 2022-06-17 10:56:07.071098
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a mock object of class CallbackModule
    callback_module = CallbackModule()
    # Create a mock object of class Result
    result = Result()
    # Call method v2_runner_on_failed of class CallbackModule
    callback_module.v2_runner_on_failed(result)


# Generated at 2022-06-17 10:56:15.588788
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Test with verbosity < 3
    callback = CallbackModule()
    callback._display = Display()
    callback._display.verbosity = 2
    result = Result()
    result._host = Host()
    result._host.get_name = lambda: 'host1'
    result._result = {'exception': 'An exception occurred during task execution. To see the full traceback, use -vvv. The error was: error'}
    callback.v2_runner_on_failed(result)
    assert callback._display.display_data[0] == 'An exception occurred during task execution. To see the full traceback, use -vvv. The error was: error'
    assert callback._display.display_data[1] == 'host1 | FAILED! => {}'
    # Test with verbosity >= 3
    callback = CallbackModule()

# Generated at 2022-06-17 10:56:16.153314
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:56:23.924639
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C

    class TestCallbackModule(CallbackBase):
        CALLBACK_VERSION = 2.0
        CALLBACK_TYPE = 'stdout'
        CALLBACK_NAME = 'oneline'

        def __init__(self):
            self.display = Display()

        def v2_runner_on_ok(self, result):
            if result._result.get('changed', False):
                color = C.COLOR_CHANGED
                state = 'CHANGED'
            else:
                color = C.COLOR_OK
                state = 'SUCCESS'


# Generated at 2022-06-17 10:56:25.039492
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:56:55.999676
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:57:01.848043
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.utils.unicode import to_unicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import wrap_text
    from ansible.utils.unsafe_proxy import unwrap_text
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.utils.unsafe_proxy import wrap_bytes
    from ansible.utils.unsafe_proxy import unwrap_bytes
    from ansible.utils.unsafe_proxy import wrap_var

# Generated at 2022-06-17 10:57:13.022640
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 3
    display.columns = 80
    display.colorize = True
    display.set_terminal_title = False
    display.debug = False
    display.deprecate_as_string = False
    display.display("test", color=C.COLOR_SKIP)
    display.display("test", color=C.COLOR_OK)
    display.display("test", color=C.COLOR_CHANGED)
    display.display("test", color=C.COLOR_ERROR)
    display.display("test", color=C.COLOR_UNREACHABLE)

# Generated at 2022-06-17 10:57:22.419021
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Test with verbosity less than 3
    result = {'exception': 'An exception occurred during task execution. To see the full traceback, use -vvv. The error was: error'}
    cb = CallbackModule()
    cb._display.verbosity = 2
    cb.v2_runner_on_failed(result)
    assert cb._display.display.call_args[0][0] == 'An exception occurred during task execution. To see the full traceback, use -vvv. The error was: error'
    assert cb._display.display.call_args[1]['color'] == 'red'

    # Test with verbosity greater than or equal to 3
    result = {'exception': 'An exception occurred during task execution. The full traceback is:\n' + 'traceback'}
    cb = Call

# Generated at 2022-06-17 10:57:23.577670
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:57:24.886778
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:57:36.300367
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Create a mock object for the result
    result = Mock()
    result._result = {'changed': False}
    result._task = Mock()
    result._task.action = 'command'
    result._host = Mock()
    result._host.get_name.return_value = 'localhost'

    # Create a mock object for the display
    display = Mock()

    # Create a mock object for the callback
    callback = CallbackModule()
    callback._display = display

    # Call the method
    callback.v2_runner_on_ok(result)

    # Assert that the display was called with the expected message
    display.display.assert_called_with("localhost | SUCCESS => {}", color=None)


# Generated at 2022-06-17 10:57:44.779344
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Test with changed=False
    result = {'changed': False}
    cb = CallbackModule()
    cb.v2_runner_on_ok(result)
    assert cb.state == 'SUCCESS'
    assert cb.color == C.COLOR_OK

    # Test with changed=True
    result = {'changed': True}
    cb = CallbackModule()
    cb.v2_runner_on_ok(result)
    assert cb.state == 'CHANGED'
    assert cb.color == C.COLOR_CHANGED

# Generated at 2022-06-17 10:57:46.198746
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:57:56.190034
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    import json

    class TestCallbackModule(CallbackBase):
        CALLBACK_VERSION = 2.0
        CALLBACK_TYPE = 'stdout'
        CALLBACK_NAME = 'oneline'

        def v2_runner_on_ok(self, result):
            if result._result.get('changed', False):
                color = C.COLOR_CHANGED
                state = 'CHANGED'
            else:
                color = C.COLOR_OK
                state = 'SUCCESS'


# Generated at 2022-06-17 10:59:13.418258
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a new instance of CallbackModule
    callbackModule = CallbackModule()
    # Create a new instance of Result
    result = Result()
    # Set the attribute _host of result to a new instance of Host
    result._host = Host()
    # Set the attribute get_name of result._host to 'localhost'
    result._host.get_name = lambda: 'localhost'
    # Set the attribute _result of result to a new dictionary
    result._result = {}
    # Set the attribute exception of result._result to 'An exception occurred during task execution. The full traceback is:\n'
    result._result['exception'] = 'An exception occurred during task execution. The full traceback is:\n'
    # Set the attribute _task of result to a new instance of Task
    result._task = Task()
    # Set the attribute action of result._

# Generated at 2022-06-17 10:59:25.390483
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.plugins.callback.oneline import CallbackModule
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

# Generated at 2022-06-17 10:59:26.824783
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:59:27.624444
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:59:28.439183
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:59:37.209121
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role

# Generated at 2022-06-17 10:59:46.664959
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.utils.unicode import to_unicode
    from ansible.plugins.callback.oneline import CallbackModule
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-17 10:59:56.169686
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    import json
    import sys
    import os
    import io
    import unittest
    import unittest.mock

    class TestCallbackModule(CallbackModule):
        def __init__(self, *args, **kwargs):
            super(TestCallbackModule, self).__init__(*args, **kwargs)
            self.results = []

        def _display(self, msg, color=None):
            self.results.append(msg)

    class TestCallbackModule_v2_runner_on_ok(unittest.TestCase):
        def setUp(self):
            self.test_callback = TestCallbackModule()
            self.test_result = unittest.mock.Mock()
            self.test_result._host

# Generated at 2022-06-17 10:59:59.345610
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule() is not None

# Generated at 2022-06-17 10:59:59.772036
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()