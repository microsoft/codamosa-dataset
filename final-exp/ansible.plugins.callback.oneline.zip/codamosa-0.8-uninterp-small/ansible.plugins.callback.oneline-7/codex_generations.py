

# Generated at 2022-06-25 08:48:50.185809
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    result = dict()
    result['changed'] = True
    callback_module = CallbackModule()
    callback_module.v2_runner_on_ok(result)

# Generated at 2022-06-25 08:48:55.019016
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()

# Generated at 2022-06-25 08:48:58.019185
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert callback_module_0.CALLBACK_VERSION == 2.0
    assert callback_module_0.CALLBACK_TYPE == 'stdout'
    assert callback_module_0.CALLBACK_NAME == 'oneline'


# Generated at 2022-06-25 08:49:02.733710
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_1 = CallbackModule()
    result = {}
    result._result = {}
    result._host = {}
    result._task = {}
    callback_module_1.v2_runner_on_ok(result)


# Generated at 2022-06-25 08:49:06.799541
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = object()
    ignore_errors_0 = object()
    callback_module_0.v2_runner_on_failed(result_0,ignore_errors_0)


# Generated at 2022-06-25 08:49:15.743961
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_obj = CallbackModule()
    mock_result = Mock(stdout="stdout")
    mock_result._result = {'rc': -1, 'exception':'abc'}
    mock_result._task = Mock()
    mock_result._task.action = "shell"
    mock_result._host = Mock()
    mock_result._host.get_name = Mock(return_value="host")
    callback_module_obj.v2_runner_on_failed(mock_result)


# Generated at 2022-06-25 08:49:18.373123
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    print("\n################################################## Testing constructor of CallbackModule ##################################################\n")
    test_case_0()

# Generated at 2022-06-25 08:49:26.979290
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_1 = CallbackModule()

# Generated at 2022-06-25 08:49:31.065435
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    test_case_0.callback_module_0.v2_runner_on_ok(None)


# Generated at 2022-06-25 08:49:33.194130
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result = TestResult()
    callback_module_0.v2_runner_on_ok(result)


# Generated at 2022-06-25 08:49:51.968931
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_v2_runner_on_failed_0 = CallbackModule()
    # fail_0 = result
    fail_1 = True
    fail_0 = fail_1
    # fail_2 = ignore_errors
    fail_3 = True
    fail_2 = fail_3
    assert callable(callback_module_v2_runner_on_failed_0.v2_runner_on_failed) == True
    assert callback_module_v2_runner_on_failed_0.v2_runner_on_failed(fail_0, fail_2) == None




# Generated at 2022-06-25 08:49:52.770893
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    pass


# Generated at 2022-06-25 08:49:55.609878
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule.CALLBACK_VERSION == 2.0
    assert CallbackModule.CALLBACK_TYPE == 'stdout'
    assert CallbackModule.CALLBACK_NAME == 'oneline'

# Generated at 2022-06-25 08:49:57.139709
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert callable(CallbackModule)


# Generated at 2022-06-25 08:50:08.808646
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():

    test_vars = dict()
    test_vars['foo'] = 'bar'

    test_result = dict()
    test_result['foo'] = test_vars['foo']
    test_result['failed'] = True
    test_result['parsed'] = False

    test_result['ansible_job_id'] = 'cb_module_test'
    test_result['_ansible_verbose_always'] = True
    test_result['_ansible_no_log'] = False
    
    test_result['invocation'] = dict()
    test_result['invocation']['module_name'] = 'debug'
    test_result['invocation']['module_args'] = test_vars

    test_result['item'] = None

    test_result['changed'] = True

    test_result

# Generated at 2022-06-25 08:50:13.288719
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    test_v2_runner_on_ok_obj = CallbackModule()
    test_result_obj = {'_result': {'changed': False}, '_task': {'action': 'ping'}}
    test_v2_runner_on_ok_obj.v2_runner_on_ok(test_result_obj)



# Generated at 2022-06-25 08:50:16.794996
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    import json
    callback_module_1 = CallbackModule()
    fake_result = FakeResult()
    callback_module_1.v2_runner_on_ok(fake_result)


# Generated at 2022-06-25 08:50:22.967775
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    result = CallbackModule()
    result._result = {'exception': 'An exception occurred during task execution. To see the full traceback, use -vvv.'}
    result._task.action = 'command'
    result._host.get_name = lambda: 'localhost'
    result._result['rc'] = -1
    result._result['stdout'] = 'STDOUT '
    result._result['stderr'] = 'STDERR '
    result._display.verbosity = 3
    result._display.display = lambda msg, color: msg

    expected = 'localhost | FAILED! => {'

    assert result.v2_runner_on_failed(result) == expected


# Generated at 2022-06-25 08:50:24.486900
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result_mock = MagicMock()
    callback_module_0.v2_runner_on_ok(result_mock)


# Generated at 2022-06-25 08:50:25.938539
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module = CallbackModule()

# Generated at 2022-06-25 08:50:39.433419
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    tuple_0 = None
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_ok(tuple_0)
    assert var_0 == None


# Generated at 2022-06-25 08:50:49.409304
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    tuple_0 = None
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_ok(tuple_0)
    print("%s == None" % var_0)
    print("%s == None" % var_0)
    print("%s == None" % var_0)
    print("%s == None" % var_0)
    print("%s == None" % var_0)
    print("%s == None" % var_0)
    print("%s == None" % var_0)
    print("%s == None" % var_0)
    print("%s == None" % var_0)
    print("%s == None" % var_0)
    print("%s == None" % var_0)


# Generated at 2022-06-25 08:50:50.155070
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
	None

# Generated at 2022-06-25 08:50:51.744124
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    tuple_0 = (None, None)
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:50:54.621066
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    tuple_0 = None
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(tuple_0)


# Generated at 2022-06-25 08:50:56.646155
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert isinstance(CallbackModule(), CallbackModule)


# Generated at 2022-06-25 08:50:59.338771
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    tuple_0 = None
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_ok(tuple_0)


# Generated at 2022-06-25 08:51:02.476313
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    tuple_0 = None
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(tuple_0)


# Generated at 2022-06-25 08:51:03.586804
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    tuple_0 = None
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 08:51:04.906730
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    tuple_0 = None
    callback_module_0 = CallbackModule()
    assert var_0 == None


# Generated at 2022-06-25 08:51:23.899987
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    tuple_0 = None
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:51:26.124233
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    tuple_0 = None
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(tuple_0)



# Generated at 2022-06-25 08:51:28.296584
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    tuple_0 = None
    callback_module_0 = CallbackModule()
    assert callback_module_v2_runner_on_failed(tuple_0) == None


# Generated at 2022-06-25 08:51:33.026500
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    tuple_0 = None
    callback_module_0 = CallbackModule()
    callback_module_v2_runner_on_failed(tuple_0)


# Generated at 2022-06-25 08:51:36.412708
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    tuple_0 = None
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(tuple_0)


# Generated at 2022-06-25 08:51:39.768872
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    tuple_0 = None
    callback_module_0 = CallbackModule()
    #AssertionError: {u'msg': u'password required', u'failed': True} != {u'fatal': u'UNREACHABLE!', u'msg': u'password required', u'unreachable': True}

# Generated at 2022-06-25 08:51:42.067289
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    tuple_0 = None
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(tuple_0)



# Generated at 2022-06-25 08:51:45.812749
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    tuple_0 = None
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(tuple_0)


# Generated at 2022-06-25 08:51:54.759996
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    tuple_0 = None
    tuple_1 = None

    # Command failed
    # Command success
    callback_module_0 = CallbackModule()
    # Testing command execution
    var_return_0 = callback_module_0._command_generic_msg(tuple_0, tuple_1, 'FAILED')
    var_return_1 = callback_module_0._command_generic_msg(tuple_0, tuple_1, 'SUCCESS')
    assert var_return_0 == 'FAILED | (stdout) (stderr) '
    assert var_return_1 == 'SUCCESS | (stdout) (stderr) '


# Generated at 2022-06-25 08:51:55.635187
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()

# Generated at 2022-06-25 08:52:38.433805
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    tuple_0 = None
    callback_module_0 = CallbackModule()
    # Test method v2_runner_on_failed of class CallbackModule
    var_0 = callback_module_0.v2_runner_on_failed(tuple_0)


# Generated at 2022-06-25 08:52:42.997278
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    tuple_0 = None
    var_0 = callback_module_0.v2_runner_on_ok(tuple_0)

# Generated at 2022-06-25 08:52:45.032927
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    tuple_0 = None
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(tuple_0)


# Generated at 2022-06-25 08:52:47.551013
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert callback_module_0.CALLBACK_NAME == "oneline", "Expected 'oneline'"

# Generated at 2022-06-25 08:52:54.473394
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    #tuple_0 = None
    #callback_module_0 = CallbackModule()
    #var_0 = callback_module_0.v2_runner_on_ok(tuple_0)
    test_case_0()

if __name__ == '__main__':
    test_CallbackModule_v2_runner_on_ok()

# Generated at 2022-06-25 08:52:56.232336
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    tuple_0 = None
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(tuple_0)

# Generated at 2022-06-25 08:52:59.292943
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    tuple_0 = None
    callback_module_0 = CallbackModule()
    assert_equal(callback_module_0.CALLBACK_VERSION, 2.0)
    assert_equal(callback_module_0.CALLBACK_TYPE, 'stdout')
    assert_equal(callback_module_0.CALLBACK_NAME, 'oneline')


# Generated at 2022-06-25 08:53:05.299823
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    tuple_0 = None
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed(tuple_0, False)



# Generated at 2022-06-25 08:53:08.188818
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    tuple_0 = None
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed(tuple_0)


# Generated at 2022-06-25 08:53:10.193709
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    result_0 = None
    ignore_errors = None
    callback_module_0 = CallbackModule()
    test_case_0(result_0, ignore_errors)


# Generated at 2022-06-25 08:54:46.081123
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    tuple_0 = None
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(tuple_0)


# Generated at 2022-06-25 08:54:56.000600
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Test empty
    tuple_0 = (3)
    callback_module_0 = CallbackModule()
    var_201 = callback_v2_runner_on_ok(tuple_0)
    try:
        assert var_201 == 3
    except AssertionError:
        raise AssertionError(var_201)
    # Test empty
    dict_208 = vars(callback_module_0)
    list_209 = list(dict_208.keys())
    list_209.sort()
    var_210 = tuple(list_209)
    tuple_1 = (var_210)
    callback_module_1 = CallbackModule()
    var_211 = callback_v2_runner_on_ok(tuple_1)

# Generated at 2022-06-25 08:54:59.454480
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    tuple_0 = None
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(tuple_0)


# Generated at 2022-06-25 08:55:01.922437
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    tuple_0 = None
    callback_module_0 = CallbackModule()
    if (not (callback_module_0.display)):
        assert(False)
    callback_module_0.v2_runner_on_failed(tuple_0)


# Generated at 2022-06-25 08:55:07.437961
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    cfg = None
    display = Display()
    options = Options(connection='smart', module_path=None, forks=10, remote_user=None, private_key_file=None, ssh_common_args=None, ssh_extra_args=None, sftp_extra_args=None, scp_extra_args=None, become=None, become_method=None, become_user=None, verbosity=3, check=False, diff=False, listhosts=None, listtasks=None, listtags=None, syntax=None)
    variable_manager = VariableManager()
    loader = DataLoader()
    passwords = dict()
    callback_module_0 = CallbackModule(display=display, options=options, loader=loader, variable_manager=variable_manager)
    callback_module_0.playbook = Playbook()


# Generated at 2022-06-25 08:55:13.137453
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    tuple_0 = None
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(tuple_0)


# Generated at 2022-06-25 08:55:15.076122
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    tuple_0 = None
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(tuple_0)


# Generated at 2022-06-25 08:55:16.717908
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    tuple_0 = None
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(tuple_0)


# Generated at 2022-06-25 08:55:22.921385
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():

    class TestAnsibleModuleTestResult(object):
        def get(self, arg):
            if arg == 'stdout':
                return 'stdout'
            elif arg == 'stderr':
                return 'stderr'
            elif arg == 'rc':
                return 1
            else:
                return None

    class TestAnsibleResult(object):
        def __init__(self, ansible_module_result):
            self._result = ansible_module_result

        def get(self, arg):
            if arg == 'exception':
                return 'exception'
            else:
                return None

    test_ansible_module_test_result = TestAnsibleModuleTestResult()
    test_ansible_result = TestAnsibleResult(test_ansible_module_test_result)

    callback

# Generated at 2022-06-25 08:55:25.247042
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    try:
        CallbackModule()
    except Exception:
        assert False
