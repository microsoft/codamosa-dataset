

# Generated at 2022-06-25 08:48:45.857361
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    # Test code here ..


# Generated at 2022-06-25 08:48:47.194870
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    pass

# Generated at 2022-06-25 08:48:50.401323
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
  callback_module = CallbackModule()
  result = {}
  callback_module.v2_runner_on_ok(result)


# Generated at 2022-06-25 08:48:56.963053
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result_0 = None
    try:
        callback_module_0.v2_runner_on_ok(result_0)
    except Exception:
        pass


# Generated at 2022-06-25 08:49:08.243386
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # test fixture
    callback_module_1 = CallbackModule()
    callback_module_1._display.verbosity = 1

    # test function

# Generated at 2022-06-25 08:49:09.589596
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = {}
    callback_module_0.v2_runner_on_failed(result_0)


# Generated at 2022-06-25 08:49:13.545298
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = object()
    ignore_errors_0 = object()
    callback_module_0.v2_runner_on_failed(result_0, ignore_errors_0)


# Generated at 2022-06-25 08:49:19.453490
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    fake_result_0 = FakeResult()
    callback_module_0.v2_runner_on_ok(fake_result_0)


# Generated at 2022-06-25 08:49:28.094156
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # See issue #29148
    from ansible.utils.vars import combine_vars
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager, TaskQueueManagerResult
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    import datetime

    host = Host(name="localhost")
    group = Group(name='ungrouped')
    group.add_host(host)
    inventory = Inventory(loader=None, variable_manager=None, host_list=[host])

# Generated at 2022-06-25 08:49:37.549567
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result_0 = dict()
    result_0['ansible_job_id'] = 'ansible_job_id'
    result_0['changed'] = False
    result_0['failed'] = False

    result_1 = dict()
    result_1['ansible_job_id'] = 'ansible_job_id'
    result_1['changed'] = True
    result_1['failed'] = False

    result_2 = dict()
    result_2['ansible_job_id'] = 'ansible_job_id'
    result_2['changed'] = False
    result_2['failed'] = True

    result_3 = dict()
    result_3['ansible_job_id'] = 'ansible_job_id'
    result_3['changed']

# Generated at 2022-06-25 08:49:52.581561
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    bytes_0 = b'r\xc1\x1f\x93\x92\x80\x9c\x81\xdf\xef\xf5,\xda\xa3\xab`\xb9\x99\xa1\x8b\xb7\xc4\xed\xc4\x8c\x91\x9d\xa4#\x93\xda\xaa\xc1>|\xb7\xd2\xab1\x9dO'
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_ok(bytes_0)


# Generated at 2022-06-25 08:49:54.429165
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_skipped(bytes_0)


# Generated at 2022-06-25 08:49:59.845250
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    bytes_0 = b'\xc6q\xf3j\xf3\xcf\xf2\xc6M\xe3\xff0\x1b\xf9'
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_skipped(bytes_0)
    var_1 = callback_module_0.v2_runner_on_skipped(bytes_0)


# Generated at 2022-06-25 08:50:04.385676
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()

    bytes_0 = b'\xc6q\xf3j\xf3\xcf\xf2\xc6M\xe3\xff0\x1b\xf9'
    ver = callback_v2_runner_on_skipped(bytes_0)

# Generated at 2022-06-25 08:50:08.362618
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    bytes_0 = b'\xc6q\xf3j\xf3\xcf\xf2\xc6M\xe3\xff0\x1b\xf9'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(bytes_0)


# Generated at 2022-06-25 08:50:18.323426
# Unit test for method v2_runner_on_failed of class CallbackModule

# Generated at 2022-06-25 08:50:24.637548
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    import sys
    import os
    import tempfile
    import shutil

    temp_dir = tempfile.mkdtemp()
    sys.path.insert(0, temp_dir)

# Generated at 2022-06-25 08:50:27.252169
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    bytes_0 = b'\xc6q\xf3j\xf3\xcf\xf2\xc6M\xe3\xff0\x1b\xf9'
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_skipped(bytes_0)


# Generated at 2022-06-25 08:50:28.518109
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert isinstance(callback_module_0, CallbackModule)


# Generated at 2022-06-25 08:50:30.770107
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    bytes_0 = b'\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00\x00'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(bytes_0)


# Generated at 2022-06-25 08:50:41.141758
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    call_back_module_object = CallbackModule()
    call_back_module_object.v2_runner_on_ok(result="dummy result")


# Generated at 2022-06-25 08:50:45.557670
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    cb = CallbackModule()
    # FIXME:
    # cb.v2_runner_on_failed()
    assert(True)

# Generated at 2022-06-25 08:50:49.618591
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    try:
        assert CallbackModule()
        assert CallbackModule() and True
    except:
        assert False


# Generated at 2022-06-25 08:51:00.744768
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_0 = CallbackModule()

# Generated at 2022-06-25 08:51:10.252710
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    arg_0 = CallbackModule()
    arg_1 = DummyResult()
    # arg_1 contains dummy attributes for '_result', '_host', '_task'
    arg_1._result = {'exception': ''}
    arg_1._host = DummyHost()
    arg_1._task = DummyTask()
    arg_2 = False

    # Call the tested method
    callback_module_0 = arg_0
    var_0 = callback_module_0.v2_runner_on_failed(arg_1, arg_2)

    var_1 = arg_1._result.get('exception')




# Generated at 2022-06-25 08:51:10.710808
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    CallbackModule()

# Generated at 2022-06-25 08:51:13.301249
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    bytes_0 = b'\xc6q\xf3j\xf3\xcf\xf2\xc6M\xe3\xff0\x1b\xf9'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(bytes_0)


# Generated at 2022-06-25 08:51:15.780229
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
	# Creating a dummy object of class 'CallbackModule' with no arguments
	callback_module_0 = CallbackModule()
	# Creating a dummy object of class '_Result' with no arguments
	_result_0 = _Result()
	# Calling the method 'v2_runner_on_failed' of class 'CallbackModule' with actual arguments
	callback_module_0.v2_runner_on_failed(_result_0)



# Generated at 2022-06-25 08:51:17.533554
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    assert isinstance(var_0, str)


# Generated at 2022-06-25 08:51:22.258075
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    bytes_0 = b'\xc6q\xf3j\xf3\xcf\xf2\xc6M\xe3\xff0\x1b\xf9'
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(bytes_0)


# Generated at 2022-06-25 08:51:40.919912
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    bytes_0 = b'(\xcd\x89\xfe\x10\x9f5\xcc\xaa\x01(l\x8c\x18\xb3'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(bytes_0)


# Generated at 2022-06-25 08:51:47.560058
# Unit test for method v2_runner_on_failed of class CallbackModule

# Generated at 2022-06-25 08:51:51.986321
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    bytes_0 = b'\xc6q\xf3j\xf3\xcf\xf2\xc6M\xe3\xff0\x1b\xf9'
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_ok(bytes_0)


# Generated at 2022-06-25 08:51:56.416820
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    bytes_0 = b'\xf7\xa6\xad'
    callback_module_0 = CallbackModule()
    assert callback_module_0
    var_0 = callback_v2_runner_on_skipped(bytes_0)


# Generated at 2022-06-25 08:51:57.724005
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    pytest.skip('Test Not Implemented')


# Generated at 2022-06-25 08:52:04.204851
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module = CallbackModule()
    # I want to test the line callback_module.v2_runner_on_failed(result, ignore_errors=False)
    # Unfortunately the code to create result is not available to me.
    # I need to mock the result.
    # But what should result be?
    # How can I write a unit test for this?


# Generated at 2022-06-25 08:52:05.673906
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed()


# Generated at 2022-06-25 08:52:11.414486
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    bytes_0 = b'\xc6q\xf3j\xf3\xcf\xf2\xc6M\xe3\xff0\x1b\xf9'
    callback_module_0 = CallbackModule()
    var_0 = test_case_0(bytes_0)

# Generated at 2022-06-25 08:52:12.094506
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()


# Generated at 2022-06-25 08:52:14.829279
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    bytes_0 = b'\xc6q\xf3j\xf3\xcf\xf2\xc6M\xe3\xff0\x1b\xf9'
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(bytes_0)


# Generated at 2022-06-25 08:52:54.964798
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()

    bytes_0 = b'\x89\x01\x9c\xe5\x0e\x97\x82\xec\x8e\x04\x10\xb5\x95'
    var_0 = callback_v2_runner_on_failed(bytes_0)


# Generated at 2022-06-25 08:52:58.641286
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    bytes_1 = b'\xaa\xec\x86\xb8\x82\x15\xad\x14\xb6\x1a\xeb\x0f\x05\x8b\x91\x17'
    callback_module_1 = CallbackModule()
    var_1 = callback_v2_runner_on_ok(callback_module_1, bytes_1)


# Generated at 2022-06-25 08:53:01.419073
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    bytes_1 = b'\xc6q\xf3j\xf3\xcf\xf2\xc6M\xe3\xff0\x1b\xf9'
    class_0 = CallbackModule()
    var_0 = callback_v2_runner_on_skipped(bytes_1)

if __name__ == "__main__":
    test_case_0()
    test_CallbackModule()

# Generated at 2022-06-25 08:53:05.521348
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Test setup
    bytes_0 = b'\xc6q\xf3j\xf3\xcf\xf2\xc6M\xe3\xff0\x1b\xf9'
    callb

# Generated at 2022-06-25 08:53:08.785004
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    result_0 = CallbackModule()
    result_0._display.verbosity = 2
    result_0._display.display('Hello', 'error')
    result_0.v2_runner_on_failed(result_0._result)


# Generated at 2022-06-25 08:53:12.234589
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    bytes_0 = b'\xc6q\xf3j\xf3\xcf\xf2\xc6M\xe3\xff0\x1b\xf9'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(bytes_0)
test_CallbackModule_v2_runner_on_ok()


# Generated at 2022-06-25 08:53:14.357859
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed()


# Generated at 2022-06-25 08:53:17.734731
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    result_0 = Result()
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(result_0)


# Generated at 2022-06-25 08:53:26.692798
# Unit test for method v2_runner_on_failed of class CallbackModule

# Generated at 2022-06-25 08:53:31.407580
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    bytes_0 = b'W\xdc\x02\x00\x00\x00\x00\x00\x00\xff\xff\xff\xff\xff\xff\xff\xff'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(bytes_0)


# Generated at 2022-06-25 08:55:13.558712
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    string_0 = fdopen(int_0)
    result_0 = callback_module_0.v2_runner_on_ok(string_0)


# Generated at 2022-06-25 08:55:14.287432
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()

# Generated at 2022-06-25 08:55:20.206813
# Unit test for method v2_runner_on_ok of class CallbackModule

# Generated at 2022-06-25 08:55:27.056924
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    bytes_0 = b'\xc6q\xf3j\xf3\xcf\xf2\xc6M\xe3\xff0\x1b\xf9'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(bytes_0)
    assert var_0 == (b'/\xaa\xaf\xdd\xae\xbb\xc0\xea\xb9\x97\xf5\x87\xfb\xd8\x91]\xa0\xc4\xcf\xf4\xba\xa4\xdb',)

if __name__ == '__main__':
    test_CallbackModule_v2_runner_on_failed()
    test_case_0()

# Generated at 2022-06-25 08:55:31.393674
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Testing object of type CallbackModule
    callback_module_0 = CallbackModule()
    # Testing method v2_runner_on_ok of class CallbackModule
    var_1 = callback_module_0.v2_runner_on_ok(result_0)


# Generated at 2022-06-25 08:55:32.378466
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    assert 0


# Generated at 2022-06-25 08:55:35.304675
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    bytes_0 = b'\x1e\x17)\x0e\xfa\x8b\xb6\x10\x15\x1f\x8c\x0b'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(bytes_0)


# Generated at 2022-06-25 08:55:38.648611
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    bytes_0 = b'\xca\xaaP\x9f\xb1\x9d\xad\x93\xb3\xbb\x83\xdc\xd7\x9aM\x9b'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_skipped(bytes_0)

if __name__ == "__main__":
    test_CallbackModule()

# Generated at 2022-06-25 08:55:48.778251
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():

    # Redefine this function locally
    def v2_runner_on_failed(self, result, ignore_errors=False):

        # Check the type of 'result' (should be Result)
        if not isinstance(result, Result):
            raise TypeError(
                "Expected type Result for 'result', but got %s" % type(result))

        # Check the type of 'ignore_errors' (should be bool or None)
        if not isinstance(ignore_errors, (bool, type(None))):
            raise TypeError(
                "Expected type bool or None for 'ignore_errors', but got %s" % type(ignore_errors))

    # Invoke the method
    result = v2_runner_on_failed()

    # Check the type returned
    if(not isinstance(result, None)):
        raise TypeError

# Generated at 2022-06-25 08:55:52.342516
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    bytes_0 = b'\xc6q\xf3j\xf3\xcf\xf2\xc6M\xe3\xff0\x1b\xf9'
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_ok(bytes_0)