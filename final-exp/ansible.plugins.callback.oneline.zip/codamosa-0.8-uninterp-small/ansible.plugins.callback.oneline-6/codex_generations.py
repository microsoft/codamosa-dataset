

# Generated at 2022-06-25 08:48:52.762539
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result = {'invocation': {'module_name': 'command', 'module_args': 'echo hello'}, 'module_name': 'command', 'module_args': 'echo hello', 'ansible_job_id': '1569137065.487892'}
    callback_module_0.v2_runner_on_failed(result)


# Generated at 2022-06-25 08:48:57.066629
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module = CallbackModule()
    assert callback_module.CALLBACK_VERSION == 2.0
    assert callback_module.CALLBACK_TYPE == 'stdout'
    assert callback_module.CALLBACK_NAME == 'oneline'

# Generated at 2022-06-25 08:49:00.139352
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    print('test_CallbackModule:')
    test_case_0()
    print('test_CallbackModule Success')
    print('===============================================================')

# Execute the unit test, by calling the method test_CallbackModule
test_CallbackModule()

# Generated at 2022-06-25 08:49:07.379983
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_2 = CallbackModule()
    result = {"ansible_job_id" : "27217.20", "changed" : True, "rc" : 0, "results" : "file.txt"}
    expected_output = "27217.20 | SUCCESS => {\"ansible_job_id\": \"27217.20\", \"changed\": true, \"rc\": 0, \"results\": \"file.txt\"}"
    _result = callback_module_2.v2_runner_on_ok(result)
    assert(expected_output == _result)


# Generated at 2022-06-25 08:49:11.591767
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert callable(CallbackModule)

# Generated at 2022-06-25 08:49:18.222519
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_1 = CallbackModule()
    assert callback_module_1.CALLBACK_VERSION == 2.0
    assert callback_module_1.CALLBACK_TYPE == 'stdout'
    assert callback_module_1.CALLBACK_NAME == 'oneline'

# Generated at 2022-06-25 08:49:27.001263
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    result_0 = {}

# Generated at 2022-06-25 08:49:31.978810
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback = CallbackModule()

    result = {}
    # v2_runner_on_failed receives a result parameter
    callback.v2_runner_on_failed(result=result)


# Generated at 2022-06-25 08:49:33.132954
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()



# Generated at 2022-06-25 08:49:39.945682
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module = CallbackModule()

    class Result:
        def __init__(self, result, host):
            self._result = result
            self._host = host

    class Host:
        def __init__(self, name):
            self._name = name

        def get_name(self):
            return self._name

    result = Result(
        {
            "changed": True
        },
        Host("host_name")
    )

    result2 = Result(
        {
            "changed": False
        },
        Host("host_name")
    )

    callback_module.v2_runner_on_ok(result)
    callback_module.v2_runner_on_ok(result2)


# Generated at 2022-06-25 08:49:54.192850
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # input
    callback_module_1 = CallbackModule()

# Generated at 2022-06-25 08:50:02.511313
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    args_dict = dict()
    args_dict['_task'] = dict()
    args_dict['_task']['action'] = 'setup'
    args_dict['_result'] = dict()
    args_dict['_result']['changed'] = False
    args_dict['_host'] = dict()
    args_dict['_host']['get_name'] = 'host_name'
    args_dict['_host']['_result'] = dict()
    args_dict['_host']['_result']['ansible_facts'] = dict()
    args_dict['_host']['_result']['ansible_facts']['ansible_memtotal_mb'] = '1024'
    callback_module_1 = CallbackModule()
    callback_module_1.v2_runner_on_

# Generated at 2022-06-25 08:50:12.070374
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    mock_display = MockDisplay()
    mock_result = MockResult()
    callback_module_0 = CallbackModule()
    callback_module_0.set_options({u'verbosity': 0})
    callback_module_0.set_runner(MockRunner())
    callback_module_0.set_task(MockTask())
    callback_module_0.set_play(MockPlay())
    callback_module_0.set_playbook(MockPlaybook())
    callback_module_0.set_loader(MockModuleLoader())
    callback_module_0.set_task_queue_manager(MockTaskQueueManager())
    callback_module_0.set_variable_manager(MockVariableManager())
    callback_module_0._display = mock_display
    mock_result.task_action = u'ping'

# Generated at 2022-06-25 08:50:13.224610
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    test_case_0.v2_runner_on_failed()


# Generated at 2022-06-25 08:50:17.400921
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result_0 = {'unreachable': True, 'stdout_lines': [], 'stdout': '', 'rc': 0}
    callback_module_0.v2_runner_on_ok(result_0)


# Generated at 2022-06-25 08:50:20.203565
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    result_1 = None
    ignore_errors_1 = False
    callback_module_1.v2_runner_on_failed(result_1, ignore_errors_1)


# Generated at 2022-06-25 08:50:22.415434
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_2 = CallbackModule()
    result = {}
    callback_module_2.v2_runner_on_failed(result)


# Generated at 2022-06-25 08:50:28.744486
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    result_0 = object()
    callback_module_0 = CallbackModule()
    callback_module_0._display = object()
    try:
        callback_module_0.v2_runner_on_ok(result_0)
    except TypeError:
        pass



# Generated at 2022-06-25 08:50:38.078281
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

    # Test target 1
    test_target_1 = {
        'stdout_lines': [
            'a',
            'b'
        ],
        'warnings': ['msg1'],
        'deprecations': ['msg2'],
        'changed': True,
        '_ansible_parsed': True,
        '_ansible_ignore_errors': True,
        '_ansible_no_log': True,
        '_ansible_verbose_always': True,
        '_ansible_warnings': [
            {'msg1': 'msg1'}
        ],
        '_ansible_deprecations': [
            {'msg2': 'msg2'}
        ]
    }

    class TestHost:
        def get_name(self):
            return 'testhost'

   

# Generated at 2022-06-25 08:50:40.417651
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result = "result"

    # Test module input parameters
    assert '_result' in result


# Generated at 2022-06-25 08:50:58.937758
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    import sys
    import __builtin__
    callback_module_1 = CallbackModule()
    result_1 = FakeResult(host=FakeHost())
    result_1._result = {'changed': False}
    result_1._task = FakeTask(action="ping")
    # test case with fails=False
    setattr(__builtin__, '__builtins__', {'open': open, 'setattr': setattr, 'getattr': getattr})
    try:
        callback_module_1.v2_runner_on_ok(result_1)
    except TypeError as e:
        print(e)
    except AttributeError as e:
        print(e)
    result_1._result = {'changed': True}
    result_1._task = FakeTask(action="ping")
    # test case with

# Generated at 2022-06-25 08:51:00.106934
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert callable(CallbackModule)

# Generated at 2022-06-25 08:51:05.314788
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Arrange
    result_0 = Mock()
    ignore_errors_0 = False

    callback_module_0 = CallbackModule()

    # Act
    callback_module_0.v2_runner_on_failed(result_0, ignore_errors_0)

    # Assert
    assert callback_module_0 == callback_module_0


# Generated at 2022-06-25 08:51:08.405331
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result_0 = V2_RUNNER_RESULT_0
    callback_module_0.v2_runner_on_ok(result_0)


# Generated at 2022-06-25 08:51:14.330655
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback = CallbackModule()
    assert hasattr(callback, 'v2_runner_on_failed')

# Generated at 2022-06-25 08:51:15.827680
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:51:18.613143
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module = CallbackModule()
    assert callback_module.v2_runner_on_ok('ok') == None

# Generated at 2022-06-25 08:51:27.391897
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result_0 = dict()
    result_0['_result.get'] = (lambda key, default=None: default)
    result_0['_result'] = dict()
    result_0['_result']['changed'] = (
        lambda: False
    )
    result_0['_host'] = dict()
    result_0['_host']['get_name'] = (lambda: 'test')
    result_0['_task'] = dict()
    result_0['_task']['action'] = 'test'
    callback_module_0.v2_runner_on_ok(result_0)

# Generated at 2022-06-25 08:51:29.526802
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    """
    Constructor of class CallbackModule
    """
    callback_module_0 = CallbackModule()
    assert(isinstance(callback_module_0, CallbackModule))


# Generated at 2022-06-25 08:51:34.307673
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    color = C.COLOR_OK
    callback_module_0 = CallbackModule()
    assert callback_module_0.v2_runner_on_ok(result) == print(result, color='\x1b[0;32m')


# Generated at 2022-06-25 08:51:54.419021
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module = CallbackModule()
    result = callback_module.v2_runner_on_failed()


# Generated at 2022-06-25 08:52:05.155032
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    result0 = {'stdout': 'stdout0'}
    ignore_errors0 = False
    callback_module_0 = CallbackModule()
    callback_module_0.result = result0
    callback_module_0.verbosity = 2

    # Test with 'exception' in result._result
    result0['exception'] = 'exception0'
    callback_module_0.v2_runner_on_failed(result0, ignore_errors0)
    assert callback_module_0.display_msg == 'An exception occurred during task execution. To see the full traceback, use -vvv. The error was: exception0'

    # Test with 'exception' not in result._result
    result0.pop('exception')

# Generated at 2022-06-25 08:52:11.220335
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    result_1 = None
    ignore_errors_1 = False
    callback_module_1.v2_runner_on_failed(result_1, ignore_errors_1)


# Generated at 2022-06-25 08:52:20.028428
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module = CallbackModule()
    task = dict()
    task['_host'] = dict()
    task['_host']['get_name'] = "test_name"
    task['_result'] = dict()
    task['_result']['_result'] = dict()
    task['_result']['_result']['exception'] = "exception_test"
    try:
        callback_module.v2_runner_on_failed(task)
    except SystemExit:
        pass


# Generated at 2022-06-25 08:52:25.587592
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module = CallbackModule()
    assert callback_module.CALLBACK_VERSION == 2.0
    assert callback_module.CALLBACK_TYPE == 'stdout'
    assert callback_module.CALLBACK_NAME == 'oneline'

# Test case for class method _command_generic_msg

# Generated at 2022-06-25 08:52:31.799542
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    try:
        # test_case_0
        test_case_0()
    except Exception as err:
        print("Caught exception: "  + repr(err))

# Unit test when the file is run as the main program
if __name__ == '__main__':
    test_CallbackModule()

# Generated at 2022-06-25 08:52:36.480241
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    test_case_0()

# Generated at 2022-06-25 08:52:42.740161
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result_0 = {}
    test_case_0()
    try:
        callback_module_0.v2_runner_on_ok(result_0)
    except Exception as exception:
        print('Exception: ', exception)


# Generated at 2022-06-25 08:52:49.560872
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    import time
    import copy
    result_0 = copy.deepcopy(result)
    result_0["created"] = False
    result_0["invocation"]["module_args"]["command"] = "ls -al"
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_ok(result_0)


# Generated at 2022-06-25 08:52:50.677060
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_1 = CallbackModule()


# Generated at 2022-06-25 08:53:31.304412
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module = CallbackModule()

# Generated at 2022-06-25 08:53:32.485285
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_test = CallbackModule()
    assert callback_module_test != None


# Generated at 2022-06-25 08:53:35.111621
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module = CallbackModule()
    task = None
    result = None
    callback_module.v2_runner_on_ok(result)


# Generated at 2022-06-25 08:53:38.496857
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Initialize the callback module
    callback_module_1 = CallbackModule()
    # Create an Ansible Result object
    ansible_result_obj_0 = AnsibleResult("ansible_task_name", "ansible_task_action", True, {"changed": False})
    callback_module_1.v2_runner_on_ok(ansible_result_obj_0)


# Generated at 2022-06-25 08:53:48.222386
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()

# Generated at 2022-06-25 08:53:57.069017
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert callback_module_0._dump_results(result=None, indent=0) is None
    assert callback_module_0._command_generic_msg(hostname="localhost", result=None, caption="localhost") == "localhost | localhost | rc=-1 | (stdout)  (null)"
    assert callback_module_0.v2_runner_on_failed(result=None, ignore_errors=False) is None
    assert callback_module_0.v2_runner_on_ok(result=None) is None
    assert callback_module_0.v2_runner_on_unreachable(result=None) is None
    assert callback_module_0.v2_runner_on_skipped(result=None) is None



# Generated at 2022-06-25 08:53:59.324121
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()

    print('TEST: method v2_runner_on_failed')
    print('NOT IMPLEMENTED YET')


# Generated at 2022-06-25 08:54:03.471701
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_1 = CallbackModule()
    callback_module_1.v2_runner_on_ok(result1)


# Generated at 2022-06-25 08:54:04.107602
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    test_case_0()

# Generated at 2022-06-25 08:54:05.615901
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module = CallbackModule()
    result = False
    result = callback_module.v2_runner_on_ok(result)
    print(result)


# Generated at 2022-06-25 08:55:40.798773
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert callback_module_0 is not None


# Generated at 2022-06-25 08:55:42.856515
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_1 = CallbackModule()
    assert callback_module_1.CALLBACK_VERSION == 2.0
    assert callback_module_1.CALLBACK_TYPE == 'stdout'
    assert callback_module_1.CALLBACK_NAME == 'oneline'


# Generated at 2022-06-25 08:55:46.564010
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    call_module_0 = CallbackModule()
    # test for valid case
    result_0 = dict(changed=True)
    call_module_0.v2_runner_on_ok(result_0)
    # test for invalid case
    result_1 = dict(changed=False)
    call_module_0.v2_runner_on_ok(result_1)


# Generated at 2022-06-25 08:55:53.889125
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Test that the output is the string 'An exception occurred during task execution'
    # and that the string 'The full traceback is:' does not appear in the output.
    # Assuming we are using the Color Display
    callback_module_0 = CallbackModule()
    # Run the v2_runner_on_failed method of the CallbackModule class.
    callback_module_0.v2_runner_on_failed(result=None, ignore_errors=None)

test_case_0()
test_CallbackModule_v2_runner_on_failed()

# Tests for method v2_runner_on_ok of class CallbackModule

# Generated at 2022-06-25 08:55:56.553067
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert callback_module_0._plugin_type == 'notify'
    assert callback_module_0._plugin_name == 'oneline'



# Generated at 2022-06-25 08:55:58.494303
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed(result='result_0', ignore_errors='ignore_errors_0')


# Generated at 2022-06-25 08:56:00.363668
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module = CallbackModule()
    callback_module.v2_runner_on_ok(1)


# Generated at 2022-06-25 08:56:03.383084
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    test_case_0()

# Generated at 2022-06-25 08:56:07.081871
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Test scenario:
    # 1. ret = '{u'changed': True}'
    # 2. Task result is 'changed'
    # 3. task.action = 'command'
    # Result: {'changed': True, 'invocation': {'module_args': 'command'}}
    result = dict(changed=True)
    result = dict(result=result)
    task = dict(action='command')
    result = dict(_result=result, _task=task)
    result = dict(_host=None, _result=result, _task=task)
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_ok(result)



# Generated at 2022-06-25 08:56:09.377279
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # Constructor test
    # Input parameters:
    #   self - Instance of the class CallbackModule
    # Output:
    #   none
    result = CallbackModule()
    assert (result is not None)
