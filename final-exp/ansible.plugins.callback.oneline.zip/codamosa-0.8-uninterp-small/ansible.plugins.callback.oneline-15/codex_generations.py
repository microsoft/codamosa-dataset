

# Generated at 2022-06-25 08:48:51.767939
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase

    callback_base_0 = CallbackBase()

    class FakeRunnerResult:
        def __init__(self):
            self.fake_runner_result_host = FakeRunnerResultHost()
            self.fake_runner_result_task = FakeRunnerResultTask()
            self.fake_runner_result_result = FakeRunnerResultResult()
            self.fake_runner_result_host_name = ""
            self.fake_runner_result_state = ""
            self.fake_runner_result_color = 0

        def get_name(self):
            self.fake_runner_result_host_name = "fake_runner_result_host_name"
            return self.fake_runner_result_host_name

        def get_task(self):
            self.fake_runner_result_

# Generated at 2022-06-25 08:48:52.528805
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert not bool('')

# Generated at 2022-06-25 08:48:56.480998
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result = CallbackModule()
    callback_module_0.v2_runner_on_ok(result)


# Generated at 2022-06-25 08:49:08.220076
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module = CallbackModule()
    class Result():
        pass
    result = Result()
    class result_host():
        def get_name(self):
            return "hostname-1"
    class result_task():
        def get_action(self):
            return "action-1"
    class result_display():
        def display(self, msg, color=None):
            print(msg)
    class result_dump_results():
        def dump_results(self, result_result, indent=0):
            return "dump-results-1"
    result._host = result_host()
    result._task = result_task()
    result._result = {}
    result._result['changed'] = False
    callback_module._display = result_display()
    callback_module._dump_results = result_dump_results()

# Generated at 2022-06-25 08:49:16.043725
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = {}
    with mock.patch.object(CallbackModule, '_display', mock.MagicMock()) as mock_display:
        with mock.patch.object(CallbackModule, '_dump_results', mock.MagicMock(return_value='frozen delights')) as mock__dump_results:
            callback_module_0.v2_runner_on_failed(result_0)
    mock_display.assert_called_with('| FAILED! => frozen delights', color='dark red')


# Generated at 2022-06-25 08:49:25.749216
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_1 = CallbackModule()

    result_1 = dict()
    result_1['changed'] = False
    result_1['_ansible_verbose_always'] = True
    result_1['_ansible_no_log'] = False
    result_1['_ansible_syslog_facility'] = 'LOG_USER'
    result_1['_ansible_selinux_special_fs'] = None
    result_1['ansible_product_name'] = 'Red Hat Enterprise Linux Server'
    result_1['_ansible_check_mode'] = False

# Generated at 2022-06-25 08:49:32.380897
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    my_callback_module = CallbackModule()
    # Setting the values for the needed parameters to test the method
    # This is for the case when exception is not present in the result object
    result_object = {"changed": True}
    ignore_errors = True
    my_callback_module.v2_runner_on_failed(result_object, ignore_errors)



# Generated at 2022-06-25 08:49:36.471064
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    test_case_0()

if __name__ == '__main__':
    print(test_CallbackModule.__doc__)
    test_CallbackModule()
    print("Done.")

# Generated at 2022-06-25 08:49:38.940630
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    try:
        test_case_0()
        return 0
    except IOError:
        return 1


# Generated at 2022-06-25 08:49:40.381944
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    result = dict()
    callback_module_1.v2_runner_on_failed(result)


# Generated at 2022-06-25 08:49:46.408495
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

    # No return value
    assert callback_module_0.v2_runner_on_ok() == None


# Generated at 2022-06-25 08:49:47.642501
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()



# Generated at 2022-06-25 08:49:52.044736
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    e = CallbackModule()
    result = FakeResult()
    result._result = {'exception': 'An exception occurred'}
    result._task = FakeTask('FAILED')
    result._host = FakeHost()
    e.v2_runner_on_failed(result)


# Generated at 2022-06-25 08:49:55.672639
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    """
    Check that method v2_runner_on_failed
    """
    callback_module = CallbackModule()
    result = {}
    result['exception'] = "Execution of '/usr/bin/dnf -d 0 -e 0 -y install python2' returned 1: Error: Unable to find a match"
    result['rc'] = 1
    callback_module.v2_runner_on_failed(result, False)

# Generated at 2022-06-25 08:50:01.898109
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = ansible_result( )
    ansible_task_0 = ansible_task_result( )
    result_0.action = ""
    result_0.task = ansible_task_0
    result_0.error = ""
    result_0.changed = False
    result_0.host = ""
    result_0.task_args = ""
    result_0.task_action = ""
    result_0.item = ""
    callback_module_0.v2_runner_on_failed(result_0)


# Generated at 2022-06-25 08:50:11.766820
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    result = dict()
    result['ansible_job_id'] = '5'
    result['changed'] = False
    result['cmd'] = 'date'
    result['delta'] = '0:00:00.022397'
    result['end'] = '2017-08-14 23:00:01.138951'
    result['invocation'] = dict()
    result['invocation']['module_args'] = dict()
    result['invocation']['module_args']['format'] = '%Y-%m-%d %H:%M:%S.%f'
    result['invocation']['module_args']['utc'] = False
    result['invocation']['module_args']['_uses_shell'] = True

# Generated at 2022-06-25 08:50:12.903519
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create an instance of class CallbackModule
    callback_module_0 = CallbackModule()

# Generated at 2022-06-25 08:50:17.362567
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_1 = CallbackModule()
    assert callback_module_1.CALLBACK_VERSION == 2.0
    assert callback_module_1.CALLBACK_TYPE == 'stdout'
    assert callback_module_1.CALLBACK_NAME == 'oneline'



# Generated at 2022-06-25 08:50:18.505232
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:50:22.467933
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module = CallbackModule()
    result_0 = 'result_0'

    #Test case with an Exception
    with pytest.raises(Exception):
        callback_module.v2_runner_on_failed(result_0)


# Generated at 2022-06-25 08:50:34.647021
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = { 'exception': 'exception' }
    ignore_errors_0 = False
    callback_module_0.v2_runner_on_failed(result_0, ignore_errors_0)


# Generated at 2022-06-25 08:50:35.998653
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:50:38.953318
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:50:41.178697
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    print("Begin test_CallbackModule")
    callback_module_0 = CallbackModule()
    print("End test_CallbackModule")
    print("")


# Generated at 2022-06-25 08:50:44.815542
# Unit test for constructor of class CallbackModule
def test_CallbackModule():

    test_case_0()

#
## Run unit tests
#

# Generated at 2022-06-25 08:50:53.397972
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

    class TestCase(object):
        def __init__(self):
            self.task_action = None
            self.task_name = None
            self.host_name = None
            self.result = None
            self.color = None
            self.state = None

    # Task action is in C.MODULE_NO_JSON and result doesn't contain module_stderr
    test_case = TestCase()
    test_case.task_action = "command"
    test_case.task_name = "test_task"
    test_case.host_name = "test_host"
    test_case.result = {"stdout": "test_stdout"}
    test_case.state = "SUCCESS"

    callback_module_1 = CallbackModule()

    callback_module_1._display.verbosity = 2


# Generated at 2022-06-25 08:50:57.793180
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Setup
    callback_module_1 = CallbackModule()
    result = object()
    ignore_errors = True

    # Test
    callback_module_1.v2_runner_on_failed(result, ignore_errors)



# Generated at 2022-06-25 08:51:00.852945
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result_0 = None
    callback_module_0.v2_runner_on_ok(result_0)


# Generated at 2022-06-25 08:51:05.119556
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    assert callback_module_0.v2_runner_on_failed == CallbackBase.v2_runner_on_failed

# Generated at 2022-06-25 08:51:08.630228
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = object()
    ignore_errors_0 = True
    callback_module_0.v2_runner_on_failed(result_0, ignore_errors_0)


# Generated at 2022-06-25 08:51:19.802772
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = 'Your test here'
    assert(1 == 1)




# Generated at 2022-06-25 08:51:22.181103
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = '\\'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(str_0)


# Generated at 2022-06-25 08:51:26.923891
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    print('')
    for i in range(2):
        str_0 = ["\n", "\n"]
        str_1 = str_0[i]
        callback_module_1 = CallbackModule()
        var_1 = callback_module_1.v2_runner_on_ok(str_1)


# Generated at 2022-06-25 08:51:27.792883
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    assert True



# Generated at 2022-06-25 08:51:39.784668
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    str_0 = ''
    str_1 = '%s | %s => %s'
    str_2 = '%s | UNREACHABLE!: %s'
    str_3 = '%s | SKIPPED'
    str_4 = '%s | %s | rc=%s | (stdout) %s'
    str_5 = '%s | %s | rc=%s | (stdout) %s (stderr) %s'
    str_6 = ''
    str_7 = '%s | FAILED! => %s'
    str_8 = 'An exception occurred during task execution. The full traceback is:\n'
    str_9 = 'An exception occurred during task execution. To see the full traceback, use -vvv. The error was: %s'
    str_10 = ''


# Generated at 2022-06-25 08:51:42.275446
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = ''
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(str_0)


# Generated at 2022-06-25 08:51:46.487735
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    Result = 'Result'
    callback_module_0 = CallbackModule()
    callback_module_1 = callback_module_0.v2_runner_on_failed(Result)


# Generated at 2022-06-25 08:51:50.798511
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    name_0 = 'oneline'
    str_0 = 'stdout'
    float_0 = 2.0
    callback_module_0 = CallbackModule()
    assert callback_module_0.name == name_0
    assert callback_module_0.type == str_0
    assert callback_module_0.version == float_0
    

# Generated at 2022-06-25 08:51:57.481054
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    str_0 = ''
    var_0 = callback_module_0.v2_runner_on_ok(str_0)
    str_0 = ''
    var_0 = callback_module_0.v2_runner_on_skipped(str_0)
    str_0 = ''
    var_0 = callback_module_0.v2_runner_on_failed(str_0)


# Generated at 2022-06-25 08:52:02.099163
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = ''
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(str_0)


# Generated at 2022-06-25 08:52:22.068150
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    assert True == True

# Generated at 2022-06-25 08:52:23.549476
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module = CallbackModule()
    assert isinstance(callback_module, CallbackModule)


# Generated at 2022-06-25 08:52:27.134548
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Input parameters
    result = str()

    # Expected return value(s)
    # No return value expected

    pass


# Generated at 2022-06-25 08:52:27.757294
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    pass


# Generated at 2022-06-25 08:52:31.460790
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    c = CallbackModule


# Generated at 2022-06-25 08:52:36.827136
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()



# Generated at 2022-06-25 08:52:41.973208
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    def v2_runner_on_ok_mock(self, result):
        assert isinstance(result, ResultCallback)

    return v2_runner_on_ok_mock


# Generated at 2022-06-25 08:52:48.076611
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    assert 'An exception occurred during task execution. To see the full traceback, use -vvv. The error was: e' in callback_module_0.v2_runner_on_failed(var_0, false)


# Generated at 2022-06-25 08:52:53.447053
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = ''
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(str_0)


# Generated at 2022-06-25 08:52:57.477409
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    var_0 = CallbackModule()
    assert var_0 != None

# Generated at 2022-06-25 08:53:36.013236
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    print('Unit test for method v2_runner_on_failed of class CallbackModule')
    

# Generated at 2022-06-25 08:53:36.688015
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule().__class__ == CallbackModule

# Generated at 2022-06-25 08:53:38.122904
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_1 = CallbackModule()
    var_1 = callback_module_1.v2_runner_on_ok()


# Generated at 2022-06-25 08:53:40.500327
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    str_0 = ''
    callback_module_0 = CallbackModule()



# Generated at 2022-06-25 08:53:41.313445
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    assert True, "Not implemented"


# Generated at 2022-06-25 08:53:44.830285
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    obj0 = CallbackModule()
    str0 = ''
    obj0.v2_runner_on_failed(var0, var1)


# Generated at 2022-06-25 08:53:46.860682
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    str_0 = ''
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(str_0)


# Generated at 2022-06-25 08:53:50.763846
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    var_0 = CallbackModule.v2_runner_on_ok(self, str_0)


# Generated at 2022-06-25 08:53:55.604931
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()


# Generated at 2022-06-25 08:53:58.778924
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    result_1 = object()
    ignore_errors_1 = True
    var_1 = callback_module_1.v2_runner_on_failed(result_1, ignore_errors_1)


# Generated at 2022-06-25 08:55:52.970037
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = 'A'
    bool_0 = bool('A')
    dict_0 = dict()
    dict_0['a'] = 'a'
    dict_0['b'] = False
    dict_0['c'] = 'c'
    dict_1 = dict()
    dict_1['exception'] = dict_0
    dict_1['b'] = bool_0
    dict_1['c'] = 'c'
    dict_2 = dict()
    dict_2['_result'] = dict_1
    dict_2['action'] = 'action'
    dict_2['_host'] = dict_1
    dict_2['_task'] = dict_2
    dict_2['verbosity'] = int(1)
    callback_module_0 = CallbackModule()
    var_0 = callback_module

# Generated at 2022-06-25 08:55:55.745605
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = ''
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(str_0)


# Generated at 2022-06-25 08:56:07.520660
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Setup test case
    light_blue = '\033[94m'
    reset_color = '\033[0m'
    str_0 = "ok"
    callback_module_0 = CallbackModule() # default object of CallbackModule
    
    # Generate expected output via the hook method
    expected_str_0 = callback_module_0.v2_runner_on_failed(str_0)
    
    # Run hook method and compare output to expected output
    actual_str_0 = callback_module_0.v2_runner_on_failed(str_0)
    #assert(actual_str_0 == expected_str_0)
    
    # Check that the reset_color occurs at end of actual_str_0
    assert(actual_str_0.endswith(reset_color))
    
   

# Generated at 2022-06-25 08:56:09.801322
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # Classic
    callback_module = CallbackModule()
    assert callback_module.CALLBACK_VERSION == 2.0
    assert callback_module.CALLBACK_TYPE == 'stdout'
    assert callback_module.CALLBACK_NAME == 'oneline'



# Generated at 2022-06-25 08:56:17.562530
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    str_0 = 'skipped'
    str_1 = 'unreachable'
    str_2 = 'ok'
    str_3 = 'changed'
    str_4 = 'failed'
    str_5 = 'skipped'
    str_6 = 'ok'
    str_7 = 'changed'
    str_8 = 'failed'
    str_9 = 'ok'
    str_10 = 'changed'
    str_11 = 'failed'
    str_12 = 'skipped'
    str_13 = 'ok'
    str_14 = 'changed'
    str_15 = 'failed'
    str_16 = 'skipped'
    str_17 = 'ok'
    str_18 = 'changed'
    str_19 = 'failed'
    str_20 = 'skipped'
    str_

# Generated at 2022-06-25 08:56:19.351339
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    test_case_0()

# Generated at 2022-06-25 08:56:21.864161
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    str_0 = ''
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(str_0)


# Generated at 2022-06-25 08:56:22.321734
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    assert True

# Generated at 2022-06-25 08:56:23.751340
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    class_instance_CallbackModule = CallbackModule()
    assert isinstance(class_instance_CallbackModule, CallbackModule)


# Generated at 2022-06-25 08:56:25.945731
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = ''
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(str_0)
