

# Generated at 2022-06-25 08:48:50.108079
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed(result=None, ignore_errors=False)


# Generated at 2022-06-25 08:48:58.532089
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    my_map = dict()
    class AnsibleResult:
        _result = my_map
        _host = 'localhost'

    callback_module_0 = CallbackModule()
    callback_module_0._display = object
    callback_module_0._display.verbosity = 3
    callback_module_0._dump_results = lambda x, y: None
    callback_module_0.v2_runner_on_failed(AnsibleResult())



# Generated at 2022-06-25 08:49:01.285930
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module = CallbackModule()
    callback_module.v2_runner_on_failed()


# Generated at 2022-06-25 08:49:07.889891
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    '''
    Unit test for method v2_runner_on_failed of class CallbackModule
    '''
    callback_module_0 = CallbackModule()
    # Test case setup
    result_1 = dict()
    result_1['stderr'] = 'stderr'
    result_1['stdout'] = 'stdout'
    result_1['rc'] = 4
    ignore_errors_1 = False
    # Test case execution
    callback_module_0.v2_runner_on_failed(result_1, ignore_errors_1)


# Generated at 2022-06-25 08:49:10.352942
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()

    # TODO: result should be mocked
    callback_module_1.v2_runner_on_failed(result, ignore_errors=False)



# Generated at 2022-06-25 08:49:12.309105
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result = result()
    ignore_errors = False
    callback_module_0.v2_runner_on_failed(result, ignore_errors)


# Generated at 2022-06-25 08:49:21.062833
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    with mock.patch('ansible.plugins.callback.CallbackBase.v2_runner_on_ok') as mocked_method:
        callback_module_0 = CallbackModule()
        result_0 = mock.MagicMock()
        callback_module_0.v2_runner_on_ok(result_0)
        mocked_method.assert_called_with(result_0)


# Generated at 2022-06-25 08:49:24.328997
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert callback_module_0.CALLBACK_VERSION == 2.0
    assert callback_module_0.CALLBACK_TYPE == 'stdout'
    assert callback_module_0.CALLBACK_NAME == 'oneline'


# Generated at 2022-06-25 08:49:27.117646
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = callback_module_0.v2_runner_on_failed(result_0)


# Generated at 2022-06-25 08:49:37.665913
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module = CallbackModule()


# Generated at 2022-06-25 08:49:47.112512
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    import callback

    set_0 = set()
    callback_module_0 = callback.CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(set_0)


# Generated at 2022-06-25 08:49:51.854827
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # set up test environment
    callback_module_0 = CallbackModule()
    result_0 = ansible.playbook.play_context.PlayContext()
    # set up test inputs
    result_0.rc = arg_0
    callback_module_0.v2_runner_on_ok(result_0)


# Generated at 2022-06-25 08:49:54.307372
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    style = Style()
    temp = ['001', '002', '003']
    for i in range(3):
        style.style = temp[i]
        callback_module_0 = CallbackModule(style)


# Generated at 2022-06-25 08:49:58.412099
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    set_0 = set()
    callback_module_0 = CallbackModule()
    result_0 = dict()
    result_0['changed'] = False
    var_0 = callback_v2_runner_on_ok(result_0)


# Generated at 2022-06-25 08:50:01.551707
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    set_0 =set()
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(set_0)



# Generated at 2022-06-25 08:50:02.786300
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    set_0 = set()
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(set_0, False)


# Generated at 2022-06-25 08:50:05.346468
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    set_0 = set()
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_skipped(set_0)


# Generated at 2022-06-25 08:50:06.872366
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    set_0 = set()
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:50:16.876722
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_obj = CallbackModule()
    # result_0
    result_0 = dict()
    # action_0
    action_0 = 'action_0'
    # result_0_result
    result_0_result = dict()

    # Testing before alterating result_0_result
    result_0_result_keys = result_0_result.keys()
    result_0_result_items = result_0_result.items()
    result_0_result_len = len(result_0_result)

    result_0_result["action"] = action_0
    result_0_result_keys = result_0_result.keys()
    result_0_result_items = result_0_result.items()
    result_0_result_len = len(result_0_result)

    # Testing after

# Generated at 2022-06-25 08:50:19.644289
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    set_0 = set()
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(set_0)
    assert var_0 == None


# Generated at 2022-06-25 08:50:34.429818
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    set_0 = set()
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(set_0)

#Unit test for method v2_runner_on_ok of class CallbackModule

# Generated at 2022-06-25 08:50:38.332191
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    set_0 = set()
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(set_0)


# Generated at 2022-06-25 08:50:44.108011
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    set_0 = set()
    var_0 = 'C:\\Program Files\\JetBrains\\PyCharm Community Edition 2018.1.4\\helpers\\pycharm\\docrunner.py:0'
    result_0 = Result()
    result_0.host = dict_0
    dict_0 = dict()
    dict_0['msg'] = var_0
    result_0._result = dict_0
    callback_module_0 = CallbackModule()
    var_1 = callback_v2_runner_on_failed(result_0, False)


# Generated at 2022-06-25 08:50:47.581228
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    set_0 = set()
    callback_module_0 = CallbackModule()
    # Assert: AssertionError: v2_runner_on_failed() takes exactly 2 arguments (1 given)
    var_0 = callback_module_0.v2_runner_on_failed(set_0)


# Generated at 2022-06-25 08:50:49.771138
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    set_1 = set()
    callback_module_1 = CallbackModule()
    var_1 = callback_v2_runner_on_ok(set_1)

# Generated at 2022-06-25 08:50:52.032914
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    set_0 = set()
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_skipped(set_0)


# Generated at 2022-06-25 08:50:56.224966
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    result = CallbackModule()
    assert result.CALLBACK_NAME == 'oneline'
    assert result.CALLBACK_VERSION == 2.0
    assert result.CALLBACK_TYPE == 'stdout'


# Generated at 2022-06-25 08:50:58.721955
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    set_1 = set()
    callback_module_1 = CallbackModule()
    var_1 = callback_v2_runner_on_ok(set_1)


# Generated at 2022-06-25 08:51:01.926048
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    set_0 = set()
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(set_0)


# Generated at 2022-06-25 08:51:05.614606
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    set_0 = set()
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(set_0)


# Generated at 2022-06-25 08:51:24.383184
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    set_0 = set()
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_ok(set_0)



# Generated at 2022-06-25 08:51:26.636154
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    set_0 = set()
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(set_0)


# Generated at 2022-06-25 08:51:28.405367
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert isinstance(callback_module_0, CallbackModule)


# Generated at 2022-06-25 08:51:34.121540
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    set_0 = set()
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_skipped(set_0)
    assert var_0 == 'SKIPPED', "Unexpected output"


# Generated at 2022-06-25 08:51:37.079251
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    set_0 = set()
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_skipped(set_0)


# Generated at 2022-06-25 08:51:39.119016
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    set_0 = set()
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(set_0)


# Generated at 2022-06-25 08:51:42.153008
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    set_0 = set()
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(set_0)



# Generated at 2022-06-25 08:51:52.849007
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # Create a new CallbackModule object
    callbackModule = CallbackModule()

    # Get the name of the callback module
    name = callbackModule.CALLBACK_NAME

    # Get the type of the callback module
    type = callbackModule.CALLBACK_TYPE

    # Get the version of the callback module
    version = callbackModule.CALLBACK_VERSION

    # Create a new result object
    result = Result()

    # Run the v2_runner_on_failed method
    callbackModule.v2_runner_on_failed(result)

    # Run the v2_runner_on_ok method
    callbackModule.v2_runner_on_ok(result)

    # Run the v2_runner_on_unreachable method
    callbackModule.v2_runner_on_unreachable(result)

    # Run the v2

# Generated at 2022-06-25 08:51:55.790523
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # Test with the first constructor
    callback_module_0 = CallbackModule()
    # Test with the second constructor
    set_1 = set()
    callback_module_1 = CallbackModule(set_1.pop())


# Generated at 2022-06-25 08:51:58.034204
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    set_0 = set()
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed(set_0)


# Generated at 2022-06-25 08:52:33.792379
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    set_0 = set()
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(set_0)


# Generated at 2022-06-25 08:52:37.770392
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    set_0 = set()
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed(set_0)


# Generated at 2022-06-25 08:52:42.816505
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Do unit test here.
    set_0 = set()
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(set_0)


# Generated at 2022-06-25 08:52:47.933461
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    set_1 = set()
    var_1 = callback_v2_runner_on_failed(set_1)


# Generated at 2022-06-25 08:52:52.887722
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    set_1 = set()
    callback_module_1 = CallbackModule()
    return not callback_module_1 is None


# Generated at 2022-06-25 08:52:58.297212
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    set_0 = set()
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(set_0)


# Generated at 2022-06-25 08:53:05.196399
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    set_0 = set()
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(set_0)


# Generated at 2022-06-25 08:53:07.902221
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    set_0 = set()
    var_0 = callback_v2_runner_on_skipped(set_0)


# Generated at 2022-06-25 08:53:10.104126
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    set_1 = set()
    callback_module_1 = CallbackModule()

    assert isinstance(callback_module_1, CallbackBase)
    assert isinstance(callback_module_1, object)



# Generated at 2022-06-25 08:53:11.769334
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    set_0 = set()
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(set_0)


# Generated at 2022-06-25 08:54:36.779028
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    set_0 = set()
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_ok(set_0)


# Generated at 2022-06-25 08:54:39.974341
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Test with various test cases
    set_0 = set()
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_ok(set_0)


# Generated at 2022-06-25 08:54:42.149718
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    assert False, "Not implemented"


# Generated at 2022-06-25 08:54:46.364129
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    set_0 = set()
    var_0 = CallbackModule(set_0)
    var_0.v2_runner_on_ok(set_0, set_0)

# Generated at 2022-06-25 08:54:56.000609
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    def v2_runner_on_failed(self, result, ignore_errors=False):
        if 'exception' in result._result:
            if self._display.verbosity < 3:
                # extract just the actual error message from the exception text
                error = result._result['exception'].strip().split('\n')[-1]
                msg = "An exception occurred during task execution. To see the full traceback, use -vvv. The error was: %s" % error
            else:
                msg = "An exception occurred during task execution. The full traceback is:\n" + result._result['exception'].replace('\n', '')


# Generated at 2022-06-25 08:54:57.816516
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    set_1 = set()
    callback_module_1 = CallbackModule()
    var_1 = callback_v2_runner_on_ok(set_1)


# Generated at 2022-06-25 08:55:02.314185
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    var_0 = set()
    var_1 = callback_v2_runner_on_ok(var_0)


# Generated at 2022-06-25 08:55:09.691281
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    arg_0 = dict(a=1)
    arg_0.update(dict(b=2))
    arg_0.update(dict(c=3))
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_ok(arg_0)


# Generated at 2022-06-25 08:55:11.465195
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    set_0 = set()
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_skipped(set_0)


# Generated at 2022-06-25 08:55:14.484973
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    set_0 = set()
    callback_module_0 = CallbackModule()
    # Do something
    result = set()
    ignore_errors = False
    callback_module_0.v2_runner_on_failed(result, ignore_errors)


# Generated at 2022-06-25 08:58:32.171157
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    class_var_1 = {'exception': 'test_exception'}
    var_1 = callback_module_1.v2_runner_on_failed(class_var_1)


# Generated at 2022-06-25 08:58:33.494046
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    set_0 = set()
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(set_0)


# Generated at 2022-06-25 08:58:34.701617
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    set_0 = set()
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed(set_0)


# Generated at 2022-06-25 08:58:37.525793
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    test_1 = CallbackModule()
    assert_equal(test_1.CALLBACK_NAME, "oneline")
    assert_equal(test_1.CALLBACK_VERSION, 2.0)
    assert_equal(test_1.CALLBACK_TYPE, "stdout")


# Generated at 2022-06-25 08:58:38.004921
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    test_case_0()


# Generated at 2022-06-25 08:58:45.881973
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    var_0 = dict()
    var_1 = True
    var_0['task_action'] = 'ensemble'
    var_0['_ansible_parsed'] = True
    var_0['_ansible_item_result'] = True
    var_0['is_failed'] = False
    var_0['_ansible_verbose_always'] = False
    var_0['rc'] = 'rc'
    var_0['invocation'] = {'module_args': 'module_args'}
    var_0['_ansible_no_log'] = False
    var_0['end'] = 'end'
    var_0['stderr'] = 'stderr'
    var_0['_ansible_ignore_errors'] = False
    var_0['stdout'] = 'stdout'
