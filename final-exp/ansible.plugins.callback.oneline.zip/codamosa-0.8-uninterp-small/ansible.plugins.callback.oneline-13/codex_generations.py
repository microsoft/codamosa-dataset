

# Generated at 2022-06-25 08:48:55.747452
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = mock.MagicMock(spec_set=_Result.Result)
    result_0.__getitem__.return_value = "hostname"
    result_0._host = mock.MagicMock(spec=HostVars)
    result_0._host.get_name.return_value = hostname
    result_0._result = mock.MagicMock(spec_set=dict)
    result_0._result.get = mock.MagicMock(return_value = "rc")
    result_0._result.__getitem__.return_value = "exception"
    result_0._result.keys.return_value = ["exception"]
    callback_module_0.CALLBACK_VERSION = 1.0
    callback_module_0.CALLBACK

# Generated at 2022-06-25 08:49:01.999980
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_ok({'_host': {'get_name': 'foo'}, '_result': {}})


# Generated at 2022-06-25 08:49:07.214939
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    result_1 = object()
    ignore_errors_1 = False

    callback_module_1.v2_runner_on_failed(result=result_1, ignore_errors=ignore_errors_1)


# Generated at 2022-06-25 08:49:12.781052
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

    callback_module_1 = CallbackModule()
    result_1 = []
    callback_module_1.v2_runner_on_ok(result_1)

# Generated at 2022-06-25 08:49:19.706954
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = {}
    callback_module_0.v2_runner_on_failed(result_0)

# Unit test of method v2_runner_on_ok of class CallbackModule

# Generated at 2022-06-25 08:49:24.256161
# Unit test for constructor of class CallbackModule
def test_CallbackModule():

    # Call the constructor of the class with no parameter
    callback_module_0 = CallbackModule()
    assert callback_module_0.CALLBACK_VERSION == 2.0
    assert callback_module_0.CALLBACK_TYPE == 'stdout'
    assert callback_module_0.CALLBACK_NAME == 'oneline'

# Generated at 2022-06-25 08:49:28.372727
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

    result = {}
    result._result = {}
    result._result['changed'] = True
    result._result['ansible_job_id'] = 1
    result._task = {}
    result._task.action = 'action'
    result._host = {}
    result._host.get_name = lambda: 'test'

    callback_module = CallbackModule()
    callback_module.v2_runner_on_ok(result)


# Generated at 2022-06-25 08:49:33.247923
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Arrange
    callback_module_0 = CallbackModule()
    result = 'result0'
    ignore_errors = False

    # Act
    callback_module_0.v2_runner_on_failed(result, ignore_errors)


# Generated at 2022-06-25 08:49:40.403666
# Unit test for constructor of class CallbackModule

# Generated at 2022-06-25 08:49:43.393178
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    cbm = CallbackModule()
    assert(cbm._dump_results == CallbackBase._dump_results)

# Generated at 2022-06-25 08:49:52.236789
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert callable(CallbackModule)



# Generated at 2022-06-25 08:49:52.817318
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module = CallbackModule()

# Generated at 2022-06-25 08:49:54.042651
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert True == isinstance(CallbackModule(), CallbackBase)


# Generated at 2022-06-25 08:49:59.821547
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    callback_module_1.v2_runner_on_failed({'exception': "This is an exception", '_task': {'action': 'setup'}, '_result': {'changed': False, 'rc': 0, 'stderr': '', 'stdout': 'REAL', 'stdout_lines': ['REAL']}, '_host': {'get_name': lambda: 'localhost'}})


# Generated at 2022-06-25 08:50:05.553537
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule.__doc__ != None, "CallbackModule.__doc__ should not be None"
    assert CallbackModule.CALLBACK_TYPE != None, "CallbackModule.CALLBACK_TYPE should not be None"
    assert CallbackModule.CALLBACK_NAME != None, "CallbackModule.CALLBACK_NAME should not be None"
    assert CallbackModule.CALLBACK_VERSION != None, "CallbackModule.CALLBACK_VERSION should not be None"
    assert CallbackModule._dump_results != None, "CallbackModule._dump_results should not be None"
    assert CallbackModule._command_generic_msg != None, "CallbackModule._command_generic_msg should not be None"

# Generated at 2022-06-25 08:50:07.720522
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = callback_module_0.v2_runner_on_failed(result, False)


# Generated at 2022-06-25 08:50:10.344618
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result_0 = FakeRunner_0()
    callback_module_0.v2_runner_on_ok(result_0)


# Generated at 2022-06-25 08:50:19.274511
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    class result_proxy_1:
        _result = {
            'msg': '',
            'exception': 'An exception occurred during task execution. The full traceback is:\n' + result._result['exception'].replace('\n', '')}
        _host = {
            'get_name': lambda: 'An exception occurred during task execution. To see the full traceback, use -vvv. The error was: %s' % error}
    result_proxy_2 = result_proxy_1()
    callback_module_1.v2_runner_on_failed(result_proxy_2, ignore_errors=False)



# Generated at 2022-06-25 08:50:21.327785
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    from ansible.plugins.callback import CallbackModule
    callback_module_0 = CallbackModule()
    assert callback_module_0 is not None


# Generated at 2022-06-25 08:50:28.900068
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_1 = CallbackModule()
    assert callback_module_1.CALLBACK_VERSION == 2.0
    assert callback_module_1.CALLBACK_TYPE == 'stdout'
    assert callback_module_1.CALLBACK_NAME == 'oneline'


# Generated at 2022-06-25 08:50:45.207493
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    int_0 = 2568
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(int_0)



# End of file test_callback_module.py

#   You should have received a copy of the GNU General Public License
# along with Ansible.  If not, see <http://www.gnu.org/licenses/>.

# Make coding more python3-ish
from __future__ import (absolute_import, division, print_function)
__metaclass__ = type


# Generated at 2022-06-25 08:50:50.361348
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackModule
    from ansible.compat.tests import unittest
    callback_module_0 = CallbackModule()
    callback_module_0.display = MagicMock()
    int_0 = 2568
    callback_module_0.v2_runner_on_ok(int_0)

if __name__ == '__main__':
    test_case_0()
    test_CallbackModule_v2_runner_on_ok()

# Generated at 2022-06-25 08:50:52.891033
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    int_0 = 1056
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_ok(int_0)


# Generated at 2022-06-25 08:50:56.932975
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    int_0 = int(input())
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(int_0)



# Generated at 2022-06-25 08:51:02.198927
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Set up parameters for test case
    int_0 = 2568
    result_0 = Result(host=host, module=module, task=task, task_fields=task_fields, result=result)
    ignore_errors_0 = False

    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(result_0, ignore_errors_0)


# Generated at 2022-06-25 08:51:05.642894
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    int_0 = 2377
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(int_0)



# Generated at 2022-06-25 08:51:09.735635
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    int_0 = 1
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(int_0)


# Generated at 2022-06-25 08:51:15.211880
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    int_0 = None
    int_1 = 8
    int_2 = None
    bool_0 = False

    callback_module_0 = CallbackModule()

    try:
        assert(False)
    except AssertionError as e:
        var_0 = '{}'.format(e)
        assert(var_0[1:] == 'assert False')
    assert(var_0 == 'AssertionError: assert False')

    var_1 = callback_v2_runner_on_failed(int_0, bool_0)
    assert(var_1 == '{} | FAILED! => {}'.format(int_0, var_0))
    var_1 = callback_v2_runner_on_failed(int_0, bool_0, indent=int_1)

# Generated at 2022-06-25 08:51:18.389995
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    int_0 = 806
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(int_0)


# Generated at 2022-06-25 08:51:22.053343
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Test case data
    result_0 = {}

    # Call method
    callback_module_0 = CallbackModule()
    result_1 = callback_module_0.v2_runner_on_failed(result_0)


# Generated at 2022-06-25 08:51:39.054556
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    test_case_0()

# Generated at 2022-06-25 08:51:42.434220
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    int_0 = 1398
    callback_module_0 = CallbackModule()
    int_1 = 1398
    str_0 = callback_module_0._dump_results(int_1, int_0)


# Generated at 2022-06-25 08:51:53.030892
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

    # Define test case inputs
    int_0 = 426
    int_1 = 617
    int_2 = 618

    # Define expected results
    expected_result_0 = 0
    expected_result_1 = expected_result_0
    expected_result_2 = expected_result_1

    # Conduct test
    result_0 = callback_v2_runner_on_ok(int_0)
    result_1 = callback_v2_runner_on_ok(int_1)
    result_2 = callback_v2_runner_on_ok(int_2)

    # Compare results
    passed = (expected_result_0 == result_0 and expected_result_1 == result_1 and expected_result_2 == result_2)

# Generated at 2022-06-25 08:51:55.092916
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    assert True


# Generated at 2022-06-25 08:51:59.799060
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Initialize the CallbackModule
    test_CallbackModule = CallbackModule()
    int_0 = 2568
    str_0 = "<result._host.get_name()>"
    str_1 = "stderr"

    # Apply the method v2_runner_on_failed
    test_CallbackModule.v2_runner_on_failed(int_0)

    # Check the expected result
    self.assertEquals(test_CallbackModule.v2_runner_on_failed(int_0))



# Generated at 2022-06-25 08:52:03.547421
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a new CallbackModule object.
    obj_0 = CallbackModule()
    # Call method v2_runner_on_failed of object obj_0.
    var_0 = obj_0.v2_runner_on_failed()



# Generated at 2022-06-25 08:52:04.888455
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    expected = None
    assert expected == None, "Failed to instantiate CallbackModule"


# Generated at 2022-06-25 08:52:07.934566
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    int_0 = 1716
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(int_0)


# Generated at 2022-06-25 08:52:10.636451
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    test_case_0()

if __name__ == '__main__':
    test_CallbackModule()

# Generated at 2022-06-25 08:52:11.453056
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    CallbackModule()


# Generated at 2022-06-25 08:52:51.800455
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # String: msg
    # String: hostname
    # Object: result
    callback_module_0 = CallbackModule()
    # TODO: Implement test
    assert True


# Generated at 2022-06-25 08:52:58.708748
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    int_0 = 78
    str_0 = 'ansible_job_id'
    str_1 = 'changed'
    str_2 = 'An exception occurred during task execution. To see the full traceback, use -vvv. The error was: %s'
    str_3 = 'An exception occurred during task execution. The full traceback is:\n'
    str_4 = '\n'
    str_5 = '\r'
    str_6 = 'rc'
    str_7 = 'stderr'
    str_8 = 'stdout'
    str_9 = 'FAILED'
    str_10 = 'FAILED! => %s'
    int_1 = 0
    unk_0 = dict()
    int_2 = -1

# Generated at 2022-06-25 08:53:02.344548
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    test_case_0()


# Generated at 2022-06-25 08:53:07.005249
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    print('\ntest_CallbackModule')
    callback_module_0 = CallbackModule()
    test_case_0()

if __name__ == '__main__':
    test_CallbackModule()

# Generated at 2022-06-25 08:53:08.118916
# Unit test for constructor of class CallbackModule
def test_CallbackModule():

    assert True


# Generated at 2022-06-25 08:53:09.710618
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    var = CallbackModule()
    result = int(2567)
    var.v2_runner_on_ok(result)


# Generated at 2022-06-25 08:53:11.651598
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    print('')
    int_0 = 2568
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_ok(int_0)


# Generated at 2022-06-25 08:53:21.554317
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Define a dict for the result which contains the following keys:
    # rc, start, end, delta, stdout, stderr, msg, exception
    result = {
        'rc' : -1,
        'start' : '2017-05-26 14:06:52.107016',
        'end' : '2017-05-26 14:06:52.288832',
        'delta' : '0:00:00.181816',
        'stdout' : '"stdout output"',
        'stderr' : '"stderr output"',
        'msg' : 'non-zero return code',
        'exception' : '"some exception"'
    }
    # Define the caption which should be printed after the hostname
    caption = 'FAILED'

    # Define the

# Generated at 2022-06-25 08:53:25.474805
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert callback_module_0.CALLBACK_VERSION == 2.0
    assert callback_module_0.CALLBACK_TYPE == 'stdout'
    assert callback_module_0.CALLBACK_NAME == 'oneline'


# Generated at 2022-06-25 08:53:26.768363
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    int_0 = 2568
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(int_0)


# Generated at 2022-06-25 08:55:07.154965
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    try:
        CallbackModule()
    except TypeError:
        assert False
    else:
        assert True

# Generated at 2022-06-25 08:55:10.792492
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    global callback_module_0
    callback_module_0 = CallbackModule()

test_case_0()
test_CallbackModule()

# Generated at 2022-06-25 08:55:13.628480
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    int_0 = 2568
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_ok(int_0)


# Generated at 2022-06-25 08:55:15.239190
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    int_0 = 5998
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_ok(int_0)

# Generated at 2022-06-25 08:55:19.215690
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

    # unit test
    # Test with an int
    int_0 = 2568
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(int_0)

    # unit test
    # Test with a str
    str_0 = "This is a test"
    callback_module_1 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(str_0)

# Generated at 2022-06-25 08:55:23.895227
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    int_0 = 21315
    callback_module_0 = CallbackModule()
    assert not callback_module_0.v2_runner_on_failed(int_0)

# Magic unit test for method v2_runner_on_ok of class CallbackModule

# Generated at 2022-06-25 08:55:27.818044
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    int_0 = 1404
    bool_0 = False
    result_0 = task_result(int_0)
    result_1 = task_result(int_0)
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(result_0, bool_0)


# Generated at 2022-06-25 08:55:31.394342
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    int_0 = 631
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_ok(int_0)


# Generated at 2022-06-25 08:55:33.011458
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    int_0 = 5020
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(int_0)

# Generated at 2022-06-25 08:55:33.559791
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    pass
