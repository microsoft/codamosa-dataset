

# Generated at 2022-06-25 08:48:51.793541
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_1 = CallbackModule()

# Generated at 2022-06-25 08:48:58.821508
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_1 = CallbackModule()
    assert(callback_module_1.v2_runner_on_failed is not None and callable(callback_module_1.v2_runner_on_failed))

# Generated at 2022-06-25 08:49:08.350242
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = {'_host': None,
                '_result': {'exception': 'An exception occurred during task execution. To see the full traceback, use -vvv. The error was: ERROR'},
                '_task': None}

# Generated at 2022-06-25 08:49:18.078462
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()

    result_0_0 = { 'changed': False, '_ansible_no_log': False, '_ansible_item_result': True, 'item': [ '3', '5', '7' ], 'invocation': { 'module_args': { 'command': 'ls -l' } }, 'stdout': 'total 4\ndrwxr-xr-x 3 root root 4096 Apr 20 03:30 a\ndrwxr-xr-x 3 root root 4096 Apr 20 03:30 b\ndrwxr-xr-x 3 root root 4096 Apr 20 03:30 c\n', 'cmd': [ 'ls', '-l' ], 'rc': 0 }
    result_0_0['_ansible_item_result'] = True

# Generated at 2022-06-25 08:49:20.624642
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    try:
        test_case_0()
    except Exception as e:
        print ("An exception occurred in the construction of class CallbackModule: %s" % (str(e)))
        return 1
    return 0

# Generated at 2022-06-25 08:49:23.267570
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_1 = CallbackModule()
    result_1 = None
    assert callback_module_1.v2_runner_on_ok(result_1) == None


# Generated at 2022-06-25 08:49:30.235765
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = {
        'exception': '{\n    "changed": false, \n    "failed": true, \n    "invocation": {\n        "module_name": "shell"\n    }, \n    "module_stderr": "", \n    "module_stdout": "", \n    "msg": "non-zero return code", \n    "rc": 1\n}',
        '_ansible_no_log': False,
        '_ansible_verbose_always': True,
        '_ansible_ignore_errors': None,
        '_ansible_item_label': None,
        '_target_host': 'local'
    }

# Generated at 2022-06-25 08:49:31.604552
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:49:41.872563
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    rc = -1 
    tmp_stdout = "tmp_stdout" + "\n"
    tmp_stdout = tmp_stdout.replace("\n", "\\n").replace("\r", "\\r")
    tmp_stderr = "tmp_stderr" + "\n"
    tmp_stderr = tmp_stderr.replace("\n", "\\n").replace("\r", "\\r")
    tmp_result = {"rc":rc,"stdout":tmp_stdout,"exception":tmp_stderr}
    callback_module_0 = CallbackModule()
    ret = callback_module_0._command_generic_msg("", tmp_result, "FAILED") 
    print(ret)


# Generated at 2022-06-25 08:49:46.522794
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    cb = CallbackModule()
    cb.v2_runner_on_failed(result, False)


# Generated at 2022-06-25 08:49:58.344857
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_1 = CallbackModule()
    assert isinstance(callback_module_1, CallbackModule)
    assert callback_module_1.CALLBACK_VERSION == 2.0
    assert callback_module_1.CALLBACK_TYPE == 'stdout'


# Generated at 2022-06-25 08:50:01.553173
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed(result = 'result_0', ignore_errors = True)


# Generated at 2022-06-25 08:50:05.211805
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

    host = 'test-server'

# Generated at 2022-06-25 08:50:09.989265
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    class FakeResult:
        _result = {'exception': "test exception"}
        _task = "task"
        _host = "host"

    fake_result_1 = FakeResult()
    fake_result_1._result = {'exception': "test exception"}
    callback_module_1.v2_runner_on_failed(fake_result_1)


# Generated at 2022-06-25 08:50:12.743108
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    with pytest.raises(AttributeError):
        callback_module_0.v2_runner_on_failed()


# Generated at 2022-06-25 08:50:14.711010
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_ok(result)


# Generated at 2022-06-25 08:50:23.048941
# Unit test for method v2_runner_on_failed of class CallbackModule

# Generated at 2022-06-25 08:50:25.150130
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    try:
        test_case_0()
    except Exception as e:
        print(e.__doc__)
        print(e.message)
        traceback.print_tb(sys.exc_info()[2])

# Generated at 2022-06-25 08:50:27.922267
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    result = {'changed': False}
    assert(callback_module_0.v2_runner_on_ok(result)) == result


# Generated at 2022-06-25 08:50:31.603026
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    print("Testing method v2_runner_on_failed of class CallbackModule")
    # Prepare test data
    callback_module_1 = CallbackModule()
    result = RunnerResult()
    ignore_errors = None

    # Call target method
    callback_module_1.v2_runner_on_failed(result, ignore_errors)

    # Assert target method results
    assert True


# Generated at 2022-06-25 08:50:53.379908
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = {
        "_ansible_ignore_errors": None,
        "_ansible_item_result": False,
        "_ansible_no_log": False,
        "_ansible_parsed": True,
        "_ansible_verbose_always": True,
        "changed": False,
        "failed": True,
        "invocation": {
            "module_args": "remote_user=root version=1.1.1",
            "module_complex_args": {},
            "module_name": "xcodebuild"
        },
        "item": "",
        "rc": 1
    }
    callback_module_0.v2_runner_on_failed(result_0, ignore_errors=False)



# Generated at 2022-06-25 08:50:58.153688
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    result = dict({
        'task_action': 'shell',
        'task_args': 'pwd',
        'task_name': 'shell'
    })
    callback_module = CallbackModule()
    callback_module.v2_runner_on_ok(result)


# Generated at 2022-06-25 08:50:59.017187
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert callable(CallbackModule)



# Generated at 2022-06-25 08:51:02.935429
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result = dict()
    result['changed'] = True
    callback_module_0.v2_runner_on_ok(result)
    result['changed'] = False
    callback_module_0.v2_runner_on_ok(result)


# Generated at 2022-06-25 08:51:04.715691
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    test_case_0()

# Generated at 2022-06-25 08:51:12.656555
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    failed_result = dict()
    failed_result['exception'] = "An exception occurred during task execution. To see the full traceback, use -vvv. The error was: "
    failed_result['_result'] = dict()
    display = dict()
    display['verbosity'] = 2
    display['display'] = "An exception occurred during task execution. The full traceback is:\n" + "test".replace('\n', '')

    class Task:
        action = "test_action"
    task = Task()
    failed_result['_task'] = task

    class Result:
        _host = dict()
        get_name = lambda self: "test_host"
        _result = "test_result"

    result = Result()
    result._result = failed_result
    
    callback_module_0 = CallbackModule()

# Generated at 2022-06-25 08:51:13.230496
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    test_case_0()


# Generated at 2022-06-25 08:51:14.511281
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    # unit test is not possible because callback_module_0._display is not a proper Python object




# Generated at 2022-06-25 08:51:17.485379
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

    # Parameters:
    result = None

    # Return value:
    # True
    result = True

    return result


# Generated at 2022-06-25 08:51:20.062170
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module = CallbackModule()
    callback_module.v2_runner_on_ok('')


# Generated at 2022-06-25 08:51:54.419067
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    utils.execute_pdfs(test_case_0, 'CallbackModule', 'v2_runner_on_failed')


# Generated at 2022-06-25 08:51:58.899400
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()

    class Object():
        def __init__(self, result, ignore_errors=False):
            self._result = result
            self._ignore_errors = ignore_errors

    result = Object({'exception': 'An exception occurred during task execution.'})

    callback_module_0.v2_runner_on_failed(result, ignore_errors=False)


# Generated at 2022-06-25 08:52:07.047318
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_test_object = CallbackModule()
    callback_module_test_result = ansible.playbook.TaskResult(host=ansible.inventory.host.Host('127.0.0.1'), task=ansible.playbook.task.Task(), return_data={'_ansible_no_log': False, 'changed': False, 'rc': 0, 'stderr': '', 'stderr_lines': [], 'stdout': 'Command successfuly executed', 'stdout_lines': ['Command successfuly executed']})
    callback_module_test_object.v2_runner_on_ok(callback_module_test_result)

# Generated at 2022-06-25 08:52:11.940767
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    import json
    import pprint
    host = {'name': 'target'}
    result = {'changed': False}
    result['_result'] = json.dumps(result)
    result['_host'] = host
    result['invocation'] = {'module_args': 'some_command'}
    callback_module_ok = CallbackModule()
    callback_module_ok.v2_runner_on_ok(result)
    return


# Generated at 2022-06-25 08:52:15.650991
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
   # Testing method v2_runner_on_ok of class CallbackModule
    host = 'jibinmathews-HP-ProBook-450-G0'
    v2_runner_on_ok = CallbackModule.v2_runner_on_ok
    v2_runner_on_ok(host)
    assert result._host.get_name() == 'jibinmathews-HP-ProBook-450-G0'


# Generated at 2022-06-25 08:52:24.394504
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # CallbackModule instance for testing
    callback_module = CallbackModule()
    # Test scenario
    '''
    Simple test

    '''
    result_token = '''
        {
            "msg": "",
            "ansible_facts": {
                "pkg_mgr": "apt",
                "distribution": "Ubuntu",
                "distribution_release": "16.04",
                "distribution_version": "16.04",
                "python_version": 2
            },
            "ansible_version": {
                "major": 2,
                "full": "2.9.7",
                "minor": 9,
                "revision": 0,
                "string": "2.9.7"
            },
            "changed": false
        }
    '''
    result_token_dec

# Generated at 2022-06-25 08:52:29.708302
# Unit test for constructor of class CallbackModule

# Generated at 2022-06-25 08:52:31.171468
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result_0 = None
    try:
        callback_module_0.v2_runner_on_ok(result_0)
    except:
        pass


# Generated at 2022-06-25 08:52:38.073971
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    error = None
    try:
        callback_module_0 = CallbackModule()
    except Exception as err:
        error = str(err)
    assert error is None


# Generated at 2022-06-25 08:52:46.846177
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = dict()
    result_0['_result'] = dict()
    result_0['_result']['exception'] = 'error'
    result_0['_result']['rc'] = 0
    result_0['_result']['stdout'] = 'streamout'
    result_0['_result']['stderr'] = 'streamerr'
    result_0['_host'] = dict()
    result_0['_host']['get_name'] = lambda : 'hostname'
    result_0['_task'] = dict()
    result_0['_task']['action'] = 'shell'
    callback_module_0._display = dict()
    callback_module_0._display['verbosity'] = 1
    callback_module_

# Generated at 2022-06-25 08:53:21.865756
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    result = result()
    callback_module_1.v2_runner_on_failed(result)


# Generated at 2022-06-25 08:53:30.720853
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Initialize the callback module
    callback_module_0 = CallbackModule()

    # Initialize a result object
    import ansible.executor.task_result
    result_0 = ansible.executor.task_result.TaskResult()
    import ansible.results
    result_0._result = ansible.results.AnsibleResult()
    import ansible.hosts
    result_0._host = ansible.hosts.Host(name='debian_jessie')
    result_0._result = dict()
    result_0._result['failed'] = True
    result_0._result['exception'] = 'message'

    # Call v2_runner_on_failed of the callback module
    callback_module_0.v2_runner_on_failed(result_0)


# Generated at 2022-06-25 08:53:32.113015
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module = CallbackModule()

    # Check that CallbackModule is a sub class of CallbackBase
    assert isinstance(callback_module, CallbackBase)


# Generated at 2022-06-25 08:53:38.310011
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()

    class Host:
        def get_name(self):
            return "host"

    result = {"changed": False}
    res = Host()
    res._result = result
    res._task = Host()
    res._task.action = 'test action'
    callback_module_0.v2_runner_on_ok(res)

    res._result['changed'] = True
    callback_module_0.v2_runner_on_ok(res)

    res._result['_ansible_no_log'] = True
    callback_module_0.v2_runner_on_ok(res)


# Generated at 2022-06-25 08:53:40.091858
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule() != None

# Generated at 2022-06-25 08:53:45.637422
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    from ansible.plugins.callback import CallbackBase
    from ansible.plugins.callback.oneline import CallbackModule

    try:
        callback_module_0 = CallbackModule()
        assert issubclass(type(callback_module_0),CallbackBase)

    except Exception as err:
        print("Failed to instantiate CallbackModule object", err)


# Generated at 2022-06-25 08:53:49.449710
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    values = {
        '_result': {
            'exception': 'abc',
            '_task': {
                'action': 'debug'
            },
            '_host': {
                'get_name': lambda: 'localhost'
            }
        },
        '_display': {
            'verbosity': 3,
            'display': lambda x, color: print(x)
        }
    }
    callback_module_0.v2_runner_on_failed(values)


# Generated at 2022-06-25 08:53:56.587679
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed({
        'exception': 'An exception occurred during task execution.\n',
        '_host': {
            'get_name': lambda : 'localhost',
        },
        '_result': {
            'exception': 'Traceback (most recent call last):\n',
            'failed': True,
            'changed': False,
            'msg': 'non-zero return code'
        },
        '_task': {
            'action': 'command'
        }
    }, ignore_errors=False)


# Generated at 2022-06-25 08:53:58.552961
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_ok(result=None)


# Generated at 2022-06-25 08:54:06.998099
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

    # Test error if result._host.get_name() is None
    result = mock.Mock()
    result._host.get_name.side_effect = AttributeError
    callback_module_0 = CallbackModule()
    with pytest.raises(AttributeError):
        callback_module_0.v2_runner_on_ok(result)

    # Test error if self._dump_results(result._result, indent=0) is None
    result = mock.MagicMock()
    result._host.get_name.return_value = 'ReturnValue'
    result._result.get.return_value = True
    callback_module_1 = CallbackModule()
    callback_module_1._dump_results.return_value = None
    with pytest.raises(TypeError):
        callback_module_1.v2_

# Generated at 2022-06-25 08:55:55.091255
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback = CallbackModule()

# Generated at 2022-06-25 08:56:02.738202
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    if __name__ == '__main__':
        import inspect
        import copy

        test_case = inspect.getmembers(sys.modules[__name__], inspect.isfunction)[0][1]
        test_case()

# Generated at 2022-06-25 08:56:10.550893
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    import json
    callback_module_0 = CallbackModule()
    result = dict()
    result['_ansible_ignore_errors'] = False
    result['_ansible_no_log'] = False
    result['_ansible_parsed'] = False
    result['_ansible_verbose_always'] = False
    result['_ansible_verbose_override'] = False
    result['_ansible_notify'] = None
    result['_ansible_no_log'] = False
    result['_ansible_delegated_vars'] = None
    result['_ansible_item_label'] = None
    result['_ansible_diff'] = False
    result['_ansible_forks'] = 0
    result['_ansible_module_name'] = None

# Generated at 2022-06-25 08:56:14.634236
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    with pytest.raises(KeyError):
        callback_module_0.v2_runner_on_failed(result, ignore_errors=False)


# Generated at 2022-06-25 08:56:19.400595
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    module = CallbackModule()
    assert module.CALLBACK_VERSION == 2.0
    assert module.CALLBACK_TYPE == 'stdout'
    assert module.CALLBACK_NAME == 'oneline'

import pytest
from ansible.plugins.callback.oneline import CallbackModule
from ansible.parsing.dataloader import DataLoader
from ansible.vars import VariableManager
from ansible.inventory import Inventory
from ansible.playbook.play import Play
from ansible.executor.task_queue_manager import TaskQueueManager
from ansible.executor.playbook_executor import PlaybookExecutor
from ansible.playbook import Playbook
from ansible.playbook.block import Block



# Generated at 2022-06-25 08:56:23.145072
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    """
    Test object creation of CallbackModule
    """
    callback_module_0 = CallbackModule()
    callback_module_0.CALLBACK_TYPE = 'default'
    callback_module_0.CALLBACK_VERSION = 2.0
    callback_module_0.CALLBACK_NAME = 'default'

# Generated at 2022-06-25 08:56:27.974910
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_1 = CallbackModule()
    callback_module_2 = CallbackModule()
    assert callback_module_1 is not None
    assert callback_module_1 == callback_module_2


# Generated at 2022-06-25 08:56:30.613088
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module = CallbackModule()
    host = {'name': 'test_images'}
    result = {'_host': host}
    callback_module.v2_runner_on_ok(result)



# Generated at 2022-06-25 08:56:32.462465
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    with pytest.raises(TypeError):
        CallbackModule().v2_runner_on_failed()


# Generated at 2022-06-25 08:56:34.223809
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    callback_module_1.v2_runner_on_failed("")
    callback_module_1.v2_runner_on_failed("")
