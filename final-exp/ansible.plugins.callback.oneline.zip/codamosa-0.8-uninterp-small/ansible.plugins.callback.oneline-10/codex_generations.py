

# Generated at 2022-06-25 08:48:51.664719
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Make an object of class CallbackModule
    callback_module_obj = CallbackModule()
    # Make a class object of class Result
    result_obj = Result()
    # Make a class object of class Host
    host_obj = Host()
    # Set the attirbute _host of result_obj to that of host_obj
    result_obj._host = host_obj
    # Set the name of host_obj to "santabrabara"
    host_obj.get_name = lambda: "santabrabara"
    # Initialise the variable stdout
    stdout = ""
    # Set the attributes stdout of result_obj to that of stdout
    result_obj.stdout = stdout

    # Call the method to test
    callback_module_obj.v2_runner_on_failed(result_obj)

# Generated at 2022-06-25 08:48:55.423104
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:48:59.621112
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    assert True == True



# Generated at 2022-06-25 08:49:07.521113
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()

# Generated at 2022-06-25 08:49:09.637307
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed(None)


# Generated at 2022-06-25 08:49:17.543317
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    result_1 = {
        '_task': {
            'action': 'setup',
            'version_added': 2.1
        },
        '_host': {
            'get_name': lambda: 'localhost',
            'get_vars': lambda: {}
        },
        '_result': {
            'exception': 'An exception occurred',
            'msg': 'An exception occurred during task execution. To see the full traceback, use -vvv. The error was: An exception occurred',
            'stdout': 'ansible-test-stdout',
            'stderr': 'ansible-test-stderr',
            'rc': -1
        }
    }
    callback_module_1.v2_runner_on_failed(result_1)

#

# Generated at 2022-06-25 08:49:21.026603
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    print('Start testing constructor of class CallbackModule')
    test_case_0()
    print('End testing constructor of class CallbackModule')

if __name__ == "__main__":
    print('Testing class CallbackModule')
    test_CallbackModule()
    print('End testing class CallbackModule')

# Generated at 2022-06-25 08:49:23.985424
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_1 = CallbackModule()
    result = {'changed': True}
    result = object()
    callback_module_1.v2_runner_on_ok(result)


# Generated at 2022-06-25 08:49:27.512523
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    msg = 'An exception occurred during task execution. To see the full traceback, use -vvv. The error was: %s'
    result = 'ok'
    callback_module_1.v2_runner_on_failed(result)


# Generated at 2022-06-25 08:49:37.491334
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    _task = Task()
    _host_result = HostResult()
    #for the first time the result has 'stderr' which will be handled
    _host_result._result['stderr'] = 'stderr'
    _host_result._task = _task
    _host_result._host = Host("192.168.1.101")
    callback_module_0 = CallbackModule()
    callback_module_0._display.verbosity = 0
    callback_module_0.v2_runner_on_failed(_host_result, ignore_errors=False)
    #for the second time, the result has not 'stderr' which will be handled
    _host_result._result['stderr'] = None
    callback_module_0 = CallbackModule()
    callback_module_0._display.verbosity = 0

# Generated at 2022-06-25 08:49:43.721546
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    int_0 = test_case_0()
    assert(int_0 == 0)

# Generated at 2022-06-25 08:49:45.932520
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    bool_0 = False
    callback_module_0 = CallbackModule(bool_0)

# Generated at 2022-06-25 08:49:50.706324
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = '0_G|\\len`m6'
    bool_0 = False
    callback_module_0 = CallbackModule(bool_0)
    result_0 = callback_module_0.v2_runner_on_failed(str_0)
    assert(result_0 =='0_G|\\len`m6')


# Generated at 2022-06-25 08:49:53.236148
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    str_0 = sys.argv[0]
    var_1 = callback_v2_runner_on_ok(str_0)


# Generated at 2022-06-25 08:49:57.461690
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    str_0 = '0_G|\\len`m6'
    bool_0 = False
    callback_module_0 = CallbackModule(bool_0)
    var_0 = callback_module_0.v2_runner_on_ok(str_0)


# Generated at 2022-06-25 08:50:03.256187
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = '0_G|\\len`m6'
    bool_0 = False
    callback_module_0 = CallbackModule(bool_0)
    var_0 = callback_v2_runner_on_failed(str_0)


# Generated at 2022-06-25 08:50:04.658533
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 08:50:07.968435
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    str_0 = '1_G|\\len`m6'
    bool_0 = False
    callback_module_0 = CallbackModule(bool_0)
    var_0 = callback_v2_runner_on_ok(str_0)


# Generated at 2022-06-25 08:50:14.186079
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = 'P,y8h{yT}T#'
    callback_module_0 = CallbackModule(str_0)
    var_0 = callback_module_0.v2_runner_on_failed(str_0)

    str_0 = 'F5}0`>'
    bool_0 = True
    callback_module_0 = CallbackModule(bool_0)
    var_0 = callback_v2_runner_on_failed(str_0)


# Generated at 2022-06-25 08:50:20.435504
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    str_0 = '8:'
    str_1 = '+_'
    str_2 = ''
    str_3 = '6A@}'
    str_4 = 'E'
    bool_0 = True
    callback_module_0 = CallbackModule(bool_0)
    var_0 = callback_module_0.v2_runner_on_ok(str_0, str_1, str_2, str_3, str_4)
    assert var_0 == None


# Generated at 2022-06-25 08:50:35.176097
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    print('Test for CallbackModule_v2_runner_on_ok:')
    str_0 = '0_G|\\len`m6'
    bool_0 = False
    callback_module_0 = CallbackModule(bool_0)
    callback_v2_runner_on_ok(str_0)


# Generated at 2022-06-25 08:50:41.324684
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    bool_0 = True
    str_0 = '#]'
    bool_1 = False
    callback_module_0 = CallbackModule(bool_0)
    str_1 = '}'
    bool_2 = False
    result_0 = callback_v2_runner_on_ok(str_0, bool_1, bool_2)


# Generated at 2022-06-25 08:50:42.118332
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    pass


# Generated at 2022-06-25 08:50:46.518890
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = 'zzc%q3'
    bool_0 = True
    callback_module_0 = CallbackModule(bool_0)
    var_0 = callback_v2_runner_on_failed(str_0)


# Generated at 2022-06-25 08:50:49.224366
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    str_0 = '0_G|\\len`m6'
    assert_equal(str_0, CallbackModule.v2_runner_on_ok(str_0))



# Generated at 2022-06-25 08:50:52.658815
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    str_0 = '0_G|\\len`m6'
    bool_0 = True
    callback_module_0 = CallbackModule(bool_0)
    var_0 = callback_v2_runner_on_ok(str_0)


# Generated at 2022-06-25 08:50:57.120995
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    str_0 = 'z0CiP]o'
    bool_0 = True
    callback_module_0 = CallbackModule(bool_0)
    callback_v2_runner_on_ok(str_0)


# Generated at 2022-06-25 08:50:58.114797
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    test_case_0() # Unit Test 0


# Generated at 2022-06-25 08:51:01.683538
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    var_0 = get_random_bool()
    var_1 = CallbackModule(var_0)
    var_2 = get_random_str()
    var_1.v2_runner_on_failed(var_2)


# Generated at 2022-06-25 08:51:05.152548
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    bool_0 = False
    callback_module_0 = CallbackModule(bool_0)


# Generated at 2022-06-25 08:51:29.528209
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Create an instance of the CallbackModule class
    cb = CallbackModule()
    # Verify that we are testing the CallbackModule class
    assert (isinstance(cb, CallbackModule))
    # Verify that the instance has an attribute (field) called v2_runner_on_ok
    assert (hasattr(cb, 'v2_runner_on_ok'))
    # CallbackModule.v2_runner_on_ok should call AnsibleModule.get_bin_path once and AnsibleModule.run_command once
    from unittest.mock import call

# Generated at 2022-06-25 08:51:40.148571
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    int_0 = -1
    dict_0 = {'stderr': '\x11', 'rc': int_0}
    str_0 = 'L&jm\xc7u\xa0\x18V\x1e;\x0b\x1c'
    str_1 = '\xec\xf2\x07'
    str_2 = 'n\xfc\xbe\x1b\xbe\xb2\x00\x8b\xd0\xf0\x9a\xcb\x8d'
    dict_1 = {'stdout': str_0, 'stderr': str_1, 'rc': int_0}
    dict_2 = {}
    dict_3 = {'msg': str_2}

# Generated at 2022-06-25 08:51:43.118804
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = '0_G|\\len`m6'
    bool_0 = False
    callback_module_0 = CallbackModule(bool_0)
    var_0 = callback_module_0.v2_runner_on_failed(str_0)
    assert_equal(var_0, None)


# Generated at 2022-06-25 08:51:48.275263
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    bool_0 = False
    callback_module_0 = CallbackModule(bool_0)
    result_data_0 = None
    ignore_errors_0 = False
    var_0 = callback_module_0.v2_runner_on_failed(result_data_0, ignore_errors_0)
    assert var_0 == None


# Generated at 2022-06-25 08:51:52.098751
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    str_0 = '0_G|\\len`m6'
    bool_0 = False
    callback_module_0 = CallbackModule(bool_0)
    var_0 = callback_v2_runner_on_ok(str_0)


# Generated at 2022-06-25 08:51:53.968159
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

    bool_4 = True
    str_4 = '0_G|\\len`m6'
    bool_5 = False
    callback_module_4 = CallbackModule(bool_5)
    var_4 = callback_module_4.v2_runner_on_ok(str_4)


# Generated at 2022-06-25 08:51:56.161047
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule('G|\\len`m6')
    assert callback_module_0._display._verbosity is False
    assert callback_module_0.CALLBACK_TYPE is 'stdout'
    assert callback_module_0.CALLBACK_NAME is 'oneline'
    assert callback_module_0.CALLBACK_VERSION is 2.0


# Generated at 2022-06-25 08:51:59.076056
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    str_0 = '0_G|\\len`m6'
    bool_0 = False
    callback_module_0 = CallbackModule(bool_0)
    var_0 = callback_v2_runner_on_failed(str_0)


# Generated at 2022-06-25 08:52:02.859320
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    str_0 = ' ='
    bool_0 = False
    callback_module_0 = CallbackModule(bool_0)
    int_0 = callback_module_0.v2_runner_on_ok(str_0)


# Generated at 2022-06-25 08:52:11.960955
# Unit test for method v2_runner_on_failed of class CallbackModule

# Generated at 2022-06-25 08:52:55.456653
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    bool_0 = 0
    bool_1 = bool_0
    str_0 = '1_G|\\len`m6'
    int_0 = 6
    str_1 = '2_G|\\len`m6'
    str_2 = '3_G|\\len`m6'
    str_3 = '4_G|\\len`m6'
    bool_2 = bool_1
    bool_3 = bool_2
    bool_4 = bool_3
    bool_5 = bool_4
    bool_6 = bool_5
    bool_7 = bool_6
    bool_8 = bool_7
    callback_module_0 = CallbackModule(bool_8)
    var_0 = callback_v2_runner_on_failed(str_0)
    var_1 = callback_v

# Generated at 2022-06-25 08:52:59.862477
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = 'qKT5<5/{'
    bool_0 = False
    callback_module_0 = CallbackModule(bool_0)
    var_0 = callback_v2_runner_on_failed(str_0)
    from ansible.plugins.callback.oneline import test_case_0

# Test method for method v2_runner_on_ok of class CallbackModule

# Generated at 2022-06-25 08:53:05.813676
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    str_0 = '0_G|\\len`m6'
    bool_0 = False
    callback_module_0 = CallbackModule(bool_0)
    var_0 = callback_v2_runner_on_ok(str_0)


# Generated at 2022-06-25 08:53:07.182750
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule(False)


# Generated at 2022-06-25 08:53:13.746541
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    bool_0 = False
    str_0 = '4M}|\\Z<N@'
    bool_1 = True
    callback_module_0 = CallbackModule(bool_0)
    var_0 = callback_module_0._command_generic_msg(str_0, callback_module_0, bool_0)
    str_1 = '<o%c{'
    bool_2 = True
    var_1 = callback_module_0.v2_runner_on_failed(str_1, bool_1)
    var_2 = callback_module_0.v2_runner_on_ok(str_1)
    bool_3 = True
    str_2 = 'Tl%a_'
    bool_4 = True
    var_3 = callback_module_0.v2_runner_on_un

# Generated at 2022-06-25 08:53:16.680093
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert( isinstance(CallbackModule(), CallbackModule) )


# Generated at 2022-06-25 08:53:17.309587
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    arg = True
    variable = CallbackModule(arg)


# Generated at 2022-06-25 08:53:20.577780
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    str_0 = '0_G|\\len`m6'
    bool_0 = False
    callback_module_0 = CallbackModule(bool_0)
    var_0 = callback_v2_runner_on_ok(str_0)


# Generated at 2022-06-25 08:53:23.972203
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = 'I4F0W8VuB'
    bool_0 = False
    callback_module_0 = CallbackModule(bool_0)
    var_0 = callback_v2_runner_on_failed(str_0)


# Generated at 2022-06-25 08:53:31.160437
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Test ID='0_0' - Test case #0 component #0
    x = 0
    # Test ID='0_1' - Test case #0 component #1
    str_0 = '0_G|\\len`m6'
    # Test ID='0_2' - Test case #0 component #2
    bool_0 = False
    # Test ID='0_3' - Test case #0 component #3
    callback_module_0 = CallbackModule(bool_0)
    # Test ID='0_4' - Test case #0 component #4
    var_0 = callback_module_0.v2_runner_on_ok(str_0)


# Generated at 2022-06-25 08:55:09.730840
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = '#Yd0te/\\'
    bool_0 = False
    callback_module_0 = CallbackModule(bool_0)
    var_0 = callback_v2_runner_on_failed(str_0)
    assert var_0 == "FAILED! => %s" % str_0



# Generated at 2022-06-25 08:55:19.719222
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    bool_0 = False
    callback_module_0 = CallbackModule(bool_0)
    str_0 = 'P[#((6M'
    func_0 = getattr(callback_module_0, 'v2_runner_on_failed')
    tuple_0 = ('9j$pW4/v3', False)
    var_0 = func_0(tuple_0)
    lst_0 = [var_0, str_0, tuple_0]
    lst_0 = sorted(lst_0)
    return lst_0

if __name__ == '__main__':
    test_case_1()
    test_case_0()
    test_CallbackModule_v2_runner_on_failed()

# Retrieve the src attribute of the class "CallbackModule"
test_Callback

# Generated at 2022-06-25 08:55:26.975673
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    ansible = 'ansible'
    bool_0 = True
    bool_1 = True
    int_0 = 0
    int_1 = 0
    int_2 = 0
    runner_0 = Runner(bool_0, bool_1)
    result_0 = runner_0.v2_runner_on_failed(runner_0.result, runner_0.result, runner_0.result, runner_0.result, runner_0.result, runner_0.result)
    result_1 = runner_0.v2_runner_on_ok(runner_0.result, runner_0.result, runner_0.result, runner_0.result, runner_0.result, runner_0.result)

# Generated at 2022-06-25 08:55:31.216846
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = '5_G|\\len`m6'
    bool_0 = False
    callback_module_0 = CallbackModule(bool_0)
    var_0 = callback_v2_runner_on_failed(str_0)
    
    

# Generated at 2022-06-25 08:55:34.090736
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = '<f/C~/khA'
    bool_0 = False
    callback_module_0 = CallbackModule(bool_0)
    var_0 = callback_v2_runner_on_failed(str_0)



# Generated at 2022-06-25 08:55:38.411407
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # input
    # output
    return


# Generated at 2022-06-25 08:55:46.226110
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = 'MSJU6\'YU,p'
    str_1 = '.*'
    bool_0 = True
    str_2 = 'AW~'
    callback_module_0 = CallbackModule(bool_0)
    var_0 = callback_v2_runner_on_failed(str_0)
    float_0 = float(str_1)
    float_1 = float(str_2)
    float_2 = float_0 + float_1
    print(float_2)


# Generated at 2022-06-25 08:55:55.712026
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = '0'
    str_1 = '1'
    str_2 = '2'
    str_3 = '3'
    str_4 = '4'
    dict_0 = dict()
    dict_0[str_0] = str_1
    dict_0[str_2] = str_3
    dict_0[str_4] = str_2
    dict_0 = dict_0
    dict_1 = dict()
    dict_1[str_0] = dict_0
    dict_1[str_2] = dict_0
    dict_1[str_4] = dict_0
    dict_1 = dict_1
    dict_2 = dict()
    dict_2[str_0] = dict_1
    dict_2[str_2] = dict_1


# Generated at 2022-06-25 08:56:03.033075
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    
    try:
        test_case_0()
    except Exception as error:
        print(error)
    else:
        print('constructor OK')


if __name__ == '__main__':
    
    test_CallbackModule()

# Generated at 2022-06-25 08:56:03.911944
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    assert 1
