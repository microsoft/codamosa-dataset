

# Generated at 2022-06-25 08:48:50.235476
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    result_1 = None
    callback_module_1.v2_runner_on_failed(result_1)


# Generated at 2022-06-25 08:48:56.335067
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result = "result"
    callback_module_0.v2_runner_on_ok(result)


# Generated at 2022-06-25 08:49:02.856481
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_1 = CallbackModule()
    assert callback_module_1.CALLBACK_TYPE == 'stdout'
    assert callback_module_1.CALLBACK_VERSION == 2.0
    assert callback_module_1.CALLBACK_NAME == 'oneline'

# Generated at 2022-06-25 08:49:03.795120
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()

# Generated at 2022-06-25 08:49:09.967877
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result = ansible.runner.RunnerResult()
    result._host = ansible.inventory.host.Host('localhost')
    result._result = dict(changed=True)
    result._task = dict(action='ping')
    result._result['ansible_job_id'] = 'some_job_id'
    callback_module_0.v2_runner_on_ok(result)


# Generated at 2022-06-25 08:49:10.996119
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    if CallbackModule:
        assert True
    else:
        assert False


# Generated at 2022-06-25 08:49:13.018641
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = {'msg': 'hoge'}



# Generated at 2022-06-25 08:49:25.440687
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    print("In test_CallbackModule_v2_runner_on_ok")
    callback_module_0 = CallbackModule()
    result_0 = callback_module_0._dump_results(None)
    result_1 = callback_module_0._dump_results(None)
    assert result_0 == result_1
    result_2 = callback_module_0._dump_results(None)
    assert result_2 == result_1
    assert result_1 == result_2
    assert result_2 == result_1
    result_3 = callback_module_0._dump_results(None)
    assert result_3 == result_2
    assert result_3 == result_1
    result_4 = callback_module_0._dump_results(None)
    assert result_4 == result_3
    assert result_3 == result_

# Generated at 2022-06-25 08:49:30.770629
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_object = CallbackModule()
    # TODO : Create "result" object and call function with it.
    #callback_module_object.v2_runner_on_failed(result, ignore_errors=False)


# Generated at 2022-06-25 08:49:32.268997
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    try:
        test_case_0()
    except:
        assert False



# Generated at 2022-06-25 08:49:39.327486
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    callback_v2_runner_on_fail(callback_module_0)


# Generated at 2022-06-25 08:49:43.086506
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed;
    del var_0
    return var_0


# Generated at 2022-06-25 08:49:51.488645
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result_0 = dict()
    result_0["_result"] = dict()
    result_0["_result"]["changed"] = False
    result_0["_task"] = dict()
    result_0["_task"]["action"] = "shell"
    result_0["_host"] = dict()
    result_0["_host"]["get_name"] = "get_name"
    callback_module_0.v2_runner_on_ok(result_0)

# Generated at 2022-06-25 08:49:54.089234
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module = CallbackModule()
    assert callback_module.CALLBACK_NAME == 'oneline'
    assert callback_module.CALLBACK_VERSION == 2.0
    assert callback_module.CALLBACK_TYPE == 'stdout'


# Generated at 2022-06-25 08:49:57.969254
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    runner_result = {'failed': True,
                     'changed': False,
                     'rc': 0
                     }
    callback_module = CallbackModule()
    callback_module.v2_runner_on_failed(runner_result)

# Generated at 2022-06-25 08:50:00.220987
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    var_0 = CallbackModule()


# Generated at 2022-06-25 08:50:01.394495
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Run method
    test_case_0()


# Generated at 2022-06-25 08:50:06.053233
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Create a CallbackModule object
    callback_module_0 = CallbackModule()

    # Call method v2_runner_on_ok
    result = callback_module_0.v2_runner_on_ok(result=None)

    # Check if the result is correct
    assert result == None



# Generated at 2022-06-25 08:50:14.814885
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    hostname_0 = 'nodec1'
    changed_0 = false
    color_0 = 'GREEN'
    action_0 = 'nop'
    callback_module_0 = CallbackModule()
    result_0 = Result('nodec1')
    result_0.set_task(action_0)
    result_0.set_host(hostname_0)
    result_0._result['changed'] = changed_0
    msg_0 = "{} | {} => {}".format(hostname_0, 'SUCCESS', result_0._result)
    callback_module_0.v2_runner_on_ok(result_0)
    assert callback_module_0._display.msg == msg_0 and callback_module_0._display.color == color_0

# Generated at 2022-06-25 08:50:17.796242
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result_0 = AnsibleResult()
    callback_module_0.v2_runner_on_ok(result_0)


# Generated at 2022-06-25 08:50:31.438109
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    import mock
    import os
    import sys
    import ansible.utils.context_objects as context_objects
    import ansible.plugins.callback
    import ansible.errors

    # Mock class MockedModuleReturnValue
    base_class_module_return_value = ansible.plugins.callback.CallbackBase
    class MockedModuleReturnValue:
        def get_name(self):
            return 'local'

    # Mock class MockedDisplay
    base_class_display = ansible.plugins.callback.CallbackBase
    class MockedDisplay:
        # Mock method _dump_results
        def _dump_results(self, indent=0):
            return 'test dump_results'

    # Mock class MockedCallbackBase with class MockedDisplay
    base_class = ansible.plugins.callback.CallbackBase

# Generated at 2022-06-25 08:50:31.968087
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    test_case_0()


# Generated at 2022-06-25 08:50:38.175386
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # construct mode_0 of type CallbackModule
    mode_0 = CallbackModule()
    assert CallbackModule.CALLBACK_VERSION == 2.0
    assert CallbackModule.CALLBACK_TYPE == 'stdout'
    assert CallbackModule.CALLBACK_NAME == 'oneline'
    assert mode_0 is not None


# Generated at 2022-06-25 08:50:48.766441
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    # Create and initialize the class instances for this test case
    callback_module_0 = CallbackModule()
    # Create and initialize the class instances for this test case
    result_0 = Result()
    result_0._result = {
        'changed': True,
        'invocation': {
            'module_args': '',
            'module_name': 'setup'
        }
    }
    result_0._task = {'action': 'setup', 'loop': 'all', 'name': 'Gather Facts'}
    result_0._host = {'name': 'server-0', 'id': 'server-0'}
    # Call the method with required arguments
    callback_module_0.v2_runner_on_ok(result_0)


# Generated at 2022-06-25 08:50:51.909554
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = v2_runner_on_failed(callback_module_0)
    ignore_errors_0 = bool()
    assert_equal(result_0, True)


# Generated at 2022-06-25 08:50:55.976843
# Unit test for constructor of class CallbackModule

# Generated at 2022-06-25 08:50:59.224411
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module = CallbackModule()
    expected = 'expected'
    result = expected
    ignore_errors = False
    assert callback_module.v2_runner_on_failed(result, ignore_errors) == expected


# Generated at 2022-06-25 08:51:02.591705
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    result_1 = ''
    ignore_errors = False
    callback_module_1.v2_runner_on_failed(result_1, ignore_errors)


# Generated at 2022-06-25 08:51:09.670444
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    # Testing if the variable is not initialized
    try:
        assert callback_module_0._display.verbosity != 0
    except AttributeError:
        pass
    except:
        raise
    else:
        pass
    # Testing the type of an if condition (line 42)
    if hasattr(callback_module_0, '_display') and callback_module_0._display.verbosity < 3:
        pass
    else:
        pass


# Generated at 2022-06-25 08:51:13.060413
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(callback_module_0)
    if var_0:
        print ("test_CallbackModule_v2_runner_on_ok has failed!")
        # return
    if var_0:
        print ("test_CallbackModule_v2_runner_on_ok has failed!")
        # return


# Generated at 2022-06-25 08:51:33.946015
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_11 = CallbackModule()
    var_11 = callback_v2_runner_on_failed(callback_module_11)


# Generated at 2022-06-25 08:51:38.261056
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    with pytest.raises(TypeError) as excinfo:
        callback_module_0.__init__(callback_module_0)
    assert "function takes exactly 1 argument (2 given)" in str(excinfo.value)



# Generated at 2022-06-25 08:51:39.778717
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_ok()


# Generated at 2022-06-25 08:51:45.264610
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Setup
    callback_module_0 = CallbackModule()
    result_0 = Mock()

    # Invoke method
    callback_module_0.v2_runner_on_ok(result_0)

    # Tests
    # Assertions
    assert len(Mock.mock_calls) == 2


# Generated at 2022-06-25 08:51:55.856765
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = ''
    ignore_errors_0 = ''
    # This is for the purpose to debug and run the test case individually
    if C.TEST_CASE_ON_DEMAND == True :
        for param in test_case_0.__dict__:
            if param.startswith('result_'):
                result_0 = test_case_0.__dict__[param]
            if param.startswith('ignore_errors_'):
                ignore_errors_0 = test_case_0.__dict__[param]
        var_0 = callback_module_0.v2_runner_on_failed(result_0, ignore_errors_0)
        assert (var_0 == 0)

# Generated at 2022-06-25 08:51:58.360926
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module = CallbackModule()
    result = CallResult()
    ignore_errors = True
    callback_module.v2_runner_on_failed(result, ignore_errors)



# Generated at 2022-06-25 08:52:00.063099
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(callback_module_0)
    assert 'False' == var_0


# Generated at 2022-06-25 08:52:02.563547
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    # calling the method of class directly
    var_0 = callback_module_0.v2_runner_on_ok()



# Generated at 2022-06-25 08:52:07.148334
# Unit test for constructor of class CallbackModule

# Generated at 2022-06-25 08:52:10.106697
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module = CallbackModule()
    assert callback_module.CALLBACK_VERSION == 2.0
    assert callback_module.CALLBACK_TYPE == 'stdout'
    assert callback_module.CALLBACK_NAME == 'oneline'



# Generated at 2022-06-25 08:52:51.936693
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert callable(CallbackModule)


# Generated at 2022-06-25 08:52:53.957775
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_01 = CallbackModule()
    result_01 = callback_module_01.v2_runner_on_failed(result)



# Generated at 2022-06-25 08:53:00.167583
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    ok_var = CallbackModule()
    ok_var._display.verbosity = 0

# Generated at 2022-06-25 08:53:05.612710
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callbackModule = CallbackModule()
    result = callbackModule.v2_runner_on_ok({'_task': {'action': 'debug'}, '_result': {'changed': False}})
    assert result == None


# Generated at 2022-06-25 08:53:09.822937
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Test with the following arguments
    callback_module_0 = CallbackModule()
    #from ansible.plugins.callback.oneline import CallbackModule
    ansible_0 = AnsibleRunner(callback=callback_module_0)
    ansible_0.run()
    # TODO: TEST
    #assert var_1 == val_1



# Generated at 2022-06-25 08:53:21.164568
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Setup mock arguments
    result = Mock()

    # Setup test data
    # result._result.get('changed', False) = False
    # result._task.action = "action"
    # result._result = {'foobar': 3.2}
    # result._host.get_name() = "hostname"
    # result._task.action = "action"
    # result._result.get('changed', False) = True
    # result._task.action = "action"
    # result._result.get('changed', False) = False
    # result._result = {'foobar': 3.2}
    # result._host.get_name() = "hostname"
    # result._task.action = "action"

    # Invoke method
    ret_val = callback_module_0.v2_runner_on_

# Generated at 2022-06-25 08:53:24.541053
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    try:
        assert callback_module.__class__.__name__ == 'CallbackModule'
    except AssertionError as e:
        print('AssertionError: ', e)
    except:
        print('An exception flew by!')


# Generated at 2022-06-25 08:53:27.569589
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_1 = CallbackModule()
    var_1 = type(callback_module_1.CALLBACK_TYPE)
    result = (type(var_1) == type(''))
    assert result


# Generated at 2022-06-25 08:53:33.606683
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Create a new instance of class CallbackModule
    callback_module_0 = CallbackModule()
    # Create a new instance of class BaseHost
    base_host_0 = BaseHost()
    # Create a new instance of class TaskResult
    task_result_0 = TaskResult()
    task_result_0._host = base_host_0
    task_result_0._result = null
    task_result_0._task = null
    # Call method v2_runner_on_ok of class CallbackModule with parameter task_result_0
    var_0 = callback_module_0.v2_runner_on_ok(task_result_0)


# Generated at 2022-06-25 08:53:37.017216
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0._display
    var_1 = callback_module_0.v2_runner_on_ok(var_0)
    assert isinstance(var_1, None)
    assert isinstance(var_0, )


# Generated at 2022-06-25 08:55:25.140802
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    #we get an ok result with a changed module
    result = result().get_object()
    result._result.Changed = True
    result._task.action = "copy"
    callback_module_0.v2_runner_on_ok(result)
    #we get an ok result with an unchanged module
    result._result.Changed = False
    result._task.action = "command"
    callback_module_0.v2_runner_on_ok(result)


# Generated at 2022-06-25 08:55:27.233889
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    var_1 = callback_v2_runner_on_failed(callback_module_1)


# Generated at 2022-06-25 08:55:31.593403
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = Result()
    ignore_errors_0 = False
    var_0 = callback_module_0.v2_runner_on_failed(result_0, ignore_errors_0)


# Generated at 2022-06-25 08:55:32.699904
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()

# Generated at 2022-06-25 08:55:34.512136
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    var_1 = callback_v2_runner_on_failed(callback_module_1)


# Generated at 2022-06-25 08:55:40.131763
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Setup
    callback_module = CallbackModule()

    class MockVars(object):
        def __init__(self, changed, result):
            self._result = MockResult(changed, result)

    class MockResult(object):
        def __init__(self, changed, result):
            self.get = MockGet(changed, result)

    class MockGet(object):
        def __init__(self, changed, result):
            self.changed = changed
            self.result = result

        def __call__(self, *args, **kwargs):
            if args[0] == 'changed':
                return self.changed
            else:
                return self.result

    class MockTask(object):
        def __init__(self):
            self.action = C.MODULE_NO_JSON


# Generated at 2022-06-25 08:55:42.980116
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:55:46.374212
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = RunnerResult()
    # TODO: finish this unit test


# Generated at 2022-06-25 08:55:48.893243
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:55:51.201095
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    var_1 = callback_v2_runner_on_failed(callback_module_0)
