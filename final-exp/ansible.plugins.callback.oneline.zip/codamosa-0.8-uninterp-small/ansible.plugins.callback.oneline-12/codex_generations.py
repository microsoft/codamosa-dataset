

# Generated at 2022-06-25 08:48:55.735546
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = {
        'changed': False,
        'rc': 0,
    }
    ignore_errors_0 = True
    assert_equal(CallbackModule._command_generic_msg(callback_module_0, 'hostname_0', result_0, 'caption_0'), 'hostname_0 | caption_0 | rc=0 | (stdout)  (stderr) ')
    assert_equal(callback_module_0.v2_runner_on_failed(result_0, ignore_errors_0={'exception': 'exception_0'}, verbosity={'verbosity': 1}), 'An exception occurred during task execution. To see the full traceback, use -vvv. The error was: exception_0')

# Generated at 2022-06-25 08:48:57.200331
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()


if __name__ == '__main__':
    test_CallbackModule()

# Generated at 2022-06-25 08:49:01.484726
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module = CallbackModule()
    callback_module.v2_runner_on_ok(result=None)


# Generated at 2022-06-25 08:49:08.018746
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result_0 = {'msg': 'test_pretty_failed'}
    callback_module_0.v2_runner_on_failed(result_0)

    result_1 = {'msg': 'test_pretty_ok'}
    callback_module_0.v2_runner_on_ok(result_1)


# Generated at 2022-06-25 08:49:13.447152
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result = dict(host_name='host_name_0', task_name='task_name_0')
    callback_module_0.v2_runner_on_failed(result)


# Generated at 2022-06-25 08:49:22.404707
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    """Test v2_runner_on_failed of class CallbackModule."""
    callback_module_1 = CallbackModule()
    result_value = {"failed": True, "exception": "", "msg": "exception"}
    result_name = "result"
    result = type(result_name, (object,), result_value)
    result._result = result_value
    result._task = result_value
    result._host = result_value
    callback_module_1.v2_runner_on_failed(result)

# Generated at 2022-06-25 08:49:28.092933
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()

    # Test with valid data
    result_0 = {'changed': False, 'start': '2018-06-06 09:55:43.297855', 'end': '2018-06-06 09:55:43.297929', 'invocation': {'module_args': '', 'module_name': 'hostname'}}
    callback_module_0.v2_runner_on_ok(result_0)


# Generated at 2022-06-25 08:49:37.812743
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Define a dict containing inputs and expected results.
    inputs = [
        # input: (result._host.get_name(), result._result), expected result: msg
        ('host', {})
    ]
    outputs = [
        # msg
        'host | SUCCESS => {}'
    ]

    for i, o in zip(inputs, outputs):
        result = {'_host': {'get_name': lambda: i[0]}, '_result': i[1]}
        # Instantiate the class.
        callback_module_0 = CallbackModule()
        # Call the method with the appropriate args.
        msg = callback_module_0.v2_runner_on_ok(result)
        # Validate the results.
        assert msg == o


# Generated at 2022-06-25 08:49:40.498578
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    result_0 = dict()
    result_0['exception'] = 'An exception occurred during task execution. The full traceback is:\n' + result._result['exception'].replace('\n', '')
    # Test case where condition 'if 'exception' in result._result' is true
    CallbackModule().v2_runner_on_failed(result_0, ignore_errors=False)
    # Test case where condition 'if 'exception' in result._result' is false
    CallbackModule().v2_runner_on_failed(result_0, ignore_errors=True)


# Generated at 2022-06-25 08:49:42.492898
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    test_case_0()
    result = Result('hostname', '{"changed": false}')
    assert CallbackModule().v2_runner_on_ok(result) == "hostname | SUCCESS => {'changed': False}"



# Generated at 2022-06-25 08:49:51.451477
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    pass

# Generated at 2022-06-25 08:49:54.229474
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = {}
    ignore_errors_0 = False
    callback_module_0.v2_runner_on_failed(result_0, ignore_errors_0)


# Generated at 2022-06-25 08:49:56.106916
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    result_0 = CallbackModule.CallbackBase.v2_runner_on_ok(None, None)


# Generated at 2022-06-25 08:49:57.514052
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule is not None


# Generated at 2022-06-25 08:50:04.791416
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed(result, ignore_errors=False)
    callback_module_0.v2_runner_on_ok(result)
    callback_module_0.v2_runner_on_unreachable(result)
    callback_module_0.v2_runner_on_skipped(result)

# Generated at 2022-06-25 08:50:07.440549
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Arrange
    callback_module_0 = CallbackModule()
    # TODO: extract 'changed' key from value of variable result._result
    # Act
    # Assert


# Generated at 2022-06-25 08:50:11.043678
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = Result()
    ignore_errors_0 = False
    callback_module_0.v2_runner_on_failed(result_0, ignore_errors_0)


# Generated at 2022-06-25 08:50:16.092598
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    test_case_0()
    callback_module_0 = CallbackModule()
    assert callback_module_0.callback_name == 'oneline'

# Generated at 2022-06-25 08:50:17.002048
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert callable(CallbackModule)

# Generated at 2022-06-25 08:50:23.888830
# Unit test for method v2_runner_on_ok of class CallbackModule

# Generated at 2022-06-25 08:50:35.071769
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()

    with pytest.raises(Exception):
        callback_module_1 = CallbackModule()
    

# Generated at 2022-06-25 08:50:37.869823
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:50:41.397246
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = Result()
    ignore_errors_0 = False
    var_0 = callback_module_0.v2_runner_on_failed(result_0, ignore_errors_0)


# Generated at 2022-06-25 08:50:43.775675
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Set up mock
    set_0 = {'undefined_variable': undefined_variable, 'result': result}
    callback_module_0 = CallbackModule()

    # Call method
    callback_v2_runner_on_ok(result)

# Generated at 2022-06-25 08:50:47.401997
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert callback_module_0.CALLBACK_VERSION == 2.0
    assert callback_module_0.CALLBACK_TYPE == 'stdout'
    assert callback_module_0.CALLBACK_NAME == 'oneline'


# Generated at 2022-06-25 08:50:51.384499
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    bytes_0 = b'\xdb\xf5'
    callback_module_0 = CallbackModule()
    class_0 = bool
    var_0 = callback_module_0.v2_runner_on_failed(bytes_0, class_0, class_0)
    callback_module_1 = CallbackModule()


# Generated at 2022-06-25 08:50:56.274510
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    bytes_0 = b'\x03\xcb'
    set_0 = {bytes_0, bytes_0, bytes_0}
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(set_0)


# Generated at 2022-06-25 08:51:01.498216
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    bytes_0 = b'\x03\xcb'
    set_0 = {bytes_0, bytes_0, bytes_0}
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_unreachable(set_0)
    assert isinstance(var_0, CallbackModule) == True


# Generated at 2022-06-25 08:51:07.931002
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    new_0 = CallbackModule()
    set_0 = {new_0}

    # Call method v2_runner_on_ok of class CallbackModule
    new_0.v2_runner_on_ok(set_0)


# Generated at 2022-06-25 08:51:10.242284
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_unreachable(result_0)
    var_0 = callback_v2_runner_on_ok(result_0)


# Generated at 2022-06-25 08:51:29.861514
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Create an instance of class CallbackModule
    callback_module = CallbackModule()

    # Create an instance of class RunnerResult
    runner_result = RunnerResult()

    # Create an instance of class RunnerCallback
    runner_callback = RunnerCallbacks()

    # Call method v2_runner_on_ok
    v2_runner_on_ok(runner_result)


# Generated at 2022-06-25 08:51:36.293698
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    bytes_0 = b'\x03\xcb'
    set_0 = {bytes_0, bytes_0, bytes_0}
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_unreachable(set_0)
    callback_module_1 = CallbackModule()

# Generated at 2022-06-25 08:51:37.901900
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    #Test case for definition of constructor with one parameter
    test_case_0()


# Generated at 2022-06-25 08:51:41.256541
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    bytes_0 = b'\x03\xcb'
    set_0 = {bytes_0, bytes_0, bytes_0}
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_unreachable(set_0)
    callback_module_1 = CallbackModule()
# END

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 08:51:42.932818
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_2 = CallbackModule()
    res_0 = callback_module_2.v2_runner_on_ok(set_0)
    assert res_0 is None


# Generated at 2022-06-25 08:51:47.552932
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    var_0 = b'\x02\xcc'
    try:
        var_1 = v2_runner_on_failed(callback_module_0, var_0)
    except Exception as e:
        pass


# Generated at 2022-06-25 08:51:55.779631
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    bytes_0 = b'\x03\xcb'
    set_0 = {bytes_0, bytes_0, bytes_0}
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(set_0)

    # Benchmark Ansible callbacks
    import timeit
    import cProfile
    for x in range(1) :
        timeit.timeit(stmt="test_case_0",setup="from __main__ import test_case_0", number=100 )
    #cProfile.run('test_case_0()')


# Generated at 2022-06-25 08:51:59.674255
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    bytes_0 = b'\x03\xcb'
    set_0 = {bytes_0, bytes_0, bytes_0}
    callback_module_0 = CallbackModule()
    bytes_0 = b'\x03\xcb'
    set_0 = {bytes_0, bytes_0, bytes_0}
    callback_module_1 = CallbackModule()


# Generated at 2022-06-25 08:52:07.100792
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():

    # Case 0: Exception thrown
    # TODO: assert that of the three sets, one is actually processed
    bytes_0 = b'\x03\xcb'
    set_0 = {bytes_0, bytes_0, bytes_0}
    callback_module_0 = CallbackModule()
    with pytest.raises(Exception):
        callback_module_0.v2_runner_on_failed(set_0)

    # Case 1: normal execution
    bytes_1 = b'\x03\xcb'
    dict_0 = {'x': bytes_1}
    set_1 = {bytes_1, dict_0, bytes_1}
    callback_module_1 = CallbackModule()
    callback_module_1.v2_runner_on_failed(set_1)


# Generated at 2022-06-25 08:52:11.451605
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # TODO: Change this test case to check results of v2_runner_on_ok
    bytes_0 = b'\x03\xcb'
    set_0 = {bytes_0, bytes_0, bytes_0}
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(set_0)
    callback_module_1 = CallbackModule()


# Generated at 2022-06-25 08:52:54.965151
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    bytes_0 = b'\x03\xcb'
    set_0 = {bytes_0, bytes_0, bytes_0}
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_unreachable(set_0)
    callback_module_1 = CallbackModule()

if __name__ == "__main__":
    import sys
    import logging
    logging.basicConfig(stream=sys.stderr)
    logging.getLogger(__name__).setLevel(logging.DEBUG)

# Generated at 2022-06-25 08:53:03.066404
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    import unittest
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars

    class DummyHost(Host):
        def get_name(self):
            return "dummy"

    class DummyHostVars(HostVars):
        def __init__(self):
            self.result = {
                'changed': False
            }
            self.task = {
                'action': 'dummy'
            }

    class TestCallbackModule(unittest.TestCase):
        def setUp(self):
            self.display = None
            self.callback_module = CallbackModule()

        def test_v2_runner_on_ok(self):
            class DummyDisplay(object):
                last_displayed = None


# Generated at 2022-06-25 08:53:09.675982
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    bytes_0 = bytes(b'\x9a\x8c\xf0\xcf\xa3')
    set_0 = {bytes_0, bytes_0, bytes_0}
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(set_0)
    callback_module_1 = CallbackModule()


# Generated at 2022-06-25 08:53:13.355521
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    bytes_0 = b'\x03\xcb'
    set_0 = {bytes_0, bytes_0, bytes_0}
    dummy_0 = Dummy()
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(set_0, True)
    callback_module_1 = CallbackModule()
    callback_module_1.v2_runner_on_failed(set_0, True)


# Generated at 2022-06-25 08:53:19.526221
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    bytes_0 = b'\x03\xcb'
    set_0 = {bytes_0, bytes_0, bytes_0}
    callback_module_0 = CallbackModule()
    result_0 = callback_module_0.ansible_version
    result_1 = callback_module_0.CALLBACK_VERSION
    result_2 = callback_module_0.CALLBACK_NAME
    result_3 = callback_module_0.CALLBACK_TYPE
    var_0 = callback_module_0.v2_runner_on_unreachable(set_0)

# Generated at 2022-06-25 08:53:26.517263
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # define a variable dict to pass the test, but it's not used
    result = {"changed": True, "invocation": {"module_args": {"host": "0.0.0.0", "port": "22", "username": "root", "password": "123", "private_key": "priv.key", "timeout": 30}}}
    # define a variable to create an object of CallbackModule
    callback = CallbackModule()
    # use the function to test
    callback.v2_runner_on_ok(result)  # there is not return, I can't judge whether it passes or not


# Generated at 2022-06-25 08:53:29.660052
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    # Test no exception is raised
    callback_module_0.v2_runner_on_failed(result())


# Generated at 2022-06-25 08:53:33.904865
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    bytes_0 = b'\x03\xcb'
    set_0 = {bytes_0, bytes_0, bytes_0}
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0._display = {set_0}
    var_1 = callback_module_0.__init__()
    var_2 = callback_module_0._display = null
    assert callback_module_0._display == null


# Generated at 2022-06-25 08:53:37.617466
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    bytes_0 = b'\x03\xcb'
    set_0 = {bytes_0, bytes_0, bytes_0}
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(set_0)
    callback_module_1 = CallbackModule()


# Generated at 2022-06-25 08:53:43.634355
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    bytes_0 = b'\x03\xcb'
    list_0 = [bytes_0, bytes_0, bytes_0]
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(list_0)
    callback_module_1 = CallbackModule()
    var_1 = callback_v2_runner_on_ok(list_0)


# Generated at 2022-06-25 08:55:27.525136
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    bytes_0 = b'\x00\xfe'
    bytes_1 = b'\xf7\x04'
    bytes_2 = b'\x1b'
    bytes_3 = b'\xee\xc5\x1f'
    bytes_4 = b'\x02\xfe\x05'
    bytes_5 = b'\xb7\x0d\x9f\xcf\x13\x10'
    bytes_6 = b'\x00\x10\x00\x06'
    bytes_7 = b'\x1d'
    bytes_8 = b'\xd7\x08\xe6\x9f\x11\x10'
    bytes_9 = b'\x00\x04\x00\x04'

# Generated at 2022-06-25 08:55:33.921875
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_2 = CallbackModule()
    caplog_1 = caplog()
    callback_module_2.v2_runner_on_unreachable({})
    assert len(caplog_1.records) == 1
    caplog_2 = caplog()
    callback_module_2.v2_runner_on_unreachable({})
    assert len(caplog_2.records) == 2


# Generated at 2022-06-25 08:55:43.192498
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    var_0 = '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-25 08:55:46.275439
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    bytes_0 = b'\x03\xcb'
    set_0 = {bytes_0, bytes_0, bytes_0}
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(set_0)
    callback_module_1 = CallbackModule()


# Generated at 2022-06-25 08:55:50.483491
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    bytes_0 = b'\x03\xcb'
    set_0 = {bytes_0, bytes_0, bytes_0}
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:55:54.880301
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    task_0 = Task()
    host_0 = Host(task=task_0)
    result_0 = Result(host=host_0)
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(result_0)
    callback_module_1 = CallbackModule()

# Generated at 2022-06-25 08:56:02.070008
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    bytes_0 = b'\xac\x9c'
    bytes_1 = b'\x1d'
    bytes_2 = b'\xc8\xcc'
    bytes_3 = b'\x1d'
    bytes_4 = b'\x14\xc8'
    set_0 = {bytes_3, bytes_3, bytes_3}
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_unreachable(set_0)
    callback_module_1 = CallbackModule()


# Generated at 2022-06-25 08:56:05.011322
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    set_0 = {b'\xcec'}
    var_0 = CallbackModule()
    callback_v2_runner_on_ok(var_0, set_0)


# Generated at 2022-06-25 08:56:10.024944
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    bytes_0 = b'\x03\xcb'
    set_0 = {bytes_0, bytes_0, bytes_0}
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.callbacks()
    var_1 = callback_module_0.runner_on_failed(set_0)
    callback_module_1 = CallbackModule()

# Generated at 2022-06-25 08:56:12.983747
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    # skipped
