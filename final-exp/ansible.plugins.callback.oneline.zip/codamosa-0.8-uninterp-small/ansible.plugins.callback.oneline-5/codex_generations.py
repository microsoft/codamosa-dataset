

# Generated at 2022-06-25 08:48:51.265998
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = {}
    ignore_errors_0 = False
    callback_module_0.v2_runner_on_failed(result_0, ignore_errors_0)


# Generated at 2022-06-25 08:49:00.629756
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

    ansible_module = CallbackModule()
    ansible_result = {"changed": False, "invocation": {"module_args": {"module_name": "setup", "_uses_shell": False, "_raw_params": "", "_hostname": "localhost", "_ansible_module_name": "setup", "_ansible_no_log": False, "_ansible_debug": False, "_ansible_verbosity": 4, "_ansible_syslog_facility": "LOG_USER", "_ansible_selinux_special_fs": ["fuse", "nfs", "vboxsf", "ramfs", "9p"], "_ansible_diff": True, "_ansible_version": "2.5.1", "_ansible_version_info": [2, 5, 1, 0, 0, 'final', 0], "filter": "*"}}}


# Generated at 2022-06-25 08:49:09.605515
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # create an instance of class CallbackModule
    callback_module_0 = CallbackModule()

    # create an instance of class Result
    result_0 = Result()

    # call the v2_runner_on_ok method of callback_module_0 instance
    return_value_0 = callback_module_0.v2_runner_on_ok(result_0)

    # check the value returned by method v2_runner_on_ok of callback_module_0 instance
    assert return_value_0 == None


# Generated at 2022-06-25 08:49:10.995530
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result_0 = {}
    callback_module_0.v2_runner_on_ok(result_0)


# Generated at 2022-06-25 08:49:11.577869
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    assert True

# Generated at 2022-06-25 08:49:13.706361
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    try:
        callback_module_0 = CallbackModule()
    except TypeError as e:
        assert False, "Failed to create an object of class CallbackModule"


# Generated at 2022-06-25 08:49:15.084275
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_v2_runner_on_failed = CallbackModule()


# Generated at 2022-06-25 08:49:23.931716
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result_0 = mock.Mock()
    type(result_0)._host = mock.PropertyMock(return_value=mock.Mock())
    type(result_0)._result = mock.PropertyMock(return_value='changed')
    type(result_0)._task = mock.PropertyMock(return_value=mock.Mock())
    type(result_0)._task.action = mock.PropertyMock(return_value='debug')
    type(result_0._task).action = mock.PropertyMock(return_value='debug')
    callback_module_0.v2_runner_on_ok(result_0)


# Generated at 2022-06-25 08:49:34.985947
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()

# Generated at 2022-06-25 08:49:36.719129
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    pass

# Generated at 2022-06-25 08:49:42.978945
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    str_0 = '?F?\\Q&j\x0b`QB+EWb\x0bk\x0cW'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(str_0)


# Generated at 2022-06-25 08:49:50.367625
# Unit test for method v2_runner_on_failed of class CallbackModule

# Generated at 2022-06-25 08:49:53.967392
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule(_display=display_0)
    assert callback_module_0.CALLBACK_NAME == 'oneline'
    assert callback_module_0.CALLBACK_VERSION == 2.0
    assert callback_module_0.CALLBACK_TYPE == 'stdout'


# Generated at 2022-06-25 08:49:58.641106
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert(len(callback_module_0.CALLBACK_VERSION) > 0)
    assert(len(callback_module_0.CALLBACK_TYPE) > 0)
    assert(len(callback_module_0.CALLBACK_NAME) > 0)


# Generated at 2022-06-25 08:50:01.493955
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert callback_module_0.CALLBACK_VERSION == 2.0
    assert callback_module_0.CALLBACK_TYPE == 'stdout'
    assert callback_module_0.CALLBACK_NAME == 'oneline'


# Generated at 2022-06-25 08:50:05.470298
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    str_0 = '?F?\\Q&j\x0b`QB+EWb\x0bk\x0cW'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(str_0)
    var_1 = callback_v2_runner_on_failed(str_0)
    var_2 = callback_v2_runner_on_unreachable(str_0)
    var_3 = callback_v2_runner_on_skipped(str_0)

# Generated at 2022-06-25 08:50:06.336211
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    test_case_0()

# Generated at 2022-06-25 08:50:14.458568
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    print('Testing method v2_runner_on_failed of class CallbackModule')
    # Test with a value for ignore_errors = False and True

    print('Test with a value for ignore_errors = True')
    # Append commandline arguments to test cases
    # Example: '-k'
    # Test with a value for ignore_errors = False

    print('Test with a value for ignore_errors = False')
    # Append commandline arguments to test cases
    # Example: '-k'
    # Test with a value for ignore_errors = True

    print('Test with a value for ignore_errors = True')
    # Append commandline arguments to test cases
    # Example: '-k'



# Generated at 2022-06-25 08:50:18.769540
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    str_0 = '?F?\\Q&j\x0b`QB+EWb\x0bk\x0cW'
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_ok(str_0)


# Generated at 2022-06-25 08:50:19.980407
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    var_1 = CallbackModule()
    assert var_1 != None

# Generated at 2022-06-25 08:50:38.047553
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

    # Initialize callbacks
    str_1 = 'j\x0b\x0bk\x0c'
    num_1 = 100.0
    str_2 = '?F?\\Q&j\x0b`QB+EWb\x0bk\x0cW'
    str_3 = 'xo^CSH\x0c\x0e'
    num_2 = 0
    num_3 = 0.0
    str_4 = '\x0c'
    str_5 = '\\e^\\'
    str_6 = '\x0b'
    str_7 = 'Z\x0c\x0e'
    str_8 = '|[\x0e\\W'
    num_4 = 0
    str_9 = 'W\\]\x0c'

# Generated at 2022-06-25 08:50:39.990852
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert callable(CallbackModule)

if __name__ == "__main__":
    pytest.main()

# Generated at 2022-06-25 08:50:43.334912
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = 'Z'
    str_1 = 'q_\x0b\x0c'
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(str_0, str_1)
    assert var_0 != 1


# Generated at 2022-06-25 08:50:51.245149
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

    test = CallbackModule()
    test._display = Mock()
    test._dump_results = Mock()

    # class _result:
    #     _host = None
    #     _result = None
    #     _task = None

    result = Mock()
    result._host.get_name.return_value = 'hostname'
    result._result.get.return_value = 'result'
    result._task.action = 'action'

    # test v2_runner_on_ok
    test.v2_runner_on_ok(result)

    test._display.display.assert_called_with('hostname | result => {"changed": false}', color='green')


# Generated at 2022-06-25 08:50:56.979639
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = 'd\x13\x1b\x17d\x11\x12\x12H'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(str_0, True)
    var_0 = callback_v2_runner_on_failed(str_0, False)

# Generated at 2022-06-25 08:50:57.609473
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    assert type(var_0) == str
    assert var_0 == 'F'

# Generated at 2022-06-25 08:51:02.690408
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    print('in test_CallbackModule')
    test_case_0()

###############################################################################
# Boilerplate
###############################################################################

if __name__ == '__main__':
    print('Testing %s' % __file__)
    print('Uncomment the line below to run individual test cases')
    #test_CallbackModule()
    print('Unit tests for this file completed')

# Generated at 2022-06-25 08:51:03.320234
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    CallbackModule()


# Generated at 2022-06-25 08:51:09.127817
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.CALLBACK_NAME
    var_1 = callback_module_0.CALLBACK_TYPE
    var_2 = callback_module_0.CALLBACK_VERSION

# TO-DO: set up ansible and test this functionality
if __name__ == '__main__':
    test_CallbackModule()

# Generated at 2022-06-25 08:51:10.102577
# Unit test for constructor of class CallbackModule
def test_CallbackModule():

    # Call constructor of class CallbackModule
    CallbackModule()


# Generated at 2022-06-25 08:51:29.834993
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # str_0 = '?F?\\Q&j\x0b`QB+EWb\x0bk\x0cW'
    # callback_module_0 = CallbackModule()
    # var_0 = callback_v2_runner_on_ok(str_0)
    assert True # TODO: implement your test here


# Generated at 2022-06-25 08:51:35.926758
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = '?F?\\Q&j\x0b`QB+EWb\x0bk\x0cW'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(str_0)


# Generated at 2022-06-25 08:51:40.556222
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # TODO - test goes here
    assert True



# Generated at 2022-06-25 08:51:42.522353
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = 'vp'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(str_0)


# Generated at 2022-06-25 08:51:47.011309
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # Initialize new instance of CallbackModule class
    callback_module_0 = CallbackModule()

    # Check type of callback_module_0 is CallbackModule
    assert (type(callback_module_0) == CallbackModule)


# Generated at 2022-06-25 08:51:47.769574
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    obj = CallbackModule()

# Generated at 2022-06-25 08:51:48.279718
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    CallbackModule()

# Generated at 2022-06-25 08:51:58.485739
# Unit test for method v2_runner_on_ok of class CallbackModule

# Generated at 2022-06-25 08:52:05.747825
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    
    v2_runner_on_failed_0 = CallbackModule()
    v2_runner_on_failed_0.v2_runner_on_failed(None)
    v2_runner_on_failed_1 = CallbackModule()
    v2_runner_on_failed_1.v2_runner_on_failed(None,  False)
    v2_runner_on_failed_2 = CallbackModule()
    v2_runner_on_failed_2.v2_runner_on_failed(None,  True)


# Generated at 2022-06-25 08:52:11.435233
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
  callback_module_0 = CallbackModule()

  str_0 = '?F?\\Q&j\x0b`QB+EWb\x0bk\x0cW'
  callback_module_0.v2_runner_on_ok(str_0)

# Generated at 2022-06-25 08:52:51.136720
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = '?F?\\Q&j\x0b`QB+EWb\x0bk\x0cW'
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(str_0)


# Generated at 2022-06-25 08:52:51.834418
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

    assert 'result.' in var_0


# Generated at 2022-06-25 08:52:54.922141
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = '?F?\\Q&j\x0b`QB+EWb\x0bk\x0cW'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(str_0)


# Generated at 2022-06-25 08:53:00.285066
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    try:
        # Test for v2_runner_on_skipped
        str_0 = '?F?\\Q&j\x0b`QB+EWb\x0bk\x0cW'
        callback_module_0 = CallbackModule()
        var_0 = callback_v2_runner_on_ok(str_0)


        assert True
    except AssertionError as e:
        print("test_CallbackModule FAIL")
        print("[*] Error: " + str(e))

# Generated at 2022-06-25 08:53:06.132264
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    str_0 = '?F?\\Q&j\x0b`QB+EWb\x0bk\x0cW'
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_ok(str_0)



# Generated at 2022-06-25 08:53:06.980479
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:53:08.288833
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    CallbackModule_0 = CallbackModule()


# Generated at 2022-06-25 08:53:11.853295
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    str_0 = 'Vl+`\x0b\x0bY\x0bk\x0c\x0cW'
    callback_module_0 = CallbackModule()

    # Call method v2_runner_on_ok on object callback_module_0
    var_0 = callback_module_0.v2_runner_on_ok(str_0)



# Generated at 2022-06-25 08:53:14.998828
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    runner_on_failed_0 = CallbackModule()
    runner_on_failed_1 = runner_on_failed_0.v2_runner_on_failed(str_0)


# Generated at 2022-06-25 08:53:18.717964
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    str_0 = '"\x1e\x17\x1b'
    callback_module_0 = CallbackModule()
    str_1 = '\x1c\x15\x13'
    callback_module_0 = CallbackModule(str_1)


# Generated at 2022-06-25 08:54:56.618412
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    print('Testing method v2_runner_on_ok of class CallbackModule...')

# Generated at 2022-06-25 08:55:01.523910
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_1 = 'Iz\x0c'
    callback_module_1 = CallbackModule()
    var_1 = callback_v2_runner_on_failed(str_1)


# Generated at 2022-06-25 08:55:07.138416
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    print("\n---\n Constructor test 1\n---")
    test_case_0()
    print("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<\n")
    print("\n---\n Constructor test 2\n---")
    test_case_1()
    print("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<\n")
    print("\n---\n Constructor test 3\n---")
    test_case_2()
    print("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<\n")
    print("\n---\n Constructor test 4\n---")
    test_case_

# Generated at 2022-06-25 08:55:14.221479
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Setup
    str_0 = '!h\x0bE\x0bM\x0bT[\x0c\x0b'
    callback_module_0 = CallbackModule()

    # Invocation
    var_0 = callback_module_0.v2_runner_on_failed(str_0)


# Generated at 2022-06-25 08:55:15.292355
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # Given
    # When
    callback_module = CallbackModule()
    # Then
    assert callback_module is not None

# Generated at 2022-06-25 08:55:15.939313
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:55:21.210271
# Unit test for method v2_runner_on_failed of class CallbackModule

# Generated at 2022-06-25 08:55:27.591454
# Unit test for constructor of class CallbackModule
def test_CallbackModule():

    str_0 = '?F?\\Q&j\x0b`QB+EWb\x0bk\x0cW'
    int_0 = 0
    callback_module_0 = CallbackModule(str_0, int_0)
    str_1 = '?F?\\Q&j\x0b`QB+EWb\x0bk\x0cW'
    int_1 = 0
    callback_module_1 = CallbackModule(str_1, int_1)
    str_2 = '?F?\\Q&j\x0b`QB+EWb\x0bk\x0cW'
    int_2 = 0
    callback_module_2 = CallbackModule(str_2, int_2)

# Generated at 2022-06-25 08:55:31.081356
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    str_0 = '?F?\\Q&j\x0b`QB+EWb\x0bk\x0cW'
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:55:32.873942
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module = CallbackModule()
    assert callback_module is not None
