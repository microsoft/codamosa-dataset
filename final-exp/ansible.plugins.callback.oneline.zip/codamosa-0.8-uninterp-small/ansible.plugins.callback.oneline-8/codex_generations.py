

# Generated at 2022-06-25 08:48:47.812688
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_1 = CallbackModule()


# Generated at 2022-06-25 08:48:56.345806
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Input
    callback_module_0 = CallbackModule()
    result = None

    # Output
    exception_call_2 = None
    exception_call_3 = None
    exception_call_4 = None

    # Call the v2_runner_on_ok method
    try:
        callback_module_0.v2_runner_on_ok(result)
    except Exception as exception_call_0:
        exception_call_2 = exception_call_0

    # Call the v2_runner_on_ok method
    try:
        callback_module_0.v2_runner_on_ok(result)
    except Exception as exception_call_1:
        exception_call_3 = exception_call_1

    # Call the v2_runner_on_ok method

# Generated at 2022-06-25 08:49:02.399518
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()

    # Force a test failed
    result_0 = 'This is a failed test'
    callback_module_0.v2_runner_on_failed(result_0);


# Generated at 2022-06-25 08:49:03.450545
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    test_case_0()

# Generated at 2022-06-25 08:49:07.579168
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_skipped("result")

if __name__ == "__main__":
    test_case_0()
    test_CallbackModule()

# Generated at 2022-06-25 08:49:10.142238
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result = None
    ignore_errors = False
    callback_module_0.v2_runner_on_failed(result, ignore_errors)


# Generated at 2022-06-25 08:49:17.551937
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    import ansible.plugins.callback.default
    callback_default_1 = ansible.plugins.callback.default.CallbackModule()
    import ansible.plugins.callback.default
    callback_default_2 = ansible.plugins.callback.default.CallbackModule()
    import ansible.plugins.callback.default
    callback_default_3 = ansible.plugins.callback.default.CallbackModule()
    import ansible.plugins.callback.default
    callback_default_4 = ansible.plugins.callback.default.CallbackModule()
    import ansible.plugins.callback.default
    callback_default_5 = ansible.plugins.callback.default.CallbackModule()
    import ansible.plugins.callback.default
    callback_default_6 = ansible.plugins.callback.default.CallbackModule()
   

# Generated at 2022-06-25 08:49:23.354434
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result_0 = dict()
    result_0['changed'] = False
    result_0['call'] = 'function'
    result_0['invocation'] = dict()
    result_0['invocation']['module_args'] = dict()
    result_0['invocation']['module_args']['test'] = 'test'
    result_0['invocation']['module_name'] = 'function'
    result_0['invocation']['module_name'] = 'function'
    result_0['item'] = dict()
    result_0['item']['function_name'] = 'function'
    result_0['item']['function_name'] = 'function'
    result_0['item']['function_name'] = 'function'
   

# Generated at 2022-06-25 08:49:24.203583
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    p = CallbackModule()
    assert isinstance(p,CallbackBase)==True


# Generated at 2022-06-25 08:49:25.851701
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_1 = CallbackModule()
    callback_module_1.v2_runner_on_ok(result)


# Generated at 2022-06-25 08:49:36.279402
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Tests args are correct number and type
    callback_module_0 = CallbackModule()
    resul_t_0 = Result()
    callback_module_0.v2_runner_on_ok(resul_t_0)



# Generated at 2022-06-25 08:49:40.316788
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = runner_result_0
    ignore_errors_0 = False
    callback_module_0.v2_runner_on_failed(result_0, ignore_errors_0)


# Generated at 2022-06-25 08:49:45.530238
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    result_0 = ansible.executor.task_result.TaskResult(host=ansible.inventory.host.Host(name="localhost"), task=ansible.playbook.task.Task(), task_fields={})
    result_0._result = dict(exception="error message")
    callback_module_1.v2_runner_on_failed(result=result_0, ignore_errors=False)

# Generated at 2022-06-25 08:49:46.122062
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    CallbackModule()

# Generated at 2022-06-25 08:49:47.726555
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_obj = CallbackModule()
    assert callback_module_obj is not None


# Generated at 2022-06-25 08:49:51.488715
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    test_result_1 = {'failed': True, 'parsed': False}
    callback_module_1.v2_runner_on_failed(test_result_1)


# Generated at 2022-06-25 08:50:00.590985
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    hostname=None
    result=None
    ignore_errors=None
    callback_module_0 = CallbackModule()
    #Test case 0

# Generated at 2022-06-25 08:50:10.253243
# Unit test for constructor of class CallbackModule

# Generated at 2022-06-25 08:50:15.950754
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_v2_runner_on_failed = CallbackModule()
    result = None
    ignore_errors = False
    callback_module_v2_runner_on_failed.v2_runner_on_failed(result, ignore_errors)


# Generated at 2022-06-25 08:50:22.666144
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_v2_runner_on_failed = CallbackModule()
    callback_module_result_v2_runner_on_failed = object()
    callback_module_ignore_errors_v2_runner_on_failed = True
    try:
        callback_module_v2_runner_on_failed.v2_runner_on_failed(callback_module_result_v2_runner_on_failed,callback_module_ignore_errors_v2_runner_on_failed)
    except Exception as exception_v2_runner_on_failed:
        print(exception_v2_runner_on_failed)
    finally:
        del callback_module_v2_runner_on_failed


# Generated at 2022-06-25 08:50:40.496965
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    test_result = TestResult()
    callback_module_0.v2_runner_on_failed(test_result)


# Generated at 2022-06-25 08:50:52.032231
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    # Create mock instance of a class
    result_0 = Mock()
    result_0._task = Mock()
    result_0._task.action = Mock()
    result_0._task.action = "some_action_0"
    result_0._host = Mock()
    result_0._host.get_name = Mock()
    result_0._host.get_name = "some_host_0"
    callback_module_1._display = Mock()
    callback_module_1._display.verbosity = Mock()
    callback_module_1._display.colorize = Mock()
    callback_module_1._display.verbosity = "some_verbosity_0"
    callback_module_1._display.colorize = "some_colorize_0"
    callback_module

# Generated at 2022-06-25 08:50:54.947421
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule().callback_version == 2.0
    assert CallbackModule().callback_type == 'stdout'
    assert CallbackModule().callback_name == 'oneline'

# Generated at 2022-06-25 08:50:58.769844
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    my_result_0 = {}
    local_params = {"result": my_result_0}
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_ok(**local_params)


# Generated at 2022-06-25 08:51:03.612779
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    """ test for method "v2_runner_on_ok" """

    # create fixture
    callback_module_0 = CallbackModule()

    # all input values needed for
    # v2_runner_on_ok(self, result)
    result_0 = {'rc': 0, 'stdout': ''}


    # run method and assert expectations
    callback_module_0.v2_runner_on_ok(result_0)


# Generated at 2022-06-25 08:51:09.364423
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    result_0 = FakeResult()
    result_0._result = "{"
    result_0._task = FakeTask()
    result_0._host = FakeHost()
    result_0._host.get_name = lambda : "faker"
    result_0._result = {'changed': False}
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_ok(result_0)


# Generated at 2022-06-25 08:51:11.111446
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_2 = CallbackModule()
    result_II = {}
    callback_module_2.v2_runner_on_ok(result_II)


# Generated at 2022-06-25 08:51:13.608483
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = mock.Mock()
    result_0.exception.return_value = ''
    callback_module_0.v2_runner_on_failed(result_0, True)
    result_0.exception.assert_called_with()


# Generated at 2022-06-25 08:51:25.203619
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Create unit test harness that injects fake "display" function that
    # can be tested.
    class FakeDisplay:
        def __init__(self):
            self.display_function = None
            self.display_args = None
            self.display_kwargs = None
            self.display_color = None
            self.display_msg = None
        def display(self, msg, color=None):
            self.display_function = "display"
            self.display_args = msg
            self.display_kwargs = color
        def display2(self, msg, color=None):
            self.display_function = "display2"
            self.display_args = msg
            self.display_kwargs = color

    # Create fake Result object where the result is not changed
    # Create fake config object

# Generated at 2022-06-25 08:51:27.444253
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    try:
        test_case_0()
    except NameError:
        print("NameError")

if __name__ == '__main__':
    test_CallbackModule()

# Generated at 2022-06-25 08:51:53.387374
# Unit test for method v2_runner_on_failed of class CallbackModule

# Generated at 2022-06-25 08:51:55.137713
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    complex_0 = Non

# Generated at 2022-06-25 08:51:55.610734
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    CallbackModule()

# Generated at 2022-06-25 08:52:00.107277
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    complex_0 = None
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(complex_0)


# Generated at 2022-06-25 08:52:07.229104
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    import random
    import string
    import json
    result = json.loads('{"changed": 0, "invocation": {"module_args": {"targets": ["1.1.1.1"]}}}')
    result["_result"] = {}
    result["_host"] = {}
    result["_host"]["get_name"] = lambda : ''.join(random.choice(string.ascii_uppercase) for _ in range(10))
    result["_task"] = {}
    result["_task"]["action"] = random.choice(C.MODULE_NO_JSON)
    assert result["changed"] == 0
    assert result["_host"]["get_name"]() != ''
    assert result["_task"]["action"] in C.MODULE_NO_JSON
    callback_module_0 = Callback

# Generated at 2022-06-25 08:52:09.339052
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    complex_0 = None
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(complex_0)



# Generated at 2022-06-25 08:52:11.784774
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    complex_0 = None
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(complex_0)
    assert(var_0 is None)


# Generated at 2022-06-25 08:52:17.467736
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    import sys
    sys.path.append("src/lib")
    import ansible
    from ansible.constants import C
    from ansible.plugins.callback import CallbackBase

    complex_0 = None
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(complex_0)

# Generated at 2022-06-25 08:52:20.655268
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    complex_0 = None
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(complex_0)


# Generated at 2022-06-25 08:52:24.005487
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    complex_1 = None
    callback_module_1 = CallbackModule()
    var_1 = callback_v2_runner_on_ok(complex_1)


# Generated at 2022-06-25 08:52:59.024756
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    complex_0 = None
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(complex_0)


# Generated at 2022-06-25 08:53:10.627206
# Unit test for constructor of class CallbackModule

# Generated at 2022-06-25 08:53:16.005578
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    complex_0 = 1 
    callback_module_0 = CallbackModule()

    # replaced above with a stub
    #var_0 = callback_module_0.v2_runner_on_failed(complex_0)

    assert var_0 == 0


# Generated at 2022-06-25 08:53:18.686295
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    complex_0 = None
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(complex_0)



# Generated at 2022-06-25 08:53:21.205012
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    complex_0 = ansible_run_result()
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_ok(complex_0)


# Generated at 2022-06-25 08:53:22.261578
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert True


# Generated at 2022-06-25 08:53:24.452290
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    complex_0 = None
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(complex_0)


# Generated at 2022-06-25 08:53:26.884673
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    try:
        CallbackModule()
    except Exception as err:
        print("Error in constructor of CallbackModule: " + str(err))


# Generated at 2022-06-25 08:53:29.477731
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    complex_1 = None
    callback_module_1 = CallbackModule()
    var_1 = callback_v2_runner_on_ok(complex_1)


# Generated at 2022-06-25 08:53:31.160146
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

    callback_module_0 = CallbackModule()
    complex_0 = None
    var_0 = callback_v2_runner_on_ok(complex_0)


# Generated at 2022-06-25 08:55:09.328962
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result = Mock()
    result._result = { 'changed': false }
    result._task = Mock()
    result._task.action = "some action"
    result._host = Mock()
    result._host.get_name = Mock()
    result._host.get_name.return_value = "name"
    callback_module_0.v2_runner_on_ok(result)
    assert callback_module_0._display.display.call_count == 1
    assert callback_module_0._dump_results.call_count == 1



# Generated at 2022-06-25 08:55:11.331786
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    complex_1 = None
    callback_module_1 = CallbackModule()
    var_1 = callback_v2_runner_on_ok(complex_1)



# Generated at 2022-06-25 08:55:14.629072
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    complex_0 = None
    callback_module_0 = CallbackModule(complex_0)
    var_0 = callback_module_0.CALLBACK_TYPE
    var_1 = callback_module_0.CALLBACK_VERSION
    var_2 = callback_module_0.CALLBACK_NAME


# Generated at 2022-06-25 08:55:16.349803
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    complex_0 = None
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(complex_0)


# Generated at 2022-06-25 08:55:22.688702
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    complex_0 = None
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(complex_0)
    var_1 = callback_module_0.v2_runner_on_ok(complex_0)
    var_2 = callback_module_0.v2_runner_on_unreachable(complex_0)
    var_3 = callback_module_0.v2_runner_on_skipped(complex_0)
    var_4 = callback_module_0.v2_on_file_diff(complex_0, complex_0)
    var_5 = callback_module_0.v2_playbook_on_start(complex_0)

# Generated at 2022-06-25 08:55:26.357350
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # The generic test values to be used
    result = None
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_ok(result)
    # Variable to check
    assert var_0 == None


# Generated at 2022-06-25 08:55:28.699130
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Verify return value is True
    assert True == callback_module_0.v2_runner_on_failed(var_0)


# Generated at 2022-06-25 08:55:30.890689
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert(isinstance(callback_module_0, CallbackModule))


# Generated at 2022-06-25 08:55:32.826697
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    complex_0 = None
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_ok(complex_0)


# Generated at 2022-06-25 08:55:33.912472
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
