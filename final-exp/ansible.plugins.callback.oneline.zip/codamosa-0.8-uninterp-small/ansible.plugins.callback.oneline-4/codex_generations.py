

# Generated at 2022-06-25 08:48:48.286054
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed(result=None)
    callback_module_0.v2_runner_on_ok(result=None)
    callback_module_0.v2_runner_on_unreachable(result=None)
    callback_module_0.v2_runner_on_skipped(result=None)

# Generated at 2022-06-25 08:48:51.936653
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Test with no parameters passed
    result = {"changed" : False}
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_ok(result)

    # Test with changed = True
    result = {"changed" : True}
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_ok(result)

# Generated at 2022-06-25 08:48:54.008656
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Setup
    callback_module_0 = CallbackModule()
    result = MockedResult()

    # Exercise
    callback_module_0.v2_runner_on_ok(result)



# Generated at 2022-06-25 08:48:58.321452
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    assert(callback_module_0.v2_runner_on_ok('result_0') == None)

# Generated at 2022-06-25 08:49:05.797499
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    result_name = 'result'
    result_type = 'result'
    result_1 = {
        '_result': result_type,
        '_task': 'task',
        '_host': {'get_name': 'get_name'}
    }
    ignore_errors = False
    callback_module_1.v2_runner_on_failed(result_1, ignore_errors)


# Generated at 2022-06-25 08:49:07.719221
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    try:
        assert CallbackModule()
    except:
        pytest.fail("Unexpected Exception Raised!")


# Generated at 2022-06-25 08:49:13.413946
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = FakeResult()
    result_0.setFailed(True)
    callback_module_0.v2_runner_on_failed(result_0)


# Generated at 2022-06-25 08:49:18.050600
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_1 = CallbackModule()


# Generated at 2022-06-25 08:49:20.882258
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result = Stub(changed=False, failed=False, skipped=False, unreachable=False, ok=False)
    callback_module_0.v2_runner_on_failed(result)


# Generated at 2022-06-25 08:49:24.140037
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # Initializing an instance of CallbackModule
    callback_module_1 = CallbackModule()
    assert callback_module_1.CALLBACK_TYPE == 'stdout'
    assert callback_module_1.CALLBACK_NAME == 'oneline'

# Generated at 2022-06-25 08:49:36.969344
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result_0 = {'msg': 'ok'}
    test_0 = callback_module_0.v2_runner_on_ok(result_0)


# Generated at 2022-06-25 08:49:37.727856
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module = CallbackModule()


# Generated at 2022-06-25 08:49:43.211038
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_1 = CallbackModule()
    result_1 = ansible.runner.Result(fake_play, fake_task, fake_result, None)
    callback_module_1.v2_runner_on_ok(result_1)


# Generated at 2022-06-25 08:49:47.600268
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():

    # Setup test
    result_0 = {}

    callback_module_0 = CallbackModule()

    # Invoke method
    callback_module_0.v2_runner_on_failed(result_0)


# Generated at 2022-06-25 08:49:52.311614
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Create a test object for class CallbackModule
    callback_module_1 = CallbackModule()
    # Create a mock object for argument 'result'
    result_1 = MockAnsibleResult()
    # Call method v2_runner_on_ok with parameter result_1
    callback_module_1.v2_runner_on_ok(result_1)

# Generated at 2022-06-25 08:49:56.282779
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result_0 = Mock()
    call_method_with_args(callback_module_0.v2_runner_on_ok, [result_0])
    assert call_count(callback_module_0._dump_results, 2) == 2


# Generated at 2022-06-25 08:50:08.732810
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    #from ansible.plugins.callback import CallbackBase
    from ansible.plugins.callback import CallbackModule
    from ansible.utils.vars import combine_vars

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.six import string_types

# Generated at 2022-06-25 08:50:13.174405
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Arrange
    callback_module_0 = CallbackModule()
    result = {}
    ignore_errors = False

    # Act
    try:
        callback_module_0.v2_runner_on_failed(result, ignore_errors=False)
    except KeyError:
        pass
    else:
        assert False


# Generated at 2022-06-25 08:50:15.956295
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    test_case_0()

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 08:50:20.671954
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = get_result_instance()
    assert False


# Generated at 2022-06-25 08:50:30.552057
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    var_0 = CallbackModule()
    test_case_0()

test_CallbackModule()


# Generated at 2022-06-25 08:50:35.348495
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    var_0 = v2_runner_on_ok(callback_module_0)
    assert isinstance(var_0, NoneType)



# Generated at 2022-06-25 08:50:39.478072
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed(result, ignore_errors=True)


# Generated at 2022-06-25 08:50:49.437600
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module = CallbackModule()

    # Testing when result._result is null
    result = Mock()
    result._result = None
    result._host = Mock()
    result._host.get_name.return_value = "127.0.0.1"
    callback_module.v2_runner_on_failed(result)

    # Testing when result._result['exception'] is null
    result._result = {'exception': None}
    result._task = Mock()
    result._task.action = "file"
    callback_module.v2_runner_on_failed(result)

    # Testing when self._display.verbosity is less than 3
    result._result['exception'] = "This is a test exception"
    callback_module.v2_runner_on_failed(result)

    # Testing when self._

# Generated at 2022-06-25 08:50:51.802486
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Get the test object
    plugin = CallbackModule()

    # Set the test arguments
    result = {}
    ignore_errors = False

    # Execute the test function
    plugin.test_case_0(result, ignore_errors)

    # Verify the results

# end of unit tests for CallbackModule

# Generated at 2022-06-25 08:51:02.532432
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    var_vars_from_args__0 = {'changed': True}
    var_vars_from_args__1 = mock.Mock()
    var_vars_from_args__1.action = 'include'
    var_vars_from_args__2 = mock.Mock()
    var_vars_from_args__2.get_name.return_value = 'host_0'
    var_vars_from_args__3 = mock.Mock()
    var_vars_from_args__3.result = var_vars_from_args__0
    var_vars_from_args__3.task = var_vars_from_args__1
    var_vars_from_args__3.host = var_vars_from

# Generated at 2022-06-25 08:51:04.017231
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # Initialize the object
    print("Testing constructor of class CallbackModule")
    callback_module_0 = CallbackModule()
    print(callback_module_0)


# Generated at 2022-06-25 08:51:09.647359
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_v2_runner_on_ok_0 = on_ok_0()
    runner_result = AnsibleRunnerResult()
    runner_result._result = {}
    runner_result._task = {}
    runner_result._host = AnsibleHost()
    runner_result._host.get_name = ""
    assert " | | => " == callback_v2_runner_on_ok_0.v2_runner_on_ok(runner_result)


# Generated at 2022-06-25 08:51:10.592995
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()



# Generated at 2022-06-25 08:51:11.565542
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()

# Generated at 2022-06-25 08:51:30.887296
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert callback_module_0.CALLBACK_NAME == 'oneline'
    assert callback_module_0.CALLBACK_TYPE == 'stdout'
    assert callback_module_0.CALLBACK_VERSION == 2.0


# Generated at 2022-06-25 08:51:34.817079
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible import context
    context.CLIARGS = ImmutableDict(tags={}, listtags=False, listtasks=False, listhosts=False, syntax=False, connection='ssh', module_path=None, forks=100, private_key_file=None, ssh_common_args=None, ssh_extra_args=None, sftp_extra_args=None, scp_extra_args=None, become=False, become_method=None, become_user=None, become_ask_pass=False, ask_pass=False, verbosity=True, check=False, start_at_task=None)
    callback_module_1 = CallbackModule()
    var_1 = callback_v2_runner_on_ok(callback_module_1)


# Generated at 2022-06-25 08:51:38.048628
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    print("Testing CallbackModule...")
    var_1 = CallbackModule()
    if var_1:
        CallbackModule()
    else:
        print("Object not created")


# Generated at 2022-06-25 08:51:41.591870
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    var_1 = callback_v2_runner_on_failed(callback_module_1)


# Generated at 2022-06-25 08:51:52.561332
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert callback_module_0._dump_results == callback_module_0._dump_results
    assert callback_module_0.v2_playbook_on_play_start == callback_module_0.v2_playbook_on_play_start
    assert callback_module_0.v2_playbook_on_stats == callback_module_0.v2_playbook_on_stats
    assert callback_module_0.v2_runner_on_ok == callback_module_0.v2_runner_on_ok
    assert callback_module_0.v2_runner_on_failed == callback_module_0.v2_runner_on_failed
    assert callback_module_0.v2_runner_on_skipped == callback_module_0.v2_runner_

# Generated at 2022-06-25 08:51:55.971231
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result = {
        'changed': True
    }
    var_0 = callback_module_0.v2_runner_on_ok(result)
    # Result should be equal to
    #   False
    assert var_0 == False

# Generated at 2022-06-25 08:51:59.359813
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    myhost = ansible.hosts.UnsafeHost('localhost')
    testresult = ansible.runner.Result(myhost, dict())
    testresult.set_results(dict(changed=False))
    callback_module_2 = CallbackModule()
    callback_v2_runner_on_ok(callback_module_2, testresult)


# Generated at 2022-06-25 08:52:03.187112
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # Assert isinstance(Arg1, CallbackModule)
    assert isinstance(CallbackModule(), CallbackModule)
    assert isinstance(CallbackBase(), CallbackBase)
    assert isinstance(CallbackBase, CallbackBase())
    assert isinstance(object(), object)


# Generated at 2022-06-25 08:52:12.437850
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
  runner_on_failed_params = dict()
  runner_on_failed_params['result'] = dict()
  runner_on_failed_params['result']['_host'] = dict()
  runner_on_failed_params['result']['_host']['get_name'] = 'ec2-123-123-123-123.compute-1.amazonaws.com'
  runner_on_failed_params['result']['_task'] = dict()
  runner_on_failed_params['result']['_task']['action'] = 'ec2'
  runner_on_failed_params['result']['_result'] = dict()
  runner_on_failed_params['result']['_result']['exception'] = 'AnsibleError: unknown error'
  runner_on_failed_params

# Generated at 2022-06-25 08:52:15.208941
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

    # pass CallbackModule object
    callback_module_0 = CallbackModule()
    result_0 = callback_v2_runner_on_unreachable(callback_module_0)

    # pass integer
    callback_module_1 = CallbackModule()
    result_1 = callback_v2_runner_on_unreachable(callback_module_1)


# Generated at 2022-06-25 08:52:57.893622
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # test constructor with no parameters
    callback_module_0 = CallbackModule()
    assert(callback_module_0.CALLBACK_VERSION == 2)
    assert(callback_module_0.CALLBACK_TYPE == 'stdout')
    assert(callback_module_0.CALLBACK_NAME == 'oneline')

    assert(callback_module_0.v2_runner_on_skipped == None)
    assert(callback_module_0.v2_runner_on_ok == None)
    assert(callback_module_0.v2_runner_on_unreachable == None)
    assert(callback_module_0.v2_runner_on_failed == None)


# Generated at 2022-06-25 08:53:02.044427
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module = CallbackModule()
    assert (callback_module != None)


# Generated at 2022-06-25 08:53:04.975135
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # Constructor does not take any arguments, so not going to test that
    pass


# Generated at 2022-06-25 08:53:08.152186
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_1 = CallbackModule()
    var_1 = callback_v2_runner_on_ok(callback_module_1)


# Generated at 2022-06-25 08:53:14.164345
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Declaring the object
    cb_0 = CallbackModule()
    # Setting up value for 'result' argument
    result_0 = {
        'action': 'ACTION_TEST',
        '_ansible_no_log': False,
        '_ansible_verbose_always': False,
        '_ansible_verbose_override': False,
        '_handle': {},
        '_host': 'HOST_TEST',
        '_result': {
            'changed': False,
            'msg': 'This is a test message',
            'rc': False},
        '_task': 'TASK_TEST'}
    
    # Invoking the method v2_runner_on_ok() of object cb_0

# Generated at 2022-06-25 08:53:23.831539
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

    # Mock import modules
    import builtins
    builtins.__dict__['_logger'] = lambda str: print(str)

    # Mock class dependency
    class CallbackBase:
        def __init__(self):
            self.call_count = 0
            self.call_count += 1

        def display(self, dump_results, color):
            self.dump_results = dump_results
            self.color = color
            self.call_count += 1

    old_colors = C.COLOR_OK

    # Initialize class instance
    callback_module_1 = CallbackModule()

    # Define local function
    def _dump_results():
        return 'test_str'

    callback_module_1._dump_results = _dump_results

    # Call method v2_runner_on_ok
    callback_module

# Generated at 2022-06-25 08:53:30.625580
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # Arrange
    # CallbackModule is a class, so creating an instance is arranging.
    # No other arranging needed.

    # Act
    # Creating an instance of CallbackModule is acting.
    callback_module_1 = CallbackModule()

    # Assert
    # As long as callback_module_1 is an instance of CallbackModule, the test passed.
    # assertIsInstance can check if callback_module_1 is an instance of CallbackModule
    # assertIsInstance is a method in the unittest library
    assertIsInstance(callback_module_1, CallbackModule)


# Generated at 2022-06-25 08:53:33.168191
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(callback_module_0)
    if var_0 == 0:
        print('Test case passed.')
    else:
        print('Test case failed.')


# Generated at 2022-06-25 08:53:41.766148
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    ansible_result = AnsibleResult()
    ansible_result._result = {
        "changed": True,
        "msg": "All items completed",
        "results": [{
            "_ansible_item_label": "test",
            "changed": True,
            "invocation": {
                "module_args": {
                    "name": "test",
                    "state": "absent"
                }
            }
        }]
    }

    ansible_result._host = {
        "id": "test",
        "hostname": "test",
        "name": "test"
    }

    ansible_result._task = {
        "tags": "TAGS",
        "action": "ACTION",
        "name": "NAME"
    }

   

# Generated at 2022-06-25 08:53:49.558366
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = RunnerResult()
    ignore_errors_0 = False
    callback_v2_runner_on_failed(callback_module_0, result_0, ignore_errors_0)
    callback_module_1 = CallbackModule()
    result_1 = RunnerResult()
    ignore_errors_1 = False
    callback_v2_runner_on_failed(callback_module_1, result_1, ignore_errors_1)
    callback_module_2 = CallbackModule()
    result_2 = RunnerResult()
    ignore_errors_2 = True
    callback_v2_runner_on_failed(callback_module_2, result_2, ignore_errors_2)
    callback_module_3 = CallbackModule()
    result_3 = RunnerResult()
   

# Generated at 2022-06-25 08:55:27.031220
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
  test_case_0()

# Generated at 2022-06-25 08:55:30.402310
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result_0 = Result()
    var_0 = callback_module_0.v2_runner_on_ok(result_0)


# Generated at 2022-06-25 08:55:34.618367
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module = CallbackModule()
    var_0 = callback_module.CALLBACK_VERSION
    var_1 = callback_module.CALLBACK_TYPE
    var_2 = callback_module.CALLBACK_NAME
    assert(var_0 == 2.0)
    assert(var_1 == "stdout")
    assert(var_2 == "oneline")

# Generated at 2022-06-25 08:55:40.230062
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    from ansible.playbook.task_include import TaskInclude
    task_include_0 = TaskInclude()
    from ansible.playbook.play_context import PlayContext
    play_context_0 = PlayContext()
    from ansible.vars.hostvars import HostVars
    hostvars_0 = HostVars()
    from ansible.executor.task_result import TaskResult
    task_result_0 = TaskResult()
    task_result_0._result = {'changed': False}
    task_result_0._task = task_include_0
    task_result_0._host = hostvars_0
    task_result_0.task = task_include_0
    task_result_0.host = hostvars_0
    task_

# Generated at 2022-06-25 08:55:46.490914
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create an instance of the CallbackModule class.
    callbackModule_instance_1 = CallbackModule()
    # Create an instance of the class 'RunnerResult'
    runnerResult_instance_1 = RunnerResult()
    # Call the v2_runner_on_failed method of the RunnerResult class
    var_1 = runnerResult_instance_1.v2_runner_on_failed(result, ignore_errors=False)
    var_2 = CallbackModule.v2_runner_on_failed(callbackModule_instance_1, var_1)


# Generated at 2022-06-25 08:55:53.863497
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    callback_module_0._display.verbosity = constants.VERBOSITY_VERBOSE
    callback_module_0._dump_results = MagicMock(return_value = "Mocked return value")
    var_0 = {}
    var_0["exception"] = "Mocked exception"
    var_0["stdout"] = "Mocked stdout"
    var_0["stderr"] = "Mocked stderr"
    var_0["rc"] = 1
    callback_module_0.v2_runner_on_failed(var_0)


# Generated at 2022-06-25 08:55:56.047872
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    callback_v2_runner_on_failed(callback_module_0)


# Generated at 2022-06-25 08:56:05.553820
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    try:
        assert callback_module_0 is not None
        assert callback_module_0.CALLBACK_TYPE == 'oneline'
        assert callback_module_0.SENSITIVE_KEYS == ['ssh_passphrase', 'become_pass', 'vault_password']
        assert callback_module_0.CALLBACK_VERSION == 2.0
    except AssertionError:
        raise SystemExit('Unable to proceed with test because assertion failed')


# Generated at 2022-06-25 08:56:08.126049
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_1 = CallbackModule()


# Generated at 2022-06-25 08:56:12.582661
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # Test to initialize the class object
    callback_module_0 = CallbackModule()
    assert (callback_module_0 != None)
