

# Generated at 2022-06-25 08:48:55.735028
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module = CallbackModule()
    callback_module._display = type('MockDisplay', (object,), {})
    callback_module._dump_results = lambda results, indent : 'This is a dump of the results'

    result = type('MockResult', (object,), { '_task' : type('MockTask', (object,), { 'action' : '' }), '_host' : type('MockHost', (object,), { 'get_name' : lambda : 'test_host' }), '_result' : { 'changed' : False } })
    callback_module.v2_runner_on_ok(result)

# Generated at 2022-06-25 08:49:01.488481
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    import datetime
    import json
    import subprocess
    from ansible.plugins.loader import callback_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.invocation.playbook_wrapper import Playbook
    from ansible.inventory.manager import InventoryManager
    import ansible.constants as C
    import time

    ###################################################################################################################
    # The following code is to set up the callback module and execute a playbook to generate the necessary output files
    ###################################################################################################################
    # Set config file path (we will generate a different output for each config file)

# Generated at 2022-06-25 08:49:05.165415
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Instantiate an object of class CallbackModule
    callbackModule = CallbackModule()


# Generated at 2022-06-25 08:49:07.647981
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result = TestResult()
    callback_module_0.v2_runner_on_failed(result)


# Generated at 2022-06-25 08:49:14.912600
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    result_2 = {}
    result_2['exception'] = 'exception'
    result_2['_result'] = '_result'
    result_2['_host'] = '_host'
    result_2['_task'] = '_task'

    callback_module_1.v2_runner_on_failed(result_2)


# Generated at 2022-06-25 08:49:20.990889
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    '''
    Unit test of constructor
    '''
    my_test_class = CallbackModule()
    assert my_test_class.CALLBACK_NAME is 'oneline'
    assert my_test_class.CALLBACK_TYPE is 'stdout'
    assert my_test_class.CALLBACK_VERSION is 2.0
    print ("test_CallbackModule completed")

# Generated at 2022-06-25 08:49:32.051193
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result_0 = {"_ansible_ignore_errors": None,
                "_ansible_item_result": True,
                "_ansible_no_log": False,
                "_ansible_parsed": True,
                "_ansible_verbose_always": True,
                "_ansible_no_log_values": [True],
                "_ansible_item_label": "*",
                "changed": False,
                "msg": "All items completed"}
    result_0["_ansible_parsed"] = True
    result_0["_ansible_no_log"] = False
    result_0["_ansible_item_result"] = True
    result_0["_ansible_ignore_errors"] = None

# Generated at 2022-06-25 08:49:40.465270
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_1 = CallbackModule()
    fake_result = {'_result': {'changed': False}}
    fake_result['_result']['changed'] = True
    fake_result['_task'] = {'action': 'shell'}
    fake_result['_host'] = { 'get_name': lambda: '127.0.0.1' }
    callback_module_1.v2_runner_on_ok(fake_result)


# Generated at 2022-06-25 08:49:43.000694
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module = CallbackModule()
    result_1 = (None, dict(changed=False))
    callback_module.v2_runner_on_ok(result_1)

    result_2 = (None, dict(changed=True))
    callback_module.v2_runner_on_ok(result_2)


# Generated at 2022-06-25 08:49:54.079222
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    options = {'verbosity': 3, 'inventory': 'inventory'}
    loader = None
    variable_manager = None
    callback_module_0 = CallbackModule()
    callback_module_0.set_options(options)
    callback_module_0.set_loader(loader)
    callback_module_0.set_vardir('./path')
    callback_module_0.set_inventory(variable_manager)
    callback_module_0.set_playbook(variable_manager)
    callback_module_0.set_task(variable_manager)
    callback_module_0.set_task_result(variable_manager)
    callback_module_0.set_play_context(variable_manager)
    callback_module_0.set_all_hosts(variable_manager)
    callback_module_0.set

# Generated at 2022-06-25 08:50:07.638208
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    class MockResult:
        _task = None
        _result = {
            'exception': 'An exception occurred during task execution. To see the full traceback, use -vvv. The error was: '
        }
        _host = {
            'get_name': lambda: 'MockHost'
        }
    mock_result = MockResult()

    class MockDisplay:
        def display(self, msg, color):
            print(msg)

    mock_display = MockDisplay()
    callback_0 = CallbackModule()
    callback_0._display = mock_display
    callback_0.v2_runner_on_failed(mock_result)


# Generated at 2022-06-25 08:50:09.789369
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    switch_0 = False
    if switch_0:
        assert test_case_0() == 1
    else:
        assert test_case_0() == 0

# Generated at 2022-06-25 08:50:13.557705
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    float_0 = 471.691
    var_0 = callback_v2_runner_on_ok(float_0)

    assert type(var_0) == type(float_0)


# Generated at 2022-06-25 08:50:22.353479
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
	number = 1
	# Test case for a failed task (changed and unreachable)
	callback_module = CallbackModule()
	list_of_results = [{'changed': True, 'unreachable': True}]
	list_of_results[0]['invocation'] = {'module_args': 'mod1'}
	list_of_results[0]['_ansible_parsed'] = True
	result = callback_module.v2_runner_on_failed(list_of_results[0])
	assert result == "%s | FAILED! => %s" % ("unknown", callback_module._dump_results(list_of_results, indent=0).replace('\n', ''))
	
	# Test case for a failed task (changed and unreachable)

# Generated at 2022-06-25 08:50:32.573419
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    print ("Test v2_runner_on_ok")

# Generated at 2022-06-25 08:50:35.911317
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    # TODO
    assert callback_module_0._display.verbosity > 2
    assert callback_module_0._dump_results() == None


# Generated at 2022-06-25 08:50:45.100391
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert '_display' in CallbackModule().__dict__
    assert '_dump_results' in CallbackModule().__dict__
    assert '_command_generic_msg' in CallbackModule().__dict__
    assert 'v2_runner_on_failed' in CallbackModule().__dict__
    assert 'v2_runner_on_ok' in CallbackModule().__dict__
    assert 'v2_runner_on_unreachable' in CallbackModule().__dict__
    assert 'v2_runner_on_skipped' in CallbackModule().__dict__
    assert 'CALLBACK_VERSION' in CallbackModule().__dict__
    assert 'CALLBACK_TYPE' in CallbackModule().__dict__
    assert 'CALLBACK_NAME' in CallbackModule().__dict__

# Generated at 2022-06-25 08:50:48.436385
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    test_object_CallbackModule = CallbackModule()
    test_object_str = 'foo'
    test_object_str_lowercase = 'f'
    assert test_object_CallbackModule.v2_runner_on_ok(test_object_str) != test_object_str_lowercase


# Generated at 2022-06-25 08:50:52.247862
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = MagicMock()
    ignore_errors_0 = MagicMock()  # Mock type bool
    var_0 = callback_module_0.v2_runner_on_failed(result_0, ignore_errors_0)


# Generated at 2022-06-25 08:50:54.801617
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_1 = CallbackModule()
    assert isinstance(callback_module_1, CallbackModule)


# Generated at 2022-06-25 08:51:04.953168
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:51:09.680555
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    def callback_v2_runner_on_skipped(self, result):
        self._display.display("%s | SKIPPED" % (result._host.get_name()), color=C.COLOR_SKIP)

    CallbackModule.callback_v2_runner_on_skipped = callback_v2_runner_on_skipped
    assert test_case_0() == 0

# Generated at 2022-06-25 08:51:11.687350
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    float_0 = 2.8
    var_0 = callback_module_0.v2_runner_on_failed(float_0)


# Generated at 2022-06-25 08:51:15.153519
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Create a new instance of CallbackModule
    callback_module_0 = CallbackModule()

    # Create a new instance of AnsibleResult
    ansible_result_0 = AnsibleResult()

    # Assign a value to the variable 'changed' of ansible_result_0
    ansible_result_0.changed = True

    # Call method v2_runner_on_ok of callback_module_0 with parameter ansible_result_0
    var_0 = callback_module_0.v2_runner_on_ok(ansible_result_0)

# Generated at 2022-06-25 08:51:21.807074
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module = CallbackModule()
    float_var = 471.691
    dict_var = dict()
    dict_var['_result'] = float_var
    dict_var['_task'] =  float_var
    dict_var['_host'] =  float_var
    dict_var['_display'] =  float_var
    callback_module.v2_runner_on_failed(dict_var)


# Generated at 2022-06-25 08:51:23.276673
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule().__class__.__name__ == "CallbackModule"

# Generated at 2022-06-25 08:51:24.509348
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    float_0 = 651.5669
    callback_module_0.v2_runner_on_ok(float_0)


# Generated at 2022-06-25 08:51:31.961397
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    ansible_result_2 = AnsibleResult()
    ansible_result_2.rc = 0
    ansible_result_2.stdout = "some stdout string"
    ansible_result_2.stderr = "some stderr string"
    ansible_result_2.changed = True
    ansible_result_2.module_stdout = "some module_stdout string"
    ansible_result_2.cmd = "some cmd string"
    ansible_result_2.start = "2018-04-11 10:57:14.122930"
    ansible_result_2.end = "2018-04-11 10:57:14.823190"

# Generated at 2022-06-25 08:51:34.675703
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    float_0 = 171.3
    var_0 = callback_v2_runner_on_ok(float_0)


# Generated at 2022-06-25 08:51:37.941234
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    float_0 = 471.691
    var_0 = callback_module_0.v2_runner_on_failed(float_0)



# Generated at 2022-06-25 08:52:04.388037
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # Test with good arguments
    callback_module_0 = CallbackModule()
    # Test with bad arguments (TypeError exception)
    try:
        callback_module_1 = CallbackModule(None)
    except TypeError:
        pass
    # Test with bad arguments (TypeError exception)
    try:
        callback_module_2 = CallbackModule(None, None)
    except TypeError:
        pass
    # Test with bad arguments (TypeError exception)
    try:
        callback_module_3 = CallbackModule(None, None, None)
    except TypeError:
        pass
    # Test with bad arguments (ValueError exception)
    try:
        callback_module_4 = CallbackModule(None, None, None, None)
    except ValueError:
        pass


# Generated at 2022-06-25 08:52:05.122707
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule() != 0

# Generated at 2022-06-25 08:52:10.660489
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule() 
    #assert callback_module_0._display == "stdout"


# Generated at 2022-06-25 08:52:12.369378
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()

    assert callback_module_0.v2_runner_on_ok


# Generated at 2022-06-25 08:52:13.601536
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    TestResult._test_case_0()


# Generated at 2022-06-25 08:52:16.489857
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert callback_module_0 != None
    assert callback_module_0._plugin_type == 'callback'


# Generated at 2022-06-25 08:52:19.407674
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()

    # Call method v2_runner_on_ok of CallbackModule and return result
    callback_module_0.v2_runner_on_ok
    return callback_module_0


# Generated at 2022-06-25 08:52:19.878907
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    pass

# Generated at 2022-06-25 08:52:24.201336
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    float_0 = 537.5
    var_0 = callback_v2_runner_on_failed(float_0)


# Generated at 2022-06-25 08:52:27.862058
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    float_0 = 471.691
    var_0 = callback_module_0.v2_runner_on_failed(float_0)


# Generated at 2022-06-25 08:53:05.355239
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    CallbackModule()

if __name__ == '__main__':
    test_case_0()
    test_CallbackModule()

# Generated at 2022-06-25 08:53:08.187709
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Assertion for instance CallbackModule.v2_runner_on_failed
    assert isinstance(v2_runner_on_failed, CallbackModule)


# Generated at 2022-06-25 08:53:10.052667
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    float_0 = 126.666
    var_0 = callback_v2_runner_on_failed(float_0)


# Generated at 2022-06-25 08:53:14.590613
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    somelist_0 = []
    somelist_1 = []
    callbackmodule_0 = CallbackModule(somelist_0, somelist_1)
    somestr_0 = '{"invocation":{"module_name":"win_ping","module_args":{},"module_complex_args":{"_ansible_check_mode":true},"module_lang":"powershell","module_set_locale":true},"result":{"stdout":"pong\r\n","stderr":"","stdout_lines":["pong"],"stderr_lines":[],"changed":false}'
    callbackmodule_0.v2_runner_on_ok(somestr_0)


# Generated at 2022-06-25 08:53:17.064088
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert callback_module_0.CALLBACK_NAME == "oneline"


# Generated at 2022-06-25 08:53:25.975828
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert callback_module_0._show_custom_stats == False
    assert callback_module_0._dump_results_on_failure == False
    #assert CallbackModule.__doc__ == '    name: oneline\n    type: stdout\n    short_description: oneline Ansible screen output\n    version_added: historical\n    description:\n        - This is the output callback used by the -o/--one-line command line option.\n'
    assert callback_module_0._play.playbook == None
    assert callback_module_0._last_task_banner == None
    assert callback_module_0._last_task_name == None
    assert callback_module_0._last_task_hosts is None
    assert callback_module_0._last_task

# Generated at 2022-06-25 08:53:30.090020
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    float_0 = 615.707
    float_1 = 781.0

    # Testing if a exception is throw by the function
    try:
        # Call the function
        CallbackModule.v2_runner_on_ok(float_0, float_1)
    except Exception:
        assert True
    else:
        assert False



# Generated at 2022-06-25 08:53:35.567234
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    ok_result = {'reboot_required': 0, 'changed': False}
    changed_result = {'reboot_required': 0, 'changed': True}
    host = {'get_name': lambda: 'localhost'}
    task = {'action': 'module'}

    callback_module = CallbackModule()
    result = host, task, ok_result
    callback_module.v2_runner_on_ok(result)
    result = host, task, changed_result
    callback_module.v2_runner_on_ok(result)

    task['action'] = 'command'
    result = host, task, ok_result
    callback_module.v2_runner_on_ok(result)
    result = host, task, changed_result
    callback_module.v2_runner_on_ok(result)

# Generated at 2022-06-25 08:53:37.430573
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    float_0 = 2109.37
    var_0 = callback_v2_runner_on_failed(float_0)


# Generated at 2022-06-25 08:53:45.977163
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert callback_module_0._dump_results(0,0)=="{}"
    callback_module_0.v2_runner_on_failed() # This will fail, maybe not implemented?
    callback_module_0.v2_runner_on_ok(0) # This will fail, maybe not implemented?
    callback_module_0.v2_runner_on_unreachable(0) # This will fail, maybe not implemented?
    callback_module_0.v2_runner_on_skipped(0) # This will fail, maybe not implemented?

# Generated at 2022-06-25 08:55:23.351131
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    float_0 = 741.94
    var_0 = callback_module_0.v2_runner_on_failed(float_0)



# Generated at 2022-06-25 08:55:27.460489
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    float_0 = 471.691
    var_1 = callback_module_0.v2_runner_on_skipped(float_0)
    assert isinstance(var_1, bool)

if __name__ == '__main__':
    test_CallbackModule()

# Generated at 2022-06-25 08:55:30.889978
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    float_0 = 723.3901
    var_0 = callback_module_0.v2_runner_on_failed(float_0)


# Generated at 2022-06-25 08:55:37.108775
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    """Test cases for method v2_runner_on_ok of class CallbackModule."""
    # Set up test data
    callback_module_0 = CallbackModule()
    str_0 = "CallbackModule.v2_runner_on_ok"
    str_1 = "CallbackModule.v2_runner_on_ok"
    str_2 = "CallbackModule.v2_runner_on_ok"
    tuple_0 = (str_0, str_1, str_2)
    list_0 = list(tuple_0)
    # Call method
    # Unpack the tuple for the call
    callback_module_0.v2_runner_on_ok(*list_0)


# Generated at 2022-06-25 08:55:46.250993
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Test case data
    test_data = [
        {
            "id": "0",
            "input": {
                "result": None,
                "display": True,
                "color": True,
                "verbosity": True,
                "expected": {
                    "result": True
                }
            },
            "output": {
            }
        }
    ]

    # Perform the unit test
    test_result = perform_callback_test(CallbackModule, "v2_runner_on_ok", test_data)

    # Print test result
    print_test_result(test_result)


# Generated at 2022-06-25 08:55:49.139198
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    #TODO: finish test for CallbackModule


# Generated at 2022-06-25 08:55:56.887101
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    import tempfile
    import random
    import re
    random_int = random.randint(0, 1000)
    random_float = float(random_int)
    module = CallbackModule()
    task_name = "Failed_Task_" + str(random_int)
    callback_module_0 = CallbackModule()
    float_0 = 471.691
    runner_on_failed = callback_v2_runner_on_failed(float_0)
    with open(tempfile.gettempdir() + "\\" + task_name + ".txt", "a") as tempfile:
        tempfile.write(str(callback_module_0.v2_runner_on_failed(runner_on_failed, random_float)))

# Generated at 2022-06-25 08:56:06.681650
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    def fake_dump_results(self, v2_playbook_on_stats, indent=0):
        return 'fake_callback_v2_runner_on_ok'
    test_CallbackModule = CallbackModule()
    test_CallbackModule.setUp(self)
    test_CallbackModule._display = 'fake_callback_v2_runner_on_ok'
    test_CallbackModule._dump_results = fake_dump_results
    test_result = 'fake_callback_v2_runner_on_ok'
    var_0 = test_CallbackModule.v2_runner_on_ok(test_result)


# Generated at 2022-06-25 08:56:13.781711
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    float_0 = float(4)
    float_1 = float(46)
    float_2 = float(-113)
    float_3 = float(-10)
    float_4 = float(-57)
    float_5 = float(23)
    float_6 = float(0)
    float_7 = float(6)
    float_8 = float(9)
    float_9 = float(8)
    float_10 = float(3)
    float_11 = float(5)
    float_12 = float(1)
    float_13 = float(7)
    float_14 = float(2)
    float_15 = float(10)
    float_16 = float(-28)
    float_17 = float(0)
    float_18 = float(0)
    float_19 = float(0)

# Generated at 2022-06-25 08:56:16.683531
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    float_0 = 471.691
    callback_module = CallbackModule(float_0)

    assert callback_module.CALLBACK_VERSION == 2.0
    assert callback_module.CALLBACK_TYPE == 'stdout'
    assert callback_module.CALLBACK_NAME == 'oneline'
    assert callback_module.CALLBACK_NEEDS_WHITELIST == False

