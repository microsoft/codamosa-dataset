

# Generated at 2022-06-25 08:48:55.243475
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
   callback_module_1 = CallbackModule()
   result = {
       "_host": {
           "get_name": lambda: "test-1"
       },
       "_task": {
          "action": "setup"
       },
       "_result": {
          "ansible_facts": {
              "ansible_os_family": "RedHat"
          },
          "changed": True
       }
   }
   # Expected output:
   # test-1 | CHANGED => {
   #     "ansible_facts": {
   #         "ansible_os_family": "RedHat"
   #     },
   callback_module_1.v2_runner_on_ok(result)


# Generated at 2022-06-25 08:48:57.269184
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_v2_runner_on_ok_0 = CallbackModule()
    assert callback_module_v2_runner_on_ok_0 != 0


# Generated at 2022-06-25 08:49:01.163821
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert callable(CallbackModule), "Class CallbackModule cannot be instantiated"


# Generated at 2022-06-25 08:49:09.637266
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    c = {'failed': True, 'rc': 1, 'stderr': '', 'stdout': '', 'module_stderr': '', 'module_stdout': ''}
    hostname = 'localhost'
    result = Results(hostname, c)
    callback_module = CallbackModule()
    callback_module.v2_runner_on_failed(result)
    #print("<<TEST>> callback type value: %s"%callback_module.CALLBACK_TYPE)


# Generated at 2022-06-25 08:49:11.017217
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed(result="result_0")


# Generated at 2022-06-25 08:49:11.814621
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()



# Generated at 2022-06-25 08:49:12.736508
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module = CallbackModule()


# Generated at 2022-06-25 08:49:18.520593
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # arrange
    callback_module = CallbackModule()

    # act

    # assert
    assert True


# Generated at 2022-06-25 08:49:21.869715
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert callback_module_0.CALLBACK_VERSION == 2.0
    assert callback_module_0.CALLBACK_TYPE == 'stdout'
    assert callback_module_0.CALLBACK_NAME == 'oneline'


# Generated at 2022-06-25 08:49:32.380888
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result_0 = ansible.module_utils.basic.AnsibleModuleResult(host=None, result=None, _task=None, _connection=None, _play_context=None)
    result_0._host = None
    result_0._result = None
    result_0._task = None
    result_0._result = {'stderr': '', 'stdout': '', 'cmd': '', 'rc': 0}
    result_0._task = ansible.module_utils.basic.AnsibleTask(action='ping', task_vars={}, play_context=None)
    callback_module_0.v2_runner_on_ok(result_0)

# Generated at 2022-06-25 08:49:40.081896
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # setup
    callback_module = CallbackModule()

    # test
    callback_module.v2_runner_on_failed(result=None, ignore_errors=False)


# Generated at 2022-06-25 08:49:41.728770
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result_0 = callback_module_0.v2_runner_on_ok(result)


# Generated at 2022-06-25 08:49:47.482057
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = None
    ignore_errors_0 = False
    callback_module_0.v2_runner_on_failed(result_0, ignore_errors_0)


# Generated at 2022-06-25 08:49:57.861095
# Unit test for method v2_runner_on_ok of class CallbackModule

# Generated at 2022-06-25 08:50:08.843008
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # create a dummy result object
    result_obj = Result()

    # create a dummy task object
    task_obj = Task()

    # set task object attributes
    task_obj.action = 'TEST'
    task_obj.args = 'TEST'
    task_obj.delegate_to = 'TEST'
    task_obj.loop = 'TEST'
    task_obj.loop_args = 'TEST'
    task_obj.name = 'TEST'
    task_obj.notify = 'TEST'
    task_obj.register = 'TEST'
    task_obj.retries = 'TEST'
    task_obj.run_once = 'TEST'
    task_obj.until = 'TEST'
    task_obj.delegate_facts = 'TEST'
    task_obj

# Generated at 2022-06-25 08:50:13.595685
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_1 = CallbackModule()
    assert callback_module_1.CALLBACK_NAME == 'oneline'
    assert callback_module_1.CALLBACK_TYPE == 'stdout'
    assert callback_module_1.CALLBACK_VERSION == 2.0
    assert callback_module_1._display.__class__ == object


# Generated at 2022-06-25 08:50:22.354836
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():

    callback_module_0 = CallbackModule()

    # Test the value of result._result['stdout'].
    result_0 = {'stdout': 'I am a string'}
    result_1 = {'stderr': 'I am a string'}
    result_2 = {'stdout': ''}
    # Test the value of result._result['rc'].
    result_3 = {'rc': 0}
    result_4 = {'rc': 2}

    # Test the values of (result._task.action in C.MODULE_NO_JSON and 'module_stderr' not in result._result).
    result_5 = {'module_stderr': 'I am a string'}
    result_6 = {}
    result_7 = {'module_stderr': ''}

    # Test the

# Generated at 2022-06-25 08:50:32.573697
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    my_host = "localhost"
    my_result = dict(changed=False, msg="")
    my_result['changed'] = False
    my_result['msg'] = ""
    callback_module_1 = CallbackModule()
    if (callback_module_1.v2_runner_on_ok(my_result) !=
            "%s | SUCCESS => {\"changed\": false, \"msg\": \"\"}" % my_host) :
        raise Exception("Test failed")
    else:
        print("Test passed")
    my_result['changed'] = True
    if (callback_module_1.v2_runner_on_ok(my_result) !=
            "%s | CHANGED => {\"changed\": true, \"msg\": \"\"}" % my_host) :
        raise Exception("Test failed")

# Generated at 2022-06-25 08:50:43.036438
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    result_0 = {}
    result_1 = {}

    try:
        assert "result._result.get('exception', '').strip().split('\\n')[-1].replace('\\n', '').replace('\\r', '')" in result_0
    except NameError:
        raise

    try:
        assert "result._result.get('exception', '').strip().split('\\n')[-1].replace('\\n', '').replace('\\r', '')" in result_1
    except NameError:
        raise

    callback_module_1.v2_runner_on_failed(result_0, False)
    callback_module_1.v2_runner_on_failed(result_1, False)


# Generated at 2022-06-25 08:50:52.301080
# Unit test for method v2_runner_on_ok of class CallbackModule

# Generated at 2022-06-25 08:51:10.430886
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Setup the class structure
    callback_module = CallbackModule()

    # Create a mock task which has a result
    task_result = dict()
    task_result['_result'] = dict()
    task_result['_result']['changed'] = False
    task_result['_task'] = dict()
    task_result['_task']['action'] = 'automation_script'
    task_result['_host'] = dict()
    task_result['_host']['get_name'] = lambda: "localhost"

    # Call the method under test
    callback_module.v2_runner_on_ok(task_result)


# Generated at 2022-06-25 08:51:14.533833
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    result_1 = {"_result": {"exception": "An exception occurred during task execution. To see the full traceback, use -vvv. The error was: error message"}}
    ignore_errors_1 = False
    expected_result_1 = "An exception occurred during task execution. To see the full traceback, use -vvv. The error was: error message"
    returned_result_1 = callback_module_1.v2_runner_on_failed(result_1, ignore_errors_1)

    assert(expected_result_1 == returned_result_1)

# Generated at 2022-06-25 08:51:25.806829
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    import mock
    import __builtin__
    class MockDisplay(object):
        def display(self, msg, color=None):
            print(msg)
    mock_display = MockDisplay()
    class MockTask(object):
        def __init__(self):
            self.action = 'action'
    class MockResult(object):
        def __init__(self):
            self._task = MockTask()
            self._host = MockHost()
            self._result = {'changed': False}
    class MockHost(object):
        def get_name(self):
            return 'host_name'
    callback_module_0 = CallbackModule()
    callback_module_0._display = mock_display
    callback_module_0.v2_runner_on_ok(MockResult())
    assert True

# Unit test

# Generated at 2022-06-25 08:51:28.854468
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    result_1 = AnsibleResult(None, None, None)
    ignore_errors_1 = False
    callback_module_1.v2_runner_on_failed(result_1, ignore_errors_1)


# Generated at 2022-06-25 08:51:36.961807
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    result_dict = {'exception': 'test exception message'}
    result = namedtuple('Result', result_dict.keys())(**result_dict)
    result._host = namedtuple('Host', ['get_name'])('test_host')
    result._task = namedtuple('Task', ['action'])('test_action')
    callback_module_1.v2_runner_on_failed(result)


# Generated at 2022-06-25 08:51:40.963042
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed(): 
    ca = CallbackModule()
    ca.v2_runner_on_failed(None)


# Generated at 2022-06-25 08:51:46.798775
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

    callback_module_0 = CallbackModule()

    class Result__task(object):
        def __init__(self):
            self.action = ""

    class Result(object):
        def __init__(self):
            self._result = {}
            self._result['changed'] = False
            self._result['msg'] = 'msg'
            self._task = Result__task()
            class Result__host(object):
                def __init__(self):
                    self.get_name = lambda: 'test'
            self._host = Result__host()

    callback_module_0.v2_runner_on_ok(Result())


# Generated at 2022-06-25 08:51:49.402647
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    cbm = CallbackModule()
    assert cbm.CALLBACK_TYPE == "stdout"
    assert cbm.CALLBACK_NAME == "oneline"
    assert cbm.CALLBACK_VERSION == 2.0


# Generated at 2022-06-25 08:51:50.182394
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    test_case_0()

# Generated at 2022-06-25 08:51:55.046421
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = {}
    ignore_errors_0 = False
    callback_module_0.v2_runner_on_failed(result_0, ignore_errors_0)


# Generated at 2022-06-25 08:52:16.282962
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_1 = CallbackModule()
    runner_on_ok_result_1_1 = runner_on_ok_result('1_1', '1_1', '1_1', '1_1')
    runner_on_ok_result_1_2 = runner_on_ok_result('1_2', '1_2', '1_2', '1_2')
    callback_module_1.v2_runner_on_ok(runner_on_ok_result_1_1)
    callback_module_1.v2_runner_on_ok(runner_on_ok_result_1_2)


# Generated at 2022-06-25 08:52:24.283636
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callbackModule = CallbackModule()
    assert callbackModule is not None

# def test_v2_runner_on_failed():
#     runnerOnFailed = CallbackModule()
#     assert runnerOnFailed is not None

# def test_v2_runner_on_ok():
#     runnerOnOk = CallbackModule()
#     assert runnerOnOk is not None

# def test_v2_runner_on_unreachable():
#     runnerOnUnreachable = CallbackModule()
#     assert runnerOnUnreachable is not None

# def test_v2_runner_on_skipped():
#     runnerOnSkipped = CallbackModule()
#     assert runnerOnSkipped is not None

# Generated at 2022-06-25 08:52:29.038190
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = MockResult()
    assert(callback_module_0.v2_runner_on_failed(result_0, False) != None)
    result_0._task.action = 'test_module'
    assert(callback_module_0.v2_runner_on_failed(result_0, False) != None)
    result_0._host.get_name = lambda : 'host_name'
    result_0._result = {'rc': 0}
    result_0._task.action = 'test_module'
    assert(callback_module_0.v2_runner_on_failed(result_0, False) != None)


# Generated at 2022-06-25 08:52:29.882937
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert callback_module_0 != None


# Generated at 2022-06-25 08:52:36.201026
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # test case 1
    callback_module_1 = CallbackModule()
    result_1 = {'_host' : 'master', '_result' : {}} # type: dict
    result_1['_result']['changed'] = False
    result_1['_result']['message'] = 'ok'
    result_1['_task'] = {'action' : 'shell'} # type: dict
    result_1['_task']['action'] = 'shell'

    c_display_1 = {'verbosity' : '4', 'color' : 'yes'} # type: dict
    callback_module_1._display = c_display_1

    callback_module_1.v2_runner_on_ok(result_1)
    assert callback_module_1._display['color'] == 'yes'



# Generated at 2022-06-25 08:52:42.816502
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module = CallbackModule()
    assert "Ansible callback plugin for oneline output" == callback_module._description.replace("\n", "")
    assert "FAILED" == callback_module._dump_results({'rc': 1, 'msg': 'FAILURE'}, indent=0).replace("\n", "")

# Generated at 2022-06-25 08:52:53.468851
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result_0 = MagicMock()
    result_0.changed.return_value = False
    result_0._host = MagicMock()
    result_0._host.get_name.return_value = 'hostname'
    result_0._task = MagicMock()
    result_0._task.action = 'ansible.utils.unsafe'
    result_0._result = {'ansible_job_id': 'ansible_job_id', 'changed': False}
    callback_module_0.v2_runner_on_ok(result_0)
    result_0.changed.return_value = True
    result_0._result = {'ansible_job_id': 'ansible_job_id', 'changed': True}

# Generated at 2022-06-25 08:52:55.580328
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    result = {'exception': 'traceback text'}
    callback_module_1.v2_runner_on_failed(result)


# Generated at 2022-06-25 08:53:01.349239
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    print('test_CallbackModule')
    callback = CallbackModule()
    if callback is not None:
        assert True

    if callback.CALLBACK_VERSION == 2.0:
        assert True

    if callback.CALLBACK_TYPE == 'stdout':
        assert True

    if callback.CALLBACK_NAME == 'oneline':
        assert True
    #assert callback._dump_results(result=1, indent=0) == True
    #assert callback._load_name_to_path_lookup() == True
    #assert callback._plugin_loaders == True
    #assert callback.v2_playbook_on_cleanup_task_start == True
    #assert callback.v2_playbook_on_handler_task_start == True
    #assert callback.v2_playbook_on_play_start == True


# Generated at 2022-06-25 08:53:04.020847
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()

if __name__ == "__main__":
    test_CallbackModule()

# Generated at 2022-06-25 08:53:49.405360
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    result = {
        "_host": {
            "get_name": lambda :"test"
        },
        "_result": {
            "exception": "some exception happened.\n",
            "stderr": "some error",
            "rc": -1,
            "stdout": "some output"
            }
        }
    callback_module = CallbackModule()
    try:
        expected = "test | An exception occurred during task execution. To see the full traceback, use -vvv. The error was: some exception happened.\n"
        callback_module.v2_runner_on_failed(result)
    except Exception as e:
        assert False, "some exception happened"

# Generated at 2022-06-25 08:53:51.890753
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = {}
    callback_module_0.v2_runner_on_failed(result_0)


# Generated at 2022-06-25 08:53:57.780749
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    result_0 = dict(changed=False, cmd=dict(creates='deadbeef'), delta=0, end='20120407150039.654954', invocation=dict(module_args=dict(arg1='val1', arg2='val2'), module_name='mymod'), rc=0, start='20120407150039.654922', stderr='', stdout='blabla\n')
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_ok(result_0)

# Generated at 2022-06-25 08:54:05.301541
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    
    callback_module_1 = CallbackModule()
    result_1 = None
    result_1_ok = 'ok'
    callback_module_1.v2_runner_on_ok(result_1)
    #assert result_1_ok == callback_module_1.v2_runner_on_ok(result_1)
    if result_1_ok == callback_module_1.v2_runner_on_ok(result_1):
        print(result_1_ok)
    else:
        raise AssertionError


# Generated at 2022-06-25 08:54:06.074588
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:54:07.905556
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_1 = CallbackModule()
    assert callback_module_1 is not None


# Generated at 2022-06-25 08:54:09.212598
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    test_case_0()

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 08:54:16.445367
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0=CallbackModule()
    result_0 = {"exception" : "exception"}
    result_0['_host'] = {'get_name': lambda : 'host1'}
    result_0['_result'] = {}
    result_0['_task'] = {'action': 'action'}

    callback_module_0.v2_runner_on_failed(result_0)


# Generated at 2022-06-25 08:54:25.444232
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = RunnerResult()
    result_0._host = Host()
    result_0._host.get_name = MagicMock(return_value='get_name_return')
    result_0._task = ActionModule()
    result_0._task.action = 'action_return'
    result_0._display = Display()
    result_0._display.verbosity = 1
    result_0._result = {'exception': 'exception_return', 'rc': 0, 'stderr': None, 'stdout': 'stdout_return'}
    assert isinstance(callback_module_0.v2_runner_on_failed(result_0), None)
    result_0._display.verbosity = 4

# Generated at 2022-06-25 08:54:29.915046
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    #global callback_module_0
    callback_module_0 = CallbackModule()
    assert callback_module_0 is not None


# Generated at 2022-06-25 08:56:13.811400
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:56:15.343137
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # Test CallbackModule object creation
    # test case with callback_version  = 2.0 and callback_type = stdout and callback_name = oneline
    test_case_0()

# Generated at 2022-06-25 08:56:25.334096
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_obj_0 = CallbackModule()
    assert hasattr(callback_module_obj_0, '_dump_results')
    assert isinstance(callback_module_obj_0._dump_results, object)

    assert hasattr(callback_module_obj_0, 'v2_playbook_on_stats')
    assert isinstance(callback_module_obj_0.v2_playbook_on_stats, object)

    assert hasattr(callback_module_obj_0, 'v2_playbook_on_play_start')
    assert isinstance(callback_module_obj_0.v2_playbook_on_play_start, object)

    assert hasattr(callback_module_obj_0, 'v2_runner_item_on_ok')

# Generated at 2022-06-25 08:56:34.501863
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    exception = 'exception'
    message = 'message'
    message_0 = 'message_0'
    error = 'error'
    error_0 = 'error_0'
    msg = 'msg'

# Generated at 2022-06-25 08:56:39.639597
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    result = MockResult({'exception':'Exception', '_host':MockHost('host'), '_task':MockTask('task')})
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed(result)


# Generated at 2022-06-25 08:56:41.499898
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = CallbackModule()
    ignore_errors_0 = False
    callback_module_0.v2_runner_on_failed(result_0, ignore_errors_0)


# Generated at 2022-06-25 08:56:45.546976
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_ok


# Generated at 2022-06-25 08:56:50.378267
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    test_host = 'localhost'
    test_data_map = dict()
    test_data_map['action'] = 'shell'
    test_data_map['changed'] = True
    test_data_map['invocation'] = dict()
    test_data_map['invocation']['module_args'] = 'ls /home/ansible/'
    test_data_map['rc'] = 0
    test_data_map['stderr'] = ''
    test_data_map['stdout'] = ''
    test_data_map['stdout_lines'] = list()
    test_data_map['warnings'] = list()

    my_result = dict()
    my_result['_host'] = dict()
    my_result['_host']['get_name'] = test_host

# Generated at 2022-06-25 08:56:51.968197
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed( "result", ignore_errors=True)


# Generated at 2022-06-25 08:57:02.046490
# Unit test for method v2_runner_on_failed of class CallbackModule