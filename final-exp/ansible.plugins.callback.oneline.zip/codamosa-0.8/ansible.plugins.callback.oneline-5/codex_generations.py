

# Generated at 2022-06-11 13:37:03.948752
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Initialize an instance of class CallbackModule
    testobj = CallbackModule()
    # Mock result object
    result = {'_result': {'stdout': 'Mocked stdout', 'stderr': 'Mocked stderr', 'rc': 0}}
    # Create a mock object of class Host
    class Host:
        def get_name():
            return 'Mocked hostname'
    result['_host'] = Host()
    # Call method under test
    testobj.v2_runner_on_failed(result)
    # Check if expected string is displayed
    #assert "Mocked hostname | FAILED! => {}" in capfd.readouterr()[0]

# Generated at 2022-06-11 13:37:12.881292
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback = CallbackModule()
    result = {'exception': 'An exception has occurred. This is the traceback', 'failed': True, 'changed': True}
    callback.v2_runner_on_failed('result', ignore_errors=False)
    assert "An exception has occurred. This is the traceback" in callback.result._result['exception']
    result = {'exception': 'An exception has occurred. This is the traceback', 'failed': False, 'changed': True}
    callback.v2_runner_on_failed('result', ignore_errors=True)
    assert "An exception has occurred. This is the traceback" in callback.result._result['exception']



# Generated at 2022-06-11 13:37:14.093549
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule().CALLBACK_VERSION == 2.0

# Generated at 2022-06-11 13:37:20.116469
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    '''Test CallbackModule.v2_runner_on_ok against sample data from the documentation'''
    from ansible.playbook.task_include import TaskInclude
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    variable_manager = VariableManager()
    host = Host(name='localhost')
    variable_manager.set_host_variable(host, 'omit', ['__ansible_parsed', '__ansible_facts', '__ansible_facts_modified'])
    task = TaskInclude()
    task._role_name = 'test'

# Generated at 2022-06-11 13:37:28.219321
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    import os
    import sys
    import unittest
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.executor import playbook_executor
    from ansible.plugins.callback import CallbackBase

    class TestCallbackModule(unittest.TestCase):
        def setUp(self):
            self.p = CallbackModule()

    # Make sure the setup function runs correctly
    sys.argv = ['']
    test_callback = TestCallbackModule()
    test_callback.setUp()
    assert isinstance(test_callback.p, CallbackModule)
    assert isinstance(test_callback.p, CallbackBase)

    # Create a host, a task and an inventory to check the

# Generated at 2022-06-11 13:37:29.369657
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    pass


# Generated at 2022-06-11 13:37:40.253971
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    module = AnsibleModuleStub()
    class FakeResult:
        def __init__(self, _host, _task, _result, _result_c):
            self._host = _host
            self._task = _task
            self._result = _result
        def __repr__(self):
            return "FakeResult(%s, %s, %s)" % (self._host, self._task, self._result)
    class FakeTask:
        def __init__(self, action):
            self.action = action
        def __repr__(self):
            return "FakeTask(%s)" % (self.action)
    class FakeDisplay:
        def __init__(self):
            self.verbosity = 3
        def display(self, msg, color=None):
            print(msg)


# Generated at 2022-06-11 13:37:42.209296
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    m = CallbackModule()
    assert type(m) == CallbackModule


# Generated at 2022-06-11 13:37:45.566644
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    module = CallbackModule()
    result = dict()
    result['exception'] = 'Error message'
    module.v2_runner_on_failed(result=result)
    assert result['exception'] == 'Error message'

# Generated at 2022-06-11 13:37:52.530073
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Tests if the new output format is printed
    result = type('Result', (object, ),
                  {'_result':{'changed':False},
                   '_host':type('Host', (object, ),
                                {'get_name': lambda self: 'localhost'})(),
                   '_task':type('Task', (object, ),
                                {'action': 'test_module'})()})
    msg = CallbackModule().v2_runner_on_ok(result)
    assert msg == 'localhost | SUCCESS => {}'


# Generated at 2022-06-11 13:38:07.286866
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

    class MockedDisplay:

        def display(self, msg, color=None):
            return (msg, color)

        @property
        def verbosity(self):
            return 3

    display = MockedDisplay()

    class MockedResult:

        def __init__(self):
            self._result = self.get_result()
            self._host = self.get_host()
            self._task = self.get_task()

        def get_result(self):
            return {'changed': False}

        def get_host(self):
            return self.MockedHost()

        def get_task(self):
            return self.MockedTask()

        class MockedHost:

            def get_name(self):
                return 'myhost'


# Generated at 2022-06-11 13:38:08.328281
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    pass
    #TODO

# Generated at 2022-06-11 13:38:11.677775
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    obj = CallbackModule()
    obj._display = None
    result = None
    ignore_errors = False
    obj.v2_runner_on_failed(result, ignore_errors)


# Generated at 2022-06-11 13:38:12.900282
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    pass


# Generated at 2022-06-11 13:38:15.381834
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    c = CallbackModule()
    assert(c.CALLBACK_TYPE == 'stdout')
    assert(c.CALLBACK_VERSION == 2.0)

# Generated at 2022-06-11 13:38:16.428266
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback = CallbackModule()
    assert isinstance(callback, CallbackModule)

# Generated at 2022-06-11 13:38:17.233661
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    x = CallbackModule()
    assert x

# Generated at 2022-06-11 13:38:23.330462
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    import re
    import unittest

    class TestCase(unittest.TestCase):

        def setUp(self):
            import types

            self.__original_display = getattr(CallbackModule, '_display')

            class MockDisplay:

                def __init__(self):
                    self.color = None
                    self.message = None

                def display(self, message, color=None):
                    self.message = message
                    self.color = color

            setattr(CallbackModule, '_display', MockDisplay())

        def tearDown(self):
            type(CallbackModule)._display = self.__original_display

        def test_result_exception_verbosity_below_3_and_action_in_module_no_json(self):
            import ansible.constants as C


# Generated at 2022-06-11 13:38:28.481376
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    import json
    import traceback

    callback = CallbackModule()
    callback._display = None
    class Result:
        _host = Host(name="localhost")
        _result = {
            'exception': traceback.format_exc()
        }
        _task = None

    callback.v2_runner_on_failed(Result())


# Generated at 2022-06-11 13:38:39.491618
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a CallbackModule object
    callback_module_obj = CallbackModule()
    
    # Create a job result object for test
    class RunnerResult(object):
        def __init__(self, host, exception, result, action):
            self._host = host
            self._result = result
            self._result['exception'] = exception
            self._task = task
            
        def get_name(self):
            return self._host.get_name()
            
    class Host(object):
        def __init__(self, name):
            self.name = name
            
        def get_name(self):
            return self.name
            
    class Task(object):
        def __init__(self, action):
            self.action = action
            
    host = Host('_')

# Generated at 2022-06-11 13:38:58.327261
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    cb = CallbackModule()
    #def v2_runner_on_ok(self, result):
    result = {}
    result["changed"] = False
    result["task"] = {}
    result["task"]["action"] = "shell"
    result["result"] = {}
    result["result"]["stdout"] = "Hello World"
    result["result"]["stderr"] = "Hello World"
    result["result"]["changed"] = True
    class result_class():
        def __init__(self):
            self._result = result
            self._task = result["task"]
        def get_name(self):
            return "TEST"
        def get_host(self):
            return self
        def get_task_result(self):
            return self._result

# Generated at 2022-06-11 13:39:05.668687
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    host = Host(name="host")
    task = Task(action='shell')
    task_result = RunnerResult(host=host, task=task, result={'changed': True}, _task=task)
    callback_module = CallbackModule()
    assert callback_module.v2_runner_on_ok(task_result) == "host | CHANGED => {}"
    task_result = RunnerResult(host=host, task=task, result={'changed': False}, _task=task)
    assert callback_module.v2_runner_on_ok(task_result) == "host | SUCCESS => {}"


# Generated at 2022-06-11 13:39:15.047665
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():

    ###########################################################################
    #                                                                         #
    # Unit test for method v2_runner_on_failed of class CallbackModule        #
    #                                                                         #
    ###########################################################################

    import unittest
    import ansible.plugins.callback.oneline as callback_oneline

    # Create a mock object for the class 'CallbackBase'
    class MockCallbackBase(object):
        def __init__(self):
            pass

        def display(self, msg, color):
            print(msg)

    # Create a mock object for the class 'ResultBase'
    class MockResultBase(object):
        def __init__(self):
            self._result = dict()
            self._task = dict()
            self._host = dict()
            self._host.get_name = lambda: 'hostname'



# Generated at 2022-06-11 13:39:15.595359
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    CallbackModule()

# Generated at 2022-06-11 13:39:26.297724
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callbackModule = CallbackModule()
    callbackModule._display = fake_display()
    test_result = fake_result(-1,"power-off() failed")
    callbackModule.v2_runner_on_failed(test_result)


# Generated at 2022-06-11 13:39:36.886885
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    module = "testmodule"
    testmodule = dict(
        name = "contained module",
        short_description = "This is a contained module",
        description = "This is a longer description of a contained module",
        returned = "success",
        sample = "module executed ok",
    )
    inventory = dict(
        host_list = ['localhost-test'],
        group_list = [],
        pattern_list = []
    )


# Generated at 2022-06-11 13:39:38.677866
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    cb_one = CallbackModule()
    assert cb_one is not None


# Generated at 2022-06-11 13:39:40.778842
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    """Unit test for v2_runner_on_failed() method of class CallbackModule."""
    pass

# Generated at 2022-06-11 13:39:51.295726
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    from collections import namedtuple

    Options = namedtuple('Options', ['listtags', 'listtasks', 'listhosts', 'syntax', 'connection','module_path', 'forks', 'remote_user', 'private_key_file', 'ssh_common_args', 'ssh_extra_args', 'sftp_extra_args', 'scp_extra_args', 'become', 'become_method', 'become_user', 'verbosity', 'check', 'diff'])

# Generated at 2022-06-11 13:39:59.958472
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    """
    Note: We could test more data, but this is only a smoke test.
    :return:
    """
    result = None
    ignore_errors = False
    callback = CallbackModule()
    ansible_host_name = "host.local"
    ansible_result = {'exception': "An exception occurred during task execution. The full traceback is:\n" + "The error was: Error"}
    ansible_result2 = {'exception': "An exception occurred during task execution. The full traceback is:\n" + "The error was: Error",
                       'stderr': 'stderr', 'rc': -1, 'stdout': 'stdout'}
    result.__setattr__('_host', type('', (object,), {'get_name': lambda self: ansible_host_name}))


# Generated at 2022-06-11 13:40:18.889755
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    cb = CallbackModule()
    ret = dict(failed = False)
    result = dict(
        _result = dict(
            exception = "this is an exception message"
        )
    )
    cb.v2_runner_on_failed(result)



# Generated at 2022-06-11 13:40:29.325444
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.facts.system.snmp.base import QFactManager

    inventory = InventoryManager(loader=DataLoader())
    hosts = ['localhost']
    inventory.add_group("test_group")
    for host in hosts:
        inventory.add_host(host)
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

# Generated at 2022-06-11 13:40:39.358135
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.utils.vars import merge_hash
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    from ansible import context

    options = context.CLIARGS
    variable_manager = VariableManager()
    loader = DataLoader()

    results_callback = CallbackModule()
    variable_manager = VariableManager()
    passwords = dict(vault_pass='secret')


# Generated at 2022-06-11 13:40:44.365055
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Setup
    ans_instance = CallbackModule()
    ans_instance._display = Display()
    result = Result()
    ignore_errors = False

    # Exercise
    ans_instance.v2_runner_on_failed(result, ignore_errors)

    # Verify
    assert ans_instance._display.msg == "msg"
    assert ans_instance._display.color == "C.COLOR_ERROR"


# Generated at 2022-06-11 13:40:50.977858
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Arrange: Define a Fake Result object
    result = FakeResult()
    fcm = CallbackModule()

    # Act: Call method v2_runner_on_failed with given result
    fcm.v2_runner_on_failed(result)

    # Assert: Check whether given result has been treated properly
    assert result._host.get_name() == "faked_host"
    assert result._result == "{'exception': 'Exc'}"
    assert fcm._display.verbosity == 4



# Generated at 2022-06-11 13:41:01.239699
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    import sys
    import io
    import json
    import unittest

    class TestCallbackModule(CallbackModule):
        def __init__(self):
            self.display_ok_msg_invoked = False
            self.display_changed_msg_invoked = False

        def v2_runner_on_ok(self, results, **kw_args):
            super().v2_runner_on_ok(results, **kw_args)
            if results._result.get('changed', False):
                self.display_changed_msg_invoked = True
            else:
                self.display_ok_msg_invoked = True

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.stdout_capture = io.StringIO()
            sys.stdout = self.stdout_capt

# Generated at 2022-06-11 13:41:04.166245
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    """
    A test for the constructor of class CallbackModule.
    """
    CModule = CallbackModule()
    assert CModule.CALLBACK_VERSION == 2.0

# Generated at 2022-06-11 13:41:12.513620
# Unit test for constructor of class CallbackModule

# Generated at 2022-06-11 13:41:13.309070
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    pass

# Generated at 2022-06-11 13:41:15.971099
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    module = CallbackModule()
    print(module)
    print(module.__dict__)
    print(CallbackModule.__dict__)


# Generated at 2022-06-11 13:41:53.425875
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    """ Constructor doesn't throw exception """
    cm = CallbackModule()

# Generated at 2022-06-11 13:42:02.888549
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

    if 'CallbackModule' not in globals():
        execfile('lib/ansible/plugins/callback/oneline.py')

    module = 'oneline'
    assert module in sys.modules

    obj = CallbackModule()
    assert isinstance(obj, CallbackModule)

    ins_str = str(obj)
    assert ins_str == '<ansible.plugins.callback.oneline.CallbackModule object at 0xXXXXXXXX>'

    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-11 13:42:04.378916
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    import ansible.plugins
    assert isinstance(ansible.plugins.callback.oneline.CallbackModule(), CallbackModule)

# Generated at 2022-06-11 13:42:11.514092
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    """ Unit test for method v2_runner_on_ok of class CallbackModule.
    """
    print("Start testing: v2_runner_on_ok")
    # Mock a result obj
    class Result_obj():
        def __init__(self):
            self._result = dict()
            self._result['changed'] = True
            self._result['results'] = "results"
            # Mock a task obj
            class Task_obj():
                def __init__(self):
                    self.action = "action"
            self._task = Task_obj()
            # Mock a host obj
            class Host_obj():
                def __init__(self):
                    self.get_name = lambda : "host_name"
            self._host = Host_obj()
    my_result_obj = Result_obj()
    # Mock a

# Generated at 2022-06-11 13:42:19.530345
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C

# Generated at 2022-06-11 13:42:30.524070
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    print("Method v2_runner_on_failed of class CallbackModule")
    try:
        cb = CallbackModule()
        result = ansible.plugins.Result()
        cb.v2_runner_on_failed(result, ignore_errors=False) # test
    except Exception as e:
        print("Exception occurred when testing the v2_runner_on_failed of class CallbackModule")
        print("An exception of type {0} occurred. Arguments:\n{1!r}".format(type(e).__name__, e.args))

from ansible.playbook.task_include import TaskInclude
from ansible.playbook.handler_task_include import HandlerTaskInclude
from ansible.playbook.block import Block
from ansible.playbook.play_context import PlayContext

# Generated at 2022-06-11 13:42:35.377510
# Unit test for constructor of class CallbackModule

# Generated at 2022-06-11 13:42:43.382727
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible import context
    import json,callbacks
    cb = callbacks.CallbackModule()
    assert cb.CALLBACK_TYPE == 'stdout'


# Generated at 2022-06-11 13:42:54.550362
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():

    from ansible import constants as C
    from ansible.module_utils._text import to_text

    stdout = to_text('''
    test without exception
    ''')

    exception = to_text('''
    An exception occurred during task execution. To see the full traceback, use -vvv. The error was:\nansible.errors.AnsibleError: original message
    ''')


# Generated at 2022-06-11 13:42:55.103421
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-11 13:44:21.885510
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # TODO: add test
    pass

# Generated at 2022-06-11 13:44:30.307867
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Create an instance of CallbackModule
    callback = CallbackModule()

    # Create an instance of Result
    result = Result()

    # Create an instance of HostVars
    host_vars = HostVars()

    # Set values for host_vars
    host_vars._host = HostVars()
    host_vars.host_name = 'test-host'

    # Set values for result
    result._result = HostVars()
    result.host = HostVars()
    result.host.host_name = 'test-host'
    result.host._host = HostVars()
    result._task = HostVars()
    result._task.action = 'setup'
    result._task.name = 'setup'

    # Call method v2_runner_on_ok of class CallbackModule

# Generated at 2022-06-11 13:44:37.463422
# Unit test for method v2_runner_on_failed of class CallbackModule

# Generated at 2022-06-11 13:44:46.013924
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    cb = CallbackModule()
    cb.CALLBACK_TYPE, cb.CALLBACK_NAME, cb.CALLBACK_VERSION
    cb._command_generic_msg('test_host', {'stdout': 'test_stdout'}, 'test_caption'), \
    cb.v2_runner_on_failed({'_result': {'exception': 'test_error', '_host': {'get_name': lambda: 'test_host'}}}, True), \
    cb.v2_runner_on_ok({'_result': {'changed': True, '_host': {'get_name': lambda: 'test_host'}, '_task': {'action': 'test_action'}},
                        '_task': {'action': 'test_action'}}), \
    cb

# Generated at 2022-06-11 13:44:47.953449
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    result = {"failed": {"msg":"Whoops"}}
    assert CallbackModule().v2_runner_on_failed(result) == None


# Generated at 2022-06-11 13:44:53.037208
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert hasattr(CallbackModule, 'CALLBACK_VERSION')
    assert hasattr(CallbackModule, 'CALLBACK_TYPE')
    assert hasattr(CallbackModule, 'CALLBACK_NAME')
    assert hasattr(CallbackModule, 'v2_runner_on_failed')
    assert hasattr(CallbackModule, 'v2_runner_on_ok')
    assert hasattr(CallbackModule, 'v2_runner_on_unreachable')
    assert hasattr(CallbackModule, 'v2_runner_on_skipped')

test_CallbackModule()

# Generated at 2022-06-11 13:44:55.515595
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create object of class CallbackModule
    c = CallbackModule()
    # Call method v2_runner_on_failed
    c.v2_runner_on_failed(result, ignore_errors=False)


# Generated at 2022-06-11 13:44:58.850795
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    msg = "Test message"
    result = {"stdout":msg, "stderr":msg, "rc":0, "changed":False}
    a = CallbackModule()
    b = a.v2_runner_on_ok(result)
    assert b == None


# Generated at 2022-06-11 13:45:08.128068
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():

    from unittest import TestCase
    from unittest.mock import Mock, patch

    from ansible.plugins.callback import CallbackBase
    from ansible.vars import VariableManager

    display = Mock()
    variable_manager = VariableManager()
    callback = CallbackModule(display=display, variable_manager=variable_manager)

    result = Mock()
    result._host = Mock()
    result._host.get_name.return_value = "127.0.0.1"
    result._result = {"failed": True, "exception": "An exception occurred during task execution. The full traceback is:\nTraceback (most recent call last):"}

    patch("ansible.plugins.callback.plugins.oneline.CallbackModule.C.COLOR_ERROR", "red").start()

# Generated at 2022-06-11 13:45:09.204944
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    module = CallbackModule()