

# Generated at 2022-06-11 13:37:00.723628
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from io import StringIO
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import colorize

    class NullDisplay:
        def display(self, msg, colorize=True, stderr=False, screen_only=False, log_only=False, newline=True):
            print("%s %s %s %s %s %s %s" % (msg, colorize, stderr, screen_only, log_only, newline, msg ))


# Generated at 2022-06-11 13:37:01.735309
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    x = CallbackModule()
    assert x

# Generated at 2022-06-11 13:37:12.582978
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    """
    This test verifies that the v2_runner_on_ok method prints
    the expected output.
    """
    import io
    import sys
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import callback_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    test_stdout = io.StringIO()
    sys.stdout = test_stdout

    play_context = PlayContext(become=False,
                               become_method=None,
                               become_user=None,
                               check_mode=False,
                               diff=False)
    variable_manager = VariableManager(loader=None, inventory=InventoryManager(loader=None))

# Generated at 2022-06-11 13:37:23.126491
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.module_utils._text import to_text
    from ansible_collections.ansible.community.tests.unit.compat import mock

    mock_result_obj = mock.Mock()
    mock_result_obj.host.get_name.return_value = "host.name"
    mock_result_obj.result = {'failed': True, 'exception': "I am bad."}

    cb = CallbackModule()

    # The semantics of a Mock object changed between Python 2 and 3
    cb._display = mock.Mock()
    cb._display.verbosity = 0
    cb.v2_runner_on_failed(mock_result_obj)

    # _command_generic_msg is called with caption == "FAILED"
    cb._display.display.assert_called_with

# Generated at 2022-06-11 13:37:26.605184
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # Constructor with no parameters
    oneline = CallbackModule()
    assert(oneline.CALLBACK_VERSION == 2.0)
    assert(oneline.CALLBACK_TYPE == 'stdout')
    assert(oneline.CALLBACK_NAME == 'oneline')

# Generated at 2022-06-11 13:37:27.721797
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    obj = CallbackModule()
    assert obj is not None

# Generated at 2022-06-11 13:37:38.716100
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    import sys

    class screen_obj(object):
        def __init__(self):
            self.verbosity = 3

        def display(self, txt, color):
            print(txt)

    class host_obj(object):
        def __init__(self):
            self.name = "localhost"

        def get_name(self):
            return "localhost"

    class result_obj(object):
        def __init__(self):
            self.data = {}
            self.msg = ""
            self.task = "This is the task name"
            self.host = host_obj()

        def get(self, key, value):
            return self.data.get(key, value)

        def __getitem__(self, key):
            return self.data.get(key)


# Generated at 2022-06-11 13:37:45.744429
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Given:
    import tempfile
    tmpfile = tempfile.NamedTemporaryFile()
    result = {'exception':{'msg': 'boo'}}
    task = {'action':'boo'}
    resultDic = {'_result':result, '_task':task}
    test_object = CallbackModule(display=None)

    # When:
    res = test_object.v2_runner_on_failed(resultDic, ignore_errors=False)

    # Then:
    assert res == None

# Generated at 2022-06-11 13:37:46.488640
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    CallbackModule()

# Generated at 2022-06-11 13:37:47.404382
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert isinstance(CallbackModule(), CallbackModule)

# Generated at 2022-06-11 13:37:58.194596
# Unit test for constructor of class CallbackModule

# Generated at 2022-06-11 13:38:09.025454
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.module_utils.six import StringIO
    from ansible.utils.display import Display
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.playbook import Playbook
    from ansible.playbook.task import Task

    class TestTask(Task):
        def __init__(self):
            pass

    class TestDisplay(Display):
        def __init__(self):
            self.verbosity = 2

        def display(self, msg, color):
            print("%s: %s" % (color, msg))

    class TestResult(object):
        def __init__(self):
            self._host = TestHost()
            self._task = TestTask()

# Generated at 2022-06-11 13:38:10.657077
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    c = CallbackModule()
    c.v2_runner_on_failed(result)

# Generated at 2022-06-11 13:38:19.616168
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create mocks
    mock_display = Mock()
    mock_result = Mock()
    mock_result._host = Mock()
    mock_result._host.get_name = Mock(return_value="host")
    mock_result._task = Mock()
    mock_result._result = {"exception": "An error occurred"}
    mock_result._task.action = "run"

    # CallbackModule.v2_runner_on_failed(result)
    # CallbackModule.v2_runner_on_failed(result)
    # CallbackModule.v2_runner_on_failed(result)
    # CallbackModule.v2_runner_on_failed(result)

    # Create test object
    cbm = CallbackModule(mock_display)

    # Verify results
    # CallbackModule.v2_runner

# Generated at 2022-06-11 13:38:20.308216
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert True

# Generated at 2022-06-11 13:38:31.351838
# Unit test for method v2_runner_on_failed of class CallbackModule

# Generated at 2022-06-11 13:38:41.683985
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    print()
    print("test_CallbackModule_v2_runner_on_failed()")
    print()

    import json
    
    def get_redis_key(hostname):
        import redis
        r = redis.StrictRedis(host='localhost', port=6379, db=0)
        s = "dockerhost1 | FAILED! => "
        key_list = r.keys(s)
        #print(key_list)
        key = None
        for key_found in key_list:
            if key_found.decode().endswith(hostname):
                key = key_found
                break
        return key
    
    hostname = 'dockerhost1'
    ignore_errors = False

# Generated at 2022-06-11 13:38:51.773123
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # v2_runner_on_ok with changed=True and action in MODULE_NO_JSON
    cb = CallbackModule()

    from ansible.executor.task_result import TaskResult
    results = TaskResult(host=None, task=None, return_data=dict(changed=True))


# Generated at 2022-06-11 13:38:54.990449
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    c = CallbackModule()
    c._display.display("test", color=C.COLOR_SKIP)

if __name__ == '__main__':
    test_CallbackModule()

# Generated at 2022-06-11 13:39:04.563657
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    print("Testing method v2_runner_on_failed ...")
    if not isinstance(result, dict):
        raise Exception("Expected dictionary for result, got %r" % result)


# Generated at 2022-06-11 13:39:17.904751
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    module = CallbackModule()
    result = {'_result': {'exception': 'exception msg'}}
    module.v2_runner_on_failed(result)
    result = {'_result': {'exception': 'exception msg', 'stderr': 'stderr msg'}}
    module.v2_runner_on_failed(result)


# Generated at 2022-06-11 13:39:28.430667
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.executor.task_result import TaskResult
    from ansible.executor.stats import AggregateStats
    from ansible.plugins.callback.default import CallbackModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    import json

    # Load default variables
    loader = DataLoader()
    results_callback = CallbackModule()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)



# Generated at 2022-06-11 13:39:31.619376
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    result = dict( _host = dict( get_name = dict( return_value = "test" ) ), _result = dict( changed = True ) )
    callback = CallbackModule()
    callback.v2_runner_on_ok( result )

# Generated at 2022-06-11 13:39:41.992042
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.playbook.task import Task

    # Create and initialize a test CallbackModule object
    my_callback = CallbackModule()
    my_callback._display = type('Display', (object,), dict())
    my_callback._display.verbosity = 0
    my_callback._display.display = lambda msg, color=None: msg
    my_callback._dump_results = lambda results, indent=4: ''

    # Create and initialize a test Result object
    my_result = type('Result', (object,), dict())
    my_result._task = Task()
    my_result._task.action = 'command'
    my_result._host = type('Host', (object,), dict())
    my_result._host.get_name = lambda: 'localhost'
    my_result._result = dict()
    my_result._

# Generated at 2022-06-11 13:39:44.884912
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert callable(CallbackModule)
    assert issubclass(CallbackModule, CallbackBase)
    callback = CallbackModule()
    assert callback
    assert isinstance(callback, CallbackModule)

# Generated at 2022-06-11 13:39:55.123331
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.plugins.callback import CallbackBase

    class TestCallbackModule(CallbackBase):
        
        def __init__(self):
            super(TestCallbackModule, self).__init__()
        
        def v2_runner_on_failed(self, result, ignore_errors=False):
            super(TestCallbackModule, self).v2_runner_on_failed(result, ignore_errors=False)
            

# Generated at 2022-06-11 13:39:55.536513
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
  assert CallbackModule()

# Generated at 2022-06-11 13:40:01.801610
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
  # Test with error in exception
  test_result = {'exception':'msg'}
  result = CallbackModule()
  assert result.v2_runner_on_failed(test_result) == 'msg'
  # Test with exception and verbose
  test_result = {'exception':'msg', 'verbose':3}
  result = CallbackModule()
  assert result.v2_runner_on_failed(test_result) == 'msg'
  # Test without exception
  test_result = {'verbose':3}
  result = CallbackModule()
  assert result.v2_runner_on_failed(test_result) == None

# Generated at 2022-06-11 13:40:03.389166
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    obj = CallbackModule()
    assert obj._display.columns == 100

# Generated at 2022-06-11 13:40:13.702800
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible import context
    from ansible.playbook.task import Task
    from ansible.utils.display import Display
    from ansible.vars.hostvars import HostVars

    result = type("Result", (object,), {})
    result._result = {
        'changed': True,
        'invocation': {
            'module_args': '',
            'module_name': 'command'
        }
    }
    result._task = Task()
    result._host = HostVars(context.CLIARGS)
    display = Display()
    display.verbosity = 0
    callback = CallbackModule()
    callback.set_options(display=display)

    msg = callback.v2_runner_on_ok(result)


# Generated at 2022-06-11 13:40:33.566346
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule(display = None).CALLBACK_VERSION == 2.0
    assert CallbackModule(display = None).CALLBACK_TYPE == 'stdout'
    assert CallbackModule(display = None).CALLBACK_NAME == 'oneline'


# Generated at 2022-06-11 13:40:38.973702
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callbackModule = CallbackModule()
    class Result:
        _host = '127.0.0.1'
        _result = {'exception': 'Exception'}
        _task = Result
        action = 'shell'

    callbackModule.v2_runner_on_failed(Result)
    # Sample output
    # 127.0.0.1 | FAILED! => {'exception': 'Exception'}


# Generated at 2022-06-11 13:40:47.552283
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback.oneline import CallbackModule
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    
    options = dict(connection='local', module_path=['/to/mymodules'], forks=10, become=True,
                become_method='sudo', become_user='root', check=False, diff=False)
    
    variable_manager = VariableManager()
    loader = DataLoader()
    
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost')
    variable_manager.set_inventory(inventory)
    

# Generated at 2022-06-11 13:40:50.159078
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
   var_1 = CallbackModule()
   if isinstance(var_1, CallbackModule):
       print("True")

# Calling test method
test_CallbackModule()

# Generated at 2022-06-11 13:40:54.911028
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    print("Testing oneline callback")
    callback = CallbackModule()
    print("Testing with 'changed'")
    result = MockResult(True)
    callback.v2_runner_on_ok(result)
    print("Testing without 'changed'")
    result = MockResult(False)
    callback.v2_runner_on_ok(result)


# Generated at 2022-06-11 13:41:02.453715
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # create instance of class CallbackModule
    clb = CallbackModule()

    # create instance of class RunnerCallback
    result = RunnerCallback()

    # define variables
    result._result = {'changed': False, 
        'stdout': 'output message\noutput message\n', 
        'stdout_lines': ['output message', 'output message']}
    result._host = 'localhost'

    # call method v2_runner_on_ok of class CallbackModule
    clb.v2_runner_on_ok(result)


# Generated at 2022-06-11 13:41:11.569883
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible import constants as C
    from ansible.plugins.loader import callback_loader
    from ansible.utils.collections import AttributeDict

    class MockDisplay:
        def __init__(self):
            self.verbosity = 0
            self.called = False

        def display(self, txt, color=None):
            self.display_text = txt
            self.display_verbosity = self.verbosity
            self.display_color = color
            self.called = True

    class MockHost:
        def __init__(self, name):
            self.name = name

        def get_name(self):
            return self.name


# Generated at 2022-06-11 13:41:22.205403
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.loader import callback_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    results_callback = callback_loader.get('oneline', class_only=True)()

    inventory = InventoryManager(loader=None, sources=[])
    variable_manager = VariableManager(loader=None, inventory=inventory)

    playbook_path = './framework/playbooks/hacker_playbook.yml'
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'unreachable': 'yes'}
    passwords = dict(vault_pass='')
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager

# Generated at 2022-06-11 13:41:31.578517
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    '''Unit tests for the method v2_runner_on_failed of the class CallbackModule.'''

    # Importing modules that will be used for manipulation
    import sys
    import io
    import string
    import unittest
    import random

    # Importing the module and class under test
    from ansible.plugins.callback import CallbackModule
    from ansible import constants as C

    # Dummy class for appending captured output of the callback
    class DummyFile(io.StringIO):
        def __init__(self, *args, **kwargs):
            io.StringIO.__init__(self, *args, **kwargs)
            self._out_buf = []

        def write(self, s):
            self._out_buf.append(s)
            io.StringIO.write(self, s)

    #

# Generated at 2022-06-11 13:41:39.918172
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    hostname = 'localhost'
    result = {'stdout': '', 'stderr': '', 'rc': 1}
    result['exception'] = 'error: argument is not found'
    caption = 'FAILED'
    command_result = "localhost | FAILED! => {}"
    _command_generic_msg_result = "localhost | FAILED%7Crc=1%7C%28stdout%29%20%28stderr%29 %20"

    cfmodule = CallbackModule()
    result = cfmodule._command_generic_msg(hostname, result, caption)
    assert result == _command_generic_msg_result

    cmd_result = cfmodule.v2_runner_on_failed(result)
    assert cmd_result == command_result



# Generated at 2022-06-11 13:42:20.317642
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule is not None

# Generated at 2022-06-11 13:42:31.578111
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    import collections
    display = objects.AnsibleDisplay()
    ansible_object = objects.AnsibleModule("name", "description", "version", "a_dynamic_module", "a_replacement")
    result = collections.defaultdict(dict)
    result['_host'] = collections.defaultdict(dict)
    result['_task'] = collections.defaultdict(dict)
    result['_result'] = collections.defaultdict(dict)
    result['_host']['get_name'] = lambda: 'test_host'
    result['_task']['action'] = 'a_dynamic_module'
    result['_result']['changed'] = True
    result['_result']['something'] = 'other'
    result['_result']['ansible_job_id'] = '1'


# Generated at 2022-06-11 13:42:38.994451
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.utils.color import stringc
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()
    run_callback = CallbackModule()

    # Making sure a host name is present in the result
    result = {"_host": "127.0.0.1"}

    # Exception message
    exception_message = "An exception occurred during task execution. To see the full traceback, use -vvv. The error was: The error"

    # We want to test that the output is correct when ansible-playbook is executed with different verbosity levels
    for verbosity_level in [0, 1, 3]:
        play_context.verbosity = verbosity_level

# Generated at 2022-06-11 13:42:43.941244
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    from ansible.plugins.callback import CallbackBase
    cb = CallbackModule()
    assert isinstance(cb, CallbackBase)
    assert cb.CALLBACK_VERSION == 2.0
    assert cb.CALLBACK_TYPE == 'stdout'
    assert cb.CALLBACK_NAME == 'oneline'

# Generated at 2022-06-11 13:42:47.402743
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback = CallbackModule()
    assert callback.CALLBACK_VERSION == 2.0
    assert callback.CALLBACK_TYPE == 'stdout'
    assert callback.CALLBACK_NAME == 'oneline'

# Generated at 2022-06-11 13:42:57.321341
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback import CallbackBase

    callbackBase = CallbackBase()
    callbackBase.verbosity = 3
    oneline = CallbackModule()
    oneline._display = callbackBase
    oneline._dump_results = callbackBase._dump_results
    oneline._dump_results = lambda x, indent=None: 'short_dump'

    result = MagicMock(spec=TaskResult)
    result._host = MagicMock(spec=Host)
    result._host.get_name.return_value = 'test_host'
    result._result = {
        'changed': True,
        'exception': 'short_exception\n',
        'exception_traceback': 'long_exception_traceback'
    }
    result._task = MagicMock(spec=Task)

# Generated at 2022-06-11 13:42:59.019789
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    obj = CallbackModule()
    assert obj.CALLBACK_VERSION == 2.0

# Generated at 2022-06-11 13:43:09.238147
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    import sys
    from ansible.utils.display import Display

    class TaskResult:
        def __init__(self):
            self._result = {}
            self._result['changed'] = 1
            self._result['stdout'] = "abcd efgh\nxyz\n"
            self._result['stderr'] = "ijkl mnop"
            self._result['rc'] = 12

        @property
        def result(self):
            return self._result

    class RunnerResult:
        def __init__(self):
            self._host = "host1"
            self._task = TaskResult()

        @property
        def _result(self):
            return self._task.result

        def _host_get_name(self):
            return self._host

    MyDisplay = Display()
    MyDisplay.verb

# Generated at 2022-06-11 13:43:10.270303
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # TODO: Implement!
    return


# Generated at 2022-06-11 13:43:16.645718
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    import ansible.plugins.callback.oneline
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    import os
    import json
    import logging
    import collections
    import sys
    import ansible.vars
    import ansible.utils
    import ansible.module_utils.basic
    from ansible.utils.display import Display

    # Create a playbook executor
    loader = DataLoader()
    variableManager = VariableManager()
    inventoryManager = InventoryManager(loader=loader, sources='localhost,')
    display = Display()
    variableManager.set_inventory(inventoryManager)

# Generated at 2022-06-11 13:44:53.992822
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Instantiate class
    callback_module = CallbackModule()

    # Sample result that should succeed
    result = {
        "changed": True,
        "invocation": {
            "module_args": {
                "name": "test"
            }
        },
        "module_stdout": "",
        "stdout": "",
        "stdout_lines": [
            ""
        ]
    }

    # Should succeed without error
    callback_module.v2_runner_on_ok(result)


# Generated at 2022-06-11 13:44:54.775330
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule


# Generated at 2022-06-11 13:44:58.684748
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    import json
    from ansible.plugins.callback.default import CallbackModule

    result = json.loads("""{
        "changed": false,
        "msg": "All items completed"
    }""")

    callback = CallbackModule()
    callback.v2_runner_on_ok("host", result)


# Generated at 2022-06-11 13:45:05.654252
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # Test for existing attributes
    assert hasattr(CallbackModule, 'CALLBACK_VERSION')
    assert hasattr(CallbackModule, 'CALLBACK_TYPE')
    assert hasattr(CallbackModule, 'CALLBACK_NAME')
    assert hasattr(CallbackModule, 'v2_runner_on_failed')
    assert hasattr(CallbackModule, 'v2_runner_on_ok')
    assert hasattr(CallbackModule, 'v2_runner_on_unreachable')
    assert hasattr(CallbackModule, 'v2_runner_on_skipped')

# Test for class methods

# Generated at 2022-06-11 13:45:12.371095
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    ansible_offline = False
    task_name = 'ping'
    task_args = {}
    play_context = 'none'

    cbm = CallbackModule()
    cbm.set_options(task_name=task_name, task_args=task_args, play_context=play_context, ansible_offline=ansible_offline)
    assert (cbm.task_name == task_name)
    assert (cbm.task_args == task_args)
    assert (cbm.play_context == play_context)
    assert (cbm.ansible_offline == ansible_offline)

# Generated at 2022-06-11 13:45:23.550750
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.plugins.callback.oneline import CallbackModule

    cm = CallbackModule()
    cb = CallbackBase()
    cb.verbosity = 2
    cm.set_options(verbosity=cb.verbosity, color=False, quiet=False)
    cm.set_play_context(play_context=cb)
    cm.v2_on_any(cb)
    cm.verbosity = 2

# Generated at 2022-06-11 13:45:33.350405
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    import unittest
    class TestClass(unittest.TestCase):
        def setUp(self):
            self.instance = CallbackModule()
        def test_v2_runner_on_ok(self):
            result = {'_host': {'get_name': lambda: 'hostname'},
                      '_result': {'changed': False, 'rc': 0, 'stdout': 'stdout', 'stderr': 'stderr'},
                      '_task': {'action': 'test'}}
            expected_result = "hostname | SUCCESS => {'rc': 0, 'stdout': 'stdout', 'stderr': 'stderr'}"

# Generated at 2022-06-11 13:45:43.444807
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # pylint: disable=protected-access
    cm = CallbackModule()
    # task which is not changed
    result = Result(
        'host1',
        {
            '_ansible_verbose_always': True,
            'changed': False,
            'invocation': {
                'module_args': {}
            }
        },
        'action'
    )
    cm.v2_runner_on_ok(result)
    assert cm._display._out_stack[0]['color'] == C.COLOR_OK
    assert 'SUCCESS' in cm._display._out_stack[0]['data']
    # task which is changed

# Generated at 2022-06-11 13:45:48.923209
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    os = "linux"
    tmpdir = "import_playbook"
    connection = "ssh"
    ansible_version = "1.9.4-dev"
    ansible_verbosity = 2
    ansible_inventory = "/home/travis/build/Liooo/ansible-docker-client/test/ansible_hosts"
    ansible_playbook = "/home/travis/build/Liooo/ansible-docker-client/ansible_playbook_call.py"
    ansible_sudo = "yes"
    callback = CallbackModule(display=None)

# Generated at 2022-06-11 13:45:50.228926
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # arrange
    C_callbackModule = CallbackModule()

    # act
    C_callbackModule.v2_runner_on_failed()
