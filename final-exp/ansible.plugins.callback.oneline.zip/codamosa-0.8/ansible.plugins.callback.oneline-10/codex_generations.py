

# Generated at 2022-06-11 13:37:02.193745
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create an instance of CallbackModule
    callback_module = CallbackModule()
    # Create an instance of CallbackBase
    callback_base = CallbackBase()
    # Create an instance of module_utils.common.removed
    module_utils_common_removed = callback_base.module_utils.common.removed
    # Add the content of module_utils.common.removed to module_utils.common.missing
    callback_base.module_utils.common.missing = module_utils_common_removed
    # Create a variable ansible_verbosity with the value 0
    callback_base.ansible_verbosity = 0
    # Create a variable verbosity with the value 0
    callback_base.verbosity = 0
    # Create an instance of ansible.constants.Color
    ansible_constants_color = C
   

# Generated at 2022-06-11 13:37:09.315741
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.collections.ansible.community.plugins.callback import CallbackModule
    display_obj = ansible.collections.ansible.community.plugins.callback.CallbackModule()
    display_obj.verbosity = 3
    result = {}
    task_name = 'Display Module'
    ansible.collections.ansible.community.plugins.callback.CallbackModule().runner_on_failed(result, display_obj, task_name)
    return True


# Generated at 2022-06-11 13:37:17.631497
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible import constants as C
    from ansible.plugins.callback import CallbackBase
    import sys

    # constants.CLI_OPTIONS = ['', '', '']
    C.color = True
    C.force_color = True

    callback = CallbackModule()
    class Dummy(object):
        def __init__(self):
            self.display = lambda msg, color: sys.stdout.write("%s\n" % msg)
            self.verbosity = 0
    callback._display = Dummy()

    class Host:
        name = 'test'
        get_name = lambda self: self.name
    class Task:
        action = None

    class Result:
        host = Host()
        task = Task()
        _result = {'changed': True}

# Generated at 2022-06-11 13:37:27.263296
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Setup
    result = Result()
    result._result = {'changed': False}
    result._task = Task()
    result._task.action = 'file'
    result._host = Host()
    result._host.get_name = MagicMock(return_value='yoda.example.com')
    callback_module = CallbackModule()
    callback_module._dump_results = MagicMock(return_value='{ \'foo\': 42 }')
    callback_module._display = Display()

    # Exercise
    callback_module.v2_runner_on_ok(result)

    # Verify
    assert callback_module._display.display.call_args_list == [call('yoda.example.com | SUCCESS => { \'foo\': 42 }',
                                                                    color='green')]


# Generated at 2022-06-11 13:37:29.681321
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # test CallbackModule object
    callback = CallbackModule()

    assert callback.v2_runner_on_ok(1) == None

# Generated at 2022-06-11 13:37:31.185953
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # TODO: Need to implement test for CallbackModule
    pass

# Generated at 2022-06-11 13:37:31.815525
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-11 13:37:42.653348
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    import pytest
    import sys
    sys.path.append('/Users/pkim/OneDrive - Microsoft/Documents/workspaces/ansible/libraries/plugins/callbacks')
    import display
    from callback_module import CallbackModule
    from ansible.vars.manager import VariableManager
    from ansible.vars import Variable
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.task import Task

    class Out(object):

        @staticmethod
        def write(msg, color=None):
            print(msg)

        @staticmethod
        def flush():
            return

    display.Display.verbosity = 1
    display

# Generated at 2022-06-11 13:37:52.742667
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.utils.color import stringc
    # This test is not very accurate. It has a lot of mocks and assumptions.
    # It does not test different callbacks, like task_start or runner_retry.
    # Reason for this is that it is quite dificult to test when we have
    # nested classes in the code.

    # Setup the basic mocks for the test
    import StringIO
    output = StringIO.StringIO()

# Generated at 2022-06-11 13:37:59.917716
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    caplog.set_level(logging.DEBUG)
    result = Result('127.0.0.1', 'test_task')
    result._result = {'failed': True, 'exception': 'Exception'}
    c = CallbackModule()
    c.v2_runner_on_failed(result)
    log_messages = "\n".join(record.message for record in caplog.records)
    assert "An exception occurred during task execution. To see the full traceback" in log_messages
    assert "127.0.0.1 | FAILED! => {'failed': True, 'exception': 'Exception'}" in log_messages

# Generated at 2022-06-11 13:38:10.165943
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    obj = CallbackModule()
    assert obj.CALLBACK_VERSION == 2.0
    assert obj.CALLBACK_TYPE == 'stdout'
    assert obj.CALLBACK_NAME == 'oneline'
    assert obj._command_generic_msg('abc', {'stdout': "hello"}, 'ok') == 'abc | ok | rc=-1 | (stdout) hello'


# Generated at 2022-06-11 13:38:17.470439
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a sample result
    result = MockResult()
    result._result = {
        "exception": "foo"
    }
    result._task = MockTask()
    result._task.action = "shell"
    result._host.get_name.return_value = "localhost"

    # Create a sample callback module
    callback = CallbackModule()

    # Execute the method
    callback.v2_runner_on_failed(result)

    # Check the result
    callback._display.display.assert_has_calls([
        call(ANY, color=ANY)
    ])


# Generated at 2022-06-11 13:38:19.753969
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule.CALLBACK_VERSION == 2.0
    assert CallbackModule.CALLBACK_TYPE == 'stdout'
    assert CallbackModule.CALLBACK_NAME == 'oneline'

# Generated at 2022-06-11 13:38:20.988711
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    cb = CallbackModule()
    print('Success')

# Generated at 2022-06-11 13:38:23.090278
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    module = CallbackModule()
    issubclass(CallbackModule, CallbackBase)

# Generated at 2022-06-11 13:38:28.623804
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Test execution with args
    result = "test_result"
    ignore_errors = "test_ignore_errors"
    test_obj = CallbackModule()

    # Test execution with default args
    test_obj.v2_runner_on_failed(result)

    # Test execution with default args
    test_obj.v2_runner_on_failed(result, ignore_errors)


# Generated at 2022-06-11 13:38:39.623094
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # CallbackModule is abstract; create an instance of one of its subclasses instead
    cb_mod = CallbackModule()
    # Simple success case: no stdout/stderr, rc=0
    result = {'stdout': '', 'stderr': '', 'rc': 0}
    out = cb_mod._command_generic_msg('foo', result, 'FAILED')
    assert out == 'foo | FAILED | rc=0 | (stdout) '
    # No stdout or stderr, non-zero rc
    result = {'stdout': '', 'stderr': '', 'rc': 1}
    out = cb_mod._command_generic_msg('foo', result, 'FAILED')
    assert out == 'foo | FAILED | rc=1 | (stdout) '


# Generated at 2022-06-11 13:38:42.042559
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Test for method v2_runner_on_ok(result)
    module = CallbackModule()
    module.v2_runner_on_ok('result')
    assert False


# Generated at 2022-06-11 13:38:52.865124
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback.oneline import CallbackModule
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    host = Host('testname')
    task = Task()
    task._role = None
    task._parent = None
    task._block = []
    task._attributes = {}
    task._dep_chain = ()
    task._role = None
    task._role_name = None
    task._task_deps = {}
    task._loaded_from = None
    task._always_run = False
    task._cleanup_action = None
    task._loop = None
    task._loop_args = None
    task._loop_items = None
    task._tmp = None
    task._tags = set

# Generated at 2022-06-11 13:38:55.927957
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    ansible = Ansible()
    results = ansible.run_simple()
    module = CallbackModule(display=AnsibleDisplay())
    module.v2_runner_on_ok(result=results)

# Generated at 2022-06-11 13:39:10.669275
# Unit test for method v2_runner_on_ok of class CallbackModule

# Generated at 2022-06-11 13:39:12.043411
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    obj = CallbackModule()
    assert isinstance(obj, CallbackModule)

# Generated at 2022-06-11 13:39:18.143844
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # init
    result = FakeResult("myhost", {"changed": False})
    callback = CallbackModule()
    callback._display.display = MagicMock()

    # execute
    callback.v2_runner_on_ok(result)
    # test
    callback._display.display.assert_called_once_with("myhost | SUCCESS => {'changed': False}", color=C.COLOR_OK)


# Generated at 2022-06-11 13:39:19.231467
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    c = CallbackModule()

# Generated at 2022-06-11 13:39:29.517489
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback import CallbackModule
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    import unittest
    import mock
    import sys
    import os


# Generated at 2022-06-11 13:39:39.752801
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Tests for "empty" result
    cb = CallbackModule()
    cb.v2_runner_on_ok({})
    test_string = cb._display.display.call_args_list[0][0][0].replace('\x1b[0m', '').replace('\x1b[m', '').replace('\x1b[0;32m', '')
    assert test_string == " | SUCCESS => "
    
    # Tests for "changed" result
    cb = CallbackModule()
    cb.v2_runner_on_ok({'changed': True})

# Generated at 2022-06-11 13:39:50.234103
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():

    from ansible import context

    from ansible.plugins.callback.oneline import CallbackModule
    from ansible.utils.color import stringc

    # This is required for unittesting on Python 2
    # since json and json.dumps does not play well
    # with unicode strings
    import sys
    reload(sys)
    sys.setdefaultencoding("utf-8")

    # 1. Create a plugin
    # 2. Create an object of the plugin
    # 3. Set the stdout to an object of StringIO class
    # 4. Call the v2_runner_on_failed method of the plugin
    # 5. Assert the behaviour

    ctx = context.CLIContext()
    ctx.stdout = sys.stdout
    ctx.verbosity = 1

# Generated at 2022-06-11 13:39:59.282760
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    import pytest
    from ansible.plugins.callback import CallbackModule
    from ansible.plugins.callback.oneline import CallbackModule as CM
    from ansible import constants as C

    # Create a mocker object
    mocker = pytest.Mock(spec=CallbackModule, instance=True)

    # Create a mock result object
    result = pytest.Mock()
    result.get.return_value = 'test_value'

    # Create a mock display object
    display = pytest.Mock()
    display.display.side_effect = 'testing_display'
    display.verbosity = 1

    # Create a mock _dump_results object
    dump_results = pytest.Mock(spec=CM._dump_results)
    dump_results.return_value = 'testing_dump_results'

    # Create an

# Generated at 2022-06-11 13:40:02.984713
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    y = CallbackModule()
    y.v2_runner_on_failed()
    y.v2_runner_on_ok()
    y.v2_runner_on_skipped()
    y.v2_runner_on_unreachable()

# Generated at 2022-06-11 13:40:05.970130
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    obj = CallbackModule()
    assert obj.CALLBACK_VERSION == 2.0
    assert obj.CALLBACK_TYPE == 'stdout'
    assert obj.CALLBACK_NAME == 'oneline'

# Generated at 2022-06-11 13:40:23.650257
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    c1 = CallbackModule()
    assert c1._display.colorize is None

# Generated at 2022-06-11 13:40:31.491281
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    """Create an instance of CallbackModule and call methods."""
    callback = CallbackModule()
    assert callback
    callback.v2_runner_on_failed({'ansible_job_id': '2222'})
    callback.v2_runner_on_ok({'ansible_job_id': '2222'})
    callback.v2_runner_on_unreachable({'msg': 'test'})
    callback.v2_runner_on_skipped({'ansible_job_id': '2222'})

# Generated at 2022-06-11 13:40:35.168828
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback = CallbackModule()

    assert callback._plugin_name == 'oneline'
    assert callback.CALLBACK_NAME == 'oneline'
    assert callback.CALLBACK_TYPE == 'stdout'
    assert callback.CALLBACK_VERSION == 2.0

# Generated at 2022-06-11 13:40:36.080278
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    obj = CallbackModule()
    assert obj

# Generated at 2022-06-11 13:40:45.541479
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    data = {}
    host = {"name": "localhost"}
    result = {
        "ansible_job_id": "3380.1",
        "changed": False,
        "cmd": "echo foo",
        "delta": "0:00:00.000227",
        "end": "2019-09-04 21:21:10.913137",
        "invocation": {
            "module_args": "echo foo",
            "module_name": "command"
        },
        "rc": 0,
        "start": "2019-09-04 21:21:10.912910",
        "stderr": "",
        "stderr_lines": [],
        "stdout": "foo",
        "stdout_lines": [
            "foo"
        ]
    }
    obj

# Generated at 2022-06-11 13:40:51.103819
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    result_dict = dict()
    result_dict['stdout'] = ''
    result_dict['rc'] = -1

    result_dict['exception'] = "An exception occurred during task execution."

    result_dict['msg'] = "UNREACHABLE!"

    runner_on_failed = CallbackModule()
    runner_on_failed.v2_runner_on_failed(result_dict, ignore_errors=True)

# Generated at 2022-06-11 13:40:54.403464
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module = CallbackModule()
    assert callback_module.CALLBACK_VERSION == 2.0
    assert callback_module.CALLBACK_TYPE == 'stdout'
    assert callback_module.CALLBACK_NAME == 'oneline'

# Generated at 2022-06-11 13:41:05.120040
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():

    """ Mock the display object so that we can capture the output and test against it """
    class MockDisplay(object):
        def __init__(self):
            self.data = {}
            self.data['status'] = []
            self.data['errors'] = []

        def display(self, msg, color=None, stderr=False, screen_only=False, log_only=False):
            self.data['status'].append(msg)

    class MockRunnerResult(object):
        def __init__(self):
            self._result = {}

        def get_name(self):
            return 'Test Host'

    # Setup
    display = MockDisplay()
    cm = CallbackModule()
    cm.set_options(direct={'verbosity': 1})
    cm._display = display

    # Set mock results

# Generated at 2022-06-11 13:41:13.041292
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    import json
    import tempfile

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-11 13:41:16.211884
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    module = CallbackModule()
    assert module.CALLBACK_VERSION == 2.0
    assert module.CALLBACK_TYPE == 'stdout'
    assert module.CALLBACK_NAME == 'oneline'

# Generated at 2022-06-11 13:41:57.116394
# Unit test for constructor of class CallbackModule
def test_CallbackModule():

    callback = CallbackModule()

    assert callback.CALLBACK_VERSION == 2.0
    assert callback.CALLBACK_TYPE == 'stdout'
    assert callback.CALLBACK_NAME == 'oneline'



# Generated at 2022-06-11 13:41:58.111506
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    a = CallbackModule()

# Generated at 2022-06-11 13:41:58.907620
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    assert True

# Generated at 2022-06-11 13:42:01.571636
# Unit test for constructor of class CallbackModule
def test_CallbackModule():

    # Test initializing an instance of the class CallbackModule
    ret = CallbackModule()
    assert isinstance(ret, CallbackModule)

# Unit test of v2_runner_on_failed

# Generated at 2022-06-11 13:42:02.807671
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module = CallbackModule()
    assert callback_module != None

# Generated at 2022-06-11 13:42:09.750147
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

    # Dummy class that can be used as input to the method under test
    class Result:
        # The needed attributes for the method under test
        _result = {'changed': True}
        _host = {'get_name': 'localhost'}

    # Create object of CallbackModule
    cm = CallbackModule()

    # Get the expected output of the method under test
    result = cm.v2_runner_on_ok(Result())

    # Show the output of the method under test, for debugging only
    print("\nOutput of v2_runner_on_ok:\n" + result)

    # The method under test is only a display method and does not have a return value,
    # a return value is not necessary for this test
    return


# Generated at 2022-06-11 13:42:17.216072
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.errors import AnsibleError
    from ansible.utils.display import Display
    from ansible.plugins.callback import CallbackBase
    import sys
    import os
    import json

    loader = DataLoader()
    display = Display()
    variable_manager = VariableManager()
    host = Host()
    host.name = 'localhost'

# Generated at 2022-06-11 13:42:19.242986
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    print("Testing")
    CallbackModule()
    print("Success")

if __name__ == '__main__':
    test_CallbackModule()

# Generated at 2022-06-11 13:42:30.185496
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    import collections
    import io
    import sys
    result_res = collections.namedtuple("result", "result")
    ansible_module = collections.namedtuple("ansible_module", "action")
    host = collections.namedtuple("host", "get_name result")
    host_result = collections.namedtuple("host_result", "result")
    display = collections.namedtuple("display", "display verbosity")
    callback = CallbackModule()
    callback.CALLBACK_VERSION = 2.0
    callback.CALLBACK_NAME = "oneline"
    callback.CALLBACK_TYPE = "stdout"
    callback.enabled = True
    callback._display = display(display=lambda x, y : [result_res(x)] if y else [result_res(x)], verbosity=3)
   

# Generated at 2022-06-11 13:42:32.733998
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    global callbackModule
    callbackModule = CallbackModule()
    assert callbackModule != None 

# Testing if the class CallbackModule has property v2_runner_on_failed

# Generated at 2022-06-11 13:43:48.592991
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert isinstance(CallbackModule(), CallbackModule)

# Generated at 2022-06-11 13:43:54.684231
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callbacks.oneline import CallbackModule
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.common._collections_compat import Mapping

    # Creating mock
    result = Mapping()
    result._result = {
        'exception': 'RuntimeError',
        'msg': 'The module failed!',
        'rc': 1
    }
    result._host = Mapping()
   

# Generated at 2022-06-11 13:43:55.322687
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
	pass
	

# Generated at 2022-06-11 13:43:59.172792
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback = CallbackModule()
    assert isinstance(callback, CallbackModule)
    assert callback.CALLBACK_VERSION == 2.0
    assert callback.CALLBACK_TYPE == 'stdout'
    assert callback.CALLBACK_NAME == 'oneline'



# Generated at 2022-06-11 13:44:00.419569
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    ansib = CallbackModule()
    res = {}
    ansib.v2_runner_on_failed(res)

# Generated at 2022-06-11 13:44:03.324350
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    class V2Unicode(unicode):
        @property
        def __class__(self):
            return unicode

    assert isinstance(V2Unicode(''), unicode)
    assert issubclass(type(V2Unicode('')), unicode)

# Generated at 2022-06-11 13:44:07.921290
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    hostname = "hostname"
    result = {"result": "result"}
    cbc = CallbackModule()
    cbc._display = MockDisplay()
    cbc.v2_runner_on_failed(result) 
    assert cbc._display.display_args[0] == "%s | FAILED! => %s" % (hostname, result)
    assert cbc._display.display_args[1] == C.COLOR_ERROR


# Generated at 2022-06-11 13:44:15.403954
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # define a host
    host = FakeHost()
    # define a result object
    result = FakeResult()
    # define a callback object
    callback = CallbackModule()
    # fill result object with some data
    result._result['changed'] = False
    # test if the method returns a string which is the expected string
    assert callback.v2_runner_on_ok(result) == "hostname | SUCCESS => {}"
    # fill result object with some data
    result._result['changed'] = True
    # test if the method returns a string which is the expected string
    assert callback.v2_runner_on_ok(result) == "hostname | CHANGED => {}"


# Generated at 2022-06-11 13:44:23.497467
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    import sys
    orig_display = sys.stdout

    # Mock class for display
    class Display:
        def display(self, str, color=None):
            orig_display.write(str + "\n")
    
    class Result:
        def __init__(self, host, task, result):
            self._host = host
            self._task = task
            self._result = result

    # Mock class for host
    class Host:
        def __init__(self, name):
            self._name = name

        def get_name(self):
            return self._name

    # Mock class for task
    class Task:
        def __init__(self, action):
            self._action = action

        @property
        def action(self):
            return self._action

    # Basic test
    host = Host('localhost')

# Generated at 2022-06-11 13:44:29.951322
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    from ansible.module_utils._text import to_text
    from ansible.plugins.callback.oneline import CallbackModule
    from ansible.utils.display import Display
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    display = Display()
    variable_manager = VariableManager()
    inventory = Inventory(
        variable_manager=variable_manager,
        loader=None,
        host_list=[]
    )
    callback = CallbackModule(
        display=display,
        options=None,
        inventory=inventory,
    )
    assert callback != None
    return callback

