

# Generated at 2022-06-12 01:14:03.813908
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    import re
    
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert re.match(r'^[0-9]{11}$', snils)


# Generated at 2022-06-12 01:14:14.511471
# Unit test for method snils of class RussiaSpecProvider

# Generated at 2022-06-12 01:14:17.307019
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert snils is not None
    assert len(snils) == 11
    assert str.isdigit(snils)
    print(snils)


# Generated at 2022-06-12 01:14:28.075259
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.builtins.base import BaseSpecProvider
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.locales import LocalesProvider
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.types import Seed
    ru = RussiaSpecProvider(seed=Seed(1))
    print('_______')
    en = ru.snils()
    ru = ru.snils()
    print(en)
    print(ru)
    assert ru == '41917492600'


# Generated at 2022-06-12 01:14:33.841120
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()

    def snils_exists_9_digits(snils):
        if len(snils) == 9:
            return snils


    provider.add_formatter('snils', snils_exists_9_digits)

    for _ in range(0, 99999):
        snils = provider.snils()
        assert len(str(snils)) == 9


# Generated at 2022-06-12 01:14:38.672093
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils[:3].isdigit()
    assert snils[3:].isdigit()


# Generated at 2022-06-12 01:14:41.285931
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test."""
    rp = RussiaSpecProvider()
    result = rp.snils()
    assert len(result) == 11


# Generated at 2022-06-12 01:14:46.128401
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # This test checks the method RussiaSpecProvider.snils()
    # The result must contain 9 characters (equal to the length of 9),
    # and the last character must be a control digit that matches the
    # control digit of the following code

    import mimesis.providers.russia as russia

    r = russia.RussiaSpecProvider()

    assert len(r.snils()) == 11



# Generated at 2022-06-12 01:14:48.587564
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    assert provider.snils() == '41917492600'

# Generated at 2022-06-12 01:14:52.791447
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert snils.isdigit() and len(snils) == 11


# Generated at 2022-06-12 01:15:19.018082
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Generate snils with special algorithm.

    :return: SNILS.

    :Example:
        41917492600.
    """
    numbers = []
    control_codes = []

    for i in range(0, 9):
        numbers.append(random.randint(0, 9))

    for i in range(9, 0, -1):
        control_codes.append(numbers[9 - i] * i)

    control_code = sum(control_codes)
    code = ''.join(str(number) for number in numbers)

    if control_code in (100, 101):
        snils = code + '00'
        return snils

    if control_code < 100:
        snils = code + str(control_code)
        return snils

    if control_code > 101:
        control

# Generated at 2022-06-12 01:15:24.911458
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    snils=RussiaSpecProvider()
    s=snils.snils()
    print(s)
    import re
    pattern=re.compile(r'([0-9]{3})[- ]([0-9]{3})[- ]([0-9]{3})[- ]([0-9]{2})')
    myList=pattern.findall(s)
    print(myList)


# Generated at 2022-06-12 01:15:29.129754
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """
    Test for method snils.
    """
    local_rsp = RussiaSpecProvider()
    assert type(local_rsp.snils()) == str and len(local_rsp.snils()) == 11


# Generated at 2022-06-12 01:15:32.770622
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    ru_provider = RussiaSpecProvider()
    result = ru_provider.snils()
    assert len(result) == 11
    assert result[-2:] != '00'

# Generated at 2022-06-12 01:15:42.870497
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.enums import Gender
    from mimesis.providers.ru.personal import RussiaPersonalProvider 
    russian_person = RussiaPersonalProvider()
    
    # Initialization of SNILS Provider
    snils_provider = RussiaSpecProvider(russian_person.seed)
    # Check if all 11 digits in them
    assert len(snils_provider.snils()) == 11
    # Check if the last 3 digits are the control digits in accordance with the algorithm
    snils_provider.snils()
    snils_provider.snils()
    snils_provider.snils()
    assert snils_provider.snils()[8:] in ['00', '38', '17']
    assert snils_provider.snils()[8:] in ['00', '38', '17']

# Generated at 2022-06-12 01:15:49.809237
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Data:
    # - Initial set-up of RussiaSpecProvider class
    en_us_provider = RussiaSpecProvider()

    # Unit test:
    # - Generate snils by method of RussiaSpecProvider class
    snils = en_us_provider.snils()
    
    # Assertion of the test:
    # - Assert the generated snils by the method of RussiaSpecProvider class
    assert len(snils) == 11



# Generated at 2022-06-12 01:15:53.267151
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    s = provider.snils()
    print(s)
    assert type(s) == str
    assert len(s) == 11


# Generated at 2022-06-12 01:15:55.476942
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    snils = RussiaSpecProvider().snils()
    assert snils.isnumeric()
    print('snils:', snils)


# Generated at 2022-06-12 01:15:58.589951
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia = RussiaSpecProvider()
    snils = russia.snils()
    assert len(snils) == 11
    assert snils[0] == '1'

# Generated at 2022-06-12 01:15:59.410530
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    provider.snils()

# Generated at 2022-06-12 01:16:43.110511
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():

    print("\n")
    print("*" * 40)
    print("Unit test for method snils of class RussiaSpecProvider")
    print("*" * 40)

    print("\n")
    print("---> instantiate RussiaSpecProvider")
    r = RussiaSpecProvider(seed=None)

    print("---> test for random snils from RussiaSpecProvider")
    print("---> random snils from RussiaSpecProvider is {}".format(r.snils()))
    print("---> random snils from RussiaSpecProvider is {}".format(r.snils()))
    print("---> random snils from RussiaSpecProvider is {}".format(r.snils()))
    print("---> random snils from RussiaSpecProvider is {}".format(r.snils()))

# Generated at 2022-06-12 01:16:52.590487
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    s = RussiaSpecProvider().snils()
    issue = True
    print("Вывод: " + s)
    nums = [int(x) for x in s]

    control_codes = []
    for i in range(9, 0, -1):
        control_codes.append(nums[9 - i] * i)

    if sum(control_codes) % 101 % 100 != nums[9] * 10 + nums[10]:
        issue = False
    assert issue

# Generated at 2022-06-12 01:16:56.935749
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test to test method snils of class RussiaSpecProvider."""
    assert len(RussiaSpecProvider().snils()) == 11


# Generated at 2022-06-12 01:17:02.502408
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
  """Test method snils of class RussiaSpecProvider."""
  rsp = RussiaSpecProvider()
  assert rsp.snils() == '41917492600'
  assert rsp.snils(seed="test") == '41917492600'

  assert rsp.snils(seed=123) == '36853089700'
  assert rsp.snils(seed="test2") == '10523240400'


# Generated at 2022-06-12 01:17:04.322860
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider"""
    russia = RussiaSpecProvider()
    russia.seed(0)
    assert russia.snils() == '41917492600'


# Generated at 2022-06-12 01:17:07.530410
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()
    for _ in range(0, 10):
        snils = rsp.snils()
        assert len(snils) == 11
        assert snils.isdigit()



# Generated at 2022-06-12 01:17:09.882702
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test method snils."""
    r = RussiaSpecProvider()
    snils = r.snils()
    assert len(snils) == 11



# Generated at 2022-06-12 01:17:17.125970
# Unit test for method snils of class RussiaSpecProvider

# Generated at 2022-06-12 01:17:26.002606
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """
    You can test the correctness of the method snils.

    For this purpose:
    1) Create an object of the class RussiaSpecProvider;
    2) Modify the required attributes (if any);
    3) Call method snils and compare the results of it with the expected one.

    :return: This function does not return any values. It's a unit test.
    """
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11, 'RussiaSpecProvider.snils() - wrong generation'


# Generated at 2022-06-12 01:17:27.820766
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    st = RussiaSpecProvider()
    for i in range(1, 20):
        assert (len(st.snils()) == 11)


# Generated at 2022-06-12 01:18:52.012066
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # 1
    snils = RussiaSpecProvider().snils()
    assert snils == '41917492600'

    # 2
    snils = RussiaSpecProvider().snils()
    assert snils == '96553000085'

    # 3
    snils = RussiaSpecProvider().snils()
    assert snils == '71121192428'

    # 4
    snils = RussiaSpecProvider().snils()
    assert snils == '82655025246'

    # 5
    snils = RussiaSpecProvider().snils()
    assert snils == '74781226572'

    # 6
    snils = RussiaSpecProvider().snils()
    assert snils == '36163070533'

    # 7
    snils = RussiaSpecProvider().snils()

# Generated at 2022-06-12 01:18:59.205621
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    import pytest
    from mimesis.typing import Seed

    @pytest.mark.parametrize('seed', [Seed.provider.value, Seed.language.value, Seed.random.value])
    def test_snils_with_different_seeds(seed):
        rs = RussiaSpecProvider(seed)
        assert len(rs.snils()) == 11
        assert rs.snils() == '41917492600'
        
    test_snils_with_different_seeds()
    
# test for inn

# Generated at 2022-06-12 01:19:01.629031
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    ru = RussiaSpecProvider()
    assert ru.snils() != ru.snils()

# Generated at 2022-06-12 01:19:07.528129
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.random import Random
    p = RussiaSpecProvider()

    for _ in range(100):
        assert len(p.snils()) == 11

    p.random.seed(1)
    assert p.snils() == '18718137658'

    p = RussiaSpecProvider(Random(seed=1))
    assert p.snils() == '18718137658'

# Generated at 2022-06-12 01:19:08.859431
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()

    for i in range(100):
        print(r.snils())

# Generated at 2022-06-12 01:19:12.491626
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rs = RussiaSpecProvider(seed=1234567890)
    snils = rs.snils()
    assert snils == '41917492600'

# Generated at 2022-06-12 01:19:14.333359
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider().snils()

# Generated at 2022-06-12 01:19:15.012847
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider().snils()



# Generated at 2022-06-12 01:19:18.043169
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils_base = '41917492600'
    snils_unit_test = provider.snils()

    assert len(snils_unit_test) == 11
    assert snils_base == snils_unit_test

# Generated at 2022-06-12 01:19:24.313037
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.builtins.russia import RussiaSpecProvider
    from mimesis.typing import Seed
    a = RussiaSpecProvider(seed=Seed(45))
    snils = a.snils()
    print("snils: " + snils)
    assert snils == '34152497000'


# Generated at 2022-06-12 01:22:50.155566
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils in range(10000000000,99999999999)

# Generated at 2022-06-12 01:22:52.982590
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    print("\nUnit test for method snils of class RussiaSpecProvider")
    russian_numbers_provider = RussiaSpecProvider()

    for _ in range(10):
        print(russian_numbers_provider.snils())


test_RussiaSpecProvider_snils()



# Generated at 2022-06-12 01:22:54.468625
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    result = provider.snils()
    assert result == '41917492600'


# Generated at 2022-06-12 01:22:58.922442
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test function snils of class RussiaSpecProvider"""
    provider = RussiaSpecProvider()
    s = provider.snils()
    assert len(s) == 11
    assert (int(s[9:]) ==
            int(s[0])*9 + int(s[1])*8 + int(s[2])*7 +
            int(s[3])*6 + int(s[4])*5 + int(s[5])*4 +
            int(s[6])*3 + int(s[7])*2 + int(s[8])*1)

# Generated at 2022-06-12 01:23:02.841646
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    ru = RussiaSpecProvider()
    assert ru.snils() == '41917492600'


if __name__ == "__main__":

    RussiaSpecProvider()

# Generated at 2022-06-12 01:23:03.804617
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    snils = RussiaSpecProvider().snils()
    print(snils)


# Generated at 2022-06-12 01:23:09.140222
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender

    rus = RussiaSpecProvider()

    for i in range(0,10):
        snils = rus.snils()
        print (snils)

if __name__ == "__main__":
    test_RussiaSpecProvider_snils()

# Generated at 2022-06-12 01:23:10.300747
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider().snils() == '41917492600'



# Generated at 2022-06-12 01:23:12.441503
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    for i in range(10):
        print(RussiaSpecProvider().snils())



# Generated at 2022-06-12 01:23:15.540727
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    seed = 123456789
    r = RussiaSpecProvider(seed)
    assert r.snils() == '41917492600'
