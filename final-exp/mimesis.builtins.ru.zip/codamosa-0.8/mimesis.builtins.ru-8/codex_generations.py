

# Generated at 2022-06-12 01:13:58.997202
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider(seed=0)
    snils = provider.snils()
    assert snils == '41917492600'


# Generated at 2022-06-12 01:14:00.451579
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rf = RussiaSpecProvider()
    print(rf.snils())

# Generated at 2022-06-12 01:14:08.015521
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Initialize provider
    provider = RussiaSpecProvider()

    # Generate first snils
    snils1 = provider.snils()

    # Generate second snils
    snils2 = ' '.join([snils1[:3], snils1[3:6], snils1[6:]])

    # Compare
    assert snils1 == snils2

# Generated at 2022-06-12 01:14:16.257084
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    assert provider.snils() == '41917492600'
    assert provider.snils() == '60077749980'
    assert provider.snils() == '37062644905'
    assert provider.snils() == '89865225723'
    assert provider.snils() == '18107813882'
    assert provider.snils() == '74929841219'
    assert provider.snils() == '47373958659'
    assert provider.snils() == '58761957000'
    assert provider.snils() == '12583814002'
    assert provider.snils() == '27331214000'
    assert provider.snils() == '23098499951'

# Generated at 2022-06-12 01:14:19.385274
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    a = RussiaSpecProvider()
    for _ in range(10):
        assert len(a.snils()) == 11


# Generated at 2022-06-12 01:14:23.438777
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Testing method snils."""

    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11

    assert int(snils) > 0
    assert int(snils) < 10000000000


# Generated at 2022-06-12 01:14:27.977144
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.builtins import RussiaSpecProvider
    prov = RussiaSpecProvider()
    ser = prov.snils()
    numb = int(ser)
    assert type(numb) == int
    assert len(str(numb)) == 11
    assert numb != None


# Generated at 2022-06-12 01:14:31.222165
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    provider.seed(0)
    snils = provider.snils()
    assert snils == '41917492600'


# Generated at 2022-06-12 01:14:44.184642
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    ru = RussiaSpecProvider(seed=1)
    ru_person = Person(seed=1)
    ru_person.set_locale('ru')
    ru_person.set_gender(Gender.MALE)
    first_name = ru_person.first_name()
    last_name = ru_person.last_name()
    patronymic = ru.patronymic(Gender.MALE)
    full_name = last_name + ' ' + first_name + ' ' + patronymic
    full_name.split()

    seed = 1
    ru = RussiaSpecProvider(seed=seed)
    ru_person = Person(seed=seed)
    ru_person.set_locale('ru')
    ru_person

# Generated at 2022-06-12 01:14:54.692190
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    import re
    r = RussiaSpecProvider()
    for _ in range(0, 10):
        ret = r.snils()
        x = re.match(r'\d{11}', ret)
        if not x:
            raise AssertionError('snils() returned invalid SNILS {}'.format(ret))
        # check that duplicates are very rare
        if ret in test_RussiaSpecProvider_snils.seq:
            raise AssertionError('snils() returned duplicate SNILS {}'.format(ret))
        test_RussiaSpecProvider_snils.seq.append(ret)
test_RussiaSpecProvider_snils.seq = []


# Generated at 2022-06-12 01:15:03.030996
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    result = RussiaSpecProvider().snils()
    print(result)
    assert (len(result) == 11)
    assert (type(result) == str)
    assert (result.isdigit())



# Generated at 2022-06-12 01:15:06.418379
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test the method snils of class RussiaSpecProvider."""
    snils = RussiaSpecProvider().snils()
    assert len(snils) == 11 and snils.isnumeric()


# Generated at 2022-06-12 01:15:09.728738
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider().snils() in [
        '41917492600',
        '74350129578',
        '13783840300'
    ]


# Generated at 2022-06-12 01:15:12.093496
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    assert len(provider.snils()) == 11, "Length of snils must be 11"


# Generated at 2022-06-12 01:15:16.233800
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test method snils."""
    rsp = RussiaSpecProvider()
    assert rsp.snils() == '89667923642'
    assert rsp.snils() == '97964950059'
    assert rsp.snils() == '95990204953'

# Generated at 2022-06-12 01:15:27.329169
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider"""

    r = RussiaSpecProvider()
    snils = r.snils()
    snils_list = list(snils)
    nums_list = snils_list[0:9]
    control_nums_list = snils_list[9:11]

    def control_sum(nums_list, control_nums_list):
        digits_dict = {
            'n2': [7, 2, 4, 10, 3, 5, 9, 4, 6, 8],
            'n1': [3, 7, 2, 4, 10, 3, 5, 9, 4, 6, 8]
        }
        number = 0
        digits = digits_dict['n2']

        for i, _ in enumerate(digits, start=0):
            number

# Generated at 2022-06-12 01:15:29.243510
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    print('snils', snils)



# Generated at 2022-06-12 01:15:32.220359
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russian_provider = RussiaSpecProvider()
    # test snils from example
    assert (russian_provider.snils() == '41917492600')

# Generated at 2022-06-12 01:15:34.542766
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    for i in range(100):
        print(RussiaSpecProvider().snils())


# Generated at 2022-06-12 01:15:38.221644
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert not len(snils) > 11
    assert len(snils) == 11
    assert not snils.startswith('0')

# Generated at 2022-06-12 01:15:51.250703
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()

    # Check generated SNILS
    assert provider.snils() == '41917492600'

# Generated at 2022-06-12 01:16:02.686703
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test the method snils from class RussiaSpecProvider"""
    # Creating object of class RussiaSpecProvider
    obj = RussiaSpecProvider()
    # Generate snils
    snils1 = obj.snils()
    snils2 = obj.snils()
    # Checking if the two created snils are not equal
    assert snils1 != snils2
    # Checking if the last seven digits of the snils match the last seven digits of the passport number
    # Unit test for method passport_number (line 161)
    obj_passport_number = obj.passport_number()
    assert int(snils1[3:10]) == obj_passport_number
    assert int(snils2[3:10]) == obj_passport_number

    # Test the method snils from class RussiaSpecProvider
    # Creating object of class RussiaSpecProvider


# Generated at 2022-06-12 01:16:04.753399
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test the snils method."""
    r = RussiaSpecProvider()
    #assert r.snils() == '41917492600'

# Generated at 2022-06-12 01:16:11.767818
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.builtins import RussiaSpecProvider
    obj = RussiaSpecProvider()
    snils = obj.snils()
    print('snils = ' + snils)
    assert len(snils)==11, 'snils does not have length of 11 characters'
    #assert 31307778402


# Generated at 2022-06-12 01:16:13.281913
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    test_object = RussiaSpecProvider()
    for i in range(100):
        assert len(test_object.snils()) == 11


# Generated at 2022-06-12 01:16:17.353184
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils.
    Expected result is 41917492600.
    """
    number = RussiaSpecProvider().snils()
    assert number == "41917492600"
    print(number)


# Generated at 2022-06-12 01:16:23.291524
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test generation of snils"""
    list_of_snils = ['41917492600', '77582345900', '73467352500', '73702919600']
    rsp = RussiaSpecProvider()
    for snils in list_of_snils:
        assert rsp.snils() == snils

# Generated at 2022-06-12 01:16:26.718661
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    import string
    import random
    test = RussiaSpecProvider()
    test_snils = test.snils()
    assert len(test_snils) == 11
    assert isinstance(test_snils, str)
    assert set(test_snils).issubset(set(string.digits))


# Generated at 2022-06-12 01:16:39.424740
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    result = []
    result.append(RussiaSpecProvider().snils())
    result.append(RussiaSpecProvider().snils())
    result.append(RussiaSpecProvider().snils())
    result.append(RussiaSpecProvider().snils())
    result.append(RussiaSpecProvider().snils())
    result.append(RussiaSpecProvider().snils())
    result.append(RussiaSpecProvider().snils())
    result.append(RussiaSpecProvider().snils())
    result.append(RussiaSpecProvider().snils())
    result.append(RussiaSpecProvider().snils())

# Generated at 2022-06-12 01:16:45.897674
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.enums import Gender
    from mimesis.schema import Field
    from mimesis.providers.ru.person import RussiaPerson

    provider = RussiaSpecProvider()
    data = {
        "first_name": Field("person.name", gender=Gender.MALE, locale="ru"),
        "last_name": Field("person.surname", locale="ru"),
        "middle_name": Field("person.patronymic", gender=Gender.MALE, locale="ru"),
        "snils": RussiaPerson.snils()
    }
    result = data["snils"].execute()
    assert len(result) == 11
    assert result.isdigit()

# Generated at 2022-06-12 01:17:09.310435
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert '41917492600' == RussiaSpecProvider().snils()

test_RussiaSpecProvider_snils()


# Generated at 2022-06-12 01:17:16.804988
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    from mimesis.providers.person import Person
    human = Person('ru')


# Generated at 2022-06-12 01:17:28.338944
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()                                             # this provider is needed to generate snils
    snils = provider.snils()                                                    # generate snils using the provider
    
    print("\n")
    print("======================Start test======================")   
    print("snils: ", snils)
    
    nums = [int(snils[i]) for i in range(len(snils))]                           # list of numbers of snils
    a = 0                                                                       # the first control number
    
    for i in range(9):                                                          # the first 9 numbers and the first control number are summed
        a += nums[i] * (9 - i)
    

# Generated at 2022-06-12 01:17:37.992845
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Testing method snils of class RussiaSpecProvider."""
    assert RussiaSpecProvider()['snils']() == '41917492600'
    assert RussiaSpecProvider()['snils']() == '46337047600'
    assert RussiaSpecProvider()['snils']() == '91916460600'
    assert RussiaSpecProvider()['snils']() == '83179794600'
    assert RussiaSpecProvider()['snils']() == '84417089600'
    assert RussiaSpecProvider()['snils']() == '45087017600'
    assert RussiaSpecProvider()['snils']() == '53136413600'
    assert RussiaSpecProvider()['snils']() == '76837006600'
    assert RussiaSpecProvider()['snils']() == '81157236600'
    assert Russia

# Generated at 2022-06-12 01:17:45.476722
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():

    # create seed with random value
    seed = "random"
    # create a special data provider for Russia
    russia_provider = RussiaSpecProvider(seed)
    # create a variable that contains the method to be tested
    snils = russia_provider.snils
    # create a variable that contains the expected result
    expected_result = "48457196215"
    # execute the method
    actual_result = snils()
    # compare the obtained result and the expected result
    assert (expected_result == actual_result)


# Generated at 2022-06-12 01:17:46.593954
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert len(RussiaSpecProvider().snils()) == 11


# Generated at 2022-06-12 01:17:52.102757
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider"""
    b = RussiaSpecProvider()
    b._seed(12345)
    assert b.snils() == '82219436400'
    assert b.snils() == '82219436400'

# Generated at 2022-06-12 01:17:54.609590
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert snils == '41917492600'


# Generated at 2022-06-12 01:17:57.804165
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    sp = RussiaSpecProvider
    assert sp.snils() == '41917492600'


# Generated at 2022-06-12 01:18:00.115347
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.finance.ru import RussiaSpecProvider
    rus = RussiaSpecProvider()
    assert rus.snils() == '41917492600'

# Generated at 2022-06-12 01:18:47.759080
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    a = provider.snils()
    assert len(a) == 11

# Generated at 2022-06-12 01:18:49.108832
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rs = RussiaSpecProvider()
    res = rs.inn()
    pass



# Generated at 2022-06-12 01:18:51.269383
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    tmp = RussiaSpecProvider()
    tmp_result = tmp.snils()
    print(tmp_result)



# Generated at 2022-06-12 01:18:52.440155
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    r.snils()


# Generated at 2022-06-12 01:18:57.596341
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test to check snils method of class RussiaSpecProvider."""
    test_obj = RussiaSpecProvider()
    assert len(test_obj.snils()) == 11
    assert isinstance(test_obj.snils(), str)

# Generated at 2022-06-12 01:19:03.926494
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    rs = RussiaSpecProvider()
    person = Person('ru')

    for i in range(20):
        person.create(snils=True)
        assert rs.snils() == person.snils(
            gender=person.gender
        )

# Generated at 2022-06-12 01:19:07.087830
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test snils method of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    print(provider.snils())


# Generated at 2022-06-12 01:19:15.918568
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis import RussiaSpecProvider
    from mimesis.enums import Gender
    from mimesis.typing import Seed

    spec = RussiaSpecProvider(seed=Seed(1))
    assert spec.snils() == '50420741129'
    assert spec.snils() == '96262022088'
    assert spec.snils() == '63407477800'
    assert spec.snils() == '47782688230'
    assert spec.snils() == '24209823760'



# Generated at 2022-06-12 01:19:19.719321
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    from mimesis.providers import RussiaSpecProvider
    from mimesis.builtins import RussiaSpecProvider as RussiaSpecProvider_builtin

    ru = RussiaSpecProvider()
    ru_builtin = RussiaSpecProvider_builtin()

    for i in range(0, 5):
        print(ru.snils())
        print(ru_builtin.snils())


# Generated at 2022-06-12 01:19:24.023722
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    snils_list = []
    for i in range(0, 100):
        snils = RussiaSpecProvider().snils()
        snils_list.append(snils)
    print(snils_list)


# Generated at 2022-06-12 01:21:44.104271
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    gen = RussiaSpecProvider()
    assert not gen.snils() == None


# Generated at 2022-06-12 01:21:48.955032
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    result = r.snils()
    assert len(result) == 11
    result = r.snils(seed=12)
    assert result == '73519487382'


# Generated at 2022-06-12 01:21:51.826345
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    provider.snils()
    assert provider.snils() == "41917492600" 


# Generated at 2022-06-12 01:21:53.708450
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    assert provider.snils() == "41917492600"

# Generated at 2022-06-12 01:21:55.933477
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11, 'snils must be 11 symbols long'
    assert snils.isdigit(), 'snils must consist only of digits'


# Generated at 2022-06-12 01:21:57.561029
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()
    rsp.snils()


# Generated at 2022-06-12 01:22:04.351535
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit Test for method snils of class RussiaSpecProvider.

    :return: Returns nothing.
    """
    # Test data
    snils = RussiaSpecProvider().snils()

    # Test case
    assert isinstance(snils, str)
    assert len(snils) == 11
    assert snils[9].isdigit()
    assert snils[10].isdigit()


# Generated at 2022-06-12 01:22:06.278837
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Check the invalid number of digits
    provider = RussiaSpecProvider()
    assert len(provider.snils()) != 8
    assert len(provider.snils()) != 7

# Generated at 2022-06-12 01:22:14.938450
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    from mimesis.providers.geography.russian_federation import RussiaSpecProvider
    for i in range(2000):
        # print(RussiaSpecProvider().snils())

        # Check for minimum length
        assert len(RussiaSpecProvider().snils()) == 11

        # Check for maximum length
        assert len(RussiaSpecProvider().snils()) == 11

        # Check if the last digit is correct
        snils = RussiaSpecProvider().snils()
        assert snils[-1] == str(sum(int(snils[i]) * (9 - i) for i in range(9)) % 101 % 100 // 10)


# Generated at 2022-06-12 01:22:17.349382
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils(): # noqa: D103
    assert RussiaSpecProvider().snils()