

# Generated at 2022-06-12 01:14:01.831177
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from pytest import approx
    
    rsp = RussiaSpecProvider()
    # Generate snils with artficial seed
    snils1 = rsp.snils(seed=1583168893)
    
    assert snils1 == '41917492600'
    
    
    

# Generated at 2022-06-12 01:14:07.352923
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from re import search
    provider = RussiaSpecProvider()
    snils = provider.snils()
    mask = r"^[0-9]{11}$"
    assert search(mask, snils) is not None


# Generated at 2022-06-12 01:14:10.476527
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.data import RUSSIAN_PROVIDER_DATA
    rp = RussiaSpecProvider()
    rp.seed("100")
    assert rp.snils() == '41082679814'

# Generated at 2022-06-12 01:14:16.317476
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test method snils of class RussiaSpecProvider"""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    # Check if simply a random number of 11 digits
    assert not int(snils) % 101 % 100 == 0
    # Check if last 3 digits conform to control number
    assert int(snils[-3:]) == int(snils[:-3]) % 101 % 100


# Generated at 2022-06-12 01:14:17.938173
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    print(provider.snils())

# Generated at 2022-06-12 01:14:22.332532
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.russia_provider import RussiaSpecProvider
    rsp = RussiaSpecProvider(seed=0)
    assert str(rsp.snils()) == '41917492600'


# Generated at 2022-06-12 01:14:28.442714
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    from mimesis.providers.person.en import Person
    person = Person()
    russ = RussiaSpecProvider(seed=person.seed)
    russ.seed = person.seed
    russ.snils()
    assert len(russ.snils()) == 11


# Generated at 2022-06-12 01:14:33.531723
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.person.ru import RussiaSpecProvider
    from re import search
    find = RussiaSpecProvider()
    snils = find.snils()
    assert len(snils) == 11
    assert search(r'\d{3}-\d{3}-\d{3} \d{2}', snils)



# Generated at 2022-06-12 01:14:38.455727
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()

    snils = provider.snils()
    assert len(snils) == 11
    assert isinstance(snils, str)



# Generated at 2022-06-12 01:14:43.130907
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test method snils of class RussiaSpecProvider."""
    result = RussiaSpecProvider().snils()
    # Does it return the string value?
    assert(isinstance(result, str))
    # Is the length ok?
    assert(len(result) == 11)

# Generated at 2022-06-12 01:15:00.954980
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test snils method"""
    print(RussiaSpecProvider.snils())
    assert len(RussiaSpecProvider.snils()) == 11


# Generated at 2022-06-12 01:15:03.681062
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    class A:
        def __init__(self, char, arr):
            self.char = char
            self.arr = arr

        def randint(self, a, b):
            return self.char
    a = A(4, [1,2,3,4,5,6,7,8,9])
    b = RussiaSpecProvider(a)
    assert b.snils() == '41917492600'
    a.char = 3
    b = RussiaSpecProvider(a)
    assert b.snils() == '33217433200'


# Generated at 2022-06-12 01:15:09.554237
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    from mimesis import RussiaSpecProvider
    from mimesis import __version__

    print('\n--- RussiaSpecProvider, version: {}'.format(__version__))
    print('\n--- Method snils')
    provider = RussiaSpecProvider()
    print(provider.snils())

# Generated at 2022-06-12 01:15:11.972995
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.person.russia import RussiaSpecProvider
    russia = RussiaSpecProvider()
    russia.snils()


# Generated at 2022-06-12 01:15:13.200913
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider().snils() != None
    

# Generated at 2022-06-12 01:15:17.085289
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    snils = RussiaSpecProvider().snils()
    # Check that snils is a number and has a length of 11 symbols
    assert (snils.isdigit() == True) and (len(snils) == 11)


# Generated at 2022-06-12 01:15:20.062635
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    expected_snils = '41917492600'
    generated_snils = RussiaSpecProvider().snils()
    assert expected_snils == generated_snils


# Generated at 2022-06-12 01:15:25.653620
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    import pytest
    from mimesis.providers.russia import RussiaSpecProvider
    from mimesis.enums import Gender

    test_snils_1 = RussiaSpecProvider(seed=123456789)
    test_snils_2 = RussiaSpecProvider(seed=987654321)

    test_snils_1.snils() == '40117492598'
    test_snils_2.snils() == '36208383611'


# Generated at 2022-06-12 01:15:33.848936
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test for method snils of class RussiaSpecProvider"""
    from mimesis.providers.number import Number
    from mimesis.providers.datetime import Datetime
    for x in range(10):
        seed_generator = Number()
        test_seed = seed_generator.random.randint(0, 10000)
        import datetime
        datetime_generator = Datetime('ru')
        datetime_now = datetime_generator.now()
        RussiaSpecProvider(seed=test_seed).snils()



# Generated at 2022-06-12 01:15:41.024269
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test for snils method of class RussiaSpecProvider
    """
    rsp = RussiaSpecProvider()
    snils_rsp = rsp.snils()
    assert snils_rsp[9] == str(sum(list(map(int, snils_rsp[:9])) * list(range(9, 0, -1))) % 101 % 100 // 10)
    assert snils_rsp[10] == str(sum(list(map(int, snils_rsp[:9])) * list(range(9, 0, -1))) % 101 % 10)

# Generated at 2022-06-12 01:16:18.177894
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test snils method."""
    russia = RussiaSpecProvider()
    assert len(russia.snils()) == 11


# Generated at 2022-06-12 01:16:20.840039
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    assert len(provider.snils()) == 11



# Generated at 2022-06-12 01:16:29.145941
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test method snils."""
    ru = RussiaSpecProvider()

    snils= ru.snils()
    numbers = [int(num) for num in snils if num in '1234567890']
    control_codes = []

    for i in range(9, 0, -1):
        control_codes.append(numbers[9 - i] * i)

    control_code = sum(control_codes)
    code = int(snils[:9])


    assert len(snils) == 11, "snils не содержит 11 знаков"
    assert control_code%101 == int(snils[9:]), "Неверное контрольное число"

# Generated at 2022-06-12 01:16:31.816435
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    ru = RussiaSpecProvider()
    print (ru.snils())
if __name__ == '__main__':
    test_RussiaSpecProvider_snils()

# Generated at 2022-06-12 01:16:38.074589
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    total = 0
    for i in range(0, 9):
        total += int(snils[i]) * (9 - i)
    print(total)


if __name__ == '__main__':
    test_RussiaSpecProvider_snils()

# Generated at 2022-06-12 01:16:40.413858
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    print(RussiaSpecProvider.snils(RussiaSpecProvider()))
    assert len(RussiaSpecProvider.snils(RussiaSpecProvider())) == 11


# Generated at 2022-06-12 01:16:44.075844
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """
    Test snils method of the class RussiaSpecProvider
    """
    provider = RussiaSpecProvider()
    assert len(provider.snils()) == 11
    assert type(provider.snils()) == str
    assert provider.snils() == "41917492600"


# Generated at 2022-06-12 01:16:52.969282
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """
    Tests snils method of class RussiaSpecProvider
    """
    r = RussiaSpecProvider()

    snils_history = []
    for i in range(10000):
        snils = r.snils()
        if snils in snils_history:
            print("SNILS {} was generated twice".format(snils))
            return False
        snils_history.append(snils)

    return True


# Generated at 2022-06-12 01:17:01.104760
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    a = RussiaSpecProvider().snils()
    assert len(a) == 11
    assert a[0] == '1' or a[0] == '2' or a[0] == '3' or a[0] == '4'
    b = int(a)
    if 100 <= b <= 101:
        assert a[-2:] == '00'
    else:
        assert a[-2:] == str(b % 101)


# Generated at 2022-06-12 01:17:05.657178
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    lst = []
    prov = RussiaSpecProvider()
    for i in range(0,10000):
        lst.append(prov.snils())
    return lst


# Generated at 2022-06-12 01:18:24.784065
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    for _ in range(0, 10):
        RussiaSpecProvider.snils()

# Generated at 2022-06-12 01:18:27.389696
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis import RussiaSpecProvider
    provider_instance = RussiaSpecProvider()
    assert len(provider_instance.snils()) == 11

# Generated at 2022-06-12 01:18:28.253984
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert len(RussiaSpecProvider().snils()) == 11



# Generated at 2022-06-12 01:18:29.650287
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    print("\n" + provider.snils())

# Generated at 2022-06-12 01:18:30.744008
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider(seed=42).snils() == '11947456827'

# Generated at 2022-06-12 01:18:33.334587
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-12 01:18:37.903297
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """ unit test for method snils of class RussiaSpecProvider"""
    obj = RussiaSpecProvider()
    snils = obj.snils()
    print(snils)
    assert snils.__len__()==11

if __name__ == '__main__':
    print(__doc__)
    print(test_RussiaSpecProvider_snils.__doc__)
    test_RussiaSpecProvider_snils()
    print('All tests completed')

# Generated at 2022-06-12 01:18:40.248885
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    s = r.snils()
    assert str(s).isdigit()
    assert len(str(s)) == 11

# Generated at 2022-06-12 01:18:43.528718
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    result = provider.snils()
    assert len(result) == 11
    assert result[0] != 0


# Generated at 2022-06-12 01:18:49.046895
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():

    snils = RussiaSpecProvider().snils()
    count_digits = sum(c.isdigit() for c in str(snils))
    assert count_digits == 11

    a = [snils]
    b = [RussiaSpecProvider().snils() for _ in range(0, 100)]

    result = len(set(a) & set(b))
    assert result == 0


if __name__ == '__main__':
    test_RussiaSpecProvider_snils()

# Generated at 2022-06-12 01:22:02.586045
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    from mimesis.providers.russia import RussiaSpecProvider
    r = RussiaSpecProvider()
    assert r.snils()


# Generated at 2022-06-12 01:22:05.420769
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert type(snils) == str
    assert len(snils) == 11


# Generated at 2022-06-12 01:22:13.648771
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    providers = RussiaSpecProvider()
    for i in range(0, 100):
        snils = providers.snils()
        numbers = []
        for x in range(0, 9):
            numbers.append(int(snils[x]))

        control_codes = []
        for x in range(9, 0, -1):
            control_codes.append(numbers[9 - x] * x)

        control_code = sum(control_codes)
        assert control_code == int(snils[9] + snils[10] + snils[11])



# Generated at 2022-06-12 01:22:23.469222
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider"""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    if (
        (snils[0] != '0') and
        (snils[1] != '1') and
        (snils[2] != '2') and
        (snils[3] != '3') and
        (snils[4] != '4') and
        (snils[5] != '5') and
        (snils[6] != '6') and
        (snils[7] != '7') and
        (snils[8] != '8') and
        (snils[9] != '9')
    ):
        assert False
    else:
        assert True

# Generated at 2022-06-12 01:22:25.619578
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test function RussiaSpecProvider.snils"""
    tester = RussiaSpecProvider()
    snils = tester.snils()
    assert len(snils) == 11
    assert snils == '41917492600'

# Generated at 2022-06-12 01:22:28.176613
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """

    :return:
    """
    actual = RussiaSpecProvider.snils()
    assert len(actual) == 11
    # TODO: Add more test scenarios for snils


# Generated at 2022-06-12 01:22:36.873896
# Unit test for method snils of class RussiaSpecProvider

# Generated at 2022-06-12 01:22:50.157074
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.generic.en import English
    from mimesis.providers.internet.ru import RussiaProvider
    seed_gen = English().seed_generator
    seed_gen.validate_seed(145542)
    rs = RussiaSpecProvider(seed=145542)

    rp = RussiaProvider(seed=145542)
    first_name = rp.first_name(gender=Gender.MALE)
    last_name = rp.last_name(gender=Gender.MALE)
    middle_name = rp.middle_name(gender=Gender.MALE)
    
    assert rs.snils() == '41917492600'
    

# Generated at 2022-06-12 01:22:51.454838
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    list = []
    for i in range(0, 1000):
        snils = r.snils()
        assert snils not in list
        list.append(snils)

# Generated at 2022-06-12 01:22:52.435839
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    assert len(r.snils()) == 11
    assert type(r.snils()) is str
