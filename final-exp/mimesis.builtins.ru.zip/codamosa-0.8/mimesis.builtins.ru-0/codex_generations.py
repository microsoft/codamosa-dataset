

# Generated at 2022-06-12 01:13:54.721628
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    #init RussiaSpecProvider
    rsp = RussiaSpecProvider()
    #generate snils
    res = rsp.snils()
    assert isinstance(res, str)
    assert len(res) == 11


# Generated at 2022-06-12 01:14:01.576349
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test of function snils in class RussiaSpecProvider."""
    r = RussiaSpecProvider()
    my_lst = [r.snils() for _ in range(100)]
    true_values = '41917492600'
    for i in my_lst:
        assert(i) is not None
        assert(true_values in i)



# Generated at 2022-06-12 01:14:13.439326
# Unit test for method snils of class RussiaSpecProvider

# Generated at 2022-06-12 01:14:15.401768
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    pass


# Generated at 2022-06-12 01:14:19.587024
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider"""
    from mimesis.builtins import RussiaSpecProvider
    r = RussiaSpecProvider()
    a = r.snils()
    print(a)
    return a



# Generated at 2022-06-12 01:14:21.638007
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    for i in range(0, 10):
        assert len(RussiaSpecProvider().snils())==11


# Generated at 2022-06-12 01:14:25.075590
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test snils method of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert snils.isdigit()
    assert len(str(snils)) == 11

# Generated at 2022-06-12 01:14:27.976710
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider(seed=42)
    assert r.snils() == '41917492600'


# Generated at 2022-06-12 01:14:33.533266
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    result = provider.snils()
    # Проверка длины строки
    assert 11 <= len(result) <= 11
    # Проверка на целые числа
    assert result.isdigit()



# Generated at 2022-06-12 01:14:45.363047
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    x = RussiaSpecProvider()
    assert len(x.snils()) == 11 
    assert type(x.snils()) == str
    def test_2():
        x = RussiaSpecProvider()
        assert len(x.snils()) == 11 
        assert type(x.snils()) == str
    def test_3():
        x = RussiaSpecProvider()
        assert len(x.snils()) == 11 
        assert type(x.snils()) == str
    def test_4():
        x = RussiaSpecProvider()
        assert len(x.snils()) == 11 
        assert type(x.snils()) == str
    def test_5():
        x = RussiaSpecProvider()
        assert len(x.snils()) == 11 
        assert type(x.snils()) == str

# Generated at 2022-06-12 01:14:59.750154
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russian_provider = RussiaSpecProvider(seed=42)

    snils = russian_provider.snils()
    snils_1 = russian_provider.snils()

    assert snils == '41917492600'
    assert snils == snils_1


# Generated at 2022-06-12 01:15:00.468170
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    result = provider.snils()
    assert len(result) == 11

# Generated at 2022-06-12 01:15:09.729330
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    snils = []
    for i in range(10000):
        sp = RussiaSpecProvider()
        snils.append(sp.snils())

        def count_sni_digit(snils_list, sni_digits):
            cnt = 0
            for snils in snils_list:
                if snils[sni_digits] == '0':
                    cnt += 1
            return cnt

        sni_0 = count_sni_digit(snils, -3)
        sni_00 = count_sni_digit(snils, -2)

        assert sni_0 == sni_00 < 2500

# Generated at 2022-06-12 01:15:18.131666
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    for i in range(0, 999):
        snils = provider.snils()
        numbers = [int(digit) for digit in snils]
        control_codes = []
        for i in range(9, 0, -1):
            control_codes.append(numbers[9 - i] * i)
        control_code = sum(control_codes)

        if control_code in (100, 101):
            assert str(control_code).endswith(snils[:2])
        else:
            assert str(control_code).endswith(snils[:2])


# Generated at 2022-06-12 01:15:22.971329
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Создаём объект класса и выводим результат
    print(RussiaSpecProvider().snils())

test_RussiaSpecProvider_snils()


# Generated at 2022-06-12 01:15:25.924998
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    ru = RussiaSpecProvider()
    ru.snils()

# Generated at 2022-06-12 01:15:29.329989
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider(seed=None)
    snils = provider.snils()
    print('Проверка снилс: ' + snils)


# Generated at 2022-06-12 01:15:32.687589
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()
    # Test if snils is a string containing 10 digits
    assert len(rsp.snils()) == 11
    for char in rsp.snils():
        assert char.isdigit()

# Generated at 2022-06-12 01:15:40.395988
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    snils_list = []
    for i in range(10000):
        snils_list.append(r.snils())

    for i in range(10000):
        assert snils_list[i] not in snils_list[i+1:]
    
    snils_list = []
    for i in range(1000):
        snils_list.append(r.passport_number())

    for i in range(1000):
        assert snils_list[i] not in snils_list[i+1:]

# Generated at 2022-06-12 01:15:46.396608
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()  # create an object
    snils = provider.snils() # create a snils number
    assert (len(snils) == 11) # check len
    print(snils)


# Generated at 2022-06-12 01:16:25.453329
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Тестирование метода snils класса RussisSpecProvider"""
    ru_provider = RussiaSpecProvider()
    a = ru_provider.snils()
    assert ru_provider.snils()
    # Проверка на то, что метод возвращает строку
    assert isinstance(a, str)
    # Проверка на то, что метод возвращает верную строку (11 символов)


# Generated at 2022-06-12 01:16:29.945630
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test Method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    assert re.match(r'^\d{11,11}$', provider.snils())


#Unit test for method inn of class RussiaSpecProvider

# Generated at 2022-06-12 01:16:35.231045
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.russia import RussiaSpecProvider
    russian_spec_provider = RussiaSpecProvider(seed=123456)
    russian_spec_provider.snils()
    assert russian_spec_provider.snils() == '41917492600'


# Generated at 2022-06-12 01:16:38.031041
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    x = RussiaSpecProvider()
    assert len(x.snils()) == 11


# Generated at 2022-06-12 01:16:39.627615
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
	r = RussiaSpecProvider()
	assert r.snils() == '41917492600'


# Generated at 2022-06-12 01:16:41.305229
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider().snils() == '41917492600'

# Generated at 2022-06-12 01:16:43.109497
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russian = RussiaSpecProvider()
    snils = russian.snils()
    assert snils == '61791567800'


# Generated at 2022-06-12 01:16:46.399527
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider"""
    RussiaSpecProvider(seed=123456).snils()
    # Check: '41917492600'


# Generated at 2022-06-12 01:16:50.910906
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    provider.validate_snils(snils)

# Generated at 2022-06-12 01:16:53.838452
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    parts = snils.split('.')
    assert snils
    assert len(snils) == 11
    assert len(parts) == 3
    assert int(parts[0]) + int(parts[1] + parts[2]) % 101 % 100 == 100

    snils = provider.snils('12345678916')
    assert snils == '12345678916'

    provider = RussiaSpecProvider('12345678916')
    snils = provider.snils()
    assert snils == '12345678916'

# Generated at 2022-06-12 01:18:11.181523
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
 # test_data
    test_data = ['41917492600', '45716489980', '39565584200', '76557904400', '79021144100', '49120885600']
    # test_data = [5, 1, 4, 2, 3, 7, 3, 3, 6, 7, 5, 4, 6, 8, 0, 4, 8, 7, 1, 8, 1, 0, 4, 1, 1, 6, 8, 0, 0, 9, 5, 0, 3, 1, 3, 3, 6, 9, 5, 2, 6, 9, 5, 1, 6, 9, 0, 8, 6, 9, 5, 2, 3, 8, 3, 3, 1, 6, 5, 8, 6, 9, 5, 2, 4, 9, 5, 2, 8, 1

# Generated at 2022-06-12 01:18:20.638070
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # first test
    seed = int("543730473330966672225372363836")
    rsp = RussiaSpecProvider(seed=seed)
    expected = "41917492600"
    actual = rsp.snils()
    assert actual == expected

    # second test
    seed = int("-757624735679979046585832635499")
    rsp = RussiaSpecProvider(seed=seed)
    expected = "04581412700"
    actual = rsp.snils()
    assert actual == expected


# Generated at 2022-06-12 01:18:23.158194
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    assert r.snils() == '81863463200'

# Generated at 2022-06-12 01:18:28.407684
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    snils = RussiaSpecProvider().snils()

    assert len(snils) == 11
    assert isinstance(snils, str)
    assert snils.isdigit()

    int_snils = int(snils)

    assert int_snils <= 99999999999



# Generated at 2022-06-12 01:18:32.526201
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
  from mimesis.enums import Gender
  from mimesis.providers import RussiaSpecProvider
  global snils
  rsp = RussiaSpecProvider(seed=0)
  snils = rsp.snils()
  if len(snils) == 11:
    return True
  else:
    return False


# Generated at 2022-06-12 01:18:36.687112
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.builtins import RussiaSpecProvider
    rus = RussiaSpecProvider()
    snils = rus.snils()
    try:
        assert snils == '41917492600'
        print('Test successful')
        return True
    except:
        print('Test failed')
        return False


# Generated at 2022-06-12 01:18:39.509129
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia = RussiaSpecProvider()
    snils = russia.snils()
    print(snils)



# Generated at 2022-06-12 01:18:46.173695
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider_1 = RussiaSpecProvider()
    snils_1 = provider_1.snils()
    for _ in range(0, 100):
        provider_2 = RussiaSpecProvider()
        snils_2 = provider_2.snils()
        assert len(snils_2) == 11
        assert snils_1 != snils_2


# Generated at 2022-06-12 01:18:47.681690
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    for i in range(10):
        assert provider.snils() != provider.snils()

# Generated at 2022-06-12 01:18:48.770129
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    print(r.snils())

# Generated at 2022-06-12 01:21:31.508119
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()
    snils_set = set()
    for i in range(0, 10000):
        snils_set.add(rsp.snils())
    len(snils_set) == 10000

# Generated at 2022-06-12 01:21:41.720006
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider"""
    test_params = [
        [
            44927390422,
            '44927390422',
        ],
        [
            '74071807931',
            '74071807931',
        ],
        [
            '59437296919',
            '59437296919',
        ],
        [
            '62489942602',
            '62489942602',
        ],
        [
            '00383737294',
            '00383737294',
        ],
    ]
    test_obj = RussiaSpecProvider(seed=1)

    for test_param in test_params:
        flag = True
        result = test_obj.snils()

# Generated at 2022-06-12 01:21:43.523987
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    assert len(provider.snils()) == 11
    assert provider.snils()[:3] == '419'


# Generated at 2022-06-12 01:21:48.879735
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    r = RussiaSpecProvider()
    result = r.snils()
    assert len(result) == 11, 'The length of the snils is wrong'



# Generated at 2022-06-12 01:21:57.375109
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.russia import RussiaSpecProvider as RSP
    from mimesis.enums import Gender
    from unittest import TestCase

    print('\n--- test_RussiaSpecProvider_snils ---')

    seed = 345
    data = []
    data_file = 'mimesis/data/rsp_snils.log'

    rsp = RSP(seed=seed)

    with open(data_file, 'r') as f:
        for line in f:
            data.append(line.rstrip())

    snils = rsp.snils()
    print(snils)

    assert snils == data[0]

    seed = 12345
    rsp = RSP(seed=seed)
    snils = rsp.snils()
    print(snils)

    assert sn

# Generated at 2022-06-12 01:22:01.748136
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """
    Test method `snils` of the class `RussiaSpecProvider`
    """

    rsp = RussiaSpecProvider()
    assert rsp.snils() == "41917492600"



# Generated at 2022-06-12 01:22:08.528113
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()
    test_snils = rsp.snils()
    test_number = int(test_snils[:-2])
    test_control_numbers=int(test_snils[-2:])

    def control_sum(nums: list, t: str) -> int: 
        digits_dict = {
            'n2': [7, 2, 4, 10, 3, 5, 9, 4, 6, 8],
            'n1': [3, 7, 2, 4, 10, 3, 5, 9, 4, 6, 8],
        }
        number = 0
        digits = digits_dict[t]

        for i, _ in enumerate(digits, start=0):
            number += nums[i] * digits[i]
        return number % 11 % 10

   

# Generated at 2022-06-12 01:22:12.062973
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    assert provider.snils() == '41917492600'
    return 'test_RussiaSpecProvider_snils - OK'


# Generated at 2022-06-12 01:22:14.301157
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    t = RussiaSpecProvider()
    assert t.snils == '41917492600'
    assert t.snils != '41917492601'


# Generated at 2022-06-12 01:22:24.223369
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.generic import Generic


    def get_birth_date():
        days_in_month_dict = {
            1: range(1, 32),
            2: range(1, 29),
            3: range(1, 32),
            4: range(1, 31),
            5: range(1, 32),
            6: range(1, 31),
            7: range(1, 32),
            8: range(1, 32),
            9: range(1, 31),
            10: range(1, 32),
            11: range(1, 31),
            12: range(1, 32),
        }
        month = Generic('ru').datetime.month()
        day = Generic('ru').random.choice(days_in_month_dict[month])
        return day, month

   