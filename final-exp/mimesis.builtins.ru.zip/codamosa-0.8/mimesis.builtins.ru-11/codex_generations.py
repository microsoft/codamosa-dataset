

# Generated at 2022-06-12 01:14:07.555266
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.russia import RussiaSpecProvider
    rus = RussiaSpecProvider()
    snils = rus.snils()
    assert type(snils) == str
    assert len(snils) == 11
    assert rus.snils() != rus.snils()



# Generated at 2022-06-12 01:14:08.659177
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()
    assert rsp.snils() is not None


# Generated at 2022-06-12 01:14:10.306758
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    ru = RussiaSpecProvider()
    assert ru.snils() == '41917492600'


# Generated at 2022-06-12 01:14:11.517301
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider().snils() == RussiaSpecProvider().snils()



# Generated at 2022-06-12 01:14:13.321591
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11


# Generated at 2022-06-12 01:14:17.728685
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Check result of method RussiaSpecProvider.snils()."""
    from mimesis.providers.person.russia_provider import RussiaSpecProvider
    rsp = RussiaSpecProvider()

    # '41917492600'
    assert rsp.snils() == '41917492600', 'Result of method RussiaSpecProvider.snils() is not correct.'

# Generated at 2022-06-12 01:14:20.392131
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    t = provider.snils()
    assert len(t) == 11



# Generated at 2022-06-12 01:14:22.474528
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert snils is not None


# Generated at 2022-06-12 01:14:27.005736
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider"""
    provider = RussiaSpecProvider()
    result = provider.snils()
    assert len(result) == 11
    assert result[-2:] == str(int(result[:-2]) % 101)


# Generated at 2022-06-12 01:14:30.000986
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    snils = r.snils()
    assert len(snils) == 11


# Generated at 2022-06-12 01:14:48.403186
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    snils = RussiaSpecProvider().snils()
    assert(len(snils) == 11)

# Generated at 2022-06-12 01:14:53.990999
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils_dict = {}

    for i in range(50000):
        snils_dict[i] = provider.snils()

    for i in snils_dict.values():
        assert len(i) == 11



# Generated at 2022-06-12 01:14:55.235212
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rus = RussiaSpecProvider()
    for _ in range(10):
        result = rus.snils()
        print(result)
        assert len(result) == 11


# Generated at 2022-06-12 01:15:02.497755
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    import unittest
    from mimesis.providers.base import BaseSpecProvider
    seed = 'test_RussiaSpecProvider_snils'

    class RussiaSpecProviderTests(unittest.TestCase):
        def setUp(self):
            self.provider = RussiaSpecProvider(seed=seed)

        def test_snils(self):
            expected = '41917492600'
            result = self.provider.snils()
            self.assertEqual(result, expected)

    return RussiaSpecProviderTests()



# Generated at 2022-06-12 01:15:05.001213
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.misc import RussiaSpecProvider

    r = RussiaSpecProvider()
    print(r.snils())

# Generated at 2022-06-12 01:15:13.120203
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()

    # list with valid snils
    valid_snils = [
        '41917492600',
        '65715322001',
        '17373619168',
        '73141613958',
        '29103983136',
        '12949195445',
        '47669313727',
        '64302088995',
        '75159064263',
        '99381318574'
    ]

    for i in range(0, 10):
        assert provider.snils() in valid_snils

# Generated at 2022-06-12 01:15:16.338341
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test method snils of class RussiaSpecProvider"""
    snils = RussiaSpecProvider().snils()
    assert snils == '54183935881'


# Generated at 2022-06-12 01:15:18.047037
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert '41917492600' == RussiaSpecProvider().snils()


# Generated at 2022-06-12 01:15:20.208343
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    assert r.snils() == '41917492600'

# Generated at 2022-06-12 01:15:21.616695
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    snils = RussiaSpecProvider().snils()
    assert len(snils) == 11

# Generated at 2022-06-12 01:15:57.559638
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit() is True


# Generated at 2022-06-12 01:16:04.452243
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.enums import Gender
    from mimesis.providers.base import BaseDataProvider
    from mimesis.seed import Seed
    from mimesis.providers.russia.rus import RussiaSpecProvider

    seed_ = Seed()
    seed = seed_.create_seed()
    bdp = BaseDataProvider(seed=seed)
    provider = RussiaSpecProvider(seed=seed)
    test_snils = provider.snils()
    assert test_snils == bdp.snils()


# Generated at 2022-06-12 01:16:09.027214
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider.

    :return: None.
    """
    import doctest

    doctest.testmod(verbose=True)

# Generated at 2022-06-12 01:16:12.875944
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()

    provider1 = RussiaSpecProvider()
    snils1 = provider1.snils()

    assert snils != snils1

# Generated at 2022-06-12 01:16:15.624299
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils[0] != 0

# Generated at 2022-06-12 01:16:21.762497
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.helpers import calculate_checksum

    obj = RussiaSpecProvider()
    for _ in range(0, 10):
        snils = obj.snils()
        assert snils[:3] != '000'
        assert snils[-1] == str(calculate_checksum(snils[:9]))


# Generated at 2022-06-12 01:16:24.489237
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russiaspp = RussiaSpecProvider()
    assert russiaspp.snils() != russiaspp.snils()

# Generated at 2022-06-12 01:16:27.698903
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    for _ in range(0, 10):
        snils = provider.snils()
        assert(len(snils) == 11)

# Generated at 2022-06-12 01:16:30.492346
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test case for RussiaSpecProvider.snils method."""
    provider = RussiaSpecProvider()
    result = provider.snils()


# Generated at 2022-06-12 01:16:34.914138
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test snils"""
    from mimesis import RussiaSpecProvider

    r = RussiaSpecProvider()
    snils = r.snils()
    assert len(snils) == 11, 'Snils length expected to be 11'



# Generated at 2022-06-12 01:17:53.063617
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    b = RussiaSpecProvider()
    s = b.snils()
    f = open('snils.txt', 'a')
    f.write(s)
    f.write('\n')
    print(s)
    f.close()


# Generated at 2022-06-12 01:17:54.741013
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    ru = RussiaSpecProvider()
    res = ru.snils()
    print(res)



# Generated at 2022-06-12 01:17:57.521418
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = str(provider.snils())
    assert len(snils) == 11


# Generated at 2022-06-12 01:18:01.325676
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test for method snils of class RussiaSpecProvider"""
    r = RussiaSpecProvider(seed=0)
    print("\nTest for method snils of class RussiaSpecProvider")
    for i in range(10):
        print("snils:", r.snils())

# Generated at 2022-06-12 01:18:04.005896
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    random_rusia_snils = RussiaSpecProvider().snils()
    assert len(random_rusia_snils) == 11


# Generated at 2022-06-12 01:18:07.595457
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils == '41917492600'



# Generated at 2022-06-12 01:18:11.361758
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider.run_seed(
        '23afb2c48f269e86',
        'RussiaSpecProvider',
        'snils',
    ) == '85889843800'

# Generated at 2022-06-12 01:18:16.406608
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert snils.isdigit() and len(snils) >= 11, 'Value {} is incorrect'.format(snils)


# Generated at 2022-06-12 01:18:21.807627
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.person import Person

    russia = RussiaSpecProvider()
    person = Person('ru')

    first_name = person.first_name(gender=Gender.FEMALE)
    middle_name = russia.patronymic(gender=Gender.FEMALE)
    last_name = person.last_name(gender=Gender.FEMALE)

    fio = first_name + ' ' + middle_name + ' ' + last_name

    snils = russia.snils()

    print(snils, fio)


# Generated at 2022-06-12 01:18:23.521722
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider().snils() == '41917492600'
