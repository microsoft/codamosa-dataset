

# Generated at 2022-06-12 01:13:57.476621
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.numbers import Checksum
    check = Checksum(seed=None)

    test_snils = check.snils()
    import mimesis.enums as enums

    test_provider = enums.nt.RussiaSpecProvider()
    assert test_snils == test_provider.snils()
    assert test_snils == "78350299634"


# Generated at 2022-06-12 01:13:58.910290
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.russia_spec import RussiaSpecProvider
    russia = RussiaSpecProvider()
    assert len(russia.snils()) == 11


# Generated at 2022-06-12 01:14:00.451333
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    assert provider.snils()

# Generated at 2022-06-12 01:14:02.685234
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()
    assert type(rsp.snils()) == str


# Generated at 2022-06-12 01:14:09.560201
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russian_snils = RussiaSpecProvider()
    russian_snils.reset_seed()
    assert russian_snils.snils() == '201917492600'
    russian_snils.reset_seed()
    assert russian_snils.snils() == '971651994600'


# Generated at 2022-06-12 01:14:11.864415
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    assert provider.snils() == '41917492600'

# Generated at 2022-06-12 01:14:19.816930
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis import RussiaSpecProvider, Datetime

    # Проверка выбора года выдачи паспорта
    datetime = Datetime()
    current_year = datetime.date('Y')
    next_year = datetime.date(plus={'months': 5})

    russia_spec_provider = RussiaSpecProvider()
    snils = russia_spec_provider.snils()

    assert snils[-2:] == '00'

    # Проверка валидности сгенерированного СНИЛС по алгори

# Generated at 2022-06-12 01:14:27.396092
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """
        Unit test for method snils of class RussiaSpecProvider
    """
    print('\n--- test_RussiaSpecProvider_snils:')
    print('>>> r = RussiaSpecProvider()')
    r = RussiaSpecProvider()
    print('>>> r.snils()')
    s = r.snils()
    print(s)
    assert len(s) == 11
    assert all(c.isdigit() for c in s)


# Tests of the module russia_provider

# Generated at 2022-06-12 01:14:37.054448
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.russia import RussiaSpecProvider
    from mimesis.providers.address import Address
    from mimesis.providers.date_time import DateTime
    import re
    # Создаем экземпляры класса поставщик данных для РФ, адреса РФ, персоны и даты
    person = Person('ru')
    address = Address('ru')
    rus = RussiaSpecProvider('ru')
    date = DateTime('ru')
    #

# Generated at 2022-06-12 01:14:40.102636
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    s = RussiaSpecProvider()
    print(s.snils())


if __name__ == '__main__':
    test_RussiaSpecProvider_snils()

# Generated at 2022-06-12 01:14:49.216456
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    print("\nTest\n")
    r = RussiaSpecProvider()
    snils = r.snils()
    print(snils)
    assert(len(str(snils))) == 11


# Generated at 2022-06-12 01:14:52.541897
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    assert r.snils() is not None


# Generated at 2022-06-12 01:14:56.362106
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider"""
    test_method = RussiaSpecProvider.snils
    snils = []
    for x in range(0, 1000):
        snils.append(test_method(RussiaSpecProvider()))
    print(snils)
    assert snils != [0]*1000

# Generated at 2022-06-12 01:15:00.954924
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider"""
    from mimesis.providers.latin.russia import RussiaSpecProvider
    spec_provider = RussiaSpecProvider()
    for _ in range(0, 10):
        print(spec_provider.snils())


# Generated at 2022-06-12 01:15:06.854811
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.russia import RussiaSpecProvider
    from mimesis.providers.address import Address
    russiaspecprovider=RussiaSpecProvider()
    russiaspecprovider.seed(45)
    assert russiaspecprovider.snils()=='05292405688'

# Generated at 2022-06-12 01:15:09.684725
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    ts = RussiaSpecProvider(seed=12345)
    result = ts.snils()
    assert result == '24380072267'


# Generated at 2022-06-12 01:15:14.000974
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    
    # check length snils
    assert len(snils) == 11, 'Length snils is not correct' 
    
    # check format
    try:
        int(snils)
    except:
        assert False, 'Wrong format snils'
       

# Generated at 2022-06-12 01:15:23.766075
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """The function checks the value returned by the snils method of the class RussiaSpecProvider"""

    # генерация snils
    russia_provider = RussiaSpecProvider()
    snils = russia_provider.snils()

    # проверка длины
    assert len(snils) == 11

    # проверка на соответствие правилам генерации snils
    snils = str(snils)
    control_code = int(snils[9] + snils[10])

    def control_sum(i: int, weight: int) -> int:
        return i * weight


# Generated at 2022-06-12 01:15:25.422482
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rus = RussiaSpecProvider()
    test_input = rus.snils()
    assert test_input.__len__() == 11


# Generated at 2022-06-12 01:15:29.373052
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils."""
    ru = RussiaSpecProvider()
    assert ru.snils() == '41917492600'
    assert ru.snils() == '91912853800'


# Generated at 2022-06-12 01:15:45.077391
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Create an instance of RussiaSpecProvider
    rsp = RussiaSpecProvider()

    # Call method snils of object rsp
    print(rsp.snils())


# Generated at 2022-06-12 01:15:49.688007
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    S = provider.snils()
    if not isinstance(S, str):
        raise TypeError("Returned data type was not Str!")
    if not ((len(S) == 11) and (S.isdigit())):
        raise ValueError("Returned data was not valid SNILS!")


# Generated at 2022-06-12 01:15:54.806185
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    # 1 test for input value
    expect = "73817268000"
    result = provider.snils()
    assert result == expect
    # 2 test for input value
    expect = "60297547800"
    result = provider.snils()
    assert result == expect

# Generated at 2022-06-12 01:15:59.251929
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """generate a snils with special algorithm.

    :return: snils.

    :Example:
        41917492600.
    """
    s = RussiaSpecProvider()
    snils = s.snils()
    print(snils)
    # 41917492600
    return snils


# Generated at 2022-06-12 01:16:04.187602
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    provider.random.seed(1234)
    assert provider.snils() == '41917492600'
    provider.random.seed(4321)
    assert provider.snils() == '10854280800'


# Generated at 2022-06-12 01:16:08.312150
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.ru.address import Address

    address = Address()
    a = RussiaSpecProvider()

    for i in range(0, 100000):
        snils = a.snils()
        assert len(str(snils)) == 11
        if snils == '80735336400':
            FIO = address.full_name(gender=Gender.MALE)
            print(FIO, snils)



# Generated at 2022-06-12 01:16:15.567004
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.enums import Gender
    r = RussiaSpecProvider()
    r.seed(12345)
    print(r.snils())
    print(r.passport_number())
    print(r.passport_series(year=12))
    print(r.series_and_number())
    print(r.generate_sentence())
    print(r.patronymic(Gender.MALE))
    print(r.patronymic(Gender.FEMALE))
    print(r.inn())
    print(r.ogrn())
    print(r.bic())
    print(r.kpp())

# Generated at 2022-06-12 01:16:18.482013
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    snils = RussiaSpecProvider(seed=42).snils()
    assert snils == '74777652100'


# Generated at 2022-06-12 01:16:22.644656
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
	"""Unit test to check class RussiaSpecProvider method snils"""
	snils = '41917492600'
	x = RussiaSpecProvider()
	assert(x.snils() == snils)



# Generated at 2022-06-12 01:16:25.678301
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider"""
    r = RussiaSpecProvider()
    #print(r.snils())
    assert r.snils() == r.snils()


# Generated at 2022-06-12 01:16:37.629413
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    print(provider.snils())


# Generated at 2022-06-12 01:16:39.189139
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    assert provider.snils() == '41917492600'


# Generated at 2022-06-12 01:16:42.271481
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert type(snils) == str
    print('snils =', snils)


# Generated at 2022-06-12 01:16:44.608892
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    test_gen = RussiaSpecProvider()

    snils_list = []
    for _ in range(0, 10):
        snils_list.append(test_gen.snils())

    assert snils_list



# Generated at 2022-06-12 01:16:48.067025
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()
    print(rsp.snils())



# Generated at 2022-06-12 01:16:52.467935
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    ru = RussiaSpecProvider()
    for _ in range(0, 100):
        assert ru.snils() == ru.snils()

# Generated at 2022-06-12 01:16:56.338268
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    for i in range(0, 100):
        assert len(r.snils()) == 11

# Generated at 2022-06-12 01:16:58.643617
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11


# Generated at 2022-06-12 01:17:01.141398
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test RussiaSpecProvider class."""
    provider = RussiaSpecProvider()
    assert provider.snils() == '41917492600'

# Generated at 2022-06-12 01:17:06.379945
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():

    from . import RussiaSpecProvider
    
    ru = RussiaSpecProvider()
    
    print("Calling RussiaSpecProvider.snils()...")
    result = ru.snils()
    print("Result: ", result)

    print("Calling RussiaSpecProvider.inn()...")
    result = ru.inn()
    print("Result: ", result)
    
    print("Calling RussiaSpecProvider.ogrn()...")
    result = ru.ogrn()
    print("Result: ", result)

    print("Calling RussiaSpecProvider.bic()...")
    result = ru.bic()
    print("Result: ", result)

    print("Calling RussiaSpecProvider.kpp()...")
    result = ru.kpp()
    print("Result: ", result)

# Generated at 2022-06-12 01:17:27.821060
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider().snils() in '41917492600'

# Generated at 2022-06-12 01:17:30.234648
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Testing functional of method snils"""
    rus = RussiaSpecProvider()
    assert rus.snils() == '41917492600'

# Generated at 2022-06-12 01:17:32.896605
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    print('snils of class RussiaSpecProvider')
    provider = RussiaSpecProvider()
    snils = provider.snils()
    print(snils)
    assert type(snils) == str
    print('Tested OK')


# Generated at 2022-06-12 01:17:37.475178
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit testing for snils method."""
    from mimesis.builtins.us import USSpecProvider

    generator1 = USSpecProvider()
    generator2 = USSpecProvider(seed=generator1.seed)

    assert generator1.snils() == generator2.snils()

# Generated at 2022-06-12 01:17:39.788455
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russian = RussiaSpecProvider()
    inn = russian.inn()
    snils = russian.snils()
    assert len(inn) == 12
    assert len(snils) == 11


# Generated at 2022-06-12 01:17:43.207605
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    ru_snils = RussiaSpecProvider()
    assert ru_snils.snils() == '41917492600'


# Generated at 2022-06-12 01:17:49.792917
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    obj = RussiaSpecProvider()
    test_list = []
    for i in range(1000):
        test_list.append(obj.snils())
    test_set = set(test_list)
    assert len(test_set) == len(test_list), 'There is a repeated number'
    for i in test_list:
        assert len(i) == 11, 'The snils number does not have 11 digits'


# Generated at 2022-06-12 01:17:52.325861
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rs = RussiaSpecProvider("1234")
    snils = rs.snils()
    assert snils == '41917492600'


# Generated at 2022-06-12 01:17:54.411735
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    for i in range(50):
        assert RussiaSpecProvider().snils().__len__() == 11


# Generated at 2022-06-12 01:17:55.914890
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    generator = RussiaSpecProvider()
    assert len(generator.snils()) == 11

# Generated at 2022-06-12 01:18:36.834062
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    print(provider.snils())


# Generated at 2022-06-12 01:18:39.196649
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    ru = RussiaSpecProvider()
    snils = ru.snils()
    print(snils)


# Generated at 2022-06-12 01:18:43.208980
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    for _ in range(10):
        print(provider.snils())


if __name__ == '__main__':
    test_RussiaSpecProvider_snils()

# Generated at 2022-06-12 01:18:46.990810
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    ru = RussiaSpecProvider()
    snils_list = []
    for _ in range(10000):
        snils_list.append(ru.snils())
        if len(snils_list) > 1:
            assert snils_list[-1] != snils_list[-2]


# Generated at 2022-06-12 01:18:52.951092
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Instantiate RussiaSpecProvider
    rsp = RussiaSpecProvider()
    # Generate snils with method snils
    snils = rsp.snils()

    # Check
    numbers = [int(snils[i:i+1]) for i in range(0, len(snils) - 2)]

    sum = 0
    for i in range(9, 0, -1):
        sum += numbers[9 - i] * i

    control_code = str(sum % 101)
    if control_code in ('100', '101'):
        control_code = '00'

    if(control_code != snils[-2:]):
        raise ValueError('snils is not valid')
        return

if __name__ == '__main__':
    test_RussiaSpecProvider_snils()

# Generated at 2022-06-12 01:18:57.124878
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    import doctest
    doctest.testmod()
    test = RussiaSpecProvider()
    CN = test.snils()
    assert len(CN) == 11
    return True

# Generated at 2022-06-12 01:19:01.388581
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(str(snils)) == 11
    assert snils == '41917492600'

# Generated at 2022-06-12 01:19:03.167960
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.builtins import RussiaSpecProvider
    print(RussiaSpecProvider().snils())



# Generated at 2022-06-12 01:19:05.932410
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert snils.isdigit()

# Generated at 2022-06-12 01:19:07.661691
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis import Generic
    gen = Generic('ru')
    snils = gen.russia_provider.snils()
    assert len(snils) == 11

if __name__ == '__main__':
    print(test_RussiaSpecProvider_snils())

# Generated at 2022-06-12 01:21:05.691342
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider(seed=0)
    assert r.snils() == '41917492600'

# Generated at 2022-06-12 01:21:07.664759
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.person.ru import RussiaSpecProvider
    snils = RussiaSpecProvider(seed=100)
    assert snils.snils() == '63909542700'


# Generated at 2022-06-12 01:21:10.134030
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.rus_provider import RussiaSpecProvider
    print(RussiaSpecProvider().snils())

# Generated at 2022-06-12 01:21:12.430884
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    snils = RussiaSpecProvider().snils()
    print(snils)
    assert snils is not None 


# Generated at 2022-06-12 01:21:15.936931
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert snils != '', "Generated SNILS is empty."
    assert type(snils) == str, "SNILS must be a string."

# Generated at 2022-06-12 01:21:18.837010
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rus = RussiaSpecProvider() 
    print(rus.snils())


# Generated at 2022-06-12 01:21:20.993636
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.builtins import RussiaSpecProvider
    rus = RussiaSpecProvider()
    snils = rus.snils()
    print(snils)


# Generated at 2022-06-12 01:21:22.159137
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider().snils() == '06081265240'

# Generated at 2022-06-12 01:21:24.941263
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.person import Person
    p = Person('ru')
    print(p.snils())

# Generated at 2022-06-12 01:21:26.337285
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test of snils method."""
    result = RussiaSpecProvider().snils()
    assert len(result) == 11
