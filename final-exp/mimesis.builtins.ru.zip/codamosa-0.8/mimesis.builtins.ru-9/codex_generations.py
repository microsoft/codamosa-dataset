

# Generated at 2022-06-12 01:14:00.691946
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.enums import Gender
    from mimesis.providers import RussiaSpecProvider
    rb = RussiaSpecProvider()
    snils = rb.snils()
    assert len(snils) == 11
    assert snils == '41917492600'


# Generated at 2022-06-12 01:14:04.421737
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider_obj = RussiaSpecProvider()
    assert provider_obj.snils() in ['41917492600', '41917492601']



# Generated at 2022-06-12 01:14:09.060014
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.person import Person
    a = RussiaSpecProvider()
    b = Person('ru')
    c = a.snils()
    d = b.snils()
    assert c == d

# Generated at 2022-06-12 01:14:18.252249
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test method snils of class RussiaSpecProvider
    Test result is generated once
    test results are stored in file
    This method compares the test result with the expected result and returns the result of the comparison"""
    russia_spec_provider = RussiaSpecProvider()
    # generation of snils
    russia_spec_provider_snils = russia_spec_provider.snils()
    # read expected result from file
    with open(file='C:/Users/v.egorov/PycharmProjects/mimesis/tests/data/RussiaSpecProvider/snils.txt',
              encoding='utf-8', mode='r') as f:
        file_content = f.read()
    # compare generated result with expected result
    if russia_spec_provider_snils == file_content:
        return True

# Generated at 2022-06-12 01:14:21.173233
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rus_spec = RussiaSpecProvider(seed=1)
    assert rus_spec.snils() == '41917492600'


# Generated at 2022-06-12 01:14:32.828651
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test generate snils with special algorithm.

    :return: SNILS.

    :Example:
        41917492600.
    """
    instance = RussiaSpecProvider()
    snils = instance.snils()
    sum = 0
    snils = list(snils)
    snils = list(map(int, snils))
    for x in snils[0:9]:
        sum += x
    if sum % 101 == snils[9] * 100 + snils[10] * 10 + snils[11]:
        print('snils: ' + str(sum % 101))
        print('check code: ' + str(snils[9] * 100 + snils[10] * 10 + snils[11]))
        print('test_RussiaSpecProvider_snils passed')

# Generated at 2022-06-12 01:14:35.892481
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    snils = RussiaSpecProvider().snils()
    assert len(snils) == 11
    print(snils)


# Generated at 2022-06-12 01:14:41.285502
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test snils method."""
    # For predictable results while testing
    rsp = RussiaSpecProvider(seed=42)
    assert rsp.snils() == '41917492600'
    rsp = RussiaSpecProvider(seed='4242')
    assert rsp.snils() == '41917492600'


# Generated at 2022-06-12 01:14:48.935747
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.person.enums import PersonSNILS
    from mimesis.providers.person.enums import PersonINN
    from mimesis.providers.person.enums import PersonOGRN
    from mimesis.providers.person.enums import PersonBIC
    from mimesis.providers.person.enums import PersonKPP
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.person import RussiaSpecProvider

    person = Person('ru')
    russia = RussiaSpecProvider('ru')
    # Test snils
    snils = russia.snils()
    assert len(snils) == 11
    assert snils.isdigit()
    assert isinstance(snils, str)
    assert r

# Generated at 2022-06-12 01:14:52.851003
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    assert provider.snils() == '41917492600'

# Generated at 2022-06-12 01:15:13.362755
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    snils = RussiaSpecProvider().snils()
    assert isinstance(int(snils), int)
    assert len(snils) == 11
    assert int(snils[-2:]) <= 101
    assert int(snils[-2:]) >= 0


# Generated at 2022-06-12 01:15:15.138453
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    ru = RussiaSpecProvider()
    ru.snils()

# Generated at 2022-06-12 01:15:16.781229
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()
    print(rsp.snils())


# Generated at 2022-06-12 01:15:28.284878
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    import pytest
    from mimesis.providers.person.ru import RussiaSpecProvider

    # Assumption of algorithm
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    list_snils = list(snils)
    check_code = int(list_snils[9] + list_snils[10] + list_snils[11])
    numbers = list(map(int, list_snils[:9]))
    control_codes = []
    for i in range(9, 0, -1):
        control_codes.append(numbers[9 - i] * i)
    control_code = sum(control_codes)
    assert control_code == check_code
    assert len(snils) == 11




# Generated at 2022-06-12 01:15:30.498615
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of RussiaSpecProvider class."""
    russ = RussiaSpecProvider()
    assert russ.snils()


# Generated at 2022-06-12 01:15:32.847808
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test snils method."""
    assert RussiaSpecProvider(seed=0).snils() == '41917492600'


# Generated at 2022-06-12 01:15:37.315954
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.person.russia_provider import RussiaSpecProvider
    rgp = RussiaSpecProvider()
    
    for i in range(10):
        print(rgp.snils())  


# Generated at 2022-06-12 01:15:41.209304
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Test case (random)
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11

    # Test case (fixed seed)
    provider = RussiaSpecProvider(seed=123)
    snils = provider.snils()
    assert snils == '48484923900'


# Generated at 2022-06-12 01:15:45.503948
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    print('Test function snils of class RussiaSpecProvider')
    d = RussiaSpecProvider()
    for _ in range(10):
        print(d.snils())


# Generated at 2022-06-12 01:15:52.642678
# Unit test for method snils of class RussiaSpecProvider

# Generated at 2022-06-12 01:16:40.870495
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    # Case 1. Some interesting snils
    provider.reset_seed(0)
    assert provider.snils() == '41917492600'
    provider.reset_seed(1)
    assert provider.snils() == '40403340696'
    provider.reset_seed(2)
    assert provider.snils() == '35604283093'
    provider.reset_seed(3)
    assert provider.snils() == '64216497292'
    provider.reset_seed(4)
    assert provider.snils() == '55705514878'
    provider.reset_seed(5)
    assert provider.snils() == '48604857605'
    provider.reset_seed(6)
    assert provider.snils() == '24803798607'


# Generated at 2022-06-12 01:16:42.347959
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider().snils() == '41917492600'


# Generated at 2022-06-12 01:16:54.152321
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    import re
    rp = RussiaSpecProvider()
    snils111 = rp.snils()
    snils112 = rp.snils()
    snils113 = rp.snils()
    snils114 = rp.snils()
    snils115 = rp.snils()
    snils116 = rp.snils()
    snils117 = rp.snils()
    snils118 = rp.snils()
    snils119 = rp.snils()
    snils120 = rp.snils()
    snils121 = rp.snils()
    snils122 = rp.snils()
    snils123 = rp.snils()
    snils124 = rp.snils()
    snils125 = rp.snils()
    snils126 = r

# Generated at 2022-06-12 01:16:56.796967
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()
    print(rsp.snils())

# Generated at 2022-06-12 01:17:02.432382
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    a = RussiaSpecProvider()
    b = RussiaSpecProvider()
    c = RussiaSpecProvider()
    d = RussiaSpecProvider()
    e = RussiaSpecProvider()

    assert len(a.snils()) == 11
    assert len(b.snils()) == 11
    assert len(c.snils()) == 11
    assert len(d.snils()) == 11
    assert len(e.snils()) == 11



# Generated at 2022-06-12 01:17:04.160442
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    f = RussiaSpecProvider()
    print(f.snils())

# Generated at 2022-06-12 01:17:05.695036
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    print(r.snils())

# Generated at 2022-06-12 01:17:08.275512
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """
    Unit test for snils of class RussiaSpecProvider
    """
    obj = RussiaSpecProvider(seed=1)
    result = obj.snils()
    assert result == '41917492600'

# Generated at 2022-06-12 01:17:14.003528
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test function snils of class RussiaSpecProvider."""
    # initialization of a class instance
    ru = RussiaSpecProvider()

    # test data

# Generated at 2022-06-12 01:17:25.846629
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """ Tests the snils method of the RussiaSpecProvider class
    """
    provider = RussiaSpecProvider()
    result = provider.snils()
    result_numbers = result[:-2]
    result_check_sum = result[-2:]

    assert len(result) == 11

    control_codes = []

    for i in range(9, 0, -1):
        control_codes.append(int(result_numbers[9 - i]) * i)

    control_code = sum(control_codes)

    if control_code in (100, 101):
        assert result_check_sum == '00'
    elif control_code < 100:
        assert result_check_sum == str(control_code)

# Generated at 2022-06-12 01:18:19.023957
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.finance import Finance
    from mimesis.providers.person import Person
    from mimesis.providers.utils import calc_luhn_checksum

    r = RussiaSpecProvider()
    f = Finance()
    p = Person()
    # 1.
    snils = r.snils()
    # 2.
    assert len(snils) == 11
    # 3.
    series = snils[:3]
    number = snils[3:]
    assert int(series) < 875
    # 4.
    assert f.checksum([(i, 0) for i in range(11)], number) == 0
    # 5.

# Generated at 2022-06-12 01:18:27.392338
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    ru = RussiaSpecProvider()

    list_snils = []

    for i in range(0, 1000):
        list_snils.append(ru.snils())

    for j in range(0, 1000):
        list_snils.append(ru.snils())

    len(set(list_snils))

    return(len(set(list_snils)) == 2000)

if __name__ == "__main__":
    print(test_RussiaSpecProvider_snils())

# Generated at 2022-06-12 01:18:28.926094
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    assert provider.snils() == '41917492600'


# Generated at 2022-06-12 01:18:32.477146
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    ru = RussiaSpecProvider()
    ru_snils_list = []
    for _ in range(1, 100):
        ru_snils = ru.snils()
        ru_snils_list.append(ru_snils)
    assert ru_snils_list.count(ru_snils) == 1

# Generated at 2022-06-12 01:18:35.452336
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    import pytest
    rus_provider = RussiaSpecProvider()
    t = rus_provider.snils()
    assert type(t) == str
    assert len(t) == 11

# Generated at 2022-06-12 01:18:37.084326
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider=RussiaSpecProvider()
    print(provider.snils())
    assert len(provider.snils())==11


# Generated at 2022-06-12 01:18:38.865325
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider().snils() == '41917492600'


# Generated at 2022-06-12 01:18:43.929149
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia = RussiaSpecProvider()
    snils = russia.snils()
    assert snils.isdigit() == True
    assert len(snils) == 11
    snils_int = int(snils)
    assert snils_int > 1001999 and snils_int < 999999999


# Generated at 2022-06-12 01:18:47.719282
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    snils = RussiaSpecProvider().snils()
    assert len(snils) == 11
    assert type(snils) == str
    assert not snils.startswith(('1', '0'))


if __name__ == '__main__':
    import os
    print(os.path.curdir)

# Generated at 2022-06-12 01:18:49.336858
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    s = RussiaSpecProvider(seed=42)
    n = s.snils()
    assert n == '41917492600'


# Generated at 2022-06-12 01:20:07.893376
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""

    rsp = RussiaSpecProvider()
    for _ in range(100):
        snils = rsp.snils()
        if not snils:
            raise ValueError
        print(snils)

    rsp = RussiaSpecProvider(seed=42)
    for _ in range(100):
        snils = rsp.snils()
        if not snils:
            raise ValueError
        print(snils)

    rsp = RussiaSpecProvider(seed='The true answer to life, the universe, '
                                    'and everything.')
    for _ in range(100):
        snils = rsp.snils()
        if not snils:
            raise ValueError
        print(snils)



# Generated at 2022-06-12 01:20:18.479320
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Задаем инстанс провайдера с фиксированным seed
    provider = RussiaSpecProvider(seed=1234567890)

    # Создаем список проверочных значений

# Generated at 2022-06-12 01:20:21.727395
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    if int(snils[-2:]) == 0:
        assert snils[-3:] == '000'
    else:
        assert int(snils[-2:]) > 0
        assert int(snils[-2:]) < 100

# Generated at 2022-06-12 01:20:24.036899
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rnp = RussiaSpecProvider()

    real_snils = rnp.snils()
    assert len(real_snils)
    assert real_snils.isnumeric()

# Generated at 2022-06-12 01:20:25.340876
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():

    russian_provider = RussiaSpecProvider()
        
    assert(russian_provider.snils() != None)

# Generated at 2022-06-12 01:20:28.435503
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test for RussiaSpecProvider.snils()."""
    a = RussiaSpecProvider()
    b = a.snils()
    print("{}".format(b))


# Generated at 2022-06-12 01:20:35.859924
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    print('Test random snils:')
    rsp = RussiaSpecProvider()
    print(rsp.snils())
    print(rsp.snils())
    print(rsp.snils())
    print(rsp.snils())
    print(rsp.snils())
    print(rsp.snils())
    print(rsp.snils())
    print(rsp.snils())
    print(rsp.snils())
    print(rsp.snils())
    print(rsp.snils())
    print(rsp.snils())
    print(rsp.snils())
    print(rsp.snils())
    print(rsp.snils())
    print(rsp.snils())
    print(rsp.snils())
    print(rsp.snils())


# Generated at 2022-06-12 01:20:38.326432
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider"""
    provider = RussiaSpecProvider()
    assert len(provider.snils()) == 11


# Generated at 2022-06-12 01:20:42.299379
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider().snils() not in (
        '0001000000', '0002000000', '0003000000',
        '9900000000', '9990000000', '9999000000',
        '9999900000', '9999900000', '9999990000',
        '9999999000', '9999999900', '9999999990')


# Generated at 2022-06-12 01:20:46.942733
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()
    flag = True
    for i in range(0, 100000):
        flag &= (len(rsp.snils()) == 11)
    assert flag

# Generated at 2022-06-12 01:23:10.334831
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider"""
    prov = RussiaSpecProvider()
    snils = prov.snils()
    assert len(snils) == 11
    assert type(snils) == str


# Generated at 2022-06-12 01:23:20.135446
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test snils method"""
    provider = RussiaSpecProvider(seed=123)
    expected = '41917492600'
    actual = provider.snils()
    assert expected == actual
    provider = RussiaSpecProvider(seed=123456)
    expected = '96390138800'
    actual = provider.snils()
    assert expected == actual
    provider = RussiaSpecProvider(seed=1234567)
    expected = '78815662400'
    actual = provider.snils()
    assert expected == actual
    provider = RussiaSpecProvider(seed=12345678)
    expected = '71827078800'
    actual = provider.snils()
    assert expected == actual
    provider = RussiaSpecProvider(seed=123456789)
    expected = '77067468800'
    actual = provider.snils()

# Generated at 2022-06-12 01:23:29.994097
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.builtins.russia import RussiaSpecProvider
    from mimesis.enums import Gender
    from mimesis.schema import Field, Schema

    seed_ = "mimesis"

    rus_provider = RussiaSpecProvider(seed=seed_)

    # snils
    assert rus_provider.snils() == '41917492600'

    # passport_series
    assert rus_provider.passport_series() == '24 15'

    # passport_number
    assert rus_provider.passport_number() == 840192

    # inn
    ## default
    assert rus_provider.inn() == '364883526140'
    ## assert inn_ == '364883526140'

    ## generate with seed
    rus_provider_2 = Russia

# Generated at 2022-06-12 01:23:32.881639
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers import RussiaSpecProvider
    r = RussiaSpecProvider()
    print(r.snils())

# Generated at 2022-06-12 01:23:39.221346
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    snils_checker = []
    testInstance = RussiaSpecProvider()
    count = 10000
    while count:
        if len(snils_checker) == 99*9*9*9*9*9*9*9*9:
            break
        snils = testInstance.snils()
        if snils not in snils_checker:
            snils_checker.append(snils)
            count = count - 1
    print("All unique SNILS numbers: ")
    print(snils_checker)
    print("Total unique numbers: ", len(snils_checker))


# Generated at 2022-06-12 01:23:42.016326
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r=RussiaSpecProvider()
    l=[]
    while True:
        l.append(r.snils())
        if len(l) > 100:
            break
    assert len(l)==101
    assert len(list(set(l))) > 1

