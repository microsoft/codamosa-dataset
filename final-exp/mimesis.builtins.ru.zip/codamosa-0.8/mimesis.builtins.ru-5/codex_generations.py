

# Generated at 2022-06-12 01:14:01.830675
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    snils = RussiaSpecProvider(seed=1234567890)
    import re
    test_result = snils.snils()
    if re.fullmatch(r'\d{9}', test_result):
        print(test_result)
    else:
        print(test_result, '<- not valid snils')



# Generated at 2022-06-12 01:14:03.881604
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    res = RussiaSpecProvider().snils()
    assert len(res) == 11

# Generated at 2022-06-12 01:14:08.079287
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    inst = RussiaSpecProvider()
    inst.reset_seed(3)
    assert str(inst.snils()).strip().lower() == '31468668948'


# Generated at 2022-06-12 01:14:17.270707
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russian = RussiaSpecProvider()
    assert len(russian.snils()) == 11

    test_snils = [russian.snils() for _ in range(0, 1000)]
    for snils in test_snils:
        check_sum1 = int(snils[9:11])
        check_sum2 = int(snils[8])
        check_sum3 = int(snils[7])
        nums = snils[:9]
        sum1 = 0
        sum2 = 0

        for i in range(9, 0, -1):
            sum1 += int(nums[9 - i]) * i

        for x in nums:
            sum2 += int(x)

        assert (check_sum1 == sum1 % 101) or (check_sum1 == 0)
        assert check_sum2

# Generated at 2022-06-12 01:14:19.962188
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    print('snils =', provider.snils())



# Generated at 2022-06-12 01:14:22.033533
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    print(snils)


# Generated at 2022-06-12 01:14:24.199793
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    ru = RussiaSpecProvider()
    res = ru.snils()
    assert len(res) == 11

# Generated at 2022-06-12 01:14:33.565436
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.enums import Gender
    from mimesis.providers.identifiers import Identifiers
    from mimesis.providers.other import Other
    r = Other('ru')
    s = Identifiers('ru')
    pat = r.patronymic(gender=Gender.FEMALE)
    surname = r.surname(gender=Gender.FEMALE)
    name = r.name(gender=Gender.FEMALE)
    snils = s.snils()
    expected_res = '41917492600'
    assert snils == expected_res, 'Should be {}, but got {}'.format(expected_res,snils)

# Generated at 2022-06-12 01:14:38.457760
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():

    provider = RussiaSpecProvider()
    snils = provider.snils()

    assert isinstance(snils, str)

    assert int(snils[0:9]) % 101 == int(snils[9:11])



# Generated at 2022-06-12 01:14:39.909936
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()
    assert len(rsp.snils()) == 11

# Generated at 2022-06-12 01:14:58.539589
# Unit test for method snils of class RussiaSpecProvider

# Generated at 2022-06-12 01:15:10.185344
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():

    # Верификация состояния атрибута экземпляра класса RussiaSpecProvider
    assert hasattr(RussiaSpecProvider, 'snils')

    # Проверка типа атрибута экземпляра класса RussiaSpecProvider
    assert type(RussiaSpecProvider.snils) is property

    # Верификация корректности работы метода snils экземпля

# Generated at 2022-06-12 01:15:19.094553
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rp = RussiaSpecProvider()
    nums = []
    for i in range(0, 500):
        num = int(rp.snils())
        nums.append(num)
        assert num >= 100000000 and num <= 999999999

    for i in range(1, 9):
        for j in range(0, 500):
            assert nums[j] % 10 == i
            nums[j] = int(nums[j] / 10)

    for i in range(0, 500):
        assert nums[i] % 10 == 9
        nums[i] = int(nums[i] / 10)

    for i in range(0, 500):
        assert nums[i] % 10 == 8
        nums[i] = int(nums[i] / 10)


# Generated at 2022-06-12 01:15:22.553823
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    print('Generate snils with special algorithm')
    results = RussiaSpecProvider()
    results = results.snils()
    print(results)



# Generated at 2022-06-12 01:15:26.288670
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    r = provider.snils()

    assert len(r) == 11
    assert int(r) % 11 % 10 == int(r[9:11])

# Generated at 2022-06-12 01:15:29.161174
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    r = RussiaSpecProvider()
    for i in range(0, 100):
        print(r.snils())

# Generated at 2022-06-12 01:15:30.698938
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()
    assert rsp.snils()


# Generated at 2022-06-12 01:15:32.645993
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    ssp = RussiaSpecProvider()
    assert len(ssp.snils()) == 11


# Generated at 2022-06-12 01:15:42.013372
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test for RussiaSpecProvider.snils method."""
    r = RussiaSpecProvider()
    for _ in range(100):
        snils = r.snils()
        assert len(snils) == 11
        assert (int(snils[0]) > 0 and int(snils[1]) > 0)
        assert (int(snils[2]) > 0 and int(snils[3]) > 0)
        assert (int(snils[4]) > 0 and int(snils[5]) > 0)
        assert (int(snils[6]) > 0 and int(snils[7]) > 0)
        assert int(snils[8]) > 0
        assert (int(snils[9]) >= 0 and int(snils[10]) >= 0)



# Generated at 2022-06-12 01:15:45.644936
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test method of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    assert len(provider.snils()) == 11

# Generated at 2022-06-12 01:16:06.805714
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    ru = RussiaSpecProvider()
    def test_snils(snils):
        nums = list(map(int, snils))
        control_codes = []

        for i in range(0, 9):
            control_codes.append(nums[i] * (9 - i))

        control_code = sum(control_codes)
        if control_code in (100, 101):
            return True
        if control_code < 100:
            return True
        if control_code > 101:
            control_code = control_code % 101
            if control_code == 100:
                return True
            return True
        return False

    for _ in range(100):
        assert test_snils(ru.snils())


# Generated at 2022-06-12 01:16:11.945600
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """
    We want to check whether the number is
    generated according to the algorithm
    """
    russian = RussiaSpecProvider()
    snils = russian.snils()
    assert snils[-2:] == str(int(snils[:-2]) % 101 % 100)

# Generated at 2022-06-12 01:16:18.874836
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider"""
    obj = RussiaSpecProvider(seed=42)

    pattern = r'\d{3}-\d{3}-\d{3} \d{2}'
    snils = obj.snils()
    text = f'{snils[:3]}-{snils[3:6]}-{snils[6:9]} {snils[9:]}'

    assert re.match(pattern, text)
    assert snils == '41917492600'



# Generated at 2022-06-12 01:16:20.790014
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    assert len(provider.snils()) == 11


# Generated at 2022-06-12 01:16:24.388035
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    snils = RussiaSpecProvider(seed=42).snils()
    assert snils == '66616492300'

# Generated at 2022-06-12 01:16:25.864711
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    result = r.snils()
    print(result)


# Generated at 2022-06-12 01:16:31.207030
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    ru = RussiaSpecProvider()
    snils = ru.snils()
    assert isinstance(snils, str)
    assert len(snils) == 11
    assert snils.isdigit()
    assert int(snils) > 0


# Generated at 2022-06-12 01:16:42.812975
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test check snils of RussiaSpecProvider.

    :return:
    """
    from mimesis.providers.person.ru import RussiaSpecProvider
    from mimesis.typing import Seed

    rsp = RussiaSpecProvider(Seed.create('32a4dfc79134b241'))
    # test snils function with default value
    assert rsp.snils() == '41917492600'
    # test snils function with count parameter
    assert rsp.snils(count=3) == ['41917492600', '41917492600', '41917492600']
    # test snils function with count & separator parameter
    assert rsp.snils(count=3, separator=',') == '41917492600,41917492600,41917492600'

# Generated at 2022-06-12 01:16:45.558318
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    n = provider.snils()
    assert n is not None, "Result is None, but expected result is not None"


# Generated at 2022-06-12 01:16:54.002783
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    last_snils = None
    for i in range(0, 94):
        snils = provider.snils()
        print(snils)
        assert snils != last_snils
        assert len(snils) == 11
        assert snils.isdigit()
        last_snils = snils
    snils = provider.snils(seed=943)
    print("\n" + snils)
    assert snils == "41917492600"


# Generated at 2022-06-12 01:17:20.237782
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    a = RussiaSpecProvider(seed=123)
    print(a.snils())


# Generated at 2022-06-12 01:17:22.473228
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    test_snils = RussiaSpecProvider()
    assert test_snils.snils() == '41917492600'

# Generated at 2022-06-12 01:17:27.417774
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
	# Some code
	snils = RussiaSpecProvider().snils()
	kpp = RussiaSpecProvider().kpp()
	inn = RussiaSpecProvider().inn()
	ogrn = RussiaSpecProvider().inn()
	bic = RussiaSpecProvider().bic()
	print(inn, ogrn, ogrn, kpp, bic)
	pass


# Generated at 2022-06-12 01:17:31.050322
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rp = RussiaSpecProvider()
    print(rp.snils())
    print(rp.snils())
    print(rp.snils())
    print(rp.snils())
    print(rp.snils())


# Generated at 2022-06-12 01:17:34.151256
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test for generate snils from RussiaSpecProvider."""
    rus = RussiaSpecProvider()
    snils = rus.snils()
    assert len(str(snils)) == 11
    assert snils == '41917492600'

# Generated at 2022-06-12 01:17:36.342856
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    assert len(r.snils()) == 11


# Generated at 2022-06-12 01:17:37.770609
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider().snils() == '41917492600'

# Generated at 2022-06-12 01:17:40.115822
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    a = []
    russia = RussiaSpecProvider()
    n = int(input())
    for _ in range(n):
        a.append(russia.snils())
    print(a)


# Generated at 2022-06-12 01:17:45.022201
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11, ("Length of generated snils number must be 11")
    assert snils != (rsp.snils()), ("snils generation must be random")


# Generated at 2022-06-12 01:17:47.080132
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()

    snils1 = provider.snils()
    snils2 = provider.snils()
    assert snils1 != snils2


# Generated at 2022-06-12 01:18:39.546057
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    test_RussiaSpecProvider = RussiaSpecProvider(seed=345)
    snils = test_RussiaSpecProvider.snils()
    assert snils == '41917492600'


# Generated at 2022-06-12 01:18:41.621382
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    a = RussiaSpecProvider()
    print(a.snils())


# Generated at 2022-06-12 01:18:44.550003
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    p = RussiaSpecProvider()
    assert len(p.snils()) == 11
    assert len(set([p.snils() for _ in range(100)])) == 100


# Generated at 2022-06-12 01:18:47.942777
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.enums import Gender
    r = RussiaSpecProvider()
    for i in range(0, 10):
        r.snils()
    for sex in Gender:
        for i in range(0, 10):
            r.patronymic(sex)


# Generated at 2022-06-12 01:18:49.775399
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    snils = r.snils()
    assert len(snils) == 11 and snils.isdigit()


# Generated at 2022-06-12 01:18:52.141980
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    print(provider.snils())
    print(provider.snils())
    print(provider.snils())


# Generated at 2022-06-12 01:18:53.592476
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    snils = RussiaSpecProvider().snils()
    assert snils in set()
    print(snils)


# Generated at 2022-06-12 01:18:58.181681
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()

    # Unit test for method snils of class RussiaSpecProvider
    def test_RussiaSpecProvider_snils():
        rsp = RussiaSpecProvider()

        assert len(rsp.snils()) == 11
        assert isinstance(rsp.snils(), str)



# Generated at 2022-06-12 01:19:03.000093
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis import Random

    ru = RussiaSpecProvider(seed=Random())
    for i in range(10):
        print(ru.snils())

test_RussiaSpecProvider_snils()


# Generated at 2022-06-12 01:19:08.800518
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    print("\nТестируется метод snils класса RussiaSpecProvider\n")
    print("Примеры:")

    russiaspecprovider = RussiaSpecProvider()
    examples = []
    for i in range(10):
        examples.append(russiaspecprovider.snils())
    for example in examples:
        print(example)


# Generated at 2022-06-12 01:21:27.406947
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    ru = RussiaSpecProvider()
    snils_list = [ru.snils() for i in range(10)]
    len_snils_list = len(snils_list)
    uniq_snils_list = list(set(snils_list))
    assert len_snils_list == len(uniq_snils_list)

# Generated at 2022-06-12 01:21:31.406233
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    '''
    Test snils method of RussiaSpecProvider class
    '''
    # Create RussiaSpecProvider object
    russia = RussiaSpecProvider()

    # Test snils method
    assert len(russia.snils()) == 11
    assert russia.snils().isnumeric()


# Generated at 2022-06-12 01:21:34.670724
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert isinstance(snils, str)



# Generated at 2022-06-12 01:21:39.154971
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    snils = RussiaSpecProvider().snils()
    print(snils)
    assert (len(snils) == 11)
    assert (snils[:3] != '000')
    assert (snils[3] != '0' or snils[4] != '0')


# Generated at 2022-06-12 01:21:40.958482
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.enums import Gender
    r = RussiaSpecProvider(seed=42)
    r.snils() == '041917492600'

# Generated at 2022-06-12 01:21:43.523992
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.russia import RussiaSpecProvider
    r = RussiaSpecProvider(seed=65)
    snils = r.snils()
    # snils should be 41917492600
    assert snils == '41917492600'


# Generated at 2022-06-12 01:21:55.501813
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for `RussiaSpecProvider.snils`."""
    provider = RussiaSpecProvider()

    # SNILS should be always 11 symbols
    snils = provider.snils()
    assert len(snils) == 11

    # SNILS should contain only digits
    assert snils.isdigit()

    # SNILS should end with zeros
    if snils[-2:-1] == '00':
        assert snils[-2:].zfill(2) == '00'
        # SNILS should consist of 9 digits + 2 zeros
        assert len(snils) == 11

    # SNILS should end with two digits
    else:
        # SNILS should be a number
        assert type(int(snils))

        # SNILS should consist of 9 digits and 2 digits at the end
        assert len(snils) == 11

# Generated at 2022-06-12 01:21:59.944868
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    pr = RussiaSpecProvider()
    name1 = pr.snils()
    name2 = pr.snils()
    assert name1 != name2
    assert name1 != pr.snils()
    assert name1 is not None
    assert name2 is not None


# Generated at 2022-06-12 01:22:02.412894
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    s = RussiaSpecProvider()
    assert len(s.snils()) == 11


# Generated at 2022-06-12 01:22:07.166725
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    test_snils_list = []
    test_cases_num = 1000
    for _ in range(test_cases_num):
        test_snils = RussiaSpecProvider().snils()
        test_snils_list.append(test_snils)
        assert len(test_snils) == 11
        assert type(test_snils) == str
    assert len(set(test_snils_list)) == len(test_snils_list)
