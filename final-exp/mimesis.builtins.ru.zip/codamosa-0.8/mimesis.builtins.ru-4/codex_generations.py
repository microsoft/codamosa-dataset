

# Generated at 2022-06-12 01:14:00.154682
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rp = RussiaSpecProvider()
    assert len(rp.snils()) == 11
    print(rp.snils())
    assert rp.snils() != rp.snils()


# Generated at 2022-06-12 01:14:02.820973
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider"""
    rsp = RussiaSpecProvider()
    assert(len(rsp.snils()) == 11)

# Generated at 2022-06-12 01:14:14.166732
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test that the generated SNILS is valid."""
    from mimesis.enums import Gender

    r = RussiaSpecProvider()  # noqa: S105
    snils = r.snils()
    series = int(snils[0:3])
    number = int(snils[3:11])

# Generated at 2022-06-12 01:14:15.819701
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    obj = RussiaSpecProvider()
    snils = obj.snils()
    assert type(snils) == str

# Generated at 2022-06-12 01:14:22.132783
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    import docopt
    import sys
    from mimesis.providers.russia_provider import RussiaSpecProvider

    options = docopt.docopt(__doc__, version='0.0.1')
    provider = RussiaSpecProvider(options['--seed'])
    print(provider.snils())
# End of Unit test for method snils of class RussiaSpecProvider

# Generated at 2022-06-12 01:14:33.223165
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for the method snils."""
    seed = [0]
    snils_list = [
        41917492600,
        70352205442,
        46962818678,
        63640579260,
        39526483088,
        94229048191,
        97869563080,
        37391921597,
        42695891360,
        68745872271,
    ]
    rsp = RussiaSpecProvider(seed=seed)

    for snils in snils_list:
        # print('\n---------------')
        # print('Result:', rsp.snils())
        # print('Expected:', snils)
        assert rsp.snils() == snils


# Generated at 2022-06-12 01:14:35.003203
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider().snils() == '1234567890'

# Generated at 2022-06-12 01:14:40.833544
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    a = RussiaSpecProvider()
    num = int(a.snils())
    control_codes = []
    for i in range(9, 0, -1):
        control_codes.append(num % 10 * i)
        num = num // 10
    control_code = sum(control_codes)
    assert control_code % 101 == num % 100

# Generated at 2022-06-12 01:14:43.481179
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    result = RussiaSpecProvider().snils()
    assert (len(result) == 11)


# Generated at 2022-06-12 01:14:45.419512
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider"""
    res = RussiaSpecProvider(seed=42).snils()
    assert res == '41917492600'

# Generated at 2022-06-12 01:14:55.238904
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test a method snils of class RussiaSpecProvider."""
    snils = RussiaSpecProvider().snils()
    assert len(snils) == 11 and snils.isdigit()


# Generated at 2022-06-12 01:14:59.448022
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():

    # Check an empty string
    assert len(RussiaSpecProvider().snils()) == 11

    # Check that the first digit is not 0
    assert int(RussiaSpecProvider().snils()[0]) != 0

    # Check that the result is a string of digits
    assert RussiaSpecProvider.snils().isdigit()

    # Check that the result is a string of digits
    assert RussiaSpecProvider.inn().isdigit()

    # Check that the result is a string of digits
    assert RussiaSpecProvider.ogrn().isdigit()

    # Check that the result is a string of digits
    assert RussiaSpecProvider.kpp().isdigit()

    # Check that the result is a string of digits
    assert RussiaSpecProvider.bic().isdigit()

    # Generate 10 SNILSes

# Generated at 2022-06-12 01:15:02.703041
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for the method snils of class RussiaSpecProvider."""
    r = RussiaSpecProvider(seed=0)
    assert r.snils() == '41917492600'

# Generated at 2022-06-12 01:15:12.453135
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    for number in range(1,101):
        snils = RussiaSpecProvider().snils()
        s = [int(i) for i in str(snils)]
        w = [9, 8, 7, 6, 5, 4, 3, 2, 1]
        a = 0
        for i in range(9):
            a += s[i] * w[i]
        if a < 100:
            a += 0
        elif a > 100:
            a = a % 101
            if a == 100:
                a += 0

        if (a != s[9]) or (a != s[9]):
            print("Error! snils is ",snils)

# Generated at 2022-06-12 01:15:15.771388
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test for method RussiaSpecProvider.snils."""
    russ = RussiaSpecProvider()
    print(russ.snils())
    return russ.snils()

# Generated at 2022-06-12 01:15:18.313149
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    data = RussiaSpecProvider()
    assert isinstance(data.snils(), str)
    assert len(data.snils()) == 11



# Generated at 2022-06-12 01:15:26.516216
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    def test_RussianSpecProvider_snils():
        """
        Testing snils method of class RussiaSpecProvider
        """
        random.seed(1)
        rsp = RussiaSpecProvider()
        snils1 = rsp.snils()
        # print(snils1)
        assert snils1 == '45111401300'
        snils2 = rsp.snils()
        # print(snils2)
        assert snils2 == '46200579000'
        random.seed(1)
        snils1_new = rsp.snils()
        # print(snils1_new)
        assert snils1 == snils1_new

# Generated at 2022-06-12 01:15:28.575583
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rp = RussiaSpecProvider()
    snils = rp.snils()


# Generated at 2022-06-12 01:15:36.491821
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    data_provider = RussiaSpecProvider(seed=None)

    for i in range(0, 100):
        org_snils = data_provider.snils()

        control_codes = []
        snils_codes = org_snils.split()
        for i in range(9, 0, -1):
            control_codes.append(int(snils_codes[9 - i]) * i)

        control_code = sum(control_codes)

        assert control_code in (100, 101)


# Generated at 2022-06-12 01:15:39.151968
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert snils.isdigit()
    assert len(snils) == 11


# Generated at 2022-06-12 01:15:56.958423
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    for _ in range(100):
        print(provider.snils())


# Generated at 2022-06-12 01:15:59.211883
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider(seed=5716805199)
    assert r.snils() == '5716805199'


# Generated at 2022-06-12 01:16:02.984674
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()

    snils = provider.snils()
    assert type(snils) == str
    assert len(snils) == 11

    assert provider.snils() != provider.snils()


# Generated at 2022-06-12 01:16:04.643585
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    assert r.snils() != r.snils()


# Generated at 2022-06-12 01:16:12.117204
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Check that snils is generated correctly.

    Here is a test for method snils
    from RussiaSpecProvider class.

    """
    russia = RussiaSpecProvider()
    assert len(russia.snils()) == 11
    assert russia.snils()[9] == russia.snils()[10]


# Generated at 2022-06-12 01:16:13.915285
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    a = r.snils()
    assert 10019982600 <= int(a) <= 99199999999
    assert len(a) == 11

# Generated at 2022-06-12 01:16:16.553917
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test method snils of class RussiaSpecProvider"""
    import doctest
    doctest.testmod(RussiaSpecProvider.snils)


# Generated at 2022-06-12 01:16:19.758717
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    assert provider.snils() == '14444444440'
    assert provider.snils() != '14444444441'

# Generated at 2022-06-12 01:16:23.646599
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis import Person
    ru = Person('ru')
    snils = ru.snils()
    print(snils)
    assert len(snils) == 11

# Generated at 2022-06-12 01:16:25.900106
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    print(snils)
    assert len(str(snils)) == 11


# Generated at 2022-06-12 01:17:01.478936
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    from mimesis.providers.person import Person

    russian = Person('ru')
    russian.snils()
    russian.snils()
    russian.snils()
    russian.snils()
    russian.snils()


# Generated at 2022-06-12 01:17:05.735785
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    ru = RussiaSpecProvider()
    snils = ru.snils()
    print(snils)
    assert isinstance(snils, int)
    assert len(str(snils)) == 11


# Generated at 2022-06-12 01:17:08.312335
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    snils = RussiaSpecProvider().snils()
    # 5 digits is used as a control code
    assert len(snils) == 11
    assert snils[-2:] != '00'


# Generated at 2022-06-12 01:17:09.794402
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider().snils() == '41917492600'

# Generated at 2022-06-12 01:17:15.742126
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    import unittest
    from mimesis.builtins import RussiaSpecProvider
    class TestRussiaSpecProvider(unittest.TestCase):
        def setUp(self):
            self.provider = RussiaSpecProvider()

        def test_snils(self):
            result = self.provider.snils()
            self.assertNotEqual(result, None)
            for i in result: #Verify that all digits are there
                self.assertTrue(i.isnumeric())
            self.assertEqual(len(result), 11)
    unittest.main()


# Generated at 2022-06-12 01:17:18.177943
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis import RussiaSpecProvider
    russian_provider = RussiaSpecProvider()
    assert russian_provider.snils()


# Generated at 2022-06-12 01:17:26.729395
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils:
    test 100 times, check if snils is valid
    """
    import re
    from mimesis.numbers import Number

    num = Number('ru')
    rsp = RussiaSpecProvider(seed=num.random_int(min=555, max=999))

    for _ in range(100):
        snils = rsp.snils()
        assert re.match(r'^\d{3}-\d{3}-\d{3}\s\d{2}$',
                        snils) or re.match(r'^\d{11}$', snils)

# Generated at 2022-06-12 01:17:28.772626
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert snils[:3] in ['419', '569', '641', '764', '794', '828', '928']
    assert ' ' not in snils
    assert snils[9] != snils[10]



# Generated at 2022-06-12 01:17:30.815424
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rus = RussiaSpecProvider()
    assert rus.snils() not in ('23011750533', '31120031828', '19876952600')

# Generated at 2022-06-12 01:17:32.385206
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis import RussiaSpecProvider
    r = RussiaSpecProvider()
    assert len(r.snils()) == 11


# Generated at 2022-06-12 01:18:47.431610
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    fake = RussiaSpecProvider()
    for _ in range(0, 10):
        result = fake.snils()
        assert len(result) == 11


# Generated at 2022-06-12 01:18:49.835503
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Testing method snils of class RussiaSpecProvider.

    Parameters
    ----------
    None

    Returns
    -------
    None
    """
    provider = RussiaSpecProvider()
    assert len(provider.snils()) == 11

# Generated at 2022-06-12 01:18:51.230974
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider().snils() == '28856323300'


# Generated at 2022-06-12 01:18:55.370744
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider(seed=4444)
    result = provider.snils()
    assert result == '41917492600'



# Generated at 2022-06-12 01:18:57.289441
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider().snils().isdigit() and len(str(RussiaSpecProvider().snils())) == 11



# Generated at 2022-06-12 01:19:08.775197
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Run the test 100 times
    for _ in range(100):
        # Randomize seed
        seed = random.randint(100, 1000)
        russian_provider = RussiaSpecProvider(seed=seed)
        # Generate random snils
        snils_1 = russian_provider.snils()
        # Break snils from first test and make wrong check-digit on the end of snils
        snils_1 = snils_1[:-1] + str(int(snils_1[-1]) + 1)
        # Run second test with the same seed
        russian_provider = RussiaSpecProvider(seed=seed)
        snils_2 = russian_provider.snils()
        # Check if second generated snils is not broken and equal to first
        assert snils_1 == snils_2

# Generated at 2022-06-12 01:19:12.337666
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russiaspp = RussiaSpecProvider(seed=123)
    assert russiaspp.snils() == '41917492600'


# Generated at 2022-06-12 01:19:17.003014
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    instance = RussiaSpecProvider()
    snils = instance.snils()
    assert snils.isdigit(), 'SNILS must be only numbers'
    assert len(snils) == 11, 'SNILS must be 11 digits'
    # Unit test for method inn of class RussiaSpecProvider


# Generated at 2022-06-12 01:19:19.250324
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert int(snils) <= 10000000000

# Generated at 2022-06-12 01:19:22.117312
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    for _ in range(10):
        snils = RussiaSpecProvider().snils()
        assert len(snils) == 11

# Generated at 2022-06-12 01:22:38.393402
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider"""
    from mimesis.providers import RussiaSpecProvider as RSP
    # Create an instance of class RussiaSpecProvider
    snils_provider = RSP()
    # Get snils
    snils = snils_provider.snils()
    # Check is it a string
    assert isinstance(snils, str)
    # Check is it not empty
    assert snils
    # Check length
    assert len(snils) == 11


# Generated at 2022-06-12 01:22:40.730862
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider(seed=0)
    assert provider.snils() == '41917492600'
