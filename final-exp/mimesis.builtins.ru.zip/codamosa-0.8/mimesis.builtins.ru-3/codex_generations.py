

# Generated at 2022-06-12 01:13:56.754227
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from string import digits
    rus = RussiaSpecProvider()
    for _ in range(20):
        snils = rus.snils()
        snils_str = str(snils)
        assert len(snils_str) == 11
        for sn in snils_str:
            assert sn in digits


# Generated at 2022-06-12 01:13:59.728355
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils[:3] != '000'



# Generated at 2022-06-12 01:14:02.231278
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    t = RussiaSpecProvider()
    snils = t.snils()
    assert len(snils) == 11
    assert snils.isdigit()

# Generated at 2022-06-12 01:14:05.454538
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    instance = 'RussiaSpecProvider'
    assert snils(instance) == '41917492600'


# Generated at 2022-06-12 01:14:09.392705
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    start = 1000000000
    end = 9999999999
    for i in range(1, 200000):
        assert start <= int(provider.snils()) <= end

# Generated at 2022-06-12 01:14:12.302931
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    import random
    rand = random.Random()
    rand.seed(1)
    provider = RussiaSpecProvider(seed=rand)

    snils = provider.snils()
    assert snils == '41917492600'



# Generated at 2022-06-12 01:14:15.307744
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test for RussiaSpecProvider.snils().

    :return: True, if the generation was successful.
    :rtype: bool
    """
    rs = RussiaSpecProvider()
    snils = rs.snils()
    print(snils)
    if not snils:
        return False
    return True

# Generated at 2022-06-12 01:14:16.821366
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()
    assert len(rsp.snils()) == 11


# Generated at 2022-06-12 01:14:22.950985
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    result = provider.snils()
    with open('snils.txt', 'a+') as f:
        for i in range(0, 10):
            # This is the method snils and generate 10 SNILS
            result = provider.snils()
            f.write(result+'\n')
    #print(result)


# Generated at 2022-06-12 01:14:27.348836
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    random_provider = RussiaSpecProvider()
    result = []
    for i in range(1, 100):
        result.append(random_provider.snils())
    print(result)
    assert result is not None

# Generated at 2022-06-12 01:14:38.625509
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    s = RussiaSpecProvider()
    assert s.snils()[0:3] > '000'



# Generated at 2022-06-12 01:14:40.882138
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    p = RussiaSpecProvider()
    res = p.snils()
    assert len(res) == 11 and res.isdigit()



# Generated at 2022-06-12 01:14:45.542736
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.person.russia import RussiaSpecProvider
    russiaspecprovider = RussiaSpecProvider()
    temp = russiaspecprovider.snils()
    if len(temp) == 11:
        print(temp)
    else:
        print('test_RussiaSpecProvider_snils() test failed')


# Generated at 2022-06-12 01:14:49.218451
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers import RussiaSpecProvider
    rsp = RussiaSpecProvider()
    assert len(rsp.snils()) == 11
    assert rsp.snils().isdigit()



# Generated at 2022-06-12 01:14:55.594965
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    list_1 = list()
    for i in range(0, 1000):
        list_1.append(provider.snils())
    # if repeatability == True, then we don't increase the number of unique numbers
    repeatability = len(set(list_1)) == len(list_1)
    assert repeatability == True


# Generated at 2022-06-12 01:14:57.625576
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()
    print(rsp.snils())
    assert len(rsp.snils()) == 11


# Generated at 2022-06-12 01:15:02.662581
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rus_provider = RussiaSpecProvider()
    snils = rus_provider.snils()
    last_two_digits = snils[8:]
    control_flag = int(last_two_digits)/10
    assert control_flag in [0,2,4,6,8,9]


# Generated at 2022-06-12 01:15:09.910166
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():

    """This is a unit test for snils method of class RussiaSpecProvider."""
    from mimesis.providers.person.ru import RussiaSpecProvider

    rus = RussiaSpecProvider()
    n = rus.snils()
    assert len(n) == 11
    assert n[:9].isdecimal()
    assert n[9:].isdecimal()
    assert n != '000-000-000'
    assert n != '000-000-000 00'


# Generated at 2022-06-12 01:15:12.278195
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    s = r.snils()
    assert(len(s) == 11)


# Generated at 2022-06-12 01:15:15.182312
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider().snils() == '41917492600' or RussiaSpecProvider().snils() == '86319845900'

# Generated at 2022-06-12 01:15:23.997561
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    for _ in range(0, 1024):
        rs = RussiaSpecProvider()
        snils = rs.snils()
        print(snils)


# Generated at 2022-06-12 01:15:26.441336
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    ru_provider = RussiaSpecProvider()
    assert ru_provider.snils() in ['54834943900', '85726953600', '69971559100']



# Generated at 2022-06-12 01:15:38.316718
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Tests that data generated by RussianProvider() is a valid snils
    """
    russian_provider = RussiaSpecProvider()

    # Generate snils
    snils = russian_provider.snils()

    # Check the length of snils
    assert(len(snils) == 11)

    # Conversion snils to list
    snils = list(snils)

    def control_sum(nums: list, t: str) -> int:
        digits_dict = {
            'n2': [7, 2, 4, 10, 3, 5, 9, 4, 6, 8],
            'n1': [3, 7, 2, 4, 10, 3, 5, 9, 4, 6, 8],
        }
        number = 0
        digits = digits_dict[t]

# Generated at 2022-06-12 01:15:44.923685
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.schema import Field
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.identification import IdentificationService

    # Можно добавить в русскую локаль функцию интернационализации
    # для слова "паспорт"
    person = Person('ru')


# Generated at 2022-06-12 01:15:47.734296
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis import RussiaSpecProvider
    provider = RussiaSpecProvider()
    assert provider.snils() == '41917492600'


# Generated at 2022-06-12 01:15:52.602421
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    seed = 11
    rsp = RussiaSpecProvider(seed)
    snils = rsp.snils()
    assert snils == '41917492600'


# Generated at 2022-06-12 01:15:55.266672
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    snilsDataBase = '41917492600'
    snilsTest = RussiaSpecProvider()
    assert snilsTest.snils() == snilsDataBase


# Generated at 2022-06-12 01:15:56.662021
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider().snils() != ''

# Generated at 2022-06-12 01:15:58.638047
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    snils = RussiaSpecProvider().snils()
    assert snils.isdigit()


# Generated at 2022-06-12 01:16:03.106532
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Example: 41917492600
    snils = RussiaSpecProvider().snils()
    assert type(snils) == str
    assert len(snils) == 11
    assert int(snils[9:]) == int(snils[0:9]) % 101
    # Clean up
    del snils

# Generated at 2022-06-12 01:16:18.382736
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider().snils().__class__ == str
    

# Generated at 2022-06-12 01:16:21.343406
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.russia import RussiaSpecProvider
    r = RussiaSpecProvider()
    snils = r.snils()
    print(snils)


# Generated at 2022-06-12 01:16:26.138744
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider"""
    for i in range(0, 50):
        seed = i
        snils = RussiaSpecProvider(seed=seed).snils()
        assert len(snils) == 11
        assert RussiaSpecProvider(seed=seed).snils() == snils



# Generated at 2022-06-12 01:16:39.294777
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.rus import RussiaSpecProvider
    from mimesis.enums import Gender
    russp = RussiaSpecProvider(seed=42)
    assert russp.snils() == '41917492600'
    assert russp.inn() == '664129194692'
    assert russp.ogrn() == '4715113303725'
    assert russp.bic() == '044025575'
    assert russp.kpp() == '560058652'
    assert russp.patronymic(Gender.FEMALE) == 'Алексеевна'
    assert russp.patronymic(Gender.MALE) == 'Петрович'
    assert russp.patronym

# Generated at 2022-06-12 01:16:41.746766
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11


# Generated at 2022-06-12 01:16:46.398412
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    import re

    snils = ['41917492600', '42321846600', '22271850575', '33349195877', '99989552510']
    a = RussiaSpecProvider()
    assert a.snils() in snils
    assert re.search('^\d{11}$', a.snils()) is not None


# Generated at 2022-06-12 01:16:56.204791
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider"""
    from mimesis.enums import Gender
    from mimesis.schema import Field
    from mimesis.providers.address.airport import AirportProvider
    from mimesis.providers.address.china import ChinaSpecProvider
    from mimesis.providers.address.rus import RussiaSpecProvider
    from mimesis.providers.code import CodeProvider
    from mimesis.providers.company import CompanyProvider
    from mimesis.providers.datetime import DatetimeProvider
    from mimesis.providers.file import FileProvider
    from mimesis.providers.geo import GeoProvider
    from mimesis.providers.internet import InternetProvider
    from mimesis.providers.number import NumberProvider

# Generated at 2022-06-12 01:16:58.851133
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-12 01:17:02.969677
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()
    for i in range(1, 10):
        snils_test = '41917492600'
        if rsp.snils() == snils_test:
            print('snils_test is passed')
            break
    else:
        print('snils_test is failed')


# Generated at 2022-06-12 01:17:04.086287
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    assert len(provider.snils()) == 11


# Generated at 2022-06-12 01:17:38.432391
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Check structure of snils."""
    data = ['41917492600']
    assert RussiaSpecProvider().snils() in data

# Generated at 2022-06-12 01:17:39.872406
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
  provider = RussiaSpecProvider()

  assert provider.snils() is not None


# Generated at 2022-06-12 01:17:43.661490
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    messages = [
        '41917492600'
    ]
    for message in messages:
        assert RussiaSpecProvider().snils() == message


# Generated at 2022-06-12 01:17:53.738469
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.person import Person
    from mimesis.enums import Gender

    rsp = RussiaSpecProvider()
    person = Person('ru')
    for gender in (Gender.MALE, Gender.FEMALE):
        if gender is Gender.MALE:
            assert all([person.gender, person.gender.lower() == 'мужской'])
        else:
            assert all([person.gender, person.gender.lower() == 'женский'])

        person.gender = gender
        patronymic = rsp.patronymic(gender)
        assert all([patronymic, isinstance(patronymic, str)])

    sentence = rsp.generate_sentence()

# Generated at 2022-06-12 01:18:00.115415
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    k = RussiaSpecProvider()
    assert k.snils()
    assert k.snils(locale='ru')
    assert not k.snils(locale='en')
    assert k.snils(seed=17 ) == '61940897900'
    assert k.snils(locale='ru',seed=17 ) == '61940897900'
    
    

# Generated at 2022-06-12 01:18:02.627149
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    snils = RussiaSpecProvider().snils()
    assert snils == '41917492600'

# Generated at 2022-06-12 01:18:07.688753
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Generate snils.
    snils = RussiaSpecProvider().snils()
    # Check correct length.
    assert len(snils) == 11
    # Check that snils begins with 4
    assert snils.startswith('4')
    # Check that snils ends with 0.
    assert snils.endswith('0')

# Generated at 2022-06-12 01:18:14.239318
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    control_code = int(snils) % 101 % 100
    if control_code == 100:
        control_code = 0
    assert snils.endswith(str(control_code))



# Generated at 2022-06-12 01:18:17.259322
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    a = RussiaSpecProvider()
    assert len(a.snils()) == 11


# Generated at 2022-06-12 01:18:18.592834
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.enums import Gender
    from mimesis.providers.ru import RussiaSpecProvider
    provider = RussiaSpecProvider()
    for i in range(100):
        assert len(provider.snils()) == 11


# Generated at 2022-06-12 01:19:23.028223
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russiaProvider = RussiaSpecProvider()
    snils = russiaProvider.snils()
    assert len(snils) == 11
    assert str.isdigit(snils) == True


# Generated at 2022-06-12 01:19:24.788129
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    mock = RussiaSpecProvider()

    res = mock.snils()
    assert len(res)==11


# Generated at 2022-06-12 01:19:26.634809
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    sp = RussiaSpecProvider()
    assert len(sp.snils()) == 11
    assert sp.snils() != sp.snils()


# Generated at 2022-06-12 01:19:27.767767
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
  assert RussiaSpecProvider().snils() == '41917492600'


# Generated at 2022-06-12 01:19:34.335462
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.builtins import RussiaSpecProvider
    provider = RussiaSpecProvider()

    snils_1 = provider.snils()
    snils_2 = provider.snils()

    assert len(snils_1) == 11
    assert snils_1 == '72891021400'
    assert snils_1 != snils_2



# Generated at 2022-06-12 01:19:38.642113
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Tests for method snils of class RussiaSpecProvider"""
    from mimesis.providers.russia import RussiaSpecProvider
    provider = RussiaSpecProvider()
    snils = provider.snils()

    assert snils != ""


# Generated at 2022-06-12 01:19:40.027962
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    instance = RussiaSpecProvider()
    snils = instance.snils()
    assert snils == instance.snils()
    assert len(snils) == 11
    assert snils.isdigit()



# Generated at 2022-06-12 01:19:45.953588
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # BOM=b'\xef\xbb\xbf'
    # SpecData.py
    # -*- coding: utf-8 -*-

    """Specific data provider for Russia (ru)."""

    from mimesis.builtins.base import BaseSpecProvider
    from mimesis.enums import Gender
    from mimesis.typing import Seed

    __all__ = ['RussiaSpecProvider']

    class RussiaSpecProvider(BaseSpecProvider):
        """Class that provides special data for Russia (ru)."""

        def __init__(self, seed: Seed = None):
            """Initialize attributes."""
            super().__init__(locale='ru', seed=seed)
            self._pull(self._datafile)

        class Meta:
            """The name of the provider."""


# Generated at 2022-06-12 01:19:52.542511
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test the method snils of class RussiaSpecProvider.
    """
    from mimesis.providers.person.russia import RussiaSpecProvider
    # Prepare test data
    control_code = 0
    code = "5" * 9
    snils = code + '{:02}'.format(control_code)
    provider = RussiaSpecProvider()

    # Do test
    generated_snils = provider.snils()

    # Check results
    assert generated_snils == snils

# Generated at 2022-06-12 01:19:54.751827
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.snils import snils_provider
    rnd = RussiaSpecProvider(11)
    for i in range(10):
        assert rnd.snils() == snils_provider(11).snils()

# Generated at 2022-06-12 01:22:50.154187
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    control_code = 0
    for i in range(0, 1000):
        generated_snils = RussiaSpecProvider().snils()
        nums = []
        for j in range(0, 9):
            nums.append(int(generated_snils[j]))
        generated_control_code = int(generated_snils[9] + generated_snils[10])
        for i in range(0, 9):
            control_code += nums[i] * (9 - i)
        if control_code % 101 != generated_control_code:
            print(str(control_code) + " != " + str(generated_control_code))
            assert False
        control_code = 0

# Generated at 2022-06-12 01:22:53.368606
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test function snils of class RussiaSpecProvider."""
    ru = RussiaSpecProvider()
    # Test the type of snils
    assert type(ru.snils()).__name__ == 'str', "The snils is not a string."
    # Test the length of snils
    assert (len(ru.snils()) == 11), "The snils has wrong length."


# Generated at 2022-06-12 01:22:54.377241
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    snils = RussiaSpecProvider().snils()
    assert len(snils) == 11

# Generated at 2022-06-12 01:22:56.585560
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.person.russia_provider import RussiaSpecProvider
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    print(snils)
    assert len(snils) == 11

# Generated at 2022-06-12 01:22:58.745967
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    ru_provider = RussiaSpecProvider()

    # Generate snils with special algorithm.
    assert ru_provider.snils() != ru_provider.snils()
    # Generate snils with special algorithm.
    assert ru_provider.snils() != ru_provider.snils()


# Generated at 2022-06-12 01:23:02.586937
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider"""
    obj = RussiaSpecProvider()
    snils = obj.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-12 01:23:03.597606
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    assert len(provider.snils()) == 11


# Generated at 2022-06-12 01:23:08.677047
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.enums import Gender
    from mimesis.builtins import RussiaSpecProvider
    rusp = RussiaSpecProvider()
    snils = rusp.snils()
    print('snils =', snils)
    print('len(snils) =', len(snils))


# Generated at 2022-06-12 01:23:10.660832
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    assert len(provider.snils()) == 11



# Generated at 2022-06-12 01:23:12.440816
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider().snils() == '41917492600'