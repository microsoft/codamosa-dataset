

# Generated at 2022-06-12 01:13:58.636620
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert isinstance(snils, str)



# Generated at 2022-06-12 01:14:00.536758
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    assert provider.snils() == '41917492600'

# Generated at 2022-06-12 01:14:03.612185
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    snils = RussiaSpecProvider().snils()
    import re
    assert re.match(r'\d{11}', snils)



# Generated at 2022-06-12 01:14:06.345353
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rus = RussiaSpecProvider()
    assert len(rus.snils()) == 11

# Generated at 2022-06-12 01:14:09.110360
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider(seed=None)
    response = provider.snils()

    assert len(response) == 11


# Generated at 2022-06-12 01:14:11.471891
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    s = RussiaSpecProvider()

    for i in range(0,5):
        assert s.snils() == s.snils()

# Generated at 2022-06-12 01:14:19.726462
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    assert len(provider.snils()) == 11
    assert provider.snils() != '00000000000'
    assert provider.snils() != '11111111111'
    assert provider.snils() != '22222222222'
    assert provider.snils() != '33333333333'
    assert provider.snils() != '44444444444'
    assert provider.snils() != '55555555555'
    assert provider.snils() != '66666666666'
    assert provider.snils() != '77777777777'
    assert provider.snils() != '88888888888'
    assert provider.snils() != '99999999999'



# Generated at 2022-06-12 01:14:23.734274
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test for method snils of class RussiaSpecProvider."""
    r = RussiaSpecProvider()
    snils = r.snils()
    assert len(snils) == 11
    assert int(snils) % 101 == 0


# Generated at 2022-06-12 01:14:26.176100
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.person.russia import RussiaSpecProvider as rsp

    print(rsp().snils())


# Generated at 2022-06-12 01:14:29.010776
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider(seed=42)
    snils = r.snils()
    print('snils:', snils)


# Generated at 2022-06-12 01:14:44.102495
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    import pytest
    spec = RussiaSpecProvider()
    snils = spec.snils()

# Generated at 2022-06-12 01:14:56.211338
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    class RussiaSpecProvider_test(RussiaSpecProvider):
        def __init__(self, seed: Seed = None):
            super().__init__(seed=seed)

        def snils(self) -> str:
            numbers = []
            control_codes = []

            for i in range(0, 9):
                numbers.append(self.random.randint(0, 9))

            for i in range(9, 0, -1):
                control_codes.append(numbers[9 - i] * i)

            control_code = sum(control_codes)
            code = ''.join(str(number) for number in numbers)

            if control_code in (100, 101):
                snils = code + '00'
            else:
                snils = code + str(control_code)

            return snils


# Generated at 2022-06-12 01:14:57.687132
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
  assert RussiaSpecProvider().snils == '41917492600'

# Generated at 2022-06-12 01:15:01.674643
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """ Testing RussiaSpecProvider.snils() """
    # Init
    rus = RussiaSpecProvider()
    # Testing
    assert len(rus.snils()) == 11
    assert rus.snils() != rus.snils()


# Generated at 2022-06-12 01:15:03.237442
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    s = RussiaSpecProvider()
    p = s.snils()
    print(p)


# Generated at 2022-06-12 01:15:05.885413
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    result = provider.snils()
    print(result)
    assert len(result) == 11



# Generated at 2022-06-12 01:15:11.820637
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis import RussiaSpecProvider
    from re import match
    provider = RussiaSpecProvider()

    regex_snils = '^[0-9]{3}-[0-9]{3}-[0-9]{3} [0-9]{2}$'
    assert match(regex_snils, provider.snils())


# Generated at 2022-06-12 01:15:16.548530
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider"""
    rsp = RussiaSpecProvider()
    assert rsp.snils() != '00000000000', \
        "snils() should not return '00000000000'"
    assert rsp.snils() != '99999999999', \
        "snils() should not return '99999999999'"



# Generated at 2022-06-12 01:15:20.207985
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.generic import Generic
    from mimesis.providers.person import Person
    provider = RussiaSpecProvider(Generic().seed)

    snils = provider.snils()
    assert snils == Person().snils()

# Generated at 2022-06-12 01:15:23.011937
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Initialization object
    provider = RussiaSpecProvider()
    # Output result
    for _ in range(0,10):
        print(provider.snils())


# Generated at 2022-06-12 01:15:39.686044
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    assert provider.snils() == provider.snils()


# Generated at 2022-06-12 01:15:51.070320
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rus = RussiaSpecProvider()
    snils = rus.snils()
    snils_list = [int(x) for x in str(snils)]
    control_codes = []
    for i in range(9, 0, -1):
        control_codes.append(snils_list[9 - i] * i)
    control_code = sum(control_codes)
    if control_code in (100, 101):
        assert snils[9] == '0' and snils[10] == '0'
        print(snils)
        print(snils_list)
        print(control_codes)
        print(control_code)
        print('snils = {}'.format(snils))
        print('snils_list = {}'.format(snils_list))

# Generated at 2022-06-12 01:15:56.743311
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert snils == '12345678911'
    snils = provider.snils()
    assert snils == '12345678900'
    snils = provider.snils()
    assert snils == '12345678901'
    
    

# Generated at 2022-06-12 01:15:58.706594
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_sp = RussiaSpecProvider()
    snils = russia_sp.snils()
    print(snils)

# Generated at 2022-06-12 01:16:02.247394
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    import re

    x = RussiaSpecProvider()
    snils = x.snils()
    assert re.match(r'\d{3}-\d{3}-\d{3}\s\d{2}', snils)

# Generated at 2022-06-12 01:16:06.662414
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis import Random
    from mimesis.exceptions import NonEnumerableError
    r = Random()
    r.set_seed(1234)
    r = RussiaSpecProvider(seed=r.create_seed(None))

    snils = r.snils()
    assert snils == '53453153400'
    for _ in range(2):
        assert r.snils() != snils

# Generated at 2022-06-12 01:16:15.888699
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.generators.numbers import Number

    loc_provider = RussiaSpecProvider()

    for _ in range(100):
        snils = loc_provider.snils()

        assert len(snils) == 11
        assert snils.isdigit()

        numbers = list(map(int, list(snils)))

        # Проверка контрольной суммы
        def control_sum(nums: list, t: str) -> int:
            digits_dict = {
                'n2': [7, 2, 4, 10, 3, 5, 9, 4, 6, 8],
                'n1': [3, 7, 2, 4, 10, 3, 5, 9, 4, 6, 8],
            }
            number

# Generated at 2022-06-12 01:16:18.628198
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    assert str(provider.snils()) == str('41917492600')
    pass


# Generated at 2022-06-12 01:16:28.195790
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Проверка правильности формирования номера
    provider = RussiaSpecProvider()
    sample1 = provider.snils()
    # Проверка на длину
    assert len(sample1) == 11
    # Проверка на первые два цифры, которые всегда не меньше 42
    assert int(sample1[0:2]) >= 42
    # Проверка на наличие кон

# Generated at 2022-06-12 01:16:32.780508
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    if len(snils) > 11:
        assert snils == '41917492600'
    else:
        assert snils == '4191749260'

# Generated at 2022-06-12 01:17:07.105238
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    print('Unit test for method snils of class RussiaSpecProvider')
    print('')
    
    # Generate a random number of SNILS
    print('Generate a random number of SNILS')
    R = RussiaSpecProvider()
    r = R.snils()
    print(r)


# Generated at 2022-06-12 01:17:08.536535
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Checking snils
    snils = RussiaSpecProvider().snils()
    assert snils == '41917492600'

# Generated at 2022-06-12 01:17:16.386040
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rus = RussiaSpecProvider()
    snils = rus.snils()

    # Проверяем что в строке меньше или равно 11 символов

# Generated at 2022-06-12 01:17:18.799106
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    assert RussiaSpecProvider().snils() == '15981088500'

# Generated at 2022-06-12 01:17:21.551087
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    i0 = RussiaSpecProvider().snils()
    i1 = RussiaSpecProvider().snils()
    assert i0 != i1


# Generated at 2022-06-12 01:17:24.062861
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    assert r.snils() != r.snils()

# Generated at 2022-06-12 01:17:25.958861
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    geo = RussiaSpecProvider()
    geo.random.seed(1)
    assert geo.snils() == '41917492600'

# Generated at 2022-06-12 01:17:35.245062
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Create instance of class RussiaSpecProvider
    spec_provider = RussiaSpecProvider()

    # Collect data
    data = [spec_provider.snils() for x in range(0, 100)]

    # Create sets with snils and codes
    sets = []
    codes = []
    for i in data:
        sets.append(i[0:3])
        codes.append(i[9:11])

    set_numbers = list(set(sets))
    set_codes = list(set(codes))

    # Counting how many times code appeared
    for i in set_codes:
        count = codes.count(i)

        if count > 1:
            print (f'\nCode {i} is not unique!\nIt was used {count} times.\n')

# Generated at 2022-06-12 01:17:38.716059
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()
    assert len(rsp.snils()) == 11
    assert rsp.snils().isdigit()
    # assert rsp.snils() == str(41917492600)


# Generated at 2022-06-12 01:17:41.646414
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isnumeric()


# Generated at 2022-06-12 01:18:56.152237
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    ru = RussiaSpecProvider()
    for i in range(10):
        snils = ru.snils()
        print(snils)


# Generated at 2022-06-12 01:18:57.900325
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    seed = 'gXRACb'
    p = RussiaSpecProvider(seed)
    result = p.snils()
    assert result == '41917492600'

# Generated at 2022-06-12 01:19:02.048089
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider(seed=123456789)
    assert provider.snils() == "44444444444"


# Generated at 2022-06-12 01:19:03.815419
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11

# Generated at 2022-06-12 01:19:10.622915
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.base import BaseSpecProvider
    class Mock(BaseSpecProvider):
        def __init__(self):
            super().__init__(seed=None)
        def randint(self, a, b):
            return b

    class Mock2(BaseSpecProvider):
        def __init__(self):
            super().__init__(seed=None)
        def randint(self, a, b):
            return a

    class Mock3(BaseSpecProvider):
        def __init__(self):
            super().__init__(seed=None)
        def randint(self, a, b):
            return 1

    class Mock4(BaseSpecProvider):
        def __init__(self):
            super().__init__(seed=None)

# Generated at 2022-06-12 01:19:14.297210
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider().snils() == '41917492600'
    assert RussiaSpecProvider().snils() != '41917492601'


# Generated at 2022-06-12 01:19:16.684063
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    a = RussiaSpecProvider()
    print(a.snils())
    assert len(a.snils()) == 11


# Generated at 2022-06-12 01:19:18.228150
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    snils = '94012975512'
    provider = RussiaSpecProvider()
    assert provider.snils() == snils


# Generated at 2022-06-12 01:19:21.735223
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test RussiaSpecProvider_snils of class RussiaSpecProvider"""
    assert isinstance(RussiaSpecProvider().snils(), str)


# Generated at 2022-06-12 01:19:24.060724
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    spec_ru = RussiaSpecProvider()
    result = spec_ru.snils()
    assert len(result) == 11

# Generated at 2022-06-12 01:22:34.730291
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    S = [r.snils() for x in range(1000)]
    assert len(set(S)) == 1000

# Generated at 2022-06-12 01:22:36.216066
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # 919-171-926-00
    rsp = RussiaSpecProvider()
    print(rsp.snils())


# Generated at 2022-06-12 01:22:36.672047
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():

   pass

# Generated at 2022-06-12 01:22:39.667410
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    seed = "Hello"
    russia_generator = RussiaSpecProvider(seed)
    assert russia_generator.snils() == "90739645300"


# Generated at 2022-06-12 01:22:50.155917
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider(seed=123)
    snils = rsp.snils()
    assert snils == '74444017500'


# Generated at 2022-06-12 01:22:52.626032
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils()."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert snils.isdigit() == True
    assert len(snils) == 11


# Generated at 2022-06-12 01:22:58.897670
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test RussiaSpecProvider's method snils.

    Тест для метода snils.
    """
    # Case 1:
    reg_number = RussiaSpecProvider().snils()

    assert isinstance(reg_number, str)
    assert len(reg_number) == 11

    # Case 2:
    numbers = []
    control_codes = []
    snils = ""

    for i in range(0, 9):
        numbers.append(int(reg_number[i]))

    for i in range(9, 0, -1):
        control_codes.append(numbers[9 - i] * i)

    control_code = sum(control_codes)
    code = reg_number[:-2]


# Generated at 2022-06-12 01:23:02.117381
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """
    Function for testing snils method of RussiaSpecProvider class
    """
    provider = RussiaSpecProvider(seed=42)
    assert provider.snils() == '9614350400'

# Generated at 2022-06-12 01:23:03.737117
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russiasnils = RussiaSpecProvider()
    snils = int(russiasnils.snils())

    assert snils >= 100000000 and snils <= 999999999



# Generated at 2022-06-12 01:23:07.683701
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    assert len(rsp.snils()) == 11
