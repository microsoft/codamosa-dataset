

# Generated at 2022-06-12 01:13:58.154927
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()
    s = rsp.snils()
    assert len(s) == 11


# Generated at 2022-06-12 01:14:01.074383
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils == '41917492600'

# Generated at 2022-06-12 01:14:06.142561
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.person.ru import RussiaSpecProvider
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11


# Generated at 2022-06-12 01:14:15.191569
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Test for city with last name
    assert RussiaSpecProvider._data['snils']['last_name']['city'] == ['Петров', 'Сидоров']

    # Test for city with patronymic
    assert RussiaSpecProvider._data['snils']['patronymic']['city'] == ['Петровна', 'Сидоровна']

    # Test
    assert RussiaSpecProvider._data['snils']['first_names']['male'] == ['Алексей', 'Александр']

    # Test

# Generated at 2022-06-12 01:14:17.589396
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    random = RussiaSpecProvider()
    snils_1 = random.snils()
    snils_2 = random.snils()

    assert snils_1 != snils_2


# Generated at 2022-06-12 01:14:25.261925
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    print("===== Start testing of RussiaSpecProvider =====")
    russia_spec_provider = RussiaSpecProvider(seed=12345)
    assert russia_spec_provider.snils() == '41917492600', \
        'Error of method RussiaSpecProvider.snils'
    print("Method RussiaSpecProvider.snils - OK")
    print("===== Finish testing of RussiaSpecProvider =====")


# Generated at 2022-06-12 01:14:28.641196
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    import pytest

    RussiaSpecProvider.set_seed(1)  # For reproducible tests
    assert RussiaSpecProvider().snils() == '41917492600'



# Generated at 2022-06-12 01:14:35.776887
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Testing random generation of SNILS
    russia = RussiaSpecProvider()
    assert len(russia.snils()) == 11

    # Testing correctness of generated SNILS
    result = []
    for _ in range(1000):
        snils = russia.snils()
        assert len(snils) == 11
        control_code = snils[-2:]
        if int(control_code) in (10, 111, 100, 101):
            assert int(control_code) == 0
            result.append(1)
        else:
            if sum([int(snils[x]) * (9 - x) for x in range(9)]) % 101 == int(control_code):
                result.append(1)
    assert all(result) == 1

# Generated at 2022-06-12 01:14:46.234114
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test method.
    
    :return: None
    """
    # test for snils
    provider = RussiaSpecProvider()
    snils = provider.snils()
    value = int(snils)
    numbers = [int(i) for i in snils]
    digits_dict = {
        'n2': [7, 2, 4, 10, 3, 5, 9, 4, 6, 8],
        'n1': [3, 7, 2, 4, 10, 3, 5, 9, 4, 6, 8],
    }
    control_codes = []
    control_code = 0
    for i in range(9, 0, -1):
        control_codes.append(numbers[9 - i] * i)


# Generated at 2022-06-12 01:14:48.230378
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia = RussiaSpecProvider()
    print(russia.snils())

# Generated at 2022-06-12 01:15:10.726750
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.rus import RussiaSpecProvider
    provider = RussiaSpecProvider()
    from mimesis.enums import Gender
    sex = Gender.FEMALE
    print(provider.snils())

# Generated at 2022-06-12 01:15:12.581887
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11


# Generated at 2022-06-12 01:15:18.252364
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for the method snils.

    :return: True if test passed else False.
    """
    rsp = RussiaSpecProvider()
    test_snils = str(rsp.snils())
    print(test_snils)
    assert len(test_snils) == len(rsp.snils()) == 11



# Generated at 2022-06-12 01:15:28.834795
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
  from mimesis.enums import Gender
  from mimesis.providers.person import Person
  from mimesis.providers.russia import RussiaSpecProvider
  from mimesis.builtins.base import BaseProvider

  def test_snils_fix(self):
    data = self.create_data()
    data.update(self.random_data())
    patronymic = data.get('patronymic')
    snils = data.get('snils')
    if self.formatter.gender == self.formatter.Gender.MASCULINE:
      patronymic = 'Иванович'
    elif self.formatter.gender == self.formatter.Gender.FEMININE:
      patronymic = 'Ивановна'

# Generated at 2022-06-12 01:15:30.188847
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    assert provider.snils() == '57316805199'

# Generated at 2022-06-12 01:15:32.645834
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for RussiaSpecProvider.snils()"""
    check = RussiaSpecProvider()
    assert check.snils() == "41917492600"

# Generated at 2022-06-12 01:15:36.079063
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    assert provider.snils() == '41917492600'

# Generated at 2022-06-12 01:15:38.263280
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rus = RussiaSpecProvider()
    assert len(rus.snils()) == 11
    assert int(rus.snils()) > 1000000



# Generated at 2022-06-12 01:15:39.537685
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    for j in range(10):
        pass


# Generated at 2022-06-12 01:15:48.328076
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    data_provider = RussiaSpecProvider()
    num = data_provider.snils()
    print (num)

    def digits_sum(num):
        return sum(map(lambda x: int(x), num))

    assert(len(num) == 11)
    assert(digits_sum(num[0:9]) % 101 == int(num[9] + num[10]))


if __name__ == '__main__':
    test_RussiaSpecProvider_snils()

# Generated at 2022-06-12 01:16:29.301901
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test the method snils of class RussiaSpecProvider"""
    provider = RussiaSpecProvider()
    result = provider.snils()
    assert isinstance(result, str)
    assert len(result) == 11


# Generated at 2022-06-12 01:16:41.547670
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Check if the snils method return a correct snils."""
    from mimesis.providers.ru.russia import RussiaSpecProvider
    from mimesis.providers.ru.address import Address
    from mimesis.providers.ru.person import Person
    person = Person()
    address = Address()
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert snils is not None
    assert len(snils) == 11
    name = person.full_name(gender=Gender.MALE)
    address = address.address()
    passport = provider.series_and_number()
    assert passport is not None
    assert len(passport) >= 14
    tax_id = provider.inn()
    assert tax_id is not None
    assert len(tax_id) == 12
    assert tax

# Generated at 2022-06-12 01:16:44.486937
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """
    Test snils method of class RussiaSpecProvider.

    :return: Unit test result.
    :rtype: bool
    """

    ru = RussiaSpecProvider()
    snils = ru.snils()
    return len(snils) == 11 and snils.isdigit()


# Generated at 2022-06-12 01:16:50.090354
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test the snils method of class RussiaSpecProvider"""
    r = RussiaSpecProvider(seed=666)
    res = r.snils()
    assert res == '41917492600'


# Generated at 2022-06-12 01:16:51.792397
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    a = RussiaSpecProvider()
    assert len(a.snils()) == 11

# Generated at 2022-06-12 01:16:57.823473
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.data import RUSSIA_DATA

    rsp = RussiaSpecProvider(data=RUSSIA_DATA)
    snils = rsp.snils()
    assert len(str(snils)) == 11
    assert snils == '41917492600'

# Generated at 2022-06-12 01:17:05.446906
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    p = RussiaSpecProvider()
    #snils = p.snils()
    #print("SNILS: ", snils)
    #assert len(snils) == 11
    errors = 0
    for i in range(0,10000):
        snils = p.snils()
        numbers = []
        control_codes = []

        for i in range(0, 9):
            numbers.append(int(snils[i]))

        for i in range(9, 0, -1):
            control_codes.append(numbers[9 - i] * i)

        control_code = int(snils[9] + snils[10])

        if sum(control_codes) == control_code:
            print("OK")
        else:
            print("ERROR!")
            errors += 1

# Generated at 2022-06-12 01:17:07.494199
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.builtins import RussiaSpecProvider
    res = RussiaSpecProvider()
    data = res.snils()
    assert len(data) == 11

# Generated at 2022-06-12 01:17:09.344224
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    result = provider.snils()
    assert result


# Generated at 2022-06-12 01:17:11.831150
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    print ("Test russia_provider.py/test_RussiaSpecProvider_snils")
    r = RussiaSpecProvider()
    snils = r.snils()
    print(snils)


# Generated at 2022-06-12 01:18:50.433108
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()

    # INN and SNILS can match,
    # so we need to make sure that is not happened
    inns=[]
    snils=[]
    while True:
        inn=provider.inn()
        snil=provider.snils()
        if inn not in inns:
            inns.append(inn)
        if snil not in snils:
            snils.append(snil)
        if len(inns) != len(snils):
            continue
        if len(inns)==3 and len(snils)==3:
            break
    
    assert inn != snil

# Generated at 2022-06-12 01:18:57.057652
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    obj = RussiaSpecProvider()
    values = [
        obj.snils()
        for _ in range(1000)
    ]
    # Test length
    assert len(values) == 1000
    # Test regex
    assert all(re.match(r'([\d]{11,11})', v) for v in values)
    # Test unique
    assert len(set(values)) == 1000

# Generated at 2022-06-12 01:19:08.599617
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    ru = RussiaSpecProvider()
    # These are tests of the algorithm.
    # If you fail this tests, then the algorithm must be changed.
    tests = {
        41917492600: [0, 9, 2, 6, 9, 4, 1, 7, 9, 1, 4],
        60981730349: [9, 3, 4, 0, 3, 7, 1, 8, 9, 6, 0],
        92407908288: [8, 8, 2, 8, 9, 0, 7, 4, 9, 2, 0],
        92407908289: [9, 2, 8, 8, 9, 0, 7, 4, 9, 2, 0],
    }
    for snils, numbers in tests.items():
        assert ru.snils() == str(snils)

# Generated at 2022-06-12 01:19:15.917664
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    s = r.snils()
    assert isinstance(s, str), "Expected string"
    assert len(s) == 11, "Expected 11 symbols"
    assert s.isdigit(), "Expected only digits"
    m = RussiaSpecProvider(seed=0)
    assert m.snils() == '45250713300'



# Generated at 2022-06-12 01:19:17.556041
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11


# Generated at 2022-06-12 01:19:20.723989
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    c = RussiaSpecProvider(seed=11)
    assert c.snils() == '41917492600'



# Generated at 2022-06-12 01:19:27.422619
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test the snils method."""
    import random
    from mimesis import RussiaSpecProvider
    r = RussiaSpecProvider()
    l = []
    for i in range(10):
        l.append(r.snils())
    for j in range(len(l) - 1):
        for k in range(j + 1, len(l) - 1):
            assert l[j] != l[k], "Проверка на коллизии не пройдена"



# Generated at 2022-06-12 01:19:32.008842
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    number = '26701554072'
    provider = RussiaSpecProvider()
    for _ in range(0, 100):
        provider_number = provider.snils()
        if provider_number == number:
            break
    assert number == provider_number

# Generated at 2022-06-12 01:19:34.870687
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    object = RussiaSpecProvider(seed=None)
    for _ in range(100):
        # print(object.snils())
        object.snils()


# Generated at 2022-06-12 01:19:40.320204
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    import gc
    import cProfile
    import pstats
    #
    cProfile.run(
        'test=RussiaSpecProvider()\n'
        'print(test.snils())',
        filename='foo.stats'
    )
    p = pstats.Stats('foo.stats')
    p.strip_dirs().sort_stats(-1).print_stats()
    #
    gc.collect()

# Generated at 2022-06-12 01:21:44.555741
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.finance import Finance

    Russ = RussiaSpecProvider()
    p = Person('ru')
    a = Address('ru')
    f = Finance('ru')

    print(Russ.generate_sentence())
    print(Russ.patronymic(gender=Gender.FEMALE))
    print(Russ.passport_series())
    print(Russ.passport_number())
    print(Russ.series_and_number())
    print(Russ.snils())
    print(Russ.inn())
    print(Russ.ogrn())
    print(Russ.bic())
    print(Russ.kpp())

# Generated at 2022-06-12 01:21:55.105643
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider().snils()[-2:] == '00'
    assert RussiaSpecProvider().snils()[-2:] != '11'
    assert RussiaSpecProvider().snils()[-2:] != '22'
    assert RussiaSpecProvider().snils()[-2:] != '33'
    assert RussiaSpecProvider().snils()[-2:] != '44'
    assert RussiaSpecProvider().snils()[-2:] != '55'
    assert RussiaSpecProvider().snils()[-2:] != '66'
    assert RussiaSpecProvider().snils()[-2:] != '77'
    assert RussiaSpecProvider().snils()[-2:] != '88'
    assert RussiaSpecProvider().snils()[-2:] != '99'


# Generated at 2022-06-12 01:22:02.377761
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Проверяем выдает ли метод число
    provider = RussiaSpecProvider(seed=987654321)
    k = provider.snils()
    assert type(k) is str
    # Проверяем количество цифр в числе
    assert len(k) == 11

# Generated at 2022-06-12 01:22:05.213425
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    result = r.snils()
    print(result)
    assert type(result) is str
    assert len(result) is 11


# Generated at 2022-06-12 01:22:09.611150
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    import csv
    csv_file = open('snils.csv', "r")
    reader = csv.reader(csv_file, dialect = 'excel')
    for line in reader:
        for snils in line:
            assert snils == RussiaSpecProvider().snils()



# Generated at 2022-06-12 01:22:12.595335
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    assert len(r.snils()) == 11
    assert isinstance(r.snils(), str)



# Generated at 2022-06-12 01:22:14.988711
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.snils import snils

    provider = RussiaSpecProvider()
    for _ in range(250):
        assert snils() == provider.snils()



# Generated at 2022-06-12 01:22:18.260676
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Test 1
    p = RussiaSpecProvider()
    assert (len(p.snils())) == 11


# Generated at 2022-06-12 01:22:20.161265
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test for method snils of class RussiaSpecProvider."""
    rs = RussiaSpecProvider(seed=42)
    assert rs.snils() == '41917492600'



# Generated at 2022-06-12 01:22:23.756400
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Tests RussiaSpecProvider.snils.
    Unit test for RussiaSpecProvider.snils.
    :return:
    """
    test_provider = RussiaSpecProvider()
    snils = test_provider.snils()
    print(snils)
