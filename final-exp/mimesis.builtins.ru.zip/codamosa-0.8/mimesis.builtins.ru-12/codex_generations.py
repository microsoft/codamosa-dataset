

# Generated at 2022-06-12 01:13:59.098042
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    for i in range(0, 100):
        rsp.snils()


# Generated at 2022-06-12 01:14:01.237225
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider(seed=1234)
    # snils = rsp.snils()
    # assert snils == '41917492600' , 'snils = {}'.format(snils)

# Generated at 2022-06-12 01:14:04.421483
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    for item in range(0, 10):
        rsp = RussiaSpecProvider()
        print(rsp.snils())


# Generated at 2022-06-12 01:14:07.494306
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test snils method."""
    assert RussiaSpecProvider().snils() == '41917492600'

# Generated at 2022-06-12 01:14:11.945895
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.person.ru import RussiaSpecProvider
    provider = RussiaSpecProvider()
    snils = provider.snils()
    print(snils)
    assert len(snils) == 11
    assert snils.isdigit() is True

if __name__ == '__main__':
    test_RussiaSpecProvider_snils()

# Generated at 2022-06-12 01:14:13.398813
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis import RussiaSpecProvider
    provider = RussiaSpecProvider()
    result = provider.snils()

# Generated at 2022-06-12 01:14:16.356311
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # russiaProvider = RussiaSpecProvider()
    # assert russiaProvider.snils() == '41917492600'
    print("Test RussiaSpecProvider.snils()")
    assert True


# Generated at 2022-06-12 01:14:21.386791
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():

    provider = RussiaSpecProvider(seed=42)

    # test 1
    snils = provider.snils()
    assert snils == '17165590000'

    # test 2
    snils = provider.snils()
    assert snils == '91527492200'

# Generated at 2022-06-12 01:14:22.765474
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rus = RussiaSpecProvider()
    assert rus.snils()



# Generated at 2022-06-12 01:14:25.358484
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    assert rsp.snils()


# Generated at 2022-06-12 01:14:44.300830
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    expected_result = '41917492600'
    actual_result = RussiaSpecProvider().snils()
    assert actual_result == expected_result


# Generated at 2022-06-12 01:14:47.229039
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.person.russia import RussiaSpecProvider
    provider = RussiaSpecProvider()
    assert provider.snils() == '41917492600'

# Generated at 2022-06-12 01:14:58.909123
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis import Generic

    ru = Generic("ru")
    cnt = 0
    cmplst = [0] * 10
    # Test for 100000 random SNILS numbers
    while cnt < 100000:
        cmplst[ru.russia_provider.snils()[-1:]] += 1
        cnt += 1

    print("Нуль: ", cmplst[0])
    print("Один: ", cmplst[1])
    print("Два: ", cmplst[2])
    print("Три: ", cmplst[3])
    print("Четыре: ", cmplst[4])
    print("Пять: ", cmplst[5])

# Generated at 2022-06-12 01:15:02.167418
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russ = RussiaSpecProvider()
    snils = russ.snils()
    # TODO: Check if all values are valid
    assert snils is not None

# Generated at 2022-06-12 01:15:05.002676
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    assert provider.snils() == '41917492600'

test_RussiaSpecProvider_snils()


# Generated at 2022-06-12 01:15:06.468430
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    data = provider.snils()
    assert len(data) == 11

# Generated at 2022-06-12 01:15:09.022310
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    random.seed(21)

    assert RussiaSpecProvider().snils() == '31183105759'

# Generated at 2022-06-12 01:15:11.728383
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    print(provider.snils())

if __name__ == "__main__":
    test_RussiaSpecProvider_snils()

# Generated at 2022-06-12 01:15:14.626203
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider"""
    class_instance = RussiaSpecProvider()
    assert type(class_instance.snils()) is str
    assert len(class_instance.snils()) == 11


# Generated at 2022-06-12 01:15:20.691461
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """
    Unit test for method snils of class RussiaSpecProvider
    """
    rs = RussiaSpecProvider()
    str_snils = rs.snils()
    # Verify that the snils consists of 11 characters
    assert len(str_snils) == 11
    # Verify that the snils consists of digits
    assert str_snils.isdigit()
    # Verify that the snils is not 00000000000
    assert str_snils != '00000000000'


# Generated at 2022-06-12 01:15:59.291969
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    print('snils: {}'.format(snils))
    assert len(snils) == 11

    # Unit test for method inn of class RussiaSpecProvider

# Generated at 2022-06-12 01:16:00.893514
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    ru = RussiaSpecProvider()
    print(ru.snils())


# Generated at 2022-06-12 01:16:03.432353
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    ru_provider = RussiaSpecProvider()
    assert ru_provider.snils() == ru_provider.snils()


# Generated at 2022-06-12 01:16:06.834941
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test for method snils of class RussiaSpecProvider."""
    print(RussiaSpecProvider().snils())

    seed = RussiaSpecProvider().create_seed('123')
    print(RussiaSpecProvider(seed).snils())

    seed = RussiaSpecProvider().create_seed('123')
    print(RussiaSpecProvider(seed).snils())


# Generated at 2022-06-12 01:16:12.915347
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider"""
    # Arrange
    test = RussiaSpecProvider(seed=1)

    # Act
    snils_1 = test.snils()
    snils_2 = test.snils()

    # Assert
    assert snils_1 == '58089220027'
    assert snils_2 == '58350007410'

# Generated at 2022-06-12 01:16:24.590762
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    from mimesis import RussiaSpecProvider
    from mimesis.enums import Gender
    from mimesis.providers.base import BaseProvider

    _seed = 'mimesis.RussiaSpecProvider.test_RussiaSpecProvider_snils'
    ru = RussiaSpecProvider(seed=_seed)
    ru_base = BaseProvider(seed=_seed)

    assert ru.snils() == '41917492600'

    ru_base.random.set_state(ru.random.get_state())
    ru.random.seed(_seed)
    ru_base_snils = ru_base.text.snils()
    ru_snils = ru.snils()
    assert ru_base_snils == ru_snils

# Generated at 2022-06-12 01:16:28.775222
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test the method snils of class RussiaSpecProvider."""

    russian = RussiaSpecProvider()
    result = russian.snils()
    assert isinstance(result, str)


# Generated at 2022-06-12 01:16:30.584676
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    p = RussiaSpecProvider()
    t = p.snils()
    print(t)


# Generated at 2022-06-12 01:16:34.313507
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    len(snils)

    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-12 01:16:42.961380
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    for _ in range(0, 100):
        assert r.snils()[-2:] == r.snils()[-2:]
        assert r.snils()[:9] == r.snils()[:9]
        assert r.snils()[-2:] != r.snils()[:9]
        assert len(r.snils()) == 11
        snils = r.snils()
        if snils[-2] != '0':
            assert snils[-1] == '0'
        else:
            assert snils[-2:] == '00'

# Generated at 2022-06-12 01:18:12.265896
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Create instance
    r = RussiaSpecProvider()

    # Get SNILS
    snils = r.snils()

    # Get last 2 numbers of SNILS
    last_digits = int('{}{}'.format(snils[-2], snils[-1]))

    # Check
    assert len(snils) == 11
    assert snils[-2] != 0
    assert snils[-1] != 0
    assert last_digits > 0

# Generated at 2022-06-12 01:18:17.203365
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test is snils is valid (have 12 digits)."""
    provider = RussiaSpecProvider()
    result = provider.snils()
    assert len(result) == 12

# Generated at 2022-06-12 01:18:20.261528
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils."""
    r = RussiaSpecProvider()
    a = r.snils()
    assert str(a).isdigit() == True
    assert len(str(a)) == 11
    print('a:', a)


# Generated at 2022-06-12 01:18:23.523348
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis import RussiaSpecProvider
    p = RussiaSpecProvider(seed=123)
    assert p.snils() == '41917492600'


# Generated at 2022-06-12 01:18:25.674175
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    print(r.snils())


# Generated at 2022-06-12 01:18:33.987847
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    import pytest
    
    for _ in range(0, 10000):
        snils = RussiaSpecProvider().snils()
        assert len(str(snils)) == 11, 'The snils length must be 11'
        numbers = [int(x) for x in snils]
        control_codes = []

        for i in range(0, 9):
            control_codes.append(numbers[i] * (10 - i))

        control_code = sum(control_codes)
        real_control_code = int(snils[9:11])

        assert control_code % 101 in (real_control_code, 100), \
        'Invalid control code of snils'


# Generated at 2022-06-12 01:18:36.723497
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Create context
    from mimesis.providers.russia import RussiaSpecProvider
    provider = RussiaSpecProvider()
    # Testing
    snils = '41917492600'
    assert snils == provider.snils()



# Generated at 2022-06-12 01:18:39.511678
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia = RussiaSpecProvider()
    test_snils = russia.snils()
    assert len(test_snils) == 11

# Generated at 2022-06-12 01:18:44.889682
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Test snils
    snils = RussiaSpecProvider().snils()
    print('snils is: ', snils)
    assert snils

    # Test specific snils
    snils = RussiaSpecProvider().snils(seed=0)
    print('snils is: ', snils)
    assert snils


# Generated at 2022-06-12 01:18:51.933735
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():

    from mimesis import Person
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender
    from mimesis.typing import Seed

    russian = RussiaSpecProvider(seed=13)
    russian.random.seed(13)
    assert russian.snils() == '41917492600'

    person = Person('ru')
    person.random.seed(13)
    assert person.snils() == '41917492600'

    snilsProvider = RussiaSpecProvider(seed=13)
    snilsProvider.random.seed(13)
    assert snilsProvider.patronymic(Gender.MALE) == 'Алексеевич'

    snilsProvider = RussiaSpecProvider(seed=13)