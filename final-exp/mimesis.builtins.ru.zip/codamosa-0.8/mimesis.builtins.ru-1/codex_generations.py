

# Generated at 2022-06-12 01:14:00.411129
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():

    rus=RussiaSpecProvider()
    print(rus.snils())




# Generated at 2022-06-12 01:14:02.686768
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    output = RussiaSpecProvider(seed=1).snils()
    assert output == "41917492600"

# Generated at 2022-06-12 01:14:12.657841
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    prv = RussiaSpecProvider()
    # Generate snils
    snils = prv.snils()
    # Get control code
    control_code = int(snils[-2:])
    # Get numbers of snils
    numbers = [int(x) for x in snils[:-2]]

    # Check control code
    control_codes = []
    for i in range(9, 0, -1):
        control_codes.append(numbers[9 - i] * i)
    if control_code == (sum(control_codes) % 101) % 100:
        assert True
    else:
        assert False


# Generated at 2022-06-12 01:14:15.441235
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test method snils of class RussiaSpecProvider."""
    rus = RussiaSpecProvider()
    assert len(rus.snils()) == 11



# Generated at 2022-06-12 01:14:27.751510
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.enum import Gender
    from mimesis.providers.person.russia import RussiaSpecProvider

    rsp = RussiaSpecProvider()

    expected_snils = '41917492600'
    actual_snils = rsp.snils()

    assert expected_snils == actual_snils

    expected_patronymic_for_man = 'Александрович'
    actual_patronymic_for_man = rsp.patronymic(Gender.MALE)

    assert expected_patronymic_for_man == actual_patronymic_for_man

    expected_patronymic_for_woman = 'Александровна'
    actual_patronymic_for_woman = rsp

# Generated at 2022-06-12 01:14:34.316745
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.code.credit_card_provider import CreditCardInfo
    from unittest import TestCase
    import pytest

    class TestRussiaSpecProvider(TestCase):
        inn_obj = RussiaSpecProvider()
        for _ in range(1, 1001):
            snils_obj = RussiaSpecProvider()
            snils = snils_obj.snils()

            if len(str(snils)) != 11:
                print(f'Wrong snils: {snils}')

    pytest.main([__file__])

# Generated at 2022-06-12 01:14:37.740802
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rs = RussiaSpecProvider()
    for i in range(0, 100):
        assert len(str(rs.snils())) == 11

# Generated at 2022-06-12 01:14:40.882423
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test RussiaSpecProvider.snils."""
    rus = RussiaSpecProvider()
    assert len(rus.snils()) == 11
    assert rus.snils() == '77657624600'


# Generated at 2022-06-12 01:14:44.223571
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test function for snils method of class RussiaSpecProvider."""
    r = RussiaSpecProvider()
    assert r.snils() == '90000784600'


# Generated at 2022-06-12 01:14:47.672550
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test for method snils of class RusiaSpecProvider."""
    from mimesis.providers.person.ru import RussiaSpecProvider
    random = RussiaSpecProvider()
    assert len(random.snils()) == 11

# Generated at 2022-06-12 01:15:05.252662
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    pass

# Generated at 2022-06-12 01:15:09.024381
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    print(snils)
    assert len(snils) == 11
    assert isinstance(int(snils), int)


# Generated at 2022-06-12 01:15:15.562637
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.schema import Field, Schema
    from mimesis.providers.bank import BankProvider
    
    s = Schema(provider=RussiaSpecProvider())
    person = s.create(
        Field('name'),
        Field('surname'),
        Field('snils')
    )
    person['snils'] = str(person['snils'])
    print(person)
    assert len(person['snils']) == 11


# Generated at 2022-06-12 01:15:20.242033
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    print("\nRunning test method RussiaSpecProvider.snils()")
    snils = RussiaSpecProvider().snils()
    print("\tType:", type(snils))
    if (type(snils) is str):
        print("\tSUCCESS")
    else:
        print("\tFAIL")


# Generated at 2022-06-12 01:15:22.089779
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider().snils() == '41917492600'

# Generated at 2022-06-12 01:15:30.425293
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test RussiaSpecProvider_snils."""
    provider = RussiaSpecProvider()

    n = provider.snils()
    assert len(n) == 11

    n = provider.snils()
    assert str(n[9]) == str(int(n[0:9]) % 101 % 100 % 10)

    n = provider.snils()
    assert str(n[8:10]) == '00'

    n = provider.snils()
    a = str(int(n[0:9]) % 101 % 100 % 10)
    b = str(int(n[0:9]) % 101 % 10)
    assert (str(n[9]) == a) or (str(n[9:10]) == b)


# Generated at 2022-06-12 01:15:35.695617
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    import re
    from mimesis.providers.generic import Generic

    gen = Generic("ru")
    pattern = re.compile("\d{11}")
    for _ in range(1000):
        assert pattern.match(gen.snils())



# Generated at 2022-06-12 01:15:37.275833
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    gen = RussiaSpecProvider()
    numbers = gen.snils()
    assert gen.validate_snils(numbers)

# Generated at 2022-06-12 01:15:39.228899
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    assert provider.snils() == '41917492600'


# Generated at 2022-06-12 01:15:40.560127
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    assert len(str(r.snils())) == 11

# Generated at 2022-06-12 01:16:27.799516
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.russia_provider import RussiaSpecProvider
    from mimesis.providers.snils import SNILS
    from mimesis.enums import Gender
    from mimesis.builtins import RussiaSpecProvider as Rus
    snils = SNILS()
    rus = RussiaSpecProvider(seed=42)
    rus_ = Rus(seed=42)

    methods = [
        snils.snils, rus.snils, rus_.snils
    ]
    expected = [
        '41917492600', '41917492600', '41917492600'
    ]
    
    for i, meth in enumerate(methods):
        assert meth() == expected[i]

# Generated at 2022-06-12 01:16:29.763554
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rp = RussiaSpecProvider()
    print(rp.snils())

# Generated at 2022-06-12 01:16:38.373495
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    snils = RussiaSpecProvider().snils()
    nums = []
    for n in snils:
        nums.append(int(n))
    digits = [9, 8, 7, 6, 5, 4, 3, 2, 1]
    control_code = 0
    for i, _ in enumerate(digits, start=0):
        control_code += nums[i] * digits[i]
    assert nums[9] * 10 + nums[10] == control_code % 101

# Generated at 2022-06-12 01:16:43.073142
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()
    f = open('test_RussiaSpecProvider_snils_result.csv', 'w', encoding='utf-8')
    k = 0
    for x in range(0, 999999999):
        snils = rsp.snils()
        f.writelines(str(x) + '\t' + snils + '\n')


# Generated at 2022-06-12 01:16:54.469974
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """
    Without argument this function return random snils
    >>> from mimesis import Builtin
    >>> from mimesis.providers.person import RussiaSpecProvider
    >>> rus_spec = RussiaSpecProvider(seed='test')
    >>> rus_spec.snils()
    '41917492600'
    >>> rus_spec.snils()
    '41917492600'
    >>> rus_spec1 = RussiaSpecProvider(seed='test1')
    >>> rus_spec1.snils()
    '88718700327'
    >>> rus_spec2 = RussiaSpecProvider(seed='test2')
    >>> rus_spec2.snils()
    '83526999431'
    """


# Generated at 2022-06-12 01:17:03.312256
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    # Create provider
    ru_spec_provider = RussiaSpecProvider()

    # Test 1: Check that generated SNILS is not an empty string
    assert ru_spec_provider.snils() != ''

    # Test 2: Check that generated SNILS consists of 11 digits
    assert len(ru_spec_provider.snils()) == 11

    # Test 3: Check that generated SNILS consists of digits only
    assert ru_spec_provider.snils().isdigit()

    # Test 4: Check that generated SNILS consists of digits only
    assert ru_spec_provider.snils().isdigit()

# Generated at 2022-06-12 01:17:05.891793
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Create a instance of class RussiaSpecProvider
    r = RussiaSpecProvider()
    # Check that result is int.
    assert isinstance(r.snils(), int)


# Generated at 2022-06-12 01:17:09.730281
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    russian_provider = RussiaSpecProvider()
    rand_snils = russian_provider.snils()
    assert isinstance(rand_snils, str)
    assert len(rand_snils) == 11



# Generated at 2022-06-12 01:17:17.046433
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit-test for method snils of class RussiaSpecProvider"""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    list = []
    for i in snils:
        list.append(i)
    a = int(list[0]) * 9 + int(list[1]) * 8 + int(list[2]) * 7 + int(list[3]) * 6 + int(list[4]) * 5 + int(list[5]) * 4 + int(list[6]) * 3 + int(list[7]) * 2 + int(list[8])
    if a % 101 == 100 or a % 101 == 101:
        a = 0
    if a % 101 != int(list[9]) * 10 + int(list[10]):
        return False
    else:
        return True

# Generated at 2022-06-12 01:17:23.685552
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    print()
    print('Run Unit Test for method snils of class RussiaSpecProvider')
    print('-------------------------------------------------------')
    print()
    temp = RussiaSpecProvider(seed=12345)
    print('Unit test for method snils of class RussiaSpecProvider')
    print('temp.snils() =', temp.snils())
    print()


# Generated at 2022-06-12 01:18:55.371980
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    assert str(provider.snils()) == provider.snils()
    assert len(provider.snils()) == 11


# Generated at 2022-06-12 01:18:57.803522
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rus = RussiaSpecProvider()
    for i in range(0, 10):
        snils = rus.snils()
        assert len(snils) == 11
    print(snils)


# Generated at 2022-06-12 01:19:09.086384
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider"""
    provider = RussiaSpecProvider()
    # snils = provider.snils()
    # assert len(snils) == 11

    numbers = []
    control_codes = []

    for i in range(0, 9):
        numbers.append(provider.random.randint(1, 9))

    for i in range(9, 0, -1):
        control_codes.append(numbers[9 - i] * i)

    control_code = sum(control_codes)
    code = ''.join(str(number) for number in numbers)

    if control_code in (100, 101):
        snils = code + '00'
        print(snils)
        assert len(snils) == 11


# Generated at 2022-06-12 01:19:13.136434
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    print(snils)


# Generated at 2022-06-12 01:19:16.795274
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.builtins.russia import RussiaSpecProvider
    a = RussiaSpecProvider()
    assert len(str(a.snils())) == 11
    assert not len(str(a.snils())) > 11

# Generated at 2022-06-12 01:19:18.562004
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    print(snils)
    assert len(snils) == 11


# Generated at 2022-06-12 01:19:21.800225
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rssp = RussiaSpecProvider()
    snils = rssp.snils()
    print(snils)


# Generated at 2022-06-12 01:19:28.201778
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    sut = RussiaSpecProvider()
    snils_list = []
    
    for i in range(0, 10):
        snils_list.append(sut.snils())
    
    assert snils_list[1] != snils_list[2]!= snils_list[3]!= snils_list[4]!= snils_list[5] != snils_list[6] != snils_list[7] != snils_list[8] != snils_list[9] != snils_list[0]
    
    
    
    

# Generated at 2022-06-12 01:19:32.736761
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test method snils of class RussiaSpecProvider"""
    tsnils = RussiaSpecProvider(seed=12345)
    assert tsnils.snils() == '41917492600'

# Generated at 2022-06-12 01:19:34.373961
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    snils = ['41917492600']
    assert RussiaSpecProvider().snils() in snils

# Generated at 2022-06-12 01:23:32.881229
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    results = []
    for _ in range(0, 1000):
        results.append(provider.snils())

    assert len(set(results)) == len(results), 'Results are not unique'
    for snils in results:
        if len(snils) != 11:
            raise ValueError('SNILS {} is not valid!'.format(snils))
        if snils.endswith('00'):
            raise ValueError('SNILS {} is not valid!'.format(snils))

        digits = []
        for i in snils:
            digits.append(int(i))

        control_codes = []

        for i in range(9, 0, -1):
            control_codes.append(digits[9 - i] * i)

        control_code = sum(control_codes)

# Generated at 2022-06-12 01:23:37.239218
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider1 = RussiaSpecProvider()
    provider2 = RussiaSpecProvider()

    result1 = provider1.snils()
    result2 = provider2.snils()

    assert result1 is not None
    assert result2 is not None

    assert len(result1) == 11
    assert len(result2) == 11

    assert int(result1) != int(result2)


# Generated at 2022-06-12 01:23:44.212912
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Тест функции  snils класса RussiaSpecProvider"""
    russia_provider = RussiaSpecProvider()
    snils = russia_provider.snils()
    #если сумма контрольной цифры меньше 100
    if int(snils[:9]) < 100:
        assert len(snils) == 11
        assert snils[-3:] == snils[-3:][::-1]
        for i in range(9):
            assert int(snils[0]) == 9 and int(snils[1]) == 8 and int(snils[2]) == 7
    #если сумма

# Generated at 2022-06-12 01:23:46.020694
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    s = RussiaSpecProvider()
    print(s.snils())
    print(s.snils())
    print(s.snils())
    print(s.snils())
    print(s.snils())
