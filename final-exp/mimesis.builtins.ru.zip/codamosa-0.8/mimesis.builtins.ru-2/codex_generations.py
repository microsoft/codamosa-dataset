

# Generated at 2022-06-12 01:14:00.197132
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    snils = RussiaSpecProvider().snils()
    assert snils.isdigit()
    assert len(snils) == 11

    # Unit test for method inn of class RussiaSpecProvider

# Generated at 2022-06-12 01:14:01.889624
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    assert provider.snils() != []


# Generated at 2022-06-12 01:14:06.417836
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    assert provider.snils() == '41917492600'
    assert provider.snils() == '41917492600'



# Generated at 2022-06-12 01:14:09.141794
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    random = RussiaSpecProvider()
    snils = random.snils()
    assert snils.isdigit()


# Generated at 2022-06-12 01:14:12.382901
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    import mimesis.builtins.russia as rsp
    rp: rsp.RussiaSpecProvider = rsp.RussiaSpecProvider()
    assert len(rp.snils()) == 11
    assert isinstance(rp.snils(), str)


# Generated at 2022-06-12 01:14:13.807888
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    snils = RussiaSpecProvider().snils()
    print(snils)



# Generated at 2022-06-12 01:14:16.193510
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Testing RussiaSpecProvider.snils"""
    provider_instance = RussiaSpecProvider()
    assert type(provider_instance.snils()) == str


# Generated at 2022-06-12 01:14:24.439313
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    import random
    import re

    random.seed(0)
    p = RussiaSpecProvider(seed=0)
    snils = p.snils()

    # remove special characters (if any)
    # and make a list of digits
    snils_list = list(re.sub("[^\d]", "", snils))

    assert snils_list == ['4', '1', '9', '1', '7', '4', '9', '2', '6', '0', '0']

# Generated at 2022-06-12 01:14:28.126681
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for RussiaSpecProvider.snils() method."""
    random.seed(123)
    rsp = RussiaSpecProvider()
    assert rsp.snils() == '41917492600'


# Generated at 2022-06-12 01:14:31.410096
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    result = provider.snils()
    assert len(result) == 11
    assert result.isdigit()


# Generated at 2022-06-12 01:14:53.162526
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test snils of RussiaSpecProvider"""
    ru = RussiaSpecProvider(seed=42)
    assert ru.snils() == '21917492600'


# Generated at 2022-06-12 01:14:56.435764
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    prv = RussiaSpecProvider()
    assert (prv.snils() == '41917492600')
    assert (prv.snils() == '41917492600')
    assert (prv.snils() == '41917492600')


# Generated at 2022-06-12 01:14:58.426446
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Print the result
    print("SNILS: ")
    print(RussiaSpecProvider().snils())


# Generated at 2022-06-12 01:15:02.989011
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.finance import Finance
    i = RussiaSpecProvider()
    f = Finance()
    assert f.snils('41917492600') == '41917492600'
    assert len(i.snils()) == 11
    assert i.snils().isdigit()

# Generated at 2022-06-12 01:15:13.999712
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.builtins import RussiaSpecProvider
    rsp = RussiaSpecProvider()
    x = rsp.snils()
    snils_numbers = x[0:9]
    digits_dict = {
        'n2': [7, 2, 4, 10, 3, 5, 9, 4, 6, 8],
        'n1': [3, 7, 2, 4, 10, 3, 5, 9, 4, 6, 8],
    }
    control_codes = []

    for i in range(0, 9):
        control_codes.append(int(snils_numbers[i]) * digits_dict['n2'][i])

    control_code = sum(control_codes)
    number = ''.join(str(number) for number in snils_numbers)


# Generated at 2022-06-12 01:15:17.671532
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    for i in range(0, 3):
        print(RussiaSpecProvider().snils())
        i += 1

    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert snils == provider.snils()

    expected = '41917492600'
    assert snils == expected

# Generated at 2022-06-12 01:15:19.429137
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()
    rsp.snils()


# Generated at 2022-06-12 01:15:21.921228
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    assert len(r.snils()) == 11


# Generated at 2022-06-12 01:15:23.728260
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    assert len(provider.snils()) == 11
    assert type(provider.snils()) == str


# Generated at 2022-06-12 01:15:26.707581
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider(seed=0)
    assert provider.snils() == '73724677200'

# Generated at 2022-06-12 01:16:09.108545
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.person import Person

    person = Person('ru')
    snils = person.snils()
    assert len(snils) == 11


# Generated at 2022-06-12 01:16:11.672283
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider().snils() != RussiaSpecProvider().snils()

# Generated at 2022-06-12 01:16:12.653499
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider().snils() != RussiaSpecProvider().snils()


# Generated at 2022-06-12 01:16:14.509900
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    ru = RussiaSpecProvider()
    snils = ru.snils()
    print(snils)
    assert len(snils) == 11


# Generated at 2022-06-12 01:16:24.439728
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    import re
    r = RussiaSpecProvider()
    examples = ['41917492600'] * 100
    valid_snils = re.compile('^(?!000-000-000 00)' \
                             + '((?!000-000-000 00)[0-9]{3}-?[0-9]{3}-?[0-9]{3} [0-9]{2})$')
    for _ in range(0, 100):
        snils = r.snils()
        assert valid_snils.match(snils)


# Generated at 2022-06-12 01:16:28.925934
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider(seed='roysharshan')
    print('\n' + rsp.snils() + '\n')


# Generated at 2022-06-12 01:16:31.988700
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """
    :return: Test the snils method of class RussiaSpecProvider.
    """
    rsp = RussiaSpecProvider()
    print('snils() =', rsp.snils())

# Generated at 2022-06-12 01:16:34.175725
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    s = RussiaSpecProvider().snils()
    assert s != ''



# Generated at 2022-06-12 01:16:36.956470
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert len(RussiaSpecProvider().snils()) == 11



# Generated at 2022-06-12 01:16:38.133154
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russ = RussiaSpecProvider()
    snils = russ.snils()
    assert snils == '41917492600'

# Generated at 2022-06-12 01:18:06.214615
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    for _ in range(100):
        provider = RussiaSpecProvider()
        provider.snils()



# Generated at 2022-06-12 01:18:08.492142
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.rus import RussiaSpecProvider
    provider = RussiaSpecProvider()
    print(provider.snils())


# Generated at 2022-06-12 01:18:20.568709
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from hypothesis import given, settings
    from hypothesis.strategies import integers, sampled_from
    from mimesis.typing import Seed

    provider = RussiaSpecProvider(seed=Seed(__name__))
    result = provider.snils()
    assert isinstance(result, str)
    assert len(result) == 11
    assert 9 <= int(result) <= 1000000001

    @given(integers(min_value=1, max_value=100000000000))
    @settings(max_examples=10, stateful_step_count=20)
    def test_snils(snils: int):
        # Test SNILS generator using Hypothesis
        if snils >= 1000000000:
            control_numbers = []
            snils_string = str(snils)

# Generated at 2022-06-12 01:18:24.741586
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    p = RussiaSpecProvider()
    print(p.snils())

if __name__ == '__main__':
    test_RussiaSpecProvider_snils()

# Generated at 2022-06-12 01:18:28.106217
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.builtins import RussiaSpecProvider
    ru = RussiaSpecProvider()
    for i in range(10):
        #print(ru.snils())
        pass
    print("ok")

# Generated at 2022-06-12 01:18:29.473525
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()
    assert rsp.snils() in rsp.snils()

# Generated at 2022-06-12 01:18:30.850301
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test snils."""
    provider = RussiaSpecProvider()

    result = provider.snils()

# Generated at 2022-06-12 01:18:33.336308
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    string = provider.snils()
    assert len(string) == 11
    assert string.isdigit()


# Generated at 2022-06-12 01:18:34.901563
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    result = RussiaSpecProvider().snils()
    print(result)

# Generated at 2022-06-12 01:18:36.895008
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rus_provider = RussiaSpecProvider()
    assert len(rus_provider.snils()) == 11
    assert isinstance(rus_provider.snils(), str)