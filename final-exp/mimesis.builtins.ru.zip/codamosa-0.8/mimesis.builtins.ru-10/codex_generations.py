

# Generated at 2022-06-12 01:14:01.327533
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Params:
    #  - seed: 13928
    #  - locale: ru
    #  - gender: MALE
    #  - use_exceptions: False
    #  - seed_obj: None
    _rsp = RussiaSpecProvider(seed=13928)

    assert _rsp.snils() == '41917492600'

# Generated at 2022-06-12 01:14:05.595947
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Function to check snils method of class RussiaSpecProvider"""
    provider = RussiaSpecProvider(seed=0)
    assert provider.snils() == '41917492600'

# Generated at 2022-06-12 01:14:08.080066
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    assert RussiaSpecProvider().snils()

# Generated at 2022-06-12 01:14:17.344642
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from argparse import ArgumentParser
    import sys
    p = ArgumentParser()
    p.add_argument('-s', '--seed', type=int, default=None, help='Seed for the random number generator.')
    p.add_argument('-n', '--count', type=int, default=None, help='Number of generated values.')
    args = p.parse_args()

    s = RussiaSpecProvider(seed=args.seed)
    snils_list = []
    for i in range(args.count):
        snils = s.snils()
        if snils in snils_list:
            print('Two identical SNILS (for seed {}): "{}"'.format(args.seed, snils))
            sys.exit(1)
        snils_list.append(snils)


# Generated at 2022-06-12 01:14:20.438019
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    obj = RussiaSpecProvider(seed=500)
    result = obj.snils()
    assert result == '41917492600'



# Generated at 2022-06-12 01:14:27.249671
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    spec_provider = RussiaSpecProvider()
    snils_1 = spec_provider.snils()
    snils_2 = spec_provider.snils()
    assert isinstance(snils_1, str)
    assert isinstance(snils_2, str)
    assert len(snils_1) == 11
    assert len(snils_2) == 11
    assert snils_1 != snils_2


# Generated at 2022-06-12 01:14:33.260100
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test snils method.

    Test cases:
    1. Random generated snils should have length 11
    2. Random generated snils should have value in range [1000000000, 9999999999]
    """
    number = RussiaSpecProvider().snils()
    assert len(number) == 11
    assert number.isdigit()
    assert 1000000000 <= int(number) <= 9999999999


# Generated at 2022-06-12 01:14:45.274560
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    import random
    from mimesis.providers.russia.ru import RussiaSpecProvider
    from mimesis.providers.person import Person
    from mimesis.enums import Gender
    class Test(RussiaSpecProvider):
        def __init__(self):
            RussiaSpecProvider.__init__(self)
        def _snils(self):
            return self.snils()
    print('СНИЛС пользователя')
    print(Test()._snils())
    print('Пользователь')
    print(Person().full_name(gender=Gender.MALE))
    print('ОГРН пользователя')

# Generated at 2022-06-12 01:14:49.216187
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    s = r.snils()
    assert type(s) == str
    assert len(s) == 11
    assert r.snils() == s


# Generated at 2022-06-12 01:14:52.541193
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    assert len(r.snils()) == 11


# Generated at 2022-06-12 01:15:16.765926
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    mimesis = RussiaSpecProvider()
    snils = mimesis.snils()
    check_digits = snils[-2:]
    middle_part = snils[:-2]
    digits = [int(middle_part[0:3]), int(middle_part[3:6]), int(middle_part[6:])]
    sum_code = digits[0] * 9 + digits[1] * 2 + digits[2] * 4
    check_sum = sum_code % 11 % 10
    if (check_sum == 10):
        check_sum = 0
    assert str(check_digits) == str(check_sum) + str(check_sum)

# Generated at 2022-06-12 01:15:19.803487
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert len(RussiaSpecProvider().snils()) == 11
    snils = RussiaSpecProvider().snils()
    first = int(snils[0])
    assert first != 0

# Generated at 2022-06-12 01:15:22.052024
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    # print(provider.snils())


# Generated at 2022-06-12 01:15:25.563683
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    p = provider.snils()
    def snils_validator(p):
        if len(p) != 11:
            return False
        else:
            return True
    assert snils_validator(p) == True
    p = provider.snils()
    assert snils_validator(p) == True

# Generated at 2022-06-12 01:15:30.313616
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis import RussiaSpecProvider
    from pytest import raises
    r = RussiaSpecProvider()

    snils = r.snils()
    assert r.snils() != r.snils()
    assert len(snils) == 11
    assert snils.isnumeric() == True


# Generated at 2022-06-12 01:15:36.658562
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider(seed=20)
    snils1 = provider.snils()
    snils2 = provider.snils()
    snils3 = provider.snils()
    assert snils1 == '41917492600'
    assert snils2 == '33354978100'
    assert snils3 == '78458728800'


# Generated at 2022-06-12 01:15:40.704435
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider"""
    russian_provider = RussiaSpecProvider()
    snils = russian_provider.snils()
    assert len(snils) == 11
    assert str.isdecimal(snils) == True
    assert len(set(snils)) == 11


# Generated at 2022-06-12 01:15:45.121385
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider(seed="abc")
    snils = r.snils()
    assert snils == "41917492600"


# Generated at 2022-06-12 01:15:46.054029
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """The snils() method is tested."""
    rp = RussiaSpecProvider()
    assert len(rp.snils()) == 11



# Generated at 2022-06-12 01:15:47.462288
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider().snils() == '41917492600'
    RussiaSpecProvider.seed(1234567)
    assert RussiaSpecProvider().snils() == '20665186978'



# Generated at 2022-06-12 01:16:25.826241
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Assert that all snils codes are in a valid range."""
    r = RussiaSpecProvider()
    for x in range(0, 100):
        snils = r.snils()
        assert 1000000 <= int(snils) <= 9999999999

# Generated at 2022-06-12 01:16:29.571446
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()
    mysnils = rsp.snils()
    print(mysnils)
    # Generated snils 41917492600

# Generated at 2022-06-12 01:16:33.141638
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rus_provider = RussiaSpecProvider()
    for i in range(1,5):
        print(rus_provider.snils())


# Generated at 2022-06-12 01:16:38.747813
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """
    Test if numbers in the series are correct
    """
    russia_prov_snils = RussiaSpecProvider()
    assert len(russia_prov_snils.snils()) == 11, "Length isn't 11"
    assert str(russia_prov_snils.snils()).isdigit(), "Not a number"


# Generated at 2022-06-12 01:16:40.016309
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider();
    assert r.snils()[-2:] == str(int(r.snils())%101%10)

# Generated at 2022-06-12 01:16:42.038104
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    data = RussiaSpecProvider()
    assert "41917492600" == data.snils()

# Generated at 2022-06-12 01:16:44.540442
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test method snils of class RussiaSpecProvider."""
    obj = RussiaSpecProvider()
    snils = obj.snils()
    assert len(snils) == 11
    assert isinstance(snils, str)


# Generated at 2022-06-12 01:16:46.936540
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    a = RussiaSpecProvider()
    print(a.snils())

# Generated at 2022-06-12 01:16:51.238225
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    print("Unit test for method snils of class RussiaSpecProvider")
    b = RussiaSpecProvider(seed=42)
    print("Random SNILS:", b.snils())

# Generated at 2022-06-12 01:16:53.683009
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    assert set(provider.snils() for i in range(10000)) == \
        set(provider._data['snils'])

# Generated at 2022-06-12 01:18:17.863835
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11


# Generated at 2022-06-12 01:18:20.977719
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russiasp = RussiaSpecProvider()
    russian_snils = [russiasp.snils() for _ in range(1000)]
    assert len(russian_snils) == 1000
    for snils in russian_snils:
        assert int(snils) in range(10000000000, 100000000001)


# Generated at 2022-06-12 01:18:27.138093
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider"""
    from mimesis.providers.person import Person
    person = Person('ru')
    snils = person.snils()
    assert len(snils) == 11
    assert snils.isnumeric() == True


# Generated at 2022-06-12 01:18:35.718950
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Check snils method of RussiaSpecProvider class."""

    # Unit test plan:
    # 1. Create an instance of RussiaSpecProvider
    # 2. Call the snils() method 10 times
    def create_instance():
        return RussiaSpecProvider()

    rsp = create_instance()
    assert isinstance(rsp, RussiaSpecProvider)
    results = []
    times = 10

    for _ in range(times):
        results.append(rsp.snils())
    print(results)

    # 3. The result is a list of strings with a length of 11 digits
    # 4. All strings in the list are different
    assert len(results) == times
    assert len(results[0]) == 11
    assert len(set(results)) == times



# Generated at 2022-06-12 01:18:37.519578
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    ru_provider = RussiaSpecProvider()
    snils_value = ru_provider.snils()
    print(snils_value)


# Generated at 2022-06-12 01:18:48.127752
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Generate snils with special algorithm.

    :return: SNILS.

    :Example:
        41917492600.
    """
    # numbers = []
    # control_codes = []
    #
    # for i in range(0, 9):
    #     numbers.append(random.randint(0, 9))
    #
    # for i in range(9, 0, -1):
    #     control_codes.append(numbers[9 - i] * i)
    #
    # control_code = sum(control_codes)
    # code = ''.join(str(number) for number in numbers)
    #
    # if control_code in (100, 101):
    #     snils = code + '00'
    #     return snils
    #
    # if control_code < 100

# Generated at 2022-06-12 01:18:49.681119
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert snils != provider.snils()

# Generated at 2022-06-12 01:18:53.533960
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    ru = RussiaSpecProvider()
    snils = ru.snils()
    test = str(snils)
    pattern = ru.pattern('snils')

    assert len(test) == 11
    assert ru.matches(pattern, test)

# Generated at 2022-06-12 01:18:56.988294
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    test = RussiaSpecProvider()
    test.seed(4)
    snils = test.snils()

    assert snils == "41917492600"

# Generated at 2022-06-12 01:19:02.006001
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert snils[:9].isnumeric()
    assert snils[9:].isnumeric()
    assert len(snils) == 11



# Generated at 2022-06-12 01:22:25.174674
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    import pytest
    from mimesis.enums import Gender
    from mimesis.providers.russia.russia import RussiaSpecProvider

    russ = RussiaSpecProvider()

    assert len(russ.snils()) == 11
    print('test_RussiaSpecProvider_snils')
    print(russ.snils())
    print('/test_RussiaSpecProvider_snils')


# Generated at 2022-06-12 01:22:29.780790
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert type(snils) == str
    assert len(snils) == 11
    provider = RussiaSpecProvider(seed='123456')
    snils = provider.snils()
    assert snils == '01871748900'



# Generated at 2022-06-12 01:22:33.814935
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test for RussiaSpecProvider class."""
    from mimesis.builtins import RussiaSpecProvider as ru
    import re

    r = ru()
    snils = r.snils()

    assert len(snils) == 11
    for i in snils:
        assert bool(re.match('[0-9]', i))

# Generated at 2022-06-12 01:22:40.057368
# Unit test for method snils of class RussiaSpecProvider

# Generated at 2022-06-12 01:22:47.285900
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils_result = provider.snils()
    assert len(snils_result) == 11
    # TODO: add more checks


# Generated at 2022-06-12 01:22:51.238653
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    s = RussiaSpecProvider()
    snils = s.snils()
    assert len(snils) == 11


# Generated at 2022-06-12 01:22:52.675822
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    result = provider.snils()

    assert type(result) is str


# Generated at 2022-06-12 01:22:55.936345
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russian_snils = RussiaSpecProvider()
    numbers = russian_snils.snils()
    length = len(numbers)
    if length != 11:
        raise Exception("RussiaSpecProvider: Length of SNILS is {0}, must be 11".format(length))
    if not numbers.isdigit():
        raise Exception("RussiaSpecProvider: SNILS must contain nothing but digits")

# Generated at 2022-06-12 01:22:57.617726
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    print(snils)
    assert len(snils) == 11


# Generated at 2022-06-12 01:23:05.463273
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Checking the snils method of class RussiaSpecProvider."""
    #List of test cases
    test_cases = [
        [
            41917492600,
            43233710400,
            67415706600,
            30152688400,
            49906884800,
            27015745000,
            10348230100,
            53192718800,
            63371725400,
            88844511300,
        ],

    ]
    #If program is executed with -m option
    if __name__ == "__main__":
        for case in test_cases:
            print("Case #{} : {}".format(
                case.index(case) + 1,
                case
            ))
    #If program is imported