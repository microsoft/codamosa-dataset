

# Generated at 2022-06-17 21:54:48.953612
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    from mimesis.providers.russia import RussiaSpecProvider
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:54:55.852730
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    from mimesis.providers.russia import RussiaSpecProvider
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:54:59.032221
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    r = RussiaSpecProvider()
    assert len(r.snils()) == 11


# Generated at 2022-06-17 21:55:00.907220
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11


# Generated at 2022-06-17 21:55:03.489888
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    assert provider.snils() == '41917492600'


# Generated at 2022-06-17 21:55:09.269373
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    assert len(rsp.snils()) == 11
    assert rsp.snils()[-2:] == '00'
    assert rsp.snils()[-3:] == '000'
    assert rsp.snils()[-3:] != '001'
    assert rsp.snils()[-3:] != '002'
    assert rsp.snils()[-3:] != '003'
    assert rsp.snils()[-3:] != '004'
    assert rsp.snils()[-3:] != '005'
    assert rsp.snils()[-3:] != '006'
    assert rsp.snils()[-3:] != '007'
    assert rsp.snils()

# Generated at 2022-06-17 21:55:18.919157
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    assert len(r.snils()) == 11
    assert r.snils()[-2:] != '00'
    assert r.snils()[-2:] != '01'
    assert r.snils()[-2:] != '02'
    assert r.snils()[-2:] != '03'
    assert r.snils()[-2:] != '04'
    assert r.snils()[-2:] != '05'
    assert r.snils()[-2:] != '06'
    assert r.snils()[-2:] != '07'
    assert r.snils()[-2:] != '08'
    assert r.snils()[-2:] != '09'
    assert r.snils()[-2:] != '10'
    assert r

# Generated at 2022-06-17 21:55:22.692753
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """
    Unit test for method snils of class RussiaSpecProvider.
    """
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:55:25.254699
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    r = RussiaSpecProvider()
    snils = r.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:55:28.523494
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test snils method of RussiaSpecProvider class."""
    r = RussiaSpecProvider()
    assert len(r.snils()) == 11


# Generated at 2022-06-17 21:55:43.319534
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    r = RussiaSpecProvider()
    assert len(r.snils()) == 11
    assert r.snils()[0] != '0'
    assert r.snils()[3] != '0'
    assert r.snils()[6] != '0'
    assert r.snils()[9] != '0'
    assert r.snils()[10] != '0'


# Generated at 2022-06-17 21:55:46.427227
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:55:50.352511
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    from mimesis.providers.russia import RussiaSpecProvider
    rsp = RussiaSpecProvider()
    assert len(rsp.snils()) == 11
    assert rsp.snils() == '41917492600'


# Generated at 2022-06-17 21:55:52.452978
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    assert rsp.snils() == '41917492600'

# Generated at 2022-06-17 21:55:58.734927
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test snils method of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils[0] != '0'
    assert snils[3] != '0'
    assert snils[6] != '0'
    assert snils[9] != '0'
    assert snils[10] != '0'


# Generated at 2022-06-17 21:56:03.256798
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    from mimesis.providers.person import Person

    person = Person('ru')
    snils = person.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:56:07.145888
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.russia import RussiaSpecProvider
    r = RussiaSpecProvider()
    assert len(r.snils()) == 11
    assert r.snils()[-2:] != '00'


# Generated at 2022-06-17 21:56:11.067714
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test snils method of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:56:13.613854
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    r = RussiaSpecProvider()
    assert len(r.snils()) == 11


# Generated at 2022-06-17 21:56:15.773378
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    assert r.snils() == '41917492600'

# Generated at 2022-06-17 21:56:35.612254
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:56:38.893380
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()

# Generated at 2022-06-17 21:56:42.023504
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:56:43.957604
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:56:46.457909
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test snils method of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:56:49.744999
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    assert len(rsp.snils()) == 11
    assert rsp.snils() == '41917492600'


# Generated at 2022-06-17 21:56:53.432136
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    assert len(rsp.snils()) == 11
    assert rsp.snils()[0] != 0


# Generated at 2022-06-17 21:56:56.764074
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils[-2:] == '00'


# Generated at 2022-06-17 21:56:59.612433
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:57:02.684444
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    assert rsp.snils() == '41917492600'

# Generated at 2022-06-17 21:57:21.352689
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test snils method of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:57:24.120087
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    r = RussiaSpecProvider()
    assert r.snils() == '41917492600'

# Generated at 2022-06-17 21:57:35.467756
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    assert len(rsp.snils()) == 11
    assert rsp.snils()[-2:] != '00'
    assert rsp.snils()[-2:] != '01'
    assert rsp.snils()[-2:] != '02'
    assert rsp.snils()[-2:] != '03'
    assert rsp.snils()[-2:] != '04'
    assert rsp.snils()[-2:] != '05'
    assert rsp.snils()[-2:] != '06'
    assert rsp.snils()[-2:] != '07'
    assert rsp.snils()[-2:] != '08'
    assert rsp.snils()

# Generated at 2022-06-17 21:57:39.135981
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test for method snils of class RussiaSpecProvider"""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:57:43.161213
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.person.russia import RussiaSpecProvider
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils[-2:] == '00'


# Generated at 2022-06-17 21:57:45.444910
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    assert rsp.snils() == '41917492600'

# Generated at 2022-06-17 21:57:47.212919
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    assert provider.snils() == '41917492600'

# Generated at 2022-06-17 21:57:52.478847
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    r = RussiaSpecProvider()
    assert len(r.snils()) == 11
    assert r.snils()[-2:] != '00'
    assert r.snils()[-2:] != '01'
    assert r.snils()[-2:] != '10'
    assert r.snils()[-2:] != '11'


# Generated at 2022-06-17 21:57:58.359063
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    from mimesis.providers.person.ru import RussiaSpecProvider
    rsp = RussiaSpecProvider()
    assert rsp.snils() == '41917492600'


# Generated at 2022-06-17 21:58:02.214889
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:58:45.967499
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:58:50.044540
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    assert len(rsp.snils()) == 11
    assert rsp.snils()[3] == '-'
    assert rsp.snils()[7] == '-'


# Generated at 2022-06-17 21:58:54.315151
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    assert provider.snils() == '41917492600'

# Generated at 2022-06-17 21:58:56.990121
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:59:13.684976
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:59:21.908290
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:59:25.564592
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:59:30.870458
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Create object of class RussiaSpecProvider
    russia_provider = RussiaSpecProvider()
    # Generate snils
    snils = russia_provider.snils()
    # Check that snils is string
    assert isinstance(snils, str)
    # Check that snils has 11 digits
    assert len(snils) == 11


# Generated at 2022-06-17 21:59:32.935974
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    assert provider.snils() == '41917492600'

# Generated at 2022-06-17 21:59:35.992100
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 22:00:56.386191
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 22:00:59.790117
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 22:01:03.519966
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()
    assert snils[-2:] != '00'


# Generated at 2022-06-17 22:01:07.573864
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 22:01:10.495160
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 22:01:12.244411
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    assert r.snils() == '41917492600'


# Generated at 2022-06-17 22:01:16.383357
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 22:01:24.999362
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils[0] != '0'
    assert snils[-2:] != '00'
    assert snils[-2:] != '01'
    assert snils[-2:] != '02'
    assert snils[-2:] != '03'
    assert snils[-2:] != '04'
    assert snils[-2:] != '05'
    assert snils[-2:] != '06'
    assert snils[-2:] != '07'
    assert snils[-2:] != '08'
    assert snils[-2:] != '09'
    assert snils[-2:] != '10'
   

# Generated at 2022-06-17 22:01:39.330067
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    assert rsp.snils() == '41917492600'

# Generated at 2022-06-17 22:01:41.875561
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()
