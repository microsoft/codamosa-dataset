

# Generated at 2022-06-17 21:54:48.572886
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:54:50.697050
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test snils method of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:54:57.778857
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()
    assert int(snils) > 1000000
    assert int(snils) < 100000000000


# Generated at 2022-06-17 21:55:01.670988
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:55:06.260487
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()
    assert snils[-2:] != '00'
    assert snils[-2:] != '01'
    assert snils[-2:] != '02'
    assert snils[-2:] != '03'
    assert snils[-2:] != '04'
    assert snils[-2:] != '05'
    assert snils[-2:] != '06'
    assert snils[-2:] != '07'
    assert snils[-2:] != '08'
    assert snils[-2:] != '09'
    assert snils[-2:] != '10'


# Generated at 2022-06-17 21:55:10.263108
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:55:13.763741
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    assert provider.snils() == '41917492600'


# Generated at 2022-06-17 21:55:17.362694
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:55:19.887394
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:55:22.887386
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11


# Generated at 2022-06-17 21:55:32.332990
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:55:34.103204
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    assert r.snils() == '41917492600'

# Generated at 2022-06-17 21:55:37.753748
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:55:41.772146
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test snils method of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:55:44.717318
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    assert provider.snils() == '41917492600'

# Generated at 2022-06-17 21:55:48.908794
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert isinstance(snils, str)


# Generated at 2022-06-17 21:55:51.848426
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test snils method of class RussiaSpecProvider."""
    r = RussiaSpecProvider()
    assert len(r.snils()) == 11


# Generated at 2022-06-17 21:55:54.463384
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    assert len(rsp.snils()) == 11


# Generated at 2022-06-17 21:56:04.625473
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils[0] != '0'
    assert snils[0] != '1'
    assert snils[0] != '2'
    assert snils[0] != '3'
    assert snils[0] != '4'
    assert snils[0] != '5'
    assert snils[0] != '6'
    assert snils[0] != '7'
    assert snils[0] != '8'
    assert snils[0] != '9'
    assert snils[1] != '0'
    assert snils[1] != '1'

# Generated at 2022-06-17 21:56:08.542850
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:56:23.747263
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:56:28.315360
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()
    assert snils[-2:] != '00'


# Generated at 2022-06-17 21:56:30.961680
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    assert rsp.snils() == '41917492600'

# Generated at 2022-06-17 21:56:34.912372
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()
    assert int(snils) > 1000000
    assert int(snils) < 100000000000


# Generated at 2022-06-17 21:56:38.602433
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:56:43.019766
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils[0] != 0
    assert snils[-2] != 0
    assert snils[-1] != 0


# Generated at 2022-06-17 21:56:45.866823
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:56:48.594374
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:56:51.009600
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    assert len(r.snils()) == 11


# Generated at 2022-06-17 21:56:54.206591
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils[-2:] == '00'


# Generated at 2022-06-17 21:57:24.645151
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    assert len(rsp.snils()) == 11
    assert rsp.snils() != rsp.snils()


# Generated at 2022-06-17 21:57:28.331772
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    assert provider.snils() == '41917492600'


# Generated at 2022-06-17 21:57:32.187575
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:57:37.022201
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils[0] != '0'
    assert snils[-2:] != '00'


# Generated at 2022-06-17 21:57:40.378693
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:57:43.282614
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    r = RussiaSpecProvider()
    assert r.snils() == '41917492600'

# Generated at 2022-06-17 21:57:46.114066
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:57:50.166940
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider"""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils[0] != '0'
    assert snils[-2:] != '00'


# Generated at 2022-06-17 21:57:55.627897
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:58:00.211255
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:59:18.559232
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    r = RussiaSpecProvider()
    assert len(r.snils()) == 11
    assert r.snils()[0] != '0'
    assert r.snils()[-1] != '0'
    assert r.snils()[-2] != '0'


# Generated at 2022-06-17 21:59:22.855837
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:59:24.992931
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:59:29.570012
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()
    assert int(snils) > 1000000
    assert int(snils) < 1000000000


# Generated at 2022-06-17 21:59:34.131881
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()
    assert snils[-2:] != '00'


# Generated at 2022-06-17 21:59:35.773627
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils[-2:] == '00'


# Generated at 2022-06-17 21:59:38.642728
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    assert len(provider.snils()) == 11


# Generated at 2022-06-17 21:59:40.365826
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test snils method of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:59:44.203268
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:59:47.077645
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 22:01:57.551311
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 22:02:01.167222
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 22:02:04.790509
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils == '41917492600'

# Generated at 2022-06-17 22:02:06.622442
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    assert rsp.snils() == '41917492600'


# Generated at 2022-06-17 22:02:11.705188
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    r = RussiaSpecProvider()
    snils = r.snils()
    assert len(snils) == 11
    assert snils.isdigit()
    assert snils[-2:] == '00'


# Generated at 2022-06-17 22:02:27.904776
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 22:02:31.208528
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 22:02:33.017728
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    assert r.snils() == '41917492600'

# Generated at 2022-06-17 22:02:35.507179
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 22:02:38.781867
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils[-2:] != '00'
