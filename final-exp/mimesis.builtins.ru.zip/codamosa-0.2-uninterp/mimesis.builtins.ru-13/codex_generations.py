

# Generated at 2022-06-17 21:54:50.909595
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:54:56.143524
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils[9] == snils[10]

# Generated at 2022-06-17 21:55:00.010730
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:55:09.096361
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.identifier import Identifier
    from mimesis.providers.financial import Financial
    from mimesis.providers.business import Business
    from mimesis.providers.internet import Internet
    from mimesis.providers.misc import Misc
    from mimesis.providers.geo import Geo
    from mimesis.providers.science import Science
    from mimesis.providers.code import Code
    from mimesis.providers.text import Text
    from mimesis.providers.file import File

# Generated at 2022-06-17 21:55:18.757454
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test for method snils of class RussiaSpecProvider."""
    r = RussiaSpecProvider()
    assert len(r.snils()) == 11
    assert r.snils()[-2:] != '00'
    assert r.snils()[-2:] != '01'
    assert r.snils()[-2:] != '02'
    assert r.snils()[-2:] != '03'
    assert r.snils()[-2:] != '04'
    assert r.snils()[-2:] != '05'
    assert r.snils()[-2:] != '06'
    assert r.snils()[-2:] != '07'
    assert r.snils()[-2:] != '08'
    assert r.snils()[-2:] != '09'

# Generated at 2022-06-17 21:55:26.791704
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.identification import Identification
    from mimesis.providers.financial import Financial
    from mimesis.providers.business import Business
    from mimesis.providers.internet import Internet
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.science import Science
    from mimesis.providers.code import Code
    from mimesis.providers.file import File
    from mimesis.providers.misc import Misc
    from mimesis.providers.geography import Geography
    from mimesis.providers.text import Text

# Generated at 2022-06-17 21:55:36.160368
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()
    assert snils[-2:] != '00'
    assert snils[-2:] != '01'
    assert snils[-2:] != '02'
    assert snils[-2:] != '03'
    assert snils[-2:] != '04'
    assert snils[-2:] != '05'
    assert snils[-2:] != '06'
    assert snils[-2:] != '07'
    assert snils[-2:] != '08'
    assert snils[-2:] != '09'
    assert snils[-2:] != '10'


# Generated at 2022-06-17 21:55:38.991445
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:55:42.058992
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.russia import RussiaSpecProvider
    r = RussiaSpecProvider()
    assert r.snils() == '41917492600'


# Generated at 2022-06-17 21:55:45.595964
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:56:07.077540
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    r = RussiaSpecProvider()
    assert len(r.snils()) == 11


# Generated at 2022-06-17 21:56:11.012358
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:56:14.722270
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:56:24.252674
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    assert len(rsp.snils()) == 11
    assert rsp.snils()[0] != '0'
    assert rsp.snils()[0] != '1'
    assert rsp.snils()[0] != '2'
    assert rsp.snils()[0] != '3'
    assert rsp.snils()[0] != '4'
    assert rsp.snils()[0] != '5'
    assert rsp.snils()[0] != '6'
    assert rsp.snils()[0] != '7'
    assert rsp.snils()[0] != '8'
    assert rsp.snils()[0] != '9'
   

# Generated at 2022-06-17 21:56:26.306207
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:56:29.472992
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    snils = RussiaSpecProvider().snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:56:32.128335
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    assert provider.snils() == '41917492600'

# Generated at 2022-06-17 21:56:34.784433
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    assert rsp.snils() == '41917492600'

# Generated at 2022-06-17 21:56:37.260876
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    assert rsp.snils() == '41917492600'

# Generated at 2022-06-17 21:56:40.321228
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    assert rsp.snils() == '41917492600'


# Generated at 2022-06-17 21:57:29.270272
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rus = RussiaSpecProvider()
    snils = rus.snils()
    assert len(snils) == 11
    assert snils.isdigit()
    assert snils[-2:] != '00'
    assert snils[-2:] != '01'
    assert snils[-2:] != '02'
    assert snils[-2:] != '03'
    assert snils[-2:] != '04'
    assert snils[-2:] != '05'
    assert snils[-2:] != '06'
    assert snils[-2:] != '07'
    assert snils[-2:] != '08'
    assert snils[-2:] != '09'
    assert snils[-2:] != '10'


# Generated at 2022-06-17 21:57:32.900738
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:57:37.771103
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    from mimesis.providers.russia import RussiaSpecProvider
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert isinstance(snils, str)


# Generated at 2022-06-17 21:57:41.471666
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:57:43.528413
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert snils == '41917492600'


# Generated at 2022-06-17 21:57:45.704880
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    assert rsp.snils() == '41917492600'

# Generated at 2022-06-17 21:57:48.614138
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:57:51.291278
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:57:57.067677
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    from mimesis.providers.russia import RussiaSpecProvider
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11


# Generated at 2022-06-17 21:58:07.747411
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    assert len(r.snils()) == 11
    assert r.snils()[-2:] == '00'
    assert r.snils()[-3] != '0'
    assert r.snils()[-3] != '1'
    assert r.snils()[-3] != '2'
    assert r.snils()[-3] != '3'
    assert r.snils()[-3] != '4'
    assert r.snils()[-3] != '5'
    assert r.snils()[-3] != '6'
    assert r.snils()[-3] != '7'
    assert r.snils()[-3] != '8'
    assert r.snils()[-3] != '9'
    assert r

# Generated at 2022-06-17 21:59:37.267779
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    assert r.snils() == '41917492600'

# Generated at 2022-06-17 21:59:39.981701
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert snils == '41917492600'

# Generated at 2022-06-17 21:59:43.914709
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test snils method of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:59:46.260953
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils == '41917492600'

# Generated at 2022-06-17 21:59:48.803688
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test for method snils of class RussiaSpecProvider."""
    r = RussiaSpecProvider()
    snils = r.snils()
    assert len(snils) == 11
    assert snils[9] == snils[10]


# Generated at 2022-06-17 21:59:51.161969
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:59:56.678729
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test for method snils of class RussiaSpecProvider."""
    from mimesis.providers.russia import RussiaSpecProvider
    r = RussiaSpecProvider()
    assert r.snils() == '41917492600'


# Generated at 2022-06-17 21:59:59.766913
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    assert len(provider.snils()) == 11


# Generated at 2022-06-17 22:00:03.090488
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 22:00:08.522113
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    r = RussiaSpecProvider()
    assert len(r.snils()) == 11
    assert r.snils()[-2:] != '00'
    assert r.snils()[-2:] != '01'
    assert r.snils()[-2:] != '99'
    assert r.snils()[-2:] != '98'
