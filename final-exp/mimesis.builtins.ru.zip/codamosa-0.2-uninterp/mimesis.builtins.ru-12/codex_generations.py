

# Generated at 2022-06-17 21:54:51.018472
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()
    assert snils != '00000000000'
    assert snils != '99999999999'


# Generated at 2022-06-17 21:54:56.296464
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:55:06.951813
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider"""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils[-2:] != '00'
    assert snils[-2:] != '01'
    assert snils[-2:] != '02'
    assert snils[-2:] != '03'
    assert snils[-2:] != '04'
    assert snils[-2:] != '05'
    assert snils[-2:] != '06'
    assert snils[-2:] != '07'
    assert snils[-2:] != '08'
    assert snils[-2:] != '09'
    assert snils[-2:] != '10'

# Generated at 2022-06-17 21:55:09.212756
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:55:12.080413
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()

# Generated at 2022-06-17 21:55:15.016529
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:55:17.930675
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:55:20.302567
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:55:22.186607
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    assert len(r.snils()) == 11


# Generated at 2022-06-17 21:55:23.726207
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    assert len(r.snils()) == 11


# Generated at 2022-06-17 21:55:50.441067
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils[-2:] == '00'
    assert snils[-3] != '0'
    assert snils[-4] != '0'
    assert snils[-5] != '0'
    assert snils[-6] != '0'
    assert snils[-7] != '0'
    assert snils[-8] != '0'
    assert snils[-9] != '0'
    assert snils[-10] != '0'
    assert snils[-11] != '0'


# Generated at 2022-06-17 21:55:52.580799
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    r = RussiaSpecProvider()
    assert len(r.snils()) == 11


# Generated at 2022-06-17 21:56:03.503259
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    assert len(r.snils()) == 11
    assert r.snils()[-2:] != '00'
    assert r.snils()[-2:] != '01'
    assert r.snils()[-2:] != '02'
    assert r.snils()[-2:] != '03'
    assert r.snils()[-2:] != '04'
    assert r.snils()[-2:] != '05'
    assert r.snils()[-2:] != '06'
    assert r.snils()[-2:] != '07'
    assert r.snils()[-2:] != '08'
    assert r.snils()[-2:] != '09'
    assert r.snils()[-2:] != '10'
    assert r

# Generated at 2022-06-17 21:56:06.188949
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:56:10.041876
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:56:13.568372
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:56:23.326456
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils[0] != '0'
    assert snils[1] != '0'
    assert snils[2] != '0'
    assert snils[3] != '0'
    assert snils[4] != '0'
    assert snils[5] != '0'
    assert snils[6] != '0'
    assert snils[7] != '0'
    assert snils[8] != '0'
    assert snils[9] != '0'
    assert snils[10] != '0'


# Generated at 2022-06-17 21:56:24.486161
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    assert r.snils() == '41917492600'

# Generated at 2022-06-17 21:56:27.332509
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    assert rsp.snils() == '41917492600'

# Generated at 2022-06-17 21:56:30.134369
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    assert len(rsp.snils()) == 11


# Generated at 2022-06-17 21:57:09.731993
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:57:18.460879
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils[-2:] != '00'
    assert snils[-2:] != '01'
    assert snils[-2:] != '02'
    assert snils[-2:] != '03'
    assert snils[-2:] != '04'
    assert snils[-2:] != '05'
    assert snils[-2:] != '06'
    assert snils[-2:] != '07'
    assert snils[-2:] != '08'
    assert snils[-2:] != '09'
    assert snils[-2:] != '10'
    assert snils[-2:] != '11'

# Generated at 2022-06-17 21:57:20.964843
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:57:23.591936
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    assert provider.snils() == '41917492600'

# Generated at 2022-06-17 21:57:26.849277
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:57:30.970926
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:57:34.590618
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:57:37.770654
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    r = RussiaSpecProvider()
    assert r.snils() == '41917492600'

# Generated at 2022-06-17 21:57:41.462058
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:57:44.636432
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:59:17.505006
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:59:22.993261
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    from mimesis.providers.russia import RussiaSpecProvider
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    print(snils)
    assert len(snils) == 11


# Generated at 2022-06-17 21:59:24.540505
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    assert r.snils() == '41917492600'


# Generated at 2022-06-17 21:59:26.140903
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    assert r.snils() == '41917492600'


# Generated at 2022-06-17 21:59:27.919544
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    assert r.snils() == '41917492600'


# Generated at 2022-06-17 21:59:31.453905
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:59:34.959790
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:59:37.408466
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    r = RussiaSpecProvider()
    assert r.snils() == '41917492600'

# Generated at 2022-06-17 21:59:41.864262
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 21:59:44.039383
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    assert r.snils() == '41917492600'


# Generated at 2022-06-17 22:03:43.989714
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils[0] != '0'
    assert snils[1] != '0'
    assert snils[2] != '0'
    assert snils[3] != '0'
    assert snils[4] != '0'
    assert snils[5] != '0'
    assert snils[6] != '0'
    assert snils[7] != '0'
    assert snils[8] != '0'
    assert snils[9] != '0'
    assert snils[10] != '0'


# Generated at 2022-06-17 22:03:45.384526
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    assert rsp.snils() == '41917492600'

# Generated at 2022-06-17 22:03:47.326622
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 22:03:49.378995
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 22:03:53.523882
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider"""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()
    assert snils[-2:] != '00'


# Generated at 2022-06-17 22:03:57.467319
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    assert provider.snils() == '41917492600'

# Generated at 2022-06-17 22:04:01.875316
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 22:04:04.006557
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-17 22:04:06.418721
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    assert rsp.snils() == '41917492600'

# Generated at 2022-06-17 22:04:09.066814
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test method snils of class RussiaSpecProvider."""
    r = RussiaSpecProvider()
    assert len(r.snils()) == 11
    assert r.snils() == '41917492600'
