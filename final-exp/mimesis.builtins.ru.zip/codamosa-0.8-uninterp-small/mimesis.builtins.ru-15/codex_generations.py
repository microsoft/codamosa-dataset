

# Generated at 2022-06-25 20:08:04.929227
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_2 = RussiaSpecProvider()
    assert russia_spec_provider_2.snils() == '17292420741'


# Generated at 2022-06-25 20:08:13.297109
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():

    list_0 = []
    russia_spec_provider_0 = RussiaSpecProvider()

    # def snils(self) -> str:
    for i in range(0, 10):
        str_0 = russia_spec_provider_0.snils()
        list_0.append(str_0)
        bool_0 = ''.isdigit()
        bool_1 = str_0.isdigit()
        if bool_1 is False:
            raise ValueError

    assert True


# Generated at 2022-06-25 20:08:22.338495
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert len(str_0) == 11
    assert str_0[:3].isdigit()
    assert str_0[3] == '-'
    assert str_0[4:7].isdigit()
    assert str_0[7] == '-'
    assert str_0[8:].isdigit()


# Generated at 2022-06-25 20:08:26.578476
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:08:37.262780
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    ru_spec_provider_0 = RussiaSpecProvider()
    snils_0 = ru_spec_provider_0.snils()
    ru_spec_provider_1 = RussiaSpecProvider()
    snils_1 = ru_spec_provider_1.snils()
    ru_spec_provider_2 = RussiaSpecProvider()
    snils_2 = ru_spec_provider_2.snils()
    ru_spec_provider_3 = RussiaSpecProvider()
    snils_3 = ru_spec_provider_3.snils()
    ru_spec_provider_4 = RussiaSpecProvider()
    snils_4 = ru_spec_provider_4.snils()
    ru_spec_provider_5 = RussiaSpecProvider()
    snils_5 = ru_spec_provider_5

# Generated at 2022-06-25 20:08:43.803807
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert str_0 is not None
    assert len(str_0) > 0
    assert len(str_0) == 11
    int_0 = int(str_0)
    assert int_0 > 0


# Generated at 2022-06-25 20:08:47.156521
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    str_0 = russia_spec_provider_1.snils()


# Generated at 2022-06-25 20:08:50.323311
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    object_0 = RussiaSpecProvider()
    assert object_0.snils() == '77134860900'


# Generated at 2022-06-25 20:08:56.045721
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    int_1 = russia_spec_provider_1.passport_number()
    str_1 = russia_spec_provider_1.passport_series()
    str_2 = russia_spec_provider_1.snils()
    str_3 = russia_spec_provider_1.ogrn()
    str_4 = russia_spec_provider_1.inn()
    str_5 = russia_spec_provider_1.bic()
    str_6 = russia_spec_provider_1.kpp()
    str_7 = russia_spec_provider_1.generate_sentence()
    str_8 = russia_spec_provider_1.patronymic()


# We need

# Generated at 2022-06-25 20:09:02.252868
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    pattern = '[0-9]{11}'
    russia_spec_provider_0 = RussiaSpecProvider()
    received_str_0 = russia_spec_provider_0.snils()
    assert received_str_0 == '41917492600'


# Generated at 2022-06-25 20:09:24.356251
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Tests for RussiaSpecProvider.snils"""
    russia_spec_provider_0 = RussiaSpecProvider()

    # Test #0
    str_0 = russia_spec_provider_0.snils()
    assert str_0 and not None



# Generated at 2022-06-25 20:09:27.031655
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    int_0 = russia_spec_provider_1.snils()
    # AssertionError: 41917492600 != 41917492601


# Generated at 2022-06-25 20:09:30.971450
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:09:34.351999
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    assert russia_spec_provider.snils() == '97625951405'


# Generated at 2022-06-25 20:09:38.938436
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:09:44.548142
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert len(str_0) == 11
    assert str_0[:9].isdigit()


# Generated at 2022-06-25 20:09:46.659265
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert len(str_0) == 11
    

# Generated at 2022-06-25 20:09:48.813234
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert str_0 is not None
    assert len(str_0) == 11


# Generated at 2022-06-25 20:09:56.560234
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Test method of class RussiaSpecProvider
    russia_spec_provider_1 = RussiaSpecProvider(seed=1823975296)
    russia_spec_provider_2 = RussiaSpecProvider(seed=1823975296)
    snils_1 = russia_spec_provider_1.snils()

    snils_2 = russia_spec_provider_2.snils()

    assert snils_1 == '98900474876'
    assert snils_2 == '98900474876'


# Generated at 2022-06-25 20:10:00.793265
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()



# Generated at 2022-06-25 20:10:18.474880
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    snils_0 = RussiaSpecProvider().snils()
    assert len(snils_0) == 11, "Test case failed"


# Generated at 2022-06-25 20:10:23.907429
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert str_0.isdigit()
    assert len(str_0) == 11

# Generated at 2022-06-25 20:10:28.136568
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert re.match(r'\d{11}', str_0)


# Generated at 2022-06-25 20:10:35.011190
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    string_0 = russia_spec_provider_0.snils()
    
if __name__ == '__main__':
    test_case_0()
    test_RussiaSpecProvider_snils()

# Generated at 2022-06-25 20:10:39.149653
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert len(str_0) == 11



# Generated at 2022-06-25 20:10:43.665625
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    str_1 = russia_spec_provider_1.snils()



# Generated at 2022-06-25 20:10:47.374202
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0_0 = RussiaSpecProvider()
    str_0_0 = russia_spec_provider_0_0.snils()


# Generated at 2022-06-25 20:10:49.781248
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    str_0 = russia_spec_provider_1.snils()


# Generated at 2022-06-25 20:11:00.595484
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert str_0 == '25066394790' or str_0 == '13113194600' or str_0 == '55677420700' or str_0 == '57705945700' or str_0 == '14081197600' or str_0 == '36551679300' or str_0 == '05833177600' or str_0 == '29151782600' or str_0 == '64785160400' or str_0 == '62483886300'


# Generated at 2022-06-25 20:11:05.225077
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert len(russia_spec_provider_0.snils()) == 11


# Generated at 2022-06-25 20:11:40.421651
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    snils_0 = russia_spec_provider_0.snils()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:11:45.054463
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert str_0 == '11112706800'
    assert str_0 == '11112706800'
    assert str_0 == '11112706800'
    assert str_0 == '11112706800'
    assert str_0 == '11112706800'
    assert str_0 == '11112706800'
    assert str_0 == '11112706800'
    assert str_0 == '11112706800'
    assert str_0 == '11112706800'
    assert str_0 == '11112706800'
    assert str_0 == '11112706800'

# Generated at 2022-06-25 20:11:45.974467
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    Russia_Spec_Provider = RussiaSpecProvider()
    Russia_Spec_Provider.snils()


# Generated at 2022-06-25 20:11:53.334634
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider(seed = 119)
    assert russia_spec_provider_0.snils() == '35860012971'
    russia_spec_provider_1 = RussiaSpecProvider(seed = 887)
    assert russia_spec_provider_1.snils() == '89092541636'
    russia_spec_provider_2 = RussiaSpecProvider(seed = 323)
    assert russia_spec_provider_2.snils() == '16961232980'
    russia_spec_provider_3 = RussiaSpecProvider(seed = 544)
    assert russia_spec_provider_3.snils() == '99096671355'
    russia_spec_provider_4 = RussiaSpecProvider(seed = 835)


# Generated at 2022-06-25 20:12:01.564777
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # random.seed(48)
    ru_0 = RussiaSpecProvider()
    str_0 = ru_0.snils()
    assert str_0 == '41917492600'

    ru_0 = RussiaSpecProvider(seed=42)
    str_0 = ru_0.snils()
    assert str_0 == '94758180300'

    ru_0 = RussiaSpecProvider(seed=48)
    str_0 = ru_0.snils()
    assert str_0 == '41917492600'

# Generated at 2022-06-25 20:12:06.005817
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:12:09.659131
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert valid_snils(russia_spec_provider_0.snils())


# Generated at 2022-06-25 20:12:13.243487
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    ru = RussiaSpecProvider()
    result = ru.snils()
    assert result
    assert len(result) == 11
    ru = RussiaSpecProvider(seed=123)
    result = ru.snils()
    # Use this value for test, if you want to replicate result
    assert result == '15175746665'


# Generated at 2022-06-25 20:12:19.209552
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert str_0 == '41256775200'


# Generated at 2022-06-25 20:12:22.685789
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    string_0 = russia_spec_provider_0.snils()
    assert len(string_0) == 11


# Generated at 2022-06-25 20:13:31.859506
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    string_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:13:33.714321
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    string_0 = russia_spec_provider_0.snils()

    assert string_0 == '49444896100'



# Generated at 2022-06-25 20:13:36.968354
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert type(str_0) == str
    assert 11 == len(str_0)


# Generated at 2022-06-25 20:13:40.358272
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.series_and_number()


# Generated at 2022-06-25 20:13:42.683281
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert str_0[0:3] == '419'


# Generated at 2022-06-25 20:13:44.466018
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    snils_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:13:46.596295
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    int_0 = russia_spec_provider_0.snils()
    assert isinstance(int_0, str)


# Generated at 2022-06-25 20:13:49.621841
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    result_snils = russia_spec_provider_0.snils()
    assert len(result_snils) == 11
    assert result_snils.isdigit() is True
    assert result_snils[9] == "0"
    assert result_snils[10] == "0"

# Generated at 2022-06-25 20:13:51.602603
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    string_0 = russia_spec_provider_0.snils()
    assert len(string_0) == 11


# Generated at 2022-06-25 20:13:54.171359
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    print(str_0)


# Generated at 2022-06-25 20:17:13.017410
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider().snils() in ['49043714154', '22437916423', '24951878183', '29397404053', '82468376806']


# Generated at 2022-06-25 20:17:15.200949
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:17:18.323155
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    snils = russia_spec_provider.snils()
    print(snils)


# Generated at 2022-06-25 20:17:20.354751
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():

    russia_spec_provider = RussiaSpecProvider()

    snils = russia_spec_provider.snils()
    print(snils)
    assert len(str(snils)) == 11


# Generated at 2022-06-25 20:17:30.106147
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    snils_0 = russia_spec_provider.snils()
    print(f'snils_0: "{snils_0}"')
    snils_1 = russia_spec_provider.snils()
    print(f'snils_1: "{snils_1}"')
    snils_2 = russia_spec_provider.snils()
    print(f'snils_2: "{snils_2}"')
    snils_3 = russia_spec_provider.snils()
    print(f'snils_3: "{snils_3}"')
    snils_4 = russia_spec_provider.snils()
    print(f'snils_4: "{snils_4}"')


# Generated at 2022-06-25 20:17:32.219314
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    str_0 = russia_spec_provider_1.snils()
    assert str_0 is not None


# Generated at 2022-06-25 20:17:34.384453
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    string_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:17:36.712780
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert str_0 == '94895205379'


# Generated at 2022-06-25 20:17:38.213344
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    str_0 = russia_spec_provider_1.snils()


# Generated at 2022-06-25 20:17:41.742391
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test for method snils of class RussiaSpecProvider.

    :return: void
    """

    # Initialize russia_spec_provider_0
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert len(str_0) == 11
    assert isinstance(str_0, str)
