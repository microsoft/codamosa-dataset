

# Generated at 2022-06-25 20:08:06.451347
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    snils_0 = russia_spec_provider_0.snils()
    assert isinstance(snils_0, str)


# Generated at 2022-06-25 20:08:08.465757
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    snils = russia_spec_provider_0.snils()
    assert len(snils) == 11


# Generated at 2022-06-25 20:08:12.615775
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert len(str_0) == 11
    assert isinstance(str_0, str)


# Generated at 2022-06-25 20:08:15.018949
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider(seed=1429)
    snils = russia_spec_provider_0.snils()
    assert snils == '96799727200'


# Generated at 2022-06-25 20:08:18.334966
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider(seed=4715113303725)
    result = russia_spec_provider_1.snils()
    assert result == '41917492600'



# Generated at 2022-06-25 20:08:20.095774
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert russia_spec_provider_0.snils() != ""


# Generated at 2022-06-25 20:08:21.663928
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    assert provider.snils() == '41917492600'


# Generated at 2022-06-25 20:08:24.825819
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    a = russia_spec_provider.snils()
    b = russia_spec_provider.snils()
    assert a != b
    assert len(a) == 11
    assert len(b) == 11


# Generated at 2022-06-25 20:08:28.485062
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()

    assert russia_spec_provider_0.snils() == '37730383713'


# Generated at 2022-06-25 20:08:36.230483
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    # We create a list of iterations of the test
    list_iterations = []
    for x in range(10):
        snils = russia_spec_provider_1.snils()
        list_iterations.append(snils)
    # We create a list of letters and record the quantity of its repetitions
    list_letters = set(list_iterations)
    for list_letter in list_letters:
        count = list_iterations.count(list_letter)
        assert count > 0


# Generated at 2022-06-25 20:08:56.777125
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    assert russia_spec_provider_1.snils() != ''


# Generated at 2022-06-25 20:09:01.265896
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert (len(russia_spec_provider_0.snils()) == 11)


# Generated at 2022-06-25 20:09:04.440236
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    snils = russia_spec_provider_0.snils()
    assert snils == '41917492600'


# Generated at 2022-06-25 20:09:13.389186
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    # Test with specified argument ``n`` = 5 (expected: 41917492600, 90220894355, 78712925369, 59418762842, 10390630171)
    for i in range(0, 5):
        assert len(russia_spec_provider_0.snils()) == 11


# Generated at 2022-06-25 20:09:14.899553
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    snils = russia_spec_provider.snils()
    return snils

# Generated at 2022-06-25 20:09:19.627178
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider(seed = 1234)
    snils = russia_spec_provider.snils()
    assert snils == "45243706100"


# Generated at 2022-06-25 20:09:29.315417
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert isinstance(russia_spec_provider_0.snils(), str)
    # Test that the number consists of 11 digits
    assert len(russia_spec_provider_0.snils()) == 11
    # Test that checksum is right
    snils = russia_spec_provider_0.snils()
    res = int(snils[0]) * 9 + int(snils[1]) * 8 + int(snils[2]) * 7 + \
          int(snils[3]) * 6 + int(snils[4]) * 5 + int(snils[5]) * 4 + \
          int(snils[6]) * 3 + int(snils[7]) * 2 + int(snils[8]) * 1
    checksum_1

# Generated at 2022-06-25 20:09:32.954898
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    assert russia_spec_provider.snils() == '41917492600'


# Generated at 2022-06-25 20:09:35.703777
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    string_1 = russia_spec_provider_1.snils()
    assert isinstance(string_1, str)


# Generated at 2022-06-25 20:09:37.623547
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    for i in range(3):
        assert len(russia_spec_provider_0.snils()) == 11


# Generated at 2022-06-25 20:10:13.959452
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    pass

# Generated at 2022-06-25 20:10:17.976075
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert isinstance(russia_spec_provider_0.snils(), str)


# Generated at 2022-06-25 20:10:21.312409
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert str(RussiaSpecProvider().snils()).strip() == str(RussiaSpecProvider().snils()).strip()

# Generated at 2022-06-25 20:10:31.122159
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russian_provider_0 = RussiaSpecProvider()
    snils = russian_provider_0.snils()
    assert snils
    snils = russian_provider_0.snils()
    assert snils
    snils = russian_provider_0.snils()
    assert snils
    snils = russian_provider_0.snils()
    assert snils
    snils = russian_provider_0.snils()
    assert snils
    snils = russian_provider_0.snils()
    assert snils
    snils = russian_provider_0.snils()
    assert snils
    snils = russian_provider_0.snils()
    assert snils
    snils = russian_provider_0.snils()
   

# Generated at 2022-06-25 20:10:42.557694
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_snils_0 = RussiaSpecProvider(seed=1)
    assert russia_spec_provider_snils_0.snils() == '41917492600'
    russia_spec_provider_snils_1 = RussiaSpecProvider(seed=1)
    assert russia_spec_provider_snils_1.snils() == '41917492600'
    russia_spec_provider_snils_2 = RussiaSpecProvider(seed=2)
    assert russia_spec_provider_snils_2.snils() == '88439230225'
    russia_spec_provider_snils_3 = RussiaSpecProvider(seed=2)
    assert russia_spec_provider_snils_3.snils() == '88439230225'
   

# Generated at 2022-06-25 20:10:48.894268
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    snils = russia_spec_provider_0.snils()
    assert number_of_digits_in_snils(snils) == 11
    assert only_digits_in_snils(snils)
    assert snils[0] != '0'


# Generated at 2022-06-25 20:10:54.351232
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    snils = russia_spec_provider.snils()
    assert snils
    assert type(snils) is str
    assert len(snils) == 11


# Generated at 2022-06-25 20:11:02.832472
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    snils_string = russia_spec_provider.snils()
    snils_int = int(snils_string)
    numbers = []
    control_codes = []

    for i in range(0, 9):
        numbers.append(snils_int % 10)
        snils_int //= 10
    numbers.reverse()

    for i in range(9, 0, -1):
        control_codes.append(numbers[9 - i] * i)

    control_code = sum(control_codes)
    code = ''.join(str(number) for number in numbers)

    if control_code in (100, 101):
        snils = int(code + '00')
        assert int(snils_string) == snils

# Generated at 2022-06-25 20:11:10.537236
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # russia_spec_provider_1 = RussiaSpecProvider()
    # print(russia_spec_provider_1.snils())

    # russia_spec_provider_2 = RussiaSpecProvider()
    # print(russia_spec_provider_2.snils())

    russia_spec_provider_3 = RussiaSpecProvider()
    print(russia_spec_provider_3.snils())


# Generated at 2022-06-25 20:11:14.807994
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert russia_spec_provider_0.snils() == '41917492600'


# Generated at 2022-06-25 20:12:49.911941
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    snils = russia_spec_provider_1.snils()
    assert len(snils) == 11


# Generated at 2022-06-25 20:12:53.936738
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider(seed=5158)
    assert russia_spec_provider_1.snils() == '41917492600'


# Generated at 2022-06-25 20:12:58.319810
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    x = 0
    for i in range(0, 10000):
        snils = russia_spec_provider_0.snils()
        print(snils)
        if len(snils) != 11:
            x += 1
    assert x == 0



# Generated at 2022-06-25 20:13:02.474427
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    test_cases = [
        ('41917492600', 1),
    ]
    provider = RussiaSpecProvider()
    for test_case, count in test_cases:
        for _ in range(count):
            data = provider.snils()
            assert isinstance(data, str)
            assert len(data) == 11


# Generated at 2022-06-25 20:13:12.040852
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    snils_num = russia_spec_provider.snils()
    snils_sum = 0
    snils_num_list = [int(x) for x in str(snils_num)]
    for i in range(len(snils_num_list)):
        snils_sum += snils_num_list[i]*(len(snils_num_list)-i)
    assert snils_sum % 101 % 100 in (snils_num_list[8:10], [0, 0])



# Generated at 2022-06-25 20:13:16.394236
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():

    russia_spec_provider_1 = RussiaSpecProvider()
    assert isinstance(russia_spec_provider_1.snils(), str)
    assert len(russia_spec_provider_1.snils()) == 11
    assert russia_spec_provider_1.snils() == russia_spec_provider_1.snils()



# Generated at 2022-06-25 20:13:19.870985
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    result = russia_spec_provider.snils()
    print(result)
    assert len(result) == 11


# Generated at 2022-06-25 20:13:24.218168
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    for i in range(1000):
        snils = russia_spec_provider_1.snils()
        assert snils[0] != '0'
        assert len(snils) == 11


# Generated at 2022-06-25 20:13:28.299115
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    assert russia_spec_provider.snils() == '38653247900'
    assert russia_spec_provider.snils() == '38653247900'
    assert russia_spec_provider.snils() == '38653247900'


# Generated at 2022-06-25 20:13:30.308537
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    assert len(russia_spec_provider.snils()) == 11 and russia_spec_provider.snils().isdigit() == True


# Generated at 2022-06-25 20:15:02.104548
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    instance_0 = russia_spec_provider_0.snils()
    pass


# Generated at 2022-06-25 20:15:09.417016
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    code = RussiaSpecProvider().snils()
    assert len(code) > 0


# Generated at 2022-06-25 20:15:14.572389
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    RussiaSpecProvider_snils = []
    i_0 = 0
    while i_0 < 100:
        RussiaSpecProvider_snils.append(russia_spec_provider_0.snils())
        i_0 = i_0 + 1
    assert all(RussiaSpecProvider_snils)


# Generated at 2022-06-25 20:15:17.070599
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    if russia_spec_provider_1.snils() != '41917492600':
        raise AssertionError()


# Generated at 2022-06-25 20:15:26.832820
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider(seed=47)
    snils_1 = russia_spec_provider_1.snils()
    assert snils_1 == '87570792632'
    russia_spec_provider_2 = RussiaSpecProvider(seed=47)
    snils_2 = russia_spec_provider_2.snils()
    assert snils_2 == '87570792632'
    russia_spec_provider_3 = RussiaSpecProvider(seed=47)
    snils_3 = russia_spec_provider_3.snils()
    assert snils_3 == '87570792632'


# Generated at 2022-06-25 20:15:30.046619
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russiaspecpovider = RussiaSpecProvider()
    test_snils_result = "47945151235"
    assert(test_snils_result == russiaspecpovider.snils())

if __name__ == '__main__':
    # russiaspecpovider = RussiaSpecProvider()
    # print(russiaspecpovider.snils())
    test_RussiaSpecProvider_snils()
    pass

# Generated at 2022-06-25 20:15:34.407695
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    if len(russia_spec_provider_1.snils()) == 11:
        print('Test № 1 "snils" passed')
    else:
        return None


# Generated at 2022-06-25 20:15:37.138550
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """RussiaSpecProvider.snils should return string."""
    russia_spec_provider = RussiaSpecProvider()
    assert isinstance(russia_spec_provider.snils(), str)


# Generated at 2022-06-25 20:15:43.483035
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    res = russia_spec_provider_0.snils()
    print(res)


# Generated at 2022-06-25 20:15:52.550156
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()

    for _ in range(0, 100):
        snils = russia_spec_provider_0.snils()
        if not (len(snils) == 11):
            raise AssertionError(snils)
