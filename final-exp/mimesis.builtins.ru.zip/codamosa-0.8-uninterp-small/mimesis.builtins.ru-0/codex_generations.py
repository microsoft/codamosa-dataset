

# Generated at 2022-06-25 20:08:08.681564
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    str_0 = russia_spec_provider.snils()
    str_1 = russia_spec_provider.snils()
    str_2 = russia_spec_provider.snils()
    assert isinstance(str_0, str)
    assert isinstance(str_1, str)
    assert isinstance(str_2, str)


# Generated at 2022-06-25 20:08:11.914078
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    snils = russia_spec_provider.snils()

    assert snils.isdigit()
    assert len(snils) == 11


# Generated at 2022-06-25 20:08:16.007250
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    RussiaSpecProvider_0 = RussiaSpecProvider()
    RussiaSpecProvider_0.snils()


# Generated at 2022-06-25 20:08:21.364986
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.person import Person

    provider = RussiaSpecProvider()

    person = Person('ru')
    assert len(provider.snils()) == 11, f"{person.full_name()} snils is not 11 characters!"


# Generated at 2022-06-25 20:08:24.117328
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Generate snils with special algorithm."""
    russia_spec_provider = RussiaSpecProvider()
    str_0 = russia_spec_provider.inn()
    assert len(str_0) == 10


# Generated at 2022-06-25 20:08:27.775007
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:08:33.084487
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider(russia_spec_provider_0.seed_0)
    str_0 = russia_spec_provider_0.snils()
    assert str_0 == str_0


# Generated at 2022-06-25 20:08:35.439834
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Set the variable
    russia_spec_provider = RussiaSpecProvider()

    # Validate the method by using the built-in function all
    assert all(
        [str(number).isdigit() for number in russia_spec_provider.snils()]
    )

# Generated at 2022-06-25 20:08:39.650173
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert_equal(len(str_0), 11)


# Generated at 2022-06-25 20:08:43.316299
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()



# Generated at 2022-06-25 20:08:54.664810
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    str_1 = russia_spec_provider_1.snils()
    str_2 = russia_spec_provider_1.snils()
    str_3 = russia_spec_provider_1.snils()
    str_4 = russia_spec_provider_1.snils()
    str_5 = russia_spec_provider_1.snils()
    str_6 = russia_spec_provider_1.snils()
    str_7 = russia_spec_provider_1.snils()
    str_8 = russia_spec_provider_1.snils()
    str_9 = russia_spec_provider_1.snils()
    str_10 = russia_spec_provider

# Generated at 2022-06-25 20:09:00.640698
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert str_0 == '98887630900'.strip()


# Generated at 2022-06-25 20:09:04.673267
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    test_seed_0 = Seed()
    russia_spec_provider_0 = RussiaSpecProvider(seed=test_seed_0)

    assert russia_spec_provider_0.snils() == '03956282791'


# Generated at 2022-06-25 20:09:10.943142
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    str_1 = russia_spec_provider_0.snils()
    assert str_0



# Generated at 2022-06-25 20:09:14.068736
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rss = RussiaSpecProvider()
    for _ in range(1000):
        assert rss.snils() != rss.snils()


# Generated at 2022-06-25 20:09:19.212841
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Tests snils method of class RussiaSpecProvider."""
    russia_spec_provider_0 = RussiaSpecProvider()
    russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:09:24.124351
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    str_1 = russia_spec_provider_1.snils()

    assert str_1 == '41917492600'


# Generated at 2022-06-25 20:09:26.687593
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    Assert(str_0)


# Generated at 2022-06-25 20:09:30.606889
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # case 0
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:09:34.051481
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    str_1 = russia_spec_provider_1.snils()
    print(str_1)

# Generated at 2022-06-25 20:09:50.015145
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:09:53.943077
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:09:55.627754
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    RussiaSpecProvider_object = RussiaSpecProvider()
    o = RussiaSpecProvider_object.snils()
    assert type(o) == str
    assert len(o) == 11


# Generated at 2022-06-25 20:10:01.737167
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    snils_0 = russia_spec_provider.snils()
    assert isinstance(snils_0, str) and len(snils_0) == 11


# Generated at 2022-06-25 20:10:05.840525
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:10:07.992230
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    # Checking if the generated number is valid and for some reason snils could be equal to 00000000000
    assert russia_spec_provider_0.snils()[0] != 0 


# Generated at 2022-06-25 20:10:12.851152
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    assert len(russia_spec_provider.snils()) == 11

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 20:10:17.327871
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    str_0 = russia_spec_provider.snils()
    assert str_0


# Generated at 2022-06-25 20:10:18.174819
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    test_case_1()


# Generated at 2022-06-25 20:10:27.121809
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    str_1 = russia_spec_provider_0.snils(seed=0)
    assert str_0 != str_1
    str_2 = russia_spec_provider_0.snils(seed=0)
    assert str_2 == str_1


# Generated at 2022-06-25 20:11:02.855798
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # unit_test_0
    russia_spec_provider_0 = RussiaSpecProvider(seed = '94fd99d78cff89')
    actual = russia_spec_provider_0.snils()
    expected = '08164594000'
    # print('actual: {}\nexpected: {}'.format(actual,expected))
    assert actual == expected
    # unit_test_1
    russia_spec_provider_1 = RussiaSpecProvider(seed = 'b03f9b8925a3f8')
    actual = russia_spec_provider_1.snils()
    expected = '28177879726'
    # print('actual: {}\nexpected: {}'.format(actual,expected))
    assert actual == expected
    # unit_test_2
    russia_spec_provider_2

# Generated at 2022-06-25 20:11:08.078771
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Variant 1
    russia_spec_provider = RussiaSpecProvider()
    check_snils = russia_spec_provider.snils()
    assert len(check_snils) == 11
    assert check_snils == '41917492600'
    # Variant 2
    russia_spec_provider.random.seed(11)
    check_snils = russia_spec_provider.snils()
    assert len(check_snils) == 11
    assert check_snils == '95957237200'


# Generated at 2022-06-25 20:11:09.660027
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert str_0 != '' and len(str_0) == 11


# Generated at 2022-06-25 20:11:15.145670
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    print(str_0)
    

# Generated at 2022-06-25 20:11:18.134191
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    str_0 = russia_spec_provider.snils()


# Generated at 2022-06-25 20:11:20.098914
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:11:24.810189
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    str_1 = russia_spec_provider_1.snils()



# Generated at 2022-06-25 20:11:30.571478
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    random = RussiaSpecProvider()
    snils = random.snils()
    assert len(snils) == 11, "Error with snils length"
    try:
        int(snils)
        assert True
    except:
        assert False, "Error with snils generating"


# Generated at 2022-06-25 20:11:39.649164
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Arrange
    russia_spec_provider_0 = RussiaSpecProvider()
    # Act
    str_0 = russia_spec_provider_0.snils()
    # Assert
    str_0_condition = 1
    assert russia_spec_provider_0.snils.__annotations__ == {}, 'Line 40'
    assert isinstance(str_0, str), 'Line 41'
    assert len(str_0) == 11, 'Line 42'
    assert str_0_condition == 1


# Generated at 2022-06-25 20:11:45.708981
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert not snils.startswith('0')
    assert not snils.endswith('00')


# Generated at 2022-06-25 20:13:02.853169
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:13:04.765510
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russian_0 = RussiaSpecProvider()
    str_0 = russian_0.inn()
    assert str_0 == '5905008322'

# Generated at 2022-06-25 20:13:08.094549
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider().snils() == '41917492600'


# Generated at 2022-06-25 20:13:11.474437
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()

    # Test
    str_0 = russia_spec_provider.snils()
    assert str_0 is not None


# Generated at 2022-06-25 20:13:13.490042
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()

# Generated at 2022-06-25 20:13:16.026437
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.inn()
    assert len(str_0) == 10


# Generated at 2022-06-25 20:13:19.263636
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert len(str_0) == 11


# Generated at 2022-06-25 20:13:23.046111
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:13:25.259340
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    ro = RussiaSpecProvider()
    snils = ro.snils()
    assert len(snils) == 11


# Generated at 2022-06-25 20:13:27.622285
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert len(str_0) == 11


# Generated at 2022-06-25 20:16:51.418852
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:16:53.861630
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()

# Generated at 2022-06-25 20:16:55.534204
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:16:59.331789
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert russia_spec_provider_0.snils() == '41917492600' or russia_spec_provider_0.snils() == '41917492600'

# Generated at 2022-06-25 20:17:01.637313
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert str_0 == '41917492600'


# Generated at 2022-06-25 20:17:03.503748
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    snils_0 = russia_spec_provider.snils()
    assert snils_0
    assert type(snils_0) is str

# Generated at 2022-06-25 20:17:05.999914
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert russia_spec_provider_0.snils() is not None


# Generated at 2022-06-25 20:17:08.692176
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test for snils of class RussiaSpecProvider."""
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert len(str_0) == 11


# Generated at 2022-06-25 20:17:11.999284
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert str_0 == '41917492600'


# Generated at 2022-06-25 20:17:14.719152
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    for _ in range(0, 1000):
        assert len(russia_spec_provider.snils()) == 11
