

# Generated at 2022-06-25 20:08:07.123199
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert russia_spec_provider_0.snils().isdigit()
    assert len(russia_spec_provider_0.snils()) == 11


# Generated at 2022-06-25 20:08:11.885339
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Initialization
    russia_spec_provider_0 = RussiaSpecProvider(239)
    # Assertion
    assert russia_spec_provider_0.snils() == "19236637200"


# Generated at 2022-06-25 20:08:16.579387
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    snils_0 = russia_spec_provider.snils()


# Generated at 2022-06-25 20:08:21.922162
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    str_0 = russia_spec_provider_1.snils()
    assert len(str_0) == 11, "Assert failure, method snils of class RussiaSpecProvider"


# Generated at 2022-06-25 20:08:24.017598
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:08:27.774420
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()

    snils = russia_spec_provider_0.snils()
    assert snils is not None



# Generated at 2022-06-25 20:08:32.759518
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    snils_0 = russia_spec_provider_0.snils()
    assert snils_0 == '41917492600'


# Generated at 2022-06-25 20:08:34.968012
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    string_0 = russia_spec_provider_0.snils()



# Generated at 2022-06-25 20:08:36.909126
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = RussiaSpecProvider().snils()
    assert len(str_0) == 11
    assert str_0[0] != '0'


# Generated at 2022-06-25 20:08:41.160991
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    snils = russia_spec_provider_0.snils()
    assert snils == '41917492600'


# Generated at 2022-06-25 20:08:57.831882
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    string_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:09:02.111442
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:09:07.878637
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    ans = True
    snils = russia_spec_provider.snils()
    nums = snils.split()
    control_codes = []
    for i in range(0, 9):
        control_codes.append(int(nums[i]) * i)
    control_code = sum(control_codes)
    if control_code%101 not in (int(nums[9]), 100):
        ans = False
    assert ans == True


# Generated at 2022-06-25 20:09:14.086002
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    # ValueError: Pattern can't be empty.
    try:
        str_0 = russia_spec_provider_0.snils()
    except ValueError:
        pass


# Generated at 2022-06-25 20:09:19.811266
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    snils = russia_spec_provider.snils()
    assert len(snils) == 11
    assert snils[:3] == '419'


# Generated at 2022-06-25 20:09:22.078057
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    int_1 = RussiaSpecProvider().snils()


# Generated at 2022-06-25 20:09:24.774871
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rus = RussiaSpecProvider()
    assert len(rus.snils()) == 11


# Generated at 2022-06-25 20:09:29.779273
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert len(str_0) == 11


# Generated at 2022-06-25 20:09:33.793187
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert len(str_0) == 11


# Generated at 2022-06-25 20:09:35.693513
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:10:07.563630
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    snils = russia_spec_provider_0.snils()
    assert snils.isnumeric()
    assert len(snils) == 11


# Generated at 2022-06-25 20:10:19.795307
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    random_0 = RussiaSpecProvider()
    str_0 = random_0.snils()
    assert len(str_0) == 11
    str_1 = random_0.snils()
    assert len(str_1) == 11
    str_2 = random_0.snils()
    assert len(str_2) == 11
    str_3 = random_0.snils()
    assert len(str_3) == 11
    str_4 = random_0.snils()
    assert len(str_4) == 11
    str_5 = random_0.snils()
    assert len(str_5) == 11
    str_6 = random_0.snils()
    assert len(str_6) == 11
    str_7 = random_0.snils()
    assert len(str_7)

# Generated at 2022-06-25 20:10:25.398148
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    int_0 = len(str_0)
    # Test if str_0 has 11 symbols
    assert int_0 == 11


# Generated at 2022-06-25 20:10:28.247999
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()



# Generated at 2022-06-25 20:10:33.421501
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:10:37.573646
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:10:39.783400
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider_0 = RussiaSpecProvider()
    str_0 = provider_0.snils()
    assert len(str_0) == 11


# Generated at 2022-06-25 20:10:44.516210
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()

    # Unit test for method inn of class RussiaSpecProvider

# Generated at 2022-06-25 20:10:49.563837
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    string_0 = russia_spec_provider_0.snils()
    assert type(string_0) == str
    assert len(string_0) == 11
    assert string_0.isdigit()


# Generated at 2022-06-25 20:10:54.641326
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert len(str_0) == 11


# Generated at 2022-06-25 20:12:10.980359
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    snils = russia_spec_provider.snils()
    assert snils[0] != '0'


# Generated at 2022-06-25 20:12:16.752443
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert re.search(r'^\d{9}$', str_0)


# Generated at 2022-06-25 20:12:21.407935
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    int_1 = russia_spec_provider_1.snils()


# Generated at 2022-06-25 20:12:22.936878
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    int_0 = RussiaSpecProvider(seed=0).snils()
    assert int_0 == '07702371400'


# Generated at 2022-06-25 20:12:26.278247
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:12:31.380983
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    string_0 = russia_spec_provider_0.snils()
    assert len(string_0) == 11


# Generated at 2022-06-25 20:12:33.428593
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:12:40.391400
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert re.match(r'\d{11}', str_0, re.DOTALL | re.VERBOSE | re.MULTILINE) is not None


# Generated at 2022-06-25 20:12:44.753713
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert len(str_0) == 11, 'Should be 11'


# Generated at 2022-06-25 20:12:49.110241
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    string_0 = russia_spec_provider.snils()
    assert string_0 is not None


# Generated at 2022-06-25 20:16:17.085424
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert str_0 == '41917492600'


# Generated at 2022-06-25 20:16:25.855018
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.enums import Gender

    russia_spec_provider = RussiaSpecProvider()
    snils = russia_spec_provider.snils()

    assert len(snils) == 11, "Incorrect length of snils"



# Generated at 2022-06-25 20:16:27.475487
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:16:32.348577
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    snils = russia_spec_provider.snils()
    assert len(snils) == 11


# Generated at 2022-06-25 20:16:36.102375
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:16:38.981284
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert str_0 != None


# Generated at 2022-06-25 20:16:42.057995
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    str_0 = russia_spec_provider.snils()
    assert len(str_0) == 11
    assert str_0.isdigit()


# Generated at 2022-06-25 20:16:43.585533
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_1 = russia_spec_provider_0.snils()
    assert len(str_1) == 11



# Generated at 2022-06-25 20:16:44.858933
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    string_0 = russia_spec_provider_0.snils()



# Generated at 2022-06-25 20:16:46.283406
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
