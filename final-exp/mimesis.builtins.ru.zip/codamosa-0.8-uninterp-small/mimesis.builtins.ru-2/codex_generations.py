

# Generated at 2022-06-25 20:08:07.350346
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = 'WAL'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    assert russia_spec_provider_0.snils() is not None


# Generated at 2022-06-25 20:08:16.015950
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = 'WAL'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    str_1 =  russia_spec_provider_0.snils()
    assert re.match(r'\b[0-9]{3}[0-9]{3}[0-9]{3}[0-9]{2} \b', str_1) is not None
    str_0 = 'SWH'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    str_2 =  russia_spec_provider_0.snils()

# Generated at 2022-06-25 20:08:18.867516
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider('')
    res = russia_spec_provider.snils()
    assert res is not None


# Generated at 2022-06-25 20:08:20.629269
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    snils_str_0 = '15493625600'
    assert snils_str_0 == RussiaSpecProvider().snils()


# Generated at 2022-06-25 20:08:27.522253
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = 'WAL'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    str_0 = russia_spec_provider_0.snils()
    str_1 = '56612355100'
    str_2 = '57641745600'
    str_3 = '84896516200'
    str_4 = '62883444400'
    str_5 = '28394592200'
    str_6 = '93171066000'
    str_7 = '85885651800'
    str_8 = '84621160400'
    str_9 = '22565511300'
    str_10 = '88682600900'
    str_11 = '70008841000'

# Generated at 2022-06-25 20:08:32.095129
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider(0)
    str_0 = russia_spec_provider_0.snils()
    assert len(str_0) == 11


# Generated at 2022-06-25 20:08:34.796389
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = 'WAL'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    russia_spec_provider_0.snils()

# Generated at 2022-06-25 20:08:38.740276
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    ret = russia_spec_provider_0.snils()
    assert ret


# Generated at 2022-06-25 20:08:47.626507
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = 'CFO'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    assert russia_spec_provider_0.snils() in ['19492264600', '84728704300', '19492264600', '19492264600', '19492264500', '19492264600', '19492264600', '19492264600', '19492264600', '19492264600']
    str_1 = 'HR'
    russia_spec_provider_1 = RussiaSpecProvider(str_1)

# Generated at 2022-06-25 20:08:52.399711
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = 'WAL'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    string_0 = russia_spec_provider_0.snils()
    print(string_0)


# Generated at 2022-06-25 20:09:18.409053
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = 'Q7C'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    str_1 = russia_spec_provider_0.snils()
    assert (str_1 == '91257676600')
    str_2 = russia_spec_provider_0.snils()
    assert (str_2 == '45568666300')
    str_3 = russia_spec_provider_0.snils()
    assert (str_3 == '32891989400')
    str_4 = russia_spec_provider_0.snils()
    assert (str_4 == '13341446300')
    str_5 = russia_spec_provider_0.snils()

# Generated at 2022-06-25 20:09:23.901872
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = 'WAL'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    snils = russia_spec_provider_0.snils()
    assert snils != '', 'snils is empty string'

# Generated at 2022-06-25 20:09:29.028039
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = 'y\x15\x89\x88\xee\xc5\xdb\x7f\xe2\x9d\x0f\x1d\x99'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    str_1 = russia_spec_provider_0.snils()
    str_2 = russia_spec_provider_0.snils()
    str_3 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:09:35.442518
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    instance = RussiaSpecProvider(seed=785922)
    assert instance.snils() == '41917492600'
    assert instance.snils() == '26891853300'
    assert instance.snils() == '26686313000'
    assert instance.snils() == '26986570800'
    assert instance.snils() == '12941117300'


# Generated at 2022-06-25 20:09:41.112329
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = 'L2'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    value_0 = russia_spec_provider_0.snils()
    assert value_0


# Generated at 2022-06-25 20:09:44.767362
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = '81464883020'
    assert RussiaSpecProvider(str_0).snils() == '81464883020'


# Generated at 2022-06-25 20:09:47.271013
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0, str_1 = '', ' '
    RussiaSpecProvider_0 = RussiaSpecProvider(str_0)
    # Representation of test case
    result = RussiaSpecProvider_0.snils()
    assert isinstance(result, str)


# Generated at 2022-06-25 20:09:57.726160
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = 'TEST'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    str_1 = russia_spec_provider_0.snils()
    assert str_1 == '02842646646'
    str_2 = russia_spec_provider_0.snils()
    assert str_2 == '02313331329'
    str_3 = russia_spec_provider_0.snils()
    assert str_3 == '14006781178'
    str_4 = russia_spec_provider_0.snils()
    assert str_4 == '15617638448'
    str_5 = russia_spec_provider_0.snils()
    assert str_5 == '08260280936'

# Generated at 2022-06-25 20:10:04.823867
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = 'P0'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    seed_0 = russia_spec_provider_0.seed
    result_0 = russia_spec_provider_0.snils()
    assert result_0 == '19073721144'


# Generated at 2022-06-25 20:10:08.267308
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = 'XFX'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    snils_0 = russia_spec_provider_0.snils()
    assert snils_0 == '41816233000'


# Generated at 2022-06-25 20:10:47.847525
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = 'L0S0'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    str_1 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:10:52.479805
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = 'WAL'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    str_1 = russia_spec_provider_0.snils()
    assert str_1 == '41917492600', 'Returns incorrect value'


# Generated at 2022-06-25 20:10:56.412513
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = '4VGP'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    str_1 = russia_spec_provider_0.snils()
    assert str_1[0] == '9'
    assert str_1[2] == '6'
    str_2 = russia_spec_provider_0.snils()
    assert str_2[0] == '0'
    assert str_2[3] == '1'
    assert str_2[0] != str_1[0]


# Generated at 2022-06-25 20:11:00.209758
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = 'WAL'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    str_1 = russia_spec_provider_0.snils()
    assert len(str_1) == 11



# Generated at 2022-06-25 20:11:11.288120
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # When
    str_0 = 'WAL'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    actual_result_0 = russia_spec_provider_0.snils()
    # Then
    assert actual_result_0 == '41917492600'
    # When
    str_1 = 'K3U'
    russia_spec_provider_1 = RussiaSpecProvider(str_1)
    actual_result_1 = russia_spec_provider_1.snils()
    # Then
    assert actual_result_1 == '96400053462'


# Generated at 2022-06-25 20:11:15.693705
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Seed = "Test"
    russia_spec_provider_0 = RussiaSpecProvider("Test")
    assert russia_spec_provider_0.snils() == '77388375300'

# Generated at 2022-06-25 20:11:19.749276
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert len(str_0) == (11)

# Generated at 2022-06-25 20:11:22.106483
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = '9'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    str_1 = russia_spec_provider_0.snils()
    assert isinstance(str_1, str)


# Generated at 2022-06-25 20:11:30.125766
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    global str_0
    str_0 = 'WAL'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    str_1 = russia_spec_provider_0.snils()
    
    if len(str_1) < 2:
        print("Test Case 0: Failed")
    else:
        print("Test Case 0: Passed")


# Generated at 2022-06-25 20:11:35.845509
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r_2 = RussiaSpecProvider()
    s_3 = r_2.snils()
    s_3 = str(s_3)
    assert len(s_3) == 11
    s_3 = s_3 + str(0)
    assert int(s_3) > 0


# Generated at 2022-06-25 20:13:03.384034
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_13 = 'QJR'
    russia_spec_provider_13 = RussiaSpecProvider(str_13)
    str_0 = russia_spec_provider_13.snils()
    assert isinstance(str_0, str)


# Generated at 2022-06-25 20:13:08.731477
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = 'Zp5q5_)&C'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    assert russia_spec_provider_0._data['snils'].replace('.', '')


# Generated at 2022-06-25 20:13:12.938398
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    seed = 'test_RussiaSpecProvider'
    russia_spec_provider_0 = RussiaSpecProvider(seed)
    str_0 = russia_spec_provider_0.snils()
    assert str_0 == '21938806155'


# Generated at 2022-06-25 20:13:19.221747
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_1 = '0'
    russia_spec_provider_a = RussiaSpecProvider(str_1)

    str_2 = 'ace2f2cec5'
    russia_spec_provider_b = RussiaSpecProvider(str_2)

    str_3 = 'b07d68e49a'
    russia_spec_provider_c = RussiaSpecProvider(str_3)

    str_4 = 'c7e44fb797'
    russia_spec_provider_d = RussiaSpecProvider(str_4)

    str_5 = '1ed6e8f6fc'
    russia_spec_provider_e = RussiaSpecProvider(str_5)

    str_6 = '3c3bfbabd9'
    russia_spec_provider_f = RussiaSpecProvider

# Generated at 2022-06-25 20:13:25.612511
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = 'WAL'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    str_1 = russia_spec_provider_0.snils()
    str_2 = russia_spec_provider_0.snils()
    try:
        assert str_1 not in str_2
    except AssertionError:
        print("False")


# Generated at 2022-06-25 20:13:32.525878
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = 'THMSL'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    str_1 = 'ZGKSXHXF'
    russia_spec_provider_1 = RussiaSpecProvider(str_1)
    str_2 = 'WJXHME'
    russia_spec_provider_2 = RussiaSpecProvider(str_2)
    str_3 = 'XJF'
    russia_spec_provider_3 = RussiaSpecProvider(str_3)
    str_4 = 'WXVB'
    russia_spec_provider_4 = RussiaSpecProvider(str_4)
    str_5 = 'ZZVX'
    russia_spec_provider_5 = RussiaSpecProvider(str_5)

# Generated at 2022-06-25 20:13:42.269453
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = 'jAg'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    snils_0 = russia_spec_provider_0.snils()
    # Asserts snils_0 == '41917492600'
    str_1 = 'B?qT'
    russia_spec_provider_1 = RussiaSpecProvider(str_1)
    snils_1 = russia_spec_provider_1.snils()
    # Asserts snils_1 == '35676096700'
    str_2 = '!a0,b'
    russia_spec_provider_2 = RussiaSpecProvider(str_2)
    snils_2 = russia_spec_provider_2.snils()
    # Asserts snils_

# Generated at 2022-06-25 20:13:48.903540
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = 'WAL'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    str_1 = russia_spec_provider_0.snils()
    str_2 = russia_spec_provider_0.snils()
    str_3 = russia_spec_provider_0.snils()
    str_4 = russia_spec_provider_0.snils()
    str_5 = russia_spec_provider_0.snils()
    str_6 = russia_spec_provider_0.snils()
    str_7 = russia_spec_provider_0.snils()
    str_8 = russia_spec_provider_0.snils()
    str_9 = russia_spec_provider_0.snils

# Generated at 2022-06-25 20:13:50.754976
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = 'WAL'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    result = russia_spec_provider_0.snils()
    assert result != 0


# Generated at 2022-06-25 20:13:53.601997
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    int_0 = 7745735693
    str_0 = '646548093'
    int_1 = 5240785757

    assert RussiaSpecProvider.snils(int_0) == '646548093'
    assert RussiaSpecProvider.snils(str_0) == '917326181'
    assert RussiaSpecProvider.snils(int_1) == '663461770'


# Generated at 2022-06-25 20:17:46.206979
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
  russia_spec_provider_0 = RussiaSpecProvider()

  # Test
  assert russia_spec_provider_0.snils() == '41917492600'


# Generated at 2022-06-25 20:17:50.895308
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Alternative 1
    russia_spec_provider_1 = RussiaSpecProvider()
    assert russia_spec_provider_1.snils() == '21438453953'
    # Alternative 2
    russia_spec_provider_2 = RussiaSpecProvider(Seed.random())
    assert russia_spec_provider_2.snils() == '65409918454'
