

# Generated at 2022-06-25 20:08:03.543636
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    str_0 = russia_spec_provider_1.snils()


# Generated at 2022-06-25 20:08:08.529475
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert (len(str_0) == 11)


# Generated at 2022-06-25 20:08:10.728259
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    ru_sp = RussiaSpecProvider()
    result = ru_sp.snils()
    assert len(result) == 11

# Generated at 2022-06-25 20:08:13.196419
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    str_1 = russia_spec_provider_1.snils()
    print(f"SNILS: {str_1}")


# Generated at 2022-06-25 20:08:17.325601
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert len(russia_spec_provider_0.snils()) == 11


# Generated at 2022-06-25 20:08:22.132233
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider(seed=1)
    str_0 = russia_spec_provider_0.snils()
    assert str_0 == '06374933211'


# Generated at 2022-06-25 20:08:24.700892
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russiaSpecProvider = RussiaSpecProvider()
    snils = russiaSpecProvider.snils()
    assert len(snils) == 11
    try:
        assert int(snils)
    except ValueError:
        assert False

# Generated at 2022-06-25 20:08:27.224739
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    gen_0 = RussiaSpecProvider()
    str_0 = gen_0.snils()


# Generated at 2022-06-25 20:08:31.801878
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test snils of RussiaSpecProvider."""
    result = RussiaSpecProvider().snils()
    length = len(result)
    assert length == 11
    assert bool(result.isdigit()) == True



# Generated at 2022-06-25 20:08:34.937897
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert len(str_0) == 11
    assert str_0[1] != '9'

# Generated at 2022-06-25 20:09:00.496993
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert isinstance(str_0, str)
    assert len(str_0) in (11, 12)
    assert str_0.isdigit()


# Generated at 2022-06-25 20:09:04.047255
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert str_0 == '41917492600'

# Generated at 2022-06-25 20:09:08.698037
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:09:12.192583
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    str_0 = russia_spec_provider.snils()


# Generated at 2022-06-25 20:09:14.488768
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()



# Generated at 2022-06-25 20:09:18.998658
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    snils = russia_spec_provider.snils()

    assert len(snils) == 11


# Generated at 2022-06-25 20:09:29.128739
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():

    check_sum_0 = 0
    str_0 = '41917492600'

    for i in range(9):
        check_sum_0 += int(str_0[i]) * (9 - i)

    # Checksum for a valid SNILS
    check_sum_0 %= 101

    # Checksum for an invalid SNILS
    check_sum_1 = check_sum_0 + 1

    # Generate SNILSs with invalid, valid checksums
    snils_0 = str_0
    snils_1 = str_0

    if check_sum_0 < 100:
        snils_0 += str(check_sum_0)

    if check_sum_1 < 100:
        snils_1 += str(check_sum_1)

    # SNILS with valid checksum is generated
    assert snils

# Generated at 2022-06-25 20:09:33.792360
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()

    for i in range(10):
        snils_0 = russia_spec_provider_0.snils()
        assert len(snils_0) == 11


# Generated at 2022-06-25 20:09:38.407020
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert (russia_spec_provider_0.snils() == "41917492600" or russia_spec_provider_0.snils() == "89418178800" or russia_spec_provider_0.snils() == "15566091100" or russia_spec_provider_0.snils() == "40418638100" or russia_spec_provider_0.snils() == "45122682900")

# Generated at 2022-06-25 20:09:39.796826
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()



# Generated at 2022-06-25 20:10:22.756527
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert len(str_0) == 11


# Generated at 2022-06-25 20:10:28.428453
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert str_0 is not None
    assert isinstance(str_0, str)
    assert len(str_0) == 11
    assert str_0.isdigit()


# Generated at 2022-06-25 20:10:33.067446
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()

# Generated at 2022-06-25 20:10:37.187070
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:10:40.158906
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert str_0 != None


# Generated at 2022-06-25 20:10:44.031004
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()



# Generated at 2022-06-25 20:10:48.378601
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert len(str_0) == 11


# Generated at 2022-06-25 20:10:52.726090
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert len(str_0) == 11
    assert str_0 != '000000000'
    assert str_0 != '00000000001'
    assert str_0 != '123'


# Generated at 2022-06-25 20:10:56.710095
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:10:59.480623
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:12:33.428581
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert type(str_0) == str


# Generated at 2022-06-25 20:12:39.310598
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    result_0 = russia_spec_provider_0.snils()
    assert isinstance(result_0, str)
    assert (len(result_0) == 11)


# Generated at 2022-06-25 20:12:43.317739
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    assert len(russia_spec_provider.snils()) == 11


# Generated at 2022-06-25 20:12:48.893152
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    snils_0 = russia_spec_provider_0.snils()
    assert len(snils_0) == 11


# Generated at 2022-06-25 20:12:54.248361
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russian_spec_provider = RussiaSpecProvider()
    snils = russian_spec_provider.snils()
    assert len(str(snils)) == 11
    assert str(snils)[-2:] == str(int(str(snils)[:-2]) % 101)


# Generated at 2022-06-25 20:12:57.259168
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russiaspecprovider_0 = RussiaSpecProvider()
    assert len(russiaspecprovider_0.snils()) == 11
    assert russiaspecprovider_0.snils() == '93938486583'


# Generated at 2022-06-25 20:13:01.788752
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    length = len(snils)
    if (snils < 10000000000 or snils > 99999999999) or length != 11:
        print("snils() failed!")
    else:
        print("snils() success!")


# Generated at 2022-06-25 20:13:04.078940
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider_0 = RussiaSpecProvider()
    snils;
    snils = provider_0.snils()
    return


# Generated at 2022-06-25 20:13:09.986727
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider(seed=0)
    # Assert.equal(russia_spec_provider_0.snils(), "41917492600")
    assert russia_spec_provider_0.snils() == "41917492600"

# Generated at 2022-06-25 20:13:13.665668
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert str_0 != None
    assert str_0 != ''


# Generated at 2022-06-25 20:17:22.071083
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:17:25.338542
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    for i in range (0, 100):
        str_0 = russia_spec_provider_0.snils()
        print("snils = ", str_0)


# Generated at 2022-06-25 20:17:27.887805
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Create the object of class RussiaSpecProvider
    russia_spec_provider_0 = RussiaSpecProvider()
    # Call the method snils
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:17:30.753059
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider(seed=59).snils() == "41917492600"


# Generated at 2022-06-25 20:17:33.463362
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Arrange
    russia_spec_provider = RussiaSpecProvider()

    # Act
    result = russia_spec_provider.snils()

    # Assert
    assert isinstance(result, str), result



# Generated at 2022-06-25 20:17:35.700424
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert len(str_0) == 11


# Generated at 2022-06-25 20:17:37.472259
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert str_0


# Generated at 2022-06-25 20:17:38.901359
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:17:40.825519
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert len(str_0) == 11



# Generated at 2022-06-25 20:17:42.733717
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    k1 = RussiaSpecProvider().snils()
    k2 = RussiaSpecProvider().snils()
    assert(k1 != k2)

