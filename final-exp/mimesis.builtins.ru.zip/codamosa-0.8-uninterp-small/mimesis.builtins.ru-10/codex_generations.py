

# Generated at 2022-06-25 20:08:06.973652
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider().snils() == '81038124914'


# Generated at 2022-06-25 20:08:15.690225
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    failed = 0
    for i in range(100):
        russia_spec_provider_1 = RussiaSpecProvider()
        snils = russia_spec_provider_1.snils()
        control_sum = 0
        for k in range(9):
            control_sum += int(snils[k]) * (9 - k)
        if control_sum < 100:
            if int(snils[9]) != control_sum:
                print("FAILED", snils)
                failed += 1
        if control_sum == 100 or control_sum == 101:
            if int(snils[9]) != 0 or int(snils[10]) != 0:
                print("FAILED", snils)
                failed += 1
        if control_sum > 101:
            control_sum = control_sum % 101

# Generated at 2022-06-25 20:08:21.326250
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    num = russia_spec_provider.snils()
    assert isinstance(num, str)
    assert len(num) == 11
    assert num[0] != 0
    assert num[2] != 0
    assert num[4] != 0
    assert num[6] != 0
    assert num[8] != 0
    assert num[9] != 0
    assert num[10] != 0



# Generated at 2022-06-25 20:08:26.766964
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_4 = RussiaSpecProvider()
    snils = russia_spec_provider_4.snils()
    checksum = 0
    value_snils_11 = int(snils[-2:])
    value_snils_10 = int(snils[-3])
    a = [int(snils[0]) * 9, int(snils[1]) * 8, int(snils[2]) * 7, int(snils[3]) * 6, int(snils[4]) * 5, int(snils[5]) * 4, int(snils[6]) * 3, int(snils[7]) * 2, int(snils[8])]
    for i in range(0,len(a)):
        checksum = checksum + a[i]

# Generated at 2022-06-25 20:08:30.793489
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    assert russia_spec_provider.snils() == '17381839400' 


# Generated at 2022-06-25 20:08:35.872624
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    test_1 = russia_spec_provider_1.snils()
    test_2 = russia_spec_provider_1.snils()
    # Make sure that snils is not constant
    assert test_1 != test_2
    # Test length
    assert len(test_1) == 11


# Generated at 2022-06-25 20:08:39.510429
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert russia_spec_provider_0.snils() == '41917492600'


# Generated at 2022-06-25 20:08:42.650344
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    snils = russia_spec_provider_0.snils()



# Generated at 2022-06-25 20:08:45.971229
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert russia_spec_provider_0.snils() == '41917492600'


# Generated at 2022-06-25 20:08:50.246051
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    assert len(russia_spec_provider.snils()) == 11
    assert type(russia_spec_provider.snils()) is str


# Generated at 2022-06-25 20:09:10.942280
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert len(russia_spec_provider_0.snils()) == 11


# Generated at 2022-06-25 20:09:15.163890
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Create a RussiaSpecProvider instance
    russia_spec_provider_0 = RussiaSpecProvider()
    # Get a snils
    snils_0: str = russia_spec_provider_0.snils()
    # Assert a snils
    assert len(snils_0) == 11


# Generated at 2022-06-25 20:09:18.567825
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russiaspecprovider = RussiaSpecProvider()
    russiaspecprovider.snils.__wrapped__()


# Generated at 2022-06-25 20:09:21.408114
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    snils = RussiaSpecProvider().snils()
    assert snils.strip().isdigit()


# Generated at 2022-06-25 20:09:25.692925
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    random_0 = Random()
    russia_spec_provider_0 = RussiaSpecProvider(random_0)
    assert russia_spec_provider_0.snils() == '41728591000'


# Generated at 2022-06-25 20:09:34.958237
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_snils = RussiaSpecProvider()
    snils_0=russia_spec_provider_snils.snils()
    assert len(snils_0) == 11, "Length of snils is {}".format(len(snils_0))
    print(snils_0)
    for i in range(10):
        assert snils_0 == russia_spec_provider_snils.snils(), "Snils number is {} ".format(snils_0)


# Generated at 2022-06-25 20:09:45.121265
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Initialize instance of RussiaSpecProvider
    russia_spec_provider = RussiaSpecProvider()

    # Generate snils with special algorithm
    snils = russia_spec_provider.snils()

    # Check snils length
    if not len(snils) == 11:
        raise ValueError("Invalid snils length")

    # Check each digit of snils
    if not all(i.isdigit() for i in snils):
        raise ValueError("Invalid snils")



# Generated at 2022-06-25 20:09:51.031901
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    russia_spec_provider_1 = RussiaSpecProvider()
    assert russia_spec_provider_1.snils() == '41917492600'


# Generated at 2022-06-25 20:09:54.518346
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    my_russiaspecprovider = RussiaSpecProvider()
    x = my_russiaspecprovider.snils()
    assert isinstance(x, str)


# Generated at 2022-06-25 20:09:56.466230
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert (len(russia_spec_provider_0.snils()) == 11)


# Generated at 2022-06-25 20:10:35.770118
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    output = russia_spec_provider_0.snils()
    assert(isinstance(output, str))
    assert(len(output) == 11)


# Generated at 2022-06-25 20:10:37.505531
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    snils = russia_spec_provider.snils()
    assert snils == '41917492600'


# Generated at 2022-06-25 20:10:43.463195
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    snils = russia_spec_provider_0.snils()
    one_numbers = [int(d) for d in str(snils)]
    two_numbers = []
    for i in range(9, 0, -1):
        two_numbers.append(one_numbers[9 - i] * i)
    two_numbers = sum(two_numbers) % 101
    if two_numbers == 100:
        two_numbers = 0
    assert snils[:9] + str(two_numbers) == snils


# Generated at 2022-06-25 20:10:47.238250
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    assert len(russia_spec_provider_1.snils()) == 11


# Generated at 2022-06-25 20:10:50.606731
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    russia_spec_provider_0 = RussiaSpecProvider()
    assert isinstance(russia_spec_provider_0.snils(), str)
    assert len(russia_spec_provider_0.snils()) == 11


# Generated at 2022-06-25 20:10:57.254842
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    expected_value_0 = russia_spec_provider_0.snils()
    actual_value_0 = '41917492600'
    assert expected_value_0 == actual_value_0


# Generated at 2022-06-25 20:11:00.947080
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    inp_snils = '41917492600'
    assert russia_spec_provider_0.snils() == inp_snils, 'Test_russia_spec_provider: snils()'


# Generated at 2022-06-25 20:11:07.124457
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()

    assert(russia_spec_provider_0.snils() != None)
    assert(russia_spec_provider_0.snils() == '41917492600')

# Generated at 2022-06-25 20:11:10.442519
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()

    result = russia_spec_provider.snils()
    assert len(result) == 11
    assert isinstance(result, str)


# Generated at 2022-06-25 20:11:15.347898
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert re.match(r'^[0-9]{11}$', russia_spec_provider_0.snils())

# Generated at 2022-06-25 20:12:44.837722
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Create the object of RussiaSpecProvider
    russia_spec_provider = RussiaSpecProvider()
    # Obtain the snils
    snils = russia_spec_provider.snils()
    assert len(snils) == 11


# Generated at 2022-06-25 20:12:52.801175
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    russia_spec_provider_0._random.seed(7)
    expected = '41917492600'
    actual = russia_spec_provider_0.snils()
    print(russia_spec_provider_0._random)
    assert actual == expected


# Generated at 2022-06-25 20:12:55.864679
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    result = provider.snils()
    assert (result == provider.snils())



# Generated at 2022-06-25 20:12:58.656733
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    snils_0 = russia_spec_provider_0.snils()
    assert len(snils_0) == 11


# Generated at 2022-06-25 20:13:01.587059
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russiaSpecProvider_0 = RussiaSpecProvider()
    russiaSpecProvider_0.snils()
    assert(isinstance(russiaSpecProvider_0.snils(), str))


# Generated at 2022-06-25 20:13:04.042439
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    print(russia_spec_provider.snils())



# Generated at 2022-06-25 20:13:08.425250
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    snils = russia_spec_provider.snils()
    assert len(snils) == 11


# Generated at 2022-06-25 20:13:11.048953
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    print(russia_spec_provider_0.snils())


# Generated at 2022-06-25 20:13:13.168783
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert re.match(r'^\d{9}$', RussiaSpecProvider().snils())

# Test case for method inn of class RussiaSpecProvider

# Generated at 2022-06-25 20:13:16.060237
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    for _ in range(0, 100):
        russia_spec_provider = RussiaSpecProvider()
        russian_snils = russia_spec_provider.snils()
        assert type(russian_snils) == str


# Generated at 2022-06-25 20:14:52.336554
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert russia_spec_provider_0.snils() == '41917492600'


# Generated at 2022-06-25 20:14:55.191700
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert isinstance(russia_spec_provider_0.snils(), str), 'Returned type of RussiaSpecProvider.snils() is not str!'


# Generated at 2022-06-25 20:14:57.240788
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert isinstance(russia_spec_provider_0.snils(), str)
    assert len(russia_spec_provider_0.snils()) == 11


# Generated at 2022-06-25 20:14:58.191471
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert len(RussiaSpecProvider().snils()) == 11


# Generated at 2022-06-25 20:15:00.144549
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert russia_spec_provider_0.snils() == '41917492600'


# Generated at 2022-06-25 20:15:09.417013
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_russia_spec_provider_0 = russia_spec_provider_0.snils()
    assert len(str_russia_spec_provider_0) == 11


# Generated at 2022-06-25 20:15:12.867765
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    snils_example = russia_spec_provider.snils()
    assert not (len(snils_example) != 11 and len(snils_example) != 14)



# Generated at 2022-06-25 20:15:15.548495
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert russia_spec_provider_0.snils() == russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:15:19.984140
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    assert russia_spec_provider_1.snils() == "46290944100"


# Generated at 2022-06-25 20:15:25.722545
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider(seed=100)
    russia_spec_provider_2 = RussiaSpecProvider(seed=100)
    assert russia_spec_provider_1.snils() == russia_spec_provider_2.snils()
    russia_spec_provider_3 = RussiaSpecProvider(seed=101)
    assert russia_spec_provider_1.snils() != russia_spec_provider_3.snils()
