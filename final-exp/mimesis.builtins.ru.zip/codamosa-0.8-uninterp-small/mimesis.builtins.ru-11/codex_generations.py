

# Generated at 2022-06-25 20:08:12.277775
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = '}S.|m65'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    str_1 = russia_spec_provider_0.snils()
    str_2 = russia_spec_provider_0.snils()
    str_3 = russia_spec_provider_0.snils()
    str_4 = russia_spec_provider_0.snils()
    str_5 = russia_spec_provider_0.snils()
    str_6 = russia_spec_provider_0.snils()
    str_7 = russia_spec_provider_0.snils()
    str_8 = russia_spec_provider_0.snils()
    str_9 = russia_spec_provider_

# Generated at 2022-06-25 20:08:20.653878
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider(seed=7)
    assert russia_spec_provider_0.snils() == '63325690875'
    assert russia_spec_provider_1.snils() == '18277831200'
    assert russia_spec_provider_2.snils() == '73635292800'

# Generated at 2022-06-25 20:08:23.880404
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = '5fJjJo.y'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    assert russia_spec_provider_0.snils() == '87425423500'


# Generated at 2022-06-25 20:08:28.769358
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = '\njS`<8'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    snils_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:08:35.003057
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = '$u*M/f`&'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    str_1 = russia_spec_provider_0.snils()
    assert str_1 == '15261584700'


if __name__ == '__main__':
    test_case_0()
    test_RussiaSpecProvider_snils()

# Generated at 2022-06-25 20:08:41.232648
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = 'Q#}@t^{'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    str_1 = russia_spec_provider_0.snils()
    print(str_1)
    print(len(str_1))


# Generated at 2022-06-25 20:08:44.810656
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = '}S.|m65'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    str_1 = russia_spec_provider_0.snils()



# Generated at 2022-06-25 20:08:50.953920
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = '}S.|m65'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    str_1 = russia_spec_provider_0.snils()
    assert str_1 == '41917492600'


# Generated at 2022-06-25 20:08:54.053637
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = '{T&<'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    str_1 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:09:00.061041
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = '}S.|m65'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    str_1 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:09:20.714762
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = ''
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    str_1 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:09:25.935368
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert russia_spec_provider_0.snils() in ("50172056808", "28978817828", "70938019941", "06803501526", "90497798179")



# Generated at 2022-06-25 20:09:28.307621
# Unit test for method snils of class RussiaSpecProvider

# Generated at 2022-06-25 20:09:31.752772
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert '{:09}'.format(russia_spec_provider_0.random.randint(0, 999999999)) \
                == russia_spec_provider_0.snils()
    assert '{:09}'.format(russia_spec_provider_0.random.randint(0, 999999999)) \
                == russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:09:34.774896
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:09:44.721592
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = 'K2+<:_cG/'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    str_1 = russia_spec_provider_0.ogrn()
    str_2 = russia_spec_provider_0.inn()
    str_3 = russia_spec_provider_0.snils()
    str_4 = russia_spec_provider_0.series_and_number()


# Generated at 2022-06-25 20:09:47.449506
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = 'F1wVn^x'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    str_1 = russia_spec_provider_0.snils()
    assert bool(str_1.startswith(str_0))


# Generated at 2022-06-25 20:09:50.966720
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider(seed=None)
    str_1 = russia_spec_provider_0.snils()




# Generated at 2022-06-25 20:09:55.264075
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # seed = '}S.|m65'
    seed = 'S)0STH'
    russia_spec_provider = RussiaSpecProvider(seed)
    assert russia_spec_provider.snils() == '74940181470'

# Generated at 2022-06-25 20:10:01.605871
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = 'W&XvT,~sD'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    assert len(russia_spec_provider_0.snils()) == 11


# Generated at 2022-06-25 20:10:39.926902
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = '>|tZSI5'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    assert russia_spec_provider_0.snils() == '6628912631'


# Generated at 2022-06-25 20:10:42.745129
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = '05t<*JtRm'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    str_1 = russia_spec_provider_0.ogrn()    
    assert str_1 == '4715113303725'



# Generated at 2022-06-25 20:10:51.047527
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from random import seed
    from mimesis.enums import Gender

    seed(0)
    russia_spec_provider_0 = RussiaSpecProvider(0)
    str_0 = russia_spec_provider_0.snils()
    print(str_0)
    assert str_0 == '6316351230'

    seed(0)
    russia_spec_provider_1 = RussiaSpecProvider(0)
    str_1 = russia_spec_provider_1.snils(gender=Gender.MALE)
    print(str_1)
    assert str_1 == '2103444844'


# Generated at 2022-06-25 20:10:57.675969
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    ru_provider = RussiaSpecProvider()

    snils = ru_provider.snils()
    assert len(snils) == 11, "Wrong snils length"
    assert snils[9] == snils[10], "Wrong snils control digits"



# Generated at 2022-06-25 20:11:00.915099
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = '3=w'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    str_1 = russia_spec_provider_0.ogrn()
    assert str_1 == '2284621407509'


# Generated at 2022-06-25 20:11:03.233631
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    pass


# Generated at 2022-06-25 20:11:06.116997
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = '2WTD(8IN#'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    str_1 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:11:08.918403
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = '2N}c+G|'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    result_0 = russia_spec_provider_0.snils()
    assert result_0 == '82541321425'


# Generated at 2022-06-25 20:11:15.146494
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = 'g(z6*2`P'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    str_1 = russia_spec_provider_0.snils()
    assert (str_1 == '63324336187')


# Generated at 2022-06-25 20:11:23.008726
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = 'Qa,6x'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    str_1 = russia_spec_provider_0.snils()
    word_0 = 'рcjS'
    str_2 = '1zz3l'
    russia_spec_provider_1 = RussiaSpecProvider(str_2)
    str_3 = russia_spec_provider_1.snils()
    str_4 = './aH'
    russia_spec_provider_2 = RussiaSpecProvider(str_4)
    str_5 = russia_spec_provider_2.snils()
    bool_0 = bool(bool_0)
    bool_1 = bool(bool_1)

# Generated at 2022-06-25 20:12:53.599808
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert len(str_0) == 11


# Generated at 2022-06-25 20:12:57.008146
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    get_seed(russia_spec_provider_0)
    assert len(russia_spec_provider_0.snils()) == 11


# Generated at 2022-06-25 20:13:04.832694
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    seed_0 = 'q'
    seed_1 = 'p'
    seed_2 = 'o'
    seed_3 = 'U'
    seed_4 = 'g'
    seed_5 = 'Z'
    seed_6 = 'H'
    seed_7 = 'J'
    seed_8 = 'E'
    seed_9 = 'C'
    seed = ''
    for index in range(0, 10):
        if index == 0:
            seed = seed_0
        elif index == 1:
            seed = seed_1
        elif index == 2:
            seed = seed_2
        elif index == 3:
            seed = seed_3
        elif index == 4:
            seed = seed_4
        elif index == 5:
            seed = seed_5

# Generated at 2022-06-25 20:13:08.191963
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert len(RussiaSpecProvider().snils()) == 11


# Generated at 2022-06-25 20:13:17.207449
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = '\'-,$'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    str_1 = russia_spec_provider_0.snils()
    assert str_1 == '58291728800'
    str_2 = russia_spec_provider_0.snils()
    assert str_2 == '40607318800'
    str_3 = russia_spec_provider_0.snils()
    assert str_3 == '39321328800'
    str_4 = russia_spec_provider_0.snils()
    assert str_4 == '24851311700'
    str_5 = russia_spec_provider_0.snils()
    assert str_5 == '13706923400'
    str_

# Generated at 2022-06-25 20:13:28.389457
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = '6Xm]O:$}Sl'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    str_1 = russia_spec_provider_0.snils()

# Generated at 2022-06-25 20:13:34.240508
# Unit test for method snils of class RussiaSpecProvider

# Generated at 2022-06-25 20:13:36.647865
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    snils = russia_spec_provider_0.snils()
    assert snils is not None


# Generated at 2022-06-25 20:13:45.379287
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Verify that the first three digits of the returned result do not begin with zero (so that they can be considered a valid social security number)
    str_0 = '}S.|m65'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    str_1 = russia_spec_provider_0.snils()
    str_2 = str_1[:3]
    try:
        assert str_2 == '419'
    except:
        bool_0 = False
    else:
        bool_0 = True
    assert bool_0

    # Verify that the last digit of the returned result is a control number for the social security number (to ensure the validity of the social security number)
    str_0 = '}S.|m65'
    russia_spec_provider_0 = RussiaSpecProvider

# Generated at 2022-06-25 20:13:50.095222
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = 'russia_provider'
    str_1 = russia_spec_provider_0.snils()
    assert str_0 == str_1
    str_0 = 'russia_provider'
    str_1 = russia_spec_provider_0.snils()
    assert str_0 == str_1
    str_0 = 'russia_provider'
    str_1 = russia_spec_provider_0.snils()
    assert str_0 == str_1


# Generated at 2022-06-25 20:17:40.720226
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    seed = str
    russia_spec_provider = RussiaSpecProvider(seed)
    result = russia_spec_provider.snils()
    assert result is not None


# Generated at 2022-06-25 20:17:44.177886
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    num = 0
    while num < 6:
        russia_spec_provider = RussiaSpecProvider()
        str_0 = russia_spec_provider.snils()
        len_str_0 = len(str_0)
        if len_str_0 == 11:
            num = num + 1
        else:
            assert 1 == 0


# Generated at 2022-06-25 20:17:51.548958
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = 'Y'
    russia_spec_provider_0 = RussiaSpecProvider(str_0)
    assert russia_spec_provider_0.snils() == '7375360900', 'Should be "7375360900"'
    str_1 = '8I'
    russia_spec_provider_0 = RussiaSpecProvider(str_1)
    assert russia_spec_provider_0.snils() == '5918078200', 'Should be "5918078200"'
    str_2 = 'Z#'
    russia_spec_provider_0 = RussiaSpecProvider(str_2)
    assert russia_spec_provider_0.snils() == '1596006100', 'Should be "1596006100"'
    str_3 = 'Z]'
    russia