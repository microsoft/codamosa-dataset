

# Generated at 2022-06-25 20:08:04.700606
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:08:06.977399
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:08:09.429802
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    import re
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert re.match(
        r'\d+', str_0)


# Generated at 2022-06-25 20:08:12.500521
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:08:18.924333
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert len(str_0) == 11
    assert str_0[0] != '0'


# Generated at 2022-06-25 20:08:22.705302
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert (str_0 is not None)


# Generated at 2022-06-25 20:08:27.294364
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    str_1 = russia_spec_provider_1.snils()
    print("str_1 : ", str_1)


# Generated at 2022-06-25 20:08:34.396648
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider
    """
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    str_1 = russia_spec_provider_0.snils()
    assert str_0 == '41917492600'
    assert str_1 == '41917492600'



# Generated at 2022-06-25 20:08:39.089168
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    ru = RussiaSpecProvider()
    snils_0 = ru.snils()
    snils_1 = ru.snils()
    assert(snils_0 == snils_1)


# Generated at 2022-06-25 20:08:42.789590
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert len(str_0) > 0

# Generated at 2022-06-25 20:09:01.824513
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_1 = RussiaSpecProvider().snils()
    pass


# Generated at 2022-06-25 20:09:04.440415
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_1 = russia_spec_provider_0.snils()



# Generated at 2022-06-25 20:09:08.562001
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    str_1 = russia_spec_provider_1.snils()

# Generated at 2022-06-25 20:09:12.836704
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    assert len(r.snils()) == 11
    assert str.isdigit(r.snils())

# Generated at 2022-06-25 20:09:15.981776
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    snils = russia_spec_provider.snils()
    assert len(snils) == 11
    assert not snils.startswith('0')
    assert snils[0:3] < snils[3:8]


# Generated at 2022-06-25 20:09:20.314693
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_snils = RussiaSpecProvider()
    str_1 = russia_spec_provider_snils.snils()
    assert str_1 is not None


# Generated at 2022-06-25 20:09:25.831803
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    str_1 = russia_spec_provider_1.snils()
    assert str_1[0:9] != '000000000'
    assert str_1[0:9] != '999999999'


# Generated at 2022-06-25 20:09:27.883885
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert str_0 == '41917492600'

# Generated at 2022-06-25 20:09:33.857928
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert len(str_0) == 11
    assert not re.match('[a-zA-Z]', str_0)


# Generated at 2022-06-25 20:09:36.155350
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert len(str_0) is 11


# Generated at 2022-06-25 20:10:18.340102
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider(seed=None)
    str_0 = russia_spec_provider_0.snils()
    assert isinstance(str_0, str)



# Generated at 2022-06-25 20:10:21.086199
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert not RussiaSpecProvider().snils() == None


# Generated at 2022-06-25 20:10:25.398142
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    snils = russia_spec_provider_0.snils()
    assert len(snils) == 11



# Generated at 2022-06-25 20:10:28.247730
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert len(russia_spec_provider_0.snils()) == 11


# Generated at 2022-06-25 20:10:33.432920
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    snils = russia_spec_provider.snils()
    assert isinstance(snils, str)


# Generated at 2022-06-25 20:10:34.700991
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider().snils().__class__ == str


# Generated at 2022-06-25 20:10:37.642884
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()
    assert len(rsp.snils()) == 11


# Generated at 2022-06-25 20:10:40.414673
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert str_0.__len__() == 11


# Generated at 2022-06-25 20:10:41.486153
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    ru = RussiaSpecProvider()
    ru.snils()


# Generated at 2022-06-25 20:10:44.443372
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """
    Unit test for method snils of class RussiaSpecProvider
    """
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert str_0.isdigit() and len(str_0) == 11


# Generated at 2022-06-25 20:12:22.124659
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Create instance
    russia_spec_provider_0 = RussiaSpecProvider()
    # Call method
    str_0 = russia_spec_provider_0.snils()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 20:12:23.949217
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    obj = RussiaSpecProvider()
    assert len(obj.snils()) == 11

# Generated at 2022-06-25 20:12:27.798661
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    str_1 = russia_spec_provider_1.snils()
    assert len(str_1) == 11


# Generated at 2022-06-25 20:12:32.049674
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:12:39.583331
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    str_1 = russia_spec_provider_1.snils()
    if str_1 == '41917492600':
        str_1 = '41917492601'
    else:
        str_1 = '41917492600'


# Generated at 2022-06-25 20:12:44.387339
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    for i in range(5):
        str_0 = russia_spec_provider_0.inn()
        assert (len(str_0) == 12)


# Generated at 2022-06-25 20:12:50.543585
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    str = russia_spec_provider.snils()
    print('SNILS: ' + str)

if __name__ == '__main__':
    test_case_0()
    RussiaSpecProvider().snils()

# Generated at 2022-06-25 20:12:54.192190
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    if str_0:
        pass


# Generated at 2022-06-25 20:12:56.916470
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert str_0 is not None


# Generated at 2022-06-25 20:12:59.353774
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russian_provider_0 = RussiaSpecProvider()
    str_0 = russian_provider_0.snils()
    assert len(str_0) == 11
