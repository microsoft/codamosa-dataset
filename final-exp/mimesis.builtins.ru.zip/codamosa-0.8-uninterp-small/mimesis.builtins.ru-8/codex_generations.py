

# Generated at 2022-06-25 20:08:02.403858
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider().snils() == '41917492600'

# Generated at 2022-06-25 20:08:11.885070
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider(seed=42)
    russia_spec_provider_2 = RussiaSpecProvider(seed=42)

    result_1 = russia_spec_provider_1.snils()
    result_2 = russia_spec_provider_2.snils()

    assert result_1 == '90322656600'
    assert result_2 == '90322656600'


# Generated at 2022-06-25 20:08:23.270272
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    snils_1 = russia_spec_provider_1.snils()
    snils_2 = russia_spec_provider_1.snils()
    assert isinstance(snils_1, str), \
        'Should be str type'
    assert snils_1 != snils_2, \
        'Should be different strings'
    assert snils_1 + snils_2 == '4191749260049932100', \
        'Should be equal 41917492600 + 49932100'


# Generated at 2022-06-25 20:08:27.568593
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    snils_0 = russia_spec_provider_0.snils()
    assert snils_0 is not None


# Generated at 2022-06-25 20:08:34.682732
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russian_provider = RussiaSpecProvider()
    for _ in range(0, 1000):
        snils = russian_provider.snils()
        assert len(snils) == 11
        assert snils[0:3] != '000'
        assert snils[3:6] != '000'
        assert snils[6:9] != '000'
        int(snils[9:11])



# Generated at 2022-06-25 20:08:40.301866
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Arrange
    rssp = RussiaSpecProvider()

    # Act
    snils = rssp.snils()

    # Assert
    assert isinstance(snils, str)
    assert len(snils) == 11
    assert snils != ''


# Generated at 2022-06-25 20:08:44.183674
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    assert len(russia_spec_provider_1.snils()) == 11
    assert type(russia_spec_provider_1.snils()) is str
    

# Generated at 2022-06-25 20:08:46.856125
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rus_prov_0 = RussiaSpecProvider()
    print(rus_prov_0.snils())


# Generated at 2022-06-25 20:08:53.120493
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    global answer_snils
    answer_snils = ['41917492600']
    for i in range(len(answer_snils)):
        RussiaSpecProvider_snils0 = RussiaSpecProvider(seed=i)
        assert RussiaSpecProvider_snils0.snils() == answer_snils[i]


# Generated at 2022-06-25 20:09:05.756715
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russp = RussiaSpecProvider()
    assert len(russp.snils()) == 11
    assert russp.snils()[0] != russp.snils()[1]
    assert russp.snils()[1] != russp.snils()[2]
    assert russp.snils()[2] != russp.snils()[3]
    assert russp.snils()[3] != russp.snils()[4]
    assert russp.snils()[4] != russp.snils()[5]
    assert russp.snils()[5] != russp.snils()[6]
    assert russp.snils()[6] != russp.snils()[7]
    assert russp.sn

# Generated at 2022-06-25 20:09:24.651667
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    russia_spec_provider_0.random.seed(444444444)
    assert russia_spec_provider_0.snils() == '41917492600'


# Generated at 2022-06-25 20:09:29.709066
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert russia_spec_provider_0.snils() == '41917492600'

test_case_0()

# Generated at 2022-06-25 20:09:38.698887
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()

# Generated at 2022-06-25 20:09:42.537931
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():

    russia_spec_provider = RussiaSpecProvider()
    assert russia_spec_provider.snils() == '12857654328'


# Generated at 2022-06-25 20:09:45.901852
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test case for RussiaSpecProvider.snils"""
    russia_spec_provider_0 = RussiaSpecProvider()
    assert russia_spec_provider_0.snils() == '41917492600'


# Generated at 2022-06-25 20:09:52.225283
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Given
    russia_spec_provider_0 = RussiaSpecProvider()

    # When
    result = russia_spec_provider_0.snils()

    # Then
    assert isinstance(result, str)
    assert re.match(r'\d{11}', result)


# Generated at 2022-06-25 20:09:56.888832
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    snils = russia_spec_provider.snils()
    snils_1 = russia_spec_provider.snils()
    print('Snils:', snils)
    print('Snils:', snils_1)
    assert isinstance(snils, str)



# Generated at 2022-06-25 20:10:09.358397
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider(seed=42)
    snils_1_result = russia_spec_provider_1.snils()
    snils_1_expected = "41917492600"
    assert snils_1_result == snils_1_expected, "snils method has a problem"
    russia_spec_provider_2 = RussiaSpecProvider(seed=59)
    snils_2_result = russia_spec_provider_2.snils()
    snils_2_expected = "49003397015"
    assert snils_2_result == snils_2_expected, "snils method has a problem"
    russia_spec_provider_3 = RussiaSpecProvider(seed=93)
    snils_3_result = russia_spec_

# Generated at 2022-06-25 20:10:12.919562
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    assert(russia_spec_provider.snils() not in ("", None))


# Generated at 2022-06-25 20:10:17.795692
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Test case 0
    russia_spec_provider_0 = RussiaSpecProvider()
    assert isinstance(russia_spec_provider_0.snils(), str)


# Generated at 2022-06-25 20:10:50.045527
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    snils = russia_spec_provider.snils()
    if (snils == '41917492600'):
        print (snils + 'valid snils')
    else:
        print (snils + 'non valid snils')


# Generated at 2022-06-25 20:11:00.250924
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()

    # Проверка генерации корректного СНИЛС
    assert len(russia_spec_provider.snils()) == 11
    assert russia_spec_provider.snils().isdigit()
    assert russia_spec_provider.snils()[:3] != '000'
    assert int(russia_spec_provider.snils()[3:]) != 0


# Generated at 2022-06-25 20:11:03.233652
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert len(RussiaSpecProvider().snils()) == 11



# Generated at 2022-06-25 20:11:07.954325
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_instance = RussiaSpecProvider()
    assert russia_spec_provider_instance.snils() == russia_spec_provider_instance.snils()


# Generated at 2022-06-25 20:11:14.129716
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    snils_1 = russia_spec_provider_1.snils()
    snils_1_type = type(snils_1)
    snils_1_len = len(snils_1)
    russia_spec_provider_2 = RussiaSpecProvider()
    snils_2 = russia_spec_provider_2.snils()
    snils_2_type = type(snils_2)
    snils_2_len = len(snils_2)
    russia_spec_provider_3 = RussiaSpecProvider()
    snils_3 = russia_spec_provider_3.snils()
    snils_3_type = type(snils_3)

# Generated at 2022-06-25 20:11:17.772242
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    global snils_1
    snils_1 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:11:20.419061
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert russia_spec_provider_0.snils() == '41917492600'


# Generated at 2022-06-25 20:11:25.002253
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    '41917492600' == russia_spec_provider.snils()


# Generated at 2022-06-25 20:11:31.450499
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    snils = russia_spec_provider_0.snils()
    assert int(snils[:9]) % 101 < 100
    assert snils[9] == str((sum(int(snils[x]) * (9 - x) for x in range(9)) % 101) % 10)
    

# Generated at 2022-06-25 20:11:36.582035
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    assert russia_spec_provider_1.snils() != ''


# Generated at 2022-06-25 20:12:49.503811
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    snils = russia_spec_provider_0.snils()
    assert snils == '41917492600'


# Generated at 2022-06-25 20:12:50.444147
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider().snils() % 101 == 0


# Generated at 2022-06-25 20:12:53.601674
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:12:58.249610
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rus_sp_0 = RussiaSpecProvider()
    result_get_snils = rus_sp_0.snils()
    assert len(result_get_snils) == 11
    result_check_snils = rus_sp_0.snils()
    assert len(result_check_snils) == 11


# Generated at 2022-06-25 20:13:01.827324
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russian_spec_provider = RussiaSpecProvider()
    # Call function snils of class RussiaSpecProvider
    snils = russian_spec_provider.snils()
    # Check the result and add assert
    assert snils
    assert type(snils) == str

# Generated at 2022-06-25 20:13:03.789680
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    snils = RussiaSpecProvider().snils()
    assert type(snils) == str


# Generated at 2022-06-25 20:13:08.100871
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider(seed=42)
    assert russia_spec_provider_1.snils() == '41771531072'

# Generated at 2022-06-25 20:13:10.202755
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    russia_spec_provider.snils()


# Generated at 2022-06-25 20:13:13.242602
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    snils = russia_spec_provider.snils()
    assert snils is not None


# Generated at 2022-06-25 20:13:16.636419
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    snils = russia_spec_provider_0.snils()
    if len(snils) != 11:
        raise AssertionError('Incorrect snils length')
    else:
        print(snils)


# Generated at 2022-06-25 20:16:11.667303
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    _list = ['41917492600']
    for i in range(0, len(_list)):
        assert russia_spec_provider.snils() in _list


# Generated at 2022-06-25 20:16:13.126657
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider().snils()
    assert len(russia_spec_provider_1) == 11


# Generated at 2022-06-25 20:16:14.555289
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert len(russia_spec_provider_0.snils()) == 11


# Generated at 2022-06-25 20:16:16.379230
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Docstring for the method snils."""
    russia_spec_provider_snils_0 = RussiaSpecProvider()
    assert russia_spec_provider_snils_0.snils() == '41917492600'


# Generated at 2022-06-25 20:16:22.091479
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    expected_snils = 41917492600
    snils = RussiaSpecProvider().snils()
    assert snils == str(expected_snils)


# Generated at 2022-06-25 20:16:27.524536
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    control_code = int(provider.snils()[-2:])
    number = int(provider.snils()[:-2])
    numbers = [int(x) for x in list(str(number))]

    control_codes = []

    for i in range(0, 9):
        control_codes.append(numbers[9 - i] * i)

    if int(sum(control_codes) % 101) != control_code:
        raise AssertionError('Wrong SNILS')

    if int(sum(control_codes) % 101) == 100:
        if control_code != 0:
            raise AssertionError('Wrong SNILS')



# Generated at 2022-06-25 20:16:32.747554
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    snils = russia_spec_provider_0.snils()
    assert len(snils) == 11
    # assert isinstance(snils, str)



# Generated at 2022-06-25 20:16:37.247706
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    value = russia_spec_provider.snils()
    assert len(str(value)) == 11
    assert int(str(value)[0]) != 0
    assert int(str(value)[3]) != 0


# Generated at 2022-06-25 20:16:39.972169
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert russia_spec_provider_0.snils() != russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:16:42.631850
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert (re.match(r'\d{11}', russia_spec_provider_0.snils()))
