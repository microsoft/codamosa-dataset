

# Generated at 2022-06-25 20:08:11.367671
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    str_1 = russia_spec_provider_0.snils()
    str_2 = russia_spec_provider_0.snils()
    str_3 = russia_spec_provider_0.snils()
    str_4 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:08:13.396000
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:08:15.828139
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert len(str_0) == 11


# Generated at 2022-06-25 20:08:20.013155
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider(seed=0)
    str_0 = russia_spec_provider_0.snils()
    assert str_0 == '36311400161'


# Generated at 2022-06-25 20:08:23.642655
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert(len(str_0) == 11)
    assert(str_0.isdigit())


# Generated at 2022-06-25 20:08:30.488084
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    russia_spec_provider = RussiaSpecProvider(seed=7777777)
    generated_snils = russia_spec_provider.snils()
    expected_snils = "86935706226"
    assert generated_snils == expected_snils


# Generated at 2022-06-25 20:08:33.828812
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    print(str_0)


# Generated at 2022-06-25 20:08:38.317742
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:08:42.577851
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert russia_spec_provider_0.snils() != russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:08:47.078291
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    snils = russia_spec_provider.snils()
    assert snils is not None
    assert len(snils) > 0
    assert snils.isnumeric()



# Generated at 2022-06-25 20:08:57.145775
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:09:03.597167
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()

    if str_0 is None:
        raise AssertionError("%r" % str_0)
    else:
        assert isinstance(str_0, str)

# Generated at 2022-06-25 20:09:08.837248
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rus_spec_provider_0 = RussiaSpecProvider()
    len_0 = len(rus_spec_provider_0.snils())
    assert len_0 == 11


# Generated at 2022-06-25 20:09:14.133581
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    #assert len(str_0) == 11, 'expected {}, got {}'.format(11, len(str_0))


# Generated at 2022-06-25 20:09:19.283010
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rs = RussiaSpecProvider()
    snils = rs.snils()
    print(snils)
    assert len(snils) == 11
    assert snils[0] != '0'



# Generated at 2022-06-25 20:09:23.605005
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:09:26.173291
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:09:32.388272
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()

    snils_0 = russia_spec_provider_0.snils()

    bool_0 = (int(snils_0) >= 100000000 and int(snils_0) <= 999999999)

    assert bool_0 is True

# Generated at 2022-06-25 20:09:36.651451
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    print('Start test_RussiaSpecProvider_snils')
    # Create russia_spec_provider generator
    russia_spec_provider = RussiaSpecProvider()
    snils = russia_spec_provider.snils()
    # Assert
    assert snils is not None
    assert len(snils) == 11
    snils2 = russia_spec_provider.snils()
    assert snils != snils2
    print('End test_RussiaSpecProvider_snils')


# Generated at 2022-06-25 20:09:42.329008
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    o = RussiaSpecProvider()
    snils = o.snils()
    assert type(snils) == str
    assert len(snils) == 11
    assert all([int(symbol) >= 0 and int(symbol) <= 10 for symbol in snils])


# Generated at 2022-06-25 20:10:01.737817
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert re.fullmatch("\d{9}", str_0)


# Generated at 2022-06-25 20:10:05.842470
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:10:09.474754
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """
    Test snils method of class RussiaSpecProvider.

    This test asserts if the snils generated is valid.
    (i.e.) if it is a 12 digit number.
    """
    russia_spec_provider_0 = RussiaSpecProvider()
    assert len(russia_spec_provider_0.snils()) == 12

# Generated at 2022-06-25 20:10:13.599043
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert len(str_0) == 11


# Generated at 2022-06-25 20:10:18.142991
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    RussiaSpecProvider = RussiaSpecProvider()
    snils = RussiaSpecProvider.snils()
    assert len(str(snils)) == 11

    # Unit test for method inn of class RussiaSpecProvider

# Generated at 2022-06-25 20:10:23.052140
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    str_1 = russia_spec_provider_1.snils()
    assert len(str_1) == 11


# Generated at 2022-06-25 20:10:30.185656
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():

    russia_provider_0 = RussiaSpecProvider()
    str_0 = russia_provider_0.snils()
    str_1 = russia_provider_0.snils()
    str_2 = russia_provider_0.snils()
    str_3 = russia_provider_0.snils()
    str_4 = russia_provider_0.snils()

    assert russia_provider_0.snils() == russia_provider_0.snils()


# Generated at 2022-06-25 20:10:32.751484
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    print("************************")
    print("Method snils test")
    print("************************")
    print("snils", snils)

# Generated at 2022-06-25 20:10:38.574018
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    str_1 = russia_spec_provider_1.snils()
    str_2 = russia_spec_provider_1.snils()
    print(str_1)


# Generated at 2022-06-25 20:10:47.647243
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # get object of RussiaSpecProvider
    russia_spec_provider = RussiaSpecProvider()
    # store result of method snils
    result = russia_spec_provider.snils()
    # define true value of method snils
    truth = russia_spec_provider.snils()
    # assert that result is str type
    assert isinstance(result, str)
    # assert that result is equal to truth
    assert result == truth


# Generated at 2022-06-25 20:11:26.745279
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert str_0.isdigit()
    assert 11 <= len(str_0)


# Generated at 2022-06-25 20:11:28.683345
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider().snils() == '41917492600'


# Generated at 2022-06-25 20:11:32.286314
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert len(str_0) == 11



# Generated at 2022-06-25 20:11:34.613155
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    g = RussiaSpecProvider()
    assert len(g.snils()) == 11


# Generated at 2022-06-25 20:11:39.108787
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Create instance of class RussiaSpecProvider
    russia_spec_provider = RussiaSpecProvider()
    # Create snils
    snils = russia_spec_provider.snils()
    assert isinstance(snils, str)



# Generated at 2022-06-25 20:11:40.832969
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    # Call method snils of class RussiaSpecProvider
    str_0 = russia_spec_provider_0.snils()

# Generated at 2022-06-25 20:11:49.421473
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    assert isinstance(provider.snils(), str)
    assert len(provider.snils()) == 11
    assert isinstance(provider.snils(mask='###-###-### ##'), str)
    assert len(provider.snils(mask='###-###-### ##')) == 14
    assert provider.snils(mask='###-###-### ##').count('#') == 11


# Generated at 2022-06-25 20:11:52.277293
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test case.

    :return: None.
    """
    russia_spec_provider_0 = RussiaSpecProvider()
    actual_result_0 = russia_spec_provider_0.snils()
    expected_result_0 = '41917492600'
    assert actual_result_0 == expected_result_0, 'Expected different snils'

# Generated at 2022-06-25 20:11:54.456878
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    str_0 = russia_spec_provider.snils()
    assert_is_instance(str_0, str)
    assert_equal(str_0, "41917492600")


# Generated at 2022-06-25 20:11:59.371332
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    result = russia_spec_provider_0.snils()
    assert russia_spec_provider_0.snils() == result


# Generated at 2022-06-25 20:13:23.425921
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert type(str_0) == str


# Generated at 2022-06-25 20:13:25.958302
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    str_1 = russia_spec_provider_1.snils()


# Generated at 2022-06-25 20:13:31.207025
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider(seed=951976)
    str_0 = russia_spec_provider_0.snils()
    assert str_0 == '50545800146'
    tool_box_0 = ToolBox()
    tool_box_0.seed = 638432
    russia_spec_provider_1 = RussiaSpecProvider(seed=tool_box_0.seed)
    str_1 = russia_spec_provider_1.snils()
    assert str_1 == '41898202407'


# Generated at 2022-06-25 20:13:32.992053
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert isinstance(str_0, str)


# Generated at 2022-06-25 20:13:37.109881
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    list_0 = []
    for i in range(0,1000):
        str_0 = russia_spec_provider.snils()
        list_0.append(int(str_0[9]))
    assert(sum(list_0) == 0)

# Generated at 2022-06-25 20:13:40.763565
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_test = RussiaSpecProvider()
    str = russia_spec_provider_test.snils()
    length = len(str)
    assert length == 11


# Generated at 2022-06-25 20:13:45.533561
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert len(str_0) == 11, \
        "assertion error in RussiaSpecProvider.test_RussiaSpecProvider_snils"
    str_1 = russia_spec_provider_0.snils()
    assert str_0 == str_1, \
        "assertion error in RussiaSpecProvider.test_RussiaSpecProvider_snils"


# Generated at 2022-06-25 20:13:47.240922
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_3 = RussiaSpecProvider()
    str_3 = russia_spec_provider_3.snils()


# Generated at 2022-06-25 20:13:48.904943
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:13:50.634119
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # arrange
    russia_spec_provider = RussiaSpecProvider()

    # act
    result = russia_spec_provider.snils()

    # assert
    assert result is not None


# Generated at 2022-06-25 20:17:42.798594
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test for RussiaSpecProvider.snils

    Tests if RussiaSpecProvider.snils returns a string.

    """
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert isinstance(str_0, str)


# Generated at 2022-06-25 20:17:45.614760
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:17:47.651109
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    for _ in range(0, 10):
        snils = russia_spec_provider.snils()
        assert len(snils) == 11
        assert isinstance(snils, str)



# Generated at 2022-06-25 20:17:51.491094
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert(str_0 >= '1000000000' and str_0 <= '9999999999')

