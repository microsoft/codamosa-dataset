

# Generated at 2022-06-25 20:08:04.475526
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    for _ in range(10):
        assert len(provider.snils()) == 11


# Generated at 2022-06-25 20:08:09.760671
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test case for method snils.

    Checks the method with correct arguments (no arguments)
    """
    russia_spec_provider_0 = RussiaSpecProvider()
    print(russia_spec_provider_0.snils())

# Generated at 2022-06-25 20:08:12.387432
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    val = russia_spec_provider.snils()
    assert isinstance(val, str)

# Generated at 2022-06-25 20:08:19.489581
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    snils = russia_spec_provider_1.snils()
    if not snils:
        assert False

if __name__ == '__main__':
    test_case_0()
    test_RussiaSpecProvider_snils()

# Generated at 2022-06-25 20:08:22.070963
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    assert russia_spec_provider_1.snils() == '41917492600'
    pass


# Generated at 2022-06-25 20:08:24.117661
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert russia_spec_provider_0.snils() is not None


# Generated at 2022-06-25 20:08:26.450687
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_expected = russia_spec_provider_0.snils()
    assert isinstance(str_expected, str) == True, "Function RussiaSpecProvider.snils must return a string"


# Generated at 2022-06-25 20:08:34.972439
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0_object = RussiaSpecProvider(seed=1000)
    russia_spec_provider_0_snils = russia_spec_provider_0_object.snils()
    russia_spec_provider_0_len_snils = len(russia_spec_provider_0_snils)
    assert russia_spec_provider_0_len_snils == 11, "Expected 10, but got %s" % russia_spec_provider_0_len_snils


# Generated at 2022-06-25 20:08:37.177074
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert re.fullmatch('\d{11}', russia_spec_provider_0.snils())


# Generated at 2022-06-25 20:08:41.943807
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert type(russia_spec_provider_0.snils()) == str
    assert len(russia_spec_provider_0.snils()) == 11


# Generated at 2022-06-25 20:08:54.833926
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider(272)  # snils_expected - 41917492600
    snils_expected = '41917492600'
    snils_actual = russia_spec_provider_0.snils()
    assert snils_expected == snils_actual


# Generated at 2022-06-25 20:09:07.138670
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from decimal import Decimal
    russia_spec_provider_1 = RussiaSpecProvider()

    snils_result_0 = '93723373534'
    snils_result_1 = '25347301439'

    assert isinstance(russia_spec_provider_1.snils(), str)
    assert len(russia_spec_provider_1.snils()) > 0
    assert isinstance(Decimal(russia_spec_provider_1.snils()), Decimal)
    assert russia_spec_provider_1.snils() is not None
    assert russia_spec_provider_1.snils() is not ''
    assert russia_spec_provider_1.snils() != snils_result_0
    assert russia_spec_provider_1.snils()

# Generated at 2022-06-25 20:09:12.322249
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert ''.join(russia_spec_provider_0.snils().split()) == russia_spec_provider_0.snils()
    

# Generated at 2022-06-25 20:09:19.434555
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()

    assert(russia_spec_provider_0.snils() == '41917492600')
    assert(russia_spec_provider_0.snils() == '41917492600')
    assert(russia_spec_provider_0.snils() == '41917492600')
    assert(russia_spec_provider_0.snils() == '41917492600')
    assert(russia_spec_provider_0.snils() == '41917492600')
    assert(russia_spec_provider_0.snils() == '41917492600')
    assert(russia_spec_provider_0.snils() == '41917492600')

# Generated at 2022-06-25 20:09:27.385664
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    snils = russia_spec_provider.snils()
    num = snils[0:9]
    sum = 0
    for i in range(9, 0, -1):
        sum += int(num[9 - i]) * i
    control_code = (sum % 101) - 100
    if control_code == -100:
        control_code = 0
    assert snils[9:11] == '{:0>2d}'.format(control_code)


# Generated at 2022-06-25 20:09:30.749516
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert len(russia_spec_provider_0.snils()) == 11


# Generated at 2022-06-25 20:09:34.861799
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    snils = russia_spec_provider.snils()
    assert snils[0] != '0'
    assert len(snils) == 11


# Generated at 2022-06-25 20:09:40.039148
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    ru_spec = RussiaSpecProvider()
    pattern = re.compile("^[\d]{11}$")
    assert pattern.match(ru_spec.snils())



# Generated at 2022-06-25 20:09:45.629672
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    snils = russia_spec_provider_1.snils()
    assert len(snils) == 11
    snils_tmp = list(snils)
    for i, el in enumerate(snils_tmp):
        assert el.isnumeric()


# Generated at 2022-06-25 20:09:48.415286
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider().snils() == '41917492600'


# Generated at 2022-06-25 20:10:01.266890
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    test_assert_equal(russia_spec_provider_0.snils(), '41917492600')


# Generated at 2022-06-25 20:10:05.335987
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()
    assert len(rsp.snils()) == 11
    assert(str.isdigit(rsp.snils()))


# Generated at 2022-06-25 20:10:07.864618
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    snils = russia_spec_provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-25 20:10:09.971905
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    russia_spec_provider.snils()


# Generated at 2022-06-25 20:10:13.529285
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    assert len(russia_spec_provider_1.snils()) == 11


# Generated at 2022-06-25 20:10:18.112965
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    test_snils = russia_spec_provider.snils()
    assert len(test_snils) == 11


# Generated at 2022-06-25 20:10:30.300722
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    russia_spec_provider_0.seed(1010)
    res = russia_spec_provider_0.snils()
    assert res == '41686582384'
    russia_spec_provider_1 = RussiaSpecProvider()
    russia_spec_provider_1.seed(8927)
    res = russia_spec_provider_1.snils()
    assert res == '21669998255'
    russia_spec_provider_2 = RussiaSpecProvider()
    russia_spec_provider_2.seed(1957)
    res = russia_spec_provider_2.snils()
    assert res == '63171455762'
    russia_spec_provider_3 = RussiaSpecProvider

# Generated at 2022-06-25 20:10:42.395913
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.exceptions import NonEnumerableError
    from mimesis.providers.phone import Phone

    try:
        russia_spec_provider_0 = RussiaSpecProvider()
        russia_spec_provider_0.snils()
    except TypeError as err:
        if str(err) == _err_msg_0:
            pass
        else:
            raise TypeError(_err_msg_0)
    except NonEnumerableError as err:
        if str(err) == _err_msg_1:
            pass
        else:
            raise NonEnumerableError(_err_msg_1)
    except AttributeError as err:
        if str(err) == _err_msg_2:
            pass
        else:
            raise AttributeError(_err_msg_2)

# Generated at 2022-06-25 20:10:46.756864
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert re.match(r'^\d{11}$', russia_spec_provider_0.snils())


# Generated at 2022-06-25 20:10:52.104753
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    snils = russia_spec_provider_1.snils()
    control_digit = int(snils[-2:])
    check_digit = 0
    digits = [int(x) for x in snils[:-2]]
    weights = [3, 2, 7, 6, 5, 4, 3, 2]
    for i in range(0, len(digits)):
        check_digit += digits[i] * weights[i]
    if check_digit > 101:
        check_digit = check_digit % 101
    assert check_digit == control_digit


# Generated at 2022-06-25 20:11:09.011196
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Type check for the method snils of class RussiaSpecProvider
    assert isinstance(russia_spec_provider_0.snils(), str)


# Generated at 2022-06-25 20:11:13.147825
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert russia_spec_provider_0.snils() == '39404045100'


# Generated at 2022-06-25 20:11:18.873966
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    snils = russia_spec_provider_0.snils()
    assert isinstance(snils, str)
    assert snils != ''
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-25 20:11:20.723333
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    assert len(russia_spec_provider_1.snils()) == 11


# Generated at 2022-06-25 20:11:32.112882
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    for i in range(0, 10):
        russia_spec_provider = RussiaSpecProvider()
        snils_0 = russia_spec_provider.snils()
        assert snils_0 != '0' * 11
        assert snils_0 != '0' * 12
        assert snils_0 != '0' * 13
        assert snils_0 != '1' * 11
        assert snils_0 != '1' * 12
        assert snils_0 != '1' * 13
        assert len(snils_0) == 11
        for char in snils_0:
            assert char in '0123456789'


# Generated at 2022-06-25 20:11:41.721468
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()


# Generated at 2022-06-25 20:11:45.776289
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    snils_1 = russia_spec_provider_1.snils()
    assert snils_1 != None


# Generated at 2022-06-25 20:11:49.355874
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert isinstance(russia_spec_provider_0.snils(), str)

# Generated at 2022-06-25 20:11:51.103819
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    # Expected: '41917492600'
    assert russia_spec_provider.snils() == '41917492600'


# Generated at 2022-06-25 20:11:56.508116
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    snils = russia_spec_provider_0.snils()
    print("snils: " + str(snils))


# Generated at 2022-06-25 20:12:39.652595
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    snils = russia_spec_provider.snils()
    assert len(snils) == 11

# Generated at 2022-06-25 20:12:43.188855
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    for _ in range(10):
        provider.snils()


# Generated at 2022-06-25 20:12:48.742328
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    
    russia_spec_provider = RussiaSpecProvider()
    snils_0 = russia_spec_provider.snils()
    assert type(snils_0) == str


# Generated at 2022-06-25 20:12:52.120391
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    russia_spec_provider.snils()


# Generated at 2022-06-25 20:12:56.996875
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    # snils = "41917492600"
    assert len(russia_spec_provider.snils()) == 11
    assert type(russia_spec_provider.snils()) == str


# Generated at 2022-06-25 20:13:04.831263
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    # russia_spec_provider_0.snils()
    assert len(russia_spec_provider_0.snils()) == 11
    # russia_spec_provider_0.snils()
    assert len(russia_spec_provider_0.snils()) == 11
    # russia_spec_provider_0.snils()
    assert len(russia_spec_provider_0.snils()) == 11
    # russia_spec_provider_0.snils()
    assert len(russia_spec_provider_0.snils()) == 11
    # russia_spec_provider_0.snils()
    assert len(russia_spec_provider_0.snils()) == 11
    # r

# Generated at 2022-06-25 20:13:08.893499
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    snils = RussiaSpecProvider().snils()
    assert isinstance(snils, str) and len(snils) == 11


# Generated at 2022-06-25 20:13:14.373366
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    snils_1 = russia_spec_provider_1.snils()
    assert isinstance(snils_1, str)

    russia_spec_provider_2 = RussiaSpecProvider()
    snils_2 = russia_spec_provider_2.snils()
    assert isinstance(snils_2, str)



# Generated at 2022-06-25 20:13:16.546351
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert isinstance(russia_spec_provider_0.snils(), str)

# Generated at 2022-06-25 20:13:22.798509
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    result = 1

    for i in range(0, 10):
        snils_i = int(russia_spec_provider.snils())
        if snils_i in range(10000000000, 100000000000):
            result = 0

    assert result == 0


# Generated at 2022-06-25 20:14:58.225339
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    for i in range(1,10):
        assert (len(russia_spec_provider_0.snils()) == 11)
        assert (russia_spec_provider_0.snils()[0] != '-')


# Generated at 2022-06-25 20:15:01.236423
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():

    # Create an instance of class RussiaSpecProvider
    russia_spec_provider_1 = RussiaSpecProvider()
    snils_0 = russia_spec_provider_1.snils()
    assert len(snils_0) == 11

# Generated at 2022-06-25 20:15:09.416757
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    _snils_result = russia_spec_provider_0.snils()

    assert isinstance(_snils_result, str)
    assert len(_snils_result) == 11


# Generated at 2022-06-25 20:15:13.393215
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    pattern_1 = re.compile(r"\d\d\d\d\d\d\d\d\d\d")
    assert re.match(pattern_1, russia_spec_provider_1.snils())


# Generated at 2022-06-25 20:15:15.577166
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider(seed=123)
    print(russia_spec_provider.snils())


# Generated at 2022-06-25 20:15:20.929375
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    with pytest.raises(AssertionError):
        russia_spec_provider_0 = RussiaSpecProvider()
        assert russia_spec_provider_0.snils() == '41917492600'


# Generated at 2022-06-25 20:15:23.260573
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    assert isinstance(russia_spec_provider_1.snils(), str)


# Generated at 2022-06-25 20:15:25.414010
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    snils = russia_spec_provider_0.snils()
    print(snils)


# Generated at 2022-06-25 20:15:27.413033
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    snils = russia_spec_provider.snils()
    assert type(snils) is str
    assert len(snils) is 11


# Generated at 2022-06-25 20:15:30.369327
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    x = RussiaSpecProvider().snils()
    y = x.isdigit()
    assert y == True
    z = len(x) == 11
    assert z == True
