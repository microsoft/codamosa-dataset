

# Generated at 2022-06-25 20:08:03.215809
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_1 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:08:14.773167
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    russia_spec_provider_0.random.seed(250108)
    assert russia_spec_provider_0.snils() == '60914589567'
    russia_spec_provider_0.random.seed(250108)
    assert russia_spec_provider_0.snils() == '60914589567'
    russia_spec_provider_0.random.seed(250108)
    assert russia_spec_provider_0.snils() == '60914589567'
    russia_spec_provider_0.random.seed(250108)
    assert russia_spec_provider_0.snils() == '60914589567'
    russia_spec_prov

# Generated at 2022-06-25 20:08:20.299662
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert type(str_0) == str
    assert type(int(str_0)) == int


# Generated at 2022-06-25 20:08:23.808579
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_ob = RussiaSpecProvider()
    result = russia_spec_provider_ob.snils()
    assert(type(result) == str)
    assert(len(result) == 11)
    assert(1000 <= int(result) <= 99999999999)


# Generated at 2022-06-25 20:08:28.696081
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert len(russia_spec_provider_0.snils()) == 11
    assert isinstance(russia_spec_provider_0.snils(), str)


# Generated at 2022-06-25 20:08:32.964072
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    print(str_0)


# Generated at 2022-06-25 20:08:34.293945
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_2 = RussiaSpecProvider()
    str_2 = russia_spec_provider_2.snils()


# Generated at 2022-06-25 20:08:36.288377
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert isinstance(snils, str)


# Generated at 2022-06-25 20:08:44.403270
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    russia_sp_0 = RussiaSpecProvider()
    str_0 = russia_sp_0.snils()
    assert len(str_0) == 11
    # number should be in range: 7, 8, 9 and all odd digits should be equal
    assert all(x in str_0 for x in set([7, 8, 9]))
    assert sum(int(x) for x in str_0) % 2


# Generated at 2022-06-25 20:08:48.247255
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:09:09.661716
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russian_provider = RussiaSpecProvider()
    assert len(russian_provider.snils()) == 11


# Generated at 2022-06-25 20:09:14.160858
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():

    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert re.match(
        '[0-9]{11}',
        str_0,
        0
    )



# Generated at 2022-06-25 20:09:18.701728
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rus_provider = RussiaSpecProvider()
    snils_0 = rus_provider.snils()
    print('snils number: ', snils_0)


# Generated at 2022-06-25 20:09:28.011579
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Setup
    russia_spec_provider_0 = RussiaSpecProvider()
    russia_spec_provider_1 = RussiaSpecProvider()

    # Exercise and Verify
    result_0 = russia_spec_provider_0.snils()
    # result_1 = russia_spec_provider_1.snils()
    # result_2 = russia_spec_provider_2.snils()

    # Verify
    assert russia_spec_provider_0.snils().isdigit()
    # assert russia_spec_provider_1.snils().isdigit()
    # assert russia_spec_provider_2.snils().isdigit()

# Generated at 2022-06-25 20:09:32.376611
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert len(str_0) == 11


# Generated at 2022-06-25 20:09:35.135902
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    print(str_0)

# Generated at 2022-06-25 20:09:40.387768
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert str_0 != 0


# Generated at 2022-06-25 20:09:45.250944
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
        russia_spec_provider_0 = RussiaSpecProvider()
        str_0 = russia_spec_provider_0.snils()
        str_1 = russia_spec_provider_0.snils()
        assert str_0 != str_1


# Generated at 2022-06-25 20:09:49.932148
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()

    with pytest.raises(KeyError):
        str_0 = russia_spec_provider_0.snils()

# Generated at 2022-06-25 20:09:54.148492
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    str_1 = RussiaSpecProvider().snils()


# Generated at 2022-06-25 20:10:35.651483
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = RussiaSpecProvider().snils()


# Generated at 2022-06-25 20:10:38.897933
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    snils_0 = russia_spec_provider_0.snils()
    assert snils_0 != None
    assert snils_0 != ""
    if not snils_0.isdigit():
        raise Exception("Value '{}' is not a digit".format(snils_0))


# Generated at 2022-06-25 20:10:46.341293
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    str_1 = russia_spec_provider_0.snils()
    assert str_0 != str_1
    assert len(str_0) == 11


# Generated at 2022-06-25 20:10:49.812285
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    str_1 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:10:55.529778
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Initialize class instance
    rsp = RussiaSpecProvider()
    
    # Check snils method
    assert len(rsp.snils()) == 11
    assert rsp.snils() == '70429120220'


# Generated at 2022-06-25 20:10:59.293129
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    snils = russia_spec_provider_0.snils()
    assert snils != '41917492600', 'fail'

# Generated at 2022-06-25 20:11:06.132571
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Arrange
    russia_spec_provider_0 = RussiaSpecProvider()

    # Act
    str_0 = russia_spec_provider_0.snils()

    # Assert
    assert len(str_0) == 11
    assert isinstance(str_0, str)



# Generated at 2022-06-25 20:11:09.494286
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    str_0 = RussiaSpecProvider.snils(RussiaSpecProvider())
    assert type(str_0) == str


# Generated at 2022-06-25 20:11:21.797204
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()

# Generated at 2022-06-25 20:11:25.137781
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_2 = RussiaSpecProvider()
    str_0 = russia_spec_provider_2.snils()

# Generated at 2022-06-25 20:13:04.984935
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    print("RussiaSpecProvider.snils()= ", str_0)


# Generated at 2022-06-25 20:13:10.253547
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test method snils of class RussiaSpecProvider."""
    russia_spec_provider = RussiaSpecProvider()
    snils = russia_spec_provider.snils()
    assert len(snils) == 11


# Generated at 2022-06-25 20:13:13.526535
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert len(str_0) == 11


# Generated at 2022-06-25 20:13:15.789393
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:13:20.263296
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    str_1 = russia_spec_provider_0.snils()
    assert str_0 != str_1


# Generated at 2022-06-25 20:13:22.870918
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    ru_0 = RussiaSpecProvider()
    str_2: str = ru_0.snils()


# Generated at 2022-06-25 20:13:25.686393
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert str_0 != None


# Generated at 2022-06-25 20:13:27.997059
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert len(str_0) == 11


# Generated at 2022-06-25 20:13:30.513860
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Positive cases
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert len(str_0) == 11
    assert str_0[0] != '0'
    # Negative cases

# Generated at 2022-06-25 20:13:32.809146
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    print(str_0)
    assert isinstance(str_0, str)
    assert len(str_0) == 11
