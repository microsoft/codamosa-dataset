

# Generated at 2022-06-25 20:08:15.164414
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    russia_spec_provider_0.seed(5)
    assert russia_spec_provider_0.snils() == '79958697600'
    russia_spec_provider_0.seed(55)
    assert russia_spec_provider_0.snils() == '41932915600'
    russia_spec_provider_0.seed(555)
    assert russia_spec_provider_0.snils() == '79953872600'
    russia_spec_provider_0.seed(5555)
    assert russia_spec_provider_0.snils() == '79958572600'
    russia_spec_provider_0.seed(55555)
    assert russia_

# Generated at 2022-06-25 20:08:17.812725
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    assert russia_spec_provider_1.snils() == '12345678900'


# Generated at 2022-06-25 20:08:21.499560
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    assert russia_spec_provider_1.snils() == '19062854409'


# Generated at 2022-06-25 20:08:23.328354
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    assert len(russia_spec_provider.snils()) == 11


# Generated at 2022-06-25 20:08:27.570161
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    seed = 'test'
    russian_spec_provider = RussiaSpecProvider(seed=seed)
    assert (russian_spec_provider.snils() == '41917492600')


# Generated at 2022-06-25 20:08:34.248845
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russian_snils = RussiaSpecProvider().snils().split('-')

    assert len(russian_snils[0]) == 3
    assert len(russian_snils[1]) == 3
    assert len(russian_snils[2]) == 3
    assert len(russian_snils[3]) == 2

    assert len(russian_snils) == 4


# Generated at 2022-06-25 20:08:39.581200
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    string_rep = repr(russia_spec_provider_0.snils())
    print("\nProperty snils of class RussiaSpecProvider: " + string_rep)


# Generated at 2022-06-25 20:08:44.113654
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Testing of method snils
    print("Testing of method snils of class RussiaSpecProvider")
    russia_spec_provider_0 = RussiaSpecProvider()
    for _ in range(3):
        print(russia_spec_provider_0.snils())


# Generated at 2022-06-25 20:08:48.534405
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_snils = RussiaSpecProvider()
    res = russia_spec_provider_snils.snils()
    assert type(res) == str


# Generated at 2022-06-25 20:08:53.387167
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    assert russia_spec_provider_1.snils() in [
        '41917492600',
        '94207856000',
        '97315961600',
    ]


# Generated at 2022-06-25 20:09:13.536213
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    snils_0 = russia_spec_provider_0.snils()
    assert snils_0.isdecimal()


# Generated at 2022-06-25 20:09:17.028687
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider(0)
    russia_spec_provider_1 = RussiaSpecProvider(1)
    assert russia_spec_provider_0.snils() == '75667429600'
    assert russia_spec_provider_1.snils() == '79762158700'


# Generated at 2022-06-25 20:09:25.054988
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert russia_spec_provider_0.snils() == russia_spec_provider_0.snils()

    russia_spec_provider_1 = RussiaSpecProvider()
    assert russia_spec_provider_1.snils() != russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:09:29.382685
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert isinstance(russia_spec_provider_0.snils(), str)


# Generated at 2022-06-25 20:09:33.985792
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils[0:9].isdigit()
    assert snils[-2:].isdigit()


# Generated at 2022-06-25 20:09:36.221156
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    snils = russia_spec_provider.snils()
    assert len(snils) == 11
    assert snils.isdigit()


# Generated at 2022-06-25 20:09:47.559193
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_snils = RussiaSpecProvider()

# Generated at 2022-06-25 20:09:51.144800
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    ret = russia_spec_provider_0.snils()
    assert ret == '41917492600'


# Generated at 2022-06-25 20:09:59.122616
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert russia_spec_provider_0.snils() == '40745787016'
    assert russia_spec_provider_0.snils() == '32296984632'
    assert russia_spec_provider_0.snils() == '12541185159'
    assert russia_spec_provider_0.snils() == '97594830307'
    assert russia_spec_provider_0.snils() == '93644583757'
    assert russia_spec_provider_0.snils() == '5236701765'
    assert russia_spec_provider_0.snils() == '2777692451'

# Generated at 2022-06-25 20:10:03.651912
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider(seed=1006)
    assert russia_spec_provider_0.snils() == ('28169809200')


# Generated at 2022-06-25 20:10:40.636729
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    result = russia_spec_provider_0.snils()
    assert result is not None and len(result) == 11


# Generated at 2022-06-25 20:10:45.356999
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    snils = str(russia_spec_provider_0.snils())
    assert type(snils) == str
    assert len(snils) == 11


# Generated at 2022-06-25 20:10:52.133117
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    russia_spec_provider_0.reset_seed(12)
    result = russia_spec_provider_0.snils(0)
    assert result == '61982536449'
    result = russia_spec_provider_0.snils(0)
    assert result == '65177023354'
    russia_spec_provider_1 = RussiaSpecProvider(seed=12)
    result = russia_spec_provider_1.snils(0)
    assert result == '61982536449'
    result = russia_spec_provider_1.snils(0)
    assert result == '65177023354'
    russia_spec_provider_1 = RussiaSpecProvider(seed=12)
   

# Generated at 2022-06-25 20:10:58.949298
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    snils_example = russia_spec_provider.snils()

    assert len(snils_example) == 11
    assert snils_example[0:9].isdigit()
    assert snils_example[9:11].isdigit()


# Generated at 2022-06-25 20:11:03.603000
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    assert russia_spec_provider_1.snils() == '41917492600'


# Generated at 2022-06-25 20:11:07.193581
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    for _ in range(0, 10):
        result = RussiaSpecProvider().snils()
        assert result is not None


# Generated at 2022-06-25 20:11:08.507119
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert len(RussiaSpecProvider().snils()) == 11
    assert len(RussiaSpecProvider().snils()) == 11


# Generated at 2022-06-25 20:11:12.317028
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    snils_0 = russia_spec_provider.snils()
    assert snils_0 == '31029495057'


# Generated at 2022-06-25 20:11:15.418051
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert russia_spec_provider_0.snils() != None


# Generated at 2022-06-25 20:11:19.871411
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()

    result = russia_spec_provider_0.snils()

    assert isinstance(result, str)
    assert len(result) == 11


# Generated at 2022-06-25 20:12:47.912488
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider().snils() == '41917492600'


# Generated at 2022-06-25 20:12:49.249535
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_snils = RussiaSpecProvider()
    assert len(russia_spec_provider_snils.snils()) == 11


# Generated at 2022-06-25 20:12:57.659194
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    answer = russia_spec_provider_1.snils()
    snils = []
    for _ in range(0, 11):
        snils.append(int(answer[_]))

    control_codes = []
    for _ in range(9, 0, -1):
        control_codes.append(snils[9 - _] * _)

    control_code = sum(control_codes)
    if control_code in (100, 101):
        assert answer[9:] == '00'
    elif control_code < 100:
        assert answer[9:] == control_code
    elif control_code > 101:
        control_code = control_code % 101
        if control_code == 100:
            control_code = 0

# Generated at 2022-06-25 20:13:00.518243
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    num_of_tests = 10
    for _ in range(num_of_tests):
        print(russia_spec_provider_0.snils())


# Generated at 2022-06-25 20:13:02.637353
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    print(russia_spec_provider_0.snils())


# Generated at 2022-06-25 20:13:04.946534
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    snils_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:13:11.096578
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    result = []
    russia_spec_provider_1 = RussiaSpecProvider()
    for _ in range(0, 20):
        result.append(russia_spec_provider_1.snils())
    assert len(result) == 20


# Generated at 2022-06-25 20:13:13.842516
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    print(str_0)


# Generated at 2022-06-25 20:13:19.628447
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    ogrn = russia_spec_provider_0.ogrn()
    snils = russia_spec_provider_0.snils()
    kpp = russia_spec_provider_0.kpp()
    inn = russia_spec_provider_0.inn()
    print("OGRN: " + ogrn)
    print("SNILS: " + snils)
    print("KPP: " + kpp)
    print("INN: " + inn)
    print("Patronymic: " + russia_spec_provider_0.patronymic())
    print("Sentence: " + russia_spec_provider_0.generate_sentence())



# Generated at 2022-06-25 20:13:23.737452
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    snils = russia_spec_provider.snils()
    if snils and len(snils) == 11:
        return True
    else:
        return False
