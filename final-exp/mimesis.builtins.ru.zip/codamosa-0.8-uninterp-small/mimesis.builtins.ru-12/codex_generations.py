

# Generated at 2022-06-25 20:08:12.918927
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert isinstance(str_0, str)
    assert len(str_0) == 11
    assert str_0.isdigit()
    for i in range(9):
        assert int(str_0[i]) == russia_spec_provider_0.random.randint(0, 9)
    assert int(str_0[9]) == russia_spec_provider_0.random.randint(0, 9)
    assert int(str_0[10]) == russia_spec_provider_0.random.randint(0, 9)


# Generated at 2022-06-25 20:08:15.533185
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    for x in range(10):
        test_case_0()

# Generated at 2022-06-25 20:08:16.931189
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert len(RussiaSpecProvider().snils()) == 11


# Generated at 2022-06-25 20:08:18.459626
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider().snils() is not None


# Generated at 2022-06-25 20:08:21.202009
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    seed = 81
    russia_spec_provider_0 = RussiaSpecProvider(seed=seed)
    seed = 81
    assert str(russia_spec_provider_0.snils()) == '716198261'



# Generated at 2022-06-25 20:08:23.735790
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # expected result is generated from the method's implementation
    expected = 41917492600
    instance = RussiaSpecProvider()
    actual = instance.snils()
    assert actual == expected


# Generated at 2022-06-25 20:08:26.911514
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert len(RussiaSpecProvider().snils()) == 11
    assert type(RussiaSpecProvider().snils()) == str



# Generated at 2022-06-25 20:08:37.413064
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    str_1 = russia_spec_provider_1.snils()

# Generated at 2022-06-25 20:08:41.088359
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    print(str_0)



# Generated at 2022-06-25 20:08:44.278751
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    RussiaSpecProvider_test = RussiaSpecProvider()
    RussiaSpecProvider_test._random = lambda: '41917492600'
    RussiaSpecProvider_test.snils() == '41917492600'


# Generated at 2022-06-25 20:09:03.780498
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider().snils() == '89593569542'


# Generated at 2022-06-25 20:09:05.937344
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # No assertions.
    test_case_0()


# Generated at 2022-06-25 20:09:09.102691
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert True == isinstance(str_0, str)
    assert False == isinstance(str_0, int)
    assert False == isinstance(str_0, float)


# Generated at 2022-06-25 20:09:13.126292
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()


# Generated at 2022-06-25 20:09:15.117097
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Test case #0
    global str_0
    str_0 = None
    test_case_0()
    assert str_0 is not None


# Generated at 2022-06-25 20:09:19.627531
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert str_0 is not None


# Generated at 2022-06-25 20:09:24.495315
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    print(str_0)


# Generated at 2022-06-25 20:09:26.313870
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    assert len(russia_spec_provider.snils()) == 11


# Generated at 2022-06-25 20:09:35.577576
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Test case 1 with seed equal None
    russia_spec_provider_1 = RussiaSpecProvider()
    str_1 = russia_spec_provider_1.snils()
    assert len(str_1) == 11
    assert str_1 == str_1
    # Test case 2 with seed equal 0
    russia_spec_provider_2 = RussiaSpecProvider(seed=0)
    str_2 = russia_spec_provider_2.snils()
    assert str_2 == '58069391600'
    assert str_2 == '58069391600'

# Generated at 2022-06-25 20:09:37.205567
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    output = russia_spec_provider.snils()
    assert len(output) == 11


# Generated at 2022-06-25 20:10:18.532130
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()

    str_0 = russia_spec_provider.snils()
    assert len(str_0) == 11
    assert (int(str_0) // 10 ** 9 != 0)

# Generated at 2022-06-25 20:10:23.562753
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    str_1 = russia_spec_provider_0.snils()

    assert(len(str_0) == 11)
    assert(str(str_0) != str(str_1))
    assert(str_0.isdecimal())
    assert(str_1.isdecimal())
    assert(str_0[-2:] != '00')
    assert(str_1[-2:] != '00')


# Generated at 2022-06-25 20:10:25.634239
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    frsp = RussiaSpecProvider()
    frsp.snils()


# Generated at 2022-06-25 20:10:27.067717
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    test_case_0()

# Generated at 2022-06-25 20:10:30.156163
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert isinstance(str_0, str)
    assert len(str_0) == 11
    assert str_0.isnumeric()


# Generated at 2022-06-25 20:10:34.795363
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    assert russia_spec_provider.snils() in ['41917492600']



# Generated at 2022-06-25 20:10:40.027516
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert str_0 != "41944444444"
    assert str_0 != "12345678900"
    assert str_0 != "00000000000"


# Generated at 2022-06-25 20:10:44.119775
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider().snils() in """41917492600
    74040374610
    71243835052
    97220989908
    92945023233
    39452055791
    84870362683
    26122602934
    97094241260
    46341345587
    46097870203
    20512789901
    39012967751
    71541897841
    78311440760
    104444444444"""



# Generated at 2022-06-25 20:10:46.747219
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    d_0 = RussiaSpecProvider()
    d_0.snils()



# Generated at 2022-06-25 20:10:49.445731
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert len(str_0) == 11
    assert str_0.isdigit() is True
    # TODO: assert - check sum


# Generated at 2022-06-25 20:12:17.619242
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert len(test_case_0()) == 11

# Generated at 2022-06-25 20:12:22.191778
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert(len(str_0) == 11)

# Generated at 2022-06-25 20:12:25.583212
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert len(str_0) == 11

# Generated at 2022-06-25 20:12:26.304482
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert len(RussiaSpecProvider().snils()) == 11



# Generated at 2022-06-25 20:12:28.382583
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert isinstance(str_0, str)
    assert len(str_0) == 11


# Generated at 2022-06-25 20:12:32.579658
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    try:
        provider = RussiaSpecProvider()
        assert type(provider.snils()) is str
        assert len(provider.snils()) == 11
    except TypeError:
        raise



# Generated at 2022-06-25 20:12:37.799589
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert len(str_0) == 11


# Generated at 2022-06-25 20:12:39.814683
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    import re
    russia_spec_provider_0 = RussiaSpecProvider()
    # Check for match between generated snils and regex for proper snils
    assert re.match(r'\d{11}', russia_spec_provider_0.snils())


# Generated at 2022-06-25 20:12:42.877895
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    print(RussiaSpecProvider.snils(RussiaSpecProvider()))


# Generated at 2022-06-25 20:12:45.037188
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    str_0 = russia_spec_provider_0.snils()
    assert len(str_0) == 11
