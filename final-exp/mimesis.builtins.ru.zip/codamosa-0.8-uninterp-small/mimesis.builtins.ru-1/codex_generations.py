

# Generated at 2022-06-25 20:08:00.078199
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    snils = russia_spec_provider.snils()
    assert len(snils) == 11, 'Error in method snils'
    return snils


# Generated at 2022-06-25 20:08:05.002901
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    snils = russia_spec_provider.snils()
    assert len(snils) == 11
    assert isinstance(snils, str)



# Generated at 2022-06-25 20:08:08.532273
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11


# Generated at 2022-06-25 20:08:13.528063
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    test_data_1 = russia_spec_provider.snils()
    test_data_2 = russia_spec_provider.snils()
    assert len(test_data_1) == 11
    assert len(test_data_2) == 11
    assert russia_spec_provider.snils().__class__ == str


# Generated at 2022-06-25 20:08:17.957863
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_snils = RussiaSpecProvider()
    print('RussiaSpecProvider snils: {}'.format(russia_spec_provider_snils.snils()))


# Generated at 2022-06-25 20:08:21.081415
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert len(russia_spec_provider_0.snils()) == 11

# Generated at 2022-06-25 20:08:23.340403
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert len(russia_spec_provider_0.snils()) == 11


# Generated at 2022-06-25 20:08:31.947820
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    print("Executing test case 0:")
    russia_spec_provider_0 = RussiaSpecProvider()
    function_output_value_0 = russia_spec_provider_0.snils()
    print("\tFunction output value: " + str(function_output_value_0))
    assert str(function_output_value_0).__len__() == 11
    print("Test case 0 passed!")


# Generated at 2022-06-25 20:08:35.440179
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    import re
    r = RussiaSpecProvider()
    result = r.snils()
    pattern = r'\d{11}'
    if re.match(pattern, str(result)) is None:
        raise Exception("Результат не является действительным СНИЛСом")


# Generated at 2022-06-25 20:08:39.065436
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()

    # number of iterations, >1
    iteration_number = 10
    # check if the length of snils is 11
    length = 11

    for _ in range(iteration_number):
        snils = russia_spec_provider_0.snils()

        # check if the length of snils is 11
        assert len(snils) == length


# Generated at 2022-06-25 20:08:59.457136
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider"""
    russia_spec_provider = RussiaSpecProvider()
    snils = russia_spec_provider.snils()
    assert snils == '23376915952'


# Generated at 2022-06-25 20:09:02.101500
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russiasnils = RussiaSpecProvider()
    assert isinstance(russiasnils.snils(), str) == True


# Generated at 2022-06-25 20:09:04.799874
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    result = russia_spec_provider_0.snils()
    assert len(str(result)) == 11, 'Test failed.'


# Generated at 2022-06-25 20:09:12.056565
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()

    # Call method snils of class RussiaSpecProvider
    # pass input parameter None
    # return value None
    result_snils_0 = russia_spec_provider_0.snils()
    print(result_snils_0)



# Generated at 2022-06-25 20:09:14.663066
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    assert len(russia_spec_provider_1.snils()) == len('41917492600')


# Generated at 2022-06-25 20:09:20.173399
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    russia_spec_provider_0 = RussiaSpecProvider()
    assert len(russia_spec_provider_0.snils()) == 11



# Generated at 2022-06-25 20:09:25.173149
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Check if the number is valid
    snils = russia_spec_provider_0.snils()
    assert snils == '93569489431' or snils == '52413257857'


# Generated at 2022-06-25 20:09:30.676760
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    snils = RussiaSpecProvider().snils()
    assert len(snils) == 11, \
        'TEST FAILED: "snils" method of "RussiaSpecProvider" class must return string with length 11'


# Generated at 2022-06-25 20:09:36.873984
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russian_spec_provider = RussiaSpecProvider()
    assert russian_spec_provider.snils() is not None
    assert type(russian_spec_provider.snils()) == str
    # If a random sequence is generated by the test,
    # there is a chance that it will be a duplicate
    # of the sequence generated by a previous test.
    # To avoid this, the following condition is set
    assert len(russian_spec_provider.snils()) == 11



# Generated at 2022-06-25 20:09:40.039176
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    result = russia_spec_provider_0.snils()
    assert True

# Generated at 2022-06-25 20:10:17.797125
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # The test checks whether the generated value is a string, not empty
    russia_spec_provider_0 = RussiaSpecProvider()
    assert isinstance(russia_spec_provider_0.snils(), str)
    assert russia_spec_provider_0.snils() != ''


# Generated at 2022-06-25 20:10:22.191944
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():

    russia_spec_provider_0 = RussiaSpecProvider()
    assert russia_spec_provider_0.snils() == '88010307800'


# Generated at 2022-06-25 20:10:25.848576
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert russia_spec_provider_0.snils() == '20637783796'


# Generated at 2022-06-25 20:10:31.998663
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Generate first snils
    russia_spec_provider_0 = RussiaSpecProvider()
    snils = russia_spec_provider_0.snils()
    # Generate second snils
    russia_spec_provider_1 = RussiaSpecProvider()
    snils_1 = russia_spec_provider_1.snils()
    # Check snils generating
    if snils == snils_1:
        print("RussiaSpecProvider snils method is works")
    else:
        print("RussiaSpecProvider snils method is not working")


# Generated at 2022-06-25 20:10:33.728572
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider(seed=1000)
    assert russia_spec_provider.snils() == "41917492600"


# Generated at 2022-06-25 20:10:39.360306
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    parse_snils = russia_spec_provider.snils()
    assert len(parse_snils) == 11
    assert int(parse_snils) > 1000000 and int(parse_snils) < 10000000


# Generated at 2022-06-25 20:10:45.007859
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert len(russia_spec_provider_0.snils()) == 11
    assert type(russia_spec_provider_0.snils()) is str


# Generated at 2022-06-25 20:10:48.720481
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert len(russia_spec_provider_0.snils()) == 11


# Generated at 2022-06-25 20:10:55.388956
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    result = str(russia_spec_provider_0.snils())
    string_list = ['31782172788', '31123573092', '66577348848']
    assert result in string_list


# Generated at 2022-06-25 20:10:57.536620
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    RussiaSpecProvider.snils()  # type: ignore


# Generated at 2022-06-25 20:11:33.645246
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    pattern = r"""^\d{11}$"""
    result = re.compile(pattern)
    snils = russia_spec_provider_1.snils()
    if result.match(snils):
        return True
    else:
        return False


# Generated at 2022-06-25 20:11:36.975124
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    assert(russia_spec_provider_0.snils() == '41917492600')


# Generated at 2022-06-25 20:11:39.355338
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()
    assert isinstance(rsp.snils(), str)


# Generated at 2022-06-25 20:11:43.688373
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    assert russia_spec_provider_1.snils()


# Generated at 2022-06-25 20:11:47.774297
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    snils_0 = russia_spec_provider_0.snils()

    assert snils_0.isnumeric()

# Generated at 2022-06-25 20:11:50.162208
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    snils_0 = russia_spec_provider_0.snils()
    assert snils_0 == '41917492600'


# Generated at 2022-06-25 20:12:00.573011
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():

    russia_spec_provider_1 = RussiaSpecProvider()
    result_1 = russia_spec_provider_1.snils()
    print(result_1)

    russia_spec_provider_2 = RussiaSpecProvider()
    result_2 = russia_spec_provider_2.snils()
    print(result_2)

    russia_spec_provider_3 = RussiaSpecProvider()
    result_3 = russia_spec_provider_3.snils()
    print(result_3)


# Generated at 2022-06-25 20:12:11.527209
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rus = RussiaSpecProvider()
    коды = ['000000000', '001002003', '002004006', '003006009', '004008012', '005001005', '006003008', '007005011', '008007014', '009009017']
    for x in range(10):
        коды[x] = int(коды[x])
    for x in range(200):
        assert len(str(rus.snils())) == 11
        assert rus.snils() in коды


# Generated at 2022-06-25 20:12:21.212542
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    snils = russia_spec_provider_1.snils()
    assert snils == '27454299700' or snils == '05282244609' or snils == '98659618054' or snils == '10377837286' or snils == '71671893782'


# Generated at 2022-06-25 20:12:26.558786
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider(seed=2)
    russia_spec_provider_1 = RussiaSpecProvider(seed=2)
    russia_spec_provider_2 = RussiaSpecProvider(seed=2)
    russia_spec_provider_3 = RussiaSpecProvider(seed=2)
    russia_spec_provider_4 = RussiaSpecProvider(seed=2)
    russia_spec_provider_5 = RussiaSpecProvider(seed=2)
    assert russia_spec_provider_0.snils() == '28889332913'
    assert russia_spec_provider_1.snils() == '28889332913'
    assert russia_spec_provider_2.snils() == '28889332913'
    assert russia_spec_

# Generated at 2022-06-25 20:13:41.640178
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    assert russia_spec_provider_1.snils() == '61384871592'



# Generated at 2022-06-25 20:13:48.457974
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider(seed=3855340973)
    russia_spec_provider_1 = RussiaSpecProvider(seed=37203032)
    russia_spec_provider_2 = RussiaSpecProvider(seed=86961644)
    russia_spec_provider_3 = RussiaSpecProvider(seed=566548588)
    russia_spec_provider_4 = RussiaSpecProvider(seed=3469609748)
    russia_spec_provider_5 = RussiaSpecProvider(seed=4272867863)
    russia_spec_provider_6 = RussiaSpecProvider(seed=2127733949)
    russia_spec_provider_7 = RussiaSpecProvider(seed=3796597189)
    russia_spec_provider_8 = Russia

# Generated at 2022-06-25 20:13:50.087859
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    snils = russia_spec_provider.snils()
    assert len(snils) == 11
    assert snils



# Generated at 2022-06-25 20:13:52.389891
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    snils = russia_spec_provider_0.snils()
    assert snils == '41917492600'


# Generated at 2022-06-25 20:13:53.932690
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider()
    russia_spec_provider_1.snils()

# Generated at 2022-06-25 20:13:56.587663
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_1 = RussiaSpecProvider(seed=100)
    snils = russia_spec_provider_1.snils()
    assert snils == '41861599600'


# Generated at 2022-06-25 20:14:03.059958
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider(seed = "12345")
    list = []
    for i in range(0, 10):
        list.append(russia_spec_provider.snils())
    assert list == ['41917492602', '96252051385', '22855119481', '17527239826', '55795589764', '47997673560', '68906400637', '83219687937', '26609120837', '89486487249']


# Generated at 2022-06-25 20:14:06.810796
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    import re
    russia_spec_provider = RussiaSpecProvider()
    snils = russia_spec_provider.snils()
    assert re.match(r"\d{11}", snils) is not None


# Generated at 2022-06-25 20:14:09.527254
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider_0 = RussiaSpecProvider()
    output_0 = russia_spec_provider_0.snils()
    assert len(output_0) == 11

test_case_0()
test_RussiaSpecProvider_snils()

# Generated at 2022-06-25 20:14:11.553719
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_spec_provider = RussiaSpecProvider()
    assert russia_spec_provider.snils() == '42015533300'
    assert len(russia_spec_provider.snils()) == 11
