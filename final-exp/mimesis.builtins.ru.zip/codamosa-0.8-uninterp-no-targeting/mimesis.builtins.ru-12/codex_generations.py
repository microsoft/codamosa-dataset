

# Generated at 2022-06-21 15:35:11.131757
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    rp = RussiaSpecProvider()
    series = rp.passport_series()
    assert len(series) == 5
    assert series == '{}{}{}{}{}'.format(
        series[0],
        series[1],
        series[2],
        series[3],
        series[4],
    )



# Generated at 2022-06-21 15:35:13.483450
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    ru = RussiaSpecProvider()
    ru.provider = 'ru_provider'
    ru.seed = 1234
    

# Generated at 2022-06-21 15:35:18.664926
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    provider = RussiaSpecProvider()
    passport_series = provider.passport_series(year=17)
    assert len(passport_series) == 5
    assert int(passport_series[-2:]) == 17
    assert int(passport_series[:2]) < 100
    assert int(passport_series[:2]) > 0



# Generated at 2022-06-21 15:35:25.588432
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    from mimesis import Generic
    from mimesis.enums import Gender

    g = Generic('ru')
    for _ in range(0, 1000):
        assert len(g.russia_provider.bic()) == 9

    g.seed(0)
    assert g.russia_provider.bic() == '044025575'

    g.seed(1)
    assert g.russia_provider.bic() == '045069168'

    g.seed(2)
    assert g.russia_provider.bic() == '045027189'


# Generated at 2022-06-21 15:35:28.066384
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    from mimesis.typing import Seed

    R = RussiaSpecProvider(seed=Seed(1))
    assert R.inn() == '1101158733'



# Generated at 2022-06-21 15:35:33.511657
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    provider = RussiaSpecProvider()
    expected = 6
    value = provider.passport_number()
    while (value < 100000 and value > 999999):
        value = provider.passport_number()
    assert len(str(value)) == expected


# Generated at 2022-06-21 15:35:35.932676
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    russia = RussiaSpecProvider(seed=1337)
    series = russia.passport_series(1)
    assert series == '43 01'


# Generated at 2022-06-21 15:35:38.351198
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.enums import Gender
    ru = RussiaSpecProvider()
    ru.snils()
    snils = ru.snils()
    assert len(str(snils)) == 11


# Generated at 2022-06-21 15:35:41.400816
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    """Test for method generate sentence."""
    russian = RussiaSpecProvider()
    result = russian.generate_sentence()
    assert type(result) is str


# Generated at 2022-06-21 15:35:43.355822
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    assert RussiaSpecProvider().series_and_number() == '96 16 087226'



# Generated at 2022-06-21 15:36:02.169242
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert type(RussiaSpecProvider().snils()) == str

# Generated at 2022-06-21 15:36:08.155742
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """ Test method kpp of class RussiaSpecProvider """
    russian_spec_provider = RussiaSpecProvider()
    kpp = russian_spec_provider.kpp()
    assert len(kpp) == 10
    numbers = [int(x) for x in kpp]
    assert type(numbers[0]) == int
    assert type(numbers[9]) == int
    assert numbers[0] != 0

# Generated at 2022-06-21 15:36:11.313086
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    provider = RussiaSpecProvider
    series = provider.passport_series(provider)
    assert isinstance(series, str)

# Generated at 2022-06-21 15:36:13.930150
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    a = RussiaSpecProvider()
    res = a.passport_number()
    assert isinstance(res, int)


# Generated at 2022-06-21 15:36:18.084180
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Unit test for method ogrn of class RussiaSpecProvider."""
    from mimesis.enums import Gender
    provider = RussiaSpecProvider()
    for i in range(100):
        assert len(provider.ogrn()) == 13
        assert provider.ogrn().isdigit()

# Generated at 2022-06-21 15:36:19.963976
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    """Unit test for constructor of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    assert provider is not None

# Generated at 2022-06-21 15:36:22.061967
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider(seed=12345)
    result = r.snils()
    assert result == '41917492600'


# Generated at 2022-06-21 15:36:24.694177
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    rsp = RussiaSpecProvider()
    rsp.seed(10)
    result = rsp.series_and_number()
    expected = '57 16 805199'
    assert result == expected

# Generated at 2022-06-21 15:36:30.850678
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    from mimesis.enums import Gender
    from mimesis.providers import RussiaSpecProvider
    assert isinstance(RussiaSpecProvider().patronymic(), str)
    assert isinstance(RussiaSpecProvider().patronymic(gender=Gender.FEMALE), str)
    assert isinstance(RussiaSpecProvider().patronymic(gender=Gender.MALE), str)

# Generated at 2022-06-21 15:36:33.899877
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils_test = '41917492600'
    assert provider.snils() == snils_test


# Generated at 2022-06-21 15:37:17.324879
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    """Unit test for method patronymic of class RussiaSpecProvider."""

    assert RussiaSpecProvider(seed=42).patronymic(Gender.MALE) == 'Николаевич'
    assert RussiaSpecProvider(seed=42).patronymic(Gender.FEMALE) == 'Александровна'
    assert RussiaSpecProvider(seed=42).patronymic() == 'Николаевна'


# Generated at 2022-06-21 15:37:23.443586
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    r = RussiaSpecProvider()
    assert r.patronymic(Gender.FEMALE) == "Алексеевна"
    assert r.patronymic(Gender.MALE) == "Иванович"
    assert r.patronymic(Gender.OTHER) == "Алексеевна" or r.patronymic(Gender.OTHER) == "Иванович"


# Generated at 2022-06-21 15:37:27.214482
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    russia_spec_provider = RussiaSpecProvider()
    russia_spec_provider.generate_sentence()
    gen_sen = russia_spec_provider.generate_sentence()
    assert isinstance(gen_sen, str)


# Generated at 2022-06-21 15:37:29.004415
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    bic = RussiaSpecProvider().bic()
    assert len(bic) == 9


# Generated at 2022-06-21 15:37:36.643967
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Initialize RussiaSpecProvider
    russia_sp = RussiaSpecProvider()

    # Create list
    snils_generated = []

    # Append 1000 random generated snils to list
    i = 0
    while i < 1000:
        snils_generated.append(russia_sp.snils())
        i += 1

    # Check uniqueness of 1000 values
    unique_snils = set(snils_generated)
    assert len(unique_snils) == len(snils_generated)
    assert len(unique_snils) == 1000

# Generated at 2022-06-21 15:37:39.759490
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider()

    bic = provider.bic()
    assert bic is not None
    assert bic[0:2] == '04'
    assert len(bic) == 9


# Generated at 2022-06-21 15:37:43.351456
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    series_and_number = RussiaSpecProvider().series_and_number()
    series_dir, number_dir = series_and_number.split()
    assert len(series_dir) == 4
    assert len(number_dir) == 6


# Generated at 2022-06-21 15:37:47.296730
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    provider = RussiaSpecProvider()
    kpp = provider.kpp()
    assert len(kpp) == 9
    assert kpp[:4].isdigit()
    assert kpp[4].isdigit()
    assert kpp[5].isdigit()
    assert kpp[6:9].isdigit()


# Generated at 2022-06-21 15:37:48.989901
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    p = RussiaSpecProvider()
    print(p.bic())


# Generated at 2022-06-21 15:37:53.916521
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    russia = RussiaSpecProvider()
    kpp = russia.kpp()
    russia.seed(russia.random.randint(0, 1000))
    russia_kpp = russia.kpp()
    assert kpp == russia_kpp

# Generated at 2022-06-21 15:39:19.539861
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    russiaspecprovider = RussiaSpecProvider()
    russiaspecprovider.seed(38)
    assert russiaspecprovider.generate_sentence() == 'Некоторые ключевые понятия в ментальном пространстве'


# Generated at 2022-06-21 15:39:23.214439
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    """Test for method generate_sentence of class RussiaSpecProvider."""
    provider = RussiaSpecProvider(seed=42)
    sentence = provider.generate_sentence()
    assert sentence, 'Сделать можно и так'


# Generated at 2022-06-21 15:39:25.572416
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    provider = RussiaSpecProvider()
    assert type(provider) is RussiaSpecProvider

#Unit test for method generate_sentence of class RussiaSpecProvider

# Generated at 2022-06-21 15:39:28.626718
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Arrange
    from mimesis import RussiaSpecProvider
    rsp = RussiaSpecProvider()
    # Act
    result = rsp.snils()
    # Assert
    assert len(result) == 11



# Generated at 2022-06-21 15:39:31.746034
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    # Test count of digits in method kpp
    test = RussiaSpecProvider()
    # in this case result string must be 9 digits
    if len(test.kpp()) == 9:
       print('True')
    else:
       print('False')


# Generated at 2022-06-21 15:39:35.848462
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    """Test method bic for class RussiaSpecProvider.

    Args:
        None.

    Returns:
        None.

    Raises:
        AssertError: Method should return string with correct BIC.
    """
    rsp = RussiaSpecProvider()
    bic = rsp.bic()
    assert len(bic) == 9
    assert bic.startswith("04")



# Generated at 2022-06-21 15:39:38.802707
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Testing method RussiaSpecProvider.series_and_number()."""
    r = RussiaSpecProvider(seed=42)
    sn = r.series_and_number()
    assert sn == '62 14 647467'

# Generated at 2022-06-21 15:39:42.006630
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    """Test the return type of method generate_sentence
    of class RussianSpecProvider.
    """
    provider = RussiaSpecProvider()
    sentence = provider.generate_sentence()    
    assert isinstance(sentence, str)


# Generated at 2022-06-21 15:39:52.809585
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    from mimesis.providers.base import BaseSpecProvider
    from mimesis.data import EN
    from mimesis.enums import Gender
    from mimesis.exceptions import NonEnumerableError

    spec = RussiaSpecProvider(BaseSpecProvider(EN))

    for x in range(0, 10):
        assert isinstance(spec.passport_series(), str)

    assert isinstance(spec.passport_series(year=2004), str)

    try:
        assert spec.passport_series(year='2004')
    except TypeError:
        pass

    try:
        assert spec.passport_series(year=2004, gender=Gender.MALE)
    except TypeError:
        pass


# Generated at 2022-06-21 15:39:57.654009
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    from mimesis.enums import Gender
    from mimesis.providers.geo.russia import RussiaSpecProvider 
    provider = RussiaSpecProvider()
    item = provider.passport_series(year=18)
    assert item == '02 18'
    item = provider.passport_series()
    assert item == '02 18' or item == '02 17'
