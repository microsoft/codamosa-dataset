

# Generated at 2022-06-21 15:35:15.120678
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia_data = RussiaSpecProvider()
    # Test 1
    snils = russia_data.snils()
    assert len(snils) == 11
    # Test 2
    snils = russia_data.snils()
    assert snils.isnumeric()
    # Test 3
    snils = russia_data.snils()
    assert snils.isdigit()

# Generated at 2022-06-21 15:35:17.996758
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    provider = RussiaSpecProvider()
    kpp = provider.kpp()
    assert len(kpp) == 9
    assert kpp == '560058652'

# Generated at 2022-06-21 15:35:26.795065
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    from mimesis.enums import Gender
    from mimesis.providers.person.en import Person
    from mimesis.providers.person.ru import RussiaPerson
    from mimesis.providers.address.ru import RussiaAddress
    from mimesis.providers.person.ru import RussiaSpecProvider
    spec = RussiaSpecProvider()
    person = RussiaPerson('ru')
    russia_address = RussiaAddress('ru')
    address = russia_address.address_with_street()
    fullname = person.full_name(gender=Gender.MALE)
    dob = person.birth_date()
    inn = spec.inn()
    ogrn = spec.ogrn()
    snils = spec.snils()
    kpp = spec.kpp()
    assert inn[0] != '0'
   

# Generated at 2022-06-21 15:35:30.875453
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    from mimesis.providers.russia import RussiaSpecProvider
    rs = RussiaSpecProvider('RU')
    for i in range(100):
        assert len(rs.inn()) == 12

# Generated at 2022-06-21 15:35:32.829897
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    for _ in range(20):
        print(RussiaSpecProvider().generate_sentence())


# Generated at 2022-06-21 15:35:34.174145
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Test ogrn method"""
    ogrn = RussiaSpecProvider().ogrn()
    assert len(ogrn) == 13


# Generated at 2022-06-21 15:35:39.030695
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Test method passport_series of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    
    series = provider.passport_series(None)
    assert series != None
    print('test_RussiaSpecProvider_passport_series: series: ', series)
    assert len(series.split(' ')) == 2
    

# Generated at 2022-06-21 15:35:43.258743
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Test the method passport_series of class RussiaSpecProvider with
    the parameters in the line below.

    :return: A list of the results.
    """
    provider = RussiaSpecProvider()
    result = provider.passport_series(year=20)
    return result


# Generated at 2022-06-21 15:35:45.100221
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    ru = RussiaSpecProvider()
    assert ru.generate_sentence() == 'Я и мы хорошо!'

# Generated at 2022-06-21 15:35:48.010714
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    provider = RussiaSpecProvider()
    assert len(provider.series_and_number()) == 11

if __name__ == '__main__':
    test_RussiaSpecProvider_series_and_number()

# Generated at 2022-06-21 15:36:06.266509
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    assert RussiaSpecProvider().snils() == '02113142800'

# Generated at 2022-06-21 15:36:07.706458
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    """Generate random sentence."""
    rs = RussiaSpecProvider()
    print(":: ", rs.generate_sentence())



# Generated at 2022-06-21 15:36:10.168212
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    assert RussiaSpecProvider().bic() == "044025575"



# Generated at 2022-06-21 15:36:11.948974
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11

# Generated at 2022-06-21 15:36:15.577421
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    # Arrange
    n = RussiaSpecProvider()
    n._random.seed(2)

    # Assert
    assert n.bic() == '044025575'


# Generated at 2022-06-21 15:36:25.271433
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    ru = RussiaSpecProvider()

    assert ru.patronymic(Gender.MALE) == "Александрович"
    assert ru.patronymic(Gender.FEMALE) == "Алексеевна"
    assert ru.patronymic(Gender.NON_BINARY) == "Алексеевна"
    assert ru.patronymic(Gender.NOT_KNOWN) == "Александрович"

    assert ru.generate_sentence() == "Он машинка игрушка динозавр создает"

    assert ru.passport_series

# Generated at 2022-06-21 15:36:28.363426
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    r = RussiaSpecProvider()
    kpp = r.kpp()
    assert isinstance(kpp, str)



# Generated at 2022-06-21 15:36:32.449559
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """The test checks the unique method."""
    from mimesis.providers import RussiaSpecProvider
    provider = RussiaSpecProvider('ru')
    assert provider.ogrn() == "4715113303725"


# Generated at 2022-06-21 15:36:34.844182
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    rsp = RussiaSpecProvider()
    assert rsp == rsp
    assert rsp.random.seed == rsp._seed


# Generated at 2022-06-21 15:36:38.311733
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    '''Test that snils method returns a random snils valid format'''
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11


# Generated at 2022-06-21 15:37:12.394211
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    random_number = RussiaSpecProvider().inn()
    assert len(random_number) == 10


# Generated at 2022-06-21 15:37:15.661506
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    from mimesis import RussiaSpecProvider
    assert RussiaSpecProvider().ogrn() == '4715113303725'


# Generated at 2022-06-21 15:37:18.324328
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    rsp = RussiaSpecProvider()
    for i in range(0, 1000):
        kpp = rsp.kpp()
        assert(len(kpp) == 9)


# Generated at 2022-06-21 15:37:22.290089
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    seed = 0
    russia = RussiaSpecProvider(seed)
    assert russia.__class__.__name__ == "RussiaSpecProvider"
    assert russia.__doc__ != ""
    assert russia.__doc__ is not None


# Generated at 2022-06-21 15:37:24.256551
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    a = RussiaSpecProvider()
    x = a.passport_series()
    assert len(x) == 5


# Generated at 2022-06-21 15:37:26.637550
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    bic = RussiaSpecProvider().bic()
    assert len(bic) == 9
    assert type(bic) is str


# Generated at 2022-06-21 15:37:31.316349
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    """Test RussiaSpecProvider.bic method"""
    bic = RussiaSpecProvider(seed = -1447942823)
    assert bic.bic() == '044025575'
    assert bic.bic() == '047032461'
    assert bic.bic() == '046069336'


# Generated at 2022-06-21 15:37:42.339883
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Test INN generation."""
    Inn = RussiaSpecProvider().inn()
    print(Inn)

    # Test if length of Inn is correct
    if len(Inn) != 10:
        raise AssertionError('Длина ИНН а не 10 символов')

    numbs = []
    for i in Inn:
        numbs.append(int(i))

    # Test if first number is not equal to zero
    if numbs[0] == 0:
        raise AssertionError('Первая цифра ИНН не может быть равна "0"')

    # Calculation of checksum

# Generated at 2022-06-21 15:37:45.054333
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Unit test for method inn of class RussiaSpecProvider"""
    PROVIDER = RussiaSpecProvider()
    INN = PROVIDER.inn()
    assert len(INN) == 10
    assert INN[0] == '0'

# Generated at 2022-06-21 15:37:45.936621
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    pass



# Generated at 2022-06-21 15:39:02.387682
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    rsp_1 = RussiaSpecProvider()
    rsp_2 = RussiaSpecProvider()
    rsp_3 = RussiaSpecProvider()
    assert rsp_1.bic() != rsp_2.bic()
    assert rsp_2.bic() != rsp_3.bic()
    assert rsp_1.bic() != rsp_3.bic()


# Generated at 2022-06-21 15:39:07.363368
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Test function passport_series() of class
    RussiaSpecProvider.
    """

    rsp = RussiaSpecProvider()

    res = rsp.passport_series()

    assert len(res) == 5


test_info = [
    ('test_RussiaSpecProvider_passport_series',
     test_RussiaSpecProvider_passport_series),
]

# Generated at 2022-06-21 15:39:11.149264
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.person import Person
    from mimesis.providers.russia import RussiaSpecProvider
    from mimesis.enums import Gender
    r = RussiaSpecProvider()
    p = Person(r.__class__)
    series_and_number = r.series_and_number()
    series = series_and_number[0:6]
    number = series_and_number[6:12]
    sex = p.gender()
    data = {1:'М', 2:'Ж'}
    snils = r.snils()
    assert series_and_number[0:2] in '10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33'.split()
    assert len(series) == 6
    assert len(number) == 6
   

# Generated at 2022-06-21 15:39:17.953050
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    list = []
    russian = RussiaSpecProvider()

    # тест на то, что сгенерированные значения не повторяются
    for i in range(0, 1000):
        list.append(russian.bic())
    for element in list:
        count = list.count(element)
        assert count == 1

    # тест на то, что генерируемые значения верны
    for i in range(0, 1000):
        assert len(russian.bic()) == 9

# Generated at 2022-06-21 15:39:23.582193
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    passport_number_expected = [
        1377944, 1377944, 1377944, 1377944, 1377944,
        1377944, 1377944, 1377944, 1377944, 1377944
    ]
    russia_spec_provider = RussiaSpecProvider(seed=1377944)
    assert [russia_spec_provider.passport_number() for i in range(10)] == passport_number_expected

# Generated at 2022-06-21 15:39:27.661949
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """
    Test for method kpp of class RussiaSpecProvider
    """
    spec = RussiaSpecProvider()
    kpp = spec.kpp()
    assert len(kpp) == 9
    assert kpp[:4].isnumeric() and kpp[4:].isnumeric()

# Generated at 2022-06-21 15:39:29.917184
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    provider = RussiaSpecProvider('ru')
    number = provider.passport_number()
    print(number)
    assert len(str(number)) == 6


# Generated at 2022-06-21 15:39:32.323617
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    RussiaSpecProvider.kpp()
    #if not RussiaSpecProvider.kpp() == RussiaSpecProvider.kpp():
    #    raise AssertionError("test failed of [method kpp of class RussiaSpecProvider]")

# Generated at 2022-06-21 15:39:38.183981
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    k = RussiaSpecProvider()
    valid_series_and_number = 0
    for i in range(100):
        series_and_number = k.series_and_number()
        series = series_and_number[0:4]
        number = series_and_number[4:10]
        if series[2:4].isdigit():
            if series[0:2].isdigit():
                if number.isdigit():
                    valid_series_and_number += 1
    assert valid_series_and_number == 100


# Generated at 2022-06-21 15:39:40.664022
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    data = RussiaSpecProvider()
    value = data.series_and_number()
    assert len(value) == 10
    assert value not in (None, "")


# Generated at 2022-06-21 15:42:55.432624
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Test for method passport_series of class RussiaSpecProvider.

    Test result: 02 15

    """
    a = RussiaSpecProvider()
    result = a.passport_series(2020)
    print(result)
    assert result == '02 20'


# Generated at 2022-06-21 15:43:01.253682
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    a = RussiaSpecProvider(seed=1000)
    b = RussiaSpecProvider(seed=1000)
    l = ["165700238", "123500240", "275900333", "944100363", "623700667", "318500118"]
    assert a.kpp() in l
    assert b.kpp() in l

# Generated at 2022-06-21 15:43:04.214162
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """Unit test for method kpp of class RussiaSpecProvider"""
    ru = RussiaSpecProvider(seed=123)
    assert ru.kpp() == '560058652'



# Generated at 2022-06-21 15:43:08.524908
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    """Sample tests."""
    # Create obj
    russian_provider = RussiaSpecProvider()
    # Check its type
    assert isinstance(russian_provider, RussiaSpecProvider)

# Normal test for generate_sentence()

# Generated at 2022-06-21 15:43:09.993090
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    assert RussiaSpecProvider().passport_series()


# Generated at 2022-06-21 15:43:16.356513
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    """Unit test for RussiaSpecProvider class."""
    print('Testing of RussiaSpecProvider class')
    try:
        test = RussiaSpecProvider()
        assert isinstance(test, RussiaSpecProvider)
        print('Test 1 - OK!')
    except AssertionError:
        print('Test 1 - FAILED!')
    except RuntimeError:
        print('Test 1 - ERROR!')


# Generated at 2022-06-21 15:43:18.566943
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    instance = RussiaSpecProvider()
    assert instance.snils() == '41917492600'

# Generated at 2022-06-21 15:43:20.354558
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    provider = RussiaSpecProvider(seed=42)
    assert provider.__class__.__name__ == 'RussiaSpecProvider'

# Generated at 2022-06-21 15:43:24.520371
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Unit test case for method passport_series of class RussiaSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers.address import Address
    assert RussiaSpecProvider().passport_series(1991) == '02 91'
    assert RussiaSpecProvider(seed=1000).passport_series(1992) == '31 92'


# Generated at 2022-06-21 15:43:26.688648
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    for x in range(0, 10):
        series_and_number = RussiaSpecProvider().series_and_number()
        assert len(series_and_number) == 11
