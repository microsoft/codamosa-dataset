

# Generated at 2022-06-21 15:35:08.215195
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    f = RussiaSpecProvider()
    try:
        y = f.passport_number()
        assert y.__len__() == 6
    except:
        pass



# Generated at 2022-06-21 15:35:12.635009
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """
    Test for method kpp of class RussiaSpecProvider
    """
    # Create a RussiaSpecProvider instance
    russiaSpecProviderInstance = RussiaSpecProvider()
    # Run the method kpp
    russiaSpecProviderInstance.kpp()

# Generated at 2022-06-21 15:35:17.368347
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """
    Testing the method passport_number.
    """
    from mimesis.providers.generic import Random

    rus_spec_provider = RussiaSpecProvider()
    rus_spec_provider.random = Random(0)

    assert rus_spec_provider.passport_number() == 974074


# Generated at 2022-06-21 15:35:19.703794
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    bic = RussiaSpecProvider().bic()
    assert bic is not None
    assert isinstance(bic, str)
    assert len(bic) == 9


# Generated at 2022-06-21 15:35:20.467874
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    tR=RussiaSpecProvider()


# Generated at 2022-06-21 15:35:28.709842
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    from mimesis.providers.person import Person
    from mimesis.providers.date import Date
    from mimesis.providers.generic import Generic
    from mimesis.providers.internet import Internet
    from mimesis.providers.phone_number import PhoneNumber
    from mimesis.providers.address import Address
    from mimesis.providers.payment import Payment
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.text import Text
    from mimesis.providers.business import Business
    from mimesis.providers.identifier import Identifier
    import csv

    person = Person('ru')
    date = Date('ru')
    generic = Generic('ru')
    internet = Internet('ru')
    phone_number = PhoneNumber('ru')
   

# Generated at 2022-06-21 15:35:32.829907
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    russian_provider = RussiaSpecProvider(seed=123456789)
    passport_number = russian_provider.passport_number()
    return passport_number == 589172

# Generated at 2022-06-21 15:35:35.674935
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    from mimesis import RussiaSpecProvider
    from mimesis.enums import Gender
    r = RussiaSpecProvider()
    for i in range(3):
        print(r.passport_number())


# Generated at 2022-06-21 15:35:37.839774
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    assert '41556354400' == provider.snils()



# Generated at 2022-06-21 15:35:40.473879
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    passport_number = RussiaSpecProvider().passport_number()
    assert len(str(passport_number)) == 6


# Generated at 2022-06-21 15:36:03.962543
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    import re
    pattern = re.compile(r'\d{4}\s\d{2}\s\d{6}')
    if re.match(pattern, RussiaSpecProvider().series_and_number()):
        pass
    else:
        raise AssertionError('Incorrect series and number')


# Generated at 2022-06-21 15:36:06.838981
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    provider = RussiaSpecProvider()
    passport_number = provider.passport_number()

    assert len(str(passport_number)) == 6


# Generated at 2022-06-21 15:36:08.395024
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    result = RussiaSpecProvider(seed=1).ogrn()
    assert result == '037709905238'

# Generated at 2022-06-21 15:36:11.369486
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    RussiaSpecProvider_gen_sent = RussiaSpecProvider()
    RussiaSpecProvider_gen_sent.generate_sentence()


# Generated at 2022-06-21 15:36:13.979417
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    print("Running test_RussiaSpecProvider_snils test")
    provider = RussiaSpecProvider()
    print(provider.snils())


# Generated at 2022-06-21 15:36:22.076423
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    country_id = "ru"
    from mimesis.providers.country import Country
    country = Country(country_id)
    ru_provider = RussiaSpecProvider(seed=country.id)
    ru_passport_series = ru_provider.passport_series(year=None)
    from mimesis.providers.passport import Passport
    ru_passport_series_1 = Passport(country_id)
    ru_passport_series_2 = ru_passport_series_1.series()
    assert ru_passport_series != ru_passport_series_2

# Generated at 2022-06-21 15:36:23.176738
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    provider = RussiaSpecProvider()
    assert len(provider.kpp()) == 9

# Generated at 2022-06-21 15:36:26.583286
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Test for method inn of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    inn = provider.inn()
    assert len(inn) == 10, "Can't generate inn."
    assert int(inn[9]) == provider._check_inn(inn), "Inn doesn't pass check sum."



# Generated at 2022-06-21 15:36:29.973204
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    """Test to generate a sentence."""
    rsp = RussiaSpecProvider()
    result = rsp.generate_sentence()
    assert result is not None and isinstance(result, str)


# Generated at 2022-06-21 15:36:32.831966
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    """Test the method bic of class RussiaSpecProvider."""
    foo = RussiaSpecProvider()
    foo.bic()


# Generated at 2022-06-21 15:37:09.365493
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    russiaspecific_provider = RussiaSpecProvider()
    kpp = russiaspecific_provider.kpp()
    assert len(kpp) == 9
    assert type(kpp) == str


# Generated at 2022-06-21 15:37:12.747589
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    russian = RussiaSpecProvider()
    for _ in range(10):
        result = russian.passport_series(18)
        assert len(result) == 5
        assert(isinstance(result, str))


# Generated at 2022-06-21 15:37:14.430096
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    assert RussiaSpecProvider().passport_series() == '02 15'



# Generated at 2022-06-21 15:37:23.469939
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    r = RussiaSpecProvider()
    assert isinstance(r, RussiaSpecProvider)
    assert(len(r.snils()) == 11)
    assert(len(r.inn()) == 12)
    assert(len(r.ogrn()) == 13)
    assert(len(r.kpp()) == 9)
    assert(len(r.bic()) == 9)
    assert(len(r.series_and_number()) == 11)
    assert(len(str(r.passport_number())) == 6)
    assert r.generate_sentence()
    r.seed(1510186583)
    assert (r.snils() == '41917492600')
    assert (r.inn() == '782509970062')
    assert (r.ogrn() == '4715113303725')


# Generated at 2022-06-21 15:37:25.921031
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    """Unit test for constructor of class RussiaSpecProvider."""
    a = RussiaSpecProvider()
    assert a.__class__.__name__ == 'RussiaSpecProvider'


# Generated at 2022-06-21 15:37:34.656251
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():

    import names
    import random
    import mimesis.providers.ru.ru_provider as rp
    #import mimesis.providers.ru.russia_provider as rp
    from mimesis.enums import Gender as g

    data = rp.RussiaSpecProvider()
    #data = rp.RussiaProvider()

    for i in range(0, 100):
        if (i % 3) == 0:
            gender = g.MALE
        elif (i % 3) == 1:
            gender = g.FEMALE
        else:
            gender = g.FEMALE

        print(data.generate_sentence())

# Generated at 2022-06-21 15:37:36.513592
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    assert len(RussiaSpecProvider.patronymic()) > 0, "Patronymic does not work"

# Generated at 2022-06-21 15:37:39.603420
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    g = RussiaSpecProvider(seed=123)
    assert g.snils() == '01917492600'


# Generated at 2022-06-21 15:37:43.537225
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    ru = RussiaSpecProvider()

    for i in range(0, 10):
        print("inn: {}".format(ru.inn()))


if __name__ == "__main__":
    print("Test for method inn of class RussiaSpecProvider")
    test_RussiaSpecProvider_inn()

# Generated at 2022-06-21 15:37:45.334538
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider()
    for _ in range(0, 10):
        print(provider.bic())


# Generated at 2022-06-21 15:39:00.836932
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    rssp = RussiaSpecProvider()
    rssp.patronymic(gender=Gender.FEMALE)

# Generated at 2022-06-21 15:39:05.077838
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    prov = RussiaSpecProvider()
    assert prov.patronymic()
    assert prov.patronymic(gender=0)
    assert prov.patronymic(gender=1)
    assert prov.patronymic(gender=2)



# Generated at 2022-06-21 15:39:06.008444
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    pass


# Generated at 2022-06-21 15:39:07.891948
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    ru_provider = RussiaSpecProvider()
    assert ru_provider.passport_series(2018) == "01 18"

# Generated at 2022-06-21 15:39:16.257445
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Unit test for method ogrn of class RussiaSpecProvider."""
    from mimesis.providers.finance import Finance
    from mimesis.enums import Gender
    from mimesis.builtins import RussiaSpecProvider
    rsp = RussiaSpecProvider()
    rsp.seed(4)
    assert rsp.ogrn() == '4715113303725'
    rsp.gender = Gender.FEMALE
    rsp.seed(4)
    assert rsp.ogrn() == '4715113303725'
    rsp.gender = Gender.MALE
    rsp.seed(2)
    assert rsp.ogrn() == '7314117748911'
    rsp.gender = Gender.FEMALE
    rsp.seed(2)

# Generated at 2022-06-21 15:39:18.551992
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    provider = RussiaSpecProvider()
    result = provider.inn()
    print(result)
    assert len(result) == 12


# Generated at 2022-06-21 15:39:20.641101
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    provider = RussiaSpecProvider()
    actual = provider.kpp()
    assert actual == "630084116"

# Generated at 2022-06-21 15:39:22.189646
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    vp = RussiaSpecProvider()
    result = vp.ogrn()
    assert len(result) == 13

# Generated at 2022-06-21 15:39:31.323024
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    import pytest
    from mimesis.enums import Gender

    class RussiaSpecProvider_T(RussiaSpecProvider):
        def __init__(self, seed=None):
            self.data = {'kpp': {'kpp_list': ['8600', '8700', '8900', '9100', '9200', '9800', '9900', '9901', '9951', '9952', '9953', '9954', '9955', '9956', '9957', '9958', '9959', '9961', '9962', '9965', '9966', '9971', '9972', '9973', '9974', '9975', '9976', '9977', '9979', '9998']}}


    provider_kpp = RussiaSpecProvider_T()
    s = provider

# Generated at 2022-06-21 15:39:32.372243
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Unit test for method series_and_number."""
    pass



# Generated at 2022-06-21 15:42:44.846754
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    """Unit test for method generate_sentence of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    result = provider.generate_sentence()
    assert type(result) is str
    assert len(result) < 50
    split_str = result.split()
    assert len(split_str) == 4


# Generated at 2022-06-21 15:42:47.861319
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    print("\nUnit test for method inn of class RussiaSpecProvider")
    provider = RussiaSpecProvider()
    inn = provider.inn()
    print("inn: ", inn)


# Generated at 2022-06-21 15:42:50.501845
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    provider = RussiaSpecProvider(seed=42)
    sentence = provider.generate_sentence()
    assert sentence == 'Вот и последнее выражение с прилетом во вторник.'


# Generated at 2022-06-21 15:42:53.980786
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    provider = RussiaSpecProvider()
    result = provider.passport_series(2016)
    assert len(result) == 5


# Generated at 2022-06-21 15:43:01.250659
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    r = RussiaSpecProvider()
    # Пыль лежала на кружке кофе, который мог быть и пить.
    print(r.generate_sentence())


# Generated at 2022-06-21 15:43:05.445371
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    from mimesis.providers.ru.russia import RussiaSpecProvider
    from mimesis.enums import Gender


    rus = RussiaSpecProvider()
    sentence = rus.sentence()
    assert isinstance(sentence, str)


# Generated at 2022-06-21 15:43:07.960519
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    rsp = RussiaSpecProvider()
    assert type(rsp.generate_sentence()) == str


# Generated at 2022-06-21 15:43:12.159197
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    import pytest
    from mimesis.enums import Gender

    p = RussiaSpecProvider()
    res = p.patronymic(Gender.MALE)
    assert isinstance(res, str)
    assert res in p._data['patronymic'][Gender.MALE]


# Generated at 2022-06-21 15:43:16.270004
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    assert len(RussiaSpecProvider().series_and_number()) == 11
    assert RussiaSpecProvider().series_and_number() not in ['01 05 123456', '02 10 987654', '03 15 321654']

# Generated at 2022-06-21 15:43:25.663034
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    r = RussiaSpecProvider()