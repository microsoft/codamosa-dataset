

# Generated at 2022-06-21 15:35:12.048453
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """Unit test for passport_number method of class RussiaSpecProvider."""
    # mimesis can't work without seed, so I set it manually
    get_seed = 618241
    # get an object of the RussiaSpecProvider class
    tester = RussiaSpecProvider(seed = get_seed)
    # test object's passport_number method
    assert tester.passport_number() == 513950



# Generated at 2022-06-21 15:35:13.155996
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    RussiaSpecProvider.ogrn()

# Generated at 2022-06-21 15:35:15.711873
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """
    I want to get a random valid ``INN``.
    """
    sp = RussiaSpecProvider()
    result = sp.inn()
    print(result)



# Generated at 2022-06-21 15:35:23.937395
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    from mimesis.enums import Gender
    from mimesis.providers.rus import RussiaSpecProvider
    ru = RussiaSpecProvider()
    ru.kpp()
    ru.kpp()
    ru.kpp()
    ru.kpp()
    ru.kpp()
    ru.kpp()
    ru.kpp()
    ru.kpp()
    ru.kpp()
    ru.kpp()
    ru.kpp()
    ru.kpp()
    ru.kpp()
    ru.kpp()
    ru.kpp()
    ru.kpp()
    ru.kpp()
    ru.kpp()
    ru.kpp()
    ru.kpp()
    ru.kpp()
    ru.kpp()
    ru.kpp()
    ru.k

# Generated at 2022-06-21 15:35:35.932407
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    provider = RussiaSpecProvider("123")

# Generated at 2022-06-21 15:35:45.843604
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    from os import getpid
    from mimesis.builtins import RussiaSpecProvider
    from time import time
    start_time = time()

    for i in range(0, 7):
        # test inn
        o = RussiaSpecProvider(seed=getpid())
        inn = o.inn()
        assert len(inn) == 10
        assert int(inn[0]) in [1, 2, 3, 4, 5, 6, 7, 8, 9]
        assert 0 <= int(inn[1]) <= 9
        assert 0 <= int(inn[2]) <= 9
        assert 0 <= int(inn[3]) <= 9
        assert 0 <= int(inn[4]) <= 9
        assert 0 <= int(inn[5]) <= 9
        assert 0 <= int(inn[6]) <= 9
        assert 0 <= int(inn[7]) <= 9

# Generated at 2022-06-21 15:35:47.613592
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    for gender in Gender:
        assert RussiaSpecProvider().patronymic(gender)


# Generated at 2022-06-21 15:35:49.902034
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    p = RussiaSpecProvider()
    print(p.patronymic(Gender.FEMALE))
    print(p.patronymic(Gender.MALE))


# Generated at 2022-06-21 15:35:58.204374
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    # Localize variables
    my_kpp = ''

# Generated at 2022-06-21 15:36:04.846362
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    result = RussiaSpecProvider().bic()
    assert isinstance(result, str)
    assert len(result) == 8
    assert result[:2] == '04'
    assert result[2] in '123456789'
    assert result[3] in '0123456789'
    assert result[4:8].isdigit()


# Generated at 2022-06-21 15:36:25.686371
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Unit test for method series_and_number of class RussiaSpecProvider
    
    :return: -
    """
    r = RussiaSpecProvider()
    result = r.series_and_number()
    print(result)

    if result is not None:
        assert isinstance(result, str)
        assert len(result) == 11
        assert result[4] == ' '
        assert result[2:4].isdigit()
        assert result[5:7].isdigit()
        assert result[7:11].isdigit()


# Generated at 2022-06-21 15:36:29.376297
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    data_provider = RussiaSpecProvider
    passport_number = data_provider.passport_number()
    assert len(passport_number) == 6


# Generated at 2022-06-21 15:36:30.654589
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    RussiaSpecProvider.snils()



# Generated at 2022-06-21 15:36:37.553601
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    for _ in range(10):
        assert(RussiaSpecProvider().patronymic(Gender.MALE) in
               ['Иванович', 'Петрович'])
        assert(RussiaSpecProvider().patronymic(Gender.FEMALE) in
               ['Петровна', 'Алексеевна'])


# Generated at 2022-06-21 15:36:45.480229
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    from .data import payload
    from .data import response
    from .data import status_code
    from .data import url
    from . import session
    from . import print_req

    data = payload(endpoint='/ru/ogrn')
    test_ogrn = RussiaSpecProvider(seed=data['seed']).ogrn()
    test_data = data['payload']['data']
    test_data['ogrn'] = test_ogrn

    response = session.post(url, data=test_data)
    print_req(url, 'post', test_data, response.request.headers,
              response.request.body, response.status_code)
    assert response.status_code == status_code
    assert response.json()['data'] == test_ogrn



# Generated at 2022-06-21 15:36:50.687366
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    from mimesis.providers.russia import RussiaSpecProvider
    from mimesis.enums import Gender

    instance = RussiaSpecProvider()
    inn = instance.inn()
    assert (12 == len(inn))

    assert (inn == '500400916308')


# Generated at 2022-06-21 15:36:54.364625
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    ru_provider = RussiaSpecProvider()
    for i in range(0, 1000):
        snils = ru_provider.snils()
        print(i + 1, snils)
        if not snils.isnumeric() or len(snils) != 11:
            print('Invalid snils №', i + 1)
            break



# Generated at 2022-06-21 15:36:55.496057
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    provider = RussiaSpecProvider()
    assert re.match(r'[0-9]{9}', provider.kpp())

# Generated at 2022-06-21 15:36:58.450204
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    """Test generate_sentence."""
    provider = RussiaSpecProvider()
    for _ in range(10):
        sentence = provider.generate_sentence()
        assert isinstance(sentence, str)



# Generated at 2022-06-21 15:37:07.469499
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """
    Unit test for method passport_series of class RussiaSpecProvider
    """
    rus_spec_provider = RussiaSpecProvider()
    passport_series = rus_spec_provider.passport_series()
    assert passport_series
    assert len(passport_series) == 5
    for i in range(0, 2):
        assert passport_series[i].isdigit()
    assert passport_series[3].isdigit()
    assert passport_series[4] in ['1', '2', '3', '4', '5', '6', '7', '8', '9']



# Generated at 2022-06-21 15:37:43.396260
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    """Test for method patronymic of class RussiaSpecProvider."""
    gender = Gender.MALE
    r = RussiaSpecProvider()
    a = r.patronymic(gender)
    assert a in r._data['patronymic'][Gender.MALE]



# Generated at 2022-06-21 15:37:45.543115
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    r = RussiaSpecProvider()
    sentence = r.generate_sentence()
    assert type(sentence) == str


# Generated at 2022-06-21 15:37:47.514217
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    assert len(r.snils()) == 11
    assert r.snils()[9] == '1'


# Generated at 2022-06-21 15:37:51.955796
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    snils = RussiaSpecProvider().snils()
    assert len(snils) == 11, 'Unable generate snils'
    assert isinstance(snils, str) == True, 'Generated snils is not str type'


# Generated at 2022-06-21 15:37:54.345996
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """Test method passport_number of class RussiaSpecProvider."""
    RussiaSpecProvider.passport_number()


# Generated at 2022-06-21 15:37:58.750247
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    #тестируем метод ОГРН
    k = RussiaSpecProvider()
    assert (len(k.ogrn()) == 13)

# тестируем метод ИНН

# Generated at 2022-06-21 15:37:59.458614
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    pass

# Generated at 2022-06-21 15:38:01.010497
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    provider=RussiaSpecProvider()
    inn="7310177659"
    assert provider.inn()==inn

# Generated at 2022-06-21 15:38:04.049265
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Test for method inn of class RussiaSpecProvider."""
    rs = RussiaSpecProvider('123')
    a = rs.inn()
    b = rs.inn()
    c = rs.inn()
    assert a != b != c

# Generated at 2022-06-21 15:38:06.854177
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Unit test for method inn of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    inn_number = provider.inn()
    assert len(inn_number) == 12


# Generated at 2022-06-21 15:39:29.415447
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    from mimesis.enums import Gender
    from mimesis.providers.generic import Generic
    from mimesis.providers.geo import Geo

    spec = RussiaSpecProvider('seed123')
    g = Generic('seed123')
    geo = Geo('seed123')

    gender = Gender.MALE
    spec.patronymic(gender)
    spec.passport_series()
    spec.passport_number()
    spec.series_and_number()
    spec.inn()
    spec.ogrn()
    spec.bic()
    spec.kpp()
    spec.generate_sentence()

# Generated at 2022-06-21 15:39:33.688520
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """Unit test for method kpp of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    kpp = rsp.kpp()
    kpp_formatted = kpp[0:2] + "-" + kpp[2:4] + "-" + kpp[4:9]
    # print(kpp, kpp_formatted)
    assert kpp == kpp_formatted


# Generated at 2022-06-21 15:39:36.253463
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    # Arrange
    gen = Generator()
    rus = gen.russia_provider()

    # Act
    result = rus.passport_series()

    # Assert
    assert len(result) == 5



# Generated at 2022-06-21 15:39:45.918865
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    rus = RussiaSpecProvider(seed=4)
    assert rus.series_and_number() == '5716805199'
    assert rus.series_and_number() == '5812870783'
    assert rus.series_and_number() == '5215276717'
    assert rus.series_and_number() == '9813171363'
    assert rus.series_and_number() == '8415965335'
    assert rus.series_and_number() == '0118160901'
    assert rus.series_and_number() == '9216091912'
    assert rus.series_and_number() == '7915381216'
    assert rus.series_and_number() == '0213946468'
    assert rus.series_and_

# Generated at 2022-06-21 15:39:53.458696
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    from mimesis.datetime import Datetime
    from mimesis.enums import Gender
    from mimesis.providers import RussiaSpecProvider

    r = RussiaSpecProvider()
    assert r.passport_series() == '45 01'
    assert r.passport_series(year=67) == '45 67'
    assert r.passport_series(Datetime().date(year=1967)) == '45 67'
    assert r.passport_series(year=Datetime().date(year=1967)) == '45 67'


# Generated at 2022-06-21 15:39:56.055430
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    provider = RussiaSpecProvider()
    provider.seed(1)
    inn = provider.inn()
    assert (inn == "8505125249")
    assert (inn != "8505125248")



# Generated at 2022-06-21 15:39:59.513701
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    """Test for method bic of class RussiaSpecProvider."""
    ru = RussiaSpecProvider()
    # Test for type of result
    assert isinstance(ru.bic(), (str,))
    # Test for length of result
    assert len(ru.bic()) == 9

# Generated at 2022-06-21 15:40:05.162098
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    from mimesis.schema import Field, Schema
    from mimesis.enums import Gender
    from mimesis.typing import Seed
    from mimesis.builtins.russia import RussiaSpecProvider

    r = RussiaSpecProvider(seed=Seed(1))
    schema = Schema(r)
    field = Field('passport_number')
    data = schema.create(field)
    assert data == ['353445']


# Generated at 2022-06-21 15:40:15.438714
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    rus_1 = RussiaSpecProvider()
    rus_2 = RussiaSpecProvider()
    rus_3 = RussiaSpecProvider()
    rus_4 = RussiaSpecProvider()
    rus_5 = RussiaSpecProvider()
    rus_6 = RussiaSpecProvider()
    rus_7 = RussiaSpecProvider()
    rus_8 = RussiaSpecProvider()
    rus_9 = RussiaSpecProvider()
    rus_10 = RussiaSpecProvider()
    rus_11 = RussiaSpecProvider()
    rus_12 = RussiaSpecProvider()
    rus_13 = RussiaSpecProvider()
    rus_14 = RussiaSpecProvider()
    rus_15 = RussiaSpecProvider()
    rus_16 = RussiaSpecProvider()
    rus_17 = RussiaSpecProvider()
    rus_18 = RussiaSpecProvider()
   

# Generated at 2022-06-21 15:40:22.432319
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    print("-------------Test method kpp of class RussiaSpecProvider-----------------")
    from mimesis.providers.base import BaseSpecProvider
    from mimesis.providers.locales import Locales
    from random import randint
    from mimesis.enums import Gender
    import random
    import mimesis
    import mimesis.enums

    a = mimesis.providers.RussiaSpecProvider()
    assert isinstance(a, BaseSpecProvider), "Should be a BaseSpecProvider"
    assert hasattr(a, 'seed'), "Should has seed"
    assert hasattr(a, '_seed'), "Should has _seed"
    assert hasattr(a, 'random'), "Should has random"
    assert callable(a.random.random), "Should has random"



# Generated at 2022-06-21 15:43:44.051147
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider"""
    rsp = RussiaSpecProvider(seed=1)
    
    # True test
    assert rsp.snils() == '41917492600'

    # Wrong test
    assert rsp.snils() != '4191749260'
    