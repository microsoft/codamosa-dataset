

# Generated at 2022-06-21 15:35:11.384216
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    r = RussiaSpecProvider()
    assert r.patronymic() == 'Алексеевна'
    assert r.patronymic(gender=1) == 'Алексеевич'
    assert r.patronymic(gender=2) == 'Алексеевна'
    assert r.patronymic(gender=3) is None


# Generated at 2022-06-21 15:35:13.729975
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Test RussiaSpecProvider.inn."""
    rs = RussiaSpecProvider()
    assert rs.inn().startswith('77')



# Generated at 2022-06-21 15:35:15.122527
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    prov = RussiaSpecProvider()
    # todo: add unit test

# Generated at 2022-06-21 15:35:23.625245
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # 1. Initialization of RussiaSpecProvider
    RUS_1 = RussiaSpecProvider()
    RUS_2 = RussiaSpecProvider()
    RUS_3 = RussiaSpecProvider()
    # 2. Check "snils" method
    # 2.1. Check if snils consists of 11 digits
    i = 0
    while i < 1000:
        snils = RUS_1.snils()
        assert len(snils) == 11, "The length of snils is not equal to 11"
        i = i + 1
    # 2.2. Check if snils begins with 3 digits from 1 to 9
    i = 0
    while i < 1000:
        snils = RUS_2.snils()

# Generated at 2022-06-21 15:35:25.262435
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    p = RussiaSpecProvider()
    assert len(p.ogrn()) == 13



# Generated at 2022-06-21 15:35:27.838918
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    """ Unit test for method bic of class RussiaSpecProvider."""

    russian_provider = RussiaSpecProvider()
    bic = russian_provider.bic()
    assert len(bic) == 9


# Generated at 2022-06-21 15:35:38.713969
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    rsp = RussiaSpecProvider()
    assert len(rsp.kpp()) == 9

# Generated at 2022-06-21 15:35:40.925094
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    rp = RussiaSpecProvider(seed=12345)
    assert rp.kpp() == '560058652'

# Generated at 2022-06-21 15:35:44.209373
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    for _ in range(50):
        sp = RussiaSpecProvider()
        inn = sp.inn()
        control_sum = str(int(inn) % 11 % 10)
        assert control_sum == inn[-1]


# Generated at 2022-06-21 15:35:53.163505
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.base import BaseSpecProvider
    from mimesis.providers.generic import Generic
    class UnitTestRussiaSpecProvider(BaseSpecProvider):
        def __init__(self, seed=None):
            super().__init__(seed=seed)

# Generated at 2022-06-21 15:36:07.539481
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    a = RussiaSpecProvider().generate_sentence()
    print(a)


# Generated at 2022-06-21 15:36:09.627949
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    assert provider.snils() == '41917492600'

# Generated at 2022-06-21 15:36:11.959792
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    assert RussiaSpecProvider().patronymic() not in (None, '', ' ', '\n', '\t')


# Generated at 2022-06-21 15:36:18.084702
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """
    Unit tests for the snils method of class RussiaSpecProvider
    """
    russian_provider = RussiaSpecProvider()

    assert len(russian_provider.snils()) == 11
    assert all(x in [0,1,2,3,4,5,6,7,8,9] for x in [int(x) for x in russian_provider.snils()])


# Generated at 2022-06-21 15:36:20.010025
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """Проверка метода RussiaSpecProvider.passport_number."""
    from mimesis.builtins.ru import RussiaSpecProvider

    ru = RussiaSpecProvider()
    assert ru.passport_number() == ru.passport_number()



# Generated at 2022-06-21 15:36:22.522910
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider()
    bic = provider.bic()
    if len(bic) != 9:
        raise AssertionError


# Generated at 2022-06-21 15:36:24.806163
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():            
    tp = RussiaSpecProvider()
    s = tp.generate_sentence()
    assert len(s) > 0
    assert isinstance(s, str)
    #print(s)

# Generated at 2022-06-21 15:36:27.108403
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    provider = RussiaSpecProvider()
    inn = provider.inn()
    assert len(inn) == 12
    assert int(inn[-1]) == int(inn[:-1]) % 10


# Generated at 2022-06-21 15:36:29.920113
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    r = RussiaSpecProvider()
    list = []
    for x in range(0, 100):
        list.append(r.bic())
    print(list)

# Generated at 2022-06-21 15:36:34.473175
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    from mimesis.providers.ru import RussiaSpecProvider
    from mimesis.enums import Gender
    t = RussiaSpecProvider()
    for i in range(0,9):
        assert(t.passport_number()>=100000)


# Generated at 2022-06-21 15:37:07.114118
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    import mimesis
    import re
    pattern = re.compile(r'\d{9}')
    rsp = mimesis.RussiaSpecProvider()
    bic = rsp.bic()
    assert pattern.match(bic) is not None


# Generated at 2022-06-21 15:37:12.445558
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    provider = RussiaSpecProvider()
    for _ in range(0, 100):
        series_and_number = provider.series_and_number()
        print("%s" % series_and_number)
        assert len(series_and_number) == 12
        assert series_and_number.find(" ") != -1
        assert series_and_number.find(" ") == 2


# Generated at 2022-06-21 15:37:14.527971
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():

    fti = RussiaSpecProvider()
    assert len(fti.inn()) == 10


# Generated at 2022-06-21 15:37:15.117176
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    r = RussiaSpecProvider()
    print(r.bic())


# Generated at 2022-06-21 15:37:16.909133
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    r = RussiaSpecProvider()
    assert len(r.ogrn()) == 13
    assert r.ogrn()[0] == '4'
    assert r.ogrn()[12] != '4'

# Generated at 2022-06-21 15:37:20.200935
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    from mimesis import Generic
    g = Generic('ru')

    r_sentence = g.text.sentence()
    exp_sentence = g.russia_provider.generate_sentence()

    assert r_sentence == exp_sentence


# Generated at 2022-06-21 15:37:22.288599
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """Test that generates KPP."""
    rsp = RussiaSpecProvider()
    print(rsp.kpp())

# Generated at 2022-06-21 15:37:23.558379
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    assert RussiaSpecProvider().bic() == '044025575'



# Generated at 2022-06-21 15:37:27.404414
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    provider = RussiaSpecProvider()
    patronymic = provider.patronymic(Gender.FEMALE)
    assert patronymic == 'Алексеевна' or patronymic == 'Анатольевна'

# Generated at 2022-06-21 15:37:29.289534
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    provider = RussiaSpecProvider()
    assert provider.inn() != provider.inn()



# Generated at 2022-06-21 15:38:32.138636
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    assert len(RussiaSpecProvider().ogrn()) == 13
    assert RussiaSpecProvider().ogrn()[-1] in ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
    assert int(RussiaSpecProvider().ogrn()[:-1]) % 11 % 10 == int(RussiaSpecProvider().ogrn()[-1])


# Generated at 2022-06-21 15:38:34.798443
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender

    rs = RussiaSpecProvider()
    print(rs.generate_sentence())

    rs = RussiaSpecProvider(seed='test')
    print(rs.generate_sentence())



# Generated at 2022-06-21 15:38:37.997786
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    p = RussiaSpecProvider()
    print(p.series_and_number())


# Generated at 2022-06-21 15:38:40.251926
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    ru = RussiaSpecProvider()
    ru.series_and_number() == ru.passport_series() + ru.passport_number()

# Generated at 2022-06-21 15:38:42.359017
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    from mimesis import RussiaSpecProvider

    r = RussiaSpecProvider()
    result = r.series_and_number()

    assert result == '57 16 805199'


# Generated at 2022-06-21 15:38:47.094976
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider()
    for _ in range(0, 100):
        bic = provider.bic()
        assert(bic[:2] == '04')
        assert(1 <= int(bic[2:4]) <= 10)
        assert(0 <= int(bic[4:6]) <= 99)
        assert(50 <= int(bic[6:]) <= 999)


# Generated at 2022-06-21 15:38:51.109603
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    provider = RussiaSpecProvider()

    # Case 1: gender=Gender.MALE
    assert type(provider.patronymic(gender=Gender.MALE)) == str

    # Case 2: gender=Gender.FEMALE
    assert type(provider.patronymic(gender=Gender.FEMALE)) == str



# Generated at 2022-06-21 15:38:55.220131
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    class NumGen:
        def __init__(self, numbers):
            self.numbers = iter(numbers)
        def randint(self, a, b):
            return next(self.numbers)
    import random
    random.randint = NumGen([560430]).randint
    rsp = RussiaSpecProvider()
    assert(rsp.passport_number() == 560430)

# Generated at 2022-06-21 15:38:56.614997
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    print("snils: " + provider.snils())


# Generated at 2022-06-21 15:39:00.186400
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Test for series_and_number."""
    rus = RussiaSpecProvider()

    for i in range(10):
        print(rus.series_and_number())
        # 56 03 103938


# Generated at 2022-06-21 15:41:09.525908
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    r = RussiaSpecProvider()
    assert len(r.kpp()) == 9



# Generated at 2022-06-21 15:41:18.171358
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    r = RussiaSpecProvider()
    assert len(r.inn()) == 10


# Generated at 2022-06-21 15:41:19.093044
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    russia_provider = RussiaSpecProvider()
    print(russia_provider.patronymic(Gender.MALE))

# Generated at 2022-06-21 15:41:20.643860
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    snils = RussiaSpecProvider().snils()
    assert len(snils) == 11
    assert isinstance(snils, str)


# Generated at 2022-06-21 15:41:23.602781
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    pattern = r'^[0-9]{4}[0-9]{2}[0-9]{3}$'
    for i in range(0, 5):
        a = RussiaSpecProvider('ru')
        assert re.match(pattern, a.kpp())



# Generated at 2022-06-21 15:41:24.880852
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    assert RussiaSpecProvider.generate_sentence() not in ['', None]

# Generated at 2022-06-21 15:41:28.383446
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    # Create an instance of RussiaSpecProvider
    specProvider = RussiaSpecProvider()
    # Generate patronymic name
    result = specProvider.patronymic(Gender.FEMALE)
    print(result)
# def test_RussiaSpecProvider_patronymic()


# Generated at 2022-06-21 15:41:31.161608
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    for _ in range(100):
        series = RussiaSpecProvider().series_and_number()
        assert len(series) == 11
        for x in series:
            assert x.isdigit()

# Generated at 2022-06-21 15:41:33.909676
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    rus_provider = RussiaSpecProvider()
    rus_provider.series_and_number() == 'хх хх хххххх'

# Generated at 2022-06-21 15:41:37.375080
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    rus_provider = RussiaSpecProvider()
    series_and_number = rus_provider.series_and_number()
    assert type(series_and_number) == str
    assert len(series_and_number) == 11