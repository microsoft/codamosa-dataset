

# Generated at 2022-06-21 15:35:18.878236
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    import random
    import string
    import time
    import os

    seed_number = random.randint(1, 10000000)
    seed_string = ''.join([random.choice(string.ascii_letters) for i in range(20)])
    seed_string_2 = ''.join([random.choice(string.ascii_letters) for i in range(20)])

    seed = seed_number
    provider = RussiaSpecProvider(seed=seed)
    passport_number_seed_number = provider.passport_number()

    seed = seed_string
    provider = RussiaSpecProvider(seed=seed)
    passport_number_seed_string = provider.passport_number()

    seed = time.time()
    provider = RussiaSpecProvider(seed=seed)
    passport_number_seed_time = provider.passport

# Generated at 2022-06-21 15:35:27.532217
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    '''
    Unit test for method kpp of class RussiaSpecProvider
    '''

    print('Start test!')
    print('...')
    import unittest

    # Constants
    kpp_length = 9
    class TestRussiaSpecProvider(unittest.TestCase):
        '''
        TestRussiaSpecProvider
        '''

        print('Initialize TestRussiaSpecProvider')

        def test_kpp(self):
            '''
            Test for method kpp
            '''

            print('Start test for method kpp of class RussiaSpecProvider')
            counter = 0
            for x in range(0, 100):
                print('. ', end='')
                counter += 1
                if counter % 50 == 0:
                    print('\n', end='')
                kpp_result = RussiaSpecProvider().kpp()

# Generated at 2022-06-21 15:35:31.760655
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()

    for _ in range(0, 10):
        snils = rsp.snils()
        print(snils)


# Generated at 2022-06-21 15:35:34.042292
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    rp = RussiaSpecProvider()
    series = rp.passport_series(10)
    assert len(series) == 4


# Generated at 2022-06-21 15:35:35.385792
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    r = RussiaSpecProvider()
    assert len(r.series_and_number()) == 9

# Generated at 2022-06-21 15:35:37.310649
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    russia = RussiaSpecProvider(seed=[1, 2, 3])
    assert russia.kpp() == '570058652'

# Generated at 2022-06-21 15:35:38.499002
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    assert RussiaSpecProvider().kpp()



# Generated at 2022-06-21 15:35:43.509952
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Case of testing method series_and_number."""
    rsp = RussiaSpecProvider()
    print('\n')
    for i in range(0, 5):
        print('Серия и номер паспорта:', rsp.series_and_number())



# Generated at 2022-06-21 15:35:44.449941
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    assert len(RussiaSpecProvider().generate_sentence()) > 1


# Generated at 2022-06-21 15:35:46.582554
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider()
    assert type(provider.bic()) == str
    assert len(provider.bic()) == 10


# Generated at 2022-06-21 15:36:05.244526
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    assert str(RussiaSpecProvider(seed=42)) == 'RussiaSpecProvider'


# Generated at 2022-06-21 15:36:09.058007
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    sp = RussiaSpecProvider()
    assert sp.snils() != sp.snils()
    assert sp.inn() != sp.inn()
    assert sp.ogrn() != sp.ogrn()
    assert sp.bic() != sp.bic()
    assert sp.kpp() != sp.kpp()

# Generated at 2022-06-21 15:36:12.791525
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    """Unit test for method `RussiaSpecProvider.generate_sentence`."""
    spec_russia = RussiaSpecProvider()
    assert spec_russia.generate_sentence() != spec_russia.generate_sentence()


# Generated at 2022-06-21 15:36:18.483164
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Tests for series_and_number in RussiaSpecProvider.

    :return: None.
    """

    r = RussiaSpecProvider()
    while True:
        try:
            assert len(r.series_and_number()) == 11
            print(r.series_and_number())
            break
        except AssertionError:
            continue


# Generated at 2022-06-21 15:36:24.652917
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    p = RussiaSpecProvider()
    series_and_number = p.series_and_number()
    assert len(series_and_number) == 11
    assert series_and_number[2] == ' '
    assert series_and_number[5] == ' '
    assert series_and_number[7] == ' '
    assert series_and_number[8] != ' '
    assert series_and_number[9] != ' '
    assert series_and_number[10] != ' '


# Generated at 2022-06-21 15:36:25.815884
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    assert len(RussiaSpecProvider().bic()) == 9


# Generated at 2022-06-21 15:36:30.975294
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Create test case
    provider = RussiaSpecProvider()
    # Run unit test
    result = provider.snils()
    # Validate result
    assert len(result) == 11
    assert not result.isalpha()
    assert result.isdigit()


# Generated at 2022-06-21 15:36:34.534865
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    """Unit test for method generate_sentence of class RussiaSpecProvider."""
    test = RussiaSpecProvider()
    sentence = test.generate_sentence()
    print(sentence)


# Generated at 2022-06-21 15:36:36.528837
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert len(RussiaSpecProvider().snils()) == 11



# Generated at 2022-06-21 15:36:39.015454
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Unit test for method ogrn of class RussiaSpecProvider."""
    ogrn = RussiaSpecProvider().ogrn()
    assert len(ogrn) == 13



# Generated at 2022-06-21 15:36:56.583011
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    c = RussiaSpecProvider()
    print(c.inn())

# Generated at 2022-06-21 15:37:07.701036
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    r = RussiaSpecProvider()
    test_sentence = r.generate_sentence()
    # Создаем список из слов созданного предложения
    test_sentence_list = test_sentence.split()
    # Проверяем, содержит ли предложение только строки из словаря

# Generated at 2022-06-21 15:37:09.561092
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    provider = RussiaSpecProvider()
    assert len(provider.kpp()) == 9


# Generated at 2022-06-21 15:37:13.579104
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    import random
    import string
    from mimesis.builtins import RussiaSpecProvider

    rsp = RussiaSpecProvider(seed=random.Random(42))
    for i in range(100):
        print(rsp.inn())
    return True


# Generated at 2022-06-21 15:37:22.923416
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    '''
    Unit test for method bic of class RussiaSpecProvider
    '''
    # First generator
    gen1 = RussiaSpecProvider()
    # Second generator with seed "1"
    gen2 = RussiaSpecProvider(seed=1)
    # Third generator with seed "2"
    gen3 = RussiaSpecProvider(seed=2)
    # Fourth generator with seed "3"
    gen4 = RussiaSpecProvider(seed=3)

    # At first we need to check that random BIC codes generated by generators with different seeds are different
    assert gen1.bic() != gen2.bic() != gen3.bic() != gen4.bic()
    # But if we will use seed which was used in generators with which we compared our first generator then BIC codes
    # should be equal
    gen1_bic = gen1.bic

# Generated at 2022-06-21 15:37:26.212681
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    RussiaSpecProvider_obj = RussiaSpecProvider()

    assert (len(str(RussiaSpecProvider_obj.passport_number())) == 6)
    assert (int(str(RussiaSpecProvider_obj.passport_number())[0]) > 0)

# Generated at 2022-06-21 15:37:28.430188
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    prov = RussiaSpecProvider()
    _sentence = prov.generate_sentence()
    assert len(_sentence) != 0

# Generated at 2022-06-21 15:37:30.714315
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    rsp = RussiaSpecProvider(seed=1234)
    assert rsp.passport_number() == 555784



# Generated at 2022-06-21 15:37:34.605852
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Unit test for ``series_and_number`` method of RussiaSpecProvider."""
    russ = RussiaSpecProvider()
    result = russ.series_and_number()
    assert len(result) == 11
    assert result



# Generated at 2022-06-21 15:37:45.086571
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    r1 = RussiaSpecProvider()
    assert r1.snils() is not None
    assert r1.inn() is not None
    assert r1.ogrn() is not None
    assert r1.bic() is not None
    assert r1.patronymic() is not None
    assert r1.patronymic(Gender.FEMALE) is not None
    assert r1.patronymic(Gender.MALE) is not None
    assert r1.series_and_number() is not None
    assert r1.passport_number() is not None
    assert r1.passport_series() is not None
    assert r1.generate_sentence() is not None
    assert r1.kpp() is not None
    assert r1.kpp() is not None


# Generated at 2022-06-21 15:38:18.726654
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia = RussiaSpecProvider()
    assert russia.snils() == '41917492600'

# Generated at 2022-06-21 15:38:19.712653
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    x = RussiaSpecProvider()


# Generated at 2022-06-21 15:38:29.516469
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    obj = RussiaSpecProvider()
    assert obj is not None

    # Unit test for patronymic(gender: Gender = None)
    def test_patronymic_gender():
        obj = RussiaSpecProvider()
        assert obj.patronymic(Gender.MALE) is not None
        assert obj.patronymic(Gender.FEMALE) is not None

    test_patronymic_gender()

    # Unit test for passport_series(year: int = None)
    def test_passport_series_year():
        obj = RussiaSpecProvider()
        assert obj.passport_series() is not None
        assert obj.passport_series(2018) is not None

    test_passport_series_year()

    # Unit test for passport_number()
    def test_passport_number():
        obj = RussiaSpec

# Generated at 2022-06-21 15:38:31.619367
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11
    assert snils.isdigit() == True

# Generated at 2022-06-21 15:38:37.008030
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    print("\n--- Constructor of RussiaSpecProvider ---")
    rus_provider = RussiaSpecProvider()
    print("\n--- Generate sentence ---")
    s = rus_provider.generate_sentence()
    print("Sentence: ", s)
    print("\n--- Generate male patronymic ---")
    p = rus_provider.patronymic(Gender.MALE)
    print("Patronymic: ", p)
    print("\n--- Generate passport series ---")
    ps = rus_provider.passport_series()
    print("Passport series: ", ps)
    print("\n--- Generate passport series with year ---")
    ps = rus_provider.passport_series(year=18)
    print("Passport series: ", ps)

# Generated at 2022-06-21 15:38:43.989457
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    from mimesis.providers.locales import Locale
    from mimesis.providers.specification import Specification
    from mimesis.builtins import RussiaSpecProvider as provider

    locales = Locale('ru', ['ru'], ['ru_RU'])
    spec = Specification(provider, locales)

    regex = r'[0-9]{4}[0-9]{2}[0-9]{3}'

    print(spec.kpp())
    assert re.match(regex, spec.kpp()) != None



# Generated at 2022-06-21 15:38:46.640664
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    rus = RussiaSpecProvider(seed=1337)
    series_and_number = rus.series_and_number()
    assert series_and_number == '57 16 805199'


# Generated at 2022-06-21 15:38:49.108947
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    import re
    rsp = RussiaSpecProvider()
    bic = rsp.bic()
    assert re.match(r'\d{9}', bic)    


# Generated at 2022-06-21 15:38:55.947146
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    provider = RussiaSpecProvider()
    result = provider.generate_sentence()
    print(result) # Expected result: В этой концепции не учитывается даже приблизительная оценка актуальных затрат на субъективную разработку.


# Generated at 2022-06-21 15:38:57.388316
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    test_ogrn = RussiaSpecProvider().ogrn()
    assert isinstance(test_ogrn, str)


# Generated at 2022-06-21 15:40:04.035791
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    from collections import Counter
    from mimesis.enums import Gender

    r = RussiaSpecProvider()
    c = Counter()

    for _ in range(100):
        c[r.patronymic(Gender.MALE)] += 1
        c[r.patronymic(Gender.FEMALE)] += 1
        c[r.patronymic(Gender.NEUTRAL)] += 1

    # Генератор далеко не эффективен (подбирает более 100 строк из файла)
    # чтобы проверить, что он

# Generated at 2022-06-21 15:40:05.883481
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    d = RussiaSpecProvider()       # Creation of class object
    assert d.passport_number()     # Testing method passport_number


# Generated at 2022-06-21 15:40:06.399725
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    pass

# Generated at 2022-06-21 15:40:09.458162
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    for _ in range(10):
        series_and_number = RussiaSpecProvider().series_and_number()
        assert len(series_and_number) == 10


# Generated at 2022-06-21 15:40:15.044285
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """
    Функция тестирует генерацию случайного SNILS.

    :return: ничего.
    """
    from mimesis import RussiaSpecProvider
    rp = RussiaSpecProvider()
    print(rp.snils())

# Generated at 2022-06-21 15:40:18.992398
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """Проверка оператора функции passport_number."""
    rus = RussiaSpecProvider(seed="0123456789")

    assert type(rus.passport_number()) is int


# Generated at 2022-06-21 15:40:20.445440
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    p = RussiaSpecProvider()
    result = p.passport_number()
    assert type(result) == int


# Generated at 2022-06-21 15:40:28.118617
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    """This function is test function for method patronymic of class RussiaSpecProvider."""
    # Creat object of class RussiaSpecProvider
    provider = RussiaSpecProvider()
    # Generate random patronymic name
    patronymic = provider.patronymic()
    # Check if result has type string
    assert type(patronymic) == str, 'Type of result is not string'
    # Show result
    print('Generated patronymic name:', patronymic)



# Generated at 2022-06-21 15:40:31.141430
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Test for correct generating of passport series and number using RussiaSpecProvider.series_and_number()."""
    RussiaSpecProvider().series_and_number() == '57 16 805199'


# Generated at 2022-06-21 15:40:35.186151
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    r = RussiaSpecProvider()
    sentence = r.generate_sentence()
    print (sentence)


# Generated at 2022-06-21 15:43:36.076907
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    for Gender in Gender:
        provider = RussiaSpecProvider(seed=12345)
        assert provider.patronymic(gender=Gender) in provider._data['patronymic'][Gender]

# Generated at 2022-06-21 15:43:40.005534
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    provider = RussiaSpecProvider()
    passport_number = provider.passport_number()
    print(passport_number)
    assert passport_number >= 100000
    assert passport_number <= 999999


# Generated at 2022-06-21 15:43:53.365367
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """
    Test method passport_number of class RussiaSpecProvider.
    """
    passport = RussiaSpecProvider()

    # First test: test valid data: 100000 <= passport_number <= 999999
    passport_number = passport.passport_number()
    assert (isinstance(passport_number, int))
    assert (100000 <= passport_number <= 999999)
    # Next tests
    for _ in range (0, 3):
        passport_number = passport.passport_number()
        assert (isinstance(passport_number, int))
        assert (100000 <= passport_number <= 999999)
    


# Generated at 2022-06-21 15:43:55.871389
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    provider = RussiaSpecProvider()
    ogrn = provider.ogrn()
    print(ogrn)
    assert len(ogrn) == 13


# Generated at 2022-06-21 15:43:59.686653
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    r = RussiaSpecProvider()
    passport_series = r.passport_series()
    assert passport_series[2:4] == str(r.random.randint(10, 18))



# Generated at 2022-06-21 15:44:02.231629
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    ogrn = RussiaSpecProvider().bic()
    print(ogrn)

test_RussiaSpecProvider_bic()


# Generated at 2022-06-21 15:44:09.158072
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    from mimesis.enums import Gender

    r = RussiaSpecProvider()
    assert r.patronymic(Gender.FEMALE) in r._data['patronymic'][Gender.FEMALE]
    assert r.patronymic(Gender.MALE) in r._data['patronymic'][Gender.MALE]
    assert r.patronymic() in (r._data['patronymic'][Gender.MALE] + r._data['patronymic'][Gender.FEMALE])

# Generated at 2022-06-21 15:44:10.418410
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    r = RussiaSpecProvider()
    r.inn()


# Generated at 2022-06-21 15:44:18.624709
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():    
    from mimesis.providers.geo.ru import RussiaSpecProvider
    from mimesis.enums import Gender
    rus_prov = RussiaSpecProvider()
    
    assert rus_prov.patronymic() in rus_prov._data["patronymic"][Gender.FEMALE] + rus_prov._data["patronymic"][Gender.MALE]
    assert rus_prov.patronymic(Gender.FEMALE) in rus_prov._data["patronymic"][Gender.FEMALE]
    assert rus_prov.patronymic(Gender.MALE) in rus_prov._data["patronymic"][Gender.MALE]

    ## Тест также проверяется н

# Generated at 2022-06-21 15:44:27.859838
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # 1st test, method snils
    testProvider = RussiaSpecProvider()
    snils1 = testProvider.snils()
    assert snils1 in '1234567890', "Wrong snils, should be digits"
    assert len(str(snils1)) == 11, "Wrong snils, wrong length"

    # 2nd test, method snils
    testProvider = RussiaSpecProvider()
    snils2 = testProvider.snils()
    assert snils2 in '1234567890', "Wrong snils, should be digits"
    assert len(str(snils2)) == 11, "Wrong snils, wrong length"

    # 3rd test, method snils
    testProvider = RussiaSpecProvider()
    snils3 = testProvider.snils()