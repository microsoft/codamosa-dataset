

# Generated at 2022-06-21 15:35:06.234439
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    _passport_number = RussiaSpecProvider().passport_number()
    return _passport_number


# Generated at 2022-06-21 15:35:07.677687
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    rsp = RussiaSpecProvider()
    rsp.passport_number()

# Generated at 2022-06-21 15:35:10.037086
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    p = RussiaSpecProvider(seed=454)
    assert p is not None

# Generated at 2022-06-21 15:35:12.802106
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    provider = RussiaSpecProvider(seed=456)

    assert provider != None
    assert provider.random != None
    assert provider.random.seed == 456


# Generated at 2022-06-21 15:35:14.005146
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """Test method passport_number from class RussiaSpecProvider
    """
    obj = RussiaSpecProvider()
    res = obj.passport_number()
    assert isinstance(res, int)
    assert 100000 <= res <= 999999

# Generated at 2022-06-21 15:35:19.948730
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    provider = RussiaSpecProvider()
    assert provider.kpp() != None
    assert provider.inn() != None
    assert provider.ogrn() != None
    assert provider.bic() != None
    assert provider.kpp() != None
    assert provider.passport_number() != None
    assert provider.passport_series() != None
    assert provider.series_and_number() != None
    assert provider.snils() != None
    assert provider.generate_sentence() != None

# Generated at 2022-06-21 15:35:22.283621
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider()
    bic = provider.bic()
    assert bic == '044025575' or bic == '042293603'

# Generated at 2022-06-21 15:35:25.671725
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Unit test for method series_and_number of class RussiaSpecProvider."""
    # Define a provider
    provider = RussiaSpecProvider()

    # Generate result
    result = provider.series_and_number()

    # Verify
    assert len(result) == 11



# Generated at 2022-06-21 15:35:27.635816
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    provider = RussiaSpecProvider()
    sentence = provider.generate_sentence()
    assert isinstance(sentence, str)
    assert len(sentence) > 0


# Generated at 2022-06-21 15:35:31.468404
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test for method snils of class RussiaSpecProvider"""
    assert RussiaSpecProvider().snils() == '41917492600'


# Generated at 2022-06-21 15:35:48.114439
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    pass


# Generated at 2022-06-21 15:35:50.071292
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    russia_provider = RussiaSpecProvider()
    assert len(russia_provider.passport_series()) == 5


# Generated at 2022-06-21 15:35:58.348332
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():

    from mimesis.enums import Gender
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.generic import Generic
    from mimesis.providers.person import Person
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.business import Business

    person = Person('ru')
    datetime = Datetime('ru')
    address = Address('ru')
    generic = Generic('ru')
    science = Science('ru')
    business = Business('ru')
    transport = Transport('ru')
    russia = RussiaSpecProvider('ru')

    inn = russia.inn()

    print('')
    print('INN:', inn)


# Generated at 2022-06-21 15:36:07.287719
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    from mimesis.builtins.enums import Currency
    from mimesis.builtins.enums import PaymentSystem
    s = RussiaSpecProvider()
    temp = []
    try:
        for i in range(0, 10):
            temp.append(s.bic())
    except Exception as e:
        print(str(e))
    finally:
        assert len(set(temp)) == 10, 'all bic aren\'t unique'
        assert len(temp[0]) == 9 and temp[0][:2] == '04', 'incorrect bic'


# Generated at 2022-06-21 15:36:10.787081
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    from mimesis.enums import Gender
    from mimesis.providers.base import BaseSpecProvider
    from mimesis.providers.generic import Generic

    class TestRussiaSpecProvider(RussiaSpecProvider):
        class Meta:
            name = 'test_russia_provider'

    spec = TestRussiaSpecProvider()
    assert spec.ogrn()



# Generated at 2022-06-21 15:36:16.804219
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    ru = RussiaSpecProvider()
    ru.reset_seed()
    kpp1 = ru.kpp()
    ru.reset_seed()
    kpp2 = ru.kpp()
    assert len(kpp1) == 9
    assert len(kpp2) == 9
    assert kpp1 != kpp2

if __name__ == '__main__':
    test_RussiaSpecProvider_kpp()

# Generated at 2022-06-21 15:36:18.287972
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    assert RussiaSpecProvider().inn() == '7716300229'


# Generated at 2022-06-21 15:36:21.721944
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    from mimesis.providers.person.ru import RussiaSpecProvider
    provider = RussiaSpecProvider()
    sentence = provider.generate_sentence()
    assert sentence.isalnum()
    assert len(sentence) > 5


# Generated at 2022-06-21 15:36:25.971861
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Test for method series_and_number of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    result = provider.series_and_number()
    assert(isinstance(result, str))
    assert(len(result) == 11)
    assert(result[2] == ' ')
    assert(result[7] == ' ')



# Generated at 2022-06-21 15:36:28.612655
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    provider = RussiaSpecProvider()
    ogrn = provider.ogrn()
    assert len(ogrn) == 13

# Generated at 2022-06-21 15:37:04.544337
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    assert RussiaSpecProvider().kpp() == '560058652'

# Generated at 2022-06-21 15:37:08.891223
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    ru = RussiaSpecProvider()
    ru.seed(1)
    result1 = ru.passport_number()
    ru.seed(1)
    result2 = ru.passport_number()
    assert result1 == result2


# Generated at 2022-06-21 15:37:11.594019
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    obj = RussiaSpecProvider()
    result = obj.snils()
    assert isinstance(result, str)
    assert len(result) == 11


# Generated at 2022-06-21 15:37:17.205143
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test method snils(self) of class RussiaSpecProvider."""
    lst = []

    for i in range(0, 20):
        lst.append(RussiaSpecProvider.snils(RussiaSpecProvider()))

    assert lst.count(lst[0]) == len(lst), 'The function generates \
    the same data'

# Generated at 2022-06-21 15:37:24.655637
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    russia_provider = RussiaSpecProvider()

    series = russia_provider.passport_series()
    assert series is not None
    assert len(series) == 5
    assert series.isdigit()
    assert int(series) < 1000000
    assert int(series) > 100000

    series = russia_provider.passport_series(year=18)
    assert series is not None
    assert len(series) == 5
    assert series.isdigit()
    assert int(series) < 1000000
    assert int(series) > 100000
    assert series[-2:] == '18'

    series = russia_provider.passport_series(year=1991)
    assert series is not None
    assert len(series) == 5
    assert series.isdigit()

# Generated at 2022-06-21 15:37:28.177146
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    provider = RussiaSpecProvider()
    number = provider.inn()
    assert len(number) == 12
    last_number = int(number[-1])
    assert last_number == 0 or last_number == 1


# Generated at 2022-06-21 15:37:33.306562
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    test_object = RussiaSpecProvider()
    # check length of output
    m = test_object.passport_number()
    assert len(str(m)) == 6
    # check range of output
    m2 = test_object.passport_number()
    assert (m2 > 100000) and (m2 < 999999)


# Generated at 2022-06-21 15:37:35.098485
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Testing of method passport_series of the class RussiaSpecProvider."""
    pass


# Generated at 2022-06-21 15:37:37.365188
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():

    assert(type(RussiaSpecProvider().bic()) == str)
    assert(len(RussiaSpecProvider().bic()) == 9)

# Generated at 2022-06-21 15:37:39.266959
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp(): 
   actual = RussiaSpecProvider().kpp()
   assert len(actual) == 9, 'Length should be 9'

# Generated at 2022-06-21 15:38:53.547845
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    provider = RussiaSpecProvider()
    assert provider.passport_number() in range(100000, 1000000)

# Generated at 2022-06-21 15:38:54.673032
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    obj = RussiaSpecProvider()
    assert len(obj.series_and_number()) == 11

# Generated at 2022-06-21 15:39:00.020820
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address

    r=RussiaSpecProvider()
    p=Person('ru')
    a=Address('ru')

    assert r.sentence()!=''
    assert r.snils()!=''
    assert r.inn()!=''
    assert r.bic()!=''
    assert r.kpp()!=''
    assert r.ogrn()!=''
    assert r.series_and_number()!=''
    assert r.patronymic()!=''
    assert r.passport_number()!=''
    assert r.passport_series()!=''
    assert r.generate_sentence()!=''
    assert r.random.seed!=None


# Generated at 2022-06-21 15:39:02.527338
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """Unit test for method passport_number of class RussiaSpecProvider"""
    russia = RussiaSpecProvider()
    assert russia.passport_number() == 735018

# Generated at 2022-06-21 15:39:12.462774
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    ru = RussiaSpecProvider()
    assert ru.random.randint(0, 9) == ru.random.randint(0, 9)
    assert ru.random.randint(0, 9) != ru.random.randint(0, 9)
    assert ru.generate_sentence() != ru.generate_sentence()
    assert ru.passport_series() != ru.passport_series()
    assert ru.passport_number() != ru.passport_number()
    assert ru.series_and_number() != ru.series_and_number()
    assert ru.snils() != ru.snils()
    assert ru.inn() != ru.inn()
    assert ru.ogrn() != ru.ogrn()
    assert ru.bic() != ru.bic()
    assert ru.kpp() != ru

# Generated at 2022-06-21 15:39:15.975809
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Test OGRN."""
    r = RussiaSpecProvider()
    assert len(r.ogrn()) == 13
    assert r.ogrn().isdigit()


# Generated at 2022-06-21 15:39:17.911169
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider()
    assert provider.bic() == '044025575'


# Generated at 2022-06-21 15:39:27.446858
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    russiaspeprovider = RussiaSpecProvider()
    print(russiaspeprovider.generate_sentence())
    print(russiaspeprovider.patronymic())
    print(russiaspeprovider.passport_series())
    print(russiaspeprovider.passport_number())
    print(russiaspeprovider.series_and_number())
    print(russiaspeprovider.generate_sentence())
    print(russiaspeprovider.snils())
    print(russiaspeprovider.inn())
    print(russiaspeprovider.ogrn())
    print(russiaspeprovider.bic())
    print(russiaspeprovider.kpp())
test_RussiaSpecProvider()

# Generated at 2022-06-21 15:39:35.218025
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    # Russian provider has to be created
    rus_provider = RussiaSpecProvider()
    # Attributes loc and data have to be defined
    assert hasattr(rus_provider, "loc") and hasattr(rus_provider, "data")
    # This attributes have to be not empty
    assert bool(rus_provider.loc) and bool(rus_provider.data)
    # Locale attribute have to be equal to 'ru'
    assert rus_provider.loc == 'ru'
    # The dictionary should have the following keys
    keys = ['first_name', 'last_name', 'patronymic', 'sentence']
    # Check that the keys are present
    assert all([key in rus_provider.data for key in keys])


# Generated at 2022-06-21 15:39:38.669764
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    provider = RussiaSpecProvider()
    ogrn = provider.ogrn()
    assert len(ogrn) == 13
    assert str(int(ogrn) % 11 % 10) == ogrn[-1]


# Generated at 2022-06-21 15:42:52.907619
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    RussiaSpecProvider.passport_number()

# Generated at 2022-06-21 15:43:02.042422
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Check if the generated snils is valid."""
    import re

    r = RussiaSpecProvider()
    for _ in range(0, 10000):
        snils = r.snils()
        numbers = re.compile(u'^[0-9]+$')
        assert numbers.match(snils) is not None
        assert len(snils) == 11

        numbers = [int(snils[i]) for i in range(0, 9)]
        control_codes = sum([x * y for x, y in zip(numbers, range(9, 0, -1))])

        assert control_codes % 101 == int(snils[9:11])


# Generated at 2022-06-21 15:43:03.498627
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    provider = RussiaSpecProvider()
    assert isinstance(provider.series_and_number(), str)


# Generated at 2022-06-21 15:43:11.045206
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    provider = RussiaSpecProvider()
    assert provider.patronymic() != provider.patronymic()
    assert provider.patronymic(Gender.MALE) != provider.patronymic(Gender.MALE)
    assert provider.patronymic(Gender.FEMALE) != provider.patronymic(Gender.FEMALE)
    assert provider.patronymic() != provider.patronymic(Gender.MALE)


# Generated at 2022-06-21 15:43:18.276718
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    test_provider = RussiaSpecProvider()
    assert len(test_provider.generate_sentence()) > 10
    test_provider = RussiaSpecProvider(seed=123456)
    assert len(test_provider.generate_sentence()) > 10
    assert test_provider.generate_sentence() == 'дорогие пользователи'


# Generated at 2022-06-21 15:43:19.681266
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    result = RussiaSpecProvider().bic()
    assert result != None


# Generated at 2022-06-21 15:43:27.949581
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider"""
    from mimesis.providers.ru.person import RussiaSpecProvider as RuSp
    from mimesis.providers.ru.person import RussiaPersonProvider as RuPr
    g = RuPr()
    c = RuSp()
    n = g.full_name()
    res = c.snils()
    assert len(res) == 11
    assert res[0:3] == n[3][0] + n[0][0] + n[1][0]

# Test data

# Generated at 2022-06-21 15:43:30.894683
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """
    Test for method passport_number of class RussiaSpecProvider.
    """
    random.seed(1234)
    provider = RussiaSpecProvider()
    assert provider.passport_number() == '560430'



# Generated at 2022-06-21 15:43:34.715491
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """
    >>> from mimesis.providers.russia import RussiaSpecProvider
    >>> r = RussiaSpecProvider(seed=42)
    >>> r.passport_number()
    '921067'

    """

# Generated at 2022-06-21 15:43:37.569686
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    """Test method bic of class RussiaSpecProvider."""
    data = RussiaSpecProvider().bic()
    assert len(data) == 9