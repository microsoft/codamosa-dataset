

# Generated at 2022-06-21 15:35:09.230463
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():

    s = RussiaSpecProvider(seed=123).passport_series()
    assert s == '22 15'


# Generated at 2022-06-21 15:35:14.781667
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    provider = RussiaSpecProvider()
    data = 'Представьте себе на секундочку красивый культурный экземпляр.'
    assert provider.generate_sentence() != data


# Generated at 2022-06-21 15:35:17.658322
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    # init
    provider = RussiaSpecProvider(seed=123456)
    # action
    result = provider.kpp()
    # assert
    assert result == '760188630'

# Generated at 2022-06-21 15:35:20.673160
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """Test for kpp method of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    for _ in range(20):
        kpp = provider.kpp()
        assert len(kpp) == 9 and type(kpp) == str



# Generated at 2022-06-21 15:35:28.817569
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    
    def test_Russian_sentence():
        """Unit test for method generate_sentence of class RussiaSpecProvider
        """
        print('Test of method generate_sentence of class RussiaSpecProvider')
        # Импортируем функцию
        from mimesis.providers.geo.russia import RussiaSpecProvider
        # Создаем экземпляр класса
        ru_spec_provider = RussiaSpecProvider()        
        # Генерируем слово
        sentence = ru_spec_provider.generate_sentence()
        print('sentence: {0}'.format(sentence))

# Generated at 2022-06-21 15:35:34.088872
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    a = []
    for _ in range(100):
        x = RussiaSpecProvider().series_and_number()
        a.append(x)
    # Check if all numbers in series are present

# Generated at 2022-06-21 15:35:44.743284
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
  from mimesis.providers.russia import RussiaSpecProvider

  r = RussiaSpecProvider(seed=17)
  assert r.ogrn() == '4715113303725'
  r = RussiaSpecProvider(seed=18)
  assert r.ogrn() == '9140013107786'
  r = RussiaSpecProvider(seed=19)
  assert r.ogrn() == '6318016032471'
  r = RussiaSpecProvider(seed=20)
  assert r.ogrn() == '5415022760295'
  r = RussiaSpecProvider(seed=21)
  assert r.ogrn() == '6114044402393'
  r = RussiaSpecProvider(seed=22)
  assert r.ogrn() == '7551056402611'

# Generated at 2022-06-21 15:35:52.743748
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    """Test method generate_sentence of class RussiaSpecProvider."""
    from mimesis.providers import RussiaSpecProvider
    x = RussiaSpecProvider()
    sentence = x.generate_sentence()
    list_sentence = sentence.split(" ")
    assert len(list_sentence) == 4
    assert list_sentence[0] in x._data['sentence']['head']
    assert list_sentence[1] in x._data['sentence']['p1']
    assert list_sentence[2] in x._data['sentence']['p2']
    assert list_sentence[3] in x._data['sentence']['tail']


# Generated at 2022-06-21 15:35:53.936498
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    rus = RussiaSpecProvider()
    assert rus.inn()


# Generated at 2022-06-21 15:35:56.399624
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    rs = RussiaSpecProvider()
    results = []
    for i in range(1000):
        results.append(rs.kpp())
    assert all([len(i) == 9 for i in results])


# Generated at 2022-06-21 15:36:23.417972
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    test = RussiaSpecProvider()

    test1 = test.generate_sentence()
    assert isinstance(test1, str)

    test2 = test.patronymic()
    assert isinstance(test2, str)

    test3 = test.passport_series()
    assert isinstance(test3, str)

    test4 = test.passport_number()
    assert isinstance(test4, int)

    test5 = test.series_and_number()
    assert isinstance(test5, str)

    test6 = test.snils()
    assert isinstance(test6, str)

    test7 = test.inn()
    assert isinstance(test7, str)

    test8 = test.ogrn()
    assert isinstance(test8, str)

    test9 = test.bic()

# Generated at 2022-06-21 15:36:28.553398
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    provider = RussiaSpecProvider()
    print(provider.passport_series())
    print(provider.passport_series())
    print(provider.passport_series())
    print(provider.passport_series())
    print(provider.passport_series())
    print(provider.passport_series())
    print(provider.passport_series())
    print(provider.passport_series())
    print(provider.passport_series())



# Generated at 2022-06-21 15:36:38.563315
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
        provider = RussiaSpecProvider()
        provider.create_unique()
        print('Sentence : ', provider.generate_sentence())
        print('Random Patronymic Name : ', provider.patronymic())
        print('Passport Series : ', provider.passport_series())
        print('Passport Number : ', provider.passport_number())
        print('Series and Number : ', provider.series_and_number())
        print('SNILS : ', provider.snils())
        print('INN : ', provider.inn())
        print('OGRN : ', provider.ogrn())
        print('BIC : ', provider.bic())
        print('KPP : ', provider.kpp())

# Generated at 2022-06-21 15:36:40.916430
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    p = RussiaSpecProvider()
    assert type(p.generate_sentence()) is str
    print('Method generate_sentence of class RussiaSpecProvider works correctly')


# Generated at 2022-06-21 15:36:42.277068
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    tmp = RussiaSpecProvider()
    assert tmp.__class__.__name__ == 'RussiaSpecProvider'
    tmp = RussiaSpecProvider(seed=10)
    assert tmp.__class__.__name__ == 'RussiaSpecProvider'


# Generated at 2022-06-21 15:36:52.819562
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    from mimesis.providers.person import Person
    from mimesis.enums import Gender
    import pytest
    rus = RussiaSpecProvider()
    persona = Person(locale='ru')
    couple_passport = [rus.passport_series() + str(rus.passport_number()) for i in range(0, 20)]
    couple_person = [persona.passport_series() + str(persona.passport_number()) for i in range(0, 20)]
    exist = False
    for i in range(0, 20):
        if couple_passport[i] == couple_person[i]:
            exist = True
    assert exist

# Generated at 2022-06-21 15:36:56.402584
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    snils = RussiaSpecProvider(seed=1).snils()
    assert snils == '042628200000'

# Generated at 2022-06-21 15:37:02.591228
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    """Unit test for method generate_sentence of class RussiaSpecProvider."""
    from mimesis.providers.helpers import replace_symbols

    rsp = RussiaSpecProvider()
    sentence = rsp.generate_sentence()
    assert isinstance(sentence, str)
    assert len(sentence) > 0
    replaced_sentence = replace_symbols(sentence, ' ')
    assert sentence == replaced_sentence


# Generated at 2022-06-21 15:37:05.965851
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    inn_list = []
    provider = RussiaSpecProvider()
    for i in range(0,100):
        inn_list.append(provider.inn())
    print(inn_list)

# Generated at 2022-06-21 15:37:08.980869
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rp = RussiaSpecProvider()
    test_str = rp.snils()
    assert len(test_str) == 11
    assert test_str.isdigit()


# Generated at 2022-06-21 15:37:44.874368
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """Test to method passport_number."""
    provider = RussiaSpecProvider(seed=1)
    provider2 = RussiaSpecProvider(seed=2)
    assert provider.passport_number() == provider2.passport_number()

# Generated at 2022-06-21 15:37:51.121286
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    from mimesis.providers.general import GeneralSpecProvider
    from mimesis.enums import ResultType

    gsp = GeneralSpecProvider('ru')
    rp = RussiaSpecProvider()
    bic = rp.bic()
    assert len(bic) == 9
    assert gsp.random.choice(rp.bank_organizations, bic=bic, result_type=ResultType.NAME) is not None

# Generated at 2022-06-21 15:37:55.548334
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    r = RussiaSpecProvider()
    for i in range(0, 100):
        a = r.ogrn()
        assert a[:-1] == str(int(a[:-1])%11%10)


# Generated at 2022-06-21 15:37:57.948668
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    from mimesis import RussiaSpecProvider
    provider = RussiaSpecProvider('ru')
    print(provider.generate_sentence())


# Generated at 2022-06-21 15:38:01.286622
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Test passport_series method of class RussiaSpecProvider."""
    rus = RussiaSpecProvider()
    print('\nTesting method passport_series of class RussiaSpecProvider')
    print(rus.passport_series())
    print(rus.passport_series(10))


# Generated at 2022-06-21 15:38:04.643361
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """Test RussiaSpecProvider.kpp()"""
    rs = RussiaSpecProvider()
    success = True
    for i in range(100):
        if len(rs.kpp()) != 9:
            success = False
            break
    print(success)


# Generated at 2022-06-21 15:38:13.442744
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    t = RussiaSpecProvider()
    t.seed(42)
    assert t.patronymic() == 'Анатольевна'
    assert t.patronymic(gender=Gender.MALE) == 'Андреевич'
    assert t.patronymic(gender=Gender.FEMALE) == 'Анатольевна'
    assert t.patronymic(gender=Gender.UNISEX) in ('Анатольевна', 'Андреевич')


# Generated at 2022-06-21 15:38:15.547594
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    ogrn1 = RussiaSpecProvider.ogrn()
    ogrn2 = RussiaSpecProvider.ogrn()
    assert ogrn1 != ogrn2


# Generated at 2022-06-21 15:38:18.688575
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Test for method ogrn of class RussiaSpecProvider"""
    ru = RussiaSpecProvider()
    ru.seed(12345)
    res = ru.ogrn()
    assert res == '4715113303725'

# Generated at 2022-06-21 15:38:23.073595
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    r = RussiaSpecProvider()
    ogrn = r.ogrn()
    assert len(ogrn) == 13
    assert (
        ogrn[11:13] == str((int(ogrn) % 11 % 10))
    )


# Generated at 2022-06-21 15:39:40.529127
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    provider = RussiaSpecProvider()
    result = provider.ogrn()
    print (result)
    assert len(result) == 13


# Generated at 2022-06-21 15:39:42.888585
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
	russia_provider = RussiaSpecProvider()
	kpp = russia_provider.kpp()
	assert len(kpp) == 9 and kpp.isdigit() == True

# Generated at 2022-06-21 15:39:47.326417
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """Test method passport_number of class RussiaSpecProvider."""
    # Arrange
    rsp = RussiaSpecProvider()
    # Act
    passport_number = rsp.passport_number()
    # Assert
    assert type(passport_number) == int
    assert len(str(passport_number)) == 6

# Generated at 2022-06-21 15:39:52.087459
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    '''
    GIVEN a provider and a datetime
    WHEN a series of passport is generated
    THEN check that the serial number is the same as the year
    '''
    provider = RussiaSpecProvider(seed=90)
    assert provider.passport_series(year=20) == '45 20'


# Generated at 2022-06-21 15:40:00.823270
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    """Test RussiaSpecProvider.patronymic method.
    """
    def assert_input_output(input_val, exp_val):
        act_val = RussiaSpecProvider(seed=42).patronymic(input_val)
        assert act_val == exp_val

    exp_val = 'Евгеньевна'
    for _ in range(10): assert_input_output(Gender.FEMALE, exp_val)

    exp_val = 'Васильевич'
    for _ in range(10): assert_input_output(Gender.MALE, exp_val)

    exp_val = 'Евгеньевна'

# Generated at 2022-06-21 15:40:02.738703
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    obj = RussiaSpecProvider()
    result = obj.passport_series()
    assert ' ' in result


# Generated at 2022-06-21 15:40:11.581311
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Проверка на вхождение в заданный интервал
    start = ''
    snils = RussiaSpecProvider().snils()
    assert start < snils < '4' + '0'*11
    # Проверка на корректность при известном значении
    result = '41917490290'
    assert RussiaSpecProvider(seed = '41917490290').snils() == result


# Generated at 2022-06-21 15:40:14.408550
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    ru_provider = RussiaSpecProvider()
    units = {
        '41917492600': ru_provider.snils()
    }
    return units



# Generated at 2022-06-21 15:40:21.916431
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    russia_provider = RussiaSpecProvider()
    print("Generate sentence: {}".format(russia_provider.generate_sentence()))
    print("Generate patronymic: {}".format(russia_provider.patronymic(Gender.FEMALE)))
    print("Generate passport series: {}".format(russia_provider.passport_series()))
    print("Generate passport number: {}".format(russia_provider.passport_number()))
    print("Generate passport number and series: {}".format(russia_provider.series_and_number()))
    print("Generate snils: {}".format(russia_provider.snils()))
    print("Generate inn: {}".format(russia_provider.inn()))

# Generated at 2022-06-21 15:40:33.331975
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Test that OGRN are not equal."""

# Generated at 2022-06-21 15:43:57.416481
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    assert RussiaSpecProvider().kpp() == '560058652'

# Generated at 2022-06-21 15:43:59.731668
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    provider = RussiaSpecProvider()
    assert len(provider.inn()) == 12
    assert isinstance(provider.inn(), str)
    

# Generated at 2022-06-21 15:44:02.689307
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    """Test constructor of class RussiaSpecProvider"""
    provider = RussiaSpecProvider()
    response = provider.provider
    assert len(response) > 0


# Generated at 2022-06-21 15:44:05.141313
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    ogrn_test = RussiaSpecProvider(seed=323)
    print(ogrn_test.ogrn())


# Generated at 2022-06-21 15:44:08.702991
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    test_object = RussiaSpecProvider()
    # test if snils is string
    assert type(test_object.snils()) == str
    # test if snils contains 11 digits
    assert len(test_object.snils()) == 11


# Generated at 2022-06-21 15:44:12.655141
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    import re

    from mimesis.builtins.ru import RussiaSpecProvider
    from mimesis.providers.bic import BIC
    x = BIC()
    assert re.match(r'\d{8}', x.bic()) is not None
    assert re.match(r'\d{8}', x.bic()) is not None

# Generated at 2022-06-21 15:44:15.867511
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Unit test for method passport_series of class RussiaSpecProvider."""
    sut = RussiaSpecProvider()
    assert sut.passport_series(year=11) == "11"
    assert sut.passport_series(year=19) == "19"


# Generated at 2022-06-21 15:44:19.937623
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    rus = RussiaSpecProvider()
    res = rus.patronymic(Gender.FEMALE)
    assert res == 'Алексеевна'
    # Unit test for method generate_sentence of class RussiaSpecProvider


# Generated at 2022-06-21 15:44:20.849465
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
  assert RussiaSpecProvider().ogrn() == '6715014629707'

# Generated at 2022-06-21 15:44:22.524567
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    russian_provider = RussiaSpecProvider()
    assert russian_provider.kpp() == "560058652"