

# Generated at 2022-06-21 15:35:06.501147
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    rsp = RussiaSpecProvider()
    assert len(rsp.series_and_number()) == 12


# Generated at 2022-06-21 15:35:07.969157
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    r = RussiaSpecProvider()
    print(r.ogrn())

# Generated at 2022-06-21 15:35:12.007154
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    r = RussiaSpecProvider()
    for _ in range(0, 10):
        bic = r.bic()
        assert len(bic) == 9 and bic.isdigit()


# Generated at 2022-06-21 15:35:14.259552
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    r = RussiaSpecProvider()
    result = r.generate_sentence()
    assert isinstance(result, str)


# Generated at 2022-06-21 15:35:15.640038
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    r = RussiaSpecProvider()
    r.inn()


# Generated at 2022-06-21 15:35:19.119668
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    # create a class
    rus = RussiaSpecProvider()
    # generate a bic
    bic = rus.bic()
    # check length of bic
    assert len(bic) == 9
    

# Generated at 2022-06-21 15:35:20.747113
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    rsp = RussiaSpecProvider()
    assert len(rsp.inn()) == 12

# Generated at 2022-06-21 15:35:26.795063
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """ Unit test for method series_and_number of class RussiaSpecProvider """

    flag=True
    for i in range(100):
        rsp=RussiaSpecProvider()
        txt=rsp.series_and_number()
        if (not txt[:5].isdigit()) or (not txt[5:].isdigit()):
            flag=False

    if flag:
        print("test_series_and_number passed")
    else:
        print("test_series_and_number failed")


# Generated at 2022-06-21 15:35:36.650126
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    from mimesis.enums import Gender
    from mimesis.providers.address import Address
    from mimesis.providers.credit_card import CreditCard
    from mimesis.providers.date_time import DateTime
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person
    from mimesis.providers.phone_code import PhoneCode
    from mimesis.providers.phone_number import PhoneNumber
    from mimesis.providers.postal_code import PostalCode
    from mimesis.providers.transport import Transport
    rus = RussiaSpecProvider()
    print(rus.bic())

# Generated at 2022-06-21 15:35:38.694753
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    provider = RussiaSpecProvider()
    assert provider.__class__.__name__ == 'RussiaSpecProvider'

# Generated at 2022-06-21 15:35:56.357693
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    r = RussiaSpecProvider()
    assert(len(r.patronymic(Gender.MALE)) > 0)

# Generated at 2022-06-21 15:35:58.581060
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    rsp = RussiaSpecProvider()
    kpp = rsp.kpp()
    print(kpp, len(kpp))

if __name__ == "__main__":
    test_RussiaSpecProvider_kpp()

# Generated at 2022-06-21 15:36:09.503873
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Unit test for method ogrn of class RussiaSpecProvider"""
    from mimesis.providers.finance import Finance
    from mimesis.data import FINANCE


    def check_ogrn(ogrn):
        """Private function for unit test of method ogrn of class
        RussiaSpecProvider
        """
        if Finance.check_ogrn(ogrn) is False:
            raise RuntimeError('Error in ogrn')
        else:
            return ogrn


    fin = Finance()
    # Test that if OGRN has 13 symbols and its checksum is correct
    if len(fin.ogrn()) != 13:
        raise RuntimeError('Error in ogrn')
    # The function check_ogrn raises exception if checksum is incorrect
    check_ogrn(fin.ogrn())



# Generated at 2022-06-21 15:36:12.227733
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    ru = RussiaSpecProvider()
    ru.seed(0)
    ru.random.randint(0, 10)

# Unit tests for generate_sentence of class RussiaSpecProvider

# Generated at 2022-06-21 15:36:14.567282
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    provider = RussiaSpecProvider()
    assert len(str(provider.passport_number())) == 6


# Generated at 2022-06-21 15:36:17.260647
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """Test random passport number."""
    n = RussiaSpecProvider().passport_number()
    assert isinstance(n, int) and 100000 <= n < 999999

# Generated at 2022-06-21 15:36:20.368793
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    russian_provider = RussiaSpecProvider()
    test_passport_number = russian_provider.passport_number()
    int(test_passport_number)


# Generated at 2022-06-21 15:36:25.827431
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Unit test for method ogrn of class RussiaSpecProvider"""

    russian_provider = RussiaSpecProvider()

    ogrn1 = russian_provider.ogrn()
    ogrn2 = russian_provider.ogrn()
    assert isinstance(ogrn1, str)
    assert isinstance(ogrn2, str)
    assert len(ogrn1) == 13
    assert len(ogrn2) == 13
    assert ogrn1 != ogrn2

# Generated at 2022-06-21 15:36:32.952611
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Проверка работы метода passport_series класса RussiaSpecProvider"""
    russian_provider = RussiaSpecProvider(seed=42)
    assert russian_provider.passport_series() == '25 17'
    assert russian_provider.passport_series() == '24 15'


# Generated at 2022-06-21 15:36:37.047047
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider()
    bic = provider.bic()
    correct = re.match(r'04\d{2}\d{2}\d{3}', bic)
    assert correct is not None


# Generated at 2022-06-21 15:37:20.202013
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    from mimesis.providers.cryptographic import Cryptographic
    ru_spec_provider = RussiaSpecProvider()
    ru_crypto_provider = Cryptographic()
    ru_spec_provider_kpp_result = ru_spec_provider.kpp()
    ru_crypto_provider_kpp_result = ru_crypto_provider.kpp()

    print('kpp result of RussiaSpecProvider: ' + ru_spec_provider_kpp_result)
    print('kpp result of Cryptographic: ' + ru_crypto_provider_kpp_result)

    assert ru_spec_provider_kpp_result == ru_crypto_provider_kpp_result


# Generated at 2022-06-21 15:37:25.637723
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider()
    bic = provider.bic()
    assert len(bic) == 9
    assert bic[0] == '0'
    assert bic[1] == '4'
    assert bic[2] == '4'
    assert bic[3] == '0'
    assert bic[4] == '2'
    assert int(bic[5]) in range(0, 5)
    assert int(bic[6]) in range(0, 5)
    assert int(bic[7]) in range(0, 5)
    assert int(bic[8]) in range(0, 5)


# Generated at 2022-06-21 15:37:36.590822
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    # функция отвечает за падение программы при вызове метода ogrn()
    print("\n...test_RussiaSpecProvider_ogrn()...")
    russian_provider = RussiaSpecProvider()
    russian_provider.ogrn()
    print("\tFINISH")


# # Unit test for method inn of class RussiaSpecProvider
# def test_RussiaSpecProvider_inn():
#     # функция отвечает за падение программы при вызове

# Generated at 2022-06-21 15:37:44.546078
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    rus_spc_provider = RussiaSpecProvider()
    bic = rus_spc_provider.bic()
    assert len(bic) <= 9
    assert len(bic) >= 8
    assert bic[0:2] == '04'
    assert int(bic[2:4]) >= 1 and int(bic[2:4]) <= 10
    assert int(bic[4:6]) >= 0 and int(bic[4:6]) <= 99
    assert int(bic[6:9]) >= 50 and int(bic[6:9]) <= 999


# Generated at 2022-06-21 15:37:47.572165
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """Unit test for method kpp of class RussiaSpecProvider.
    """
    provider = RussiaSpecProvider()
    kpp = provider.kpp()
    print(kpp)
    assert len(kpp) == 9
    assert kpp.isnumeric()

# Generated at 2022-06-21 15:37:53.841191
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    provider = RussiaSpecProvider()
    assert type(provider.patronymic()) == str
    # Test gender
    assert type(provider.patronymic(Gender.MALE)) == str
    assert type(provider.patronymic(Gender.FEMALE)) == str
    assert type(provider.patronymic('female')) == str


# Generated at 2022-06-21 15:38:01.912503
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    provider = RussiaSpecProvider()
    result_M = provider.patronymic(Gender.MALE)
    result_F = provider.patronymic(Gender.FEMALE)
    result = provider.patronymic()
    
    assert isinstance(result, str)
    assert result_M in provider._data['patronymic'][Gender.MALE]
    assert result_F in provider._data['patronymic'][Gender.FEMALE]

    assert result in provider._data['patronymic'][Gender.MALE] + provider._data['patronymic'][Gender.FEMALE]

# Generated at 2022-06-21 15:38:11.099109
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    import unittest
    import doctest
    doctest.testmod()
    class Test_test_RussiaSpecProvider(unittest.TestCase):
        def setUp(self):
            self.russiaspecprovider = RussiaSpecProvider()

        def test_generate_sentence(self):
            self.assert_(self.russiaspecprovider.generate_sentence())

        def test_patronymic(self):
            self.assert_(self.russiaspecprovider.patronymic())

        def test_passport_series(self):
            self.assert_(self.russiaspecprovider.passport_series())

        def test_passport_number(self):
            self.assert_(self.russiaspecprovider.passport_number())


# Generated at 2022-06-21 15:38:12.547414
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    rus = RussiaSpecProvider()
    assert len(rus.bic()) == 9


# Generated at 2022-06-21 15:38:18.412748
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    r1 = RussiaSpecProvider()
    kpp = r1.kpp()
    assert len(kpp) == 9

# Generated at 2022-06-21 15:39:46.570951
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    # Step 1: create an object of class RussiaSpecProvider
    Russian_provider = RussiaSpecProvider()
    # Step 2:  call a method generate_sentence of class RussiaSpecProvider
    #          with the seed 0 and without parameter
    result = Russian_provider.generate_sentence(seed=0)
    # Step 3: Check result with expected value
    assert result == 'Я иду в парк'



# Generated at 2022-06-21 15:39:49.761007
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """ Test for method kpp of class RussiaSpecProvider """
    obj = RussiaSpecProvider()
    result = obj.kpp()
    assert isinstance(result, str) and len(result) == 9


# Generated at 2022-06-21 15:39:59.453016
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    provider = RussiaSpecProvider()
    inn = provider.inn()

    def control_sum(nums: list, t: str) -> int:
        digits_dict = {
            'n2': [7, 2, 4, 10, 3, 5, 9, 4, 6, 8],
            'n1': [3, 7, 2, 4, 10, 3, 5, 9, 4, 6, 8],
        }
        number = 0
        digits = digits_dict[t]

        for i, _ in enumerate(digits, start=0):
            number += nums[i] * digits[i]
        return number % 11 % 10

    # check_length
    assert len(inn) == 12
    # check_sum
    n1, n2 = inn[-1], inn[-2]

# Generated at 2022-06-21 15:40:02.230136
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    ru = RussiaSpecProvider()
    ru.patronymic()
    ru.patronymic(Gender.FEMALE)  
    ru.patronymic(Gender.MALE)


# Generated at 2022-06-21 15:40:03.854514
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    r = RussiaSpecProvider()
    print(r.generate_sentence())


# Generated at 2022-06-21 15:40:05.737142
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    bic = RussiaSpecProvider().bic()
    assert bic.startswith('04')
    assert len(bic) == 9


# Generated at 2022-06-21 15:40:16.205742
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    import time
    import random
    import string
    import mimesis
    from mimesis.enums import Gender

    """test RussiaSpecProvider.patronymic method"""

    def get_random_string(length):
        letters = string.ascii_lowercase
        result_str = ''.join(random.choice(letters) for i in range(length))
        return result_str

    # set seed
    seed = int(time.time())
    random.seed(seed)
    seeds = [str(seed) * 10]

    print('seed:', seed)
    print()

    rus = mimesis.RussiaSpecProvider()

    for idx, s in enumerate(seeds):
        print('Test Case #{}'.format(idx + 1))

        # set seed
        random.seed(s)

# Generated at 2022-06-21 15:40:18.171282
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    expected = "5123030196"
    assert RussiaSpecProvider().inn() == expected


# Generated at 2022-06-21 15:40:19.269809
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    a = RussiaSpecProvider()
    a.generate_sentence()

# Generated at 2022-06-21 15:40:24.678602
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """SNILS must be valid."""
    r = RussiaSpecProvider()
    snils = r.snils()

    digits = [int(digit) for digit in str(snils)]
    sum_ = 0
    for i, _ in enumerate(digits, start=1):
        sum_ += digits[i - 1] * i

    assert sum_ % 101 % 100 == digits[-2] * 10 + digits[-1]

# Generated at 2022-06-21 15:44:01.229813
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    provider = RussiaSpecProvider(seed="test")
    print("kpp: ", provider.kpp())


# Generated at 2022-06-21 15:44:06.433913
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():

    #Arrange
    expected = 6
    actual = len(RussiaSpecProvider().passport_number())

    #Assert
    try:
        assert(expected == actual)
    except:
        print("Error: expected=" + expected + " actual=" + actual)

test_RussiaSpecProvider_passport_number()


# Generated at 2022-06-21 15:44:09.738283
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    seed = "123456"
    sut = RussiaSpecProvider(seed)
    assert sut.__class__.__name__ == 'RussiaSpecProvider'
    assert sut._locale == 'ru'
    assert sut._seed.args[0] == 123456

# Generated at 2022-06-21 15:44:12.080944
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    provider = RussiaSpecProvider()
    number = provider.passport_number()
    assert isinstance(number, int)
    assert (100000 <= number <= 999999)

# Generated at 2022-06-21 15:44:17.725451
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    """Test method bic from class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    bic = provider.bic()
    assert bic.isdigit()
    assert len(bic) == 9
    assert int(bic[:2]) in range(1, 99)
    assert int(bic[2:4]) in range(0, 10)
    assert int(bic[4:6]) in range(0, 100)
    assert int(bic[6:]) in range(100, 1000)


# Generated at 2022-06-21 15:44:23.062847
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    # Создание объекта класса RussiaSpecProvider
    rsp = RussiaSpecProvider()
    # Генерация данных
    rsp.patronymic(Gender.MALE)
    rsp.patronymic(Gender.FEMALE)
    rsp.patronymic(Gender.UNKNOWN)
    # Проверка возвращаемого объекта
    assert isinstance(rsp.patronymic(), str)
    # Проверка возможности принимать ар

# Generated at 2022-06-21 15:44:25.473600
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    rus = RussiaSpecProvider()
    for _ in range(40):
        assert len(str(rus.passport_series())) == 5


# Generated at 2022-06-21 15:44:29.575006
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    russ = RussiaSpecProvider()
    sent = russ.generate_sentence()

    if sent is None:
        raise AssertionError('Value is None')
    if not isinstance(sent, str):
        raise TypeError('Value is not string')
    if sent == '':
        raise ValueError('Value is empty')



# Generated at 2022-06-21 15:44:32.403010
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    provider = RussiaSpecProvider(seed=42)
    assert provider.passport_series() == "75 15"
    

# Generated at 2022-06-21 15:44:34.715418
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """Test to check the method passport_number of class RussiaSpecProvider"""
    a = RussiaSpecProvider().passport_number()
    assert len(str(a)) == 6
