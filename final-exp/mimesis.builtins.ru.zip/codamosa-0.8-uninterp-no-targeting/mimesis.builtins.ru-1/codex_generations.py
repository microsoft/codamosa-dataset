

# Generated at 2022-06-21 15:35:11.145716
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.person import Person
    from mimesis.providers.social import SocialSecurityNumber
    def validate_snils(snils):
        number = int(snils)
        control_codes = []
        for i in range(9, 0, -1):
            control_codes.append(number % 10 * i)
            number //= 10
        control_code = sum(control_codes) % 101
        return control_code == int(snils[9:])

    r = RussiaSpecProvider()
    s = SocialSecurityNumber('ru')
    p = Person('ru')
    men = p.create_male_full_name()
    women = p.create_female_full_name()
    from mimesis.builtins import RussiaSpecProvider
    for _ in range(1000):
        assert validate_sn

# Generated at 2022-06-21 15:35:20.834600
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    import json
    import os
    from tests.utils import each_provider

    def _assert_valid_passport_series():
        parts = item.split(' ')
        assert len(parts) == 2
        for part in parts:
            assert part.isdigit()
            assert len(part) == 2

    current_dir = os.path.dirname(os.path.abspath(__file__))
    data_file = os.path.join(current_dir, 'data', 'ru.json')

    with open(data_file) as file:
        data = json.load(file)

    items = data['passport_series']

    for provider in each_provider(RussiaSpecProvider):
        for item in items:
            result = provider.passport_series(year=item)
            _assert_valid

# Generated at 2022-06-21 15:35:24.303394
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    from mimesis import Generic
    from mimesis.providers.finance import Finance

    russian_finance = Finance('ru')
    bic = russian_finance.bic()
    assert isinstance(bic, str)



# Generated at 2022-06-21 15:35:26.142209
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
   for i in range(100):
      assert RussiaSpecProvider().snils() != RussiaSpecProvider().snils()


# Generated at 2022-06-21 15:35:37.464513
# Unit test for method snils of class RussiaSpecProvider

# Generated at 2022-06-21 15:35:43.511764
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    # Create
    rsp = RussiaSpecProvider()
    
    # Method should not return None
    patronymic = rsp.patronymic()
    assert patronymic is not None
    
    # Method should return a string
    assert type(patronymic) is str
    
    # Method should return a string with length at least 2
    assert len(patronymic) >= 2


# Generated at 2022-06-21 15:35:47.701398
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    from mimesis.enums import Gender
    from mimesis.providers.person.russia import RussiaSpecProvider

    rsp = RussiaSpecProvider()

    assert rsp.patronymic(Gender.MALE) in rsp._data['patronymic'][Gender.MALE]
    assert rsp.patronymic(Gender.FEMALE) in rsp._data['patronymic'][Gender.FEMALE]

# Generated at 2022-06-21 15:35:48.952726
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    assert RussiaSpecProvider().passport_series() == '34 18'


# Generated at 2022-06-21 15:35:55.553359
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    pr = RussiaSpecProvider(seed=1234567890)
    assert pr.generate_sentence() == 'В течение всего времени нахождения в России какой-то человек обязан быть зарегистрирован в месте проживания.'


# Generated at 2022-06-21 15:35:59.837442
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    import os, sys
    import doctest
    os.chdir(os.path.dirname(os.path.abspath(sys.argv[0])))
    doc_test = doctest.DocTestSuite(RussiaSpecProvider)
    doc_test.testmod()
   

# Generated at 2022-06-21 15:36:24.238442
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    """Unit test for RussiaSpecProvider."""

    russia_provider = RussiaSpecProvider()
    assert russia_provider.generate_sentence() == 'У него стояло несколько вопросов.'
    assert russia_provider.patronymic(Gender.MALE) == 'Авдеевна'
    assert russia_provider.passport_series(18) == '70 18'
    assert russia_provider.passport_number() == 872634
    assert russia_provider.series_and_number() == '2502 207085'
    assert russia_provider.snils() == '47023835325'

# Generated at 2022-06-21 15:36:27.489805
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    from mimesis.providers.person.ru import RussiaSpecProvider as rsp
    from mimesis.schema import Field
    from mimesis.typing import Datetime

    provider = rsp(Datetime(2019))
    assert(provider.passport_number() == '211853')


# Generated at 2022-06-21 15:36:39.064738
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    from re import match
    from mimesis.enums import Gender
    from mimesis.providers.code import Code

    provider = RussiaSpecProvider()
    code = Code.get_provider(region='ru')
    
    # Pattern for matching kpp
    pattern = '\d{4}[1-9]\d{2}'
    
    # Loop for first 100 generated kpp for matching with pattern
    for _ in range(100):
        assert match(pattern, provider.kpp())
    
    # Test for making sure RussiaSpecProvider is a subclass of BaseSpecProvider
    assert issubclass(RussiaSpecProvider, BaseSpecProvider)
    
    # Test for the property 'Meta.name' of RussiaSpecProvider
    assert RussiaSpecProvider.Meta.name in ('russia_provider', 'provider')
    
    #

# Generated at 2022-06-21 15:36:41.999809
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test a method that generate snils"""
    p = RussiaSpecProvider()
    snils_1 = p.snils()
    p = RussiaSpecProvider()
    snils_2 = p.snils()
    assert snils_1 != snils_2

# Generated at 2022-06-21 15:36:44.706634
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    rsp = RussiaSpecProvider()
    ogrn = rsp.ogrn()
    print(ogrn)
    assert len(ogrn) == 13
    assert ogrn[12] == str(int(ogrn[0:12]) % 11 % 10)


# Generated at 2022-06-21 15:36:47.651452
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    provider = RussiaSpecProvider()
    ogrn = provider.ogrn()
    assert len(ogrn) == 13


# Generated at 2022-06-21 15:36:52.470148
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Unit test for method series_and_number of class RussiaSpecProvider."""
    test_inst = RussiaSpecProvider()

    for i in range(0,10):
        assert len(test_inst.series_and_number()) == 13
    assert len(test_inst.series_and_number()) == 13


# Generated at 2022-06-21 15:36:56.040274
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    r = RussiaSpecProvider()
    assert type(r.patronymic(Gender.FEMALE)) is str


# Generated at 2022-06-21 15:36:59.722477
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    from mimesis.builtins import RussiaSpecProvider
    rus_spec_provider = RussiaSpecProvider()
    rus_spec_provider.seed(1)
    doc = rus_spec_provider.series_and_number()
    assert doc == '301211188126'

# Generated at 2022-06-21 15:37:01.921623
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    assert RussiaSpecProvider().snils() == '41917492600'


# Generated at 2022-06-21 15:37:34.605353
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    r = RussiaSpecProvider(seed=1234567890)
    assert r.series_and_number() == '62 18 513451'

# Generated at 2022-06-21 15:37:37.638885
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    r = "4715113303725"
    assert len(r) == 13
    r1 = RussiaSpecProvider.ogrn()
    assert len(r1) == 13


# Generated at 2022-06-21 15:37:40.012775
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Test ogrn."""
    assert len(RussiaSpecProvider().ogrn()) == 13
    assert isinstance(RussiaSpecProvider().ogrn(), str)

# Generated at 2022-06-21 15:37:45.127237
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test snils:
        1. Create instance RussiaSpecProvider.
        2. Get snils.

    :return: None
    """
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert isinstance(snils, str) == True
    assert len(snils) == 11
    assert snils.isdigit() == True


# Generated at 2022-06-21 15:37:49.468136
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    ru = RussiaSpecProvider()
    ru.generate_sentence()
    ru.patronymic(Gender.MALE)
    ru.patronymic(Gender.FEMALE)
    ru.passport_series(11)
    ru.passport_number()
    ru.series_and_number()
    ru.snils()
    ru.inn()
    ru.ogrn()
    ru.bic()
    ru.kpp()


# Generated at 2022-06-21 15:37:51.437613
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    provider = RussiaSpecProvider()
    assert hasattr(provider, 'generate_sentence')

# Generated at 2022-06-21 15:37:55.462114
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    """Test BIC generate."""
    provider = RussiaSpecProvider()
    bic = provider.bic()
    assert type(bic) is str
    assert len(bic) == 9


# Generated at 2022-06-21 15:37:57.469039
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    provider = RussiaSpecProvider()
    result = provider.passport_number()
    assert isinstance(result, int)
    assert len(str(result)) == 6


# Generated at 2022-06-21 15:38:00.896372
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    spec_provider = RussiaSpecProvider()
    assert spec_provider.locale == "ru"
    assert spec_provider.__repr__() == '<RussiaSpecProvider.RussiaSpecProvider>'
    assert spec_provider.__str__() == 'ru'


# Generated at 2022-06-21 15:38:02.688778
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    new_RussiaSpecProvider = RussiaSpecProvider()
    assert new_RussiaSpecProvider != None

# Unit tests for method generate_sentence

# Generated at 2022-06-21 15:39:15.564575
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    Russia = RussiaSpecProvider(seed=42)
    Russia.seed = 42
    p = Russia.patronymic(gender=Gender.MALE)
    assert p == 'Герасимович'
    p = Russia.patronymic(gender=Gender.FEMALE)
    assert p == 'Владимировна'


# Generated at 2022-06-21 15:39:17.561255
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    provider = RussiaSpecProvider(seed=42)
    assert provider.ogrn() == "4715113303725"

# Generated at 2022-06-21 15:39:18.938935
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    print(RussiaSpecProvider().bic())


# Generated at 2022-06-21 15:39:21.656706
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    p = RussiaSpecProvider()
    result = p.passport_number()
    assert type(result) == int
    assert result >= 100000
    assert result <= 999999


# Generated at 2022-06-21 15:39:23.961348
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    rus = RussiaSpecProvider()
    series_and_number = rus.series_and_number()
    print(series_and_number)
    assert True


# Generated at 2022-06-21 15:39:24.522638
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    RussiaSpecProvider()

# Generated at 2022-06-21 15:39:26.450819
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    assert RussiaSpecProvider()
    assert RussiaSpecProvider().generate_sentence()


# Generated at 2022-06-21 15:39:28.122173
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    prov = RussiaSpecProvider()
    assert prov.generate_sentence()


# Generated at 2022-06-21 15:39:29.330063
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    assert len(RussiaSpecProvider().bic()) == 9


# Generated at 2022-06-21 15:39:36.939579
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    from mimesis.schema import Field, Schema
    from mimesis.types import Type

    # create seed provider
    sp = RussiaSpecProvider(seed = 1234)
    
    # create schema
    s = Schema(sp)

    # create fields
    f1 = Field('passport_number')
    f2 = Field('passport_series')
    
    f3 = Field('series_and_number')

    f4 = Field('inn')
    f5 = Field('ogrn')
    f6 = Field('bic')
    f7 = Field('kpp')

    f8 = Field('patronymic')

    f9 = Field('snils')
    
    f10 = Field('generate_sentence')
    
    # create Type
    t = Type(s)

    # print values


# Generated at 2022-06-21 15:42:33.428739
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    ru = RussiaSpecProvider()
    ru.generate_sentence()
    assert ru.generate_sentence() is not None



# Generated at 2022-06-21 15:42:35.076722
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """Unit test for method kpp of class RussiaSpecProvider"""
    kpp = RussiaSpecProvider()
    print(kpp.kpp())

# Generated at 2022-06-21 15:42:37.463121
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    import pytest
    kpp = RussiaSpecProvider().kpp()
    assert len(kpp) == 9


# Generated at 2022-06-21 15:42:40.583621
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """Test method passport_number of class RussiaSpecProvider."""

    russiaprovider = RussiaSpecProvider()

    assert isinstance(russiaprovider.passport_number(), int)


# Generated at 2022-06-21 15:42:46.082143
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    test_list = [
        RussiaSpecProvider().series_and_number(),
        RussiaSpecProvider().series_and_number(),
        RussiaSpecProvider().series_and_number(),
        RussiaSpecProvider().series_and_number(),
        RussiaSpecProvider().series_and_number(),
    ]
    assert len(test_list[0]) == 11
    assert len(test_list[1]) == 11
    assert len(test_list[2]) == 11
    assert len(test_list[3]) == 11
    assert len(test_list[4]) == 11


# Generated at 2022-06-21 15:42:55.091691
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Test method series_and_number of class RussiaSpecProvider
    for generete valid passport number and series"""
    from mimesis.builtins import RussiaSpecProvider as inn_check

    # Generate passport number and series with RussiaSpecProvider
    passport_series_and_number = inn_check().series_and_number()

    # Check that passport number and series starts with a number
    # and ends with a number and have length 11
    assert passport_series_and_number[0] in '0123456789'
    assert passport_series_and_number[-1] in '0123456789'
    assert len(passport_series_and_number) == 11



# Generated at 2022-06-21 15:42:55.784073
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    assert RussiaSpecProvider.generate_sentence() in RussiaSpecProvider._data['sentence']

# Generated at 2022-06-21 15:42:57.156887
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    provider = RussiaSpecProvider()
    a1 = provider.passport_number()
    a2 = provider.passport_number()
    assert a1 == (a2 - 1 or a2 + 1)


# Generated at 2022-06-21 15:43:01.250657
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():

    provider = RussiaSpecProvider()
    bic = provider.bic()
    assert len(bic) == 9


# Generated at 2022-06-21 15:43:04.593454
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    try:
        rsp = RussiaSpecProvider()
        kpp = rsp.kpp()
        assert len(kpp) == 9
    except Exception:
        assert False
