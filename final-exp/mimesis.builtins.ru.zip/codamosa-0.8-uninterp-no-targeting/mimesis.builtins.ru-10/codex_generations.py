

# Generated at 2022-06-21 15:35:07.223006
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    russia_provider = RussiaSpecProvider()
    assert russia_provider.kpp() == '560058652'

# Generated at 2022-06-21 15:35:07.928314
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    assert RussiaSpecProvider()

# Generated at 2022-06-21 15:35:19.196671
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """Test for method kpp of class RussiaSpecProvider.
    
    Checking whether the method kpp returns a number of the correct 
    format. KPP is the main State Registration Number (OGRN). 
    Consists of nine digits: the first two digits are equal to 77,
    and the rest are of the form 00-01-001.
    """
    # create an object of the tested class
    russia_provider = RussiaSpecProvider()
    
    # generate fake data by calling the method under test
    kpp = russia_provider.kpp()
    
    # create a template for the fake data
    kpp_template = [r'\d{2}', r'\d{2}', r'\d{1}', r'\d{2}', r'\d{3}']
    
    # compare the

# Generated at 2022-06-21 15:35:21.897322
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    r = RussiaSpecProvider()
    assert (r.passport_series().__len__() == 5)
    assert (r.passport_series(18).__len__() == 5)


# Generated at 2022-06-21 15:35:23.513108
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    provider = RussiaSpecProvider()
    result = provider.passport_number()
    assert 9999 < result < 1000000

# Generated at 2022-06-21 15:35:25.828666
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    provider = RussiaSpecProvider()
    patronymic = provider.patronymic()
    assert len(patronymic) > 0
    assert patronymic is not None


# Generated at 2022-06-21 15:35:34.093539
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Test for method 'ogrn' of class 'RussiaSpecProvider'."""
    from mimesis.providers.russia import RussiaSpecProvider
    rsp = RussiaSpecProvider()
    ogrn = rsp.ogrn()
    assert len(ogrn) == 13
    assert '-' not in ogrn
    assert ogrn[0] == '1' or ogrn[0] == '7'
    assert ogrn[0] == '1' or ogrn[0] == '7'

# Generated at 2022-06-21 15:35:38.646204
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    from mimesis import RussiaSpecProvider, Gender
    from mimesis.builtins.base import BaseSpecProvider
    provider = RussiaSpecProvider()
    assert provider.patronymic(Gender.MALE)
    assert BaseSpecProvider.patronymic(provider, Gender.MALE)



# Generated at 2022-06-21 15:35:41.224272
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider()
    test_str = provider.bic()
    assert len(test_str) == 9


# Generated at 2022-06-21 15:35:45.099056
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    russiaspecprovider = RussiaSpecProvider()
    n = russiaspecprovider.series_and_number()
    print(n)
#     assert re.fullmatch('[0-9]{4} [0-9]{2} [0-9]{6}', n)


# Generated at 2022-06-21 15:36:09.750361
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Testing RussiaSpecProvider method snils."""
    from tddspry.django import TestCase
    from eregs_core.models import RussiaProvider

    class Test(TestCase):
        # Unit test for method snils of class RussiaSpecProvider
        def test_RussiaSpecProvider_snils(self):
            """Testing RussiaSpecProvider method snils."""
            rus = RussiaProvider()
            snils = rus.snils()
            assert snils is not None
            assert len(snils) == 11
            assert str(snils).isdigit()

    test = Test()
    test.test_RussiaSpecProvider_snils()


# Generated at 2022-06-21 15:36:11.948455
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    provider = RussiaSpecProvider()
    passport = provider.series_and_number()
    print(passport)



# Generated at 2022-06-21 15:36:15.579342
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    provider = RussiaSpecProvider()
    for _ in range(100):
        inn = provider.inn()
        assert len(inn) == 10
        assert isinstance(inn, str)


# Generated at 2022-06-21 15:36:25.307906
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    patronymics = [
        'Александровна',
        'Анатолиевна',
        'Аполлинарьевна',
        'Артёмовна',
        'Архиповна',
        'Архиповна',
        'Архиповна',
        'Архиповна',
        'Архиповна',
    ]
    ru = RussiaSpecProvider()
    for i in range(0, 100):
        assert ru.patronymic()in patronymics



# Generated at 2022-06-21 15:36:37.784916
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    rp = RussiaSpecProvider()
    for _ in range(1000):
        kpp = str(rp.kpp())
        assert len(kpp) == 10
        for n in kpp:
            assert n in '0123456789'
        assert kpp[0] != '0'

# Generated at 2022-06-21 15:36:39.151561
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    assert RussiaSpecProvider().kpp() == "560028267"

# Generated at 2022-06-21 15:36:42.114581
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    """Unit test for method patronymic of class RussiaSpecProvider.
    :return:
    """
    assert RussiaSpecProvider(seed=1234567890).patronymic() == 'ична'



# Generated at 2022-06-21 15:36:47.461333
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider"""
    from mimesis.builtins.specs import russia_provider
    russia_provider = RussiaSpecProvider('seed')
    snils = russia_provider.snils()
    # Simple check
    assert len(snils) == 11
    # Generate a lot of SNILS
    list_snils = [russia_provider.snils() for _ in range(0, 1000)]
    # Check if any of the generated data are equal
    assert len(set(list_snils)) == len(list_snils)
    # Check if the data is unique
    assert min(list_snils) != max(list_snils)

# Generated at 2022-06-21 15:36:51.333030
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Unit test for method inn of class RussiaSpecProvider."""
    r = RussiaSpecProvider()
    inn = r.inn()
    assert len(inn) == 12
    assert isinstance(inn, str)

# Generated at 2022-06-21 15:36:53.056475
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    provider = RussiaSpecProvider()
    assert provider.passport_series(year=18) == "02 18"


# Generated at 2022-06-21 15:37:28.918837
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    r = RussiaSpecProvider(seed=42)
    sn = r.series_and_number()
    assert sn == '671805199'


# Generated at 2022-06-21 15:37:33.257712
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    """Unit test for method patronymic of class RussiaSpecProvider"""
    assert RussiaSpecProvider().patronymic()
    assert RussiaSpecProvider().patronymic(Gender.FEMALE)
    assert RussiaSpecProvider().patronymic(Gender.MALE)


# Generated at 2022-06-21 15:37:35.098530
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    rsp = RussiaSpecProvider()

    assert len(rsp.kpp()) == 9
#

# Generated at 2022-06-21 15:37:39.909405
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    from mimesis import Russia
    from mimesis.providers.base import BaseSpecProvider

    class RussiaSpecProvider(BaseSpecProvider):
        class Meta:
            name = 'russia_provider'

    rsp = Russia.RussiaSpecProvider(None)
    assert isinstance(rsp, RussiaSpecProvider)



# Generated at 2022-06-21 15:37:41.454668
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    rsp = RussiaSpecProvider()
    rsp.inn()

# Generated at 2022-06-21 15:37:49.623012
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    russian_provider = RussiaSpecProvider(seed=15)
    fio = russian_provider.full_name(gender='male')
    passport = russian_provider.series_and_number()
    address = russian_provider.address()
    sentence = russian_provider.generate_sentence()
    assert fio == 'Земцов Юлий Георгиевич'
    assert passport == '52 12 945179'
    assert address == 'Михайла обл., Иловля, Стрельникова, 3А, 6, 21'

# Generated at 2022-06-21 15:37:51.540903
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    rsp = RussiaSpecProvider()
    print(rsp.generate_sentence())


# Generated at 2022-06-21 15:37:55.501808
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    from mimesis.enums import Gender
    r = RussiaSpecProvider()
    bic = r.bic()
    print(bic)
    assert type(bic) == str


# Generated at 2022-06-21 15:37:57.974341
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
  russian_spec_provider = RussiaSpecProvider()
  patronymic = russian_spec_provider.patronymic()
  assert len(patronymic) == len("Ивановна")


# Generated at 2022-06-21 15:37:59.318135
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    result = RussiaSpecProvider().bic()
    assert len(result) == 9

# Generated at 2022-06-21 15:39:17.694617
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    rsp = RussiaSpecProvider(seed=1234567890)
    assert rsp.passport_number() == rsp.passport_number(seed=1234567890)


# Generated at 2022-06-21 15:39:20.213244
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    sentence = RussiaSpecProvider().generate_sentence()
    assert len(sentence) > 0
    assert type(sentence) == str


# Generated at 2022-06-21 15:39:26.410694
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    obj = RussiaSpecProvider(seed=123)
    for i in range(0, 10):
        assert obj.passport_series() == '57 16'
    obj = RussiaSpecProvider(seed=123)
    for i in range(0, 10):
        assert obj.passport_series(2018) == '88 18'
    obj = RussiaSpecProvider(seed=123)
    for i in range(0, 10):
        assert obj.passport_series(2098) == '98 98'


# Generated at 2022-06-21 15:39:29.749961
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    def test_one_run():
        provider = RussiaSpecProvider()
        sentence = provider.generate_sentence()
        assert(len(sentence) > 0)

    for i in range (0, 10):
        test_one_run()


# Generated at 2022-06-21 15:39:32.123332
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
   """Unit test for kpp of RussiaSpecProvider"""
   RussiaSpecProvider_kpp_test_obj = RussiaSpecProvider()
   print("Unit test for method kpp of class RussiaSpecProvider")
   print(RussiaSpecProvider_kpp_test_obj.kpp())



# Generated at 2022-06-21 15:39:34.214000
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """Testing method passport_number of class RussiaSpecProvider."""
    rus = RussiaSpecProvider()
    num = rus.passport_number()
    assert len(str(num)) == 6



# Generated at 2022-06-21 15:39:35.326347
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    assert RussiaSpecProvider(seed=0).kpp() == '330059350'

# Generated at 2022-06-21 15:39:38.016937
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rus = RussiaSpecProvider()
    assert(len(rus.snils()) == 11)



# Generated at 2022-06-21 15:39:42.624007
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    x = RussiaSpecProvider()
    assert len(x.series_and_number().split()) == 2
    assert len(x.series_and_number().split(' ')[0]) == 4
    assert len(x.series_and_number().split(' ')[1]) == 6
    assert x.series_and_number().split(' ')[1].isdigit()


# Generated at 2022-06-21 15:39:53.507978
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    import unittest
    from mimesis.enums import Gender
    from mimesis.providers.person.ru import RussiaSpecProvider
    from mimesis.typing import Seed

    class TestRussiaSpecProvider(unittest.TestCase):
        def setUp(self):
            self.seed = Seed('test')
            self.rs = RussiaSpecProvider(self.seed)

        def test_generate_sentence(self):
            result = self.rs.generate_sentence()
            self.assertEqual(result, 'Все стучат по дверям надо идти.')

        def test_patronymic(self):
            result = self.rs.patronymic(gender=Gender.MALE)

# Generated at 2022-06-21 15:43:15.651222
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    obj = RussiaSpecProvider()
    # Test for russian characters
    char_test = obj.snils()
    assert char_test.isalpha() == False


# Generated at 2022-06-21 15:43:18.969879
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Unit test for method ogrn of class RussiaSpecProvider."""
    server = RussiaSpecProvider()
    ogrn = server.ogrn()
    assert isinstance(ogrn, str)



# Generated at 2022-06-21 15:43:26.059338
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Unit test for method inn of class RussiaSpecProvider.

    Args:
        inn_regular_expression: A compiled regular expression pattern.

    Returns:
        None

    Example:
        test_inn_regular_expression = re.compile(r'[0-9]{10}')
        test_RussiaSpecProvider_inn(test_inn_regular_expression)
    """
    ru_provider = RussiaSpecProvider()
    for _ in range(0, 3):
        value = ru_provider.inn()
        assert re.match(inn_regular_expression, value) is not None
        print('Value of inn:', value)


# Generated at 2022-06-21 15:43:28.820781
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """Unit test for method kpp of class RussiaSpecProvider."""
    r = RussiaSpecProvider()

    # Test 1
    # r.random = random.Random(1234)
    kpp = r.kpp()
    assert '560058652' == kpp, print(kpp)

# Generated at 2022-06-21 15:43:36.123096
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():

    # test result of method series_and_number for all possible values of year parameter
    for year in range(1910, 2010):
        series_and_number = RussiaSpecProvider().series_and_number(year)
        series = series_and_number.split(" ")[0]
        series_year = int(series.split(" ")[1])
        print("For year = " + str(year) + " series year = " + str(series_year) + " - " + ("OK" if series_year == year % 10 else "FAIL"))


# Generated at 2022-06-21 15:43:40.053203
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    russian = RussiaSpecProvider()
    result = russian.ogrn()
    assert len(result) == 13
    assert result > '0000000000000'
    assert result < '99999999999999'

# Generated at 2022-06-21 15:43:41.826824
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider().snils() == '41917492600'


# Generated at 2022-06-21 15:43:53.365550
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    """Test bic method of class RussiaSpecProvider."""

    provider = RussiaSpecProvider()
    bic = provider.bic()
    assert isinstance(bic, str)
    assert len(bic) == 9
    assert bic[0:2] == '04'

    # BIC number is longer than 9 digits
    bic_number = provider.bic()
    assert len(bic_number) == 9



# Generated at 2022-06-21 15:43:55.246449
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """Unit test for method kpp of class RussiaSpecProvider."""
    kpp = RussiaSpecProvider().kpp()
    assert len(kpp) == 9
    assert int(kpp) > 0



# Generated at 2022-06-21 15:43:59.113827
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    """Check initializing of RussiaSpecProvider."""
    s = RussiaSpecProvider()
    assert isinstance(s, RussiaSpecProvider)
    assert s is not None
    assert s.seed is not None
