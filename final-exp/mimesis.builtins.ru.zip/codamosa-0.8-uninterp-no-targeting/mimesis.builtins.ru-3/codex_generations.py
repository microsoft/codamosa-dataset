

# Generated at 2022-06-21 15:35:17.321443
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    assert RussiaSpecProvider().patronymic(Gender.MALE) in [
        "Александрович",
        "Артемович",
        "Антонович",
        "Андреевич",
        "Владимирович",
    ]

# Generated at 2022-06-21 15:35:19.079235
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    provider = RussiaSpecProvider()

    assert provider.ogrn() == '4715121463266'


# Generated at 2022-06-21 15:35:20.698907
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    rsp = RussiaSpecProvider()
    assert len(rsp.ogrn()) == 13


# Generated at 2022-06-21 15:35:27.154778
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    test_ogrn_russian = True
    russian_ogrn = RussiaSpecProvider().ogrn
    if len(russian_ogrn) != 13 or not russian_ogrn.isnumeric() or not russian_ogrn[:12].isnumeric() or not russian_ogrn[12].isnumeric() or not int(russian_ogrn[:12]) % 11 % 10 == int(russian_ogrn[12]):
        test_ogrn_russian = False
    assert test_ogrn_russian


# Generated at 2022-06-21 15:35:30.100952
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    rup = RussiaSpecProvider()
    print(rup.inn())


# Generated at 2022-06-21 15:35:33.257010
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    r = RussiaSpecProvider()
    result = r.kpp()
    result2 = r.kpp()
    assert len(result) == 9
    assert result != result2


# Generated at 2022-06-21 15:35:34.980356
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """Unit test of RussiaSpecProvider.kpp"""
    provider = RussiaSpecProvider()
    print(provider.kpp())

# Generated at 2022-06-21 15:35:36.023976
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    pass


# Generated at 2022-06-21 15:35:37.537142
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    provider = RussiaSpecProvider('test_provider')
    inn = provider.inn()
    assert len(inn) == 12

# Generated at 2022-06-21 15:35:39.158775
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    provider = RussiaSpecProvider()
    assert len(provider.ogrn()) == 13

# Generated at 2022-06-21 15:35:58.134824
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    r = RussiaSpecProvider()
    res = r.passport_number()
    assert isinstance(res, int)
    assert 100000 >= res <= 999999


# Generated at 2022-06-21 15:36:04.847487
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """Test for method passport_number of class RussiaSpecProvider."""
    print(RussiaSpecProvider().passport_number())
    if len(str(RussiaSpecProvider().passport_number())) == 6:
        print("Test for method passport_number of class RussiaSpecProvider - OK")
    else:
        print("Test for method passport_number of class RussiaSpecProvider - NO")


# Generated at 2022-06-21 15:36:07.768024
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    from mimesis.providers.russia import RussiaSpecProvider
    russian_provider = RussiaSpecProvider()
    inn = russian_provider.inn()
    print(inn)


# Generated at 2022-06-21 15:36:16.285144
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    provider = RussiaSpecProvider(seed=1337)
    assert provider.patronymic(Gender.MALE) == 'Алексеевна'
    assert provider.patronymic(Gender.FEMALE) == 'Юрьевна'
    assert provider.patronymic(Gender.MALE) == 'Алексеевна'
    assert provider.patronymic(Gender.FEMALE) == 'Юрьевна'


# Generated at 2022-06-21 15:36:25.816614
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    from mimesis.enums import Gender
    a = RussiaSpecProvider()
    assert a.patronymic(gender=Gender.FEMALE) in ['Алексеевна', 'Дмитриевна', 'Александровна', 'Андреевна', 'Альбина']
    assert a.patronymic(gender=Gender.MALE) in ['Алексеевич', 'Дмитриевич', 'Александрович', 'Андреевич', 'Альбинович']


# Generated at 2022-06-21 15:36:38.357786
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    rsp = RussiaSpecProvider(seed=None)
    kpp = rsp.kpp()
    assert type(kpp) == str
    assert len(kpp) == 9

# Generated at 2022-06-21 15:36:40.005160
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    provider = RussiaSpecProvider()
    result = provider.series_and_number()
    assert len(result) == 10

# Generated at 2022-06-21 15:36:42.796502
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    rsp = RussiaSpecProvider()

    for i in range(0, 1000):
        assert rsp.patronymic(Gender.MALE) != rsp.patronymic(Gender.FEMALE)



# Generated at 2022-06-21 15:36:53.937166
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    P = RussiaSpecProvider()
    print()

    # Unit test for generate_sentence method
    assert P.generate_sentence()
    print('generate_sentence:', P.generate_sentence())

    # Unit test for patronymic method
    assert P.patronymic(gender=Gender.MALE)
    print('patronymic:', P.patronymic(gender=Gender.MALE))

    # Unit test for passport_series method
    assert P.passport_series()
    print('passport series:', P.passport_series())
    print('passport series:', P.passport_series(year=2015))

    # Unit test for passport_number method
    assert P.passport_number()
    print('passport number:', P.passport_number())

    # Unit

# Generated at 2022-06-21 15:36:56.444923
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    r = RussiaSpecProvider()
    r.inn()


# Generated at 2022-06-21 15:37:34.954036
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Test method inn of class RussiaSpecProvider."""

    rsp = RussiaSpecProvider()

    assert len(rsp.inn()) == 10

    pass


# Generated at 2022-06-21 15:37:37.230988
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    from mimesis.specifiers import RussiaSpecProvider
    rus = RussiaSpecProvider()
    print(rus.series_and_number())


# Generated at 2022-06-21 15:37:41.727388
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    # Init RussiaSpecProvider
    provider = RussiaSpecProvider()
    # Get passport number
    passport_number = provider.passport_number()
    # Check if passport number is integer and length = 6
    assert isinstance(passport_number, int)
    assert len(str(passport_number)) == 6


# Generated at 2022-06-21 15:37:44.546529
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Test for method ``passport_series``."""
    r = RussiaSpecProvider()
    series = r.passport_series()
    assert len(series) == 5
    assert series.count(' ') == 1


# Generated at 2022-06-21 15:37:52.261182
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    """Unit test for constructor of class RussiaSpecProvider."""
    rus = RussiaSpecProvider(seed='hgf')
    print(rus.generate_sentence())
    print(rus.patronymic())
    print(rus.passport_series())
    print(rus.passport_number())
    print(rus.series_and_number())
    print(rus.snils())
    print(rus.inn())
    print(rus.ogrn())
    print(rus.bic())
    print(rus.kpp())

# Generated at 2022-06-21 15:38:02.534643
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Function test_RussiaSpecProvider_series_and_number."""
    from mimesis.builtins.base import BaseSpecProvider
    from mimesis.enums import Gender
    from mimesis.providers.russia import RussiaSpecProvider

    russia_provider = RussiaSpecProvider()

    assert isinstance(russia_provider, BaseSpecProvider)
    assert isinstance(russia_provider, RussiaSpecProvider)
    assert isinstance(russia_provider.gender(), Gender)
    assert isinstance(russia_provider.series_and_number(), str)

    assert russia_provider.series_and_number() == russia_provider.series_and_number()
    assert russia_provider.series_and_number() != russia_provider.series_and_number()

# Unit test

# Generated at 2022-06-21 15:38:04.680392
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    print("---Testing series_and_number---")
    test_provider = RussiaSpecProvider()
    print(test_provider.series_and_number())

# Generated at 2022-06-21 15:38:06.518205
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    actual = RussiaSpecProvider.bic()
    assert len(actual) == 9


# Generated at 2022-06-21 15:38:08.543236
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    provider = RussiaSpecProvider()
    assert provider.patronymic() != provider.patronymic(gender=Gender.FEMALE)


# Generated at 2022-06-21 15:38:10.461850
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    for i in range(0, 1000):
        assert len(RussiaSpecProvider().passport_number()) == 6


# Generated at 2022-06-21 15:39:38.469258
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    # call the function and check if kpp matches the regular expression
    assert not RussiaSpecProvider.kpp().__contains__("-")
    # call the function and check if kpp matches the regular expression
    assert not RussiaSpecProvider.kpp().__contains__(" ")
    # call the function and check whether the number of characters is equal to 9
    assert len(RussiaSpecProvider.kpp()) == 9
    # test if the kpp returned is not None
    assert RussiaSpecProvider.kpp() is not None



# Generated at 2022-06-21 15:39:39.810297
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    RussiaSpecProvider()

# Unit test of generate_sentence()

# Generated at 2022-06-21 15:39:40.447349
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    pass

# Generated at 2022-06-21 15:39:43.188919
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    russia = RussiaSpecProvider()
    assert len(russia.series_and_number()) == 11
    assert type(russia.series_and_number()) is str


# Generated at 2022-06-21 15:39:46.513489
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    # Code copied from mimesis
    r = RussiaSpecProvider()
    s = r.passport_number()
    assert type(s) is int
    assert len(str(s)) == 6

# Generated at 2022-06-21 15:39:47.468013
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    """Test RussiaSpecProvider"""
    RussiaSpecProvider()

# Generated at 2022-06-21 15:39:50.250482
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Unit test for method ogrn of class RussiaSpecProvider"""
    rsp = RussiaSpecProvider()
    ogrn = rsp.ogrn()
    assert len(ogrn) == 13

# Generated at 2022-06-21 15:39:59.868101
# Unit test for method inn of class RussiaSpecProvider

# Generated at 2022-06-21 15:40:01.925952
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    provider = RussiaSpecProvider(seed=4)
    series = provider.passport_series()
    assert series == '60 17'

# Generated at 2022-06-21 15:40:06.245280
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    r = RussiaSpecProvider()  # create an object of class RussiaSpecProvider
    ogrn = r.ogrn()  # generate a random ogrn
    assert type(ogrn) == str  # the ogrn is a string
    assert len(ogrn) == 13  # the ogrn is 13 digits long

"""
Unit test for method bic of class RussiaSpecProvider
"""