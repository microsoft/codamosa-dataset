

# Generated at 2022-06-21 15:35:10.527894
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Testing passport_series method of class RussiaSpecProvider"""
    provider = RussiaSpecProvider()
    result = provider.passport_series()
    assert len(result) == 5
    assert result[2] == " "


# Generated at 2022-06-21 15:35:12.903664
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Unit test for method series_and_number."""
    rsp = RussiaSpecProvider()
    assert len(rsp.series_and_number()) == 10

# Generated at 2022-06-21 15:35:21.960062
# Unit test for method patronymic of class RussiaSpecProvider

# Generated at 2022-06-21 15:35:29.998199
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    test_RussiaSpecProvider = RussiaSpecProvider(seed=0)
    for x in range (1, 10):
        test = test_RussiaSpecProvider.series_and_number()
        expected = '0213' + str(x) + str(0) + str(0) + str(0) + str(1) + str(x)
        if test == expected:
            print ("Test passed: test_RussiaSpecProvider_series_and_number")
        else:
            print ("Test failed: test_RussiaSpecProvider_series_and_number")


# Generated at 2022-06-21 15:35:37.461852
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    from mimesis.providers.russia_provider import RussiaSpecProvider
    s = RussiaSpecProvider()
    result = s.series_and_number()
    count = 0
    random_series_and_number= []
    for i in range (0,1000):
        random_series_and_number.append(s.series_and_number())
    for i in range (0, 999):
        if result == random_series_and_number[i]:
            count += 1
    if count > 10:
        raise AssertionError("The random number is not random")
        

# Generated at 2022-06-21 15:35:47.115804
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    from mimesis.enums import Gender
    provider = RussiaSpecProvider()
    assert provider.patronymic(Gender.FEMALE) in provider._data['patronymic'][Gender.FEMALE]
    assert provider.patronymic(Gender.MALE) in provider._data['patronymic'][Gender.MALE]
    assert provider.patronymic(Gender.UNKNOWN) in provider._data['patronymic'][Gender.UNKNOWN]
    assert provider.patronymic(Gender.UNDEFINED) in provider._data['patronymic'][Gender.UNDEFINED]
    assert provider.patronymic(Gender.NON_BINARY) in provider._data['patronymic'][Gender.NON_BINARY]


# Generated at 2022-06-21 15:35:49.468761
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    # check type of result
    assert type(RussiaSpecProvider().inn()) == str

    # check length of result
    assert len(RussiaSpecProvider().inn()) == 12


# Generated at 2022-06-21 15:35:52.742794
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    from mimesis.builtins.russia import RussiaSpecProvider
    provider = RussiaSpecProvider()
    result = provider.series_and_number()
    assert len(result) == 11
    assert provider.series_and_number() == '57 16 805199'


# Generated at 2022-06-21 15:35:53.653510
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    """Test """


# Generated at 2022-06-21 15:36:00.767363
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    # Importing required modules
    from mimesis.enums import Gender
    from mimesis.providers.base import BaseSpecProvider
    from mimesis.providers.person.enums import NameFormats
    from mimesis.providers.person.enums import RelationshipStatus
    from mimesis.providers.person.enums import UsMilitaryStatus
    from mimesis.providers.person.enums import UsState
    from mimesis.providers.person.enums import UsaTitle
    # Declaring required constants
    data_path = 'mimesis.providers.person.en_.data'

    class Usa(BaseSpecProvider):
        """Class that provides data for Russia (ru)."""

        class Meta:
            """The name of the provider."""

            name = 'usa_en'

        # Instance

# Generated at 2022-06-21 15:36:23.884966
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test for method 'snils' of class 'RussiaSpecProvider'."""
    test_data = [
        ('225-729-480 52', True,),
        ('225 729 480 52', True,),
        ('225-729-4805 2', False,),
        ('225-729-480 52 ', False,),
        ('123-123-123 12', True,),
        ('123-123-1231 2', True,),
        ('123-123-1231 7', False,),
        ('123-123-123 1', False,),
        ('123-123-123 12 ', False,),
        ('223-729-480 50', True,),
        ('223 729 480 50', True,),
        ('223-729-4805 0', False,),
        ('223-729-480 50 ', False,),
    ]


# Generated at 2022-06-21 15:36:26.899685
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rus = RussiaSpecProvider()
    snils = rus.snils()
    if ' ' in snils:
        print('Test failed')
    else:
        print(snils)
        print('Test passed')

test_RussiaSpecProvider_snils()


# Generated at 2022-06-21 15:36:29.721014
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """Unit test for method kpp of class RussiaSpecProvider."""
    assert RussiaSpecProvider().kpp() in str(list(range(1, 99)) + list(range(100, 999)))

# Generated at 2022-06-21 15:36:40.917045
# Unit test for method inn of class RussiaSpecProvider

# Generated at 2022-06-21 15:36:42.383069
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    ru = RussiaSpecProvider()
    r = ru.kpp()
    assert len(r) == 9


# Generated at 2022-06-21 15:36:48.433925
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    """Test method bic of class RussiaSpecProvider"""
    provider = RussiaSpecProvider()
    # import ipdb; ipdb.set_trace()
    assert provider.bic() == '440010599'
    assert len(provider.bic()) == 9
    assert type(provider.bic()) == str


# Generated at 2022-06-21 15:36:56.611288
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test RussiaSpecProvider.snils() method."""

    rsp = RussiaSpecProvider()
    # Check control codes in the end of snils numbers

# Generated at 2022-06-21 15:36:58.857863
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    """Test method bic of class RussiaSpecProvider"""
    provider = RussiaSpecProvider(seed=42)
    assert provider.bic() == '044025575'


# Generated at 2022-06-21 15:37:04.041238
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russian = RussiaSpecProvider()
    snils_1 = '41917492600'
    snils_2 = '41917492600'
    snils_3 = '41917492600'
    assert snils_1 == snils_2 == snils_3
    #assert russian.snils() == '41917492600'


# Generated at 2022-06-21 15:37:06.947043
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    obj = RussiaSpecProvider()
    assert len(obj.passport_series()) == 5


# Generated at 2022-06-21 15:37:45.044193
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    russiaspecs = RussiaSpecProvider()
    print("Test generate_sentence: " + russiaspecs.generate_sentence())
# Test results:
# Test generate_sentence: В совместных усилиях Краснодара и Пскова наше предприятие является единственным представителем и импортером нефтепродуктов Китая.


# Generated at 2022-06-21 15:37:57.045278
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Unit test for method passport_series of class RussiaSpecProvider."""
    r = RussiaSpecProvider(seed=42)

    # Check return type
    assert isinstance(r.passport_series(), str)

    # Check length
    assert len(r.passport_series()) == 5

    # Check year
    years = [r.passport_series(year) for _ in range(0, 10000)]
    assert all([year[2:] == '16' for year in years])

    # Check with random year
    years = [r.passport_series(year) for _ in range(0, 10000)]
    assert all([year[2:] in ['10', '11', '12', '13', '14', '15', '16',
                             '17', '18'] for year in years])


# Generated at 2022-06-21 15:37:59.079889
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    rsp = RussiaSpecProvider()
    assert len(str(rsp.passport_number())) == 6


# Generated at 2022-06-21 15:38:07.538341
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """
    Данный тест для проверки корректности работы метода
    series_and_number класса RussiaSpecProvider
    """
    format_regex = "[0-9]{4} [0-9]{2} [0-9]{6}"
    errors = 0
    for _ in range(0, 100):
        series_and_number = RussiaSpecProvider().series_and_number()
        if re.match(format_regex, series_and_number) is None:
            errors += 1
    assert errors == 0



# Generated at 2022-06-21 15:38:15.318484
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """
    Проверка исключений, которые могут выбросить метод inn класса RussiaSpecProvider
    """
    provider = RussiaSpecProvider()
    try:
        provider.inn(10)
        assert False
    except:
        assert True

    try:
        provider.inn('sdfsdfsdfs')
        assert False
    except:
        assert True

    try:
        provider.inn(1, 2)
        assert False
    except:
        assert True

    try:
        provider.inn(1, 2, 3)
        assert False
    except:
        assert True


# Generated at 2022-06-21 15:38:18.725226
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    seed = 'R-D-W'
    rus = RussiaSpecProvider(seed)
    actual = rus.snils()
    expected = '41917492600'
    assert actual == expected, "Test snils() of class RussiaSpecProvider failed"

# Generated at 2022-06-21 15:38:20.598400
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    test_provider = RussiaSpecProvider()
    assert len(str(test_provider.passport_number())) == 6



# Generated at 2022-06-21 15:38:23.344488
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    """Unit test for constructor of class RussiaSpecProvider."""
    assert RussiaSpecProvider().locale == 'ru'

# Generated at 2022-06-21 15:38:25.660908
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()
    numbers = set()
    for i in range(100):
        numbers.add(rsp.snils())
    assert len(numbers) == 100


# Generated at 2022-06-21 15:38:33.834716
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Test method inn of class RussiaSpecProvider."""
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.address import Address

    provider = RussiaSpecProvider()
    inn_list = []

    for i in range(1, 1001):
        inn_list.append(provider.inn())

    assert provider.inn() in inn_list
    assert provider.inn() in inn_list
    assert provider.inn() in inn_list
    assert provider.inn() in inn_list
    assert provider.inn() in inn_list
    assert provider.inn() in inn_list
    assert provider.inn() in inn_list
    assert provider.inn() in inn_list
    assert provider.inn() in inn_list
    assert provider.inn() in inn_list


# Generated at 2022-06-21 15:39:38.016100
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    provider = RussiaSpecProvider()
    assert len(str(provider.passport_number())) == 6


# Generated at 2022-06-21 15:39:41.918601
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    # Unit test
    import re

    pattern = r'\d{12}'
    rp = RussiaSpecProvider(seed=123456)

    for i in range(10):
        inn = rp.inn()
        assert re.match(pattern, inn) is not None


# Generated at 2022-06-21 15:39:46.685739
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    obj = RussiaSpecProvider()
    assert (obj.generate_sentence().strip() == "Энергия на корабле Волне облаков велика.".strip())
test_RussiaSpecProvider_generate_sentence()

# Generated at 2022-06-21 15:39:50.553439
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    provider = RussiaSpecProvider()
    result = provider.generate_sentence()
    assert len(result.split()) == 4
    result2 = provider.generate_sentence()
    assert len(result2.split()) == 4
    assert result != result2


# Generated at 2022-06-21 15:39:56.291458
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    from nose.tools import eq_
    from re import findall
    from mimesis import RussiaSpecProvider

    r = RussiaSpecProvider()
    kpp = r.kpp()
    eq_(len(kpp), 9)
    regex = '[0-9]{4}[0-9]{2}[0-9]{3}'
    eq_(len(findall(regex, kpp)), 1)
    
    

# Generated at 2022-06-21 15:39:58.010979
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():

    instance = RussiaSpecProvider()
    assert instance



# Generated at 2022-06-21 15:40:03.808927
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    r = RussiaSpecProvider()
    # тариф Пример Примечания
    # Первые два диапазона 01–45 и 46–50
    # и последний 01–99 используются.
    assert r.passport_series(18) in ['01 18' , '99 18']
    # Для идентификации регионов используются первые два числа сер

# Generated at 2022-06-21 15:40:06.861106
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    provider = RussiaSpecProvider()
    assert provider.passport_series() in ['02 15', '01 07', '01 15', '01 08', '01 18', '01 11', '01 16', '01 12', '01 14', '01 17']


# Generated at 2022-06-21 15:40:10.177454
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    """Unit test method generate_sentence of class RussiaSpecProvider"""
    rus_test = RussiaSpecProvider()
    assert rus_test.generate_sentence()


# Generated at 2022-06-21 15:40:13.550862
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Test method inn of class RussiaSpecProvider"""
    provider = RussiaSpecProvider()
    result = provider.inn()
    assert len(result) == 12
    assert provider.inn() != provider.inn()


# Generated at 2022-06-21 15:43:10.402146
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    provider = RussiaSpecProvider()
    sentences = provider.generate_sentence()
    assert len(sentences.split(" ")) > 2


# Generated at 2022-06-21 15:43:12.082670
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    assert RussiaSpecProvider.passport_series(year=18) == '18'


# Generated at 2022-06-21 15:43:14.618827
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    rus = RussiaSpecProvider()
    assert rus.provider_name == 'RussiaSpecProvider'

# Generated at 2022-06-21 15:43:17.943528
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    provider = RussiaSpecProvider()
    result = provider.patronymic(Gender.FEMALE)
    assert not result == provider.patronymic(Gender.MALE)

# Generated at 2022-06-21 15:43:22.429996
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    # Initialize provider
    provider = RussiaSpecProvider()

    # Get the passport_number
    passport_number = provider.passport_number()

    # Test 1: Assert method passport_number return a string
    assert isinstance(passport_number, str), \
        "The type of return value of method passport_number of " \
        "class RussiaSpecProvider should be a string"

    # Test 2: Assert length of passport_number
    assert len(passport_number) == 6, \
        "The length of passport_number should be 6"

    # Test 3: Assert passport_number contains only digits
    assert passport_number.isdigit(), \
        "The value of passport_number should be a number"


# Generated at 2022-06-21 15:43:24.909985
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    provider = RussiaSpecProvider()

    # Run method inn()
    result = provider.inn()
    # Check result
    assert isinstance(result, str)
    assert len(result) == 12


# Generated at 2022-06-21 15:43:29.894259
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Test for in of class RussiaSpecProvider."""
    r = RussiaSpecProvider()
    for num in range(0, 100):
        inn = r.inn()
        control_nums = inn[-2:]
        control_sum = int(inn[:-2]) % 11 % 10
        assert control_nums[1] == str(control_sum)
        if control_sum == 10:
            control_sum = int(inn[:-2]) % 13 % 10
        assert control_nums[0] == str(control_sum)

# Generated at 2022-06-21 15:43:41.872511
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    from mimesis.enums import Gender
    from mimesis.providers.address import Address
    from mimesis.providers.date_time import DateTime
    from mimesis.providers.personal import Personal
    from mimesis.providers.text import Text
    from mimesis.enums import Gender
    from mimesis.typing import Seed
    dt = DateTime('ru')
    ru_address = Address('ru')
    ru_text = Text('ru', seed=dt.timestamp())
    ru_personal = Personal('ru', seed=dt.timestamp())
    ru_spec = RussiaSpecProvider(seed=dt.timestamp())
    ru_person = ru_personal.create_person(gender=Gender.MALE)
    ru_passport = ru_spec.passport_number()
    ru_

# Generated at 2022-06-21 15:43:44.364818
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    # Test __init__(self, seed=None)
    lang = RussiaSpecProvider()
    assert(lang != None)
    assert(type(lang) == RussiaSpecProvider)

# Generated at 2022-06-21 15:43:47.473053
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    provider = RussiaSpecProvider()
    series_and_number = provider.series_and_number()
    assert len(series_and_number) == 11
