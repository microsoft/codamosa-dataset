

# Generated at 2022-06-21 15:35:07.677319
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    from mimesis.providers.address import Address

    rs = RussiaSpecProvider()
    assert len(rs.generate_sentence()) > 10
    assert isinstance(rs.address, Address)

# Generated at 2022-06-21 15:35:10.796347
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11


# Generated at 2022-06-21 15:35:13.582698
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    rsp = RussiaSpecProvider()
    print('Generate sentence:')
    print(rsp.generate_sentence())
    print('\n')



# Generated at 2022-06-21 15:35:16.309402
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    provider = RussiaSpecProvider()
    result = provider.generate_sentence()
    print('Предложение:', result)


# Generated at 2022-06-21 15:35:18.920383
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()

    provider = RussiaSpecProvider()
    snils_ = provider.snils()

    assert snils != snils_

# Generated at 2022-06-21 15:35:24.812134
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    # Проверка контрольных сумм
    # Test control sums
    assert RussiaSpecProvider().generate_sentence() is not ''
    # Test without data
    assert RussiaSpecProvider(seed=True).generate_sentence() is not ''
    # Test for 100 times
    for i in range(0, 100):
        assert RussiaSpecProvider(seed=True).generate_sentence() is not ''


# Generated at 2022-06-21 15:35:31.612596
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    """Test that the method returns a valid patronymic."""
    assert RussiaSpecProvider().patronymic(Gender.MALE) in \
        RussiaSpecProvider().data['patronymic'][Gender.MALE]
    assert RussiaSpecProvider().patronymic(Gender.FEMALE) in \
        RussiaSpecProvider().data['patronymic'][Gender.FEMALE]


# Generated at 2022-06-21 15:35:34.709789
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    '''
    Tests the method passport_number of class RussiaSpecProvider
    '''
    provider = RussiaSpecProvider()

    assert len(str(provider.passport_number())) == 6


# Generated at 2022-06-21 15:35:36.313254
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    for gender in Gender:
        print(RussiaSpecProvider().patronymic(gender))


# Generated at 2022-06-21 15:35:40.361147
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender
    from mimesis.typing import Seed

    rus = RussiaSpecProvider()
    x = rus.patronymic(gender = Gender.MALE)

    assert(len(x) is 8)
    assert(x in rus._data['patronymic'][Gender.MALE])
    print(x)


# Generated at 2022-06-21 15:36:01.275309
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    test_provider = RussiaSpecProvider()
    country_name = test_provider.country.name()
    return country_name

# Generated at 2022-06-21 15:36:10.737880
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.person.ru import RussiaPersonProvider
    from mimesis.providers.ruspecs import RussiaSpecProvider
 
    rsp = RussiaSpecProvider()
    rpp = RussiaPersonProvider()
     
    snils = rsp.snils()
    full_name = rpp.full_name()
 
    # If a person is less than 18 years of age, his/her SNILS (Russian social security number)
    # is constructed from his/her parent’s SNILS and date of birth
    # i.e. <parent’s SNILS> <DD> <MM> <YY> <KK>
    # where KK is a two-digit check digit
    # <parent’s SNILS> <DD> <MM> <YY> <KK> = 41917492600 070912 43


# Generated at 2022-06-21 15:36:15.525857
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Unit test for method passport_series of class RussiaSpecProvider."""
    rus = RussiaSpecProvider()
    data = rus.passport_series()
    if data == '02 15':
        rus.passport_series(year=15)
        assert True
    else:
        assert False


# Generated at 2022-06-21 15:36:17.008028
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    r = RussiaSpecProvider()
    print(r.bic())


# Generated at 2022-06-21 15:36:19.261357
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()
    assert(rsp.snils() == '94444444444')


# Generated at 2022-06-21 15:36:24.982545
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    s = RussiaSpecProvider().snils()
    assert len(s) == 11
    assert s.isnumeric()
    #assert not s.startswith('0')
    #assert not s.startswith('12')
    assert s[:3] != '000'
    assert s[3:5] != '00'
    assert s[5:] != '000'
    assert s not in ['50001765027', '42029885637', '96600321289']

# Generated at 2022-06-21 15:36:29.328404
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    kpp = ()
    while True:
        kpp = RussiaSpecProvider().kpp()
        if kpp[0] == "7" and kpp[1] == "7":
            break
    assert len(kpp) == 9

# Generated at 2022-06-21 15:36:31.021624
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    assert len(RussiaSpecProvider().ogrn()) == 13


# Generated at 2022-06-21 15:36:34.994743
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    from mimesis.enums import Gender
    test = RussiaSpecProvider()
    result = test.patronymic(Gender.MALE)
    assert result in test._data['patronymic']['MALE']


# Generated at 2022-06-21 15:36:39.956746
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Test method inn of class RussiaSpecProvider."""
    inn = RussiaSpecProvider().inn()
    assert len(inn) == 10
    assert list(inn)[8] == str(int(inn[:-1]) % 11 % 10)
    assert list(inn)[9] == str(int(inn[:-2]) % 11 % 10)


# Generated at 2022-06-21 15:37:20.577618
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Unit test for method series_and_number of class RussiaSpecProvider"""
    russia = RussiaSpecProvider()
    series_and_number = russia.series_and_number()

    assert len(series_and_number) == 10, 'Value length should be 10.'
    assert type(series_and_number) is str, 'Type of value should be str.'
    assert series_and_number.isdigit(), 'Value should be digits'


# Generated at 2022-06-21 15:37:22.828143
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    random_data = RussiaSpecProvider()
    assert len(random_data.generate_sentence()) == 14


# Generated at 2022-06-21 15:37:24.345733
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    t1 = RussiaSpecProvider()
    print("INN: {}".format(t1.inn()))


# Generated at 2022-06-21 15:37:33.605330
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    rup = RussiaSpecProvider()
    rup.seed(145)
    inn1 = rup.inn()
    assert inn1 == '1289824828'
    assert len(inn1) == 10
    inn2 = rup.inn()
    assert inn2 == '9825371792'
    assert len(inn2) == 10
    rup.seed(145)
    inn1 = rup.inn()
    assert inn1 == '1289824828'
    assert len(inn1) == 10
    rup.reset_seed()
    inn1 = rup.inn()
    inn2 = rup.inn()
    assert inn1 != inn2


# Generated at 2022-06-21 15:37:35.453239
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    assert RussiaSpecProvider().passport_number() != RussiaSpecProvider().passport_number()


# Generated at 2022-06-21 15:37:36.957091
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    assert len(RussiaSpecProvider().ogrn()) == 13


# Generated at 2022-06-21 15:37:40.515941
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.builtins.russia import RussiaSpecProvider
    r = RussiaSpecProvider()

    i = r.snils()
    assert len(i) == 11
    assert i.isdigit()



# Generated at 2022-06-21 15:37:42.897019
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    kpp = RussiaSpecProvider.kpp()
    assert kpp is not None
    assert type(kpp) == str

# Generated at 2022-06-21 15:37:50.300565
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Unit test RussiaSpecProvider.inn method."""
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.address import Address
    from mimesis.providers.internet import Internet
    from mimesis.providers.business import Business
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.lorem import Lorem
    from mimesis.builtins.russia_provider import RussiaSpecProvider
    bp = BaseProvider(seed='123')
    address = Address(seed='123')
    internet = Internet(seed='123')
    business = Business(seed='123')
    numbers = Numbers(seed='123')
    lorem = Lorem(seed='123')
    rus = RussiaSpecProvider(seed='123')

# Generated at 2022-06-21 15:37:52.923769
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    from mimesis.builtins import RussiaSpecProvider
    provider=RussiaSpecProvider()
    print(provider.inn())
    

# Generated at 2022-06-21 15:39:17.005247
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    provider = RussiaSpecProvider()
    kpp = provider.kpp()
    assert len(kpp) == 9 and kpp.isdigit()

# Generated at 2022-06-21 15:39:20.594388
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    from mimesis.providers.russia import RussiaSpecProvider
    rsp = RussiaSpecProvider()
    ogrn = rsp.ogrn()
    assert len(ogrn) == 13
    assert type(ogrn) == str


# Generated at 2022-06-21 15:39:23.214366
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    RussiaSP = RussiaSpecProvider(seed=1234)
    assert RussiaSP.snils() == '51382458800'


# Generated at 2022-06-21 15:39:32.238524
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.enums import Gender
    from mimesis.providers.address import Address
    # Assert a valid SNILS as per http://www.consultant.ru/document/cons_doc_LAW_30050/
    snils_provider = RussiaSpecProvider()
    # INN
    inn = snils_provider.inn()
    # OGRN
    ogrn = snils_provider.ogrn()
    # BIC
    bic = snils_provider.bic()
    # KPP
    kpp = snils_provider.kpp()
    # Passport Series & Number
    passport_sn = snils_provider.series_and_number()

    # Get address provider
    address = Address('ru')

    print('INN: ' + inn)

# Generated at 2022-06-21 15:39:36.020067
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    rp = RussiaSpecProvider()
    rp.set_seed(0)

    assert rp.generate_sentence() == 'Возмутительно неумело раскрыть вектор требовательства.'


# Generated at 2022-06-21 15:39:37.410704
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    assert len(RussiaSpecProvider().kpp()) == 9

# Generated at 2022-06-21 15:39:47.325213
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    # GIVEN
    provider = RussiaSpecProvider()

    # WHEN
    inn = provider.inn()

    # THEN
    assert len(inn) == 10
    assert int(inn[0]) != 0

    # WHEN
    first_symbol = (int(inn[0]) * 2 + int(inn[1]) * 4 + int(inn[2]) * 10 +
                    int(inn[3]) * 3 + int(inn[4]) * 5 + int(inn[5]) * 9 +
                    int(inn[6]) * 4 + int(inn[7]) * 6 + int(inn[8]) * 8) % 11 % 10

# Generated at 2022-06-21 15:39:49.341520
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    rsp = RussiaSpecProvider()
    assert len(rsp.ogrn()) == 13


# Generated at 2022-06-21 15:39:53.496394
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    inn_list = []
    for i in range(10):
        inn_list.append(RussiaSpecProvider().inn())
        assert(len(inn_list[i]) == 12)
    print('test_RussiaSpecProvider_inn: Inn list -', inn_list)


# Generated at 2022-06-21 15:39:57.894529
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    provider = RussiaSpecProvider()
    result = provider.series_and_number()
    assert isinstance(result, str)
    assert len(result) == 11
    assert result[2:] != result [2]
    assert result[7:] != result [7]
    assert result[4: 6] == ' '


# Generated at 2022-06-21 15:43:27.990940
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    assert RussiaSpecProvider().inn() == '9905013477'


# Generated at 2022-06-21 15:43:39.497878
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender
    from mimesis.typing import Seed

    seed = Seed(1)
    r = RussiaSpecProvider(seed)
    expected = '4715113303725'
    actual = r.ogrn()
    assert expected == actual

    g = Gender(0)
    assert r.patronymic(g) == 'Анатольевна'

    expected = 'Пример предложения'
    actual = r.generate_sentence()
    assert expected == actual

    r2 = RussiaSpecProvider(seed)
    assert r2.ogrn() == '4715113303725'


# Test for method snils of class RussiaSpecProvider

# Generated at 2022-06-21 15:43:45.890257
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    rss = RussiaSpecProvider()
    assert rss.generate_sentence() == 'Статистика показывает, что в 2010 году ' \
                                      'была зарегистрирована рост продаж.'


# Generated at 2022-06-21 15:43:55.357556
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    rsp = RussiaSpecProvider()
    inn = rsp.inn()
    rinn = int(inn)
    inn_int = int(inn)
    inn_int_9 = inn_int % 1000000000
    p = rinn // 1000000000
    r = rinn % 10
    q = rinn // 100000000 % 10
    s = rinn // 10000000 % 10
    t = rinn // 1000000 % 10
    u = rinn // 100000 % 10
    v = rinn // 10000 % 10
    w = rinn // 1000 % 10
    x = rinn // 100 % 10
    y = rinn // 10 % 10
    z = rinn % 10
    inn_list = [p, q, r, s, t, u, v, w, x, y, z]
    assert isinstance(inn, str)


# Generated at 2022-06-21 15:43:59.946750
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """Unit test for method passport_number of class RussiaSpecProvider."""
    assert ''.join([str(num) for num in range(6)]) == '012345'
    assert len(''.join([str(num) for num in range(6)])) == 6


# Generated at 2022-06-21 15:44:02.570294
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    obj = RussiaSpecProvider(seed=1)
    assert obj.snils() == '41917492600'


# Generated at 2022-06-21 15:44:05.333914
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Unit test for method ogrn of class RussiaSpecProvider."""
    rus_prov = RussiaSpecProvider()
    assert rus_prov.ogrn()


# Generated at 2022-06-21 15:44:14.697256
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    sp = RussiaSpecProvider()

    control_sentence = 'Возьмите ребенка за руку в такси.'
    assert sp.generate_sentence() == control_sentence

    control_patronymic = 'Алексеевна'
    assert sp.patronymic() == control_patronymic

    control_patronymic = 'Алексеевна'
    assert sp.patronymic() == control_patronymic

    control_patronymic = 'Александровна'
    assert sp.patronymic(Gender.FEMALE) == control_patronymic

    control_patronym

# Generated at 2022-06-21 15:44:17.652338
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    """Unit tests for method generate_sentence of class RussiaSpecProvider."""
    spec = RussiaSpecProvider()
    sentence = spec.generate_sentence()
    assert isinstance(sentence, str)
    assert sentence  # Make sure it is not None


# Generated at 2022-06-21 15:44:25.561833
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    rsp = RussiaSpecProvider()
    passport_series = rsp.passport_series()
    assert len(passport_series) == 5
    assert passport_series[0] in ['0', '1']
    assert passport_series[1] in ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
    assert passport_series[2] == ' '
    assert passport_series[3] in ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
    assert passport_series[4] in ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']