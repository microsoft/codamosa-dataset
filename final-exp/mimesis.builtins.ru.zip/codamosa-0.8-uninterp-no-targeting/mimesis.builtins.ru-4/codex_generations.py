

# Generated at 2022-06-21 15:35:10.432037
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    rs = RussiaSpecProvider()
    print(rs.generate_sentence())


# Generated at 2022-06-21 15:35:16.051021
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    locale = RussiaSpecProvider(0)
    assert locale.generate_sentence() == 'Постановления международных региональных и общественных обществ'


# Generated at 2022-06-21 15:35:17.657055
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    obj = RussiaSpecProvider()
    assert len(obj.inn()) == 10



# Generated at 2022-06-21 15:35:19.208629
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    rsp  = RussiaSpecProvider()
    code = rsp.kpp()
    assert len(code) == 9

# Generated at 2022-06-21 15:35:21.460106
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    provider = RussiaSpecProvider()
    doc_number = provider.passport_series()
    doc_number_len = len(doc_number)
    assert doc_number_len == 5



# Generated at 2022-06-21 15:35:23.422027
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    p = RussiaSpecProvider()
    result = p.passport_number()
    assert p.passport_number() in range(100000,999999)

# Generated at 2022-06-21 15:35:25.749422
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    """Test RussiaSpecProvider_bic."""
    a = RussiaSpecProvider()
    b = a.bic()
    assert isinstance(b, str)


# Generated at 2022-06-21 15:35:31.906325
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    ru = RussiaSpecProvider()
    temp_snils_list = []
    for i in range(0, 100):
        ru_snils = ru.snils()

        control_codes = []

        for i in range(9, 0, -1):
            control_codes.append(int(ru_snils[9 - i]) * i)

        control_code = sum(control_codes)

        temp_snils_list.append(ru_snils)

        if control_code == 100:
            assert ru_snils[-2:] == '00'

        if control_code < 100:
            control_code = str(control_code)
            assert ru_snils[-2:] == control_code

        if control_code > 101:
            control_code = str(control_code % 101)

# Generated at 2022-06-21 15:35:38.243127
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    tmp = RussiaSpecProvider()
    test_inn = tmp.inn()
    all_inn = []
    all_inn.append(test_inn)
    for i in range(0, 10):
        all_inn.append(tmp.inn())
    # Unit test
    if len(all_inn) != len(set(all_inn)):
        print('Unit test for method inn of class RussiaSpecsProvider: failed')
    else:
        print('Unit test for method inn of class RussiaSpecsProvider: passed')


# Generated at 2022-06-21 15:35:41.316972
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    rsp = RussiaSpecProvider()
    passport_series = rsp.passport_series()
    print(passport_series)
    assert len(passport_series) == 5

# Generated at 2022-06-21 15:36:09.468462
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    from mimesis.providers.utils import count_values_from_list
    from mimesis.enums import Gender

    def test(male=True, female=True):

        spec = RussiaSpecProvider()
        spec.seed(1)
        male_counter = 0
        female_counter = 0
        for i in range(100):
            series_and_number = spec.series_and_number()
            region = series_and_number[0:2]
            year = series_and_number[2:4]
            numbers = int(series_and_number[4:10])
            assert 10000 <= numbers <= 999999
            assert 1 <= int(region) <= 99
            assert 10 <= int(year) <= 18
            gender = spec.gender(series_and_number)
            if gender == Gender.MALE:
                male

# Generated at 2022-06-21 15:36:14.670248
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis import RussiaSpecProvider
    a = RussiaSpecProvider()
    b = a.snils()
    control = 0
    for i in range(0, 9):
        control += int(b[i]) * (9 - i)
    if control % 101 == int(b[9:11]):
        return True
    else:
        return False

# Generated at 2022-06-21 15:36:16.131827
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    r = RussiaSpecProvider()
    assert len(r.bic()) == 9

# Generated at 2022-06-21 15:36:20.518887
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    provider = RussiaSpecProvider
    # check that right exception is raised when setting incorrect locale
    try:
        provider(locale='en')
    except ValueError:
        assert True
    # check that calling class constructor with correct locale setting
    # doesn't raise any exceptions
    provider(locale='ru')



# Generated at 2022-06-21 15:36:23.366994
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Unit test for RussiaSpecProvider_series_and_number."""
    rsp = RussiaSpecProvider()
    x = rsp.series_and_number()
    #print(x)
    assert len(x) == 12


# Generated at 2022-06-21 15:36:25.456205
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    provider = RussiaSpecProvider()
    actual_result = provider.inn()
    assert len(actual_result) == 10
    assert actual_result.isdigit()


# Generated at 2022-06-21 15:36:30.979553
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """
    Test for RussiaSpecProvider.series_and_number
    """
    provider = RussiaSpecProvider(seed=None)
    result = provider.series_and_number()
    assert isinstance(result, str)
    assert len(result) == 10
    assert result.isdigit()


# Generated at 2022-06-21 15:36:35.481620
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    provider = RussiaSpecProvider()
    assert provider.__class__.__name__ == 'RussiaSpecProvider'
    assert RussiaSpecProvider.Meta.name == 'russia_provider'
    assert provider._validate_enum("", Gender) == Gender.MALE


# Generated at 2022-06-21 15:36:37.984486
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    p = RussiaSpecProvider()
    result = p.generate_sentence()
    assert len(result.split(" ")) == 4


# Generated at 2022-06-21 15:36:39.668088
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    print(provider.snils())


test_RussiaSpecProvider_snils()

# Generated at 2022-06-21 15:37:18.323439
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Test for snils method with default parameter
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert all([snils[i] in '0123456789' for i in range(0, 11)])


# Generated at 2022-06-21 15:37:20.279963
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    for i in range(0, 100):
        if len(RussiaSpecProvider().bic()) != 15:
            return False
    return True



# Generated at 2022-06-21 15:37:26.546725
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    assert RussiaSpecProvider().patronymic() == RussiaSpecProvider(seed=1).patronymic(gender=Gender.FEMALE)
    assert RussiaSpecProvider(seed=2).patronymic() == RussiaSpecProvider(seed=2).patronymic(gender=Gender.FEMALE)
    assert RussiaSpecProvider(seed=3).patronymic() == RussiaSpecProvider(seed=3).patronymic(gender=Gender.FEMALE)


# Generated at 2022-06-21 15:37:30.424127
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    rus = RussiaSpecProvider()
    bic1 = rus.bic()
    bic2 = rus.bic()
    assert bic1 != bic2

if __name__ == '__main__':
    test_RussiaSpecProvider_bic()

# Generated at 2022-06-21 15:37:33.111031
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    provider = RussiaSpecProvider()
    for gender in Gender:
        assert isinstance(provider.patronymic(gender), str)

# Generated at 2022-06-21 15:37:35.739144
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider()
    bic = provider.bic()
    return bic.__class__.__name__ == 'str'


# Generated at 2022-06-21 15:37:45.416636
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    rus = RussiaSpecProvider()
    print(rus.generate_sentence())
    print(rus.patronymic())
    print(rus.patronymic(Gender.MALE))
    print(rus.patronymic(Gender.FEMALE))
    print(rus.patronymic(Gender.NON_BINARY))
    print(rus.passport_series())
    print(rus.passport_series(17))
    print(rus.passport_number())
    print(rus.series_and_number())
    print(rus.inn())
    print(rus.ogrn())
    print(rus.bic())
    print(rus.kpp())
    print(rus.snils())

# Generated at 2022-06-21 15:37:48.308054
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """Unit test for method kpp of class RussiaSpecProvider."""

    # test for method kpp
    rs = RussiaSpecProvider()
    assert len(rs.kpp()) == 9

# Generated at 2022-06-21 15:37:52.460088
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    LOCALE = 'en'  # 'en' or 'ru'
    provider = RussiaSpecProvider(LOCALE)
    series_and_number = provider.series_and_number()
    return series_and_number


# Generated at 2022-06-21 15:38:02.691612
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Test case for method series_and_number of class RussiaSpecProvider."""
#
    assert len(RussiaSpecProvider().series_and_number()) == 9
    assert str(len(RussiaSpecProvider().series_and_number(year=18))) == '9'
#
for _ in range(0, 100):
    assert RussiaSpecProvider().series_and_number() == '{}{}'.format(
        RussiaSpecProvider().passport_series(year=18),
        RussiaSpecProvider().passport_number(),
    )
#
for _ in range(0, 100):
    assert RussiaSpecProvider().series_and_number(year=18) == '{}{}'.format(
        RussiaSpecProvider().passport_series(year=18),
        RussiaSpecProvider().passport_number(),
    )
#

# Generated at 2022-06-21 15:39:23.997758
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    t = RussiaSpecProvider()
    sentences = t.generate_sentence()
    print(sentences)
    assert sentences is not None


# Generated at 2022-06-21 15:39:26.970190
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider()
    bic = provider.bic()
    bic_list = bic.split("")
    assert len(bic_list) == 9


# Generated at 2022-06-21 15:39:29.576318
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    ru = RussiaSpecProvider()
    ru.seed(1)
    result = ru.patronymic()
    assert result == 'Ивановна'


# Generated at 2022-06-21 15:39:31.708461
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    provider = RussiaSpecProvider()
    series = provider.passport_series()
    assert len(str(series)) == 5
    assert str(series)[2] == ' '


# Generated at 2022-06-21 15:39:34.316668
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    provider = RussiaSpecProvider()
    list_of_codes = [provider.kpp() for x in range(0, 10)]
    print(list_of_codes)
    assert len(list_of_codes) == 10



# Generated at 2022-06-21 15:39:38.536242
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    import pytest
    from mimesis.builtins.ru import RussiaSpecProvider as spec_provider
    from re import match
    
    provider = spec_provider()
    kpp = provider.kpp()
    assert match("\d{4}[0-9]{2}[0-9]{3}", kpp)

# Generated at 2022-06-21 15:39:41.377031
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    russia_spec_provider = RussiaSpecProvider()
    sentence = russia_spec_provider.generate_sentence()
    print('\n', sentence)
    assert sentence is not None


# Generated at 2022-06-21 15:39:45.920063
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    from mimesis.enums import Gender

    p = RussiaSpecProvider(seed=None)

    for i in range(0, 5):
        print(p.patronymic(gender=Gender.MALE))

    for i in range(0, 5):
        print(p.patronymic(gender=Gender.FEMALE))



# Generated at 2022-06-21 15:39:49.179698
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider()

    bic = provider.bic()
    assert len(bic) == 9
    for char in bic:
        assert char.isdigit()



# Generated at 2022-06-21 15:39:52.520197
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Unit test for method inn of class RussiaSpecProvider.

    :Unit test coverage:
        The test shows that argument inn of method inn is not None
    """
    test = RussiaSpecProvider()
    test.inn()