

# Generated at 2022-06-21 15:35:10.139921
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    ru = RussiaSpecProvider()
    sentence = ru.generate_sentence()
    assert isinstance(sentence, str)


# Generated at 2022-06-21 15:35:15.640496
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    r = RussiaSpecProvider()
    test = r.bic()
    assert len(test) == 9
    assert test[0] == '0'
    assert test[1] == '4'
    assert int(test[2]) in range(1, 10)
    assert int(test[3]) in range(0, 10)
    assert int(test[4:7]) in range(50, 999)


# Generated at 2022-06-21 15:35:18.516791
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    # Create a instance of the class RussiaSpecProvider
    spec_provider = RussiaSpecProvider()
    # Call method kpp and test if the length is 9
    assert len(spec_provider.kpp()) == 9


# Generated at 2022-06-21 15:35:20.488656
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    '''
    Unit test for method inn of class RussiaSpecProvider
    '''
    assert RussiaSpecProvider().inn() == '7726056693'

# Generated at 2022-06-21 15:35:22.820982
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    russiaprovider = RussiaSpecProvider()
    result = russiaprovider.patronymic(gender=Gender.MALE)
    assert isinstance(result, str)
    assert result != ''


# Generated at 2022-06-21 15:35:26.804017
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    a = RussiaSpecProvider(seed=None)
    assert a.generate_sentence() == "Это одно из лучших предложений"


# Generated at 2022-06-21 15:35:36.313201
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    def get_all_values(filename):
        file = open(filename)
        values = list(file)
        file.close()
        return values

    # create list of expected values
    expected_values = get_all_values('expected_kpp_values.txt')

    # create RussiaSpecProvider object
    rsp_obj = RussiaSpecProvider()

    # create list of actual values
    actual_values = []
    for _ in range(10000):
        actual_values.append(rsp_obj.kpp())

    # check if all values in actual_values are in list of expected values
    for value in actual_values:
        assert value in expected_values

# Generated at 2022-06-21 15:35:37.336008
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    tmp = RussiaSpecProvider()
    assert tmp is not None

# Generated at 2022-06-21 15:35:47.025666
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    from mimesis.builtins import RussiaSpecProvider
    import pytest
    from mimesis.enums import Gender

    data = [
        [RussiaSpecProvider(seed=i).bic() for i in range(0, 100)],
        [RussiaSpecProvider(seed=i).bic() for i in range(0, 100)],
        [RussiaSpecProvider(seed=i).bic() for i in range(0, 100)],
        [RussiaSpecProvider(seed=i).bic() for i in range(0, 100)],
    ]

# Generated at 2022-06-21 15:35:50.029522
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    provider = RussiaSpecProvider()
    with open('mimesis/datasets/default/data_ru.json') as f:
        from json import load
        content = load(f)

    assert provider._data == content

# Generated at 2022-06-21 15:36:11.760099
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    r = RussiaSpecProvider()
    for _ in range(0, 3):
        assert r.patronymic() != r.patronymic()


# Generated at 2022-06-21 15:36:14.517490
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    rus = RussiaSpecProvider()
    assert rus.passport_number() in range(100000, 999999)



# Generated at 2022-06-21 15:36:17.643443
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    for i in range(1):
        series_and_number = RussiaSpecProvider().series_and_number()
        print(series_and_number)

test_RussiaSpecProvider_series_and_number()

# Generated at 2022-06-21 15:36:26.760877
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    test = RussiaSpecProvider()
    test.seed(0)
    assert test.passport_number() == 560430
    assert test.passport_number() == 955778
    assert test.passport_number() == 642361
    assert test.passport_number() == 698575
    assert test.passport_number() == 642361
    assert test.passport_number() == 645011
    assert test.passport_number() == 868987
    assert test.passport_number() == 558103
    assert test.passport_number() == 633954
    assert test.passport_number() == 823480
    assert test.passport_number() == 855520
    assert test.passport_number() == 534990
    assert test.passport_number() == 955778

# Generated at 2022-06-21 15:36:35.973357
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    # Test 1
    rus_provider = RussiaSpecProvider(seed=123)
    result = '11 16 968866'
    assert rus_provider.series_and_number() == result

    # Test 2
    rus_provider = RussiaSpecProvider(seed=456)
    result = '79 10 102823'
    assert rus_provider.series_and_number() == result

    # Test 3
    rus_provider = RussiaSpecProvider(seed=789)
    result = '15 11 777530'
    assert rus_provider.series_and_number() == result

# Generated at 2022-06-21 15:36:40.390044
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Unit test for method passport_series of class RussiaSpecProvider."""
    p = RussiaSpecProvider()
    assert p.passport_series(year=10) == '80 10'
    assert p.passport_series(year=18) == '99 18'
    assert p.passport_series(year=19) == '47 19'

# Generated at 2022-06-21 15:36:43.698063
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    print("Test snils()")
    rsp = RussiaSpecProvider()

    snils = rsp.snils()
    print(snils)
    assert (len(snils) == 11)

    # Custom testing
    assert (rsp.snils() == '41917492600')


# Generated at 2022-06-21 15:36:48.259079
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    sp = RussiaSpecProvider()
    u_inn = sp.inn()
    assert len(u_inn) == 10
    for i in range(9):
        assert u_inn[i] != '0'



# Generated at 2022-06-21 15:36:51.376650
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    russia = RussiaSpecProvider()
    sentence = russia.generate_sentence()
    assert isinstance(sentence, str)

# Generated at 2022-06-21 15:36:55.241503
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    m = RussiaSpecProvider()
    for i in range(0,10):
        assert(len(m.patronymic()) == 10)

# Generated at 2022-06-21 15:37:34.149483
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    my_provider = RussiaSpecProvider()
    assert my_provider.ogrn() != my_provider.ogrn()

# Generated at 2022-06-21 15:37:44.587788
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    assert len(RussiaSpecProvider().kpp()) == 9

# Generated at 2022-06-21 15:37:56.283490
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    data = []
    russia = RussiaSpecProvider()
    for x in range(0, 100):
        data.append(russia.series_and_number())

# Generated at 2022-06-21 15:37:58.870141
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    ogrn = RussiaSpecProvider(seed=12345)
    result = ogrn.ogrn()
    assert result == '551655122814'

# Generated at 2022-06-21 15:38:00.175269
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    assert len(RussiaSpecProvider().generate_sentence()) > 10


# Generated at 2022-06-21 15:38:01.047971
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    r = RussiaSpecProvider()
    r.ogrn()

# Generated at 2022-06-21 15:38:04.396795
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    """Test for method patronymic of class RussiaSpecProvider."""
    rp = RussiaSpecProvider(seed=132)
    assert rp.patronymic(gender=Gender.FEMALE) == 'Алексеевна'


# Generated at 2022-06-21 15:38:09.049799
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    from mimesis.enums import BICCode
    from mimesis.providers.finance import Finance
    rsp = RussiaSpecProvider()
    bic = BICCode.random().value
    print(bic)
    #print(rsp.bic())
    f = Finance(seed=None)
    assert f.bic(bic) == rsp.bic()

# Generated at 2022-06-21 15:38:10.299880
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    rsp = RussiaSpecProvider()
    print(rsp.generate_sentence())

# Generated at 2022-06-21 15:38:15.317392
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    rsp = RussiaSpecProvider()
    result = rsp.generate_sentence()
    lst = result.split()
    assert len(lst) == 4
    assert lst[0].isupper()
    assert lst[3].endswith(('.', '!', '?'))
    assert lst[1].endswith(',')
    assert lst[2].endswith(',')
    assert lst[1][:-1].islower()
    assert lst[2][:-1].islower()


# Generated at 2022-06-21 15:39:45.375260
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    provider.validate_snils(snils)


# Generated at 2022-06-21 15:39:46.905845
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rp = RussiaSpecProvider()
    assert rp.snils()


# Generated at 2022-06-21 15:39:51.176678
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Unit test for method passport_series of class RussiaSpecProvider."""
    a = RussiaSpecProvider()
    b = a.passport_series()
    c = '\\b\d{2}\s\d{2}\b'
    res = re.match(c,b)
    assert res


# Generated at 2022-06-21 15:39:55.854716
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    rsp = RussiaSpecProvider()
    assert rsp.patronymic(Gender.MALE) in rsp._data['patronymic'][Gender.MALE]
    assert rsp.patronymic(Gender.FEMALE) in rsp._data['patronymic'][Gender.FEMALE]


# Generated at 2022-06-21 15:39:58.722558
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    russ = RussiaSpecProvider()
    res = russ.generate_sentence()
    result = len(res.split())
    assert result == 4
    assert res.startswith('А')


# Generated at 2022-06-21 15:40:01.074806
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    expected = ['Викторовна', 'Матвеевна', 'Никитична']
    assert RussiaSpecProvider.patronymic() in expected


# Generated at 2022-06-21 15:40:11.057381
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """Test for method `kpp`."""

    r = RussiaSpecProvider()
    k = r.kpp()
    assert len(k) == 9


# Generated at 2022-06-21 15:40:12.780562
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    provider = RussiaSpecProvider()
    provider.kpp()          # 560058652

# Generated at 2022-06-21 15:40:14.486101
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    rsp = RussiaSpecProvider()
    assert len(rsp.passport_series()) == 5


# Generated at 2022-06-21 15:40:16.782291
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    rsp = RussiaSpecProvider()
    kpp = rsp.kpp()
    print('\t', 'KPP:', kpp, end='\n\n')
