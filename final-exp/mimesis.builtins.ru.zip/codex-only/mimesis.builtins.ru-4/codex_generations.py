

# Generated at 2022-06-23 20:47:49.871636
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Check the function which generate random series of passport."""
    provider = RussiaSpecProvider()

    # Check that a series has length 5
    assert len(provider.passport_series()) == 5

    # Check that a series starts with '02' and has year
    series = provider.passport_series()
    assert series[0] == '0' and series[1] == '2'
    assert series[2] in ('1', '2') and series[3] == '0'



# Generated at 2022-06-23 20:47:51.138519
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    r = RussiaSpecProvider()
    assert len(r.bic()) == 9


# Generated at 2022-06-23 20:47:53.421127
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider()
    result = provider.bic()
    assert isinstance(result, str)
    assert len(result) == 9

# Generated at 2022-06-23 20:48:03.419424
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    provider = RussiaSpecProvider(seed=1234)
    for _ in range(10):
        patronymic = provider.patronymic(Gender.MALE)
        assert isinstance(patronymic, str)
        assert patronymic == 'Николаевна'
    for _ in range(10):
        patronymic = provider.patronymic(Gender.FEMALE)
        assert isinstance(patronymic, str)
        assert patronymic == 'Игнатьевна'
    for _ in range(10):
        patronymic = provider.patronymic(Gender.NEUTRAL)
        assert isinstance(patronymic, str)
        assert patronymic == 'Михайловна'
   

# Generated at 2022-06-23 20:48:06.246786
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    russian = RussiaSpecProvider()
    patronymic = russian.patronymic(Gender.FEMALE)
    print(patronymic)
    assert len(patronymic) > 0


# Generated at 2022-06-23 20:48:08.015472
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    provider = RussiaSpecProvider()
    assert isinstance(provider.ogrn(), str)


# Generated at 2022-06-23 20:48:12.534412
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    russia_spec = RussiaSpecProvider()
    assert russia_spec.patronymic() == russia_spec.patronymic(Gender.FEMALE)
    assert russia_spec.patronymic(Gender.MALE)
    assert russia_spec.patronymic(Gender.FEMALE)


# Generated at 2022-06-23 20:48:19.967540
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """Test kpp method."""
    r = RussiaSpecProvider()
    assert len(r.kpp()) == 9

# Generated at 2022-06-23 20:48:27.393956
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    # Creating object RussiaSpecProvider
    spec_provider = RussiaSpecProvider()
    # Getting passport series and number
    spec_provider.series_and_number()
    # Getting snils
    spec_provider.snils()
    # Getting inn
    spec_provider.inn()
    # Getting ogrn
    spec_provider.ogrn()
    # Getting bic
    spec_provider.bic()
    # Getting kpp
    spec_provider.kpp()

if __name__ == "__main__":
    test_RussiaSpecProvider()

# Generated at 2022-06-23 20:48:35.889954
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    # Testing for validation INN
    def check_inn(inn):
        digits = [int(x) for x in inn if x.isdigit()]
        if len(digits) != 10:
            return False
        n2 = sum(digits[i] * (7 if i > 0 else 1) for i in range(10)) % 11 % 10
        n1 = sum(digits[i] * (3 if i > 0 else 1) for i in range(10)) % 11 % 10
        return digits[9] == n2 and digits[10] == n1

    ru = RussiaSpecProvider()
    assertions = []
    for _ in range(100):
        assert check_inn(ru.inn())

    if len(assertions) > 0:
        print('Unit test for method inn of class RussiaSpecProvider failed')
        exit

# Generated at 2022-06-23 20:48:37.726639
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
	for i in range(1000):
		assert len(RussiaSpecProvider().patronymic()) > 0


# Generated at 2022-06-23 20:48:41.118682
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    from mimesis.enums import Gender
    import re
    provider = RussiaSpecProvider()
    for _ in range(100):
        inn = provider.inn()
        match = re.match('(\d){10}',inn)
        assert match is not None

# Generated at 2022-06-23 20:48:42.535442
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """Testing RussiaSpecProvider.passport_number """
    pass

# Generated at 2022-06-23 20:48:51.269836
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    assert RussiaSpecProvider().snils() in [
        '97246673800', '84712396500', '43655706800', '53412989800',
        '08449646300', '56632529600', '41155465700', '16171398500',
        '19378152300', '70789412400', '14096114600', '73513496600',
        '96511752900', '01756608300', '44444444400', '22222222200',
        '03339993900', '11111111100', '22339898900', '03377777800',
        '86666666700', '55555555500'
    ]

# Generated at 2022-06-23 20:48:54.061597
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    r = RussiaSpecProvider()
    for i in range(0,10):
        inn = ''.join(str(x) for x in r.inn())
    assert r.inn() == inn


# Generated at 2022-06-23 20:48:59.440306
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    from mimesis.enums import Gender
    from mimesis.builtins import RussiaSpecProvider
    rus = RussiaSpecProvider()
    m = rus.patronymic(Gender.MALE)
    f = rus.patronymic(Gender.FEMALE)
    assert not m.startswith('а')
    assert f.startswith('а')


# Generated at 2022-06-23 20:49:00.722442
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    provider = RussiaSpecProvider()
    assert provider.inn() == '319522021128'


# Generated at 2022-06-23 20:49:02.685588
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    rp = RussiaSpecProvider()
    s = rp.generate_sentence()
    assert type(s) == str
    assert len(s.split(" ")) == 4



# Generated at 2022-06-23 20:49:04.499964
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    r = RussiaSpecProvider()
    assert len(r.series_and_number()) == 10

# Generated at 2022-06-23 20:49:08.961562
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    from mimesis.enums import Gender
    from mimesis.providers.russia import RussiaSpecProvider
    spec = RussiaSpecProvider(seed=1)
    assert spec.bic() == '044025575'


# Generated at 2022-06-23 20:49:12.725398
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    x = RussiaSpecProvider()
    a = 0
    with open("out.txt", "r") as f:
        for line in f:
            if x.bic() == line.strip():
                a += 1
    print(a)


# Generated at 2022-06-23 20:49:16.722468
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    rsp = RussiaSpecProvider()
    test_inn = rsp.inn()
    # Regular expression for the inn (The regular expression is taken from the web site www.hosted.reg.ru)
    pattern_inn = '^[1-9]\d{11}$'
    test_inn_is_match = test_inn.isalnum() and re.match(pattern_inn, test_inn)
    assert test_inn_is_match is True

# Generated at 2022-06-23 20:49:26.223997
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    from mimesis.enums import Gender
    from mimesis.providers import RussiaSpecProvider
    r = RussiaSpecProvider()
    for _ in range(10):
        assert r.ogrn() not in r.ogrn()
        assert r.inn() not in r.inn()
        assert r.patronymic(Gender.MALE) not in r.patronymic(Gender.MALE)
        assert r.patronymic(Gender.FEMALE) not in r.patronymic(Gender.FEMALE)

if __name__ == '__main__':
    test_RussiaSpecProvider()

# Generated at 2022-06-23 20:49:28.378070
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    rus = RussiaSpecProvider()
    res = rus.series_and_number()
    assert res == res
    print(res)

# Generated at 2022-06-23 20:49:30.196688
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Unit test for method inn of class RussiaSpecProvider"""
    rsp = RussiaSpecProvider()
    print(rsp.inn())


# Generated at 2022-06-23 20:49:32.490883
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    provider = RussiaSpecProvider()
    assert hasattr(provider, '__iter__')
    assert hasattr(provider, '__next__')

# Generated at 2022-06-23 20:49:34.071740
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    assert RussiaSpecProvider().passport_number() >= 100000 and RussiaSpecProvider().passport_number() <= 999999

# Generated at 2022-06-23 20:49:38.630311
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    series_and_number_actual = RussiaSpecProvider().series_and_number()
    assert len(series_and_number_actual) == 11, "Обнаружено нарушение длины"

# Generated at 2022-06-23 20:49:40.372688
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia = RussiaSpecProvider()
    snils = russia.snils()
    assert isinstance(snils, str)

# Generated at 2022-06-23 20:49:43.228258
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    provider = RussiaSpecProvider()
    assert len(provider.passport_series(provider.random.randint(10,18))) == 5
    assert provider.passport_series() is not None


# Generated at 2022-06-23 20:49:45.391399
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    r = RussiaSpecProvider()
    for _ in range(10):
        print(r.generate_sentence())


# Generated at 2022-06-23 20:49:48.799526
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    series_and_number = RussiaSpecProvider().series_and_number()
    assert (len(series_and_number) == 11) and series_and_number.isdigit()


# Generated at 2022-06-23 20:49:51.979894
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    test_obj = RussiaSpecProvider()
    assert len(test_obj.ogrn()) == 13
    assert test_obj.ogrn()[-1] != '0'


# Generated at 2022-06-23 20:50:02.762920
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider"""

    import re

    with open('tests/test_data_ru_PROVIDER/snils.txt', 'r', encoding='utf-8') as snils_file:
        with open('tests/test_results_ru_PROVIDER/method_snils_result.txt', 'w', encoding='utf-8') as resultfile:
            snils_list = snils_file.readlines()
            snils_list = [re.sub('\n', '', snils) for snils in snils_list]
            resultfile.truncate()

            result = []

            provider = RussiaSpecProvider(seed=1111)
            for _ in range(0, 100):
                result.append(provider.snils())

# Generated at 2022-06-23 20:50:12.396280
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    from mimesis.providers.locales.ru import data
    import re
    import random
    # KPP - Код причины постановки на учет
    test_Kpp_Regex = re.compile(r'[^0-9][0-9]{4}[^0-9]')
    provider = RussiaSpecProvider()
    for _ in range(1, 100):
        kpp = provider.kpp()
        test_kpp = test_Kpp_Regex.search(kpp)
        if test_kpp is None:
            print('test_kpp is None')
            assert test_kpp is not None
        else:
            print('test_kpp is not None')
            assert test

# Generated at 2022-06-23 20:50:14.294148
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    assert len(provider.snils()) == 11
    assert provider.snils() is not None


# Generated at 2022-06-23 20:50:22.406736
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
  for _ in range(100):
    male = RussiaSpecProvider().patronymic(Gender.MALE)
    female = RussiaSpecProvider().patronymic(Gender.FEMALE)

# Generated at 2022-06-23 20:50:28.249953
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.random import Random

    from mimesis.providers.person.ru import RussiaSpecProvider as RSP

    provider = RSP(seed=1234)
    assert provider.snils() == '41917492600'

    provider2 = RSP(Random)
    snils = provider2.snils()
    assert isinstance(snils, str)
    assert len(snils) == 11
    assert snils.isdigit()



# Generated at 2022-06-23 20:50:32.797611
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Unit test for method passport_series of class RussiaSpecProvider."""
    ru = RussiaSpecProvider()
    assert ru.passport_series(2011) == '02 11'
    assert ru.passport_series(2000) == '07 00'
    assert ru.passport_series(2020) == '46 20'


# Generated at 2022-06-23 20:50:33.868773
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    rsp = RussiaSpecProvider()
    result = rsp.bic()
    assert result == '044025575'

# Generated at 2022-06-23 20:50:36.963416
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    provider = RussiaSpecProvider()
    text = provider.inn()

    print(text)
    assert len(text) == 10
    assert text[0] != '0'



# Generated at 2022-06-23 20:50:41.865921
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """
    Тестируем метод snils класса RussiaSpecProvider
    """

    print("Test method snils of class RussiaSpecProvider")
    test_obj = RussiaSpecProvider()
    for test_num in range(0, 100):
        print(test_obj.snils())



# Generated at 2022-06-23 20:50:43.758612
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    assert RussiaSpecProvider().generate_sentence()

# Generated at 2022-06-23 20:50:50.919029
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    import json
    test_dict = {}
    for _ in range(1000):
        test_rsp = RussiaSpecProvider()
        test_str = repr(test_rsp.generate_sentence())
        if test_str in test_dict.keys():
            test_dict[test_str] = test_dict[test_str] + 1
        else:
            test_dict[test_str] = 1

    with open('test_RussiaSpecProvider_generate_sentence_result.json', 'w') as f:
        json.dump(test_dict, f)
# if __name__ == '__main__':
#     test_RussiaSpecProvider_generate_sentence()

# Generated at 2022-06-23 20:50:52.882027
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    assert RussiaSpecProvider().generate_sentence() == "Она очень хочет поехать по океану . "

# Generated at 2022-06-23 20:50:54.155248
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider()
    result = provider.bic()
    assert(len(result) == 9)


# Generated at 2022-06-23 20:50:56.849492
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    import re
    regex = re.compile(r'[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]')
    obj = RussiaSpecProvider()
    for _ in range(0, 100):
        assert re.match(regex, obj.kpp()) is not None

# Generated at 2022-06-23 20:50:59.669890
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    provider = RussiaSpecProvider()
    assert len(provider.passport_series()) == 5 and \
    provider.passport_series()[2] == "1"


# Generated at 2022-06-23 20:51:03.543445
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    """Test for example of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    # Test for 'bic'
    for i in range(10):
        provider.bic()
    # Test bic
    assert provider.bic() == '044025575'

# Generated at 2022-06-23 20:51:07.393689
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    r = RussiaSpecProvider()
    patronymic = r.patronymic()
    assert patronymic in r._data['patronymic'][Gender.MALE] or \
        patronymic in r._data['patronymic'][Gender.FEMALE]


# Generated at 2022-06-23 20:51:10.864681
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    from mimesis import RussiaSpecProvider

    rsp = RussiaSpecProvider()
    result = rsp.generate_sentence()
    assert isinstance(result, str)


# Generated at 2022-06-23 20:51:16.706369
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    r = RussiaSpecProvider()

    # 12 digits
    assert len(r.inn()) == 12

    # first digit should not be 0
    inn_first_digit = int(r.inn()[0])
    assert inn_first_digit > 0

    # inn should be in range
    inn = int(r.inn())
    assert inn <= 999999999999
    assert inn >= 1000000000



# Generated at 2022-06-23 20:51:18.808399
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    rsp = RussiaSpecProvider()
    result = rsp.bic()
    assert result == '044025576'
    # print(result)


# Generated at 2022-06-23 20:51:24.890254
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
   list_kpp = []
   for i in range (10):
       russia = RussiaSpecProvider()
       kpp = russia.kpp()
       if kpp in list_kpp:
           print('Such a KPP already exists')
       else:
           try:
              int(kpp)
           except ValueError:
              print ('Kpp is not a number')
           else:
              list_kpp.append(kpp)
              print ('KPP: ' + kpp)


# Generated at 2022-06-23 20:51:26.782366
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    provider = RussiaSpecProvider()
    assert provider.kpp() == '560058652'

# Generated at 2022-06-23 20:51:27.421329
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    pass

# Generated at 2022-06-23 20:51:29.240644
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    from mimesis.providers.russia import RussiaSpecProvider
    test_provider = RussiaSpecProvider()
    assert len(test_provider.inn()) == 10


# Generated at 2022-06-23 20:51:30.938134
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    for i in range(0,10):
        print(RussiaSpecProvider().generate_sentence())


# Generated at 2022-06-23 20:51:38.804540
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    """Test method bic of class RussiaSpecProvider.

    This test used the strategy of the method TaxCodeGenerator.
    Call method generate_tax_code_for_russia(2) and check if
    the result is equal to method RussiaSpecProvider.bic().
    """
    from mimesis.providers.finance import TaxCodeGenerator
    from mimesis.providers.finance import BIC
    
    rsp = RussiaSpecProvider()
    tcg = TaxCodeGenerator()
    bic_tcg = tcg.generate_tax_code_for_russia(2)
    bic_rsp = rsp.bic()

    if bic_tcg != bic_rsp:
        raise Exception
    else:
        pass

# Generated at 2022-06-23 20:51:47.534403
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    rsp = RussiaSpecProvider()
    patronymic = rsp.patronymic()
    assert type(patronymic) == str
    assert patronymic in rsp._data['patronymic'][Gender.FEMALE] or patronymic in rsp._data['patronymic'][Gender.MALE]
    assert rsp.patronymic(Gender.MALE) in rsp._data['patronymic'][Gender.MALE]
    assert rsp.patronymic(Gender.FEMALE) in rsp._data['patronymic'][Gender.FEMALE]


# Generated at 2022-06-23 20:51:50.044152
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    test_RussiaSpecProvider.obj = RussiaSpecProvider()
    assert test_RussiaSpecProvider.obj.provider == 'russia_provider'


# Generated at 2022-06-23 20:52:00.910799
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit tests for method snils of class RussiaSpecProvider."""
    from mimesis.providers.person.ru import RussiaSpecProvider
    rsp = RussiaSpecProvider()
    res1 = rsp.snils()
    assert isinstance(res1, str)
    assert len(res1) == 11
    res2 = rsp.snils()
    assert isinstance(res2, str)
    assert len(res2) == 11
    res3 = rsp.snils()
    assert isinstance(res3, str)
    assert len(res3) == 11
    res4 = rsp.snils()
    assert isinstance(res4, str)
    assert len(res4) == 11
    res5 = rsp.snils()
    assert isinstance(res5, str)
    assert len(res5)

# Generated at 2022-06-23 20:52:08.225887
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    from mimesis.providers.person import Person

    from mimesis.builtins.russia import Russia

    person = Person()
    rus = Russia()

    # import random
    # i = 0
    # while i < 100:
    #     full_name = person.full_name(gender=Gender.MALE)
    #     gender = person.gender()
    #     country = person.country()
    #     age = person.age(min_age=16, max_age=70)
    #     email = person.email()
    #     password = person.password()
    #     phone = person.phone_number()
    #     i += 1
    #     print("N = " + str(i) + " : " +
    #          

# Generated at 2022-06-23 20:52:09.817329
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    rus = RussiaSpecProvider()
    passport_number = rus.passport_number()
    assert len(str(passport_number)) == 6 # The length of Russian passport number is 6 digits


# Generated at 2022-06-23 20:52:11.676900
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    assert len(RussiaSpecProvider().inn()) == 10


# Generated at 2022-06-23 20:52:18.259976
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    import unittest
    import re
    from mimesis.builtins import RussiaSpecProvider
    
    russia_sp = RussiaSpecProvider()
    pattern = r'^\d{10}$'
    for _ in range(10):
        inn = russia_sp.inn()
        res = re.search(pattern, inn)
        assert res.group() == inn


# Generated at 2022-06-23 20:52:21.826903
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
	test_class = RussiaSpecProvider()
	# Test 1
	assert len(str(test_class.passport_number())) == 6
	# Test 2
	assert len(str(test_class.passport_number())) == 6


# Generated at 2022-06-23 20:52:25.065905
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.builtins.russia import RussiaSpecProvider
    provider = RussiaSpecProvider('ru')
    for _ in range(0,50):
        print(provider.snils())

# Generated at 2022-06-23 20:52:30.168186
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    correctNames = ['Алексеевна', 'Александровна', 'Александрович', 'Альбертовна'] # Correct names for unit test
    randomProvider = RussiaSpecProvider() # Create object of RussiaSpecProvider class

    names = []
    for i in range(0, 4):
        name = randomProvider.patronymic()
        names.append(name)
    assert names == correctNames

# Generated at 2022-06-23 20:52:38.352264
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    from mimesis.builtins.russian import RussiaSpecProvider
    from mimesis.schema import Field
    from mimesis.enums import Gender

    rsp = RussiaSpecProvider()

    for x in range(10):
        series_and_number = Field('russia_provider.series_and_number')

        if rsp.full_name(gender=Gender.MALE) is None:
            assert series_and_number() is None
        assert isinstance(series_and_number(), str)


# Generated at 2022-06-23 20:52:39.894379
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    r = RussiaSpecProvider()
    r.generate_sentence()

# Generated at 2022-06-23 20:52:52.061789
# Unit test for method patronymic of class RussiaSpecProvider

# Generated at 2022-06-23 20:52:55.015772
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Unit test for method RussiaSpecProvider.ogrn()."""
    rsp = RussiaSpecProvider()
    ogrn = rsp.ogrn()
    assert len(ogrn) == 13
    assert ogrn[-1].isdigit()


# Generated at 2022-06-23 20:53:06.369173
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Unit test for method passport_series of class RussiaSpecProvider."""
    # Create a object of class RussiaSpecProvider
    provider = RussiaSpecProvider()
    passport_series = provider.passport_series()
    # Check that the type of result is str
    assert isinstance(passport_series, str)
    # Check that length of result is equal 5
    assert len(passport_series) == 5
    # Check that the first symbol of result is digit
    assert passport_series.isdigit()
    # Create a object of class RussiaSpecProvider
    provider = RussiaSpecProvider()
    passport_series = provider.passport_series()
    # Check that the type of result is str
    assert isinstance(passport_series, str)
    # Check that length of result is equal 5
    assert len(passport_series) == 5
   

# Generated at 2022-06-23 20:53:10.341486
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    provider = RussiaSpecProvider()
    actual = provider.kpp()
    length = 8
    assert len(str(actual)) == length
    assert isinstance(actual, str)
    expected = 9
    assert actual[:expected] == '7700'

# Generated at 2022-06-23 20:53:14.954497
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Test for method series_and_number of class RussiaSpecProvider"""
    rsp = RussiaSpecProvider()
    first = rsp.series_and_number()
    second = rsp.series_and_number()
    assert first != second

# Generated at 2022-06-23 20:53:16.097137
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    import doctest
    doctest.testmod(RussiaSpecProvider.snils)

# Generated at 2022-06-23 20:53:20.771039
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    from mimesis.providers.russia import RussiaSpecProvider
    from re import compile
    result = str(RussiaSpecProvider().inn())
    pattern = compile('[0-9]{10}')
    match = pattern.fullmatch(result)
    assert match != None

# Generated at 2022-06-23 20:53:30.322152
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():

    from mimesis import RussianSpecProvider
    from mimesis.enums import Gender

    ru = RussianSpecProvider()
    print("Генерация случайных СНИЛС")
    for i in range(10):
        print("\t{}".format(ru.snils()))

    ru = RussianSpecProvider()
    print("Генерация случайных ИНН")
    for i in range(10):
        print("\t{}".format(ru.inn()))

    ru = RussianSpecProvider()

# Generated at 2022-06-23 20:53:35.874281
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    from mimesis import RussiaSpecProvider

    rsp = RussiaSpecProvider()
    assert len(rsp.kpp()) == 9
    assert rsp.kpp()[4:6] == '00' or rsp.kpp()[4:6] == '01' or rsp.kpp()[4:6] == '02' or rsp.kpp()[4:6] == '03' or rsp.kpp()[4:6] == '04' or rsp.kpp()[4:6] == '05' or rsp.kpp()[4:6] == '06' or rsp.kpp()[4:6] == '07' or rsp.kpp()[4:6] == '08' or rsp.kpp()[4:6] == '09' or rsp.kpp

# Generated at 2022-06-23 20:53:37.681035
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    assert RussiaSpecProvider().passport_number() != RussiaSpecProvider().passport_number()


# Generated at 2022-06-23 20:53:42.040053
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    r = RussiaSpecProvider()
    """
    for i in range(0, 1000):
        print (r.ogrn())
    """
    assert r.ogrn() == '47151133037252'
    assert len(r.ogrn()) == 13 # I changed this assert to make lenght of OGRN equel 13 becouse some results was with lenght 12


# Generated at 2022-06-23 20:53:45.382030
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """The function that checks the correctness of the generation of OGRN."""
    ogrn = RussiaSpecProvider(seed=100).ogrn()
    assert ogrn == '466539276563'

# Generated at 2022-06-23 20:53:52.212865
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    from mimesis.enums import Gender

    assert RussiaSpecProvider().bic() == '04852093145'
    assert RussiaSpecProvider().bic() == '04220202886'
    assert RussiaSpecProvider().bic() == '04970831432'
    assert RussiaSpecProvider().bic() == '04190831136'
    assert RussiaSpecProvider().bic() == '04150821467'



# Generated at 2022-06-23 20:53:54.590450
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    r = RussiaSpecProvider()
    print(r.bic())
    assert r.bic() == '044025575'



# Generated at 2022-06-23 20:53:56.834786
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    ru_provider = RussiaSpecProvider()
    assert ru_provider.series_and_number() != ru_provider.series_and_number()


# Generated at 2022-06-23 20:54:00.478559
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Unit testing for RussiaSpecProvider inn method """
    r_spec = RussiaSpecProvider()
    r_there_was_error = 0

    for i in range(10000):
        inn = r_spec.inn()
        if not check_inn(inn):
            r_there_was_error = 1
            print(inn)
            break

    assert r_there_was_error == 0



# Generated at 2022-06-23 20:54:03.465005
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    provider = RussiaSpecProvider()
    assert provider.generate_sentence() != ""
    assert provider.generate_sentence() == provider.generate_sentence()


# Generated at 2022-06-23 20:54:11.649332
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    r = RussiaSpecProvider()
    r.set_seed(4)
    for _ in range(10):
        assert r.passport_number() in range(100000, 999999)

    r.set_seed(31)
    assert r.passport_number() == 708962, "Test failed"

    r.set_seed(90)
    assert r.passport_number() == 733651, "Test failed"

    r.set_seed(4)
    assert r.passport_number() == 523410, "Test failed"



# Generated at 2022-06-23 20:54:21.616009
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    rus = RussiaSpecProvider(seed = 1234)
    assert rus.passport_number() == 564682
    assert rus.passport_series(year=14) == '72 14'
    assert rus.series_and_number() == '31 16 668649'
    assert rus.patronymic() == 'Александрович'
    assert rus.patronymic(gender=Gender.FEMALE) == 'Александровна'

# Generated at 2022-06-23 20:54:23.966076
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    # Test for ru
    ru_provider = RussiaSpecProvider('ru')
    result = ru_provider.series_and_number()
    assert len(result) == 11


# Generated at 2022-06-23 20:54:27.601688
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russiaspecprovider = RussiaSpecProvider()
    assert len(russiaspecprovider.snils()) == 11


# Generated at 2022-06-23 20:54:33.556669
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """Unit test for method kpp of class RussiaSpecProvider."""
    r1 = RussiaSpecProvider()
    r2 = RussiaSpecProvider()
    r3 = RussiaSpecProvider()
    r4 = RussiaSpecProvider()
    r5 = RussiaSpecProvider()
    assert len(r1.kpp()) == 9
    assert len(r2.kpp()) == 9
    assert len(r3.kpp()) == 9
    assert len(r4.kpp()) == 9
    assert len(r5.kpp()) == 9


# Generated at 2022-06-23 20:54:39.251549
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    ru = RussiaSpecProvider()
    assert ru.patronymic(Gender.MALE) in ru.list_from_file("patronymic_male")
    assert ru.patronymic(Gender.FEMALE) in ru.list_from_file("patronymic_female")
    assert ru.patronymic(Gender.OTHER) in ru.list_from_file("patronymic_other")


# Generated at 2022-06-23 20:54:50.258941
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    r1 = RussiaSpecProvider()
    r2 = RussiaSpecProvider()
    r3 = RussiaSpecProvider()
    r4 = RussiaSpecProvider()
    r5 = RussiaSpecProvider()
    r6 = RussiaSpecProvider()
    r7 = RussiaSpecProvider()
    r8 = RussiaSpecProvider()
    r9 = RussiaSpecProvider()
    r10 = RussiaSpecProvider()


# Generated at 2022-06-23 20:54:52.293023
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    """Unit test for constructor of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    assert provider



# Generated at 2022-06-23 20:55:01.261438
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider"""
    provider = RussiaSpecProvider()
    snils = provider.snils()  # returns 41917492600
    assert len(snils) == 11, "Длина СНИЛС должна быть 11 символов"
    assert snils[-2:] == '00', "Последние два цифры сгенерированного СНИЛС должны быть 00"

# Generated at 2022-06-23 20:55:05.440767
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    ru_spec_provider = RussiaSpecProvider(seed=0)
    sentence = ru_spec_provider.generate_sentence()
    assert sentence == 'Этот сайт довольно странно выглядит на моей старой принтере.'

# Generated at 2022-06-23 20:55:07.106115
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    obj = RussiaSpecProvider()
    assert obj.provider == 'russia_provider'

# Generated at 2022-06-23 20:55:11.855102
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    rsp = RussiaSpecProvider()
    a = True
    while a == True:
        if rsp.ogrn() == '4715113303725':
            a = False
            print('ogrn:', rsp.ogrn())
            print('Тест ogrn пройден')
        else:
            a = True
            print('Тест ogrn провален')


# Generated at 2022-06-23 20:55:13.497600
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    ru = RussiaSpecProvider()
    
    generated_inn = ru.inn()
    expected_inn = '5065010010'

    assert generated_inn == expected_inn

# Generated at 2022-06-23 20:55:22.343550
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    r = RussiaSpecProvider()

# Generated at 2022-06-23 20:55:26.473534
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    '''
    Check Unique code of KPP
    '''
    p = RussiaSpecProvider(seed=14)
    assert len(set(p.kpp() for _ in range(1,1000))) == 999

# Generated at 2022-06-23 20:55:28.066468
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    r = RussiaSpecProvider()
    assert len(r.ogrn()) == 13


# Generated at 2022-06-23 20:55:30.895577
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    provider = RussiaSpecProvider()
    assert len(provider.series_and_number()) == 11

# Generated at 2022-06-23 20:55:33.135492
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider(seed=0)
    bic = provider.bic()
    assert bic=="044025575"

# Generated at 2022-06-23 20:55:40.226396
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    r = RussiaSpecProvider()
    for i in range(0, 99):
        s = r.series_and_number()
        print(s[0:2], s[2:4], s[4:])
        assert int(s[0:2]) > 0
        assert int(s[0:2]) < 99
        assert int(s[2:4]) > 9
        assert int(s[2:4]) < 19
        assert int(s[4:]) > 99999
        assert int(s[4:]) < 999999
        assert s[4:] != ''
        assert int(s[4:]) > 100000
        assert int(s[4:]) < 999999
        assert len(s) == 10
        sn = int(s[4:])
        sr = s[0:4]

# Generated at 2022-06-23 20:55:41.680988
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    assert len(RussiaSpecProvider().generate_sentence()) >= 5


# Generated at 2022-06-23 20:55:45.650903
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    for x in range(1, 100):
        assert len(rsp.snils()) >= 11



# Generated at 2022-06-23 20:55:48.023296
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    ru_sp = RussiaSpecProvider()
    ru_sp.seed(1)
    ru_sp.generate(1)



# Generated at 2022-06-23 20:55:50.792642
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    rus = RussiaSpecProvider()
    print(rus.passport_number())
    assert len(str(rus.passport_number())) == 6


# Generated at 2022-06-23 20:55:52.638529
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    rsp = RussiaSpecProvider()
    assert len(rsp.bic()) == 9


# Generated at 2022-06-23 20:55:55.644545
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    rsp = RussiaSpecProvider()

    number = []
    for _ in range(0, 100):
        number.append(rsp.passport_number())
# ========================================================================


# Generated at 2022-06-23 20:56:00.133434
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    from mimesis.providers.business import Business

    test_data = Business().inn()
    assert len(test_data) == 10, 'It should be 10 charaters inn.'

    with open('data/kpp.txt') as file:
        kpp_data = file.read()

    assert test_data in kpp_data, 'There are no such inn in data file.'


# Generated at 2022-06-23 20:56:05.704932
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    for _ in range(100):
        kpp = RussiaSpecProvider().kpp()
        assert len(kpp) == 9
        assert kpp[:4].isdigit()
        assert kpp[4:6].isdigit()
        assert kpp[6:].isdigit()

# Generated at 2022-06-23 20:56:10.653972
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    r1 = RussiaSpecProvider()
    r2 = RussiaSpecProvider()
    bic1 = r1.bic()
    bic2 = r2.bic()

    assert bic1 != bic2
    assert isinstance(bic1, str)
    assert isinstance(bic2, str)
    assert len(bic1) == 9
    assert len(bic2) == 9


# Generated at 2022-06-23 20:56:19.743917
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.typing import Seed

    seed = Seed(2)
    rus = RussiaSpecProvider(seed)
    print('Sentence:', rus.generate_sentence())
    print('Patronymic:', rus.patronymic())
    print('Passport series:', rus.passport_series())
    print('Series and number:', rus.series_and_number())
    print('SNILS:', rus.snils())
    print('INN:', rus.inn())
    print('OGRN:', rus.ogrn())
    print('BIC:', rus.bic())
    print('KPP:', rus.kpp())

# Generated at 2022-06-23 20:56:27.101163
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    # we generate 10000 random numbers to check
    # the correct work of the method
    kpps = list()
    for _ in range(10000):
        kpps.append(RussiaSpecProvider().kpp())
    # KPP number is always 9 digits long
    kpps_len = [len(kpp) for kpp in kpps]
    assert all(len_ == 9 for len_ in kpps_len)
    # KPP always starts with 2 digits then 2 digits and last 3 digits
    kpp_pattern = re.compile("[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]")
    kpps_pattern = [kpp_pattern.match(kpp) for kpp in kpps]

# Generated at 2022-06-23 20:56:28.694649
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    provider = RussiaSpecProvider()
    print(provider.passport_series(year=12))

# Generated at 2022-06-23 20:56:33.316809
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    snils = RussiaSpecProvider().snils()
    print(snils)
    print(len(snils))
    assert len(snils) == 11
    assert type(snils) == str


# Generated at 2022-06-23 20:56:33.980787
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    assert RussiaSpecProvider()

# Generated at 2022-06-23 20:56:37.464857
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    provider = RussiaSpecProvider()
    assert provider.__class__.__name__ == "RussiaSpecProvider"
    assert provider.__class__.__bases__[0].__name__ == "BaseSpecProvider"


# Generated at 2022-06-23 20:56:44.117218
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    from mimesis.enums import Gender
    from mimesis.providers.base import BaseDataProvider
    from mimesis.providers.geo import GeoProvider

    class RussiaDataProvider(BaseDataProvider):
        class Meta:
            name = 'RussiaProvider'

        class RussiaSpecProvider(RussiaSpecProvider):
            class Meta:
                name = 'RussiaSpecProvider'

        class GeoProvider(GeoProvider):
            class Meta:
                name = 'GeoProvider'

        russia_spec = RussiaSpecProvider

        geo = GeoProvider

    data_provider = RussiaDataProvider()
    numbers = []
    num_numbers = 0
    while True:
        num_numbers += 1
        numbers.append(data_provider.russia_spec.inn())
        if num_numbers == 1_000:
            break

# Generated at 2022-06-23 20:56:54.255859
# Unit test for method inn of class RussiaSpecProvider

# Generated at 2022-06-23 20:56:56.931200
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    rdp = RussiaSpecProvider()
    assert len(str(rdp.passport_number())) == 6

# Generated at 2022-06-23 20:56:59.592101
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    provider = RussiaSpecProvider()
    assert provider.patronymic(Gender.MALE) in provider.patronymic(Gender.FEMALE)


# Generated at 2022-06-23 20:57:04.142364
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    russia_code = 0
    for i in range(0, 100):
        a = RussiaSpecProvider(russia_code)
        assert len(a.patronymic(gender = Gender.MALE)) != 0
        assert len(a.patronymic(gender = Gender.FEMALE)) != 0
        assert len(a.patronymic(gender = Gender.UNKNOWN)) != 0
        russia_code += 1


# Generated at 2022-06-23 20:57:05.924150
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    provider = RussiaSpecProvider()
    assert provider.__class__.__name__ == 'RussiaSpecProvider'



# Generated at 2022-06-23 20:57:12.919087
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    ru_spec = RussiaSpecProvider()
    ru_spec.seed(0)
    assert ru_spec.patronymic(Gender.MALE) == 'Алексеевна'
    assert ru_spec.patronymic(Gender.FEMALE) == 'Алексеевна'


# Generated at 2022-06-23 20:57:14.574684
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider()
    result = provider.bic()

    assert len(result) == 8

# Generated at 2022-06-23 20:57:17.873492
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    code = provider.snils()
    assert len(code) == 11

# Generated at 2022-06-23 20:57:20.827955
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    # Generete 10 random KPP
    for _ in range(0,10):
        print(RussiaSpecProvider().kpp())



# Generated at 2022-06-23 20:57:24.840748
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    provider = RussiaSpecProvider()
    sentence = provider.generate_sentence()
    words = sentence.split()
    for word in words:
        assert word in provider._data['sentence']


# Generated at 2022-06-23 20:57:26.606984
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    r = RussiaSpecProvider()
    assert r.bic() == '044025575'


# Generated at 2022-06-23 20:57:29.193037
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    """Test constructor of class RussiaSpecProvider."""
    print("Test constructor of class RussiaSpecProvider")
    provider = RussiaSpecProvider()
    assert provider.__class__.__base__ == BaseSpecProvider


# Generated at 2022-06-23 20:57:30.535191
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    r = RussiaSpecProvider()
    r.bic()


# Generated at 2022-06-23 20:57:34.383116
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    provider = RussiaSpecProvider()
    s = provider.generate_sentence()
    assert isinstance(s, str)
    assert len(s) > 0


# Generated at 2022-06-23 20:57:36.871160
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    r = RussiaSpecProvider()
    for i in range(100):
        print(r.bic())


# Generated at 2022-06-23 20:57:39.820894
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    russian_provider = RussiaSpecProvider()
    ogrn = russian_provider.ogrn()
    assert ogrn.__len__() == 13
    assert ogrn[12] == "2"

# Generated at 2022-06-23 20:57:45.520243
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Unit test for method ogrn of class RussiaSpecProvider
    """
    from mimesis.providers.organization import Organization
    import pprint
    pp = pprint.PrettyPrinter(indent=4, width=10)
    russia = Organization('ru')
    x = russia.ogrn()
    assert(len(x) == 13)
    for i in x:
        assert(i.isnumeric())
