

# Generated at 2022-06-23 20:47:45.145869
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    print("\n --- Test of RussiaSpecProvider class constructor ---\n")
    d = RussiaSpecProvider()
    assert (d is not None), "Provider is empty"
    print("Provier is ok.")


# Generated at 2022-06-23 20:47:49.501407
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    """Test constructor of class RussiaSpecProvider."""
    # Test with empty args
    test_ru_dataprovider = RussiaSpecProvider()
    assert test_ru_dataprovider
    # Test with seed
    test_ru_dataprovider = RussiaSpecProvider('123')
    assert test_ru_dataprovider


# Generated at 2022-06-23 20:47:52.162794
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    provider = RussiaSpecProvider()
    assert provider.patronymic() != None
    assert type(provider.patronymic()) == str


# Generated at 2022-06-23 20:47:54.628984
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """Test RussiaSpecProvider.passport_number method."""
    provider = RussiaSpecProvider()
    assert 100000 <= provider.passport_number() <= 999999


# Generated at 2022-06-23 20:47:57.446770
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    ru = RussiaSpecProvider()
    ru.seed(0)
    ru.random.randint = lambda x, y: 0
    assert ru.passport_number() == 100000


# Generated at 2022-06-23 20:47:59.385486
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    assert len(RussiaSpecProvider().generate_sentence())>0


# Generated at 2022-06-23 20:48:07.182707
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    from mimesis.builtins.russia import RussiaSpecProvider
    ru_spec_provider = RussiaSpecProvider()
    kpp_list = []
    for i in range(0, 2000):
        kpp = ru_spec_provider.kpp()
        # в некоторых провинциях диапазон регистрационных номеров
        # ограничен значением до 368.
        if int(kpp[3:6]) <= 368:
            print(kpp)
        if kpp[3:6] == '368':
            print

# Generated at 2022-06-23 20:48:07.836051
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    assert RussiaSpecProvider()

# Generated at 2022-06-23 20:48:10.221383
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    provider = RussiaSpecProvider(seed=123)
    x = provider.passport_number()
    assert x == 563592


# Generated at 2022-06-23 20:48:12.646865
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    from mimesis.providers.russia import RussiaSpecProvider
    for i in range(0, 50):
        rus = RussiaSpecProvider(seed = i)
        assert len(rus.inn()) == 10


# Generated at 2022-06-23 20:48:14.751202
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    r = RussiaSpecProvider()
    print(r.series_and_number())

if __name__ == "__main__":
    test_RussiaSpecProvider_series_and_number()

# Generated at 2022-06-23 20:48:23.050157
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    from mimesis.providers import RussiaSpecProvider
    ru = RussiaSpecProvider()

    # Create dictionary for test
    # key - value
    # key - number of iterations

# Generated at 2022-06-23 20:48:31.809134
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    from mimesis import RussiaSpecProvider
    from mimesis.builtins import RussiaSpecProvider as Base
    from mimesis.typing import Seed

    provider = RussiaSpecProvider('ru')
    # Base.Meta.name == 'russia_provider'
    assert provider.__class__.Meta.name == Base.Meta.name
    assert provider.bic() == '044025575'
    provider = RussiaSpecProvider(Seed.random())
    # Base.Meta.name == 'russia_provider'
    assert provider.__class__.Meta.name == Base.Meta.name
    assert provider.bic() == '044025575'



# Generated at 2022-06-23 20:48:42.940655
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    data = RussiaSpecProvider().passport_series()

# Generated at 2022-06-23 20:48:44.678160
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    r = RussiaSpecProvider(seed=12345)
    assert r.passport_number() == 828377


# Generated at 2022-06-23 20:48:45.767293
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    o = RussiaSpecProvider()
    assert o.bic() == '044025575'

# Generated at 2022-06-23 20:48:47.686761
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider(seed=0)
    assert provider.bic() == '044025575'


# Generated at 2022-06-23 20:48:51.199419
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    rus = RussiaSpecProvider()
    bic = rus.bic()
    assert '_' not in str(bic)
    assert len(str(bic)) == 9


# Generated at 2022-06-23 20:48:54.018741
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    """Test for RussiaSpecProvider.bic"""
    bic = RussiaSpecProvider()
    expected = bic.bic()
    assert len(expected) == 9 # BIC must have 9 number


# Generated at 2022-06-23 20:48:56.673876
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    russia = RussiaSpecProvider()
    assert russia.generate_sentence() != russia.generate_sentence()



# Generated at 2022-06-23 20:48:57.940107
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    assert RussiaSpecProvider().ogrn() == '5211274733193'

# Generated at 2022-06-23 20:49:03.799156
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    russia_provider = RussiaSpecProvider()
    passport_series = russia_provider.passport_series()
    assert isinstance(passport_series, str)
    assert len(passport_series) == 5
    assert passport_series[0:2].isdigit()
    assert passport_series[3:5].isdigit()
    assert passport_series[2] == ' '
    assert int(passport_series[0:2]) > 0
    assert int(passport_series[0:2]) < 100
    assert int(passport_series[3:5]) > 9
    assert int(passport_series[3:5]) < 19


# Generated at 2022-06-23 20:49:06.638387
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider()
    result = provider.bic()
    print(f'\nresult: {result}')


# Generated at 2022-06-23 20:49:11.110015
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    from mimesis.providers.finance import Finance
    from mimesis.typing import Seed

    f = Finance(Seed.random())
    x = 0
    for _ in range(100):
        bic = f.bic()

        if bic.startswith('04'):
            x += 1

    assert x >= 90         # check if most of these bics start with 04



# Generated at 2022-06-23 20:49:12.242948
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
  assert RussiaSpecProvider().patronymic() == RussiaSpecProvider().patronymic()

# Generated at 2022-06-23 20:49:14.001417
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    x = RussiaSpecProvider(seed=4)
    output = x.ogrn()
    assert output == '168008377438'


# Generated at 2022-06-23 20:49:20.082790
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    russ = RussiaSpecProvider()

# Generated at 2022-06-23 20:49:24.822915
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    """
    Проверка метода bic (получение БИК) класса RussiaSpecProvider
    """
    ru_sp = RussiaSpecProvider()
    assert ru_sp.bic() == "044025575" 


# Generated at 2022-06-23 20:49:28.298678
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    rus_provider = RussiaSpecProvider()
    assert rus_provider.__class__.__name__ == 'RussiaSpecProvider'
    assert rus_provider._data.__class__.__name__ == 'dict'


# Generated at 2022-06-23 20:49:36.880828
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    # Проверка аргументов не производится в сервисе
    russian_provider = RussiaSpecProvider()
    inn = russian_provider.inn()
    assert int(str(inn)[0]) != 0
    assert len(inn) == 10
    assert inn.isdigit()

    for _ in range(0, 100):
        inn = russian_provider.inn()

# Generated at 2022-06-23 20:49:40.650578
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():

    # Initialize RussiaSpecProvider
    provider = RussiaSpecProvider()

    # Generate sentence
    sentence = provider.generate_sentence()

    # Assert sentence is string
    assert isinstance(sentence, str)


# Generated at 2022-06-23 20:49:44.626880
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    '''
    Тестирование метода generate_sentence класса RussiaSpecProvider
    '''
    rus = RussiaSpecProvider()
    assert len(rus.generate_sentence()) > 0

# Generated at 2022-06-23 20:49:47.051696
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    r = RussiaSpecProvider()
    INN=r.inn()
    assert len(INN) == 10

# Generated at 2022-06-23 20:49:49.285331
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Test RussiaSpecProvider class method inn."""
    obj = RussiaSpecProvider()
    print('inn: ' + obj.inn())


# Generated at 2022-06-23 20:49:58.773074
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Unit test for method series_and_number of class RussiaSpecProvider"""
    values = [
        '36 08 165247',
        '32 09 372855',
        '14 05 918049',
        '12 17 716609',
        '15 08 354401',
        '28 17 197510',
        '36 13 446023',
        '11 16 626915',
        '21 05 642000',
        '50 11 264842'
    ]
    provider = RussiaSpecProvider(seed='Ivan')
    for index in range(0, 10):
        assert provider.series_and_number() in values

# Generated at 2022-06-23 20:50:03.906118
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    provider = RussiaSpecProvider() 
    # Testing passport_series method with default arguments 
    passport_series = provider.passport_series()
    # Checking type of result
    assert(isinstance(passport_series, str))
    # Checking length of result
    assert(len(passport_series) == 5)
    # Testing passport_series method with year as argument 
    passport_series = provider.passport_series(year=18)
    # Checking type of result
    assert(isinstance(passport_series, str))
    # Checking length of result
    assert(len(passport_series) == 5)
    # Getting last two symbols of result
    last_two_symbols = passport_series[-2:]
    # Checking last two symbols
    assert(last_two_symbols == '18')

# Unit

# Generated at 2022-06-23 20:50:07.832490
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    print("Testing method ogrn of class RussiaSpecProvider -------------")
    ru = RussiaSpecProvider()
    for _ in range(0,10):
        ogrn = ru.ogrn()
        ogrn_mult = int(ogrn) % 11 % 10
        assert int(ogrn[-1]) == ogrn_mult
    print("OK")


# Generated at 2022-06-23 20:50:10.770803
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Unit test for method series_and_number of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    assert isinstance(provider.series_and_number(), str)

# Generated at 2022-06-23 20:50:15.362257
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    class RussiaSpecProvider_testObj:
        def __init__(self):
            self.russia_testObj = RussiaSpecProvider('en')

    russia_testObj = RussiaSpecProvider_testObj().russia_testObj
    if isinstance(russia_testObj.generate_sentence(), str):
        assert 1
    else:
        assert 0


# Generated at 2022-06-23 20:50:22.998830
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """Test function kpp in class RussiaSpecProvider."""
    RussiaSpecProvider_ = RussiaSpecProvider()
    assert RussiaSpecProvider_._validate_enum(None, Gender) == Gender.MALE
    assert RussiaSpecProvider_.generate_sentence() == 'Назовите Петровна задачу задачу правильно правильно'
    assert RussiaSpecProvider_.patronymic(Gender.MALE) == 'Иванович'
    assert RussiaSpecProvider_.passport_number() in range(100000, 999999)
    assert RussiaSpecProvider_.passport_series(18) == '98 18'
    assert RussiaSpecProvider_.series_and_number

# Generated at 2022-06-23 20:50:30.864877
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    r = RussiaSpecProvider()
    test_inn = r.inn()
    assert len(test_inn) == 12
    t_inn = ''.join(test_inn)
    inn_int = int(t_inn)
    c_sum = 0
    digits = [7, 2, 4, 10, 3, 5, 9, 4, 6, 8]
    digits_int = []
    for dig in digits:
        digits_int.append(int(dig))

    for i in range(0, 10):
        c_sum += digits_int[i] * int(test_inn[i])
    c_sum = c_sum % 11 % 10
    assert c_sum == int(test_inn[10])

    digits = [3, 7, 2, 4, 10, 3, 5, 9, 4, 6, 8]

# Generated at 2022-06-23 20:50:36.567746
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Unit test for method inn of class RussiaSpecProvider."""
    rs = RussiaSpecProvider()
    inn = rs.inn()
    assert len(inn) == 10
    assert inn != rs.inn()

    expected = '7012345678'
    inn = rs.inn(expected)
    assert inn == expected


# Generated at 2022-06-23 20:50:41.588597
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Generate 12 digit number, starts with 0, checksum is the 11th and 12th"""
    assert len(RussiaSpecProvider().inn()) == 12
    assert RussiaSpecProvider().inn()[0] == '0'
    assert RussiaSpecProvider().inn()[10] > '0'
    assert RussiaSpecProvider().inn()[11] > '0'


# Generated at 2022-06-23 20:50:45.459393
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    print("Unit test for method passport_series of class RussiaSpecProvider")
    russia_spec_provider = RussiaSpecProvider()
    passport_ser = russia_spec_provider.passport_series()
    print(passport_ser)


# Generated at 2022-06-23 20:50:52.559691
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    rus_provider = RussiaSpecProvider()

    # Test case 1
    kpp1 = rus_provider.kpp()
    assert len(kpp1) == 9
    assert kpp1[0:4].isnumeric()
    assert kpp1[4:6].isnumeric()
    assert kpp1[6:9].isnumeric()

    # Test case 2
    kpp2 = rus_provider.kpp()
    assert len(kpp2) == 9
    assert kpp2[0:4].isnumeric()
    assert kpp2[4:6].isnumeric()
    assert kpp2[6:9].isnumeric()

    # Test case 3
    kpp3 = rus_provider.kpp()
    assert len(kpp3) == 9
   

# Generated at 2022-06-23 20:50:53.147874
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    rs = RussiaSpecProvider()
    assert len(rs.bic()) == 9

# Generated at 2022-06-23 20:50:54.684627
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    for i in range(1):
        assert RussiaSpecProvider().patronymic() not in ('', ' ', None)


# Generated at 2022-06-23 20:50:56.020252
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    
    rsp = RussiaSpecProvider()
    bic = rsp.bic()
    assert len(bic) == 9




# Generated at 2022-06-23 20:50:58.784030
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    rup = RussiaSpecProvider()

    for i in range(0, 10):
        assert len(rup.bic()) == 9


# Generated at 2022-06-23 20:51:09.286662
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    provider = RussiaSpecProvider()
    assert provider.passport_series(18) == '49 18'
    assert provider.passport_number() in range(100000, 999999)
    assert provider.series_and_number() == '57 16 805199'
    assert provider.snils() == '41917492600'
    assert provider.inn() == '5620046445'
    assert provider.ogrn() == '4715113303725'
    assert provider.bic() == '044025575'
    assert provider.kpp() == '5900560058652'
    assert provider.patronymic(Gender.FEMALE) == 'Алексеевна'

# Generated at 2022-06-23 20:51:10.095696
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    russian_provider = RussiaSpecProvider()
    russian_provider.generate_sentence()


# Generated at 2022-06-23 20:51:15.918978
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    seed = "144024f6b457466dfb0afcc8f47c27b0134b056b"
    RussiaSpecProvider(seed=seed)
    result = RussiaSpecProvider().generate_sentence()
    assert result == 'Я люблю наши поля и леса.'


# Generated at 2022-06-23 20:51:20.887377
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    test = RussiaSpecProvider()
    test.seed(1) #Use the same seed for reproducible results
    assert isinstance(test,RussiaSpecProvider)
    assert isinstance(test.seed, int)
    assert test.seed == 1
    # test.reset_seed()
    # assert test.seed is not None
    # assert isinstance(test.seed, int)


# Generated at 2022-06-23 20:51:31.964296
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    print("\nTesting RussiaSpecProvider class ...")
    provider = RussiaSpecProvider()
    # Testing generate_sentence
    sentence = provider.generate_sentence()
    print("Testing generate_sentence: " + sentence)
    assert sentence != ""
    # Testing patronymic
    patronymic = provider.patronymic()
    print("Testing patronymic: " + patronymic)
    assert patronymic != ""
    # Testing passport_series
    passport_series = provider.passport_series()
    print("Testing passport_series: " + passport_series)
    assert passport_series != ""
    # Testing passport_number
    passport_number = provider.passport_number()
    print("Testing passport_number: " + str(passport_number))
    assert passport_number != ""
    # Testing series_and

# Generated at 2022-06-23 20:51:33.662438
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    a = r.snils()
    assert len(a) == 11


# Generated at 2022-06-23 20:51:41.058279
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for snils method."""
    sample_snils = ['25174638527', '25182031066', '25197580989', '25182272843', '25148405579', '25141433824', '25188516984',
                    '25159998820', '25141416054', '25181717416', '25180622300', '25179009552', '25164915562', '25181274307',
                    '25185067276', '25164904109', '25197506474', '25179810284', '25187747186', '25172775448', '25141416306',
                    '25187898466', '25165220523']
    russia_snils = RussiaSpecProvider()
   

# Generated at 2022-06-23 20:51:47.978176
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    russian = RussiaSpecProvider()
    assert russian.full_name() == "Сергей Сергеевич Сергеев"
    assert russian.snils() == "5716805199"
    assert russian.inn() == "7707083893"
    assert russian.ogrn() == "4715113303725"
    assert russian.bic() == "044025575"
    assert russian.kpp() == "560058652"

# Generated at 2022-06-23 20:51:50.730689
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Unit test for method inn of class RussiaSpecProvider.
    """
    assert len(RussiaSpecProvider().inn()) == 12
    assert RussiaSpecProvider().inn() != RussiaSpecProvider().inn()



# Generated at 2022-06-23 20:51:55.611170
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    p = RussiaSpecProvider(seed=12345)
    assert p.patronymic() == "вич"
    assert p.patronymic(gender=Gender.FEMALE) == "вна"
    assert p.patronymic(gender=Gender.MALE) == "вич"

# Generated at 2022-06-23 20:52:05.231753
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    r = RussiaSpecProvider()

# Generated at 2022-06-23 20:52:10.604522
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    test_data = ['044025575', '044025248', '044025993', '044025931', '044025332', '044025190', '044025953', '044025218', '044025294', '044025505']
    test_object = RussiaSpecProvider()
    for i in range(10):
        assert test_object.bic() in test_data

# Generated at 2022-06-23 20:52:14.346385
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Passport series is valid or not."""
    from mimesis import RussiaSpecProvider

    r = RussiaSpecProvider()

    passport_series = r.passport_series()
    new_passport_series = r.passport_series(2012)

    assert len(passport_series) == 5
    assert len(new_passport_series) == 5
    assert new_passport_series == '02 12'


# Generated at 2022-06-23 20:52:18.296744
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    rus_prov = RussiaSpecProvider()
    assert rus_prov.patronymic() in rus_prov._data['patronymic'][None]

#Unit test for method inn of class RussiaSpecProvider

# Generated at 2022-06-23 20:52:20.741575
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    rs = RussiaSpecProvider()
    sentence = rs.generate_sentence()
    print(sentence)



# Generated at 2022-06-23 20:52:22.192733
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    assert RussiaSpecProvider().ogrn() != '715113303725'

# Generated at 2022-06-23 20:52:27.000437
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Test function inn of class RussiaSpecProvider"""
    test_data = """1234567897"""
    test_object = RussiaSpecProvider()

    for _ in range(0, 7):
        pattern = """\d{10}"""
        regex_test(test_object.inn(), pattern)
        assert len(test_object.inn()) == 10



# Generated at 2022-06-23 20:52:30.263021
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """Test method passport_number of class RussiaSpecProvider
    """
    assert RussiaSpecProvider().passport_number() <= 999999
    assert RussiaSpecProvider().passport_number() >= 100000


# Generated at 2022-06-23 20:52:36.917981
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Unit test for RussiaSpecProvider.series_and_number."""
    r = RussiaSpecProvider()
    series = r.series_and_number()
    assert len(str(series)) == 11
    assert not (set(str(series)) - set('1234567890'))
    assert int(str(series)[-6:]) in range(100000, 999999)
    

# Generated at 2022-06-23 20:52:39.119186
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Test data
    provider = RussiaSpecProvider(seed=42)
    snils = '41917492600'
    # test
    assert snils == provider.snils()

# Generated at 2022-06-23 20:52:41.075437
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    assert isinstance(r.snils(), str)
    assert len(r.snils()) == 11


# Generated at 2022-06-23 20:52:42.889447
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    r = RussiaSpecProvider()
    print(r.inn())


# Generated at 2022-06-23 20:52:48.240244
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    """Ensure method generates patronymics."""
    provider = RussiaSpecProvider()
    patronymics = [provider.patronymic() for _ in range(0, 20)]
    assert all([patronymic in provider._data['patronymic'].values()
                for patronymic in patronymics])


# Generated at 2022-06-23 20:52:54.299447
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    for i in range(0, 10):
        p = RussiaSpecProvider()
        patronymic = p.patronymic(Gender.FEMALE)
        assert patronymic in RussiaSpecProvider._data['patronymic'][Gender.FEMALE]
        patronymic = p.patronymic(Gender.MALE)
        assert patronymic in RussiaSpecProvider._data['patronymic'][Gender.MALE]


# Generated at 2022-06-23 20:52:56.224885
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    provider = RussiaSpecProvider()
    series = provider.passport_series()
    assert len(series) == 5



# Generated at 2022-06-23 20:52:59.136592
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    # bic = RussiaSpecProvider()
    for i in xrange(10):
        bic = RussiaSpecProvider().bic()
        print(bic)


# Generated at 2022-06-23 20:53:01.410385
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    assert len(RussiaSpecProvider().generate_sentence()) > 0
    print("Test of method generate_sentence passed.")


# Generated at 2022-06-23 20:53:06.520941
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    print("\nStart unit test for constructor of class RussiaSpecProvider")

    ru = RussiaSpecProvider()
    print("INN: ", ru.inn ())
    print("OGRN: ", ru.ogrn())
    print("BIC: ", ru.bic ())
    print("KPP: ", ru.kpp ())

# Generated at 2022-06-23 20:53:10.599176
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    provider = RussiaSpecProvider()
    series_and_number = provider.series_and_number()
    series_and_number_length = 9
    assert len(series_and_number) == series_and_number_length


# Generated at 2022-06-23 20:53:12.397735
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    rs = RussiaSpecProvider()
    assert 100000 <= rs.passport_number() <= 999999


# Generated at 2022-06-23 20:53:13.738804
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    print(RussiaSpecProvider())
    assert RussiaSpecProvider()


# Generated at 2022-06-23 20:53:14.944078
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    provider = RussiaSpecProvider()
    print(provider.kpp())


# Generated at 2022-06-23 20:53:16.561090
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    kpp = RussiaSpecProvider(seed=1).kpp()
    assert kpp == '550055302'


# Generated at 2022-06-23 20:53:24.603986
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    russiaspecp = RussiaSpecProvider()
    tmp = russiaspecp.bic()
    assert (
        tmp in [
            '044025575',
            '046024061',
            '046025635',
            '046026305',
            '046006937',
            '045026135',
            '046023061',
            '047025575',
            '044025575',
        ]
    )
    print(tmp)



# Generated at 2022-06-23 20:53:33.945778
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    provider = RussiaSpecProvider()
    # test for generate_sentence method
    assert provider.generate_sentence()
    # test for random patronymic
    assert provider.patronymic()
    # test for passport_series method
    assert provider.passport_series()
    # test for passport_number method
    assert provider.passport_number()
    # test for series_and_number method
    assert provider.series_and_number()
    # test for snils method
    assert provider.snils()
    # test for inn method
    assert provider.inn()
    # test for ogrn method
    assert provider.ogrn()
    # test for bic method
    assert provider.bic()
    # test for kpp method
    assert provider.kpp()
    # test for seed
    provider_1 = Russia

# Generated at 2022-06-23 20:53:38.533394
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    rus = RussiaSpecProvider()
    bic = rus.bic()
    assert len(bic) == 9, "Длина бика должна быть 9 символов"

## Unit test for method snils of class RussiaSpecProvider

# Generated at 2022-06-23 20:53:40.383577
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():

    russian = RussiaSpecProvider()
    bic = russian.bic()
    assert (len(bic)==9)


# Generated at 2022-06-23 20:53:45.164147
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    a = RussiaSpecProvider()
    assert len(a.passport_series()) == 5
    assert a.passport_series(year=15) == '02 15'
    assert a.passport_series(year=20) == '02 20'

# Generated at 2022-06-23 20:53:48.043237
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    provider = RussiaSpecProvider()
    assert isinstance(provider.passport_series(), str)
    assert 4 == len(provider.passport_series())


# Generated at 2022-06-23 20:53:52.260755
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Unit test for method passport_series of class RussiaSpecProvider."""
    rs = RussiaSpecProvider()
    assert isinstance(rs.passport_series(), str)
    assert len(rs.passport_series()) == 5


# Generated at 2022-06-23 20:53:56.379801
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    rsp = RussiaSpecProvider()
    ogrn_result = rsp.ogrn()
    assert len(ogrn_result) == 13
    assert '13' in ogrn_result
    assert '4715' in ogrn_result
    assert '113303' in ogrn_result


# Generated at 2022-06-23 20:53:59.402683
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    rv = RussiaSpecProvider().patronymic(Gender.FEMALE)
    assert rv in ["Ивановна", "Петровна", "Сидоровна", "Максимовна"]


# Generated at 2022-06-23 20:54:09.103779
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    uid = RussiaSpecProvider()
    res = uid.bic()
    for i in res:
        ascii = ord(i)
        if ascii < 48 or ascii > 57:
            print("Error: Character outside the ASCII range !")
        else:
            print("Success: Character within the ASCII range !")
    if len(res) == 9:
        print("Success: Length of the string is valid !")
    else:
        print("Error: Length of the string is not valid !")

print(test_RussiaSpecProvider_bic())



# Generated at 2022-06-23 20:54:10.588712
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    assert RussiaSpecProvider().kpp() == RussiaSpecProvider().kpp()


# Generated at 2022-06-23 20:54:20.708883
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    # Создать объект класса RussiaSpecProvider
    rsp = RussiaSpecProvider()
    # Генерировать один отчество для мужского пола
    patr = rsp.patronymic()
    # Проверить длину отчества
    assert len(patr) > 3 and len(patr) < 10
    # Проверить наличие прописной буквы
    assert patr[0].isupper()
   

# Generated at 2022-06-23 20:54:28.712318
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Указываем сид
    g = RussiaSpecProvider(seed=0)

    # Извлекаем случайный snils
    snils = g.snils()
    # Проверяем соответствие snils правилу
    assert snils == '41917492600'

# Generated at 2022-06-23 20:54:31.736212
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Test method inn of class RussiaSpecProvider."""
    # Arrage
    r = RussiaSpecProvider()
    # Act
    r.seed('123')
    tr = r.inn()
    # Assert
    assert tr == '5350002032'

# Generated at 2022-06-23 20:54:34.444808
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    r = RussiaSpecProvider()
    res = r.passport_series()
    assert len(res) == 5



# Generated at 2022-06-23 20:54:37.535570
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    attr = RussiaSpecProvider(seed=47)
    input_value = attr._data['passport_number']
    expected_value = 75
    actual_value = input_value
    assert actual_value == expected_value

# Generated at 2022-06-23 20:54:39.250559
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    r_p_p = RussiaSpecProvider()
    r_p_p.passport_number()


# Generated at 2022-06-23 20:54:40.516962
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    RussiaSpecProvider().passport_series() == '04 18'

# Generated at 2022-06-23 20:54:45.950593
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    """Test for method generate_sentence of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    sentence = provider.generate_sentence()
    assert isinstance(sentence, str), 'Method generate_sentence() works incorectly.'


# Generated at 2022-06-23 20:54:49.585059
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    i = 1
    while i != 5:
        gender = Gender.MALE
        patronymic = RussiaSpecProvider().patronymic(gender)
        assert patronymic in RussiaSpecProvider()._data['patronymic'][gender]
        i += 1


# Generated at 2022-06-23 20:54:52.729294
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    from mimesis.builtins import RussiaSpecProvider
    r = RussiaSpecProvider()
    sen = r.generate_sentence()
    print(sen)
    assert sen != None


# Generated at 2022-06-23 20:54:58.635260
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    rus = RussiaSpecProvider(seed=123)
    assert rus.patronymic() == 'Алексеевна'
    assert rus.patronymic(Gender.MALE) == 'Алексеевич'
    assert rus.patronymic(Gender.FEMALE) == 'Алексеевна'

# Generated at 2022-06-23 20:55:03.346889
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    p = RussiaSpecProvider()
    inn = p.inn()
    assert len(inn) == 10
    assert inn[:2] != '00'
    assert inn[2:4] != '00'
    assert inn[4:6] != '00'
    assert inn[6:9] != '000'
    assert inn[9] != '0'


# Generated at 2022-06-23 20:55:09.155249
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    # Instance of class RussiaSpecProvider
    rus = RussiaSpecProvider()

    # Create list with INN
    inn = []
    # Run 1000 times generate INN
    for i in range(0, 1000):
        # Do append to list inn
        inn.append(rus.inn())

    # Create set with INN
    inn_set = set(inn)
    # Then len of set must be equal len of list
    assert(len(inn) == len(inn_set))

# Generated at 2022-06-23 20:55:10.140307
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    provider = RussiaSpecProvider()
    print(provider.passport_number())

# Generated at 2022-06-23 20:55:11.752546
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider()
    bic = provider.bic()
    assert bic == '044025575'



# Generated at 2022-06-23 20:55:14.772292
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    sample_series_and_number = ['6353194690',
                                '5785397583',
                                '9638352497',
                                '6397518612']
    for i in range(0, 4):
        assert RussiaSpecProvider().series_and_number() in sample_series_and_number

# Generated at 2022-06-23 20:55:16.163820
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider(seed=12345)

    for i in range(0, 10):
        assert provider.snils() == '41917492600'


# Generated at 2022-06-23 20:55:19.826305
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    pass
    """
    def test_RussiaSpecProvider_passport_number():
        provider = RussiaSpecProvider()
        assert len(str(provider.passport_number())) == 6
        assert str(provider.passport_number()).isdigit() is True
        """

# Generated at 2022-06-23 20:55:28.736579
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    ogrn_list = []
    unique_list = []
    unique_amount = 0

    while unique_amount < 100:
        ogrn = RussiaSpecProvider().ogrn()
        ogrn_list.append(ogrn)
        unique_list = set(ogrn_list)

        if len(unique_list) == unique_amount:
            ogrn_list[:] = []
            unique_list[:] = []
            unique_amount += 1
    print('test RussiaSpecProvider_ogrn passed')



# Generated at 2022-06-23 20:55:32.338806
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Check that the method returns correct value."""
    russiaSpecProvider = RussiaSpecProvider()
    snils = russiaSpecProvider.snils()
    assert isinstance(snils, str)



# Generated at 2022-06-23 20:55:32.937334
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    pass

# Generated at 2022-06-23 20:55:34.296360
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    r = RussiaSpecProvider()
    assert r.patronymic()

# Generated at 2022-06-23 20:55:37.898057
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
  rsp = RussiaSpecProvider()
  ogrn_1 = rsp.ogrn()
  ogrn_2 = rsp.ogrn()
  assert len(ogrn_1) == len(ogrn_2)
  assert len(ogrn_1) == 13
  assert ogrn_1 != ogrn_2


# Generated at 2022-06-23 20:55:40.518895
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    ru_provider = RussiaSpecProvider()
    for i in range(0, 100):
        ru_provider.passport_number()



# Generated at 2022-06-23 20:55:44.899168
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.person.ru.ru import RussiaSpecProvider
    t = RussiaSpecProvider(seed=0)
    test_data = '41917492600'
    assert t.snils() == test_data


# Generated at 2022-06-23 20:55:47.726820
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    """Unit test for method generate_sentence of class RussiaSpecProvider."""
    obj = RussiaSpecProvider()
    sentence = obj.generate_sentence()
    assert isinstance(sentence, str)


# Generated at 2022-06-23 20:55:56.761843
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.enums import Gender
    from mimesis.providers.identifiers import Passport
    import re

    address = Address('ru')
    person = Person('ru')
    needed_person = person.create_fake_person(gender=Gender.MALE)
    str_number = str(Passport('ru').passport_number(needed_person))

    # Паспорт состоит из региона, года, порядкового номера и контрольного кода
    assert re

# Generated at 2022-06-23 20:56:03.958355
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    provider = RussiaSpecProvider()

# Generated at 2022-06-23 20:56:06.685586
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    from mimesis.enums import Gender
    r = RussiaSpecProvider(seed = 'test')
    result = r.kpp()
    assert result == '010014006'

# Generated at 2022-06-23 20:56:09.155472
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    
    sn = RussiaSpecProvider().series_and_number()
    assert sn == '{}{}'.format(RussiaSpecProvider().passport_series(), RussiaSpecProvider().passport_number())

# Generated at 2022-06-23 20:56:19.929460
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    expected = '560058652'

# Generated at 2022-06-23 20:56:31.546315
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    """Unit test for constructor of class RussiaSpecProvider.

    :return: True or False
    :rtype: bool
    """
    from mimesis.providers.person import Person

    person = Person()
    person.seed(2)

    assert person.first_name(gender='female') == 'Татьяна'
    assert person.last_name(gender='female') == 'Маркова'
    assert person.full_name(gender='female') == 'Татьяна Маркова'
    assert person.username(
        gender='female', birth_date='1993-02-14') == 'tatyana-markova'
    assert person.ssn() == '193221475300'

# Generated at 2022-06-23 20:56:33.714552
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    provider = RussiaSpecProvider()
    assert provider.kpp() == '560058652'

# Generated at 2022-06-23 20:56:36.011216
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Unit test for method passport_series"""
    provider = RussiaSpecProvider()
    assert len(provider.passport_series()) == 5


# Generated at 2022-06-23 20:56:38.430193
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Unit test for method inn of class RussiaSpecProvider"""
    a = RussiaSpecProvider()
    inn = a.inn()
    assert len(inn)==12


# Generated at 2022-06-23 20:56:40.298097
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    RSP = RussiaSpecProvider(seed=0)
    assert RSP.inn() == '7411181245'


# Generated at 2022-06-23 20:56:46.738936
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    # Create object of class RussiaSpecProvider
    s = RussiaSpecProvider()
    # Generate random KPP
    kpp = s.kpp()
    # Count the number of digits in the KPP
    number_of_digits = len(kpp)
    # Сompare the number of digits in the generated KPP with the template
    assert number_of_digits == 9

# Generated at 2022-06-23 20:56:47.849838
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    RussiaSpecProvider.generate_sentence()

# Generated at 2022-06-23 20:56:54.716157
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    p = Person('ru', seed=42)
    assert p.snils() == '41917492600'
    assert p.snils() == '41917492600'
    assert p.snils() == '41917492600'

    p = Person('ru', seed=43)
    assert p.snils() == '41917492600'
    assert p.snils() == '41917492600'
    assert p.snils() == '41917492600'



# Generated at 2022-06-23 20:56:57.062562
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    provider = RussiaSpecProvider()
    series = provider.passport_series()
    assert series[:2].isdigit() and len(series) == 5


# Generated at 2022-06-23 20:57:03.205561
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    import unittest

    provider = RussiaSpecProvider()

    class RussiaSpecProviderTestCase(unittest.TestCase):
        def runTest(self):
            self.assertRegex(provider.series_and_number(), r'[0-9]{2}\s[0-9]{2}\s[0-9]{6}')

    suite = unittest.TestSuite()
    suite.addTest(RussiaSpecProviderTestCase())
    runner = unittest.TextTestRunner()
    print(runner.run(suite))

# Generated at 2022-06-23 20:57:04.991852
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    r = RussiaSpecProvider(seed=42)
    print(r.kpp())


# Generated at 2022-06-23 20:57:05.762081
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    r = RussiaSpecProvider()
    assert r

# Generated at 2022-06-23 20:57:07.755305
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    r = RussiaSpecProvider()
    print(r.passport_series())


# Generated at 2022-06-23 20:57:11.151281
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    r = RussiaSpecProvider()
    assert(r.passport_series(15))


# Generated at 2022-06-23 20:57:13.808365
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    p = RussiaSpecProvider()
    assert p.patronymic(Gender.FEMALE) in p._data['patronymic'][Gender.FEMALE]

# Generated at 2022-06-23 20:57:15.790678
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    inn = RussiaSpecProvider(seed = 12).inn()
    assert inn == "9140791343"


# Generated at 2022-06-23 20:57:28.112610
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.russia import RussiaSpecProvider

    p = Person('ru')
    rsp = RussiaSpecProvider('seed')
    assert rsp.inn() == '7707083893'
    assert rsp.patronymic(Gender.MALE) == 'Артёмовна'
    assert rsp.patronymic(Gender.FEMALE) == 'Анатольевна'
    assert rsp.patronymic() == 'Владимировна'
    assert rsp.ogrn() == '4715113303725'
    assert rsp.passport_number() == '560430'

# Generated at 2022-06-23 20:57:34.221977
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    ru = RussiaSpecProvider(seed = 0)
    result = ru.generate_sentence()
    expected = 'Услуги предоставляются только по предварительной договоренности. Заявка на запрос требует квалификации и обязанность.'
    assert result == expected


# Generated at 2022-06-23 20:57:39.821361
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():

    from mimesis.enums import Gender

    for _ in range(0, 100):
        r = RussiaSpecProvider()
        res = r.patronymic(Gender.MALE)
        assert res

    for _ in range(0, 100):
        r = RussiaSpecProvider()
        res = r.patronymic(Gender.FEMALE)
        assert res


# Generated at 2022-06-23 20:57:41.958241
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    provider = RussiaSpecProvider()
    assert provider.inn() == '460220825300'



# Generated at 2022-06-23 20:57:44.009855
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    r = RussiaSpecProvider()
    assert r.generate_sentence() != r.generate_sentence()
