

# Generated at 2022-06-23 20:47:43.959304
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    s = RussiaSpecProvider(seed = 1)
    sn = s.series_and_number()
    assert isinstance(sn, str), 'resut should be a string'
    assert len(sn) == 11, 'resut should be 11 symbols long'

# Generated at 2022-06-23 20:47:49.227630
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    from mimesis.enums import Gender

    provider = RussiaSpecProvider()
    answer = provider.kpp()
    assert isinstance(answer, str)
    assert len(answer) == 9
    assert provider.kpp() != provider.kpp()

    provider = RussiaSpecProvider()
    answer = provider.kpp()
    assert isinstance(answer, str)
    assert len(answer) == 9

# Generated at 2022-06-23 20:47:51.643854
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Unit test for method inn of class RussiaSpecProvider."""
    test = RussiaSpecProvider()
    test_inn = test.inn()
    assert len(test_inn) == 12

# Generated at 2022-06-23 20:47:52.491239
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    pass

# Generated at 2022-06-23 20:47:54.207927
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    rsp = RussiaSpecProvider()
    print (rsp.series_and_number())


# Generated at 2022-06-23 20:47:56.658823
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """Unit test for method passport_number of class RussiaSpecProvider."""
    # Create object of class RussiaSpecProvider
    test = RussiaSpecProvider(seed = 13)
    # Call method
    test.passport_number()
    # Create assertions
    assert test.passport_number() not in range(100000, 999999)


# Generated at 2022-06-23 20:47:59.659298
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    # проверяем формат bic
    assert (len(RussiaSpecProvider().bic()) == 9)


# Generated at 2022-06-23 20:48:01.297313
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    provider = RussiaSpecProvider(seed=42)
    assert provider.inn() == '7707071393'

# Generated at 2022-06-23 20:48:05.077074
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Test method passport_series of class RussiaSpecProvider."""
    x = RussiaSpecProvider()
    assert x.passport_series(year=19) == '02 19'
    assert x.passport_series(year=19).split(' ')[1] == '19'
    assert len(x.passport_series(year=19)) == 5


# Generated at 2022-06-23 20:48:06.904441
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    ogrn = RussiaSpecProvider().ogrn()
    assert ogrn == "4715113303725"

# Generated at 2022-06-23 20:48:11.591114
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    # Given
    r = RussiaSpecProvider()
    # When
    ogrn = r.ogrn()
    # Then
    assert type(ogrn) == str
    assert len(ogrn) == 13
    a1 = int(ogrn) // 1000000000000
    assert a1 == 4 or a1 == 5


# Generated at 2022-06-23 20:48:15.606293
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    ru = RussiaSpecProvider()
    ogrn = ru.ogrn()
    assert len(ogrn) == 13
    assert ogrn[0:12].isnumeric()
    assert ogrn[12].isnumeric()
    assert int(ogrn[12]) == int(int(ogrn[0:12]) % 11 % 10)


# Generated at 2022-06-23 20:48:23.634333
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    ru_provider = RussiaSpecProvider()

    assert ru_provider.__class__.__name__ == 'RussiaSpecProvider'
    assert ru_provider.__doc__ is not None
    assert ru_provider.__init__.__doc__ is not None
    assert ru_provider.__str__.__doc__ is not None
    assert ru_provider._format_str.__doc__ is not None
    assert ru_provider._get_data.__doc__ is not None
    assert ru_provider._pull.__doc__ is not None
    assert ru_provider.bic.__doc__ is not None
    assert ru_provider.inn.__doc__ is not None
    assert ru_provider.kpp.__doc__ is not None

# Generated at 2022-06-23 20:48:27.218307
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.utils import calculate_check_digit_snils
    for _ in range(0, 10000):
        fst_part = RussiaSpecProvider().snils()
        assert calculate_check_digit_snils(fst_part) == '00'

# Generated at 2022-06-23 20:48:28.630318
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    assert RussiaSpecProvider().kpp() == '560058652'


# Generated at 2022-06-23 20:48:37.015716
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    from mimesis.enums import Gender
    from mimesis.providers.enums import PersonTitle
    from mimesis.builtins import RussiaSpecProvider

    r = RussiaSpecProvider()
    print("=====Method passport_series of class RussiaSpecProvider=====")
    print("1st case:")
    print("method call: r.passport_series()")
    print("expected output: a string")
    print("actual output:")
    print(r.passport_series())
    print(" ")
    print("2nd case:")
    print("method call: r.passport_series(year=2)")
    print("expected output: a string")
    print("actual output:")
    print(r.passport_series(year=2))
    print(" ")
    print("3rd case:")

# Generated at 2022-06-23 20:48:39.763664
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider()
    for i in range(25):
        bic = provider.bic()
        assert bic in ['044025575', '049025575']

# Generated at 2022-06-23 20:48:41.657149
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    """Test method RussiaSpecProvider's constructor."""
    b = RussiaSpecProvider()
    assert repr(b) == "<RussiaSpecProvider 'ru'>"

# Generated at 2022-06-23 20:48:44.162631
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    ru = RussiaSpecProvider()
    inn = ru.inn() # 567759035009
    assert isinstance(inn, str)
    assert len(inn) == 10


# Generated at 2022-06-23 20:48:46.469713
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Unit test for method ogrn of class RussiaSpecProvider"""
    rsp = RussiaSpecProvider()
    assert rsp.ogrn() != rsp.ogrn()


# Generated at 2022-06-23 20:48:51.068420
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    test_data = {(2018): [18], (2010): [10]}
    provider = RussiaSpecProvider()
    for year in test_data:
        for i in range(10):
            assert provider.passport_series(year) in test_data[year]


# Generated at 2022-06-23 20:48:54.225793
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    from mimesis.builtins.russia import RussiaSpecProvider
    rsp = RussiaSpecProvider()
    assert len(rsp.bic()) == 9
    assert type(rsp.bic()) == str


# Generated at 2022-06-23 20:48:59.102934
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    # GIVEN
    rp = RussiaSpecProvider()

    # WHEN
    first_series = rp.passport_series(2005)
    second_series = rp.passport_series(2010)
    third_series = rp.passport_series(1990)

    # THEN
    assert first_series == '81 05'
    assert second_series == '54 10'
    assert third_series == '32 90'


# Generated at 2022-06-23 20:49:03.726511
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    rp = RussiaSpecProvider()
    series = rp.passport_series()
    assert (len(series) == 5) and (series[:2].isdigit()) and (series[2:].isdigit()), (
        'Expected length of return string is 5, Example: "04 15".'
    )


# Generated at 2022-06-23 20:49:14.309899
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    # Проверка на различных языках
    from mimesis import locales
    for el in locales:
        if el == 'ru':
            continue
        random = mimesis.Generic(el)
        sent = random.text.sentence()
        assert '\n' not in sent
        assert len(sent) > 0
        assert sent == random.text.sentence()
        sent = random.text.sentence(len_words=1)
        assert '\n' not in sent
        assert len(sent) > 0
        assert sent == random.text.sentence(len_words=1)

# Generated at 2022-06-23 20:49:19.399197
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    russian = RussiaSpecProvider()
    print(russian.snils())
    print(russian.inn())
    print(russian.ogrn())
    print(russian.bic())
    print(russian.kpp())

test_RussiaSpecProvider()

# Generated at 2022-06-23 20:49:24.361738
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    rsp = RussiaSpecProvider()
    patronymic = rsp.patronymic(Gender.MALE)
    assert len(patronymic) > 0
    assert patronymic.endswith('ич') or patronymic.endswith('на') or patronymic.endswith('ыч')

# Generated at 2022-06-23 20:49:28.182499
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Test the method series_and_number of class RussiaSpecProvider."""
    r = RussiaSpecProvider()
    n = r.series_and_number()
    assert len(str(n)) == 11
    assert n[2] == ' '
    assert n[6] == ' '

# Generated at 2022-06-23 20:49:33.241143
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    # 01 - Valid OGRN
    provider = RussiaSpecProvider(seed=12) # seed 12 -> OGRN=4715113303725
    ogrn1 = provider.ogrn()
    assert ogrn1=='4715113303725'

    # 02 - Invalid OGRN
    provider = RussiaSpecProvider(seed=12) # seed 12 -> OGRN=4715113303725
    ogrn2 = provider.ogrn()
    assert ogrn2=='4715113303725', 'Invalid OGRN'

# Generated at 2022-06-23 20:49:36.469211
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    provider = RussiaSpecProvider()

    for i in range(0, 10):
        inn = provider.inn()
        for i in range(0, len(inn)):
            assert (int(inn[i]) >= 0) and (int(inn[i]) <= 9)
        assert len(inn) == 12



# Generated at 2022-06-23 20:49:40.968817
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    result = RussiaSpecProvider().bic()
    assert result is not None
    assert type(result) is str
    assert len(result) == 9
    assert result[:2] == '04'
    assert result[-3:].isdigit()


# Generated at 2022-06-23 20:49:43.102489
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    ru = RussiaSpecProvider()
    for x in range(0, 10):
         print(ru.series_and_number())


# Generated at 2022-06-23 20:49:51.885153
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider('en')
    bic = provider.bic()
    assert len(bic) == 9
    assert bic[0:2] == '04'
    assert bic[2:4] in ('01', '02', '03', '05', '06', '07', '08', '09', '10',
                        '11', '12', '13', '14', '15', '16', '17', '18', '19',
                        '20', '21', '22', '23', '24', '25', '26', '27', '28',
                        '29')

# Generated at 2022-06-23 20:49:54.481026
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    rsp = RussiaSpecProvider()
    assert rsp.series_and_number() == '0510705446'

# Generated at 2022-06-23 20:49:58.682053
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test for snils method of class RussiaSpecProvider.

    Test with assertion statement.
    """
    ru = RussiaSpecProvider()
    snils = ru.snils()
    assert len(snils) == 11
    assert isinstance(snils, str)


# Generated at 2022-06-23 20:50:00.737646
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    from mimesis.providers.russia import RussiaSpecProvider
    provider = RussiaSpecProvider()
    result = provider.kpp()
    assert isinstance(result, str) and len(result) == 9


# Generated at 2022-06-23 20:50:02.451496
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    assert len(RussiaSpecProvider().generate_sentence().split(' ')) == 4



# Generated at 2022-06-23 20:50:04.705185
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    provider = RussiaSpecProvider()
    assert provider.passport_number().isdigit()


# Generated at 2022-06-23 20:50:09.658608
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    """Test method bic of class RussiaSpecProvider
    """
    rusprov = RussiaSpecProvider()
    actual = rusprov.bic()
    assert len(actual) == 9
    for i in range(len(actual)):
        assert actual[i] in ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']


# Generated at 2022-06-23 20:50:18.698221
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    from mimesis.schema import Field
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Format

    class MySchema(object):
        sentence = Field('sentence')

    rus = RussiaSpecProvider()
    my_schema = MySchema()

    test_words = {'Что', 'бы', 'Вы', 'сказали'}

    for i in range(1000):
        sentence = rus.generate_sentence()
        for word in sentence.split():
            assert word in test_words

    sentence = my_schema.sentence(formatter=Format.WORD)
    assert sentence not in test_words

    sentence = my_schema.sentence(formatter=Format.WORD)
    assert isinstance

# Generated at 2022-06-23 20:50:22.078307
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    r = RussiaSpecProvider(seed = 0)
    # Test with default arguments
    res = r.snils()
    assert res == '64405684600'
    # Test with valid arguments
    # ...

    # Test with invalid arguments
    # ...

# Generated at 2022-06-23 20:50:23.730152
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia = RussiaSpecProvider()
    assert(russia.snils())

# Generated at 2022-06-23 20:50:27.583057
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Test the method ogrn of class RussiaSpecProvider."""
    import re

    provider = RussiaSpecProvider()
    ogrn = provider.ogrn()

    assert len(ogrn) == 13
    assert re.match(r'^\d{13}$', ogrn) is not None


# Generated at 2022-06-23 20:50:31.741538
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    from mimesis.providers.person import Person

    person = Person('ru')
    passport_number = person.passport_number()

    assert len(str(passport_number)) == 6
    assert ' ' not in passport_number
    assert passport_number.isdigit()



# Generated at 2022-06-23 20:50:43.100615
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    from mimesis.providers.person import Person
    from mimesis.schema import Field

    class Human(Person):
        nationality = Field('russia_provider.nationality')
        name = Field('person.name', gender=None)
        patronymic = Field('russia_provider.patronymic')
        surname = Field('person.surname')
        snils = Field('russia_provider.snils')
        inn = Field('russia_provider.inn')
        ogrn = Field('russia_provider.ogrn')
        series_and_number = Field('russia_provider.series_and_number')
        generate_sentence = Field('russia_provider.generate_sentence')

    person = Human()
    print(person.generate_sentence())


# Generated at 2022-06-23 20:50:45.933324
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    # Create an instance of class RussiaSpecProvider
    test_RussiaSpecProvider = RussiaSpecProvider()

    # Show kpp
    print('test_RussiaSpecProvider.kpp(): ' + test_RussiaSpecProvider.kpp())


# Generated at 2022-06-23 20:50:48.670919
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    instance_1 = RussiaSpecProvider()
    assert isinstance(instance_1, RussiaSpecProvider)
    instance_2 = RussiaSpecProvider.__new__(RussiaSpecProvider)
    assert isinstance(instance_2, RussiaSpecProvider)



# Generated at 2022-06-23 20:50:55.020879
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    assert RussiaSpecProvider()
    assert hasattr(RussiaSpecProvider, 'name')
    assert hasattr(RussiaSpecProvider, 'Meta')
    assert hasattr(RussiaSpecProvider, 'generate_sentence')
    assert hasattr(RussiaSpecProvider, 'patronymic')
    assert hasattr(RussiaSpecProvider, 'passport_series')
    assert hasattr(RussiaSpecProvider, 'passport_number')
    assert hasattr(RussiaSpecProvider, 'series_and_number')
    assert hasattr(RussiaSpecProvider, 'snils')
    assert hasattr(RussiaSpecProvider, 'inn')
    assert hasattr(RussiaSpecProvider, 'ogrn')
    assert hasattr(RussiaSpecProvider, 'bic')
    assert hasattr(RussiaSpecProvider, 'kpp')


# Generated at 2022-06-23 20:51:04.978114
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    rsp = RussiaSpecProvider()
    print(rsp.generate())
    #print(rsp.generate_sentence())
    #print(rsp.patronymic(Gender.MALE))
    #print(rsp.passport_number())
    #print(rsp.passport_series())
    #print(rsp.series_and_number())
    #print(rsp.snils())
    print(rsp.inn())
    #print(rsp.ogrn())
    #print(rsp.bic())
    #print(rsp.kpp())

if __name__ == "__main__":
    test_RussiaSpecProvider()

# Generated at 2022-06-23 20:51:07.129167
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    russia = RussiaSpecProvider()
    for i in range(0, 100):
        print(russia.kpp())



# Generated at 2022-06-23 20:51:13.676583
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    # Generate 1 ogrn and check that it is correct
    ogrn = RussiaSpecProvider().ogrn()
    ogrn_number = int(ogrn[:-1])
    # The last digit of the ogrn must be equal to the remainder of the division of the first 12 digits by 11
    assert int(ogrn[-1]) == ogrn_number % 11 % 10


# Generated at 2022-06-23 20:51:17.309844
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    """Test for method bic of class RussiaSpecProvider."""
    from mimesis.providers.finance import Finance
    f = Finance('ru')
    assert RussiaSpecProvider().bic() == f.bic()


# Generated at 2022-06-23 20:51:22.181746
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    """Unit test for method generate_sentence of class RussiaSpecProvider."""
    provider = RussiaSpecProvider(seed=43245234)
    assert provider.generate_sentence() == 'Представьте себе женщину Софью Владимировну Прокофьеву молодую женщину'


# Generated at 2022-06-23 20:51:25.717866
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Unit test for method inn of class RussiaSpecProvider"""
    RussiaSpecProvider(seed=12345).inn() == "5010456213"


# Generated at 2022-06-23 20:51:28.426838
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    
    import pytest

    assert (Russian.series_and_number()) == "57 16 805199."


# Generated at 2022-06-23 20:51:29.986253
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    for i in range(10):
        print(RussiaSpecProvider().passport_number())

# Generated at 2022-06-23 20:51:32.796513
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Test generate passport series."""
    spec = RussiaSpecProvider()
    spec.seed(0)
    assert spec.passport_series(year=2018) == '17 18'


# Generated at 2022-06-23 20:51:38.698622
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Unit test for method series_and_number of class RussiaSpecProvider.

    1. Generate 5000 series_and_number for Russia:
        1.1. Check, that series_and_number looks like "57 16 805199"
    2. Generate 5000 series_and_number for Russia, but specify year (2017):
        2.1. Check, that series_and_number starts with "57 17"
    """
    r = RussiaSpecProvider()

    def check_series_and_number(series_and_number):
        return series_and_number[-6:] == \
            str(r.passport_number()) and series_and_number[-10:-6].isdecimal()

    for _ in range(0, 5000):
        assert check_series_and_number(r.series_and_number())


# Generated at 2022-06-23 20:51:41.596205
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    import re
    n = 100   # number of tests
    for i in range(n):
        test = RussiaSpecProvider().kpp()
        # check if test matches the pattern of kpp
        pattern = re.compile('^\d{9}$')
        assert re.fullmatch(pattern, test) is not None, "Test failed!"

# Generated at 2022-06-23 20:51:50.005390
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """Unit test for method kpp.

    :return:
    :rtype:
    """
    r = RussiaSpecProvider()

    for i in range(0, 1000):
        kpp = r.kpp()
        assert len(kpp) == 9

        # Check tax code
        tax_code = kpp[0:4]
        assert int(tax_code) > 0 and int(tax_code) < 9999

        # Check region
        region = kpp[4:6]
        assert region == '77'

        # Check register number
        register = kpp[6:9]
        assert int(register) > 0 and int(register) < 999

# Generated at 2022-06-23 20:51:55.571240
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test method snils in RussiaSpecProvider class."""
    x = RussiaSpecProvider()
    assert x.meta.name == 'russia_provider'
    assert x.meta.seed == x._seed
    assert x.meta.locale == 'ru'
    assert len(x.snils()) == 11
    assert x.snils().isdigit()
    print(x.snils())


# Generated at 2022-06-23 20:51:57.285763
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    # TODO: how to test this? 
    # assert result == expected
    pass


# Generated at 2022-06-23 20:52:06.610531
# Unit test for method patronymic of class RussiaSpecProvider

# Generated at 2022-06-23 20:52:08.875795
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    bic = RussiaSpecProvider().bic()
    assert type(bic) == str
    assert len(bic) == 9


# Generated at 2022-06-23 20:52:10.802302
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    rus = RussiaSpecProvider()
    for _ in range(0, 10):
        print(rus.inn())


# Generated at 2022-06-23 20:52:13.441354
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    r = RussiaSpecProvider()
    kpps = []
    for i in range(0, 1000):
        kpps.append(r.kpp())
    print(kpps)

# Generated at 2022-06-23 20:52:15.031428
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    r = RussiaSpecProvider(seed=None)
    print(r.passport_series())


# Generated at 2022-06-23 20:52:17.057471
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    seed = 1234
    sp = RussiaSpecProvider(seed)
    assert sp.seed == seed

# Generated at 2022-06-23 20:52:27.395009
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    russian_kpp = RussiaSpecProvider(seed=12345)
    kpp = russian_kpp.kpp()
    assert kpp in ['780089014', '780089018', '780089013', '780089015', '780089017']
    kpp = russian_kpp.kpp()
    assert kpp in ['770079017', '770079016', '770079015', '770079014', '770079013']
    kpp = russian_kpp.kpp()
    assert kpp in ['780079016', '780079015', '780079014', '780079013', '780079017']
    kpp = russian_kpp.kpp()

# Generated at 2022-06-23 20:52:29.860353
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    rsp = RussiaSpecProvider()
    result = rsp.passport_series()
    assert len(result.split()) == 2


# Generated at 2022-06-23 20:52:37.353454
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Unit test for method ogrn of class RussiaSpecProvider."""
    from mimesis.providers import RussiaSpecProvider

    rus_spec = RussiaSpecProvider()
    for _ in range(0, 100):
        ogrn = rus_spec.ogrn()
        assert isinstance(ogrn, str)
        assert len(ogrn) == 13
        assert ogrn[12] == str(int(ogrn[:12]) % 11 % 10)



# Generated at 2022-06-23 20:52:40.892858
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    russian_provider = RussiaSpecProvider()
    assert russian_provider.provider_name == "russia_provider"
    assert len(russian_provider.snils()) != 0

#Unit test for method generate_sentence of class RussiaSpecProvider

# Generated at 2022-06-23 20:52:41.935300
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    assert len(RussiaSpecProvider().kpp()) == 9

# Generated at 2022-06-23 20:52:48.440838
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    import pytest
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender

    seed = {"random": {"seed": 10}}  # 'random seed'.
    rsp = RussiaSpecProvider(seed=seed)

    _series_and_number = rsp.series_and_number()
    assert _series_and_number == "45 15 615354"
    assert type(_series_and_number) == str

    _series_and_number = rsp.series_and_number()
    assert _series_and_number == "11 16 948973"
    assert type(_series_and_number) == str

# Generated at 2022-06-23 20:52:51.042807
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Test for method series_and_number of class RussiaSpecProvider."""
    russ = RussiaSpecProvider()
    assert len(russ.series_and_number()) == 11



# Generated at 2022-06-23 20:52:53.169377
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    rp = RussiaSpecProvider()
    kpp = rp.kpp()
    assert isinstance(kpp, str)
    assert len(kpp) == 9


# Generated at 2022-06-23 20:52:57.869477
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test that method snils generates a valid snils."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    # isinstance(snils, str)
    # snils is not "00000000000"
    # len(snils) == 11
    # str(snils).count("0") != 11
    # str(snils).count("9") != 11
    snils


test_RussiaSpecProvider_snils()

# Generated at 2022-06-23 20:53:00.287340
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    assert len(russia.passport_series()) == 5
    assert type(russia.passport_series()) == str


# Generated at 2022-06-23 20:53:10.937694
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    from mimesis.providers.russia import RussiaSpecProvider
    from mimesis.providers.russia.kpp import KPP

    russia_providers_inn = RussiaSpecProvider()
    assert len(russia_providers_inn.inn()) == 10

    # Assert that each digit of the inn is less than 10
    for digit in russia_providers_inn.inn():
        assert int(digit) < 10

    # Assert that each inn has a unique check sum
    inn_list = set(russia_providers_inn.inn() for _ in range(1000))
    assert len(inn_list) == 1000
    assert not any(len(inn) != 10 for inn in inn_list)

    # Assert the validity of the inn by checking its sum

# Generated at 2022-06-23 20:53:12.355180
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    rp = RussiaSpecProvider()
    assert rp.passport_series()

# Generated at 2022-06-23 20:53:14.375777
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    from mimesis.enums import Gender

    sp = RussiaSpecProvider()
    assert len(sp.series_and_number()) == 11

# Generated at 2022-06-23 20:53:15.786394
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    x = RussiaSpecProvider()
    inn = x.inn()
    assert len(inn) == 10


# Generated at 2022-06-23 20:53:21.240070
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    # Initialize class
    pr = RussiaSpecProvider()
    # Get random sentence
    random_sentence = pr.generate_sentence()
    # Check that random sentence is not None
    assert(random_sentence != None)
    # Check that random sentence is str
    assert(type(random_sentence) == str)


# Generated at 2022-06-23 20:53:24.069711
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    rsp = RussiaSpecProvider()
    kpp = rsp.kpp()
    assert len(kpp) == 9


# Generated at 2022-06-23 20:53:29.840207
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    r = RussiaSpecProvider()
    d = {}
    for i in range(0, 10000):
        bic = r.bic()
        print(bic)
        if bic not in d:
            d[bic] = 1
        else:
            d[bic] += 1
    print(d)


# Generated at 2022-06-23 20:53:32.242716
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    provider = RussiaSpecProvider()
    result = provider.series_and_number()
    assert len("57 16 805199") == len(result)



# Generated at 2022-06-23 20:53:36.356227
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Unit test for RussiaSpecProvider.passport_series."""
    provider = RussiaSpecProvider()
    result = provider.passport_series()
    expected = str
    assert isinstance(result, expected)
    assert len(result) == 4


# Generated at 2022-06-23 20:53:38.131041
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    r = RussiaSpecProvider()
    assert r.provider == 'russia_provider'


# Generated at 2022-06-23 20:53:43.266811
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    from mimesis import RussiaSpecProvider
    from mimesis.enums import Gender
    from mimesis.typing import Seed

    doe = RussiaSpecProvider(seed=Seed(42))
    series = doe.passport_series()
    assert series == '10 19'

    series = doe.passport_series(year=16)
    assert series == '75 16'

test_RussiaSpecProvider_passport_series()


# Generated at 2022-06-23 20:53:47.107220
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Unit test for method passport_series of class RussiaSpecProvider."""

    provider = RussiaSpecProvider()
    assert len(provider.passport_series()) == 5
    assert type(provider.passport_series(2000)) is str


# Generated at 2022-06-23 20:53:55.085612
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    obj = RussiaSpecProvider()
    assert (obj.patronymic(Gender.MALE) in obj._data['patronymic'][Gender.MALE])
    assert (obj.patronymic(Gender.FEMALE) in obj._data['patronymic'][Gender.FEMALE])
    assert (obj.patronymic(None) in obj._data['patronymic'][Gender.MALE] or obj.patronymic(None) in obj._data['patronymic'][Gender.FEMALE])

# Generated at 2022-06-23 20:53:56.982557
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Test_series_and_number."""
    provider = RussiaSpecProvider()
    passport = provider.series_and_number()
    print(passport)


# Generated at 2022-06-23 20:54:09.303588
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    from mimesis.enums import Gender
    from mimesis.specifiers import RussiaSpecProvider
    rus_spec_provider = RussiaSpecProvider()
    assert rus_spec_provider.__class__.__name__ == 'RussiaSpecProvider'
    assert rus_spec_provider.__init__() == None
    assert rus_spec_provider.__init__(seed='') == None
    assert rus_spec_provider.generate_sentence() == None
    assert rus_spec_provider.patronymic() == None
    assert rus_spec_provider.passport_series() == None
    assert rus_spec_provider.passport_number() == None
    assert rus_spec_provider.series_and_number() == None
    assert rus_spec_

# Generated at 2022-06-23 20:54:19.332207
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    rus = RussiaSpecProvider()
    bics = []
    for i in range(0, 10):
        bics.append(rus.bic())
    assert bics[0] == '041010339'
    assert bics[1] == '044010597'
    assert bics[2] == '043005593'
    assert bics[3] == '046010124'
    assert bics[4] == '043025986'
    assert bics[5] == '044025575'
    assert bics[6] == '041010889'
    assert bics[7] == '044010211'
    assert bics[8] == '042010789'
    assert bics[9] == '044025116'

# Generated at 2022-06-23 20:54:23.606617
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
        russiaspecprovider = RussiaSpecProvider()
        kpp_1 = russiaspecprovider.kpp()
        kpp_2 = russiaspecprovider.kpp()
        assert len(kpp_1) == 9 and len(kpp_2) == 9
        assert type(kpp_1) == str and type(kpp_2) == str


# Generated at 2022-06-23 20:54:29.852395
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    ru_provider = RussiaSpecProvider()
    ru_provider.seed(12345)
    assert ru_provider.generate_sentence() == 'Он не открыл окно, потому что погода хорошая.'

# Generated at 2022-06-23 20:54:32.399260
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    provider = RussiaSpecProvider()
    assert provider.ogrn() != provider.ogrn()
    assert provider.ogrn() != provider.ogrn()
    assert provider.ogrn() != provider.ogrn()


# Generated at 2022-06-23 20:54:34.225453
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    """Test for constructor of class 'RussiaSpecProvider'."""
    assert RussiaSpecProvider()


# Generated at 2022-06-23 20:54:40.983423
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender
    from test_utils import get_random_result_from_function_and_verify_against_enum

    def test_function(pattern=None):
        return RussiaSpecProvider().patronymic(pattern)

    get_random_result_from_function_and_verify_against_enum(
        function=test_function,
        enum=Gender,
        patterns=None,
        count=100
    )



# Generated at 2022-06-23 20:54:43.093305
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    doc = RussiaSpecProvider()
    print(doc.ogrn())


# Generated at 2022-06-23 20:54:45.225674
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r=RussiaSpecProvider()
    print("snils = ", r.snils())


# Generated at 2022-06-23 20:54:47.167194
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    g = RussiaSpecProvider()
    assert len(g.bic()) == 9


# Generated at 2022-06-23 20:54:51.001705
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    prov = RussiaSpecProvider()
    result = prov.kpp()
    assert all([result[i: i + 1].isnumeric() for i in range(len(result))])
    assert len(result) == 9


# Generated at 2022-06-23 20:54:54.368642
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    assert RussiaSpecProvider().passport_series() in ('02 15', '34 10', '75 17')
    assert RussiaSpecProvider().passport_series(year = 2010) in ('02 10', '34 10', '75 10')

# Generated at 2022-06-23 20:54:57.620958
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    import unittest
    rus = RussiaSpecProvider(seed=11111)
    inn = rus.snils()
    unittest.TestCase().assertEqual(inn, '41917492600')

# Generated at 2022-06-23 20:55:00.442850
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    """ Method test for method bic of class RussiaSpecProvider. """
    russia = RussiaSpecProvider()
    for i in range(4):
        print(russia.bic())


# Generated at 2022-06-23 20:55:02.681133
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    r = RussiaSpecProvider()
    #print(r.passport_series())
    assert r.passport_series() != ''


# Generated at 2022-06-23 20:55:04.685667
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    spec_provider = RussiaSpecProvider()
    assert spec_provider.__class__.__name__ is 'RussiaSpecProvider'


# Generated at 2022-06-23 20:55:08.489420
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    num = RussiaSpecProvider().passport_number()
    if num == None:
        print("There is no number")
    if not isinstance(num, int):
        print("The number is not an integer")
    if not 100000 <= num <= 999999:
        print("The number is not in the range from 100000 to 999999")
    return num


# Generated at 2022-06-23 20:55:11.888606
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    r = RussiaSpecProvider()
    assert r.patronymic(gender=Gender.FEMALE) in r._data['patronymic'][Gender.FEMALE]
    assert r.patronymic(gender=Gender.MALE) in r._data['patronymic'][Gender.MALE]



# Generated at 2022-06-23 20:55:15.671788
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    print("testing method generate_sentence of class RussiaSpecProvider")
    ru = RussiaSpecProvider()
    sample = ru.generate_sentence()
    if sample in ru._data['sentence']['head'] \
            + ru._data['sentence']['p1'] + ru._data['sentence']['p2'] + ru._data['sentence']['tail']:
        print(sample)
        return 0
    else:
        print(sample)
        return 1



# Generated at 2022-06-23 20:55:18.384565
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    r = RussiaSpecProvider()
    r.seed(seed=2)
    actual = r.ogrn()
    expected = "1260311337561"
    assert actual == expected


# Generated at 2022-06-23 20:55:20.519635
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    tester = RussiaSpecProvider()
    test = tester.passport_series()
    assert test != ''
    assert isinstance(test, str)


# Generated at 2022-06-23 20:55:30.799540
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """
    Unit test for method series_and_number of
    class RussiaSpecProvider.
    """
    provider = RussiaSpecProvider()
    series_and_number = provider.series_and_number()
    assert len(series_and_number) == 11

    # Test of the values of the method
    assert series_and_number[0:2].isdigit()
    assert 0 < int(series_and_number[0:2]) < 100
    assert int(series_and_number[2]) == 0

    # Test of the values of the method
    assert series_and_number.isdigit()
    assert not series_and_number[2] == 0

    # Test of the values of the method
    assert 1 <= int(series_and_number[-6]) <= 9

# Generated at 2022-06-23 20:55:33.422478
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider()
    result = provider.bic()
    # TODO: perform insight unit test for bic method
    assert len(result) == 9


# Generated at 2022-06-23 20:55:35.056294
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    russian_provider = RussiaSpecProvider()
    assert len(russian_provider.bic()) == 9

# Generated at 2022-06-23 20:55:37.929742
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    provider = RussiaSpecProvider()
    for _ in range(10):
        inn = provider.inn()
        print(inn)
        assert len(inn) == 10


# Generated at 2022-06-23 20:55:42.911389
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    from mimesis.builtins import RussiaSpecProvider as RSP
    rd = RSP()

    assert rd.patronymic()
    assert rd.patronymic(Gender.MALE)
    assert rd.patronymic(Gender.FEMALE)


# Generated at 2022-06-23 20:55:49.000807
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    from mimesis.builtins import RussiaSpecProvider
    ru = RussiaSpecProvider()
    print(ru.generate_sentence())
    # Result is 
    # Много данных в рамках применения их при подготовке специалистов


# Generated at 2022-06-23 20:55:58.378997
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test snils method of class RussiaSpecProvider"""
    from mimesis.enums import Gender
    from mimesis.providers.person.russia import RussiaSpecProvider
    p = RussiaSpecProvider()
    assert p.patronymic(Gender.MALE) == 'Иванович'
    assert p.patronymic(Gender.FEMALE) == 'Ивановна'
    assert p.patronymic(Gender.NOT_KNOWN) in ['Иванович', 'Ивановна']
    assert p.patronymic() in ['Иванович', 'Ивановна']
    assert p.passport_series() == '56 04'

# Generated at 2022-06-23 20:56:02.474018
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    from mimesis.builtins import RussiaSpecProvider
    data_provider = RussiaSpecProvider()
    kpp = data_provider.kpp()
    assert len(kpp) == 9


# Generated at 2022-06-23 20:56:12.424721
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """Unit test for метод kpp класса RussiaSpecProvider."""
    import unittest
    from mimesis.providers.russia_provider import RussiaSpecProvider as rsp
    r = rsp()
    ukpp = r.kpp()
    assert (len(ukpp) == 9)
    assert (ukpp[:3].isdigit() and ukpp[-3:].isdigit())
    assert (ukpp[3] == ukpp[4])
    assert (ukpp[4] in ('0', '1'))
    assert (ukpp[5:7].isdigit())
    assert (ukpp[7] == ukpp[8])
    assert (ukpp[8] in ('1', '2', '3', '4'))
   

# Generated at 2022-06-23 20:56:15.741675
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    russia_spec_provider = RussiaSpecProvider()
    expected_result = '4336118209'
    result = russia_spec_provider.inn()
    assert result == expected_result


# Generated at 2022-06-23 20:56:17.452066
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    for _ in range(20):
        assert type(RussiaSpecProvider().passport_series()) == str


# Generated at 2022-06-23 20:56:27.968442
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    address = Address('ru')
    person = Person('ru')
    spec = RussiaSpecProvider()
    series = spec.passport_series()
    assert len(series) == 5
    print("");
    print("### Passport Series Unit Test ###");
    print("Generated Series: ", series);
    print("Generated Series Type: ", type(series));
    print("Generated Series Elements: ", "Country Code - ", series[0:2], ", Year - ", series[3:5]);
    print("");


# Generated at 2022-06-23 20:56:29.984681
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    s = RussiaSpecProvider()
    b = s.series_and_number()
    assert b == '57 16 805199'

# Generated at 2022-06-23 20:56:39.382063
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    # Create object instance
    rsp = RussiaSpecProvider()

    # Unit test for 1st method
    for i in range(0, 10):
        # Get value from 1st method
        value_of_method = rsp.series_and_number()

        # Check if value is not None
        assert(value_of_method is not None)
        # Check if value is string
        assert(isinstance(value_of_method, str))
        # Check if value is from a specified range
        assert(isinstance(int(value_of_method), int))
        assert(len(value_of_method) == 12)


# Generated at 2022-06-23 20:56:44.453580
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Function for testing method snils of class RussiaSpecProvider."""
    tmp_provider = RussiaSpecProvider(seed=42)
    tmp_snils = tmp_provider.snils()
    expected_snils = "41917492600"

    assert tmp_snils == expected_snils



# Generated at 2022-06-23 20:56:48.987212
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    # Pattern of verification
    pattern = re.compile('^[0-9]{9}$')

    rsp = RussiaSpecProvider()
    bic = rsp.bic()

    assert pattern.match(bic) is not None



# Generated at 2022-06-23 20:56:52.531764
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    # Setup
    raser = RussiaSpecProvider()
    # Exercise
    assert( len(raser.kpp()) == 9 )
    # Verify
    assert( raser.kpp().isdigit() )
    # Cleanup - none necessary

# Generated at 2022-06-23 20:56:55.656465
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    rus = RussiaSpecProvider()
    result = rus.inn()
    assert len(result) == 10
    assert result == '7736195777'


# Generated at 2022-06-23 20:56:58.571984
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    for i in range(7):
        assert RussiaSpecProvider().bic() == RussiaSpecProvider().bic()



# Generated at 2022-06-23 20:57:00.553725
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    inn = RussiaSpecProvider().inn()
    print(inn)
    assert len(inn) == 10


# Generated at 2022-06-23 20:57:03.205562
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    r = RussiaSpecProvider()
    result = r.kpp()
    assert result.__class__ == str
    assert len(result) == 9
    print('test_RussiaSpecProvider_kpp passed!')


# Generated at 2022-06-23 20:57:04.555479
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    russian_provider = RussiaSpecProvider()
    assert len(russian_provider.series_and_number()) == 13

# Generated at 2022-06-23 20:57:06.618926
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    from random import seed
    from mimesis import RussiaSpecProvider

    seed(9001)
    r = RussiaSpecProvider()
    for i in range(100):
        print(r.bic())

# Generated at 2022-06-23 20:57:10.700723
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    provider = RussiaSpecProvider()
    sentence1 = provider.generate_sentence()
    sentence2 = provider.generate_sentence()

    assert sentence1 != sentence2


# Generated at 2022-06-23 20:57:12.803411
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    test_provider = RussiaSpecProvider()
    result = test_provider.passport_number()
    assert len(str(result)) == 6
    assert isinstance(result, int)


# Generated at 2022-06-23 20:57:15.034587
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    # my_unit_test
    russia_provider = RussiaSpecProvider()
    assert len(russia_provider.series_and_number()) == 11



# Generated at 2022-06-23 20:57:16.974085
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    rs = RussiaSpecProvider()
    number = rs.passport_number()
    assert (len(str(number)) == 6), "Error: Passport number length incorrect"


# Generated at 2022-06-23 20:57:23.608647
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    from mimesis.providers.person import Person
    from mimesis.enums import Gender
    provider = Person('ru')
    sentence = provider.generate_sentence()
    man = provider.full_name(Gender.MALE)
    woman = provider.full_name(Gender.FEMALE)
    assert man in sentence or woman in sentence


# Generated at 2022-06-23 20:57:26.058676
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    provider = RussiaSpecProvider(seed=42)
    result = provider.passport_number()
    assert result == 560430


# Generated at 2022-06-23 20:57:30.883636
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    provider = RussiaSpecProvider(seed=1)
    passport_number_list = []
    for i in range(1, 10000):
        passport_number = provider.passport_number()
        assert len(str(passport_number)) == 6
        assert passport_number >= 100000
        assert passport_number <= 999999
        passport_number_list.append(passport_number)
    print('passport_number test passed')


# Generated at 2022-06-23 20:57:35.039660
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    ru = RussiaSpecProvider()
    sentence = ru.generate_sentence()
    assert isinstance(sentence, str)
    assert sentence != ru.generate_sentence()



# Generated at 2022-06-23 20:57:37.066504
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    rsp = RussiaSpecProvider()
    assert len(rsp.kpp()) == 9

# Generated at 2022-06-23 20:57:41.340838
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    """Test patronymic of class RussiaSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers.person.ru import RussiaSpecProvider
    rsp = RussiaSpecProvider()
    assert rsp.patronymic() in rsp._data['patronymic'][Gender.FEMALE]

