

# Generated at 2022-06-23 20:47:45.183947
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    from mimesis.providers import RussiaSpecProvider
    rsp = RussiaSpecProvider()
    print(rsp.bic())
    print(len(rsp.bic()))    
    

# Generated at 2022-06-23 20:47:47.852218
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    rp = RussiaSpecProvider()
    assert isinstance(rp.passport_number(), str) == True
    assert len(rp.passport_number()) == 6

# Generated at 2022-06-23 20:47:49.889056
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    print('Generate sentence: ', RussiaSpecProvider().generate_sentence())


# Generated at 2022-06-23 20:47:50.413196
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    pass

# Generated at 2022-06-23 20:47:51.688505
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    rsp = RussiaSpecProvider()
    pass


# Generated at 2022-06-23 20:48:02.177169
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    provider = RussiaSpecProvider()

    results = {
        Gender.MALE: [provider.patronymic(Gender.MALE) for _ in range(10)],
        Gender.FEMALE: [provider.patronymic(Gender.FEMALE) for _ in range(10)],
        Gender.NOT_APPLICABLE: [provider.patronymic(Gender.NOT_APPLICABLE) for _ in range(10)],
    }

    for gender in Gender:
        assert len(results[gender]) == 10
        for result in results[gender]:
            assert isinstance(result, str)
            assert result.endswith(provider.get_data('patronymics')[gender])
            assert result.startswith(provider.get_data('first_names')[gender])

# Generated at 2022-06-23 20:48:04.246375
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    assert len(r.snils()) == 11
    print(r.snils())

# Generated at 2022-06-23 20:48:06.003184
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    result = RussiaSpecProvider.passport_series()
    assert result == '02 15'


# Generated at 2022-06-23 20:48:11.771513
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Test that the series and number generated is valid."""
    from mimesis.providers import RussiaSpecProvider

    res = RussiaSpecProvider().series_and_number()
    assert res[:2].isalpha()
    assert res[2] == " "
    assert res[3:5].isnumeric()
    assert res[5] == " "
    assert res[6:].isnumeric()
    assert len(res) == 11



# Generated at 2022-06-23 20:48:14.979167
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    RussiaSP = RussiaSpecProvider(seed=42)
    assert RussiaSP.ogrn() == '4715113303725'


# Generated at 2022-06-23 20:48:16.784080
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    r = RussiaSpecProvider()
    assert r.generate_sentence()



# Generated at 2022-06-23 20:48:18.075792
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    assert len(RussiaSpecProvider().kpp()) == 9


# Generated at 2022-06-23 20:48:20.202600
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test for method snils of class RussiaSpecProvider."""
    for i in range(10):
        rsp = RussiaSpecProvider()
        print(rsp.snils())


# Generated at 2022-06-23 20:48:21.536681
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    r = RussiaSpecProvider()
    print(r.generate_sentence())

# Generated at 2022-06-23 20:48:23.177356
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    r = RussiaSpecProvider()
    assert r.series_and_number()

# Generated at 2022-06-23 20:48:24.854418
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    provider = RussiaSpecProvider()
    passport_series = provider.passport_series()
    if len(passport_series) == 5:
        return True
    else:
        return False


# Generated at 2022-06-23 20:48:26.133440
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():

    rus_sp = RussiaSpecProvider()
    for i in range(10):
        assert type(rus_sp.generate_sentence()) == str


# Generated at 2022-06-23 20:48:30.284921
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    assert RussiaSpecProvider.Meta.name == "russia_provider"
    rsp = RussiaSpecProvider()
    r = rsp.series_and_number()
    if r[0] == "0":
        assert r[:2].isdigit()
    else:
        assert r[:2].isdigit()

# Generated at 2022-06-23 20:48:32.759946
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    c = RussiaSpecProvider()
    c.seed(123)
    number = c.passport_number()
    assert number == 829493


# Generated at 2022-06-23 20:48:35.232751
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Testing method ``ogrn`` of class ``RussiaSpecProvider``."""
    a = RussiaSpecProvider()
    print(a.ogrn())

# Generated at 2022-06-23 20:48:36.835659
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    rp = RussiaSpecProvider()
    assert rp is not None

# Generated at 2022-06-23 20:48:37.865068
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    print("Test snils: ", provider.snils())


# Generated at 2022-06-23 20:48:39.251666
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    assert len(provider.snils()) == 11

# Generated at 2022-06-23 20:48:43.583741
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():

    provider = RussiaSpecProvider()
    assert provider.snils() is not None
    assert provider.inn() is not None
    assert provider.ogrn() is not None
    assert provider.bic() is not None
    assert provider.series_and_number() is not None
    assert provider.kpp() is not None

# Generated at 2022-06-23 20:48:45.275441
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider()
    result = provider.bic()
    assert len(result) == 9
    assert result.isdigit()

# Generated at 2022-06-23 20:48:50.064606
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    """Unit test for constructor of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    assert isinstance(provider, RussiaSpecProvider)
    assert isinstance(provider, BaseSpecProvider)

# Generated at 2022-06-23 20:48:51.899476
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    bic = RussiaSpecProvider().bic()
    assert len(bic) == 9


# Generated at 2022-06-23 20:49:00.401875
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    
    from mimesis.providers.address import Address

    russ = RussiaSpecProvider('en')
    
    russ.random.seed(0)

# Generated at 2022-06-23 20:49:02.175240
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    rsp = RussiaSpecProvider()
    assert isinstance(rsp.generate_sentence(), str) == True


# Generated at 2022-06-23 20:49:13.352026
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """Test RussiaSpecProvider.kpp()
    This is a unit test for method kpp of class RussiaSpecProvider
    :return:
    """
    from mimesis import RussiaSpecProvider
    import json
    import os

    static_data_file = 'static_data_for_tests/RussiaSpecProvider.json'
    this_folder_path = os.path.dirname(os.path.abspath(__file__))
    static_data_file_path = os.path.join(this_folder_path, static_data_file)

    with open(static_data_file_path, 'r', encoding='utf-8') as f:
        static_data = json.load(f)

    kpp_list = static_data['kpp_list']

    russia = RussiaSpecProvider()


# Generated at 2022-06-23 20:49:20.969873
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Unit test for method ``series_and_number`` of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    for _ in range(10):
        ssn = rsp.series_and_number()
        assert (len(ssn) == 10)
        assert (int(ssn[6:8]) > 18)
        assert (int(ssn[6:8]) < 99)
        assert (int(ssn[:2]) < 99)
        assert (int(ssn[:2]) > 0)
        assert (int(ssn[2:4]) <= 99)
        assert (int(ssn[2:4]) > 0)
        assert (int(ssn[4:10]) < 1000000)
        assert (int(ssn[4:10]) > 100000)

# Generated at 2022-06-23 20:49:27.207731
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """
    Test RussiaSpecProvider's method ogrn.
    """
    # Create instance of RussiaSpecProvider
    russian_provider = RussiaSpecProvider()
    # Create list of ogrns
    ogrns = []
    # Generate 1000 ogrns with method ogrn
    for i in range(1000):
        ogrns.append(russian_provider.ogrn())
    # Test: there are no duplicates in the generated list of ogrns
    assert len(ogrns) == len(set(ogrns))

# Generated at 2022-06-23 20:49:30.081095
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Test method series_and_number of class RussiaSpecProvider"""
    russia = RussiaSpecProvider(seed=0)
    series_and_number = russia.series_and_number()
    assert series_and_number == '99 10 014422'

# Generated at 2022-06-23 20:49:31.715205
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """Test RussiaSpecProvider method kpp."""
    r = RussiaSpecProvider()
    assert len(r.kpp()) == 9

# Generated at 2022-06-23 20:49:33.344725
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    res = RussiaSpecProvider().series_and_number()
    print(res)
    assert len(res) == 11


# Generated at 2022-06-23 20:49:39.377827
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    """Testing for class RussiaSpecProvider."""
    us = RussiaSpecProvider()
    assert us.generate_sentence() != None
    assert us.patronymic() != None
    assert us.patronymic(Gender.MALE) != None
    assert us.patronymic(Gender.FEMALE) != None
    assert us.passport_series(year=1) != None
    assert us.passport_number() != None
    assert us.series_and_number() != None
    assert us.snils() != None
    assert us.inn() != None
    assert us.ogrn() != None
    assert us.bic() != None
    assert us.kpp() != None

# Generated at 2022-06-23 20:49:42.679077
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """Test.

    :return: None
    """
    russia = RussiaSpecProvider()
    kpp = russia.kpp()
    assert len(str(kpp)) == 9 and isinstance(kpp, str)


# Generated at 2022-06-23 20:49:44.249518
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    r = RussiaSpecProvider()
    inn = r.inn()
    assert len(inn) == 12


# Generated at 2022-06-23 20:49:45.033491
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    """Unit test for constructor of class RussiaSpecProvider"""
    provider = RussiaSpecProvider()
    assert provider



# Generated at 2022-06-23 20:49:48.482165
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    import re
    provider = RussiaSpecProvider()
    pattern = re.compile(r'^\d{10}$')
    inn = provider.inn()
    assert pattern.match(inn)

# Generated at 2022-06-23 20:49:52.838100
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    from mimesis.enums import Gender
    provider = RussiaSpecProvider()

    for gender in Gender:
        patronymic = provider.patronymic(gender)
        assert isinstance(patronymic, str)


# Generated at 2022-06-23 20:49:57.864017
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Test method passport_series of class 'RussiaSpecProvider'"""
    rsp = RussiaSpecProvider()
    year = rsp.random.randint(10,  18)
    passport_series = rsp.passport_series(year)
    print('Passport series is: ', passport_series)


# Generated at 2022-06-23 20:49:59.880448
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    provider = RussiaSpecProvider()

    assert len(provider.inn()) == 12
    assert provider.inn() != provider.inn()


# Generated at 2022-06-23 20:50:01.045018
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    assert RussiaSpecProvider(seed=42) is not None

# Unit test of method generate_sentence of class RussiaSpecProvider

# Generated at 2022-06-23 20:50:06.582917
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """Unit test for method kpp of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider(seed=5737095)
    kpp = rsp.kpp()
    kpp2 = rsp.kpp()
    assert kpp == '570098672' and kpp2 == '690020884'

# Generated at 2022-06-23 20:50:16.494390
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    try:
        from mimesis.providers.address import Address
    except ImportError:
        # NOTE: If module was not found, import it from providers
        from mimesis.builtins.providers.address import Address
    ru = RussiaSpecProvider()
    ru = ru.__dict__
    assert ru['locale'] == 'ru'
    ru['_pull'](ru['_datafile'])
    ru['generate_sentence']()
    ru['patronymic']()
    ru['patronymic'](Gender.MALE)
    ru['patronymic'](Gender.FEMALE)
    ru['patronymic'](Gender.NOT_SURE)
    ru['passport_series']

# Generated at 2022-06-23 20:50:18.794268
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
  for _ in range(100):
    print(RussiaSpecProvider().patronymic(Gender.MALE))
    print(RussiaSpecProvider().patronymic(Gender.FEMALE))
  print('Test is successful')

# Generated at 2022-06-23 20:50:19.966123
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    assert RussiaSpecProvider().kpp() == '560058652'

# Generated at 2022-06-23 20:50:24.284187
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    """Unit test for method patronymic of class RussiaSpecProvider."""
    print("\n==============method patronymic()==============\n")
    seed = "0xdeadbeef"
    provider = RussiaSpecProvider(seed=seed)
    print(provider.patronymic(Gender.MALE))
    print(provider.patronymic(Gender.FEMALE))
    print(provider.patronymic(Gender.NON_BINARY))
    print(provider.patronymic())


# Generated at 2022-06-23 20:50:31.453801
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test method snils."""
    from collections import Counter
    from mimesis.enums import Gender

    rsp = RussiaSpecProvider()
    for _ in range(1000):
        snils = rsp.snils()
        assert len(snils) == 11, 'Wrong lenght: {0}'.format(snils)
        assert snils.isdigit(), 'Wrong type of SNILS: {0}'.format(snils)
    # Test that all 9 first digits are unique (hopefully they are random)
    all_snils = [rsp.snils() for _ in range(1000)]
    snils_init = [x[0:9] for x in all_snils]
    c = Counter(snils_init)

# Generated at 2022-06-23 20:50:32.893357
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    a = RussiaSpecProvider()
    assert len(a.snils()) == 11

# Generated at 2022-06-23 20:50:35.194706
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    assert RussiaSpecProvider().cr_code() == '560058652'



# Generated at 2022-06-23 20:50:36.058347
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    r = RussiaSpecProvider()
    sn = r.series_and_number()
    print(sn)



# Generated at 2022-06-23 20:50:37.580409
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    r = RussiaSpecProvider()
    sentence = r.generate_sentence()
    len_sentence = len(sentence.split())
    assert(len_sentence > 20)
    assert(len_sentence < 30)

# Generated at 2022-06-23 20:50:39.883009
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    rsp = RussiaSpecProvider()
    actual = rsp.patronymic(Gender.MALE)
    assert isinstance(actual, str)

# Generated at 2022-06-23 20:50:44.490843
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    assert RussiaSpecProvider().patronymic(gender=Gender.MALE) in ('ич','ович','евич')
    assert RussiaSpecProvider().patronymic(gender=Gender.FEMALE) in ('на','овна','евна')


# Generated at 2022-06-23 20:50:48.083335
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    # Тестируем класс RussiaSpecProvider на метод series_and_number
    r = RussiaSpecProvider()
    if not r.series_and_number():
       raise Exception("incorrect result")


# Generated at 2022-06-23 20:50:49.521690
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    russian = RussiaSpecProvider()
    te_kpp = russian.kpp()
    print(te_kpp)

# Generated at 2022-06-23 20:50:50.848889
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    provider = RussiaSpecProvider()
    assert provider.kpp()


# Generated at 2022-06-23 20:50:53.935570
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Test passport_series."""
    # Series and number of passport
    data = "01 65 447684"

    u = RussiaSpecProvider()
    assert u.passport_series() == data[:5]

# Generated at 2022-06-23 20:51:00.673303
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    snils = RussiaSpecProvider().snils()
    snils_parts = snils.split(' ')
    int_snils_parts = [int(part) for part in snils_parts]
    control_sum = sum([int_snils_parts[i] * (9 - i) for i in range(9)]) % 101
    if not (control_sum == 100 or control_sum == 101):
        print('Incorrect snils control sum')
        assert False
    if not snils == '{}{}'.format(snils_parts[0], snils_parts[1]):
        print('Incorrect snils format')
        assert False

# Generated at 2022-06-23 20:51:05.435491
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    results = [
        (RussiaSpecProvider(seed=x).passport_series()[2:4]) for x
        in range(1, 10)
    ]
    assert results == [
        17, 16, 16, 18, 17,
        18, 17, 18, 17
    ]


# Generated at 2022-06-23 20:51:08.185562
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    snils = r.snils()
    assert snils[0] != 0
    assert len(snils) == 11
    assert snils.isdigit() == True


# Generated at 2022-06-23 20:51:11.745207
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    res = RussiaSpecProvider().snils()
    assert len(res) == 11
    assert int(res) > 0

# Generated at 2022-06-23 20:51:15.114419
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    """Unit test for method patronymic of class RussiaSpecProvider"""
    provider = RussiaSpecProvider()
    print(provider.patronymic(gender=Gender.FEMALE))
    return True


# Generated at 2022-06-23 20:51:17.798324
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Unittest for method passport_series of class RussiaSpecProvider."""
    r = RussiaSpecProvider()
    assert len(r.passport_series()) == 5



# Generated at 2022-06-23 20:51:19.442735
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    provider = RussiaSpecProvider()
    sentence = provider.generate_sentence()
    assert isinstance(sentence, str)


# Generated at 2022-06-23 20:51:23.025356
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    import re
    provider = RussiaSpecProvider()
    series_and_number = provider.series_and_number()
    assert bool(re.match(r'^[0-9]{4}[0-9]{6}$', series_and_number))

# Generated at 2022-06-23 20:51:27.803722
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    provider = RussiaSpecProvider()
    result = provider.passport_series()
    assert len(result) == 5
    assert result[0:2].isnumeric()
    assert result[3:5].isnumeric()


# Generated at 2022-06-23 20:51:28.738693
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    assert RussiaSpecProvider().passport_number() in range(100000, 999999)

# Generated at 2022-06-23 20:51:31.338887
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """Unit test for method passport_number of class RussiaSpecProvider."""
    fake = RussiaSpecProvider(seed=0)
    assert fake.passport_number() == 905626

# Generated at 2022-06-23 20:51:32.274244
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    RussiaSpecProvider()


# Generated at 2022-06-23 20:51:33.960029
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    data_provider = RussiaSpecProvider()
    assert data_provider.passport_number() > 100000

# Generated at 2022-06-23 20:51:35.854205
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Check that method "inn" returns a string with valid INN"""
    assert (len(RussiaSpecProvider().inn()) == 12)



# Generated at 2022-06-23 20:51:44.244657
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    from mimesis.enums import Gender
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.enums import DatetimeUnit
    from mimesis.providers.ru.person import Person
    from mimesis.schema import Field

    class _Person(Person):
        pass

    p = _Person()
    year = BaseProvider().datetime(
        datetime_unit=DatetimeUnit.YEAR,
        minimum=p.birthday.year,
        maximum=p.birthday.year + 30,
    )
    data = (
        (
            Field('passport_series', year=year),
            str,
        ),
        (
            Field('passport_series'),
            str,
        ),
    )

    for field, result_type in data:
        res

# Generated at 2022-06-23 20:51:46.017234
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    for _ in range(100):
        assert 100000 <= RussiaSpecProvider().passport_number() <= 999999

# Generated at 2022-06-23 20:51:48.063062
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    obj = RussiaSpecProvider()
    sentence = obj.generate_sentence()
    assert len(sentence.split()) == 4


# Generated at 2022-06-23 20:51:54.536328
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Test 1
    provider = RussiaSpecProvider()
    assert (provider.snils() == '02802396690')
    # Test 2
    provider = RussiaSpecProvider(seed=54321)
    assert (provider.snils() == '52605877568')
    # Test 3
    provider = RussiaSpecProvider(seed=12345)
    assert (provider.snils() == '15306908680')

# Generated at 2022-06-23 20:52:04.231559
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    obj = RussiaSpecProvider()
    kpp = obj.kpp()
    print(kpp)
    assert len(kpp) == 9
    assert str(kpp).isdigit()

# Generated at 2022-06-23 20:52:05.250391
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    """Unit test for method generate_sentence of class RussiaSpecProvider."""
    assert True

# Generated at 2022-06-23 20:52:06.796667
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    provider = RussiaSpecProvider()
    for i in range(10):
        print(i, provider.kpp())


# Generated at 2022-06-23 20:52:09.447195
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():

    provider = RussiaSpecProvider(seed=42)
    result = provider.snils()

    expected = '41917492600'
    assert result == expected


# Generated at 2022-06-23 20:52:12.575340
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    from mimesis.enums import Gender
    from mimesis.providers.address import Address
    gen = Address('ru')
    for i in range(0, 10):
        patronymic = gen.patronymic(Gender.FEMALE)
        print(patronymic)


# Generated at 2022-06-23 20:52:14.272005
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    provider = RussiaSpecProvider()
    assert provider.kpp() == '560058652'
    return


# Generated at 2022-06-23 20:52:15.891230
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    test = RussiaSpecProvider()
    assert(test)

# Generated at 2022-06-23 20:52:24.329031
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    # Define the args inside the method
    arg = None
    # Define the expected result
    expected_result = '02 15'
    # Define the expected type of result
    expected_result_type = str
    # Define the provider to test
    provider_to_test = RussiaSpecProvider()
    # Call the method on the provider to test
    result = provider_to_test.passport_series(arg)
    # Assert the type of the result is the one we expect
    assert type(result) is expected_result_type
    # Assert the result is the one we expect
    assert result == expected_result

# Generated at 2022-06-23 20:52:27.905559
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    from mimesis.providers.finance.russia_provider import RussiaSpecProvider as rspp
    aspp = rspp()
    print(aspp.passport_number())
    assert (len(aspp.passport_number()) == 6 and type(aspp.passport_number()) == str)

# Generated at 2022-06-23 20:52:29.565404
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    r = RussiaSpecProvider()
    assert r.passport_series() == '02 15'

# Generated at 2022-06-23 20:52:33.416943
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    """Test patronymic generation"""
    rsp = RussiaSpecProvider()
    rsp.patronymic(Gender.MALE)
    rsp.patronymic(Gender.FEMALE)


# Generated at 2022-06-23 20:52:36.762061
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    provider = RussiaSpecProvider()

    assert provider.passport_number() >= 100000 and provider.passport_number() <= 999999
    assert isinstance(provider.passport_number(), int)


# Generated at 2022-06-23 20:52:38.678702
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russian_povider = RussiaSpecProvider()
    assert len(russian_povider.snils()) == 11

# Generated at 2022-06-23 20:52:43.489007
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    r = RussiaSpecProvider(seed=42)
    # Test 1
    assert r.kpp() == '560058652'
    # Test 2
    assert r.kpp() == '560058652'
    # Test 3
    assert r.kpp() == '560058652'


    # Unit test for method bic of class RussiaSpecProvider

# Generated at 2022-06-23 20:52:45.210592
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    print('Inn: ', RussiaSpecProvider().inn())
    '''
    Inn:  7770552466
    '''


# Generated at 2022-06-23 20:52:52.648864
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    """Unit Test for constructor of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    assert hasattr(provider, "random")
    assert hasattr(provider, "datetime")
    assert hasattr(provider, "seed")
    assert hasattr(provider, "formatter")
    assert hasattr(provider, "locale")
    assert hasattr(provider, "Meta")
    assert hasattr(provider, "_data")


# Generated at 2022-06-23 20:52:56.397624
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    print("Testing RussiaSpecProvider_bic\n")
    rsp = RussiaSpecProvider()
    bic = rsp.bic()
    print('BIC = ' + bic)



# Generated at 2022-06-23 20:53:03.828083
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    from mimesis.builtins.ru.russia import RussiaSpecProvider
    provider = RussiaSpecProvider()

    year = provider.random.randint(10, 18)
    region = provider.random.randint(1, 99)

    p = provider.passport_series(year)
    assert p[0:2] == '{:02}'.format(region)
    assert p[3:] == '{:02}'.format(year)


# Generated at 2022-06-23 20:53:05.732578
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    rsp = RussiaSpecProvider()
    assert rsp.kpp() == '029002400'



# Generated at 2022-06-23 20:53:10.417596
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """Test method passport_number of class RussiaSpecProvider"""
    from mimesis.builtins.russia import RussiaSpecProvider
    test_number = RussiaSpecProvider().passport_number()
    assert type(test_number) == int, "Passport number should be an integer"
    assert 0 < len(str(test_number)) <= 6, \
        "Passport number should have 6 digits"

# Generated at 2022-06-23 20:53:15.130087
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """
    Testing of method inn from class RussiaSpecProvider.
    """
    russia = RussiaSpecProvider()
    assert len(russia.inn()) == 12
    assert RussiaSpecProvider().inn() != RussiaSpecProvider().inn()


# Generated at 2022-06-23 20:53:21.300968
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    print("\nRunning unit test for method passport_series() of class RussiaSpecProvider")
    rp = RussiaSpecProvider()
    # series = rp.passport_series(year=10)
    series = rp.passport_series()
    if isinstance(series, str):
        print("Passed\n")
    else:
        print("Failed\n")


# Generated at 2022-06-23 20:53:28.277868
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    from mimesis.enums import Gender
    from mimesis.providers.russia import RussiaSpecProvider
    import re

    r = RussiaSpecProvider()
    result = r.inn()
    assert re.match(r'\d{10}', result)

    r = RussiaSpecProvider()
    result = r.inn()
    assert re.match(r'\d{10}', result)

    r = RussiaSpecProvider()
    result = r.inn()
    assert re.match(r'\d{10}', result)


# Generated at 2022-06-23 20:53:29.544892
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    assert len(RussiaSpecProvider.bic()) == 9


# Generated at 2022-06-23 20:53:37.022418
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    # Create a instance of RussiaSpecProvider
    rsp = RussiaSpecProvider()

    # Generate OGRN number
    ogrn = rsp.ogrn()

    # Get last digit of OGRN number
    ogrn_last_digit = int(ogrn[-1])

    # Get OGRN numbe without last digit
    ogrn_without_last_digit = int(ogrn[:-1])

    # Check for the last digit of OGRN number
    assert ogrn_last_digit == ogrn_without_last_digit % 11 % 10

# Generated at 2022-06-23 20:53:39.418295
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()
    assert(rsp.snils() != rsp.snils() or rsp.snils() == rsp.snils())


# Generated at 2022-06-23 20:53:42.895481
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Test series_and_number."""
    sample = ['13 12 749691', '07 15 170879', '39 16 738894']
    provider = RussiaSpecProvider()
    for _ in range(0, 3):
        result = provider.series_and_number()
        assert result in sample


# Generated at 2022-06-23 20:53:48.032859
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider(seed=None)
    #default
    bic = provider.bic()
    assert bic is not None
    print(bic)
    #custom
    provider = RussiaSpecProvider(seed=None)
    bic = provider.bic()
    assert bic is not None
    print(bic)


# Generated at 2022-06-23 20:53:51.386915
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.builtins import RussiaSpecProvider
    provider = RussiaSpecProvider()
    assert provider.snils() == '41917492600'



# Generated at 2022-06-23 20:53:53.488743
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender

    rus = RussiaSpecProvider(seed = 123)
    for i in range (0, 9):
        assert(isinstance(rus.snils(), str))
        assert(len(rus.snils()) == 11)


# Generated at 2022-06-23 20:53:57.321189
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    rus = RussiaSpecProvider()
    assert rus.generate_sentence() in rus._data['sentence']['head'] + ' ' + rus._data['sentence']['p1'] + ' ' + rus._data['sentence']['p2'] + ' ' + rus._data['sentence']['tail']
    

# Generated at 2022-06-23 20:54:01.591241
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    rup = RussiaSpecProvider()
    valid_series = rup.passport_series()
    assert len(valid_series) == 5
    assert isinstance(valid_series, str)


# Generated at 2022-06-23 20:54:03.305935
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    ru = RussiaSpecProvider()
    ru.bic()


# Generated at 2022-06-23 20:54:13.363902
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    # Выборка из разных годов
    years = set()
    for _ in range(1000):
        years.add(RussiaSpecProvider().passport_series(2015))
        years.add(RussiaSpecProvider().passport_series(2016))
        years.add(RussiaSpecProvider().passport_series(2017))
    assert 3 == len(years)

    # Проверка правильности формата
    assert re.findall(r'\d{2} \d{2}', RussiaSpecProvider().passport_series())


# Generated at 2022-06-23 20:54:16.525851
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    rsp = RussiaSpecProvider()
    result = rsp.passport_series(year=12)

    assert result in rsp._passport_series_list(year=12)



# Generated at 2022-06-23 20:54:18.717150
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    r = RussiaSpecProvider(seed=43)
    expected = '87 99'
    actual = r.passport_series()
    assert expected == actual


# Generated at 2022-06-23 20:54:20.891451
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    assert type(RussiaSpecProvider(seed=1234).passport_number()) == int


# Generated at 2022-06-23 20:54:22.131040
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Test for method passport_series."""
    pass

# Generated at 2022-06-23 20:54:28.952928
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    ru = RussiaSpecProvider()
    ru.passport_series()
    ru.passport_series(23)
    ru.passport_series(47)
    ru.passport_series(69)
    ru.passport_series(81)
    ru.passport_series(99)
    ru.passport_series(100)
    ru.passport_series(101)



# Generated at 2022-06-23 20:54:33.927623
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.person import Person
    snils = []
    p = Person('ru')
    for i in range(100):
        snils.append(p.snils())
    assert '41917492600' == snils[0]
    assert '19917492600' == snils[1]
    assert '9917492600' == snils[2]
    assert '1917492600' == snils[3]
    assert '917492600' == snils[4]
    assert '17492600' == snils[5]
    assert '7492600' == snils[6]
    assert '492600' == snils[7]
    assert '92600' == snils[8]
    assert '2600' == snils[9]


# Generated at 2022-06-23 20:54:38.844272
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    data_list = []
    for i in range(1, 101):
        r = RussiaSpecProvider()
        data = r.inn()
        if data not in data_list:
            data_list.append(data)
        else:
            assert False, "Повтор при генерации INN"



# Generated at 2022-06-23 20:54:41.205789
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """ Test RussiaSpecProvider method snils"""
    ru_sp = RussiaSpecProvider()
    ru_snils = ru_sp.snils()
    return ru_snils


# Generated at 2022-06-23 20:54:46.112871
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    obj = RussiaSpecProvider()
    max = 999999
    min = 100000
    number = obj.passport_number()
    assert number < max and number > min, 'Number should be a number from' + str(min) + ' to ' + str(max)


# Generated at 2022-06-23 20:54:49.701527
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    ru = RussiaSpecProvider()
    ru.passport_series()
    ru.passport_series(10)
    ru.passport_series(year=10)
    ru.passport_series(year=10) == ru.passport_series(10)


# Generated at 2022-06-23 20:54:52.467922
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    rus = RussiaSpecProvider(seed=420)
    assert rus.ogrn() == '4715113303725'

test_RussiaSpecProvider_ogrn()

# Generated at 2022-06-23 20:55:02.317234
# Unit test for method patronymic of class RussiaSpecProvider

# Generated at 2022-06-23 20:55:08.816554
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    a = RussiaSpecProvider()
    print(a.series_and_number())
    print(a.series_and_number())
    print(a.series_and_number())
    print(a.series_and_number())
    print(a.series_and_number())
    print(a.series_and_number())
    print(a.series_and_number())
    print(a.series_and_number())
    print(a.series_and_number())
    print(a.series_and_number())


# Generated at 2022-06-23 20:55:14.366059
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    fh = open("1millionPassport_SNILS_INN_OGRN.txt", 'w+')
    fh.write("Passport Series and Number"+", "+"SNILS"+", "+"INN"+", "+"OGRN"+"\n")
    for i in range(0, 999999):
        fh.write(str(RussiaSpecProvider().series_and_number())+", "+str(RussiaSpecProvider().snils())+", "+str(RussiaSpecProvider().inn())+", "+str(RussiaSpecProvider().ogrn())+"\n")
    fh.close()



# Generated at 2022-06-23 20:55:18.123490
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    rsp = RussiaSpecProvider()
    for i in range(0, 100):
        assert int(rsp.passport_number()) > 999999
        assert int(rsp.passport_number()) > 100000 



# Generated at 2022-06-23 20:55:19.577164
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
  rss = RussiaSpecProvider()
  rss.passport_series(18) == '11 18'
  rss.passport_series(00) == '54 00'
  rss.passport_series() == '43 18'

# Generated at 2022-06-23 20:55:30.701587
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    """Test generation sentence from the parts."""
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender
    rp = RussiaSpecProvider(seed=123)

    # check gender
    assert rp.gender() == Gender.MALE

    # check patronymic
    assert 'Александровна' not in rp.patronymic(gender=Gender.FEMALE)
    assert rp.patronymic(gender=Gender.MALE) == 'Александрович'

    # check passport_series
    assert rp.passport_series() == '47 15'

    # check passport_number
    assert rp.passport_number() == 779992

    # check series_and_number

# Generated at 2022-06-23 20:55:32.542083
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11

# Generated at 2022-06-23 20:55:34.965804
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    print("Test RussiaSpecProvider.passport_number")
    assert RussiaSpecProvider.passport_number() == RussiaSpecProvider.passport_number()


# Generated at 2022-06-23 20:55:36.475630
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    provider = RussiaSpecProvider()
    p = provider.inn()
    print(p)
    

# Generated at 2022-06-23 20:55:39.756219
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """
        Testing method passport_number of RussiaSpecProvider
    """

    test_class = RussiaSpecProvider()
    test_object = test_class.passport_number()
    print(test_object)


# Generated at 2022-06-23 20:55:41.644120
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    ru = RussiaSpecProvider()
    ru.passport_series() == ru.passport_series()



# Generated at 2022-06-23 20:55:45.153569
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    assert RussiaSpecProvider().passport_series() == '{:02d} {}{}'.format(
            random.randint(1, 99),
            random.choice(['1', '2', '3', '4', '5', '6', '7', '8', '9']),
            random.choice(['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'])
    )


# Generated at 2022-06-23 20:55:55.356367
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Unit test for RussiaSpecProvider.series_and_number."""
    class RussiaSpecProvider_test(RussiaSpecProvider):
        def __init__(self, seed=None):
            super().__init__(seed)
            self.count = 0
            self.test_count = 10
            self.to_test = [
                '03 10 243366',
                '25 18 556196',
                '15 17 515324',
                '02 12 745888',
                '43 11 906204',
                '23 15 986535',
                '20 18 447186',
                '22 14 823803',
                '55 10 063453',
                '48 12 181211'
            ]

    test_obj = RussiaSpecProvider_test()

# Generated at 2022-06-23 20:55:56.537958
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    r = RussiaSpecProvider()
    assert isinstance(r, RussiaSpecProvider)

# Generated at 2022-06-23 20:55:58.537766
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider()
    result = provider.bic()
    print(result)
    assert len(result) == 9


# Generated at 2022-06-23 20:56:09.662391
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    # Create RussiaSpecProvider class object
    rsp = RussiaSpecProvider()

    # Get KPP
    kpp = rsp.kpp()
    
    # Check the length of KPP
    assert len(kpp) == 9

    # Get first two characters
    first_two = kpp[:2]

    # Check if first two characters are numeric
    assert first_two.isnumeric() == True

    # Get second two characters
    second_two = kpp[2:4]

    # Check if second two characters are numeric
    assert second_two.isnumeric() == True

    # Get third two characters
    third_two = kpp[4:6]

    # Check if third two characters are numeric
    assert third_two.isnumeric() == True

    # Get forth two characters

# Generated at 2022-06-23 20:56:12.881838
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    # given
    spec_ru = RussiaSpecProvider(seed=42)
    # when
    inn = spec_ru.inn()
    # then
    assert inn == '3926107477'

# Generated at 2022-06-23 20:56:14.958053
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider()
    assert provider.bic() == "044025575"


# Generated at 2022-06-23 20:56:16.423812
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    a = RussiaSpecProvider()
    print(a.inn())


# Generated at 2022-06-23 20:56:19.095742
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    assert RussiaSpecProvider().bic() == '044025575'


# Generated at 2022-06-23 20:56:19.975662
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    RussiaSpecProvider().generate_sentence()

# Generated at 2022-06-23 20:56:24.221196
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    json_data = '{}'
    ru = RussiaSpecProvider(seed=0, json_data=json_data)
    snils = ru.snils()
    assert snils == '41917492600'


# Generated at 2022-06-23 20:56:29.383108
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    import pytest
    provider_inn = RussiaSpecProvider(seed=42)
    inn_1 = provider_inn.inn()
    provider_inn = RussiaSpecProvider(seed=42)
    inn_2 = provider_inn.inn()
    assert inn_1 == str(inn_2)

# Generated at 2022-06-23 20:56:33.974773
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """Unit test for method passport_number of class RussiaSpecProvider."""
    obj = RussiaSpecProvider()
    ans = obj.passport_number()
    assert ans in range(100000, 999999)


# Generated at 2022-06-23 20:56:36.671610
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """Test a random number of passport."""
    r = RussiaSpecProvider()
    res = len(str(r.passport_number()))
    assert res == 6

# Generated at 2022-06-23 20:56:39.890180
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()

    # Проверка основных значений
    assert rsp.snils() == "41917492600"


# Generated at 2022-06-23 20:56:43.767162
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    sl = RussiaSpecProvider()
    assert type(sl.patronymic(Gender.MALE)) == str
    assert type(sl.patronymic(Gender.FEMALE)) == str


# Generated at 2022-06-23 20:56:48.191468
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    r = RussiaSpecProvider()
    bic1 = r.bic()
    bic2 = r.bic()
    assert len(bic1) == 9
    assert len(bic2) == 9
    assert bic1 != bic2


# Generated at 2022-06-23 20:56:51.313443
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Unit test for method inn of class RussiaSpecProvider"""

    provider = RussiaSpecProvider()
    print(provider.inn())
    # TODO: Need write unittest


# Generated at 2022-06-23 20:56:59.909141
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """
    Example of using:

        from mimesis.providers.russia import RussiaSpecProvider
        from mimesis.enums import Gender

        rsp = RussiaSpecProvider()
        rsp.series_and_number()

    :return: None
    """
    N = 10

    for x in range(0, N):
        print(RussiaSpecProvider().series_and_number())
    for x in range(0, N):
        print(RussiaSpecProvider().inn())
    print(RussiaSpecProvider().ogrn())
    print(RussiaSpecProvider().bic())
    print(RussiaSpecProvider().kpp())


# Generated at 2022-06-23 20:57:01.045367
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    ru_provider = RussiaSpecProvider(seed=1)
    bic = ru_provider.bic()
    assert bic == '041035139'

# Generated at 2022-06-23 20:57:06.881984
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    """Unit - test method bic of class RussiaSpecProvider."""
    from mimesis.providers.finance import Finance

    r_bic = RussiaSpecProvider().bic()
    r_bank = RussiaSpecProvider().bank(bic=r_bic)
    r_bank_number = r_bic[4:6]
    r_bank_office = r_bic[6:]

    assert type(r_bic) == type(Finance().bic())
    assert r_bank[0][0] == r_bank_number
    assert r_bank[0][1] == r_bank_office


# Generated at 2022-06-23 20:57:17.174166
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    # Test 1
    from mimesis.builtins import RussiaSpecProvider
    from pprint import pprint
    import random
    import sys

    russian = RussiaSpecProvider()

    for _ in range(1, 10):
        _bic = russian.bic()
        print(_bic)

    # Test 2
    from mimesis.builtins import RussiaSpecProvider
    from pprint import pprint
    import random
    import sys

    russian = RussiaSpecProvider()

    _bic = russian.bic()
    print("bic: " + _bic)
    pprint(_bic)

    # Test 3
    import mimesis
    import pprint
    import random
    import sys

    russian = mimesis.RussiaSpecProvider()

    _bic = russian.bic()
   

# Generated at 2022-06-23 20:57:28.908590
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    russiaSpecProvider = RussiaSpecProvider(seed=11)
    print(russiaSpecProvider.generate_sentence())
    assert russiaSpecProvider.generate_sentence() == 'Хорошо подумай, где девушка и держи что рисунок должна быть'
    assert russiaSpecProvider.patronymic() == "Антоновна"
    assert russiaSpecProvider.patronymic(gender=Gender.FEMALE) == "Александровна"

# Generated at 2022-06-23 20:57:30.877964
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    """Some tests for method bic of class RussiaSpecProvider."""
    rp = RussiaSpecProvider()
    assert len(rp.bic()) == 9
    assert isinstance(rp.bic(), str)
    assert rp.bic()=='044025575'


# Generated at 2022-06-23 20:57:32.769516
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    r = RussiaSpecProvider()
    ogrn = r.ogrn()
    print(ogrn)
    assert len(ogrn) == 13


# Generated at 2022-06-23 20:57:38.825321
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Testing RussiaSpecProvider.passport_series() method."""
    r_more = RussiaSpecProvider(seed=1)
    series_1 = r_more.passport_series()
    series_2 = r_more.passport_series()
    series_3 = r_more.passport_series()
    assert series_1 != series_2 != series_3


# Generated at 2022-06-23 20:57:42.938836
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    from mimesis.builtins import RussiaSpecProvider as rus
    from mimesis.enums import Gender
    import random

    random.seed(1)
    r = rus()
    for i in range(0, 10):
        print("ru bic : " + r.bic())

if __name__ == '__main__':
    test_RussiaSpecProvider_bic()

# Generated at 2022-06-23 20:57:46.186458
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
	o = RussiaSpecProvider()
	sentence1 = o.generate_sentence()
	assert sentence1 != ' '
	sentence2 = o.generate_sentence()
	assert sentence2 != ' '
