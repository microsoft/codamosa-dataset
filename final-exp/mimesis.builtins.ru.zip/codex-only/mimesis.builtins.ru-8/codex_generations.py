

# Generated at 2022-06-23 20:47:51.586236
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    from test.base_provider_test_case import TestCase
    from itertools import islice
    from re import compile as compile_re
    from mimesis.providers.base import BaseDataProvider

    rsb = RussiaSpecProvider()

    # Test generation of different strings
    assert isinstance(rsb, BaseDataProvider)
    assert isinstance(rsb, TestCase)
    assert rsb.provider == 'russia_provider'
    assert rsb.seed == TestCase.seed
    assert TestCase.seed in rsb.DEFAULT_SEEDS
    assert rsb.seed_factory is not None

    re_passport_series = compile_re(r'^\d{2} [0-9]{2}$')

# Generated at 2022-06-23 20:48:02.085427
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    from pprint import pprint
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    rus_man = Person('ru')
    rus_woman = Person('ru')
    
    rus_patronymic = RussiaSpecProvider()

    patronymic_man = rus_patronymic.patronymic(Gender.MALE)
    patronymic_woman = rus_patronymic.patronymic(Gender.FEMALE)

    man_full_name = rus_man.full_name(gender=Gender.MALE) + " " + patronymic_man

    woman_full_name = rus_woman.full_name(gender=Gender.FEMALE) + " " + patronymic_woman


# Generated at 2022-06-23 20:48:12.364030
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    from mimesis.enums import Gender
    
    locale = 'ru'
    seed_ = '12345678'
    
    # Create an object of class RussiaSpecProvider
    object_ = RussiaSpecProvider(seed=seed_)
    
    # Generate random sentence
    sentence = object_.generate_sentence()
    
    # Create an object of class RussiaSpecProvider with default seed
    object_default_seed = RussiaSpecProvider()
    
    # Generate random sentence
    sentence_default_seed = object_default_seed.generate_sentence()
    
    # Check the locale
    assert object_.locale == locale
    assert object_default_seed.locale == locale
    
    # Check seed
    assert object_.seed == seed_
    assert object_default_seed.seed != seed_
    
    # Check

# Generated at 2022-06-23 20:48:15.615223
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    r = RussiaSpecProvider()
    assert isinstance(r.passport_series(), str)
    assert len(r.passport_series()) == 5


# Generated at 2022-06-23 20:48:16.705846
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    assert 4715113303725 == RussiaSpecProvider().ogrn()



# Generated at 2022-06-23 20:48:19.281274
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """Test function to test method kpp of class RussiaSpecProvider."""
    kpp = RussiaSpecProvider().kpp()
    assert kpp.isnumeric()
    assert len(kpp) == 9
    pass

# Generated at 2022-06-23 20:48:23.681065
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    list_series_and_number = []
    for i in range(10):
        list_series_and_number.append(RussiaSpecProvider().series_and_number())
    list_series_and_number1 = RussiaSpecProvider().series_and_number()
    print('list_series_and_number: {}'.format(list_series_and_number))
    print('list_series_and_number1:{}'.format(list_series_and_number1))

# Generated at 2022-06-23 20:48:28.840501
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    # Initial setup
    rus = RussiaSpecProvider()
    old = rus.random.getrandbits(32)
    new = rus.random.randint(100000, 999999)  # bad random generator
    rus.random = new
    a = rus.patronymic()
    rus.random = old
    b = rus.patronymic()
    assert a != b

# Generated at 2022-06-23 20:48:30.619258
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    assert provider.snils() == "41917492600"

# Generated at 2022-06-23 20:48:33.554236
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    """Test for method bic of class RussiaSpecProvider."""
    bic = RussiaSpecProvider(seed=10).bic()
    assert bic == '044013540'

# Generated at 2022-06-23 20:48:40.101888
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    x = RussiaSpecProvider(seed=123)

    assert x.inn() == '7415139513'
    assert x.ogrn() == '5067314752436'
    assert x.bic() == '044025575'
    assert x.kpp() == '340122001'
    assert x.snils() == '21768541700'
    assert x.patronymic() == 'Петрович'

# Generated at 2022-06-23 20:48:45.904743
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    """Unit test for method bic of class RussiaSpecProvider"""
    result_list = []
    for i in range(0, 100):
        ru_provider = RussiaSpecProvider()
        result = ru_provider.bic()
        result_list.append(result)
    result = set(result_list)
    print(len(result))
    print(result)


if __name__ == "__main__":
    test_RussiaSpecProvider_bic()


# Generated at 2022-06-23 20:48:54.632221
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    r = RussiaSpecProvider()
    patronymic_list=[]
    for i in range(100):
        patronymic_list.append(r.patronymic())

    patronymic_list_male = list(filter(lambda x: x.endswith("ич"), patronymic_list))
    patronymic_list_female = list(filter(lambda x: x.endswith("на"), patronymic_list))

    assert len(patronymic_list) == 100
    assert patronymic_list_male != []
    assert patronymic_list_female != []


# Generated at 2022-06-23 20:48:56.502459
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    russia = RussiaSpecProvider()
    assert russia is not None
    assert russia.snils() is not None


# Generated at 2022-06-23 20:49:04.206883
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """
    Проверка работы метода ogrn класса RussiaSpecProvider
    """
    # Сохранение результата работы метода в переменную для последующей проверки
    result = RussiaSpecProvider().ogrn()
    # Условия для проверки выполнения теста
    assert len(result) == 13
    assert result.isdigit()

# Generated at 2022-06-23 20:49:08.284726
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    assert len(r.snils()) == 11
    assert r.snils()[0] != '0'
    assert r.snils()[-1] != '0'


# Generated at 2022-06-23 20:49:11.071711
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """Testing method kpp() of RussiaSpecProvider class"""
    r = RussiaSpecProvider()
    assert len(r.kpp()) == 9
    assert len(r.kpp()) == len(set(r.kpp()))


# Generated at 2022-06-23 20:49:14.346124
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    test_russia_provider = RussiaSpecProvider()

    check_list = list()

    check_list.append(test_russia_provider.snils() != '')

    if check_list.count(False) == 0:
        return True
    else:
        return False


# Generated at 2022-06-23 20:49:26.180983
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis import RussiaSpecProvider
    russian_data = RussiaSpecProvider()
    assert russian_data.snils() == '42015718600'
    assert russian_data.snils() == '28434513400'
    assert russian_data.snils() == '59035245100'
    assert russian_data.snils() == '62207654400'
    assert russian_data.snils() == '25267039400'
    assert russian_data.snils() == '73986600900'
    assert russian_data.snils() == '24365733300'
    assert russian_data.snils() == '69335741700'
    assert russian_data.snils() == '00449095800'
    assert russian_data.sn

# Generated at 2022-06-23 20:49:28.507082
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    assert RussiaSpecProvider.snils() in ('41917492600', '42133311700', '62214140794')

# Generated at 2022-06-23 20:49:28.903805
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    r = Rus

# Generated at 2022-06-23 20:49:31.294813
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    result = RussiaSpecProvider(seed=47).patronymic(gender=0)
    assert result == 'Степанович'

# Generated at 2022-06-23 20:49:33.801347
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    r = RussiaSpecProvider()
    assert len(str(r.passport_number())) == 6
    assert isinstance(r.passport_number(), int)


# Generated at 2022-06-23 20:49:37.304220
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    from mimesis.builtins.russia import RussiaSpecProvider

    ru = RussiaSpecProvider()
    bic = ru.bic()
    
    assert len(bic) == 9
    assert type(bic) == str


# Generated at 2022-06-23 20:49:39.459068
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    result = RussiaSpecProvider.generate_sentence()
    assert type(result) == str



# Generated at 2022-06-23 20:49:42.383080
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Unit test for method passport_series of class RussiaSpecProvider."""
    rs = RussiaSpecProvider()
    passport_series = rs.passport_series()
    assert len(passport_series) == 5



# Generated at 2022-06-23 20:49:48.040883
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Test method passport_series of class RussiaSpecProvider."""
    russia = RussiaSpecProvider()

    assert russia.passport_series(year=2005) == russia.passport_series(year=2005)
    assert russia.passport_series(year=2005) != russia.passport_series(year=2010)
    assert russia.passport_series()



# Generated at 2022-06-23 20:49:54.723203
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender
    r = RussiaSpecProvider()
    for _ in range(0, 10):
        print(r.patronymic(Gender.MALE))
        print(r.patronymic(Gender.FEMALE))
    print('=' * 10)


# Generated at 2022-06-23 20:49:58.455733
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    ru = RussiaSpecProvider()
    ru.passport_series(10)
    ru.passport_series(15)
    ru.passport_series()
    ru.passport_series(18)
    

# Generated at 2022-06-23 20:50:01.181742
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    import re
    import mimesis.enums as enums
    p = enums.Gender.FEMALE
    obj = RussiaSpecProvider()
    kpp = obj.kpp()
    assert re.match(r'\d\d\d\d\d\d\d\d', kpp)

# Generated at 2022-06-23 20:50:07.180359
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """
    Test function that verifies that the INN complies with the check digit
    """
    provider = RussiaSpecProvider()
    assert len(provider.inn()) == 10
    assert int(provider.inn()[9]) == sum(
        int(x) * int(y) for (x, y)
        in zip(provider.inn(), '2765432')
    ) % 11 % 10


# Generated at 2022-06-23 20:50:10.771361
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Unit test function test_RussiaSpecProvider_ogrn."""
    Russia = RussiaSpecProvider()
    result = Russia.ogrn()
    assert result == '4715113303725'


# Generated at 2022-06-23 20:50:19.980933
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    provider = RussiaSpecProvider()
    series = provider.passport_series()
    assert len(series) == 5
    assert (series[0:2] == '01') or (series[0:2] == '77') or (series[0:2] == '98') or (series[0:2] == '99') or \
           (series[0:2] == '00') or (series[0:2] == '50') or (series[0:2] == '60') or (series[0:2] == '70') or \
           (series[0:2] == '80') or (series[0:2] == '88') or (series[0:2] == '89')
    assert series[2] == ' '

# Generated at 2022-06-23 20:50:21.533931
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    ogrn = RussiaSpecProvider(seed=42).ogrn()
    assert ogrn == "550441849337"


# Generated at 2022-06-23 20:50:24.427722
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider"""
    from mimesis.builtins import RussiaSpecProvider
    assert RussiaSpecProvider().snils() == '41917492600'

# Generated at 2022-06-23 20:50:27.738065
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Unit test for test_RussiaSpecProvide_ogrn of class RussiaSpecProvider."""
    from mimesis.providers import RussiaSpecProvider

    RussiaSpecProvider = RussiaSpecProvider()
    assert RussiaSpecProvider.ogrn() == '4715113303725'



# Generated at 2022-06-23 20:50:34.857574
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """Unit-test for method passport_number of class RussiaSpecProvider."""
    rp = RussiaSpecProvider()
    # Number is greater than or equal to 6 digits
    assert len(str(rp.passport_number())) >= 6

    # Number is less than or equal to 6 digits
    assert len(str(rp.passport_number())) <= 6

if __name__ == '__main__':
    test_RussiaSpecProvider_passport_number()

# Generated at 2022-06-23 20:50:37.699522
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """
    Unit test for method kpp of class RussiaSpecProvider

    """
    rs = RussiaSpecProvider(seed=4)
    assert rs.kpp() == '560058652'

# Generated at 2022-06-23 20:50:39.114482
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    assert 6 == len(RussiaSpecProvider().passport_number())



# Generated at 2022-06-23 20:50:48.092238
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    russia_provider = RussiaSpecProvider()
    assert russia_provider.generate_sentence() == 'Известно, что в ходе работы метод исследования объектов исследования объектов исследования выявил существенные различия между анализируемыми процессами.'
    assert r

# Generated at 2022-06-23 20:50:50.101569
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Tests class RussiaSpecProvider_ogrn."""
    rsp = RussiaSpecProvider()
    assert rsp.ogrn() == '4715113303725'

# Generated at 2022-06-23 20:50:59.255738
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    provider = RussiaSpecProvider()
    p_number1 = provider.passport_number()
    p_number2 = provider.passport_number()
    p_number3 = provider.passport_number()
    p_number4 = provider.passport_number()
    p_number5 = provider.passport_number()
    p_number6 = provider.passport_number()
    p_number7 = provider.passport_number()
    p_number8 = provider.passport_number()
    p_number9 = provider.passport_number()
    p_number10 = provider.passport_number()
    assert p_number1 and p_number2 and p_number3 and p_number4 and p_number5 and p_number6 and p_number7 and p_number8 and p_number9 and p_number10

# Generated at 2022-06-23 20:51:00.618953
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    temp = RussiaSpecProvider()
    temp.generate_sentence()


# Generated at 2022-06-23 20:51:10.624797
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    from mimesis.enums import Gender as G
    from mimesis.providers.locales import Locale as L
    ip = RussiaSpecProvider(seed=4)
    assert ip.bic() == '042010264'
    ip = RussiaSpecProvider(seed=4)
    assert ip.bic() == '042010264'
    ip = RussiaSpecProvider()
    assert ip.bic() == '042032480'
    ip = RussiaSpecProvider(seed=4)
    assert ip.bic() == '042010264'
    ip = RussiaSpecProvider(seed=4)
    assert ip.bic() == '042010264'
    ip = RussiaSpecProvider()
    assert ip.bic() == '042032480'
    ip = RussiaSpecProvider(seed=4)
    assert ip.bic()

# Generated at 2022-06-23 20:51:12.770070
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    c = RussiaSpecProvider()
    c.reset_seed()
    s = c.kpp()
    assert len(s) == 9

# Generated at 2022-06-23 20:51:16.706468
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    rus_kpp = RussiaSpecProvider()
    kpp = rus_kpp.kpp()
    if not len(kpp) == 9:
        raise Exception('The length of the kpp number should be 9.')


# Generated at 2022-06-23 20:51:25.908877
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    result = []

    # Unit test for method passport_number of class RussiaSpecProvider
    # when the argument year is None
    def test_none_arg():
        r = RussiaSpecProvider()
        result.append(True) if len(str(r.passport_number())) == 6 else result.append(False)

    test_none_arg()

    # Unit test for method passport_number of class RussiaSpecProvider
    # when the argument year is int(10, 18)
    def test_int():
        for i in range(10, 18):
            r = RussiaSpecProvider()
            result.append(True) if len(str(r.passport_number(i))) == 6 else result.append(False)

    test_int()

    # Unit test for method passport_number of class RussiaSpecProvider
    # when the argument year is not

# Generated at 2022-06-23 20:51:27.804128
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    assert RussiaSpecProvider().kpp() == '560058651'

# Generated at 2022-06-23 20:51:34.095444
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    obj = RussiaSpecProvider(seed=42)
    sentence = obj.generate_sentence()
    print(sentence)
    assert sentence == ('Хорошее дело создано будет мне приходить в '
                        'ресторан на сегодняшний день.')


# Generated at 2022-06-23 20:51:37.791582
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence(): # add unittest
    provider = RussiaSpecProvider()
    assert provider.generate_sentence() == "Давайте поедем на обед в кафе на твоей работе."


# Generated at 2022-06-23 20:51:40.995200
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    provider = RussiaSpecProvider()
    assert provider.series_and_number() == '57 16 805199'

# Generated at 2022-06-23 20:51:48.928245
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    assert RussiaSpecProvider().kpp() == "560058652"
    assert RussiaSpecProvider().kpp() == "560058652"
    assert RussiaSpecProvider().kpp() == "560058652"
    assert RussiaSpecProvider().kpp() == "560058652"
    assert RussiaSpecProvider().kpp() == "560058652"
    assert RussiaSpecProvider().kpp() == "560058652"
    assert RussiaSpecProvider().kpp() == "560058652"
    assert RussiaSpecProvider().kpp() == "560058652"
    assert RussiaSpecProvider().kpp() == "560058652"


# Generated at 2022-06-23 20:51:53.107386
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    test = RussiaSpecProvider()
    test_inn = test.inn()
    print(test_inn)
    print(len(test_inn))
    assert len(test_inn) == 12

if __name__ == '__main__':
    test_RussiaSpecProvider_inn()

# Generated at 2022-06-23 20:51:58.774716
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    """Test for RussiaSpecProvider.patronymic."""
    provider = RussiaSpecProvider()
    assert provider.patronymic(Gender.MALE)
    assert provider.patronymic(Gender.FEMALE)
    assert provider.patronymic() in (provider.patronymic(Gender.MALE), provider.patronymic(Gender.FEMALE))


# Generated at 2022-06-23 20:52:00.640780
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider()
    print(provider.bic())


# Generated at 2022-06-23 20:52:03.815713
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    provider = RussiaSpecProvider()
    series_and_number = provider.series_and_number()
    print(series_and_number)
    assert len(series_and_number) == 11
test_RussiaSpecProvider_series_and_number()

# Generated at 2022-06-23 20:52:09.404622
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    rp = RussiaSpecProvider()
    for _ in range(0, 10):
        print("patronymic female:", rp.patronymic("female"))
        print("patronymic male:", rp.patronymic("male"))
    for _ in range(0, 10):
        print("patronymic any:", rp.patronymic("any"))


# Generated at 2022-06-23 20:52:11.222750
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    rp = RussiaSpecProvider()
    result = rp.generate_sentence()
    assert isinstance(result, str)

# Generated at 2022-06-23 20:52:15.669581
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    from mimesis.providers.base import BaseSpecProvider
    from mimesis.builtins import RussiaProvider

    class RussiaSpecProvider1(RussiaSpecProvider, BaseSpecProvider):
        pass

    ru = RussiaSpecProvider1()
    sn = ru.series_and_number()
    ru.reset_seed()
    return sn == ru.series_and_number()


# Generated at 2022-06-23 20:52:18.259359
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    r = RussiaSpecProvider()
    assert len(r.ogrn()) == len('4715113303725')


# Generated at 2022-06-23 20:52:21.058226
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
        r = RussiaSpecProvider()
        sn = r.series_and_number()
        assert sn.startswith(r.passport_series())


# Generated at 2022-06-23 20:52:22.898763
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    ru_spec = RussiaSpecProvider()
    ru_spec.seed(0)


# Generated at 2022-06-23 20:52:27.277758
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Test for method 'inn' of class RussiaSpecProvider
    """
    from mimesis.providers.russia_provider import RussiaSpecProvider
    import re

    r = RussiaSpecProvider()
    inn = r.inn()
    assert inn.isdigit()
    assert len(inn) == 12
    assert inn[0].isdigit()

# Generated at 2022-06-23 20:52:30.150038
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11, "lenght of snils must be equal 11"


# Generated at 2022-06-23 20:52:34.665335
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    import pytest
    from mimesis.typing import Seed

    provider = RussiaSpecProvider(seed=Seed(3))

    result = provider.series_and_number()
    expected = '57 16 805199'

    assert result == expected

# Generated at 2022-06-23 20:52:39.225535
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    rus_provider = RussiaSpecProvider(seed=1)
    sentence = rus_provider.generate_sentence()
    assert sentence == 'Однажды что-то случилось. Я помню.'


# Generated at 2022-06-23 20:52:40.829148
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    """Test initialization of RussiaSpecProvider class."""
    provider = RussiaSpecProvider()
    assert provider


# Generated at 2022-06-23 20:52:42.638649
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    assert RussiaSpecProvider().ogrn() == '4715113303725'

# Generated at 2022-06-23 20:52:45.215288
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    rsp = RussiaSpecProvider()
    result = rsp.generate_sentence()
    assert result != ''


# Generated at 2022-06-23 20:52:47.746083
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    provider = RussiaSpecProvider()
    ogrns = []
    for _ in range(0, 1000):
        ogrns.append(provider.ogrn())
    assert len(ogrns) == len(set(ogrns))

# Generated at 2022-06-23 20:52:52.809708
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Unit test for method ogrn of class RussiaSpecProvider"""
    provider = RussiaSpecProvider()
    ogrn = provider.ogrn()
    assert len(ogrn) == 13
    assert int(ogrn[:-1]) % 11 % 10 == int(ogrn[-1])


# Generated at 2022-06-23 20:52:55.764217
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    rsp = RussiaSpecProvider()
    res = rsp.ogrn()
    print('ogrn: ', res)
    assert True


# Generated at 2022-06-23 20:52:57.428828
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()

    assert provider.snils() == '41917492600'

# Generated at 2022-06-23 20:53:00.138448
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider(seed=None)
    result = provider.bic()
    assert '044025575'==result


# Generated at 2022-06-23 20:53:01.625644
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    ru = RussiaSpecProvider()
    print(ru.kpp())

# Generated at 2022-06-23 20:53:04.980363
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    provider = RussiaSpecProvider()
    male_patronymics = provider._data['patronymic']['MALE']
    female_patronymics = provider._data['patronymic']['FEMALE']
    assert provider.patronymic(gender=Gender.MALE) in male_patronymics
    assert provider.patronymic(gender=Gender.FEMALE) in female_patronymics
    assert provider.patronymic() in (male_patronymics + female_patronymics)


# Generated at 2022-06-23 20:53:11.092216
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Test for method series_and_number"""
    r = RussiaSpecProvider()
    result = r.series_and_number()
    
    # Format of the passport should be 10 digits with space between two parts
    assert (len(result) == 10)
    
    # First part of the passport should be 4 digits
    assert (result[:4].isdigit())
    
    # Second part of the passport should be 6 digits
    assert (result[5:].isdigit())


# Generated at 2022-06-23 20:53:13.022930
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider()
    assert provider.bic() == '044025575'
    assert len(provider.bic()) == 9

# Generated at 2022-06-23 20:53:20.775574
# Unit test for method ogrn of class RussiaSpecProvider

# Generated at 2022-06-23 20:53:23.121378
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    """Test RussiaSpecProvider component method bic."""
    assert RussiaSpecProvider().bic() == '044025575'


# Generated at 2022-06-23 20:53:24.418984
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    provider = RussiaSpecProvider()
    inn = provider.inn()
    assert len(inn) == 12
    assert int(inn[0]) != 0


# Generated at 2022-06-23 20:53:27.496326
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    provider = RussiaSpecProvider()
    generated_passport_series = provider.passport_series()
    assert len(generated_passport_series.split()) == 2


# Generated at 2022-06-23 20:53:29.416466
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    print("\nUnit test for constructor of class RussiaSpecProvider\n")
    assert RussiaSpecProvider()

# Generated at 2022-06-23 20:53:31.815909
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11 # return value should have length of 11


# Generated at 2022-06-23 20:53:33.835136
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    r = RussiaSpecProvider()
    assert r.provider.__class__.__name__ == 'RussiaSpecProvider'

# Generated at 2022-06-23 20:53:36.169716
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    provider = RussiaSpecProvider()
    assert provider.passport_number() in range(100000, 999999)


# Generated at 2022-06-23 20:53:39.032312
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    RussiaSpecProvider1 = RussiaSpecProvider
    Russia_inn = RussiaSpecProvider1()
    x = Russia_inn.inn()
    assert len(x) == 10
    assert type(x) is str


# Generated at 2022-06-23 20:53:41.180045
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    bic = RussiaSpecProvider.bic()
    assert len(bic) == 9
    assert bic[:2] == '04'

# Generated at 2022-06-23 20:53:53.168054
# Unit test for method series_and_number of class RussiaSpecProvider

# Generated at 2022-06-23 20:53:55.819060
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    test = RussiaSpecProvider()
    test_passport_number = test.passport_number()
    assert test_passport_number in range(100000, 999999)


# Generated at 2022-06-23 20:53:57.207942
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    provider = RussiaSpecProvider()

    assert provider.ogrn() is not None


# Generated at 2022-06-23 20:53:59.125195
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider(seed=123)
    r.snils() == '41861961600'

# Generated at 2022-06-23 20:54:01.699151
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    assert len(RussiaSpecProvider().kpp()) == 9

# Generated at 2022-06-23 20:54:04.261711
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    ogrn = RussiaSpecProvider().ogrn()
    assert len(ogrn) == 13
    assert isinstance(ogrn, str)

# Generated at 2022-06-23 20:54:06.085049
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    assert RussiaSpecProvider().inn() == '513010038336'


# Generated at 2022-06-23 20:54:17.021002
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    provider = RussiaSpecProvider()
    # check full name
    assert provider.person.full_name() in [
        'Асемкин Алексей Владиславович',
        'Анисименко Валерий Алексеевич',
        'Архипов Леонид Олегович'
    ]

# Generated at 2022-06-23 20:54:19.397638
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    russia = RussiaSpecProvider()
    ogrn = russia.ogrn()
    print(ogrn)
    assert len(ogrn) == 13



# Generated at 2022-06-23 20:54:21.331692
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    russia_spec_provider = RussiaSpecProvider()
    print(russia_spec_provider.patronymic())


# Generated at 2022-06-23 20:54:24.615066
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    ogrn = RussiaSpecProvider().ogrn()
    assert len(ogrn) == 13
    if int(ogrn[-1]) in range(0, 10):
        assert True
    else:
        assert False


# Generated at 2022-06-23 20:54:34.756752
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    import random
    import re

    russian_provider = RussiaSpecProvider()

    seed_list = [817, 967, 367, 697, 995, 855, 559, 755, 678, 676, 969, 699, 979]
    for seed in seed_list:
        russian_provider.set_seed(seed)
        assert russian_provider.snils() == '41839112900'

    # Test different seed
    seed_list = range(100, 20000, 1000)
    for seed in seed_list:
        russian_provider.set_seed(seed)
        snils = russian_provider.snils()

# Generated at 2022-06-23 20:54:35.715756
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    RussiaSpecProvider().ogrn()

# Generated at 2022-06-23 20:54:43.886610
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    p = RussiaSpecProvider()
    temp = p.patronymic()
    assert temp in [
        'Петровна', 'Ивановна', 'Алексеевна',
        'Георгиевна', 'Матвеева', 'Васильевна', 'Владимировна',
    ]
    temp = p.patronymic(Gender.MALE)
    assert temp in ['Петрович', 'Иванович', 'Алексеевич']
    temp = p.patronymic(Gender.FEMALE)
    assert temp

# Generated at 2022-06-23 20:54:51.501213
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """Test method kpp of class RussiaSpecProvider."""
    from mimesis.providers.russia import RussiaSpecProvider
    rus = RussiaSpecProvider()
    for _ in range(100):
        value = rus.kpp()
        assert len(value) == 9
        tax_code = value[:4]
        reg_code = value[4:6]
        reg_number = value[6:]
        assert tax_code.isdigit()
        assert reg_code.isdigit()
        assert reg_number.isdigit()


# Generated at 2022-06-23 20:54:54.312740
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    obj = RussiaSpecProvider()
    kpp = obj.kpp()
    print(kpp)
    assert len(kpp) == 9
    assert type(kpp) == str


# Generated at 2022-06-23 20:55:03.527763
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    random = RussiaSpecProvider(seed=123)
    result = random.generate_sentence()

# Generated at 2022-06-23 20:55:07.020802
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    # Set up
    r = RussiaSpecProvider()
    # Exercise
    actual = r.kpp()
    # Verify
    import re
    assert re.match("[0-9]{9}", actual)



# Generated at 2022-06-23 20:55:13.733162
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    from mimesis.providers.generic import Generic
    from mimesis.enums import Gender

    gen = Generic('ru')
    test_cases = [
        ('1', 100000),
        ('1.0.0', 100000),
        ('10.0.0', 100000),
        ('99.9.9', 999999),
        ('0.9.9', 100000),
        (0.0, 100000),
        ('0.0.100.100', 1),
        (100100, 100100),
        ('100100', 100100),
        ('', 100000),
        (None, 100000),
    ]
    for case, expected in test_cases:
        assert gen.code.passport_number(case) == expected

# Generated at 2022-06-23 20:55:15.889791
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    assert RussiaSpecProvider().series_and_number() == "07 16 648402"


# Generated at 2022-06-23 20:55:23.785689
# Unit test for method generate_sentence of class RussiaSpecProvider

# Generated at 2022-06-23 20:55:27.859531
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    ru_provider = RussiaSpecProvider()
    ogrn = ru_provider.ogrn()
    assert ogrn[13] == str(int(ogrn[0:13]) % 11 % 10)

# Generated at 2022-06-23 20:55:29.263070
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider()
    print('\nBIC: ',provider.bic())


# Generated at 2022-06-23 20:55:32.695796
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Test for method inn of class RussiaSpecProvider."""
    inn = RussiaSpecProvider().inn()
    assert len(inn) == 10
    inn_nums = [int(inn[i]) for i in range(len(inn))]
    assert (inn_nums[-2] + 2 * inn_nums[-1]) % 11 % 10 == 0

# Generated at 2022-06-23 20:55:34.559723
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    provider = RussiaSpecProvider()
    passport_number = provider.passport_number()
    assert len(str(passport_number)) == 6
    assert type(passport_number) == int


# Generated at 2022-06-23 20:55:37.035369
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    test_value = RussiaSpecProvider()
    result = test_value.passport_number()
    assert isinstance(result, int)


# Generated at 2022-06-23 20:55:40.833510
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    provider = RussiaSpecProvider()
    assert provider.__doc__
    assert provider.__name__ == 'ru_provider'
    assert provider.__class__.__bases__[0] == BaseSpecProvider


# Generated at 2022-06-23 20:55:43.444594
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    from mimesis.providers.base import BaseSpecProvider
    ru = RussiaSpecProvider()
    assert ru.generate_sentence() != None

# Generated at 2022-06-23 20:55:44.832711
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    rsp = RussiaSpecProvider()
    rs = rsp.passport_series(2018)
    assert isinstance(rs, str) and len(rs) == 5


# Generated at 2022-06-23 20:55:48.781620
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()

    # create list of random snils
    snils_list = []
    for _ in range(0, 20):
        snils_list.append(provider.snils())

    # check if all created snils numbers are valid
    for x in snils_list:
        assert provider.check_snils_number(x)

# Generated at 2022-06-23 20:55:54.618003
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    rsp = RussiaSpecProvider()
    series = rsp.passport_series()
    series_08 = rsp.passport_series(year=8)

    assert len(series) == 5
    assert len(series_08) == 5
    assert series != series_08
    assert type(series) == str
    assert type(series_08) == str
    assert series[2] == ' '
    assert series_08[2] == ' '


# Generated at 2022-06-23 20:56:02.834479
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Test series_and_number of RussiaSpecProvider."""

    from ..data import countries
    from ..data import languages

    from mimesis import Address

    from mimesis.enums import Gender

    provider = RussiaSpecProvider()

    assert provider.provider.__name__ == 'RussiaSpecProvider'
    assert provider.__doc__ == 'Class that provides special data for Russia (ru).'
    assert provider.generate_sentence()
    assert provider.patronymic(gender=Gender.MALE)
    assert provider.passport_series()
    assert provider.passport_number()
    assert provider.series_and_number()
    assert provider.snils()
    assert provider.inn()
    assert provider.ogrn()
    assert provider.bic()
    assert provider.kpp()

    assert provider.__repr

# Generated at 2022-06-23 20:56:07.203033
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Unit test for method passport_series of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    result = provider.passport_series()
    print(result)
    assert(3 <= len(result) <= 4)
    assert(isinstance(result, str) is True)


# Generated at 2022-06-23 20:56:13.245228
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    """Unit test for constructor of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    assert provider._locale == 'ru'
    assert provider._seed == None
    assert provider._spec == 'spec_ru'
    assert provider._data is not None
    assert provider._has_data is True
    assert provider._data_file is not None
    assert provider._datafile is not None


# Generated at 2022-06-23 20:56:15.789690
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    from mimesis.builtins.ru.helpers import (
        RussiaSpecProvider as ru
    )
    ru.passport_number()

# Generated at 2022-06-23 20:56:16.809756
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    print(provider.snils())
    assert len(provider.snils()) == 11
    

# Generated at 2022-06-23 20:56:19.128559
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    kpp = RussiaSpecProvider().kpp()
    assert len(kpp) == 9

# Generated at 2022-06-23 20:56:21.632460
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    for _ in range(0, 10):
        result = provider.snils()
        assert len(result) == 11
        assert result.count('0') == 2


# Generated at 2022-06-23 20:56:23.237422
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    from mimesis import RussiaSpecProvider
    rsp = RussiaSpecProvider()
    result = rsp.bic()
    assert result



# Generated at 2022-06-23 20:56:33.665185
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    import pytest
    from mimesis.enums import Gender


# Generated at 2022-06-23 20:56:35.555418
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    assert RussiaSpecProvider(seed="123").passport_series(year=18) == "02 18"


# Generated at 2022-06-23 20:56:38.085279
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    """Unit test for RussiaSpecProvider class.

    :return: None.
    """
    a = RussiaSpecProvider()
    assert a.locale == 'ru'



# Generated at 2022-06-23 20:56:39.792147
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers import BaseSpecProvider
    provider = BaseSpecProvider(locale='ru')
    inn = provider.snils()
    assert inn

# Generated at 2022-06-23 20:56:43.099614
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    provider = RussiaSpecProvider()
    document = provider.series_and_number()
    assert isinstance(document, str)
    assert len(document) == 11


# Generated at 2022-06-23 20:56:51.313828
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    ru = RussiaSpecProvider()
    assert ru.generate_sentence() == "Этот гражданин является необстрагированным и занимает в компании обязанности по личному рабочему месту."

# Generated at 2022-06-23 20:56:58.824793
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.base import BaseSpecProvider
    from mimesis.providers.enums import Gender as GenderEnum

    provider = RussiaSpecProvider()
    # Populate the cache
    for _ in range(0, 100):
        provider.snils()
    for i in range(0, 100):
        snils = provider.snils()
        assert isinstance(snils, str)
        assert len(snils) == 11
        assert isinstance(provider.snils(str(i)), str)



# Generated at 2022-06-23 20:57:01.667181
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    from mimesis.providers.person import Person

    person = Person()
    print(person.full_name(gender=Gender.MALE))

    print(RussiaSpecProvider().generate_sentence())


# Generated at 2022-06-23 20:57:03.262790
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    provider = RussiaSpecProvider(seed=0)
    assert provider.inn() == '7812661825'


# Generated at 2022-06-23 20:57:06.684817
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Test passport_series method of RussiaSpecProvider class."""
    provider = RussiaSpecProvider()
    for _ in range(0, 10000):
        result = provider.passport_series()
        assert result is not False


# Generated at 2022-06-23 20:57:09.696188
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    obj = RussiaSpecProvider()
    result = obj.generate_sentence()
    assert result



# Generated at 2022-06-23 20:57:11.404990
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    a = RussiaSpecProvider()
    assert a.inn()



# Generated at 2022-06-23 20:57:14.490718
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    b = RussiaSpecProvider(seed=2)
    result = b.patronymic()
    expected = 'Сергеевна'
    assert result == expected


# Generated at 2022-06-23 20:57:15.941256
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    assert not (RussiaSpecProvider().patronymic() == '')


# Generated at 2022-06-23 20:57:18.362720
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    ru = RussiaSpecProvider()
    ru.seed('tests')
    ru.passport_number()

# Generated at 2022-06-23 20:57:19.498401
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    assert RussiaSpecProvider().passport_number() == RussiaSpecProvider().passport_number()


# Generated at 2022-06-23 20:57:20.760132
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    r = RussiaSpecProvider()
    assert len(r.passport_series(17)) == 5


# Generated at 2022-06-23 20:57:30.932200
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Test RussiaSpecProvider.ogrn() function."""
    import re
    import random
    import string
    import pytest
    from mimesis.exceptions import NonEnumerableError

    random.seed('mimesis')
    repetitions = 100
    pattern = re.compile(r'\d{13}')
    for _ in range(repetitions):
        obj = RussiaSpecProvider('en')
        result = obj.ogrn()
        assert result == obj.ogrn()
        assert pattern.fullmatch(result) is not None
        assert result[0] != '0'
        assert str(int(result) % 11 % 10) == result[-1]

    # Check exception
    with pytest.raises(NonEnumerableError):
        obj = RussiaSpecProvider('en')
        obj.ogrn(123)

# Generated at 2022-06-23 20:57:37.619243
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    # Создание экземпляра класса RussiaSpecProvider
    provider = RussiaSpecProvider()

    # Проверка того, что он существует
    assert provider is not None


# Generated at 2022-06-23 20:57:39.047082
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    rsp = RussiaSpecProvider()
    assert len(rsp.kpp()) == 9

# Generated at 2022-06-23 20:57:41.067159
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    russian_provider = RussiaSpecProvider()
    result = russian_provider.series_and_number()
    assert len(result) == 12

# Generated at 2022-06-23 20:57:44.929514
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    p = RussiaSpecProvider(seed=2)
    assert p.bic() == '044025575'
    p.set_seed(3)
    assert p.bic() == '049008432'
    p.set_seed(5)
    assert p.bic() == '049041401'
