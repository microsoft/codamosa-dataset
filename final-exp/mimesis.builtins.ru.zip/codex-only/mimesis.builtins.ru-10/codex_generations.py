

# Generated at 2022-06-23 20:47:47.767538
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    """Unit test for method bic of class RussiaSpecProvider"""
    provider = RussiaSpecProvider()

    # Loop 100 times
    for _ in range(0, 100):
        # At each iteration generate new BIC by method bic of class RussiaSpecProvider
        bic = provider.bic()
        # Check whether the length of the generated BIC is equal to 9
        assert len(bic) == 9
        # Check whether the first two characters of the generated BIC are equal to 04
        assert bic[:2] == '04'



# Generated at 2022-06-23 20:47:50.227543
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    ru = RussiaSpecProvider()
    assert ru.inn() == '770701001'
    assert ru.inn() == '910701001'
    assert ru.inn() == '971201001'


# Generated at 2022-06-23 20:47:51.700730
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Unit test for method ogrn of class RussiaSpecProvider."""
    instance = RussiaSpecProvider()
    assert isinstance(instance.ogrn(), str)

# Generated at 2022-06-23 20:47:54.013543
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    # Test type of method passport_number() of class RussiaSpecProvider
    assert type(RussiaSpecProvider().passport_number()) is int


# Generated at 2022-06-23 20:47:57.225935
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert snils[3] == '-' and snils[7] == '-'
    assert len(snils) == 14

# Generated at 2022-06-23 20:47:59.886412
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    provider = RussiaSpecProvider()
    for _ in range(0, 10):
        print(provider.inn())


# Generated at 2022-06-23 20:48:06.761241
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    expected = '41917492600'
    # The Russian Social Insurance Fund number is taken from the Internet,
    # and it is checked for correctness on the website,
    # since there is no way to check the correct number of social insurance,
    # as there is no such formula on the Internet:
    # https://itunes.apple.com/ru/app/snils/id1085301114?mt=8
    # https://play.google.com/store/apps/details?id=ru.app.snils&hl=ru
    # https://www.snils.ru

    snils = RussiaSpecProvider.snils()
    assert snils == expected, 'Error checking the correctness of the number of social insurance'

# Generated at 2022-06-23 20:48:14.158877
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    ru_provider = RussiaSpecProvider()
    ru_bic = ru_provider.bic()
    ru_bic = ru_bic.split('-')[0]
    assert ru_bic.isdigit()
    assert len(ru_bic) == 9
    ru_provider_2 = RussiaSpecProvider(seed = ru_bic)
    ru_bic_2 = ru_provider_2.bic()
    ru_bic_2 = ru_bic_2.split('-')[0]
    assert ru_bic_2 == ru_bic


# Generated at 2022-06-23 20:48:18.281215
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    snils_provider = RussiaSpecProvider()
    snils = snils_provider.snils()
    snils_list = snils.split()
    assert len(snils) == 11
    for number in snils_list:
        assert type(number) == int


# Generated at 2022-06-23 20:48:19.584003
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    r = RussiaSpecProvider()
    kpp = r.kpp()
    print(kpp)


# Generated at 2022-06-23 20:48:22.201379
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    pass_series = RussiaSpecProvider()
    assert pass_series.passport_series(18) == '58 18'
    assert pass_series.passport_series(11) == '18 11'
    assert pass_series.passport_series(4) == '74 04'


# Generated at 2022-06-23 20:48:26.492702
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """Test for passport_number method."""
    ru = RussiaSpecProvider()
    number = ru.passport_number()
    assert len(str(number)) == 6
    assert isinstance(number, int)
    assert number in range(100000, 999999)



# Generated at 2022-06-23 20:48:28.293819
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Check passport_series method of class RussiaSpecProvider.

    :return:
    """
    ru_provider = RussiaSpecProvider()
    ru_provider.seed(0)
    ru_provider.passport_series(year=11)

# Generated at 2022-06-23 20:48:29.981742
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    r = RussiaSpecProvider()
    t=r.generate_sentence()


# Generated at 2022-06-23 20:48:33.819510
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    from mimesis.enums import Gender
    r = RussiaSpecProvider()
    year = r.year(start=2010, stop=2017)
    series = r.passport_series(year)
    print(series)
    assert len(series) == 5
    print('_' * 10)


# Generated at 2022-06-23 20:48:35.741826
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    # arrange
    rus = RussiaSpecProvider(seed=0)

    # act
    result = rus.passport_number()

    # assert
    assert result == 560430


# Generated at 2022-06-23 20:48:38.484364
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """
    Unit test for method RussiaSpecProvider.snils
    """
    x = RussiaSpecProvider()
    assert len(x.snils()) == 11, "unexpected snils length"

# Generated at 2022-06-23 20:48:40.792663
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    pr = RussiaSpecProvider()
    result = pr.passport_series(year=99)
    assert result == '99'


# Generated at 2022-06-23 20:48:42.579817
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    test_obj = RussiaSpecProvider()
    print(test_obj.snils())


# Generated at 2022-06-23 20:48:44.205214
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    x = RussiaSpecProvider()
    print(x.passport_number())


# Generated at 2022-06-23 20:48:45.594892
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for snils method."""
    r = RussiaSpecProvider()
    assert r.snils() != ''

# Generated at 2022-06-23 20:48:52.334026
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    provider = RussiaSpecProvider()
    # Test 1
    test_inn = provider.inn()
    assert len(test_inn) == 10
    try:
        int(test_inn)
    except Exception:
        assert False
    # Test 2
    test_inn = provider.inn()
    assert len(test_inn) == 10
    try:
        int(test_inn)
    except Exception:
        assert False
    # Test 3
    test_inn = provider.inn()
    assert len(test_inn) == 10
    try:
        int(test_inn)
    except Exception:
        assert False


# Generated at 2022-06-23 20:48:59.892012
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    # Test if all characters in bic are one of the following:
    all_chars_possible = ['0','1','2','3','4','5','6','7','8','9']
    # Loop 10000 times:
    for i in range(10000):
        # Generate bic:
        bic = RussiaSpecProvider().bic()
        # Check if generated bic is 9 characters long and if all characters are one of the above:    
        if len(bic) == 9:
            for char in bic:
                if char not in all_chars_possible:
                    print(char)
                    print(bic)
                    print('Fail')
    print('Test done')
    

# Generated at 2022-06-23 20:49:06.159859
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    random = RussiaSpecProvider(seed=42)
    # test generate_phone
    ru_phone = random.phone()
    assert ru_phone == '8-800-200-7373'
    ru_phone = random.phone('8999123450')
    assert ru_phone == '8-999-123-450'
    # test generate_email
    ru_email = random.email()
    assert ru_email == 'anatoliy-danilovich@booking.ru'
    ru_email = random.email('test')
    assert ru_email == 'test@mail.ru'
    ru_email = random.email(domain='com')
    assert ru_email == 'boris-dmitrievich@gmail.com'
    ru_email = random.email(local_part='example', domain='com')
   

# Generated at 2022-06-23 20:49:09.535306
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    from mimesis.enums import Gender
    from mimesis.providers.person.ru import RussiaSpecProvider
    ru = RussiaSpecProvider()
    assert ru.kpp() != ru.kpp()

# Generated at 2022-06-23 20:49:15.276157
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    rsp = RussiaSpecProvider()
    p = rsp.patronymic()
    assert p in rsp._data['patronymic'][Gender.MALE]+rsp._data['patronymic'][Gender.FEMALE]
    p = rsp.patronymic(Gender.MALE)
    assert p in rsp._data['patronymic'][Gender.MALE]
    p = rsp.patronymic(Gender.FEMALE)
    assert p in rsp._data['patronymic'][Gender.FEMALE]


# Generated at 2022-06-23 20:49:16.850275
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider(seed=1)
    result = provider.snils()
    assert result == '18735839600'


# Generated at 2022-06-23 20:49:28.182232
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    rp = RussiaSpecProvider()
    # Ожидаем вывод какого-то имени родителя
    print('RussiaSpecProvider.patronymic() имени родителя:', rp.patronymic())
    # Ожидаем вывод какого-то имени родителя по указанному полу

# Generated at 2022-06-23 20:49:29.266637
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    """Test method generate_sentence()."""
    assert RussiaSpecProvider().generate_sentence()

# Generated at 2022-06-23 20:49:30.264555
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    a = RussiaSpecProvider()
    assert a is not None
    assert a.kpp() is not None

# Generated at 2022-06-23 20:49:33.636263
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    russian_provider = RussiaSpecProvider()
    assert russian_provider.__class__ == RussiaSpecProvider
    assert russian_provider.__doc__ == "Class that provides special data for Russia (ru)."


# Generated at 2022-06-23 20:49:34.894706
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    try:
        RussiaSpecProvider()
    except:
        assert False

# Unit test generate_sentence method 

# Generated at 2022-06-23 20:49:38.771956
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    russia = RussiaSpecProvider()
    passport_number = russia.passport_number()
    assert isinstance(passport_number, int)


# Generated at 2022-06-23 20:49:41.776023
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    prov = RussiaSpecProvider()
    assert prov.__class__.__name__ == 'RussiaSpecProvider'
    assert prov.__doc__ == 'Class that provides special data for Russia (ru).'
    

# Generated at 2022-06-23 20:49:49.451045
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    from mimesis.providers.generic import Generic
    from mimesis.providers.personal import Personal
    import random
    import unittest
    random.seed(0)
    generic = Generic('ru')
    personal = Personal('ru')
    passport_series = generic.passport_series()
    gender = personal.gender()
    assert passport_series in ('57 16', '77 16', '84 17', '86 18', '22 14', '17 14', '56 15', '49 16', '54 15', '19 10')
    assert gender in ('male', 'female')


# Generated at 2022-06-23 20:50:00.991604
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    from mimesis import Person, RussiaSpecProvider
    from pprint import pprint

    rs = RussiaSpecProvider()
    p = Person('ru')
    print('Unit test for method inn of class RussiaSpecProvider')

    # Тестирование метода inn при задании генерации ИНН рандомного человека
    print('Test inn method when generating INN random person')
    print(p.inn(), p.full_name(), p.gender())

    # Тестирование метода inn при задании гендер

# Generated at 2022-06-23 20:50:04.659570
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    rs = RussiaSpecProvider('en')
    rs = RussiaSpecProvider()
    assert isinstance(rs, RussiaSpecProvider)


# Generated at 2022-06-23 20:50:07.322669
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    utf8 = 'utf-8'
    for _ in range(0, 100):
        p = RussiaSpecProvider()
        result = p.inn()
        assert (type(result) == str) or (type(result) == bytes)


# Generated at 2022-06-23 20:50:10.431091
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    russian_dataprovider = RussiaSpecProvider()
    passport = russian_dataprovider.series_and_number()
    assert isinstance(passport, str)



# Generated at 2022-06-23 20:50:12.732863
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    provider = RussiaSpecProvider()
    sentence = provider.generate_sentence()
    print(sentence)


# Generated at 2022-06-23 20:50:16.199170
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    ru = RussiaSpecProvider() # create class
    ru.patronymic(Gender.FEMALE) # check patronymic female
    ru.patronymic(Gender.MALE) # check patronymic male
    ru.patronymic(Gender.UNDEFINED) # check patronymic undefined



# Generated at 2022-06-23 20:50:17.915401
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    a = RussiaSpecProvider()
    test_data = a.ogrn()
    assert len(test_data) == 13


# Generated at 2022-06-23 20:50:24.600342
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    print("\n\nTesting method passport_number of class RussiaSpecProvider")
    r = RussiaSpecProvider()
    print(r.passport_number())
    print(r.passport_number())
    print(r.passport_number())
    print(r.passport_number())
    print(r.passport_number())
    print(r.passport_number())
    print(r.passport_number())
    print(r.passport_number())
    print(r.passport_number())
    print(r.passport_number())


# Generated at 2022-06-23 20:50:26.936527
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    provider = RussiaSpecProvider()
    kpp = provider.kpp()
    assert len(kpp) == 9
    assert ' ' not in kpp
    assert '-' not in kpp

# Generated at 2022-06-23 20:50:38.513395
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    rsp = RussiaSpecProvider()
    # generating two different values
    assert(rsp.snils() != rsp.snils())
    assert(rsp.ogrn() != rsp.ogrn())
    assert(rsp.bic() != rsp.bic())
    assert(rsp.inn() != rsp.inn())
    assert(rsp.kpp() != rsp.kpp())
    assert(rsp.patronymic() != rsp.patronymic())
    assert(rsp.series_and_number() != rsp.series_and_number())
    assert(rsp.generate_sentence() != rsp.generate_sentence())

    # generating a lot of values
    for i in range(100):
        assert(len(rsp.snils()) == 11)
       

# Generated at 2022-06-23 20:50:47.690910
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    from mimesis.providers.base import BaseProvider
    # 1:Create a class for RussiaSpecProvider
    russia_provider = RussiaSpecProvider()
    # 2:Create a class for BaseProvider
    base_provider = BaseProvider()
    # 3:Create a list of values for a passport number
    passport_number_list = []
    for i in range(1000):
        passport_number_list.append(int(russia_provider.passport_number()))
    # 4:Check that all numbers are in the range [100000, 999999]
    assert (min(passport_number_list) == 100000)
    assert (max(passport_number_list) == 999999)
    # 5:Check that the distribution of numbers is uniform

# Generated at 2022-06-23 20:50:48.777731
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    r = RussiaSpecProvider()
    assert r.passport_series() == '02 15'

# Generated at 2022-06-23 20:50:53.992413
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    # Проверка работы метода __ogrn
    provider = RussiaSpecProvider()
    ogrn = provider.ogrn()
    assert len(ogrn) == 13
    assert ogrn[-1] == str(int(ogrn[:len(ogrn) - 1]) % 11 % 10)


# Generated at 2022-06-23 20:50:55.397028
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    for _ in range(100):
        assert len(RussiaSpecProvider().kpp()) == 9

# Generated at 2022-06-23 20:51:03.452418
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    """Test patronymic request from class RussiaSpecProvider."""
    from mimesis.enums import Gender

    provider = RussiaSpecProvider()
    genders = [Gender.MALE, Gender.FEMALE]
    for gender in genders:
        patronymic = provider.patronymic(gender)
        # All patronymics must contain letters
        assert any(x.isalpha() for x in patronymic)

        patronymic = provider.patronymic()
        # All patronymics must contain letters
        assert any(x.isalpha() for x in patronymic)

# Generated at 2022-06-23 20:51:09.358439
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    provider = RussiaSpecProvider()
    output = provider.patronymic(Gender.MALE)
    assert output in ['Николаевич', 'Анатольевич', 'Васильевич', 'Андреевич', 'Дмитриевич']


# Generated at 2022-06-23 20:51:12.796493
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    rus = RussiaSpecProvider()
    assert rus.generate_sentence() == 'Извините, пожалуйста, что я написал Вам не на материале письма.'


# Generated at 2022-06-23 20:51:15.005104
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    for _ in range(3):
        print(RussiaSpecProvider().generate_sentence())


# Generated at 2022-06-23 20:51:24.737862
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """Test RussiaSpecProvider class."""

    from mimesis.providers.number import Number
    from mimesis.providers.text import Text

    rkpp = RussiaSpecProvider()
    kpp = rkpp.kpp()
    assert len(kpp) == 9
    assert len(kpp.split('0')) <= 5
    assert len(kpp.split('1')) <= 5
    assert len(kpp.split('2')) <= 5
    assert len(kpp.split('3')) <= 5
    assert len(kpp.split('4')) <= 5
    assert len(kpp.split('5')) <= 5
    assert len(kpp.split('6')) <= 5
    assert len(kpp.split('7')) <= 5

# Generated at 2022-06-23 20:51:27.462666
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    provider = RussiaSpecProvider(seed=42)

    assert provider.series_and_number() == '45 17 658159'


# Generated at 2022-06-23 20:51:36.786038
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    provider = RussiaSpecProvider()
    print('gender = {}, patronymic = {}'.format(
        'Male',
        repr(provider.patronymic(Gender.MALE))
    ))
    print('gender = {}, patronymic = {}'.format(
        'Female',
        repr(provider.patronymic(Gender.FEMALE))
    ))
    print('gender = {}, patronymic = {}'.format(
        'Neutral',
        repr(provider.patronymic(Gender.NEUTRAL))
    ))
    # gender = Male, patronymic = 'евич'
    # gender = Female, patronymic = 'евна'
    # gender = Neutral, patronymic = 'евич'


# Generated at 2022-06-23 20:51:45.119609
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    # Get a object of class RussiaSpecProvider
    provider = RussiaSpecProvider()

    # List of different genders
    list_genders = [Gender.MALE, Gender.FEMALE, Gender.NEUTRAL]

    # Test custom gender
    for gender in list_genders:
        # Test different language
        assert provider.patronymic(gender=gender) is not None
        assert provider.patronymic(gender=gender).isalpha() is True


# Generated at 2022-06-23 20:51:46.278237
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """Test  method passport_number of class RussiaSpecProvider."""
    assert isinstance(RussiaSpecProvider().passport_number(), int)



# Generated at 2022-06-23 20:51:49.415736
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    # Test with all genders
    ru = RussiaSpecProvider()
    ru.patronymic(Gender.MALE)


# Generated at 2022-06-23 20:51:51.015746
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    r = RussiaSpecProvider()
    assert r.kpp() == '01001000'


# Generated at 2022-06-23 20:51:55.187132
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    import pytest
    from mimesis.enums import Gender
    russian = RussiaSpecProvider()
    for _ in range(10000):
        series = russian.passport_series()
        assert (len(series) == 5) and (series[2] == ' ') and (int(series[3:]) in range(10, 19))


# Generated at 2022-06-23 20:51:57.731499
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    seed = 'NTp8AAAAAA' #1234567890
    _ = '318248717264'
    assert RussiaSpecProvider(seed).ogrn() == _



# Generated at 2022-06-23 20:52:00.166028
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    provider = RussiaSpecProvider()

    for _ in range(0, 10):
        series_and_number = provider.series_and_number()
        assert isinstance(series_and_number, str)
        assert len(series_and_number) == 12

# Generated at 2022-06-23 20:52:04.033518
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """Unit test for method passport_number of class RussiaSpecProvider"""
    def test1():
        """Test method."""
        rsp = RussiaSpecProvider()
        passport_number = rsp.passport_number()
        assert 100000 <= passport_number <= 999999

    # Run test
    test1()

# Generated at 2022-06-23 20:52:05.905318
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Unit test for method ogrn of class RussiaSpecProvider."""
    ogrn = RussiaSpecProvider.ogrn()
    assert type(ogrn) == str

# Generated at 2022-06-23 20:52:09.656005
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    data = []
    provider = RussiaSpecProvider()

    for i in range(0, 100):
        data.append(provider.bic())

    for element in data:
        if len(element) == 9:
            assert element
        else:
            assert False

# Generated at 2022-06-23 20:52:12.374468
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    rus = RussiaSpecProvider()
    assert rus.__class__.__name__ == 'RussiaSpecProvider'



# Generated at 2022-06-23 20:52:15.252740
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Unit test for method series_and_number of class RussiaSpecProvider."""
    assert len(RussiaSpecProvider().series_and_number()) == 12

# Generated at 2022-06-23 20:52:26.065622
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
  # Generate OGRN from class RussiaSpecProvider
  ogrn = RussiaSpecProvider().ogrn()
  # Проверяем делимость ОГРН без последнего символа на 11
  ogrn_int = int(ogrn[:-1])
  assert ogrn_int % 11 == 0
  # Проверяем соответствие последнего символа ОГРН сумме
  ogrn_last_digit = int(ogrn[-1])

# Generated at 2022-06-23 20:52:38.388798
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    seed = 'Сравнение значений с {provider}'
    provider = RussiaSpecProvider()

    # Check the sytac
    assert len(provider.kpp()) == 9
    assert provider.kpp().__class__ == str

    # Start cycle for checking len
    for i in range(1, 20):
        assert len(provider.kpp()) == 9
        assert provider.kpp().__class__ == str

    # Start cycle for checking values
    for i in range(1, 20):
        assert provider.kpp()[0:4].__class__ == str
        assert provider.kpp()[4:6].__class__ == str
        assert provider.kpp()[6:9].__class__ == str

# Generated at 2022-06-23 20:52:41.399110
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    """Test constructor of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    assert provider.locale == 'ru'
    assert isinstance(provider, RussiaSpecProvider)


# Generated at 2022-06-23 20:52:45.093343
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    russia_generator = RussiaSpecProvider()
    assert russia_generator.generate_sentence() is not None
    assert russia_generator.generate_sentence() != ''


# Generated at 2022-06-23 20:52:49.966284
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Init RussiaSpecProvider
    russia = RussiaSpecProvider()

    # Get random snils
    snils = russia.snils()
    snils_sample = ['41917492600']

    # Check snils
    assert snils in snils_sample, "Should return true!"

# Generated at 2022-06-23 20:52:58.347332
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.snils import RussiaSpecProvider
    ru = RussiaSpecProvider()
    for _ in range(0, 10):
        control_codes = []
        snils = ru.snils()
        numbers = [int(x) for x in list(snils)]
        print(numbers)
        for i in range(9, 0, -1):
            control_codes.append(numbers[9 - i] * i)
            print(control_codes)
        control_code = sum(control_codes)
        print(control_code)
        if control_code % 101 in (100, 101):
            control_code = 0
        if str(control_code % 101) == snils[-2:]:
            print(True)
        else:
            print(False)

# Generated at 2022-06-23 20:53:01.560290
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """Test the kpp method of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    assert len(rsp.kpp()) == 9
    assert rsp.kpp().isdigit()


# Generated at 2022-06-23 20:53:04.956815
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    russianspecprovider = RussiaSpecProvider()
    provider = russianspecprovider.passport_series()
    assert type(provider) == str

# Generated at 2022-06-23 20:53:10.461093
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    RussiaSpecProvider(seed=1)
    fp = open("testdata/RussiaSpecProvider/patronymic.txt")
    n = int(fp.readline())
    for i in range(n):
        gender = fp.readline().strip()
        fp.readline()
        result = fp.readline().strip()
        assert RussiaSpecProvider.patronymic(Gender[gender.upper()]) == result


# Generated at 2022-06-23 20:53:20.529076
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Test passport series of class RussiaSpecProvider."""
    # When country code is not given
    result = RussiaSpecProvider().passport_series()
    # Then series should be in format 'xx xx'
    assert len(result) == 5
    assert result[2] == ' '
    # And last part should be two digit number
    assert result[3:].isdigit()
    assert len(result[3:]) == 2
    # And when country code year is given
    result = RussiaSpecProvider().passport_series(year=2014)
    # Then series should be in format 'xx xx'
    assert len(result) == 5
    assert result[2] == ' '
    # And last part should be two digit number
    assert result[3:].isdigit()
    assert len(result[3:]) == 2
    # And

# Generated at 2022-06-23 20:53:22.857785
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    a = RussiaSpecProvider()
    assert a.patronymic() in a._data['patronymic']['male']


# Generated at 2022-06-23 20:53:26.255216
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    provider = RussiaSpecProvider()
    sentence = provider.generate_sentence()
    print(sentence)
    assert sentence is not None


# Generated at 2022-06-23 20:53:30.698969
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    russ = RussiaSpecProvider()
    s = russ.passport_series()
    s = s.replace(' ', '')
    day = int(s[0:2])
    year = int(s[2:4])
    return (day < 100 and year < 19 and year > 9)


# Generated at 2022-06-23 20:53:32.927878
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    ru = RussiaSpecProvider()
    result = ru.patronymic(Gender.FEMALE)
    assert result in ru._data['patronymic'][Gender.FEMALE]


# Generated at 2022-06-23 20:53:34.992497
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    data = RussiaSpecProvider()
    assert data

 # Unit test for method inn and inn_formatted of class RussiaSpecProvider

# Generated at 2022-06-23 20:53:42.196084
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    from mimesis.enums import Gender
    from mimesis.providers.person.base import Person
    from mimesis.providers.person.ru import Provider as RUProvider
    ru = RUProvider('ru', seed=9876)
    ru_person = Person('ru', seed=9876)
    p = ru_person.patronymic(gender=Gender.FEMALE)
    assert p in ru.patronymic(gender=Gender.FEMALE)
    assert ru_person.patronymic(gender=Gender.MALE) in ru.patronymic(gender=Gender.MALE)

# Generated at 2022-06-23 20:53:52.159253
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    ruprov = RussiaSpecProvider()
    family_name = 'Сидоров'

    for gender in Gender:
        patronymic = ruprov.patronymic(gender)
        if gender == Gender.MALE:
            assert patronymic == family_name + 'ович'
        elif gender == Gender.FEMALE:
            assert patronymic == family_name + 'овна'
        elif gender == Gender.NEUTER:
            assert patronymic == family_name + 'овична'
        else:
            raise AssertionError('Invalid gender.')


# Generated at 2022-06-23 20:53:59.993094
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender
    from mimesis.builtins import RussiaProvider
    rs = RussiaSpecProvider()
    ru = RussiaProvider()
    for _ in range(1, 10):
        p1 = ru.person(gender=Gender.FEMALE)
        p2 = ru.person(gender=Gender.MALE)
        p3 = ru.person(gender=Gender.MALE)
        p4 = ru.person(gender=Gender.FEMALE)
        sentence = rs.generate_sentence()

# Generated at 2022-06-23 20:54:11.644334
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    from re import match
    from random import seed as random_seed
    from mimesis.enums import Gender

    random_seed(4281148)
    provider = RussiaSpecProvider()
    provider.seed(4281148)
    assert provider.kpp() == '770085132'
    assert provider.kpp() == '560043282'
    assert provider.kpp() == '650067762'
    assert provider.kpp() == '990326651'
    assert provider.kpp() == '770043504'
    assert provider.kpp() == '560026977'
    assert provider.kpp() == '770023333'
    assert provider.kpp() == '650099233'
    assert provider.kpp() == '770079252'

# Generated at 2022-06-23 20:54:13.819109
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    a = RussiaSpecProvider()
    b = a.inn()
    assert type(b) == str

# Generated at 2022-06-23 20:54:16.583239
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():

    provider = RussiaSpecProvider(seed=123456789)
    expected = '560058652'
    actual = provider.kpp()
    assert expected == actual

# Generated at 2022-06-23 20:54:18.766986
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    provider = RussiaSpecProvider()
    assert provider.patronymic(Gender.MALE) != provider.patronymic(Gender.FEMALE)


# Generated at 2022-06-23 20:54:20.666633
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    provider = RussiaSpecProvider()
    inn = provider.inn()
    assert len(inn) == 12
    assert type(inn) == str



# Generated at 2022-06-23 20:54:23.051853
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    for x in range(0, 5):
        assert len(RussiaSpecProvider(seed=x).patronymic()) == len('Алексеевна')


# Generated at 2022-06-23 20:54:27.252822
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russia = RussiaSpecProvider()
    # test values
    for _ in range(0, 5):
    	assert russia.snils() == russia.snils()


# Generated at 2022-06-23 20:54:32.748327
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    """Unit test for generate_sentence."""
    for _ in range(200):
        rsp = RussiaSpecProvider()
        sentence = rsp.generate_sentence()
        print(sentence)
        assert isinstance(sentence, str)
        assert sentence.startswith(('Я', 'Мы', 'Я,', 'Мы,'))
        assert sentence.endswith(('.', '!', '?'))


# Generated at 2022-06-23 20:54:34.854422
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    russia = RussiaSpecProvider()
    assert russia.passport_series(16) == '02 16'


# Generated at 2022-06-23 20:54:37.950303
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    """Unit test for RussiaSpecProvider"""
    ru = RussiaSpecProvider()
    ru_1 = RussiaSpecProvider('1234')

    assert ru != ru_1
    assert ru.snils() != ru_1.snils()

# Generated at 2022-06-23 20:54:41.681615
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    provider = RussiaSpecProvider()
    sentence = provider.generate_sentence()
    print(sentence)
    provider.seed(42)
    new_sentence = provider.generate_sentence()
    print(new_sentence)
    assert sentence != new_sentence


# Generated at 2022-06-23 20:54:47.759594
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Function for test random generated INN.

    :Example:
        781001006802
    """
    from mimesis import RussiaSpecProvider
    from mimesis.builtins import RussiaSpecProvider as RSP

    r = RussiaSpecProvider()
    r2 = RSP()

    assert r.inn() in RSP.inn()
    assert r2.inn() in RussiaSpecProvider.inn()

# Generated at 2022-06-23 20:54:50.157879
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    BSTest = RussiaSpecProvider(seed=0)
    assert BSTest.bic() == '044025575'


# Generated at 2022-06-23 20:54:53.954456
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    provider = RussiaSpecProvider()
    output = provider.series_and_number()

    print('series_and_number() output: ' + output)
    assert (len(output) == 10)
    assert (output.isdigit())


# Generated at 2022-06-23 20:54:59.266060
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    import pytest
    from mimesis.enums import Gender
    from mimesis.typing import Seed
    from mimesis.exceptions import SeedLengthError

    provider = RussiaSpecProvider(seed = Seed(314))
    kpp = provider.kpp()

    assert isinstance(kpp, str) == True
    assert kpp == '640078125'

# Generated at 2022-06-23 20:55:01.498594
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    """Unit test for method bic of class RussiaSpecProvider."""
    assert RussiaSpecProvider().bic() != None


# Generated at 2022-06-23 20:55:02.616489
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    assert len(RussiaSpecProvider().series_and_number()) == 11


# Generated at 2022-06-23 20:55:05.074867
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    rs = RussiaSpecProvider()
    passportSeries = rs.passport_series(int(input("Enter the year of manufacture\n")))
    print("Passport series: " + passportSeries)
# Output - Passport series: 20 14


# Generated at 2022-06-23 20:55:13.821085
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """
    This unit test for method passport_series of class
    RussiaSpecProvider.
    """
    from random import randint
    from mimesis.providers.russia_provider import RussiaSpecProvider
    from mimesis.enums import Gender
    from mimesis.typing import Seed
    print("\n==============================\n"
          "Unit test for method passport_series of class "
          "RussiaSpecProvider\n"
          "==============================\n")
    seed = Seed.create_from_hex(hex(randint(0, 1000000))[2:])
    year = randint(0, 100)
    generations = [RussiaSpecProvider(seed), RussiaSpecProvider()]
    for generation in generations:
        result = generation.passport_series(year)

# Generated at 2022-06-23 20:55:19.208636
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    provider = RussiaSpecProvider()
    assert isinstance(provider.passport_series(year=99), str)
    assert len(provider.passport_series(year=99)) == 5
    assert str(provider.passport_series(year=99)).isdigit()
    assert string.count(str(provider.passport_series(year=99)), " ") == 1


# Generated at 2022-06-23 20:55:27.943841
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    rus = RussiaSpecProvider()
    rus.seed(0)
    sent = rus.generate_sentence()
    assert sent == "Любая достоверная информация не должна быть секретом в обществе."


# Generated at 2022-06-23 20:55:33.654471
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    """Unit test for method patronymic of class RussiaSpecProvider"""
    provider = RussiaSpecProvider()

    provider.seed(200)
    assert provider.patronymic(Gender.MALE) == 'ович'

    provider.seed(1)
    assert provider.patronymic(Gender.MALE) == 'ич'

    provider.seed(1)
    assert provider.patronymic(Gender.FEMALE) == 'на'

    provider.seed(100)
    assert provider.patronymic(Gender.FEMALE) == 'овна'



# Generated at 2022-06-23 20:55:35.616852
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    r = RussiaSpecProvider(seed=42)
    out = r.kpp()
    assert out == '560003299'


# Generated at 2022-06-23 20:55:42.412650
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    from mimesis.providers.identification import Identification
    from mimesis.builtins.Russia import RussiaSpecProvider

    russia = RussiaSpecProvider()
    identification = Identification()
    input = identification.series_and_number(country='ru')

    assert isinstance(russia.series_and_number(), str) 
    assert len(russia.series_and_number()) > 0
    assert type(input) == type(russia.series_and_number())


# Generated at 2022-06-23 20:55:44.853551
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    rs = RussiaSpecProvider()
    assert len(rs.passport_series(10)) == 5



# Generated at 2022-06-23 20:55:52.435048
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Unit test for method passport_series of class RussiaSpecProvider"""
    provider = RussiaSpecProvider()
    #provider.reset_seed()
    a = provider.passport_series()
    #provider.reset_seed()
    b = provider.passport_series()
    #provider.reset_seed()
    c = provider.passport_series()
    if (a == b) and (b == c):
        print("The method passport_series of class RussiaSpecProvider don't work")
    else:
        print('Test OK')


# Generated at 2022-06-23 20:55:53.109919
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    pass

# Generated at 2022-06-23 20:55:55.412175
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    for i in range(0, 100):
        assert len(RussiaSpecProvider().passport_number()) == 6


# Generated at 2022-06-23 20:55:56.561429
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    assert RussiaSpecProvider().bic() == '044025575'


# Generated at 2022-06-23 20:55:59.202263
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    pattern = re.compile('\d{2}\s\d{2}\s\d{6}')
    test=RussiaSpecProvider().series_and_number()
    assert pattern.match(test)


# Generated at 2022-06-23 20:56:02.986942
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    from mimesis.providers import RussiaSpecProvider
    rsp = RussiaSpecProvider()
    assert len(rsp.bic()) == 9


# Generated at 2022-06-23 20:56:06.054438
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    provider = RussiaSpecProvider()
    kpp = provider.kpp()
    assert len(kpp) == 9
    assert ' ' not in kpp
    assert kpp.isalnum()


# Generated at 2022-06-23 20:56:08.623378
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    provider = RussiaSpecProvider()
    ogrn = provider.ogrn()
    assert len(ogrn) == 13
    assert not (int(ogrn[-1]) % 11 % 10)

# Generated at 2022-06-23 20:56:15.491590
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    # Тест первый
    print('Тест первый')
    rus = RussiaSpecProvider()
    assert rus.generate_sentence() == 'Последний день работы не предшествует определенному деню.'

    # Тест второй
    print('Тест второй')
    rus = RussiaSpecProvider(seed=12345)

# Generated at 2022-06-23 20:56:21.469409
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    spec = RussiaSpecProvider()
    assert spec.patronymic()
    assert spec.patronymic(Gender.FEMALE)
    assert spec.patronymic(Gender.MALE)
    assert spec.generate_sentence()
    assert spec.series_and_number()
    assert spec.passport_number()
    assert spec.passport_series()
    assert spec.snils()
    assert spec.inn()
    assert spec.ogrn()
    assert spec.bic()
    assert spec.kpp()

# Generated at 2022-06-23 20:56:26.331686
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """
    Test the method passport_series of class RussiaSpecProvider.
    """
    provider = RussiaSpecProvider()
    assert len(provider.passport_series()) == 5


# Generated at 2022-06-23 20:56:28.336296
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    p = RussiaSpecProvider()
    assert len(str(p.passport_number())) == 6



# Generated at 2022-06-23 20:56:35.854175
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Test method series_and_number of class RussiaSpecProvider."""
    a1 = RussiaSpecProvider()
    a2 = RussiaSpecProvider()
    a3 = RussiaSpecProvider()
    a4 = RussiaSpecProvider()
    a5 = RussiaSpecProvider()
    assert a1.series_and_number() != a2.series_and_number() != a3.series_and_number() != a4.series_and_number() != a5.series_and_number()
    assert len(a1.series_and_number()) == 11
    assert type(a2.series_and_number()) is str
    assert type(a3.series_and_number()) is str
    assert type(a4.series_and_number()) is str
    assert type(a5.series_and_number()) is str


# Generated at 2022-06-23 20:56:37.289020
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    for i in range(100):
        assert len(RussiaSpecProvider().inn()) == 10

# Generated at 2022-06-23 20:56:39.312496
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11

# Generated at 2022-06-23 20:56:43.046398
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """Test generate passport number."""
    count = 100
    for _ in range(0, count):
        code = RussiaSpecProvider().passport_number()

        assert code < 1000000
        assert code > 100000

# Generated at 2022-06-23 20:56:47.572217
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    characteristics = {'inn_lenght': 10}
    assert RussiaSpecProvider().inn() in range(1000000000, 9999999999), 'ИНН должен быть длиной 10 цифр'

# Generated at 2022-06-23 20:56:51.493382
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    from mimesis.builtins.russia import RussiaSpecProvider
    rus = RussiaSpecProvider()
    print("ИНН:", rus.inn())

test_RussiaSpecProvider_inn()



# Generated at 2022-06-23 20:56:54.278728
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    russian_provider = RussiaSpecProvider()
    assert russian_provider.ogrn()=='4715113303725'

# Generated at 2022-06-23 20:57:03.929892
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    """Testing patronymic method"""
    ru_patr = RussiaSpecProvider()
    ru_patr_m = ru_patr.patronymic(Gender.MALE)
    ru_patr_f = ru_patr.patronymic(Gender.FEMALE)
    ru_patr_n = ru_patr.patronymic(Gender.NEUTRAL)
    ru_patr_a = ru_patr.patronymic()
    ru_patr_m_l = ru_patr.patronymic(Gender.MALE, False)
    ru_patr_f_l = ru_patr.patronymic(Gender.FEMALE, False)
    ru_patr_n_l = ru_patr.patronymic(Gender.NEUTRAL, False)


# Generated at 2022-06-23 20:57:05.351563
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    r = RussiaSpecProvider()
    assert r.random is not None


# Generated at 2022-06-23 20:57:06.956952
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    r = RussiaSpecProvider()
    assert isinstance(r, RussiaSpecProvider)



# Generated at 2022-06-23 20:57:10.700654
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    r = RussiaSpecProvider()
    sentence = r.generate_sentence()
    assert isinstance(sentence, str)


# Generated at 2022-06-23 20:57:12.784903
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider()
    result = provider.bic()
    assert len(result) == 9



# Generated at 2022-06-23 20:57:14.724277
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    rsp = RussiaSpecProvider()
    result = rsp.inn()
    assert len(result) == 10


# Generated at 2022-06-23 20:57:16.713492
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    """Unit test for method generate_sentence of class RussiaSpecProvider."""
    assert len(RussiaSpecProvider().generate_sentence().split()) == 4


# Generated at 2022-06-23 20:57:21.115410
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Unit test for method passport_series of class RussiaSpecProvider."""
    expected_result = '16 25'
    input_year = 16
    actual_result = RussiaSpecProvider().passport_series(input_year)

    assert actual_result == expected_result

# Generated at 2022-06-23 20:57:23.172824
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    assert type(RussiaSpecProvider().bic()) is str


# Generated at 2022-06-23 20:57:26.155933
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    rus_provider = RussiaSpecProvider(seed=1000)
    assert rus_provider.bic() == '044025575'



# Generated at 2022-06-23 20:57:29.736789
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Test case for method series_and_number of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    series_and_number = provider.series_and_number()
    assert len(series_and_number) == 11 and series_and_number.isdigit()



# Generated at 2022-06-23 20:57:31.714219
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    r = RussiaSpecProvider(seed=None)
    data = r.kpp()
    assert len(data) == 9
    assert data.isdigit()


# Generated at 2022-06-23 20:57:41.301636
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    """Test method patronymic of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    assert provider.patronymic() != provider.patronymic()
    assert provider.patronymic('male') != provider.patronymic('male')
    assert provider.patronymic('female') != provider.patronymic('female')
    assert provider.patronymic(Gender.MALE) != provider.patronymic(Gender.MALE)
    assert provider.patronymic(Gender.FEMALE) != provider.patronymic(Gender.FEMALE)

test_RussiaSpecProvider_patronymic()
