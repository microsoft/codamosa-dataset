

# Generated at 2022-06-23 20:47:43.310847
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider().snils() == '41917492600'

if __name__ == '__main__':
    test_RussiaSpecProvider_snils()

# Generated at 2022-06-23 20:47:47.274246
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    year = random.randint(10, 18)
    region = random.randint(1, 99)
    actual_output = '{:02d} {}'.format(region, year)
    assert RussiaSpecProvider().passport_series(year) == actual_output


# Generated at 2022-06-23 20:47:53.703770
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    provider = RussiaSpecProvider()
    inns = []
    for _ in range(50):
        inn = provider.inn()
        assert isinstance(inn, str)
        assert len(inn) == 12
        if inn in inns:
            print('Дублирующийся inn = {}'.format(inn))
        else:
            inns.append(inn)


# Generated at 2022-06-23 20:47:55.384437
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
  russian_provider = RussiaSpecProvider()
  return russian_provider.ogrn()


# Generated at 2022-06-23 20:47:58.166329
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    r = RussiaSpecProvider()
    # print("TEST patronymic..............................")
    # print("GENDER = MALE.....................",r.patronymic(Gender.MALE))
    # print("GENDER = FEMALE.....................",r.patronymic(Gender.FEMALE))
    # print("GENDER = NULL.....................",r.patronymic())


# Generated at 2022-06-23 20:48:01.173163
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils_rsp = rsp.snils()

    assert snils_rsp == "41917492600"

# Generated at 2022-06-23 20:48:04.146033
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    assert RussiaSpecProvider.generate_sentence() == 'Я вас любил только из побывавших'

# Generated at 2022-06-23 20:48:06.294659
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    snils = r.snils()
    assert snils in list(range(1000000000, 1500000000))

# Generated at 2022-06-23 20:48:19.415748
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    obj = RussiaSpecProvider()
    assert len(obj.ogrn()) == 13


# Generated at 2022-06-23 20:48:22.320662
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    # Setup
    spec = RussiaSpecProvider()
    # Exercise
    ogrn = spec.ogrn()
    # Verify
    assert len(ogrn) == 13
    for c in ogrn:
        assert '0' <= c <= '9'


# Generated at 2022-06-23 20:48:25.126800
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Unit test for RussiaSpecProvider.inn method."""
    ru = RussiaSpecProvider()
    assert len(ru.inn()) == 10


# Generated at 2022-06-23 20:48:26.492661
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    russia = RussiaSpecProvider()
    assert russia is not None

# Generated at 2022-06-23 20:48:29.777757
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    print("test_RussiaSpecProvider_passport_number")
    random_provider = RussiaSpecProvider()
    passport_number = random_provider.passport_number()
    assert len(str(passport_number)) == 6


# Generated at 2022-06-23 20:48:38.627432
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """The unit test for method snils of class RussiaSpecProvider."""
    russia_provider = RussiaSpecProvider()
    russia_provider.seed(42)
    snils = russia_provider.snils()
    assert snils == '41917492600'


# Generated at 2022-06-23 20:48:40.256887
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():

    assert len(RussiaSpecProvider().passport_number()) == 6


# Generated at 2022-06-23 20:48:43.091415
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    """Unit test for method bic of class RussiaSpecProvider."""

    import doctest
    doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE)

# Generated at 2022-06-23 20:48:45.064323
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    """Test method bic of class RussiaSpecProvider

    :return:
    """
    assert len(RussiaSpecProvider().bic()) == 9



# Generated at 2022-06-23 20:48:53.902749
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    rp = RussiaSpecProvider()
    assert rp.generate_sentence() == 'Иван Алексеев работал в детстве.'
    assert rp.generate_sentence() == 'Александр Иванов в школу не ходил.'
    assert rp.generate_sentence() == 'Владимир Сергеев читает хорошо.'

# Generated at 2022-06-23 20:49:02.877466
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Тест метода inn класса RussiaSpecProvider."""
    # Инициализация объекта
    rus = RussiaSpecProvider()
    # Вызов функции
    out = rus.inn()
    # Проверка типа выходных данных
    assert isinstance(out, str), 'Тип данных должен быть строка'
    # Проверка длины вы

# Generated at 2022-06-23 20:49:08.094582
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    spec = RussiaSpecProvider(seed=123)

    assert spec.locale == 'ru'
    assert len(spec.data) == 9

    with open('mimesis/locales/data/ru.json') as f:
        data = json.load(f)

    assert spec.data == data


# Generated at 2022-06-23 20:49:09.949818
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider(seed=0)
    assert provider.bic() == '044025575'


# Generated at 2022-06-23 20:49:12.048337
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Unit test for method ogrn of class RussiaSpecProvider."""
    assert RussiaSpecProvider().ogrn() == '4715113303725'



# Generated at 2022-06-23 20:49:19.228007
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    ru = RussiaSpecProvider()
    sentence_for_check = ru.generate_sentence()
    sentence_parts = sentence_for_check.split(' ')
    if not ru._data["sentence"]["head"]:
        if sentence_parts[0] not in ru._data["sentence"]["head"]:
            raise Exception("sentence_parts[0] don't equal to ru._data[\"sentence\"][\"head\"]")
    if not ru._data["sentence"]["p1"]:
        if sentence_parts[1] not in ru._data["sentence"]["p1"]:
            raise Exception("sentence_parts[1] don't equal to ru._data[\"sentence\"][\"p1\"]")

# Generated at 2022-06-23 20:49:21.173680
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    """Test RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    provider.snils()

# Generated at 2022-06-23 20:49:23.799678
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    r = RussiaSpecProvider(seed=7)

    series_and_number = r.series_and_number()
    assert series_and_number == '57 16 805199'

# Generated at 2022-06-23 20:49:33.475046
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    ob1 = RussiaSpecProvider(seed=555)
    str1 = ob1.series_and_number()
    assert str1 == '623192755777'
    str2 = ob1.series_and_number()
    assert str2 == '841252464283'
    ob2 = RussiaSpecProvider(seed=555)
    str3 = ob2.series_and_number()
    assert str3 == '623192755777'
    ob3 = RussiaSpecProvider(seed=556)
    str4 = ob3.series_and_number()
    assert str4 == '589596877353'
    ob4 = RussiaSpecProvider(seed=556)
    str5 = ob4.series_and_number()
    assert str5 == '589596877353'


# Generated at 2022-06-23 20:49:34.611174
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    assert RussiaSpecProvider.bic() == "044025575"


# Generated at 2022-06-23 20:49:37.137599
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    """Test initialisation."""
    rp = RussiaSpecProvider(seed=12345)
    assert rp is not None, 'Provider should be built'

    assert rp.random is not None, 'Provider should have a random instance'



# Generated at 2022-06-23 20:49:39.320489
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    provider = RussiaSpecProvider()
    num = provider.series_and_number()
    print(num)


# Generated at 2022-06-23 20:49:44.454069
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    rp = RussiaSpecProvider()
    str_passport_series = rp.passport_series()
    assert (len(str_passport_series) == 5)
    assert (str_passport_series[:2].isdigit())
    assert (str_passport_series[2] == ' ')
    assert (str_passport_series[-2:].isdigit())


# Generated at 2022-06-23 20:49:47.668215
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    test_object = RussiaSpecProvider()
    assert re.match(r'\d\d \d\d', test_object.passport_series()) is not None


# Generated at 2022-06-23 20:49:54.577226
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    from mimesis.enums import Gender

    # Test the default case
    assert len(RussiaSpecProvider().bic()) == 9
    # Test the case with a random seed
    assert len(RussiaSpecProvider(seed=456).bic()) == 9
    # Test the case when gender is specified
    assert len(RussiaSpecProvider().bic(Gender.MALE)) == 9



# Generated at 2022-06-23 20:49:56.400511
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    assert len(RussiaSpecProvider().bic()) == 9


# Generated at 2022-06-23 20:49:58.618368
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    ru = RussiaSpecProvider()
    ru.patronymic(Gender.MALE)
    ru.patronymic(Gender.FEMALE)


# Generated at 2022-06-23 20:49:59.875110
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider()
    print(provider.bic())

# Generated at 2022-06-23 20:50:03.777999
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    from mimesis.providers.base import BaseProvider
    rus_sentence = RussiaSpecProvider()
    text = rus_sentence.generate_sentence()
    assert len(text) > 1
    assert isinstance(text, str)
    assert isinstance(rus_sentence, BaseProvider)


# Generated at 2022-06-23 20:50:06.905437
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    rsp = RussiaSpecProvider()
    rsp._locale = 'ru'
    rsp.random.seed(42)
    # Provider returns a correct INN for a given seed
    assert rsp.inn() == '5505102912'


# Generated at 2022-06-23 20:50:09.032961
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    x = RussiaSpecProvider()
    a = x.ogrn()
    assert len(a) == 13


# Generated at 2022-06-23 20:50:11.797640
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    provider = RussiaSpecProvider(seed=12345)
    provider.random.seed(12345)
    provider.generate_sentence()  # Should not crash


# Generated at 2022-06-23 20:50:16.787419
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    rus = RussiaSpecProvider()
    for i in range(0, 20):
        series_and_number = rus.series_and_number()
        assert len(series_and_number) == 11
        assert series_and_number[:2].isdigit()
        assert series_and_number[2] == " "
        assert series_and_number[3:].isdigit()
        print(series_and_number)

# Generated at 2022-06-23 20:50:20.673338
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    import unittest

    class RussiaSpecProviderTestCase(unittest.TestCase):
        def setUp(self):
            self.russian_provider = RussiaSpecProvider()

        def test_passport_series(self):
            result = self.russian_provider.passport_series()
            self.assertRegex(result, '^\d{2}\s\d{2}$')
    unittest.main()

# Generated at 2022-06-23 20:50:29.547476
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider(): # pragma: no cover
    """Unit test for RussiaSpecProvider class."""
    print('Testing RussiaSpecProvider class')
    from mimesis import Person, Datetime
    from mimesis.providers.address import Address
    from mimesis.providers.money import Money
    from mimesis.providers.company import Company
    from IPython.display import Markdown, display
    from pprint import pprint
    import base64

    rus = RussiaSpecProvider()
    rus_person = Person(locale='ru')
    rus_date = Datetime(locale='ru')
    rus_money = Money(locale='ru')
    rus_address = Address(locale='ru')
    rus_company = Company(locale='ru')

    # Общие данны

# Generated at 2022-06-23 20:50:30.532097
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    assert RussiaSpecProvider().__init__() != None

# Generated at 2022-06-23 20:50:41.707838
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    provider = RussiaSpecProvider()
    kpp = provider.kpp()

# Generated at 2022-06-23 20:50:43.807038
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    provider = RussiaSpecProvider()
    assert provider.ogrn() == '4715113303725'

# Generated at 2022-06-23 20:50:47.742131
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    p = RussiaSpecProvider()
    assert p.patronymic(Gender.MALE) in p._data['patronymic'][Gender.MALE]
    assert p.patronymic(Gender.FEMALE) in p._data['patronymic'][Gender.FEMALE]



# Generated at 2022-06-23 20:50:50.887262
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """
    Test function of class RussiaSpecProvider.
    """
    
    rsp = RussiaSpecProvider(seed=1)
    result = rsp.inn()
    assert result == '780007152'
    
if __name__ == '__main__':
    test_RussiaSpecProvider_inn()

# Generated at 2022-06-23 20:50:54.378328
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    """Test constructor of class RussiaSpecProvider"""
    provider = RussiaSpecProvider(seed=1234)
    assert provider.seed == 1234
    assert provider.locale == 'ru'
    assert provider.language == 'ru'

# Generated at 2022-06-23 20:50:56.725901
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    import doctest
    doctest.testmod(verbose=True)


if __name__ == '__main__':
    test_RussiaSpecProvider_passport_number()

# Generated at 2022-06-23 20:50:59.990140
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils in ['41917492600', '4715113303725']

# Generated at 2022-06-23 20:51:02.140577
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    class Russian(RussiaSpecProvider):
        pass
    check = Russian()
    assert check.inn() != check.inn()



# Generated at 2022-06-23 20:51:05.774180
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    rus = RussiaSpecProvider()
    assert len(rus.kpp()) == 9
    print("Test unit_test_RussiaSpecProvider_kpp OK")
    print(rus.kpp())


# Generated at 2022-06-23 20:51:07.175622
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    print(RussiaSpecProvider().bic())


# Generated at 2022-06-23 20:51:08.503448
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    crp = RussiaSpecProvider()
    assert(type(crp) == RussiaSpecProvider)

# Generated at 2022-06-23 20:51:10.830193
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    rusprov = RussiaSpecProvider(seed=0)
    bic = rusprov.bic()
    assert isinstance(bic, str) and len(bic) == 9


# Generated at 2022-06-23 20:51:21.406627
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    # Проверка корректного создания объекта класса RussiaSpecProvider
    assert RussiaSpecProvider(seed=132) 
    # Создание объекта класса RussiaSpecProvider
    r = RussiaSpecProvider(seed=132)
    # Создание переменной для хранения вызова метода passport_number
    p = r.passport_number()
    # Проверка корректности

# Generated at 2022-06-23 20:51:32.406652
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Test method RussiaSpecProvider.inn()."""
    def to_int(s: str) -> int:
        return int(s)
    for _ in range(10):
        inn = RussiaSpecProvider(seed=_).inn()
        assert len(inn) == 12
        assert 0 < to_int(inn[:1]) < 10
        assert 0 <= to_int(inn[1:]) < 10**10
        assert to_int(inn[-2:]) == (sum(map(to_int, [n * i for i, n in enumerate(inn[:10], start=2)])) % 11 % 10)
        assert to_int(inn[-1:]) == (sum(map(to_int, [n * i for i, n in enumerate(inn[:11], start=1)])) % 11 % 10)

# Generated at 2022-06-23 20:51:38.999614
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    import unittest
    import re
    from mimesis.providers.russia import RussiaSpecProvider

    class TestRussiaSpecProvider_bic(unittest.TestCase):

        def setUp(self):
            self.rsp = RussiaSpecProvider('en')

        def test_bic(self):
            bic = self.rsp.bic()
            pattern = r'^[0-9]{9}$'
            assert pattern == re.compile(pattern).pattern
            assert re.findall(pattern, bic) != []

        def tearDown(self):
            del self.rsp

    unittest.main()


# Generated at 2022-06-23 20:51:45.786341
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    from mimesis.providers.geo.ru import RussiaSpecProvider

    russen = RussiaSpecProvider()

    assert len(russen.kpp()) == 9
    assert russen.kpp()[:4].isdigit()
    assert russen.kpp()[4:6].isdigit()
    assert russen.kpp()[5:8].isdigit()
    assert russen.kpp()[8].isdigit()



# Generated at 2022-06-23 20:51:47.843422
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    russia = RussiaSpecProvider()
    inn = russia.inn()
    assert inn == '7903605623'


# Generated at 2022-06-23 20:51:49.091369
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    assert RussiaSpecProvider._is_valid_inn(RussiaSpecProvider.inn())

# Generated at 2022-06-23 20:51:52.515400
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    test = RussiaSpecProvider.kpp()
    if len(test) != 9:
        print("test failed: Wrong number of digits in kpp: {}".format(test))
        failed("Method kpp of class RussiaSpecProvider failed")


# Generated at 2022-06-23 20:52:03.263834
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    provider = RussiaSpecProvider()
    assert '560058652' == provider.kpp()
    assert '560058652' == provider.kpp()
    assert '560058652' == provider.kpp()
    assert '560058652' == provider.kpp()
    assert '560058652' == provider.kpp()
    assert '560058652' == provider.kpp()
    assert '560058652' == provider.kpp()
    assert '560058652' == provider.kpp()
    assert '560058652' == provider.kpp()
    assert '560058652' == provider.kpp()
    assert '560058652' == provider.kpp()
    assert '560058652' == provider.kpp()

# Generated at 2022-06-23 20:52:12.574636
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    from mimesis.enums import Gender
    from mimesis.providers.person.ru import RussiaProvider
    from mimesis.providers.address import RussiaSpecProvider
    from mimesis.typing import Seed

    rsp = RussiaSpecProvider()
    rp = RussiaProvider(seed=Seed(1))

    passport_series = rsp.passport_series()

    assert rsp.passport_number() == '840189'
    assert rp.full_name(gender=Gender.MALE) == 'Станислав Савинин'
    assert rp.full_name(gender=Gender.FEMALE) == 'Евгения Вайнина'

# Generated at 2022-06-23 20:52:14.937283
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider()
    bic = provider.bic()
    assert len(bic) == int(10)

# Generated at 2022-06-23 20:52:17.554697
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rus = RussiaSpecProvider()
    snils = rus.snils()
    assert snils is not None, "snils is None"

# Generated at 2022-06-23 20:52:21.642763
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """Extract random passport number.

    :return: passport number

    """
    provider = RussiaSpecProvider()
    assert len(provider.passport_number()) == 6
    assert provider.passport_number() > 100000
    assert provider.passport_number() < 1000000

# Generated at 2022-06-23 20:52:23.470754
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    rsp = RussiaSpecProvider()
    assert len(rsp.series_and_number()) == 11


# Generated at 2022-06-23 20:52:25.807429
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    rsp = RussiaSpecProvider()
    result = rsp.generate_sentence()
    assert type(result) == str



# Generated at 2022-06-23 20:52:28.955516
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    from mimesis.builtins import RussiaSpecProvider

    ru = RussiaSpecProvider()
    ru.patronymic(Gender.FEMALE)
    ru.patronymic(Gender.MALE)
    ru.patronymic(Gender.NON_BINARY)


# Generated at 2022-06-23 20:52:36.499153
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    class LocalRussiaSpecProvider(RussiaSpecProvider):
        def __init__(self):
            super().__init__(seed=0)
            
    r = LocalRussiaSpecProvider()
    assert r.patronymic(Gender.MALE) == 'Алексеевич'
    assert r.patronymic(Gender.FEMALE) == 'Александровна'



# Generated at 2022-06-23 20:52:38.678605
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Unit test for method ogrn of class RussiaSpecProvider."""
    m = RussiaSpecProvider()
    assert len(m.ogrn()) == 13


# Generated at 2022-06-23 20:52:40.620211
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    provider = RussiaSpecProvider()
    inn = provider.inn()

    assert len(inn) == 10



# Generated at 2022-06-23 20:52:43.987897
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Test for RussiaSpecProvider.ogrn."""
    russia = RussiaSpecProvider()
    print(russia.ogrn())


if __name__ == '__main__':
    test_RussiaSpecProvider_ogrn()

# Generated at 2022-06-23 20:52:47.798250
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    from mimesis import RussiaSpecProvider
    r = RussiaSpecProvider()
    assert len(str(r.passport_number())) == 6
    assert 0 <= r.passport_number() <= 999999


# Generated at 2022-06-23 20:52:56.398439
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    ru = RussiaSpecProvider()
    ru_patr = ru.patronymic(Gender.FEMALE)
    ru_patr = ru.patronymic(Gender.MALE)
    ru_patr_f = ru.patronymic(Gender.FEMALE)
    ru_patr_m = ru.patronymic(Gender.MALE)
    ru_patr_f = ru.patronymic(Gender.FEMALE)
    ru_patr_m = ru.patronymic(Gender.MALE)
    ru_patr_f = ru.patronymic(Gender.FEMALE)
    ru_patr_m = ru.patronymic(Gender.MALE)
    ru_patr_f = ru.patronymic(Gender.FEMALE)
   

# Generated at 2022-06-23 20:53:07.072301
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    test_data = [
        {
            'year': 2010,
            'result': "02 10"
        },
        {
            'year': 2018,
            'result': "02 18"
        },
        {
            'year': 2021,
            'result': "02 21"
        },
        {
            'year': 2060,
            'result': "02 60"
        },
        {
            'year': 2010,
            'result': "02 10"
        },
    ]
    rs_provider = RussiaSpecProvider()
    for case in test_data:
        result = rs_provider.passport_series(year=case['year'])
        assert result == case['result']


# Generated at 2022-06-23 20:53:09.622407
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    spec = RussiaSpecProvider()
    assert spec.__class__.__name__ == 'RussiaSpecProvider'


# Generated at 2022-06-23 20:53:11.178873
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    r = RussiaSpecProvider()
    assert r.passport_series(year=16) == "02 16"

# Generated at 2022-06-23 20:53:20.451431
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Test for method passport_series of class RussiaSpecProvider."""
    from mimesis.providers import RussiaSpecProvider
    obj = RussiaSpecProvider()
    test_data = {
        'series': obj.passport_series(),
        'series_with_year': obj.passport_series(17),
    }
    assert len(test_data) == 2
    assert isinstance(test_data["series"], str)
    assert len(test_data["series"]) == 6
    assert isinstance(test_data["series_with_year"], str)
    assert len(test_data["series_with_year"]) == 6
    assert test_data["series_with_year"][-2:] == '17'


# Generated at 2022-06-23 20:53:22.784370
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    russiaspecprovider = RussiaSpecProvider()
    result = russiaspecprovider.ogrn()
    assert len(result) == 13

# Generated at 2022-06-23 20:53:25.335862
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    rsp = RussiaSpecProvider()

    length = len(rsp.bic())
    assert length == length == 9


# Generated at 2022-06-23 20:53:29.754851
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    import re
    random_number =  RussiaSpecProvider()
    passport_series = random_number.passport_series()
    pattern = re.compile('^\d{2} \d{2}$')
    assert re.match(pattern, passport_series)
    

# Generated at 2022-06-23 20:53:31.398854
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    import pytest
    assert RussiaSpecProvider is not None
    #TODO: write unit test to init

# Generated at 2022-06-23 20:53:32.742814
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    russia = RussiaSpecProvider()
    assert russia is not None


# Generated at 2022-06-23 20:53:42.459153
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    from mimesis.enums import Gender
    from mimesis.providers.person.en_US import ENUSPersonProvider
    from mimesis.providers.business.en_US import ENUSBUSProvider

    r = RussiaSpecProvider()
    p = ENUSPersonProvider('en')
    b = ENUSBUSProvider()

    inn_1 = r.inn()
    ogrn_1 = r.ogrn()

    inn_2 = r.inn()
    ogrn_2 = r.ogrn()

    # print(inn_1)
    # print(ogrn_1)
    # print()
    # print(inn_2)
    # print(ogrn_2)

    # output
    # print(r.patronymic(Gender.MALE))
    # Алексан

# Generated at 2022-06-23 20:53:54.121911
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    from mimesis.providers.helpers import uuid
    from mimesis.builders import RussiaSpecProviderBuilder
    seed = uuid()
    russiaspecprovider = RussiaSpecProviderBuilder(seed=seed)

# Generated at 2022-06-23 20:53:55.994225
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
  provider = RussiaSpecProvider()
  bic = provider.bic()
  assert bic.isdigit()
  assert len(bic)==9


# Generated at 2022-06-23 20:53:57.679019
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    rp = RussiaSpecProvider()
    pn = rp.passport_number()
    assert len(str(pn)) == 6


# Generated at 2022-06-23 20:54:01.305928
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Test for method series_and_number of class RussiaSpecProvider"""
    rsp = RussiaSpecProvider()
    print(rsp.series_and_number())


# Generated at 2022-06-23 20:54:11.345891
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    from mimesis.enums import Gender
    from random import randint
    provider = RussiaSpecProvider()
    gender_list = [0, 1, 2]
    gender = gender_list[randint(0, 2)]
    if gender == 0:
        assert provider.patronymic(Gender.FEMALE) != None
        assert provider.patronymic(Gender.MALE) != None
        assert provider.patronymic(Gender.NON_BINARY) != None
    if gender == 1:
        assert provider.patronymic(Gender.FEMALE) != None
    if gender == 2:
        assert provider.patronymic(Gender.MALE) != None



# Generated at 2022-06-23 20:54:14.347295
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    from mimesis.builtins import RussiaSpecProvider
    rs = RussiaSpecProvider()
    kpp = rs.kpp()
    assert len(kpp) == 10



# Generated at 2022-06-23 20:54:16.670437
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    a = RussiaSpecProvider()
    assert isinstance(a.bic(), str)
    assert len(a.bic()) == 9


# Generated at 2022-06-23 20:54:25.327153
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    provider = RussiaSpecProvider()
    ogrn_number = [] # List of random OGRN numbers
    check_result = [] # List of check results
    for number in range(0, 100, 1):
        ogrn_number.append(provider.ogrn)
    for number in ogrn_number:
        i = 1
        result = 0
        while i < 11:
            result += int(number[i])*(13-i)
            i += 1
        result = result % 11 % 10
        if result == int(number[12]):
            check_result.append('True')
        else:
            check_result.append('False')
    if check_result.count('True') == 100:
        print('Test RussiaSpecProvider_ogrn: passed.')

# Generated at 2022-06-23 20:54:26.110864
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    r = RussiaSpecProvider()
    assert r.__class__.__name__ == "RussiaSpecProvider"


# Generated at 2022-06-23 20:54:28.913329
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    from mimesis.providers.person.en import Person

    person = Person('ru')
    russia = RussiaSpecProvider('ru')
    name = russia.name(person.gender)
    surname = russia.surname(person.gender)
    patronymic = russia.patronymic(person.gender)
    ogrn = russia.ogrn()
    assert len(ogrn) == 13

# Generated at 2022-06-23 20:54:29.522019
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    return RussiaSpecProvider()


# Generated at 2022-06-23 20:54:31.185371
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    # -------------------------------------------------------
    # TODO:
    #   1) Add assertions for the method.
    # -------------------------------------------------------
    rsp = RussiaSpecProvider()
    rsp.patronymic()


# Generated at 2022-06-23 20:54:32.825561
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    seed = '5bfd719ed939b929f966c6a2'
    rsp = RussiaSpecProvider(seed=seed)

    assert rsp.series_and_number() == '4716090795'

# Generated at 2022-06-23 20:54:34.584844
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    a = RussiaSpecProvider()
    assert isinstance(a.passport_series(), str)


# Generated at 2022-06-23 20:54:37.303580
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """
    Check that the snils method generates an integer.

    :return: bool.
    """
    provider = RussiaSpecProvider()
    assert isinstance(provider.snils(), int)

# Generated at 2022-06-23 20:54:38.938087
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    import mimesis
    provider = mimesis.RussiaSpecProvider()
    control_value = '{}{}'.format(provider.passport_series(), provider.passport_number())
    assert control_value == provider.series_and_number()


# Generated at 2022-06-23 20:54:40.662720
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """Unit test for method kpp of class RussiaSpecProvider."""
    pass


# Generated at 2022-06-23 20:54:44.223908
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    r = RussiaSpecProvider()
    assert(len(r.ogrn()) == 13 and r.ogrn().isdigit())


# Generated at 2022-06-23 20:54:46.307602
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider()
    assert len(provider.bic()) == 9


# Generated at 2022-06-23 20:54:49.607547
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    rus = RussiaSpecProvider()
    gender = rus._validate_enum(None, Gender)
    rus.patronymic(gender=gender)


# Generated at 2022-06-23 20:54:52.379964
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Unit tests."""
    r = RussiaSpecProvider()
    assert len(r.series_and_number()) == 10
    assert r.series_and_number()


# Generated at 2022-06-23 20:54:54.421795
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    r = RussiaSpecProvider()
    a = r.kpp()
    assert a != None


# Generated at 2022-06-23 20:55:03.591795
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    provider = RussiaSpecProvider()
    # Check for correct length
    assert (len(provider.inn()) == 12)
    # Check for first digit is not a zero
    assert (str(provider.inn())[0] != '0')
    # Check for correct controlsum
    def control_sum(nums: list, t: str) -> int:
        digits_dict = {
            'n2': [7, 2, 4, 10, 3, 5, 9, 4, 6, 8],
            'n1': [3, 7, 2, 4, 10, 3, 5, 9, 4, 6, 8],
        }
        number = 0
        digits = digits_dict[t]

        for i, _ in enumerate(digits, start=0):
            number += nums[i] * digits[i]
        return

# Generated at 2022-06-23 20:55:12.205145
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    from mimesis.providers.business import BusinessSpecProvider
    from mimesis.providers.address import AddressSpecProvider
    russ = RussiaSpecProvider()
    bus = BusinessSpecProvider()
    adr = AddressSpecProvider()
    bankname = bus.company_name()
    bn_len = len(bankname)
    branch = bus.company_name()
    adr = adr.address()
    adr_len = len(adr)
    biccode = russ.bic()
    #print(biccode)
    if (bn_len > 5) and (adr_len > 5):
        bank_code = bankname[0:4]
        branch_code = branch[0:4]
        area_code = adr[0:4]

# Generated at 2022-06-23 20:55:21.648795
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    r = RussiaSpecProvider(seed=100)
    assert r.inn() == '7715159661'
    assert r.inn() == '9338312347'
    assert r.inn() == '3785635236'
    assert r.inn() == '2328448368'
    assert r.inn() == '3009447249'
    assert r.inn() == '4857788074'
    assert r.inn() == '8861385458'
    assert r.inn() == '8591518653'
    assert r.inn() == '2497286249'
    assert r.inn() == '1912702472'
    assert r.inn() == '9428073055'
    assert r.inn() == '1531807748'
    assert r.inn() == '5098716039'
   

# Generated at 2022-06-23 20:55:28.408847
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    rus = RussiaSpecProvider()
    rus.inn() == rus.inn()
    rus.ogrn() == rus.ogrn()
    rus.kpp() == rus.kpp()
    rus.bic() == rus.bic()
    rus.patronymic(Gender.FEMALE) == rus.patronymic(Gender.FEMALE)

# Generated at 2022-06-23 20:55:32.544270
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    # import pylint: disable=no-member
    # import pylint: disable=too-few-public-methods
    class Foo(RussiaSpecProvider):
        pass
    foo = Foo()
    assert foo._data



# Generated at 2022-06-23 20:55:32.946543
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    pass

# Generated at 2022-06-23 20:55:38.764209
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    rsp = RussiaSpecProvider()
    print("Generate sentence: ", rsp.generate_sentence())
    print("Generate patronymic: ", rsp.patronymic())
    print("Generate passport_series: ", rsp.passport_series())
    print("Generate passport_number: ", rsp.passport_number())
    print("Generate series_and_number: ", rsp.series_and_number())
    print("Generate snils: ", rsp.snils())
    print("Generate inn: ", rsp.inn())
    print("Generate ogrn: ", rsp.ogrn())
    print("Generate bic: ", rsp.bic())
    print("Generate kpp: ", rsp.kpp())

# Generated at 2022-06-23 20:55:41.073975
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    """Check create a instance of class RussiaSpecProvider().

    :return:
    """
    provider = RussiaSpecProvider()
    assert provider is not None

# Generated at 2022-06-23 20:55:44.301156
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():

    provider = RussiaSpecProvider()
    assert provider.gender() != provider.random.choice([Gender.MALE, Gender.FEMALE])

# Generated at 2022-06-23 20:55:45.738110
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    rsp = RussiaSpecProvider()
    assert rsp is not None

# Generated at 2022-06-23 20:55:55.396439
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    rus = RussiaSpecProvider()
    assert rus.provider.seed == rus.random.seed

# Generated at 2022-06-23 20:56:03.101555
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    from mimesis.models import Person
    from mimesis.providers.person import PersonProvider
    from mimesis.providers.russia_provider import RussiaSpecProvider
    eng = Person()
    rus = Person(locale='ru', providers=(RussiaSpecProvider, PersonProvider))

# Generated at 2022-06-23 20:56:13.030047
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test RussiaSpecProvider.snils()."""
    from mimesis import RussiaSpecProvider
    rus = RussiaSpecProvider()
    data = rus.snils()
    assert len(data) == 11
    data = rus.snils()
    assert len(data) == 11
    data = rus.snils()
    assert len(data) == 11
    data = rus.snils()
    assert len(data) == 11
    data = rus.snils()
    assert len(data) == 11
    data = rus.snils()
    assert len(data) == 11
    data = rus.snils()
    assert len(data) == 11
    data = rus.snils()
    assert len(data) == 11
    data = rus.snils()

# Generated at 2022-06-23 20:56:15.598778
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    test_object = RussiaSpecProvider(seed=123)
    assert test_object.kpp() == '126002705'


# Generated at 2022-06-23 20:56:18.331364
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    rsp = RussiaSpecProvider()
    output = rsp.patronymic(Gender.MALE)
    assert output in rsp._data['patronymic'][Gender.MALE]


# Generated at 2022-06-23 20:56:19.567557
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    RussiaSpecProvider.generate_sentence()

# Generated at 2022-06-23 20:56:31.243380
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    provider = RussiaSpecProvider(seed=42)
    assert provider.inn() == '8877841223'
    assert provider.snils() == '68637263611'
    assert provider.ogrn() == '4715113303725'
    assert provider.bic() == '044895083'
    assert provider.kpp() == '680016680'
    assert provider.passport_series() == '91 10'
    assert provider.passport_number() == 829652
    assert provider.series_and_number() == '91 10829652'
    assert provider.patronymic(gender=Gender.MALE) == 'Александрович'

# Generated at 2022-06-23 20:56:36.177540
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    russia= RussiaSpecProvider()

    assert russia.data['name'] is not None
    assert russia.data['last_name'] is not None
    assert russia.data['patronymic'] is not None
    assert russia.data['sentence'] is not None

# Generated at 2022-06-23 20:56:37.908866
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    rsp = RussiaSpecProvider()
    rsp.series_and_number()


# Generated at 2022-06-23 20:56:42.844683
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    r = RussiaSpecProvider()
    for i in range(0,10000):
        kpp = r.kpp()
        assert kpp[0] in ['7', '8', '5', '0', '9']
        assert kpp[1] in ['7', '8']
        assert len(kpp) == 9


# Generated at 2022-06-23 20:56:51.075366
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    from mimesis.providers.person import Person
    from mimesis.enums import Gender
    from mimesis.types import Constants
    ru = RussiaSpecProvider()
    ru.seed(0)
    ru1 = RussiaSpecProvider()
    ru1.seed(0)
    for i in range(0, 10):
        ru.passport_series()
        ru1.passport_series()
    result = ru.passport_series()
    expected = ru1.passport_series()
    assert result == expected


# Generated at 2022-06-23 20:56:53.165225
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    r = RussiaSpecProvider()
    assert r.provider.name == 'russia_provider'


# Generated at 2022-06-23 20:56:55.348808
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    ru = RussiaSpecProvider()
    sentence = ru.generate_sentence()
    assert len(sentence) > 0

# Generated at 2022-06-23 20:57:04.089514
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    """Method test_RussiaSpecProvider_patronymic."""
    from mimesis.enums import Gender
    from mimesis.providers import RussiaSpecProvider
    rus = RussiaSpecProvider()
    assert rus.patronymic(gender=Gender.MALE) in rus._data['patronymic'][Gender.MALE]
    assert rus.patronymic(gender=Gender.FEMALE) in rus._data['patronymic'][Gender.FEMALE]
    assert rus.patronymic() in rus._data['patronymic'][Gender.FEMALE]
    assert rus.patronymic() in rus._data['patronymic'][Gender.MALE]
    assert rus.patronymic(gender=Gender.UNKNOWN) in rus._

# Generated at 2022-06-23 20:57:07.654545
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    # Arrange
    r = RussiaSpecProvider(seed = 3)
    expected = '89 10'

    # Act
    actual = r.passport_series(2019)

    # Assert
    assert actual == expected


# Generated at 2022-06-23 20:57:11.962841
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert isinstance(snils, str)
    assert len(snils) == 11


# Generated at 2022-06-23 20:57:14.450918
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    rsp = RussiaSpecProvider()
    data = rsp.inn()
    assert isinstance(data, str)
    assert len(data) == 10



# Generated at 2022-06-23 20:57:15.302718
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    a = RussiaSpecProvider()



# Generated at 2022-06-23 20:57:18.320471
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    rp = RussiaSpecProvider()
    rp.seed(0)
    assert rp.patronymic(Gender.MALE) == 'Иванович'
    assert rp.patronymic(Gender.FEMALE) == 'Александровна'


# Generated at 2022-06-23 20:57:21.662361
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    """Unit test for method generate_sentence of class
    RussiaSpecProvider."""
    russia = RussiaSpecProvider()
    assert russia.generate_sentence().split(' ')

# Generated at 2022-06-23 20:57:24.246187
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    instance = RussiaSpecProvider()
    res = instance.series_and_number()
    print(res)

# Generated at 2022-06-23 20:57:26.873674
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    from mimesis import Address
    import time
    assert len(Address.RussiaSpecProvider().passport_series(
        time.localtime().tm_year - 2000)) == 5

# Generated at 2022-06-23 20:57:29.110312
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    with pytest.raises(ValueError):
        _ = RussiaSpecProvider().passport_number()
    assert len(RussiaSpecProvider().passport_number())==6


# Generated at 2022-06-23 20:57:34.009578
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    rs = RussiaSpecProvider()
    for i in range(0, 10):
        sentence = rs.generate_sentence()
        assert len(sentence) <= 146
        assert ' ' in sentence
        assert sentence.endswith(('.', '?', '!'))


# Generated at 2022-06-23 20:57:36.567812
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    # result of function must be string
    assert type(RussiaSpecProvider().passport_series()) is str


# Generated at 2022-06-23 20:57:38.291714
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    assert RussiaSpecProvider().ogrn() == '4715113303725'



# Generated at 2022-06-23 20:57:45.260908
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    from random import randint
    from itertools import product

    def get_checksum_kpp():
        """Calculate checksum for kpp.

        :return: str.

        """
        def f_multiply(list_of_digits):
            """Function to multiply digits of number.

            :param list_of_digits: List of digits.
            :type list_of_digits: list
            :return: int. Product of digits of number.

            """
            product = 1
            for digit in list_of_digits:
                product *= digit

            return product
