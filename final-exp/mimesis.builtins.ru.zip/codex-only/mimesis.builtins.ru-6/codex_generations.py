

# Generated at 2022-06-23 20:47:47.617617
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    r = RussiaSpecProvider()
    series_and_number = r.series_and_number()
    series_and_number_by_parts = '{}{}'.format(r.passport_series(), r.passport_number())
    assert series_and_number == series_and_number_by_parts

# Generated at 2022-06-23 20:47:50.956293
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Unit test for method ogrn of class RussiaSpecProvider."""
    assert len(RussiaSpecProvider().ogrn()) == 13
    assert RussiaSpecProvider().ogrn().isdigit() is True


# Generated at 2022-06-23 20:47:52.482934
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    provider = RussiaSpecProvider()
    provider.inn()

    print(provider.inn())

# Generated at 2022-06-23 20:47:59.617698
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Test for method ogrn of ckass RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    assert len(provider.ogrn()) == 13
    assert provider.ogrn()[6] != 0
    assert provider.ogrn()[7] != 0
    assert provider.ogrn()[8] != 0
    assert provider.ogrn()[9] != 0
    assert provider.ogrn()[10] != 0
    assert provider.ogrn()[11] != 0
    assert provider.ogrn()[12] != 0


# Generated at 2022-06-23 20:48:07.320556
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():

    ru = RussiaSpecProvider()
    ru_seed = RussiaSpecProvider()

    assert ru.ogrn() != ru_seed.ogrn()
    assert ru.ogrn() != ru_seed.ogrn()
    assert ru.ogrn() != ru_seed.ogrn()
    assert ru.ogrn() != ru_seed.ogrn()
    assert ru.ogrn() != ru_seed.ogrn()
    assert ru.ogrn() != ru_seed.ogrn()
    assert ru.ogrn() != ru_seed.ogrn()
    assert ru.ogrn() != ru_seed.ogrn()
    assert ru.ogrn() != ru_seed.ogrn()
    assert ru.ogrn() != ru_seed.ogrn()
    assert ru.ogrn() != ru_seed.ogrn()
    assert ru.og

# Generated at 2022-06-23 20:48:08.585769
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    rsp = RussiaSpecProvider()
    assert rsp.bic() == '044025575'

# Generated at 2022-06-23 20:48:17.146840
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    # Arrange
    r = RussiaSpecProvider()

    # Act
    for i in range(100):
        print(r.series_and_number())

    # Problem:
    # Для большинства случаев генерируются
    # паспорта с номером серии 02 15
    # Пробовал разные варианты генерации серии,
    # но проблема остается.
    # Возможн

# Generated at 2022-06-23 20:48:20.369371
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence(): 
    ru_SP = RussiaSpecProvider()
    ru_SP.seed(3.0)
    ru_SP.generate_sentence() == 'Погоним по уровнем даже с подружками.'


# Generated at 2022-06-23 20:48:21.991934
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    from random import seed
    from mimesis.builtins import RussiaSpecProvider
    seed(0)
    assert RussiaSpecProvider().passport_number() == 649122


# Generated at 2022-06-23 20:48:24.834298
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    rus = RussiaSpecProvider()
    k = rus.kpp()
    assert len(k) == 9


# Generated at 2022-06-23 20:48:34.218219
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Unit test for method ogrn of class RussiaSpecProvider."""
    from mimesis.providers.finance import Finance
    from mimesis.enums import Gender

    gender = Gender.FEMALE
    for _ in range(5):
        rsp = RussiaSpecProvider()
        fp = Finance()
        # NOTE: These variable just for output purposes
        gender_dict = {
            Gender.FEMALE: 'She',
            Gender.MALE: 'He',
        }
        gender_str = 'Her'
        if gender == Gender.MALE:
            gender_str = 'His'

        print('{0} passport series and number is {1}'.format(
            gender_dict[gender],
            rsp.series_and_number(),
        ))

# Generated at 2022-06-23 20:48:39.530863
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Unit test for OGRN."""
    from mimesis.providers.russia_provider import RussiaSpecProvider
    rsp = RussiaSpecProvider()
    for _ in range(0, 10):
        ogrn = rsp.ogrn()
        assert 12 <= len(ogrn)
        assert isinstance(ogrn, str)


# Generated at 2022-06-23 20:48:45.275140
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    country = RussiaSpecProvider()

    assert country.patronymic(gender=Gender.MALE) != ''
    assert country.passport_series() != ''
    assert country.passport_number() != ''
    assert country.series_and_number() != ''
    assert country.snils() != ''
    assert country.inn() != ''
    assert country.ogrn() != ''
    assert country.bic() != ''
    assert country.kpp() != ''

# Generated at 2022-06-23 20:48:49.709012
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Test method inn() of class RussiaSpecProvider"""
    provider = RussiaSpecProvider()
    assert provider._len_check(11, provider.inn())


# Generated at 2022-06-23 20:48:51.565600
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    ru = RussiaSpecProvider()
    assert ru.bic() == '044025575'


# Generated at 2022-06-23 20:48:52.549935
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    assert RussiaSpecProvider().ogrn()



# Generated at 2022-06-23 20:48:54.549425
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Test method RussiaSpecProvider.inn"""
    rus = RussiaSpecProvider()
    assert len(rus.inn()) == 10


# Generated at 2022-06-23 20:48:56.462410
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    provider = RussiaSpecProvider()
    result = provider.generate_sentence()
    assert isinstance(result, str)
    assert len(result) < 128

# Generated at 2022-06-23 20:49:04.175999
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Unit test for method ogrn of class RussiaSpecProvider."""
    data = {
        "120012296122": "312300058073",
        "120021300919": "312300058074",
        "120021900122": "312300058075",
        "120021900300": "312300058076",
        "120021900700": "312300058077",
        "120022300122": "312300058078",
        "120022300300": "312300058079",
        "120022300700": "312300058080",
        "120022301122": "312300058081",
        "120022301300": "312300058082"
    }

    for index in data.keys():
        res = RussiaSpecProvider(seed=index).ogrn()

# Generated at 2022-06-23 20:49:12.563059
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    # Test for method ogrn of class RussiaSpecProvider.
    # Create instance of class RussiaSpecProvider
    rus = RussiaSpecProvider()
    # Generate OGRN for test
    ogrn = rus.ogrn()
    # Initialize variable for last digit of generated OGRN
    last_digit = int(ogrn[-1])
    # Initialize variable with OGRN except last digit
    ogrn_test = int(ogrn[:-1])
    # Check right OGRN's last digit
    assert last_digit == ogrn_test % 11 % 10

# Generated at 2022-06-23 20:49:18.644834
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    rsp = RussiaSpecProvider()

    output_ogrn = rsp.ogrn()
    print(f"\n Проверка. Возвращаемый номер ОГРН получен из кода RussiaSpecProvider.ogrn(): {output_ogrn}.")

    ogrn_digit_counter = len(output_ogrn)
    print(f"\n Проверка. Функция сгенерировала номер ОГРН из {ogrn_digit_counter} цифр.")
    ogrn_

# Generated at 2022-06-23 20:49:19.461387
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    pass

# Generated at 2022-06-23 20:49:22.709922
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    r = RussiaSpecProvider()
    ls = []
    for i in range(0, 100):
        rnd = r.ogrn()
        ls.append(rnd)
    return ls


# Generated at 2022-06-23 20:49:30.772207
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    for _ in range(0, 10000):
        snils = provider.snils()
        numbers = []
        control_codes = []
        for i in range(0, 9):
            numbers.append(int(snils[i]))

        for i in range(9, 0, -1):
            control_codes.append(numbers[9 - i] * i)

        control_code = sum(control_codes)
        code = int(snils[:9])

        if control_code == 100 or control_code == 101:
            assert code % 101 == 0
            assert control_code == 100 or control_code == 101
        if control_code < 100:
            assert control_code == code % 101

# Generated at 2022-06-23 20:49:40.097542
# Unit test for method patronymic of class RussiaSpecProvider

# Generated at 2022-06-23 20:49:43.313603
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():

    expected = '044025575'
    actual = RussiaSpecProvider().bic()

    print('test_object_bic_value: ' + str(actual) + ' == ' + str(expected))
    assert actual == expected


# Generated at 2022-06-23 20:49:52.020685
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    rype = RussiaSpecProvider()
    rype.seed(3)
    person = Person('ru')

    assert rype.ru.kpp() == "7800300011", "Failed kpp test"
    assert rype.ru.passport_series() == "02 15", "Failed passport_series"
    assert rype.ru.passport_number() == 560430, "Failed passport_number test"
    assert rype.ru.series_and_number() == "57 16 805199", "Failed series_and_number test"
    assert rype.ru.patronymic(gender=Gender.FEMALE) == "Ивановна", "Failed patronymic test"
   

# Generated at 2022-06-23 20:49:55.744416
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    g = RussiaSpecProvider()
    assert len(g.passport_series()) == 5
    assert type(g.passport_series()) is str


# Generated at 2022-06-23 20:49:59.485849
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    test_passport_number = RussiaSpecProvider().passport_number()
    if test_passport_number < 100000 or test_passport_number > 999999:
         raise AssertionError("passport_number() != int(range(100000, 999999))")


# Generated at 2022-06-23 20:50:02.247753
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.enums import Gender
    provider = RussiaSpecProvider()
    gender = Gender.MALE
    passport = provider.snils()
    print(passport)


# Generated at 2022-06-23 20:50:05.587113
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    method = "bic"
    result = RussiaSpecProvider().bic()
    assert type(result) == str, "Return type of method bic() is not str"
    assert len(result) == 9, "Wrong result of method bic()"
    print(f"{method}() = {result}")


# Generated at 2022-06-23 20:50:07.363057
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    provider = RussiaSpecProvider()
    data = provider.generate_sentence()
    assert len(data) >= 10



# Generated at 2022-06-23 20:50:13.722900
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    import unittest
    import re

    class RussiaSpecProviderTestCase(unittest.TestCase):
        def setUp(self):
            self.provider = RussiaSpecProvider()

        def test_kpp(self):
            res = self.provider.kpp()
            assert len(res) == 9
            match = re.match(r'[0-9]{9}', res)
            assert match

    unittest.main()

# Generated at 2022-06-23 20:50:17.228184
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    from mimesis.providers.russia_provider import RussiaSpecProvider
    from mimesis.enums import Gender
    g = RussiaSpecProvider(seed=12345)
    assert g.bic() == '044025575'


# Generated at 2022-06-23 20:50:19.344116
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    provider = RussiaSpecProvider()
    number = provider.passport_number()
    assert len(str(number)) == 6
    assert isinstance(number, int)


# Generated at 2022-06-23 20:50:21.730015
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    # Given
    russia_provider = RussiaSpecProvider()
    # When
    inn = russia_provider.inn()
    # Then
    assert len(inn) == 12


# Generated at 2022-06-23 20:50:22.864349
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    inn_provider = RussiaSpecProvider()
    inn = inn_provider.inn()
    assert len(inn) == 12


# Generated at 2022-06-23 20:50:30.864928
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    # Arrange
    provider = RussiaSpecProvider()
    # Act
    sentence = provider.generate_sentence()
    patronymic = provider.patronymic()
    passport_series = provider.passport_series()
    passport_number = provider.passport_number()
    series_and_number = provider.series_and_number()
    inn = provider.inn()
    snils = provider.snils()
    ogrn = provider.ogrn()
    bic = provider.bic()
    kpp = provider.kpp()
    # Assert
    assert sentence is not None
    assert patronymic is not None
    assert passport_series is not None
    assert passport_number is not None
    assert series_and_number is not None
    assert inn is not None
    assert snils is not None
   

# Generated at 2022-06-23 20:50:39.470559
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Написать тесты на каждый метод и проверить его правильность.

    Создать отдельный файл для теста unittest.
    """
    rsp = RussiaSpecProvider()
    assert rsp.ogrn() == '4715113303725'

# Generated at 2022-06-23 20:50:41.904178
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    for method in ([RussiaSpecProvider(seed=123).series_and_number]):
        assert len(method()) == 11

# Generated at 2022-06-23 20:50:46.098645
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    import datetime
    x = str(datetime.datetime.now())
    spr = RussiaSpecProvider(seed=x)
    assert spr.seed == x
    x = str(datetime.datetime.now())
    spr = RussiaSpecProvider(seed=x)
    assert spr.seed == x


# Generated at 2022-06-23 20:50:55.306849
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    """Unit test for RussiaSpecProvider"""
    rus = RussiaSpecProvider()
    rus.seed(4)
    assert rus.generate_sentence() == 'Во время прогулки она позвонила в дверь.'
    assert rus.patronymic(Gender.MASCULINE) == 'Викторович'
    assert rus.patronymic(Gender.MASCULINE) == 'Викторович'
    assert rus.patronymic(Gender.FEMININE) == 'Павловна'

# Generated at 2022-06-23 20:51:05.867428
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """This is a test for method ogrn."""
    seed = 'test_RussiaSpecProvider_ogrn'
    ru_provider = RussiaSpecProvider(seed)
    ru_provider.random.seed(seed)
    random_ogrn = ru_provider.ogrn()
    expected_ogrn_number = '4715113303725'
    assert random_ogrn == expected_ogrn_number
    assert len(random_ogrn) == 13
    assert random_ogrn == ru_provider.ogrn(seed=seed)
    # Test for a different seed.
    ru_provider.random.seed('another seed')
    assert ru_provider.ogrn() != expected_ogrn_number


# Generated at 2022-06-23 20:51:09.092874
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """Unit test for method kpp of class RussiaSpecProvider."""
    from mimesis.providers.russia import RussiaSpecProvider
    rsp = RussiaSpecProvider('ru')
    assert len(rsp.kpp()) == 9

# Generated at 2022-06-23 20:51:11.144487
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    rs = RussiaSpecProvider()
    ogrn = rs.ogrn()
    assert len(set(ogrn)) == 1

# Generated at 2022-06-23 20:51:16.182734
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    import pytest
    rup = RussiaSpecProvider()
    # check length
    assert len(rup.bic()) == 9
    # check if string
    assert isinstance(rup.bic(), str)
    # check if string starts with 0
    assert rup.bic().startswith("0") == True

# Generated at 2022-06-23 20:51:18.879503
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider()
    s = provider.bic()
    assert len(s) == 9

if __name__ == "__main__":
    provider = RussiaSpecProvider()
    print(provider.bic())

# Generated at 2022-06-23 20:51:22.987307
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    instance_1 = RussiaSpecProvider()
    instance_2 = RussiaSpecProvider(seed=42)
    instance_3 = RussiaSpecProvider(seed='42')

    assert isinstance(instance_1, RussiaSpecProvider)
    assert instance_1 != instance_2
    assert instance_2 == instance_3


# Generated at 2022-06-23 20:51:30.212537
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """
    This test checks the correctness of the method passport_series(RussiaSpecProvider).
    #TODO: Change test when country will changed.
    """
    provider = RussiaSpecProvider()
    test_series = provider.passport_series(20)
    assert test_series[0:2] < '10'
    assert test_series[0:2] > '99'
    int(test_series[2:4])


# Generated at 2022-06-23 20:51:35.733596
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    # generate 10000 ogrn and check it
    ogrns = []
    test_provider = RussiaSpecProvider()
    control = 0
    for _ in range(0, 10000):
        ogrn = test_provider.ogrn()
        ogrns.append(ogrn)
        if len(ogrn) != 13:
            control += 1
    assert len(ogrns) - len(list(set(ogrns))) == 0
    assert control == 0

# Generated at 2022-06-23 20:51:38.706369
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Unit test for method inn of class RussiaSpecProvider.

    :return: None
    """
    pattern = '\d{7}(1|2)'
    result = RussiaSpecProvider().inn()
    assert len(result) == 9
    assert re.search(pattern, result)


# Generated at 2022-06-23 20:51:40.439794
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    ru = RussiaSpecProvider()
    kpp = ru.kpp()
    if kpp == None:
        raise ValueError('The test for method kpp of class RussiaSpecProvider is failed')

# Generated at 2022-06-23 20:51:46.016787
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Unit test for method ogrn of class RussiaSpecProvider."""
    ogrn = RussiaSpecProvider()
    ogrn_1 = ogrn.ogrn()
    ogrn_2 = ogrn.ogrn()
    assert isinstance(ogrn_1, str)
    assert len(ogrn_1) == 13
    assert (ogrn_1 != ogrn_2)


# Generated at 2022-06-23 20:51:51.598787
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    rsp = RussiaSpecProvider()
    # Series is always 2 digits, space and year
    assert len(rsp.passport_series(18)) == 4
    assert len(rsp.passport_series(18)) == 4
    assert len(rsp.passport_series(18)) == 4
    assert len(rsp.passport_series(18)) == 4
    assert len(rsp.passport_series(18)) == 4
    assert len(rsp.passport_series(18)) == 4
    assert len(rsp.passport_series(18)) == 4
    assert len(rsp.passport_series(18)) == 4
    assert len(rsp.passport_series(18)) == 4
    assert len(rsp.passport_series(18)) == 4
    # Year is always two digits


# Generated at 2022-06-23 20:51:53.870930
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    ru_spec = RussiaSpecProvider(seed=42)
    print(ru_spec.series_and_number())

# Generated at 2022-06-23 20:51:58.879903
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Test method inn of class RussiaSpecProvider"""
    from mimesis.enums import Gender
    from mimesis.providers import RussiaSpecProvider
    from mimesis.exceptions import NonEnumerableError
    from mimesis.typing import Seed

    russia = RussiaSpecProvider(seed=12345)

    print(russia.inn())
    # 5038124767



# Generated at 2022-06-23 20:52:02.438061
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    provider = RussiaSpecProvider()
    kpp = provider.kpp()
    assert len(kpp) == 9
    assert int(kpp) > 0
    print(kpp)



# Generated at 2022-06-23 20:52:05.320725
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender

    rsp = RussiaSpecProvider()
    for i in range(0,10):
        assert len(rsp.series_and_number()) == 11


# Generated at 2022-06-23 20:52:09.007245
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    '''
    Generate random sentence
    :return: random sentence
    '''
    rus_spec_provider = RussiaSpecProvider()
    sentences = rus_spec_provider.generate_sentence()
    return sentences


# Generated at 2022-06-23 20:52:15.800688
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    # проверка функции OGRN
    # проверять будем на регулярке
    import re
    from mimesis import RussianSpecProvider
    rp = RussianSpecProvider()
    ogrn = rp.ogrn()
    res = re.fullmatch(r'\d{13}', ogrn)
    if res == None:
        raise Exception('not valid ogrn')
    ogrn_first_12_digits = ogrn[0:12]
    ogrn_last_digit = ogrn[12]
    print(ogrn_first_12_digits)
    print(ogrn_last_digit)

# Generated at 2022-06-23 20:52:17.798834
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
	x = RussiaSpecProvider()
	assert isinstance(x.patronymic(), str) 


# Generated at 2022-06-23 20:52:20.592081
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    russianSpecs = RussiaSpecProvider()
    assert russianSpecs.patronymic() in russianSpecs._data['patronymic'][Gender.FEMALE]\
        or russianSpecs.patronymic() in russianSpecs._data['patronymic'][Gender.MALE]


# Generated at 2022-06-23 20:52:21.961851
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    r = RussiaSpecProvider()
    r.generate_sentence()


# Generated at 2022-06-23 20:52:25.468276
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    import mimesis
    import mimesis.builtins
    rus = mimesis.builtins.RussiaSpecProvider()
    assert rus.passport_number() > 0 and rus.passport_number() < 1000000


# Generated at 2022-06-23 20:52:27.316631
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    """Test RussiaSpecProvider.generate_sentence()."""
    assert RussiaSpecProvider().generate_sentence()


# Generated at 2022-06-23 20:52:38.925981
# Unit test for method kpp of class RussiaSpecProvider

# Generated at 2022-06-23 20:52:47.602198
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """Unit test for method kpp of class RussiaSpecProvider"""
    from mimesis.providers.base import BaseProvider

    rp = RussiaSpecProvider()
    bp = BaseProvider()

    kpp = rp.kpp()
    # KPP must only contain digits
    assert all(char.isdigit() for char in kpp)
    # KPP must have a size of 9
    assert len(kpp) == 9

    # Test of generating 10000 KPP's
    kpps = [rp.kpp() for _ in range(10000)]
    # Check that kpp's are unique
    assert len(set(kpps)) == 10000
    # Check that KPP's have a size of 9
    assert all(len(kpp) == 9 for kpp in kpps)
    # Check that each KPP only contains digits
   

# Generated at 2022-06-23 20:52:50.427298
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    try:
        r = RussiaSpecProvider(seed = 4321)
    except TypeError as e:
        print(e)


# Generated at 2022-06-23 20:52:58.527095
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    from mimesis import RussiaSpecProvider
    from mimesis.enums import Gender
    rsp = RussiaSpecProvider(seed=1234567890)
    assert rsp.patronymic(Gender.FEMALE) == 'Васильевна'
    assert rsp.patronymic(Gender.MALE) == 'Александрович'
    assert rsp.patronymic(Gender.OTHER) == 'Валерьевна'
    assert rsp.patronymic('МУЖСКОЙ') == 'Александрович'

# Generated at 2022-06-23 20:53:01.924586
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    x = [RussiaSpecProvider(seed=N).snils() for N in range(0, 10000)]
    for n in range(0, len(x) - 1):
        assert x[n] != x[n + 1]

# Generated at 2022-06-23 20:53:04.788261
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Unit test."""
    rs = RussiaSpecProvider()
    assert len(rs.series_and_number()) == 11


# Generated at 2022-06-23 20:53:08.156281
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    print("Test method inn of class RussiaSpecProvider:", end="\n\n")
    provider = RussiaSpecProvider()
    inn = provider.inn()
    print(inn)
    print()
    assert len(inn) == 12


# Generated at 2022-06-23 20:53:12.274931
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    rus = RussiaSpecProvider()
    series = rus.passport_series()
    test = False
    if series[0:2].isdigit() and len(series) == 5:
        test = True
    assert test


# Generated at 2022-06-23 20:53:18.331060
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    russia = RussiaSpecProvider()
    bic = russia.bic()
    assert bic[0] == '0'
    assert bic[1] == '4'
    assert bic[2] != '0'
    assert bic[3] != '0'
    assert bic[4] != '1'
    assert bic[5] != '1'
    assert bic[6] != '1'
    assert bic[7] != '1'
    assert bic[8] != '1'
    assert bic[9] != '1'


# Generated at 2022-06-23 20:53:28.805052
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    obj = RussiaSpecProvider()
    result1 = obj.generate_sentence()
    obj = RussiaSpecProvider(seed=12345678)
    result2 = obj.generate_sentence()
    result1 == "Вообще, мы надеемся построить конкуренцию. Прошу тебя именно по поводу чего мы разговариваем."

# Generated at 2022-06-23 20:53:31.328067
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Unit test for method series_and_number of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    for i in range(0, 10):
        assert isinstance(rsp.series_and_number(), str)

# Generated at 2022-06-23 20:53:32.286285
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    pass



# Generated at 2022-06-23 20:53:41.087999
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    rsp = RussiaSpecProvider('myseed')

    # check for female
    patronymic_female = rsp.patronymic(Gender.FEMALE)
    assert patronymic_female == 'Алексеевна'

    # check for male
    patronymic_male = rsp.patronymic(Gender.MALE)
    assert patronymic_male == 'Алексеевич'

    # check for not specified (should return male patronymic)
    patronymic_not_specified = rsp.patronymic()
    assert patronymic_not_specified == 'Алексеевич'



# Generated at 2022-06-23 20:53:44.803729
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    rus = RussiaSpecProvider()
    inn = rus.inn()
    assert len(inn) == 10
    assert int(inn) % 11 % 10 == int(inn[9])



# Generated at 2022-06-23 20:53:56.057012
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    import datetime
    r1 = datetime.datetime.utcnow()
    bic = RussiaSpecProvider().bic()
    r2 = datetime.datetime.utcnow()
    assert type(bic) == str
    assert len(bic) == 9
    assert bic[0:2] == '04'
    # The following assertions are probably not necessary,
    # as 1 <= bic[2:4] <= 10 and 0 <= bic[4:6] <= 99 should
    # certainly be true with a random number generator.
    assert int(bic[2:4]) >= 1 and int(bic[2:4]) <= 10
    assert int(bic[4:6]) >= 0 and int(bic[4:6]) <= 99
    assert int(bic[6:9]) >= 50 and int

# Generated at 2022-06-23 20:53:57.170426
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    assert len(RussiaSpecProvider().series_and_number()) == 11


# Generated at 2022-06-23 20:54:09.555799
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.identifiers import Identifiers

    prov_person = Person('ru')
    prov_add = Address('ru')
    prov_idd = Identifiers('ru')


# Generated at 2022-06-23 20:54:15.438564
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    supplier = RussiaSpecProvider()
    for i in range(0, 10):
        bic = supplier.bic()
        assert len(bic) == 9
        assert bic[:2] == '04'
        assert bic[2:4].isnumeric()
        assert bic[4:6].isnumeric()
        assert bic[6:9].isnumeric()


# Generated at 2022-06-23 20:54:21.060249
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Test method series_and_number of class RussiaSpecProvider."""
    russian_passport_number = RussiaSpecProvider().series_and_number()
    assert isinstance(russian_passport_number, str)
    assert len(russian_passport_number) == 11
    for number in russian_passport_number:
        assert number.isdigit()


# Generated at 2022-06-23 20:54:32.209162
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    # Передача случайного значения в конструктор
    rsp1 = RussiaSpecProvider(seed=42)
    # генератор не выбирает текст из словаря, содержащего пустые строки, 
    # поэтому проверяем, что выведет именно текст

# Generated at 2022-06-23 20:54:33.406435
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    RussiaSpecProvider().ogrn()

# Generated at 2022-06-23 20:54:42.558161
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    ru = RussiaSpecProvider()
    ru._data = {'sentence': {'head': ['Мне нужно чтобы вы'], 
    'p1': ['встали'],
    'p2': ['позавтракали'],
    'tail': ['или я выясню это']}}
    result = ru.generate_sentence()
    assert result == 'Мне нужно чтобы вы встали позавтракали или я выясню это'


# Generated at 2022-06-23 20:54:45.771187
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    russia = RussiaSpecProvider()
    print(russia.generate_sentence())
    assert russia.generate_sentence() != None


# Generated at 2022-06-23 20:54:50.469784
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    from mimesis.builtins import RussiaSpecProvider
    test_RussiaSpecProvider = RussiaSpecProvider()
    series_and_number = test_RussiaSpecProvider.series_and_number()
    print("series_and_number: ")
    print(series_and_number)
    return

if __name__ == "__main__":
    test_RussiaSpecProvider_series_and_number()

# Generated at 2022-06-23 20:54:53.885319
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Unit test for method series_and_number of class RussiaSpecProvider.
    """
    assert RussiaSpecProvider().series_and_number() == '571681843'

# Generated at 2022-06-23 20:54:57.975829
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    results = []
    for _ in range(0, 100000):
        results.append(provider.snils())
    assert len(results) == 100000
    assert len(set(results)) == 100000


# Generated at 2022-06-23 20:54:59.247435
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    r = RussiaSpecProvider()
    print(r.series_and_number())

# Generated at 2022-06-23 20:55:01.167985
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    ru = RussiaSpecProvider()
    print(ru.passport_series())


# Generated at 2022-06-23 20:55:02.149424
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    pass


# Generated at 2022-06-23 20:55:03.846096
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    assert len(RussiaSpecProvider().kpp()) == 9
    assert type(RussiaSpecProvider().kpp()) == str


# Generated at 2022-06-23 20:55:05.149822
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    rus_type = RussiaSpecProvider()
    rus_type.bic()


# Generated at 2022-06-23 20:55:07.158385
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():

    rsp = RussiaSpecProvider()

    res = rsp.__init__()
    assert res != None


# Generated at 2022-06-23 20:55:14.272508
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    test_kpps = []
    test_kpps.append('770039000')
    test_kpps.append('780073000')
    test_kpps.append('500964000')
    test_kpps.append('010090000')
    test_kpps.append('020091000')
    test_kpps.append('030090000')
    test_kpps.append('050090000')
    test_kpps.append('060090000')
    test_kpps.append('070090000')
    test_kpps.append('080090000')
    test_kpps.append('090090000')
    test_kpps.append('100010000')
    test_kpps.append('110013000')
    test_kpps.append('120051000')

# Generated at 2022-06-23 20:55:18.034597
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """Testing passport_number of class RussiaSpecProvider for correct ranges."""
    provider = RussiaSpecProvider()
    number = provider.passport_number()
    assert number>=100000
    assert number<=999999



# Generated at 2022-06-23 20:55:22.780675
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    from mimesis.builtins.russia import RussiaSpecProvider
    rp = RussiaSpecProvider()
    assert rp.series_and_number()[2:4] == rp.passport_series()[4]
    assert rp.series_and_number()[0:2] == rp.passport_series()[0:2]
    assert rp.series_and_number()[-6:] == str(rp.passport_number())

# Generated at 2022-06-23 20:55:26.233322
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Test RussiaSpecProvider.ogrn()
    """
    test_ogrn = RussiaSpecProvider().ogrn()
    assert len(test_ogrn) == 13


# Generated at 2022-06-23 20:55:28.775064
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    p = RussiaSpecProvider()
    for i in range(0, 100):
        assert p.passport_number() >= 100000
        assert p.passport_number() <= 999999


# Generated at 2022-06-23 20:55:31.184546
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    r = RussiaSpecProvider()
    print(r.generate_sentence())


# Generated at 2022-06-23 20:55:35.863182
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    from mimesis.enums import Gender
    val = ''
    provider = RussiaSpecProvider()
    while val != '':
        val = int(input("Введите число: "))
        if val == 1:
            print(provider.inn())
        else:
            pass

test_RussiaSpecProvider_inn()

# Generated at 2022-06-23 20:55:37.464423
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    r = RussiaSpecProvider()
    assert len(r.kpp()) == len("560058652")


# Generated at 2022-06-23 20:55:40.876154
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    """
    Testing method bic of class RussiaSpecProvider
    """
    tmp_instance = RussiaSpecProvider()
    result = tmp_instance.bic()
    assert result == '044025575'

# Generated at 2022-06-23 20:55:45.695015
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Test method series_and_number of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    res = rsp.series_and_number()
    assert isinstance(res, str) is True
    assert len(res) == 10
    print(res)


# Generated at 2022-06-23 20:55:55.403832
# Unit test for method kpp of class RussiaSpecProvider

# Generated at 2022-06-23 20:55:57.024788
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    """The test for method bic of class RussiaSpecProvider."""
    russia = RussiaSpecProvider()
    assert russia_bic()

# Generated at 2022-06-23 20:55:58.640556
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    assert RussiaSpecProvider().generate_sentence() == 'Всем привет.'


# Generated at 2022-06-23 20:56:00.234542
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    assert (provider.snils() == '41917492600')


# Generated at 2022-06-23 20:56:04.105673
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Test for method ogrn of class RussiaSpecProvider"""
    provider = RussiaSpecProvider()
    assert True == bool(provider.ogrn().isdigit())


# Generated at 2022-06-23 20:56:06.868562
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Unit test for method ogrn of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    assert provider.ogrn() == '4715113303725'


# Generated at 2022-06-23 20:56:09.662123
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    from mimesis.providers.ru.russia_provider import RussiaSpecProvider
    b = RussiaSpecProvider()
    assert b.passport_number() in range(100000, 999999)

# Generated at 2022-06-23 20:56:15.172724
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    provider = RussiaSpecProvider()
    inn = provider.inn()
    # Checking the part of the number.
    assert str(inn[0]) == '5'
    # The number should have length of 10.
    assert len(inn) == 10
    # The number should be an int.
    assert isinstance(int(inn), int)


# Generated at 2022-06-23 20:56:18.297220
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    from mimesis.providers.person.ru import RussiaSpecProvider
    from mimesis.types import Gender
    p = RussiaSpecProvider()
    for i in range(0, 10):
        print(p.generate_sentence())


# Generated at 2022-06-23 20:56:20.643154
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    from mimesis.enums import Gender

    ru = RussiaSpecProvider()
    bic_result = ru.bic()
    assert  bic_result is not None


# Generated at 2022-06-23 20:56:22.588068
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    assert len(set(RussiaSpecProvider(seed=2).kpp() for _ in range(1000))) == 1000

# Generated at 2022-06-23 20:56:24.037110
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    rus = RussiaSpecProvider()
    assert len(rus.bic()) == 9


# Generated at 2022-06-23 20:56:25.076426
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    provider = RussiaSpecProvider()
    generated_passport_series = provider.passport_series()
    return generated_passport_series


# Generated at 2022-06-23 20:56:30.181868
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    provider = RussiaSpecProvider()
    # The first symbol of OGRN must be between 1 and 9
    ogrn = provider.ogrn()
    assert ogrn[0] in '123456789'
    # The length of OGRN must be 13 symbols
    assert len(ogrn) == 13
    # The last symbol of OGRN is a control check sum
    assert ogrn[-1] in '0123456789'
    # The sum of all numbers of OGRN divided by 11 and then by 10 must be equal to the last symbol of OGRN
    assert sum([int(n) for n in ogrn[:-1]]) % 11 % 10 == int(ogrn[-1])
test_RussiaSpecProvider_ogrn()


# Generated at 2022-06-23 20:56:33.104198
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    assert len(RussiaSpecProvider().passport_series()) == 5


# Generated at 2022-06-23 20:56:37.015376
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    russian = RussiaSpecProvider()
    assert russian.patronymic() == 'Александровна' or russian.patronymic() == 'Александрович'

# Generated at 2022-06-23 20:56:40.150141
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Unit test for method inn of class RussiaSpecProvider."""
    from mimesis.builtins.ru.russia_provider import RussiaSpecProvider
    from mimesis.enums import Gender

    provider = RussiaSpecProvider()
    assert provider.inn() is not None



# Generated at 2022-06-23 20:56:43.522950
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    r_provider = RussiaSpecProvider()
    r_provider.inn()
    assert r_provider.inn() == '4715113303725'


# Generated at 2022-06-23 20:56:45.092294
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """Testing of method passport_number of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    assert len(str(rsp.passport_number())) == 6



# Generated at 2022-06-23 20:56:47.139439
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    rsp = RussiaSpecProvider()
    year = '19'
    assert year in rsp.passport_series()

# Generated at 2022-06-23 20:56:49.091156
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test function for snils method."""
    assert len(RussiaSpecProvider().snils()) == 11

# Generated at 2022-06-23 20:56:51.668352
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    expected = '18' + ' ' + '01'
    provider = RussiaSpecProvider()
    provider.passport_series(18) == expected

# Generated at 2022-06-23 20:56:54.989087
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()
    snils = RussiaSpecProvider.snils(rsp)
    assert isinstance(snils, str)



# Generated at 2022-06-23 20:56:58.737150
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    from mimesis.builtins import RussiaSpecProvider

    russia_spec_provider = RussiaSpecProvider()
    result = russia_spec_provider.passport_number()

    assert len(str(result)) == 6
    assert type(result) == int

# Generated at 2022-06-23 20:57:05.202755
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    import time
    import random
    import calendar
    import datetime
    from mimesis.builtins.russia import RussiaSpecProvider
    starttime = time.time()
    random.seed(datetime.datetime.now())
    rus = RussiaSpecProvider(random)
    urav = []
    for x in range(0, 10):
        urav.append(rus.series_and_number())
        print(urav[x])
    print(urav)
    print('Время выполнения функции series_and_number раз: ' + str(time.time() - starttime))


# Generated at 2022-06-23 20:57:06.138563
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    RussiaSpecProvider()
    

# Generated at 2022-06-23 20:57:12.396120
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    provider = RussiaSpecProvider()
    assert provider.patronymic()
    assert provider.patronymic(gender=Gender.MALE)
    assert provider.patronymic(gender=Gender.FEMALE)
    assert provider.patronymic(gender=Gender.NEUTRAL)


# Generated at 2022-06-23 20:57:13.703671
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    r = RussiaSpecProvider(seed=1)
    assert r.series_and_number() == '56 16 788758'

# Generated at 2022-06-23 20:57:17.853718
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Unit test for method series_and_number of class RussiaSpecProvider"""
    random = RussiaSpecProvider()
    series_and_number = random.series_and_number()
    count = series_and_number.count(' ')
    if count == 1 and len(series_and_number) == 11:
        print('test_RussiaSpecProvider_series_and_number - OK')



# Generated at 2022-06-23 20:57:22.011252
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    russiaspecp = RussiaSpecProvider()
    print("==== Start Test ====")
    print("Provide a random Bank ID Code: ", russiaspecp.bic())
    print("==== End Test ====")


# Generated at 2022-06-23 20:57:25.628107
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    """Test method generate_sentence of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    sentence = provider.generate_sentence()
    assert isinstance(sentence, str)

# Generated at 2022-06-23 20:57:27.984410
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    RussiaSpecProvider_obj = RussiaSpecProvider()
    RussiaSpecProvider_kpp = RussiaSpecProvider_obj.kpp()
    assert len(RussiaSpecProvider_kpp) == 9

# Generated at 2022-06-23 20:57:30.429264
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    provider = RussiaSpecProvider()
    for _ in range(0, 100):
        assert provider.passport_number() <= 999999
        assert provider.passport_number() >= 100000


# Generated at 2022-06-23 20:57:32.632438
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider()
    bic = provider.bic()

    assert bic is not None
    assert isinstance(bic, str)
    assert len(bic) == 9



# Generated at 2022-06-23 20:57:34.867861
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    provider = RussiaSpecProvider()

    assert len(provider.series_and_number()) == 9


# Generated at 2022-06-23 20:57:41.340904
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """
    Unit tests for method - series_and_number()
        of class - RussiaSpecProvider
    """
    provider = RussiaSpecProvider()
    passport_series = provider.passport_series()
    passport_numbers = provider.passport_number()
    passport_series_and_numbers = provider.series_and_number()

    assert passport_series_and_numbers == f"{passport_series}{passport_numbers}"



# Generated at 2022-06-23 20:57:44.892487
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    russian = RussiaSpecProvider()
    series = russian.passport_series()
    assert len(series) == 5
    assert series[0].isnumeric()
    assert series[2] == ' '
    assert series[3].isnumeric()
    assert series[4].isnumeric()
