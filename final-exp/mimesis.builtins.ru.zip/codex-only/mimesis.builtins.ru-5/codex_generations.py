

# Generated at 2022-06-23 20:47:44.487579
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    """Test for method generate_sentence of class RussiaSpecProvider"""
    generate = RussiaSpecProvider()
    sentence = generate.generate_sentence()
    print(sentence)
    assert len(sentence.split()) >= 4


# Generated at 2022-06-23 20:47:47.939622
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    ru_provider = RussiaSpecProvider()
    generated_example = ru_provider.generate_sentence()
    print(generated_example)
    print("Length of the generated sentence:", len(generated_example))


# Generated at 2022-06-23 20:47:49.539900
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    provider = RussiaSpecProvider()
    assert provider.ogrn() == '4715113303725'


# Generated at 2022-06-23 20:47:53.634739
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    seed = 'af01fd548fdc5a521a0d6aa88f8f67b485c1b9cbbb13ce9f'
    rsp = RussiaSpecProvider(seed)
    sn = rsp.series_and_number()

    assert_class = 'RussiaSpecProvider'
    assert_method = 'series_and_number'
    assert_value = sn

    assert_class_method_return_value(assert_class, assert_method,
                                     assert_value, '42 12 634784')


# Generated at 2022-06-23 20:48:03.571071
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Testing ogrn method of RussiaSpecProvider class."""
    def test_ogrn_is_string():
        """Test that ogrn() return type is string."""
        provider = RussiaSpecProvider()
        assert isinstance(provider.ogrn(), str)

    def test_ogrn_is_length_13():
        """Test that ogrn() return length is 13."""
        provider = RussiaSpecProvider()
        assert len(provider.ogrn()) == 13

    def test_ogrn_is_valid():
        """Test that ogrn() return is valid."""
        def calculate_control_sum(ogrn: str) -> int:
            """Calculate control sum.

            :param ogrn: OGRN.
            :return: Control sum.
            """

# Generated at 2022-06-23 20:48:05.616726
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russian_provider = RussiaSpecProvider()

    assert russian_provider.snils() == russian_provider.snils()


# Generated at 2022-06-23 20:48:09.066082
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Unit testing for method ogrn of class RussiaSpecProvider."""
    ogrn = RussiaSpecProvider().ogrn()
    assert len(ogrn) == 13
    assert ogrn.isdigit() == True



# Generated at 2022-06-23 20:48:10.057895
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    m = RussiaSpecProvider()
    for _ in range(1):
        print(m.bic())


# Generated at 2022-06-23 20:48:11.554238
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    russia = RussiaSpecProvider()
    ogrn = russia.ogrn()
    assert ogrn.isdigit()
    assert len(ogrn) == 13


# Generated at 2022-06-23 20:48:17.386186
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    from mimesis.enums import Gender
    from mimesis.providers.address.ru import RussiaSpecProvider
    r = RussiaSpecProvider()
    bic = r.bic()
    # assert isinstance(bic, str)
    # assert bic in ['044025575']
    return print(bic)

test_RussiaSpecProvider_bic()


# Generated at 2022-06-23 20:48:22.286262
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    russian = RussiaSpecProvider()
    russian.seed(43)
    assert russian.generate_sentence() == 'Доброе утро, Анна Александровна. Как дела? Поздоровайтесь.'


russian = RussiaSpecProvider()
russian.seed(43)

# Generated at 2022-06-23 20:48:30.451405
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    result = RussiaSpecProvider().series_and_number()
    assert len(result) == 12
    assert result[1].isdigit()
    assert result[2].isdigit()
    assert result[4].isdigit()
    assert result[5].isdigit()
    assert result[7].isdigit()
    assert result[8].isdigit()
    assert result[9].isdigit()
    assert result[10].isdigit()
    assert result[11].isdigit()
    assert result[12].isdigit()
    assert result[13].isdigit()


# Generated at 2022-06-23 20:48:40.583255
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    provider = RussiaSpecProvider()
    assert provider.patronymic(Gender.MALE).isalpha(), \
        provider.patronymic(Gender.MALE)
    assert provider.patronymic(Gender.FEMALE).isalpha(), \
        provider.patronymic(Gender.FEMALE)
    assert provider.patronymic(Gender.MALE) in provider._data['patronymic'][Gender.MALE], \
        provider.patronymic(Gender.MALE)
    assert provider.patronymic(Gender.FEMALE) in provider._data['patronymic'][Gender.FEMALE], \
        provider.patronymic(Gender.FEMALE)


# Generated at 2022-06-23 20:48:47.278843
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider(seed=5)
    snils = provider.snils()
    assert snils in [
        '41917492600', '41917492600', '43203744100', '35321143800',
        '34987692300', '06051152200', '84713831900', '70549987400',
        '83439236800', '70691849800', '39109889400', '95590267300'
    ]

# Generated at 2022-06-23 20:48:49.709824
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    rsp = RussiaSpecProvider()
    assert rsp.kpp() == '7720001'


# Generated at 2022-06-23 20:48:51.230552
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    ogrn = RussiaSpecProvider().ogrn()
    assert ogrn == '4715113303725'

# Generated at 2022-06-23 20:49:00.813804
# Unit test for method generate_sentence of class RussiaSpecProvider

# Generated at 2022-06-23 20:49:02.292974
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    a = RussiaSpecProvider()
    b = a.snils()
    assert b == a.snils()

# Generated at 2022-06-23 20:49:05.574799
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    from mimesis.providers import RussiaSpecProvider
    russian_provider = RussiaSpecProvider()
    assert len(russian_provider.kpp()) == 9


# Generated at 2022-06-23 20:49:08.094345
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    r = RussiaSpecProvider()
    assert r.passport_series() in ('02 15', '22 18', '98 10')


# Generated at 2022-06-23 20:49:16.003478
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    rsp = RussiaSpecProvider()
    kpp = rsp.kpp()
    assert kpp.__len__() == 9

# Generated at 2022-06-23 20:49:20.548804
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    assert len(snils) == 11
    assert snils != "41917492600"

# Generated at 2022-06-23 20:49:25.971478
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    """Test the method bic."""
    from mimesis.providers.finance import Finance
    from mimesis.providers.address import Address

    provider = RussiaSpecProvider()
    bank_id_code = provider.bic()

    f = Finance(26, 'ru')
    a = Address('ru')

    assert bank_id_code in f.bic()
    assert bank_id_code in a.bic()


# Generated at 2022-06-23 20:49:30.004382
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    p = RussiaSpecProvider()
    assert p.patronymic(Gender.FEMALE) in p.patronymic(Gender.FEMALE)
    assert p.patronymic(Gender.MALE) in p.patronymic(Gender.MALE)
    assert p.patronymic(Gender.MALE) not in p.patronymic(Gender.FEMALE)


# Generated at 2022-06-23 20:49:36.864023
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    from mimesis.data import BASE_PATH
    # get data from file
    file_name = 'specs/ru_data.json'
    file_path = str(BASE_PATH / 'ru' / file_name)
    # init test class
    provider = RussiaSpecProvider()
    # get default data from provider
    default_data = provider._data

    # get data from file
    with open(file_path, encoding="utf8") as f:
        new_data = f.read()

    with open(file_path, 'w', encoding="utf8") as f:
        # put new data to file
        f.write(new_data)

    # get data from file

# Generated at 2022-06-23 20:49:39.140185
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    pr = RussiaSpecProvider()
    # print(pr.series_and_number())



# Generated at 2022-06-23 20:49:40.878840
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    val = RussiaSpecProvider().inn()
    assert val is not None
    assert len(val) == 12


# Generated at 2022-06-23 20:49:50.551912
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    class TestRussiaSpecProvider(RussiaSpecProvider):
        def __init__(self, seed=None, oblast=None):
            self.seed = seed
            self.oblast = oblast
            super().__init__(seed=self.seed)

        def kpp(self):
            return super().kpp()

    # Check that every call to method kpp of class TestRussiaSpecProvider
    # return a number of 9 digits (length of KPP)
    test_provider = TestRussiaSpecProvider(seed=123)
    assert len(test_provider.kpp()) == 9

    # Check that every call to method kpp of class TestRussiaSpecProvider
    # return a number with 3 first digits equal to '7700' (RegionCode of Moscow)
    test_provider = TestRussiaSpecProvider(seed=456)
    assert test_prov

# Generated at 2022-06-23 20:49:54.027327
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    r=RussiaSpecProvider()
    ans=r.series_and_number()
    L=len(ans)
    assert(L==11)


# Generated at 2022-06-23 20:49:56.709998
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    """Test generate sentence."""
    provider = RussiaSpecProvider()
    sentence = provider.generate_sentence()
    print(sentence)

# Generated at 2022-06-23 20:49:58.648653
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    seed = 444
    r = RussiaSpecProvider(seed=seed)
    assert r.kpp() == '560058652'

# Generated at 2022-06-23 20:50:00.931248
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Unit test for method series_and_number of class RussiaSpecProvider"""
    result = RussiaSpecProvider().series_and_number()
    assert len(result) == 11


# Generated at 2022-06-23 20:50:03.532974
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    provider = RussiaSpecProvider()
    passport_number = provider.passport_number()
    assert provider.passport_number() == passport_number
    assert len(str(passport_number)) == 6


# Generated at 2022-06-23 20:50:05.158030
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    for i in range(5):
        print(RussiaSpecProvider().series_and_number())
    return


# Generated at 2022-06-23 20:50:07.179812
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
	bic = RussiaSpecProvider().bic()
	assert len(bic) == 8
	assert bic[0:2] == r'04'


# Generated at 2022-06-23 20:50:09.709313
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    provider = RussiaSpecProvider()
    print(provider.passport_series())
    print(provider.passport_number())


# Generated at 2022-06-23 20:50:14.092019
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    import mimesis.providers.bank as bank
    provider = RussiaSpecProvider()

    assert isinstance(provider.bic(), str)
    assert len(provider.bic()) == 9
    assert provider.bic() == bank.BankProvider('ru').bic()


# Generated at 2022-06-23 20:50:15.899256
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    """Test for method  RussiaSpecProvider_generate_sentence."""
    assert RussiaSpecProvider().generate_sentence()


# Generated at 2022-06-23 20:50:17.569789
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """Test method passport_number of class RussiaSpecProvider."""

    assert len(str(RussiaSpecProvider().passport_number())) == 6


# Generated at 2022-06-23 20:50:19.424474
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    rsp = RussiaSpecProvider()
    for x in range(0, 19):
        assert len(str(rsp.passport_number())) == 6

# Generated at 2022-06-23 20:50:24.858729
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    provider = RussiaSpecProvider()
    answer = provider.patronymic()
    assert type(answer) == str
    answer_male = provider.patronymic('male')
    assert type(answer_male) == str
    answer_female = provider.patronymic('female')
    assert type(answer_female) == str
    answer_neutral = provider.patronymic('neutral')
    assert type(answer_neutral) == str


# Generated at 2022-06-23 20:50:25.578865
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    # TODO: test generation of random BIC
    pass

# Generated at 2022-06-23 20:50:27.608956
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    rsp = RussiaSpecProvider()
    print(rsp.patronymic()) # см.примеры


# Generated at 2022-06-23 20:50:38.912657
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    provider = RussiaSpecProvider()
    assert provider.patronymic(Gender.MALE) == 'Александрович'
    assert provider.patronymic(Gender.FEMALE) == 'Александровна'
    assert provider.passport_series(year=87) == '67 87'
    assert provider.passport_series(year=87).isalpha() == False
    assert provider.passport_number() in range(100000, 999999)
    assert provider.passport_number().isalpha() == False
    assert provider.series_and_number() == '69 18 590312'
    assert provider.series_and_number().isalpha() == False
    assert len(provider.snils()) == 11
    assert provider.sn

# Generated at 2022-06-23 20:50:40.778311
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    ru = RussiaSpecProvider()
    inn = ru.snils()
    assert len(inn) == 11

# Generated at 2022-06-23 20:50:47.291057
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    r = RussiaSpecProvider()
    print('\n')
    print('Test constructor attributes of class RussiaSpecProvider:')
    print('Gender: ', r.gender())
    print('Random item: ', r.random_element())
    print('Random email: ', r.email())
    print('Random phone number: ', r.phone_number())
    print('Random full name: ', r.full_name())
    print('Random date: ', r.datetime())
    print('Random postcode: ', r.postcode())
    print('Random address: ', r.address())


# Generated at 2022-06-23 20:50:56.687757
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    provider = RussiaSpecProvider()
    # Male
    result = provider.patronymic(Gender.MALE)
    assert isinstance(result, str)
    assert result != ''
    assert result in provider._data['patronymic'][Gender.MALE]
    # Female
    result = provider.patronymic(Gender.FEMALE)
    assert isinstance(result, str)
    assert result != ''
    assert result in provider._data['patronymic'][Gender.FEMALE]
    # Unknown
    result = provider.patronymic(Gender.UNKNOWN)
    assert isinstance(result, str)
    assert result != ''
    assert result in provider._data['patronymic'][Gender.UNKNOWN]
    # Random
    result = provider.patronymic()

# Generated at 2022-06-23 20:50:58.738433
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()


# Generated at 2022-06-23 20:51:00.978978
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    russia_dp = RussiaSpecProvider()
    assert russia_dp.passport_number() in range(100000, 999999)


# Generated at 2022-06-23 20:51:10.899516
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    russia_provider = RussiaSpecProvider(seed=1)
    assert russia_provider.series_and_number() == '49 17 165353'
    assert russia_provider.series_and_number() == '11 15 588931'
    assert russia_provider.series_and_number() == '75 11 522787'
    assert russia_provider.series_and_number() == '05 18 665761'
    assert russia_provider.series_and_number() == '98 14 715428'
    assert russia_provider.series_and_number() == '89 13 984809'
    assert russia_provider.series_and_number() == '74 11 243604'
    assert russia_provider.series_and_number() == '24 10 618245'

# Generated at 2022-06-23 20:51:15.490520
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    rus = RussiaSpecProvider()
    passport_number = rus.passport_number()
    if len(str(passport_number)) != 6:
        raise ValueError('Length of passport number must be 6 symbols')
    else:
        print('passport number: ', passport_number)


# Generated at 2022-06-23 20:51:18.127099
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    print('test_RussiaSpecProvider_bic')
    provider = RussiaSpecProvider()
    for _ in range(100):
        print(provider.bic())

# Generated at 2022-06-23 20:51:21.166406
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    # Constructor of class RussiaSpecProvider
    print("Constructor of class RussiaSpecProvider")
    russia_provider = RussiaSpecProvider()
    print("Constructor of class RussiaSpecProvider - OK")

# Generated at 2022-06-23 20:51:27.440806
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    # тест для метода series_and_number, получающего паспортные данные
    russia = RussiaSpecProvider()
    series = russia.passport_series()
    number = russia.passport_number()
    seriesAndNumber = str(series) + str(number)
    assert(len(series) == 5) and (len(str(number)) == 7) and (len(seriesAndNumber) == 12)


# Generated at 2022-06-23 20:51:29.731255
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    ru = RussiaSpecProvider()
    snils = ru.snils()
    print(snils)
    assert len(snils) == 11

# Generated at 2022-06-23 20:51:31.786575
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    from mimesis import Person
    ru_person = Person('ru')
    ru_person.series_and_number()


# Generated at 2022-06-23 20:51:36.509382
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    # Init RussiaSpecProvider
    rus_provider = RussiaSpecProvider()

    # Generate one ogrn
    ogrn = rus_provider.ogrn()

    # Check ogrn
    assert isinstance(ogrn, str)
    assert len(ogrn) == 13
    assert ogrn[0:-1].isdigit()
    assert ogrn[-1].isdigit()

# Generated at 2022-06-23 20:51:47.200461
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    """Unit test for method patronymic of class RussiaSpecProvider."""
    rs = RussiaSpecProvider()
    result = rs.patronymic()
    assert any([result == 'Алексеевна', result == 'Валентиновна', result == 'Антоновна'])
    result = rs.patronymic(Gender.MALE)
    assert result == 'Алексеевич'
    result = rs.patronymic(Gender.FEMALE)
    assert result == 'Алексеевна'


# Generated at 2022-06-23 20:51:49.707416
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Unit test for method ogrn of class RussiaSpecProvider"""
    provider = RussiaSpecProvider()
    assert provider.ogrn() == '4715113303725'


# Generated at 2022-06-23 20:51:51.464794
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    obj = RussiaSpecProvider()
    assert obj.passport_series() != None


# Generated at 2022-06-23 20:51:53.669325
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    r = RussiaSpecProvider()
    for i in range(10):
        print(r.ogrn())


# Generated at 2022-06-23 20:52:03.853249
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    ru_provider = RussiaSpecProvider()
    ru_series_and_number = ru_provider.series_and_number()
    comb = ru_series_and_number.split(" ")
    ru_series = comb[0] + comb[1]
    ru_number = int(comb[2])
    year = ru_series[2:]
    region = ru_series[0:2]

    if ru_number < 100000 or ru_number > 999999:
        assert 0, "Invalid number: " + str(ru_number)
    if int(year) < 10 or int(year) > 18:
        assert 0, "Invalid year: " + year
    if int(region) < 1 or int(region) > 99:
        assert 0, "Invalid region: " + ru_series[0:2]

# Generated at 2022-06-23 20:52:06.546612
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    """Unit test for method bic of class RussiaSpecProvider"""
    russ = RussiaSpecProvider(seed=0)

    assert russ.bic() == '044025575'
    assert russ.bic() == '044025575'


# Generated at 2022-06-23 20:52:08.475630
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    provider = RussiaSpecProvider()
    result = provider.inn()
    assert len(result) == 10



# Generated at 2022-06-23 20:52:13.484527
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    """Tests for method patronymic of class RussiaSpecProvider."""
    value = RussiaSpecProvider().patronymic(Gender.MALE)
    assert value != ''
    assert len(value) == 8
    assert value[-2:] == 'на'



# Generated at 2022-06-23 20:52:24.930238
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """
    Checks whether passport series are generated correctly.
    """
    rp = RussiaSpecProvider()

# Generated at 2022-06-23 20:52:29.012707
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    provider = RussiaSpecProvider()
    passport_number = provider.passport_number()
    assert len(str(passport_number)) == 6

# Generated at 2022-06-23 20:52:32.010022
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    provider = RussiaSpecProvider()
    sentence = provider.generate_sentence()
    assert isinstance(sentence, str)


# Generated at 2022-06-23 20:52:41.855454
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    """Unit test for method patronymic.
    """
    from mimesis.enums import Gender
    import os
    import yaml

    root_path = os.path.dirname(__file__)
    data = yaml.safe_load(open(
        os.path.join(
            root_path,
            'data/russia/ru_spec_provider.yml'
        )))

    pattern = '^[А-Я](ль|ии́|лии́|ле|лю|ей|ев|евич|евна|ич|ична)'


# Generated at 2022-06-23 20:52:43.987770
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    inn = RussiaSpecProvider().inn()
    print('inn =', inn)
    assert(len(inn) == 10)

# Generated at 2022-06-23 20:52:54.848180
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    for x in range(0,10000):
        patronymic = RussiaSpecProvider().patronymic(Gender.FEMALE)

# Generated at 2022-06-23 20:52:56.269848
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    r = RussiaSpecProvider(seed=0)
    assert r.inn() == '7829017982'
    assert r.inn() == '4143006888'


# Generated at 2022-06-23 20:52:58.276683
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    year = RussiaSpecProvider().passport_series(17)
    assert year == '17'


# Generated at 2022-06-23 20:53:00.705993
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    provider = RussiaSpecProvider()
    kpp = provider.kpp()
    assert len(kpp) == 9


# Generated at 2022-06-23 20:53:03.774738
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    p1 = RussiaSpecProvider()
    passport_number = p1.passport_number()
    assert len(str(passport_number)) == 6

# Generated at 2022-06-23 20:53:07.273003
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis import random
    from mimesis.providers.russia_provider import RussiaSpecProvider
    provider = RussiaSpecProvider(random.Random())
    assert provider.snils() == '41917492600'


# Generated at 2022-06-23 20:53:10.709280
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    if RussiaSpecProvider().passport_number() is not None:
        print("The test for method passport_number of class RussiaSpecProvider is successful!")
    else:
        print("The test for method passport_number of class RussiaSpecProvider is incorrect!")


# Generated at 2022-06-23 20:53:16.931731
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    from mimesis.providers.financial import RussiaSpecProvider
    f=open("test_FinPro.txt","w")
    for i in range(0, 10000):
        rs=RussiaSpecProvider()
        f.write("method: 'bic()',")
        f.write("result: '"+rs.bic()+"',")
        f.write('\n')
    f.close()


# Generated at 2022-06-23 20:53:27.030032
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    p = RussiaSpecProvider()
    inn = p.inn()
    assert len(inn) == 10, "Длина ИНН должна быть равна 10, сейчас она {}".format(len(inn))

# Generated at 2022-06-23 20:53:37.300664
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers import RussiaSpecProvider
    provider = RussiaSpecProvider()
    provider.snils()
    provider.inn()
    provider.ogrn()
    provider.bic()
    provider.kpp()
    provider.series_and_number()
    provider.generate_sentence()
    provider.patronymic(gender=Gender.FEMALE)
    provider.patronymic(gender=Gender.MALE)
    provider.patronymic()
    provider.passport_series()
    provider.passport_number()
    provider.passport_series(year=17)
    provider.random.info()
    provider.random.version()


# Generated at 2022-06-23 20:53:38.320086
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    r = RussiaSpecProvider()
    assert len(str(r.passport_number())) == 6


# Generated at 2022-06-23 20:53:45.774906
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    """Test of method patronymic of class RussiaSpecProvider."""

# Generated at 2022-06-23 20:53:51.376675
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Test RussiaSpecProvider.passport_series()."""
    provider = RussiaSpecProvider()
    result = provider.passport_series()
    assert len(result) == 5
    assert result[0:2].isnumeric()
    assert result[2:4].isspace()
    assert result[4:5].isnumeric()


# Generated at 2022-06-23 20:53:58.289982
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    # ru = RussiaSpecProvider()
    # inn = ru.inn()
    # assert len(inn) == 10
    #
    # # Check algorithm
    # assert ru.inn() == '7713277579'
    # assert ru.inn() == '5219120736'
    # assert ru.inn() == '2317024693'
    # assert ru.inn() == '4533156061'
    # assert ru.inn() == '1327591066'
    # assert ru.inn() == '4539124107'
    # assert ru.inn() == '9387829384'
    assert True

# Generated at 2022-06-23 20:54:10.539685
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    # Test string
    a = "Приехал в Германию. Особенности страны его поразили. Последнее время он увлекся фотографией."
    # New RussiaSpecProvider class
    RussiaSpecProvider = RussiaSpecProvider()
    # Test function generate_sentence
    assert RussiaSpecProvider.generate_sentence() in a
    # Test function patronymic
    assert RussiaSpecProvider.patronymic(Gender.MALE) == "Иванович"
    assert RussiaSpecProvider.patronym

# Generated at 2022-06-23 20:54:12.433309
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    assert RussiaSpecProvider(seed=1).patronymic() == "Ильинична"

# Generated at 2022-06-23 20:54:21.852030
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    ogrn_check = (4715113303725, 5037572000143, 3216280596862, 5037060807106,
                  2117018973425, 5177744283844, 5037030300575, 5037005825799,
                  4660065401152, 9125028002567, 9121010006336, 7737074001593,
                  5037012564715, 9124025011909, 9124025011205, 9124025010478,
                  5037030301198, 9121010000484, 5037030300549)
    for i in range(len(ogrn_check)):
        assert ogrn_check[i] == RussiaSpecProvider().ogrn()

# Generated at 2022-06-23 20:54:23.601319
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    provider = RussiaSpecProvider()
    sentence = provider.generate_sentence()
    print("generate_sentence: ", sentence)

# Generated at 2022-06-23 20:54:27.153106
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    russian_provider = RussiaSpecProvider()
    for i in range(0,10):
        print(russian_provider.generate_sentence())

# Generated at 2022-06-23 20:54:30.072567
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    ogrn = RussiaSpecProvider().ogrn()
    assert len(ogrn) == 13
    assert ogrn[-1] == str(int(ogrn[0:12]) % 11 % 10)

# Generated at 2022-06-23 20:54:36.364448
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    dummy = RussiaSpecProvider(seed='123')
    # snils = dummy.snils()
    dummy.snils() == '57879326400'
    dummy.snils() == '41917492600'
    dummy.snils() == '49313253900'
    dummy.snils() == '39906320000'
    dummy.snils() == '89826291500'
    dummy.snils() == '89101993600'
    dummy.snils() == '67067484900'
    dummy.snils() == '51945163900'
    dummy.snils() == '37752832900'
    dummy.snils() == '99568053600'

# Generated at 2022-06-23 20:54:38.643840
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    from mimesis import Generic
    g = Generic('ru')
    gender = g.gender()
    patronymic = g.person.patronymic(gender)
    patronymic_is_string = isinstance(patronymic, str)
    print(patronymic, patronymic_is_string)


# Generated at 2022-06-23 20:54:40.262859
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    provider = RussiaSpecProvider()
    assert len(provider.kpp()) == 9


# Generated at 2022-06-23 20:54:41.741968
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    assert RussiaSpecProvider().passport_number() != RussiaSpecProvider().passport_number()


# Generated at 2022-06-23 20:54:45.845189
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    from mimesis.providers.russia import RussiaSpecProvider
    r = RussiaSpecProvider()
    res = r.series_and_number()
    assert len(res) == 9
    assert isinstance(res, str) is True

# Generated at 2022-06-23 20:54:47.312829
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    assert len(RussiaSpecProvider().passport_number()) == 6


# Generated at 2022-06-23 20:54:49.380933
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    assert RussiaSpecProvider().patronymic() != RussiaSpecProvider().patronymic()

# Generated at 2022-06-23 20:54:51.002683
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    r = RussiaSpecProvider()
    assert r.snils()

# Generated at 2022-06-23 20:54:53.141010
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    provider = RussiaSpecProvider()

    assert provider.kpp() == '560058652'

# Generated at 2022-06-23 20:54:55.088779
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    rs = RussiaSpecProvider()
    print(rs.series_and_number())


# Generated at 2022-06-23 20:55:00.207770
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    for x in range(0, 100):
        provider = RussiaSpecProvider()
        test_data = [
            Gender.MALE,
            Gender.FEMALE,
            Gender.NEUTRAL,
            None,
        ]
        for gender in test_data:
            patronymic = provider.patronymic(gender)
            assert patronymic is not None


# Generated at 2022-06-23 20:55:03.425678
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Test method series_and_number of RussiaSpecProvider"""
    russia_provider = RussiaSpecProvider()
    series_and_number = russia_provider.series_and_number()
    print(series_and_number)


# Generated at 2022-06-23 20:55:05.484826
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    assert RussiaSpecProvider() is not None
    assert RussiaSpecProvider.Meta.name == 'russia_provider'


# Generated at 2022-06-23 20:55:10.340971
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    RussiaSpecProvider_object = RussiaSpecProvider()
    RussiaSpecProvider_snils = RussiaSpecProvider_object.snils()
    assert int(RussiaSpecProvider_snils)
    assert len(RussiaSpecProvider_snils) == 11
    assert not int(RussiaSpecProvider_snils) % 101
    print (RussiaSpecProvider_snils)

# Generated at 2022-06-23 20:55:12.044253
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    r = RussiaSpecProvider(seed=3)
    assert r.passport_series(year=18) == "85 18"


# Generated at 2022-06-23 20:55:14.466729
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Unit test for RussiaSpecProvider class."""

    provider = RussiaSpecProvider()
    inn = provider.inn()
    assert len(inn) == 12


# Generated at 2022-06-23 20:55:18.253164
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """ Method tests kpp of class RussiaSpecProvider.
    """
    rus_provider = RussiaSpecProvider()
    for _ in range(1000):
        assert len(rus_provider.kpp()) == 9



# Generated at 2022-06-23 20:55:19.542119
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider()
    result = provider.bic()
    assert len(str(result)) == 9


# Generated at 2022-06-23 20:55:21.802991
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
	print(RussiaSpecProvider().passport_series())


# Generated at 2022-06-23 20:55:26.426234
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    provider = RussiaSpecProvider(seed=1)
    assert provider.passport_number() == 816458
    provider = RussiaSpecProvider(seed=2)
    assert provider.passport_number() == 748012


# Generated at 2022-06-23 20:55:30.552264
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    
    class TestClass:
        random = 'str' 
    
    test_obj = TestClass()
    test_obj.random = 'random'
    temp = RussiaSpecProvider(seed=None)._pull(RussiaSpecProvider()._datafile)
    result = RussiaSpecProvider(seed=None, data=temp)
    
    
    assert (result, RussiaSpecProvider)
    

# Generated at 2022-06-23 20:55:31.999822
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    assert RussiaSpecProvider().__class__.__name__ == "RussiaSpecProvider"



# Generated at 2022-06-23 20:55:33.045479
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    pass


# Generated at 2022-06-23 20:55:37.255331
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.builtins import RussiaSpecProvider

    rsp = RussiaSpecProvider()
    snils_1 = rsp.snils()
    snils_2 = rsp.snils()

    assert isinstance(snils_1, str)
    assert len(snils_1) == 11
    assert snils_1 != snils_2


# Generated at 2022-06-23 20:55:41.073609
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    """Test for RussiaSpecProvider.bic()."""
    sp = RussiaSpecProvider()
    bic = sp.bic()
    assert (bic[:4] == '0440')
    assert (len(bic) == 9)

# Generated at 2022-06-23 20:55:41.760035
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
	pass

# Generated at 2022-06-23 20:55:44.854147
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    # Create provider
    provider = RussiaSpecProvider(seed=0)

    # Check result
    assert '044025575' == provider.bic()

# Generated at 2022-06-23 20:55:46.619581
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    _ = RussiaSpecProvider()

# Generated at 2022-06-23 20:55:50.248640
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    # Arrange
    # Act
    rs = RussiaSpecProvider()
    pn = rs.passport_number()

    # Assert
    assert isinstance(pn, int)
    assert len(str(pn)) == 6


# Generated at 2022-06-23 20:55:52.350635
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    result = RussiaSpecProvider().patronymic()
    assert isinstance(result, str)
    assert len(result) >= 5


# Generated at 2022-06-23 20:55:54.306041
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11


# Generated at 2022-06-23 20:55:57.428217
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    inn = RussiaSpecProvider().inn()
    assert len(inn) == 12
    assert RussiaSpecProvider().inn('') == inn
    assert RussiaSpecProvider().inn(None) == inn


# Generated at 2022-06-23 20:55:58.511475
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    r = RussiaSpecProvider()
    assert type(r.patronymic()) == str

# Generated at 2022-06-23 20:56:00.474768
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    provider = RussiaSpecProvider()
    ogrn = provider.ogrn()
    assert ogrn == '1047792142903'


# Generated at 2022-06-23 20:56:03.977297
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    p = RussiaSpecProvider()
    a = p._data['kpp']
    b = p.kpp()
    assert b in a


# Generated at 2022-06-23 20:56:10.024415
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    from mimesis.builtins import RussiaSpecProvider
    rsp = RussiaSpecProvider(seed=42)
    assert rsp.generate_sentence() == 'В случае внесения изменений, заявление необходимо подавать заново.'


# Generated at 2022-06-23 20:56:12.581737
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    sentence = RussiaSpecProvider().generate_sentence()
    num_words = sentence.count(' ') + 1
    assert num_words == 4

# Generated at 2022-06-23 20:56:15.060689
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    assert len(RussiaSpecProvider().series_and_number()) == 11
    assert RussiaSpecProvider().series_and_number().isdigit()


# Generated at 2022-06-23 20:56:16.708801
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """Test method kpp of class RussiaSpecProvider"""
    ogrn_provider = RussiaSpecProvider()
    assert len(ogrn_provider.kpp()) == 9
    assert ogrn_provider.kpp().isdigit()


# Generated at 2022-06-23 20:56:18.291115
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    # Initialize a provider
    rus_provider = RussiaSpecProvider()


# Generated at 2022-06-23 20:56:21.369834
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    from mimesis import RussiaSpecProvider
    rus_prov = RussiaSpecProvider()
    kpp = rus_prov.kpp()
    assert len(kpp) == 9


# Generated at 2022-06-23 20:56:27.649053
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    from mimesis.providers.russia_provider import RussiaSpecProvider
    from mimesis.typing import Seed
    from mimesis.enums import Gender
    seed = Seed()
    s = RussiaSpecProvider(seed=seed)

    assert len(s.inn()) == 12


# Generated at 2022-06-23 20:56:35.379497
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Test inn method."""
    items = []
    # get all elements
    provider = RussiaSpecProvider()
    for _ in range(100):
        val = provider.inn()
        if val in items:
            print("Need unique value")
            raise ValueError()
        items.append(val)
    # Check length
    for item in items:
        if not len(item) == 12:
            print("Bad length")
            raise ValueError()
    print("Ok")

    # Check control number
    for item in items:
        control_num = int(item[-1])
        num = int(item[:-1])

# Generated at 2022-06-23 20:56:37.196480
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    serialAndNumber = RussiaSpecProvider.series_and_number()
    return serialAndNumber



# Generated at 2022-06-23 20:56:43.987389
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    data = RussiaSpecProvider().kpp()
    test_data = ['710001001', '360003973']
    print('Тестируемые данные: ', data)
    # Цикл проходится по списку тестовых данных

# Generated at 2022-06-23 20:56:48.396546
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    provider = RussiaSpecProvider()
    ogrn = provider.ogrn()
    print(ogrn)
    assert len(ogrn) == 13
    for x in range(0, 12):
        assert x != 0
        assert x <= 9


# Generated at 2022-06-23 20:56:51.492940
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    provider = RussiaSpecProvider()
    passport_number = provider.passport_number()
    
    assert len(str(passport_number)) == 6


# Generated at 2022-06-23 20:57:01.724663
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    from mimesis.providers.person.ru.ru_provider import RussiaPersonProvider
    from mimesis.providers.address.ru.ru_provider import RussiaAddressProvider
    from random import seed
    from . import DATA_DIR
    seed(1)

    ru = RussiaSpecProvider('ru', seed=1)
    ru_person = RussiaPersonProvider('ru', seed=1)
    ru_address = RussiaAddressProvider('ru', seed=1)
    ru_person.load_data(DATA_DIR)
    ru_address.load_data(DATA_DIR)
    ru.load_data(DATA_DIR)


# Generated at 2022-06-23 20:57:04.304209
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    """Test the constructor of RussiaSpecProvider."""
    seed = b'Mimesis'
    rp = RussiaSpecProvider(seed=seed)
    assert rp._seed == b'Mimesis'

# Generated at 2022-06-23 20:57:07.143740
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    provider = RussiaSpecProvider()
    inn = provider.inn()
    assert len(inn) == 12 and provider.validate_inn(inn) is True


# Generated at 2022-06-23 20:57:13.135266
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    # As part of the test, check the manufacture of a passport issued in 1984
    # and the validity of the passport series
    passport_series = RussiaSpecProvider().passport_series(84)
    print(passport_series[-2:])
    assert passport_series[-2:] == '84'


# Generated at 2022-06-23 20:57:16.017896
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    test_object = RussiaSpecProvider()
    test_series = test_object.series_and_number()
    test_split = test_series.split(' ')[0]
    assert len(test_split) == 6


# Generated at 2022-06-23 20:57:19.928199
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    RussiaSpecProvider()
    print("\nUnit test for method series_and_number of class RussiaSpecProvider")
    print("The result is:")
    print(RussiaSpecProvider().series_and_number())


# Generated at 2022-06-23 20:57:21.313697
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    RussiaSpecProvider.passport_number()
    

# Generated at 2022-06-23 20:57:25.726086
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """Testing random method kpp of class RussiaSpecProvider."""
    rus_spec_provider = RussiaSpecProvider()
    for _ in range(0, 10):
            assert len(rus_spec_provider.kpp()) == 9


# Generated at 2022-06-23 20:57:30.618111
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    from mimesis.providers.encryption import Encryption
    from mimesis.enums import Gender
    from mimesis.builtins import RussiaSpecProvider

    seed = '0123456789'
    encryption_provider = Encryption(seed=seed)
    rsp = RussiaSpecProvider(seed=seed)
    assert rsp.kpp() == encryption_provider.decrypt(rsp.kpp()).decode()

# Generated at 2022-06-23 20:57:34.060737
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    r = RussiaSpecProvider()

    assert len(r.kpp()) == 9
    assert r.kpp().isdigit()



# Generated at 2022-06-23 20:57:36.567200
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    r = RussiaSpecProvider()
    kpp = r.kpp()
    assert len(kpp) == 9

# Generated at 2022-06-23 20:57:40.722819
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.schema import Field, Schema
    class MySchema(Schema):
        address = Field(Address)
        person = Field(Person)
        text = Field(Text)
    s = MySchema()
    assert s.sentence() == 'Адрес: %s ФИО: %s Текст: %s' % (s.address(), s.person(), s.text())
