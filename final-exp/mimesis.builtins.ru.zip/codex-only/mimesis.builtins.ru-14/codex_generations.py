

# Generated at 2022-06-23 20:47:45.090227
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    from mimesis import RussiaSpecProvider, Seed
    spec = RussiaSpecProvider(Seed.random())
    for bic in spec.bic():
        assert len(bic) == 9
        assert bic == '044025575'

# Generated at 2022-06-23 20:47:48.457765
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """
    Test method inn of class RussiaSpecProvider
    """
    pattern = re.compile(r'[0-9]{10}')
    provider = RussiaSpecProvider()
    assert pattern.fullmatch(provider.inn())

# Generated at 2022-06-23 20:47:52.622386
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    pr = RussiaSpecProvider(seed=42)
    expected = 'Кабы не велёк, то и не белый был.'
    result = pr.generate_sentence()
    assert result == expected


# Generated at 2022-06-23 20:47:55.070687
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    """Test RussiaSpecProvider._bic()."""
    rs = RussiaSpecProvider() # RussiaSpecProvider()
    assert rs.bic() in ('044025575', '044025578')

# Generated at 2022-06-23 20:47:59.633305
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    # Тестирование метода RussiaSpecProvider.passport_series()
    print('\n# Unit test for method passport_series of class RussiaSpecProvider: \n')
    print('\tMethod passport_series() Work!')


# Generated at 2022-06-23 20:48:01.256308
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    provider = RussiaSpecProvider()
    assert len(provider.generate_sentence()) > 0



# Generated at 2022-06-23 20:48:04.770724
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Unit test of class series_and_number of class RussiaSpecProvider."""
    seed = "test_RussiaSpecProvider_series_and_number"
    russian_spec = RussiaSpecProvider(seed=seed)
    sn = russian_spec.series_and_number()
    assert sn == "56 16 679300"

# Generated at 2022-06-23 20:48:07.331323
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Unit test for method inn of class RussiaSpecProvider."""
    r = RussiaSpecProvider()
    assert isinstance(r.inn(), str)
    assert len(r.inn()) == 10

# Generated at 2022-06-23 20:48:12.705621
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    p = RussiaSpecProvider()
    assert p.patronymic(), "Must be not None"
    assert p.patronymic(gender=Gender.MALE) in p._data['patronymic'][Gender.MALE]
    assert p.patronymic(gender=Gender.FEMALE) in p._data['patronymic'][Gender.FEMALE]


# Generated at 2022-06-23 20:48:15.651931
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    from mimesis.builtins import RussiaSpecProvider
    provider = RussiaSpecProvider
    assert len(provider().generate_sentence()) > 0

# Generated at 2022-06-23 20:48:17.554074
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    rsp = RussiaSpecProvider()
    print("RussiaSpecProvider_kpp="+rsp.kpp())
    assert len(rsp.kpp()) == 9


# Generated at 2022-06-23 20:48:19.796070
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    ru_spec = RussiaSpecProvider()
    ru_spec.inn()

    ru_spec = RussiaSpecProvider(seed=4321)
    ru_spec.inn()

# Generated at 2022-06-23 20:48:21.575349
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    data = []
    for i in range(0, 100000):
        data.append(RussiaSpecProvider().inn())
    return data

# Generated at 2022-06-23 20:48:25.828638
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    # Decision
    rsp = RussiaSpecProvider()
    series_and_number = rsp.series_and_number()
    series_and_number_count = len(series_and_number)

    # Check
    assert series_and_number_count == 11

# Generated at 2022-06-23 20:48:29.505168
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    russian_spec_provider = RussiaSpecProvider(seed = 1)
    try:
        russian_spec_provider.generate_sentence()
    except Exception as e:
        err = str(e)
        assert 1==0, err
    return


# Generated at 2022-06-23 20:48:31.350308
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    rup = RussiaSpecProvider()
    rup.ogrn()


# Generated at 2022-06-23 20:48:34.391516
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    russia = RussiaSpecProvider()
    for x in range(0,10):
        assert len(russia.passport_series()) == 5


# Generated at 2022-06-23 20:48:38.774394
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    provider = RussiaSpecProvider()
    assert provider.inn() == '7716773893'
    assert provider.inn() == '7509000102'
    assert provider.inn() == '7707684863'
    assert provider.inn() == '5810337470'


# Generated at 2022-06-23 20:48:41.353843
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    obj = RussiaSpecProvider()
    for i in range(0, 10):
        assert type(obj.generate_sentence()) == str
    return 0


# Generated at 2022-06-23 20:48:43.149938
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    provider = RussiaSpecProvider()
    result = provider.passport_series()
    assert result is not None


# Generated at 2022-06-23 20:48:44.565413
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    provider = RussiaSpecProvider()
    assert 0 < len(provider.passport_series()) == 5


# Generated at 2022-06-23 20:48:45.930964
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    assert '4715113303725' == RussiaSpecProvider().ogrn()


# Generated at 2022-06-23 20:48:48.131885
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    ru = RussiaSpecProvider()
    print(ru.ogrn())


# Generated at 2022-06-23 20:48:49.965865
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    assert RussiaSpecProvider().kpp() == '560058652'



# Generated at 2022-06-23 20:48:51.383724
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    import doctest
    doctest.testmod(RussiaSpecProvider())
    return True

# Generated at 2022-06-23 20:48:53.846102
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    """Test method generate_sentence of class RussiaSpecProvider."""
    obj=RussiaSpecProvider()
    assert type(obj.generate_sentence())==str


# Generated at 2022-06-23 20:48:55.353506
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    assert len(RussiaSpecProvider().inn()) == 10

# Generated at 2022-06-23 20:48:56.710735
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
	r = RussiaSpecProvider()
	r.kpp()


# Generated at 2022-06-23 20:48:59.996764
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    import random
    # pylint: disable=unused-import
    from mimesis.enums import Gender
    russia_provider = RussiaSpecProvider()
    russia_provider.seed(random.randint(1,10))
    assert russia_provider.ogrn() == '534777400077'


# Generated at 2022-06-23 20:49:02.214779
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    from mimesis.providers.misc import RussiaSpecProvider
    rsp = RussiaSpecProvider()
    assert len(str(rsp.ogrn())) == 13


# Generated at 2022-06-23 20:49:03.902280
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    assert RussiaSpecProvider().generate_sentence() != None


# Generated at 2022-06-23 20:49:05.675084
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    assert RussiaSpecProvider().bic() == '044025575'

# Generated at 2022-06-23 20:49:09.243293
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    russia_provider = RussiaSpecProvider()
    kpp = russia_provider.kpp()
    assert len(kpp) == 9
    assert type(kpp) == str


# Generated at 2022-06-23 20:49:11.379316
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    provider = RussiaSpecProvider()
    result = provider.kpp()
    assert len(result) == 9, "The length of the result is not 9"
    

# Generated at 2022-06-23 20:49:18.560656
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """Unit test for method kpp of class RussiaSpecProvider"""
    from mimesis import RussiaSpecProvider
    from copy import copy
    from random import Random
    r = RussiaSpecProvider(seed=Random(12345))
    r.seed.setstate(r.seed.getstate())
    assert r.kpp() == '560058652'
    r.seed.setstate(r.seed.getstate())
    assert r.kpp() == '560058652'
    r.seed.setstate(r.seed.getstate())
    assert r.kpp() == '560058652'
    r.seed.setstate(r.seed.getstate())
    assert r.kpp() == '560058652'
    r.seed.setstate(r.seed.getstate())
    assert r.kpp()

# Generated at 2022-06-23 20:49:29.083668
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    provider = RussiaSpecProvider()
    result = provider.passport_number()
    assert result is not None
    assert str(result).isdigit()
    assert len(str(result)) == 6
    if int(str(result)[0]) != 1 or int(str(result)[0]) == 5:
        assert int(str(result)[0]) == 6
        assert int(str(result)[1]) >= 0
        assert int(str(result)[2]) >= 0
        assert int(str(result)[3]) >= 0
        assert int(str(result)[4]) >= 0
        assert int(str(result)[5]) >= 0
    if int(str(result)[0]) == 1:
        assert int(str(result)[1]) == 0
        assert int(str(result)[2]) == 0

# Generated at 2022-06-23 20:49:31.987733
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.enums import Gender
    from mimesis.providers import RussiaSpecProvider

    russia_spec_provider = RussiaSpecProvider('en')
    result = russia_spec_provider.snils()
    assert len(result) == 11
    result = russia_spec_provider.snils()
    assert len(result) == 11

# Generated at 2022-06-23 20:49:36.640251
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    ru = RussiaSpecProvider()
    print("Код контрагента: ", ru.kpp())
    ru.reset_seed()
    print("Код контрагента по случайному алгоритму: ", ru.kpp())


# Generated at 2022-06-23 20:49:39.094447
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    russian_spec_provider = RussiaSpecProvider()

    assert russian_spec_provider


# Generated at 2022-06-23 20:49:41.372520
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    rsp = RussiaSpecProvider()
    result = rsp.bic()
    assert isinstance(result, str)
    assert len(result) == 10

# Generated at 2022-06-23 20:49:50.262963
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    # Create seed for debugging
    seed = 'a6c5d6b9-9b10-45f3-ab07-47ceb7e6b8d6'

    # Initialize RussiaSpecProvider() with seed
    russiaprovider = RussiaSpecProvider(seed)

    # Create list of 10 passport numbers
    passport_numbers = []
    for i in range(0, 10):
        passport_numbers.append(russiaprovider.passport_number())

    # Assert that list of 10 passport numbers is correct
    assert passport_numbers == [276017, 285854, 976459, 887448, 395147, 861391, 714223, 117500, 755256, 160493]


# Generated at 2022-06-23 20:49:56.350121
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Test for method ogrn of class RussiaSpecProvider."""
    a = RussiaSpecProvider(seed = 'Mimesis')
    assert a.ogrn() == '4715113303725'
    b = RussiaSpecProvider(seed = 'Mimesis')
    assert b.ogrn() == '4715113303725'

# Generated at 2022-06-23 20:50:05.091998
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    seed = "a0d7d10b-c204-4303-b8c2-c9bcdb2fea12"
    russianProv = RussiaSpecProvider(seed)
    
    # generate_sentence
    assert russianProv.generate_sentence() == "Мы не можем понять тебя так, как должны."
    
    # patronymic
    assert russianProv.patronymic() == "Константинович"
    assert russianProv.patronymic(Gender.MALE) == "Константинович"

# Generated at 2022-06-23 20:50:06.737765
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    provider = RussiaSpecProvider()
    result = provider.passport_series()
    assert len(result) == 5


# Generated at 2022-06-23 20:50:14.132261
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    provider_1 = RussiaSpecProvider()
    kpp_1 = provider_1.kpp()
    assert len(kpp_1) == 9, "The length of the KPP is not equal 9"

    provider_2 = RussiaSpecProvider()
    kpp_2 = provider_2.kpp()
    assert len(kpp_2) == 9, "The length of the KPP is not equal 9"
    assert kpp_1.__ne__(kpp_2), "The KPPs are the same"


# Generated at 2022-06-23 20:50:21.703279
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    """Test method generate_sentence of class RussiaSpecProvider."""
    from mimesis.providers.datetime import Datetime
    datetime_instance = Datetime('ru', seed=42)
    russia_instance = RussiaSpecProvider(seed=42)
    sentence = russia_instance.generate_sentence()
    assert sentence == 'Здравствуйте! На улице {0} градусов. В{1} по местному времени'\
        .format(datetime_instance.temperature(), datetime_instance.local_time(military=True))



# Generated at 2022-06-23 20:50:26.765137
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    if len(snils) != 11:
        raise ValueError("snils(len) = " + str(len(snils)))
    if not snils.isdecimal():
        raise ValueError("snils(decimal) = " + str(snils))

test_RussiaSpecProvider_snils()

# Generated at 2022-06-23 20:50:29.352079
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    # Test with random arguments
    RussiaSpecProvider().kpp()

    # Test with custom arguments
    RussiaSpecProvider().kpp(None)


# Generated at 2022-06-23 20:50:35.722107
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    import sys
    import cProfile
    import re

    cProfile.run('snils = RussiaSpecProvider().snils()')
    if not re.match(r'\d{11}', snils):
        sys.exit('Test failed. snils = {}'.format(snils))
    print('Test Success. snils = {}'.format(snils))

test_RussiaSpecProvider_snils()

# Generated at 2022-06-23 20:50:38.462663
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    ogrn = RussiaSpecProvider().ogrn()
    
    assert (len(ogrn) == 13, "Length of ogrn != 13")


# Generated at 2022-06-23 20:50:39.987514
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    c = RussiaSpecProvider()
    c.patronymic(Gender.FEMALE)

# Generated at 2022-06-23 20:50:43.471621
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    from mimesis.builtins import RussiaSpecProvider
    russiaspecpprovider = RussiaSpecProvider()
    print(russiaspecpprovider.generate_sentence())


# Generated at 2022-06-23 20:50:45.933239
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    from mimesis.providers.russia import RussiaSpecProvider
    provider = RussiaSpecProvider()
    sn = provider.series_and_number()
    assert type(sn) == str
    assert len(sn) == 11

# Generated at 2022-06-23 20:50:47.701684
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    assert RussiaSpecProvider().patronymic(
        Gender.MALE) == 'евич'

# Generated at 2022-06-23 20:50:54.345923
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    from mimesis.providers.address import Address
    from mimesis.providers.text import Text
    from mimesis.providers.date import Date
    from mimesis.providers.geography import Geography
    from mimesis.providers.science import Science
    from mimesis.providers.person import Person

    from mimesis.enums import Gender

    locale = 'ru'

    spec = RussiaSpecProvider(locale)
    address = Address(locale)
    text = Text(locale)
    date = Date(locale)
    geo = Geography(locale)
    science = Science(locale)
    person = Person(locale)

    assert isinstance(spec.generate_sentence(), str)
    assert len(spec.generate_sentence()) <= 40

# Generated at 2022-06-23 20:50:55.523179
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    provider = RussiaSpecProvider()
    assert isinstance(provider, RussiaSpecProvider)


# Generated at 2022-06-23 20:51:06.764316
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    # создаем большую коллекцию данных
    n = 100000
    snils_list = []
    for i in range(n):
        snils_list.append(provider.snils())
    # проверяем, сколько элементов коллекции совпало с уникальным
    unique_snils = list(set(snils_list))
    print(len(unique_snils))
    for i in unique_snils:
        print(i)
    assert len

# Generated at 2022-06-23 20:51:18.545499
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """
    По факту, для тестирования метода
    passport_number не нужно ничего,
    проверяя выдачу метода в random числа,
    не лучший вариант, т.к. не на 100%
    проверит валидность полученных чисел
    """
    new_passport_number = RussiaSpecProvider.passport_

# Generated at 2022-06-23 20:51:22.315490
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Test method inn of class RussiaSpecProvider."""
    obj = RussiaSpecProvider()
    assert len(str(obj.inn())) == 12
    assert obj.inn()[0:3] in ['770', '780', '500', '010']


# Generated at 2022-06-23 20:51:25.717087
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert len(snils) == 11, 'SNILS has wrong length. '


# Generated at 2022-06-23 20:51:29.356914
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    """Unit test for method generate_sentence of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    result = provider.generate_sentence()
    assert (result)


# Generated at 2022-06-23 20:51:30.347042
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    provider = RussiaSpecProvider()
    assert provider is not None

# Generated at 2022-06-23 20:51:38.660815
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.person import Person
    from mimesis.enums import Gender
    p = Person('ru')
    for _ in range(0, 8):
        snils = p.snils()
        result_snils = p._parse_snils(snils)
        if _ == 0:
            assert snils == '41917492600'
            assert result_snils == {'numbers': '419174926', 'control_code': '0'}
        if _ == 1:
            assert snils == '08527693904'
            assert result_snils == {'numbers': '085276939', 'control_code': '4'}
        if _ == 2:
            assert snils == '29000907958'

# Generated at 2022-06-23 20:51:44.001008
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    ru_sp = RussiaSpecProvider()
    assert ru_sp.inn()
    assert ru_sp.patronymic()
    assert ru_sp.ogrn()
    assert ru_sp.bic()
    assert ru_sp.series_and_number()
    assert ru_sp.snils()
    assert ru_sp.kpp()

# Generated at 2022-06-23 20:51:46.968881
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    rs = RussiaSpecProvider()
    for i in range(100):
        a = rs.kpp()
        assert(len(a)==9)

# test_RussiaSpecProvider_kpp() 


# Generated at 2022-06-23 20:51:51.456535
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    assert RussiaSpecProvider().generate_sentence() == 'Проживающий в гостинице, в общежитии или на стационарном участке.'

# Generated at 2022-06-23 20:51:54.068437
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    provider = RussiaSpecProvider()
    sentence = provider.generate_sentence()
    assert str(sentence)
    assert len(sentence) > 0
    print(sentence)



# Generated at 2022-06-23 20:51:57.285227
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    import re
    p = RussiaSpecProvider()
    for _ in range(1000):
        x = p.ogrn()
        assert re.match(r'\d{13}', x) is not None


# Generated at 2022-06-23 20:51:58.602787
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    pass


# Generated at 2022-06-23 20:52:02.486115
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    rsp = RussiaSpecProvider()
    series_and_number = rsp.series_and_number()
    print(series_and_number)

if __name__ == "__main__":
    test_RussiaSpecProvider_series_and_number()

# Generated at 2022-06-23 20:52:04.603575
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils in class RussiaSpecProvider."""
    rp = RussiaSpecProvider()
    assert len(rp.snils()) == 11


# Generated at 2022-06-23 20:52:07.172911
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    for _ in range(0, 9):
        pattern = r'\d{4}\s\d{2}\s\d{6}'
        serial_number = RussiaSpecProvider().series_and_number()
        assert re.match(pattern, serial_number)


# Generated at 2022-06-23 20:52:09.491190
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """Method test_RussiaSpecProvider_kpp."""
    russia = RussiaSpecProvider()
    kpp = russia.kpp()


# Generated at 2022-06-23 20:52:12.594761
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    my_passport_number = RussiaSpecProvider()
    assert len(str(my_passport_number.passport_number())) == 6


# Generated at 2022-06-23 20:52:19.800321
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    ru = RussiaSpecProvider()
    ru.bic()

    assert ru.bic()
    assert ru.inn()
    assert ru.ogrn()
    assert ru.kpp()

    assert ru.passport_series()
    assert ru.passport_number()
    assert ru.series_and_number()

    assert ru.patronymic()

    assert ru.snils()
    assert ru.generate_sentence()

# Generated at 2022-06-23 20:52:21.551870
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    assert len(provider.snils()) == 11


# Generated at 2022-06-23 20:52:28.357212
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    gen = RussiaSpecProvider()
    result = gen.generate_sentence()
    print("\nПервые слова:")
    print(result.split(" ")[0:4])
    print("\nПоследние слова:")
    print(result.split(" ")[-4:])
    print("\nСобственно сама фраза:\n" + result)
    assert result is not None


# Generated at 2022-06-23 20:52:29.908742
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    r = RussiaSpecProvider()
    assert r.bic() == '044025575'

# Generated at 2022-06-23 20:52:34.447451
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
  rsp = RussiaSpecProvider()
  correct_number = 100000
  wrong_number = 999999
  num = rsp.passport_number()
  assert num >= correct_number and num <= wrong_number


# Generated at 2022-06-23 20:52:36.597453
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    for i in range(0, 10):
        assert len(RussiaSpecProvider().series_and_number()) == 11


# Generated at 2022-06-23 20:52:38.457580
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    provider = RussiaSpecProvider()

    assert '02 15' == provider.passport_series()

    return provider


# Generated at 2022-06-23 20:52:43.486642
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Unit test for RussiaSpecProvider.series_and_number."""
    p = RussiaSpecProvider()
    s_and_n = p.series_and_number()
    assert len(s_and_n.split()) <= 2
    assert len(s_and_n) == 11
    assert isinstance(p, RussiaSpecProvider)

# Generated at 2022-06-23 20:52:49.100185
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    print("\nUnit test for method snils of class RussiaSpecProvider")
    provider = RussiaSpecProvider()
    result = provider.snils()
    print("Test = 41917492600\nResult = {}".format(result))
    assert result == "41917492600"



# Generated at 2022-06-23 20:52:53.661443
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test method snils of class RussiaSpecProvider."""
    import re
    provider = RussiaSpecProvider()
    result = provider.snils()
    assert result
    assert isinstance(result, str)
    assert len(result) == 11
    assert re.match(r'\d{11}', result)
    return result


# Generated at 2022-06-23 20:52:56.225098
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    provider = RussiaSpecProvider()
    code = provider.kpp()
    assert isinstance(code, str)
    assert len(code) == 9

# Test for method snils of class RussiaSpecProvider

# Generated at 2022-06-23 20:53:02.105004
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    test_unit = RussiaSpecProvider()
    res = test_unit.passport_number()
    print(res)
    # Для получения информации по законодательству: http://www.gibdd.ru/check/dogovor/
    # 1. Основная часть паспорта (серия и номер)
    # Пример серии и номера паспорта: 01 11 111111.
    # Серия паспо

# Generated at 2022-06-23 20:53:05.815868
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    r = RussiaSpecProvider()
    assert len(r.bic()) == 9
    assert isinstance(r.bic(), str)
    assert isinstance(int(r.bic()), int)


# Generated at 2022-06-23 20:53:09.085111
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    assert len(RussiaSpecProvider().passport_series()) == 5
    assert len(RussiaSpecProvider().passport_series(2019)) == 5
    assert isinstance(RussiaSpecProvider().passport_series(), str)


# Generated at 2022-06-23 20:53:10.698647
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    r = RussiaSpecProvider()
    res = r.inn()
    assert len(res) == 12


# Generated at 2022-06-23 20:53:15.086390
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    # Arrange
    srp = RussiaSpecProvider()

    # Act
    sentence = srp.generate_sentence()

    # Assert
    assert isinstance(sentence, str)


# Generated at 2022-06-23 20:53:26.239095
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    rus = RussiaSpecProvider()
    print("Test: Generate sentence: ", rus.generate_sentence())
    print("Test: Generate patronymic: ", rus.patronymic())
    print("Test: Generate passport series: ", rus.passport_series())
    print("Test: Generate passport number: ", rus.passport_number())
    print("Test: Generate series and number: ", rus.series_and_number())
    print("Test: Generate snils: ", rus.snils())
    print("Test: Generate inn: ", rus.inn())
    print("Test: Generate ogrn: ", rus.ogrn())
    print("Test: Generate bic: ", rus.bic())

# Generated at 2022-06-23 20:53:30.659801
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    a = RussiaSpecProvider()
    for i in range(0, 99999):
        x = a.snils()
        print(x)
        assert len(x) == 11
        assert x[9] == x[10]

if __name__ == "__main__":
    test_RussiaSpecProvider_snils()

# Generated at 2022-06-23 20:53:32.279559
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    provider = RussiaSpecProvider()
    assert isinstance(provider.kpp(), str)
    assert len(provider.kpp()) == 9

# Generated at 2022-06-23 20:53:35.091501
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    provider = RussiaSpecProvider()
    assert isinstance(provider.passport_series(year=18), str)
test_RussiaSpecProvider_passport_series()


# Generated at 2022-06-23 20:53:37.815833
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    RussiaProvider = RussiaSpecProvider()
    kpp = RussiaProvider.kpp()
    assert len(kpp) == 9
    assert kpp.isdigit()

# Generated at 2022-06-23 20:53:40.715184
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    rsp = RussiaSpecProvider(seed=10) # RussiaSpecProvider instance

    d = {} # dictionary with kpp (key) and its counter (value)
    for i in range(0, 10000):
        kpp = rsp.kpp()
        if kpp in d:
            d[kpp] += 1
        else:
            d[kpp] = 1
    print(d)
    return None


# Generated at 2022-06-23 20:53:47.870489
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Проверка корректности генерации ИНН"""
    r = RussiaSpecProvider()
    inn = r.inn()
    assert len(inn) == 10
    assert int(inn[-2]) == control_sum(inn, 'n1')
    assert int(inn[-1]) == control_sum(inn, 'n2')


# Generated at 2022-06-23 20:53:55.682881
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    inn = RussiaSpecProvider()
    test_inn = inn.inn()
    # так как тест всегда проходит в одном и том же порядке, проверяем всегда одно и тоже число
    assert test_inn == "7800417429"


# Generated at 2022-06-23 20:53:56.757058
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    assert RussiaSpecProvider().kpp() == 8112


# Generated at 2022-06-23 20:53:59.917863
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    """Test the method generate_sentence of the class RussiaSpecProvider."""
    # Create object for class RussiaSpecProvider
    russiaspp = RussiaSpecProvider()
    # Generate sentence
    sentence = russiaspp.generate_sentence()
    # Printing sentence
    print('Sentence is:', sentence)


# Generated at 2022-06-23 20:54:03.294167
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    rus_provider = RussiaSpecProvider()
    inn = rus_provider.inn()
    assert inn == '7730001359'


# Generated at 2022-06-23 20:54:05.309492
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    provider = RussiaSpecProvider()
    r = provider.passport_number()
    print(r)

# Generated at 2022-06-23 20:54:09.254374
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    """Test method generate_sentence() of class RussiaSpecProvider."""
    russia_spec_provider = RussiaSpecProvider()
    sentence = russia_spec_provider.generate_sentence()
    print(sentence)


# Generated at 2022-06-23 20:54:14.283121
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    assert type(RussiaSpecProvider(seed=1).patronymic(gender=Gender.MALE)) == str
    assert type(RussiaSpecProvider(seed=1).patronymic(gender=Gender.FEMALE)) == str
    assert type(RussiaSpecProvider(seed=1).patronymic()) == str


# Generated at 2022-06-23 20:54:23.016156
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    """Test method bic of class RussiaSpecProvider"""
    sample_data = {
                "country_code" : "04",
                "code" : "4025575",
                "bank_number" : "40",
                "bank_office" : "255"
    }
    russia = RussiaSpecProvider()
    assert russia.bic()[:2] == sample_data["country_code"]
    assert russia.bic()[2:5] == sample_data["code"][:3]
    assert russia.bic()[5:7] == sample_data["bank_number"]
    assert int(sample_data["code"][3:]) % 99 == 0
    assert russia.bic()[7:] == sample_data["bank_office"]



# Generated at 2022-06-23 20:54:25.949376
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    p = RussiaSpecProvider

    def check_generate_sentence():
        for _ in range(0, 5):
            assert p.generate_sentence().startswith('Как отразится ')

    check_generate_sentence()



# Generated at 2022-06-23 20:54:35.075807
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    provider = RussiaSpecProvider()
    result = provider.patronymic(Gender.MALE)
    assert isinstance(result, str)
    assert result in ['Алексеевна', 'Владимировна', 'Дмитриевна', 'Евгеньевна', 'Николаевна', 'Игоревна', 'Александровна', 'Петровна', 'Сергеевна']

# Generated at 2022-06-23 20:54:42.453854
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    provider = RussiaSpecProvider()
    assert isinstance(provider.inn(), str)
    assert isinstance(provider.ogrn(), str)
    assert isinstance(provider.bic(), str)
    assert isinstance(provider.kpp(), str)
    assert isinstance(provider.snils(), str)
    assert isinstance(provider.patronymic(), str)
    assert isinstance(provider.passport_series(), str)
    assert isinstance(provider.passport_number(), int)
    assert isinstance(provider.series_and_number(), str)
    assert isinstance(provider.generate_sentence(), str)

# Generated at 2022-06-23 20:54:49.542459
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    rp = RussiaSpecProvider()
    rp.locale = 'ru'
    rp.dump = 'test_data/test_RussiaSpecProvider_ogrn.txt'
    for _ in range(0, 1000):
        rp.ogrn()
    with open('test_data/test_RussiaSpecProvider_ogrn.txt') as f:
        count = 0
        for line in f:
            if line[-2] == '\n':
                count += 1
        assert count == 1000


# Generated at 2022-06-23 20:54:50.573073
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    return RussiaSpecProvider().kpp()

# Generated at 2022-06-23 20:54:53.388696
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    """Unit test for method generate_sentence of class
    RussiaSpecProvider
    """
    pass

# Generated at 2022-06-23 20:54:59.166935
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    provider = RussiaSpecProvider()
    assert provider.patronymic() in ("Алексеевна", "Федорович", "Иванович", "Максимович", "Александрович", "Сергеевич")

# Generated at 2022-06-23 20:55:02.494194
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    rsp = RussiaSpecProvider()
    inn = rsp.inn()
    assert len(inn) == 12
    numbers = [int(i) for i in inn]
    assert sum(numbers) % 11 % 10 == numbers[-1]

# Generated at 2022-06-23 20:55:08.961564
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    f = RussiaSpecProvider()
    g = f.passport_series()
    assert len(g) == 5
    for i in g:
        if int(i) in range(10, 19):
            assert i in ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0']
        else:
            assert i in ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0', ' ', '']


# Generated at 2022-06-23 20:55:11.127967
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    assert isinstance(provider.snils(), str)
    assert len(provider.snils()) == 11

# Generated at 2022-06-23 20:55:13.604098
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """Test function for passport_number of class RussiaSpecProvider."""
    passport_number = RussiaSpecProvider().passport_number()
    assert len(str(passport_number)) == 6

# Generated at 2022-06-23 20:55:14.389005
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    RussiaSpecProvider().series_and_number()

# Generated at 2022-06-23 20:55:17.070265
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    r = RussiaSpecProvider()
    assert r.inn() in ''.join(str(x) for x in range(1, 10)) * 8

# Generated at 2022-06-23 20:55:20.005466
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Unit test for method inn of class RussiaSpecProvider."""
    from mimesis.providers.russia import RussiaSpecProvider as rsp
    rus = rsp()
    assert (len(rus.inn()) == 10) == True


# Generated at 2022-06-23 20:55:22.424892
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    r = RussiaSpecProvider()
    print(r.passport_series())


# Generated at 2022-06-23 20:55:24.712870
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Testing method inn of class RussiaSpecProvider."""
    assert RussiaSpecProvider().inn() == '7701101271'


# Generated at 2022-06-23 20:55:31.436280
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    rsp = RussiaSpecProvider()
    # Test method generate_sentence
    print(rsp.generate_sentence())
    # Test method series_and_number
    print(rsp.series_and_number())
    # Test method snils
    print(rsp.snils())
    # Test method inn
    print(rsp.inn())
    # Test method ogrn
    print(rsp.ogrn())
    # Test method bic
    print(rsp.bic())
    # Test method kpp
    print(rsp.kpp())

# Run test
test_RussiaSpecProvider()

# Generated at 2022-06-23 20:55:39.420807
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    """Test for method generate_sentence of class RussiaSpecProvider."""
    provider = RussiaSpecProvider('seed')
    assert provider.generate_sentence() == 'Я думаю, вы видите, что в нем скрывается.'
    assert provider.generate_sentence() == 'Я думаю, вы видите, что в нем скрывается.'
    assert provider.generate_sentence() == 'Я думаю, вы видите, что в нем скрывается.'
   

# Generated at 2022-06-23 20:55:41.272902
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    rsp = RussiaSpecProvider()
    assert len(rsp.series_and_number()) == 12


# Generated at 2022-06-23 20:55:42.663519
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    tmp = RussiaSpecProvider()


# Generated at 2022-06-23 20:55:45.212865
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test snils of RussiaSpecProvider"""
    assert RussiaSpecProvider().snils() == '41917492600'

# Generated at 2022-06-23 20:55:51.223250
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    result = RussiaSpecProvider().bic()
    assert result[0:2] == '04'
    assert result[2] >= str(1) and result[2] <= str(10)
    assert result[3:5] >= str(0) and result[3:5] <= str(99)
    assert result[5:8] >= str(50) and result[5:8] <= str(999)

# Generated at 2022-06-23 20:55:58.458784
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    print('Testing RussiaSpecProvider.passport_series')
    passport_all = []
    for i in range(10):
        result = RussiaSpecProvider().passport_series()
        passport_all.append(result)
    print('Test-case 1: ', 'PASSED' if len(passport_all) == 10 else 'FAILED')
    print('Test-case 2: ', 'PASSED' if isinstance(passport_all[0], str) else 'FAILED')
    print('Test-case 3: ', 'PASSED' if len(passport_all[0]) == 5 else 'FAILED')

# Generated at 2022-06-23 20:56:03.288203
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    provider = RussiaSpecProvider()
    assert provider.patronymic(Gender.FEMALE) != provider.patronymic(Gender.MALE)
    assert provider.patronymic(Gender.MALE) != provider.patronymic(Gender.FEMALE)


# Generated at 2022-06-23 20:56:07.610830
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender
    rsp = RussiaSpecProvider()
    assert rsp.series_and_number() == '57 16 805199'
    assert rsp.series_and_number() is not None


# Generated at 2022-06-23 20:56:12.581867
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    inn = RussiaSpecProvider().inn()
    assert isinstance(inn, str)
    assert len(inn) == 10
    assert inn.isdigit()
    for i in [1, 2, 3, 4, 5, 9, 11]:
        assert int(inn[i]) % 2 == 0
    assert int(inn[2]) <= 8
    assert int(inn[8]) <= 5


# Generated at 2022-06-23 20:56:17.365578
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Test method `ogrn` from the class `RussiaSpecProvider`.

    :return:
    """
    rsp = RussiaSpecProvider(seed=42)
    
    result = rsp.ogrn()
    assert result == '4715113303725', 'Must be 4715113303725, but returned >> {}'.format(result)

# Generated at 2022-06-23 20:56:19.567556
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    r = RussiaSpecProvider(seed='123')
    assert r.__init__('123') == None

# Generated at 2022-06-23 20:56:20.989358
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    assert RussiaSpecProvider().series_and_number() == "57 16 805199"

# Generated at 2022-06-23 20:56:31.776796
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    # Initialization
    # The class, method and expected value to be tested
    provider = RussiaSpecProvider()
    method = provider.generate_sentence()
    expected_value = "Я пошёл в магазин и купил себе выходной билет"

    # Actual value being returned by method
    # This line of code calls a method to be tested
    actual_value = method

    # Test
    test_result = actual_value == expected_value
    print("{0} == {1} : {2}".format(method, actual_value, expected_value))
    assert test_result

# Generated at 2022-06-23 20:56:35.859552
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    print("Testing 5 times method passport_number of class RussiaSpecProvider...")
    prov = RussiaSpecProvider(seed=42)
    for i in range(5):
        print(prov.passport_number())
    print("Done!")


# Generated at 2022-06-23 20:56:38.729503
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    sp = RussiaSpecProvider()
    assert type(sp.generate_sentence()) == str


    # Unit test for method passport_series of class RussiaSpecProvider

# Generated at 2022-06-23 20:56:43.467028
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    from mimesis.providers.person.russia import RussiaSpecProvider

    for i in range(1, 13):
        passport_series = RussiaSpecProvider().passport_series()
        passport_number = RussiaSpecProvider().passport_number()
        print(passport_series + passport_number)

# Generated at 2022-06-23 20:56:45.688623
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    provider = RussiaSpecProvider()
    result = provider.generate_sentence()
    print(result)


# Generated at 2022-06-23 20:56:50.677736
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    from mimesis.providers.geo.russia import RussiaSpecProvider
    #print(RussiaSpecProvider().provider_name())
    #print(RussiaSpecProvider().__name__)
    print(RussiaSpecProvider().address())

if __name__ == "__main__":
    test_RussiaSpecProvider()

# Generated at 2022-06-23 20:56:54.647848
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    p = RussiaSpecProvider()
    x = p.passport_number()
    assert len(str(x)) == 6
    assert x > 100000
    assert x < 999999


# Generated at 2022-06-23 20:56:57.355336
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """
    Unit test for method passport_series of class RussiaSpecProvider
    """
    assert (RussiaSpecProvider().passport_series())[
        :4] == "11 14"



# Generated at 2022-06-23 20:57:05.032863
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():

    # Test with default values
    test_1 = RussiaSpecProvider()
    res1 = test_1.passport_series()

    assert type(res1) == str, 'Возвращенное значение не является строкой'
    assert len(res1) == 5, 'Кол-во символов в строке не равно 5'

# Generated at 2022-06-23 20:57:10.498428
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    r1 = RussiaSpecProvider().passport_series()
    assert len(r1) == 5
    assert r1[2] == ' '
    assert r1[0:2].isdigit()
    assert r1[3:5].isdigit()


# Generated at 2022-06-23 20:57:12.594591
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    assert RussiaSpecProvider(seed=385).passport_series(year=15)=='88 15'


# Generated at 2022-06-23 20:57:16.378842
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis import RussiaSpecProvider

    rsp = RussiaSpecProvider()
    snils_list = []
    while len(set(snils_list)) < 150:
        snils_list.append(rsp.snils())

    assert len(snils_list) >= 150
    assert len(set(snils_list)) >= 149

# Generated at 2022-06-23 20:57:18.464434
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    bic = RussiaSpecProvider().bic()
    assert len(bic) > 0


# Generated at 2022-06-23 20:57:19.810081
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    r = RussiaSpecProvider()
    assert len(r.ogrn()) == 13
    assert r.ogrn().isdigit()


# Generated at 2022-06-23 20:57:24.556815
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    # Test case 1
    provider = RussiaSpecProvider()
    assert provider.bic() == '044025575'
    # Test case 2
    provider = RussiaSpecProvider()
    assert provider.bic() == '044025575'


# Generated at 2022-06-23 20:57:31.500370
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider()

    bic = provider.bic()
    assert len(bic) == 9
    assert bic[0] == '0'
    assert bic[1] == '4'
    assert bic[2] in "123456789"
    assert bic[3] in "0123456789"
    assert bic[4] == "2"
    assert bic[5] in "123456789"
    assert bic[6] in "0123456789"
    assert bic[7] == "5"
    assert bic[8] in "0123456789"


# Generated at 2022-06-23 20:57:33.307698
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider()
    provider.bic()


# Generated at 2022-06-23 20:57:43.320604
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    provider = RussiaSpecProvider()
    random_patronymic = provider.patronymic(Gender.MALE.value)