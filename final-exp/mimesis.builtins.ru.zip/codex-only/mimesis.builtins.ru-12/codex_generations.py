

# Generated at 2022-06-23 20:47:46.108420
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Unit test for method passport_series of class RussiaSpecProvider."""

    p = RussiaSpecProvider()
    assert len(p.passport_series()) == 5
    assert p.passport_series(16) == '16 16'

# Generated at 2022-06-23 20:47:48.977730
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    provider = RussiaSpecProvider()
    ogrn = provider.ogrn()
    assert len(ogrn) == 13
    assert int(ogrn) % 11 % 10 == int(ogrn[-1])


# Generated at 2022-06-23 20:47:59.294224
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rus = RussiaSpecProvider()
    for i in range(0, 999):
        snils = rus.snils()
        snils = snils.replace('-', '')
        result = 0
        for i in range(9, 0, -1):
            result += int(snils[9 - i]) * i
        if (result % 101 == 100):
            assert snils[9:11] == '00'
        if (result % 101 < 100):
            assert snils[9:11] == str(result % 101)
        if (result % 101 > 100):
            result_ = result % 101 % 100
            if (result_ == 100):
                result_ = 0
            assert snils[9:11] == '{:02}'.format(result_)


# Generated at 2022-06-23 20:48:00.964328
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    provider = RussiaSpecProvider(seed=42)
    assert provider.ogrn() == "4715123708310"

# Generated at 2022-06-23 20:48:11.544702
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    import inspect
    import sys
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.internet import Internet
    from mimesis.enums import Gender

    rus_pers = Person('ru')
    rus_internet = Internet('ru')
    rus_addr = Address('ru')

    pers0 = rus_pers.full_name(gender=Gender.FEMALE)
    pers1 = rus_pers.full_name(gender=Gender.MALE)
    pers2 = rus_pers.full_name(gender=Gender.FEMALE)
    pers3 = rus_pers.full_name(gender=Gender.MALE)

# Generated at 2022-06-23 20:48:13.493832
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    test_object = RussiaSpecProvider()
    print(test_object.series_and_number()) # 01 05 823100


# Generated at 2022-06-23 20:48:15.525653
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    ru = RussiaSpecProvider()
    print(ru.kpp())

# Generated at 2022-06-23 20:48:22.356420
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    a  = RussiaSpecProvider()
    passport_number = a.passport_number()
    # проверим длину полученного номера
    if len(str(passport_number)) != 6:
        print('Неверная длина номера паспорта')
    else:
        print('Длина номера паспорта верна')


# Generated at 2022-06-23 20:48:25.204307
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    r = RussiaSpecProvider()
    assert 1e6 > r.passport_number() > 1e5, 'passport_number test'


# Generated at 2022-06-23 20:48:27.272229
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    x = RussiaSpecProvider()
    print(x.snils())
    print(x.ogrn())
    print(x.inn())

# Generated at 2022-06-23 20:48:35.326049
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """The unit test for method ogrn of class RussiaSpecProvider.
    """
    # Init
    russia_spec_provider = RussiaSpecProvider()
    ogrn = russia_spec_provider.ogrn()
    # Check
    assert len(ogrn) == 13
    assert int(ogrn) % 11 % 10 == int(ogrn[-1])
    # Init 2
    russia_spec_provider = RussiaSpecProvider(seed="RANDOM_SEED")
    ogrn = russia_spec_provider.ogrn()
    # Check 2
    assert len(ogrn) == 13
    assert int(ogrn) % 11 % 10 == int(ogrn[-1])


# Generated at 2022-06-23 20:48:38.088339
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Test method inn of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    data = provider.inn()

    assert len(data) == 12


# Generated at 2022-06-23 20:48:40.101987
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    r = RussiaSpecProvider()
    assert r.ogrn() == '4715113303725'

# Generated at 2022-06-23 20:48:41.548429
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    tmp = RussiaSpecProvider()
    assert tmp is not None


# Generated at 2022-06-23 20:48:47.485943
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    from mimesis.builtins import RussiaSpecProvider
    ru_spec = RussiaSpecProvider()
    ru_spec.generate_sentence()
    ru_spec.patronymic()
    ru_spec.passport_series()
    ru_spec.passport_number()
    ru_spec.series_and_number()
    ru_spec.inn()
    ru_spec.snils()
    ru_spec.ogrn()
    ru_spec.kpp()
    ru_spec.bic()

# Generated at 2022-06-23 20:48:52.945369
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    from mimesis.providers.generic import GenericSpecProvider

    spec = RussiaSpecProvider(GenericSpecProvider())
    assert spec.passport_series() == '49 00'
    spec.reset_seed()
    assert spec.passport_series() == '49 00'
    spec.reset_seed()
    assert spec.passport_series() == '30 00'


# Generated at 2022-06-23 20:48:54.983349
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    r = RussiaSpecProvider()
    assert r.provider.generate_sentence() != r.provider.generate_sentence()


# Generated at 2022-06-23 20:48:59.682204
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    import unittest
    import re

    class RussiaSpecProviderTests(unittest.TestCase):
        def setUp(self):
            self.provider = RussiaSpecProvider()

        def test_snils(self):
            pattern = re.compile(r'^[0-9]{11}$')
            val = self.provider.snils()
            self.assertRegex(val, pattern)

    unittest.main()

# Generated at 2022-06-23 20:49:04.550905
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    list_inns = []
    set_inns = set()

    rsp = RussiaSpecProvider()
    for _ in range(0, 100000):
        inn = rsp.inn()
        list_inns.append(inn)
        set_inns.add(inn)

    assert len(set_inns) == len(list_inns)


# Generated at 2022-06-23 20:49:07.899990
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    rsp = RussiaSpecProvider()
    assert len(rsp.bic()) == 9
    assert rsp.bic()[0:2] == '04'



# Generated at 2022-06-23 20:49:10.030597
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    provider = RussiaSpecProvider()
    assert len(provider.inn()) == 10


# Generated at 2022-06-23 20:49:12.128070
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    rp = RussiaSpecProvider()
    rp.random.seed(1)
    pn = rp.passport_number()
    assert pn == 966562


# Generated at 2022-06-23 20:49:17.918936
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    russ = RussiaSpecProvider(seed=1)
    assert russ.generate_sentence() == 'Всем существованию человеческому для общения предназначены инстинкты, но не главные черты человеческой природы.'


# Generated at 2022-06-23 20:49:21.085474
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Test method passport_series"""
    test_obj = RussiaSpecProvider()
    assert isinstance(test_obj.passport_series(), str)


# Generated at 2022-06-23 20:49:29.622131
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    # Init
    rus = RussiaSpecProvider(seed=0)

    # Test with first number as 0
    assert rus.snils() == "85950659200"

    # Test with second number as 0
    rus2 = RussiaSpecProvider(seed=123)
    assert rus2.snils() == "99274642700"

    # Test with third number as 0
    rus3 = RussiaSpecProvider(seed=35)
    assert rus3.snils() == "90727846000"

    # Test with sum from 100 to 101
    rus4 = RussiaSpecProvider(seed=20)
    assert rus4.snils() == "04989809700"

    # Test with sum more than 101
    rus5 = RussiaSpecProvider(seed=1500)
    assert rus5.snils

# Generated at 2022-06-23 20:49:33.323995
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    import mimesis
    russiaspecprovider = mimesis.RussiaSpecProvider()
    ogrn = russiaspecprovider.ogrn()
    assert (len(ogrn) == 13)
    assert isinstance(ogrn, str)


# Generated at 2022-06-23 20:49:34.865513
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    russian_provider = RussiaSpecProvider()
    assert russian_provider.bic() == '044025575'


# Generated at 2022-06-23 20:49:37.196388
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    rsp = RussiaSpecProvider()
    number = rsp.kpp()
    print(number)
    if len(number) != 9:
        raise AssertionError

    if not number.isdigit():
        raise AssertionError


# Generated at 2022-06-23 20:49:41.820350
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    """Test method RussiaSpecProvider.generate_sentence()"""
    provider = RussiaSpecProvider()
    sentences = [provider.generate_sentence() for _ in range(100)]
    assert len(sentences) == 100

    for s in sentences:
        assert len(s) > 5


# Generated at 2022-06-23 20:49:44.083828
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider()
    assert len(provider.bic()) == 9
    assert provider.bic()[0:2] == '04'


# Generated at 2022-06-23 20:49:44.751836
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    assert RussiaSpecProvider().kpp() is not None


# Generated at 2022-06-23 20:49:48.241586
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    rsp = RussiaSpecProvider()
    number = rsp.passport_number()
    if 100000 <= number <= 999999:
        return True
    else:
        return False


# Generated at 2022-06-23 20:49:59.134765
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    from . import RussiaSpecProvider as rs
    from mimesis.builtins.base import BaseSpecProvider
    from mimesis.enums import Gender
    from mimesis.typing import Seed
    russian = rs(Seed.random())
    russian.Meta.name = "Test"
    gender = russian._validate_enum(None, Gender)
    russian.patronymic(gender)
    russian.passport_series()
    russian.passport_number()
    russian.series_and_number()
    russian.snils()
    russian.inn()
    russian.ogrn()
    russian.bic()
    russian.kpp()

# Generated at 2022-06-23 20:50:01.023943
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    data = RussiaSpecProvider()
    assert data.passport_series(10) == '01 10'
    assert data.passport_series(5) == '65 05'
    assert data.passport_series(15) == '76 15'
    assert data.passport_series(18) == '94 18'

# Generated at 2022-06-23 20:50:09.427548
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    pass_ser = RussiaSpecProvider()
    test_cases = [
        (pass_ser.passport_series()[0:2], "02"),
        (pass_ser.passport_series()[3:4], "1"),
        (pass_ser.passport_series()[3:4], "2")
    ]
    for test in test_cases:
        assert (test[0] == test[1]), "Возвращаемый результат должен быть {}".format(test[1])

# Generated at 2022-06-23 20:50:11.822768
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    """Unit test for constructor of class RussiaSpecProvider."""
    rssp = RussiaSpecProvider()
    assert rssp is not None

# Generated at 2022-06-23 20:50:18.880969
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    rs = RussiaSpecProvider(seed=0)
    #Create a list of year
    years = []
    for _ in range(0, 5):
        years.append(rs.random.randint(10, 18))
    #Create a list of series
    passport_series_list = []
    for year in years:
        passport_series_list.append(rs.passport_series(year))
    #Assert
    assert passport_series_list == ['36 10', '74 12', '09 18', '44 10', '20 16']


# Generated at 2022-06-23 20:50:21.616303
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    import re

    provider = RussiaSpecProvider()
    ogrn = provider.ogrn()
    assert bool( len(ogrn) == 13 and re.match('^[0-9]{13}$', ogrn) ) == True


# Generated at 2022-06-23 20:50:23.144570
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    string = RussiaSpecProvider().series_and_number()
    assert len(string) == 11
    assert string[2] == ' '
    assert string[6] == ' '


# Generated at 2022-06-23 20:50:25.324073
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    a = RussiaSpecProvider()
    assert a.patronymic() == RussiaSpecProvider().patronymic()


# Generated at 2022-06-23 20:50:26.937189
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    rsp = RussiaSpecProvider()
    print(rsp.generate_sentence())


# Generated at 2022-06-23 20:50:30.618893
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    inn = RussiaSpecProvider.inn()
    inn_length = len(inn)

    condition_1 = inn_length == 10
    condition_2 = int(inn[0]) == 4

    assert condition_1 and condition_2


# Generated at 2022-06-23 20:50:40.774160
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    from mimesis.providers.person.russia import RussiaSpecProvider
    p = RussiaSpecProvider()
    for _ in range(10):
        passport_serie = p.passport_series()
        assert len(passport_serie) == 5
        assert passport_serie[-1] == '1' or passport_serie[-1] == '2'
        assert passport_serie[-2] == '0' or passport_serie[-2] == '9'
        assert passport_serie[1] == ' '
        assert int(passport_serie[2:4]) < 100 and int(passport_serie[2:4]) >= 10


# Generated at 2022-06-23 20:50:43.073905
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    l = RussiaSpecProvider()
    l.series_and_number()
    # 38 14 148837
    # 12 18 133478

# Generated at 2022-06-23 20:50:50.833306
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """
    Тестирует случайное получение КПП
    """
    r = RussiaSpecProvider()
    kpp = r.kpp()
    assert len(kpp) == 9

# Generated at 2022-06-23 20:50:53.247871
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    provider = RussiaSpecProvider()
    ogrn = provider.ogrn()

    assert(len(ogrn) == 13)
    assert(int(ogrn) % 11 % 10 == int(ogrn[12]))
    assert(12 == len(ogrn))

# Generated at 2022-06-23 20:50:58.347602
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    from . import RussiaSpecProvider
    rup = RussiaSpecProvider()
    assert type(rup.series_and_number()) == str
    rup = RussiaSpecProvider()
    assert type(rup.series_and_number()) == str
    rup = RussiaSpecProvider()
    assert type(rup.series_and_number()) == str
    rup = RussiaSpecProvider()
    assert type(rup.series_and_number()) == str


# Generated at 2022-06-23 20:50:59.809321
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    print(r.snils())

# Generated at 2022-06-23 20:51:04.929094
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Test for method passport_series of class RussiaSpecProvider."""
    # create a RussiaSpecProvider object
    provider = RussiaSpecProvider()
    # call method passport_series of class RussiaSpecProvider
    passport_series = provider.passport_series()
    # check the result
    assert len(passport_series) == 5


# Generated at 2022-06-23 20:51:07.442838
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    data = RussiaSpecProvider(seed=14305729087)
    assert data.patronymic() == 'Алексеевна'


# Generated at 2022-06-23 20:51:13.942110
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    rusprov = RussiaSpecProvider()

    for _ in range(0, 100):
        inn = rusprov.inn()
        assert len(inn) == 12, 'INN must contain 12 characters'
        assert inn[:2] in ['10', '20', '31', '32', '33', '36'], 'INN must start from 10, 20, 31, 32, 33 or 36'



# Generated at 2022-06-23 20:51:16.061513
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert len(RussiaSpecProvider().snils()) == 11


# Generated at 2022-06-23 20:51:17.527587
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    provider = RussiaSpecProvider()
    provider.patronymic(Gender.MALE)


# Generated at 2022-06-23 20:51:20.271712
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    from mimesis.providers.russia_provider import RussiaSpecProvider
    russianprovider=RussiaSpecProvider(seed=0)
    assert russianprovider.ogrn() == '4715113303725'



# Generated at 2022-06-23 20:51:23.112117
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Test for method series_and_number of class RussiaSpecProvider."""
    from mimesis import RussiaSpecProvider

    rsp = RussiaSpecProvider()
    print(rsp.series_and_number())

# Generated at 2022-06-23 20:51:27.414988
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    provider = RussiaSpecProvider()
    for _ in range(0, 1000):
        inn = int(provider.inn())
        assert inn >= 1000000000 and inn <= 9999999999



# Generated at 2022-06-23 20:51:29.682994
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    provider = RussiaSpecProvider()
    kpp = provider.kpp()
    assert len(kpp) == 9


# Generated at 2022-06-23 20:51:30.668661
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    russian = RussiaSpecProvider()

# Generated at 2022-06-23 20:51:33.790645
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    rd = RussiaSpecProvider()
    for _ in range(0, 10):
        rd.patronymic(Gender.FEMALE)
        rd.patronymic(Gender.MALE)


# Generated at 2022-06-23 20:51:36.995973
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    # Create an instance of RussiaSpecProvider
    russian_instance = RussiaSpecProvider()
    # Get some link to body of class RussiaSpecProvider
    test_russian_instance = russian_instance.__init__()
    assert type(test_russian_instance) is None


# Generated at 2022-06-23 20:51:41.401268
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    russiaSpecProvider = RussiaSpecProvider(seed=38)
    passport_number = russiaSpecProvider.passport_number()
    assert passport_number == 779425


# Generated at 2022-06-23 20:51:44.960724
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    # Create instance of class RussiaSpecProvider
    spec = RussiaSpecProvider()
    # Generate random patronymic name
    patronymic = spec.patronymic()
    # Print it
    print(patronymic)


# Generated at 2022-06-23 20:51:54.142317
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    russian_provider = RussiaSpecProvider()
    assert russian_provider.patronymic(gender=Gender.MASCULINE) in russian_provider._data['patronymic'][Gender.MASCULINE]
    assert russian_provider.patronymic(gender=Gender.FEMININE) in russian_provider._data['patronymic'][Gender.FEMININE]
    assert russian_provider.patronymic(gender=Gender.NEUTER) in russian_provider._data['patronymic'][Gender.NEUTER]

# Generated at 2022-06-23 20:51:56.803484
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    russiaSpecProvider=RussiaSpecProvider()
    assert len(russiaSpecProvider.passport_series()) == 4
    assert isinstance(russiaSpecProvider.passport_series(), str)



# Generated at 2022-06-23 20:51:58.513263
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    """Test method patronymic in class RussiaSpecProvider"""

# Generated at 2022-06-23 20:52:07.201441
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    from mimesis.enums import Gender
    sp = RussiaSpecProvider()
    # Например, чтобы получить случайную мужскую фамилию, вызовите
    result = sp.patronymic(Gender.MALE)
    print('result: ' + result)
    result = sp.patronymic(Gender.FEMALE)
    print('result: ' + result)
# Выходные данные
# result: Григорьевич
# result: Петровна

#

# Generated at 2022-06-23 20:52:12.196441
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    from mimesis.enums import Gender
    from mimesis.providers.person.ru import RussiaSpecProvider

    # When we use the method patronymic without parameters
    # Then we get random patronymic name 
    test_patronymic = RussiaSpecProvider().patronymic()


# Generated at 2022-06-23 20:52:15.232106
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    output = []
    for index in range(0, 100):
        provider = RussiaSpecProvider()
        output.append(provider.patronymic(Gender.FEMALE))
    assert len(output) == 100


# Generated at 2022-06-23 20:52:20.442076
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Unit test for method ogrn of class RussiaSpecProvider.

    Usage:
        python -m doctest tests/builtins_providers_test.py -v
    """
    provider = RussiaSpecProvider()
    ogrn = provider.ogrn()
    assert len(ogrn) == 13
    assert ogrn == provider.ogrn()

# Generated at 2022-06-23 20:52:21.777066
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    r = RussiaSpecProvider()
    r.generate_sentence()

# Generated at 2022-06-23 20:52:25.720686
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    provider = RussiaSpecProvider()
    provider_str = "RussiaSpecProvider(seed=%r)"
    assert provider.__repr__() == provider_str % provider.seed
    assert provider.__str__() == provider_str % provider.seed


# Generated at 2022-06-23 20:52:29.569586
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    rsp = RussiaSpecProvider()
    ogrn = rsp.ogrn()
    assert ogrn[11] == str(int(ogrn[:11]) % 11 % 10)

# Generated at 2022-06-23 20:52:30.965207
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Testing RussiaSpecProvider.ogrn."""
    for i in range(0, 100):
        assert RussiaSpecProvider().ogrn()



# Generated at 2022-06-23 20:52:39.511182
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    from mimesis.providers.russia_provider import RussiaSpecProvider
    from mimesis.enums import Gender
    from mimesis.exceptions import NonEnumerableError
    from mimesis.typing import Seed
    import pytest

    spec = RussiaSpecProvider(seed=Seed(12345))

    # Unit testing method passport_number of class RussiaSpecProvider
    assert spec.passport_number() == 772627
    assert spec.passport_number() == 772627
    seed = Seed(12345)
    assert spec.passport_number(seed=seed) == 772627

# Generated at 2022-06-23 20:52:41.541741
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    r = RussiaSpecProvider()
    assert len(r.series_and_number()) == 11
    print(r.series_and_number())

# Generated at 2022-06-23 20:52:43.783923
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    r = RussiaSpecProvider()
    #print(r.inn())
    pass


# Generated at 2022-06-23 20:52:45.743133
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    provider = RussiaSpecProvider()
    assert len(provider.kpp())==9

# Generated at 2022-06-23 20:52:48.241177
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    spam = RussiaSpecProvider()
    assert spam.generate_sentence() in spam._data['sentence']


# Generated at 2022-06-23 20:52:51.731050
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    """Test RussiaSpecProvider bic method."""
    from mimesis.providers.financial import RussiaSpecProvider
    rsp = RussiaSpecProvider()
    bic_actual = rsp.bic()
    assert len(bic_actual) == 9
    assert type(bic_actual) == str


# Generated at 2022-06-23 20:52:54.048403
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    def f():
        asrt = {
            '41917492600'
        }
        for i in range(20):
            assert RussiaSpecProvider().snils() in asrt
    f()


# Generated at 2022-06-23 20:53:01.121757
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    provider = RussiaSpecProvider()
    series = provider.passport_series(year=18)

# Generated at 2022-06-23 20:53:04.178297
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    _RussiaSpecProvider = RussiaSpecProvider(seed = 10)
    assert _RussiaSpecProvider.provider == 'Russiaprovider'

# Generated at 2022-06-23 20:53:07.987367
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    russ = RussiaSpecProvider()
    print(russ.bic())
    print(russ.bic())
    print(russ.bic())

    # The test result is "044025575", "044025575", "044025575"


# Generated at 2022-06-23 20:53:11.583842
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    russiaspecprovider = RussiaSpecProvider()
    inn = russiaspecprovider.inn()
    russiaspecprovider.inn()
    russiaspecprovider.inn()
    russiaspecprovider.inn()
    print(russiaspecprovider)
    print(inn)

# Generated at 2022-06-23 20:53:12.780725
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    assert len(RussiaSpecProvider().bic()) == 9


# Generated at 2022-06-23 20:53:16.713495
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    """Test method bic of class RussiaSpecProvider."""
    rp = RussiaSpecProvider(seed=None)
    bic1 = rp.bic()
    bic2 = rp.bic()
    assert len(bic1) == 9
    assert len(bic2) == 9
    assert bic1 != bic2


# Generated at 2022-06-23 20:53:23.078374
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Case of checking that the generated series is not unique."""
    import collections
    import string

    cnt = collections.Counter()

    for _ in range(0, 999):
        series = RussiaSpecProvider().passport_series()
        assert len(series) == 5

        cnt[series] += 1

    assert not all(b == 1 for b in cnt.values())


# Generated at 2022-06-23 20:53:24.936985
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    assert RussiaSpecProvider().series_and_number() == '5613273777'

# Generated at 2022-06-23 20:53:34.136190
# Unit test for method patronymic of class RussiaSpecProvider

# Generated at 2022-06-23 20:53:35.389478
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    provider = RussiaSpecProvider()
    test_sentence = provider.generate_sentence()
    assert test_sentence != ""

# Generated at 2022-06-23 20:53:37.344597
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    russia_provider = RussiaSpecProvider()
    russia_provider.passport_series()


# Generated at 2022-06-23 20:53:39.426354
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    from mimesis.providers.russia import RussiaSpecProvider
    spec_ru = RussiaSpecProvider
    assert spec_ru._data['ogrn'][0] <= int(spec_ru.ogrn()) <= spec_ru._data['ogrn'][1]



# Generated at 2022-06-23 20:53:43.038805
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    obj = RussiaSpecProvider()
    print('Testing passport_number method ... ', end='')
    assert obj.passport_number() in range(100000, 999999)
    print('done.')


# Generated at 2022-06-23 20:53:54.630926
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Unit test for method inn of class RussiaSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers.address import Address
    from mimesis.providers.geography import Geography
    from mimesis.providers.person import Person
    from mimesis.providers.russia import RussiaSpecProvider
    from mimesis.providers.time import Time
    import pandas as pd

    g = Geography('ru')
    r = RussiaSpecProvider()
    p = Person('ru')
    a = Address('ru')
    t = Time('ru')

    list_person = []
    # для быстрой проверки создаем просто список,

# Generated at 2022-06-23 20:53:59.543993
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    test_cases = [
        (10, "22 10"),
        (11, "42 11"),
        (12, "83 12"),
        (13, "15 13"),
        (14, "55 14"),
        (15, "39 15"),
        (16, "35 16"),
        (17, "86 17"),
        (18, "56 18")
    ]
    test_provider = RussiaSpecProvider()
    for year, result in test_cases:
        assert test_provider.passport_series(year) == result


# Generated at 2022-06-23 20:54:06.132214
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    from mimesis.typing import Seed
    from mimesis.providers.russia import RussiaSpecProvider
    r = RussiaSpecProvider()
    ogrn = r.ogrn()
    r2 = RussiaSpecProvider(seed=Seed(r.seed))
    ogrn2 = r2.ogrn()
    assert ogrn == ogrn2


# Generated at 2022-06-23 20:54:09.403090
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    ru_provider = RussiaSpecProvider()
    ru_provider.seed(1)
    sn = ru_provider.series_and_number()
    assert sn == '57 16 805199'


# Generated at 2022-06-23 20:54:14.441921
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    for _ in range(0,10):
        person = RussiaSpecProvider()
        name = person.name(gender = person.gender())
        surname = person.surname()
        patronymic = person.patronymic()
        print(name, ' ', surname, ' ', patronymic, sep = '')




# Generated at 2022-06-23 20:54:17.156049
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Unit test for method inn of class RussiaSpecProvider."""
    o_inn = RussiaSpecProvider(seed=12345)
    assert o_inn.inn() == "7713268859"

# Generated at 2022-06-23 20:54:21.017059
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """Test function kpp of class RussiaSpecProvider."""
    actual = RussiaSpecProvider().kpp()
    assert isinstance(actual, str)
    assert len(actual) == 9
    assert actual != '000000000'
    assert actual != '111111111'


# Generated at 2022-06-23 20:54:24.039319
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    """Тест для метода bic класса RussiaSpecProvider."""

    r = RussiaSpecProvider()
    print(r.bic())
    assert r.bic() == "044025575"

# Generated at 2022-06-23 20:54:27.303409
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    rsp = RussiaSpecProvider()
    assert len(rsp.kpp()) == 9



# Generated at 2022-06-23 20:54:30.554717
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Unit test for method series_and_number of class RussiaSpecProvider."""
    from mimesis.providers.person.russia import RussiaSpecProvider
    spec = RussiaSpecProvider()
    print(spec.series_and_number())


# Generated at 2022-06-23 20:54:33.328294
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    rv = RussiaSpecProvider()
    assert rv.patronymic(Gender.MALE) in rv._data['patronymic'][Gender.MALE]
    assert rv.patronymic(Gender.FEMALE) in rv._data['patronymic'][Gender.FEMALE]
    assert rv.patronymic(Gender.UNKNOWN) in rv._data['patronymic'][Gender.UNKNOWN]


# Generated at 2022-06-23 20:54:33.962593
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    pass

# Generated at 2022-06-23 20:54:35.626312
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    provider = RussiaSpecProvider()
    assert len(str(provider.passport_number())) == 6

# Generated at 2022-06-23 20:54:37.995527
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    obj = RussiaSpecProvider.series_and_number('8104', '270790')
    assert obj == '8104270790'


# Generated at 2022-06-23 20:54:43.137436
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    """Test function for patronymic of the class RussiaSpecProvider."""
    def check_method_ru(gender):
        provider = RussiaSpecProvider()
        data = provider.patronymic(gender=gender)
        assert isinstance(data, str)

    print('\t\texecution of function "patronymic"')
    check_method_ru(Gender.FEMALE)
    check_method_ru(Gender.MALE)
    check_method_ru(Gender.UNDEFINED)



# Generated at 2022-06-23 20:54:44.543513
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    ru = RussiaSpecProvider()
    ru.passport_series()
    assert ru.passport_series() in ru._data['passport_series']

# Generated at 2022-06-23 20:54:46.562500
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    r = RussiaSpecProvider()
    assert r.inn() == '7727486011'


# Generated at 2022-06-23 20:54:53.444281
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    ru_sp = RussiaSpecProvider()
    assert ru_sp.patronymic() in ru_sp._data['patronymic'][Gender.MALE]
    assert ru_sp.patronymic(gender=Gender.MALE) in ru_sp._data['patronymic'][Gender.MALE]
    assert ru_sp.patronymic(gender=Gender.FEMALE) in ru_sp._data['patronymic'][Gender.FEMALE]

# Generated at 2022-06-23 20:54:57.621584
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    obj = RussiaSpecProvider()

    assert ( len( set(obj.kpp() for _ in range(4)) ) == 4 )
    assert ( len( set(obj.kpp() for _ in range(400)) ) == obj.random.randint(1,400) )

# Generated at 2022-06-23 20:54:58.693157
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    return RussiaSpecProvider().bic()


# Generated at 2022-06-23 20:55:04.040999
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    def get_dict_kpp():
        kpp_dict = {}
        provider = RussiaSpecProvider()
        for i in range(100):
            kpp = provider.kpp()
            if kpp in kpp_dict:
                kpp_dict[kpp] += 1
            else:
                kpp_dict[kpp] = 1
        return kpp_dict
    print(get_dict_kpp())


# Generated at 2022-06-23 20:55:09.209567
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    rsp = RussiaSpecProvider()

    # Check the default method
    assert rsp.patronymic().__class__ == str

    # With type argument
    assert rsp.patronymic(gender=Gender.MALE).__class__ == str
    assert rsp.patronymic(gender=Gender.FEMALE).__class__ == str
    assert rsp.patronymic(gender=Gender.NEUTRAL).__class__ == str

    # With invalid type argument
    assert rsp.patronymic(gender='wrong_type')



# Generated at 2022-06-23 20:55:11.705082
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    RussiaSpecProvider_obj = RussiaSpecProvider()
    RussiaSpecProvider_obj.patronymic('MALE')
    RussiaSpecProvider_obj.patronymic('FEMALE')
    RussiaSpecProvider_obj.patronymic()


# Generated at 2022-06-23 20:55:18.161906
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    mimesis = RussiaSpecProvider()
    # Генерация патронимика для мужчины
    patronymic_male = mimesis.patronymic(Gender.MALE)
    # Генерация патронимика для женщины
    patronymic_female = mimesis.patronymic(Gender.FEMALE)

    assert patronymic_male in mimesis._data['patronymic'][Gender.MALE]
    assert patronymic_female in mimesis._data['patronymic'][Gender.FEMALE]



# Generated at 2022-06-23 20:55:20.628987
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    """ Unit test for method generate_sentence of class RussiaSpecProvider. """
    x = RussiaSpecProvider().generate_sentence()
    assert (isinstance(x, str))


# Generated at 2022-06-23 20:55:24.054978
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rus = RussiaSpecProvider()
    actual = rus.snils() # SNILS consists of 11 digits
    assert len(actual) == 11
    assert actual.isdigit() == True
    

# Generated at 2022-06-23 20:55:29.813450
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    series_and_number = [
        773407810
        , 745887935
        , 709566267
        , 775340663
        , 739283354
        , 706455817
    ]
    for i in range(0, len(series_and_number)):
        assert RussiaSpecProvider().series_and_number()[7:]


# Generated at 2022-06-23 20:55:37.965808
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Generate an example INN and compare it with the official"""
    
    # Generate random test INN
    test_inn = RussiaSpecProvider().inn()

    # Get last digit pair of official INN
    last_code_pair = "INN_SUFFIXES.txt"
    with open(last_code_pair, "r") as f:
        content = f.read().split()
        for i in range(0, len(content)):
            if content[i] == test_inn[0:12]:
                # compare last 2 nums of official INN with test one
                assert content[i+1] == test_inn[12:14]
                print(test_inn, ": True")
                break

# Generated at 2022-06-23 20:55:48.881552
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    provider = RussiaSpecProvider()
    assert provider.patronymic(Gender.MALE) in [
        'Алексеевич', 'Владимирович', 'Иванович',
        'Александрович', 'Максимович', 'Юрьевич',
    ]

# Generated at 2022-06-23 20:55:57.568695
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    data = RussiaSpecProvider()
    # assert data.snils() is not None
    # assert data.inn() is not None
    # assert data.ogrn() is not None
    # assert data.bic() is not None
    # assert data.kpp() is not None
    # assert data.generate_sentence() is not None
    # assert data.series_and_number() is not None

if __name__ == '__main__':
    test_RussiaSpecProvider()
    print('Test successful')
    # print(data.snils())
    # print(data.inn())
    # print(data.ogrn())
    # print(data.bic())
    # print(data.kpp())
    # print(data.generate_sentence())
    # print(data.series_and_number())

# Generated at 2022-06-23 20:55:59.756583
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    ru_provider = RussiaSpecProvider()
    
    ru_provider.passport_series()


# Generated at 2022-06-23 20:56:03.193738
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Unit test for method passport_series."""
    ru = RussiaSpecProvider(seed=42)
    assert ru.passport_series() == '82 19'

# Generated at 2022-06-23 20:56:07.148242
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    snils1 = RussiaSpecProvider().snils()
    assert snils1 is not None
    snils2 = RussiaSpecProvider().snils()
    assert snils1!=snils2

if __name__ == '__main__':
    test_RussiaSpecProvider_snils()

# Generated at 2022-06-23 20:56:09.198518
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    ru = RussiaSpecProvider()
    snils = ru.snils()
    assert len(snils) == 11


# Generated at 2022-06-23 20:56:13.594180
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Unit test for method series_and_number of class RussiaSpecProvider"""
    provider = RussiaSpecProvider()
    serial = provider.series_and_number()
    assert isinstance(serial, str)
    assert len(serial) == 10


# Generated at 2022-06-23 20:56:22.544045
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """Unit test for method kpp of class RussiaSpecProvider."""
    rr = RussiaSpecProvider()
    assert len(rr.kpp()) == 9

# Generated at 2022-06-23 20:56:29.729660
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    #from mimesis.enums import Gender
    provider = RussiaSpecProvider()

    passport_series = provider.passport_series()
    passport_number = provider.passport_number()
    series_and_number = provider.series_and_number()
    assert len(series_and_number) == 14
    assert passport_series in series_and_number
    assert str(passport_number) in series_and_number

# Generated at 2022-06-23 20:56:33.103855
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    r = RussiaSpecProvider()
    s = r.bic()
    assert len(s) == 9



# Generated at 2022-06-23 20:56:35.050724
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    provider = RussiaSpecProvider()
    assert len(provider.passport_series()) == 5


# Generated at 2022-06-23 20:56:37.287465
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    rsp = RussiaSpecProvider()
    print(rsp.generate_sentence())
    print('\n')


# Generated at 2022-06-23 20:56:40.876257
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    rp = RussiaSpecProvider()
    a = rp.inn()
    assert a
    assert len(a) == 12
    assert a.isdigit()
    assert int(a[-2]) == rp.inn()[-2]
    assert int(a[-1]) == rp.inn()[-1]


# Generated at 2022-06-23 20:56:45.532578
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    assert RussiaSpecProvider().inn() == '7707083893'
    assert RussiaSpecProvider().inn() == '6876377076'
    assert RussiaSpecProvider().inn() == '2250377308'
    


# Generated at 2022-06-23 20:56:47.554413
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    rsp = RussiaSpecProvider()
    for _ in range(10):
        san = rsp.series_and_number()
        assert len(san) == 11


# Generated at 2022-06-23 20:56:52.113577
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Unit test for method ``series_and_number`` of class ``RussiaSpecProvider``."""
    ru = RussiaSpecProvider()
    series_and_number = ru.series_and_number()
    assert len(series_and_number) == 10
    assert type(series_and_number) == str


# Generated at 2022-06-23 20:57:01.641698
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    from mimesis.providers.base import BaseProvider

    seed = 'test_RussiaSpecProvider_generate_sentence'
    russia_provider = RussiaSpecProvider(seed)

    def test_generate_sentence():
        sentence = russia_provider.generate_sentence()
        assert isinstance(sentence, str)

    test_generate_sentence()

    provider = BaseProvider(seed)
    provider.add_provider(russia_provider)

    def test_generate_sentence_with_provider():
        sentence = provider.rus.generate_sentence()
        assert isinstance(sentence, str)

    test_generate_sentence_with_provider()


# Generated at 2022-06-23 20:57:02.959484
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    for _ in range(1):
        print("".join(str(item) for item in RussiaSpecProvider().inn()))

# Generated at 2022-06-23 20:57:05.880490
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    provider = RussiaSpecProvider()
    number = provider.passport_number()
    assert isinstance(number, int)
    assert number>=100000 and number<=999999


# Generated at 2022-06-23 20:57:13.561090
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """Unit test for method kpp of class RussiaSpecProvider.

    >>> from mimesis.providers.russia import RussiaSpecProvider
    >>> prov = RussiaSpecProvider()
    >>> type(prov.kpp())
    <class 'str'>
    >>> len(prov.kpp())
    9
    >>> len(set([prov.kpp() for _ in range(0, 1000)]))
    1000

    """


# Generated at 2022-06-23 20:57:15.632942
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    obj = RussiaSpecProvider()
    assert len(obj.bic()) == 9
    assert type(obj.bic()) == str



# Generated at 2022-06-23 20:57:21.367231
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    p = RussiaSpecProvider()
    ogrn = p.ogrn()
    assert len(ogrn) == 13, \
        f'The length of the generated OGRN must be equals to 13. Current lenght is {len(ogrn)}'
# test_RussiaSpecProvider_ogrn()


# Generated at 2022-06-23 20:57:24.598481
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    # System under test:
    rsp = RussiaSpecProvider()
    assert isinstance(rsp.patronymic(), str)


# Generated at 2022-06-23 20:57:28.783637
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    provider = RussiaSpecProvider()
    for _ in range(0, 10):
        provider.patronymic()
    for _ in range(0, 10):
        provider.patronymic(Gender.MALE)
    for _ in range(0, 10):
        provider.patronymic(Gender.FEMALE)



# Generated at 2022-06-23 20:57:30.629655
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    r = RussiaSpecProvider()
    for i in range(10):
        r.series_and_number()


# Generated at 2022-06-23 20:57:42.110906
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    ru_provider = RussiaSpecProvider()
    ru_provider.seed(823)
    ru_provider.passport_series(20)
    ru_provider.reset_seed()
    ru_provider.passport_series(20)
    ru_provider.reset_seed()
    ru_provider.passport_series(20)
    ru_provider.reset_seed()
    ru_provider.passport_series(20)
    ru_provider.reset_seed()
    ru_provider.passport_series(20)
    ru_provider.reset_seed()
    ru_provider.passport_series(20)
    ru_provider.reset_seed()
    ru_provider.passport_series(20)
    ru_provider.reset_seed()
   