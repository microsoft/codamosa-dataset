

# Generated at 2022-06-23 20:47:42.387816
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    test = RussiaSpecProvider()
    print(test.passport_number())



# Generated at 2022-06-23 20:47:44.225761
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    data = RussiaSpecProvider().patronymic()
    assert data


# Generated at 2022-06-23 20:47:49.980574
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test for method snils of class RussiaSpecProvider"""

    obj = RussiaSpecProvider(seed=12345)

    assert obj.snils() == "41917492600"
    assert obj.snils() == "01579093700"
    assert obj.snils() == "71627037500"
    assert obj.snils() == "50184259749"
    assert obj.snils() == "58086667877"



# Generated at 2022-06-23 20:47:54.479147
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    result = provider.snils()
    assert len(result) == 11
    for digit in result[:-2]:
        assert digit in '0123456789'
    assert result[-2] in '0123456789'
    assert result[-1] in '0123456789'


# Generated at 2022-06-23 20:47:56.594747
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    provider = RussiaSpecProvider()
    print(provider.kpp())

test_RussiaSpecProvider_kpp()


# Generated at 2022-06-23 20:47:58.904384
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    r = RussiaSpecProvider()
    assert str(r.series_and_number()) == r.series_and_number()

# Generated at 2022-06-23 20:48:06.840053
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Unit test for method passport_series of class RussiaSpecProvider."""
    from mimesis.providers.generic import GenericSpecProvider
    from mimesis.enums import Gender
    from mimesis.data import RUSSIA_PROVIDER
    from mimesis.providers.base import BaseDataProvider

    class TestProvider(BaseDataProvider):

        def __init__(self, seed=None):
            super().__init__(seed=seed)
            self.russian = RussiaSpecProvider(seed=seed)

        def random_year(self):
            return self.random.randint(2001, 2019)

    test_provider = TestProvider()

    assert test_provider.random_year() in range(2001, 2020)


# Generated at 2022-06-23 20:48:09.569757
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    testProvider = RussiaSpecProvider()
    bic = testProvider.bic()
    # length 10
    assert len(bic) == 10


# Generated at 2022-06-23 20:48:11.406872
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    obj = RussiaSpecProvider()
    assert obj.kpp() == '560058652'


# Generated at 2022-06-23 20:48:12.804451
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    assert RussiaSpecProvider().inn() == '7805772611'


# Generated at 2022-06-23 20:48:18.405457
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Unit test for method passport_series of class RussiaSpecProvider"""
    # Test a result from random choice
    prov = RussiaSpecProvider(seed=14)
    result = prov.passport_series(year=16)
    assert result == '71 16'
    result = prov.passport_series()
    assert result == '71 16'
    assert result != '58 01'


# Generated at 2022-06-23 20:48:19.709326
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    provider = RussiaSpecProvider()
    print("Generate sentence = ", provider.generate_sentence())


# Generated at 2022-06-23 20:48:20.803612
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider()
    assert provider.bic() == '044025575'


# Generated at 2022-06-23 20:48:26.636196
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    ru = RussiaSpecProvider(seed=20180524)
    assert ru.patronymic(gender='male') == 'Петрович'
    assert ru.patronymic(gender='female') == 'Николаевна'
    assert ru.patronymic(gender='other') == 'Петровна'


# Generated at 2022-06-23 20:48:29.516748
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    provider = RussiaSpecProvider()
    provider.seed(0)
    result = provider.passport_number()
    assert result == 574031
    provider.reset_seed()

# Generated at 2022-06-23 20:48:32.663600
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    import pytest
    russia = RussiaSpecProvider()
    result = russia.inn()
    assert len(result) == 10
    assert isinstance(result, str)


# Generated at 2022-06-23 20:48:34.790564
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    bic = RussiaSpecProvider().bic()
    assert bic == "044025575"


# Generated at 2022-06-23 20:48:38.383940
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    # Test without parameter
    x = RussiaSpecProvider().passport_series()
    print(x)
    # Test with parameter
    x = RussiaSpecProvider().passport_series(year=2013)
    print(x)


# Generated at 2022-06-23 20:48:40.709134
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    rus = RussiaSpecProvider(seed=1234)
    assert rus.ogrn() == '465522671086'

# Generated at 2022-06-23 20:48:43.280836
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    provider = RussiaSpecProvider()
    assert provider.patronymic(Gender.FEMALE) != provider.patronymic(Gender.MALE)


# Generated at 2022-06-23 20:48:46.597035
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    assert RussiaSpecProvider().seed == 1
    assert RussiaSpecProvider().seed == 2
    assert RussiaSpecProvider().seed == 3
    assert RussiaSpecProvider().seed == 4
    assert RussiaSpecProvider().seed == 5
    assert RussiaSpecProvider().seed == 6
    assert RussiaSpecProvider().seed == 7
    assert RussiaSpecProvider().seed == 8
    

# Generated at 2022-06-23 20:48:51.292459
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    r = RussiaSpecProvider()
    y = r.inn()
    y = str(y)
    for s in range(1,10):
        if int(y[s]) < int(y[s-1]):
            assert True
        else:
            assert False


# Generated at 2022-06-23 20:48:53.398005
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    assert len(RussiaSpecProvider().passport_series()) == 5
    assert len(RussiaSpecProvider().passport_series()) == 5



# Generated at 2022-06-23 20:48:56.456882
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    r = RussiaSpecProvider()
    expected = 4715113303725
    result = int(r.ogrn())
    assert result == expected


# Generated at 2022-06-23 20:49:03.625897
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Unit test for method inn of class RussiaSpecProvider."""
    bp = RussiaSpecProvider()

    # === Test inn === #
    # --- Test inn without params --- #
    _inn = bp.inn()
    assert len(_inn) == 12
    # --- Test inn with params --- #
    _inn = bp.inn()
    assert len(_inn) == 12
    # === Test inn === #

    # === Test ogrn === #
    # --- Test ogrn without params --- #
    _ogrn = bp.ogrn()
    assert len(_ogrn) == 13
    # --- Test ogrn with params --- #
    _ogrn = bp.ogrn()
    assert len(_ogrn) == 13
    # === Test ogrn === #

    # === Test snils === #
    # --- Test

# Generated at 2022-06-23 20:49:14.244622
# Unit test for method ogrn of class RussiaSpecProvider

# Generated at 2022-06-23 20:49:15.310779
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    print(r.snils())

# Generated at 2022-06-23 20:49:19.291793
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    prov = RussiaSpecProvider()
    for _ in range(10):
        print(prov.passport_series())
    for _ in range(10):
        print(prov.passport_series(18))


# Generated at 2022-06-23 20:49:22.258843
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    print(RussiaSpecProvider().series_and_number())
    assert RussiaSpecProvider().series_and_number() == \
        RussiaSpecProvider(seed=666).series_and_number()


# Generated at 2022-06-23 20:49:24.862896
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Unit-test for method ogrn of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    assert len(provider.ogrn()) == 13


# Generated at 2022-06-23 20:49:28.337744
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    # Arrange
    russia_spec_provider = RussiaSpecProvider()
    # Act
    sentence = russia_spec_provider.generate_sentence()
    # Assert
    assert type(sentence) is str


# Generated at 2022-06-23 20:49:29.841325
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    provider = RussiaSpecProvider()
    result = provider.series_and_number()
    assert len(result) == 11

# Generated at 2022-06-23 20:49:34.804363
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    """Test patronymic method of class RussiaSpecProvider"""
    rus_spec_provider = RussiaSpecProvider()

    assert rus_spec_provider.patronymic(Gender.MALE) in rus_spec_provider._data['patronymic'][Gender.MALE], "Invalid patronymic"
    assert rus_spec_provider.patronymic(Gender.FEMALE) in rus_spec_provider._data['patronymic'][Gender.FEMALE], "Invalid patronymic"


# Generated at 2022-06-23 20:49:35.960682
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    obj = RussiaSpecProvider()
    assert len(obj.inn()) == 10


# Generated at 2022-06-23 20:49:47.584132
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """
    Test function test_RussiaSpecProvider_snils.
    """
    def validate_snils(snils: str) -> bool:
        """
        Function validate SNILS number.
        """
        control_codes = []
        numbers = [int(number) for number in str(snils[:-2])]
        for i in range(9, 0, -1):
            control_codes.append(numbers[9 - i] * i)
        control_code = sum(control_codes)

        if control_code in (100, 101):
            return snils[-2:] == '00'
        elif control_code < 100:
            return str(control_code) == snils[-2:]
        elif control_code > 101:
            control_code = control_code % 101

# Generated at 2022-06-23 20:49:49.553017
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    ru = RussiaSpecProvider()
    ru.passport_series()


# Generated at 2022-06-23 20:49:54.227082
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    assert(RussiaSpecProvider().bic(55) == '044025575')
    assert(RussiaSpecProvider().bic() == '044025575')
    assert(RussiaSpecProvider().bic(66) == '049025575')

# Generated at 2022-06-23 20:49:57.345477
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test for method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    snils = rsp.snils()
    print(snils)



# Generated at 2022-06-23 20:49:58.832617
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    provider = RussiaSpecProvider()
    assert len(provider.ogrn()) == 13


# Generated at 2022-06-23 20:50:01.213766
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    random.seed(10)
    kpp = RussiaSpecProvider(random).kpp()
    assert kpp == '7700278050'

test_RussiaSpecProvider_kpp()

# Generated at 2022-06-23 20:50:11.798461
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    test = RussiaSpecProvider
    # result1 = test.bic()
    # assert result1[0] == "0" or "1" or "2" or "4" or "8" or "9"
    # assert result1[1] == "0" or "1" or "2" or "4" or "8" or "9"
    # assert result1[2] == "0" or "1" or "2" or "4" or "8" or "9"
    # assert result1[3] == "0" or "1" or "2" or "4" or "8" or "9"
    # assert result1[4] == "0" or "1" or "2" or "4" or "8" or "9"
    # assert result1[5] == "0" or "1"

# Generated at 2022-06-23 20:50:16.970481
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    rsp = RussiaSpecProvider()
    for _ in range(100):
        year = 1998
        ps = rsp.passport_series(year)
        assert all(ord(char) < 128 for char in ps)
        assert ps == '{:02d} {}'.format(int(ps[0:2]), int(ps[3:5]))
        assert ps[3:5] == str(year)[2:4]


# Generated at 2022-06-23 20:50:19.695598
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    inn = RussiaSpecProvider().inn()
    assert len(inn) == 12
    assert int(inn[:2]) != 0
    assert int(inn[2:9]) != 0
    assert int(inn[9:]) != 0


# Generated at 2022-06-23 20:50:20.534483
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    assert RussiaSpecProvider().kpp()


# Generated at 2022-06-23 20:50:29.428657
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    import random
    import string

    random.seed(1)
    string.ascii_letters

    # test function
    def test_function(random_seed, expected_result):
        random.seed(random_seed)
        instance = RussiaSpecProvider()
        # call tested function
        result = instance.passport_series()
        # check result
        assert result == expected_result

    # expected results

# Generated at 2022-06-23 20:50:32.747545
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test for method snils of class RussiaSpecProvider."""
    from mimesis.providers import RussiaSpecProvider
    test_object = RussiaSpecProvider()
    assert test_object.snils() == "41917492600"

# Generated at 2022-06-23 20:50:40.187847
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    from mimesis.providers.helpers.number import Number
    provider = RussiaSpecProvider(seed=None)
    number = Number(seed=None)
    result = provider.generate_sentence()
    if len(result) == 0:
        raise AssertionError('len(result) == 0')
    if number.is_int(result) == True:
        raise AssertionError('number.is_int(result) == True')


# Generated at 2022-06-23 20:50:42.792957
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    raw_inn = RussiaSpecProvider().inn()
    print(raw_inn)
    assert len(raw_inn) == 12

test_RussiaSpecProvider_inn()

# Generated at 2022-06-23 20:50:44.993371
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    r = RussiaSpecProvider()
    # This is an example of valid passport series of 2016 year
    assert r.passport_series(16) == '02 16'



# Generated at 2022-06-23 20:50:45.556178
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    pass

# Generated at 2022-06-23 20:50:49.165111
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    import random
    import pytest

    random.seed(0)

    russian = RussiaSpecProvider()

    passport_number = russian.passport_number()

    assert passport_number == 985823

    passport_number = russian.passport_number()

    assert passport_number == 985823

    return True


# Generated at 2022-06-23 20:50:58.460236
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    from mimesis.enums import Gender
    from mimesis.providers.person.languages import RussianSpecProvider
    ru = RussianSpecProvider(seed=str(1))

    # Checking in constructor
    ru1 = ru.person.last_name()
    ru2 = ru.person.last_name(gender=Gender.FEMALE)
    ru3 = ru.person.name(gender=Gender.FEMALE)

    ru4 = ru.person.patronymic(gender=Gender.MALE)
    ru5 = ru.person.patronymic(gender=Gender.FEMALE)
    ru6 = ru.person.full_name(gender=Gender.MALE)
    ru7 = ru.person.full_name(gender=Gender.FEMALE)
    ru8 = ru.address.address()
    ru

# Generated at 2022-06-23 20:51:04.825914
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    russia_provider = RussiaSpecProvider()
    ogrn = russia_provider.ogrn()
    assert len(ogrn) == 13
    assert ogrn[:12].isdigit()
    assert ogrn[-1].isdigit() and 0 <= int(ogrn[-1]) < 10
    assert int(ogrn[-1]) == int(ogrn[:-1]) % 11 % 10


# Generated at 2022-06-23 20:51:09.495175
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    ru = RussiaSpecProvider()
    ru.inn()
    ru.ogrn()
    ru.bic()
    ru.kpp()
    ru.passport_series()
    ru.passport_number()
    ru.series_and_number()
    ru.snils()
    ru.patronymic()
    ru.generate_sentence()

# Generated at 2022-06-23 20:51:11.827211
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    """Unit test for method bic of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    assert len(rsp.bic()) == 9
    assert rsp.bic()[:2] == '04'


# Generated at 2022-06-23 20:51:13.886219
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    provider = RussiaSpecProvider()
    assert provider.inn() == '5027014298'


# Generated at 2022-06-23 20:51:16.288300
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    provider = RussiaSpecProvider()
    result = provider.passport_number()
    assert (len(str(result)) == 6)

# Generated at 2022-06-23 20:51:18.700721
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Checks that the class."""
    rsp = RussiaSpecProvider()
    result = rsp.inn()
    assert len(result) == 12
    assert int(result[0]) == 1


# Generated at 2022-06-23 20:51:20.553185
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    assert(RussiaSpecProvider().ogrn() == '4715113303725')



# Generated at 2022-06-23 20:51:28.562959
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    provider = RussiaSpecProvider()
    assert isinstance(provider.generate_sentence(), str)

# Generated at 2022-06-23 20:51:37.633835
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.geo.base import BaseGeoProvider
    from mimesis.providers.identification import Identification
    from mimesis.providers.person import Person
    from mimesis.providers.person.address import Address
    from mimesis.providers.person.contact import Communication

    r = RussiaSpecProvider(seed=42)

    assert isinstance(r, BaseSpecProvider)
    assert isinstance(r, BaseProvider)
    assert isinstance(r, BaseGeoProvider)
    assert isinstance(r, Identification)
    assert isinstance(r, Person)
    assert isinstance(r, Address)

# Generated at 2022-06-23 20:51:45.111672
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    patronymic_list = []
    for i in range(0, 1000):
        patronymic = RussiaSpecProvider.Meta.provider().patronymic()
        if patronymic not in patronymic_list:
            patronymic_list.append(patronymic)
        if len(patronymic_list) == 48:
            break
    assert len(patronymic_list) == 48


# Generated at 2022-06-23 20:51:47.577491
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Unit test for method passport_series of class RussiaSpecProvider."""
    rus = RussiaSpecProvider()
    print(rus.passport_series(year = 19))

# Generated at 2022-06-23 20:51:53.841778
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    a = RussiaSpecProvider()
    bic = a.bic()
    assert bic[0] == "0"
    assert bic[1] == "4"
    assert bic[2] == "4"
    assert bic[3] == "0"
    assert bic[4] == "2"
    assert bic[5] == "5"
    assert bic[6] == "5"
    assert bic[7] == "7"
    assert bic[8] == "5"


# Generated at 2022-06-23 20:51:55.451324
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    rus = RussiaSpecProvider()
    assert rus.passport_series() == '36 10'


# Generated at 2022-06-23 20:51:57.549584
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    random_number = RussiaSpecProvider().passport_number()
    assert 100000 <= random_number <= 999999


# Generated at 2022-06-23 20:51:58.926780
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    rus = RussiaSpecProvider()
    assert len(rus.inn()) == 10


# Generated at 2022-06-23 20:52:01.809688
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Test for RussiaSpecProvider.inn."""
    assert RussiaSpecProvider().inn() == '7728558655'
    assert RussiaSpecProvider(seed=1).inn() == '9684114370'
    assert RussiaSpecProvider(seed=2).inn() == '6005270019'

test_RussiaSpecProvider_inn()

# Generated at 2022-06-23 20:52:04.024480
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    provider = RussiaSpecProvider()
    assert provider.generate_sentence() is not None


# Generated at 2022-06-23 20:52:05.961578
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    genBIC = RussiaSpecProvider()
    genBIC.bic()


# Generated at 2022-06-23 20:52:07.600384
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    rsp = RussiaSpecProvider(seed=0)
    rsp.seed(0)
    assert rsp.ogrn() == '4715113303725'

# Generated at 2022-06-23 20:52:11.728615
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    print('\nRussiaSpecProvider')
    r = RussiaSpecProvider(seed=666)
    print('passport_series:', r.passport_series())
    print('passport_number:', r.passport_number())
    print('series_and_number:', r.series_and_number())
    print('snils:', r.snils())
    print('inn:', r.inn())
    print('ogrn:', r.ogrn())
    print('bic:', r.bic())
    print('kpp:', r.kpp())

if __name__ == '__main__':
    test_RussiaSpecProvider()

# Generated at 2022-06-23 20:52:17.714538
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    assert RussiaSpecProvider(seed=123456789).patronymic(gender=Gender.MALE) == 'евич'
    assert RussiaSpecProvider(seed=123456789).patronymic(gender=Gender.MALE) == 'евич'
    assert RussiaSpecProvider(seed=123456789).patronymic(gender=Gender.FEMALE) == 'евна'
    assert RussiaSpecProvider(seed=123456789).patronymic(gender=Gender.FEMALE) == 'евна'


# Generated at 2022-06-23 20:52:19.892402
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    """Test RussiaSpecProvider"""
    instance = RussiaSpecProvider()
    assert instance is not None


# Generated at 2022-06-23 20:52:23.593966
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    from mimesis.providers.person.russia import RussiaSpecProvider
    from random import seed
    provider = RussiaSpecProvider()
    for x in range(0, 100):
        seed(x)
        a = RussiaSpecProvider._random.randint(100000, 999999)
        b = provider.passport_number()
        if a != b:
            print('{:12} {} {}'.format(a, b, provider.passport_series()))

# Generated at 2022-06-23 20:52:25.198692
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider().snils() == '41917492600'



# Generated at 2022-06-23 20:52:38.352187
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider()
    bic = provider.bic()
    assert len(bic) == 9
    assert bic[:2] == '04'

# Generated at 2022-06-23 20:52:42.537551
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """Testing for method passport_number of class RussiaSpecProvider."""
    spec = RussiaSpecProvider()
    spec.set_seed(1) # set seed for check result
    ans = spec.passport_number()
    assert ans == 873690


# Generated at 2022-06-23 20:52:43.993168
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    assert RussiaSpecProvider().patronymic() != None


# Generated at 2022-06-23 20:52:51.690301
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    random.seed(1)
    russian_provider = RussiaSpecProvider()
    assert russian_provider.bic() == "042047139"
    assert russian_provider.bic() == "046063184"
    assert russian_provider.bic() == "044072487"
    assert russian_provider.bic() == "044034999"
    assert russian_provider.bic() == "041083141"
    assert russian_provider.bic() == "044077299"
    assert russian_provider.bic() == "043055448"
    assert russian_provider.bic() == "045079350"
    assert russian_provider.bic() == "043012391"

# Generated at 2022-06-23 20:52:57.450344
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    provider = RussiaSpecProvider(seed=4715113303725)
    assert provider.kpp() == '560058652'
    provider = RussiaSpecProvider(seed=25)
    assert provider.kpp() == '720051878'
    provider = RussiaSpecProvider(seed=11)
    assert provider.kpp() == '730090355'
    provider = RussiaSpecProvider(seed=39)
    assert provider.kpp() == '770023304'
    provider = RussiaSpecProvider(seed=37)
    assert provider.kpp() == '740050638'
    provider = RussiaSpecProvider(seed=14)
    assert provider.kpp() == '770083455'
    provider = RussiaSpecProvider(seed=8)
    assert provider.kpp() == '780076160'
    provider = RussiaSpec

# Generated at 2022-06-23 20:53:05.416589
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    from mimesis.providers.person import Person
    from mimesis.enums import Gender

    p = Person('ru')
    for i in range(0, 100):
        if p.full_name(gender=Gender.FEMALE) in RussiaSpecProvider().generate_sentence():
            break
    if i != 100:
        print('test_RussiaSpecProvider_generate_sentence() passed')
    else:
        print('test_RussiaSpecProvider_generate_sentence() failed')


# Generated at 2022-06-23 20:53:07.601057
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Test method ogrn of class RussiaSpecProvider."""
    assert RussiaSpecProvider().ogrn() == '976717374022'

# Generated at 2022-06-23 20:53:09.259719
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    r = RussiaSpecProvider()
    assert r.generate_sentence() is not None


# Generated at 2022-06-23 20:53:13.194555
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """Test case for method passport_number of class RussiaSpecProvider."""
    from mimesis.providers.russia_provider import RussiaSpecProvider

    provider = RussiaSpecProvider()
    passport_number = provider.passport_number()
    assert isinstance(passport_number, int)
    assert len(str(passport_number)) == 6

# Generated at 2022-06-23 20:53:14.499431
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
  print(RussiaSpecProvider().provider.inn())

# Generated at 2022-06-23 20:53:16.913101
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    provider = RussiaSpecProvider()
    assert isinstance(provider, RussiaSpecProvider)
    assert hasattr(provider, 'generate_sentence')


# Generated at 2022-06-23 20:53:24.525870
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    """
    Unit test for method generate_sentence of class RussiaSpecProvider.

    :return: nothing.
    """
    rsp = RussiaSpecProvider()
    generated_sentence = rsp.generate_sentence()
    assert len(generated_sentence) == 18, "Длина предложения не соответствует условию."



# Generated at 2022-06-23 20:53:31.895315
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()
    test_cases = [('41917492600', '41917492600'),
                  ('75451872496', '75451872496'),
                  ('53284875138', '53284875138'),
                  ('54490669293', '54490669293'),
                  ('37111204640', '37111204640'),]
    for test_case in test_cases:
        test_case = test_case[1]
        assert test_case == rsp.snils()


# Generated at 2022-06-23 20:53:34.262337
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    kpp = RussiaSpecProvider().kpp()
    assert len(kpp) == 9
    assert type(kpp) == str



# Generated at 2022-06-23 20:53:37.024730
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    from mimesis.enums import Gender
    bic = RussiaSpecProvider().bic()
    assert len(bic) == 9
    assert  bic[:2] == '04'

# Generated at 2022-06-23 20:53:40.338062
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.random import Random
    from mimesis.providers.misc import RussiaSpecProvider
    rsp = RussiaSpecProvider()
    r = Random()
    r.set_seed(12345)
    for _ in range(10):
      assert len(rsp.snils()) == 11
      assert rsp.snils() == rsp.snils()
    r.set_seed(54321)
    assert rsp.snils() == "41917492600"


# Generated at 2022-06-23 20:53:43.849520
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    data = []
    prov = RussiaSpecProvider()
    for i in range(0, 1000):
        data.append(prov.inn())
    assert len(data)
    for i in data:
        if len(i) != 10:
            raise AssertionError('Incorrect number of characters: ', len(i))
    return True


# Generated at 2022-06-23 20:53:55.297397
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Unit test for method inn of class RussiaSpecProvider.

    This is a test for the correctness of randomly generated inn.

    """
    a = RussiaSpecProvider()
    for i in range(0, 10):
        inn = a.inn()
        digits_dict = {
            'n2': [7, 2, 4, 10, 3, 5, 9, 4, 6, 8],
            'n1': [3, 7, 2, 4, 10, 3, 5, 9, 4, 6, 8],
        }
        digits = digits_dict['n2']
        number = 0
        for i, x in enumerate(digits, start=0):
            number += int(inn[i]) * digits[i]
        if number % 11 % 10 != int(inn[9]):
            print(inn, False)

# Generated at 2022-06-23 20:53:59.165867
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    rus_spec = RussiaSpecProvider()
    print("Серия и номер паспорта: ", rus_spec.series_and_number())
    print("Серия: ", rus_spec.passport_series())
    print("Номер: ", rus_spec.passport_number())


# Generated at 2022-06-23 20:54:02.195385
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    assert r.snils() == '41917492600'

# Generated at 2022-06-23 20:54:05.821877
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    provider = RussiaSpecProvider()
    new_series_and_number = provider.series_and_number()

    assert new_series_and_number == '90198434300'


# Generated at 2022-06-23 20:54:13.862458
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    """Test the correctness of method bic."""
    bic_list = []
    # Check that <bic> is always a string
    assert isinstance(RussiaSpecProvider().bic(), str)
    # Check that the length of digit bic equal to 9
    assert len(str(RussiaSpecProvider().bic())) == 9
    for i in range(9999):
        bic_list.append(RussiaSpecProvider().bic())
    # Check that the uniqueness of bic for the generator
    assert len(bic_list) == len(set(bic_list))


# Generated at 2022-06-23 20:54:14.805672
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    russia = RussiaSpecProvider()
    assert len(russia.bic()) == 9


# Generated at 2022-06-23 20:54:18.841222
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """Test for method passport_number of class RussiaSpecProvider"""
    instance = RussiaSpecProvider()
    for _ in range(10):
        pass_number = str(instance.passport_number())
        assert len(pass_number) == 6
        assert pass_number.isdigit()


# Generated at 2022-06-23 20:54:22.859147
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """test method kpp of class RussiaSpecProvider"""
    from mimesis.builtins import RussiaSpecProvider
    from mimesis import Generic

    gen = Generic('ru')
    for i in range(3):
        assert len(gen.russia_provider.kpp()) == 9


# Generated at 2022-06-23 20:54:24.570183
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    a = RussiaSpecProvider()
    res = a.passport_series(0)
    assert isinstance(res, str)

# Generated at 2022-06-23 20:54:29.048379
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    provider = RussiaSpecProvider()

    for i in range(10):
        sentence = provider.generate_sentence()
        print(sentence)
    # assert isinstance(sentence, str)



# Generated at 2022-06-23 20:54:36.389616
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    ru = RussiaSpecProvider()
    assert ru.__name__ == 'RussiaSpecProvider'
    assert ru.__doc__ == 'Class that provides special data for Russia (ru).'
    assert ru.__init__.__doc__ == 'Initialize attributes.'
    assert ru.generate_sentence.__doc__ == 'Generate sentence from the parts.\n\n:return: Sentence.'
    assert ru.Meta.__doc__ == 'The name of the provider.'
    assert ru.Meta.name == 'russia_provider'
    assert ru.patronymic.__doc__ == 'Generate random patronymic name.\n\n:param gender: Gender of person.\n:return: Patronymic name.\n\n:Example:\n    Алексеевна.'

# Generated at 2022-06-23 20:54:38.972146
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    rsp = RussiaSpecProvider()
    assert rsp.passport_series() == rsp.passport_series()
    assert rsp.passport_series(year=19) == rsp.passport_series(year=19)
    assert rsp.passport_series(year=20) == rsp.passport_series(year=20)


# Generated at 2022-06-23 20:54:41.451599
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    ru = RussiaSpecProvider()
    assert ru.inn() == '5465010575'
    assert ru.inn() == '2843195197'

# Generated at 2022-06-23 20:54:45.227060
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    """Unit test for method patronymic of class RussiaSpecProvider"""
    obj = RussiaSpecProvider(seed=42)
    assert obj.patronymic() == 'Алексеевна'

# Generated at 2022-06-23 20:54:49.254546
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    rsp = RussiaSpecProvider()
    pseries = rsp.passport_series()
    assert len(pseries) == 5
    assert type(pseries) == str


# Generated at 2022-06-23 20:54:59.921936
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Unit test for method ogrn of class RussiaSpecProvider."""

    rsp = RussiaSpecProvider()
    generated_ogrn = rsp.ogrn()
    print(f'This is generated OGRN: {generated_ogrn}')
    
    # Проверка по формуле подсчета контрольного числа. Нагло взято из статьи про ИНН (параграф Валидация):
    # 1. Вычисляется контр

# Generated at 2022-06-23 20:55:02.829642
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    from mimesis.providers import RussiaSpecProvider
    print (RussiaSpecProvider().inn())
    print (str(RussiaSpecProvider().inn()).isdigit()) # Test is digit
    

# Generated at 2022-06-23 20:55:05.232270
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    r = RussiaSpecProvider()
    r.reset_seeds()
    numbers = []
    for _ in range(100):
        numbers.append(
            r.series_and_number()
        )
    assert len(set(numbers)) == 100

# Generated at 2022-06-23 20:55:09.805138
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    # Init instance of class RussiaSpecProvider
    provider = RussiaSpecProvider()
    # Call method ogrn and save result
    ogrn = provider.ogrn()
    # Check length of ogrn
    assert len(ogrn) == 13
    # Check that every digit of ogrn is number
    assert ogrn.isdigit()


# Generated at 2022-06-23 20:55:11.441803
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    for gender in Gender:
        assert len(RussiaSpecProvider(seed=0).patronymic(gender=gender)) > 0



# Generated at 2022-06-23 20:55:13.139493
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    provider = RussiaSpecProvider(seed=12345)
    inn = provider.inn()
    assert str(inn) == "7150343258"


# Generated at 2022-06-23 20:55:14.690459
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    """Test RussiaSpecProvider.bic.

    """
    provider = RussiaSpecProvider()
    bic = provider.bic()
    assert bic == '044025575'

# Generated at 2022-06-23 20:55:17.244359
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Test method inn."""
    inn = RussiaSpecProvider()
    assert len(inn.inn()) == 10


# Generated at 2022-06-23 20:55:18.420345
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    rus_spec = RussiaSpecProvider()
    func_rus_spec = rus_spec.passport_series()
    assert len(func_rus_spec) == 5


# Generated at 2022-06-23 20:55:21.770202
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    from mimesis.providers.base import BaseSpecProvider

    class RussiaSpecProvider(BaseSpecProvider):
        def generate_sentence(self):
            return "История этой страны многовековая."

    provider = RussiaSpecProvider()
    assert provider.generate_sentence() == "История этой страны многовековая."


# Generated at 2022-06-23 20:55:24.016295
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    ogrn = RussiaSpecProvider()
    assert ogrn.ogrn() == '4715113303725'

# Generated at 2022-06-23 20:55:26.253207
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    spec = RussiaSpecProvider()
#Unit test for generate_sentence function

# Generated at 2022-06-23 20:55:27.558453
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    r = RussiaSpecProvider()
    assert len(r.series_and_number()) == 11


# Generated at 2022-06-23 20:55:29.268427
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    """Test method generate_sentence."""
    r = RussiaSpecProvider()
    print(r.generate_sentence())


# Generated at 2022-06-23 20:55:31.285528
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    assert RussiaSpecProvider().passport_number() == 560430


# Generated at 2022-06-23 20:55:32.339119
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    pass


# Generated at 2022-06-23 20:55:34.460435
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    #expected = 431009193
    r = RussiaSpecProvider()
    assert len(r.inn()) == 10


# Generated at 2022-06-23 20:55:46.182615
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    import unittest
    
    class RussiaSpecProviderTestCase(unittest.TestCase):
        '''Class that test the patronymic method of RussiaSpecProvider class.'''

        def setUp(self):
            self.rsp = RussiaSpecProvider()
            self.person = Person('ru')
            self.address = Address('ru')
            self.business = Business('ru')

        def test_patronymic_1(self):
            '''Test that test patronymic method of RussiaSpecProvider class.'''
            
            for i in range(0, 10):
                sex = self.person.gender()

# Generated at 2022-06-23 20:55:55.737798
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    rsp = RussiaSpecProvider()
    kpp = rsp.kpp()
    assert len(kpp) == 9

# Generated at 2022-06-23 20:55:57.428217
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    provider = RussiaSpecProvider()
    result = provider.inn()
    print(result)


# Generated at 2022-06-23 20:55:58.931744
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    r = RussiaSpecProvider()
    assert r.generate_sentence()


# Generated at 2022-06-23 20:56:02.688231
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    """Unit test for method bic of class RussiaSpecProvider."""
    russ = RussiaSpecProvider()
    assert russ.bic() == '047114163'


# Generated at 2022-06-23 20:56:04.103783
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    inn = RussiaSpecProvider()
    print(inn.inn())


# Generated at 2022-06-23 20:56:06.451233
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    r = RussiaSpecProvider()
    sentence = r.generate_sentence()
    assert isinstance(sentence, str)


# Generated at 2022-06-23 20:56:10.618739
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    provider = RussiaSpecProvider()
    # 1
    target_kpp1 = '560058652'
    provider.seed(1)
    output_kpp1 = provider.kpp()
    assert(len(output_kpp1) == 9)
    assert(output_kpp1 == target_kpp1)


# Generated at 2022-06-23 20:56:12.063382
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    rsp = RussiaSpecProvider(seed=55)
    return rsp

# Generated at 2022-06-23 20:56:13.886178
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    """Unit test for RussiaSpecProvider."""
    rsp = RussiaSpecProvider()


# Generated at 2022-06-23 20:56:16.779400
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    ogrn_provider = RussiaSpecProvider()
    ogrn = ogrn_provider.ogrn()
    assert len(ogrn) == 13


# Generated at 2022-06-23 20:56:29.612380
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    r = RussiaSpecProvider()
    assert r.patronymic(Gender.MALE) in r._data['patronymic'][Gender.MALE]
    assert r.patronymic(Gender.FEMALE) in r._data['patronymic'][Gender.FEMALE]
    assert r.patronymic(Gender.ALL) in r._data['patronymic'][Gender.ALL]
    assert r.patronymic() in r._data['patronymic'][Gender.ALL]
    assert r.patronymic(Gender.MALE) not in r._data['patronymic'][Gender.FEMALE]
    assert r.patronymic(Gender.FEMALE) not in r._data['patronymic'][Gender.MALE]
    assert r.patronym

# Generated at 2022-06-23 20:56:33.036627
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    assert RussiaSpecProvider().ogrn() == '4715113303725'


# Generated at 2022-06-23 20:56:39.927153
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """RussiaSpecProvider class unit test."""
    test_provider = RussiaSpecProvider()
    ogrn_str = test_provider.ogrn()

    # Check length of string
    assert len(ogrn_str) == 13

    # Convert string to int
    ogrn_int = int(ogrn_str)

    # Check if the last number is equal to the check sum of OGRN
    check_sum = int(ogrn_int % 11 % 10)
    last_char = int(ogrn_str[-1])
    assert check_sum == last_char

# Generated at 2022-06-23 20:56:43.806093
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """
    Unit test for method ogrn of class RussiaSpecProvider.
    """
    spec_provider = RussiaSpecProvider()
    assert len(spec_provider.ogrn()) == 13


# Generated at 2022-06-23 20:56:46.133336
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    d = RussiaSpecProvider()
    assert 'RussiaSpecProvider' == d.Meta.name


# Generated at 2022-06-23 20:56:49.391587
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    r = RussiaSpecProvider()
    answer = r.kpp()
    assert len(answer) == 9
    assert not answer.find('7700')
    assert not answer.find('9901')

# Generated at 2022-06-23 20:56:58.436162
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    from mimesis.enums import Gender
    from . import RussiaSpecProvider

    russia = RussiaSpecProvider()

    assert type(russia.patronymic()) == str
    assert russia.patronymic(gender=Gender.FEMALE) in russia._data['patronymic'][Gender.FEMALE]
    assert type(russia.patronymic(gender=Gender.MALE)) == str
    assert russia.patronymic(gender=Gender.MASCULINE) in russia._data['patronymic'][Gender.MASCULINE]
    assert russia.patronymic() in russia._data['patronymic'][None]


# Generated at 2022-06-23 20:57:01.995537
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    from mimesis.providers import RussiaSpecProvider
    rsp = RussiaSpecProvider(seed=0)
    rsp.seed = 0
    p1 = rsp.series_and_number()
    p2 = '521261329074'
    assert p1 == p2




# Generated at 2022-06-23 20:57:12.394800
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Test for inn method of class RussiaSpecProvider.
    """
    provider = RussiaSpecProvider()
    inn = provider.inn()
    assert isinstance(inn, str)
    assert len(inn) == 10
    # TODO: Надо проверить, что это вообще INN.
    # А то на данный момент это случайная строка из 10 цифр.


# Generated at 2022-06-23 20:57:17.476875
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    """Test method patronymic() of class RussiaSpecProvider."""

    rsp = RussiaSpecProvider()
    print(rsp.patronymic(Gender.MALE))
    assert isinstance(rsp.patronymic(Gender.MALE), str)
    assert isinstance(rsp.patronymic(Gender.FEMALE), str)
    assert isinstance(rsp.patronymic(Gender.OTHER), str)

test_RussiaSpecProvider_patronymic()


# Generated at 2022-06-23 20:57:21.764603
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    r = RussiaSpecProvider()
    series_and_number = r.series_and_number()
    assert isinstance(series_and_number, str)
    assert len(series_and_number) == 12


# Generated at 2022-06-23 20:57:24.992313
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    """ Creates an object of RussiaSpecProvider and ensures that
    each method of this object gives the correct result

    """
    RussiaSpecProvider.generate()

# Generated at 2022-06-23 20:57:31.819506
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    bic = RussiaSpecProvider().bic()
    assert len(bic) == 9
    assert bic[0:2] == '04'
    assert bic[2:4] < '12'
    assert bic[4:6] < '100'
    assert bic[6:9] < '1000'
    assert bic[0] != '0'
    assert bic[1] != '0'
    assert bic[2] != '0'
    assert bic[3] != '0'
    assert bic[4] != '0'
    assert bic[5] != '0'


# Generated at 2022-06-23 20:57:37.705029
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    provider = RussiaSpecProvider('ru')
    assert provider.patronymic(Gender.MALE) in provider._data['patronymic'][Gender.MALE]
    assert provider.patronymic(Gender.FEMALE) in  provider._data['patronymic'][Gender.FEMALE]


# Generated at 2022-06-23 20:57:44.023066
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """Test method passport_number of class RussiaSpecProvider."""
    from mimesis.providers.locale.ru.russia import RussiaSpecProvider
    from mimesis.enums import Gender
    from mimesis.mimesis import Mimesis

    mimesis = Mimesis(locale='ru')
    rsp = RussiaSpecProvider()

    for _ in range(0, 1000):
        result = rsp.passport_number()
        assert isinstance(result, int)

    result = rsp.passport_number()
    assert isinstance(result, int)
    assert mimesis.code.luhn(result)

