

# Generated at 2022-06-23 20:47:47.985854
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test if the number is correct."""
    r = RussiaSpecProvider()
    snils = r.snils()
    assert len(snils) == 11
    assert snils.isdigit()
    assert int(snils[9]) == control_sum(snils[:9])
    assert int(snils[10]) == control_sum(snils[:10])


# Generated at 2022-06-23 20:47:51.170341
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    Russian_passport_series_test = ['35 11', '49 18', '02 16', '60 10']
    rsp = RussiaSpecProvider()
    for i in range(0, 4):
        assert Russian_passport_series_test[i] == rsp.passport_series()


# Generated at 2022-06-23 20:47:54.207709
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Unit test for method inn of class RussiaSpecProvider."""
    inn = RussiaSpecProvider().inn()
    assert len(inn) == 10
    assert str(inn).isdigit()



# Generated at 2022-06-23 20:48:01.255620
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Tests for method inn of class RussiaSpecProvider."""
    inn_provider = RussiaSpecProvider()

    # Test first branch
    inn_provider._seed = 1
    assert inn_provider.inn() == '1763968268'

    # Test second branch
    inn_provider.seed(2)
    assert inn_provider.inn() == '5749295414'

    # Test third branch
    inn_provider.seed(3)
    assert inn_provider.inn() == '2838563374'



# Generated at 2022-06-23 20:48:05.800564
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    rus=RussiaSpecProvider(seed=1)
    a=rus.generate_sentence()
    assert a == 'Пытался продать слепое куплетное сочинение в вопросе о гипертонии', a



# Generated at 2022-06-23 20:48:12.321128
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    from mimesis.enums import Gender
    from mimesis.random import Random
    from mimesis.providers.geography.russia import RussiaSpecProvider
    import unittest.mock as mock
    random = Random(10)

    with mock.patch('mimesis.random.Random', random):
        provider = RussiaSpecProvider()
        assert provider.country_code('ru') == 'RU'
        assert provider.country_name('ru') == 'Russia'
        assert provider.kpp()

# Generated at 2022-06-23 20:48:14.897382
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    r_inn = RussiaSpecProvider().inn()
    assert len(r_inn) == 12


# Generated at 2022-06-23 20:48:23.129539
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    r = RussiaSpecProvider(seed=123456789)
    assert (r.generate_sentence() == "Я пришёл, видел и победил."), \
        "generate_sentence() method does not work, go fix it!"
    assert (r.patronymic(Gender.MALE) == "Алексеевич"), \
        "patronymic() method does not work, go fix it!"
    assert (r.patronymic(Gender.FEMALE) == "Алексеевна"), \
        "patronymic() method does not work, go fix it!"

# Generated at 2022-06-23 20:48:23.971318
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    pr = RussiaSpecProvider()
    assert pr.ogrn()

# Generated at 2022-06-23 20:48:33.563073
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    provider =RussiaSpecProvider()
    inns = [provider.inn() for i in range(0,1000)]
    
    for inn in inns:
        # Заполнение массива цифр ИНН
        number = []
        for i in range(0, len(inn)):
            number.append(int(inn[i]))
        
        # Строка с цифрами ИНН для контрольной суммы
        n1_list = ['{}'.format(number[i]) for i in range(0, 9)]

# Generated at 2022-06-23 20:48:36.783705
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    g = RussiaSpecProvider()
    sentence = g.generate_sentence()
    print(sentence)
    assert sentence is not None
    assert len(sentence) > 0


# Generated at 2022-06-23 20:48:45.698459
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    from numpy import testing as npt
    from numpy import abs

    rng = RussiaSpecProvider()
    stat = [0] * 10
    for i in range(10000):
        tst = [int(x) for x in rng.ogrn()[:-1]]
        ogrn = [int(x) for x in rng.ogrn()[:-1]]
        stat[sum(abs(x-y) for x,y in zip(tst, ogrn)) % 10] += 1
    test = [rng.random.randint(0, 500) for _ in range(10)]
    assert npt.allclose(stat, test, rtol=0.2, atol=0)



# Generated at 2022-06-23 20:48:54.689233
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    p = RussiaSpecProvider()
    patronymic = p.patronymic(gender=Gender.MALE)

# Generated at 2022-06-23 20:48:59.994421
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    rsp = RussiaSpecProvider()
    ogrn = rsp.ogrn()
    ls = str(ogrn)
    assert len(ls) == 13
    for i in range(len(ls)):
        if i < 12:
            assert ls[i] != "-"
            assert ls[i] not in ("+", " ", "*", "/", "&", "$", "#", "@", "!")
            assert bool(ls[i].isnumeric())
        else:
            assert ls[i].isnumeric()

# Generated at 2022-06-23 20:49:02.215067
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    bic = RussiaSpecProvider()
    result = bic.bic()
    print(result)
    assert not result or len(str(result))==9


# Generated at 2022-06-23 20:49:08.549653
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Test for method inn of class RussiaSpecProvider"""
    ru = RussiaSpecProvider()
    ru.random.seed(1)
    assert ru.inn() == '5032837256'
    ru.random.seed(10)
    assert ru.inn() == '7834569079'
    ru.random.seed(100)
    assert ru.inn() == '5909693464'


# Generated at 2022-06-23 20:49:14.713922
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    from mimesis.enums import Gender
    from mimesis.providers.person.russia import RussiaSpecProvider
    rsp = RussiaSpecProvider()
    assert rsp.patronymic(Gender.FEMALE) == 'алексеевна'
    assert rsp.patronymic(Gender.MALE) == 'сергеевич'
    assert rsp.patronymic() == 'алексеевна' or rsp.patronymic() == 'сергеевич'



# Generated at 2022-06-23 20:49:18.454304
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    test_provider = RussiaSpecProvider()
    sn_0 = test_provider.series_and_number()
    sn_1 = test_provider.series_and_number()
    assert sn_0 != sn_1

# Generated at 2022-06-23 20:49:22.010025
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    """Test patronymic method."""
    provider = RussiaSpecProvider(seed=123456)
    result = provider.patronymic()
    assert_that(result).is_equal_to('Сергеевна')



# Generated at 2022-06-23 20:49:24.649700
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    generator = RussiaSpecProvider()
    sentence = generator.generate_sentence()
    assert isinstance(sentence, str)
    assert sentence.strip() != ''


# Generated at 2022-06-23 20:49:28.477037
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    test = RussiaSpecProvider()
    test_inn = test.inn()
    print(test_inn)
    if len(test_inn) == 12:
        print("The INN length is right!")
    else:
        print("The INN length is wrong!")


# Generated at 2022-06-23 20:49:29.685756
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    r = RussiaSpecProvider()
    print(r.passport_series())

# Generated at 2022-06-23 20:49:36.609348
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test the generation of a valid SNILS number."""
    rs = RussiaSpecProvider()
    generated_snils = rs.snils()
    print(generated_snils)
    control_codes = generated_snils[-2:]
    control_sum = 0
    for i in range(9, 0, -1):
        control_sum += int(generated_snils[9 - i]) * i
    assert control_sum % 101 == int(control_codes)
    # '41917492600'

    rs = RussiaSpecProvider()
    generated_snils = rs.snils()
    print(generated_snils)
    control_codes = generated_snils[-2:]
    control_sum = 0

# Generated at 2022-06-23 20:49:39.093700
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    rus = RussiaSpecProvider()
    assert rus.passport_series() == '62 20'


# Generated at 2022-06-23 20:49:43.935595
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    from mimesis.builtins import RussiaSpecProvider

    rus = RussiaSpecProvider()

    expected = ['Алексеевна', 'Михайловна', 'Александровна',
                'Петровна', 'Ивановна', 'Евгеньевна', 'Ильинична',
                'Сергеевна', 'Павловна', 'Степановна']

    actual = []

    for _ in range(0, 10):
        actual.append(rus.patronymic(Gender.FEMININE))


# Generated at 2022-06-23 20:49:49.845773
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    x = RussiaSpecProvider()
    #test_inn()
    #test_ogrn()
    #test_bic()
    #test_kpp()
    #test_passport_series()
    #test_passport_number()
    #test_series_and_number()
    #test_snils()
    #test_patronymic()
    #test_generate_sentence()

# Test inn()

# Generated at 2022-06-23 20:49:53.722250
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    s = RussiaSpecProvider().generate_sentence()
    assert s.__class__.__name__ == 'str' and not s == '', "Sentence generation error"

# Generated at 2022-06-23 20:50:00.174256
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    # Create an object of class RussiaSpecProvider
    rus_spec_provider = RussiaSpecProvider()
    # Generate 1000000 numbers of passport
    passport_number = [rus_spec_provider.passport_number() for _ in range(1000000)]
    number = rus_spec_provider.random.randint(100000, 999999)
    # Check the value of passport_number is the same as it should be
    assert number in passport_number


# Generated at 2022-06-23 20:50:04.909672
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    r = RussiaSpecProvider()
    assert (r.patronymic(Gender.FEMALE) in r._data['patronymic']['f'])
    assert (r.patronymic(Gender.MALE) in r._data['patronymic']['m'])



# Generated at 2022-06-23 20:50:06.269947
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    ru = RussiaSpecProvider()
    ru.ogrn()

test_RussiaSpecProvider_ogrn()

# Generated at 2022-06-23 20:50:08.735942
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """Unit test for method kpp of class RussiaSpecProvider"""
    assert len(RussiaSpecProvider().kpp()) == 9


# Generated at 2022-06-23 20:50:15.164884
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    p = RussiaSpecProvider()
    a = p.passport_number()
    b = p.passport_number()
    c = p.passport_number()
    assert isinstance(a, int)
    assert isinstance(b, int)
    assert isinstance(c, int)
    assert 100000 <= a <= 999999
    assert 100000 <= b <= 999999
    assert 100000 <= c <= 999999
    assert a != b and b != c and c != a


# Generated at 2022-06-23 20:50:16.567805
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    provider = RussiaSpecProvider()
    assert provider.inn() == '7801015373'


# Generated at 2022-06-23 20:50:18.344130
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """Unit test for method kpp of class RussiaSpecProvider."""
    r = RussiaSpecProvider()
    assert len(r.kpp()) == 9

# Generated at 2022-06-23 20:50:20.119600
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
	provider = RussiaSpecProvider(seed=0)
	result = provider.kpp()
	assert result == '380015201'

# Generated at 2022-06-23 20:50:22.358153
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    provider = RussiaSpecProvider(seed=42)
    expected_result = '51 18'
    generated_result = provider.passport_series()
    assert generated_result == expected_result

# Generated at 2022-06-23 20:50:25.588175
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """Unit test for method passport_number."""
    from mimesis.providers.russia import RussiaSpecProvider
    r = RussiaSpecProvider()
    assert 100000 <= r.passport_number() <= 999999

# Generated at 2022-06-23 20:50:36.615532
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    rus = RussiaSpecProvider()
    o = rus.ogrn()
    assert isinstance(o, str)
    assert len(o) == 13
    assert o.count('0') >= 1
    assert o.count('1') >= 1
    assert o.count('2') >= 1
    assert o.count('3') >= 1
    assert o.count('4') >= 1
    assert o.count('5') >= 1
    assert o.count('6') >= 1
    assert o.count('7') >= 1
    assert o.count('8') >= 1
    assert o.count('9') >= 1
    a = ''
    for i in range(13):
        if i == 12:
            a = a + str(i % 11 % 10)
        else:
            a = a + str(i)

# Generated at 2022-06-23 20:50:42.620411
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """
    Unit test for method ogrn of class RussiaSpecProvider
    """
    provider = RussiaSpecProvider()

    ogrn = provider.ogrn()
    assert len(ogrn) == 13
    assert ogrn[-1] != 0

    k = 1
    for i in range(12):
        k *= int(ogrn[i])

    assert (k % 11) % 10 == int(ogrn[-1])

# Generated at 2022-06-23 20:50:44.247382
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    assert len(RussiaSpecProvider().series_and_number()) == 11



# Generated at 2022-06-23 20:50:49.967749
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """Test passport_number."""
    import bigmler.utils as bigmler_utils
    import bigmler.checkpoint as bigmler_checkpoint

    logger = bigmler_utils.get_logger('BigMLer_RussiaSpecProvider_passport_number')
    
    # Remove the created resources
    bigmler_checkpoint.clean_created_resources(logger, True)
    # Call the main function
    main(logger)
    # Remove the created resources
    bigmler_checkpoint.clean_created_resources(logger, True)


# Generated at 2022-06-23 20:50:52.038873
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    russia_provider = RussiaSpecProvider()
    assert len(str(russia_provider.passport_number())) == 6


# Generated at 2022-06-23 20:50:58.123582
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    """ Unit test for method generate_sentence of class RussiaSpecProvider. """
    rus = RussiaSpecProvider()
    rus.seed(444)
    sentence = 'На занятиях картины начинают вызывать объекты в примеры.'
    assert rus.generate_sentence() == sentence


# Generated at 2022-06-23 20:50:59.130978
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    pass


# Generated at 2022-06-23 20:51:01.971843
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """Unit test for method kpp of class RussiaSpecProvider."""
    result = RussiaSpecProvider.kpp()
    assert(len(result) == 9)

test_RussiaSpecProvider_kpp()

# Generated at 2022-06-23 20:51:09.287066
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Unit test for :func:`~mimesis.providers.russia_provider.RussiaSpecProvider.series_and_number()`"""
    sn = RussiaSpecProvider()
    result = sn.series_and_number()
    assert len(result) == 11

    assert result[2] == ' '

    assert result[6] == ' '

    assert result[7].isdigit()

    assert result[8].isdigit()

    assert result[9].isdigit()

    assert result[10].isdigit()


# Generated at 2022-06-23 20:51:11.451011
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    provider = RussiaSpecProvider()
    series = provider.passport_series()
    assert len(series) == 5
    assert series[4] == '1' or series[4] == '0'



# Generated at 2022-06-23 20:51:20.944087
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Method to test the generation of a random Russia social number."""
    from mimesis.providers.person.snils import Snils
    from mimesis.builtins.base import BaseSpecProvider
    rsp = RussiaSpecProvider()
    bsp = BaseSpecProvider(seed=rsp.seed)
    for _ in range(1000):
        sn = rsp.snils()
        if not Snils().is_valid(sn):
            raise AssertionError('Invalid social number.')
    bsp.random.reset_state()
    rsp = RussiaSpecProvider(seed=bsp.seed)
    for _ in range(1000):
        sn = rsp.snils()
        if not Snils().is_valid(sn):
            raise AssertionError('Invalid social number.')


# Generated at 2022-06-23 20:51:25.205748
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    ru = RussiaSpecProvider()
    assert ru.passport_number() < 1000000
    assert ru.passport_number() > 100000
    ru = RussiaSpecProvider(seed=1)
    assert ru.passport_number() == 288002


# Generated at 2022-06-23 20:51:35.363396
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    """Test that patronymic is generated valid."""
    data = {
        'Александровна': 'Александровна',
        'Петровна': 'Петровна',
        'Иванович': 'Иванович',
        'Алексеевич': 'Алексеевич',
        'Петрович': 'Петрович',
    }
    obj = RussiaSpecProvider()

    for k, v in data.items():
        assert k == obj.patronymic(Gender.FEMALE)
       

# Generated at 2022-06-23 20:51:37.632900
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    temp1 = int(RussiaSpecProvider().passport_number() / 100000)
    temp2 = int(RussiaSpecProvider().passport_number() / 100000)
    assert(temp1 != temp2)

# Generated at 2022-06-23 20:51:47.711597
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    r = RussiaSpecProvider()
    i = 0
    while i < 10:
        series_and_number = r.series_and_number()
        assert len(series_and_number) == 10
        assert int(series_and_number[0:2]) >= 1 and int(series_and_number[0:2]) <= 99
        assert int(series_and_number[2:4]) >= 10 and int(series_and_number[2:4]) <= 18
        assert int(series_and_number[4:]) >= 100000 and int(series_and_number[4:]) <= 999999
        i += 1
        print(series_and_number)


# Generated at 2022-06-23 20:51:50.522359
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    assert RussiaSpecProvider().patronymic() != RussiaSpecProvider().patronymic()
    assert RussiaSpecProvider().patronymic() == RussiaSpecProvider().patronymic()


# Generated at 2022-06-23 20:51:52.032552
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    assert RussiaSpecProvider().passport_number()

# Generated at 2022-06-23 20:52:02.896015
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    r = RussiaSpecProvider()
    # Message generation:
    # test_gen_patronymic = r.patronymic(Gender.MALE).encode('ascii', 'ignore')
    # print(test_gen_patronymic)

# Generated at 2022-06-23 20:52:07.283109
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    rp = RussiaSpecProvider()
    res = rp.series_and_number()
    print(res)
    assert " ".join(res[0:3]) == res[3:10]

if __name__ == '__main__':
    test_RussiaSpecProvider_series_and_number()



# Generated at 2022-06-23 20:52:09.230191
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    """ Test for the constructor of class RussiaSpecProvider."""
    assert RussiaSpecProvider


# Generated at 2022-06-23 20:52:12.549934
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    provider = RussiaSpecProvider(seed=42)
    for _ in range(0, 100):
        assert provider.ogrn() == "1235380406040"



# Generated at 2022-06-23 20:52:16.103052
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    patronymics = []
    rps = RussiaSpecProvider()
    for gender in Gender:
        p = rps.patronymic(gender)
        patronymics.append(p)

    assert len(set(patronymics)) == len(patronymics)


# Generated at 2022-06-23 20:52:19.535601
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    """Unit test for method generate_sentence of class RussiaSpecProvider."""
    russian = RussiaSpecProvider()
    sentence = russian.generate_sentence()
    assert sentence is not None


# Generated at 2022-06-23 20:52:25.418129
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """
    The test function.

    :return:
        Test result.
    """
    provider = RussiaSpecProvider()
    ogrn = provider.ogrn()
    ogrn_valid = ogrn[:12]
    ogrn_check_digit = ogrn[-1]
    n = int(ogrn_valid) % 11 % 10
    assert n == int(ogrn_check_digit)


# Generated at 2022-06-23 20:52:26.959582
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    obj = RussiaSpecProvider(seed=12345678)
    assert obj.snils() == "41917492600"

# Generated at 2022-06-23 20:52:38.568517
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    def is_valid_kpp(kpp):
        """
        :return: True if kpp is correct, False otherwise
        """
        if (len(kpp) != 9) or not kpp.isdigit() or not (kpp[-1] in ('0', '1', '2', '3', '4', '5', '6', '7', '8', '9')):
            return False
        else:
            return True

    kpp_list = []  # list of kpp
    kpp_list_len = 100000  # number of elements in kpp_list
    # kpp_list_len = 1  # number of elements in kpp_list
    kpp_list_unique = []  # list of unique kpp
    provider = RussiaSpecProvider()


# Generated at 2022-06-23 20:52:50.715757
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    from random import randint
    from string import digits, ascii_letters

    russiaSpecProvider = RussiaSpecProvider(randint(0,99999))
    assert isinstance(russiaSpecProvider, RussiaSpecProvider)

    # Заполнить словарь
    data = {}
    
    data['city'] = russiaSpecProvider.city()
    data['building_number'] = russiaSpecProvider.building_number()
    data['house_street'] = russiaSpecProvider.house_street()
    data['phone_number'] = russiaSpecProvider.phone_number()
    data['fio'] = russiaSpecProvider.fio()
    data['address'] = russiaSpecProvider.address()


# Generated at 2022-06-23 20:52:54.651185
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Test for method series_and_number of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    sample_series = rsp.passport_series()
    sample_number = rsp.passport_number()
    expected = f'{sample_series}{sample_number}'
    actual = rsp.series_and_number()
    assert expected == actual

# Generated at 2022-06-23 20:52:56.309293
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    assert provider.snils() == '73524194444'


# Generated at 2022-06-23 20:52:57.254414
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    assert RussiaSpecProvider().series_and_number() != None

# Generated at 2022-06-23 20:52:59.944751
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    russian_provider = RussiaSpecProvider()
    assert russian_provider.snils() == '25969741448'


# Generated at 2022-06-23 20:53:04.643681
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """Unit test for method kpp of class RussiaSpecProvider
    :return:
    """
    rsp = RussiaSpecProvider()
    assert len(rsp.kpp()) == 9
    assert rsp.kpp().startswith('77')


# Generated at 2022-06-23 20:53:06.519141
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider()
    print(provider.bic()) # should be 044025575

# Generated at 2022-06-23 20:53:08.644010
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    result = RussiaSpecProvider(seed=4).patronymic()
    assert result == 'Петровна'


# Generated at 2022-06-23 20:53:16.948476
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    r = RussiaSpecProvider()
    assert len(r.kpp()) == 9

# Generated at 2022-06-23 20:53:21.145743
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    provider = RussiaSpecProvider()
    assert provider.patronymic(Gender.MALE) == "вич"
    assert provider.patronymic(Gender.FEMALE) == "вна"
    assert provider.patronymic(Gender.MALE) in provider.patronymic(Gender.MALE)
    assert provider.patronymic(Gender.FEMALE) in provider.patronymic(Gender.FEMALE)


# Generated at 2022-06-23 20:53:23.074437
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    r = RussiaSpecProvider()
    assert len(r.passport_series()) == 5


# Generated at 2022-06-23 20:53:26.986496
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    provider = RussiaSpecProvider()
    assert provider.patronymic()
    assert provider.patronymic(Gender.FEMALE)
    assert provider.patronymic(Gender.MALE)


# Generated at 2022-06-23 20:53:29.286551
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    r = RussiaSpecProvider()
    bic = r.bic()

# Generated at 2022-06-23 20:53:39.288162
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    ru = RussiaSpecProvider()
    ru.reset_seed()
    names = set()
    for i in range(1, 100):
        name = ru.patronymic()
        names.add(name)

# Generated at 2022-06-23 20:53:41.847965
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    provider = RussiaSpecProvider()
    if provider.passport_series() == None:
        return False

    return True

# Generated at 2022-06-23 20:53:50.859331
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    rsp = RussiaSpecProvider(seed = None)
    # Generate
    ogrn = rsp.ogrn()
    # Get the last digit of OGRN
    last_digit_ogrn = (int)(ogrn[-1:])
    # Get the first 12 digits of OGRN
    first_12_digits = int(ogrn[:-1])
    # Calculate the last digit
    last_digit = (int)(first_12_digits % 11 % 10)
    # Assert that ogrn is correct
    assert (last_digit == last_digit_ogrn)


# Generated at 2022-06-23 20:53:56.873334
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    bic = RussiaSpecProvider().bic()
    assert len(bic) == 9

    assert bic[:2] == '04'
    assert int(bic[2:4]) > 0 and int(bic[2:4]) < 11
    assert int(bic[4:6]) >= 0 and int(bic[4:6]) < 100
    assert int(bic[6:]) >= 50 and int(bic[6:]) < 999


# Generated at 2022-06-23 20:54:02.407394
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    provider = RussiaSpecProvider()
    series_and_number = provider.series_and_number()

    assert len(series_and_number) == 12
    assert series_and_number[2] == ' '
    assert all(c.isdigit() for c in series_and_number)


# Generated at 2022-06-23 20:54:09.010050
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """The test for the snils method."""
    random_data = RussiaSpecProvider()
    print("SNILS: " + random_data.snils())
    print("INN: " + random_data.inn())
    print("OGRN: " + random_data.ogrn())
    print("BIC: " + random_data.bic())
    print("KPP: " + random_data.kpp())

# Generated at 2022-06-23 20:54:12.094301
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    russia_spec_provider = RussiaSpecProvider()
    assert russia_spec_provider.__class__.__name__ == 'RussiaSpecProvider'

    print("Test OK")


# Generated at 2022-06-23 20:54:18.515345
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    import re
    print("Start test function RussiaSpecProvider_snils")
    obj = RussiaSpecProvider()
    snils = obj.snils()
    print("Generated snils", snils)
    if snils == None:
        print("Failed")
        return
    if not re.match("^[0-9]{11}$", snils):
        print("Failed")
        return
    print("Success")

test_RussiaSpecProvider_snils()

# Generated at 2022-06-23 20:54:20.548324
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    gen = RussiaSpecProvider()
    assert len(gen.generate_sentence()) > 0


# Generated at 2022-06-23 20:54:21.132034
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    pass

# Generated at 2022-06-23 20:54:27.786551
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.generic import Generic
    from mimesis.enums import Gender
    from mimesis.providers.russia import RussiaSpecProvider
    p = Person('ru')
    a = Address('ru')
    g = Generic('ru')
    r = RussiaSpecProvider()
    num = r.series_and_number()
    # print(p.full_name(gender=Gender.FEMALE))
    # print(p.full_name(gender=Gender.MALE))
    # print(a.address())
    # print(r.snils())
    # print(r.inn())
    # print(r.kpp())
    # print(r.ogrn())
    # print(

# Generated at 2022-06-23 20:54:29.951907
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    rsp = RussiaSpecProvider(seed=1)
    assert rsp.passport_series(year=18) == '04 18'


# Generated at 2022-06-23 20:54:31.855855
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    instance = RussiaSpecProvider(seed=20000000000000000)
    result = instance.bic()
    assert result == '044025575'


# Generated at 2022-06-23 20:54:38.884512
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    from src.utils import check_function_results
    # Initialize class
    russia = RussiaSpecProvider()
    patterns = ['^[0-9]{13}$']
    results = check_function_results(russia.ogrn, patterns=patterns)

    #print('\nResults:')
    #[print(result) for result in results]

    #print('\nStandards:')
    #[print(pattern) for pattern in patterns]

    # Test
    assert all(results) == True

# Generated at 2022-06-23 20:54:44.064438
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    """
    Test constructor of class RussiaSpecProvider
    """
    obj = RussiaSpecProvider(seed=1)

    print(obj.snils())
    print(obj.inn())
    print(obj.ogrn())


if __name__ == '__main__':
    test_RussiaSpecProvider()

# Generated at 2022-06-23 20:54:48.255626
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    russia_provider = RussiaSpecProvider()
    russia_provider.passport_series()
    assert isinstance(russia_provider.passport_series(), str)
    assert len(russia_provider.passport_series()) == 5


# Generated at 2022-06-23 20:54:49.645074
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    assert(len(RussiaSpecProvider().kpp()) == 9)

# Generated at 2022-06-23 20:55:00.285619
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    t=0
    f=0

    rsp = RussiaSpecProvider()

    a = rsp.passport_series()
    if a[0:2].isdigit() and a[3].isdigit():
        t+=1
    else:
        f+=1

    a = rsp.passport_series()
    if a[0:2].isdigit() and a[3].isdigit():
        t+=1
    else:
        f+=1

    a = rsp.passport_series()
    if a[0:2].isdigit() and a[3].isdigit():
        t+=1
    else:
        f+=1

    a = rsp.passport_series()
    if a[0:2].isdigit() and a[3].isdigit():
        t

# Generated at 2022-06-23 20:55:02.271088
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    assert RussiaSpecProvider(seed=1).passport_series() == '32 08'


# Generated at 2022-06-23 20:55:06.406722
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    rp = RussiaSpecProvider()
    kpp = rp.kpp()
    assert kpp
    assert len(kpp) == 9
    for i in range(4):
        assert kpp[i] in '0123456789'
    for i in range(4, 6):
        assert kpp[i] in '0123456789'
    for i in range(6, 9):
        assert kpp[i] in '0123456789'


# Generated at 2022-06-23 20:55:11.856919
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    from mimesis import Random
    provider = RussiaSpecProvider(seed=Random.DEFAULT_SEED)
    assert provider.generate_sentence() == 'Можно ли ' \
           'сократить длину тренировок ' \
           'при существенном увеличении их качества.'



# Generated at 2022-06-23 20:55:21.273523
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    test = RussiaSpecProvider()
    test._datafile
    test.Meta
    test._seed = 0
    test._random = 0
    test._datapath = 'mimesis/data'
    test._datafile = 'spec/ru.json'
    test._data = test._pull(test._datafile)
    test.generate_sentence()
    test.Meta.name = 'russia_provider'
    test.provider_name = 'russia_provider'
    test.language_code = 'ru'
    test.seed()
    test.reset_seed()
    test.create_token()
    test.create_unique()
    test.__str__()
    test.__repr__()
    test.__eq__(test)
    test.__ne__(test)

# Generated at 2022-06-23 20:55:26.233268
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    list = []
    russia = RussiaSpecProvider()
    list.append(russia.ogrn())
    while russia.ogrn() not in list:
        list.append(russia.ogrn())
    assert len(list) == 1000000


# Generated at 2022-06-23 20:55:28.257424
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    rus_spec_provider = RussiaSpecProvider(seed=12345)
    pass


# Generated at 2022-06-23 20:55:37.573489
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    russianObject = RussiaSpecProvider()

    #Test that method patronymic return correct value when we input Gender.MALE
    assert russianObject.patronymic(Gender.MALE) in russianObject._data["patronymic"]["male"]

    #Test that method patronymic return correct value when we input Gender.FEMALE
    assert russianObject.patronymic(Gender.FEMALE) in russianObject._data["patronymic"]["female"]

    #Test that method patronymic return correct value when we input Gender.NON_BINARY
    assert russianObject.patronymic(Gender.NON_BINARY) in russianObject._data["patronymic"]["non-binary"]


# Generated at 2022-06-23 20:55:39.350086
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    spec = RussiaSpecProvider()
    spec.ogrn()
    spec.ogrn()

# Generated at 2022-06-23 20:55:44.588401
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    from mimesis.providers.russia import RussiaSpecProvider
    r = RussiaSpecProvider()
    for _ in range(10):
        print(r.passport_number())

if __name__ == '__main__':
    test_RussiaSpecProvider_passport_number()

# Generated at 2022-06-23 20:55:49.147121
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    #Test for method patronymic of class RussiaSpecProvider
    rsp = RussiaSpecProvider()
    for x in range(20):
        assert rsp.patronymic(Gender.MALE) in rsp._data['patronymic']['MALE']
        assert rsp.patronymic(Gender.FEMALE) in rsp._data['patronymic']['FEMALE']

# Generated at 2022-06-23 20:55:56.829308
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():                                   # Unit test
    provider = RussiaSpecProvider()                                                # Initialize provider
    start_number = 11876357                                                        # Get start number
    start_series = '01 18'                                                         # Get start series
    # Generate series and number
    series_and_number1 = provider.series_and_number()                              # Generate series and number
    series_and_number2 = provider.series_and_number()                              # Generate series and number
    # Check if they start with the same digits
    assert (series_and_number1[:7] == start_series + str(start_number)) or (series_and_number2[:7] == start_series + str(start_number))


# Generated at 2022-06-23 20:55:57.917591
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    assert len(RussiaSpecProvider().passport_number()) == 6


# Generated at 2022-06-23 20:56:04.504565
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    import time
    import pytest
    from mimesis import RussiaSpecProvider
    from mimesis.enums import Gender
    from mimesis.providers.base import BaseSpecProvider
    from dtpattern.dtpattern import DTPattern

    # Init
    provider = RussiaSpecProvider()
    start = time.perf_counter()
    rnd_snils = provider.snils()
    finish = time.perf_counter()
    dt_pattern = DTPattern(rnd_snils)
    is_snils = dt_pattern.is_snils()
    first_run = finish - start
    snils_old = rnd_snils
    # Repeat
    start = time.perf_counter()
    rnd_snils = provider.snils()
    finish = time.perf_counter

# Generated at 2022-06-23 20:56:05.903358
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """Unit test RussiaSpecProvider"""
    rus = RussiaSpecProvider()
    assert len(str(rus.passport_number())) == 6

# Generated at 2022-06-23 20:56:12.253466
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    """
    тестирование генерации случайного предложения
    """
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    p = Person('ru')
    for i in range(0,10):
        print(p.full_name(gender=Gender.FEMALE))
    
    

# Generated at 2022-06-23 20:56:14.090366
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    r = RussiaSpecProvider()
    inn = r.inn()
    assert len(inn) == 12


# Generated at 2022-06-23 20:56:15.837800
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    print(RussiaSpecProvider().snils())


# Generated at 2022-06-23 20:56:19.115805
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    """Unit test for method generate_sentence of class RussiaSpecProvider"""
    print('Unit test for method generate_sentence of class RussiaSpecProvider')
    r = RussiaSpecProvider()
    sen = r.generate_sentence()
    print(sen)


# Generated at 2022-06-23 20:56:20.816442
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    year = RussiaSpecProvider().passport_series(18)
    assert year == "86 18"



# Generated at 2022-06-23 20:56:24.269088
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    a = RussiaSpecProvider().ogrn()
    print(a)
    assert len(a) == 13
    #assert a == '4715113303725'


# Generated at 2022-06-23 20:56:27.501773
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    for i in range(1, 1000):
        print(RussiaSpecProvider().series_and_number())
test_RussiaSpecProvider_series_and_number()

# Generated at 2022-06-23 20:56:38.792332
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    from mimesis.providers.address import Address
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.payment import Payment
    from mimesis.providers.finance import Finance
    from mimesis.providers.generic import Generic
    from mimesis.providers.internet import Internet
    from mimesis.providers.file import File
    from mimesis.providers.phone import Phone
    from mimesis.providers.misc import Misc
    from mimesis.providers.science import Science
    from mimesis.providers.business import Business
    from mimesis.providers.identifier import Identifier
   

# Generated at 2022-06-23 20:56:40.421733
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    assert provider.snils() == '29454073600'

# Generated at 2022-06-23 20:56:42.595717
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    assert RussiaSpecProvider().kpp() == '730011001'



# Generated at 2022-06-23 20:56:43.242949
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    RussiaSpecProvider()

# Generated at 2022-06-23 20:56:46.991507
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    import pytest

    provider = RussiaSpecProvider()

    with pytest.raises(TypeError):
        provider.series_and_number(1)
    assert isinstance(provider.series_and_number(), str)

# Generated at 2022-06-23 20:56:48.493888
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    p = RussiaSpecProvider()
    assert type(p.passport_number()) == int

# Generated at 2022-06-23 20:56:52.231364
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    # Create object of RussiaSpecProvider
    provider = RussiaSpecProvider()

    # Generate random inn
    inn = provider.inn()
    # Check if inn matches the regex
    assert re.match(r'[0-9]{10}', inn)

# Generated at 2022-06-23 20:56:54.841629
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    assert provider.snils() == '41917492600'

# Generated at 2022-06-23 20:56:57.928818
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    russia_spec_provider = RussiaSpecProvider()
    passport_number = russia_spec_provider.passport_number()
    assert len(str(passport_number)) == 6


# Generated at 2022-06-23 20:57:00.567572
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    rsp = RussiaSpecProvider()
    inn = rsp.inn()
    assert len(inn) == 12
    assert str.isdigit(inn)
    assert inn[:1] != 0

# Generated at 2022-06-23 20:57:03.544324
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    number = range(1000)
    russia_spec_provider = RussiaSpecProvider(seed=12345)
    for x in number:
        russia_spec_provider.series_and_number()
    assert russia_spec_provider.series_and_number() == '02 15805435'

# Generated at 2022-06-23 20:57:05.727051
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    print("\n===== test_RussiaSpecProvider_snils =====\n")
    ru = RussiaSpecProvider()
    for i in range(0, 10):
        print(ru.snils())



# Generated at 2022-06-23 20:57:07.329510
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    assert RussiaSpecProvider().series_and_number().isnumeric() == 1

# Generated at 2022-06-23 20:57:12.545868
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    print("Testing snils of RussiaSpecProvider")
    # Initializing the spec provider
    provider = RussiaSpecProvider()

    # Testing snils()
    assert(42 == len(provider.snils()))
    print("Done")


# Generated at 2022-06-23 20:57:14.478432
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Unit test for method inn of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    assert provider.inn() == '500100735'

# Generated at 2022-06-23 20:57:20.924259
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    from mimesis.enums import Gender

    # Initialize RussiaSpecProvider
    rusprov = RussiaSpecProvider()

    assert rusprov.gender == Gender.FEMALE
    assert rusprov.locale == 'ru'

    rusprov.set_gender(Gender.MALE)
    assert rusprov.gender == Gender.MALE


# Generated at 2022-06-23 20:57:27.517852
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    provider = RussiaSpecProvider()
    assert provider.patronymic(Gender.MALE) in provider._data['patronymic'][Gender.MALE] and \
           provider.patronymic(Gender.MALE) != provider.patronymic(Gender.MALE) and \
           provider.patronymic(Gender.MALE) != provider.patronymic(Gender.FEMALE), "Wrong function work."


# Generated at 2022-06-23 20:57:30.956609
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    for i in range(0, 100):
        russian = RussiaSpecProvider()
        test = russian.passport_series()
        assert test == '{:02d} {}'.format(russian.random.randint(1, 99), russian.random.randint(10, 18))


# Generated at 2022-06-23 20:57:34.167557
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    r = RussiaSpecProvider()

    for _ in range(10):
        assert len(str(r.passport_number())) == 6


# Generated at 2022-06-23 20:57:43.550568
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    pass_series_and_number = RussiaSpecProvider().series_and_number()
    assert len(pass_series_and_number) == 10

    snils = RussiaSpecProvider().snils()
    assert len(snils) == 11

    kpp = RussiaSpecProvider().kpp()
    assert len(kpp) == 9

    bic = RussiaSpecProvider().bic()
    assert len(bic) == 9

    inn = RussiaSpecProvider().inn()
    assert len(inn) == 12

    ogrn = RussiaSpecProvider().ogrn()
    assert len(ogrn) == 13

    pass_series = RussiaSpecProvider().passport_series()
    assert len(pass_series) == 5

    pass_number = RussiaSpecProvider().passport_number()
    assert len(str(pass_number)) == 6

    patron