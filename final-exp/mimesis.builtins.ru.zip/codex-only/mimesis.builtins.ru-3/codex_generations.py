

# Generated at 2022-06-23 20:47:45.341949
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Test for method ogrn of class RussiaSpecProvider"""
    import re
    ogrn = RussiaSpecProvider().ogrn()
    assert re.match(r"\d{13}", ogrn)



# Generated at 2022-06-23 20:47:48.676672
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    """
    Unit test for method generate_sentence of class RussiaSpecProvider
    Assert : 
        - generate_sentence returns string
    """
    rsp = RussiaSpecProvider()
    assert(isinstance(rsp.generate_sentence(), str))

# Generated at 2022-06-23 20:47:50.076848
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    assert(len(str(RussiaSpecProvider().ogrn())) == 13)

# Generated at 2022-06-23 20:47:54.936046
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    rs = RussiaSpecProvider()
    inn = rs.inn()
    if len(inn) == 10:
        print('Code 10: ', check_INN_10(inn) == 0)
    elif len(inn) == 12:
        print('Code 12: ', check_INN_12(inn) == 0)
    else:
        print('Error')


# Generated at 2022-06-23 20:47:57.044454
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Unit test -> RussiaSpecProvider.series_and_number"""
    ru = RussiaSpecProvider()
    ru.series_and_numb

# Generated at 2022-06-23 20:48:06.041537
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """
    Тестируем метод snils класса RussiaSpecProvider.
    Тестируем для случайных snils что они валидны и не валидны.
    """
    class Ev:
        """ Класс для хранения сгенерированных snils """
        data = []

    snils_provider = RussiaSpecProvider()

    for i in range(1000):
        Ev.data.append(snils_provider.snils())


# Generated at 2022-06-23 20:48:08.255085
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    r = RussiaSpecProvider()
    s = r.generate_sentence()
    assert(len(s) > 0)


# Generated at 2022-06-23 20:48:16.896375
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    assert len(RussiaSpecProvider().series_and_number()) == 13
    assert RussiaSpecProvider().series_and_number()[2] == RussiaSpecProvider().series_and_number()[6]
    assert RussiaSpecProvider().series_and_number()[3] == RussiaSpecProvider().series_and_number()[7]
    assert RussiaSpecProvider().series_and_number()[4] == RussiaSpecProvider().series_and_number()[8]
    assert RussiaSpecProvider().series_and_number()[9] != '0'
    assert RussiaSpecProvider().series_and_number()[10] != '0'
    assert RussiaSpecProvider().series_and_number()[11] != '0'
    assert RussiaSpecProvider().series_and_number()[12] != '0'


# Generated at 2022-06-23 20:48:17.973191
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    obj = RussiaSpecProvider()
    assert isinstance(obj.passport_number(), int)

# Generated at 2022-06-23 20:48:19.788631
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    r = RussiaSpecProvider()
    passport_number = r.passport_number()
    print(passport_number)


# Generated at 2022-06-23 20:48:25.437810
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    print("\nTest for method patronymic of class RussiaSpecProvider")
    ru_provider = RussiaSpecProvider()

    result = ru_provider.patronymic(Gender.FEMALE)
    print("Test 1 - result:", result, end="")
    result = ru_provider.patronymic(Gender.MALE)
    print("Test 2 - result:", result, end="")

    ru_provider = RussiaSpecProvider(seed=6)

    result = ru_provider.patronymic(Gender.FEMALE)
    print("Test 3 - result:", result, end="")
    result = ru_provider.patronymic(Gender.MALE)
    print("Test 4 - result:", result, end="")

    ru_provider = RussiaSpecProvider(seed=12)

    result

# Generated at 2022-06-23 20:48:26.620910
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    rsp = RussiaSpecProvider()
    inntest = rsp.inn()
    print('INN:', inntest)


# Generated at 2022-06-23 20:48:28.411170
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    provider = RussiaSpecProvider(seed='test')
    assert isinstance(provider, RussiaSpecProvider)



# Generated at 2022-06-23 20:48:30.243891
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    provider = RussiaSpecProvider()
    assert len(str(provider.ogrn())) == 13


# Generated at 2022-06-23 20:48:37.265601
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    """Unit test for method patronymic of class RussiaSpecProvider"""
    import mimesis
    data_provider = mimesis.RussiaSpecProvider

    assert len(data_provider.patronymic()) == 8
    assert len(data_provider.patronymic(1)) == 8
    assert data_provider.patronymic(1) == data_provider.patronymic(
        'М')
    assert data_provider.patronymic(0) == data_provider.patronymic(
        'Ж')
    assert data_provider.patronymic(
        1) != data_provider.patronymic(0)



# Generated at 2022-06-23 20:48:41.393835
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider"""
    # Generate some snils
    generator = RussiaSpecProvider()
    snils = generator.snils()
    # Assert that generated snils consists of 11 digits
    assert (len(str(snils))) == 11

# Unit te

# Generated at 2022-06-23 20:48:43.544449
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Unit test for RussiaSpecProvider.ogrn()."""
    assert RussiaSpecProvider().ogrn() == '4715113303725'


# Generated at 2022-06-23 20:48:45.237550
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Test method ogrn of class RussiaSpecProvider."""
    assert (validate_checksum(RussiaSpecProvider().ogrn()) == True)

# Generated at 2022-06-23 20:48:46.857419
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    ogrn = RussiaSpecProvider().ogrn()
    assert ogrn in str(ogrn)

# Generated at 2022-06-23 20:48:53.713887
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis import RussiaSpecProvider
    from mimesis.enums import Gender
    from mimesis.typing import Seed

    # Test 1
    rsp = RussiaSpecProvider(seed = Seed.random())
    snils = rsp.snils()
    print(snils)

    # Test 2
    rsp2 = RussiaSpecProvider('ru', seed = Seed.random())
    snils2 = rsp2.snils()
    print(snils2)

# Generated at 2022-06-23 20:49:02.748236
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    provider = RussiaSpecProvider()
    assert provider.gender.male(upper=True) == 'Мужской'
    assert provider.name.last_name() == 'Петров'
    assert provider.address.municipality() == 'Калининский район'
    assert provider.address.region() == 'Тюменская область'
    assert provider.business.company_name() == 'ООО "ПРОМТЕХКОМПЛЕКТ-С"'

# Generated at 2022-06-23 20:49:08.044205
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    Russia_SpecProvider = RussiaSpecProvider(seed=0)
    assert Russia_SpecProvider.patronymic() == "Александровна"
    assert Russia_SpecProvider.patronymic() == "Алексеевна"


# Generated at 2022-06-23 20:49:09.573630
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    r = RussiaSpecProvider()
    assert len(r.bic()) == 9


# Generated at 2022-06-23 20:49:12.882051
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    obj = RussiaSpecProvider()
    assert len(obj.snils()) == 11
    assert obj.snils()[3] == obj.snils()[7] == '-'
    print(obj.snils())


# Generated at 2022-06-23 20:49:14.038821
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    assert len(RussiaSpecProvider().inn()) == 12



# Generated at 2022-06-23 20:49:16.126430
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
  provider = RussiaSpecProvider()
  ogrn = provider.ogrn()
  print(ogrn)
  assert ogrn.isdigit() and len(ogrn) == 13


# Generated at 2022-06-23 20:49:24.897716
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    import random

    year = random.randint(10, 18)
    region = random.randint(1, 99)

    # Проверка на правильное значение года
    test_passport_series = RussiaSpecProvider.passport_series(year)
    passport_series = str(region) + " " + str(year)

    assert len(test_passport_series) == 5
    assert test_passport_series == passport_series


# Generated at 2022-06-23 20:49:33.165853
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    assert RussiaSpecProvider().snils() == '41917492600'
    # В принципе, все фактически возможные числа
    # будут одинаково вероятны, поэтому все варианты
    # нужно проверить вручную на сайте ФНС

# Generated at 2022-06-23 20:49:36.112960
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    from mimesis.schema import Field
    rs = RussiaSpecProvider(seed=1)

    data = {'my_ogrn': Field('ogrn')}
    for _ in range(5):
        print(rs.create(data))


# Generated at 2022-06-23 20:49:39.414562
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    snils_provider = RussiaSpecProvider()
    print("SNILS: " + snils_provider.snils())


# Generated at 2022-06-23 20:49:44.176312
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    ##################
    # Test 1
    test_number_1 = '4715113303725'
    test_1 = RussiaSpecProvider().ogrn()
    assert test_1 == test_number_1

    ##################
    # Test 2
    test_number_2 = '5019118307811'
    test_2 = RussiaSpecProvider().ogrn()
    assert test_2 == test_number_2

    ##################
    # Test 3
    test_number_3 = '9904001112'
    test_3 = RussiaSpecProvider().ogrn()
    assert test_3 == test_number_3

    ##################
    # Test 4
    test_number_4 = '590105101'
    test_4 = RussiaSpecProvider().ogrn()
    assert test_4 == test_number_

# Generated at 2022-06-23 20:49:45.686811
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    assert RussiaSpecProvider().series_and_number() == '09 16 059269'

# Generated at 2022-06-23 20:49:49.338233
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    russian = RussiaSpecProvider(seed = 4)
    for x in range(1,10):
        temp = russian.kpp()
        print(temp)
        assert len(temp) == 9
        assert type(temp) == str

# Generated at 2022-06-23 20:49:51.663982
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    inn = RussiaSpecProvider().inn()
    assert len(inn) == 10
    

# Generated at 2022-06-23 20:50:02.536058
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.person import Person
    from mimesis.providers.base import BaseProvider
    import unittest
    import re

    class TestRussiaSpecProvider_snils(unittest.TestCase):
        def setUp(self):
            self.person = Person('ru')
            self.snils_pattern = re.compile(
                    "^[0-9]{11}$"
            )

        def test_RussiaSpecProvider_snils_1(self):
            result = self.person.snils()
            self.assertEqual(bool(self.snils_pattern.match(result)), True)

        def test_RussiaSpecProvider_snils_2(self):
            result = self.person.snils()
            self.assertNotEqual(result, None)


# Generated at 2022-06-23 20:50:06.331795
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    from . import RussiaSpecProvider
    rsp = RussiaSpecProvider(seed=123)
    a = rsp.ogrn()
    b = rsp.ogrn()
    assert a == '4715113303725'
    assert b == '4715113303725'

# Generated at 2022-06-23 20:50:16.274394
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    from mimesis.providers.address.enums import AddressType
    from mimesis.enums import Gender
    from mimesis.providers import RussiaSpecProvider

    russia = RussiaSpecProvider()
    for i in range(10):
        assert russia.generate_sentence() in russia.sentence()
        assert russia.generate_sentence(address_type=AddressType.CITY) in russia.sentence(address_type=AddressType.CITY)
        assert russia.generate_sentence(
            address_type=AddressType.REGION) in russia.sentence(address_type=AddressType.REGION)

# Generated at 2022-06-23 20:50:21.986351
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    r = RussiaSpecProvider()
    mydict = {}
    for _ in range(0, 1000000):
        inn = r.inn()
        if inn in mydict:
            mydict[inn] += 1
        else:
            mydict[inn] = 1
    print(mydict) # выводим все вхождения номеров ИНН и их количество

if __name__ == '__main__':
    test_RussiaSpecProvider_inn()

# Generated at 2022-06-23 20:50:30.489838
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    # Проверка метода series_and_number класса RussiaSpecProvider для корректности возвращаемой строки
    #
    # Создание специального провайдера без параметров вызова(выбор случайной локали и случайный "семя" генератора)
    provider

# Generated at 2022-06-23 20:50:34.110288
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    rs = RussiaSpecProvider()
    result = rs.generate_sentence()
    assert len(result) == 50
    assert result[0].isupper()
    assert result[-1] == '.'

# Generated at 2022-06-23 20:50:37.041365
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    provider = RussiaSpecProvider()
    bic = provider.bic()
    assert len(bic) == 9
    assert bic.isdigit()


# Generated at 2022-06-23 20:50:39.367922
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    rnd = RussiaSpecProvider()
    assert rnd.kpp() == '540012345', "Method kpp returns incorrect result"

# Generated at 2022-06-23 20:50:44.372785
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    provider = RussiaSpecProvider()
    year = provider.random.randint(10, 18)
    region = provider.random.randint(1, 99)
    passport_series = provider.passport_series(year)
    assert f"{region} {year}" == passport_series


# Generated at 2022-06-23 20:50:45.659115
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    print(RussiaSpecProvider().passport_series())


# Generated at 2022-06-23 20:50:47.815989
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    assert len(russia_provider.kpp()) == 9
    assert len(russia_provider.kpp()) == 9

# Generated at 2022-06-23 20:50:49.559353
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    provider = RussiaSpecProvider()
    inn = provider.inn()
    assert len(inn) == 10 and type(inn) == str



# Generated at 2022-06-23 20:50:54.141389
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    from mimesis.enums import Gender
    russ = RussiaSpecProvider()
    print(russ.patronymic())
    print(russ.patronymic(Gender.MALE))
    print(russ.patronymic(Gender.FEMALE))
# test_RussiaSpecProvider_patronymic()


# Generated at 2022-06-23 20:50:56.230652
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    assert RussiaSpecProvider().passport_number() > 0 and RussiaSpecProvider().passport_number() < 1000000


# Generated at 2022-06-23 20:51:07.354572
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.providers.identifier import Identifier
    from mimesis.providers.locales import Russia
    from mimesis.providers.ru_russia import RussiaSpecProvider

    # Test method snils without params
    russian = Russia(seed=523)
    russian_spec_provider = RussiaSpecProvider(seed=523)
    identifier = Identifier(seed=523)
    referee_number = '41917492600'

    generated_snils = russian_spec_provider.snils()
    generated_referee_number = identifier.numeric_code(9)
    generated_full_name = russian.full_name(Gender.MALE)
    generated_address = russian.address()

# Generated at 2022-06-23 20:51:10.342544
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    russia_locale = RussiaSpecProvider()
    result = russia_locale.passport_number()
    assert result >= 100000 and result <= 999999

# Generated at 2022-06-23 20:51:12.873591
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
	assert RussiaSpecProvider().passport_number() in range(100000, 1000000)


# Generated at 2022-06-23 20:51:14.687261
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    russia = RussiaSpecProvider()
    print(russia.inn())



# Generated at 2022-06-23 20:51:17.798449
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    provider = RussiaSpecProvider(seed=0)
    value = provider.inn()
    assert value == '9969474045'

#Unit test for method ogrn of class RussiaSpecProvider

# Generated at 2022-06-23 20:51:20.036839
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    provider = RussiaSpecProvider()
    print(provider.kpp())
    assert len(provider.kpp()) == 9


# Generated at 2022-06-23 20:51:28.229426
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    from mimesis.providers.person import Person
    from mimesis.enums import Gender

    new_Russia = RussiaSpecProvider()

    sentence = new_Russia.generate_sentence()
    if not sentence:
        assert False

    for _ in range(4):
        head = new_Russia.random.choice(new_Russia._data['sentence']['head'])
        p1 = new_Russia.random.choice(new_Russia._data['sentence']['p1'])
        p2 = new_Russia.random.choice(new_Russia._data['sentence']['p2'])
        tail = new_Russia.random.choice(new_Russia._data['sentence']['tail'])

# Generated at 2022-06-23 20:51:35.133694
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Test for method ogrn of class RussiaSpecProvider."""
    # Test whether the first digit is 0
    assert RussiaSpecProvider().ogrn()[0] != '0'
    # Test whether there are only numbers in ogrn
    ogrn = RussiaSpecProvider().ogrn()
    assert ogrn.isnumeric()
    # Test whether the last digit is the check sum
    assert int(ogrn) % 11 % 10 == int(ogrn[-1])
    # Test whether the length of ogrn is 13
    assert len(ogrn) == 13



# Generated at 2022-06-23 20:51:40.046528
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    p = RussiaSpecProvider()
    print(p.generate_sentence())
    print(p.patronymic())
    print(p.passport_series())
    print(p.passport_number())
    print(p.series_and_number())
    print(p.snils())
    print(p.inn())
    print(p.ogrn())
    print(p.bic())
    print(p.kpp())

if __name__ == '__main__':
    test_RussiaSpecProvider()

# Generated at 2022-06-23 20:51:42.007342
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    r = RussiaSpecProvider()
    assert r.ogrn() == '4715113303725'

# Generated at 2022-06-23 20:51:44.303991
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    a = RussiaSpecProvider()
    assert len(a.ogrn()) == 13
    assert len(a.ogrn(seed=1)) == 13

# Generated at 2022-06-23 20:51:46.422243
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Test method inn of class RussiaSpecProvider."""
    inn = RussiaSpecProvider()
    r = inn.inn()
    assert r is not None

# Generated at 2022-06-23 20:51:51.361777
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    assert RussiaSpecProvider().generate_sentence() \
        == 'Привет, мы работаем над проектом и используем мемы.'

# Generated at 2022-06-23 20:51:56.951456
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    rsp = RussiaSpecProvider()

    number_list = []
    series_list = []

    for n in range(100):
        passport = rsp.series_and_number()
        series_list.append(passport[:4])
        number_list.append(passport[4:])

    # Проверить на повторения:
    assert len(series_list) == len(set(series_list)), \
        "Series is not unique"
    assert len(number_list) == len(set(number_list)), \
        "Numbers is not unique"

# Generated at 2022-06-23 20:51:59.818830
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    from mimesis import RussiaSpecProvider as tr
    t = tr()
    print(t.generate_sentence())


# Generated at 2022-06-23 20:52:06.041719
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """
    Tests the method inn of class RussiaSpecProvider.

    It tests the correctness of the INN generated by the method inn of the
    class RussiaSpecProvider.
    """
    LOCALE = 'ru'
    LOCALES = [LOCALE]
    for LOCALE in LOCALES:
        provider = RussiaSpecProvider(LOCALE)
        for _ in range(0, 5):
            assert len(provider.inn()) == 10
        for _ in range(0, 5):
            tmp = int(provider.inn())
            assert 1000000000 <= tmp <= 9999999999


# Generated at 2022-06-23 20:52:10.067530
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    instances = []
    repeat = 100
    provider = RussiaSpecProvider()
    
    for _ in range(repeat):
        instances.append(provider.series_and_number())
    
    assert len(instances) == repeat
    assert all(isinstance(x, str) for x in instances)

# Generated at 2022-06-23 20:52:12.721494
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    provider = RussiaSpecProvider(seed=4)
    expected = '041419037'
    result = provider.inn()
    assert result == expected

# Generated at 2022-06-23 20:52:14.390834
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    random = RussiaSpecProvider()
    random.series_and_number()
    print('OK')

# Generated at 2022-06-23 20:52:18.707118
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    """Unit test for method passport_number of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    print("passport_number:", rsp.passport_number(),
          type(rsp.passport_number()))

# Generated at 2022-06-23 20:52:21.103088
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    r = RussiaSpecProvider()
    assert set(r.passport_series().split()) == set(['66', '18'])


# Generated at 2022-06-23 20:52:24.329151
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    provider = RussiaSpecProvider(seed=123)
    provider.random.randint = lambda a, b: b
    inn = provider.inn()
    assert inn  == '9999999999'

# Generated at 2022-06-23 20:52:27.878037
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    import doctest
    doctest.testmod(verbose=True)


# Generated at 2022-06-23 20:52:30.329289
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test method snils of class RussiaSpecProvider."""
    rsp = RussiaSpecProvider()
    assert(len(rsp.snils()) == 11)

# Generated at 2022-06-23 20:52:40.461213
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    russiaspecprovider = RussiaSpecProvider()
    russiaspecprovider.inn()
    russiaspecprovider.ogrn()
    russiaspecprovider.bic()
    russiaspecprovider.kpp()
    russiaspecprovider.generate_sentence()
    russiaspecprovider.patronymic()
    russiaspecprovider.passport_series()
    russiaspecprovider.passport_number()
    russiaspecprovider.series_and_number()
    russiaspecprovider.snils()
    #print(russiaspecprovider.inn()+" "+russiaspecprovider.ogrn())


# Generated at 2022-06-23 20:52:44.286662
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    """
    Запуск тестов модуля
    """
    from mimesis import RussiaSpecProvider
    assert RussiaSpecProvider().kpp() == RussiaSpecProvider().kpp()

# Generated at 2022-06-23 20:52:46.380550
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Unit test for method inn of class RussiaSpecProvider."""
    assert RussiaSpecProvider().inn() in range(100000000000, 999999999999)


# Generated at 2022-06-23 20:52:50.154739
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    # Arrange
    provider = RussiaSpecProvider()

    # Assert
    assert len(provider.passport_series()) == 5
    assert provider.passport_series()[2] == ' '


# Generated at 2022-06-23 20:52:52.962566
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    prov = RussiaSpecProvider(seed=None)
    result = prov.series_and_number()
    assert len(result) == 11
    assert result.isdigit()

# Generated at 2022-06-23 20:52:58.675182
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    seed_provider = RussiaSpecProvider()
    passport = seed_provider.series_and_number()
    print("passport = ", passport)
    assert len(passport) == 11
    assert passport[:2].isdigit()
    assert passport[2:4].isdigit()
    assert passport[4:].isdigit()


# Generated at 2022-06-23 20:53:01.511229
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    russia_spec_provider = RussiaSpecProvider
    assert russia_spec_provider.passport_series(russia_spec_provider) == '11 18'


# Generated at 2022-06-23 20:53:08.112769
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    snils_list = dict()
    russia = RussiaSpecProvider(seed=42)
    for i in range(10):
        snils = russia.snils()
        if snils in snils_list:
            snils_list[snils] += 1
        else:
            snils_list[snils] = 1
    
    for key in snils_list:
        print(key, snils_list[key])

# Generated at 2022-06-23 20:53:16.585634
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    from mimesis.enums import Gender
    from mimesis.providers.russia import RussiaSpecProvider
    RussiaSpecProvider_ = RussiaSpecProvider()

# Generated at 2022-06-23 20:53:21.706439
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    ru = RussiaSpecProvider()
    i = 0
    for x in range(1, 1000):
        if ru.series_and_number() in ru.series_and_number():
            i += 1
    if i > 0:
        print(ru.series_and_number())
        return True


# Generated at 2022-06-23 20:53:30.630850
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    provider = RussiaSpecProvider()
    assert isinstance(provider, RussiaSpecProvider)
    assert provider._data is not None
    assert isinstance(provider.sentence, str)
    assert isinstance(provider.patronymic(gender=Gender.MALE), str)
    assert isinstance(provider.passport_series(), str)
    assert isinstance(provider.passport_number(), int)
    assert isinstance(provider.series_and_number(), str)
    assert isinstance(provider.snils(), str)
    assert isinstance(provider.inn(), str)
    assert isinstance(provider.ogrn(), str)
    assert isinstance(provider.bic(), str)
    assert isinstance(provider.kpp(), str)

# Generated at 2022-06-23 20:53:32.634550
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    from mimesis.providers.russia import RussiaSpecProvider
    from mimesis.enums import Gender
    test = RussiaSpecProvider(seed=101)
    result = test.series_and_number()
    print(result)

# Generated at 2022-06-23 20:53:41.410645
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    provider = RussiaSpecProvider()
    assert provider.patronymic(Gender.MALE) in ('Александрович', 'Иванович', 'Юрьевич')
    assert provider.patronymic(Gender.FEMALE) in ('Каролиновна', 'Ниновна', 'Еленовна')
    assert provider.patronymic(Gender.UNKNOWN) in ('Матвеевна', 'Гавриловна', 'Петровна')


# Generated at 2022-06-23 20:53:51.702016
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Unit test for method snils of class RussiaSpecProvider"""
    from unittest.mock import patch, Mock
    from pprint import pprint

    OLD_RANDRANGE = RussiaSpecProvider().random.randint
    NEW_RANDRANGE = Mock()


    RussiaSpecProvider().random.randint = NEW_RANDRANGE
    NEW_RANDRANGE.side_effect = [ 1, 7, 4, 1, 7, 4, 9, 2, 6, 0]

    snils = RussiaSpecProvider.snils(RussiaSpecProvider())
    assert snils == '17141744926'

    RussiaSpecProvider().random.randint = OLD_RANDRANGE

# Generated at 2022-06-23 20:53:53.741104
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    from mimesis import Generic
    rsp = Generic('ru')
    print(rsp.russia.generate_sentence())
    print(rsp.russia.generate_sentence())
    print(rsp.russia.generate_sentence())


# Generated at 2022-06-23 20:54:00.736287
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    from mimesis.builtins.russia import RussiaSpecProvider

    r = RussiaSpecProvider()
    p = Person('en')
    for _ in range(100):
        snils = r.snils()
        gender = p.gender()
        if gender == Gender.MALE:
            assert snils[-2] in ('0', '5')
        else:
            assert snils[-2] in ('1', '6')
        assert snils[-3] == '0'
        if snils[-1] == '0':
            assert snils[-2] not in ('3', '4')

# Generated at 2022-06-23 20:54:03.717242
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Test for method series_and_number of class RussiaSpecProvider."""
    rs = RussiaSpecProvider()
    assert len(rs.series_and_number()) == 10


# Generated at 2022-06-23 20:54:05.250828
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    from pprint import pprint
    ru = RussiaSpecProvider()


# Generated at 2022-06-23 20:54:07.989742
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    provider = RussiaSpecProvider()
    assert provider.gender == Gender.MALE
    assert provider.locale == 'ru'


# Generated at 2022-06-23 20:54:18.475062
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Unit test for method ogrn of class RussiaSpecProvider."""
    from mimesis.providers.finance import Finance
    from mimesis.providers.person import Person
    from mimesis.providers.localisation import Localisation
    from mimesis.providers.address import Address
    from mimesis.providers.code import Code
    from mimesis.providers.company import Company
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.identifier import Identifier
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.vehicle import Vehicle
    from mimesis.providers.internet import Internet
    from mimesis.providers.communication import Communication
    from mimesis.providers.text import Text

# Generated at 2022-06-23 20:54:21.974805
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    """Testing the method bic of class RussiaSpecProvider."""
    russian_provider = RussiaSpecProvider()
    # Verify that the length of the result is equal to 9
    assert len(russian_provider.bic()) == 9


# Generated at 2022-06-23 20:54:23.450755
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    provider = RussiaSpecProvider()
    result = provider.kpp()
    assert len(result) == 9


# Generated at 2022-06-23 20:54:25.043686
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    russia_provider = RussiaSpecProvider(seed=None)
    print(russia_provider.bic())


# Generated at 2022-06-23 20:54:29.180754
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    # Arrange
    provider = RussiaSpecProvider()
    expected = 6

    # Act
    actual = len(provider.passport_series())

    # Assert
    assert actual == expected



# Generated at 2022-06-23 20:54:31.165990
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    provider = RussiaSpecProvider()
    r = provider.patronymic(Gender.FEMALE)
    assert len(r) == 8

# Generated at 2022-06-23 20:54:37.294654
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    from mimesis.providers import RussiaSpecProvider
    russia_spec = RussiaSpecProvider()
    # Check for correct length
    assert(len(russia_spec.inn()) == 10)
    # Check for correct length
    assert(len(russia_spec.inn()) == 10)
    # Check for correct length
    assert(len(russia_spec.inn()) == 10)
    # Check for correct length
    assert(len(russia_spec.inn()) == 10)
    # Check for correct length
    assert(len(russia_spec.inn()) == 10)
    # Check for correct length
    assert(len(russia_spec.inn()) == 10)
    # Check for correct length
    assert(len(russia_spec.inn()) == 10)
    # Check for correct length

# Generated at 2022-06-23 20:54:39.032042
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    rus = RussiaSpecProvider()
    print(rus.passport_series())


# Generated at 2022-06-23 20:54:42.714505
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    provider = RussiaSpecProvider()
    res = provider.ogrn()
    assert len(res) == 13
    assert res[:12].isdigit()
    assert res[12:].isdigit()


# Generated at 2022-06-23 20:54:49.146443
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    """Unit test for method ogrn of class RussiaSpecProvider."""
    r = RussiaSpecProvider()
    ogrn_list = []
    len_ = []
    for i in range(10000):
        ogrn_list.append(r.ogrn())
        if len(ogrn_list[i]) == 13:
            len_.append(ogrn_list[i])
    assert len(len_) == 10000


# Generated at 2022-06-23 20:54:54.062820
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    """Unit test for method bic of class RussiaSpecProvider."""
    from mimesis.providers.finance import Faker
    import re
    faker = Faker('ru')
    bic = faker.bic()
    assert len(bic) == 9
    assert re.match(r'\d{9}', bic)

# Generated at 2022-06-23 20:54:58.856576
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    provider = RussiaSpecProvider()
    snils = provider.snils()
    assert str(snils) == snils, "Value snils must be string."
    assert len(str(snils)) == 11, "The length of snils must be 11."
    assert int(snils) > 0, "Snils not to be a negative."


# Generated at 2022-06-23 20:55:02.328042
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    assert RussiaSpecProvider().passport_series(18) == "15 18"
    assert RussiaSpecProvider().passport_series(10) == "91 10"
    assert RussiaSpecProvider().passport_series(99) == "60 99"


# Generated at 2022-06-23 20:55:09.079399
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    provider = RussiaSpecProvider()
    res = provider.series_and_number()
    # data = [int(i) for i in res if i.isdigit()]
    data = [int(i) for i in res]
    assert len(data) == 10
    assert data[0]*10 + data[1] < 100
    assert data[2] == 1 or  data[2] == 2
    assert data[3]*10 + data[4] < 20
    assert data[4]*10 + data[5] < 100000


# Generated at 2022-06-23 20:55:10.685947
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    ru_provider = RussiaSpecProvider()
    bic = ru_provider.bic()
    assert len(bic) == 9


# Generated at 2022-06-23 20:55:12.365839
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    """Create an instance of RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    assert isinstance(provider, RussiaSpecProvider)

# Generated at 2022-06-23 20:55:14.216189
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    """Test method bic of class RussiaSpecProvider."""
    provider = RussiaSpecProvider(seed=1)
    bic = provider.bic()
    assert bic == '044325575'


# Generated at 2022-06-23 20:55:16.896832
# Unit test for method ogrn of class RussiaSpecProvider
def test_RussiaSpecProvider_ogrn():
    provider = RussiaSpecProvider()
    sample = provider.ogrn()
    assert isinstance(sample, str)


# Generated at 2022-06-23 20:55:19.854387
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    r = RussiaSpecProvider()
    year = r.random.randint(10, 18)
    assert r.passport_series(year) == str(r.random.randint(1, 99)) + " " + str(year)



# Generated at 2022-06-23 20:55:23.555177
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    test_object = RussiaSpecProvider()
    assert len(test_object.bic()) == 11
    assert test_object.bic() != test_object.bic()

# Generated at 2022-06-23 20:55:31.976599
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    rp = RussiaSpecProvider()
    # a new test
    # getting the list of all possible output for passport_series
    # function result will be for the next 6 years
    passport_series_list = []
    for i in range(10, 16):
        for j in range(1, 99):
            pass_series = '{:02} {}'.format(j, i)
            passport_series_list.append(pass_series)

    # generating 1000 new passport series
    passport_series_generated = []
    for i in range(1000):
        pass_series = rp.passport_series()
        passport_series_generated.append(pass_series)

    # checking if the generated series are in list of possible outputs
    for i in range(1000):
        assert passport_series_generated[i] in passport_series_list



# Generated at 2022-06-23 20:55:33.751836
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    assert RussiaSpecProvider().passport_series(year = 15) == '57 15'


# Generated at 2022-06-23 20:55:36.228882
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    from mimesis.providers.russia_provider import RussiaSpecProvider
    ru = RussiaSpecProvider()
    ru.passport_number()


# Generated at 2022-06-23 20:55:40.313120
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    provider = RussiaSpecProvider()
    male_patronymic = provider.patronymic(gender=Gender.MALE)
    female_patronymic = provider.patronymic(gender=Gender.FEMALE)

    assert male_patronymic != female_patronymic

# Generated at 2022-06-23 20:55:42.523115
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    r = RussiaSpecProvider()
    snils = r.snils()
    assert snils == '41917492600'

# Generated at 2022-06-23 20:55:48.479343
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Test method snils of class RussiaSpecProvider."""
    provider = RussiaSpecProvider()
    snils = provider.snils()
    print('snils = ', snils)
    assert snils.count('0') == 2
    provider = RussiaSpecProvider(seed=0xDEADBEEF)
    snils = provider.snils()
    print('snils = ', snils)
    assert snils.count('0') == 2


# Generated at 2022-06-23 20:55:52.512696
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """
    Test that method passport_series of class RussiaSpecProvider
    returns string of region (2 digits) and manufacture year (2 digits)
    """
    import re
    assert re.match('\d{2} ?\d{2}', RussiaSpecProvider().passport_series())



# Generated at 2022-06-23 20:56:00.064085
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """
    Тест метода генерации СНИЛС класса RussiaSpecProvider.
    """

    a = RussiaSpecProvider()

    snils = a.snils()

    # Только 10 символов
    assert len(snils) == 11

    def control_sum(nums: list, t: str) -> int:
        digits_dict = {
            'n2': [7, 2, 4, 10, 3, 5, 9, 4, 6, 8],
            'n1': [3, 7, 2, 4, 10, 3, 5, 9, 4, 6, 8],
        }
        number = 0
        digits = digits_dict[t]

# Generated at 2022-06-23 20:56:03.530500
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    assert RussiaSpecProvider().generate_sentence()
    assert isinstance(RussiaSpecProvider().generate_sentence(), str)


# Generated at 2022-06-23 20:56:13.334883
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    from mimesis.enums import Gender 
    from mimesis.enums import Specialization
    from mimesis.enums import Seed 
    from mimesis.providers.specialization import Specialization
    from mimesis.providers.address import Address 
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person 
    from mimesis.providers.payments import Payments
    from mimesis.providers.science import Science 
    from mimesis.providers.text import Text 
    from mimesis.providers.unit import Unit 
    from mimesis.providers.bank import Bank 
    from mimesis.providers.business import Business 
    from mimesis.providers.code import Code 

# Generated at 2022-06-23 20:56:15.838193
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    russiaSpecProviderObj = RussiaSpecProvider()
    assert len(russiaSpecProviderObj.inn()) == 10



# Generated at 2022-06-23 20:56:19.700070
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    """Sample test for method inn of class RussiaSpecProvider."""
    assert len(RussiaSpecProvider().inn()) == 10



# Generated at 2022-06-23 20:56:22.400671
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    class_ = RussiaSpecProvider()
    assert class_ is not None, "Unable to instantiate RussiaSpecProvider class."

# Unit tests for methods of class RussiaSpecProvider

# Generated at 2022-06-23 20:56:30.264421
# Unit test for method bic of class RussiaSpecProvider
def test_RussiaSpecProvider_bic():
    # Arrange
    spec_provider = RussiaSpecProvider()
    expected_result = 100000
    # Act
    num_of_results = 0
    for i in range(expected_result):
        result = spec_provider.bic()
        if result == '044025575':
            num_of_results += 1
    # Assert
    assert num_of_results > 0.0
    # Assert
    assert num_of_results < expected_result * 1.1

# Generated at 2022-06-23 20:56:36.063492
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    s = RussiaSpecProvider()  
    a = s.patronymic()
    l = [str(i) for i in range(0, 100)]
    for i in l:
    	assert len(a) == 8
    	assert a[3] == 'е'


# Generated at 2022-06-23 20:56:43.465832
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    """Check if returned snils is valid and the same for two returns.
    
    This function is an unit test for method snils of class RussiaSpecProvider.
    If a snils returned by an instance of this class is valid, and if the same snils is returned twice in a row,
    the test is passed. Otherwise, the test is failed.
    
    Parameters
    ----------
    None
    
    Returns
    -------
    is_ok : bool
        Returns True if the test is passed, and False if the test is failed.
    
    """
    russia_provider = RussiaSpecProvider()
    snils_1 = russia_provider.snils()
    snils_1_sum = 0
    snils_1_str = str(snils_1)
    for i in range(9):
        snils_1_

# Generated at 2022-06-23 20:56:45.267803
# Unit test for method inn of class RussiaSpecProvider
def test_RussiaSpecProvider_inn():
    assert len(RussiaSpecProvider().inn()) == 12



# Generated at 2022-06-23 20:56:49.441737
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    from mimesis.builtins import RussiaSpecProvider

    rus = RussiaSpecProvider()

    actual = rus.patronymic(Gender.FEMALE)
    expected = 'Александровна'
    assert actual == expected


# Generated at 2022-06-23 20:56:59.329334
# Unit test for method snils of class RussiaSpecProvider
def test_RussiaSpecProvider_snils():
    rsp = RussiaSpecProvider()
    assert rsp.snils() == '41917492600'
    assert rsp.snils() == '83596277600'
    assert rsp.snils() == '40670845659'
    assert rsp.snils() == '32092724644'
    assert rsp.snils() == '70454906220'
    assert rsp.snils() == '28056759144'
    assert rsp.snils() == '10300378980'
    assert rsp.snils() == '24667131600'
    assert rsp.snils() == '48658979000'
    assert rsp.snils() == '74767568600'
    assert rsp.snils() == '75463822900'

# Generated at 2022-06-23 20:57:00.487824
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    pass

# Generated at 2022-06-23 20:57:01.956994
# Unit test for method generate_sentence of class RussiaSpecProvider
def test_RussiaSpecProvider_generate_sentence():
    r = RussiaSpecProvider()
    sentence = r.generate_sentence()
    assert isinstance(sentence, str)

# Generated at 2022-06-23 20:57:08.445942
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Checking the passport_series method."""
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.misc import Misc
    # Create a misc provider
    sp1 = Misc('ru')
    # Create a russia provider
    rsp = RussiaSpecProvider('ru')
    # Create a datetime provider
    dt = Datetime('ru')
    # Get a random year
    year = dt.year()
    # Get a string variable of type '02 15'
    res1 = rsp.passport_series(year)
    # Get a string variable of type '02 15'
    res2 = rsp.passport_series(year)
    # Get a string variable of type '02 15'
    res3 = rsp.passport_series(year)
    # Get a string variable

# Generated at 2022-06-23 20:57:12.445606
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    from mimesis import RussiaSpecProvider
    p=RussiaSpecProvider(seed=None)
    z=p.passport_series()
    assert z is not None


# Generated at 2022-06-23 20:57:14.313247
# Unit test for method kpp of class RussiaSpecProvider
def test_RussiaSpecProvider_kpp():
    provider = RussiaSpecProvider()
    for _ in range(10):
        print(provider.kpp())


# Generated at 2022-06-23 20:57:16.942925
# Unit test for method passport_number of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_number():
    test_provider = RussiaSpecProvider(seed=None)

    for _ in range(10):
        assert test_provider.passport_number() >= 100000 and test_provider.passport_number() <= 999999


# Generated at 2022-06-23 20:57:18.255055
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    provider = RussiaSpecProvider()
    return provider

# Generated at 2022-06-23 20:57:21.963462
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    """Test for method series_and_number of class RussiaSpecProvider"""
    rsp = RussiaSpecProvider()

    for _ in range(0, 100):
        rsp.series_and_number()


# Generated at 2022-06-23 20:57:26.335527
# Unit test for constructor of class RussiaSpecProvider
def test_RussiaSpecProvider():
    """Unit test for method 'RussiaSpecProvider'."""
    provider = RussiaSpecProvider(seed=4545)
    assert provider.__class__.__module__ == 'mimesis.providers.address.ru'


# Generated at 2022-06-23 20:57:34.868360
# Unit test for method patronymic of class RussiaSpecProvider
def test_RussiaSpecProvider_patronymic():
    provider = RussiaSpecProvider()

# Generated at 2022-06-23 20:57:37.661910
# Unit test for method series_and_number of class RussiaSpecProvider
def test_RussiaSpecProvider_series_and_number():
    provider = RussiaSpecProvider()
    result = provider.series_and_number()
    length = len(result)
    assert length == 9

# Generated at 2022-06-23 20:57:42.677079
# Unit test for method passport_series of class RussiaSpecProvider
def test_RussiaSpecProvider_passport_series():
    """Test for method passport_series of class RussiaSpecProvider."""
    # Arrange
    pattern = r'^[01][0-9] (1[0-8]|2[0-9])$'
    russian_provider = RussiaSpecProvider()
    # Act
    series = russian_provider.passport_series()
    # Assert
    assert re.match(pattern, series) is not None
