

# Generated at 2022-06-22 05:33:06.167841
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    assert repr(Message(text="hello", code="max_length", position=Position(1,2,3))) == "Message(text='hello', code='max_length', position=Position(line_no=1, column_no=2, char_index=3))"
    assert repr(Message(text="hello", code="max_length", start_position=Position(1,2,3), end_position=Position(9,8,7))) == "Message(text='hello', code='max_length', start_position=Position(line_no=1, column_no=2, char_index=3), end_position=Position(line_no=9, column_no=8, char_index=7))"



# Generated at 2022-06-22 05:33:11.281765
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    value = 'hello'
    error = ValidationError(text='oops')
    assert ValidationResult(value=value) == ValidationResult(value=value)
    assert ValidationResult(error=error) == ValidationResult(error=error)
    assert ValidationResult(value=value) != ValidationResult(value='goodbye')
    

# Generated at 2022-06-22 05:33:16.799597
# Unit test for constructor of class ValidationError
def test_ValidationError():
    error = ValidationError(text='msg1')
    display(error)
    print(repr(error))

    error = ValidationError(messages=[Message('msg2', 'code2')])
    display(error)
    print(repr(error))

test_ValidationError()


# Generated at 2022-06-22 05:33:26.078902
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Test for two messages are the same

    expected = True
    result = Message("May not have more than 100 characters", "max_length", "username", [
                     "users", 3, "username"], Position(1, 1, 0)) == Message("May not have more than 100 characters", "max_length", "username", [
                                                                             "users", 3, "username"], Position(1, 1, 0))
    assert expected == result

    # Test for two messages are not the same because of different text
    expected = False

# Generated at 2022-06-22 05:33:36.985631
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    message = Message(text="hello", code="code1", key="key1")
    message2 = Message(text="hello2", code="code1", key="key1")
    assert hash(message) != hash(message2)

    message = Message(text="hello", code="code1", key="key1")
    message2 = Message(text="hello", code="code1", key="key1")
    assert hash(message) == hash(message2)

    message = Message(text="hello", code="code1", key="key1")
    message2 = Message(text="hello", code="code2", key="key1")
    assert hash(message) != hash(message2)

    message = Message(text="hello", code="code1", key="key1")

# Generated at 2022-06-22 05:33:38.254809
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    BaseError()

# Generated at 2022-06-22 05:33:48.496997
# Unit test for constructor of class ParseError
def test_ParseError():
    pe = ParseError(text="test",code="test1",key = 1,position = Position(0,0,0))

# Generated at 2022-06-22 05:33:56.516223
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    value = "value"
    error = ValidationError(text="error")
    vr1 = ValidationResult(value=value)
    vr2 = ValidationResult(error=error)
    assert(bool(vr1) is True)
    assert(bool(vr2) is False)
    # End of test

# Generated at 2022-06-22 05:34:01.514068
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    from typesystem.types import Integer

    int_schema = Integer()
    res = int_schema.validate_or_error(3)
    assert bool(res) is True

    res = int_schema.validate_or_error("bad")
    assert bool(res) is False



# Generated at 2022-06-22 05:34:04.639964
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="x", code="a") == Message(text="x", code="a")
    assert not (Message(text="x", code="a") == Message(text="x", code="b"))


# Generated at 2022-06-22 05:34:12.488728
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    position = Position(line_no=1, column_no=2, char_index=3)
    assert repr(position) == "Position(line_no=1, column_no=2, char_index=3)"


# Generated at 2022-06-22 05:34:20.863456
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    # Instantiate with a single message
    error = BaseError(text="abc", code="abc", key="abc", position=Position(1, 1, 1))
    assert repr(error) == "BaseError(text='abc', code='abc')"

    # Instantiate with multiple messages
    error = BaseError(messages=[Message(text="abc", code="abc", key="abc", position=Position(1, 1, 1))])
    assert repr(error) == "BaseError([Message(text='abc', code='abc', key='abc', position=Position(line_no=1, column_no=1, char_index=1))])"


# Generated at 2022-06-22 05:34:27.555899
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    # arrange
    line_no = 2
    column_no = 3
    char_index = 4
    expected = 'Position(line_no=2, column_no=3, char_index=4)'

    # act
    sut = Position(line_no, column_no, char_index)
    actual = sut.__repr__()

    # assert
    assert actual == expected


# Generated at 2022-06-22 05:34:34.395677
# Unit test for constructor of class BaseError
def test_BaseError():
    error = BaseError(messages=[
        Message(text='Error type: may not have more than 100 characters',
                code='max_length',
                index=[],
                position=Position(line_no=1, column_no=12, char_index=11)),
        Message(text='Error type: may not have more than 100 characters',
                code='max_length',
                index=[0],
                position=Position(line_no=1, column_no=12, char_index=11)),
    ])
    assert error.keys() == ['0']

# Generated at 2022-06-22 05:34:38.429258
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    msg = Message(text="May not have more than 100 characters", key="username")
    with pytest.raises(KeyError):
        ValidationError([msg])["invalid_key"]

# Generated at 2022-06-22 05:34:51.883872
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    # Test 1
    code = 'test'
    index = [1, 'test']
    message = Message(text='test', code=code, index=index)
    e = BaseError(messages=[message])
    try:
        rv = e[index[0]]
    except:
        pass
    else:
        assert False

    # Test 2
    code = 'test'
    index = [1, 'test']
    message = Message(text='test', code=code, index=index)
    e = BaseError(messages=[message])
    try:
        rv = e[index[1]]
    except:
        pass
    else:
        assert False

    # Test 3
    # Exception raised
    e = BaseError()

# Generated at 2022-06-22 05:34:54.131492
# Unit test for constructor of class BaseError
def test_BaseError():
    e1 = BaseError(text="this should break", code=None, key=None, position=None, messages=None)
    assert e1

# Generated at 2022-06-22 05:34:56.204444
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError(text="error", code="error_code", key=1, position=[2, 3])

# Generated at 2022-06-22 05:35:02.567084
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    print("Test: Constructor of class ValidationResult")
    a = ValidationResult()
    b = ValidationResult(value = 10)
    c = ValidationResult(error = ValidationError())
    
    for state in [a,b,c]:
        print("value: " + str(state.value))
        print("error: " + str(state.error))



# Generated at 2022-06-22 05:35:08.211934
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    # Setup
    message1 = Message(text="Stuff is bad", code="badness", index=[0])
    message2 = Message(text="Stuff is bad", code="badness", index=[0])

    # Preconditions
    assert message1 == message2

    # Test
    assert hash(message1) == hash(message2)


# Generated at 2022-06-22 05:35:17.666199
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    value = 2
    error = ValidationError(text="TEST ERROR")
    assert str(ValidationResult(value=value)) == 'ValidationResult(value=2)'
    assert str(ValidationResult(error=error)) == 'ValidationResult(error=ValidationError(text=\'TEST ERROR\', code=\'custom\'))'


# Generated at 2022-06-22 05:35:28.510577
# Unit test for constructor of class ValidationError
def test_ValidationError():
    assert repr(ValidationError(
        text='hello',
        code='custom',
        key='foo',
        position = Position(line_no = 1, column_no = 1, char_index = 1), 
    )) == "ValidationError(text='hello', code='custom')"
    assert repr(ValidationError(
    	messages = [
    		Message(text = 'hello',code = 'custom' ,key = 1),
    		Message(text = 'hello world',code = 'custom' ,key = 1),
    	]
    )) == "ValidationError([Message(text='hello', code='custom', index=[1]), Message(text='hello world', code='custom', index=[1])])"

# Generated at 2022-06-22 05:35:37.997239
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert ValidationError(text='username', code='max_length', key=100) == \
           ValidationError(text='username', code='max_length', key=100)
    assert ValidationError(text='username', code='max_length', key=100) != \
           ValidationError(text='username', code='max_length', key=101)
    assert ValidationError(text='username', code='max_length', index=[100]) == \
           ValidationError(text='username', code='max_length', index=[100])
    assert ValidationError(text='username', code='max_length', index=[100]) != \
           ValidationError(text='username', code='max_length', index=[101])
    assert ValidationError(text='username', code='max_length', key=100) != \
           ValidationError

# Generated at 2022-06-22 05:35:41.275443
# Unit test for constructor of class BaseError
def test_BaseError():
    assert BaseError(text="Hello", code="hello", key="key") == BaseError(
        messages=[Message(text="Hello", code="hello", key="key")]
    )


# Generated at 2022-06-22 05:35:47.173389
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    # Call method '__repr__' for class 'Position'
    line_no = 0
    column_no = 0
    char_index = 0
    instance = Position(line_no, column_no, char_index)
    expected = "Position(line_no=0, column_no=0, char_index=0)"
    result = instance.__repr__()
    assert result == expected


# Generated at 2022-06-22 05:35:53.944004
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    error = ValidationError(messages=[
        Message(text='Has to be one of', code='one_of', key='field_name', index=['field_name'])
    ])
    msg = error.messages()[0]
    assert msg.text == 'Has to be one of'
    assert msg.code == 'one_of'
    assert msg.index == ['field_name']

# Generated at 2022-06-22 05:35:55.920991
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    validator = ValidationResult(value = 20)
    assert validator.value == 20


# Generated at 2022-06-22 05:36:08.213210
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    # Test 1:
    messages = [Message(text="First error.", code="custom"), Message(text="First error.", code="custom")]
    error = BaseError(messages=messages)
    assert hash(error) == hash(messages)
    test_messages = [Message(text="First error.", code="custom"), Message(text="First error.", code="custom"), Message(text="First error.", code="custom")]
    test_error = BaseError(messages=test_messages)
    assert hash(test_error) == hash(test_messages)
    # Test 2:
    messages = [Message(text="First error."), Message(text="Second error.")]
    error = BaseError(messages=messages)
    assert hash(error) == hash(messages)

# Generated at 2022-06-22 05:36:10.213773
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    item = ValidationResult(error=ValidationError())
    print(item)
    assert False


# Generated at 2022-06-22 05:36:11.697730
# Unit test for constructor of class Position
def test_Position():
    pass
    # print(Position(1,1,1))


# Generated at 2022-06-22 05:36:17.522648
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    assert repr(Position(1, 2, 3)) == 'Position(line_no=1, column_no=2, char_index=3)'


# Generated at 2022-06-22 05:36:22.386529
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    value = 'dummy'
    vr = ValidationResult(value=value)
    assert bool(vr)
    
    error = ValidationError(text='test error')
    vr = ValidationResult(error=error)
    assert not bool(vr)


# Generated at 2022-06-22 05:36:24.168407
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    value = 'Hello'
    val_result = ValidationResult(value=value)
    return val_result

# Generated at 2022-06-22 05:36:35.297939
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    a = Position(
        line_no=1,
        column_no=2,
        char_index=3,
    )
    if not isinstance(a, Position):
        raise AssertionError("a {0}".format(a))
    b = Position(
        line_no=1,
        column_no=2,
        char_index=3,
    )
    if not isinstance(b, Position):
        raise AssertionError("b {0}".format(b))
    if not a == b:
        raise AssertionError("a {0} b {1}".format(a, b))
    if a == b:
        pass
    else:
        raise AssertionError("a {0} b {1}".format(a, b))
    # __eq__ of Position equals Position

# Generated at 2022-06-22 05:36:41.006583
# Unit test for constructor of class BaseError
def test_BaseError():
    messages = [Message(text='bad_key', code='type_error', key='foo')]
    b1 = BaseError(text='bad_key', code='type_error', key='foo')
    b2 = BaseError(messages=messages)


# Generated at 2022-06-22 05:36:45.088678
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message0 = Message(text="text", code='code')
    message1 = Message(text="text", code='code')
    assert(message0 == message1)
    assert(message0 == message0)
    assert(message1 == message1)


# Generated at 2022-06-22 05:36:52.075212
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    code = None
    key = None
    index = None
    position = None
    start_position = None
    end_position = None
    text = "test text"
    messages = [Message(text=text,code=code,key=key,position=position)]
    
    # Test the default conditions
    v1 = ValidationError(messages=messages)
    v2 = ValidationError(messages=messages)
    assert hash(v1) != hash(v2)



# Generated at 2022-06-22 05:37:03.877068
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='Hello World!', code='custom', key='hello', index=None, start_position=Position(1, 2, 3), end_position=Position(4, 5, 6))
    message2 = Message(text='Hello World!', code='custom', key='hello', index=None, start_position=Position(1, 2, 3), end_position=Position(4, 5, 6))
    m = message1 == message2
    assert (m == True)
    message3 = Message(text='Hello World!', code='custom', key='hello', index=None, start_position=Position(1, 2, 3), end_position=Position(4, 5, 7))
    n = message1 == message3
    assert (n == False)

# Generated at 2022-06-22 05:37:14.047358
# Unit test for constructor of class BaseError
def test_BaseError():
    import copy
    b = BaseError()
    assert b == {"" : ""}, "Should be of length 1 and have a key of ''. Is " + str(b)
    c = BaseError(text="Error", code="Format Message", key="message", position = Position(1, 2, 3))
    assert c == {'message' : 'Error'}, "Should be of length 1 and have a key of 'message'. Is " + str(c)
    d = BaseError(text="Error", code="Format Message", key="message", position = Position(1, 2, 3))
    assert d == {'message' : 'Error'}, "Should be of length 1 and have a key of 'message'. Is " + str(d)

# Generated at 2022-06-22 05:37:21.126292
# Unit test for constructor of class Message
def test_Message():
    message = Message(text="a", code="a", key=1, index=[1,5], position=Position(1,1,1), start_position=Position(1,1,1), end_position=Position(1,1,1))
    assert message.text == "a"
    assert message.code == "a"
    assert message.index == [1,5]
    assert message.start_position == Position(1,1,1)
    assert message.end_position == Position(1,1,1)


# Generated at 2022-06-22 05:37:38.408364
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    data = {"a": {"b": 1, "c": 2}, "d": 3}
    
    # Both objects are empty
    messages1 = []
    messages2 = []
    error1 = BaseError(messages=messages1)
    error2 = BaseError(messages=messages2)
    assert error1.__eq__(error2)
    
    # Two objects have same messages
    messages1.append(Message(text="May not have more than 100 characters"))
    messages2.append(Message(text="May not have more than 100 characters"))
    error1 = BaseError(messages=messages1)
    error2 = BaseError(messages=messages2)
    assert error1.__eq__(error2)
    
    # Two objects have different messages

# Generated at 2022-06-22 05:37:46.535015
# Unit test for constructor of class ParseError
def test_ParseError():
    """
    >>> ParseError(text=1)
    ParseError(text=1)
    >>> ParseError(code=1, key=1)
    ParseError(text=ParseError(code=1, key=1), code='custom')
    >>> ParseError(position=1, index=1, code=1, key=1)
    ParseError(text=ParseError(position=1, index=1, code=1, key=1), code='custom')
    >>> ParseError(messages=1, index=1)
    ParseError(text=ParseError(messages=1, index=1))
    >>> ParseError(text=1, index=1)
    ParseError(text=1, index=1)
    """


# Generated at 2022-06-22 05:37:49.948204
# Unit test for constructor of class ParseError
def test_ParseError():
    p = ParseError(text='error', code='custom', key='key')
    print(str(p._messages[0]))
    print(str(p._message_dict))
    print(str(p))


# Generated at 2022-06-22 05:37:55.609249
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    # Case 1
    obj = BaseError({})
    assert repr(obj) == "BaseError({})"

    # Case 2
    obj = BaseError()
    assert repr(obj) == "BaseError({})"

    # Case 3
    obj = BaseError
    assert repr(obj) == "BaseError"

    # Case 4
    obj = BaseError({"a": "b"})
    assert repr(obj) == "BaseError({'a': 'b'})"



# Generated at 2022-06-22 05:37:58.174936
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    message = Message(text="Error text", code="Error code", index=["index"])
    message_error = BaseError(messages=[message])
    assert message_error.messages() == [Message(text="Error text", code="Error code", index=["index"])]

# Generated at 2022-06-22 05:38:04.010320
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    try:
        value = None
        error = None
        result = ValidationResult(value=value, error=error)
        assert result.__repr__() == 'ValidationResult(value=None)'
        result = ValidationResult(value=value, error=error)
        assert result.__repr__() == 'ValidationResult(value=None)'
    except:
        print("test_ValidationResult___repr__ failed")



# Generated at 2022-06-22 05:38:14.283358
# Unit test for constructor of class ValidationError
def test_ValidationError():
    error1 = ValidationError(text="An error", code="error", key="key")
    error2 = ValidationError(messages=[Message(text="An error", code="error", index=["key"])])
    assert error1 == error2
    assert hash(error1) == hash(error2)
    assert str(error1) == '"An error"'
    assert str(error2) == '"An error"'
    assert repr(error1) == "ValidationError(text='An error', code='error')"
    assert repr(error2) == "ValidationError(text='An error', code='error', index=['key'])"
    assert dict(error1) == {"key": "An error"}
    assert dict(error2) == {"key": "An error"}
    assert list(error1) == ["key"]

# Generated at 2022-06-22 05:38:15.474522
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    assert hash(BaseError()) == hash(BaseError())



# Generated at 2022-06-22 05:38:24.887976
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    pos1 = Position(1, 1, 1)
    pos2 = Position(1, 1, 1)
    pos3 = Position(2, 1, 1)
    pos4 = Position(1, 2, 1)
    pos5 = Position(1, 1, 2)
    assert pos1 == pos1
    assert pos1 == pos2
    assert pos1 != pos3
    assert pos1 != pos4
    assert pos1 != pos5
    #assert not pos1 == pos3
    #assert not pos1 == pos4
    #assert not pos1 == pos5



# Generated at 2022-06-22 05:38:26.479017
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    error= BaseError()
    assert len(error) == 0
    return

# Generated at 2022-06-22 05:38:40.250734
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    a=BaseError(text='ValidationError: 2 errors found.\n', code='ValidationError')
    assert str(a) == 'ValidationError: 2 errors found.'



# Generated at 2022-06-22 05:38:46.007812
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    error = ValidationError(text="hello")
    assert str(error) == "hello"
    assert str(error) == error.text

    error = ValidationError(
        messages=[Message(text="hello", index=["name"]), Message(text="world")]
    )
    assert str(error) == "{'name': 'hello', '': 'world'}"

# Generated at 2022-06-22 05:38:51.474784
# Unit test for constructor of class Position
def test_Position():
    assert Position(line_no=1, column_no=2, char_index=3) == Position(
        line_no=1, column_no=2, char_index=3
    )
    assert Position(line_no=1, column_no=2, char_index=3) == Position(
        line_no=1, column_no=2, char_index=3
    )



# Generated at 2022-06-22 05:38:56.685249
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    value1 = ValidationResult(value=1)
    assert next(iter(value1)) == 1
    assert next(iter(value1)) is None

    error1 = ValidationResult(error='error')
    assert next(iter(error1)) is None
    assert next(iter(error1)) == 'error'

# Generated at 2022-06-22 05:39:06.838241
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    """
    Test method '__str__' from class 'BaseError'
    """
    print("\nTesting method '__str__' from class 'BaseError'.\n")
    class_name = str(BaseError)
    print(f"\nType of class: {class_name}.")
    print(f"Each instance has the following attributes: text, code, key, messages, index.")
    print("\nLet's test the method '__str__' ...")
    input_string = "Jane Smith"

# Generated at 2022-06-22 05:39:19.470669
# Unit test for constructor of class Message
def test_Message():
    msg = Message(
        text="spam",
        code="bad_instruction",
        key="instruction",
        index=["cmd", "instruction"],
        position=Position(1,1,1),
        start_position=Position(1,1,1),
        end_position=Position(1,1,1),
    )
    assert msg.text == "spam" and msg.code == "bad_instruction" and msg.index == ["cmd", "instruction"]
    assert msg.start_position == msg.end_position == msg.position == Position(1,1,1)


# Generated at 2022-06-22 05:39:25.289461
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    line_no = 1
    column_no = 2
    char_index = 3
    position = Position(line_no, column_no, char_index)
    assert repr(position) == 'Position(line_no=1, column_no=2, char_index=3)'

# Generated at 2022-06-22 05:39:28.988695
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert list(ValidationResult(value=[1, 2, 3])) == [([1, 2, 3], None)]
    assert list(ValidationResult(error=ValidationError(text="Hello"))) == [None, ValidationError(text="Hello")]



# Generated at 2022-06-22 05:39:31.247094
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    assert not ValidationResult(error=ValidationError(text='error message'))



# Generated at 2022-06-22 05:39:35.272890
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    tst = ValidationResult(value=10)
    assert tst.__repr__() == "ValidationResult(value=10)"
    tst = ValidationResult(error="error")
    assert tst.__repr__() == 'ValidationResult(error="error")'

