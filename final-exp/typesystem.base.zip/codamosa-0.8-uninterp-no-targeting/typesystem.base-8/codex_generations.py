

# Generated at 2022-06-22 05:33:13.802138
# Unit test for constructor of class BaseError
def test_BaseError():
    error = BaseError(text = 'May not have more than 100 characters', code = 'max_length', key = 'username')
    assert error._messages == [Message(text = 'May not have more than 100 characters', code = 'max_length', index = ['username'])]



# Generated at 2022-06-22 05:33:17.745753
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    assert ValidationResult(value=0).__bool__() == True
    assert ValidationResult(error=ValidationError()).__bool__() == False


# Generated at 2022-06-22 05:33:26.396151
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    a = BaseError(text="text", code="code", key="key")
    a_same = BaseError(text="text", code="code", key="key")
    a_different = BaseError(text="text", code="code_different", key="key")
    a_different_2 = BaseError(text="text_different", code="code", key="key")
    a_different_3 = BaseError(text="text", code="code", key="key_different")
    b = BaseError(messages=[Message(text="text", key=["key"])])
    b_same = BaseError(messages=[Message(text="text", key=["key"])])
    b_different_1 = BaseError(messages=[Message(text="text", key=["key_different"])])
    b_different_2 = BaseError

# Generated at 2022-06-22 05:33:27.882749
# Unit test for constructor of class ValidationError
def test_ValidationError():
    err = ValidationError()
    return err.messages


# Generated at 2022-06-22 05:33:33.339948
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    message_list = [Message(text='message_text')]
    test_BaseError = BaseError(messages=message_list)
    # Check the result is the class name and the attribute 'text'
    assert test_BaseError.__repr__() == "BaseError([Message(text='message_text', code='custom', index=[])])"
    return



# Generated at 2022-06-22 05:33:37.737861
# Unit test for constructor of class Position
def test_Position():
    a = Position(4, 16, 28)
    print("Object a is :", a)
    b = Position(4, 16, 28)
    print("Object b is :", b)


# Generated at 2022-06-22 05:33:46.476454
# Unit test for method __repr__ of class Message
def test_Message___repr__():

    # Test 1
    message1 = Message(text='fake text', code='fake code', key='fake key', position=Position(1, 2, 3))
    assert repr(message1) == 'Message(text=\'fake text\', code=\'fake code\', key=\'fake key\', position=Position(line_no=1, column_no=2, char_index=3))'

    # Test 2
    message2 = Message(text='fake text', code='fake code', start_position=Position(1, 2, 3), end_position=Position(4, 5, 6))

# Generated at 2022-06-22 05:33:50.222806
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    error = BaseError(
        text='May not have more than 100 characters',
        code='max_length',
        key='name',
        position=Position(1, 1, 2)
    )
    assert error['name'] == 'May not have more than 100 characters'

# Generated at 2022-06-22 05:33:59.108997
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    """ Unit test for method __repr__ of class BaseError  """
    messages = [
        Message(
            text="Text1",
            key='Message1',
            code='Code1',
            index=None,
            position=None,
            start_position=None,
            end_position=None
        )
    ]
    test_class = BaseError(messages=messages)

    assert repr(test_class) == "BaseError([Message(text='Text1', code='Code1', index=['Message1'])])"


# Generated at 2022-06-22 05:34:02.186782
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    result = BaseError(code="test").__iter__()
    assert isinstance(result, typing.Iterator)
    assert result == iter([])


# Generated at 2022-06-22 05:34:25.792224
# Unit test for constructor of class ValidationError
def test_ValidationError():
    # Given
    error_message_1 = 'Error message 1'
    error_code_1 = 'error_code_1'
    key_1 = 'key_1'
    error_message_2 = 'Error message 2'
    error_code_2 = 'error_code_2'
    key_2 = 'key_2'
    messages = [
        Message(text=error_message_1, code=error_code_1, key=key_1),
        Message(text=error_message_2, code=error_code_2, key=key_2),
    ]
    expected = {key_1: error_message_1, key_2: error_message_2}

    # When
    validationError = ValidationError(messages=messages)

    # Then

# Generated at 2022-06-22 05:34:29.936952
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    """
    Method _Message___eq___ is tested
    """
    print("test_Message___eq__")
    a = Message(text="s", code="s", key="s", index="s")
    b = Message(text="s", code="s", key="s", index="s")
    assert a == b


# Generated at 2022-06-22 05:34:35.797820
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    error = ValidationError(text="Error from BaseError")
    print(error.messages())
    error = ValidationError(messages=[Message(text="Error from BaseError")])
    print(error.messages())
    print(error)
    print(Message(text="Error from BaseError"))


if __name__ == '__main__':
    test_BaseError_messages()

# Generated at 2022-06-22 05:34:41.070552
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    try:
        raise BaseError(messages=[Message(text="text", code="code", index=[])])
    except BaseError as e:
        assert e.messages()[0].text == "text"
        assert e.messages(add_prefix="index")[0].index[0] == "index"
    else:
        assert False, "No exception raised"

# Generated at 2022-06-22 05:34:52.661310
# Unit test for constructor of class ValidationError
def test_ValidationError():
    text = "May not have more than 100 characters"
    code = "max_length"
    key = 'test'
    # Set up a default error message
    message = Message(text=text, code=code, key=key)
    error = ValidationError(messages=[message])
    assert error.messages() == [message]
    assert len(error) == 1
    assert error[key] == text
    assert list(iter(error)) == [key]

    # Set up partial error message
    error = ValidationError(text=text, code=code, key=key)
    assert error.messages() == [message]
    assert len(error) == 1
    assert error[key] == text
    assert list(iter(error)) == [key]

# Generated at 2022-06-22 05:34:56.364261
# Unit test for constructor of class BaseError
def test_BaseError():
    error = BaseError(text='Error : Price should be greater than 1000', code='max_length')

    assert error.text == 'Error : Price should be greater than 1000'
    assert error.code == 'max_length'


# Generated at 2022-06-22 05:35:09.093253
# Unit test for constructor of class ValidationError
def test_ValidationError():
    assert ValidationError(text="test_text", code="test_code", key="test_key") == \
           ValidationError(messages=[Message(text="test_text", code="test_code", key="test_key")])
    assert ValidationError(messages=[Message(text="test_text", code="test_code", key="test_key")]) == \
           ValidationError(messages=[Message(text="test_text", code="test_code", key="test_key")])
    assert ValidationError(messages=[Message(text="test_text", code="test_code", key="test_key")]) != \
           ValidationError(messages=[Message(text="test_text", code="test_code1", key="test_key1")])

# Generated at 2022-06-22 05:35:13.262620
# Unit test for constructor of class ValidationError
def test_ValidationError():
    error1 = ValidationError(text="1")
    error2 = ValidationError(text="2")
    error3 = ValidationError(messages=[error1, error2])
    assert dict(error3) == {"": ["1", "2"]}



# Generated at 2022-06-22 05:35:19.029403
# Unit test for constructor of class ParseError
def test_ParseError():
    text = "Parse Error."
    code = "a_code_01"
    key = "myKey"
    position = Position(line_no=1, column_no=2, char_index=6)
    messages = [Message(text=text, code=code, key=key, position=position)]

    err = ParseError(text=text, code=code, key=key, position=position)
    assert err.messages() == messages

    err = ParseError(messages=messages)
    assert err.messages() == messages
    # assert err.messages() == [Message(text="Parse Error.", code="a_code_01", key="myKey", position=Position(line_no=1, column_no=2, char_index=6))]


# Generated at 2022-06-22 05:35:23.483402
# Unit test for constructor of class BaseError
def test_BaseError():
    try:
        BaseError(text='hello', code='max')
    except:
        pass

    try:
        BaseError(messages=[Message(text='hello', code='max')])
    except:
        pass



# Generated at 2022-06-22 05:35:40.504620
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    # When schemas is not a list, then an assertion error should be raised
    try:
        schema = ValidationError(messages=[Message(text="text")])
        assert False
    except AssertionError:
        assert True

# Generated at 2022-06-22 05:35:51.066228
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    t = Message(text='a', code='b', index=[1], position=Position(0,0,0))
    assert hash(t) == hash(t)
    t1 = Message(text='a', code='b', index=[1, 1], position=Position(0,0,0))
    assert hash(t) != hash(t1)
    t2 = Message(text='a', code='b', index=[1], position=Position(0,0,0))
    assert hash(t) == hash(t2)
    t3 = Message(text='a', code='c', index=[1], position=Position(0,0,0))
    assert hash(t) != hash(t3)
    t4 = Message(text='a', code='c', index=[1, 1], position=Position(0,0,0))


# Generated at 2022-06-22 05:35:56.619494
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    # Scenario: If there are multiple messages, the string representation is a JSON object.
    # Given a BaseError with two messages - one with no index and one with an index
    berr = BaseError(messages=[
        Message(text='error message 1', code='err1'),
        Message(text='error message 2', code='err2', index=['key1', 'key2']),
    ])
    # And a BaseError with no messages
    berr2 = BaseError(messages=[])
    # Then the string representation of the BaseErrors is a JSON object
    assert berr.__str__() == '{"": "error message 1", "key1": {"key2": "error message 2"}}'
    assert berr2.__str__() == '{}'

    # Scenario: If there is only one message with no index,

# Generated at 2022-06-22 05:36:02.041058
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    error = ValidationError(
        messages=[
            Message(text="One", code="code1", key="key1"),
            Message(text="Two", code="code2", key="key2"),
            Message(text="Three", code="code3", key="key3"),
        ]
    )
    assert len(error) == 3

# Generated at 2022-06-22 05:36:09.562867
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    error = BaseError(text="message", code='code', key='key', position=Position(line_no=1, column_no=2, char_index=3))
    from pprint import pprint
    pprint(error.messages())
    assert error.messages() == [Message(text="message", code='code', key='key', position=Position(line_no=1, column_no=2, char_index=3))]

# Test __eq__ implementation

# Generated at 2022-06-22 05:36:10.597471
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    error = BaseError(messages=[Message(text="foo")])
    assert bool(error) is True
    assert dict(error) == {}



# Generated at 2022-06-22 05:36:17.529425
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert(BaseError(text="text", code="code", key="key", position=Position(1,1,1))==BaseError(text="text", code="code", key="key", position=Position(1,1,1)))
    assert(BaseError(text="text", code="code", key="key", position=Position(1,1,1))==BaseError(text="text", code="code", key="key"))
    assert(BaseError(text="text", code="code", key="key", position=Position(1,1,1))==BaseError(text="text", code="code", position=Position(1,1,1)))
    assert(BaseError(text="text", code="code", key="key", position=Position(1,1,1))==BaseError(text="text", position=Position(1,1,1)))
   

# Generated at 2022-06-22 05:36:23.934805
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    error1 = BaseError(text='error message', code='code', key=1)
    error2 = BaseError(messages=[Message(text='error message', code='code', key=1)])
    error3 = BaseError(messages=[Message(text='error message', code='code', index=['users', 1, 'username'])])
    assert error1 == error2
    assert error2 == error3



# Generated at 2022-06-22 05:36:35.088744
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    var = '''
    def __repr__(self) -> str:
        class_name = self.__class__.__name__
        index_str = f", index={self.index!r}" if self.index else ""
        if self.start_position is None:
            position_str = ""
        elif self.start_position == self.end_position:
            position_str = f", position={self.start_position!r}"
        else:
            position_str = f", start_position={self.start_position!r}, end_position={self.end_position!r}"
        return f"{class_name}(text={self.text!r}, code={self.code!r}{index_str}{position_str})"
    '''
    # 测试字符串


# Generated at 2022-06-22 05:36:46.930673
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    position1 = Position(line_no=1, column_no=2, char_index=3)
    position2 = Position(line_no=1, column_no=2, char_index=3)
    position3 = Position(line_no=1, column_no=2, char_index=4)
    position4 = Position(line_no=1, column_no=3, char_index=3)
    position5 = Position(line_no=2, column_no=2, char_index=3)
    result = position1 == position2
    assert result is True
    result = position1 == position3
    assert result is False
    result = position1 == position4
    assert result is False
    result = position1 == position5
    assert result is False


# Generated at 2022-06-22 05:37:09.994768
# Unit test for constructor of class ValidationError
def test_ValidationError():
    validationError = ValidationError(text="Hola que tal", code="custom", key="0", position=Position(0, 0, 0))
    assert validationError.text == "Hola que tal"
    assert validationError.code == "custom"
    assert validationError.key == "0"
    assert validationError.position.line_no == 0
    assert validationError.position.column_no == 0
    assert validationError.position.char_index == 0


# Generated at 2022-06-22 05:37:20.201811
# Unit test for constructor of class Message
def test_Message():
    assert Message(
        text="OK", code="custom", index=["a", 1, "b"], position=Position(1, 2, 3)
    ) == Message(
        text="OK",
        code="custom",
        start_position=Position(1, 2, 3),
        end_position=Position(1, 2, 3),
        index=["a", 1, "b"],
    )

    with pytest.raises(AssertionError):
        Message(text="OK", key="a", index=["a", 1, "b"])

    with pytest.raises(AssertionError):
        Message(text="OK", position=Position(1, 2, 3), start_position=Position(1, 2, 3))


# Generated at 2022-06-22 05:37:25.837938
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    vr = ValidationResult(value=10)
    assert repr(vr)=="ValidationResult(value=10)"
    vr = ValidationResult(error=ValidationError())
    assert repr(vr)=="ValidationResult(error=ValidationError([Message(text='', code='custom')]))"

# Generated at 2022-06-22 05:37:33.186807
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Test for a Message instantiated with a single error message
    msg = Message(text = "", code = "", key = "", index = [], position = Position(1, 2, 3))
    assert msg == msg
    assert msg != "somestring"
    msg2 = Message(text = "", code = "", key = "", index = [], position = Position(1, 2, 3))
    assert msg == msg2


# Generated at 2022-06-22 05:37:37.901562
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    # Given
    testee = Position(line_no=2, column_no=3, char_index=4)

    # When
    result = testee.__repr__()

    # Then
    assert result == "Position(line_no=2, column_no=3, char_index=4)"


# Generated at 2022-06-22 05:37:44.048682
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    # Given
    line_no=1
    column_no=2
    char_index=3
    position=Position(line_no=line_no,column_no=column_no,char_index=char_index)
    # When
    position_repr=repr(position)
    #Then
    assert position_repr=="Position(line_no=1, column_no=2, char_index=3)"


# Generated at 2022-06-22 05:37:51.828233
# Unit test for constructor of class ValidationError
def test_ValidationError():
    ValidationError(text='Illegal value', code='not_in_enum', key='password')
    ValidationError(text='May not be empty', code='required', key='roles', index=['users', 3])
    ValidationError(messages=[
        Message(text='May not be empty', code='required', key='roles'),
        Message(text='May not be empty', code='required', key='username'),
    ])


# Generated at 2022-06-22 05:37:54.174961
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    result = ValidationResult(value=1)
    assert repr(result) == 'ValidationResult(value=1)'
    result = ValidationResult(error=ParseError(text='a'))
    assert repr(result) == "ValidationResult(error=ParseError(text='a'))"


# Generated at 2022-06-22 05:38:01.647346
# Unit test for constructor of class Message
def test_Message():
    msg = Message(text="hi", code=None, key=None, index=[], position=None, start_position=None, end_position=None)
    assert msg.text == 'hi'
    assert msg.code == "custom"
    assert list(msg.index) == []
    assert msg.start_position == None
    assert msg.end_position == None
    assert repr(msg) == "Message(text='hi', code='custom')"
# Unit test end


# Generated at 2022-06-22 05:38:04.608387
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    print(ValidationResult())
    print(ValidationResult(value = 5))
    print(ValidationResult(error = "error"))


# Generated at 2022-06-22 05:38:35.162009
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # Given
    value = "value"

    # When
    result = ValidationResult(value=value)
    out = [i for i in result]

    # Then
    assert out == [value,None]



# Generated at 2022-06-22 05:38:44.225942
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    r'''Attributes, 'code' and 'index', of class Message are used to calculate the hash value.
    '''
    msg = Message(text='some_text', code='some_code', index=['some_index'])
    msg_hash = hash(msg)
    assert msg_hash == hash(msg)
    code_value = 'some_code'
    index_value = ['some_index']
    msg2 = Message(text='some_text', code=code_value, index=index_value)
    msg_hash2 = hash(msg2)
    assert msg_hash2 == hash(msg2)
    msg.code = 'some_other_code'
    msg_hash_changed = hash(msg)
    assert msg_hash_changed != hash(msg)
    assert msg_hash_changed != hash(msg2)

# Generated at 2022-06-22 05:38:47.766922
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    a = Message(text='error message', code='custom', key='name', position=None, start_position=None, end_position=None)
    print(a)
    assert a == eval(repr(a))
    

# Generated at 2022-06-22 05:38:59.203554
# Unit test for constructor of class ValidationError
def test_ValidationError():
    # Create ValidationError by passing in parameters
    validation_error1 = ValidationError(text = "message1", code = "error code1", key = 0)
    assert validation_error1._messages[0].text == 'message1'
    assert validation_error1._messages[0].code == 'error code1'
    assert validation_error1._messages[0].index == [0]

    # Check return type of 'messages' method
    messages = validation_error1.messages()
    assert isinstance(messages, list)

    # Check 'messages' method returns the expected list of messages
    message = messages[0]
    assert message.text == 'message1'
    assert message.code == 'error code1'
    assert message.index == [0]

    # Create ValidationError by passing in a list of

# Generated at 2022-06-22 05:39:02.196883
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    position = Position(1,1,7)
    assert repr(position) == 'Position(line_no=1, column_no=1, char_index=7)'


# Generated at 2022-06-22 05:39:07.102606
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    error = BaseError(text = 'Test error')
    assert str(error) == 'Test error'

    error = BaseError(messages = [Message(text = 'Test error')])
    assert str(error) == "{'': 'Test error'}"


# Generated at 2022-06-22 05:39:14.563697
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    message = Message(
        text="Foo",
        code="bar",
        key=42,
        start_position=Position(42, 42, 42),
        end_position=Position(42, 42, 43),
    )
    assert hash(message) == hash(("bar", (42,)))
    assert hash(message) == hash(Message(**message.__dict__))


# Generated at 2022-06-22 05:39:16.183171
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    # TODO: define test
    pass


# Generated at 2022-06-22 05:39:28.236568
# Unit test for constructor of class ParseError
def test_ParseError():
    line_no = 1
    column_no = 5
    char_index = 7
    data = '{"a": True, "b": "hello", "c": [1,2,3]}'
    pos = Position(line_no, column_no, char_index)
    msg = 'test message'
    assert ParseError(text=msg, position=pos) == ParseError(text=msg, start_position=pos, end_position=pos)
    assert ParseError(text=msg, position=pos) == ParseError(text=msg, start_position=pos)
    assert ParseError(text=msg, position=pos) == ParseError(text=msg, end_position=pos)

    test_obj = ParseError(text=msg, position=pos)
    assert test_obj.start_position == test

# Generated at 2022-06-22 05:39:33.970573
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    # test for val
    test_result = ValidationResult(value=1)
    assert test_result.value == 1
    assert test_result.error == None

    # test for err
    test_result = ValidationResult(error=ValidationError())
    assert test_result.value == None
    assert test_result.error != None

# Generated at 2022-06-22 05:41:00.794020
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    String = String(maxLength=100)
    String.validate("1234567890")



# Generated at 2022-06-22 05:41:07.217600
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    from typesystem import Schema, types
    from typesystem.error import ValidationError
    from typesystem.error import BaseError

    class MySchema(Schema):
        number = types.Integer()
        name = types.String(max_length=100)

    data = {"number": 1, "name": "A"}
    error = ValidationError(
        code="max_length", text="Must not have more than 100 characters.", key="name",
    )
    my_schema = MySchema()

    assert len(error) == 1
    assert error._messages == [error.messages()[0]]
    assert error.messages()[0].index
    assert error.messages()[0].index == ["name"]
    assert error._message_dict == {"name": error.messages()[0].text}
   

# Generated at 2022-06-22 05:41:16.728756
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    error = BaseError(text="Error message 1", code="custom", key="message1")
    assert repr(error) == "BaseError(text='Error message 1', code='custom')"

    error = BaseError(text="Error message 1", key="message1")
    assert repr(error) == "BaseError(text='Error message 1', code='custom')"

    error = BaseError(messages=[
        Message(text="Error message 1", code="custom1", key="message1", index=["message1"]),
        Message(text="Error message 2", code="max_length", key="message2", index=["message2"]),
        Message(text="Error message 3", code="max_length", key="message3", index=["message3"]),
    ])

# Generated at 2022-06-22 05:41:19.311346
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert ValidationError(text="text1", code="code1") == ValidationError(text="text1", code="code1")


# Generated at 2022-06-22 05:41:28.846989
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    e = BaseError()
    assert str(e) == ""
    e = BaseError(text="Oh noes")
    assert str(e) == "Oh noes"
    e = BaseError(messages=[Message(text="Oh noes")])
    assert str(e) == "Oh noes"
    e = BaseError(messages=[Message(text="Oh noes", key='message')])
    assert str(e) == "{'message': 'Oh noes'}"
    e = BaseError(messages=[Message(text="Oh noes", index=['message'])])
    assert str(e) == "{'message': 'Oh noes'}"
    e = BaseError(messages=[Message(text="Oh noes", index=['message', 0, 'error'])])

# Generated at 2022-06-22 05:41:34.639401
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    validate_BaseError___len__(BaseError(text='val', code='val', key='val'))
    validate_BaseError___len__(BaseError(messages=[Message(text='val', code='val', index=['val'])]))
    validate_BaseError___len__(
        BaseError(messages=[Message(text='val', code='val', key='val')])
    )


# Generated at 2022-06-22 05:41:44.257623
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    m1 = Message(text='May not have more than 100 characters', code='max_length', key='username')
    m2 = Message(text='May not have more than 100 characters', code='max_length', key='password')
    be1 = BaseError(messages=[m1])
    be2 = BaseError(messages=[m1])
    be3 = BaseError(messages=[m2])
    be4 = BaseError(messages=[m1, m2])
    be5 = BaseError(messages=[m2, m1])
    assert be1 == be1
    assert be1 == be2
    assert be1 != be3
    assert be1 != be4
    assert be1 != be5
    assert be3 == be3
    assert be3 != be4
    assert be3 != be5

# Generated at 2022-06-22 05:41:56.397011
# Unit test for constructor of class BaseError
def test_BaseError():

    messages = [Message(text='text', code='code', key='key', position=Position(1,2,3))]

    with pytest.raises(AssertionError):
        BaseError(text='text', code='code', key='key', position=Position(1,2,3))

    assert BaseError(messages=messages) == BaseError(messages=messages)
    assert BaseError(messages=messages) != BaseError(messages=messages[::-1])
    b1 = BaseError(messages=messages)
    b2 = BaseError(messages=messages)
    assert hash(b1)==hash(b2)
    assert b1 == b2

    assert b1.messages() == messages

# Generated at 2022-06-22 05:42:00.050423
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    position = Position(line_no=2, column_no=3, char_index=4)
    repr_value = repr(position)

    assert repr_value == "Position(line_no=2, column_no=3, char_index=4)"



# Generated at 2022-06-22 05:42:05.338621
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    # No error messages
    error = BaseError()
    assert not hash(error)

    # Single error message
    error = BaseError(key="my-key", text="my-text")
    assert not hash(error)

    # Multiple error messages
    error = BaseError(messages=[Message(key="key1", text="text1"), Message(text="text2")])
    assert hash(error)