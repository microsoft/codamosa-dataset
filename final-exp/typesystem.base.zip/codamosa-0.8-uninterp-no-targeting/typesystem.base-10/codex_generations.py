

# Generated at 2022-06-22 05:33:12.660942
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    messages = [Message(text="a"), Message(text="b"), Message(text="c"), Message(text="d")]
    error = BaseError(messages=messages)
    assert ["a", "b", "c", "d"] == list(iter(error))
    
    

# Generated at 2022-06-22 05:33:24.282758
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    from typesystem.message import Message
    a1 = Message(text="a", code="b", index=[])
    a2 = Message(text="a", code="b", index=[])
    b = Message(text="a", code="c", index=[])
    c = Message(text="a", code="b", index=["d"])
    d = Message(text="a", start_position=Position(line_no=1, column_no=1, char_index=1), end_position=Position(line_no=1, column_no=1, char_index=2))
    e = Message(text="a", start_position=Position(line_no=1, column_no=1, char_index=1), end_position=Position(line_no=1, column_no=1, char_index=3))
   

# Generated at 2022-06-22 05:33:27.620943
# Unit test for constructor of class Position
def test_Position():
    position = Position(line_no=2, column_no=1, char_index=4)
    assert position.line_no == 2
    assert position.column_no == 1
    assert position.char_index == 4



# Generated at 2022-06-22 05:33:35.434726
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    assert hash(ValidationError(messages=[Message(text="Text", code="Code", key="Key")]))
    assert hash(ValidationError(messages=[Message(text="Text", code="Code", key="Key")])) == hash(ValidationError(messages=[Message(text="Text", code="Code", key="Key")]))
    assert hash(ValidationError(messages=[Message(text="Text", code="Code", key="Key")])) != hash(ValidationError(messages=[Message(text="Text", code="Code2", key="Key2")]))


# Generated at 2022-06-22 05:33:46.552804
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text='hello', code=None, key=None, index=None, position=None, start_position=Position(1, 2, 3), end_position=Position(4, 5, 6)) == Message(text='hello', code=None, key=None, index=None, position=None, start_position=Position(1, 2, 3), end_position=Position(4, 5, 6))
    assert not (Message(text='hello', code=None, key=None, index=None, position=None, start_position=Position(1, 2, 3), end_position=Position(4, 5, 6)) == Message(text='hello', code=None, key=None, index=None, position=None, start_position=Position(1, 2, 3), end_position=Position(4, 5, 7)))

# Generated at 2022-06-22 05:33:51.658456
# Unit test for constructor of class ParseError
def test_ParseError():
    parse_error = ParseError(text="test", code="test_code", key="test_key")
    for message in parse_error.messages():
        assert message.text == "test"
        assert message.code == "test_code"
        assert message.index == ["test_key"]
        assert message.start_position is None
        assert message.end_position is None


# Generated at 2022-06-22 05:33:52.492758
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    hash(BaseError())

# Generated at 2022-06-22 05:34:04.221383
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    # Test a single error, with no index
    error = ValidationError(text="text", code="code")
    assert error.messages() == [Message(text="text", code="code")]
    assert error.messages(add_prefix=1) == [Message(text="text", code="code", index=[1])]
    assert error.messages(add_prefix="add_prefix") == [Message(text="text", code="code", index=["add_prefix"])]

    # Test multiple errors, with and without index

# Generated at 2022-06-22 05:34:12.684017
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    # Assert correct repr without index
    message = Message(text="May not have more than 100 characters", code="max_length")
    assert repr(message) == 'Message(text=\'May not have more than 100 characters\', code=\'max_length\')'
    # Assert correct repr with index
    message = Message(text="May not have more than 100 characters", code="max_length", index=['username'])
    assert repr(message) == 'Message(text=\'May not have more than 100 characters\', code=\'max_length\', index=[\'username\'])'


# Generated at 2022-06-22 05:34:21.584148
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    class_name = 'ValidationResult'
    value = mock.Mock()
    error = mock.Mock()
    value.__repr__ = mock.MagicMock(return_value='value')
    error.__repr__ = mock.MagicMock(return_value='error')
    value_str = f"{class_name}(value={value!r})"
    error_str = f"{class_name}(error={error!r})"
    validation_result = ValidationResult(value=value)
    assert validation_result.__repr__() == value_str
    validation_result = ValidationResult(error=error)
    assert validation_result.__repr__() == error_str



# Generated at 2022-06-22 05:34:37.359324
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    res1 = ValidationResult(value=2)
    assert list(res1) == [2, None]
    res2 = ValidationResult(error=ValidationError())
    assert list(res2) == [None, ValidationError()]


# Generated at 2022-06-22 05:34:39.227018
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    assert repr(BaseError(text="Invalid")) == "BaseError(text='Invalid', code='custom')"


# Generated at 2022-06-22 05:34:42.549230
# Unit test for constructor of class Position
def test_Position():
    import doctest
    doctest.testmod(verbose=True)


# Generated at 2022-06-22 05:34:45.836674
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    result = ValidationResult(value='data')
    assert bool(result) == True
    result = ValidationResult(error='error')
    assert bool(result) == False

# Generated at 2022-06-22 05:34:53.794871
# Unit test for constructor of class Message
def test_Message():
    error = Message(
        text="May not have more than 100 characters.",
        code='max_length',
        key='username',
        start_position=Position(1,1,1),
        end_position=Position(2,2,3)
    )
    assert isinstance(error, Message)
    assert error.text == "May not have more than 100 characters."
    assert error.code == 'max_length'
    assert error.index == ['username']
    assert error.start_position == Position(1,1,1)
    assert error.end_position == Position(2,2,3)


# Generated at 2022-06-22 05:35:02.729084
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    # Should return the number of error messages
    e = ValidationError(text='Error 1', key='key1')
    assert len(e) == 1

    e = ValidationError(text='Error 1', key='key1') + ValidationError(text='Error 2', key='key2')
    assert len(e) == 2

    # Should return the total number of error messages across all indexes
    e = ValidationError(text='Error 1', key='key1') + ValidationError(text='Error 2', key='key1')
    assert len(e) == 2

    e = ValidationError(text='Error 1', key='key1') + ValidationError(text='Error 2', key='key1/key2')
    assert len(e) == 2

    # Should work for ValidationError and ParseError
    e = ValidationError

# Generated at 2022-06-22 05:35:07.226108
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    repr_ = repr(Position(line_no = 1, column_no = 2, char_index = 3))
    assert repr_ == "Position(line_no=1, column_no=2, char_index=3)"


# Generated at 2022-06-22 05:35:11.519727
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    assert repr(ValidationResult(value=1)) == "ValidationResult(value=1)"
    assert repr(ValidationResult(error=ValidationError())) == "ValidationResult(error=ValidationError({}))"
test_ValidationResult___repr__()



# Generated at 2022-06-22 05:35:14.566008
# Unit test for method __eq__ of class Position
def test_Position___eq__():
	p1 = Position(1, 2, 3)
	p2 = Position(1, 2, 3)
	is_equal = p1 == p2
	assert is_equal == True


# Generated at 2022-06-22 05:35:18.623672
# Unit test for constructor of class Message
def test_Message():
    message = Message(text="text", code="code", key="key", index=[1, 2, 3])
    expected_message = Message(text="text", code="code", index=[1, 2, 3, "key"])
    assert message == expected_message
    assert isinstance(message, Message)


# Generated at 2022-06-22 05:35:31.560970
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    pos1 = Position(1, 2, 3)
    pos2 = Position(1, 2, 3)
    assert pos1 == pos2



# Generated at 2022-06-22 05:35:43.570349
# Unit test for constructor of class Message
def test_Message():
    position = Position(line_no=0, column_no=1, char_index=2)
    start_position = Position(line_no=0, column_no=1, char_index=2)
    end_position = Position(line_no=0, column_no=1, char_index=2)

    # test 1
    message = Message(text='abc', code='abc', key='abc', index=['abc'], \
        position=position, start_position=start_position, end_position=end_position)
    assert message.text == 'abc'
    assert message.code == 'abc'
    assert message.index == ['abc']
    assert message.start_position == position
    assert message.end_position == position

    # test 2

# Generated at 2022-06-22 05:35:48.819413
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    import pytest
    from hypothesis import given, settings
    from .strategies import messages

    @given(messages())
    @settings(max_examples=300, deadline=None)
    def _test(messages):
        error = BaseError(messages=messages)
        assert error == BaseError(messages=messages)
        assert not error != BaseError(messages=messages)

    _test()



# Generated at 2022-06-22 05:35:52.764955
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    error = BaseError(messages=[Message()])
    error2 = BaseError(messages=[Message()])
    assert error is not error2
    assert error == error2
    assert hash(error) == hash(error2)



# Generated at 2022-06-22 05:36:05.169962
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    # Test that identical Message instances have the same hash value
    # Test1
    message_1 = Message(
        text='May not have more than 100 characters',
        code='max_length',
        key=123,
        index=[1, 2, 3],
        position=Position(line_no=1, column_no=1, char_index=1),
        start_position=Position(line_no=1, column_no=1, char_index=1),
        end_position=Position(line_no=1, column_no=1, char_index=1),
    )

# Generated at 2022-06-22 05:36:12.558221
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    a = BaseError(text=0, code=1, key=2)
    b = BaseError(messages=[2, 1, 0])
    assert repr(a) == "BaseError(text=0, code=1, key=2)"
    assert repr(b) == "BaseError([2, 1, 0])"

# Generated at 2022-06-22 05:36:16.119564
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    error_text = 'Los datos no son correctos'
    messages = [Message(text=error_text, code='wrong_data')]
    error = BaseError(messages=messages)

    assert error.messages() == messages
    assert error.messages(add_prefix="users") == [
        Message(text=error_text, code='wrong_data', index=["users"])
    ]

# Generated at 2022-06-22 05:36:27.574385
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    messages = [
        Message(text="A text"),
        Message(text="B text", key="custom key"),
        Message(text="C text", key="custom key"),
    ]
    error = BaseError(messages=messages)
    messages_as_dict = {
        "": "A text",
        "custom key": [
            "B text",
            "C text",
        ],
    }
    assert list(error) == list(messages_as_dict)
    assert sorted(error.keys()) == sorted(messages_as_dict.keys())
    assert sorted(error.values()) == sorted(messages_as_dict.values())
    assert sorted(error.items()) == sorted(messages_as_dict.items())
    assert set(error) == set(messages_as_dict)

# Generated at 2022-06-22 05:36:33.581678
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='Some text', code='custom', index=[1, 2, 3], position=Position(1, 1, 1))
    message2 = Message(text='Some text', code='custom', index=[1, 2, 3], position=Position(1, 1, 1))
    assert message1 == message2


# Generated at 2022-06-22 05:36:35.953679
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    class Mock(Message):
        pass

    m1 = Mock(code='test', index=[])
    expected = hash((m1.code, tuple(m1.index)))
    actual = hash(m1)
    assert actual == expected

# Generated at 2022-06-22 05:37:07.233969
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    error = BaseError(messages=[Message(text='foo'), Message(text='bar')])
    assert error.messages() == [Message(text='foo'), Message(text='bar')]
    assert error.messages(add_prefix='foo') == [
        Message(text='foo', index=['foo']), Message(text='bar', index=['foo'])
    ]


if __name__ == '__main__':
    test_BaseError_messages()

# Generated at 2022-06-22 05:37:16.318843
# Unit test for constructor of class ValidationError
def test_ValidationError():
    # Test with only one error message
    error = ValidationError(text="May not have more than 100 characters", code="max_length", key="username")
    assert isinstance(error, ValidationError)
    assert len(error) == 1
    assert error.error_messages() == [Message(text="May not have more than 100 characters", code="max_length", key="username")]
    assert error._message_dict == {"username": "May not have more than 100 characters"}
    assert dict(error) == {"username": "May not have more than 100 characters"}
    error = ValidationError(text="May not have more than 100 characters", code="max_length")
    assert isinstance(error, ValidationError)
    assert len(error) == 1

# Generated at 2022-06-22 05:37:28.196838
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    instance_1 = ValidationResult(value=None, error=None)
    assert bool(instance_1) == True
    instance_2 = ValidationResult(value='', error=None)
    assert bool(instance_2) == True
    instance_3 = ValidationResult(value=False, error=None)
    assert bool(instance_3) == True
    instance_4 = ValidationResult(value=1, error=None)
    assert bool(instance_4) == True
    instance_5 = ValidationResult(value=0, error=None)
    assert bool(instance_5) == True
    instance_6 = ValidationResult(value=None, error='')
    assert bool(instance_6) == False
    instance_7 = ValidationResult(value=None, error=False)
    assert bool(instance_7)

# Generated at 2022-06-22 05:37:30.694264
# Unit test for constructor of class BaseError
def test_BaseError():
    msg = Message(text="Missing field", code="required_field")
    err = BaseError(messages=[msg])


# Generated at 2022-06-22 05:37:32.493128
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    a = ValidationResult(value=1)
    assert [1, None] == [i for i in a], "Value is not 1!"
    b = ValidationResult(error=ValueError("Fatal Error!"))
    assert [None, ValueError("Fatal Error!")] == [i for i in b], "Error not match!"


# Generated at 2022-06-22 05:37:35.610420
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    value, error = ValidationResult(value=3)
    assert value == 3
    assert error is None
    assert bool(value == 3)
    assert bool(error is None)


# Generated at 2022-06-22 05:37:38.644642
# Unit test for constructor of class ParseError
def test_ParseError():
    print("\nTest ParseError")
    error = ParseError(text="Error1:", code="code1", key="key1")
    assert error == ParseError(messages=[Message(text="Error1:", code="code1", key="key1")])
    print(error)
    # print(Message(text="Error1:", code="code1", key="key1"))
    print(error.messages())


# Generated at 2022-06-22 05:37:43.296289
# Unit test for method __repr__ of class Position
def test_Position___repr__():

    # Arrange
    position = Position(line_no=5, column_no=11, char_index=7)

    # Act
    result = repr(position)

    # Assert
    assert result == "Position(line_no=5, column_no=11, char_index=7)"

# Generated at 2022-06-22 05:37:51.388388
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    assert (
        Message(
            text="foo",
            code="custom",
            key=None,
            index=None,
            start_position=Position(line_no=0, column_no=0, char_index=0),
        ).__repr__() == "Message(text='foo', code='custom', start_position=Position(line_no=0, column_no=0, char_index=0))"
    )


# Generated at 2022-06-22 05:37:55.009391
# Unit test for constructor of class Message
def test_Message():
    msg = Message(text="Invalid", code="max_len", key="email")
    assert isinstance(msg, Message)
    assert msg.text == "Invalid"
    assert msg.code == "max_len"
    assert msg.index == ["email"]
    assert msg.start_position is None
    assert msg.end_position is None
    return msg


# Generated at 2022-06-22 05:38:49.470981
# Unit test for method __getitem__ of class BaseError

# Generated at 2022-06-22 05:38:54.895139
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    # 1) assert BaseError(text='...').__str__() == '...'
    # assert BaseError(text='...').__str__() == '...'
    # 2) assert ValidationError(text='...').__str__() == '...'
    assert ValidationError(text='...').__str__() == '...'

# Generated at 2022-06-22 05:39:05.381522
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    # Setup
    errors = [
        BaseError(text="Invalid character"),
        BaseError(text="Invalid character", code="invalid_character"),
        BaseError(text="Invalid character", key="username"),
        BaseError(text="Invalid character", key="username", code="invalid_character"),
        BaseError(
            text="Invalid character", key="users", index=[0, "username"]
        ),
        BaseError(
            text="Invalid character",
            key="users",
            index=[0, "username"],
            code="invalid_character",
        ),
    ]
    # Exercise
    result = repr(errors[0])
    # Verify
    assert result == "BaseError(text='Invalid character')", result
    # Exercise
    result = repr(errors[1])
    # Verify

# Generated at 2022-06-22 05:39:13.738304
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    instance_1 = ValidationResult(value="some value")
    assert instance_1.value == "some value"
    assert "some value" == instance_1.value
    assert not instance_1.error
    assert instance_1.error is None
    print(instance_1)

    instance_2 = ValidationResult(error=ValidationError(text="some error message"))
    assert instance_2.error == ValidationError(text="some error message")
    assert ValidationError(text="some error message") == instance_2.error
    assert not instance_2.value
    assert instance_2.value is None
    print(instance_2)

    assert bool(instance_1)
    assert not bool(instance_2)

test_ValidationResult()

# Generated at 2022-06-22 05:39:18.081021
# Unit test for constructor of class ValidationError
def test_ValidationError():
    error = BaseError(text="text")
    assert error.messages() == [Message(text="text")]

    error = BaseError(messages=[Message(text="messages")])
    assert error.messages() == [Message(text="messages")]



# Generated at 2022-06-22 05:39:23.004983
# Unit test for constructor of class Message
def test_Message():
    msg = Message(text="hello", code="something", key="hahaha")
    assert msg.text == "hello"
    assert msg.code == "something"
    assert msg.index == ["hahaha"]


# Generated at 2022-06-22 05:39:28.190381
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
	"""Unit test for method __iter__ of class ValidationResult
	"""
	result = ValidationResult(error=ValidationError(text='message 1'))
	assert list(result) == [None, ValidationError(text='message 1')]
	result = ValidationResult(value='value')
	assert list(result) == ['value', None]


# Generated at 2022-06-22 05:39:32.993062
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    m1 = Message("Foo", code="max_length", key="bar")
    m2 = Message("Bar", code="max_length", key="bar")
    assert m1.__hash__() == m2.__hash__()

# Generated at 2022-06-22 05:39:36.857460
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    e = BaseError(text="abc", code="abc", index=[1, 2, 3], position=1)
    assert len(e) == e._message_dict



# Generated at 2022-06-22 05:39:44.615871
# Unit test for constructor of class BaseError
def test_BaseError():
    # Instantiated as a ValidationError with a single error message.
    error = BaseError(text='text',code='code',key='key')
    assert error.text == 'text' and error.code == 'code' and error.key == 'key'

    # Instantiated as a ValidationError with multiple error messages.
    error = BaseError(messages=[Message(text='text',code='code',key='key')])
    assert error.text == None and error.code == None and error.key == None

    # Assert none of the assertions have not been completed
    assert True