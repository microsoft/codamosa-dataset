

# Generated at 2022-06-22 05:33:07.490592
# Unit test for constructor of class BaseError
def test_BaseError():
    messagesDict = {
        '7': 'Username cannot be blank', 
        '8': 'This field is required', 
        '9': 'Password cannot be blank', 
        '10': 'This field is required'
    }
    messages = [Message(text=messagesDict['7'], code='custom', key='username')]
    error = ValidationError(text=messagesDict['7'], code='custom', key='username', messages=messages)
    assert error._messages == messages
    assert error._message_dict == messagesDict
    assert error == ValidationError(text=messagesDict['7'], code='custom', key='username', messages=messages)
    assert error != ValidationError(text=messagesDict['8'], code='custom', key='username', messages=messages)

# Generated at 2022-06-22 05:33:19.708794
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    error = BaseError(text='hello', key='k')
    assert repr(error) == "BaseError(text='hello', code='custom', index=['k'])"
    error = BaseError(text='hello', index=['k', 'l'])
    assert repr(error) == "BaseError(text='hello', code='custom', index=['k', 'l'])"
    error = BaseError(messages=[
        Message(text='hello', key='k'),
        Message(text='world', key='l')
    ])
    assert repr(error) == "BaseError([Message(text='hello', code='custom', index=['k']), Message(text='world', code='custom', index=['l'])])"

# Generated at 2022-06-22 05:33:27.274741
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    m1 = Message(text="the text", code="the code", index=[1, 2, 3],
             start_position=Position(1, 2, 3), end_position=Position(3, 2, 1))
    m2 = Message(text="the text", code="the code", index=[1, 2, 3],
             start_position=Position(1, 2, 3), end_position=Position(3, 2, 1))
    assert m1 == m2


# Generated at 2022-06-22 05:33:30.065702
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    assert repr(ValidationResult(error=ValidationError(text="Text"))) == "ValidationResult(error=ValidationError(text='Text', code='custom'))"

# Generated at 2022-06-22 05:33:32.923960
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    r1 = ValidationResult(value='value')
    r2 = ValidationResult(error='error')
    return (r1.value == 'value' and r2.error == 'error')

# Generated at 2022-06-22 05:33:39.970021
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    """
    Test method __iter__ of class ValidationResult
    Args:
        N/A
    Raises:
        N/A
    Returns:
        N/A
    Pre-condition:
    Post-condition:
    """
    # Set-up
    value, error = ValidationResult(value=1, error=None).__iter__()

    # Act

    # Assert
    assert value == 1
    assert error is None



# Generated at 2022-06-22 05:33:49.696100
# Unit test for constructor of class Message
def test_Message():
    print("Start test for constructor of class Message")
    m = Message(text="value is required", code="required", key="id", position = Position(1, 2, 3))
    m1 = Message(text="value is required", code="required", index=[0, 1, "id"], position = Position(1, 2, 3))
    assert m1.code == "required"
    assert m1.index == [0, 1, "id"]
    assert m1.position.line_no == 1
    assert m1.position.column_no == 2
    assert m1.position.char_index == 3
    assert m1.start_position is None
    assert m1.end_position is None
    assert m.position is not None
    assert m1.position is not None


# Generated at 2022-06-22 05:33:57.971184
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    value = ValidationError(text="text")
    assert repr(value) == "ValidationError(text='text', code='custom')"
    value = ParseError(text="text")
    assert repr(value) == "ParseError(text='text', code='custom')"
    value = BaseError(text="text")
    assert repr(value) == "BaseError(text='text', code='custom')"

# Generated at 2022-06-22 05:34:03.860796
# Unit test for constructor of class Message
def test_Message():
    message = Message(text='May not have more than 100 characters', code='max_length', key='username', start_position='0', end_position='10')
    assert message.text == 'May not have more than 100 characters'
    assert message.code == 'max_length'
    assert message.index == ['username']
    assert message.start_position == '0'
    assert message.end_position == '10'


# Generated at 2022-06-22 05:34:06.151691
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    p = Position(1, 2, 3)
    q = Position(1, 2, 3)
    assert p == q



# Generated at 2022-06-22 05:34:20.747514
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError(None, None, None, None)
    # Check type of err
    assert isinstance(err, BaseError)
    # Check if hasattr of err
    assert hasattr(err, "text")
    assert hasattr(err, "code")
    assert hasattr(err, "key")
    assert hasattr(err, "position")
    assert hasattr(err, "messages")
    assert hasattr(err, "_messages")
    assert hasattr(err, "_message_dict")
    assert hasattr(err, "messages")
    assert hasattr(err, "__iter__")
    assert hasattr(err, "__len__")
    assert hasattr(err, "__getitem__")
    assert hasattr(err, "__eq__")

# Generated at 2022-06-22 05:34:23.584305
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    a = ValidationResult(error = ValidationError())
    assert eval(repr(a)) == a
    b = ValidationResult(value = 1)
    assert eval(repr(b)) == b


# Generated at 2022-06-22 05:34:27.950710
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    v1 = ValidationResult(value=5)
    assert v1.value == 5
    assert v1.error == None

    v2 = ValidationResult(error="Error")
    assert v2.value == None
    assert v2.error == "Error"
# End test


# Generated at 2022-06-22 05:34:30.572714
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    assert len(BaseError(messages=[Message()])) == 0
    assert len(BaseError(messages=[Message(key=1)])) == 1


# Generated at 2022-06-22 05:34:37.837252
# Unit test for constructor of class Position
def test_Position():
    assert Position(2, 3, 4) == Position(2, 3, 4)
    assert Position(2, 3, 4) != Position(3, 3, 4)
    assert Position(2, 3, 4) != Position(2, 4, 4)
    assert Position(2, 3, 4) != Position(2, 3, 5)
    assert Position(2, 3, 4) != 1
    assert repr(Position(2, 3, 4)) == "Position(line_no=2, column_no=3, char_index=4)"


# Generated at 2022-06-22 05:34:44.102856
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    """
    >>> Message(text="ERROR", code="")
    Message(text='ERROR', code='custom')


    >>> Message(text="ERROR", code="", key="username")
    Message(text='ERROR', code='custom', index=['username'])
    """


# Generated at 2022-06-22 05:34:45.679084
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    e = BaseError()
    assert e._message_dict
    messages = e._messages
    assert messages is not None

# Generated at 2022-06-22 05:34:48.740647
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    BaseError({'a': 'b'}, code="c", key="d", position=Position(1, 1, 1))


# Generated at 2022-06-22 05:34:59.701849
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    def test_case(message: Message, assert_equal: typing.Callable) -> None:
        assert_equal(hash(message), hash(message))

    m1 = Message(text="a message")
    test_case(m1, assert_equal=lambda a, b: a == b)

    m2 = Message(text="a message", code="custom")
    test_case(m2, assert_equal=lambda a, b: a == b)

    m3 = Message(text="a message", key="foo")
    test_case(m3, assert_equal=lambda a, b: a == b)

    m4 = Message(text="a message", index=["foo"])
    test_case(m4, assert_equal=lambda a, b: a == b)


# Generated at 2022-06-22 05:35:12.595088
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test a ValidationError with a single error message
    assert BaseError(text='text') == BaseError(text='text')
    assert BaseError(text='text1') != BaseError(text='text2')
    assert BaseError(text='text', code='custom') == BaseError(text='text', code='custom')
    assert BaseError(text='text', code='custom1') != BaseError(text='text', code='custom2')
    assert BaseError(text='text', key='name') == BaseError(text='text', key='name')
    assert BaseError(text='text', key='name1') != BaseError(text='text', key='name2')

    # Test a ValidationError with different lists of error messages
    assert BaseError(messages=[]) == BaseError(messages=[])

# Generated at 2022-06-22 05:35:25.572179
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    """
    Method __repr__ of class Position
    """
    class_name = "Position"
    line_no = 1
    column_no = 2
    char_index = 5
    ret = f"{class_name}(line_no={line_no}, column_no={column_no}, char_index={char_index})"
    assert Position.__repr__(Position(line_no, column_no, char_index)) == ret


# Generated at 2022-06-22 05:35:33.255309
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    from unittest.mock import MagicMock
    mockMessage = MagicMock()
    mockMessage.code = "custom"
    mockMessage.index = [0]
    mockMessage.text = "May not have more than 100 characters"
    mockMessage.start_position = Position(0, 0, 0)
    mockMessage.end_position = Position(0, 0, 0)
    hash_result = BaseError(messages=[mockMessage]).__hash__()
    assert hash_result == 8853747071515081641

# Generated at 2022-06-22 05:35:41.324619
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult(value=1)
    assert result.value == 1
    assert result.error is None

    result = ValidationResult(error=Exception())
    assert result.value is None
    assert isinstance(result.error, Exception)

    try:
        ValidationResult(value=1, error=Exception())
        assert False, "Assert failed"
    except AssertionError as e:
        assert str(e) == "Assert failed"
    except:
        assert False

test_ValidationResult()

# Generated at 2022-06-22 05:35:52.450922
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    import random
    import string
    import pytest
    
    messages = []
    for i in range(0,100):
        text = ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(100))
        code = ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(100))
        key = random.randint(0, 5000000)
        messages.append(Message(text=text, code=code, key=key))

    be = BaseError(messages=messages)
    hash(be)
    
    with pytest.raises(TypeError):
        hash(be)
        
    be2 = BaseError()
    hash(be2)
    

# Generated at 2022-06-22 05:35:53.890932
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    x = Position(1, 2, 3)
    assert repr(x) == 'Position(line_no=1, column_no=2, char_index=3)'

# Generated at 2022-06-22 05:36:00.215201
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="May not have more than 100 characters", code="max_length", key="username")
    message2 = Message(text="Needs to be a valid e-mail address", code="type_error", key="email")
    message3 = Message(text="May not have more than 100 characters", code="max_length", key="username")
    assert message1 == message3
    assert message1 != message2


# Generated at 2022-06-22 05:36:03.967550
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=1)
    value = iter(result)
    assert next(value) == 1
    assert next(value) is None


# Generated at 2022-06-22 05:36:15.069350
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    msg1 = Message(text='text1', code='code1', key='key1', index=['index1'])
    msg2 = Message(text='text2', code='code2', key='key2', index=['index2'])
    error1 = BaseError(text='text1', code='code1', key='key1', position='position1', messages=[msg1])
    error2 = BaseError(text='text1', code='code1', key='key1', position='position1', messages=[msg1])
    assert error1 == error2
    error2.text = 'text2'
    assert error1 != error2
    error2.text = 'text1'
    error2.code = 'code2'
    assert error1 != error2
    error2.code = 'code1'

# Generated at 2022-06-22 05:36:24.493203
# Unit test for constructor of class Message
def test_Message():
    # case 1
    text = "error_text"
    code = "max_length"
    key = "username"
    position = Position(1,1,1)
    msg = Message(text=text, code=code, key=key, position=position)
    assert msg.text == "error_text"
    assert msg.code == "max_length"
    assert msg.index == ["username"]
    assert msg.start_position == Position(1,1,1)
    assert msg.end_position == Position(1,1,1)

    # case 2
    text = "error_text"
    code = "max_length"
    key = "username"
    position = Position(1,1,1)
    index = [0,"error"]

# Generated at 2022-06-22 05:36:30.385938
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    first_Position = Position(line_no=1, column_no=1, char_index=1)
    second_Position = Position(line_no=1, column_no=1, char_index=1)
    assert first_Position == second_Position


# Generated at 2022-06-22 05:36:43.663035
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    """
    Check that method messages works properly.
    """
    msg = Message(text="error", index=[1, 2, 3], code="errorcode")
    be = BaseError(messages=[msg])
    assert [[1, 2, 3, 4], 'error', 'errorcode'] in [
        [m.index, m.text, m.code] for m in be.messages(add_prefix=4)
    ]
    assert be.messages() == [msg]

# Generated at 2022-06-22 05:36:51.701367
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value='1234')
    assert next(iter(result)) == '1234'
    try:
        next(iter(result))
    except StopIteration:
        pass
    else:
        assert False, 'Should have raised StopIteration'

    result = ValidationResult(error='error')
    assert next(iter(result)) == 'error'
    try:
        next(iter(result))
    except StopIteration:
        pass
    else:
        assert False, 'Should have raised StopIteration'


# Generated at 2022-06-22 05:37:03.527939
# Unit test for constructor of class ValidationError
def test_ValidationError():
    v = ValidationError()
    assert len(v._messages) == 0
    assert v._message_dict == {}

    v = ValidationError(messages=[
    Message(text="E1", code="code1", key="a"),
    Message(text="E2", code="code2", key="b")
    ])
    assert len(v._messages) == 2
    assert v._message_dict == {"a": "E1", "b": "E2"}

    v = ValidationError(text="text", code="c", key="k")
    assert len(v._messages) == 1
    assert v._message_dict == {"k": "text"}
    assert v._messages[0].text == "text"
    assert v._messages[0].code == "c"

# Generated at 2022-06-22 05:37:10.844744
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    import uuid
    # Create an instance of BaseError
    error_instance = BaseError()
    # Check whether __str__ method is implemented
    try:
        _ = error_instance.__str__()
    except NotImplementedError:
        # If not implemented, pass the test
        pass
    else:
        # If implemented, check whether it is implemented correctly
        str_instance = str(error_instance)
        assert isinstance(str_instance, str)



# Generated at 2022-06-22 05:37:12.567938
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    e = BaseError()
    assert e.__str__() == "{}"


# Generated at 2022-06-22 05:37:14.501480
# Unit test for constructor of class BaseError
def test_BaseError():
    v = BaseError(messages=[Message(text='Some text')])
    print(v)
    

# Generated at 2022-06-22 05:37:19.608993
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    a = Message("Hello")
    b = Message("Hello")
    assert a == b
    assert hash(a) == hash(b)

    c = Message("Hello", code="custom")
    assert a != c
    assert hash(a) != hash(c)

    d = Message("Hello", key=0)
    assert a != d
    assert hash(a) != hash(d)

# Generated at 2022-06-22 05:37:28.193210
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result1 = ValidationResult(value="hello")
    assert len(result1) == 2
    assert result1.value == "hello"
    assert result1.error is None
    assert bool(result1) == True

    result2 = ValidationResult(error=ValidationError(text="Hello"))
    assert len(result2) == 2
    assert result2.value is None
    assert isinstance(result2.error, ValidationError)
    assert bool(result2) == False

# Generated at 2022-06-22 05:37:31.419692
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 1, 1) == Position(1, 1, 1)
    not_Position = 5
    assert Position(1, 1, 1) != not_Position



# Generated at 2022-06-22 05:37:40.690458
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    from yamale import yamale_model
    from yamale import yamale_schema

    class User(yamale_model.Model):
        name = yamale_model.String('name')
        age = yamale_model.Integer('age')

    class Users(yamale_model.Model):
        user = yamale_model.List('users', User)

    class Root(yamale_model.Model):
        users = yamale_model.List('users', Users)

    class RootSchema(yamale_schema.Schema):
        users = yamale_schema.List(Users)


# Generated at 2022-06-22 05:37:51.096261
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(error=ValidationError())
    assert iter(vr) == iter((None, vr.error))
    vr = ValidationResult(value=1)
    assert iter(vr) == iter((vr.value, None))

# Generated at 2022-06-22 05:37:55.334400
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    pos1 = Position(line_no=1, column_no=2, char_index=3)
    pos2 = Position(line_no=1, column_no=2, char_index=3)
    assert pos1 == pos2


# Generated at 2022-06-22 05:38:05.397242
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    error = BaseError(text='Must be less than or equal to 2.', key=0)
    assert error == BaseError(messages=[Message(index=[0], text='Must be less than or equal to 2.')])

    i = iter(error)
    assert next(i) == 0
    assert list(i) == []

    error = BaseError(messages=[Message(text='Must be less than or equal to 2.'), Message(index=['0'], text='Must be less than or equal to 2.'), Message(index=['1'], text='Must be less than or equal to 2.')])
    i = iter(error)
    assert next(i) == 0
    assert list(i) == ['0', '1']


# Generated at 2022-06-22 05:38:07.639844
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    vr = ValidationResult()
    assert vr
    vr = ValidationResult(error=ValidationError())
    assert not vr



# Generated at 2022-06-22 05:38:18.745479
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    error = BaseError(messages=[
        Message(text='text1', key='key1'),
        Message(text='text2', key='key2'),
    ])
    assert error['key1'] == 'text1'
    assert error['key2'] == 'text2'
    error = BaseError(messages=[
        Message(text='text1', key=0),
        Message(text='text2', key=1),
    ])
    assert error[0] == 'text1'
    assert error[1] == 'text2'
    error = BaseError(messages=[
        Message(text='text1', index=['index1']),
        Message(text='text2', index=['index1']),
        Message(text='text3', index=['index2']),
    ])

# Generated at 2022-06-22 05:38:28.148960
# Unit test for constructor of class ValidationError
def test_ValidationError():

    assert dict(ValidationError(text="Hello world")) == {"": "Hello world"}

    assert ValidationError(text="Hello world") == ValidationError(
        text="Hello world", code="custom"
    )

    assert dict(ValidationError(text="123", code="foo")) == {"": "123"}

    assert dict(ValidationError(text="123", key="hello")) == {"hello": "123"}

    assert dict(ValidationError(text="123", index=[1, 2, 3])) == {
        1: {"2": {"3": "123"}}
    }


# Generated at 2022-06-22 05:38:30.379860
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    from typesystem.base import TypeSystem
    from typesystem.types import String
    assert ValidationResult(value="1")
    schema = TypeSystem(types=[String(max_length=1)])
    assert not ValidationResult(error=schema.validate("12"))


# Generated at 2022-06-22 05:38:32.956364
# Unit test for constructor of class ValidationError
def test_ValidationError():
    a = ValidationError(text=None, code=None, key=None, position=None, messages=None)


# Generated at 2022-06-22 05:38:35.833337
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    message = Message(text="password required", code="required", key="password", index=["password"])
    assert repr(message) == "Message(text='password required', code='required', index=['password'])"


# Generated at 2022-06-22 05:38:37.228212
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    bool(Result()) == True
    bool(Result(value=None)) == False


# Generated at 2022-06-22 05:38:59.877575
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    # Simple case
    msg = "Error message"
    error = BaseError(text=msg, code='error_code')
    error['key'] == msg
    # Compound case
    msg1 = "Error message 1"
    msg2 = "Error message 2"
    error = BaseError(messages=[Message(text=msg1, code='error_code', key='key1'), Message(text=msg2, code='error_code', key='key2')])
    assert error['key1'] == msg1
    assert error['key2'] == msg2
    assert error == {'key1': msg1, 'key2': msg2}

# Generated at 2022-06-22 05:39:01.470501
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    errors = BaseError(text="Field required")
    assert str(errors)=="Field required"


# Generated at 2022-06-22 05:39:09.523042
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    position1 = Position(line_no=1, column_no=1, char_index=0)
    position2 = Position(line_no=2, column_no=2, char_index=1)
    position3 = Position(line_no=3, column_no=3, char_index=2)
    assert position1 == position1
    assert not (position1 == position2)
    assert not (position1 == position3)
    assert position2 == position2
    assert not (position2 == position3)
    assert position3 == position3

# Generated at 2022-06-22 05:39:14.350071
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    # It should be able to return the value of the method
    assert Position(1, 1, 1).__repr__() == "Position(line_no=1, column_no=1, char_index=1)"


# Generated at 2022-06-22 05:39:17.226983
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    # __str__ function should return the string content of error
    error = BaseError(text="Some error text")
    assert str(error) == "Some error text"


# Generated at 2022-06-22 05:39:29.074254
# Unit test for constructor of class ValidationError
def test_ValidationError():
    with pytest.raises(assertion_error):
        BaseError(text=None, messages=[])
    with pytest.raises(assertion_error):
        BaseError(text="", code=None, messages=[])
    with pytest.raises(assertion_error):
        BaseError(text="", code="", key=None, messages=[])
    with pytest.raises(assertion_error):
        BaseError(text="", code="", key="", position=None, messages=[])
    with pytest.raises(assertion_error):
        BaseError(text="", code="", key="", position=0, messages=[])
    with pytest.raises(assertion_error):
        BaseError(text="", code="", key="", position=Position(0,0,0), messages=[])
   

# Generated at 2022-06-22 05:39:39.704726
# Unit test for constructor of class ParseError
def test_ParseError():
    import io
    import sys
    from typesystem.tokenizers import tokenize_json, tokenize_yaml
    from typesystem.tokenizers import JSON_TOKENIZER, YAML_TOKENIZER

    # Tokenizers raise errors via sys.exit() with a custom error message
    try:
        tokenize_json(None, "")
    except SystemExit as err:
        assert err.code == 1
        message = err.exception
    else:
        raise AssertionError("Did not raise a SystemExit exception")

    # Test error form JSON tokenizer
    assert isinstance(message, ParseError)
    assert str(message) == message.messages()[0].text

    # Test error form YAML tokenizer

# Generated at 2022-06-22 05:39:41.972236
# Unit test for constructor of class ParseError
def test_ParseError():
    message = parse_error.Message(
        text="Failed to locate the document start",
        code="yaml.parser.document_start"
    )
    parse_error.ParseError(messages=[message])


# Generated at 2022-06-22 05:39:52.964409
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    try:
        message1 = Message(text='invalid value', code='invalid_value', index=[], start_position=Position(line_no=1, column_no=1, char_index=0), end_position=Position(line_no=1, column_no=13, char_index=12))
        message2 = Message(text='invalid value', code='invalid_value', index=[], start_position=Position(line_no=1, column_no=1, char_index=0), end_position=Position(line_no=1, column_no=13, char_index=12))
        assert message1 == message2
    except Exception:
        print("Error while calling method __eq__ of class Message")
        raise


# Generated at 2022-06-22 05:40:00.521668
# Unit test for constructor of class ValidationError

# Generated at 2022-06-22 05:40:40.044989
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    v = ValidationResult(value={'hello':'world'})
    assert v
    assert v.value == {'hello':'world'}
    assert v.error is None
    assert not ValidationResult(error=ValidationError(text="Woops"))
    assert v.value == {'hello':'world'}
    assert v.error is None
    # Now test __iter__
    v1, v2 = v
    assert v1 == v.value
    assert v2 is None
    # Test __bool__()
    assert bool(v)

# Generated at 2022-06-22 05:40:42.834520
# Unit test for constructor of class Message
def test_Message():
    m = Message(text="message")
    assert m.text == "message"
    assert m.code == "custom"
    assert m.index == []
    assert m.start_position is None
    assert m.end_position is None


# Generated at 2022-06-22 05:40:45.853585
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    assert bool(ValidationResult(value=None)) is False
    assert bool(ValidationResult(value=1)) is True
    assert bool(ValidationResult(error=None)) is False
    assert bool(ValidationResult(error=ValidationError(text='Error'))) is False

# Generated at 2022-06-22 05:40:50.379360
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    schema = String('a string')
    value, error = schema.validate_or_error('foo')
    assert repr(value) == "ValidationResult(value='foo')"
    assert repr(error) == "ValidationResult(error=ValidationError(['String does not match pattern']))"

# Generated at 2022-06-22 05:41:00.322945
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    # __repr__ of class BaseError
    # Case 1: message with key
    message_with_key = Message(text="This is message with key", key="key1")
    # Case 2: message without key
    message_without_key = Message(text="This is message without key")
    # Case 3: message with index
    message_with_index = Message(text="This is a message", index=[1, 2, 3])
    # Case 4: message without index
    message_without_index = Message(text="This is a message")
    # Case 5: message with key and index
    message_with_key_and_index = Message(
        text="This is a message", key="key2", index=[1, 2, 3]
    )
    # Case 6: message with position

# Generated at 2022-06-22 05:41:04.894106
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    message_1 = Message(text='May not have more than 100 characters', code='max_length', key='username')
    message_2 = Message(text='May not have more than 100 characters', code='max_length', key='username')
    assert hash(message_1) == hash(message_2)
test_Message___hash__()

# Generated at 2022-06-22 05:41:07.965092
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    assert repr(BaseError(text='a', code='a', key='a', position='a', messages='a')) == "BaseError(a)"


# Generated at 2022-06-22 05:41:11.358104
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    statement = "Position(line_no=100, column_no=100, char_index=100)"
    obj = Position(100, 100, 100)
    assert repr(obj) == statement


# Generated at 2022-06-22 05:41:14.718582
# Unit test for constructor of class Message
def test_Message():
    message = Message(text='x')
    assert message.text == 'x'
    assert message.code == 'custom'
    assert message.index == []
    assert message.start_position == None
    assert message.end_position == None

# Generated at 2022-06-22 05:41:25.553109
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    m1 = Message(text='a', code='code', key=1)
    m2 = Message(text='a', code='code', key=1)
    assert m1 == m2

    m1 = Message(text='a', code='code', key=1, index=[1, 2, 3])
    m2 = Message(text='a', code='code', key=1, index=[1, 2, 3])
    assert m1 == m2

    m1 = Message(text='a', code='code', key=1, end_position=Position(1, 1, 1))
    m2 = Message(text='a', code='code', key=1, end_position=Position(1, 1, 1))
    assert m1 == m2


# Generated at 2022-06-22 05:42:33.329309
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    from typing import Any

    class ValidationError(BaseError):
        pass

    class ParseError(BaseError):
        pass

    def parse_json():
        return ParseError(
            text="Unable to parse JSON", code="parse_error", position=Position(
                line_no=1, column_no=2, char_index=3
            )
        )

    def validate():
        return ValidationError(
            text="Value may not be empty",
            code="value_error",
            key="name",
            position=Position(
                line_no=1, column_no=2, char_index=3
            )
        )


# Generated at 2022-06-22 05:42:37.245858
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    err1 = BaseError(text="An error message")
    err2 = BaseError(text="An error message")
    assert err1 == err2


# Generated at 2022-06-22 05:42:42.006932
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    position = Position(line_no=4, column_no=5, char_index=6)
    repr_ = repr(position)
    assert isinstance(repr_, str)
    assert repr_ == 'Position(line_no=4, column_no=5, char_index=6)'



# Generated at 2022-06-22 05:42:44.449160
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    instance = BaseError(text="test text", code="test code", key="test key", position="test position", messages=["test messages"])
    print(str(instance.__repr__()))

