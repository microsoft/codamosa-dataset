

# Generated at 2022-06-22 05:33:19.351564
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error = BaseError(messages=[Message(text='test01', code='testcode01', index=['testindex01'])])
    assert error == BaseError(messages=[Message(text='test01', code='testcode01', index=['testindex01'])])
    assert error != BaseError(messages=[Message(text='test02', code='testcode01', index=['testindex02'])])


# Generated at 2022-06-22 05:33:26.912115
# Unit test for constructor of class ValidationError
def test_ValidationError():
    """
    Ensure that ValidationError is correctly accepting constructor arguments.
    """
    error_text = "error message"
    error_key = "key"
    error_message = Message(text=error_text, code=None, key=error_key)

    # Initialize ValidationError with error_message
    error = ValidationError(messages=[error_message])

    # ValidationError should have 1 message
    assert len(error) == 1

    # ValidationError should have the same error message as the one passed to constructor
    assert error._messages == [error_message]

    # ValidationError should have a list representation
    assert repr(error) == repr([error_message])

    # ValidationError should have a dictionary representation
    assert error[error_key] == error_text

    # ValidationError should have a string representation


# Generated at 2022-06-22 05:33:31.031452
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    p1 = Position(0, 0, 0)
    p2 = Position(0, 1, 0)
    p3 = Position(0, 0, 0)
    assert p1 == p1
    assert p1 != p2
    assert p1 == p3


# Generated at 2022-06-22 05:33:34.645310
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    code = "max_length"
    key = 0
    String = String()
    message = String.build_validation_error(value="hello", code=code, key=key)
    assert hash(message) == hash((code, (key,)))

# Generated at 2022-06-22 05:33:43.043387
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    m1 = Message(text="First error")
    m2 = Message(text="Second error")
    m3 = Message(text="Third error", index=["a", "b"])
    v1 = ValidationError(messages=[m1, m2, m3])
    assert v1.messages() == [m1, m2, m3]
    assert v1.messages(add_prefix="x") == [
        Message(text="First error", index=["x"]),
        Message(text="Second error", index=["x"]),
        Message(text="Third error", index=["x", "a", "b"]),
    ]


# Generated at 2022-06-22 05:33:52.113955
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    # test with a single Message
    v_err = ValidationError(text="Text")
    assert isinstance(v_err.messages(), list)
    assert len(v_err.messages()) == 1
    assert isinstance(v_err.messages()[0], Message)
    assert v_err.messages()[0].text == "Text"
    assert v_err.messages()[0].code == "custom"
    assert v_err.messages()[0].index == []

    # test with multiple Messages and a key for add_prefix.
    v_err = ValidationError(
    messages=[
        Message(text="Text1", code="custom"),
        Message(text="Text2", code="custom"),
        Message(text="Text3", code="custom"),
        ]
    )
    assert isinstance

# Generated at 2022-06-22 05:33:59.080826
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    message = Message(
        text = 'May not have more than 100 characters',
        code = 'max_length',
        key = 'username',
        index = None,
        position = None,
        start_position = None,
        end_position = None
    )
    assert message.__repr__() == "Message(text='May not have more than 100 characters', code='max_length', index=None, position=None)"


# Generated at 2022-06-22 05:34:07.420163
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    a = Message(text='a')
    b = Message(text='b')
    c = Message(text='a', code='c')
    a1 = Message(text='a', code='c', index=[1])
    a2 = Message(text='a', code='c', index=[1, 2])
    a3 = Message(text='a', code='c', index=[1, 2, 3])
    assert a == a
    assert a != b
    assert a != c
    assert a1 != a2
    assert a1 != a3
    assert a2 != a3
    return



# Generated at 2022-06-22 05:34:11.225435
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():

    error_0 = BaseError(text="abc", key='abc')
    assert list(error_0) == ['abc']
    assert len(error_0) == 1

    error_1 = BaseError(messages=[Message(text="abc", key='def')])
    assert list(error_1) == ['def']

    error_2 = BaseError(messages=[Message(text="abc", key='def'), Message(text="abc", key='abc')])
    assert list(error_2) == ['def', 'abc']



# Generated at 2022-06-22 05:34:13.348029
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert list(ValidationResult(value=None, error=None) == [None, None])


# Generated at 2022-06-22 05:34:23.854095
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    value = "value"
    error = ValidationError(text="error")
    result = ValidationResult(value=value)
    assert result.__repr__()=="ValidationResult(value='value')"
    result = ValidationResult(error=error)
    assert result.__repr__()=="ValidationResult(error=ValidationError('error'))"

# Generated at 2022-06-22 05:34:29.408675
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    e1 = Exception()
    e2 = Exception()
    e3 = Exception()
    b1 = BaseError(error=e1)
    b2 = BaseError(error=e2)
    b3 = BaseError(error=e3)
    b = BaseError(error=b1, error=b2, error=b3)

    assert list(b) == [e1, e2, e3]

# Generated at 2022-06-22 05:34:33.049325
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    result = ValidationResult(value=123)
    assert repr(result) == 'ValidationResult(value=123)'
    result = ValidationResult(error=ValidationError())
    assert repr(result) == 'ValidationResult(error=ValidationError([]))'



# Generated at 2022-06-22 05:34:36.166378
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(line_no=1, column_no=1, char_index=1) == Position(line_no=1, column_no=1, char_index=1)


# Generated at 2022-06-22 05:34:38.569328
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    message = Message(text="Error message")
    error = BaseError(messages=[message])
    assert repr(error) == "BaseError([Message(text='Error message', code='custom')])"


# Generated at 2022-06-22 05:34:51.953284
# Unit test for constructor of class ValidationError
def test_ValidationError():
    error = BaseError(
        text="May not have more than 100 characters",
        code="max_length",
    )
    assert len(error) == 1
    assert error.messages() == [
        Message(text="May not have more than 100 characters", code="max_length")
    ]
    assert str(error) == "May not have more than 100 characters"
    assert dict(error) == {"": "May not have more than 100 characters"}
    assert error.messages(add_prefix="surname") == [
        Message(
            text="May not have more than 100 characters",
            code="max_length",
            index=["surname"],
        )
    ]

# Generated at 2022-06-22 05:35:03.949174
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    #
    # __hash__()
    #
    # 1. Call method __hash__() of an object MyError with 
    #    arguments:
    #    - self=MyError object, with the following members:
    #      - text: "This is the error message"
    #      - code: "the_error_code"
    #      - key: "error_key"
    #      - messages: []
    #    - store result in variable hash_value
    # 2. The method __hash__() should return value:
    #    (code, tuple(index))
    # 3. The variable hash_value should equal to that value
    #
    MyError = BaseError(text="This is the error message", 
                        code="the_error_code", 
                        key="error_key")
    assert MyError.__

# Generated at 2022-06-22 05:35:13.460049
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    message = Message(text='May not have more than 100 characters', code='max_length', key='username')
    error = BaseError(messages=[message])

    # if add_prefix is not None
    # return [
    #     Message(
    #         text=message.text,
    #         code=message.code,
    #         index=[add_prefix] + message.index,
    #     )
    #     for message in self._messages
    # ]
    assert error.messages(add_prefix='users') == [Message(text='May not have more than 100 characters', code='max_length', index=['users', 'username'])]

# Generated at 2022-06-22 05:35:22.849035
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    messages = []                                                                    # type: typing.List[Message]
    messages.append(Message(text="Page not found.", code="not_found", key="error"))
    messages.append(Message(text="Username must be at least 5 characters.", code="min_length", key="username", index=["users", 0]))
    messages.append(Message(text="Username must be at most 10 characters.", code="max_length", key="username", index=["users", 0]))
    messages.append(Message(text="Username may only contain letters and numbers.", code="invalid_characters", key="username", index=["users", 0]))

    error = ValidationError(messages=messages)
    assert error
    assert isinstance(error, Mapping)
    assert isinstance(error, typing.Mapping)

# Generated at 2022-06-22 05:35:28.669832
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    messages = [Message(text="Message 0", code="a"), Message(text="Message 1", code="b"), Message(text="Message 2", code="c")]
    error = BaseError(messages=messages)
    string = '{"Message 0":"Message 0", "Message 1":"Message 1", "Message 2":"Message 2"}'
    assert string == str(error)


# Generated at 2022-06-22 05:35:38.706946
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    message1 = Message(text="I am message 1", code="I_am_code_1")
    message2 = Message(text="I am message 2", code="I_am_code_2")
    error = BaseError(messages=[message1, message2])
    assert error.messages() == [message1, message2]


# Generated at 2022-06-22 05:35:46.522107
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    error = BaseError(messages=[Message(text="text", index=["key1", "key2"]), Message(text="text2", index=["key3", "key4"])])
    assert error.messages() == [Message(text="text", index=["key1", "key2"]), Message(text="text2", index=["key3", "key4"])]
    assert error.messages(add_prefix="test") == [Message(text="text", index=["test", "key1", "key2"]), Message(text="text2", index=["test", "key3", "key4"])]

# Generated at 2022-06-22 05:35:58.543207
# Unit test for constructor of class ValidationError
def test_ValidationError():
    # Case 1: error having a single message
    message = Message(text="text1", code="code1", key="key1", position="position1")
    error = ValidationError(text=message.text, code=message.code, key=message.key, position=message.position)
    assert error.messages() == [message]
    assert error._messages == [message]
    assert error.messages(add_prefix="add_prefix1") == [Message(text="text1", code="code1", index=["add_prefix1", "key1"])]
    assert error._message_dict == {"key1": "text1"}

    # Case 2: error having multiple error messages
    message1 = Message(text="text1", code="code1", key="key1", position="position1")

# Generated at 2022-06-22 05:36:04.033259
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    value, error = ValidationResult(value=1).__repr__()
    assert value == "ValidationResult(value=1)"
    error, value = ValidationResult(error=ValidationError()).__repr__()
    assert error == "ValidationResult(error=ValidationError())"


# Generated at 2022-06-22 05:36:08.422659
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    res = ValidationResult(value=1)
    assert res == (1, None)
    assert bool(res)

    res = ValidationResult(error='Error')
    assert res == (None, 'Error')
    assert not bool(res)



# Generated at 2022-06-22 05:36:11.231184
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    _actual_method = Message.__hash__
    _expected_method = typing.Any.__hash__
    assert _actual_method == _expected_method


# Generated at 2022-06-22 05:36:13.514315
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    for i in ValidationResult(value=[1,2,3]):
        assert i == [1,2,3]


# Generated at 2022-06-22 05:36:19.561116
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    import pytest
    m = Message(text = 'a', code = 'b', key = 'c', position = Position(1, 2, 3))
    assert m == m
    assert m != 1
    assert m == Message(text = 'a', code = 'b', key = 'c', position = Position(1, 2, 3))
    assert m != Message(text = 'a', code = 'b', key = 'd', position = Position(1, 2, 3))
    assert m != Message(text = 'a', code = 'b', key = 'c', position = Position(1, 2, 4))
    assert m != Message(text = 'a', code = 'b', key = 'c')
    assert m != Message(text = 'a', code = 'b', key = 'c', start_position = Position(1, 2, 3))

# Generated at 2022-06-22 05:36:30.374514
# Unit test for constructor of class ValidationError
def test_ValidationError():
    messages = [
        Message(text="Start", code='BadStart', position=Position(0, 0, 0)),
        Message(text="End", code='BadEnd', position=Position(0, 2, 2)),
    ]
    error = ValidationError(messages=messages)
    error2 = ValidationError(messages=messages)
    assert error == error2
    assert error.messages() == messages
    assert error == {
        "": "Start",
        "0": "End",
    }

    # Instantiated as a ValidationError with multiple error messages.
    error = ValidationError(messages=messages)
    error2 = ValidationError(messages=messages)
    assert error == error2
    assert error.messages() == messages

# Generated at 2022-06-22 05:36:32.889049
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    BaseError(code='custom')
    BaseError(code='custom', key='a')
    BaseError(code='custom', index=['a'])



# Generated at 2022-06-22 05:36:39.002625
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    pass


# Generated at 2022-06-22 05:36:45.911957
# Unit test for method __eq__ of class Message

# Generated at 2022-06-22 05:36:55.465536
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    first = ValidationError(text='First')
    assert first['First'] == 'First'

    second = ValidationError(messages=[
        Message(text='First', index=[1]),
        Message(text='Second', index=[2]),
        Message(text='Third', index=[3]),
    ])
    expected = {
        1: {
            '': 'First',
        },
        2: {
            '': 'Second',
        },
        3: {
            '': 'Third',
        },
    }
    assert second[1] == 'First'
    assert second[2] == 'Second'
    assert second[3] == 'Third'
    assert second == expected


# Generated at 2022-06-22 05:36:56.529492
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    item = BaseError(text="100 characters")
    assert hash(item)

# Generated at 2022-06-22 05:37:00.627857
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    print("test_Position___eq__ start...")
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)
    assert Position(1, 2, 3) != "1"
    print("test_Position___eq__ ok.")



# Generated at 2022-06-22 05:37:09.974460
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    print(Message(text="This is an error message"))
    print(Message(text="This is an error message", code="custom"))
    print(Message(text="This is an error message", key="username"))
    print(Message(text="This is an error message", index=["users", 3, "username"]))
    print(Message(text="This is an error message", position=Position(line_no=1, column_no=1, char_index=0)))
    print(Message(text="This is an error message", start_position=Position(line_no=1, column_no=1, char_index=0), end_position=Position(line_no=1, column_no=10, char_index=9)))


# Generated at 2022-06-22 05:37:20.201282
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError(text='May not have more than 100 characters', code='max_length', key='username',
                position=Position(line_no=1, column_no=2, char_index=3))
    assert error.messages()[0].text == 'May not have more than 100 characters'
    assert error.messages()[0].code == 'max_length'
    assert error.messages()[0].key == 'username'
    assert error.messages()[0].position == Position(line_no=1, column_no=2, char_index=3)
    assert error.messages()[0].start_position == Position(line_no=1, column_no=2, char_index=3)

# Generated at 2022-06-22 05:37:23.143284
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    error = BaseError(text='error message')
    assert str(error) == 'error message'
    error = BaseError(messages=[Message(text='error message')])
    assert str(error) == 'error message'
    error = BaseError(messages=[Message(text='error message', index=[0])])
    assert str(error) == "{'0': 'error message'}"
    error = BaseError(messages=[Message(text='error message', index=[0, 'a'])])
    assert str(error) == "{'0': {'a': 'error message'}}"



# Generated at 2022-06-22 05:37:29.815866
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    import pytest
    other = Position(line_no=1, column_no=2, char_index=3)
    pos = Position(line_no=1, column_no=2, char_index=3)
    assert pos.__eq__(other)



# Generated at 2022-06-22 05:37:39.816770
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    error = BaseError(
        messages=[
            Message(text="A", key="name"),
            Message(text="B", key="age"),
            Message(text="C", index=["rules", "list", 1]),
        ]
    )
    # test for keys "name", "age", "rules"
    assert error["name"] == ["A"], "Error on line test_BaseError___getitem__: 'error[\"name\"] == [\"A\"]' should be 'True'"
    assert error["age"] == ["B"], "Error on line test_BaseError___getitem__: 'error[\"age\"] == [\"B\"]' should be 'True'"

# Generated at 2022-06-22 05:37:48.539268
# Unit test for constructor of class ParseError
def test_ParseError():
    print("Test constructor of class ParseError ...")
    ParseError()


# Generated at 2022-06-22 05:38:00.386529
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    text1 = "text1"
    code1 = "code1"
    key1 = "key1"
    index1 = [1, 2, 3]
    position1 = Position(1, 2, 3)
    start_position1 = Position(1, 2, 3)
    end_position1 = Position(1, 2, 3)

    text2 = "text2"
    code2 = "code2"
    key2 = "key2"
    index2 = [1, 2, 3]
    position2 = Position(1, 2, 3)
    start_position2 = Position(1, 2, 3)
    end_position2 = Position(1, 2, 3)


# Generated at 2022-06-22 05:38:05.523743
# Unit test for constructor of class ValidationError
def test_ValidationError():
    error = ValidationError(
        text="Too many items", code="too_many_items"
    )
    assert error.messages() == [Message(text="Too many items", code="too_many_items")]

test_ValidationError()

# Generated at 2022-06-22 05:38:13.813016
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    # Setup
    message = Message(
        text='May not have more than 100 characters',
        code='max_length',
        key='username',
        position=Position(
            line_no=7,
            column_no=8,
            char_index=11,
        ),
    )
    # Exercise
    s = repr(message)
    # Verify
    assert s == 'Message(text=\'May not have more than 100 characters\', code=\'max_length\', index=[\'username\'], position=Position(line_no=7, column_no=8, char_index=11))'


# Generated at 2022-06-22 05:38:16.482728
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    errs = ["hello", "world"]
    be = BaseError(text="hello", code="c")
    res = be[:]
    assert (res == errs)



# Generated at 2022-06-22 05:38:25.941452
# Unit test for constructor of class Message
def test_Message():
    message = Message(text="May not have more than 100 characters")
    assert message.text == "May not have more than 100 characters"
    assert message.code == "custom"
    assert message.index == []
    assert message.start_position is None
    assert message.end_position is None

    message = Message(
        text="May not have more than 100 characters",
        code="max_length",
        index=["users", 3, "username"],
        position=Position(line_no=1, column_no=1, char_index=0),
    )
    assert message.index == ["users", 3, "username"]

# Generated at 2022-06-22 05:38:26.586210
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    pass

# Generated at 2022-06-22 05:38:28.068451
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert ValidationResult(value=5)
    assert ValidationResult(error=5)

# Generated at 2022-06-22 05:38:31.749535
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    assert bool(ValidationResult(value=None))
    assert not bool(ValidationResult(error=None))
    assert bool(ValidationResult(value=1))
    assert not bool(ValidationResult(error=2))

# Generated at 2022-06-22 05:38:35.833242
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError(text="xyz");
    assert len(error) == 1
    assert error.messages() == [Message(text="xyz", code="custom")]
    assert str(error) == "xyz"
    assert str(error) == "xyz"


# Generated at 2022-06-22 05:38:56.074503
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(line_no=1, column_no=2, char_index=3) == Position(line_no=1, column_no=2, char_index=3)
    assert Position(line_no=1, column_no=2, char_index=3) != Position(line_no=2, column_no=2, char_index=3)
    assert Position(line_no=1, column_no=2, char_index=3) != Position(line_no=1, column_no=1, char_index=3)
    assert Position(line_no=1, column_no=2, char_index=3) != Position(line_no=1, column_no=2, char_index=4)

# Generated at 2022-06-22 05:38:58.123417
# Unit test for constructor of class ParseError
def test_ParseError():
    assert ParseError(text='hello') == ParseError(text='hello')



# Generated at 2022-06-22 05:39:04.488705
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    instance_1 = ValidationResult(error=ValidationError(messages=[Message(text='invalid value')]))
    instance_2 = ValidationResult(value=1)

    assert (instance_1.__repr__() == "ValidationResult(error=ValidationError([Message(text='invalid value', code='custom', index=[''], position=None)]))")
    assert (instance_2.__repr__() == "ValidationResult(value=1)")

# Generated at 2022-06-22 05:39:09.269032
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    # Arrange
    error = BaseError(messages=[Message(text='Invalid value')])
    # Act
    error_repr = error.__repr__()
    # Assert
    assert error_repr == "ValidationError([Message(text='Invalid value', code='custom', index=[])])"


# Generated at 2022-06-22 05:39:21.895585
# Unit test for constructor of class BaseError
def test_BaseError():
    # test with text, code, key and position
    er = BaseError(
        text="This is a test",
        code="test_code",
        key="test_key",
        position=None,
        messages=None
    )
    assert len(er) == 1
    assert er["test_key"] == "This is a test"
    er = BaseError(
        text=None,
        code=None,
        key=None,
        position=None,
        messages=[Message(text="This is a test", code="test_code", key="test_key", position=None)]
    )
    assert len(er) == 1
    assert er["test_key"] == "This is a test"

# Generated at 2022-06-22 05:39:27.861818
# Unit test for constructor of class ParseError
def test_ParseError():
    assert ParseError()
    assert ParseError(text="a")
    assert ParseError(text="a", code="b")
    assert ParseError(text="a", code="b", key=1)
    assert ParseError(messages=[Message(text="a")])
    assert ParseError(messages=[Message(text="a", index=[1])])



# Generated at 2022-06-22 05:39:37.257130
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    data = {
      "timestamp": 123,
      "url": "https://www.google.com",
      "responsetime": 6.7,
      "code": 404,
      "message": "Not found",
      "ok": False
    }
    try:
        url = Schema(Object({
          "timestamp": Integer(),
          "url": String(),
          "responsetime": Float(),
          "statuscode": Integer(),
          "message": String(),
          "ok": Boolean()
        })).validate(data)
    except ValidationError as e:
        print(str(e))
    else:
        pass


# Generated at 2022-06-22 05:39:41.438793
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    # Test case data
    error_1 = BaseError(text="This is a test!", code="test")

    # Perform the test
    result = error_1.__repr__()

    # Post test processing
    assert result == "BaseError(text='This is a test!', code='test')"


# Generated at 2022-06-22 05:39:49.671129
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    # Assert that Position.__eq__() returns True when the arguments are equivalent
    assert Position(1, 1, 1) == Position(1, 1, 1)

    # Assert that Position.__eq__() returns False when the arguments are not equivalent
    assert Position(1, 1, 1) != Position(1, 2, 1)
    assert Position(1, 1, 1) != Position(2, 1, 1)
    assert Position(1, 1, 1) != Position(1, 1, 2)


# Generated at 2022-06-22 05:39:57.022169
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    with pytest.raises(AssertionError):
        ValidationResult(value=3, error='error')
    with pytest.raises(AssertionError):
        ValidationResult(value=None, error=None)
    with pytest.raises(AssertionError):
        ValidationResult()
    v = ValidationResult(value=3)
    assert repr(v) == "ValidationResult(value=3)"
    v2 = ValidationResult(error='error')
    assert repr(v2) == "ValidationResult(error='error')"

# Generated at 2022-06-22 05:40:44.203681
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    error = ValidationError(text="Hello", code="greeting")
    for item in error:
        assert item == "Hello"


# Generated at 2022-06-22 05:40:53.551425
# Unit test for constructor of class BaseError
def test_BaseError():

    with pytest.raises(AssertionError):
        error = BaseError()

    error = BaseError(text='error1')
    assert error._messages == [Message(text='error1', code='custom', key=None, position=None)]
    assert error._message_dict == {'': 'error1'}

    messages = [
        Message(text='error1', code='custom', key=None, position=None),
        Message(text='error2', code='custom', key=None, position=None)
    ]
    error = BaseError(messages=messages)
    assert error._messages == messages
    assert error._message_dict == {'': 'error1', 1: 'error2'}

    error = BaseError(text='error1', code='custom', key='testkey', position=None)
   

# Generated at 2022-06-22 05:41:00.062439
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    value = ValidationError(text='Error')
    assert len(value) == 1
    value = ValidationError(messages=[Message(text='Error')])
    assert len(value) == 1
    value = ValidationError(messages=[Message(text='Error', key='Key')])
    assert len(value) == 1
    value = ValidationError(messages=[
        Message(text='Error', key='Key1'),
        Message(text='Error2', key='Key2', index=['Items', 0])
    ])
    assert len(value) == 2


# Generated at 2022-06-22 05:41:08.894672
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    value = {'status': 'success'}
    data = ValidationResult(value=value)
    assert repr(data) == 'ValidationResult(value={\'status\': \'success\'})'

    error_code, error_text = ('invalid_status', 'status value is invalid')
    error = ValidationError(text=error_text, code=error_code)
    data = ValidationResult(error=error)
    assert repr(data) == f"ValidationResult(error=ValidationError(text='{error_text}', code='{error_code}'))"

test_ValidationResult___repr__()

# Generated at 2022-06-22 05:41:12.108555
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    message = Message(text="Something went wrong!", code="invalid_value")
    assert repr(message) == "Message(text='Something went wrong!', code='invalid_value')"


# Generated at 2022-06-22 05:41:14.048575
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    instance = BaseError(text="some text")
    assert isinstance(instance.__hash__(), int)



# Generated at 2022-06-22 05:41:15.916724
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    assert hash(Message(text=", '", code="x'", index=[1], position=Position(1,1,1))) == -4870519571448529314

# Generated at 2022-06-22 05:41:22.464304
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    import pytest
    from contextlib import ExitStack as does_not_raise

    cases = (
        ("case_0", Position(line_no=1, column_no=2, char_index=3), does_not_raise()),
    )
    for case, (left, right), expectation in cases:
        with expectation:
            assert (left == right) == __unit__(Position.__eq__, left, right)


# Generated at 2022-06-22 05:41:23.320848
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    BaseError()



# Generated at 2022-06-22 05:41:30.955762
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError() == BaseError()
    assert BaseError(messages=[Message(text="foo")]) == BaseError(messages=[Message(text="foo")])
    # text
    assert not BaseError(text="foo") == BaseError(text="bar")
    # code
    assert BaseError(text="foo", code="bar") == BaseError(text="foo", code="bar")
    assert not BaseError(text="foo", code="bar") == BaseError(text="foo", code=None)
    # position
    assert BaseError(text="foo", position=Position(1, 2, 3)) == BaseError(text="foo", position=Position(1, 2, 3))