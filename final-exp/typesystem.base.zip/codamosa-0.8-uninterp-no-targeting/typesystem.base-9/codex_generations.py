

# Generated at 2022-06-22 05:33:07.623323
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    res = ValidationResult(value='abc')
    assert res.value == 'abc'
    assert res.error is None
    res = ValidationResult(error=ValidationError())
    assert res.value is None
    assert isinstance(res.error, ValidationError)

# Generated at 2022-06-22 05:33:19.879605
# Unit test for constructor of class BaseError
def test_BaseError():
    # Single error message constructor
    assert BaseError(text="May not have more than 100 characters") == BaseError(
        text="May not have more than 100 characters"
    )
    assert BaseError(
        text="May not have more than 100 characters", code="max_length"
    ) == BaseError(
        text="May not have more than 100 characters", code="max_length"
    )
    assert BaseError(
        text="May not have more than 100 characters", key="name"
    ) == BaseError(text="May not have more than 100 characters", key="name")

# Generated at 2022-06-22 05:33:24.203218
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    position = Position(1, 2, 3)
    assert repr(position) == "Position(line_no=1, column_no=2, char_index=3)"


# Generated at 2022-06-22 05:33:30.794338
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    # Example 1
    a = ValidationError(
        messages=[
            Message(text="Missing field", code="required", key="username"),
            Message(text="Missing field", code="required", key="password"),
        ]
    )
    b = ValidationError(
        messages=[
            Message(text="Missing field", code="required", key="password"),
            Message(text="Missing field", code="required", key="username"),
        ]
    )
    assert hash(a) == hash(b)


# Generated at 2022-06-22 05:33:39.267734
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    error = BaseError(messages=[Message(text="text", code="code"), Message(text="text2", code="code", key="key")])
    assert error.messages() == [Message(text="text", code="code"), Message(text="text2", code="code", key="key")]
    assert error.messages(add_prefix="prefix") == [Message(text="text", code="code", index=["prefix"]), Message(text="text2", code="code", key="key", index=["prefix", "key"])]


# Unit tests for message position information

# Generated at 2022-06-22 05:33:47.251219
# Unit test for constructor of class Message
def test_Message():
    assert Message(text='hello', code='custom', key=1, index=['a','b'], position=Position(1,1,1), start_position=Position(1,1,1), end_position=Position(2,2,2)) == Message(text='hello', code='custom', key=1, index=['a','b'], position=Position(1,1,1), start_position=Position(1,1,1), end_position=Position(2,2,2))

# Generated at 2022-06-22 05:33:57.609686
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    from typesystem import ValidationError
    import pytest
    BaseError = ValidationError
    error = BaseError(text="May not have more than 100 characters", code="max_length")
    assert len(error) == 1
    error = BaseError(messages=[
        Message(text="May not have more than 100 characters", code="max_length"),
        Message(text="May not have more than 200 characters", code="max_length"),
    ])
    assert len(error) == 2
    error = BaseError(messages=[
        Message(text="May not have more than 100 characters", code="max_length", key="foo"),
        Message(text="May not have more than 200 characters", code="max_length", key="bar"),
    ])
    assert len(error) == 2

# Generated at 2022-06-22 05:34:01.825635
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    position_instance = Position(line_no=1, column_no=1, char_index=1)
    assert repr(position_instance) == "Position(line_no=1, column_no=1, char_index=1)"


# Generated at 2022-06-22 05:34:07.584080
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    error = ValidationError(messages=[
        Message(text="Username must be at least 3 characters long.", code="min_length", key="username", position=Position(1, 1, 0)),
        Message(text="Password must be at least 8 characters long.", code="min_length", key="password", position=Position(2, 1, 0))
    ])
    assert len(error) == 2


# Generated at 2022-06-22 05:34:10.250149
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    a = ValidationResult(value=1)
    b = ValidationResult(error=ValidationError())
    c = a.__iter__()

    assert next(c) == 1
    assert next(c) is None
    assert b.value is None
    assert b.error is not None
    assert a
    assert not b

# Generated at 2022-06-22 05:34:26.805317
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    hash(ValidationError(text="test_text"))
    hash(ValidationError(text="test_text", code="test_code"))
    hash(ValidationError(text="test_text", code="test_code", key="test_key"))
    hash(ValidationError(text="test_text", code="test_code", key="test_key"))
    hash(ValidationError(text="test_text", code="test_code", key="test_key"))


# Generated at 2022-06-22 05:34:29.269687
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    assert repr(ValidationResult(error="Error")) == "ValidationResult(error='Error')"
    assert repr(ValidationResult(value="Value")) == "ValidationResult(value='Value')"

# Generated at 2022-06-22 05:34:39.579834
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    def _test(test_value):
        class_name = "BaseError"
        if isinstance(test_value, Message):
            assert test_value == Message(text=test_value.text,
                                         code=test_value.code, index=test_value.index,
                                         start_position=test_value.start_position,
                                         end_position=test_value.end_position)
            assert hash(test_value) == hash(Message(text=test_value.text,
                                                    code=test_value.code, index=test_value.index,
                                                    start_position=test_value.start_position,
                                                    end_position=test_value.end_position))

# Generated at 2022-06-22 05:34:43.226401
# Unit test for constructor of class Position
def test_Position():
    line_no = 2
    column_no = 3
    char_index = 4
    position = Position(line_no, column_no, char_index)
    return line_no, column_no, char_index

#Unit test for constructor of class Message

# Generated at 2022-06-22 05:34:53.782992
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    from pprint import pprint
    from copy import deepcopy
    from json import loads as json_loads
    from yaml import load as yaml_load
    from typesystem.tokenize_json import tokenize_json
    from typesystem.tokenize_yaml import tokenize_yaml
    # From module constants
    assert len(BaseError()) == 0
    assert not BaseError()
    # From module class ParseError
    parse_error = ParseError(text="foo")
    assert len(parse_error) == 1
    assert parse_error
    # From module class ValidationError
    validation_error = ValidationError(text="foo")
    assert len(validation_error) == 1
    assert validation_error
    # From module class ValidationResult
    validation_result = ValidationResult(value=1)
    assert len

# Generated at 2022-06-22 05:35:06.456072
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(line_no=1, column_no=1, char_index=1) == Position(line_no=1, column_no=1, char_index=1)
    assert not Position(line_no=1, column_no=1, char_index=1) == Position(line_no=1, column_no=1, char_index=2)
    assert not Position(line_no=1, column_no=1, char_index=1) == Position(line_no=1, column_no=2, char_index=1)
    assert not Position(line_no=1, column_no=1, char_index=1) == Position(line_no=2, column_no=1, char_index=1)

# Generated at 2022-06-22 05:35:08.903153
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    # Given
    e1 = BaseError()
    e2 = BaseError()
    # When
    h1 = hash(e1)
    h2 = hash(e2)
    # Then
    assert h1 == h2

# Generated at 2022-06-22 05:35:15.462054
# Unit test for constructor of class ValidationError
def test_ValidationError():
    err = ParseError(text="Failed to parse input", code="parse_error")
    assert dict(err) == {"": "Failed to parse input"}
    assert err.messages() == [
        Message(text="Failed to parse input", code="parse_error")
    ]
    assert err.messages(add_prefix="test") == [
        Message(text="Failed to parse input", code="parse_error", index=["test"])
    ]

# Generated at 2022-06-22 05:35:21.333028
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    p = Position(line_no=1,column_no=1,char_index=1)
    m = Message(text='This is a test message', code = '', key = 1, index = [1,2,3], position = p, start_position = p, end_position = p)
    print(m)
    expect = "Message(text='This is a test message', code='', index=[1, 2, 3], position=Position(line_no=1, column_no=1, char_index=1))"
    assert expect == str(m)

# Generated at 2022-06-22 05:35:26.843151
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    messages = [
        Message(text="Option A", code="custom"),
        Message(text="Option B", code="custom"),
        Message(text="Option C", code="custom"),
    ]
    error = ValidationError(messages=messages)
    result = len(error)
    assert result == 3
