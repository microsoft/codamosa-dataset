

# Generated at 2022-06-22 05:33:10.611437
# Unit test for constructor of class ParseError
def test_ParseError():
    pos = Position(1, 2, 3)
    error = ParseError(
        text="Some error text",
        code="custom",
        position=pos,
        index=["hello"],
    )
    error_msg = error.messages()[0]
    assert error_msg.text == "Some error text"
    assert error_msg.code == "custom"
    assert error_msg.index == ["hello"]
    assert error_msg.start_position == pos
    assert error_msg.end_position == pos
    assert error._message_dict == {"hello": "Some error text"}


if __name__ == "__main__":
    test_ParseError()

# Generated at 2022-06-22 05:33:15.582536
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    # object of class ValidationResult with value and error
    validation_result_1 = ValidationResult(value="value", error="error")
    assert validation_result_1.value == "value"
    assert validation_result_1.error == "error"



# Generated at 2022-06-22 05:33:22.260341
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    assert BaseError(text='A',key=3).messages() == [Message(text='A', code='custom', key=3, index=[3])]
    assert BaseError(messages=[Message(text='A', code='custom', key=3, index=[3])]).messages() == [Message(text='A', code='custom', key=3, index=[3])]
    assert BaseError(text='A').messages() == [Message(text='A', code='custom', key=None, index=[])]
    assert BaseError(messages=[Message(text='A', code='custom', key=None, index=[])]).messages() == [Message(text='A', code='custom', key=None, index=[])]

# Generated at 2022-06-22 05:33:28.826718
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    # We want to test the method `__len__`
    # of class `BaseError`.

    # Create a `BaseError` object using the constructor.
    # Call the constructor as `e1 = BaseError(...)`.
    e1 = BaseError(text="May not have more than 100 characters", code="max_length")

    # This method should return 1.
    assert len(e1) == 1



# Generated at 2022-06-22 05:33:40.225971
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    from datetime import date
    from decimal import Decimal

    from typesystem.types import Date, Decimal as DecimalType, String

    m1 = Message(
        text="this is a message",
        code="Test",
        index=["root","items",0],
        start_position=Position(
            line_no=1,
            column_no=1,
            char_index=0
        ),
        end_position=Position(
            line_no=1,
            column_no=5,
            char_index=5
        )
    )

# Generated at 2022-06-22 05:33:42.369371
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    error = BaseError(text='texto', index=['index'])

    assert error.messages() == [Message('texto', 'custom', ['index'], None, None, None)]

# Generated at 2022-06-22 05:33:52.234059
# Unit test for constructor of class ValidationError
def test_ValidationError():
    error = ValidationError()
    assert repr(error) == "ValidationError([])"

    error = ValidationError(text="text")
    assert repr(error) == "ValidationError(text='text', code='custom')"

    error = ValidationError(text="text")
    assert repr(error) == "ValidationError(text='text', code='custom')"

    error = ValidationError(text="text", code="code")
    assert repr(error) == "ValidationError(text='text', code='code')"

    error = ValidationError(text="text", key="key")
    assert repr(error) == "ValidationError(text='text', code='custom', index=['key'])"

    error = ValidationError(text="text", key="key", code="code")
    assert repr(error)

# Generated at 2022-06-22 05:34:03.624475
# Unit test for constructor of class ValidationError
def test_ValidationError():
  # test if __init__ raise any error
  error = ValidationError(text='subject is required', key='subject')
  assert isinstance(error, BaseError)
  assert isinstance(error, ValidationError)

  error = ValidationError(text='subject is required', key='')
  assert error.text == 'subject is required'
  assert error.key == ''

  error = ValidationError(text='subject is required', message_data={'subject': 'subject is required'})
  assert isinstance(error, ValidationError)
  assert error.text == 'subject is required'
  assert error.message_data == {'subject': 'subject is required'}
  assert error.key == 'subject'

  error = ValidationError(message_data={'subject': 'subject is required'})

# Generated at 2022-06-22 05:34:06.315789
# Unit test for constructor of class Position
def test_Position():
    Position(line_no = 2, column_no = 4, char_index = 6)
    Position(line_no = 2, column_no = 4, char_index = 6)



# Generated at 2022-06-22 05:34:09.839579
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    instance = BaseError(messages=[Message(text="Expected an integer".format())])
    i = 0
    for value in instance:
        i += 1
    assert i == 1


# Generated at 2022-06-22 05:34:17.068178
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    v1 = ValidationResult(value=1)
    assert (1, None) == tuple(v1)
    v2 = ValidationResult(error=ValidationError(text="error"))
    assert (None, ValidationError(text="error")) == tuple(v2)


# Generated at 2022-06-22 05:34:23.545154
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="test", code="test", index=[1, 2, 3]) == Message(text="test", code="test", index=[1, 2, 3])
    assert Message(text="test", code="test", index=[1, 2, 3]) != Message(text="test", code="test", index=[1, 2])


# Generated at 2022-06-22 05:34:32.384757
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error_a = BaseError(text = "test", code = "testCode")
    error_b_text_different = BaseError(text = "test1", code = "testCode")
    error_c_code_different = BaseError(text = "test", code = "testCode1")
    error_d_key_different = BaseError(text = "test", code = "testCode", key = "a")
    error_e_index_different = BaseError(text = "test", code = "testCode", index = ["a"])
    error_f_position_different = BaseError(text = "test", code = "testCode", position = Position(1, 2, 3))

# Generated at 2022-06-22 05:34:36.207234
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    message = Message(text="May not have more than 100 characters", code="max_length", key="username", position=Position(3, 5, 2))

# Generated at 2022-06-22 05:34:38.034385
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert ValidationResult(value = ('a', 'b'))
    assert ValidationResult(error = ('a', 'b'))

# Generated at 2022-06-22 05:34:47.034701
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    from typesystem import Schema, types

    class UserSchema(Schema):
        name = types.String(max_length=10)

    user = {"name": "alice"}
    user_error = UserSchema.validate_or_error(user)
    assert user_error.error is not None
    assert user_error.error == user_error.error

    user_1 = {"name": "alice"}
    user_2 = {"name": "bob"}
    user_error_1 = UserSchema.validate_or_error(user_1)
    user_error_2 = UserSchema.validate_or_error(user_2)
    assert user_error_1.error != user_error_2.error


# Generated at 2022-06-22 05:34:52.041151
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    msg1 = Message(text="This is a test", code="custom")
    msg2 = Message(text="This is a test", code="custom")
    assert msg1.__hash__() == msg2.__hash__()
    msg2 = Message(text="This is another test", code="custom")
    assert msg1.__hash__() != msg2.__hash__()

# Generated at 2022-06-22 05:34:54.486966
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    message = Message(
        text="Error message 1", index=["a", 3, "b"], code="max_length"
    )
    assert "'Error message 1'" in repr(message)



# Generated at 2022-06-22 05:34:59.967348
# Unit test for constructor of class Position
def test_Position():
    one = Position(line_no=1, column_no=1, char_index=1)
    two = Position(line_no=1, column_no=1, char_index=1)
    assert one == two
    assert str(one) == "Position(line_no=1, column_no=1, char_index=1)"


# Generated at 2022-06-22 05:35:12.792972
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    class_name = "Error"  # string
    text = "Some Text"  # string
    code = "named"  # string
    key = "key"  # string
    index = [key] # list of string 

    # option 1
    # position = class Position:
    line_no = 1  # integer
    column_no = 1  # integer
    char_index = 34  # integer
    position = Position(line_no, column_no, char_index)

    # option 2
    # start_position - The start position of the error message within the raw content.
    # end_position - The end position of the error message within the raw content.
    start_position = Position(line_no, column_no, char_index)
    end_position = Position(line_no, column_no, char_index)



# Generated at 2022-06-22 05:35:28.456873
# Unit test for constructor of class Position
def test_Position():
    pos1 = Position(1,2,3)
    pos2 = Position(1,2,3)
    assert pos1 == pos2
    assert pos1.line_no == 1
    assert pos1.column_no == 2
    assert pos1.char_index == 3


# Generated at 2022-06-22 05:35:40.557819
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    messages1 = [Message(text="xxx", code="custom", start_position=Position(1, 1, 1))]
    error1 = BaseError(
        text=None,
        code=None,
        key=None,
        position=None,
        messages=messages1
    )
    assert str(error1) == "xxx"

    messages2 = [
        Message(text="xxx", code="custom", start_position=Position(1, 1, 1), key="key1"),
        Message(text="yyy", code="custom", start_position=Position(2, 2, 2), key="key2"),
        Message(text="zzz", code="custom", start_position=Position(3, 3, 3), key="key3"),
    ]

# Generated at 2022-06-22 05:35:44.143417
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert ValidationResult(value=99).value == 99
    assert ValidationResult(error="Something is wrong").error == "Something is wrong"

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-22 05:35:45.022113
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    pass    # TODO


# Generated at 2022-06-22 05:35:53.347997
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="Not enough characters", start_position=Position(line_no=1, column_no=2, char_index=0), end_position=Position(line_no=1, column_no=2, char_index=0))
    message1_1 = Message(text="Not enough characters", start_position=Position(line_no=2, column_no=3, char_index=1), end_position=Position(line_no=4, column_no=5, char_index=3))
    message2 = Message(text="It has enough characters", start_position=Position(line_no=1, column_no=2, char_index=0), end_position=Position(line_no=1, column_no=2, char_index=0))

# Generated at 2022-06-22 05:36:04.604843
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    a = Position(line_no=1, column_no=2, char_index=3)
    b = Position(line_no=1, column_no=2, char_index=3)
    assert a == b

    b1 = Position(line_no=1, column_no=2, char_index=3)
    b2 = Position(line_no=0, column_no=3, char_index=2)
    assert b1 == b2

    c = Position(line_no=1, column_no=2, char_index=4)
    assert a != c

    d = Position(line_no=1, column_no=2, char_index=3)
    assert a is not d


# Generated at 2022-06-22 05:36:15.580342
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    req_messages = [
        Message(text="May not be None", code="none"),
        Message(text="Must be a two-element array", code="invalid_array_type"),
    ]
    req = BaseError(messages=req_messages)

    messages = [
        Message(text="May not be None", code="none", key="name"),
        Message(
            text="Must be a two-element array",
            code="invalid_array_type",
            key="scores",
        ),
        Message(text="Must be an even number", code="invalid_number", key="age"),
    ]
    error = BaseError(messages=messages)

    assert list(req) == ["invalid_array_type"]

# Generated at 2022-06-22 05:36:24.934623
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    # Case: Single message with key
    message = Message(text='<message>', key='foo')
    assert repr(message) == "Message(text='<message>', code='custom', key='foo')"

    # Case: Single message with index
    message = Message(text='<message>', index=['foo', 'bar'])
    assert (
        repr(message)
        == "Message(text='<message>', code='custom', index=['foo', 'bar'])"
    )

    # Case: Single message with position
    message = Message(text='<message>', position=Position(1, 2, 3))

# Generated at 2022-06-22 05:36:35.904389
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    from typesystem import Validation

    class UserSchema(Validation):
        username: str
        first_name: str
        last_name: str

    e1 = ValidationError(
        messages=[Message(text="username"), Message(text="last_name")]
    )
    e2 = ValidationError(
        messages=[Message(text="username"), Message(text="last_name")]
    )
    e3 = ValidationError(messages=[Message(text="username")])
    e4 = UserSchema.validate({"username": "alice", "first_name": "Alice"})
    assert e1 == e2
    assert e2 == e1
    assert e1 == e1
    assert e1 != e3
    assert e2 != e3
    assert e3 != e1

# Generated at 2022-06-22 05:36:40.490487
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=42)
    actual_iter = iter(vr)
    assert actual_iter.__next__() == 42
    assert actual_iter.__next__() is None


# Generated at 2022-06-22 05:36:56.174221
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    # Test branch coverage of getitem of BaseError
    error = BaseError(text="", code="", key="")
    assert "" in error



# Generated at 2022-06-22 05:37:00.097397
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult(value=123)
    assert isinstance(result, ValidationResult)
    assert not result
    assert result.value == 123
    assert result.error is None
    assert list(result) == [123, None]

    result = ValidationResult(error=ValidationError())
    assert isinstance(result, ValidationResult)
    assert not result
    assert result.value is None
    assert isinstance(result.error, ValidationError)
    assert list(result) == [None, result.error]

# Generated at 2022-06-22 05:37:01.624945
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError(text='This is an error!')



# Generated at 2022-06-22 05:37:06.628864
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    a = ValidationResult(value=1)
    assert a.value == 1
    assert a.error is None

    a = ValidationResult(error=2)
    assert a.value is None
    assert a.error == 2

# Generated at 2022-06-22 05:37:12.747310
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    instance_1 = BaseError()
    instance_2 = BaseError()

    assert instance_1.__hash__() == instance_2.__hash__()

    assert instance_1.__hash__() == type(instance_1).__hash__(instance_1)

    assert isinstance(instance_1.__hash__(), int)

    assert instance_1.__hash__() == hash((instance_1.messages(),))


# Generated at 2022-06-22 05:37:18.335013
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    err = BaseError()
    assert list(iter(err)) == []

    err = BaseError(text="this is a test", key="this_key")
    assert list(iter(err)) == ["this_key"]

    err = BaseError(text="this is a test", key="this_key")
    err_dict = err
    assert list(iter(err_dict)) == ["this_key"]


# Generated at 2022-06-22 05:37:21.292775
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    try:
        s = BaseError()
    except:
        print("AssertionError: test_BaseError___len__")


# Generated at 2022-06-22 05:37:26.801215
# Unit test for constructor of class ValidationError
def test_ValidationError():
  validation_error = ValidationError(text='Some error', key='some_key')
  assert validation_error
  assert validation_error.messages()[0].text == 'Some error'
  assert validation_error.messages()[0].index == ['some_key']

# Function that'll test the ValidationResult class

# Generated at 2022-06-22 05:37:30.453347
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    # Create a Message object and print it
    message_obj = Message(text='text', code='code', index=[1])
    print(message_obj.__hash__())


# Generated at 2022-06-22 05:37:33.653075
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    with pytest.raises(TypeError):
        BaseError().__str__()

    with pytest.raises(TypeError):
        BaseError(messages=[]).__str__()



# Generated at 2022-06-22 05:37:54.047914
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test that equality between two BaseError objects is calculated
    # correctly.
    #
    # Setup: Create two BaseError objects with exactly the same messages
    # list.
    messages = [Message(
        text="Docstring",
        code="custom",
        key=None,
        index=[],
        position=None,
        start_position=None,
        end_position=None
    )]
    error_one = BaseError(messages=messages)
    error_two = BaseError(messages=messages)
    # Test: Test for equality.
    eq_(error_one, error_two)



# Generated at 2022-06-22 05:37:56.987376
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
	assert BaseError(key="a",text="message")["a"] == "message"


# Generated at 2022-06-22 05:38:00.964893
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    assert repr(ValidationResult(error=ValidationError(text="Foo"))) == "ValidationResult(error=ValidationError(text='Foo', code='custom'))"
    assert repr(ValidationResult(value=42)) == "ValidationResult(value=42)"

# Generated at 2022-06-22 05:38:05.280626
# Unit test for constructor of class Position
def test_Position():
    pos = Position(1,2,3)
    assert(pos.line_no == 1)
    assert(pos.column_no == 2)
    assert(pos.char_index == 3)


# Generated at 2022-06-22 05:38:15.387479
# Unit test for method __getitem__ of class BaseError

# Generated at 2022-06-22 05:38:27.305436
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text='a') == BaseError(text='a')
    assert BaseError(text='a') != BaseError(text='b')
    assert BaseError(text='a') != BaseError(text='a', code='b')
    assert BaseError(text='a') != BaseError(text='a', key=1)
    assert BaseError(text='a') != BaseError(messages=[])
    assert BaseError(messages=[
        Message(text='a')
    ]) == BaseError(messages=[
        Message(text='a')
    ])
    assert BaseError(messages=[
        Message(text='a', code='b')
    ]) != BaseError(messages=[
        Message(text='a')
    ])

# Generated at 2022-06-22 05:38:30.564136
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    # Test for correct repr
    position = Position(1, 2, 3)
    assert repr(position) == "Position(line_no=1, column_no=2, char_index=3)"



# Generated at 2022-06-22 05:38:38.826231
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code")
    message2 = Message(text="text", code="other_code")
    message3 = Message(text="other_text", code="code")
    message4 = Message(text="text", code="code", index=[1, 2])
    message5 = Message(text="text", code="code", index=[3, 4])
    message6 = Message(text="other_text", code="code", index=[1, 2])
    message7 = Message(text="text", code="other_code", index=[1, 2])
    message8 = Message(text="text", code="code", index=[1, 2], start_position=Position(1, 2, 1))

# Generated at 2022-06-22 05:38:49.943134
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    def create():
        return BaseError(text='test', code='test', key='test', position='test', messages='test')
    def create_copy(copy):
        return BaseError(text=copy.text, code=copy.code, key=copy.key, position=copy.position, messages=copy.messages)

    # Check that all instances of the class are equal
    equal_instances = [create() for _ in range(10)]
    assert len({id(i) for i in equal_instances}) == 1

    # Assert that each instance is equal to another instance created with the same arguments
    def create_args(*args, **kwargs):
        return [arg for arg in args] + [f"{key}={value}" for key, value in kwargs.items()]

# Generated at 2022-06-22 05:39:00.622503
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    # (1) dict with not key error
    error_dict = dict(
        error=dict(
            username="Username must start with a letter"
        )
    )
    base_error = BaseError(messages=[
        Message(
            text="Username must start with a letter",
            code="username_start_with_letter",
            key="username",
        )
    ])
    base_error_hash = base_error.__hash__()

    # (2) dict with key error
    error_dict2 = dict(
        error=dict(
            username=dict(
                first="Username must start with a letter"
            )
        )
    )

# Generated at 2022-06-22 05:39:34.289591
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    cases = [
        (
            Message("foo", "bar"),
            Message("foo", "bar", add_prefix="x"),
        ),
        (Message("foo"), Message("foo", add_prefix="x")),
        (
            Message("foo", index=[1, 2]),
            Message("foo", index=[1, "x", 2], add_prefix="x"),
        ),
        (
            Message("foo", index=["a", 1, 2]),
            Message("foo", index=["a", "x", 1, 2], add_prefix="x"),
        ),
    ]

    for case in cases:
        obj = BaseError(messages=[case[0]])
        assert obj.messages(add_prefix="x") == [case[1]]



# Generated at 2022-06-22 05:39:40.167031
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    vr = ValidationResult(value=1)
    assert vr.value == 1
    assert vr.error is None

    vr = ValidationResult(error="error")
    assert vr.value is None
    assert vr.error == "error"

    assert bool(ValidationResult(value=1)) is True
    assert bool(ValidationResult(error=1)) is False



# Generated at 2022-06-22 05:39:50.267517
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    # set up
    msg1 = Message(text="test", code="test", index=[1,2,3])
    msg2 = Message(text="test", code="test", index=[1,2,3])
    msg3 = Message(text="test", code="test", index=[1,2,3])
    # test __hash__
    assert hash(msg1) == hash(msg2) == hash(msg3)
    # set up
    msg2 = Message(text="test", code="test", index=[3,2,1])
    # test __hash__
    assert hash(msg1) != hash(msg2)


# Generated at 2022-06-22 05:39:55.326077
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    class_name = "ValidationResult"
    value = "value"
    error = "error"

    assert eval(f"{class_name}(value={value!r})") == ValidationResult(value=value)
    assert eval(f"{class_name}(error={error!r})") == ValidationResult(error=error)


# Generated at 2022-06-22 05:40:01.992385
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    messages = [
        Message(text="Did not meet in person."),
        Message(text="Does not talk about personal life."),
        Message(text="Refuses to answer personal questions."),
        Message(text="Has no family member or close friend."),
        Message(text="No information about the past."),
        Message(text="Does not reveal where he lives."),
        Message(text="Hides information about his family."),
        Message(text="Keeps only online contacts (no physical contact)."),
        Message(text="Declares love only after a few letters or messages."),
        Message(text="Does not like to meet in person."),
        Message(text="Avoid on-line meeting."),
    ]
    error = BaseError(messages=messages)
    # Assertion
    assert len(error)==0
    
#

# Generated at 2022-06-22 05:40:09.088027
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    message1 = Message(text="test text")
    message2 = Message(
        text="test text",
        code="test code",
        key=True,
        index=[12345, 678],
        position=Position(1, 2, 3),
        start_position=Position(3, 4, 5),
        end_position=Position(5, 6, 7)
    )
    assert type(message1.__hash__()) is int
    assert message1.__hash__() == message1.__hash__()
    assert message2.__hash__() == message2.__hash__()
    assert message1.__hash__() != message2.__hash__()


# Generated at 2022-06-22 05:40:20.065005
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Create a ValidationError
    error = ValidationError(text="Field is required", key="username")
    # Validate BaseError.__eq__
    assert error
    assert error.messages()
    assert error.messages(add_prefix="users")
    assert error.messages(add_prefix=0)
    assert error.messages(add_prefix=0)[0].text == "Field is required"
    assert error.messages(add_prefix=0)[0].code == "custom"
    assert error.messages(add_prefix=0)[0].index == ["users", "username"]
    assert error.messages(add_prefix=0)[0].start_position == None
    assert error.messages(add_prefix=0)[0].end_position == None

# Generated at 2022-06-22 05:40:23.988046
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result_data = ValidationResult(value=3)
    result_error = ValidationResult(error=ValidationError(text="asdf"))

    assert result_data.value == 3
    assert result_error.error.text == "asdf"


# Generated at 2022-06-22 05:40:34.676898
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    # Case 1: empty BaseError instance
    error = ParseError()
    assert str(error) == "{}"
    error = ValidationError()
    assert str(error) == "{}"
    # Case 2: empty BaseError instance with text
    error = ParseError(text="test")
    assert str(error) == "test"
    error = ValidationError(text="test")
    assert str(error) == "test"
    # Case 3: BaseError instance with messages
    messages = [Message(text="test", code="test", key=1)]
    error = ParseError(messages=messages)
    assert str(error) == "{1: 'test'}"
    error = ValidationError(messages=messages)
    assert str(error) == "{1: 'test'}"

# Generated at 2022-06-22 05:40:36.938436
# Unit test for constructor of class ValidationError
def test_ValidationError():
    test = ValidationError(messages=[Message(text="asdf"), Message(text="asdf")])
    assert test._messages == [Message(text="asdf"), Message(text="asdf")]

# Generated at 2022-06-22 05:41:36.442978
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    m1 = Message(text='may not have more than 100 characters', code='max_length', key='username')
    m2 = Message(text='may not have more than 100 characters', code='max_length', key='username')
    assert m1 == m2



# Generated at 2022-06-22 05:41:44.658552
# Unit test for constructor of class Message
def test_Message():
    test_Message = Message("testing", "test_code", 1, [1, 2, 3])
    assert test_Message.text == "testing"
    assert test_Message.code == "test_code"
    assert test_Message.key == 1
    assert test_Message.index == [1, 2, 3]
    assert test_Message.start_position == test_Message.end_position == test_Message.position
    # Unit test for __eq__ of class Message
    assert test_Message == Message("testing", "test_code", 1, [1, 2, 3])
    assert Message("testing", "test_code", 1, [1, 2, 3]) == test_Message
    assert Message("testing", "test_code") != Message("test", "test_code")

# Generated at 2022-06-22 05:41:50.997046
# Unit test for constructor of class BaseError
def test_BaseError():
    # Create a BaseError instance for testing
    baseError = BaseError(text="spam", code="spam code")
    # Test whether the __init__ function for BaseError is working correctly
    assert(baseError._messages[0].text == "spam")
    assert(baseError._messages[0].code == "spam code")


# Generated at 2022-06-22 05:41:52.746479
# Unit test for constructor of class Position
def test_Position():
    assert Position(1,1,1) == Position(1,1,1)


# Generated at 2022-06-22 05:41:56.150966
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    for i, item in enumerate(vr):
        if i==0:
            assert item==1
        else:
            assert item is None


# Generated at 2022-06-22 05:41:58.396386
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    a = ValidationResult(value=1)
    assert repr(a) == "ValidationResult(value=1)"


# Generated at 2022-06-22 05:42:00.961494
# Unit test for constructor of class Position
def test_Position():
    pos = Position(line_no=10, column_no=2, char_index=3)
    assert pos.line_no == 10
    assert pos.column_no == 2
    assert pos.char_index == 3


# Generated at 2022-06-22 05:42:02.918357
# Unit test for constructor of class ValidationError
def test_ValidationError():
    error = ValidationError(text="this is a message")  # type: ignore

# Generated at 2022-06-22 05:42:11.750777
# Unit test for constructor of class Message
def test_Message():
    line_no = 12
    column_no = 3
    char_index = 4
    text = "May not have more than 100 characters"
    code = "max_length"
    key = "username"
    index = ["users", 3, "username"]
    assert Message(text=text, code=code, key=key, position=Position(line_no, column_no, char_index)) == Message(text=text, code=code, key=key, position=Position(line_no, column_no, char_index))

# Generated at 2022-06-22 05:42:20.261788
# Unit test for constructor of class BaseError
def test_BaseError():
    message_1 = Message(text='text-1', code='code-1', key='key-1')
    message_1_1 = Message(text='text-1-1', code='code-1-1', key='key-1-1')
    message_1_2 = Message(text='text-1-2', code='code-1-2', key='key-1-2')
    message_2 = Message(text='text-2', code='code-2', key='key-2')
    message_2_1 = Message(text='text-2-1', code='code-2-1', key='key-2-1')
    message_2_2 = Message(text='text-2-2', code='code-2-2', key='key-2-2')