

# Generated at 2022-06-22 05:33:13.493292
# Unit test for constructor of class BaseError
def test_BaseError():
    input = "hello world"
    error = BaseError(text=input)
    assert dict(error) == {"" : input}, "constructor of class BaseError failed"


# Generated at 2022-06-22 05:33:24.871601
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    error = BaseError(messages=[
        Message(text='A', code='a', index=[]),
        Message(text='B', code='b', index=['x']),
        Message(text='C', code='c', index=['x', 1]),
        Message(text='D', code='d', index=['x', 2, 'y']),
        Message(text='E', code='e', index=['x', 3]),
    ])

# Generated at 2022-06-22 05:33:36.561313
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    message_hash = hash(Message(text="asdf", code="asdf", key="asdf"))
    message_hash = hash(Message(text="asdf", code="asdf"))
    message_hash = hash(
        Message(text="asdf", index=[1, 2, 3])
    )  # different index, different hash
    message_hash = hash(Message(text="asdf"))
    message_hash = hash(
        Message(text="asdf", index=[])
    )  # different index, same hash


# Generated at 2022-06-22 05:33:40.380477
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    assert repr(Position(line_no=1, column_no=1, char_index=1)) == "Position(line_no=1, column_no=1, char_index=1)"


# Generated at 2022-06-22 05:33:47.608060
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    a = BaseError(text='text1', code='code1', key='key1')
    b = BaseError(text='text1', code='code1', key='key1')
    c = BaseError(text='text1', code='code1', key='key2')
    d = BaseError(messages=[Message(text='text1', code='code1', key='key1'), Message(text='text2', code='code2', key='key2')])
    e = BaseError(messages=[Message(text='text1', code='code1', key='key1'), Message(text='text2', code='code2', key='key2')])


# Generated at 2022-06-22 05:33:50.877704
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    first = Position(line_no=1, column_no=2, char_index=3)
    second = Position(line_no=1, column_no=2, char_index=3)
    assert first == second


# Generated at 2022-06-22 05:33:53.822271
# Unit test for constructor of class Position
def test_Position():
    Position(line_no = 1, column_no = 1, char_index = 1)


# Generated at 2022-06-22 05:33:56.427165
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    error = BaseError(text="field is required")
    assert str(error) == "field is required"


# Generated at 2022-06-22 05:34:07.856274
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    # Test a single message.
    error = BaseError(text="Invalid type", code="invalid_type", key="username")
    assert error["username"] == "Invalid type"
    assert list(error.messages()) == [Message(text="Invalid type", code="invalid_type", key="username")]

    # Test two messages at the same level.
    error = BaseError(
        messages=[
            Message(text="Invalid type", code="invalid_type", key="username"),
            Message(text="This field is required", code="required", key="password"),
        ]
    )
    assert error["username"] == "Invalid type"
    assert error["password"] == "This field is required"

# Generated at 2022-06-22 05:34:19.215665
# Unit test for constructor of class ParseError
def test_ParseError():

    with pytest.raises(AssertionError, match=r".*Default value must be of type: None"):
        a=ParseError(text='text', code='code', key='key', position='position', messages='messages')

    with pytest.raises(AssertionError, match=r".*Expected one of: \['messages'\]+"):
        a=ParseError(text='text', code='code', key='key', position='position')

    with pytest.raises(AssertionError, match=r".*Expected one of: \['text'\]+"):
        a=ParseError(code='code', key='key', position='position', messages='messages')


# Generated at 2022-06-22 05:34:32.971977
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    v = ValidationResult(value=None)
    assert v.value == None


# Generated at 2022-06-22 05:34:40.804537
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    a = Message(text="asdf", code="foobar")
    b = Message(text="asdf", code="foobar")
    assert a == b

    c = Message(text="asdf", code="foobar", key="foo")
    assert a != c

    d = Message(text="asdf", code="foobar", index=[1, 2, 3])
    assert a != d

    e = Message(text="asdf", code="foobar", position=Position(1, 2, 3))
    assert a != e

    f = Message(text="asdf", code="foobar", start_position=Position(1, 2, 3))
    assert a != f

    g = Message(text="asdf", code="foobar", end_position=Position(1, 2, 3))
    assert a != g


# Generated at 2022-06-22 05:34:53.280421
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    # Test with any, bool and None
    position_instance = Position(1, 1, 1)
    assert position_instance.__eq__(None) == False
    assert position_instance.__eq__(True) == False
    assert position_instance.__eq__(False) == False

    # Test with Position instance
    position_1 = Position(1, 1, 1)
    position_2 = Position(1, 1, 1)
    assert position_1.__eq__(position_2) == True

    position_1 = Position(1, 1, 1)
    position_2 = Position(1, 1, 2)
    assert position_1.__eq__(position_2) == False

    position_1 = Position(1, 2, 1)
    position_2 = Position(1, 1, 1)
    assert position_1

# Generated at 2022-06-22 05:34:57.923606
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    error = BaseError(text="text", code="code", key="key")
    messages = error.messages()
    assert len(messages) == 1
    assert messages[0].text == "text"
    assert messages[0].code == "code"
    assert messages[0].index == ["key"]

# Generated at 2022-06-22 05:35:10.689620
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="hello", code="world", position="blah")
    message2 = Message(text="hello", code="world", position="blah")
    message3 = Message(text="hello", code="universe", position="blah")
    message4 = Message(text="hello", code="world", position="different")
    message5 = Message(text="hello", code="world", index=[1, 2])
    message6 = Message(text="hello", code="world", index=[1, 2])
    message7 = Message(text="hello", code="universe", index=[1, 2])
    message8 = Message(text="hello", code="world", index=[1, 3])

    assert message1._Message__eq__(message2)
    assert not message1._Message__eq__(message3)
    assert not message1

# Generated at 2022-06-22 05:35:21.212028
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    with pytest.raises(AssertionError):
        BaseError(text="a", code="b", key="c", position="d", messages=[1, 2, 3])
    with pytest.raises(AssertionError):
        BaseError(text="a", code="b", key="c", position="d", messages=[])
    with pytest.raises(AssertionError):
        BaseError(code="a")
    with pytest.raises(AssertionError):
        BaseError(text="a")
    error = BaseError(messages=[Message(text="a", code="b", key="c")])
    assert len(error) == 1
    assert error["c"] == "a"
    assert iter(error).__next__() == "c"

# Generated at 2022-06-22 05:35:23.267076
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    message = BaseError(text='xxx')
    assert len(message) == 1



# Generated at 2022-06-22 05:35:35.072840
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    text = 'May not have more than 100 characters'
    code = 'max_length'
    key = 'users'
    index = ['users', 3, 'username']
    position = Position(line_no=3, column_no=4, char_index=4)
    start_position = Position(line_no=4, column_no=4, char_index=4)
    end_position = Position(line_no=5, column_no=4, char_index=4)
    message = Message(
        text=text,
        code=code,
        key=key,
        index=index,
        position=position,
        start_position=start_position,
        end_position=end_position
    )

# Generated at 2022-06-22 05:35:44.789164
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    msg1 = Message(text="msg1")
    msg2 = Message(text="msg2")
    msg3 = Message(text="msg3")
    be1 = BaseError(messages=[msg1, msg2, msg3])
    assert len(be1) == 3
    # test with key:index
    msg4 = Message(text="msg4", index=["index1"])
    msg5 = Message(text="msg5", index=["index2"])
    msg6 = Message(text="msg6", index=["index1"])
    be2 = BaseError(messages=[msg4, msg5, msg6])
    assert len(be2) == 3


# Generated at 2022-06-22 05:35:47.015610
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    # Check the content of the function BaseError.__repr__
    # Test the function BaseError.__repr__
    pass


# Generated at 2022-06-22 05:36:08.480561
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    # Test with one same instance
    a = Position(1, 2, 3)  # type: Position
    assert a.__eq__(a) == True

    # Test with same values
    b = Position(1, 2, 3)  # type: Position
    assert a.__eq__(b) == True

    # Test with different values
    c = Position(1, 2, 4)  # type: Position
    assert a.__eq__(c) == False


# Generated at 2022-06-22 05:36:17.642854
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    def case(left: Message, right: Message):
        assert left == right
        assert right == left
        assert hash(left) == hash(right)

    yield case, Message(text='abc'), Message(text='abc')
    yield case, Message(text='abc', code='abc'), Message(text='abc', code='abc')
    yield case, Message(text='abc', index=[1]), Message(text='abc', index=[1])
    yield case, Message(text='abc', index=[1, 2]), Message(text='abc', index=[1, 2])
    yield case, Message(text='abc', index=[1, 2], code='abc'), Message(text='abc', index=[1, 2], code='abc')

# Generated at 2022-06-22 05:36:26.226952
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    err = BaseError(messages=[Message(text='May not have more than 100 characters',
                                      code='max_length',
                                      key=['users', 3, 'username'],
                                      position=Position(line_no=3, column_no=5, char_index=40),
                                     ),
                             ])
    assert repr(err) == "BaseError([Message(text='May not have more than 100 characters', code='max_length', index=['users', 3, 'username'], position=Position(line_no=3, column_no=5, char_index=40))])"


# Generated at 2022-06-22 05:36:31.248257
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    # @see: https://stackoverflow.com/a/38455161
    def create_BaseError(*args, **kwargs):
        return BaseError(*args, **kwargs)

    BaseErrorInst = create_BaseError()
    assert 1 == BaseErrorInst.__len__()



# Generated at 2022-06-22 05:36:34.600831
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    assert repr(Position(line_no=3, column_no=6, char_index=8)) == \
          "Position(line_no=3, column_no=6, char_index=8)"


# Generated at 2022-06-22 05:36:42.459727
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    text = 'text'
    code = 'code'
    key = 'key'
    position = 'position'
    messages = Message(text = text, code = code, key = key, position = position)
    BaseError(text = text, code = code, key = key, position = position, messages = messages)
    BaseError(messages = messages)


# Generated at 2022-06-22 05:36:51.543758
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    messages = [
        Message(text='Debes tener al menos 18 años', code='min_age'),
        Message(text='Debes tener al menos 18 años', code='min_age', key='birthday'),
    ]
    error = BaseError(messages=messages)
    assert isinstance(error, Mapping)
    assert isinstance(error, dict)
    assert error['birthday'] == 'Debes tener al menos 18 años'
    assert error[''] == 'Debes tener al menos 18 años'

# Generated at 2022-06-22 05:37:03.320852
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    # msg_0
    msg_0 = Message(text="text_0", code="code_0", key="key_0", position="position_0")
    print(msg_0)
    assert msg_0.__repr__() == "Message(text='text_0', code='code_0', index=['key_0'], position='position_0')"

    # msg_1
    msg_1 = Message(text="text_1", code="code_1", index="index_1", start_position="start_position_1", end_position="end_position_1")
    print(msg_1)

# Generated at 2022-06-22 05:37:07.565339
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    # Test that two Position instances are equal to each other.
    assert Position(line_no=1, column_no=2, char_index=3) == Position(line_no=1, column_no=2, char_index=3)


# Generated at 2022-06-22 05:37:10.715173
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    m = Message(text="sometext", code="somemessagecode", key=1)
    assert hash(m) != 0


# Generated at 2022-06-22 05:37:38.457061
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    error = BaseError(messages=[Message(text='May not have more than 100 characters', key='first_name')])
    len(error) == 1


# Generated at 2022-06-22 05:37:41.158159
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    err = BaseError(text="Hello, world!")
    hash(err)


# Generated at 2022-06-22 05:37:47.375487
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    # Test the case when value is not None and error is None
    value = 'value_1'
    error = None
    assert ValidationResult.__repr__(value, error) == f"{class_name}(value={value!r})"
    # Test the case when value is None and error is not None
    value = None
    error = 'error_1'
    assert ValidationResult.__repr__(value, error) == f"{class_name}(error={error!r})"

# Generated at 2022-06-22 05:37:50.807347
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    m1 = Message(text="asd", code="a", index=[1,2,3])
    m2 = Message(text="asd", code="a", index=[1,2,3])
    assert m1 == m2


# Generated at 2022-06-22 05:37:55.253815
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    assert str(ValidationError(text='hi')) == 'hi'
    assert str(ValidationError(messages=[Message(text='hi')])) == '{\'\': \'hi\'}'
    assert str(ValidationError(messages=[Message(text='hi', code='test')])) == '{\'\': \'hi\'}'
    assert str(ValidationError(messages=[Message(text='hi', code='test', key='test')])) == '{\'test\': \'hi\'}'

    print('test__str_of_base_error passed')


# Generated at 2022-06-22 05:38:06.348406
# Unit test for constructor of class Message
def test_Message():
    message_list = []
    message = Message(
        text="May not have more than 100 characters",
        code="max_length",
        key="username",
        position=Position(line_no=2, column_no=10, char_index=20),
    )
    message_list.append(message)
    message = Message(
        key="password",
        text="May not have more than 100 characters",
        code="max_length",
        index=[0],
        position=Position(line_no=2, column_no=10, char_index=20),
    )
    message_list.append(message)

# Generated at 2022-06-22 05:38:08.795259
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    error = BaseError(text="a message", code="a_code")
    assert error.messages() == [Message(text="a message", code="a_code")]

# Generated at 2022-06-22 05:38:19.577605
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    class MyError(BaseError):
        pass
    if __debug__:
        assert str(MyError("Some error")) == "Some error"
        assert str(MyError("Some error", code="some code")) == "Some error"
        assert str(MyError("Some error with some data", key="data")) == "{'data': 'Some error with some data'}"
        assert (
            str(
                MyError(
                    "Some error with some data",
                    key="data",
                    code="some code",
                )
            )
            == "{'data': 'Some error with some data'}"
        )

# Generated at 2022-06-22 05:38:24.576596
# Unit test for constructor of class Message
def test_Message():
    message = Message(text="Test text", code="Test code", key=[1, 2, 3])
    assert message.text == "Test text"
    assert message.code == "Test code"
    assert message.index == [1, 2, 3]



# Generated at 2022-06-22 05:38:35.074644
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    # positional arguments (parameters)
    text = "str"
    code = "ignore"
    key = "str"
    index = ["str"]
    start_position = Position(1, 2, 3)
    end_position = Position(2, 3, 4)
    # instantiate a message
    message = Message(text=text, code=code, key=key, index=index, start_position=start_position, end_position=end_position)
    assert message.__hash__() == hash(("ignore", ("str",)))
    text = "str"
    code = "str"
    index = ["str"]
    start_position = Position(1, 2, 3)
    end_position = Position(2, 3, 4)

# Generated at 2022-06-22 05:40:29.395824
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    e = BaseError(text = "a", code = "b", key = "c")
    assert e.messages() == [Message(text = "a", code = "b", key = "c")]
    assert e.messages(add_prefix = "d") == [Message(text = "a", code = "b", index = ["d","c"])]

# Generated at 2022-06-22 05:40:34.205051
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    b1 = BaseError()
    assert repr(b1) == "BaseError(error={})"

    b2 = BaseError(text = 'error-text')
    assert repr(b2) == "BaseError(text='error-text', code='custom')"


# Generated at 2022-06-22 05:40:38.264172
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    error = ValidationError(messages=[Message(text='error_message', code='code', index=[1, 'a'])])
    assert error._message_dict == {1: {'a': 'error_message'}}
    assert error['a'] == 'error_message'

# Generated at 2022-06-22 05:40:41.408865
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    import typing
    import typesystem


    class String(typesystem.String):
        pass


    schema = String()
    output = schema.validate_or_error(10)
    error = output.error
    assert isinstance(error,Exception)

# Generated at 2022-06-22 05:40:50.677998
# Unit test for constructor of class Message
def test_Message():
    start_position = Position(line_no=1, column_no=2, char_index=3)
    end_position = Position(line_no=4, column_no=5, char_index=6)
    message = Message(
        text="May not have more than 100 characters",
        code="max_length",
        key="username",
        start_position=start_position,
        end_position=end_position,
    )
    assert message.text == "May not have more than 100 characters"
    assert message.code == "max_length"
    assert message.index == ["username"]
    assert message.start_position == start_position
    assert message.end_position == end_position


# Generated at 2022-06-22 05:40:54.550304
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Setup
    self = Message(text='The error message.', code='code', index=['a', 'b', 123])
    other = Message(text='The error message.', code='code', index=['a', 'b', 123])
    # Exercise
    actual = self.__eq__(other)
    # Verify
    assert actual == True
    

# Generated at 2022-06-22 05:40:58.423706
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="message1", code="The code", key="The key")

    message2 = Message(text="message1", code="The code", key="The key")

    assert message1.__eq__(message2) == True


# Generated at 2022-06-22 05:41:09.101972
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    # constructor test 1
    v1 = ValidationResult(value=True)
    try:
        assert v1.value
        assert v1.error is None
        assert True
    except:
        assert False
    # constructor test 2
    v2 = ValidationResult(error=True)
    try:
        assert v2.value is None
        assert v2.error
        assert True
    except:
        assert False
    # constructor test 3
    try:
        v3 = ValidationResult(value=True, error=False)
    except AssertionError:
        assert True
    # constructor test 4
    try:
        v4 = ValidationResult(value=False)
    except AssertionError:
        assert True
    # constructor test 5

# Generated at 2022-06-22 05:41:13.033761
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    # test_BaseError___getitem__() - unit test for method __getitem__ of class BaseError
    # _getitem__(self, key) -> typing.Union[str, dict]
    def str(arg):
        return arg
    T = type('T', (object,), {'__str__': str})
    error = BaseError(text='text', code='code', key=T())
    m = (isinstance(error[T()], str)
         and isinstance(error[''], str)
         and type(error.get(T(), None)) is str
         and type(error.get('')) is str
         and error[T()] == 'text'
         and error[''] == 'text')
    success(m)

# Generated at 2022-06-22 05:41:14.123195
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError(text="test parse error")
    assert error.messages() == [Message(text="test parse error", code="custom")]


# Generated at 2022-06-22 05:42:23.750999
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    error1 = BaseError(text="abc", code="code", key="key", position=Position(1, 2, 3))
    error2 = BaseError(text="abc", code="code", key="key", position=Position(1, 2, 3))
    # Calling method __hash__
    hash1 = error1.__hash__()
    hash2 = error2.__hash__()

    # These two hash values should not be equal
    assert hash1 != hash2

# Generated at 2022-06-22 05:42:33.557225
# Unit test for constructor of class ParseError
def test_ParseError():
    try: raise ParseError(text = 'text', code = 'code', position = Position(line_no = 1, column_no = 2, char_index = 3), index = ['text', 'code'])
    except ParseError as exc:
        assert str(exc) == 'text'
        assert exc.text == 'text'
        assert exc.code == 'code'
        assert exc.index == ['text', 'code']
        assert exc.start_position == Position(line_no = 1, column_no = 2, char_index = 3)
        assert exc.end_position == Position(line_no = 1, column_no = 2, char_index = 3)

# Generated at 2022-06-22 05:42:37.640066
# Unit test for constructor of class ParseError
def test_ParseError():
    s = ParseError()
    s = ParseError(code = 'max_length', messages = ['aa'])
    s = ParseError(code = 'max_length', key = 'a', messages = ['aa'])
    s = ParseError(
        code = 'max_length',
        messages = [
            Message(text = 'aa', code = 'max_length', position = Position(1, 2, 3))
        ]
    )


# Generated at 2022-06-22 05:42:41.123150
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert ValidationResult(value = None, error = None)
    assert ValidationResult(value = True, error = None)
    assert ValidationResult(value = None, error = "error")

# Generated at 2022-06-22 05:42:46.452967
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(error='some error')
    value, error = vr
    assert error == 'some error'
    assert value is None
    value, error = list(vr)
    assert error == 'some error'
    assert value is None
    vr = ValidationResult(value='some value')
    value, error = vr
    assert error is None
    assert value == 'some value'
    value, error = list(vr)
    assert error is None
    assert value == 'some value'



# Generated at 2022-06-22 05:42:51.099138
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    assert str(ValidationError(text='some error information')) == 'some error information'
    assert str(ValidationError(messages=[Message(text='error information 1'), 
                                          Message(text='error information 2')])) == "{'': 'error information 1', '': 'error information 2'}"


# Generated at 2022-06-22 05:42:52.632610
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    error = BaseError(text="Hello", code="message")
    assert list(error) == [""]
