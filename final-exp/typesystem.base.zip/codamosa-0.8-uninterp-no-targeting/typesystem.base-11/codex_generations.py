

# Generated at 2022-06-22 05:33:09.467315
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    x = BaseError(text="test", code="test", key="test")
    assert x.messages() == [Message(text="test", code="test", key="test")]

# Generated at 2022-06-22 05:33:12.090419
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    assert bool(ValidationResult(value=1)) == True
    assert bool(ValidationResult(error=ValidationError())) == False

# Generated at 2022-06-22 05:33:20.592135
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert ValidationResult(value=1) == ValidationResult(value=1)
    assert ValidationResult(value=2) != ValidationResult(value=1)
    assert ValidationResult(error=ValidationError(text="a")) == ValidationResult(error=ValidationError(text="a"))
    assert ValidationResult(error=ValidationError(text="b")) != ValidationResult(error=ValidationError(text="a"))
    assert ValidationResult(value=1) != ValidationResult(error=ValidationError(text="a"))

# Generated at 2022-06-22 05:33:32.002502
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    m1 = Message(text="a", code="a", key="a")
    m2 = Message(text="a", code="a", key="a")
    m3 = Message(text="a", code="a", key="b")
    m4 = Message(text="a", code="a", index=["a"])
    m5 = Message(text="a", code="a", index=[2])
    m6 = Message(text="a", code="a", index=["a", 2])
    m7 = Message(text="a", code="a", index=["a", 2, 3])
    assert hash(m1) == hash(m2)
    assert hash(m1) != hash(m3)
    assert hash(m1) == hash(m4)
    assert hash(m1) != hash(m5)


# Generated at 2022-06-22 05:33:43.730520
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    def calc(arg):
        return Message(**arg)
    assert calc(dict(text='May not have more than 100 characters', code=None, key=None, index=[], start_position=Position(line_no=0, column_no=0, char_index=0), end_position=Position(line_no=0, column_no=0, char_index=0))) == calc(dict(text='May not have more than 100 characters', code=None, key=None, index=[], position=Position(line_no=0, column_no=0, char_index=0)))

# Generated at 2022-06-22 05:33:53.472891
# Unit test for constructor of class ParseError
def test_ParseError():
    msg1 = Message(
        text="Expected property name enclosed in double quotes",
        code="expected_property_name_string",
        position=Position(
            line_no=1, column_no=2, char_index=1
        ),
    )
    msg2 = Message(
        text="Expected property name enclosed in single quotes",
        code="expected_property_name_string",
        position=Position(
            line_no=1, column_no=3, char_index=2
        ),
    )

    # Test for __init__
    print("Test for constructor of ParseError class: ")
    multiple_error = ParseError(messages=[msg1, msg2])
    assert multiple_error._messages == [msg1, msg2]
    print("Constructor works as expected")

    # Test for

# Generated at 2022-06-22 05:34:05.344971
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert bool(ValidationResult(value=None)) is False
    assert bool(ValidationResult(error=None)) is False
    assert bool(ValidationResult(value=1)) is True
    assert bool(ValidationResult(error=ValidationError(text='foobar'))) is False
    assert repr(ValidationResult(value=None)) == 'ValidationResult(value=None)'
    assert repr(ValidationResult(error=None)) == 'ValidationResult(error=None)'
    assert repr(ValidationResult(value=1)) == 'ValidationResult(value=1)'
    assert repr(ValidationResult(error=ValidationError(text='foobar'))) == 'ValidationResult(error=ValidationError(text=\'foobar\', code=\'custom\'))'

# Generated at 2022-06-22 05:34:09.338966
# Unit test for constructor of class Position
def test_Position():
    line_no = 1
    column_no = 2
    char_index = 3
    assert Position(line_no, column_no, char_index) == Position(line_no, column_no, char_index)



# Generated at 2022-06-22 05:34:16.804361
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    e1 = BaseError(messages = [Message(text='T1'), Message(text='T2')])
    e2 = BaseError(messages = [Message(text='T1', key='key'), Message(text='T2')])
    assert list(e1.messages()) == [Message(text='T1'), Message(text='T2')]
    assert list(e2.messages()) == [Message(text='T1', key='key'), Message(text='T2')]



# Generated at 2022-06-22 05:34:29.083195
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    from hypothesis import given
    import hypothesis.strategies as st
    import hypothesis.extra.datetime as dt
    import datetime as dt
    import typesystem as ts

    @given(st.one_of(st.integers(), st.text(), st.none(), st.booleans(), st.floats()))
    def test_valid_type(value):
        assert repr(ts.ValidationResult(value=value)) == "ValidationResult(value={!r})".format(value)
        assert repr(ts.ValidationResult(error=value)) == "ValidationResult(error={!r})".format(value)


# Generated at 2022-06-22 05:34:41.710174
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_1 = Message(text="", code="1", index=[1, 2], start_position=Position(1, 2, 3), end_position=Position(2, 3, 4))
    message_2 = Message(text="", code="1", index=[1, 2], start_position=Position(1, 2, 3), end_position=Position(2, 3, 4))
    assert message_1 == message_2


# Generated at 2022-06-22 05:34:49.564922
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    foo = BaseError(text='a', code='a', key='a', position=Position(1,1,1), messages=None)
    foo_hash = hash(foo)
    bar = BaseError(text='a', code='a', key='a', position=Position(1,1,1), messages=None)
    bar_hash = hash(bar)
    assert foo_hash == bar_hash
    # assert foo_hash == foo.__hash__()

# Generated at 2022-06-22 05:35:00.901622
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    msg = Message(text='May not have more than 100 characters', code='max_length', key='username')
    assert repr(msg) == "Message(text='May not have more than 100 characters', code='max_length', index=['username'])"
    msg = Message(text='May not have more than 100 characters', code='max_length', index=['username'])
    assert repr(msg) == "Message(text='May not have more than 100 characters', code='max_length', index=['username'])"
    msg = Message(text='May not have more than 100 characters', position=Position(line_no=0, column_no=1, char_index=1))

# Generated at 2022-06-22 05:35:07.767843
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    assert repr(ValidationResult()) == "ValidationResult(value=None)"
    assert repr(ValidationResult(value="foo")) == "ValidationResult(value='foo')"
    assert (
        repr(ValidationResult(error=ValidationError("Error")))
        == "ValidationResult(error=ValidationError('Error'))"
    )



# Generated at 2022-06-22 05:35:14.816804
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    error = BaseError(text="A text")
    # print(error.messages())
    assert error.messages() == [Message(text="A text", code="custom")]

    error = BaseError(messages=[Message(text="A text", code="custom")])
    assert error.messages() == [Message(text="A text", code="custom")]
    assert error.messages(add_prefix=1) == [Message(text="A text", code="custom", index=[1])]



# Generated at 2022-06-22 05:35:23.084358
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    message1=Message(text='text',code='code',key='key',index=['index1','index2'], position=Position(1,2,3), start_position=Position(1,2,3), end_position=Position(1,2,3))
    message2=Message(text='text',code='code',key='key',index=['index1','index2'], position=Position(1,2,3), start_position=Position(1,2,3), end_position=Position(1,2,3))
    message3=Message(text='text3',code='code',key='key',index=['index1','index2'], position=Position(1,2,3), start_position=Position(1,2,3), end_position=Position(1,2,3))

# Generated at 2022-06-22 05:35:34.910158
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    error = BaseError(text="An error", code="a_code", key=0)
    assert error[0] == "An error"
    with pytest.raises(KeyError):
        error["0"]

    error = BaseError(
        messages=[
            Message(text="A", code="a", key=0),
            Message(text="B", code="b", key=0),
            Message(text="C", code="c", key=1),
            Message(text="D", code="d", key=2),
        ]
    )
    assert error[0] == {"": "A", "": "B"}
    assert error[1] == {"": "C"}
    assert error[2] == {"": "D"}
    with pytest.raises(KeyError):
        error["0"]

    error = Base

# Generated at 2022-06-22 05:35:42.741658
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    assert len({}) == 0
    assert len({'b': 0}) == 1
    assert len({'b': {'c': 0}}) == 1
    assert len(BaseError(messages=[Message(text="test")])) == 0
    assert len(BaseError(messages=[Message(text="test", key="b")])) == 1
    assert len(BaseError(messages=[Message(text="test", index=['b','c'])])) == 1


# Generated at 2022-06-22 05:35:51.513936
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    from typesystem import Schema
    from typesystem import Integer, String
    from typesystem import Array, Object

    class UserSchema(Schema):
        username = String(max_length=10)
        email = String(max_lenth=5)
        age = Integer(minimum=18, maximum=150)

    class PostSchema(Schema):
        title = String(max_length=100)
        body = String()
        author = UserSchema()
        comments = Array(items=String())


# Generated at 2022-06-22 05:35:58.646132
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError(text="abc")
    assert e._messages == [Message(text="abc", code="custom")]

if __name__ == "__main__":
    # Usage examples:
    try:
        message = Message(text="abc")
        e = ParseError(messages=[message])
        assert e.messages() == [message]
        test_ParseError()
    except AssertionError:
        print("error in usage examples")

# Generated at 2022-06-22 05:36:08.809272
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    position1 = Position(line_no=1, column_no=1, char_index=1)
    position2 = Position(line_no=1, column_no=1, char_index=1)
    assert position1 == position2


# Generated at 2022-06-22 05:36:17.790635
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    assert str(ValidationError("bad")) == "bad"
    assert str(ValidationError({"good": "bad"})) == "{'good': 'bad'}"
    assert str(ValidationError(messages=[Message("a"), Message("b")])) == "{'': 'a'}"
    assert (
        str(
            ValidationError(
                messages=[
                    Message("a", key="1"),
                    Message("b", key="2"),
                    Message("c", key="3"),
                ]
            )
        )
        == "{'1': 'a', '3': 'c'}"
    )

# Generated at 2022-06-22 05:36:22.154664
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    r1 = ValidationResult(value=3)
    r2 = ValidationResult(error=3)
    assert not r1
    assert r2
    assert r1.value == 3
    assert r2.error == 3



# Generated at 2022-06-22 05:36:33.054220
# Unit test for constructor of class Message
def test_Message():
    message_1 = Message(
        text="text1",
        code="code1",
        key="key1",
        index=[1,2,3],
        position=Position(1,2,3)
    )
    message_2 = Message(text="text1", code="code1", key="key1", index=[1,2,3], start_position=Position(1,2,3), end_position=Position(1,2,3))
    assert message_1.text == "text1"
    assert message_1.code == "code1"
    assert message_1.index == ["key1"]
    assert message_1.start_position.line_no == 1
    assert message_1.start_position.column_no == 2
    assert message_1.start_position.char_index == 3
    assert message

# Generated at 2022-06-22 05:36:37.445270
# Unit test for constructor of class BaseError
def test_BaseError():
    error = BaseError(text='May not have more than 100 characters', code='max_length', key='username')
    assert error == BaseError(messages=[Message(text='May not have more than 100 characters', code='max_length', key='username')])
    assert error['username'] == 'May not have more than 100 characters'



# Generated at 2022-06-22 05:36:40.022905
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    # 'BaseError' has no class attribute `__annotations__`
    pass


# Generated at 2022-06-22 05:36:41.904004
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    assert hash(BaseError()) == hash(BaseError())


# Generated at 2022-06-22 05:36:44.296427
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    BaseError._BaseError__len__()


# Generated at 2022-06-22 05:36:48.341275
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    # Setup
    line_no = 1
    column_no = 1
    char_index = 1
    position = Position(line_no, column_no, char_index)

    # Exercise

    # Verify
    assert repr(position) == f'Position(line_no={line_no}, column_no={column_no}, char_index={char_index})'


# Generated at 2022-06-22 05:36:49.031591
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    pass

# Generated at 2022-06-22 05:36:56.991018
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(line_no=1, column_no=1, char_index=1) == Position(line_no=1, column_no=1, char_index=1)

# Generated at 2022-06-22 05:37:04.635097
# Unit test for constructor of class ValidationError
def test_ValidationError():
    error = ValidationError(text='Слишком длинный пароль', key='password', code='max_length')
    assert error['password'] == 'Слишком длинный пароль'
    error_message = error.messages()[0]
    assert error_message.text == 'Слишком длинный пароль'
    assert error_message.key == 'password'
    assert error_message.code == 'max_length'
# test_ValidationError()


# Generated at 2022-06-22 05:37:13.207639
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    print(Message(text='May not have more than 100 characters', code='max_length', index=[], position=Position(0, 0, 0)))
    print(Message(text='May not have more than 100 characters', code='max_length', index=['username']))
    print(Message(text='May not have more than 100 characters', code='max_length', index=[], start_position=Position(0, 0, 0), end_position=Position(0, 0, 0)))
    print(Message(text='May not have more than 100 characters', code='max_length', index=[], start_position=Position(0, 0, 0), end_position=Position(0, 0, 1)))


# Generated at 2022-06-22 05:37:16.710748
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
   error = BaseError(text="username not found")
   assert hash(error) == hash("{}(error={!r})".format("BaseError", error))

# Generated at 2022-06-22 05:37:18.598977
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    error = ValidationError(text="test")
    assert str(error) == "test"

# Generated at 2022-06-22 05:37:25.580267
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    msg1 = Message(text="May not have more than 100 characters", code='max_length', key='username')
    msg2 = Message(text="May not have more than 100 characters", code='max_length', key='username')
    error1 = BaseError(messages=[msg1, msg2])
    error2 = BaseError(messages=[msg1, msg2])
    assert hash(error1) == hash(error2)

# Generated at 2022-06-22 05:37:29.921586
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    message = Message(text='The error message.', code='code')
    error = BaseError(messages=[message])
    assert hash(error) == hash(BaseError(messages=[message]))


# Generated at 2022-06-22 05:37:35.200289
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    error = BaseError(text="text", code="code", key="key", position="position", messages="messages")
    # assert len(self._message_dict)==len(self)
    try:
        assert len(error) == len(error._message_dict)
    except IndexError:
        print("Test failed")
# test_BaseError___len__()



# Generated at 2022-06-22 05:37:45.069121
# Unit test for constructor of class ParseError
def test_ParseError():
    # Create expected object data
    text = 'text'
    code = 'code'
    key = 'key'
    position = Position(line_no=1, column_no=1, char_index=1)
    messages = [
        Message(text=text, code=code, key=key, position=position)]

    # Create instance of class BaseError with message list
    error = BaseError(messages=messages)

    # Check message list
    assert len(error._messages) == len(messages)
    assert error._messages[0].text == text
    assert error._messages[0].code == code
    assert error._messages[0].index == [key]
    assert error._messages[0].start_position == position
    assert error._messages[0].end_position == position

    # Check message

# Generated at 2022-06-22 05:37:48.294874
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(line_no=1, column_no=2, char_index=3) == Position(line_no=1, column_no=2, char_index=3)


# Generated at 2022-06-22 05:38:06.165263
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    v = ValidationResult()
    assert list(v) == [None, None]
    v = ValidationResult(value=1)
    assert list(v) == [1, None]
    v = ValidationResult(error=ValidationError())
    assert list(v) == [None, ValidationError()]



# Generated at 2022-06-22 05:38:15.749382
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    error = BaseError(
        text="May not have more than 100 characters",
        code="max_length",
        key="username",
        position=Position(line_no=1, column_no=2, char_index=3),
    )
    assert error["username"] == "May not have more than 100 characters"
    assert error.messages() == [Message(text="May not have more than 100 characters", code="max_length", key="username", position=Position(line_no=1, column_no=2, char_index=3))]

# Generated at 2022-06-22 05:38:20.482104
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    msg1 = Message(text="test text", code="test code", index=[1,2,3])
    msg2 = Message(text="test text", code="test code", index=[1,2,3])
    assert msg1 == msg2


# Generated at 2022-06-22 05:38:32.652549
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    b = BaseError()
    assert b.messages() == []
    b = BaseError(text="error")
    assert b.messages() == [Message(text="error", code="custom")]
    b = BaseError(messages=[Message(text="error", code="custom")])
    assert b.messages() == [Message(text="error", code="custom")]
    b = BaseError(
        messages=[Message(text="error", index=[1, 2, 3], code="custom")]
    )
    assert b.messages() == [Message(text="error", index=[1, 2, 3], code="custom")]
    b = BaseError(
        messages=[Message(text="error", index=[1, 2, 3], code="custom")],
        add_prefix=4,
    )
    assert b.mess

# Generated at 2022-06-22 05:38:39.587135
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    # Test with an empty BaseError.
    messages = []
    error = ParseError(messages=messages)
    assert list(error) == []
    # Test with a singleton error message.
    message = Message(text="", code="", index=["a"])
    messages = [message]
    error = ParseError(messages=messages)
    assert list(error) == ["a"]
    # Test with multiple error messages.
    message1 = Message(text="", code="", index=["a"])
    message2 = Message(text="", code="", index=["b"])
    messages = [message1, message2]
    error = ParseError(messages=messages)
    assert list(error) == ["a", "b"]



# Generated at 2022-06-22 05:38:50.600448
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    # Declare test inputs and expected outputs
    input_data_list = [
        { "value": None, "error": ValidationError(text="Foobar", code="custom") },
        { "value": { "foo": "bar" }, "error": None }
    ]
    expected_output_data_list = [
        "ValidationResult(error=ValidationError(text='Foobar', code='custom'))",
        "ValidationResult(value={'foo': 'bar'})"
    ]

    # Loop over the test inputs and expected outputs
    for test_number, input_data, expected_output in zip(
        range(1, len(input_data_list) + 1),
        input_data_list,
        expected_output_data_list
    ):
        # Print information about the current test
        print

# Generated at 2022-06-22 05:38:53.506989
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    pos = Position(1,2,3)
    assert repr(pos) == "Position(line_no=1, column_no=2, char_index=3)"


# Generated at 2022-06-22 05:38:57.358330
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    _line_no = 1
    _column_no = 2
    _char_index = 3
    _position1 = Position(_line_no, _column_no, _char_index)
    _position2 = Position(_line_no, _column_no, _char_index)
    assert (_position1 == _position2)


# Generated at 2022-06-22 05:39:07.372871
# Unit test for constructor of class ValidationError
def test_ValidationError():
    assert ValidationError()
    assert ValidationError(text="asd")
    assert ValidationError(messages=[Message(text="a", code="a")])
    assert ValidationError(text="a", code="a")
    assert ValidationError(messages=[Message(text="a", code="a"), Message(text="a", code="a")])
    assert ValidationError(text="a", code="a", key="a")
    assert ValidationError(messages=[Message(text="a", code="a"), Message(text="a", code="a", key="a")])
    assert ValidationError(text="a", code="a", position=Position(1, 2, 3))

# Generated at 2022-06-22 05:39:12.640069
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    error = BaseError(messages=[
        Message(text='error1', code='code1'),
        Message(text='error2', code='code2', key='key2'),
    ])
    assert len(error) == 2
    

# Generated at 2022-06-22 05:39:31.934139
# Unit test for constructor of class ValidationError
def test_ValidationError():
    error = ValidationError(
        text='Message 1'
    )
    assert error.text == 'Message 1'



# Generated at 2022-06-22 05:39:34.974954
# Unit test for constructor of class ValidationError
def test_ValidationError():
    messages = [
        Message(text = "Message1", code = "code1"),
        Message(text = "Message2", code = "code2"),
    ]
    ver = ValidationError(messages = messages)
    assert messages == ver.messages()

# Generated at 2022-06-22 05:39:38.773082
# Unit test for constructor of class Position
def test_Position():
    position = Position(line_no=2, column_no=3, char_index=4)
    assert position.line_no == 2
    assert position.column_no == 3
    assert position.char_index == 4


# Generated at 2022-06-22 05:39:42.945038
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    assert repr(ValidationResult(value=42)) == "ValidationResult(value=42)"
    assert repr(ValidationResult(error=ValidationError(text="error"))) == "ValidationResult(error=ValidationError(text='error'))"


# Generated at 2022-06-22 05:39:49.308873
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    some_message = Message(text="Some message", code="custom", key="foo")
    error = BaseError(messages=[some_message])
    assert error.messages() == [some_message]
    assert error.messages(add_prefix="bar") == [Message(text="Some message", code="custom", index=["bar", "foo"])]


# Generated at 2022-06-22 05:39:51.697969
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
	obj = ValidationResult(value = None, error = None)
	expected = iter([None, None])
	assert iter(obj) == expected


# Generated at 2022-06-22 05:40:00.565944
# Unit test for constructor of class BaseError
def test_BaseError():

    error = BaseError(text="Test", code="String")
    assert error[""] == "Test"
    assert error.code == "String"

    error = BaseError(text="Test", code="String", key="Index")
    assert error["Index"] == "Test"
    assert error.code == "String"

    messages = [
        Message(text="Test", code="String", key="Index"),
        Message(text="Test2", code="String", key="Index2")
    ]

    error = BaseError(messages=messages)
    assert error["Index"] == "Test"
    assert error.code == "String"
    assert error["Index2"] == "Test2"

    error = BaseError(messages=[messages[0]])
    assert error["Index"] == "Test"

# Generated at 2022-06-22 05:40:06.950121
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    m1 = Message(text="a", code="x", key="b")
    m2 = Message(text="a", code="x", key="b")
    m3 = Message(text="a", code="x", key="c")
    m4 = Message(text="a", code="y", key="b")
    assert m1 == m2
    assert m1 != m3
    assert m1 != m4
    assert m3 != m4


# Generated at 2022-06-22 05:40:08.722199
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    assert ValidationResult(value=None, error=None) == False
    assert ValidationResult(value=None, error=ValidationError()) == True

# Generated at 2022-06-22 05:40:16.374793
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    text = 'May not have more than 100 characters'
    code = 'text is longer than 100 characters'
    key = 'username'
    index = 'users'
    pos = Position(1, 2, 3)
    m1 = Message(text=text, code=code, key=key)
    m2 = Message(text=text, code=code, key=key)
    m3 = Message(text=text, code=code, index=index)
    m4 = Message(text=text, code=code, start_position=pos)
    m5 = Message(text=text, code=code, end_position=pos)
    m6 = Message(text=text, code=code, position=pos)
    m7 = Message(text=text, code=code, key=key, start_position=pos)
    m8 = Message