

# Generated at 2022-06-22 05:33:10.317016
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    expected = """Message(
            text='May not have more than 100 characters',
            code='max_length',
            index=['username']
        )"""
    s = Message(text="May not have more than 100 characters", code="max_length", index=["username"])
    assert repr(s) == expected


# Generated at 2022-06-22 05:33:22.445137
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    position_1 = Position(
        line_no=1, column_no=2, char_index=3
    )
    assert Position(
        line_no=1, column_no=2, char_index=3
    ) == position_1
    assert Position(
        line_no=1, column_no=2, char_index=3
    ) == Position(
        line_no=1, column_no=2, char_index=3
    )
    assert Position(
        line_no=1, column_no=2, char_index=3
    ) != Position(
        line_no=2, column_no=2, char_index=3
    )

# Generated at 2022-06-22 05:33:32.163598
# Unit test for constructor of class Message
def test_Message():
    message = Message(
        text="May not have more than 100 characters",
        code="max_length",
        key="username",
        start_position=Position(1, 2, 3),
        end_position=Position(4, 5, 6),
    )
    assert(message.text == "May not have more than 100 characters")
    assert(message.code == "max_length")
    assert(message.index == ["username"])
    assert(message.start_position == Position(1, 2, 3))
    assert(message.end_position == Position(4, 5, 6))

# Generated at 2022-06-22 05:33:35.293149
# Unit test for constructor of class BaseError
def test_BaseError():
    assert BaseError()


# Generated at 2022-06-22 05:33:41.385910
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    err = ValidationError(text="my_message", code="my_code", key="my_key", position=Position(line_no=5, column_no=5, char_index=5))
    assert err.__repr__() == "ValidationError(text='my_message', code='my_code', key='my_key', position=Position(line_no=5, column_no=5, char_index=5))"

# Generated at 2022-06-22 05:33:51.514515
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    def check(msg1, msg2):
        fmt = "msg1={!r} != msg2={!r}"
        assert msg1 == msg2, fmt.format(msg1, msg2)


# Generated at 2022-06-22 05:33:54.664304
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    assert not ValidationResult()
    assert not ValidationResult(error=ValidationError())
    assert ValidationResult(value=1)
test_ValidationResult___bool__()

# Generated at 2022-06-22 05:33:57.409111
# Unit test for constructor of class BaseError
def test_BaseError():
    try:
        BaseError()
    except AssertionError:
        return

    raise AssertionError("Expected assertion error")



# Generated at 2022-06-22 05:34:07.581782
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    message1 = Message(text='foo')
    message2 = Message(text='foo')
    message3 = Message(code='foo', text='foo')
    message4 = Message(text='bar')
    message5 = Message(text='foo', index=[1])
    message6 = Message(text='foo', index=[1])
    message7 = Message(text='foo', index=[2])
    assert hash(message1) == hash(message2)
    assert hash(message1) != hash(message3)
    assert hash(message1) != hash(message4)
    assert hash(message5) == hash(message6)
    assert hash(message5) != hash(message7)


# Generated at 2022-06-22 05:34:10.566777
# Unit test for constructor of class Position
def test_Position():
    x = Position(1,1,1)
    assert x.line_no == 1
    assert x.column_no == 1
    assert x.char_index == 1



# Generated at 2022-06-22 05:34:22.991151
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(
        text="message1",
        code="code1",
        key="key1",
        position=Position(1, 2, 3),
    )
    error2 = BaseError(
        text="message1",
        code="code1",
        key="key1",
        position=Position(1, 2, 3),
    )
    error3 = BaseError(
        text="message2",
        code="code1",
        key="key1",
        position=Position(1, 2, 3),
    )
    error4 = BaseError(
        text="message1",
        code="code2",
        key="key1",
        position=Position(1, 2, 3),
    )

# Generated at 2022-06-22 05:34:25.771461
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    b = BaseError(
        text='May not have more than 100 characters', code='max_length', key='username'
    )
    assert len(b) == 1


# Generated at 2022-06-22 05:34:31.144350
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    result_t = ValidationResult(value=1)
    result_f = ValidationResult(error=ValidationError(text="error"))
    xx = result_t.__repr__
    assert xx() == 'ValidationResult(value=1)'
    xx = result_f.__repr__
    assert xx() == 'ValidationResult(error=ValidationError(text=\'error\'))'



# Generated at 2022-06-22 05:34:37.404021
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    from typesystem import ValidationResult
    vr1 = ValidationResult(value=1)
    vr2 = ValidationResult(value=0)
    assert bool(vr1) is True
    assert bool(vr2) is True
    vr3 = ValidationResult(error=1)
    vr4 = ValidationResult(error=0)
    assert bool(vr3) is False
    assert bool(vr4) is False

# Generated at 2022-06-22 05:34:43.401767
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    # Test function Position.__repr__
    i1 = Position(line_no=1, column_no=2, char_index=3)
    assert repr(i1) == "Position(line_no=1, column_no=2, char_index=3)"


# Generated at 2022-06-22 05:34:44.573666
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    pass



# Generated at 2022-06-22 05:34:50.757464
# Unit test for constructor of class ValidationError
def test_ValidationError():
    error = ValidationError(text="Bad", code="invalid", key="username")
    assert error.messages() == [Message(text="Bad", code="invalid", key="username")]
    error = ValidationError(messages=[Message(text="Bad", code="invalid")])
    assert error.messages() == [Message(text="Bad", code="invalid")]



# Generated at 2022-06-22 05:34:54.938559
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    c = BaseError(messages = [Message(key=0, position=Position(line_no=4,column_no=1,char_index=30),code='max_length',text='May not have more than 100 characters')])
    assert c.__len__()==1


# Generated at 2022-06-22 05:35:07.767949
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    assert str(BaseError(text='a')) == 'a'
    assert str(BaseError(messages=[Message(text='a', code='a')])) == "{'': 'a'}"
    assert str(BaseError(messages=[Message(text='a', code='a', key='b')])) == "{'b': 'a'}"
    assert str(
        BaseError(
            messages=[Message(text='a', code='a', index=[1]), Message(text='b', code='b', index=[2])]
        )
    ) == '{1: \'a\', 2: \'b\'}'
    assert str(BaseError(messages=[Message(text='a', code='a', index=[1, 2])])) == '{1: {2: \'a\'}}'

# Generated at 2022-06-22 05:35:18.250555
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    msg = Message(text="no text", code="no code")
    assert msg.__repr__() == "Message(text='no text', code='no code')"
    msg = Message(text="hello", code="no code", key="key")
    assert msg.__repr__() == "Message(text='hello', code='no code', index=['key'])"
    msg = Message(text="world", code="no code", index=["array", 0])
    assert msg.__repr__() == "Message(text='world', code='no code', index=['array', 0])"
    pos = Position(line_no=1, column_no=2, char_index=3)
    msg = Message(text="world", code="no code", index=["array", 0], position=pos)
    assert msg.__re

# Generated at 2022-06-22 05:35:26.165918
# Unit test for constructor of class ParseError
def test_ParseError():
    assert ParseError(text="Parse error", code="parse_error", key="key") == ParseError(text="Parse error", code="parse_error", key="key")


# Generated at 2022-06-22 05:35:27.711853
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    b = BaseError()
    assert len(b) == 0


# Generated at 2022-06-22 05:35:38.542080
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
  a = BaseError(text = '1')
  b = BaseError(text = '1')
  c = BaseError(text = '1', messages = [Message(text = '1')])
  d = BaseError(messages = [Message(text = '2')])
  e = BaseError(messages = [Message(text = '1')])
  f = BaseError(messages = [Message(text = '1'), Message(text = '2')])
  g = BaseError(messages = [Message(text = '1')])
  inputs = [a, b, c, d, e, f, g]
  assert len(inputs) == len(set(inputs))


# Generated at 2022-06-22 05:35:40.129060
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    assert BaseError(text="message").__str__() == "message"

# Generated at 2022-06-22 05:35:51.066091
# Unit test for constructor of class BaseError
def test_BaseError():
    messages = [Message(text='1', code='code', key='key', position='position'), Message(text='2', code='code2', key='key2', position='position2')]
    assert BaseError(messages=messages).messages() == messages
    assert BaseError(text='text', code='code', key='key', position='position').messages() == [Message(text='text', code='code', key='key', position='position')]
    try:
        BaseError()
    except TypeError as e:
        assert str(e) == '__init__() missing 1 required keyword-only argument: \'text\'' or str(e) == '__init__() missing 1 required positional argument: \'text\''
    assert BaseError(text='text').messages() == [Message(text='text', code='custom')]

# Generated at 2022-06-22 05:35:52.192787
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError()


# Generated at 2022-06-22 05:35:54.874953
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    v = ValidationResult(value=1, error=2)
    assert list(v) == [1, 2]



# Generated at 2022-06-22 05:36:07.164072
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    test_ValidationResult = ValidationResult(value=3)
    test_ValidationResult_name = test_ValidationResult.__class__.__name__
    assert test_ValidationResult_name == "ValidationResult"
    assert test_ValidationResult.value == 3
    assert test_ValidationResult.error is None
    assert str(test_ValidationResult) == "ValidationResult(value=3)"
    assert repr(test_ValidationResult) == "ValidationResult(value=3)"

    test_ValidationResult_1 = ValidationResult(error=ValidationError(text="Value 3 expected"))
    assert test_ValidationResult_1.value is None
    assert test_ValidationResult_1.error == ValidationError(text="Value 3 expected")

# Generated at 2022-06-22 05:36:13.821409
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    assert str(ValidationError(text='test')) == 'test'
    assert str(ValidationError(messages=[Message(text='test1'), Message(text='test2')])) == "{'': 'test1'}"
    with pytest.raises(AssertionError):
        assert str(ValidationError(messages=[Message(text='test1'), Message(text='test2')], text='test')) == "{'': 'test1'}"


# Generated at 2022-06-22 05:36:16.996613
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    text = "error message"
    base_error = BaseError(text=text)
    assert len(base_error) == 1


# Generated at 2022-06-22 05:36:30.552896
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    error = BaseError(messages=[Message(text="x", code="y", index=["a"])])
    assert list(error.messages()) == [Message(text="x", code="y", index=["a"])]



# Generated at 2022-06-22 05:36:35.062967
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    assert hash(Message(text = "error text", code = "error_code", index = [])) == hash((("error_code", ()),))
    assert hash(Message(text = "error text", code = "error_code", index = ["key"])) == hash((("error_code", ("key",)),))

# Generated at 2022-06-22 05:36:47.169283
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(TypeError):
        ParseError()
    with pytest.raises(TypeError):
        ParseError(text="value is not a number")
    with pytest.raises(TypeError):
        ParseError(code="not_a_number")
    with pytest.raises(TypeError):
        ParseError(value="value is not a number", key="foo")
    with pytest.raises(TypeError):
        ParseError(value="value is not a number", key="foo")
    with pytest.raises(TypeError):
        ParseError(
            value="value is not a number", code="not_a_number", key="foo"
        )

# Generated at 2022-06-22 05:36:50.805456
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    assert eval(repr(Position(line_no=3, column_no=7, char_index=13))) == Position(
        line_no=3, column_no=7, char_index=13
    )


# Generated at 2022-06-22 05:36:56.099700
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    class_ = Position
    obj1 = class_(123, 456, 789)
    obj2 = class_(123, 457, 789)
    obj3 = class_(123, 456, 789)
    obj4 = class_(123, 456, 790)
    assert obj1 == obj3
    assert obj1 != obj2
    assert obj1 != obj4



# Generated at 2022-06-22 05:37:07.682736
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    messages = [
        Message(text="text1", code="code1", key="key1", position=Position(1, 1, 1)),
        Message(text="text2", code="code2", key="key2", position=Position(2, 2, 2)),
        Message(text="text3", code="code3", key="key3", position=Position(3, 3, 3)),
    ]
    error = BaseError(messages=messages)
    error_messages = error.messages()
    assert error_messages == messages

# Generated at 2022-06-22 05:37:18.869617
# Unit test for constructor of class Message
def test_Message():
    assert Message(text="Hello World!") == Message(text="Hello World!")
    assert Message(text="Hello World!", code="custom") == Message(text="Hello World!", code="custom")
    assert Message(text="Hello World!", key="username") == Message(text="Hello World!", key="username")
    assert Message(text="Hello World!", index=["users", 3, "username"]) == Message(text="Hello World!", index=["users", 3, "username"])
    assert Message(text="Hello World!", position=Position(1, 1, 1)) == Message(text="Hello World!", position=Position(1, 1, 1))

# Generated at 2022-06-22 05:37:22.358157
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    assert ValidationResult(error='error').__bool__() == False
    assert ValidationResult(value='value').__bool__() == True


# Generated at 2022-06-22 05:37:28.322156
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    obj = Position(line_no=1, column_no=2, char_index=3)
    assert repr(obj) == 'Position(line_no=1, column_no=2, char_index=3)'


# Generated at 2022-06-22 05:37:39.228787
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    # noinspection PyTypeChecker
    assert BaseError()._message_dict == {}
    assert BaseError(text="abc", code="code", key="key")._message_dict == {"": "abc"}
    assert BaseError(text="abc", code="code", key="key")._message_dict == {"": "abc"}

    assert BaseError(messages=[Message(text="abc", code="code", key="key")])._message_dict == {
        "": "abc"
    }
    assert BaseError(messages=[Message(text="abc", code="code", index=["key"])])._message_dict == {
        "key": "abc"
    }

# Generated at 2022-06-22 05:38:01.836916
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    from unittest import TestCase
    tc: TestCase = TestCase()

    class TestSchema(Schema):
        pass

    import datetime
    value = datetime.date.today()
    result = TestSchema.validate(value)
    tc.assertTrue(result)

    result = TestSchema.validate('10/10/2019')
    tc.assertFalse(result)


# Generated at 2022-06-22 05:38:12.274789
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # given
    err1 = BaseError(
        text='Error 1',
        code=None,
        key=None,
        position=None,
        messages=None,
    )
    # when
    err2 = BaseError(
        text='Error 1',
        code=None,
        key=None,
        position=None,
        messages=None,
    )
    result = err1 == err2
    # then
    assert result == True
    # when
    err3 = BaseError(
        text='Error 1',
        code=None,
        key=0,
        position=None,
        messages=None,
    )
    result = err1 == err3
    # then
    assert result == False


# Generated at 2022-06-22 05:38:20.199834
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    # 1 sample
    error = BaseError(
        messages=[
            Message(text="error 1", position=Position(line_no=1, column_no=1, char_index=0)),
            Message(text="error 2", position=Position(line_no=2, column_no=1, char_index=2)),
            Message(text="error 3", position=Position(line_no=3, column_no=1, char_index=4)),
        ]
    )
    messages = list(error)
    assert messages == ["error 1", "error 2", "error 3"]


# Generated at 2022-06-22 05:38:32.553773
# Unit test for constructor of class ParseError
def test_ParseError():
    msg = Message(text=str(1), code=str(1), key=str(1), index=str(1), position=str(1), start_position=str(1), end_position=str(1))
    msg1 = Message(text=str(2), code=str(2), key=str(2), index=str(2), position=str(2), start_position=str(2), end_position=str(2))
    # Test __init__
    error = ParseError(text=str(1), code=str(1), key=str(1), position=str(1), messages=str(1))
    error1 = ParseError(messages=[msg, msg1])
    # Test __eq__
    assert error != error1
    # Test __hash__
    assert hash(error) == hash(error)

# Generated at 2022-06-22 05:38:42.951481
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Test 'True' branches
    assert Message(text='abc', code='abc') == Message(text='abc', code='abc')
    assert Message(index=[1]) == Message(index=[1])
    assert Message(index=[1, 2]) == Message(index=[1, 2])
    assert Message(text='abc', index=[1]) == Message(text='abc', index=[1])
    assert Message(code='abc', index=[1]) == Message(code='abc', index=[1])

    assert Message(position=Position(1, 2, 3)) == Message(position=Position(1, 2, 3))
    assert Message(start_position=Position(1, 2, 3)) == Message(start_position=Position(1, 2, 3))

# Generated at 2022-06-22 05:38:54.619340
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    from typesystem.exceptions import BaseError

    # Validate initial object state
    message = Message(text='May not have more than 100 characters')
    error = BaseError(messages=[message])
    assert str(error) == "{'': 'May not have more than 100 characters'}"
    assert error.text == 'May not have more than 100 characters'
    assert error.code == 'custom'
    assert error.key is None
    assert error.position is None
    assert error.messages() == [message]

    # Validate function returns
    assert repr(error) == "ValidationError([Message(text='May not have more than 100 characters', code='custom', index=[])])"

# Generated at 2022-06-22 05:38:57.119839
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    msg = Message(text='test', code='test')
    error = BaseError(messages=[msg, msg])
    assert len(error) == 2


# Generated at 2022-06-22 05:39:01.897782
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    value = True
    error = None
    result = ValidationResult(value = value, error = error)
    assert value == result.value
    assert error == result.error
    assert True == bool(result)
    assert str(result) == "ValidationResult(value=True)"


# Generated at 2022-06-22 05:39:12.780852
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    assert BaseError(text="Test 1", code="custom", key="my_key").__repr__() == "BaseError(text='Test 1', code='custom', index=['my_key'])"
    assert BaseError(messages=[Message(text="Test 2", code="custom", key="my_key")]).__repr__() == "BaseError([Message(text='Test 2', code='custom', index=['my_key'])])"
    assert BaseError(messages=[Message(text="Test 3", code="custom")]).__repr__() == "BaseError([Message(text='Test 3', code='custom')])"
    assert BaseError(messages=[Message(text="Test 4", code="custom", key="")]).__repr__() == "BaseError([Message(text='Test 4', code='custom')])"



# Generated at 2022-06-22 05:39:25.290400
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError(text="message")
    d = dict(error)
    assert d == {"": "message"}
    assert error.text == "message"
    assert error.code is None
    assert error.key is None
    assert error.position is None

    error = ParseError(messages=[Message(text="message")])
    d = dict(error)
    assert d == {"": "message"}
    assert error.text is None
    assert error.code is None
    assert error.key is None
    assert error.position is None
    assert type(error) == ParseError

    # ParseError with a single message with a key specified
    error = ParseError(text="message", key="username")
    d = dict(error)
    assert d == {"username": "message"}

# Generated at 2022-06-22 05:40:23.404127
# Unit test for constructor of class BaseError
def test_BaseError():
    try:
        text = "This is an error message"
        BaseError(text="This is an error message")
    except:
        result = False
    else:
        result = True
    assert result == True, "Failed BaseError constructor test"


# Generated at 2022-06-22 05:40:34.607679
# Unit test for constructor of class Message
def test_Message():
    msg = Message(text='Text', code='Code', key='Key', position=Position(1,2,3))
    assert msg.text == 'Text'
    assert msg.code == 'Code'
    assert msg.index == ['Key']
    assert msg.start_position == Position(1,2,3)
    assert msg.end_position == Position(1,2,3)
    msg = Message(text='Text', code='Code', key='Key', start_position=Position(1,2,3), end_position=Position(2,3,4))
    assert msg.text == 'Text'
    assert msg.code == 'Code'
    assert msg.index == ['Key']
    assert msg.start_position == Position(1,2,3)
    assert msg.end_position == Position(2,3,4)

# Generated at 2022-06-22 05:40:40.822889
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError()
    assert len(error) == 0
    assert list(error) == []
    assert bool(error) == False
    assert error.text == None
    assert error.code == None
    assert error.key == None
    assert error.position == None
    assert error.messages() == []
    assert error.__len__() == 0
    assert error.__iter__() == iter([])
    assert error.__bool__() == False
    assert error.__getitem__('a') == {}
    assert error == ParseError()
    assert error.__repr__() == "ParseError()"
    assert error.__str__() == "{}"

    error = ParseError(text="a")
    assert len(error) == 0
    assert list(error) == []

# Generated at 2022-06-22 05:40:46.866489
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    m = Message(text='text', code='email')

    m_set = {m}

    assert m in m_set
    assert Message(text='text', code='email') in m_set
    assert Message(text='text2', code='email') not in m_set
    assert Message(text='text', code='email2') not in m_set


if __name__ == "__main__":
    test_Message___hash__()

# Generated at 2022-06-22 05:40:55.332066
# Unit test for constructor of class ValidationError
def test_ValidationError():
    messages = [
        Message(text="Hello World!", code="custom"),
        Message(text="Goodbye World!", code="custom", index=[1, "username"]),
    ]
    error = ValidationError(messages=messages)
    assert dict(error) == {
        "": "Hello World!",
        1: {"username": "Goodbye World!"},
    }
    assert error.messages() == messages
    assert repr(error) == "ValidationError([Message(text='Hello World!', code='custom'), Message(text='Goodbye World!', code='custom', index=[1, 'username'])])"

# Generated at 2022-06-22 05:40:57.317851
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    # type: () -> None
    error = BaseError(messages=[])

    result = list(error)
    assert result == []



# Generated at 2022-06-22 05:41:00.419939
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    value = ValidationResult(value=5)
    assert repr(value) == "ValidationResult(value=5)"
    error = ValidationResult(error="error")
    assert repr(error) == "ValidationResult(error='error')"



# Generated at 2022-06-22 05:41:05.761812
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    # Case 1: instantiated with a single message
    error = BaseError(text='xxx', code='yyy')
    assert str(error) == 'xxx'

    # Case 2: instantiated with multiple error messages
    messages = [Message(text='xxx', code='yyy', key='zzz')]
    error = BaseError(messages=messages)
    assert str(error) == "{'': 'xxx'}"

# Generated at 2022-06-22 05:41:09.100173
# Unit test for constructor of class Position
def test_Position():
    position = Position(1,2,3)
    assert position.line_no == 1
    assert position.column_no == 2
    assert position.char_index == 3


# Generated at 2022-06-22 05:41:13.952255
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    assert repr(ValidationResult(value=1)) == 'ValidationResult(value=1)'
    assert repr(ValidationResult(error=ValidationError(text='Hello world'))) == 'ValidationResult(error=ValidationError(text=\'Hello world\', code=\'custom\'))'



# Generated at 2022-06-22 05:42:35.528522
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    # Test with a ValidationError with multiple error messages.
    error = ValidationError(messages=[
        Message(text="foo", key=0, code='custom'),
        Message(text="bar", key="zap", code='custom'),
    ])
    assert error[0] == "foo"
    assert error["zap"] == "bar"
    assert error[1] == {}
    assert error["zim"] == {}
    assert error == {0: 'foo', 'zap': 'bar', 1: {}, 'zim': {}}

    # Test with a ValidationError with a single error message.
    error = ValidationError(text="hello", key=5)
    assert error[5] == "hello"
    assert error == {5: 'hello'}

    # Test with a ValidationError with a single error message with

# Generated at 2022-06-22 05:42:37.771084
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    assert repr(ValidationResult(value=1, error='empty')) == "ValidationResult(error='empty')"


# Generated at 2022-06-22 05:42:41.253815
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    obj = Position(line_no = int, column_no = int, char_index = int)
    str = repr(obj)
    assert isinstance(str, str)


# Generated at 2022-06-22 05:42:43.512911
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    vrTrue = ValidationResult(value=[1, 2, 3])
    assert vrTrue != None

    vrFalse = ValidationResult(error='error!')
    assert vrFalse != None

# Generated at 2022-06-22 05:42:47.093448
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    vr = ValidationResult(value=True)
    assert repr(vr) == "ValidationResult(value=True)"

    vr = ValidationResult(error=ValidationError(text="My message"))
    assert repr(vr) == "ValidationResult(error=ValidationError(text='My message', code='custom'))"

# Generated at 2022-06-22 05:42:54.343301
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    from typesystem import String

    schema = String(max_length=10)

    # case 1
    value, error = schema.validate_or_error(value='typesystem')
    assert value is not None
    assert error is None
    assert bool(ValidationResult(value=value, error=error))

    # case 2
    value, error = schema.validate_or_error(value='typesystemtypesystem')
    assert value is None
    assert error is not None
    assert not bool(ValidationResult(value=value, error=error))
