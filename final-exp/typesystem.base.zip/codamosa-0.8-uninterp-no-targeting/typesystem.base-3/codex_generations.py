

# Generated at 2022-06-22 05:33:10.966040
# Unit test for constructor of class BaseError
def test_BaseError():
    messages = [Message(text="text1", code="code1", key="key1")]
    assert BaseError(messages=messages).messages() == messages

# Generated at 2022-06-22 05:33:18.731716
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult()

    assert vr.value is None
    assert vr.error is None

    vr = ValidationResult(value = 1)

    assert vr.value == 1
    assert vr.error is None

    vr = ValidationResult(error = 'error')

    assert vr.value is None
    assert vr.error == 'error'

    for x in vr:
        assert x == 'error'


# Generated at 2022-06-22 05:33:25.615669
# Unit test for constructor of class ParseError
def test_ParseError():
    msg = ParseError(text="Invalid data", code="invalid")
    assert msg.messages() == [Message(text="Invalid data", code="invalid")]

    # No messages
    with pytest.raises(ValueError):
        ParseError()

    # Too many messages
    with pytest.raises(ValueError):
        ParseError(messages=[Message(text="Invalid data", code="invalid")] * 2)



# Generated at 2022-06-22 05:33:33.551930
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    instance = BaseError(text="May not have more than 100 characters", code="max_length", key="username")
    instance2 = BaseError(text="May not have more than 100 characters", code="max_length", key="username")
    instance3 = BaseError(text="May not have more than 100 characters", code="max_length")
    instance4 = BaseError(text="May not have more than 100 characters")
    instance5 = BaseError()
    instance6 = BaseError(messages=[Message(text="May not have more than 100 characters", code="max_length", key="username")])
    instance7 = BaseError(messages=[Message(text="May not have more than 100 characters", code="max_length", key="username")])
    assert hash(instance) == hash(instance2)
    assert hash(instance) != hash(instance3)


# Generated at 2022-06-22 05:33:38.797844
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    error = ValidationError(messages=[Message(text="test1", code='custom', key=''), Message(text="test2", code='custom', key='test2')])
    result = list(error)
    assert result == ['test1', 'test2']


# Generated at 2022-06-22 05:33:44.466904
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    e = BaseError(messages=[Message(text='text_A', code='code_A', index=['index_A'])])
    e2 = BaseError(messages=[Message(text='text_A', code='code_A', index=['index_A'])])
    print(e is e2)
    print(hash(e))
    print(hash(e2))
    print(e is e2)



# Generated at 2022-06-22 05:33:52.526102
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    print('Test BaseError.__iter__')
    errors = [
        {}, {'a': 'message'},
        {'a': {'b': 'message'}},
        {'a': {'b': {'c': 'message'}}},
        {'a': {'b': {'c': ['message1', {'d': 'message2'}]}}}
    ]
    for error in errors:
        error_instance = ValidationError(message_dict=error)
        assert error_instance.message_dict == error
        check_keys = sorted(list(error_instance.keys()))
        assert check_keys == sorted(list(error))
        for key in check_keys:
            assert error[key] == error_instance[key]



# Generated at 2022-06-22 05:34:00.496085
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    x = Message(
        text = "This is a text",
        code = "a code",
        key = "a key",
        index = [1, 2, 3],
        position = Position(1, 2, 3)
    )
    y = Message(
        text = "This is a text",
        code = "a code",
        key = "a key",
        index = [1, 2, 3],
        position = Position(1, 2, 3)
    )

    assert x == y


# Generated at 2022-06-22 05:34:11.833637
# Unit test for constructor of class ValidationError
def test_ValidationError():
    # Test ValidationError with a single error message.
    error = ValidationError(text="Value is too big", code="max_value", key="my_value")

    assert len(error) == 1
    assert "my_value" in error
    assert error["my_value"] == "Value is too big"
    assert error.messages() == [Message(text="Value is too big", code="max_value", key="my_value")]
    assert error.messages(add_prefix="my_value") == [Message(text="Value is too big", code="max_value", index=[])]
    assert str(error) == "Value is too big"

    # Test ValidationError with multiple error messages.

# Generated at 2022-06-22 05:34:21.637165
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="error") == Message(text="error")
    assert Message(text="error") != Message(text="different")
    assert Message(text="error", code="code") == Message(text="error", code="code")
    assert Message(text="error", code="code") != Message(text="error", code="different")
    assert Message(text="error", index=["a"]) == Message(text="error", index=["a"])
    assert Message(text="error", index=["a"]) != Message(text="error", index=["b"])
    assert Message(text="error", position=Position(line_no=1, column_no=1, char_index=1)) == Message(text="error", position=Position(line_no=1, column_no=1, char_index=1))
    assert Message

# Generated at 2022-06-22 05:34:31.372296
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    from typesystem.base import ValidationResult
    d=ValidationResult(value="s", error=ValidationError(text="error"))
    assert list(d)==["s",ValidationError(text="error")]

# Generated at 2022-06-22 05:34:40.333720
# Unit test for constructor of class BaseError
def test_BaseError():
    error = BaseError()
    assert error.text is None
    assert error.code is None
    assert error.key is None
    assert error.position is None
    assert error.messages == []
    
    error = BaseError(text = "error1", code = "code1", key = 100, position = 1)
    assert error.text == "error1"
    assert error.code == "code1"
    assert error.key == 100
    assert error.position == 1
    assert error.messages == [Message(text = "error1", code = "code1", key = 100, position = 1)]
    
    error = BaseError(messages = [Message(text = "error1", code = "code1", key = 100, position = 1)])
    assert error.text is None
    assert error.code is None
   

# Generated at 2022-06-22 05:34:53.166578
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    # Tests of basic functionality
    message = Message(text="May not have more than 100 characters", code="max_length")
    assert repr(message) == "Message(text='May not have more than 100 characters', code='max_length')"

    # Regardless of whether the instance is created using a single position or
    # a pair of start and end positions, the same repr is generated
    message = Message(text="May not have more than 100 characters", code="max_length", position=Position(1, 2, 3))
    assert repr(message) == "Message(text='May not have more than 100 characters', code='max_length', position=Position(line_no=1, column_no=2, char_index=3))"


# Generated at 2022-06-22 05:34:59.019780
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    e = BaseError()
    assert e.__str__() == '{}'
    e = BaseError(text = 'error1')
    assert e.__str__() == 'error1'
    e = BaseError(messages = [Message(text = 'error1'), Message(text = 'error2')])
    assert e.__str__() == "{'': 'error1', '': 'error2'}"

# Generated at 2022-06-22 05:35:06.068441
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    message1 = Message(text="text")
    message1_copy = Message(text="text")
    message2 = Message(text="text1")
    assert message1 == message1_copy
    assert message1 != message2
    assert hash(message1) != hash(message2)
    assert hash(message1) == hash(message1_copy)


# Generated at 2022-06-22 05:35:16.778513
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    """Unit test for method __hash__ of class BaseError"""
    object1 = BaseError(text="text_value", code="code_value", key=1, messages=BaseError(text="text_value", code="code_value", key=1, messages=BaseError(text="text_value", code="code_value", key=1, messages=BaseError(text="text_value", code="code_value", key=1, messages=BaseError(text="text_value", code="code_value", key=1, messages=None)))))

# Generated at 2022-06-22 05:35:21.519989
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(text="error1")
    error2 = BaseError(text="error2")
    assert error1 == BaseError(text="error1")
    assert error2 == BaseError(text="error2")
    assert error1 != error2
    error3 = BaseError(messages=[Message(text="error3")])
    assert error3 == BaseError(messages=[Message(text="error3")])
    assert error3 != error1


# Generated at 2022-06-22 05:35:33.124330
# Unit test for constructor of class BaseError
def test_BaseError():
    message1 = Message(text="text1", code="code1", index=["index1"])
    message2 = Message(text="text2", code="code2", index=["index2"])
    message3 = Message(text="text3", code="code3", index=["index3"])
    test1 = BaseError(messages=[message1])
    assert message1 in test1.messages()

    test2 = BaseError(
        text="text1", code="code1", key="key1", position=Position(1, 1, 1)
    )
    assert test1 == test2

    # test if value can be gotten by index or key
    assert test1.message_dict["index1"] == "text1"
    assert test1["index1"] == "text1"
    # test get value by key when there are

# Generated at 2022-06-22 05:35:39.532583
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    # check that ValidationResult.__bool__()
    # works as expected when ValidationResult
    # is instantiated with value or error
    myInstance = ValidationResult(value=False)
    assert (bool(myInstance) == False)
    myInstance = ValidationResult(error=ValidationError(text='err'))
    assert (bool(myInstance) == True)

# Generated at 2022-06-22 05:35:44.653978
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    msg = Message(text='', code='', key=None, index=None, position=None, start_position=None, end_position=None)
    assert hash(msg) == hash(msg)



# Generated at 2022-06-22 05:36:24.156026
# Unit test for constructor of class BaseError
def test_BaseError():
    # test for empty message
    err1 = BaseError()
    assert not err1
    assert err1.messages() == []
    assert err1.messages(add_prefix=1) == []

    # test for instantiated with text, code and key
    err2 = BaseError(text='text', code='code', key='key')
    assert not err2
    assert err2.messages() == [Message(text='text', code='code', key='key')]
    assert err2.messages(add_prefix=1) == [Message(text='text', code='code', index=[1, 'key'])]
    
    # test for instantiated with message
    err3 = BaseError(messages=['message'])
    assert not err3
    assert repr(err3) == "BaseError(['message'])"

# Generated at 2022-06-22 05:36:26.275014
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    v = BaseError(messages = [])
    r = len(v)
    assert isinstance(r, int)


# Generated at 2022-06-22 05:36:37.404581
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    assert eval(repr(Message(text="", code=None, key=None, index=None, position=Position(1, 1, 1)))).__dict__ == \
        eval(Message(text="", code=None, key=None, index=None, position=Position(1, 1, 1))).__dict__
    assert eval(repr(Message(text="", code="", key="", index=[], start_position=Position(1, 1, 1), end_position=Position(1, 1, 1)))).__dict__ == \
        eval(Message(text="", code="", key="", index=[], start_position=Position(1, 1, 1), end_position=Position(1, 1, 1))).__dict__

# Generated at 2022-06-22 05:36:39.546833
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    assert isinstance(Message(text="text").__hash__(), int)


# Generated at 2022-06-22 05:36:42.942767
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    assert repr(Position( line_no=1, column_no=2, char_index=3)) == "Position(line_no=1, column_no=2, char_index=3)"

# Generated at 2022-06-22 05:36:54.850700
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    cases = [[None, None], [1, None], [None, "error"]]
    for [value, error] in cases:
        _value, _error = ValidationResult(value=value, error=error)
        assert value == _value
        assert error == _error

    # Test iter
    [value, error] = ValidationResult(value=1, error=None)
    assert value == 1
    assert error is None

    # Test __bool__
    assert bool(ValidationResult(value=1, error=None)) is True
    assert bool(ValidationResult(value=None, error="error")) is False

    # Test __repr__
    assert repr(ValidationResult(value=1, error=None)) == "ValidationResult(value=1)"
    assert repr(ValidationResult(value=None, error="error"))

# Generated at 2022-06-22 05:37:01.266294
# Unit test for constructor of class ValidationError
def test_ValidationError():
    #test single error condition
    expected = "Can't have more than 3 items."
    error = ValidationError(text=expected, code="max_items", key="")
    msg = error.messages()
    assert msg[0].text == expected
    assert msg[0].index == []

    #test multi error condition
    expected = "Can't have more than 3 items."
    expected2 = "Can't have more than 100 characters."
    error = ValidationError(text=expected, code="max_items", key="items")
    error2 = ValidationError(text=expected2, code="max_length", key="text")
    msg = error.messages()
    msg2 = error2.messages()
    msg3 = msg + msg2
    error3 = ValidationError(messages=msg3)

# Generated at 2022-06-22 05:37:06.486672
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError(text="test")
    assert e.messages() == [Message(text="test", code="custom")]
    assert dict(e) == {"" : 'test'}  # type: ignore
    assert str(e) == "test"


# Generated at 2022-06-22 05:37:15.981490
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    messages = [
        Message(text="1 error", code="type_error"),
        Message(text="2 errors", code="type_error", key='index_1'),
        Message(text="1 error", code="type_error", key='index_2[0]'),
        Message(text="2 errors", code="type_error", key='index_2[1]'),
        Message(text="3 errors", code="type_error", key='index_3[0][0]'),
        Message(text="4 errors", code="type_error", key='index_3[0][1]'),
        Message(text="5 errors", code="type_error", key='index_3[1][0]'),
        Message(text="6 errors", code="type_error", key='index_3[1][1]'),
    ]
    error_

# Generated at 2022-06-22 05:37:28.032295
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    v1 = ValidationResult()
    v2 = ValidationResult()
    v3 = ValidationResult(value='value')
    v4 = ValidationResult(value='value')
    v5 = ValidationResult(error=ValidationError())
    v6 = ValidationResult(error=ValidationError())

    def test_iter(v):
        return list(iter(v))

    assert test_iter(v1) == [None, None]
    assert test_iter(v1) == test_iter(v2)
    assert test_iter(v3) == ['value', None]
    assert test_iter(v3) == test_iter(v4)
    assert test_iter(v5) == [None, ValidationError()]
    assert test_iter(v5) == test_iter(v6)

#

# Generated at 2022-06-22 05:37:53.645456
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert ValidationResult(value='a') == ('a', None)
    assert ValidationResult(value='a', error='b') == ('a', None)
    assert ValidationResult(error='b') == (None, 'b')


# Generated at 2022-06-22 05:38:04.837728
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert (
        Message(
            text="The value may not be empty",
            code="required",
            key="name",
            index=["users", 3, "name"],
            position=Position(line_no=1, column_no=1, char_index=0),
        )
        == Message(
            text="The value may not be empty",
            code="required",
            key="name",
            index=["users", 3, "name"],
            position=Position(line_no=1, column_no=1, char_index=0),
        )
    )

# Generated at 2022-06-22 05:38:14.605329
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    error = BaseError(messages=[
        Message(text="abc", code="abc", index=[1, 2, 3], start_position=Position(1, 1, 1), end_position=Position(2, 2, 2)),
    ])
    assert error.messages() == [
        Message(text="abc", code="abc", index=[1, 2, 3], start_position=Position(1, 1, 1), end_position=Position(2, 2, 2)),
    ]
    assert error.messages(add_prefix=4) == [
        Message(text="abc", code="abc", index=[4, 1, 2, 3], start_position=Position(1, 1, 1), end_position=Position(2, 2, 2)),
    ]


# Generated at 2022-06-22 05:38:16.557815
# Unit test for constructor of class Position
def test_Position():
    pos = Position(1, 2, 3)
    assert(pos.line_no == 1)
    assert(pos.column_no == 2)
    assert(pos.char_index == 3)


# Generated at 2022-06-22 05:38:20.900596
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    """
    Unit test for method __repr__ of class ValidationResult
    """
    validation_result = ValidationResult(value = 'value')
    assert repr(validation_result) == "ValidationResult(value='value')"


# Generated at 2022-06-22 05:38:22.735172
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
  pass


# Generated at 2022-06-22 05:38:27.609167
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    vr = ValidationResult()
    assert bool(vr) == True

    vr = ValidationResult(value=10)
    assert bool(vr) == True

    vr = ValidationResult(error=ValidationError(text="error1"))
    assert bool(vr) == False


# Generated at 2022-06-22 05:38:32.503258
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    @fields({"name": String()})
    class User:
        pass

    user_object = User(name="John")
    user_dict = {"name": "John"}
    result = user_object.validate_or_error(user_dict)
    assert result.value == user_object
    assert result.error == None

# Generated at 2022-06-22 05:38:33.238679
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    pass

# Generated at 2022-06-22 05:38:40.279766
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    # Instantiated as a ValidationError with a single error message
    text = "hello"
    code = "test_code"
    key = 1
    position = Position(line_no=1, column_no=1, char_index=1)
    error1 = BaseError(text=text, code=code, key=key, position=position)
    assert repr(error1) == f"BaseError(text={text!r}, code={code!r}, index={[key]!r}, position={position!r})"

    # Instantiated as a ValidationError with multiple error messages
    text = "hello"
    code = "test_code"
    key = 1
    position = Position(line_no=1, column_no=1, char_index=1)