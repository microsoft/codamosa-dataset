

# Generated at 2022-06-22 05:33:18.142121
# Unit test for constructor of class ValidationError
def test_ValidationError():
    # Instantiated as a ValidationError with a single error message.
    error1 = ValidationError(text="text1", code="code1", key="key1", position="position1")
    assert dict(error1) == {"key1": "text1"}
    assert list(error1) == [("key1", "text1")]
    assert error1.messages() == [Message(text="text1", code="code1", key="key1", position="position1")]

    error2 = ValidationError(messages="messages2")
    assert dict(error2) == {"messages2"}
    assert list(error2) == [("messages2")]
    assert error2.messages() == ["messages2"]


# Generated at 2022-06-22 05:33:22.342753
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert ValidationResult(value=None).__iter__().__next__() is None
    assert ValidationResult(value=True).__iter__().__next__() is True
    assert ValidationResult(value=1).__iter__().__next__() == 1



# Generated at 2022-06-22 05:33:25.406536
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    assert ValidationResult().__bool__() == False
    assert ValidationResult(error='test').__bool__() == False
    assert ValidationResult(value='test').__bool__() == True

# Generated at 2022-06-22 05:33:33.494407
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    message = Message(
        text="May not have more than 100 characters",
        code="max_length",
        key="username",
        index=["a", "b", "c"],
        position=Position(line_no=1, column_no=2, char_index=3),
    )
    a = BaseError(messages=[message])
    b = BaseError(messages=[message])
    assert a == b
    assert hash(a) == hash(b)
    assert set([a, b]) == set([a])

# Generated at 2022-06-22 05:33:43.328433
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # if self.text == other.text and self.code == other.code and self.index == other.index and self.start_position == other.start_position and self.end_position == other.end_position: return True
    expected = (True, True, True, True, True)
    # test_BaseError___eq__.__wrapped__ = <function BaseError.__eq__ at 0x10ccbaa60>
    args = [PerfData(a=0), PerfData(b=1), PerfData(c=2), PerfData(d=3), PerfData(e=4)]
    actual = test_BaseError___eq__.__wrapped__(*args)
    assert actual == expected


# Generated at 2022-06-22 05:33:52.199600
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    assert list(BaseError(text='foo')) == []
    assert list(BaseError(messages=[Message(text='foo')])) == []
    assert list(BaseError(messages=[Message(text='foo', key='bar')])) == ['bar']
    assert list(BaseError(messages=[Message(text='foo', index=['bar'])])) == ['bar']
    assert list(BaseError(messages=[Message(text='foo', key='bar', index=['baz'])])) == ['bar']
    assert list(BaseError(messages=[Message(text='foo', key='bar'), Message(text='bar', key='foo')])) == ['bar', 'foo']

# Generated at 2022-06-22 05:34:03.865111
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    assert hash(Message(text="abc"))  # type: ignore
    assert hash(Message(text="abc")) == hash(Message(text="abc"))  # type: ignore
    assert hash(Message(text="abc")) != hash(Message(text="abd"))  # type: ignore
    assert hash(Message(text="abc", code="def")) == hash(
        Message(text="abc", code="def")
    )  # type: ignore
    assert hash(Message(text="abc", code="def")) != hash(
        Message(text="abd", code="def")
    )  # type: ignore
    assert hash(Message(text="abc", code="def")) != hash(
        Message(text="abc", code="deg")
    )  # type: ignore
    assert hash(Message(text="abc", index=[2, 3]))

# Generated at 2022-06-22 05:34:07.206826
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    ValidationResult(value="foo").__repr__() == "ValidationResult(value='foo')"
    ValidationResult(error="bar").__repr__() == "ValidationResult(error='bar')"

# Generated at 2022-06-22 05:34:10.095554
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    __tracebackhide__ = True

    class TestBaseError(BaseError):
        pass

    test_base_error = TestBaseError()
    assert test_base_error.__repr__() == "TestBaseError({})", \
        "Test failed: test_base_error.__repr__() should be 'TestBaseError({})'"


# Generated at 2022-06-22 05:34:20.920197
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    # This test is used to check the method messages of BaseError
    error1 = BaseError(text="error1", code="code1", key="key1")
    error2 = BaseError(
        messages=[
            Message(text="error1", code="code1", index=[1]),
            Message(text="error2", code="code2", index=[2]),
        ]
    )
    error3 = BaseError(
        messages=[
            Message(text="error1", code="code1", index=[1]),
            Message(text="error2", code="code2", index=[2]),
        ],
        add_prefix=2,
    )
    assert error1.messages() == [Message(text="error1", code="code1", key="key1")]

# Generated at 2022-06-22 05:34:31.750025
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    text = 'message'
    code = 'code'
    key = 'key'
    index = ['index']
    position = Position(1, 1, 1)
    messages = [Message(
        text=text,
        code=code,
        key=key,
        index=index,
        position=position,
    )]
    error = BaseError(
        text=None,
        code=None,
        key=None,
        position=None,
        messages=messages,
    )
    assert error.messages() == messages



# Generated at 2022-06-22 05:34:34.150559
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    assert ValidationResult(value="OK")
    assert not ValidationResult(error="KO")



# Generated at 2022-06-22 05:34:39.615425
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value= 5)
    i = iter(result)
    assert next(i) == 5
    assert next(i) == None
    try:
        next(i)
        assert False
    except StopIteration:
        pass


# Generated at 2022-06-22 05:34:44.849859
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    baseError1 = BaseError()
    baseError2 = BaseError()
    assert baseError1.__hash__() == baseError2.__hash__()


# Generated at 2022-06-22 05:34:54.844201
# Unit test for constructor of class Message
def test_Message():
    text = 'May not have more than 100 characters'
    code = 'max_length'
    key = 'username'
    index = ['users', 3, 'username']
    start_position = Position(1, 0, 0)
    end_position = Position(1, 17, 17)
    position = Position(1, 0, 17)

    #Case 1 - instantiated with a single error message
    #For the following cases text, code and key should be not none but index and position should be None
    assert Message(text=text, code=code, key=key)
    assert Message(text=text, code=code, key=key, index=index) == False
    assert Message(text=text, code=code, key=key, position=position) == False
    assert Message(text=text, code=code, index=index) == False


# Generated at 2022-06-22 05:34:59.072196
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    instance = Position(line_no=1, column_no=2, char_index=3)
    _repr = instance.__repr__()
    assert _repr == 'Position(line_no=1, column_no=2, char_index=3)'


# Generated at 2022-06-22 05:35:03.351576
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    assert repr(Position(line_no=2, column_no=3, char_index=4)) == "Position(line_no=2, column_no=3, char_index=4)"

# Generated at 2022-06-22 05:35:07.654954
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    try:
        # Try to call the method with no parameters
        error = BaseError()
        hash_value = error.__hash__()
        assert hash_value is not None
    except Exception as e:
        assert False


# Generated at 2022-06-22 05:35:15.874929
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    # the object to be tested is 'self'
    obj = Position(1, 2, 3)

    # check types of the objects
    assert isinstance(obj, Position)

    # check if the object equals to itself
    assert obj == obj

    # check if the object equals to None
    assert obj != None

    # check if the object equals to the other type of object
    assert obj != 1

    # check if the object equals to other different object
    assert obj != Position(1, 2, 4)
    assert obj != Position(1, 3, 3)
    assert obj != Position(2, 2, 3)


# Generated at 2022-06-22 05:35:22.015638
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(
        text='Hej',
        code='max_length',
        key='username',
        index=['users', 3, 'username'],
    )
    message2 = Message(
        text='Hej',
        code='max_length',
        key='username',
        index=['users', 3, 'username'],
    )
    assert message1 == message2


# Generated at 2022-06-22 05:35:38.027016
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    assert repr(Message(text="a", code="b", index=["c"])) == "Message(text='a', code='b', index=['c'])"
    assert repr(Message(text="a", code="b", index=["c"], start_position=Position(1, 2, 3), end_position=Position(1, 5, 3))) == "Message(text='a', code='b', index=['c'], start_position=Position(line_no=1, column_no=2, char_index=3), end_position=Position(line_no=1, column_no=5, char_index=3))"

# Generated at 2022-06-22 05:35:48.969851
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    class_name = Message.__name__
    assert Message(text="hello", code="custom", key="key").__eq__(
        eval(f"{class_name}(text=\"hello\", code=\"custom\", key=\"key\")")
    )
    assert not Message(text="hello", code="custom", key="key").__eq__(
        eval(f"{class_name}(text=\"hello2\", code=\"custom\", key=\"key\")")
    )
    assert not Message(text="hello", code="custom", key="key").__eq__(
        eval(f"{class_name}(text=\"hello\", code=\"custom2\", key=\"key\")")
    )

# Generated at 2022-06-22 05:35:51.588665
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    obj = ValidationResult(error='ERROR')
    assert obj.__iter__() == iter([None, 'ERROR'])


# Generated at 2022-06-22 05:35:56.733132
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    e1 = BaseError(text="ssss")
    e2 = BaseError(text="ssss")
    assert(e1.__eq__(e2)==True)
    e1 = BaseError(messages=[Message(text="ssss", code="Code")])
    e2 = BaseError(messages=[Message(text="ssss", code="Code")])
    assert(e1.__eq__(e2)==True)

# Generated at 2022-06-22 05:36:09.024827
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    assert (
        "Message(text='May not have more than 100 characters',"
        " code='max_length', index=['users', 2, 'username']"
        ", position=Position(line_no=2, column_no=7, char_index=13))"
        == repr(
            Message(
                text="May not have more than 100 characters",
                code="max_length",
                index=["users", 2, "username"],
                position=Position(line_no=2, column_no=7, char_index=13),
            )
        )
    )

# Generated at 2022-06-22 05:36:17.683186
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    msg1 = Message(text="too short", code="min_length", position=Position(1, 0, 0))
    msg2 = Message(text="too long", code="max_length", position=Position(1, 0, 0))
    msg3 = Message(text="invalid char", code="not_allowed", position=Position(1, 0, 0))
    messages = [msg1, msg2, msg3]

    test1 = BaseError(messages=messages)
    test2 = BaseError(messages=messages)

    # test1 equals test2
    assert test1 == test2
    # test1 does not equal test2 if messages are different
    test2._messages = messages = [msg1, msg3]
    assert not test1 == test2


# Generated at 2022-06-22 05:36:25.893526
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_1 = Message(text="text",code="code",key=1,position=Position(1,1,1))
    message_2 = Message(text="text",code="code",key=1,position=Position(1,1,1))
    message_3 = Message(text="text",code="code",key=1,position=Position(1,1,1))
    assert message_1 == message_2
    assert message_2 == message_1
    assert message_1 == message_3
    assert message_3 == message_1

test_Message___eq__()

# Generated at 2022-06-22 05:36:36.341146
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    error = BaseError(text='123')
    assert str(error) == '123'

    error = BaseError(messages=[Message(text='123', code='custom')])
    assert str(error) == "{'': '123'}"

    error = BaseError(messages=[Message(text='123', code='custom', index=[])])
    assert str(error) == "{'': '123'}"

    error = BaseError(messages=[Message(text='123', code='custom', key='foo')])
    assert str(error) == "{'foo': '123'}"

    error = BaseError(messages=[Message(text='123', code='custom', index=['foo'])])
    assert str(error) == "{'foo': '123'}"


# Generated at 2022-06-22 05:36:42.112391
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError("A parse error")
    d = dict(e)
    assert d == {"": "A parse error"}
    assert e.messages() == [Message("A parse error")]

# Test for the __eq__ function of ValidationError

# Generated at 2022-06-22 05:36:46.662053
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    assert repr(Position(line_no=0, column_no=1, char_index=0)) == "Position(line_no=0, column_no=1, char_index=0)"


# Generated at 2022-06-22 05:36:54.439723
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    assert repr(Position(0,0,0)) == 'Position(line_no=0, column_no=0, char_index=0)'

if __name__ == "__main__":
    test_Position___repr__()

# Generated at 2022-06-22 05:36:59.442872
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    # Setup
    text = "text"
    code = "code"
    index = ("index",)
    start_position = Position(1, 2, 3)
    end_position = Position(4, 5, 6)
    message = Message(text=text, code=code, index=index, start_position=start_position, end_position=end_position)
    # Exercise
    message_hash = message.__hash__()
    # Verify
    # Assert that message_hash is an integer.
    assert isinstance(message_hash, int)


# Generated at 2022-06-22 05:37:09.679559
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    # Instantiate with a single error message
    error = BaseError(text='Test message')
    assert repr(error) == "BaseError(text='Test message', code=None)"

    error = BaseError(text='Test message', code='test_code')
    assert repr(error) == "BaseError(text='Test message', code='test_code')"

    error = BaseError(text='Test message', key='test_key')
    assert repr(error) == "BaseError(text='Test message', code=None, index=['test_key'])"

    error = BaseError(text='Test message', key='test_key', code='test_code')
    assert repr(error) == "BaseError(text='Test message', code='test_code', index=['test_key'])"

    # Instantiate with a list of error messages

# Generated at 2022-06-22 05:37:17.416804
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    m1 = Message(text = "May not have more than 100 characters")
    m2 = Message(text = "May not have more than 100 characters")
    assert m1 == m2
    m3 = Message(text = "May not have more than 100 characters", key = "username")
    assert m1 != m3

    # test all hashable values
    vd = {
        1: {0: "str"},
        "str": "str",
        1.0: 1.0,
        True: True,
        False: False,
        None: None,
        (1, 1): (1, 1)
    }
    for _, value in vd.items():
        m = Message(text = "May not have more than 100 characters", key = value)
        #print(m.__repr__())

# Generated at 2022-06-22 05:37:23.278510
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    messages = [Message(text="Error number 1", code="code_1", key=1), Message(text="Error number 2", code="code_2", key=2)]
    base_error = BaseError(messages=messages)
    msg = base_error[1]
    assert msg == "Error number 1"


# Generated at 2022-06-22 05:37:25.628645
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr=ValidationResult(value=2)
    list(vr)

# Generated at 2022-06-22 05:37:37.442348
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    for i in range(1,1000):
        # Test 1
        error_1 = BaseError(text = 'Error_1', code = 'code_1', key = 'key_1', position = Position(3,4,5), messages = Message('Message_1', 'code_1_2', [1,2], Position(3,4,5)))
        error_2 = BaseError(text = 'Error_1', code = 'code_1', key = 'key_1', position = Position(3,4,5), messages = Message('Message_1', 'code_1_2', [1,2], Position(3,4,5)))
        assert error_1.__eq__(error_2)
        # Test 2

# Generated at 2022-06-22 05:37:42.341363
# Unit test for constructor of class Message
def test_Message():
    class_name = Message.__name__
    message = Message(text="Test Message", code="test_code")
    expected = f"{class_name}(text='Test Message', code='test_code', index=[])"
    assert repr(message) == expected

# Generated at 2022-06-22 05:37:52.357334
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # empty object
    error1 = BaseError()
    error2 = BaseError()

    ok_(error1 == error2)

    # object with one error
    error1 = BaseError(text="text", code="code", key="key")
    error2 = BaseError(text="text", code="code", key="key")

    ok_(error1 == error2)

    # one error with different keys
    error1 = BaseError(text="text", code="code")
    error2 = BaseError(text="text", code="code", key="key")

    ok_(error1 != error2)

    # one error with different text
    error1 = BaseError(text="text1", code="code")
    error2 = BaseError(text="text2", code="code")

    ok_(error1 != error2)

    # one error with

# Generated at 2022-06-22 05:37:53.409316
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    vr = ValidationResult(error=ValidationError())
    assert vr.error is not None

# Generated at 2022-06-22 05:38:08.511085
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    class BaseError:
        def __init__(
            self,
            *,
            text: str = None,
            code: str = None,
            key: typing.Union[int, str] = None,
            position: Position = None,
            messages: typing.List[Message] = None,
        ):
            if messages is None:
                # Instantiated as a ValidationError with a single error message.
                assert text is not None
                messages = [Message(text=text, code=code, key=key, position=position)]
            else:
                # Instantiated as a ValidationError with multiple error messages.
                assert text is None
                assert code is None
                assert key is None
                assert position is None
                assert len(messages)

            self._messages = messages
            self._message_dict: typing.Dict

# Generated at 2022-06-22 05:38:14.935054
# Unit test for constructor of class BaseError
def test_BaseError():
    error = BaseError(
        text="bar",
        code="foo",
        key=1,
        position=Position(line_no=1 ,column_no=1, char_index=1),
        )
    assert error.messages() == [Message(text="bar", code="foo", key=1, position=Position(line_no=1, column_no=1, char_index=1))]
    

# Generated at 2022-06-22 05:38:19.854808
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
  error = BaseError(
    text='My Text',
    code='My Code',
    key='My Key',
    messages=None
  )
  assert hasattr(error, 'index')
  assert error.index == ['My Key']


# Generated at 2022-06-22 05:38:22.796411
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    assert bool(ValidationResult(value={'a' : 'b'}))


# Generated at 2022-06-22 05:38:33.886611
# Unit test for constructor of class BaseError
def test_BaseError():
    print('---------test_BaseError----------')
    # check the instantiated error with a single message
    text = 'Expected a string, but got 123.'
    code = 'type_error.string'
    key = 'name'
    position = Position(line_no=1, column_no=8, char_index=7)
    error = BaseError(text=text, code=code, key=key, position=position)
    print(error)
    print('messages:', error.messages())
    assert error.messages()[0].text == text
    assert error.messages()[0].code == code
    assert error.messages()[0].index == [key]
    assert error.messages()[0].position == position

# Generated at 2022-06-22 05:38:40.811227
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Case 1: both objects are equal
    message1 = Message(text="some text", code="required", index=['a', 'b'], start_position=Position(
        line_no=1, column_no=3, char_index=4), end_position=Position(
        line_no=2, column_no=4, char_index=5))
    message2 = Message(text="some text", code="required", index=['a', 'b'], start_position=Position(
        line_no=1, column_no=3, char_index=4), end_position=Position(
        line_no=2, column_no=4, char_index=5))
    assert message1 == message2
    # Case 2: text is different
    message2.text = "some different text"

# Generated at 2022-06-22 05:38:51.340741
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    from typesystem import Integer, Schema

    schema = Schema(properties={"name": Integer()})

    value, error = schema.validate_or_error({"name": "42"})
    assert bool(value)
    assert not bool(error)

    value, error = schema.validate_or_error({"name": "invalid"})
    assert not bool(value)
    assert bool(error)

    value, error = schema.validate_or_error({"name": None})
    assert not bool(value)
    assert bool(error)

    value, error = schema.validate_or_error({"name": 42})
    assert bool(value)
    assert not bool(error)



# Generated at 2022-06-22 05:39:03.132477
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    m1 = Message(text='My Error', code='error', index=['a', 'b'], start_position=Position(line_no=1, column_no=1, char_index=2), end_position=Position(line_no=1, column_no=1, char_index=2))
    m2 = Message(text='My Error', code='error', index=['a', 'b'], start_position=Position(line_no=1, column_no=1, char_index=2), end_position=Position(line_no=1, column_no=1, char_index=3))

# Generated at 2022-06-22 05:39:06.637212
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    parsed_msg = eval(repr(BaseError()))
    assert isinstance(parsed_msg, BaseError)
    assert not parsed_msg.messages


# Generated at 2022-06-22 05:39:13.838406
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    # Check whether the result of repr(Position(line_no=1, column_no=2, char_index=3)) is the same as the string we expect
    assert repr(Position(line_no=1, column_no=2, char_index=3)) == (
        "Position(line_no=1, column_no=2, char_index=3)"
    )


# Generated at 2022-06-22 05:39:36.959258
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    from typesystem.types import Boolean, Float, Integer
    from typesystem.schemas import Schema
    schema = Schema(properties={"x": Float(), "y": Integer()})
    value, error = schema.validate_or_error({"x": 232.0, "y": "23"})
    other_value, other_error = schema.validate_or_error({"x": "232.0", "y": 23})
    assert not value
    assert not other_value
    assert hash(error) == hash(other_error)
    assert error != other_error



# Generated at 2022-06-22 05:39:39.694214
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    err = BaseError(messages=[
        Message(text='foo', code='bar', index=['foo']),
        Message(text='bar', code='bar', index=['bar']),
        Message(text='baz', code='qux', index=['baz']),
    ])
    assert err[''] == {
        'foo': 'foo',
        'bar': 'bar',
        'baz': 'baz',
    }
    assert err['baz'] == 'baz'

# Generated at 2022-06-22 05:39:44.103121
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    value = 'value'
    val = ValidationResult(value = value)
    assert val.value is value
    assert val.error is None

    error = 'error'
    val = ValidationResult(error = error)
    assert val.value is None
    assert val.error is error

# Generated at 2022-06-22 05:39:50.420573
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    text = "abc123"
    code = "abc"
    key = "def"
    error = BaseError(text=text, code=code, key=key)
    assert error.__repr__() == "BaseError(text='abc123', code='abc')"
    assert error.text == text
    assert error.code == code
    assert error.key == key


# Generated at 2022-06-22 05:39:52.315610
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    assert str(BaseError(text='May not have more than 100 characters')) == 'May not have more than 100 characters'

# Generated at 2022-06-22 05:40:00.812905
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    # Index goes below zero
    local_error1 = BaseError(text='May not have more than 100 characters', code='max_length', key='username', index=[-1])
    assert "BaseError(text='May not have more than 100 characters', code='max_length', index=[-1])" == repr(local_error1)

    # Index is a negative number
    local_error2 = BaseError(text='May not have more than 100 characters', code='max_length', key='username', index=[-1,0])
    assert "BaseError(text='May not have more than 100 characters', code='max_length', index=[-1, 0])" == repr(local_error2)

    # Index is a positive number

# Generated at 2022-06-22 05:40:06.993224
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    _expected = "BaseError(text='foo', code='custom', index=['bar'], position=Position(line_no=0, column_no=0, char_index=0))"
    _schema = BaseError(text='foo', key='bar')
    _schema = _schema.messages(add_prefix='baz')[0]
    assert repr(_schema) == _expected


# Generated at 2022-06-22 05:40:09.872944
# Unit test for constructor of class Position
def test_Position():
    assert Position(1, 3, 5) == Position(1, 3, 5)


# Generated at 2022-06-22 05:40:20.382636
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    root_error = BaseError(messages=[
        Message(text='A single error'),
        Message(text='A dict error', key='key'),
        Message(text='A nested dict error', index=['key']),
    ])

    assert root_error.messages() == [
        Message(text='A single error'),
        Message(text='A dict error', key='key'),
        Message(text='A nested dict error', index=['key']),
    ]
    assert root_error.messages(add_prefix=1) == [
        Message(text='A single error', index=[1]),
        Message(text='A dict error', key='key', index=[1]),
        Message(text='A nested dict error', index=[1, 'key']),
    ]

    # Unit test for method messages of class ValidationError

# Generated at 2022-06-22 05:40:24.010233
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    error = BaseError(text='text', code='code')
    assert len(error) == 0

    error = BaseError(text='text', code='code', key='key')
    assert len(error) == 1


# Generated at 2022-06-22 05:41:00.228744
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    Position_obj = Position(line_no=0, column_no=0, char_index=0)
    assert Position_obj.__repr__() == "Position(line_no=0, column_no=0, char_index=0)"
    return Position_obj


# Generated at 2022-06-22 05:41:11.141360
# Unit test for constructor of class BaseError
def test_BaseError():
    message = Message(text="Some error", code="code1", key="key1")
    message2 = Message(text="Some other error", code="code2", key="key1")
    messages = [message, message2]
    error = BaseError(messages=messages)
    assert error is not None
    assert error[0] == message
    assert error[1] == message2
    assert len(error) == 2
    assert error.messages() == messages
    assert dict(error) == {'key1': {'code1': 'Some error', 'code2': 'Some other error'}}
    assert error.__repr__() == BaseError(messages=[Message(text='Some error', code='code1', key='key1'), Message(text='Some other error', code='code2', key='key1')]).__repr

# Generated at 2022-06-22 05:41:20.695479
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    error = ValidationError(text="foo", code="bar")
    assert error[""] == "foo"
    # Test no exception
    try:
        error["baz"]
    except KeyError:
        assert False
    assert error.messages() == [Message(text="foo", code="bar")]
    assert dict(error) == {"": "foo"}
    assert repr(error) == ("ValidationError(text='foo', " "code='bar')")
    assert str(error) == "foo"
    # Test no exception
    try:
        bool(error)
    except ValueError:
        assert False
    # Test no exception
    try:
        iter(error)
    except TypeError:
        assert False
    # Test no exception
    try:
        len(error)
    except TypeError:
        assert False

# Generated at 2022-06-22 05:41:23.037716
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    assert len(BaseError(text="a")) == 1
    assert len(BaseError(messages=[Message(text="a"), Message(text="b")])) == 1


# Generated at 2022-06-22 05:41:33.563248
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    #
    # Defaults
    #
    e = ValidationError()
    messages = e.messages()
    assert messages == [Message(text='', key='')]

    #
    # No prefix, with index, with start and end position
    #
    e = ValidationError(messages=[
        Message(text='msg_text', code='msg_code', index=['index'],
                start_position=Position(1, 1, 0),
                end_position=Position(2, 2, 5))])
    messages = e.messages()
    assert messages == [Message(text='msg_text', code='msg_code', index=['index'],
                                start_position=Position(1, 1, 0),
                                end_position=Position(2, 2, 5))]

    #
    # Prefix,

# Generated at 2022-06-22 05:41:38.135836
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    value = 1.0
    assert repr(ValidationResult(value=value)) == 'ValidationResult(value=1.0)'
    error = ValidationError(text='Value must be an integer')
    assert repr(ValidationResult(error=error)) == 'ValidationResult(error=ValidationError(\'Value must be an integer\'))'

# Generated at 2022-06-22 05:41:42.685765
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    value = "str"
    vr = ValidationResult(value=value)
    assert vr == (value, None)
    assert bool(vr) == True
    vr = ValidationResult(error=ValidationError(text="Error"))
    assert vr == (None, ValidationError(text="Error"))
    assert bool(vr) == False


# Generated at 2022-06-22 05:41:53.908619
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Message(text, code, key, position)
    m1 = Message('txt1', 'c1', 'k1', Position(1, 2, 3) )
    m2 = Message('txt1', 'c1', 'k1', Position(1, 2, 3) )
    assert m1 == m2
    m2 = Message('txt2', 'c1', 'k1', Position(1, 2, 3) )
    assert m1 != m2
    m2 = Message('txt1', 'c2', 'k1', Position(1, 2, 3) )
    assert m1 != m2
    m2 = Message('txt1', 'c1', 'k2', Position(1, 2, 3) )
    assert m1 != m2


# Generated at 2022-06-22 05:41:56.728642
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    arg = Message(text="text", code="code", key="key", position=Position(1, 1, 1))
    # No exception is raised
    hash(arg)


# Generated at 2022-06-22 05:42:05.449500
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    text: str = "text0"
    code: str = "code0"
    key: typing.Union[int, str] = "key0"
    position: Position = Position(line_no=0, column_no=0, char_index=0)
    messages: typing.List[Message] = [
        Message(text=text, code=code, key=key, position=position)
    ]
    # BaseError with a single error message (text, code, key)
    BaseError0 = BaseError(text=text, code=code, key=key, position=position)
    # BaseError with a list of error messages (messages)
    BaseError1 = BaseError(messages=messages)
    assert BaseError0 == BaseError1
    # BaseError with a single error message (text, code, key)
    Base