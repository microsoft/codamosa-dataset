

# Generated at 2022-06-22 05:33:20.124450
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    m1 = Message(text="text1",code="code1",key="key1",index=["index1","index2"],position=Position(line_no=1,column_no=1,char_index=1),start_position=Posiiton(line_no=1,column_no=1,char_index=1),end_position=Position(line_no=1,column_no=1,char_index=1))

# Generated at 2022-06-22 05:33:30.616259
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    assert str(ParseError(text="test")) == "test"
    assert str(ParseError(messages=[Message(text="test")])) == {"": "test"}
    assert str(ParseError(messages=[Message(text="test", key="key")])) == "test"
    assert str(ParseError(messages=[Message(text="test", index=["index"])])) == {"index": "test"}
    assert str(ParseError(messages=[Message(text="test", index=["index", "key"])])) == "test"
    assert str(ParseError(messages=[Message(text="test", index=["index", 1])])) == "test"

# Generated at 2022-06-22 05:33:41.918765
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    import hypothesis
    import hypothesis.strategies
    import typesystem
    import typesystem.json
    def to_Message(
        *,
        text: str,
        code: typing.Optional[str] = None,
        key: typing.Optional[str] = None,
        index: typing.Optional[typing.List[str]] = None,
        position: typing.Optional[typing.Tuple[int, int, int]] = None,
        start_position: typing.Optional[typing.Tuple[int, int, int]] = None,
        end_position: typing.Optional[typing.Tuple[int, int, int]] = None,
    ) -> Message:
        import typesystem
        if position is not None:
            assert start_position is None
            assert end_position is None
            start_line_no

# Generated at 2022-06-22 05:33:47.336114
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    value, error = ValidationResult.__new__(ValidationResult)
    value.value, value.error = 'value', 'error'
    error.value, error.error = 'value', 'error'
    assert repr(value) == "ValidationResult(value='value')"
    assert repr(error) == "ValidationResult(error='error')"

# Generated at 2022-06-22 05:33:48.745166
# Unit test for constructor of class ParseError
def test_ParseError():
    value, error = ValidationError()
    print(value,error)

# Generated at 2022-06-22 05:33:54.100838
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    vr = ValidationResult(value = 'hello')
    assert(vr)

    vr = ValidationResult(error = 'error')
    assert(not vr)

# Generated at 2022-06-22 05:34:00.224647
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)


# Generated at 2022-06-22 05:34:04.639999
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    line_no = 1
    column_no = 1
    char_index = 1
    position = Position(line_no, column_no, char_index)
    assert repr(position) == "Position(line_no=1, column_no=1, char_index=1)"


# Generated at 2022-06-22 05:34:06.102807
# Unit test for constructor of class ValidationError
def test_ValidationError():
    v1 = ValidationError(text="Some error")
    return True


# Generated at 2022-06-22 05:34:14.321471
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    vr = ValidationResult()
    assert vr.value is None
    assert vr.error is None

    vr = ValidationResult(error=None)
    assert vr.value is None
    assert vr.error is None

    vr = ValidationResult(value=5)
    assert vr.value == 5
    assert vr.error is None

    vr = ValidationResult(error=ValidationError())
    assert vr.value is None
    assert isinstance(vr.error, ValidationError)


# Generated at 2022-06-22 05:34:24.748119
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    be = BaseError(text = 'May not have more than 100 characters', code = 'max_length', key = 'username')
    print(be)


# Generated at 2022-06-22 05:34:36.554140
# Unit test for constructor of class ValidationError
def test_ValidationError():
    # Test instantiating a ValidationError with a single message.
    # Start with the most basic test: empty message
    error = ValidationError()
    assert error.messages() == [
        Message(text="", code="custom", index=[])
    ]

    # Test instantiating a ValidationError with a single message.
    error = ValidationError(text="This is an error message.")
    assert error.messages() == [
        Message(text="This is an error message.", code="custom", index=[])
    ]

    # Test instantiating a ValidationError with a single message.
    error = ValidationError(text="This is an error message.", code="error_code")
    assert error.messages() == [
        Message(text="This is an error message.", code="error_code", index=[])
    ]

    # Test

# Generated at 2022-06-22 05:34:38.637511
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    position = Position(1, 1, 1)
    assert repr(position) == "Position(line_no=1, column_no=1, char_index=1)"


# Generated at 2022-06-22 05:34:44.102769
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert list(ValidationResult(value=5)) == [5, None]
    assert list(ValidationResult(error=ValidationError())) == [None, ValidationError()]



# Generated at 2022-06-22 05:34:48.392411
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    instance = ValidationResult(value=1)
    assert instance.value == 1
    assert instance.error is None

    instance = ValidationResult(error=ValidationError())
    assert instance.error is not None
    assert instance.value is None

    assert bool(ValidationResult(value=1)) == True
    assert bool(ValidationResult(error=ValidationError())) == False
    assert bool(ValidationResult(value=1, error=ValidationError())) == False
    assert bool(ValidationResult(value=None, error=None)) == False
test_ValidationResult()



# Generated at 2022-06-22 05:34:54.886382
# Unit test for constructor of class ParseError
def test_ParseError():
    expect = "Expected end of line (line 1, column 4 (char 3))"
    error = ParseError(
        text="Expected end of line",
        position=Position(line_no=1, column_no=4, char_index=3)
    )
    expect = """{
  'ParseError': {
    '': 'Expected end of line'
  }
}"""
    assert expect == json.dumps(error, indent="  ")



# Generated at 2022-06-22 05:34:55.786663
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    error = BaseError()
    print(error)


# Generated at 2022-06-22 05:35:08.437423
# Unit test for constructor of class Message
def test_Message():
    print("\nThis is the test for the constructor of class Message:\n")
    # the line below will print the actual thing
    print(Message(text = "May not have more than 100 characters", code = "max_length", key = "username", position = Position(1, 2, 3)))
    # the line below will print the thing that I expect to see
    print(Message(text = "May not have more than 100 characters", code = "max_length", key = "username", position = Position(1, 2, 3)))
    # the line below will print the result comparing the two previous methods

# Generated at 2022-06-22 05:35:09.124210
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    BaseError.__iter__("BaseError")

# Generated at 2022-06-22 05:35:12.060809
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    result = ValidationResult(value=1)
    print(bool(result))
    result = ValidationResult(error=1)
    print(bool(result))


# Generated at 2022-06-22 05:35:35.308936
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    assert hash(Message(text="msg 1")) == hash(Message(text="msg 1", code="custom", index=(), start_position=None))
    assert hash(Message(text="msg 1", code="code 1")) == hash(Message(text="msg 1", code="code 1", index=(), start_position=None))
    assert hash(Message(text="msg 1", index=["1"])) == hash(Message(text="msg 1", code="custom", index=("1",), start_position=None))
    assert hash(Message(text="msg 1", code="code 1", index=["1"])) == hash(Message(text="msg 1", code="code 1", index=("1",), start_position=None))

# Generated at 2022-06-22 05:35:39.293917
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    error = ValidationError(messages=[
        Message(text="oops", code="max_length", key="a"),
        Message(text="oops", code="max_length", key="b"),
        Message(text="oops", code="max_length", key="c"),
    ])
    assert len(error.messages()) == 3


# Generated at 2022-06-22 05:35:50.737003
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    assert len(BaseError()) == 0
    assert len(BaseError(text="Message text")) == 0
    assert len(BaseError(messages=[Message(text="Message text")])) == 0
    assert len(
        BaseError(messages=[Message(key="username", text="Message text")])
    ) == 1
    assert len(
        BaseError(
            messages=[Message(key="username", text="Message text"), Message(text="Message text")]
        )
    ) == 1
    assert len(
        BaseError(
            messages=[
                Message(key="username", text="Message text"),
                Message(key="password", text="Message text"),
            ]
        )
    ) == 2

# Generated at 2022-06-22 05:35:57.098850
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    """
    Tests for ValidationResult
    """
    validation_result_value = ValidationResult(value=1)
    assert validation_result_value.value == 1
    assert validation_result_value.error is None

    validation_result_error = ValidationResult(error=ValidationError(text="test"))
    assert validation_result_error.value is None
    assert validation_result_error.error is not None

# Generated at 2022-06-22 05:35:59.899104
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    key1 = Message(text='ab')
    key2 = Message(text='ab')
    assert hash(key1) == hash(key2)


# Generated at 2022-06-22 05:36:05.445669
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    test_cases = [
        ValidationResult(value=123),
        ValidationResult(error=ValidationError(text="An error occurred.")),
    ]
    for test_case in test_cases:
        assert list(test_case) == [test_case.value, test_case.error]



# Generated at 2022-06-22 05:36:13.162568
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    lst = [
        {"message": "Hello from data"},
        {"message": "Hello from error"}
    ]
    for entry in lst:
        v = ValidationResult(**entry)
        if entry["message"] == "Hello from data":
            assert isinstance(v.value, str)
            assert bool(v)
            assert v.error is None
        if entry["message"] == "Hello from error":
            assert isinstance(v.error, str)
            assert not bool(v)
            assert v.value is None



# Generated at 2022-06-22 05:36:16.833595
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    s = [1, 2, 3, 4, 5]
    for item in BaseError(s):
        print(item)


# Generated at 2022-06-22 05:36:23.451015
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    # Test case 1
    message = Message(
        text = "this is the text",
        key = "key_value",
    )
    tester = BaseError(messages = [ message ])
    actual = tester['key_value']
    expected = 'this is the text'
    assert actual == expected
    print("pass test case 1")


# Generated at 2022-06-22 05:36:34.649819
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    class Test:
        def __init__(self):
            self.assertEqual = unittest.TestCase().assertEqual

        # Test number of messages in case of duplicate messages in error
        def test_num_messages(self):
            error = BaseError(messages=[
                Message(text='text', code='code', key=1),
                Message(text='text', code='code', key=1)
            ])
            self.assertEqual(len(error), 1)

        # Test number of messages in case of non-duplicate messages in error
        def test_num_messages(self):
            error = BaseError(messages=[
                Message(text='text', code='code', key=1),
                Message(text='text', code='code', key=2)
            ])

# Generated at 2022-06-22 05:37:06.253102
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():

    _a = BaseError()
    _y = _a.__iter__()
    return (_y == _y)


# Generated at 2022-06-22 05:37:14.674420
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    text_dict = {1:'aaa', 2:'bbb', 3:'ccc'}
    message_dict = {'aaa':'bbb'}
    value_dict = {'aaa':1, 'bbb':2, 'ccc':3}
    value_list = [1, 2, 3]
    message_list = [Message(1, 2, 'aaa', 'bbb')]
    value_list_list = [[1,2,3], [4,5,6]]
    value_list_dict = [{1:2}, {2:3}]

    assert len(BaseError()) == 0
    assert BaseError(messages=message_list)[1] == 'bbb'


# Generated at 2022-06-22 05:37:19.089635
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    from pytest import raises
    from typesystem.base import BaseError, Message

    error = BaseError(messages=[Message(text='a', code='b', key='c')])
    assert error['c'] == 'a'

    error = BaseError(messages=[Message(text='a', code='b', index=['c', 'd'])])
    assert error['c'] == {'d': 'a'}

    with raises(KeyError):
        error = BaseError(messages=[Message(text='a', code='b', index=['c', 'e'])])
        error['c']



# Generated at 2022-06-22 05:37:22.618776
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    result = ValidationResult(value=95)
    assert repr(result) == "ValidationResult(value=95)"


# Generated at 2022-06-22 05:37:32.559529
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    assert hash(ValidationError(messages=[Message(text="a1", code="c1", key="k1")])) == hash(ValidationError(messages=[Message(text="a1", code="c1", key="k1")]))
    assert hash(ValidationError(messages=[Message(text="a1", code="c1", key="k1")])) != hash(ValidationError(messages=[Message(text="a2", code="c2", key="k2")]))


# Generated at 2022-06-22 05:37:44.048626
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    from pytest import raises
    from typesystem import validators

    with raises(TypeError):
        validators.String.validate_or_error(b"")

    value, error = validators.String.validate_or_error(1)
    assert error.messages() == [
        Message(text="Value is not a string.", index=[], code="type_error")
    ]
    assert error[""] == "Value is not a string."
    assert error[0] == "Value is not a string."
    with raises(KeyError):
        error[3]
    with raises(KeyError):
        error["a"]
    with raises(TypeError):
        error[1.0]
    with raises(TypeError):
        error[[]]
    with raises(KeyError):
        error[None]

# Generated at 2022-06-22 05:37:54.947710
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    er = BaseError(messages=[
        Message(text='text1', code='code1'),
        Message(text='text2', code='code2', key='key2'),
        Message(text='text3', code='code3', key='key3'),
    ])
    result = er.messages()
    assert result == [
        Message(text='text1', code='code1'),
        Message(text='text2', code='code2', key='key2'),
        Message(text='text3', code='code3', key='key3'),
    ]
    result = er.messages(add_prefix='add_prefix1')

# Generated at 2022-06-22 05:37:59.372736
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    message = Message(text="text", code="code", index=[1, "a"])
    assert repr(message) == "Message(text='text', code='code', index=[1, 'a'])"




# Generated at 2022-06-22 05:38:00.822425
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    error = BaseError()
    for t in error:
        assert t


# Generated at 2022-06-22 05:38:02.424835
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    pass

# Generated at 2022-06-22 05:39:07.185513
# Unit test for constructor of class Message
def test_Message():
    s = Message(text='Invalid username', code='invalid_username', key='username')
    #assert s.text == 'Invalid username'
    #assert s.code == 'invalid_username'
    #assert s.key == 'username'

test_Message()

# Generated at 2022-06-22 05:39:12.254027
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    class TempError(BaseError):
        pass
    error = TempError(messages=[Message(text="foo"), Message(text="bar")])
    messages = error.messages()
    assert len(messages) == 2



# Generated at 2022-06-22 05:39:24.860073
# Unit test for method __len__ of class BaseError

# Generated at 2022-06-22 05:39:29.417371
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    x = BaseError(text='5', code='5', key='5', position=Position(5,5,5))
    assert x.messages() == [Message(text='5', code='5', key='5', position=Position(5,5,5))]

# Generated at 2022-06-22 05:39:40.035858
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    assert repr(Message(text='a', code='b', index=[])) == "Message(text='a', code='b')"
    assert repr(Message(text='a', code='b', index=['c'])) == "Message(text='a', code='b', index=['c'])"
    assert repr(Message(text='a', code='b', start_position=Position(1,2,3), end_position=Position(1,2,3))) == "Message(text='a', code='b', position=Position(line_no=1, column_no=2, char_index=3))"

# Generated at 2022-06-22 05:39:51.796244
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    message = Message(text='text', code='code', index=['a'], start_position=Position(1, 1, 1), end_position=Position(1, 1, 1))
    message2 = Message(text='text', code='code', index=['a'], start_position=Position(1, 1, 1), end_position=None)
    assert repr(message) == "Message(text='text', code='code', index=['a'], position=Position(line_no=1, column_no=1, char_index=1))"
    assert repr(message2) == "Message(text='text', code='code', index=['a'], start_position=Position(line_no=1, column_no=1, char_index=1), end_position=None)"

# Generated at 2022-06-22 05:39:53.659589
# Unit test for constructor of class ParseError
def test_ParseError():
    parse_error = ParseError(text='--')
    assert parse_error is not None


# Generated at 2022-06-22 05:39:56.805464
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    m1 = Message(text="message")
    m2 = Message(text="message")
    assert m1 == m2
    assert hash(m1) == hash(m2)
    assert m1 is not m2


# Generated at 2022-06-22 05:40:08.515745
# Unit test for constructor of class Message
def test_Message():
    # test __init__
    message = Message(text='abc', code='def', key=None, index=[], start_position=Position(1, 2, 3), end_position = Position(1, 2, 3))
    assert message.text == 'abc'
    assert message.code == 'def'
    assert message.index == []
    assert message.start_position.line_no == 1
    assert message.start_position.column_no == 2
    assert message.start_position.char_index == 3
    assert message.end_position.line_no == 1
    assert message.end_position.column_no == 2
    assert message.end_position.char_index == 3

# Generated at 2022-06-22 05:40:18.582647
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    print('test_BaseError___len__')
    # Define expected_result
    expected_result = 2
    # Create object
    obj = BaseError(messages=[Message(text='text1', code='code1'), Message(text='text2', code='code2')])
    # Apply method
    result = len(obj)
    # Check result
    assert result == expected_result
    # Check that the line above raises an exception when the wrong type of argument is given
    try:
        len(123)
        raise Exception('Exception expected')
    except Exception as e:
        if not str(e) == "object of type 'int' has no len()":
            raise Exception('Unexpected exception')

