

# Generated at 2022-06-22 05:33:17.429104
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    position_1 = Position(1, 1, 1)
    position_2 = Position(1, 1, 1)
    position_3 = Position(1, 2, 1)
    position_4 = Position(1, 1, 2)
    position_5 = Position(2, 1, 1)
    assert position_1 == position_2
    assert position_1 != position_3
    assert position_1 != position_4
    assert position_1 != position_5



# Generated at 2022-06-22 05:33:22.547520
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    error = ValidationError(
        code="invalid_type",
        text="Not a valid integer.",
        key="some_field",
        position=Position(line_no=1, column_no=1, char_index=1),
    )
    assert str(error) == 'Not a valid integer.'



# Generated at 2022-06-22 05:33:28.537705
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    messages = [
        Message(text="x", code="x", key=0),
        Message(text="y", code="y", key=1),
        Message(text="z", code="z", key=2),
        Message(text="a", code="a", key=3),
    ]
    assert len(BaseError(messages=messages)) == 4


# Generated at 2022-06-22 05:33:31.840919
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    error = BaseError(text='depends on field "first_name"', code='dependency', key='last_name')
    assert error['last_name'] == 'depends on field "first_name"'


# Generated at 2022-06-22 05:33:43.641051
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    # BaseError without messages
    with pytest.raises(AssertionError):
        BaseError()
    # BaseError with single message
    BaseError(text="error") == BaseError(text="error")
    assert (
        BaseError(text="error") == BaseError(text="error")
    ), "BaseError(text) should be equal to BaseError(text)"
    assert (
        BaseError(text="error") != BaseError(text="error2")
    ), "BaseError(text) should not be equal to BaseError(text2)"
    assert (
        hash(BaseError(text="error")) == hash(BaseError(text="error"))
    ), "hash(BaseError(text)) should equal hash(BaseError(text))"

# Generated at 2022-06-22 05:33:46.223724
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(line_no=1, column_no=1, char_index=1) == Position(line_no=1, column_no=1, char_index=1)


# Generated at 2022-06-22 05:33:54.149901
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    message = Message(text='message.text', code='message.code', index=['message', 'index'], start_position=Position(line_no=3, column_no=2, char_index=5), end_position=Position(line_no=5, column_no=10, char_index=20))
    assert message.__repr__() == "Message(text='message.text', code='message.code', index=['message', 'index'], start_position=Position(line_no=3, column_no=2, char_index=5), end_position=Position(line_no=5, column_no=10, char_index=20))"


# Generated at 2022-06-22 05:34:06.103971
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    message_1 = Message(text='May not have more than 100 characters', code='max_length')
    assert message_1.__hash__() == hash(('max_length', ()))
    message_2 = Message(text='May not have more than 100 characters', code='max_length')
    assert message_1.__hash__() == message_2.__hash__()
    message_3 = Message(text='test_text_3', code='test_code_3', key='test_key_3')
    assert message_3.__hash__() == hash(('test_code_3', ('test_key_3',)))
    message_4 = Message(text='test_text_4', code='test_code_4', key='test_key_4')
    assert message_3.__hash__() == message_4.__hash

# Generated at 2022-06-22 05:34:17.726708
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    assert hash(Message(text="", code=None, key=None, index=[1])) == hash(Message(text="", code=None, key=None, index=[1]))
    assert hash(Message(text="", code=None, key=None, index=[1])) != hash(Message(text="", code=None, key=None, index=[2]))
    assert hash(Message(text="", code=None, key=None, index=[1,2])) != hash(Message(text="", code=None, key=None, index=[1]))
    assert hash(Message(text="", code=None, key=None, index=[1])) != hash(Message(text="", code=None, key=None, index=[1,2]))

# Generated at 2022-06-22 05:34:29.775393
# Unit test for constructor of class BaseError
def test_BaseError():
    messages: typing.List[Message] = []
    messages.append(Message(text='Programming error', code=None, key=None, index=None, position=None, start_position=None, end_position=None))
    messages.append(Message(text='Schema error', code='max_length', key='username', index=None, position=None, start_position=None, end_position=None))
    messages.append(Message(text='File error', code='required', key=None, index=['file', '0', 'username'], position=None, start_position=None, end_position=None))
    messages.append(Message(text='File error2', code='required', key=None, index=['file', '1', 'username'], position=None, start_position=None, end_position=None))
    #

# Generated at 2022-06-22 05:34:38.925732
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    m = Message(text = 'text', code = 'code', key = 'key', index = ['index'], start_position = 0, end_position = 0)
    m1 = Message(text = 'text', code = 'code', key = 'key', index = ['index'], start_position = 0, end_position = 0)
    m2 = Message(text = 'text', code = 'code', key = 'key', index = ['index'])
    assert m == m1
    assert m2 == m1
    assert m == m2


# Generated at 2022-06-22 05:34:43.009204
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    vr_value = ValidationResult(value=1)
    vr_error = ValidationResult(error=1)
    assert(repr(vr_value) == "ValidationResult(value=1)")
    assert(repr(vr_error) == "ValidationResult(error=1)")

# Generated at 2022-06-22 05:34:53.677900
# Unit test for constructor of class ValidationError
def test_ValidationError():
    value, error = ValidationResult()
    assert value is None
    assert error is None

    value, error = ValidationResult(
    )
    assert value is None
    assert error is None

    value, error = ValidationResult(value="hello")
    assert value == "hello"
    assert error is None

    error = ValidationError(
        text="hello", code="custom", key=None, position=None, messages=None
    )
    value, error = ValidationResult(error=error)
    assert value is None
    assert error == ValidationError(
        text="hello", code="custom", key=None, position=None, messages=None
    )

# Generated at 2022-06-22 05:34:58.294416
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    from typesystem.base_schema import BaseSchema
    from typesystem.undefined import Undefined
    x = ValidationResult(value=Undefined)
    x1 = iter(x)
    assert (next(x1) == Undefined)
    assert next(x1) == None



# Generated at 2022-06-22 05:35:04.844790
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Create 2 BaseError instances
    be1 = BaseError()
    be2 = BaseError()
    # check if they are equal
    if(be1 == be2):
        # show that they are equal
        print("BaseError objects are equal")
    else:
        # show that they are not equal
        print("BaseError objects are not equal")



# Generated at 2022-06-22 05:35:12.221025
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    # Test with missing arguments passed to __init__
    with pytest.raises(AssertionError):
        Message()
    # Test with non-missing arguments passed to __init__
    test = Message(text = "May not have more than 100 characters", code = "max_length", key = "username")
    assert test.__repr__() == "Message(text='May not have more than 100 characters', code='max_length', index=['username'])"


# Generated at 2022-06-22 05:35:17.498315
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert ValidationResult(value = None, error = None).value is None
    assert ValidationResult(value = None, error = None).error is None
    assert ValidationResult(value = 'value1', error = None).value == 'value1'
    assert ValidationResult(value = 'value1', error = None).error is None

# Generated at 2022-06-22 05:35:25.298545
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    pos1 = Position(line_no=1, column_no=1, char_index=1)
    pos2 = Position(line_no=2, column_no=2, char_index=2)
    pos3 = Position(line_no=1, column_no=2, char_index=2)
    assert pos1 == pos1
    assert pos1 != pos2
    assert pos2 == pos2
    assert pos1 != pos3


# Generated at 2022-06-22 05:35:34.468008
# Unit test for constructor of class ValidationError
def test_ValidationError():
    validation_error = ValidationError(text= 'May not have more than 100 characters',
        code= 'max_length',
        key= 'username')
    assert validation_error is not None
    validation_error = ValidationError(text= 'May not have more than 100 characters',
        code= 'max_length')
    assert validation_error is not None
    validation_error = ValidationError(messages=[Message(text= 'May not have more than 100 characters',
        code= 'max_length',
        key= 'username')])
    assert validation_error is not None
    validation_error = ValidationError(messages=[Message(text= 'May not have more than 100 characters',
        code= 'max_length')])
    assert validation_error is not None

# Generated at 2022-06-22 05:35:45.122957
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    position1 = Position(line_no=1, column_no=2, char_index=3)
    position2 = Position(line_no=1, column_no=2, char_index=3)
    assert position1 == position2

    # test false
    position2 = Position(line_no=0, column_no=2, char_index=3)
    assert position1 != position2
    position2 = Position(line_no=1, column_no=0, char_index=3)
    assert position1 != position2
    position2 = Position(line_no=1, column_no=2, char_index=0)
    assert position1 != position2
    position2 = object()
    assert position1 != position2


# Generated at 2022-06-22 05:36:01.292960
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    position_1 = Position(line_no=4, column_no=2, char_index=15)
    assert position_1 == Position(line_no=4, column_no=2, char_index=15)
    assert not (position_1 == Position(line_no=4, column_no=2, char_index=16))
    assert not (position_1 == Position(line_no=4, column_no=3, char_index=15))
    assert not (position_1 == Position(line_no=5, column_no=2, char_index=15))
    assert not (position_1 == Position(line_no=4, column_no=2, char_index=16))
    assert not (position_1 == Position(line_no=5, column_no=3, char_index=16))
   

# Generated at 2022-06-22 05:36:13.212994
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    code_test_cases = ["max_length", None]
    key_test_cases = ["username", None]
    index_test_cases = [[1], None]

    for code in code_test_cases:
        for key in key_test_cases:
            for index in index_test_cases:
                value_test_case = Message(text="test", code=code, key=key, index=index)
                assert value_test_case.__eq__(value_test_case) == True
                assert value_test_case.__eq__(Message(text="test", code=code, key=key, index=index)) == True
                assert value_test_case.__eq__(Message(text="test1", code=code, key=key, index=index)) == False
                assert value_test_case.__eq__

# Generated at 2022-06-22 05:36:17.194595
# Unit test for constructor of class ParseError
def test_ParseError():
    parse_error = ParseError(key="custom", text="This is a ParseError.")
    print(parse_error)
    print(parse_error.messages())


# Generated at 2022-06-22 05:36:23.884955
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    value = 'some_value'
    error = "Some Error has occured"
    value_result = ValidationResult(value=value)
    error_result = ValidationResult(error=error)

    assert repr(value_result) == f"ValidationResult(value='{value}')"
    assert repr(error_result) == f"ValidationResult(error='{error}')"


# Generated at 2022-06-22 05:36:31.681754
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    text = "Some Text"
    code = "Some Code"
    key = "Some Key"
    assert BaseError(text=text, code=code, key=key).messages() == [Message(**{'text': text, 'code': code, 'key': key})]
    messages = [Message(**{'text': text, 'code': code, 'key': key})]
    assert BaseError(messages=messages).messages() == messages


# Generated at 2022-06-22 05:36:37.872443
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    text = 'text'
    code = 'code'
    key = 'key'
    index = ['index']
    start_position = Position(100,100,100)
    end_position = Position(100,100,100)
    message = Message(text=text, code=code, key=key, index=index, start_position=start_position, end_position=end_position)
    message_repr = 'Message(text=\'text\', code=\'code\', index=[\'index\'], start_position=Position(line_no=100, column_no=100, char_index=100), end_position=Position(line_no=100, column_no=100, char_index=100))'
    assert repr(message) == message_repr



# Generated at 2022-06-22 05:36:40.280396
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    m1 = Message(text="a")
    m2 = Message(text="a")
    assert m1 == m2

# Generated at 2022-06-22 05:36:48.909954
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Default test
    obj1 = BaseError(text="test")
    obj2 = BaseError(text="test")
    is_equal = obj1 == obj2
    assert is_equal
    assert not (not is_equal)
    # Default test
    obj1 = BaseError(text="test")
    obj2 = BaseError(text="test2")
    is_equal = obj1 == obj2
    assert not is_equal
    assert not (not is_equal)
    # Default test
    obj1 = BaseError(text="test", messages=[Message(text="test2")])
    obj2 = BaseError(text="test", messages=[Message(text="test")])
    is_equal = obj1 == obj2
    assert not is_equal
    assert not (not is_equal)
    # Default test

# Generated at 2022-06-22 05:36:53.569313
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    instance_1 = Position(line_no=1, column_no=1, char_index=1)
    instance_2 = Position(line_no=2, column_no=2, char_index=2)
    assert not (instance_1 == instance_2)
    assert instance_1 == instance_1


# Generated at 2022-06-22 05:36:55.394299
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    object1 = BaseError(text="error")

    # Calling __str__ method with explicit self
    # BaseError.__str__(object1)



# Generated at 2022-06-22 05:37:11.490033
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    """
    Unit test for method __repr__ of class ValidationResult
    """
    vr = ValidationResult(value='value')
    print(vr)
    vr = ValidationResult(error='error')
    print(vr)


# Generated at 2022-06-22 05:37:21.710129
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError("Bad JSON")
    assert isinstance(error, BaseError)
    assert isinstance(error, Mapping)
    assert isinstance(error, Exception)
    assert error.text == "Bad JSON"
    assert error.code == "custom"
    assert error.key is None
    assert error.index == []
    assert error.position is None
    assert error.start_position is None
    assert error.end_position is None
    assert error._messages == [
        Message(text="Bad JSON", code="custom", index=[])
    ]
    assert error._message_dict == {"": "Bad JSON"}
    assert len(error) == 1
    assert str(error) == "Bad JSON"
    assert repr(error) == "ParseError(text='Bad JSON', code='custom')"

# Unit test

# Generated at 2022-06-22 05:37:35.201216
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    assert repr(BaseError(
        text='May not have more than 100 characters',
        code='max_length',
        key='username',
    )) == "BaseError(text='May not have more than 100 characters', code='max_length')"

    assert repr(BaseError(messages=[Message(
        text='May not have more than 100 characters',
        code='max_length',
        key='username',
    )])
    ) == "BaseError([Message(text='May not have more than 100 characters', code='max_length', index=['username'])])"


# Generated at 2022-06-22 05:37:40.227291
# Unit test for constructor of class ValidationError
def test_ValidationError():
	ve = ValidationError(text="text", code="code", key="key", position="position", messages="messages")
	assert ve._message_dict == {"": ""}
	assert ve._messages == ["messages"]
	assert ve.text == "text"
	assert ve.code == "code"
	assert ve.key == "key"
	assert ve.position == "position"
	assert ve.messages == ["messages"]

# Generated at 2022-06-22 05:37:49.800456
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    error1 = BaseError(text="This is a test error", code='test_error')
    assert repr(error1) == "BaseError(text='This is a test error', code='test_error')"

    message1 = Message(text="This is a test error", code="test_error", key="username")
    message2 = Message(text="This is a second test error", code="test_error", key="password")
    error2 = BaseError(messages=[message1, message2])
    assert repr(
        error2
    ) == "BaseError([Message(text='This is a test error', code='test_error', key='username'), Message(text='This is a second test error', code='test_error', key='password')])"


# Generated at 2022-06-22 05:38:01.598357
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    assert repr(BaseError(messages=[Message(text='test_text')])) == "BaseError([Message(text='test_text', code='custom', index=[], position=None, start_position=None, end_position=None)])"
    assert repr(BaseError(messages=[Message(text='test_text1'), Message(text='test_text2')])) == "BaseError([Message(text='test_text1', code='custom', index=[], position=None, start_position=None, end_position=None), Message(text='test_text2', code='custom', index=[], position=None, start_position=None, end_position=None)])"
    assert repr(BaseError(text='test_text')) == "BaseError(text='test_text', code='custom')"

# Generated at 2022-06-22 05:38:07.680136
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    import datetime
    result = ValidationResult()
    assert result.value == None
    assert result.error == None

    result = ValidationResult(value=10)
    assert result.value == 10
    assert result.error == None

    result = ValidationResult(error=ValidationError())
    assert result.value == None
    assert result.error != None

    assert isinstance(bool(result), bool)

# Generated at 2022-06-22 05:38:13.607386
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    # Case 1: value = 1, result = True
    res = ValidationResult(value = 1)
    assert (res.value == 1) and (res.error == None)
    assert res
    # Case 2: value = 1, result = False
    res = ValidationResult(error = 1)
    assert (res.value == None) and (res.error == 1)
    assert not res


# Generated at 2022-06-22 05:38:22.856829
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    error = ValidationError(messages=[
        Message(text="Not a number", code="custom", key=0),
        Message(text="Not a number", code="custom", key=1),
        Message(text="Not a number", code="custom", key=3),
        Message(text="Less than 100", code="custom", key=2),
    ])
    assert error[0] == "Not a number"
    assert error[1] == "Not a number"
    assert error[2] == "Less than 100"
    assert error[3] == "Not a number"
    assert error[4] == None


# Generated at 2022-06-22 05:38:30.446850
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    error = BaseError(messages=[Message(text='error1', code='code1', key='key1'), Message(text='error2', code='code2', key='key2')])
    list(error)
    assert error['key1'] == 'error1'
    assert error['key2'] == 'error2'
    # Unit test for method messages of class BaseError
    def test_BaseError_messages():
        error = BaseError(messages=[Message(text='error1', code='code1', key='key1'), Message(text='error2', code='code2', key='key2')])
        msg = error.messages()
        assert msg[0].text == 'error1' and msg[0].code == 'code1' and msg[0].index == ['key1']

# Generated at 2022-06-22 05:39:01.496659
# Unit test for constructor of class Message
def test_Message():
    message = Message(text="G", position=Position(1, 2, 3))
    assert message.text == "G"
    assert message.code == "custom"
    assert message.index == []
    assert message.start_position == Position(1, 2, 3)
    assert message.end_position == Position(1, 2, 3)

# Generated at 2022-06-22 05:39:12.604460
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(
        line_no=1, column_no=1, char_index=1
    ) == Position(line_no=1, column_no=1, char_index=1)
    assert Position(
        line_no=2, column_no=2, char_index=2
    ) == Position(line_no=2, column_no=2, char_index=2)
    assert Position(
        line_no=3, column_no=3, char_index=3
    ) == Position(line_no=3, column_no=3, char_index=3)
    assert Position(
        line_no=1, column_no=1, char_index=1
    ) != Position(line_no=2, column_no=2, char_index=2)

# Generated at 2022-06-22 05:39:19.883862
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    """Unit test for method __repr__ of class ValidationResult."""
    actual_1 = repr(ValidationResult(value=5))
    expected_1 = "ValidationResult(value=5)"
    assert actual_1 == expected_1
    actual_2 = repr(ValidationResult(error=ValidationError(text="This is an error.")))
    expected_2 = "ValidationResult(error=ValidationError(text='This is an error.'))"
    assert actual_2 == expected_2

# Generated at 2022-06-22 05:39:31.277585
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
       
        result = ValidationResult(value='abc')
        print(result)
        assert result.value == 'abc'
        assert result.error == None
        assert result == ValidationResult(value='abc')
        assert result != ValidationResult(error='abc')
        assert result.__bool__() == True
        assert result.__bool__()
        assert result.__iter__()
        assert next(result.__iter__()) == 'abc'
        assert next(result.__iter__()) == None
        assert repr(result) == "ValidationResult(value='abc')"

        result = ValidationResult(error='abc')
        print(result)
        assert result.value == None
        assert result.error == 'abc'
        assert result == ValidationResult(error='abc')

# Generated at 2022-06-22 05:39:35.188898
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    base_error = BaseError(messages=[Message(text="May not have more than 100 characters")])
    expected = "{'': 'May not have more than 100 characters'}"
    assert str(base_error) == expected


# Generated at 2022-06-22 05:39:46.963245
# Unit test for constructor of class BaseError
def test_BaseError():
    # Instantiate with a single message
    text = 'this is an error message'
    code = 'code value'
    key = 'key'
    position = Position(1,2,3)
    print_msg = BaseError(text=text,code=code,key=key,position=position)
    assert print_msg._messages == [Message(text=text,code=code,key=key,position=position)]
    assert print_msg._message_dict == {'key': 'this is an error message'}

    # Instantiate with a list of error messages
    message1 = Message(text=text,code=code,key=key,position=position)
    message2 = Message(text=text,code='code2',key=key,position=position)
    messages = [message1, message2]
    print_msg = Base

# Generated at 2022-06-22 05:39:56.890392
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    # first test
    # Case: when Value is not none and error is None
    a = ValidationResult(value="hello")
    b = iter(a)
    assert next(b) == "hello"
    assert next(b) == None
    assert bool(a) == True
    assert repr(a) == "ValidationResult(value='hello')"

    # Second Test
    # Case: when Error is not none and value is None
    a = ValidationResult(error="Error")
    b = iter(a)
    assert next(b) == None
    assert next(b) == "Error"
    assert bool(a) == False
    assert repr(a) == "ValidationResult(error='Error')"



# Generated at 2022-06-22 05:39:59.313315
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
  pass


# Generated at 2022-06-22 05:40:06.711361
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert (Position(1,2,3) == Position(1,2,3)) == True
    assert (Position(1,2,3) == Position(1,2,4)) == False
    assert (Position(1,2,3) == Position(1,3,3)) == False
    assert (Position(1,2,3) == Position(2,2,3)) == False
    assert (Position(1,2,3) == 1) == False


# Generated at 2022-06-22 05:40:08.801611
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    vr = ValidationResult(value=10)
    vr_r = repr(vr)
    assert (vr_r == "ValidationResult(value=10)")

# Generated at 2022-06-22 05:41:10.427118
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    assert (BaseError(text = 'May not have more than 100 characters', code = 'max_length')).__repr__() == "BaseError(text='May not have more than 100 characters', code='max_length')"


# Generated at 2022-06-22 05:41:17.012452
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    # Check the repr of ValidationError with single error message
    assert repr(ValidationError(text="error 1", code="c")) == "ValidationError('error 1', code='c')"
    assert repr(ValidationError(text="error 1", code="c", key=1)) == "ValidationError('error 1', code='c')"
    # Check the repr of ValidationError with multiple error messages
    assert repr(ValidationError(messages=[Message(text="error 1"), Message(text="error 2")])) == "ValidationError([Message('error 1'), Message('error 2')])"


# Generated at 2022-06-22 05:41:18.956839
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    dic = {'a':1, 'b':2}
    instance = ValidationResult(dic)
    assert dic == instance


# Generated at 2022-06-22 05:41:25.788056
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    """
    This test is meant to check whether __eq__() is implemented correctly.
    """

    message = Message(text="text", code="code", key="key", index=["index"], position=Position(1, 2, 3))
    message_same = Message(text="text", code="code", key="key", index=["index"], position=Position(1, 2, 3))
    message_different = Message(text="other_text", code="code", key="key", index=["index"], position=Position(1, 2, 3))

    assert message == message_same
    assert not message == message_different



# Generated at 2022-06-22 05:41:36.131439
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result1 = ValidationResult(value='value')
    validation_result2 = ValidationResult(error='error')

    assert validation_result1.value == 'value'
    assert validation_result1.error is None
    assert bool(validation_result1) == True

    assert validation_result2.value is None
    assert validation_result2.error == 'error'
    assert bool(validation_result2) == False

    assert list(iter(validation_result1)) == ['value', None]
    assert list(iter(validation_result2)) == [None, 'error']

    print("Unit test for method __iter__ of class ValidationResult:")
    print("  ValidationResult(value='value') => {}".format(validation_result1))

# Generated at 2022-06-22 05:41:41.391582
# Unit test for constructor of class Position
def test_Position():
    assert Position(10, 20, 30) == Position(10, 20, 30)
    assert Position(10, 20, 30) != Position(11, 20, 30)
    assert Position(10, 20, 30) != Position(10, 21, 30)
    assert Position(10, 20, 30) != Position(10, 20, 31)
    assert Position(10, 20, 30) != "hello"



# Generated at 2022-06-22 05:41:44.017842
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    assert repr(Position(1,2,3)) == 'Position(line_no=1, column_no=2, char_index=3)'


# Generated at 2022-06-22 05:41:56.056284
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    err1 = BaseError(text="Error 1")
    assert str(err1) == "Error 1"
    err2 = BaseError(messages=[Message(text="Error 1"), Message(text="Error 2")])
    assert str(err2) == "{'': 'Error 1'}"
    err3 = BaseError(
        messages=[
            Message(text="Error 1", key="key1"),
            Message(text="Error 2", key="key2"),
        ]
    )
    assert str(err3) == "{'key1': 'Error 1', 'key2': 'Error 2'}"

# Generated at 2022-06-22 05:42:00.464514
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    message = Message(text="The error message to display", code="custom", key=None, index=None, start_position=Position(3, 4, 5), end_position=Position(6, 7, 8))
    error = BaseError(messages=[message])
    assert isinstance(error['The error message to display'], str)



# Generated at 2022-06-22 05:42:03.818177
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    error = BaseError(text="this is a text\n this is another text")
    item = error[0]

    assert item == "this is a text\n this is another text"
