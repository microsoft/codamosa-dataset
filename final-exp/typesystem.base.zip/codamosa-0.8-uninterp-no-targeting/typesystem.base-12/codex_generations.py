

# Generated at 2022-06-22 05:33:04.493669
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    obj = BaseError(text="foo", code="bar", key="baz")
    assert obj["baz"] == "foo"
    obj = BaseError(text="foo", code="bar", key=None)
    assert obj[""] == "foo"

# Generated at 2022-06-22 05:33:09.196482
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    # equal
    assert Position(1, 2, 3) == Position(1, 2, 3)
    # not equal
    assert Position(1, 2, 3) != Position(2, 2, 3)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    # not instance
    assert Position(1, 2, 3) != 1
    assert Position(1, 2, 3) != "hello"


# Generated at 2022-06-22 05:33:19.904546
# Unit test for constructor of class ValidationError
def test_ValidationError():
    assert ValidationError(text='invalid') == ValidationError(text='invalid')
    assert ValidationError(text='invalid', code='code', key='key') == ValidationError(text='invalid', code='code', key='key')
    assert ValidationError(text='invalid', position=Position(1, 2, 3)) == ValidationError(text='invalid', position=Position(1, 2, 3))
    assert ValidationError(text='invalid') == ValidationError(messages=[Message(text='invalid')])
    assert ValidationError(text='invalid', code='code') == ValidationError(messages=[Message(text='invalid', code='code')])

# Generated at 2022-06-22 05:33:27.191833
# Unit test for constructor of class ParseError
def test_ParseError():
    msg = 'ParseError'
    index = ['item']
    start = Position(0, 0, 0)
    end = Position(0, 0, 1)
    pe = ParseError(text=msg, index=index, start_position=start, end_position=end)
    assert pe.messages() == [Message(text=msg, index=index, position=start, start_position=start, end_position=end)]


# Generated at 2022-06-22 05:33:31.773735
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    BaseError(text="foo") == BaseError(text="foo")
    ValidationError(text="foo") == ValidationError(text="foo")
    BaseError(text="foo") != BaseError(text="bar")
    ValidationError(text="foo") != ValidationError(text="bar")


# Generated at 2022-06-22 05:33:32.871800
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    pass



# Generated at 2022-06-22 05:33:38.704504
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    value = BaseError(text='text=dataDict', code='code=dataDict', key='key=dataDict')
    print(value.__repr__())
    value = BaseError(messages=[Message('text=dataDict'), Message('text=dataDict'), Message('text=dataDict')])
    print(value.__repr__())


# Generated at 2022-06-22 05:33:42.151143
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    assert repr(ValidationResult(value=1, error=ValidationError(messages=[ValidationError(text="1")]))) == 'ValidationResult(value=1, error=ValidationError([ValidationError(text="1")]))'

# Generated at 2022-06-22 05:33:47.696468
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # BaseError__eq__1
    # equal
    assert ValidationError(messages=[Message(text="text")]) == ValidationError(messages=[Message(text="text")])
    # BaseError__eq__2
    # not equal
    assert not ValidationError(messages=[Message(text="text")]) == ValidationError(messages=[Message(text="text2")])


# Generated at 2022-06-22 05:33:53.775536
# Unit test for constructor of class Position
def test_Position():
    x = Position(1, 2, 3)
    assert x.line_no == 1
    assert x.column_no == 2
    assert x.char_index == 3


# Generated at 2022-06-22 05:34:08.173709
# Unit test for constructor of class Message
def test_Message():
    assert Message(text="Text") == Message(text="Text")
    assert Message(text="Text") != Message(text="Text", code="foo")
    assert Message(text="Text", index=["foo"]) == Message(text="Text",index=["foo"])
    assert Message(text="Text", index=["foo"]) != Message(text="Text",index=["bar"])
    assert Message(text="Text", position=Position(1,2,3)) == Message(text="Text",position=Position(1,2,3))
    assert Message(text="Text", position=Position(1,2,3)) != Message(text="Text",position=Position(4,5,6))

# Generated at 2022-06-22 05:34:19.507507
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    message = Message(text="Invalid value")
    assert len(BaseError(messages=[message])) == 0

    message = Message(text="Invalid value", key="username")
    assert len(BaseError(messages=[message])) == 1

    message = Message(text="Invalid value", index=["users", 0, "username"])
    assert len(BaseError(messages=[message])) == 1

    message = Message(text="Invalid value", index=["users", 0, "username"])
    message2 = Message(text="Invalid value", index=["users", 1, "username"])
    assert len(BaseError(messages=[message, message2])) == 2

    message = Message(text="Invalid value", index=["users", 0, "username"])

# Generated at 2022-06-22 05:34:28.201084
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    m1 = Message(text="text", code="code", index=[1, 2], start_position=Position(1, 2, 3), end_position= Position(3, 2, 1))
    print(m1)
    m2 = Message(text="text", code="code", index=[1, 2], start_position=Position(1, 2, 3), end_position= Position(3, 2, 1))
    print(m2)
    assert m1 == m2
    d = {m1: 1}
    d[m2] = 2
    assert len(d) == 1


# Generated at 2022-06-22 05:34:34.793570
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError(
        messages = [
            Message(text='"1" is not of type "array"'),
            Message(text='"foo" is not an allowed key', key='foo')
        ]
        )
    assert error["foo"] == '"foo" is not an allowed key'
    assert error[0] == '"1" is not of type "array"'
    assert len(error) == 2
    assert 'foo' in error
    assert list(error.items()) == [
        ('foo', '"foo" is not an allowed key'),
        (0, '"1" is not of type "array"')
    ]
    assert isinstance(error, BaseError)
    assert isinstance(error, ParseError)
    assert isinstance(error, Exception)

# Generated at 2022-06-22 05:34:37.562434
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    assert repr(ValidationError(text="This is a test", code="code", key="key")) == 'ValidationError(text=\'This is a test\', code=\'code\')'


# Generated at 2022-06-22 05:34:43.177467
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    message = Message(text = "Text", code= "custom", index = ['Users'])
    result = message.__repr__()
    assert result == "Message(text='Text', code='custom', index=['Users'])"


# Generated at 2022-06-22 05:34:53.746695
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    error = BaseError(text="foo", code="bar", key="baz")
    assert error.messages() == [Message(text="foo", code="bar", key="baz")]

    error = BaseError(
        messages=[Message(text="foo1", code="bar1"), Message(text="foo2", code="bar2")]
    )
    assert error.messages() == [
        Message(text="foo1", code="bar1"),
        Message(text="foo2", code="bar2"),
    ]

    error = BaseError(
        messages=[Message(text="foo1", code="bar1"), Message(text="foo2", code="bar2")]
    )

# Generated at 2022-06-22 05:34:58.760894
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    obj = BaseError(text='Txt', code='Cde', key='Kye')
    print(obj)
    print(len(obj))


if __name__ == '__main__':
    test_BaseError___len__()
    """
    BaseError(text='Txt', code='Cde', key='Kye')
    1
    """

# Generated at 2022-06-22 05:35:08.047579
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    data_list = [
        (
            # first set
            1,
            1,
            0,
        ),
    ]
    for myline_no, mycolumn_no, mychar_index in data_list:
        position = Position(
            myline_no,
            mycolumn_no,
            mychar_index
        )
        # test
        assert repr(position)==f"Position(line_no={myline_no}, column_no={mycolumn_no}, char_index={mychar_index})"


# Generated at 2022-06-22 05:35:18.474835
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(
        text="You must provide a value"
    ) == BaseError(
        text="You must provide a value"
    )
    assert BaseError(
        text="You must provide a value"
    ) != BaseError(
        text="You must provide a value", code="required"
    )
    assert BaseError(
        text="Must be a string with at least 10 characters"
    ) != BaseError(
        text="Must be a string with at most 10 characters"
    )

    assert BaseError(
        text="You must provide a value", key="username"
    ) == BaseError(
        text="You must provide a value", key="username"
    )

# Generated at 2022-06-22 05:35:27.072437
# Unit test for constructor of class ParseError
def test_ParseError():
    pe = ParseError(text = 'hello world', code = 'error', key = 'key')
    assert pe.text == 'hello world'
    assert pe.code == 'error'
    assert pe.key == 'key'


# Generated at 2022-06-22 05:35:29.525892
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    vr_case1 = ValidationResult()
    vr_case2 = ValidationResult(value="abc")
    vr_case3 = ValidationResult(error="abc")

# Generated at 2022-06-22 05:35:38.182240
# Unit test for constructor of class Message
def test_Message():
    msg = Message(
        text='error in validate_email',
        code='custom',
        key='email',
        position=Position(line_no=1, column_no=1, char_index=1)
    )
    assert msg.text == 'error in validate_email'
    assert msg.code == 'custom'
    assert msg.index == ['email']
    assert msg.start_position == msg.end_position == Position(line_no=1, column_no=1, char_index=1)


# Generated at 2022-06-22 05:35:43.099361
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    position_0 = Position(line_no=1, column_no=2, char_index=3)
    assert repr(position_0) == "Position(line_no=1, column_no=2, char_index=3)"



# Generated at 2022-06-22 05:35:45.734415
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert len(list(vr)) == 2
    vr = ValidationResult(error=ValidationError())
    assert len(list(vr)) == 2


# Generated at 2022-06-22 05:35:47.972410
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    basic_1: BaseError = BaseError()
    var_1: int = len(basic_1)
    assert var_1 == 0


# Generated at 2022-06-22 05:35:51.260822
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    error = BaseError(text='test error')
    assert error.messages() == [Message(text='test error', code='custom', index=[])]



# Generated at 2022-06-22 05:35:52.947202
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    position1 = Position(1,1,1)
    position2 = Position(1,1,1)
    assert position1 == position2


# Generated at 2022-06-22 05:36:02.053104
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    """
    Unit test for Message.__hash__
    """
    assert hash(Message(text="abc", code="max_length", key="username")) == hash(
        Message(text="abc", code="max_length", key="username")
    )
    assert hash(Message(text="abc", code="max_length", index=["username"])) == hash(
        Message(text="abc", code="max_length", index=["username"])
    )
    assert hash(
        Message(text="abc", code="max_length", key="username")
    ) != hash(Message(text="abc", index=["username"]))
    assert hash(Message(text="abc", key="username")) != hash(
        Message(text="abc", index=["username"])
    )

# Generated at 2022-06-22 05:36:13.463653
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    assert repr(ValidationError(text='May not be null')) == "ValidationError(text='May not be null', code='custom')"
    assert repr(ValidationError(messages=[Message(index=['users', 3], text='May not be null')])) == "ValidationError([Message(text='May not be null', code='custom', index=['users', 3])])"
    assert repr(ValidationError(messages=[Message(index=[], text='May not be null')])) == "ValidationError([Message(text='May not be null', code='custom')])"
    assert repr(ParseError(text='Expected value')) == "ParseError(text='Expected value', code='custom')"

# Generated at 2022-06-22 05:36:35.669254
# Unit test for method __eq__ of class Message
def test_Message___eq__():
#	message1 = Message()
#	message2 = Message()
	message1 = Message(text="May not have more than 100 characters", code="max_length", key="username")
	message2 = Message(text="May not have more than 100 characters", code="max_length", key="username")
	if message1.__eq__(message2):
		print("The method Message.__eq__ works.")
	else:
		print("The method Message.__eq__ doesn't work.")
	message2 = Message(text="May not have more than 100 characters", code="max_length", key="username", index = ["users", 3])
	if not message1.__eq__(message2):
		print("The method Message.__eq__ works.")
	else:
		print("The method Message.__eq__ doesn't work.")


# Generated at 2022-06-22 05:36:47.257096
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    msg1 = Message(
        text="Failure message 1", code="code1", index=[1])
    msg2 = Message(
        text="Failure message 2", code="code2", index=[2])
    msg3 = Message(
        text="Failure message 3", code="code3", index=[3])
    msg4 = Message(
        text="Failure message 4", code="code4", index=[4])
    msg5 = Message(
        text="Failure message 5", code="code5", index=[5])

    msgs = [msg1, msg2, msg3, msg4, msg5]

    seen = set()
    for msg in msgs:
        assert msg not in seen
        seen.add(msg)
    
if __name__ == "__main__":
    test_Message___hash__()

# Generated at 2022-06-22 05:36:53.034462
# Unit test for constructor of class ValidationResult
def test_ValidationResult():

    value = ""
    error = ValidationError(text="error text",code="code",key="key",messages=["error message"])
    res1 = ValidationResult(value=value)
    assert res1.value == value and res1.error is None

    res2 = ValidationResult(error=error) 
    assert res2.value is None and res2.error == error



# Generated at 2022-06-22 05:36:57.400157
# Unit test for constructor of class Position
def test_Position():
    pos1 = Position(1,1,1)
    pos2 = Position(1,1,1)
    assert pos1 == pos2
    assert pos1.line_no == 1
    assert pos1.column_no == 1
    assert pos1.char_index == 1


# Generated at 2022-06-22 05:37:02.938097
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    error = BaseError(
        text="Not a number",
        code="invalid_type",
        key="user_id",
        position=Position(line_no=1, column_no=8, char_index=7),
    )
    assert error["user_id"] == "Not a number"



# Generated at 2022-06-22 05:37:10.138096
# Unit test for constructor of class BaseError
def test_BaseError():
    error = BaseError(text="Wrong")
    print(error)
    assert error[""] == "Wrong"
    assert error == BaseError(text="Wrong")

    error = BaseError(
        text="Wrong user name", messages=[Message(text="Wrong user name", code='username_error')]
    )
    assert error[""] == "Wrong user name"
    error == BaseError(
        messages=[Message(text="Wrong user name", code='username_error')]
    )
    assert error['username_error'] == 'Wrong user name'


# Generated at 2022-06-22 05:37:12.617906
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    result = ValidationResult(error='an error')
    assert not result
    result = ValidationResult(value=5)
    assert result
test_ValidationResult___bool__()

# Generated at 2022-06-22 05:37:22.770942
# Unit test for constructor of class ParseError
def test_ParseError():
    # Test without position
    error = ParseError(text="Hello", key=1)
    assert len(error) == 1
    messages = error.messages()
    assert len(messages) == 1
    assert messages[0].text == "Hello"
    assert messages[0].code == "custom"
    assert messages[0].index == [1]

    # Test with position
    error = ParseError(text="Hello", key=1, position=Position(1, 2, 3))
    assert len(error) == 1
    messages = error.messages()
    assert len(messages) == 1
    assert messages[0].text == "Hello"
    assert messages[0].code == "custom"
    assert messages[0].index == [1]

# Generated at 2022-06-22 05:37:35.912097
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    base_error = BaseError()
    assert(base_error.__repr__() == "BaseError([])")
    base_error = BaseError(messages=[Message(text='text', code='code', index=['index'])])
    assert(base_error.__repr__() == "BaseError([Message(text='text', code='code', index=['index'])])")
    base_error = BaseError(text='text', code='code')
    assert(base_error.__repr__() == "BaseError(text='text', code='code')")
    base_error = BaseError(text='text', code='code', key='foo')
    assert(base_error.__repr__() == "BaseError(text='text', code='code')")



# Generated at 2022-06-22 05:37:39.503882
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    value = ValidationResult(value='X')
    value = ValidationResult(error='X')
    error = ValidationResult(error='X')
    assert list(value) == ['X', None]
    assert list(error) == [None, 'X']


# Generated at 2022-06-22 05:38:18.060516
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # Test the function named by function_name
    # with the arguments listed in args
    # and the expected value listed in expected
    # And return whether the result matches expected
    vr_1 = ValidationResult(value=5)
    vr_2 = ValidationResult(value=None)
    vr_3 = ValidationResult(error=ValidationError(text="message", code="code"))
    vr_4 = ValidationResult(error=ValidationError())

    assert next(iter(vr_1)) == 5
    assert next(iter(vr_2)) == None
    assert next(iter(vr_3)) == vr_3.error
    assert next(iter(vr_4)) == vr_4.error



# Generated at 2022-06-22 05:38:24.657939
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert Message(text="Test", code="test", key="test") == Message(
        text="Test", code="test", key="test"
    )
    assert Message(text="Test", code="test", key="test") != Message(
        text="Test", code="test", key="test2"
    )
    assert Message(text="Test", code="test", key="test") != Message(
        text="Test", code="test", key="test3"
    )


# Generated at 2022-06-22 05:38:25.830577
# Unit test for constructor of class ParseError
def test_ParseError():
    error=ParseError()
    assert True

# Generated at 2022-06-22 05:38:36.008394
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    import pytest

    class TestBaseError(BaseError):
        pass

    # __repr__() for error with index
    error = TestBaseError(messages=[Message(text="invalid", code="foo", index=[5])])
    assert repr(error) == "TestBaseError([Message(text='invalid', code='foo', index=[5])])"

    # __repr__() for error without index
    error = TestBaseError(messages=[Message(text="invalid", code="foo")])
    assert repr(error) == "TestBaseError(text='invalid', code='foo')"

    # __repr__() for error without code
    error = TestBaseError(messages=[Message(text="invalid", index=[5])])

# Generated at 2022-06-22 05:38:47.460291
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    base_error_instance = BaseError(messages=[
        Message(
            text="Username may not have more than 100 characters",
            code="max_length",
            key="username",
        ),
        Message(
            text="May not have more than 100 characters",
            code="max_length",
            key="body_or_comments",
            index=[1, "body"],
        ),
    ])
    print("messages:", base_error_instance.messages())
    print("error_dict:", dict(base_error_instance))
    print("error_dict['username']:", base_error_instance["username"])
    print("error_dict[1]['body']:", base_error_instance[1]["body"])


if __name__ == "__main__":
    test_BaseError___get

# Generated at 2022-06-22 05:38:53.243713
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    result = ValidationResult(value=1)
    assert bool(result) is True
    assert result.value == 1
    assert result.error is None

    result = ValidationResult(error=ValidationError(text="Error!"))
    assert bool(result) is False
    assert result.value is None
    assert result.error.text == "Error!"


# Generated at 2022-06-22 05:39:01.958243
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    obj1 = ValidationResult(value=None, error=ValidationError(messages=[]))
    if not obj1:
        print(True)

    obj2 = ValidationResult(value=None, error=ValidationError(messages=None))
    if not obj2:
        print(True)

    obj3 = ValidationResult(value=None, error=ValidationError())
    if not obj3:
        print(True)

    obj4 = ValidationResult(value=None, error=ValidationError(messages=[""]))
    if not obj4:
        print(True)


# Generated at 2022-06-22 05:39:12.843297
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    assert hash(Message(text="abc")) == hash(Message(text="abc"))
    assert hash(Message(text="abc", code="custom")) == hash(Message(text="abc", code="custom"))
    assert hash(Message(text="abc", code="custom", key="age")) == hash(Message(text="abc", code="custom", key="age"))
    assert hash(Message(text="abc", code="custom", index=["users", 3, "age"])) == hash(Message(text="abc", code="custom", index=["users", 3, "age"]))
    assert hash(Message(text="abc", code="custom", position=Position(1, 2, 3))) == hash(Message(text="abc", code="custom", position=Position(1, 2, 3)))

# Generated at 2022-06-22 05:39:16.286841
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    assert ValidationResult().__bool__() == False
    assert ValidationResult(value=1).__bool__() == True
    assert ValidationResult(error=ValidationError()).__bool__() == False

# Generated at 2022-06-22 05:39:19.522345
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    # The error message must be returned right.
    error = BaseError(text='test_BaseError___str__')
    assert str(error) == 'test_BaseError___str__'
    
    

# Generated at 2022-06-22 05:39:47.644697
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    assert ValidationResult().__bool__() is False
    assert ValidationResult(value = 1).__bool__() is True
    assert ValidationResult(error = ValidationError()).__bool__() is False


# Generated at 2022-06-22 05:39:51.757789
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    assert repr(ValidationResult(value=1)) == "ValidationResult(value=1)"
    assert repr(ValidationResult(error=ValidationError(text='test_text'))) == "ValidationResult(error=ValidationError(text='test_text'))"



# Generated at 2022-06-22 05:39:55.913065
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    assert repr(ValidationResult(error=ValidationError(text='test_message_a'))) ==\
           'ValidationResult(error=ValidationError(text=test_message_a))'
    assert repr(ValidationResult(value='test_value')) == 'ValidationResult(value=test_value)'

# Generated at 2022-06-22 05:40:08.154560
# Unit test for constructor of class ParseError
def test_ParseError():
    assert ParseError(text="hello world") == ParseError(text="hello world")
    assert (
        ParseError(text="hello", code="max_length", key="username")
        == ParseError(text="hello", code="max_length", key="username")
    )
    assert ParseError(
        text="hello world", position=Position(line_no=1, column_no=1, char_index=0)
    ) == ParseError(
        text="hello world",
        position=Position(line_no=1, column_no=1, char_index=0),
    )

    assert ParseError(messages=[]) == ParseError(messages=[])

# Generated at 2022-06-22 05:40:18.307989
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    m1 = Message(
        text='foo',
        code='c1',
        key='k1',
        index=[0, 1, 2],
        position=Position(1, 2, 3),
        start_position=Position(4, 5, 6),
        end_position=Position(7, 8, 9)
    )
    m2 = Message(
        text='foo',
        code='c1',
        key='k1',
        index=[0, 1, 2],
        position=Position(1, 2, 3),
        start_position=Position(4, 5, 6),
        end_position=Position(7, 8, 9)
    )
    assert m1 == m2


# Generated at 2022-06-22 05:40:23.251892
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    error_message = Message(text='text', code='code', key='key')
    error_list = [error_message]
    error = BaseError(messages=error_list)
    for i, x in enumerate(error):
        if i == 0:
            assert x == error_message.key
        else:
            raise AssertionError()


# Generated at 2022-06-22 05:40:33.403372
# Unit test for constructor of class ParseError
def test_ParseError():
    x = ParseError()
    assert isinstance(x, Mapping)
    assert isinstance(x, Exception)
    assert x.__str__() == '{}'
    assert x.__repr__() == 'ParseError({})'
    assert x.__eq__(ParseError([Message('Value is required but not found.', key='', position=Position(1, 1, 0))])) == False
    assert x.__hash__() == -2644448741
    assert x.__len__() == 0
    assert x.__iter__() == '<dict_keyiterator object at 0x7f5d5cb7b0f0>'
    assert x.__getitem__('key') == None

# Generated at 2022-06-22 05:40:37.163177
# Unit test for constructor of class Message
def test_Message():
    Message(text='1 is not a valid value', code='invalid', key='age', index=None, position=(1,2,3), start_position=None, end_position=None)
    assert 1==1


# Generated at 2022-06-22 05:40:40.494108
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    err = BaseError(text='May not have more than 100 characters', code='max_length', key='username')
    assert len(err) == 1
    assert 'username' in err
    assert err['username'] == 'May not have more than 100 characters'


# Generated at 2022-06-22 05:40:47.978323
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    # Pass string and int
    message1 = Message(code = 'max_length', text = 'May not have more than 100 characters', key = 'username')
    assert repr(message1) == "Message(text='May not have more than 100 characters', code='max_length', index=['username'])"

    # Pass string only
    message2 = Message(code = 'max_length', text = 'May not have more than 100 characters')
    assert repr(message2) == "Message(text='May not have more than 100 characters', code='max_length')"

# Generated at 2022-06-22 05:41:57.250193
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    # GIVEN
    error_messages = [
        Message(text='text1', code='code1', key=0),
        Message(text='text2', code='code2', key='key'),
        Message(text='text3', code='code3', key=1, index=[0, 0]),
        Message(text='text4', code='code4', key='key', index=[0, 'key']),
        Message(text='text5', code='code5'),
        Message(text='text6', code='code6', key=0, index=[1]),
    ]
    error = BaseError(messages=error_messages)

# Generated at 2022-06-22 05:42:01.102473
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    pos = Position(1, 2, 3)
    assert pos == Position(1, 2, 3)
    assert not pos == Position(2, 2, 3)
    assert not pos == Position(1, 10, 3)
    assert not pos == Position(1, 2, 4)


# Generated at 2022-06-22 05:42:10.749674
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="A", code="B") == BaseError(text="A", code="B")
    assert BaseError(text="A", code="B") != BaseError(text="A", code="C")
    assert BaseError(text="A", code="B") != BaseError(text="C", code="B")
    assert BaseError(text="A", code="B") == BaseError(messages=[Message(text="A", code="B")])
    assert BaseError(text="A", code="B") != BaseError(messages=[Message(text="A", code="C")])
    assert BaseError(text="A", code="B") != BaseError(messages=[Message(text="C", code="B")])

# Generated at 2022-06-22 05:42:20.608433
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    err = BaseError()
    assert str(err) == "{}"

    err = BaseError(text="hello")
    assert str(err) == "ValidationError(text='hello', code='custom')"

    err = BaseError(text="hello", key="username")
    assert str(err) == "ValidationError(text='hello', code='custom', index=['username'])"

    err = BaseError(text="hello", index=["user", 3, "name"])
    assert str(err) == "ValidationError(text='hello', code='custom', index=['user', 3, 'name'])"

    err = BaseError(
        text="hello", code="max_length", index=["users", 3, "username"]
    )

# Generated at 2022-06-22 05:42:31.798342
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    data = {'username': 'mihai'}
    v1 = ValidationError(text='text', code='code', key='username')
    data1 = {'username': 'maria'}
    v2 = ValidationError(text='text', code='code', key='username')
    assert v1 == v2
    # Test case 1
    assert isinstance(v1, BaseError)
    assert v1.messages()
    assert v1.messages()[0].text == 'text'
    assert v1.messages()[0].code == 'code'
    assert v1.messages()[0].index == ['username']
    assert v2.messages()[0].index == ['username']
    # Test case 2
    assert v1.messages()[0].text == 'text'
    assert v

# Generated at 2022-06-22 05:42:37.841998
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    BaseError()
    BaseError(text="may not be blank", code='required')
    BaseError(text='may only contain letters', code='alphabetic', key='username')
    BaseError(messages=[Message(text='field is required', code='required', key='username'), Message(text='may only contain letters', code='alphabetic', key='username')])



# Generated at 2022-06-22 05:42:47.044833
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    schema = {
        'type': 'object',
        'properties': {
            'first_name': {'type': 'string'},
            'last_name': {'type': 'string'},
            'age': {'type': 'integer'}
        }
    }
    data = {'first_name': 'John', 'last_name': 'Smith', 'age': '31'}
    # Execute the function under test
    error = BaseError(text='Not an integer', code='type', key='age')
    error = schema.validate_or_error(data)
    # Validate the result
    assert len(error) == 3
    assert list(error) == ['first_name', 'last_name', 'age']



# Generated at 2022-06-22 05:42:55.030512
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    message = Message(
        text="This is a test",
        code="test",
        index=[10, "username"],
        start_position=Position(10, 10, 10),
        end_position=Position(20, 20, 20),
    )
    message2 = Message(
        text="This is a test",
        code="test",
        index=[10, "username"],
        start_position=Position(10, 10, 10),
        end_position=Position(20, 20, 20),
    )
    assert message == message2  # type: ignore
    assert hash(message) == hash(message2)

