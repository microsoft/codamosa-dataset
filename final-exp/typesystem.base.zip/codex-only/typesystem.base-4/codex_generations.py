

# Generated at 2022-06-24 10:25:40.221273
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    pos1 = Position(line_no=1, column_no=2, char_index=3)
    pos2 = Position(line_no=1, column_no=2, char_index=3)
    pos3 = Position(line_no=2, column_no=2, char_index=3)
    pos4 = Position(line_no=1, column_no=3, char_index=3)
    pos5 = Position(line_no=1, column_no=2, char_index=4)
    assert pos1 == pos2
    assert pos1 != pos3
    assert pos1 != pos4
    assert pos1 != pos5
    assert pos1 != 1


# Generated at 2022-06-24 10:25:43.074977
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert ValidationResult(value=4)
    assert ValidationResult(value=4) == (4,)
    assert ValidationResult(error=ValidationError(text="2 may be too large"))
    assert ValidationResult(error=ValidationError(text="2 may be too large")) == ValidationResult(error=ValidationError(text="2 may be too large"))



# Generated at 2022-06-24 10:25:46.469450
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    # Test when no input is given
    assert bool(ValidationResult(value=None, error=None)) == False



# Generated at 2022-06-24 10:25:52.191002
# Unit test for constructor of class Message
def test_Message():
    if __name__ == '__main__':
        message = Message(text='May not have more than 100 characters', code='max_length', key='username')
        assert message.text == 'May not have more than 100 characters'
        assert message.code == 'max_length'
        assert message.key == 'username'
        assert message.index == ['username']
        assert message.start_position == None
        assert message.end_position == None
        assert message.position == None


# Generated at 2022-06-24 10:25:58.102672
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    key = "key"
    index = [key]

    message = Message(text="text", code="code", key=key, index=index)
    assert message.__hash__() == Message(text="text", code="code", index=index).__hash__()

    error = BaseError(messages=[message])
    assert error.__hash__() == BaseError(messages=[message]).__hash__()

# Temporary wrapper for BaseError.__init__

# Generated at 2022-06-24 10:26:06.873821
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    # Test messages
    error = BaseError(text="Value is required!")
    assert list(error.messages()) == [
        Message(text="Value is required!", code="custom", index=[])
    ]

    # Test messages with a prefix
    error = BaseError(text="Value is required!")
    assert list(error.messages(add_prefix="key")) == [
        Message(text="Value is required!", code="custom", index=["key"])
    ]

    # Test messages with a index
    error = BaseError(text="Value is required!", index=["key", 1])
    assert list(error.messages()) == [
        Message(text="Value is required!", code="custom", index=["key", 1])
    ]

    # Test messages with a index and a prefix

# Generated at 2022-06-24 10:26:09.889822
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    p = Position(line_no=1, column_no=2, char_index=3)
    assert repr(p) == "Position(line_no=1, column_no=2, char_index=3)"

# Generated at 2022-06-24 10:26:13.138055
# Unit test for constructor of class ParseError
def test_ParseError():
    pe1 = ParseError(text="error1", code='2', key='3', position="4")
    pe2 = ParseError(messages="5")
    print(pe1)
    print(pe2)


# Generated at 2022-06-24 10:26:17.053516
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    error_obj = ValidationError(messages=[
        Message(text="some test message", code="test"),
        Message(text="some other test message", key="someKey"),
        Message(text="another message", index=["someKey", 2])
    ])
    assert error_obj["test"] == "some test message"
    assert error_obj["someKey"] == "some other test message"
    assert error_obj["someKey"][2] == "another message"


# Generated at 2022-06-24 10:26:20.342456
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    error = ValidationError(messages=[Message(text="test", code="test", index=[0])])
    assert len(error) == 1


# Generated at 2022-06-24 10:26:29.628169
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    msg1 = Message(text='hello',code='custom',key=None,index=[],position=Position(1,2,3),start_position=Position(1,2,3),end_position=Position(1,2,3))
    msg2 = Message(text='hello',code='custom',key=None,index=[],position=Position(1,2,3),start_position=Position(1,2,3),end_position=Position(1,2,3))

    assert msg1 == msg2
    assert hash(msg1) == hash(msg2)
    assert hash(msg1) == hash(msg2)


# Generated at 2022-06-24 10:26:30.862141
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    pass  # TODO



# Generated at 2022-06-24 10:26:34.823618
# Unit test for constructor of class Position
def test_Position():
    pos = Position(1,2,3)
    pos2 = Position(4,5,6)
    assert pos.line_no == 1
    assert pos.column_no == 2
    assert pos.char_index == 3
    assert pos == pos
    assert pos != pos2


# Generated at 2022-06-24 10:26:39.676843
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    from . import string, integer
    schema = string & integer
    data = "1234"
    vr = schema.validate_or_error(data)
    assert repr(vr) == f"ValidationResult(value={data!r})"
    data = "abc"
    vr = schema.validate_or_error(data)
    assert repr(vr) == f"ValidationResult(error=ValidationError([Message(text={data!r}, code='custom')]))"
test_ValidationResult___repr__()

# Generated at 2022-06-24 10:26:42.224796
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    error = BaseError(text="myerror", code="mycode")
    assert dict(error) == dict(test_BaseError___iter__.__annotations__)


# Generated at 2022-06-24 10:26:45.377753
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_1 = Message(text="May not have more than 100 characters", code="max_length")
    message_2 = Message(text="May not have more than 100 characters", code="max_length")
    assert message_1 == message_2


# Generated at 2022-06-24 10:26:54.746934
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    error = BaseError(text='baz')
    assert error.messages() == [Message(text='baz')]
    error = BaseError(messages=[Message(text='baz')])
    assert error.messages() == [Message(text='baz')]
    error = BaseError(
        messages=[Message(text='baz', key='foo'), Message(text='bar')],
    )
    assert error.messages() == [
        Message(text='baz', key='foo'), Message(text='bar'),
    ]
    error = BaseError(
        messages=[Message(text='baz', key='foo'), Message(text='bar')],
    )

# Generated at 2022-06-24 10:27:04.547952
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    print(BaseError(text="May not have more than 100 characters", code="max_length"))
    print(BaseError(text="May not have more than 100 characters", code="max_length", key="username"))
    print(BaseError(messages=[Message(text="Not a valid choice", code="invalid_choice", key="color")]))
    print(BaseError(messages=[Message(text="Not a valid choice", code="invalid_choice", index=["color"])]))
    print(BaseError(messages=[Message(text="Not a valid choice", code="invalid_choice", index=["color", 2, "name"])]))
    print(BaseError(messages=[Message(text="Not a valid choice", code="invalid_choice", index=["color", "name"])]))


# Generated at 2022-06-24 10:27:06.229606
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    message = Message(text='', code='', index=[])
    assert message.__hash__() != 0

# Generated at 2022-06-24 10:27:17.088850
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    error = BaseError()
    assert len(error) == 0

    error = BaseError(text="error")
    assert len(error) == 1

    error = BaseError(text="error1", key=0)
    assert len(error) == 1
    assert len(error[0]) == 1
    assert len(error[0][0]) == 1

    error = BaseError(text="error2", key=1)
    assert len(error) == 1
    assert len(error[1]) == 1
    assert len(error[1][1]) == 1

    error = BaseError(text="error1", key=0) + BaseError(text="error2", key=1)
    assert len(error) == 2
    assert len(error[0]) == 1
    assert len(error[0][0]) == 1
    assert len

# Generated at 2022-06-24 10:27:21.602893
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    v = ValidationResult(value = 1)
    assert v.__repr__() == 'ValidationResult(value=1)'

    v = ValidationResult(error = 1)
    assert v.__repr__() == 'ValidationResult(error=1)'

# Generated at 2022-06-24 10:27:28.141749
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    assert repr(Message(
        text='May not have more than 100 characters',
        code='max_length',
        key='username',
        position=Position(
            line_no=1,
            column_no=2,
            char_index=3,
        ),
    )) == "Message(text='May not have more than 100 characters', code='max_length', key='username', position=Position(line_no=1, column_no=2, char_index=3))"


# Generated at 2022-06-24 10:27:38.692336
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    error1 = Message(
        text="text",
        code="code",
        key="key",
        index=["index1"],
        start_position=Position(line_no=1, column_no=1, char_index=1),
        end_position=Position(line_no=2, column_no=2, char_index=2),
    )

    error2 = Message(
        text="text",
        code="code",
        key="key",
        index=["index1"],
        start_position=Position(line_no=1, column_no=1, char_index=1),
        end_position=Position(line_no=2, column_no=2, char_index=2),
    )

    assert error1 == error2

test_Message___eq__()


# Generated at 2022-06-24 10:27:47.426253
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    Error = typing.Union[ValidationError, ParseError]
    assert Error(text="hello") == Error(text="hello")
    assert Error(text="hello") != Error(text="goodbye")
    assert Error(text="hello") != Error(text="hello", code="another_code")
    assert Error(text="hello") != Error(text="hello", key="key")
    assert Error(key="key") == Error(key="key")
    assert Error(key="key") != Error(key="another_key")
    assert Error(key="key") != Error(key="key", text="hello")
    assert Error(key="key") != Error(text="hello")
    assert Error(text="hello", key="key") != Error(key="key")

# Generated at 2022-06-24 10:27:51.777735
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
	expected = ['key1', 'key2']

	actual = BaseError(messages = [Message(text = 'text1', code = 'code1', key = 'key1'), Message(text = 'text2', code = 'code2', key = 'key2')])

	assert expected == list(actual)



# Generated at 2022-06-24 10:27:56.671017
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    assert str(BaseError(text="Hi", key=1)) == "Hi"
    assert str(BaseError(messages=[Message(text="Hi", key=1)])) == "Hi"

    assert (
        str(BaseError(messages=[Message(text="Hi", key=1), Message(text="Hi2", key=2)]))
        == "{'1': 'Hi', '2': 'Hi2'}"
    )

# Generated at 2022-06-24 10:28:06.880014
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    """Returns a list of all the messages of an error.
    
    The messages are all available at this.messages()
    If a key is provided, the key is added to the index of every message
    """
    # Arrange
    e = BaseError(text="message1",code="code1",key="key1",position=Position(1,1,1))
    e.messages()
    # Act
    messages = [Message(text="message1",code="code1",key="key1",position=Position(1,1,1))]
    result = e.messages()
    # Assert
    assert result == messages

    # Act
    e = BaseError(text="message1",code="code1",key="key1",position=Position(1,1,1))

# Generated at 2022-06-24 10:28:16.511823
# Unit test for constructor of class ParseError
def test_ParseError():
    dict_key = ValidationError(text="key 1", code="123", key="key 1")
    dict_key2 = ValidationError(text="key 2", code="234", key="key 2")
    dict_key3 = ValidationError(text="key 3", code="345", key="key 3")
    dict_key4 = ValidationError(text="key 4", code="456", key="key 4")
    dict_key5 = ValidationError(text="key 5", code="567", key="key 5")
    dict_key6 = ValidationError(text="key 6", code="678", key="key 6")
    dict_key7 = ValidationError(text="key 7", code="789", key="key 7")

test_ParseError()


# Generated at 2022-06-24 10:28:22.204694
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    error = BaseError(key="foo", text="bar")
    assert error.messages() == [Message(text="bar", code="custom", index=["foo"])]
    assert error.messages(add_prefix="add_prefix") == [Message(text="bar", code="custom", index=["add_prefix", "foo"])]

# Generated at 2022-06-24 10:28:23.609820
# Unit test for constructor of class Message
def test_Message():
    message = Message(text="text", code="code", key="key", position=Position(1, 2, 3))


# Generated at 2022-06-24 10:28:31.125702
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError(text="Invalid json", code='invalid_json', position=Position(1,1,1))
    assert str(error) == 'Invalid json'
    assert repr(error) == "ParseError(text='Invalid json', code='invalid_json', position=Position(line_no=1, column_no=1, char_index=1))"
    assert error.messages() == [
        Message(text="Invalid json", code='invalid_json', position=Position(1,1,1))
        ]
    assert error.messages(add_prefix=0) == [
        Message(text="Invalid json", code='invalid_json', index=[0], position=Position(1,1,1))
        ]


# Generated at 2022-06-24 10:28:35.781691
# Unit test for constructor of class BaseError
def test_BaseError():
    error = BaseError(text='Bad data')
    assert error.messages() == [Message(text='Bad data')]

    error = BaseError(messages=[Message(text='Bad data', index=[1])])
    assert error.messages() == [Message(text='Bad data', index=[1])]

# Generated at 2022-06-24 10:28:41.206087
# Unit test for constructor of class Message
def test_Message():
    assert Message(text='whatever') == Message(text='whatever')
    assert Message(text='whatever', code='custom', key='a') == Message(text='whatever', code='custom', key='a')
    assert Message(text='whatever', code='custom', index=['a']) == Message(text='whatever', code='custom', index=['a'])


# Generated at 2022-06-24 10:28:43.019316
# Unit test for constructor of class Position
def test_Position():
    with pytest.raises(AssertionError):
        Position(1, 2, -1)



# Generated at 2022-06-24 10:28:50.203262
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    # success
    assert bool(ValidationResult(value=1)) == True
    assert bool(ValidationResult(value=1.0)) == True
    assert bool(ValidationResult(value=True)) == True
    assert bool(ValidationResult(value="xyz")) == True
    assert bool(ValidationResult(value=[])) == True
    assert bool(ValidationResult(value={})) == True

    # failure
    assert bool(ValidationResult(error=ValidationError(text="error"))) == False

# Generated at 2022-06-24 10:28:56.628021
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    error = BaseError(
        text="An error message",
        code="a_code",
        key="key_1",
    )
    assert str(error) == "An error message"
    error = BaseError(
        text="An error message",
        code="a_code",
        key=1,
    )
    assert str(error) == "An error message"
    error = BaseError(messages=[Message(text="Text 1"), Message(text="Text 2")])
    assert str(error) == "{'': 'Text 1'}"
    error = BaseError(
        messages=[
            Message(text="Text 1"),
            Message(text="Text 2"),
            Message(key="key_1", text="Text 3"),
            Message(key="key_1", text="Text 4"),
        ]
    )
   

# Generated at 2022-06-24 10:28:58.626897
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    error = ValidationError(text="test")
    assert len(error) == 1
    assert len(error.messages()) == 1


# Generated at 2022-06-24 10:29:00.470164
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    from typesystem import ValidationResult
    from typesystem import ValidationResult as ValidationResult
    import re
    val = ValidationResult(value={'a': 1, 'b': '2'}, error=None)
    print(val)


# Generated at 2022-06-24 10:29:09.728748
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    e1 = BaseError(text="abc")
    e2 = BaseError(text="abc",code='custom')
    e3 = BaseError(text="abc",key='username')
    e4 = BaseError(text="abc",key='username',code='custom')
    e5 = BaseError(text="abc",position=Position(1,2,3))
    e6 = BaseError(text="abc",key='username',position=Position(1,2,3))
    e7 = BaseError(text="abc",key='username',code='custom',position=Position(1,2,3))
    e8 = BaseError(messages=[Message(text="abc")])
    e9 = BaseError(messages=[Message(text="abc",code='custom')])

# Generated at 2022-06-24 10:29:18.058472
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    from typesystem import Integer
    from typesystem.validators import min_length

    class MySchema(Integer):
        validators = [min_length(2)]

    result = MySchema.validate_or_error(1)
    assert result.value is None
    assert isinstance(result.error, ValidationError)
    assert len(result.error) == 1

    value, error = result
    assert value is None
    assert isinstance(error, ValidationError)
    assert len(error) == 1


# Generated at 2022-06-24 10:29:26.014955
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    assert repr(
        Message(
            text="May not have more than 100 characters",
            code="max_length",
            key="username",
            position=Position(line_no=1, column_no=2, char_index=7),
        )
    ) == "Message(text='May not have more than 100 characters', code='max_length', index=['username'], position=Position(line_no=1, column_no=2, char_index=7))"

# Generated at 2022-06-24 10:29:30.143987
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    result_true=ValidationResult(value=1)
    result_false=ValidationResult(error=ValidationError(text="error"))
    return (result_true and not result_false)

# Generated at 2022-06-24 10:29:40.013847
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    my_err = BaseError(text="My error message")
    assert my_err[0] == "My error message"
    assert my_err[()] == "My error message"
    assert my_err[""] == "My error message"
    assert my_err == {"": "My error message"}
    assert my_err == ["My error message"]
    assert my_err == [{"": "My error message"}]
    assert my_err == {"": {"": "My error message"}}
    assert my_err != ["Some other error"]
    assert my_err != {"": "Some other error"}
    assert my_err != [{"": "Some other error"}]
    assert my_err != {"": {"": "Some other error"}}
    assert my_err != {}
    assert my_err != []

# Generated at 2022-06-24 10:29:45.091221
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(line_no=1, column_no=2, char_index=3) == Position(line_no=1, column_no=2, char_index=3)
    assert Position(line_no=1, column_no=1, char_index=1) != Position(line_no=1, column_no=2, char_index=3)
    pass


# Generated at 2022-06-24 10:29:48.950362
# Unit test for constructor of class ParseError
def test_ParseError():
    p = ParseError()
    assert p
    assert not p.value
    assert p.error
    assert isinstance(p.error, ValidationError)

    p = ParseError(value=1)
    assert p
    assert p.value
    assert not p.error
    assert isinstance(p.value, int)

# Generated at 2022-06-24 10:29:52.499218
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    checker = pytest.checker()
    checker.check_ast(ast.parse(checker.samples['test_ValidationResult___repr__']))


# Generated at 2022-06-24 10:30:01.621954
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=None, error=None)
    for index, value in enumerate(result):
        if index == 0:
            assert value is None
        else:
            assert value is None
    result = ValidationResult(value=42, error=None)
    for index, value in enumerate(result):
        if index == 0:
            assert value == 42
        else:
            assert value is None
    result = ValidationResult(value=None, error=ValidationError())
    for index, value in enumerate(result):
        if index == 0:
            assert value is None
        else:
            assert isinstance(value, ValidationError)
    result = ValidationResult(value=42, error=ValidationError())

# Generated at 2022-06-24 10:30:10.749165
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)

    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)


# Generated at 2022-06-24 10:30:21.724182
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    index = [4, 'foo', '']
    start = Position(1, 2, 3)
    end = Position(4, 5, 6)
    assert (
        Message(
            text='text',
            code='code',
            index=index,
            start_position=start,
            end_position=end,
        ).__repr__()
        == f"Message(text='text', code='code', index={index!r}, start_position={start!r}, end_position={end!r})"
    )

    index = ['foo', '']

# Generated at 2022-06-24 10:30:25.166347
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    assert repr(ValidationResult(value = 7, error = None)) == "ValidationResult(value=7)"
    assert repr(ValidationResult(value = None, error = 7)) == "ValidationResult(error=7)"

# Generated at 2022-06-24 10:30:34.450360
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    error1 = ValidationError(text="test error")

    ret = error1.messages()
    expt_ret = [Message(text="test error", code="custom")]
    if ret != expt_ret: return "Test method messages(1) of class BaseError failed: ret = {}, expt_ret = {}".format(repr(ret), repr(expt_ret))

    error2 = ValidationError(text="test error", code="code_test")

    ret = error2.messages()
    expt_ret = [Message(text="test error", code="code_test")]
    if ret != expt_ret: return "Test method messages(2) of class BaseError failed: ret = {}, expt_ret = {}".format(repr(ret), repr(expt_ret))

    error2 = Val

# Generated at 2022-06-24 10:30:42.641502
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    # Initialize a ValidationError object.
    error = ValidationError(messages=[Message('Invalid email address.', key='email')])
    # Check if the key exists in error
    assert 'email' in error
    # Check if the value of the key is correct
    assert error['email'] == 'Invalid email address.'
    # Check if the key exists in error
    assert 'password' not in error
    # Raise KeyError if key is not in error
    with pytest.raises(KeyError):
        error['password']


# Generated at 2022-06-24 10:30:48.564487
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    my_obj = BaseError(
        text="foo",
        code="bar",
        position=Position(line_no=1, column_no=2, char_index=3),
    )
    assert my_obj == {"" : "foo"}
    assert my_obj[""] == "foo"
    assert my_obj.messages() == [
        Message(
            text="foo",
            code="bar",
            position=Position(line_no=1, column_no=2, char_index=3),
        )
    ]

# Generated at 2022-06-24 10:30:56.110656
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    # Test one message.
    error = BaseError(text="May not have more than 100 characters", code='max_length')
    assert repr(error) == "BaseError(text='May not have more than 100 characters', code='max_length')"
    # Test multiple messages.
    error = BaseError(messages=[Message(text="message1"), Message(text="message2")])
    assert repr(error) == "BaseError([Message(text='message1', code='custom', index=[]), Message(text='message2', code='custom', index=[])])"


# Generated at 2022-06-24 10:31:01.947388
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    assert len(BaseError(text="Some Message")) == 0
    assert len(BaseError(messages=[Message(text="Some Message")])) == 0
    assert len(BaseError(messages=[Message(text="Some Message", key="a")])) == 1
    assert len(BaseError(messages=[Message(text="Some Message", key="a"), Message(text="Some Message", key="b")])) == 2
    assert len(BaseError(messages=[Message(text="Some Message", key="a"), Message(text="Some Message", key="a")])) == 1


# Generated at 2022-06-24 10:31:12.515616
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    # test case 1:
    pos1 = Position(line_no = 2, column_no = 3, char_index = 2)
    pos2 = Position(line_no = 2, column_no = 3, char_index = 2)
    assert pos1.__eq__(pos2) == True

    # test case 2:
    pos1 = Position(line_no = 2, column_no = 3, char_index = 2)
    pos2 = Position(line_no = 3, column_no = 4, char_index = 3)
    assert pos1.__eq__(pos2) == False

    # test case 3:
    pos1 = Position(line_no = 2, column_no = 3, char_index = 2)
    pos2 = None
    assert pos1.__eq__(pos2) == False

    #

# Generated at 2022-06-24 10:31:19.921769
# Unit test for constructor of class ValidationError
def test_ValidationError():
    Text = "Problema"
    Code = "Not valid"
    Key = "Usuario"
    messages = [Message(text=Text, code=Code, key=Key)]
    error = ValidationError(messages=messages)
    assert error["Usuario"] == Text
    assert error.messages()[0] == Message(text=Text, code=Code, index=["Usuario"])
    print(error)

# Generated at 2022-06-24 10:31:28.601770
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    m0 = Message(text = 'May not have more than 100 characters', code = 'max_length', key = 'username')
    m1 = Message(text = 'May not have more than 100 characters', code = 'max_length', key = 'username')
    m2 = Message(text = 'May not have more than 100 characters', code = 'max_length', key = 'password')
    m3 = Message(text = 'May not have more than 100 characters', code = 'min_length', key = 'username')
    assert m0.__eq__(m1) == True and m1.__eq__(m0) == True
    assert m0.__eq__(m2) == False and m2.__eq__(m0) == False

# Generated at 2022-06-24 10:31:34.497579
# Unit test for constructor of class Position
def test_Position():
    a = Position(1,2,3)
    b = Position(1,2,3)
    assert a == b
    b = Position(1,2,4)
    assert a != b
    assert a.line_no == 1
    assert a.column_no == 2
    assert a.char_index == 3



# Generated at 2022-06-24 10:31:38.056753
# Unit test for constructor of class BaseError
def test_BaseError():
    error = BaseError(messages=[Message(text="hello there!")])
    assert error
    assert str(error) == "hello there!"



# Generated at 2022-06-24 10:31:38.531026
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    pass

# Generated at 2022-06-24 10:31:42.763670
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError()
    assert isinstance(error, dict)
    assert not error
    assert error.messages() == []
    assert error.messages(add_prefix=0) == []
    assert repr(error) == "ParseError()"
    assert str(error) == "{}"



# Generated at 2022-06-24 10:31:51.954570
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    messages = [
        Message(text="A", code=None, key="a_key", position=None),
        Message(text="B", code=None, key=None, index=["first", "second", "third"], position=None),
        Message(text="C", code=None, key=None, index=["first", "second", "third", "fourth"], position=None),
        Message(text="D", code=None, key=None, index=["first", "second", "third", "fourth", "fifth"], position=None),
        Message(text="E", code=None, key=None, index=["first", "second", "third", "fourth", "fifth", "sixth"], position=None),
    ]
    test_error = BaseError(messages=messages)

# Generated at 2022-06-24 10:32:02.941922
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    from typesystem import _error
    b = _error.BaseError(text='This is no error')
    assert repr(b) == "BaseError(text='This is no error', code='custom')"
    b = _error.BaseError(text='This is no error', code='JSON_SYNTAX')
    assert repr(b) == "BaseError(text='This is no error', code='JSON_SYNTAX')"
    b = _error.BaseError(text='This is no error', code='JSON_SYNTAX', key='username')
    assert repr(b) == "BaseError(text='This is no error', code='JSON_SYNTAX', key='username')"

# Generated at 2022-06-24 10:32:14.223151
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    # BaseError with multiple error messages
    error1 = ValidationError(
        messages=[Message(text="first error message", code="code1"), Message(text="second error message", code="code2")]
    )
    error2 = ValidationError(
        messages=[Message(text="first error message", code="code1"), Message(text="second error message", code="code2")]
    )
    hash_error1 = hash(error1)
    hash_error2 = hash(error2)
    assert hash_error1 is not None
    assert hash_error2 is not None
    assert hash_error1 == hash_error2

    # BaseError with single error message
    error1 = ValidationError(messages=[Message(text="error message", code="code")])

# Generated at 2022-06-24 10:32:19.262805
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    x = ValidationResult(error='error')

# Generated at 2022-06-24 10:32:23.897720
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    p1 = Position(1, 2, 3)
    p2 = Position(4, 5, 6)
    print(Message(text='a', position=p1))
    print(Message(text='a', start_position=p1, end_position=p2))

if __name__ == '__main__':
    test_Message___repr__()



# Generated at 2022-06-24 10:32:26.581890
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    x = Position(9, 10, 11)
    assert repr(x) == "Position(line_no=9, column_no=10, char_index=11)"


# Generated at 2022-06-24 10:32:31.134807
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    error = BaseError(
        text='Value must be less than or equal to 10',
        code='max_value',
        key='users',
        position=Position(line_no=5, column_no=3, char_index=40),
    )
    assert len(error) == 1
    assert len(error['users']) == 1
    assert error['users']['max_value'] == 'Value must be less than or equal to 10'


# Generated at 2022-06-24 10:32:33.428650
# Unit test for constructor of class Position
def test_Position():
    position = Position(line_no=1, column_no=2, char_index=3)
    assert position.line_no == 1
    assert position.column_no == 2
    assert position.char_index == 3


# Generated at 2022-06-24 10:32:43.022909
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    position = Position(0, 0, 0)
    a = Position(line_no=0, column_no=0, char_index=0)
    b = Position(line_no=1, column_no=0, char_index=0)
    c = Position(line_no=0, column_no=1, char_index=0)
    d = Position(line_no=0, column_no=0, char_index=1)

    assert position.__eq__(a) is True
    assert position.__eq__(b) is False
    assert position.__eq__(c) is False
    assert position.__eq__(d) is False


# Generated at 2022-06-24 10:32:49.862846
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    class MyBaseError(BaseError):
        pass
    assert len(MyBaseError(text="msg1")) == 1
    assert len(MyBaseError(text="msg1 msg2")) == 1
    assert len(MyBaseError(text="msg1", key="key1")) == 1
    assert len(MyBaseError(text="msg1", key="key1", position=Position(2,3,4))) == 1
    assert len(MyBaseError(text="msg1", key="key1", position=Position(2,3,4),
                                     messages=[Message(text="msg1", code="code1", key="key1", index=["index1"],
                                                       position=Position(2,3,4))])) == 1

# Generated at 2022-06-24 10:32:58.859869
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    err1 = ValidationError(text = 'error message', code = 'code')
    err2 = ValidationError(text = 'error message', code = 'code')
    assert err1 == err2
    err3 = ValidationError(text = 'error message', code = 'code2')
    assert not (err1 == err3)
    err4 = ValidationError(text = 'error message', code = 'code', key = 'key')
    assert not (err1 == err4)
    err5 = ValidationError(text = 'error message2', code = 'code')
    assert not (err1 == err5)
    err6 = ValidationError(messages=[Message(text = 'error message', code = 'code'), Message(text = 'error message2', code = 'code')])
    assert not (err1 == err6)


# Generated at 2022-06-24 10:33:00.710537
# Unit test for constructor of class ValidationError
def test_ValidationError():
    error = ValidationError(text="test", code="test_code", key="test_key")
    print(error)

# Generated at 2022-06-24 10:33:06.070695
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    line_no = 0
    column_no = 0
    char_index = 0
    position_1 = Position(line_no, column_no, char_index)
    position_2 = Position(line_no, column_no, char_index)
    expected = True
    actual = position_1 == position_2
    assert actual == expected


# Generated at 2022-06-24 10:33:16.599849
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    from typesystem.types import StringType, IntegerType
    from typesystem.components import OneOf
    from typesystem.components import Object
    class UserType(OneOf):
        def types(self):
            return {
                'admin': Object(
                    properties={
                        'type': StringType(enum=['admin']),
                        'username': StringType(max_length=10),
                        'password': StringType(max_length=10),
                    }
                ),
                'user': Object(
                    properties={
                        'type': StringType(enum=['user']),
                        'username': StringType(max_length=10),
                        'password': StringType(max_length=10),
                        'age': IntegerType(minimum=0, maximum=100)
                    }
                )
            }

# Generated at 2022-06-24 10:33:25.601562
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError()
    ParseError(text="foo")
    ParseError(messages=[Message(text="foo")])
    ParseError(text="foo", code="custom", key="foo")

    with pytest.raises(AssertionError):
        ParseError(text="foo", code="custom", key="foo", messages=[Message(text="foo")])

    ParseError(text="foo", code="custom", key="foo", position=Position(2, 2, 2))

    with pytest.raises(AssertionError):
        ParseError(text="foo", code="custom", key="foo", start_position=Position(2, 2, 2))


# Generated at 2022-06-24 10:33:31.823306
# Unit test for constructor of class ValidationError
def test_ValidationError():
    print("Testing constructor of class ValidationError")
    assert ValidationError(text = "The value is wrong")
    assert ValidationError(text = "The value is wrong", code = "wrong_value")
    assert ValidationError(text = "The value is wrong", code = "wrong_value", key = "value")
    assert ValidationError(text = "The value is wrong", code = "wrong_value", key = "value", position = Position(11, 0, 11))
    assert ValidationError(messages = [Message(text = "The value is wrong", code = "wrong_value")])
    print("Test passed")

# Generated at 2022-06-24 10:33:34.716878
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    # No `__getitem__` method in [Python 3.6]: typing.Dict[typing.Union[int, str], typing.Union[str, dict]]
    # Pass
    pass


# Generated at 2022-06-24 10:33:38.829691
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    # Error
    result = ValidationResult(error=ParseError())
    assert result.value is None
    assert result.error is not None
    assert isinstance(result.error, ParseError)

    # Value
    result = ValidationResult(value=123)
    assert result.value is not None
    assert result.error is None
    assert result.value == 123

# Generated at 2022-06-24 10:33:40.997270
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    message = Message(text = 'May not have more than 100 characters', code = 'max_length')
    assert hash(message) != None

# Generated at 2022-06-24 10:33:47.112279
# Unit test for constructor of class ParseError
def test_ParseError():
    # Instantiated as a ParseError with a single error message.
    error = ParseError(text = "Invalid JSON")
    assert error.text == "Invalid JSON"

    # Instantiated as a ValidationError with multiple error messages.
    error = ValidationError(messages = [])
    assert error.messages() == []



# Generated at 2022-06-24 10:33:56.965060
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(
        text="a", code="b", index=[1, 2, 3, 4], position=Position(1, 2, 3)
    )
    message2 = Message(
        text="a", code="b", index=[1, 2, 3, 4], position=Position(1, 2, 3)
    )
    message3 = Message(
        text="a", code="c", index=[1, 2, 3, 4], position=Position(1, 2, 3)
    )
    message4 = Message(
        text="a", code="b", index=[2, 3, 4], position=Position(1, 2, 3)
    )
    message5 = Message(
        text="a", code="b", index=[1, 2, 3, 4], position=Position(2, 3, 4)
    )
   

# Generated at 2022-06-24 10:33:58.662520
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError(
        text="Invalid JSON", code="invalid_json", key="mapping", position=Position(1, 1, 2)
    )



# Generated at 2022-06-24 10:34:02.725215
# Unit test for constructor of class Position
def test_Position():
    class_name = __class__.__name__
    print(f"\n{class_name}")

    def assert_eq(actual, expected):
        print(f"{actual!r} == {expected!r}")
    
    pos = Position(line_no=3, column_no=2, char_index=1)
    assert_eq(pos.line_no, 3)
    assert_eq(pos.column_no, 2)
    assert_eq(pos.char_index, 1)


# Generated at 2022-06-24 10:34:11.936991
# Unit test for constructor of class Position
def test_Position():
    # Test different argument
    assert Position(line_no=1, column_no=2, char_index=3) == Position(
        line_no=1, column_no=3, char_index=3
    )
    # Test equal argument
    assert (
        Position(line_no=1, column_no=2, char_index=3)
        == Position(line_no=1, column_no=2, char_index=3)
    )
    # Test different argument
    assert Position(line_no=1, column_no=2, char_index=3) != Position(
        line_no=4, column_no=3, char_index=3
    )
    # Test __repr__

# Generated at 2022-06-24 10:34:16.903113
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Check __eq__ returns True for objects for which __hash__ returns the same value 
    message1 = Message(text = "error message", code = "code", key = "key")
    message2 = Message(text = "error message", code = "code", key = "key")
    error1 = ValidationError(messages = [message1])
    error2 = ValidationError(messages = [message2])
    assert error1.__eq__(error2) == True
    assert error1.__hash__() == error2.__hash__()

    # Check __eq__ returns False for objects with different __eq__ values
    error1 = ValidationError(messages = [message1])
    error2 = ValidationError(messages = [message2], code = "code2")
    assert error1.__eq__(error2)

# Generated at 2022-06-24 10:34:27.955946
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    schema = types.String(minimum_length=1, maximum_length=32)
    thing = "thing"
    value, error = schema.validate_or_error(thing)

    assert value == thing
    assert error is None

    val_res = ValidationResult(value=value, error=error)
    assert val_res.value == thing
    assert val_res.error is None

    iter_val = iter(val_res)
    assert next(iter_val) == thing
    assert next(iter_val) is None

    schema = types.String(minimum_length=7, maximum_length=8)
    thing = "thing"
    value, error = schema.validate_or_error(thing)


# Generated at 2022-06-24 10:34:33.541209
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    message = Message(text='text', code='code', index=[1, 2], start_position=Position(1, 1, 1), end_position=Position(2,2,2))
    result = message.__repr__()
    assert result == "Message(text='text', code='code', index=[1, 2], start_position=Position(line_no=1, column_no=1, char_index=1), end_position=Position(line_no=2, column_no=2, char_index=2))"


# Generated at 2022-06-24 10:34:34.678150
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    ...


# Generated at 2022-06-24 10:34:36.412226
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    # ToDo: Nothing to Test
    return True


# Generated at 2022-06-24 10:34:41.842792
# Unit test for method __len__ of class BaseError

# Generated at 2022-06-24 10:34:43.815954
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    value = Message(text='may not have more than 100 characters', code='max_length', key='username')
    expected = "Message(text='may not have more than 100 characters', code='max_length', index=['username'])"
    assert repr(value) == expected


# Generated at 2022-06-24 10:34:51.784931
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    assert hash(BaseError()) == hash(BaseError())
    assert hash(BaseError(text="hello")) == hash(BaseError(text="hello"))
    assert hash(BaseError(text="world")) != hash(BaseError(text="worldd"))
    assert hash(BaseError(text="world")) != hash(BaseError(text="world", code="custom"))
    assert hash(BaseError(text="world", code="custom")) == hash(BaseError(text="world", code="custom"))

# Generated at 2022-06-24 10:34:57.756539
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():

    class Schema:
        id: str
        title: str

    data = {
        'id': 'some-id', 
        'title': 'some-title', 
    }

    result, error = Schema.validate_or_error(data)

    assert repr(result) == 'ValidationResult(value={\'id\': \'some-id\', \'title\': \'some-title\'})'
    assert repr(error) == 'ValidationResult(error=ValidationError("Must have only allowed keys"))'

# Generated at 2022-06-24 10:35:01.802547
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    result = ValidationResult(value=1)
    assert repr(result) == "ValidationResult(value=1)"

    result = ValidationResult(error=ValidationError())
    assert repr(result) == "ValidationResult(error=ValidationError())"




# Generated at 2022-06-24 10:35:04.187228
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    parameter0 = ""
    parameter1 = ""
    parameter2 = ""

    expected0 = ""
    expected1 = ""
    expected2 = ""

    result0 = parameter0
    result1 = parameter1
    result2 = parameter2

    assert result0 == expected0
    assert result1 == expected1
    assert result2 == expected2



# Generated at 2022-06-24 10:35:11.411930
# Unit test for constructor of class ValidationError
def test_ValidationError():
    # test for a single message
    error = ValidationError(text="The value is not a int.", key="age")
    assert error._messages == [Message(text="The value is not a int.", key="age")]
    assert error._message_dict == {"age": "The value is not a int."}
    assert message in error
    assert key in error
    # test for multiple messages
    error = ValidationError(messages=[Message(text="The value is not a int.", key="age"),
                                      Message(text="The value is not a str.", key="name")])
    assert len(error) == 2
    assert "age" in error
    assert "name" in error

# Generated at 2022-06-24 10:35:21.648617
# Unit test for constructor of class ValidationError
def test_ValidationError():
    error = ValidationError(
        text="Invalid value", key="a.b.c", code="invalid"
    )

    assert error.messages() == [
        Message(text="Invalid value", code="invalid", index=["a", "b", "c"])
    ]
    assert error == ValidationError(
        messages=[Message(text="Invalid value", code="invalid", index=["a", "b", "c"])]
    )
    assert error == ValidationError(text="Invalid value", code="invalid", key="a.b.c")
    assert error != ValidationError(text="Invalid value", code="invalid", key="a.b.x")


# Generated at 2022-06-24 10:35:28.237752
# Unit test for constructor of class Message
def test_Message():
    message = Message(text='a', code='b')
    assert message.text == 'a'
    assert message.code == 'b'
    assert message.key == None
    assert message.position == None

    message = Message(text='a', code='b')
    assert message.text == 'a'
    assert message.code == 'b'
    assert message.key == None
    assert message.position == None



# Generated at 2022-06-24 10:35:29.791989
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    assert bool(ValidationResult(value=1))
    assert not bool(ValidationResult(error=ValidationError()))

# Generated at 2022-06-24 10:35:30.668796
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    assert hash(Message(text="Some text"))

# Generated at 2022-06-24 10:35:33.731288
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    pos_1 = Position(line_no=1, column_no=3, char_index=8)
    pos_2 = Position(line_no=1, column_no=3, char_index=8)
    assert (pos_1 == pos_2) == True
