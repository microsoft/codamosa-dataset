

# Generated at 2022-06-24 10:25:35.083705
# Unit test for constructor of class ParseError
def test_ParseError():
    parse_error = ParseError(text="X", code="Y", key="Z")
    assert parse_error.text == "X"
    assert parse_error.code == "Y"
    assert parse_error.key == "Z"


# Generated at 2022-06-24 10:25:39.416189
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    assert repr(ValidationError(text='Must be a string')) == "ValidationError(text='Must be a string', code='custom')"
    assert repr(ValidationError(messages=[
        Message(text='Must be a string', code='custom')])) == "ValidationError([Message(text='Must be a string', code='custom', index=[])])"


# Generated at 2022-06-24 10:25:44.904286
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    error = BaseError(text='abc', key='abc', code='abc')
    assert len(error) == 1
    error = BaseError(messages=["a", "b", "c"])
    assert len(error) == len(['a', 'b', 'c'])



# Generated at 2022-06-24 10:25:49.725274
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    args = {
        "line_no": 1,
        "column_no": 2,
        "char_index": 3,
    }
    assert Position(**args) == Position(**args)
    args["line_no"] = 4
    assert Position(**args) != Position(**args)


# Generated at 2022-06-24 10:25:59.839828
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    msg1 = Message(text="Text 1")
    assert msg1.__repr__() == "Message(text='Text 1', code='custom')"

    msg2 = Message(text="Text 2", code="CODE")
    assert msg2.__repr__() == "Message(text='Text 2', code='CODE')"

    msg3 = Message(text="Text 3", key="KEY")
    assert msg3.__repr__() == "Message(text='Text 3', code='custom', index=['KEY'])"

    msg4 = Message(text="Text 4", index=["INDEX1", "INDEX2"])
    assert msg4.__repr__() == "Message(text='Text 4', code='custom', index=['INDEX1', 'INDEX2'])"


# Generated at 2022-06-24 10:26:09.422462
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    vr = ValidationResult(value = 1)
    vr2 = ValidationResult(error = ValidationError())
    assert vr.value == 1
    assert bool(vr) is True
    assert vr.error is None
    assert vr2.value is None
    assert bool(vr2) is False
    assert isinstance(vr2.error, ValidationError)
    assert repr(vr) == "ValidationResult(value=1)"
    assert repr(vr2) == "ValidationResult(error=ValidationError({}))"
    vr, vr2 = ValidationResult(1), ValidationResult(error = ValidationError())
    assert vr == 1
    assert vr2 == False

# Generated at 2022-06-24 10:26:10.096858
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    pass

# Generated at 2022-06-24 10:26:13.595518
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    _error = BaseError(
        text="Valor minimo permitido é 5",
        code="min_value",
        key="nome",
        position=Position(line_no=0, column_no=0, char_index=0),
    )



# Generated at 2022-06-24 10:26:16.090629
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    is_iter = iter(ValidationResult())
    assert next(is_iter) is None
    assert next(is_iter) is None
    assert next(is_iter) is None
    with pytest.raises(StopIteration):
        next(is_iter)


# Generated at 2022-06-24 10:26:27.771566
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    import pytest
    from pprint import pformat, pprint
    import sys
    import json
    from pathlib import Path

    sys.path.append(Path(__file__).parent.parent.parent)
    from typesystem import BaseError
    from typesystem import Message
    from typesystem import ValidationError

    #*************
    # class BaseError
    #*************

    error = BaseError() # Text and code are not specified in the constructor
    error_expected = BaseError(text = "Text and code are not specified", code = "custom")
    assert error == error_expected
    assert hash(error) == hash(error_expected)

    error = BaseError(text = "Text is specified") # code is not specified
    error_expected = BaseError(text = "Text is specified", code = "custom")
    assert error == error

# Generated at 2022-06-24 10:26:36.867058
# Unit test for constructor of class Position
def test_Position():
    pos = Position(2, 4, 13)
    assert pos.line_no == 2
    assert pos.column_no == 4
    assert pos.char_index == 13
    assert pos.__dict__ == { 
        'line_no': 2,
        'column_no': 4,
        'char_index': 13
    }
    # Testing equality
    assert pos == Position(2, 4, 13)
    assert pos != Position(3, 4, 13)
    assert pos != Position(2, 5, 13)
    assert pos != Position(2, 4, 14)
    # Testing repr
    assert pos.__repr__() == 'Position(line_no=2, column_no=4, char_index=13)'


# Generated at 2022-06-24 10:26:41.290018
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    validation_result = ValidationResult(value=None, error=None)
    assert validation_result.__bool__() is True
    validation_result = ValidationResult(value="hello world", error=None)
    assert validation_result.__bool__() is True
    validation_result = ValidationResult(value=None, error=ValidationError("error message"))
    assert validation_result.__bool__() is False


# Generated at 2022-06-24 10:26:44.345467
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    test_message = Message(text="May not have more than 100 characters", code=None, key=None, index=None, position=None, start_position=None, end_position=None)
    assert test_message.__repr__() == "Message(text='May not have more than 100 characters', code=None, index=None, position=None, start_position=None, end_position=None)"


# Generated at 2022-06-24 10:26:49.353466
# Unit test for constructor of class Position
def test_Position():
    pos = Position(0, 0, 0)
    pos1 = Position(0, 0, 0)
    pos2 = Position(0, 1, 1)
    pos3 = Position(1, 0, 1)
    pos4 = Position(1, 1, 2)

    print("¤¤¤ ¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤  TEST_Position")
    print("test 1")
    print("pos == pos1 :", pos == pos1)
    print("test 2")
    print("pos == pos2 :", pos == pos2)
    print("test 3")

# Generated at 2022-06-24 10:26:54.481730
# Unit test for constructor of class ValidationError
def test_ValidationError():

    error = ValidationError(code='max_length', key='username', text='username is too long', position=Position(1,2,3))
    assert error.index == ['username']
    assert error.start_position == Position(1,2,3) and error.end_position == Position(1,2,3)


# Generated at 2022-06-24 10:27:04.421416
# Unit test for constructor of class BaseError
def test_BaseError():
    class_name = 'BaseError'
    ErrorInstance = BaseError()
    # Checks if BaseError() is an instance of BaseError
    assert isinstance(BaseError(), BaseError)
    # Checks if BaseError() is an instance of Mapping
    assert isinstance(BaseError(), Mapping)
    # Checks for __init__
    assert getattr(ErrorInstance, '__init__')
    assert getattr(ErrorInstance, '_messages')
    assert getattr(ErrorInstance, '_message_dict')
    # Checks for __eq__
    assert getattr(ErrorInstance, '__eq__')
    # Checks for __hash__
    assert getattr(ErrorInstance, '__hash__')
    # Checks for __iter__
    assert getattr(ErrorInstance, '__iter__')
    # Checks for __len__
    assert getattr

# Generated at 2022-06-24 10:27:07.245636
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    obj = BaseError(text='test__text', code='test__code', key='test__key', position=None, messages=None)
    other_obj = {}

    assert not obj == other_obj

# Generated at 2022-06-24 10:27:12.087953
# Unit test for constructor of class Message
def test_Message():
    code = "test_Message"
    text = "Testing Message constructor"
    index = [1, 2, 3]
    line = 1
    column = 2
    position = Position(line, column, line*10 + column)

    message = Message(text=text, code=code, index=index, position=position)

    assert message.code == code
    assert message.text == text
    assert message.index == index
    assert message.start_position == position
    assert message.end_position == position



# Generated at 2022-06-24 10:27:12.579193
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    pass

# Generated at 2022-06-24 10:27:22.105293
# Unit test for constructor of class Message
def test_Message():
    # Test one
    position = Position(1, 1, 1)
    message = Message(text = "Title needs to be less than 50 characters", code="max_length", key="title",
                      start_position=position, end_position=position)
    assert message.text == "Title needs to be less than 50 characters"
    assert message.code == "max_length"
    assert message.index == ["title"]
    assert message.start_position == position
    assert message.end_position == position

    # Test two
    message = Message(text="Title needs to be less than 50 characters", code="max_length", key="title",
                      position=position)
    assert message.text == "Title needs to be less than 50 characters"
    assert message.code == "max_length"
    assert message.index == ["title"]

# Generated at 2022-06-24 10:27:31.815287
# Unit test for constructor of class ValidationError
def test_ValidationError():
    error = ValidationError(
        text='name must be present', 
        code='missing_field', 
        key='name',
    )
    assert error
    message = error.messages()
    assert message == [Message(text='name must be present', code='missing_field', index=['name'])]
    assert message[0] == Message(text='name must be present', code='missing_field', index=['name'])
    assert message[0].text == "name must be present"
    assert message[0].code == "missing_field"
    assert message[0].index == ['name']

    error = ValidationError(messages=[Message(text='name must be present', code='missing_field')])
    assert error
    message = error.messages()

# Generated at 2022-06-24 10:27:41.552933
# Unit test for constructor of class BaseError
def test_BaseError():
    # Instantiation with a single error message
    base_error = BaseError(text="error message", key="key")
    assert base_error["key"] == "error message"

    # Instantiation with a list of error messages
    error_list: typing.List[Message] = []
    error_list.append(Message(text="error message 1", key="key 1"))
    error_list.append(Message(text="error message 2", key="key 2"))
    base_error = BaseError(messages=error_list)
    assert base_error["key 1"] == "error message 1"
    assert base_error["key 2"] == "error message 2"


# Generated at 2022-06-24 10:27:47.118017
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Empty BaseError test
    error1 = BaseError()
    error2 = BaseError()
    assert error1 == error2
    # Singular BaseError test
    error3 = BaseError(text="1")
    error4 = BaseError(text="1")
    assert error3 == error4
    # Double BaseError test
    error4 = BaseError(text="1", code="2")
    assert not error3 == error4
    error4 = BaseError(text="1", key="2")
    assert not error3 == error4
    # Non equal BaseError test
    error5 = BaseError(text="1", code="2")
    assert not error3 == error5


# Generated at 2022-06-24 10:27:48.737779
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    """
    test method ValidationResult.__iter__()
    """
    print(ValidationResult(error=ValidationError(text="failed")))


# Generated at 2022-06-24 10:27:57.607637
# Unit test for method __eq__ of class BaseError

# Generated at 2022-06-24 10:27:59.999821
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    from typesystem.exceptions import BaseError
    value, error = BaseError().__repr__()
    assert value == 'BaseError()'

# Generated at 2022-06-24 10:28:02.327571
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    message = Message(text='', code=None, index=[])
    assert message.__hash__() == hash(('custom', ()))

# Generated at 2022-06-24 10:28:12.319397
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    error = ValidationError(text="Invalid email address.")
    assert len(error) == 1

    error = ParseError(
        text="Could not parse json. Expecting value: line 1 column 1 (char 0)",
        code="parse_error",
    )
    assert len(error) == 1

    error = ValidationError(error=error)
    assert len(error) == 1

    error = ValidationError(
        [
            ValidationError(text="Invalid email address."),
            ValidationError(
                text="Invalid zip code."
            ),  # yapf: disable
            ValidationError(
                text="Invalid date of birth."
            ),  # yapf: disable
        ]
    )
    assert len(error) == 3


# Generated at 2022-06-24 10:28:20.046664
# Unit test for constructor of class BaseError
def test_BaseError():
    
    messages = [
        Message(text="text 1", code="code 1", key="key 1", position=Position),
        Message(text="text 2", code="code 2", key="key 2", position=Position)
    ]
    message_dict={
        "key 1":"text 1",
        "key 2":"text 2"
    }
    error=BaseError(messages=messages)
    assert error._messages == messages
    assert error._message_dict == message_dict



# Generated at 2022-06-24 10:28:29.806633
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    import copy

    error1 = BaseError(text="error text")
    error2 = BaseError(text="error text")
    assert error1 == error2

    error1 = BaseError(messages=[Message(text="error text")])
    error2 = BaseError(messages=[Message(text="error text")])
    assert error1 == error2

    error1 = BaseError(messages=copy.copy(error2.messages()))
    assert error1 == error2

    error1 = BaseError(messages=[
        Message(text="error text 1"),
        Message(text="error text 2", key=1),
        Message(text="error text 3", key="key")
    ])

# Generated at 2022-06-24 10:28:36.085201
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    message = Message(text="May not have more than 100 characters", code="max_length", index=["foo"], position=Position(line_no=123, column_no=321, char_index=1))
    print(message)
    assert str(message) == "Message(text='May not have more than 100 characters', code='max_length', index=['foo'], position=Position(line_no=123, column_no=321, char_index=1))"


# Generated at 2022-06-24 10:28:44.395279
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError(
        key="username",
        position=Position(
            line_no=3, column_no=4, char_index=12
        ),
    )
    message = error.messages()[0]
    assert message.index == ["username"]
    assert message.start_position == Position(line_no=3, column_no=4, char_index=12)
    assert message.end_position == Position(line_no=3, column_no=4, char_index=12)
    assert error[0] == "username"
    assert error[1] == message.text


# Generated at 2022-06-24 10:28:51.212341
# Unit test for constructor of class Message
def test_Message():
    assert Message(text="abc") == Message(text="abc")
    assert Message(text="abc") != Message(text="ab")
    assert Message(text="abc") != Message(text="abc", code="code")
    assert Message(text="abc") != Message(text="abc", key=0)
    assert Message(text="abc") != Message(text="abc", index=[0])
    assert Message(text="abc") != Message(text="abc", key=0, index=[0])
    assert Message(text="abc") != Message(text="abc", position=Position(0, 1, 2))
    assert Message(text="abc") != Message(text="abc", start_position=Position(0, 1, 2))
    assert Message(text="abc") != Message(text="abc", end_position=Position(0, 1, 2))
   

# Generated at 2022-06-24 10:28:58.469677
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # BaseError with a single error message
    error1 = BaseError(text="May not have more than 100 characters", code="max_length", key="username")
    error2 = BaseError(text="May not have more than 100 characters", code="max_length", key="username")
    assert error1 == error2
    assert hash(error1) == hash(error2)

    # BaseError with a single error message
    error3 = BaseError(text="May not have more than 100 characters", code="max_length", key="email")
    assert error1 != error3
    assert hash(error1) != hash(error3)

    # BaseError with multiple error messages

# Generated at 2022-06-24 10:29:03.774954
# Unit test for constructor of class BaseError
def test_BaseError():
    e = BaseError(text="message", code="code", key=1)
    assert e._messages == [Message(text="message", code="code", key=1)]

    e = BaseError(messages=[Message(text="message1"), Message(text="message2")])
    assert e._messages == [Message(text="message1"), Message(text="message2")]


# Generated at 2022-06-24 10:29:12.049733
# Unit test for constructor of class ParseError
def test_ParseError():
    assert repr(ParseError()) == "ParseError(messages=[])"

    error = ParseError(
        text="Expected an integer, got 'ten'",
        code="invalid_value",
        key="age",
        position=Position(line_no=2, column_no=3, char_index=23),
    )
    expected_error = "ParseError(text='Expected an integer, got \\'ten\\'', code='invalid_value', key='age', position=Position(line_no=2, column_no=3, char_index=23))"
    assert repr(error) == expected_error


# Generated at 2022-06-24 10:29:22.025864
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    import json
    class_name = 'BaseError'
    text = 'Invalid data in "users": [1, 2, 3]'
    code = 'invalid_data'
    key = 'users'
    position = Position(line_no=1, column_no=6, char_index=5)
    messages = [Message(text=text, code=code, key=key, position=position)]
    json_repr = repr(BaseError(text=text, code=code, key=key, position=position))
    assert json.loads(json_repr) == json.loads('{"text":"Invalid data in \"users\": [1, 2, 3]", "code": "invalid_data", "key": "users", "position": {"line_no": 1, "column_no": 6, "char_index": 5}}')
   

# Generated at 2022-06-24 10:29:26.486747
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():

    """Unit test for method __repr__ of class BaseError"""

    BaseError()
    BaseError(text='text')
    BaseError(text='text', key='key')
    BaseError(text='text', key=0)
    BaseError(text='text', key='key', code='code')
    BaseError(text='text', key=0, code='code')
    BaseError(text='text', key='key', code='code', position=Position(0, 0, 0))
    BaseError(text='text', key=0, code='code', position=Position(0, 0, 0))
    BaseError(messages=[Message(text='text', key='key')])
    BaseError(messages=[Message(text='text', key=0)])

# Generated at 2022-06-24 10:29:30.252160
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    d = ValidationResult(value = {'a':1})
    assert d.value == {'a':1}
    assert d.error == None


# Generated at 2022-06-24 10:29:33.441765
# Unit test for constructor of class Position
def test_Position():
    position = Position(line_no = 1, column_no = 2, char_index = 3)
    assert position.line_no == 1 and position.column_no == 2 and position.char_index == 3



# Generated at 2022-06-24 10:29:34.673787
# Unit test for constructor of class Position
def test_Position():
    Position(3,3,3)


# Generated at 2022-06-24 10:29:42.565546
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    # Test that hash is unique for different instances of class Message
    assert hash(Message(text='text', code='code', key='key', position=Position(line_no=1, column_no=1, char_index=1))) != hash(
        Message(text='text', code='code', key='key'))
    # Test that hash is unique for different instances of class Message
    assert hash(Message(text='text', code='code', key='key')) != hash(
        Message(text='text', code='code'))
    # Test that hash is unique for different instances of class Message
    assert hash(Message(text='text', code='code')) != hash(Message(text='text'))
    # Test that hash is unique for different instances of class Message

# Generated at 2022-06-24 10:29:50.994791
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    base = BaseError(messages=[Message(text="a", index=[1]), Message(text="b", index=[2])])
    assert hash(base) == hash(BaseError(messages=[Message(text="a", index=[1]), Message(text="b", index=[2])]))
    assert hash(base) != hash(BaseError(messages=[Message(text="b", index=[2]), Message(text="a", index=[1])]))
    assert hash(base) != hash(BaseError(messages=[Message(text="a", index=[1]), Message(text="a", index=[2])]))
    assert hash(base) != hash(BaseError(messages=[Message(text="b", index=[1]), Message(text="b", index=[2])]))

# Generated at 2022-06-24 10:29:51.853059
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    result = ValidationResult()
    assert bool(result) is True


# Generated at 2022-06-24 10:29:53.327599
# Unit test for constructor of class ValidationError
def test_ValidationError():
    vError = ValidationError()
    assert vError is not None


# Generated at 2022-06-24 10:29:55.994086
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    result1 = ValidationResult(value="a")
    assert bool(result1) == True

    result2 = ValidationResult(error="b")
    assert bool(result2) == False

# Generated at 2022-06-24 10:30:07.746809
# Unit test for constructor of class ValidationError
def test_ValidationError():

    error = ValidationError(text="Must contain at least 50 characters",
                            code="min_length",
                            key="username")

    assert error.code == "min_length"
    assert error.key == "username"
    assert error.text == "Must contain at least 50 characters"
    assert repr(error) == "ValidationError(text='Must contain at least 50 characters', code='min_length')"

    error2 = ValidationError(text="Must contain at least 50 characters",
                             code="min_length",
                             key="username")

    assert error == error2
    assert hash(error) == hash(error2)

    error3 = ValidationError(text="Must contain at least 50 characters",
                             code="min_length",
                             key="password")

    assert error != error3

# Generated at 2022-06-24 10:30:10.813057
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    _message_1 = Message(text='',code='',key='',index='',start_position='',end_position='')
    _message_2 = Message(text='',code='',key='',index='',start_position='',end_position='')
    assert _message_1 == _message_2


# Generated at 2022-06-24 10:30:11.375906
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    BaseError().__getitem__(1)
    pass

# Generated at 2022-06-24 10:30:16.557233
# Unit test for constructor of class Message
def test_Message():
    test1 = Message(text='test', code='test', key='test', index=['test'], position=Position(1, 2, 3), start_position=Position(3, 2, 1), end_position=Position(3, 2, 1))
    assert test1.text == 'test'
    assert test1.code == 'test'
    assert test1.index == ['test']
    assert test1.start_position == Position(3, 2, 1)
    assert test1.end_position == Position(3, 2, 1)


# Generated at 2022-06-24 10:30:17.038548
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    pass

# Generated at 2022-06-24 10:30:25.670917
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    import yaml
    text0 = "May not have more than 100 characters"
    code0 = "max_length"
    obj0 = Message(text=text0, code=code0)
    msg0 = f"{type(obj0).__name__}(text={text0!r}, code={code0!r})"
    assert repr(obj0) == msg0

    text1 = "May not have more than 100 characters"
    code1 = "max_length"
    key1 = "username"
    obj1 = Message(text=text1, code=code1, key=key1)
    msg1 = f"{type(obj1).__name__}(text={text1!r}, code={code1!r}, index={[key1]!r})"
    assert repr(obj1) == msg1

    text

# Generated at 2022-06-24 10:30:26.269854
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    pass

# Generated at 2022-06-24 10:30:33.091483
# Unit test for constructor of class Message
def test_Message():
    # At least one argument is required
    with pytest.raises(AssertionError):
        Message()
    # Key or index must be set
    with pytest.raises(AssertionError):
        Message(key=None, index=None, text="message")
    # Key and index must not be set together
    with pytest.raises(AssertionError):
        Message(key=1, index=1, text="message")
    # Position must not be set together with start and end position
    with pytest.raises(AssertionError):
        Message(position=1, start_position=1, end_position=1, text="message")
    # Position must be set when start and end position are not set

# Generated at 2022-06-24 10:30:40.136369
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    assert BaseError().messages() == []
    assert BaseError().messages(add_prefix="ID") == []
    msgs = [Message(text='foo', code='bar', key='baz')]
    assert BaseError(messages=msgs).messages() == msgs
    assert BaseError(messages=msgs).messages(add_prefix="ID") == [Message(text='foo', code='bar', index=['ID', 'baz'])]

# Generated at 2022-06-24 10:30:49.305532
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    try:
        # Test 1: Try to get error message when there are no messages
        error = ValidationError()
        error["SomeKey"]
    except:
        pass
    else:
        assert False, "Did not raise KeyError"

    test_message = Message(
        text="An error message", code="code", key="SomeKey", position=Position(
            line_no=1, column_no=1, char_index=0
        )
    )

    try:
        # Test 2: Try to get a message from the error when there is only one message and it does not have a key
        error = ValidationError(messages=[test_message])
        error["SomeKey"]
    except:
        pass
    else:
        assert False, "Did not raise KeyError"


# Generated at 2022-06-24 10:30:55.801168
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="Hello") == BaseError(text="Hello")
    assert BaseError(text="Hello") != BaseError(text="Bye")
    assert BaseError(text="Hello") != BaseError(text="Hello", code="custom")
    assert BaseError(text="Hello", code="custom") != BaseError(text="Hello")
    assert BaseError(text="Hello", code="custom") != BaseError(text="Hello", code="whatever")
    assert BaseError(text="Hello", key=3) == BaseError(text="Hello", key=3)
    assert BaseError(text="Hello", key=3) != BaseError(text="Hello", index=[3])
    assert BaseError(text="Hello", index=[3]) == BaseError(text="Hello", index=[3])

# Generated at 2022-06-24 10:30:57.727980
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    code = 'code'
    index = ['index']
    text = 'text'
    msg = Message(text=text, code=code, index=index)
    assert hash(msg) == hash(('code', ('index',)))


# Generated at 2022-06-24 10:31:00.366642
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert (Position(1, 2, 3) == Position(1, 2, 3)) is True
    assert (Position(1, 2, 3) == Position(1, 2, 4)) is False


# Generated at 2022-06-24 10:31:04.194127
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    val, err = ValidationResult(value = 1)
    assert val == 1
    assert err is None
    val, err = ValidationResult(error = 'error')
    assert val is None
    assert err == 'error'


# Generated at 2022-06-24 10:31:14.110049
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text='a', code='a', index=[1], start_position=Position(1, 1, 1), end_position=Position(1, 1, 1)) == Message(text='a', code='a', index=[1], start_position=Position(1, 1, 1), end_position=Position(1, 1, 1))
    assert Message(text='a', code='a', index=[1], start_position=Position(1, 1, 1), end_position=Position(1, 1, 1)) != Message(text='a', code='a', index=[1], start_position=Position(1, 1, 1), end_position=Position(1, 1, 2))

# Generated at 2022-06-24 10:31:22.067358
# Unit test for constructor of class Position
def test_Position():
    # Test 1
    position1 = Position(1, 1, 0)
 
    # Test 2
    position2 = Position(1, 1, 0)

    # Test 3
    position3 = Position(2, 1, 0)

    # Test 4
    position4 = Position(1, 1, 0)

    # Test 5
    position5 = Position(1, 2, 0)
 
    assert position1 == position2
    assert position1 != position3
    assert position1 == position4
    assert position1 != position5

# Generated at 2022-06-24 10:31:25.676891
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    assert repr(BaseError(text="test_text", code="test_code", key="test_key")) == "BaseError(text='test_text', code='test_code', index=['test_key'])"
# End of unit test


# Generated at 2022-06-24 10:31:30.565916
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Create 2 equal instances, but with different element ordering
    error1 = BaseError(messages=[Message(text="foo", code="bar")])
    error2 = BaseError(messages=[Message(code="bar", text="foo")])

    # Both instances should be equal
    assert error1 == error2


# Generated at 2022-06-24 10:31:41.320222
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    # check if the method throws ValueError if there are invalid arguments
    with pytest.raises(ValueError):
        BaseError(text='', code='', key='', position='', messages='')
    with pytest.raises(ValueError):
        BaseError(text='', code='', key='', position='', messages='')
    with pytest.raises(ValueError):
        BaseError(text='', code='', key='', position='')
        messages=['', '', '']
    with pytest.raises(ValueError):
        BaseError(text='', code='', key='', position='', messages=[1])
    with pytest.raises(ValueError):
        BaseError(text='', code='', key='', position='', messages=['', ''])

# Generated at 2022-06-24 10:31:44.445513
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(line_no=1, column_no=2, char_index=3) == Position(line_no=1, column_no=2, char_index=3)


# Generated at 2022-06-24 10:31:46.976274
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    BaseError()
    # assert BaseError().__len__() == 0


# Generated at 2022-06-24 10:31:58.639226
# Unit test for constructor of class ValidationError
def test_ValidationError():
    error = ValidationError(text="Something went wrong")
    assert error.messages() == [
        Message(text="Something went wrong", code="custom", index=[])
    ]
    assert dict(error) == {"": "Something went wrong"}

    error = ValidationError(
            text="Something went wrong", key="first_name"
    )
    assert error.messages() == [
        Message(text="Something went wrong", code="custom", index=["first_name"])
    ]
    assert dict(error) == {"first_name": "Something went wrong"}


# Generated at 2022-06-24 10:31:59.711745
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    assert isinstance(BaseError.__hash__, collections.abc.Callable)

# Generated at 2022-06-24 10:32:04.146139
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    # Given
    p = Position(
        line_no=1,
        column_no=2,
        char_index=3
    )
    # When
    actual = p.__repr__()
    # Then
    assert actual == "Position(line_no=1, column_no=2, char_index=3)"


# Generated at 2022-06-24 10:32:13.609997
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    # Test with key not in error messages (return empty str)
    messages = [
        Message(text="", code="", index=[1, "name"], position=Position(1, 1, 1)),
        Message(text="", code="", index=[1, "age"], position=Position(1, 1, 1)),
    ]
    error = BaseError(messages=messages)
    assert error["name"] == ""
    # Test with key in error messages (return correct error message)
    assert error["age"] == ""
    # Test with key not in error messages (return empty dict)
    assert error["email"] == {}



# Generated at 2022-06-24 10:32:23.532119
# Unit test for constructor of class BaseError
def test_BaseError():
    # assert statement_expected == statement_actual
    # assert statement_expected != statement_actual
    # assert statement_expected is statement_actual
    # assert statement_expected is not statement_actual
    # assert statement_expected < statement_actual
    # assert statement_expected <= statement_actual
    # assert statement_expected >= statement_actual
    # assert statement_expected > statement_actual
    # assert statement_expected in statement_actual
    # assert statement_expected not in statement_actual

    error = BaseError(text="Hello world", code="custom", key="name", position=None, messages=None)
    assert error.messages() == [Message(text="Hello world", code="custom", key="name", position=None)]


# Generated at 2022-06-24 10:32:28.836779
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    # assert constructor of class ValidationResult
    a = ValidationResult(value="test")
    assert(a.value == "test" and a.error == None)
    b = ValidationResult(error=None)
    assert(b.error == None)
    c = ValidationResult()
    assert(c.error == None)
    d = ValidationResult(value="test", error="test")
    assert(d.value == "test" and d.error == None)
    e = ValidationResult(error="test", value="test")
    assert(e.value == "test" and e.error == None)

# Generated at 2022-06-24 10:32:30.784414
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    v = ValidationResult()
    assert not v

    v = ValidationResult(value=1)
    assert v


# Generated at 2022-06-24 10:32:35.054960
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    from pprint import pprint
    from typesystem.base.types import IntegerType
    v1 = ValidationResult(value=4)
    v2 = ValidationResult(error=ValidationError(text="error1"))
    for v in (v1, v2):
        print(v)
        pprint([i for i in v])
# test_ValidationResult___iter__()


# Generated at 2022-06-24 10:32:36.647764
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    message = Message(text="test text", code="test code", key="test key", index=["test index"])
    assert hash(message) == hash(("test code", ("test index",)))


# Generated at 2022-06-24 10:32:45.954786
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    message1 = Message(text="text0", code="code0", index=[0, "0", 0],
                       start_position=Position(line_no=0, column_no=0, char_index=0),
                       end_position=Position(line_no=0, column_no=0, char_index=0))
    message2 = Message(text="text0", code="code0", index=[0, "0", 0],
                       start_position=Position(line_no=0, column_no=0, char_index=0),
                       end_position=Position(line_no=0, column_no=0, char_index=0))
    assert hash(message1) == hash(message2)


# Generated at 2022-06-24 10:32:48.877622
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    """
    Test for `BaseError.__iter__()`.
    """
    error = BaseError(messages=[Message(text="error 1"), Message(text="error 2")])
    assert set(error) == {"", "1"}



# Generated at 2022-06-24 10:32:58.355311
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():

    from .enums import ValidationErrorType
    from .types import validate_json, validate_yaml

    # In case of invalid json
    raw_json = """{"first_name": "Wim", "last_name": "Poppinga"}"""

    # In case of invalid yaml
    raw_yaml = """
        first_name: Wim
        last_name: Poppinga
        """

    # In case of valid json
    raw_json_2 = """
        {"names": [
            {"first_name": "Wim", "last_name": "Poppinga"},
            {"first_name": "Peter", "last_name": "Kotthagen"}
        ]}"""

    # In case of valid yaml

# Generated at 2022-06-24 10:33:06.998782
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    message1 = Message(text='May not have more than 100 characters', code='max_length', key=None, index=['key1', 'key2', 'key3'], start_position=Position(line_no=66, column_no=1, char_index=0), end_position=None)
    message2 = Message(text='May not have more than 100 characters', code='max_length', key=None, index=['key1', 'key2', 'key3'], start_position=None, end_position=Position(line_no=66, column_no=1, char_index=1))

# Generated at 2022-06-24 10:33:15.360125
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    assert hash(Output(text="foobar", key="foo")) == hash(Output(text="foobar", key="foo"))
    assert hash(Output(text="foobar", key="foo")) == hash(Output(text="foobar", key="foo"))
    assert hash(Output(text="foobar", key="foo")) != hash(Output(text="bar", key="foo"))
    assert hash(Output(text="foobar", key="foo")) != hash(Output(text="foobar", key="bar"))
    assert hash(Output(text="foobar", key="foo")) != hash(Output(text="foobar"))

# Generated at 2022-06-24 10:33:22.037860
# Unit test for constructor of class BaseError
def test_BaseError():
    # Raise error if text and messages are absent
    try:
        BaseError()
        assert False
    except AssertionError:
        pass

    # Raise error if text and messages are present
    try:
        BaseError(text="", messages=[])
        assert False
    except AssertionError:
        pass

    # Raise error if code or key is present but text is absent
    try:
        BaseError(code="", key="")
        assert False
    except AssertionError:
        pass


# Generated at 2022-06-24 10:33:29.435985
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    class_name = type(ValidationResult()).__name__
    
    # value not None, error is None
    assert repr(ValidationResult(value={})) == f"{class_name}(value={dict()!r})"
    assert repr(ValidationResult(value=5)) == f"{class_name}(value={5!r})"
    assert repr(ValidationResult(value="abc")) == f"{class_name}(value={'abc'!r})"

    # error not None
    assert repr(ValidationResult(error=ValidationError(text="Invalid"))) == f"{class_name}(error=ValidationError(text='Invalid'))"

# Generated at 2022-06-24 10:33:39.508422
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    from copy import deepcopy
    from .. import Type
    from ..schema_builder import Schema, Field

    # Run class BaseError as it is
    o = BaseError(text="bad one", key="name", code="ok", position="0,1")
    oo = BaseError(messages=[o])
    msg = oo.messages()
    print(msg)
    assert str(msg[0]) == "[{'text': 'bad one', 'code': 'ok', 'key': 'name', 'position': '0,1'}]"

    # Test with class Type

# Generated at 2022-06-24 10:33:48.649185
# Unit test for constructor of class Position
def test_Position():
    # case 1:
    a = Position(1, 1, 1)
    assert a.line_no == 1
    assert a.column_no == 1
    assert a.char_index == 1

    # case 2:
    b = Position(2, 2, 2)
    assert b.line_no == 2
    assert b.column_no == 2
    assert b.char_index == 2

    # case 3:
    c = Position(3, 3, 3)
    assert c.line_no == 3
    assert c.column_no == 3
    assert c.char_index == 3


# Generated at 2022-06-24 10:33:57.669908
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    # Assert __eq__ returns True when line_no, column_no, char_index are same.
    arg = Position(line_no = 0, column_no = 0, char_index = 0)
    actual = arg == arg
    expected = True
    message = "Expected {}, got {}".format(repr(expected), repr(actual))
    assert actual == expected, message

    # Assert __eq__ returns True when line_no, column_no, char_index are different.
    arg = Position(line_no = 0, column_no = 0, char_index = 0)
    other = Position(line_no = 0, column_no = 0, char_index = 1)
    actual = arg == other
    expected = True
    message = "Expected {}, got {}".format(repr(expected), repr(actual))

# Generated at 2022-06-24 10:34:03.574386
# Unit test for constructor of class ValidationError
def test_ValidationError():
    e = ValidationError(text="hello world", code="some_error")
    assert dict(e) == {"": "hello world"}
    assert e.messages() == [Message(text="hello world", code="some_error")]

    e = ValidationError(messages=[Message(text="a", code="b"), Message(text="c", code="d")])
    assert dict(e) == {"": "a", "": "c"}
    assert e.messages() == [Message(text="a", code="b"), Message(text="c", code="d")]

# test_ValidationError()


# Generated at 2022-06-24 10:34:06.976802
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    # Check that repr() output is correct
    assert repr(Position(line_no=10, column_no=11, char_index=12)) == "Position(line_no=10, column_no=11, char_index=12)"


# Generated at 2022-06-24 10:34:12.217858
# Unit test for constructor of class ParseError
def test_ParseError():
    # calling constructor without providing any input(i.e default call)
    ParseError()
    # calling constructor with all the input arguments
    ParseError(messages = [Message(text='error1',code = 'custom',key = 'key1')])
    # Calling constructor with required arguments
    ParseError(text = 'error1',code = 'custom',key = 'key1')


# Generated at 2022-06-24 10:34:19.790616
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():

    class TestBaseError(BaseError):
        pass

    test1 = TestBaseError(text="test text", code="test code", key="test key")
    assert str(test1) == "test text"

    test2 = TestBaseError(messages=[Message(text="test text", code="test code")])
    assert str(test2) == "{'': 'test text'}"

    test3 = TestBaseError(
        messages=[Message(text="test text", code="test code", index=['test index'])]
    )
    assert str(test3) == "{'test index': 'test text'}"

# Generated at 2022-06-24 10:34:23.429298
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    result = eval(repr(Position(1, 2, 3)))

    assert isinstance(result, Position)
    assert result.line_no == 1
    assert result.column_no == 2
    assert result.char_index == 3


# Generated at 2022-06-24 10:34:25.827801
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    obj = ValidationResult()
    assert bool(obj) == False
    obj = ValidationResult(value=1)
    assert bool(obj) == True

# Generated at 2022-06-24 10:34:29.674049
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    e = BaseError()
    assert "" == str(e)

    e = BaseError(text="some text")
    assert "some text" == str(e)

    e = BaseError()
    e._message_dict = {"foo": "bar"}
    assert '{"foo": "bar"}' == str(e)

# Generated at 2022-06-24 10:34:32.175313
# Unit test for constructor of class Message
def test_Message():
    Message('This is a test', 'test_code', 'test_key', [1,2], Position(1,1,1), Position(2,2,2), Position(3,3,3))


# Generated at 2022-06-24 10:34:38.083315
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Case 1: boolean
    a = Message(text="text 1")
    assert a.__eq__(True) is False
    # Case 2: compare two different objects
    b = Message(text="text 2")
    assert a.__eq__(b) is False
    # Case 3: compare two equal objects
    b.text = "text 1"
    assert a.__eq__(b) is True


# Generated at 2022-06-24 10:34:46.940565
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message = Message(text='May not have more than 100 characters', code='max_length', index=['email'], start_position=Position(line_no=0, column_no=1, char_index=2), end_position=Position(line_no=0, column_no=2, char_index=2))
    assert message == message
    assert message != object()
    assert message != Message(text='May not have more than 100 characters', code='max_length', index=[], start_position=Position(line_no=0, column_no=1, char_index=2), end_position=Position(line_no=0, column_no=2, char_index=2))

# Generated at 2022-06-24 10:34:50.739498
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    import doctest
    doctest.run_docstring_examples(
        ValidationResult.__repr__, globals(), 
        name='ValidationResult.__repr__'
    )



# Generated at 2022-06-24 10:34:59.419565
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    a = ValidationResult(value = 4)
    b = ValidationResult(error = "ERROR")
    c = ValidationResult(value = 'value', error = "ERROR")
    d = ValidationResult(value = 4)
    a_value_iterable = list(a)
    b_value_iterable = list(b)
    c_value_iterable = list(c)
    d_value_iterable = list(d)
    a_bool = bool(a)
    b_bool = bool(b)
    c_bool = bool(c)
    d_bool = bool(d)
    if a_value_iterable[0] != a.value:
        raise Exception('ValidationResult class constructor failed on attribute value')
    if b_value_iterable[1] != b.error:
        raise Exception

# Generated at 2022-06-24 10:35:03.171158
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    assert repr(ValidationResult(value=3)) == "ValidationResult(value=3)"
    assert repr(ValidationResult(error=ValidationError(text="test"))) == "ValidationResult(error=ValidationError(text='test'))"


# Generated at 2022-06-24 10:35:08.867167
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    # It should return different hashes for different error messages.
    error = ValidationError(text="Error text 1")
    assert hash(error) != hash(ValidationError(text="Error text 2"))

    # It should return the same hash for a ValidationError and a child ValidationError with the same error message.
    error = ValidationError(text="Error text 1")
    child_error = ValidationError(text="Error text 1", key="child key")
    assert hash(error) == hash(child_error)

# Generated at 2022-06-24 10:35:12.795305
# Unit test for constructor of class ParseError
def test_ParseError():
    parse_error = ParseError(text="Testing")
    assert str(parse_error) == "Testing"


# Generated at 2022-06-24 10:35:17.271145
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    vr_without_error = ValidationResult(value="value")
    assert not vr_without_error
    # vr_without_error: bool = False

    vr_with_error = ValidationResult(error="error")
    assert vr_with_error
    # vr_with_error: bool = True

# Generated at 2022-06-24 10:35:20.828426
# Unit test for constructor of class Position
def test_Position():
    position = Position(3, 4, 5)
    assert position.__eq__(3) == False
    assert position.__eq__(position) == True
    assert position.__repr__() == "Position(line_no=3, column_no=4, char_index=5)"


# Generated at 2022-06-24 10:35:26.228345
# Unit test for constructor of class Message
def test_Message():
    assert '<class \'typesystem.error.Message\'>' == str(type(Message(text='', code='', key='', index='', position='', start_position='', end_position='')))
    assert '<class \'typesystem.error.Message\'>' == str(type(Message(text='', code='', index='')))

# Generated at 2022-06-24 10:35:27.195541
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    # TODO
    pass


# Generated at 2022-06-24 10:35:35.144405
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    assert eval(repr(Message(text='a', code='custom', key=None, index=None, position=Position(line_no=0, column_no=0,
                                                                                                 char_index=0)))) == Message(
        text='a', code='custom', key=None, index=None, position=Position(line_no=0, column_no=0, char_index=0))
    assert eval(repr(Message(text='a', code='custom', key=None, index=None, position=Position(line_no=0, column_no=0,
                                                                                                 char_index=0)))) != Message(
        text='a', code='custom', key=None, index=None, position=Position(line_no=1, column_no=0, char_index=0))
# Unit test