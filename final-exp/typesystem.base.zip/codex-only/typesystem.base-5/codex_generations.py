

# Generated at 2022-06-24 10:25:35.086276
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    from mu.sco import old
    old.testfail

    import datetime
    from mu.sco import old
    from mu.mel import ji
    from mu.mel import mel
    from mu.utils import tools
    from mu.sco import old
    from mu.mel import trad
    from mu.utils import infit
    from mu.sco import old
    from mu.mel import hc
    from mu.utils import interpolations
    from mu.rhy import rhy
    from mu.sco import old
    from mu.mel import seg
    from mu.mel import elis



# Generated at 2022-06-24 10:25:37.226032
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    first_error=BaseError(text="There is some error")
    second_error=BaseError(text="There is some error")
    assert hash(first_error)==hash(second_error)


# Generated at 2022-06-24 10:25:40.489554
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult(value=42)
    assert result.value == 42
    assert result.error is None

    error = ValidationError(text="test")
    result = ValidationResult(error=error)
    assert result.value is None
    assert result.error == error

# Generated at 2022-06-24 10:25:47.591823
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    err = BaseError(messages=[Message(text="", code="", index=[])])
    assert len(err) == 0

    err = BaseError(messages=[Message(text="", code="", index=["a"])])
    assert len(err) == 1

    err = BaseError(messages=[Message(text="", code="", index=["a", "b"])])
    assert len(err) == 1

    err = BaseError(messages=[Message(text="", code="", index=[]), Message(text="", code="", index=[])])
    assert len(err) == 0

    err = BaseError(messages=[Message(text="", code="", index=[]), Message(text="", code="", index=["a"])])
    assert len(err) == 1


# Generated at 2022-06-24 10:25:49.868764
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    from typesystem import String

    assert String(max_length=100).validate_or_error("a" * 100).value == "a"*100  # type: ignore
    assert String(max_length=100).validate_or_error("a" * 101) is False  # type: ignore

# Generated at 2022-06-24 10:25:55.976145
# Unit test for method __eq__ of class Message
def test_Message___eq__():
	# Trivial cases
	assert Message(text='a', code='b', key='c') == Message(text='a', code='b', key='c')
	assert Message(text='a', code='b', key='c') != 1
	assert Message(text='a', code='b', key='c') != 'a'
	assert Message(text='a', code='b', key='c') != Message(text='b', code='b', key='c')
	assert Message(text='a', code='b', key='c') != Message(text='a', code='a', key='c')
	assert Message(text='a', code='b', key='c') != Message(text='a', code='b', key='d')


# Generated at 2022-06-24 10:26:00.646993
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    error = ValidationError(text="error", code="code", key="key")
    assert error.messages() == [
        Message(text="error", code="code", key="key")
    ]
    assert error.messages(add_prefix="add_prefix") == [
        Message(text="error", code="code", index=["add_prefix", "key"])
    ]

# Generated at 2022-06-24 10:26:03.701168
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    # Setup
    expected = 'ValidationResult(error=ValidationError({}))'
    # Assert
    assert (ValidationResult(error=ValidationError()).__repr__()) == expected


# Generated at 2022-06-24 10:26:06.494518
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    vr = ValidationResult(value=['x'])
    assert bool(vr)
    vr = ValidationResult(error='invalid')
    assert not bool(vr)

# Generated at 2022-06-24 10:26:13.053327
# Unit test for constructor of class BaseError
def test_BaseError():
    error = BaseError(text="foo", code="code", key="key")
    assert error._messages == [Message(text="foo", code="code", key="key")]
    assert error._message_dict == {"": "foo"}

    error = BaseError(messages=[Message(text="foo", code="code", index=[0])])
    assert error._messages == [Message(text="foo", code="code", index=[0])]
    assert error._message_dict == {0: "foo"}



# Generated at 2022-06-24 10:26:15.145335
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    ee = BaseError(messages=[Message(text='hello'), Message(text='hello')])
    assert iter(ee) is iter(ee)



# Generated at 2022-06-24 10:26:17.588331
# Unit test for constructor of class Message
def test_Message():
    message = Message(text="text")
    assert message.text == "text"
    assert message.code == "custom"
    assert message.index == []
    assert message.start_position is None
    assert message.end_position is None

# Generated at 2022-06-24 10:26:21.579731
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    class_name = BaseError.__class__.__name__
    assert BaseError(text='a', code='b', key='c').__eq__(Message(text='a', code='b', key='c'))

# Generated at 2022-06-24 10:26:29.100438
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    # Initialization
    msg = Message(text="val1", code="val2", key="val3", index=["val4", "val5"], position="val6", start_position="val7", end_position="val8")
    # Expected output
    assert msg.__repr__() == 'Message(text=\'val1\', code=\'val2\', index=[\'val4\', \'val5\'], start_position="val7", end_position="val8")'
    return None


# Generated at 2022-06-24 10:26:33.764227
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    """
    Test `BaseError.__iter__()`.
    """
    error = ValidationError(
        messages=[Message(text="oops", code="oops", key="foo"), Message(text="oops", code="oops", key="bar")]
    )
    assert list(error) == ["foo", "bar"]



# Generated at 2022-06-24 10:26:36.208805
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    position = Position(line_no=1, column_no=2, char_index=3)
    assert repr(position) == "Position(line_no=1, column_no=2, char_index=3)"


# Generated at 2022-06-24 10:26:44.418020
# Unit test for constructor of class ValidationError
def test_ValidationError():
    error1 = ValidationError(key='user_count', text='Must be non-negative')
    error2 = ValidationError(text='Must be non-negative', code='custom', key='user_count')
    error3 = ValidationError(text='Must be non-negative', code='custom', key='user_count')
    assert error1 == error2
    assert error1 == error3
    assert error1 is not error2
    assert error1 is not error3
    assert error2 is not error3
    assert error1.messages() == [Message(text='Must be non-negative', code='custom', key='user_count')]

# Generated at 2022-06-24 10:26:54.018160
# Unit test for constructor of class ParseError
def test_ParseError():
    # test for ParseError(text, code, key)
    error1 = ParseError('test message', 'test code', 'test key')
    assert error1._messages == [Message(text='test message', code='test code', key='test key', position=None)]
    assert error1._message_dict == {'test key': 'test message'}

    # test for ParseError(messages)
    message1 = Message(text='test message1', code='test code1', key='test key1')
    message2 = Message(text='test message2', code='test code2', key='test key2')
    message3 = Message(text='test message3', code='test code3', key='test key3')
    error2 = ParseError(messages=[message1, message2, message3])
    assert error2._

# Generated at 2022-06-24 10:27:01.620307
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    assert str(ValidationError(text="data type must be string")) == "data type must be string"
    error = ValidationError([
        Message(text="min value is 0", key="min"),
        Message(text="max value is 10", key="max"),
    ])
    assert str(error) == "{'min': 'min value is 0', 'max': 'max value is 10'}"
    assert str(ValidationError(messages=[Message(text="data type must be string", index=[])])) == "data type must be string"
    error = ValidationError([
        Message(text="max value is 0", index=[0, "max"]),
        Message(text="max value is 10", index=[1, "max"]),
    ])

# Generated at 2022-06-24 10:27:09.958640
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="text") == Message(text="text")
    assert Message(text="text", code="code") == Message(text="text", code="code")
    assert Message(text="text", key=0) == Message(text="text", key=0)
    assert Message(text="text", index=[1, 2]) == Message(text="text", index=[1, 2])
    assert Message(text="text", position=Position(1, 2, 3)) == Message(text="text", position=Position(1, 2, 3))
    assert Message(text="text", start_position=Position(1, 2, 3), end_position=Position(1, 2, 3)) == Message(text="text", start_position=Position(1, 2, 3), end_position=Position(1, 2, 3))


# Generated at 2022-06-24 10:27:13.367007
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    line_no = 1
    column_no = 2
    char_index = 3
    position_instance = Position(line_no, column_no, char_index)
    assert repr(position_instance) == (
            "Position(line_no=1, column_no=2, char_index=3)")

# Generated at 2022-06-24 10:27:18.259220
# Unit test for constructor of class BaseError
def test_BaseError():
  key = None
  message = "error"
  code = "1"
  e = BaseError(message=message, code=code, key=key)
  assert str(e) == message
  assert e._messages[0].text == message
  assert e._messages[0].code == code
  assert e._messages[0].key == key

# Generated at 2022-06-24 10:27:22.417767
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    v1, _ = ValidationResult(value=42).__iter__()
    assert v1 == 42
    v2, e2 = ValidationResult(error=ValidationError(text="error")).__iter__()
    assert v2 is None and isinstance(e2, ValidationError)
    assert e2.messages() == [Message(text="error")]

# Generated at 2022-06-24 10:27:28.600331
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    expected = {'ErrorCode': 'ErrorMessage', 'ErrorCode1': 'ErrorMessage1'}
    ErrorCode = Message(text='ErrorMessage', code='ErrorCode')
    ErrorCode1 = Message(text='ErrorMessage1', code='ErrorCode1')
    messages = [ErrorCode, ErrorCode1]
    result = BaseError(messages=messages)
    assert result == {'ErrorCode': 'ErrorMessage', 'ErrorCode1': 'ErrorMessage1'}


# Generated at 2022-06-24 10:27:30.436548
# Unit test for constructor of class BaseError
def test_BaseError():
    error = BaseError()
    print(error)
    print(dict(error))
    print(error.messages())


# Generated at 2022-06-24 10:27:31.459691
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError(text='test text', code='test code', key='test key')


# Generated at 2022-06-24 10:27:36.585646
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    valid_result = ValidationResult(value="a")
    assert valid_result.value == "a" and valid_result.error is None
    invalid_result = ValidationResult(error=ValidationError(text="hi"))
    assert valid_result.value == "a" and valid_result.error is None

# Generated at 2022-06-24 10:27:38.468246
# Unit test for constructor of class ParseError
def test_ParseError():
    text = "this is a error message"
    exception = ParseError(text=text)


# Generated at 2022-06-24 10:27:47.246169
# Unit test for constructor of class Message
def test_Message():
    message = Message(text="May not have more than 100 characters", code="max_length", key="username", index=None, position=Position(1, 1, 1), start_position=Position(1, 1, 1), end_position=Position(1, 1, 1))
    assert message.text == "May not have more than 100 characters"
    assert message.code == "max_length"
    assert message.key == "username"
    assert message.index == None
    assert message.position == Position(1, 1, 1)
    assert message.start_position == Position(1, 1, 1)
    assert message.end_position == Position(1, 1, 1)
    assert message.__eq__(message)
    assert message.__hash__() == -743228765

# Generated at 2022-06-24 10:27:55.035113
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    msg = Message(text="hi", code="hi", key="hi", index=["hi"], position=Position(1, 2, 3), start_position=Position(2, 3, 4), end_position=Position(3, 4, 5))
    assert "__repr__" in dir(msg)
    assert msg.__repr__() == "Message(text='hi', code='hi', index=['hi'], start_position=Position(line_no=2, column_no=3, char_index=4), end_position=Position(line_no=3, column_no=4, char_index=5))"


# Generated at 2022-06-24 10:28:05.787848
# Unit test for method __eq__ of class Position

# Generated at 2022-06-24 10:28:07.527024
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    msg = ValidationError(key='msg', text="Message")
    assert msg['msg'] == 'Message'

# Generated at 2022-06-24 10:28:17.043230
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    m1 = Message(
        text=str(),
        code=str(),
        key=typing.Union[int, str](),
        index=typing.List[typing.Union[int, str]](),
        position=Position(int(), int(), int()),
        start_position=Position(int(), int(), int()),
        end_position=Position(int(), int(), int()),
    )
    m2 = Message(
        text=str(),
        code=str(),
        key=typing.Union[int, str](),
        index=typing.List[typing.Union[int, str]](),
        position=Position(int(), int(), int()),
        start_position=Position(int(), int(), int()),
        end_position=Position(int(), int(), int()),
    )
    assert m

# Generated at 2022-06-24 10:28:19.303316
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    assert hash(BaseError(text='', code='', key=None, position=None, messages=[])) == 0

# Generated at 2022-06-24 10:28:22.472442
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    assert repr(Position(1, 2, 3)) == "Position(line_no=1, column_no=2, char_index=3)"


# Generated at 2022-06-24 10:28:30.989341
# Unit test for constructor of class ValidationError
def test_ValidationError():
    # Constructor with 1 error message
    e1 = ValidationError(
        text="This is an error message.", code="error_code", key="key"
    )
    assert e1.messages() == [
        Message(text="This is an error message.", code="error_code", key="key")
    ]

    # Constructor with 2 error messages
    e2 = ValidationError(
        messages=[
            Message(text="This is an error message.", code="error_code", key="key"),
            Message(text="This is an error message.", code="error_code", key="key"),
        ]
    )

# Generated at 2022-06-24 10:28:33.417195
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    with pytest.raises(AssertionError):
        error = BaseError(text="Invalid email address", code="invalid_email")
        error_length = len(error)


# Generated at 2022-06-24 10:28:37.277828
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    v = BaseError(text="foo")
    messages = v.messages()
    assert isinstance(messages[0].code, str)
    assert messages[0].code == "custom"
    assert messages[0].text == "foo"


# Generated at 2022-06-24 10:28:43.896910
# Unit test for constructor of class BaseError
def test_BaseError():
    assert BaseError(text='text', code='code', key='key', position='position')
    assert BaseError(messages='messages')
    try:
        BaseError(text='text', code='code', key='key', position='position', messages='messages')
    except AssertionError:
        assert True
    try:
        BaseError(text='text', code='code', key='key', position='position', messages='messages', message='message')
    except AssertionError:
        assert True


# Generated at 2022-06-24 10:28:50.444889
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    my_error = BaseError(messages=[
        Message(text='message 1'),
        Message(text='message 2', code='error_2')
    ])
    assert my_error.messages() == [
        Message(text='message 1'),
        Message(text='message 2', code='error_2')
    ]
    assert my_error.messages(add_prefix='key1') == [
        Message(text='message 1', index=['key1']),
        Message(text='message 2', code='error_2', index=['key1']),
    ]
    assert my_error.messages(add_prefix=1) == [
        Message(text='message 1', index=[1]),
        Message(text='message 2', code='error_2', index=[1]),
    ]

# Generated at 2022-06-24 10:28:51.508859
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    # Init
    expected = None

    # Exercise

    # Verify
    assert expected == None

# Generated at 2022-06-24 10:28:57.809895
# Unit test for method __hash__ of class BaseError

# Generated at 2022-06-24 10:29:07.648445
# Unit test for constructor of class Message
def test_Message():
    line_no = 1
    column_no = 2
    
    # 클래스 생성
    message = Message(
        text = 'hello world',
        code = 'MAX_LEN',
        key = 'name',
        index = [1,2,3],
        position = Position(
            line_no = line_no,
            column_no = column_no,
            char_index = 0
        ),
        start_position = Position(
            line_no = line_no,
            column_no = column_no,
            char_index = 0
        ),
        end_position = Position(
            line_no = line_no,
            column_no = column_no,
            char_index = 0
        )
    )

# Generated at 2022-06-24 10:29:10.851187
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    msg1 = Message("Message 1")
    msg2 = Message("Message 2")
    error1 = BaseError(messages=[msg1, msg2])
    error2 = BaseError(messages=[msg2, msg1])
    assert hash(error1) == hash(error2)



# Generated at 2022-06-24 10:29:21.690252
# Unit test for constructor of class ParseError
def test_ParseError():
    def assert_instantiate_with_positions():
        error1 = ParseError(
            key=3,
            text="Invalid value",
            position=Position(line_no=1, column_no=5, char_index=5),
        )
        error2 = ParseError(
            key=3,
            text="Invalid value",
            start_position=Position(line_no=1, column_no=4, char_index=4),
            end_position=Position(line_no=1, column_no=7, char_index=7),
        )
        assert error1 == error2


# Generated at 2022-06-24 10:29:26.251971
# Unit test for constructor of class Message
def test_Message():
    message_object = Message(text="test", code="test_code")
    assert message_object.text == "test"
    assert message_object.code == "test_code"
    assert message_object.index == []
    assert message_object.start_position is None
    assert message_object.end_position is None


# Generated at 2022-06-24 10:29:37.842609
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    message1 = Message(text='May not have more than 100 characters', code='max_length',
                       key='username', index=['users', 3, 'username'], position=Position(1,2,100),
                       start_position=Position(1,2,100), end_position=Position(1,2,100))
    print(message1, repr(message1))
    assert repr(message1) == "Message(text='May not have more than 100 characters', code='max_length', index=['users', 3, 'username'], position=Position(line_no=1, column_no=2, char_index=100))"
    print(message1.text, message1.code, message1.index, message1.position, message1.start_position, message1.end_position)

# Generated at 2022-06-24 10:29:43.557923
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    validation_err = ValidationError(
        text="hello", code="", key="", position=None, messages=None
    )
    validation_err1 = ValidationError(
        text="hello", code="", key="", position=None, messages=None
    )
    validation_err2 = ValidationError(
        text="hello_daniel", code="", key="", position=None, messages=None
    )
    validation_err3 = ValidationError(
        text="hello", code="bad_user", key="", position=None, messages=None
    )
    assert validation_err == validation_err1
    assert validation_err != validation_err2
    assert validation_err != validation_err3


# Generated at 2022-06-24 10:29:51.618243
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    # An instance with a single error message.
    error = BaseError(text="Text for single error message")
    assert str(error) == "Text for single error message"

    # An instance with multiple error messages.
    error = BaseError(messages=[
        Message(text="First error message", code="first"),
        Message(text="Second error message", code="second"),
    ])
    assert str(error) == (
        '{\n'
        '   "first"\n'
        '      "Text for first error message"\n'
        '   "second"\n'
        '      "Text for second error message"\n'
        '}'
    )

    # An instance with a single error message with a key.
    error = BaseError(text="Text for single error message", key="key")
    assert str

# Generated at 2022-06-24 10:29:53.517462
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    class_name = BaseError.__class__.__name__
    assert class_name == "BaseError"

# Generated at 2022-06-24 10:29:56.184848
# Unit test for constructor of class Position
def test_Position():
    position = Position(20, 21, 22)
    assert position.line_no == 20
    assert position.column_no == 21
    assert position.char_index == 22


# Generated at 2022-06-24 10:29:58.415735
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    assert ValidationResult(value=[1, 2, 3]).__bool__() == True



# Generated at 2022-06-24 10:30:00.695191
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    p1 = Position(1, 2, 3)
    p2 = Position(1, 2, 3)
    assert p1 == p2



# Generated at 2022-06-24 10:30:10.425664
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    validated, error = ValidationResult(value=1), ValidationResult(error="error")
    assert validated.value == 1
    assert validated.error == None
    assert error.value == None
    assert error.error == "error"
    assert bool(validated) == True and bool(error) == False
    assert repr(validated) == "ValidationResult(value=1)" and repr(error) == "ValidationResult(error='error')"
    assert validated[0] == 1 and validated[1] == None and error[0] == None and error[1] == "error"
    assert list(validated) == [1, None] and list(error) == [None, "error"]



# Generated at 2022-06-24 10:30:13.697836
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    message = Message(text='"value" is required', code='required', key='value')
    assert message.__repr__() == 'Message(text="\\"value\\" is required", code=\'required\', index=[\'value\'])'


# Generated at 2022-06-24 10:30:19.013916
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    position_1 = Position(1, 2, 3)
    position_2 = Position(1, 2, 3)
    assert position_1 == position_2

    position_1 = Position(1, 2, 3)
    position_2 = Position(1, 2, 4)
    assert position_1 != position_2



# Generated at 2022-06-24 10:30:23.613264
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    pos1 = Position(line_no=1, column_no=2, char_index=3)
    pos2 = Position(line_no=1, column_no=2, char_index=3)
    pos3 = Position(line_no=1, column_no=2, char_index=4)
    assert pos1 == pos2
    assert pos1 != pos3


# Generated at 2022-06-24 10:30:33.519525
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    text = 'message_text'
    code = 'message_code'
    key = 'message_key'
    index_0 = []
    index_1 = [0]
    index2 = [0, 1]
    start_position = Position(line_no=1, column_no=1, char_index=1)
    end_position = Position(line_no=2, column_no=2, char_index=2)
    position = Position(line_no=1, column_no=1, char_index=1)
    message0 = Message(text=text, code=code, key=key, index=index_0, start_position=start_position, end_position=end_position)

# Generated at 2022-06-24 10:30:40.038645
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(messages=[Message(text='Text1', code='Code1', index=[1])])
    error2 = BaseError(messages=[Message(text='Text1', code='Code1', index=[1])])
    assert error1 == error2
    error3 = BaseError(messages=[Message(text='Text1', code='Code1', index=[1, 2])])
    assert error1 != error3


# Generated at 2022-06-24 10:30:49.307199
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    from datetime import date
    from typesystem import String
    from .utils import validate

    data = "abc"
    # str_schema = String(max_length=2)
    str_schema = String(minimum_length=4, maximum_length=6)
    try:
        result = validate(str_schema, data)
    except ValidationError as e:
        print(e)
        print(e.messages())
        print(repr(e))
        print()

    schema = [String(), date]
    try:
        result = validate(schema, ["abc", "abc"])
    except ValidationError as e:
        print(e)
        print(e.messages())
        print(repr(e))
        print()



# Generated at 2022-06-24 10:30:51.694646
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    assert repr(Position(line_no=1, column_no=2, char_index=3)) == "Position(line_no=1, column_no=2, char_index=3)"


# Generated at 2022-06-24 10:30:55.979915
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value = 'a')
    assert len(list(result)) == 2
    assert list(result) == ['a', None]

    result = ValidationResult(error = ValidationError(text = 'a'))
    assert len(list(result)) == 2
    assert list(result) == [None, ValidationError(text='a')]




# Generated at 2022-06-24 10:30:57.510466
# Unit test for constructor of class BaseError
def test_BaseError():
    BaseError(text="test text")
    BaseError(messages=[Message(text="test text")])


# Generated at 2022-06-24 10:31:04.823563
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    error = BaseError(text="text", code="code", key="key")
    assert repr(error) == "BaseError(text='text', code='code')"
    message = Message(text="text", code="code", index=["index"])
    error = BaseError(messages=[message])
    assert repr(error) == "BaseError([Message(text='text', code='code', index=['index'])])"


# Generated at 2022-06-24 10:31:05.796999
# Unit test for constructor of class ParseError
def test_ParseError():
    assert ParseError()


# Generated at 2022-06-24 10:31:14.141675
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    class_name = 'BaseError'
    text = "Some Error Message"
    code = "custom"
    position = Position(line_no=2, column_no=3, char_index=4)
    message = Message(
        text=text, code=code, key=None, index=None, position=position)
    error = BaseError(messages=[message])
    repr_text = repr(error)
    repr_text1 = "BaseError(text='Some Error Message', code='custom', position=Position(line_no=2, column_no=3, char_index=4))"
    assert repr_text == repr_text1



# Generated at 2022-06-24 10:31:17.179169
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    message = Message(
        text="May not have more than 100 characters",
        code="max_length",
        key="username",
        position=Position(line_no=10, column_no=1, char_index=100),
    )
    assert message.__repr__() == f"Message(text='May not have more than 100 characters', code='max_length', key='username', position=Position(line_no=10, column_no=1, char_index=100))"
    

# Generated at 2022-06-24 10:31:26.859329
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    e = BaseError()
    assert isinstance(e, Mapping)
    assert [] == list(e)
    assert 0 == len(e)
    assert {} == dict(e)
    assert {'a': None} != dict(e)
    assert {'a': 'b'} != dict(e)

    e = BaseError(messages=[
        Message(code='a', text='b', key='a')
    ])
    assert [0] == list(e)
    assert 1 == len(e)
    assert {0: 'b'} == dict(e)
    assert {'a': 'b'} != dict(e)


# Generated at 2022-06-24 10:31:36.744833
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    class ReprTest:
        def __init__(self, value: int = 0):
            self.value = value
        def __repr__(self):
            return f"{self.__class__.__name__}({self.value})"

    repr_test = ReprTest(123)
    assert repr(ValidationResult(value=repr_test)) == "ValidationResult(value=ReprTest(123))"
    assert repr(ValidationResult(error=repr_test)) == "ValidationResult(error=ReprTest(123))"



# Generated at 2022-06-24 10:31:43.513743
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    test_result = ValidationResult(value = 5)
    assert test_result.value == 5
    assert test_result.error is None
    test_result = ValidationResult(error = ValidationError(text = "Test Error"))
    assert test_result.value is None
    assert test_result.error is not None
    assert test_result.error.text == "Test Error"
    test_result = ValidationResult(value = 5, error = ValidationError(text = "Test Error"))
    assert test_result.value == 5
    assert test_result.error is not None
    assert test_result.error.text == "Test Error"
    test_result = ValidationResult(error = ValidationError(text = "Test Error"), value = 5)
    assert test_result.value == 5

# Generated at 2022-06-24 10:31:52.370328
# Unit test for constructor of class Message
def test_Message():
    assert Message(text="This is a message") == Message(text="This is a message")
    assert Message(text="This is a message") != Message(text="This is not a message")
    assert Message(text="This is a message") != Message(text="this is a message")
    assert Message(text="This is a message", code="abc") == Message(text="This is a message", code="abc")
    assert Message(text="This is a message", code="abc") != Message(text="This is a message", code="def")
    assert Message(text="This is a message", code="abc") != Message(text="This is a not message", code="abc")
    assert Message(text="This is a message", key="def") == Message(text="This is a message", key="def")

# Generated at 2022-06-24 10:32:02.494781
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    error = BaseError(text=1)
    expected = '["message", 1]'
    actual = str(error)
    assert actual == expected, f"Expected: {expected}\nActual:   {actual}"
    error = BaseError(messages=[Message(text=1)])
    expected = '["message", 1]'
    actual = str(error)
    assert actual == expected, f"Expected: {expected}\nActual:   {actual}"
    error = BaseError(messages=[Message(text=1), Message(text=2)])
    expected = '{"message": 1}'
    actual = str(error)
    assert actual == expected, f"Expected: {expected}\nActual:   {actual}"


# Generated at 2022-06-24 10:32:10.747508
# Unit test for constructor of class ParseError
def test_ParseError():
    assert ParseError() == {}
    assert ParseError(text="Foo") == {"": "Foo"}
    m = ParseError(text="Foo", code="bar", key="baz").messages()
    assert m[0] == Message(text="Foo", code="bar", index=["baz"], position=None)
    assert ParseError(messages=[]) == {}
    assert ParseError(messages=[Message(text="Foo")]) == {"": "Foo"}

# Generated at 2022-06-24 10:32:20.714782
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    data1 = {1: 'one', 2: 'two'}

    try:
        data2 = data1[3]
    except KeyError as ex:
        error1 = BaseError(text="Not found", code="no_key", key=ex.args, messages=[])

    if error1:
        print(error1)
    else:
        print("No 'no_key'")

    try:
        data3 = data1[3]
    except KeyError as ex:
        error2 = BaseError(text="Not found", code="no_key", key=ex.args, messages=[])

    if error2:
        print(error2)
    else:
        print("No 'no_key'")

    assert error1 == error2

test_BaseError___eq__()

# Generated at 2022-06-24 10:32:29.675722
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    value = "hello world"
    error = ValidationError(text=value)
    v = ValidationResult(error=error)
    assert v.error == error
    assert v.value is None
    v = ValidationResult(value=value)
    assert v.value == value
    assert v.error is None
    assert bool(v)
    assert not bool(ValidationResult(error=error))
    v = ValidationResult()
    assert v.value is None
    assert v.error is None
    assert bool(v)
    assert bool(ValidationResult(value=None))
    assert not bool(ValidationResult(error=None))



# Generated at 2022-06-24 10:32:31.868714
# Unit test for constructor of class Position
def test_Position():
    with pytest.raises(AssertionError):
        Position(line_no=2.0, column_no=1, char_index=1)


# Generated at 2022-06-24 10:32:35.665804
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    text = "this is an error message"
    code = "err_code"
    key = "my_key"
    messages = [Message(text=text, code=code, key=key)]
    error1 = BaseError(messages=messages)
    error2 = BaseError(messages=messages)
    assert error1 == error2


# Generated at 2022-06-24 10:32:45.247242
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    def key_and_message(message):
        return message.index[0], message.text

    assert key_and_message(message1) == ('username', 'May not have more than 100 characters')
    assert key_and_message(message2) == ('username', 'May not be empty')
    assert key_and_message(message3) == ('id', 'May not be blank')
    assert key_and_message(message4) == ('id', 'May not be blank')
    assert key_and_message(message5) == ('first_name', 'Must be at least 3 characters long')
    assert key_and_message(message6) == ('last_name', 'Must be at least 3 characters long')
    assert key_and_message(message7) == ('interests', 'May not have more than 10 items')
    assert key_and

# Generated at 2022-06-24 10:32:50.284827
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    err = BaseError()
    assert len(err) == 0

    err = BaseError(text="Error 1")
    assert len(err) == 1

    err = BaseError(messages=[Message(text="Error 1"), Message(text="Error 2")])
    assert len(err) == 2

    err = BaseError(messages=[Message(text="Error 1", key="key1"), Message(text="Error 2", key="key2")])
    assert len(err) == 2
    assert err.messages()[0].key in err.messages()[1].key


# Generated at 2022-06-24 10:32:57.356018
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    class SubError(BaseError):
        pass
    assert hash(BaseError(text='text')) == hash(BaseError(text='text'))
    assert hash(BaseError(text='text')) != hash(BaseError(text='text_'))
    assert hash(BaseError(text='text')) != hash(SubError(text='text'))
    assert hash(SubError(text='text')) == hash(SubError(text='text'))
    assert hash(SubError(text='text')) != hash(SubError(text='text_'))


# Generated at 2022-06-24 10:32:59.816560
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult(value=12)
    assert len(result) == 2
    assert result.value == 12
    assert result.error is None
    assert result



# Generated at 2022-06-24 10:33:00.858156
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    pass



# Generated at 2022-06-24 10:33:11.732605
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    assert repr(Message(text='May not have more than 100 characters', code=None, key=None, index=None, position=None, start_position=None, end_position=None)) == "Message(text='May not have more than 100 characters', code='custom', position=None)"
    assert repr(Message(text='May not have more than 100 characters', code=None, key=None, index=None, position=Position(line_no=1, column_no=1, char_index=1), start_position=None, end_position=None)) == "Message(text='May not have more than 100 characters', code='custom', position=Position(line_no=1, column_no=1, char_index=1))"

# Generated at 2022-06-24 10:33:14.141711
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    b1 = BaseError()
    b2 = BaseError()
    assert BaseError.__eq__(b1,b2)


# Generated at 2022-06-24 10:33:22.434275
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    instance1 = Message(text='foo', code='custom', index=[])
    instance2 = Message(text='bar', code='custom', index=[])
    instance3 = Message(text='foo', code='custom', index=[])
    instance4 = Message(text='foo', code='custom', index=[])
    instance5 = Message(text='bar', code='custom', index=[])

    assert hash(instance1) == hash(instance3)
    assert hash(instance1) == hash(instance4)
    assert hash(instance1) != hash(instance2)
    assert hash(instance2) == hash(instance5)

# Generated at 2022-06-24 10:33:29.505175
# Unit test for constructor of class ValidationError
def test_ValidationError():
    error = ValidationError(text="Hello world")
    assert error.messages() == [Message(text="Hello world", code="custom")]
    assert error.messages(add_prefix="foo") == [
        Message(text="Hello world", code="custom", index=["foo"])
    ]

    error = ValidationError(messages=[Message(text="Hello world"), Message(text="Hello world")])
    assert error.messages() == [Message(text="Hello world"), Message(text="Hello world")]
    assert error.messages(add_prefix="foo") == [
        Message(text="Hello world", index=["foo"]),
        Message(text="Hello world", index=["foo"]),
    ]


# Generated at 2022-06-24 10:33:37.055252
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    # Constructor values of the class
    message1 = Message(text = "error1", code = "code1", index = [0, 1, 2])
    message2 = Message(text = "error2", code = "code2", index = [0, 1, 2])
    message3 = Message(text = "error3", code = "code3", index = [0, 1, 2])
    # Testing __hash__ method
    assert hash(message1) == hash(message2)
    assert hash(message1) != hash(message3)


# Generated at 2022-06-24 10:33:43.074784
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    def run_test(input_value, expected_value):
        # Arrange
        number_of_errors_required = len(expected_value)
        error_messages = [Message(
            text="error {0}".format(i),
            index=[i],
            )
            for i in range(0, number_of_errors_required)
        ]
        error = BaseError(messages=error_messages)

        # Act
        actual_value = error[input_value]
        
        # Assert
        assert actual_value == expected_value
        
    yield run_test, 0, "error 0"
    yield run_test, 1, "error 1"
    yield run_test, 2, "error 2"

# Unit tests for method messages of class BaseError

# Generated at 2022-06-24 10:33:53.571732
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    line_no = 1
    column_no = 2
    char_index = 3
    position1 = Position(line_no=line_no, column_no=column_no, char_index=char_index)
    position1_dup = Position(line_no=line_no, column_no=column_no, char_index=char_index)
    position1_diff_line_no = Position(line_no=line_no + 1, column_no=column_no, char_index=char_index)
    position1_diff_column_no = Position(line_no=line_no, column_no=column_no + 1, char_index=char_index)

# Generated at 2022-06-24 10:34:02.053918
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    error1 = BaseError(text="error", code=None, key=None, position=None, messages=None)
    error2 = BaseError(text="error", code=None, key=None, position=None, messages=None)
    if not (hash(error1) == hash(error2)):
        raise Exception(
            "Unexpected behavior during hash of BaseError: in test 1 hash(error1) != hash(error2)!"
        )

    code = "code"
    error1 = BaseError(text="error", code=code, key=None, position=None, messages=None)
    error2 = BaseError(text="error", code=code, key=None, position=None, messages=None)

# Generated at 2022-06-24 10:34:11.720830
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    # Test when line_no=0, column_no=0, char_index=0
    # Should return the result of string formatting
    position = Position(0, 0, 0)
    result = position.__repr__()
    assert result == "Position(line_no=0, column_no=0, char_index=0)"

    # Test when line_no=19, column_no=8, char_index=28
    # Should return the result of string formatting
    position = Position(19, 8, 28)
    result = position.__repr__()
    assert result == "Position(line_no=19, column_no=8, char_index=28)"

    # Test when line_no=27, column_no=7, char_index=72
    # Should return the result of string formatting

# Generated at 2022-06-24 10:34:16.920720
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    # Arrange
    pos = Position(1, 2, 3)
    value = Message(text="text", code="code", key="key", position=pos)

    # Act
    result = value.__repr__()

    # Assert
    assert isinstance(result, str)
    assert result == "Message(text='text', code='code', index=['key'], position=Position(line_no=1, column_no=2, char_index=3))"



# Generated at 2022-06-24 10:34:20.559916
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    test_instance = BaseError()
    test_instance._message_dict = {'a': 1, 'b': 2, 'c': 3}
    assert test_instance['a'] == 1


# Generated at 2022-06-24 10:34:30.553865
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    code = 'max_length'
    text = '...'
    key = 'value'
    start_position = Position(1, 0, 1)
    end_position = Position(1, 0, 1)

    m = Message(code=code, text=text, key=key,
        start_position=start_position, end_position=end_position)
    assert hash(m) == hash((code, (key,)))

    start_position = Position(3, 0, 1)
    end_position = Position(4, 0, 1)
    m2 = Message(code=code, text=text, key=key,
        start_position=start_position, end_position=end_position)
    assert hash(m) != hash(m2)

    key = 'username'

# Generated at 2022-06-24 10:34:34.280231
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    error = BaseError(messages=[Message(text="Test Message")])

    assert error.messages() == [Message(text="Test Message")]

    assert error.messages(add_prefix="Test prefix") == [
        Message(text="Test Message", index=["Test prefix"])
    ]

# Generated at 2022-06-24 10:34:36.411438
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError()
    assert isinstance(error, BaseError)


# Generated at 2022-06-24 10:34:45.892423
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert (
        Position(line_no=1, column_no=2, char_index=3)
        == Position(line_no=1, column_no=2, char_index=3)
    )
    assert not (
        Position(line_no=1, column_no=2, char_index=3)
        == Position(line_no=1, column_no=2, char_index=4)
    )
    assert not (
        Position(line_no=1, column_no=2, char_index=3)
        == Position(line_no=1, column_no=3, char_index=3)
    )

# Generated at 2022-06-24 10:34:50.162566
# Unit test for constructor of class Position
def test_Position():
    # First call to constructor
    Position(1, 2, 3)
    # Second call to constructor
    Position(1, 2, 3)
    # Third call to constructor
    Position(1, 2, 3)


# Generated at 2022-06-24 10:34:55.329540
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    e = BaseError(messages=[Message(text='May not have more than 100 characters', code='max_length', key='username'), Message(text='May not have more than 100 characters', code='max_length', key='password')])
    assert e.__str__() == "{'username': 'May not have more than 100 characters', 'password': 'May not have more than 100 characters'}"


# Generated at 2022-06-24 10:35:02.478795
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    assert list(BaseError(messages=[])) == []
    assert list(BaseError(messages=[Message(text="text")])) == [""]
    assert list(BaseError(messages=[Message(text="text", key="key")])) == ["key"]
    assert list(BaseError(messages=[Message(text="text", index=["a"])])) == ["a"]  # type: ignore
    assert list(BaseError(messages=[Message(text="text", index=["a", "b"])])) == ["a"]  # type: ignore
    assert list(BaseError(messages=[Message(text="text", index=["a", "b", "c"])])) == ["a"]  # type: ignore


# Generated at 2022-06-24 10:35:05.677360
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    assert repr(BaseError(messages=[Message(text='some text')])) == 'BaseError([Message(text=\'some text\', code=\'custom\', index=[])])'


# Generated at 2022-06-24 10:35:15.557329
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    from pprint import pprint
    from io import StringIO
    io = StringIO()
    class_name = 'BaseError'
    code = 'code'
    key = 'key'
    text = 'text'
    index = ['index']
    position = Position('position', 'position', 'position')
    message = Message(text=text, code=code, key=key, position=position)
    message_dict = {message : message.text}
    messages = [message]
    error = BaseError(messages=messages)
    pprint(message_dict, stream=io)
    error_str = str(error)
    print(error)
    assert error_str == io.getvalue()

# Generated at 2022-06-24 10:35:23.787253
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    print("\n test_BaseError___getitem__\n")
    # BaseError with one message

    error = BaseError(text="hello")
    assert error[""] == "hello"
    assert error[None] == "hello"
    assert list(error) == [""]

    error = BaseError(text="hello", key="name")
    assert error["name"] == "hello"
    assert list(error) == ["name"]

    error = BaseError(text="hello", key=[])
    assert error[""] == "hello"
    assert error[None] == "hello"
    assert list(error) == [""]

    error = BaseError(text="hello", key=["name"])
    assert error["name"] == "hello"
    assert error[None] == "hello"
    assert list(error) == ["name"]


# Generated at 2022-06-24 10:35:33.558947
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    def test_messages(input, expected_output, add_prefix):
        result = BaseError(messages=input).messages(add_prefix=add_prefix)
        assert result == expected_output

    test_messages(
        [Message(index=[], text="error1", code="code1"), Message(index=[], text="error2", code="code2")],
        [Message(index=[], text="error1", code="code1"), Message(index=[], text="error2", code="code2")],
        None,
    )