

# Generated at 2022-06-24 10:25:32.509720
# Unit test for constructor of class Position
def test_Position():
    position_1 = Position(
        line_no=1, column_no=2, char_index=3,
    )
    position_2 = Position(
        line_no=1, column_no=2, char_index=4,
    )
    position_3 = Position(
        line_no=1, column_no=2, char_index=3,
    )

    assert position_1 == position_3
    assert position_1 != position_2
    assert position_1.__repr__() == (
        "Position(line_no=1, column_no=2, char_index=3)"
    )


# Generated at 2022-06-24 10:25:38.289088
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    error = BaseError(messages=[
        Message(
            text='My Error Message',
            code='max_length',
            key='key_test',
            position=Position(1, 1, 1)
        )
    ])
    messages = error.messages()
    assert messages == [
        Message(
            text='My Error Message',
            code='max_length',
            key='key_test',
            position=Position(1, 1, 1)
        )
    ]

# Generated at 2022-06-24 10:25:47.459617
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error = BaseError(text='text', code='code', key=1, position=Position(1, 1, 1), messages=[Message(text='text', code='code', key=1, index=[1], position=Position(1, 1, 1))])
    error1 = BaseError(text='text', code='code', key=1, position=Position(1, 1, 1), messages=[Message(text='text', code='code', key=1, index=[1], position=Position(1, 1, 1))])
    assert (error == error1) == True


# Generated at 2022-06-24 10:25:50.884423
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    """
    test_Message___eq__
    """
    msg1 = Message("test_Message___eq__()")
    msg2 = Message("test_Message___eq__()")
    assert msg1 == msg2
    assert msg2 == msg1



# Generated at 2022-06-24 10:25:57.573826
# Unit test for constructor of class Position
def test_Position():
    pos = Position(
        line_no=999, column_no=999, char_index=999
    )
    assert pos.line_no == 999
    assert pos.column_no == 999
    assert pos.char_index == 999
    
    # Other types
    pos = Position(
        line_no='999', column_no='999', char_index='999'
    )
    assert pos.line_no == '999'
    assert pos.column_no == '999'
    assert pos.char_index == '999'


# Generated at 2022-06-24 10:26:06.446387
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    message = Message(text="may not be empty", code="required")
    assert message.__repr__() == "Message(text='may not be empty', code='required')"
    message = Message(text="may not have more than 100 characters", code="max_length", key="username")
    assert message.__repr__() == "Message(text='may not have more than 100 characters', code='max_length', index=['username'])"
    message = Message(text="must be a string", code="type", index=["users", 3, "username"])
    assert message.__repr__() == "Message(text='must be a string', code='type', index=['users', 3, 'username'])"

# Generated at 2022-06-24 10:26:09.179036
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    # Test coverage: 100%
    message = Message(text='Hello')
    assert message.__hash__() == hash(('custom', tuple()))


# Generated at 2022-06-24 10:26:13.221107
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="Testing the method __eq__ of class Message.")
    message2 = Message(text="Testing the method __eq__ of class Message.")
    if message1 == message2:
        print("Both messages are equal")
    else:
        print("Both messages are not equal!")



# Generated at 2022-06-24 10:26:18.916493
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    with pytest.raises(AssertionError):
        text = 'abc'
        code = 'abc'
        key = 'abc'
        position = Position(1,1,1)
        messages = 'abc'
        BaseError(text = text, code = code, key = key, position = position, messages = messages)
        BaseError(text = text, code = code, key = key, position = position)
        BaseError(messages = [Message(text=text, code=code, key=key, position=position)])
        BaseError(messages = [Message(text=text, code=code, key=key, position=position)])
        BaseError(messages = [Message(text=text, code=code, key=key, position=position)])


# Generated at 2022-06-24 10:26:31.158576
# Unit test for constructor of class Message
def test_Message():
    text = 'May not have more than 100 characters'
    code = 'max_length'
    key = 'username'
    index = ['users', 3, 'username']
    start_position = Position(1, 0, 0)
    end_position = Position(1, 100, 100)
    a = Message(text=text, code=code, key=key)
    b = Message(text=text, code=code, index=index)
    c = Message(text=text, code=code, position=start_position)
    d = Message(text=text, code=code, start_position=start_position, end_position=end_position)
    assert (a.text == text)
    assert (b.text == text)
    assert (c.text == text)
    assert (d.text == text)

# Generated at 2022-06-24 10:26:33.291584
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    assert hash(BaseError(text="text", code="code"))
    assert hash(BaseError(messages=[Message(text="text", code="code")]))

# Generated at 2022-06-24 10:26:36.007109
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    result = ValidationResult(value=1)
    assert result == (1, None)
    assert bool(result) == True
    result = ValidationResult(error=ValidationError())
    assert result == (None, ValidationError())
    assert bool(result) == False

# Generated at 2022-06-24 10:26:38.578783
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    p1 = Position(1, 2, 3)
    p2 = Position(1, 2, 3)
    assert p1 == p2
    assert not p1 == None
    assert not p1 == 1
    assert not p1 == [1,2,3]


# Generated at 2022-06-24 10:26:47.596591
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    c_0 = BaseError(messages=[Message(text='length of value must be greater than or equal to 4', code='min_length', index=['password'], start_position=Position(line_no=1,column_no=19,char_index=18),end_position=Position(line_no=1,column_no=55,char_index=54))])
    c_1 = BaseError(messages=[Message(text='length of value must be greater than or equal to 4', code='min_length', index=['password'], start_position=Position(line_no=1,column_no=19,char_index=18),end_position=Position(line_no=1,column_no=55,char_index=54))])
    hash_c = hash(c_0)

# Generated at 2022-06-24 10:26:49.689313
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    val_result = ValidationResult(value=7)
    print(val_result)
    assert str(val_result) == "ValidationResult(value=7)"

# Generated at 2022-06-24 10:26:57.329601
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    m = Message(text="test", code="test", position=Position(1,1,1))
    mg = Message(text="test", code="test", position=Position(1,2,1))
    mh = Message(text="test", code="test", position=Position(1,1,2))
    mk = Message(text="test", code="test", index=['test'])
    ml = Message(text="test", code="test", index=['test', 6])
    mf = Message(text="test", code="test")
    m.__hash__() == mg.__hash__() == mh.__hash__() == mk.__hash__() == ml.__hash__() == mf.__hash__()


# Generated at 2022-06-24 10:27:04.340604
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test when self._messages == other._messages
    self = BaseError(messages=[Message(text="message1")])
    other = BaseError(messages=[Message(text="message1")])
    assert self == other
    # Test when self._messages != other._messages
    self = BaseError(messages=[Message(text="message1")])
    other = BaseError(messages=[Message(text="message2")])
    assert self != other


# Generated at 2022-06-24 10:27:07.471311
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    position = Position(line_no=1, column_no=2, char_index=3)
    assert repr(position) == "Position(line_no=1, column_no=2, char_index=3)"


# Generated at 2022-06-24 10:27:08.585967
# Unit test for constructor of class Message
def test_Message():
    Message("May not have more than 100 characters")



# Generated at 2022-06-24 10:27:11.318687
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    r = BaseError(messages=[Message(text="")])
    assert repr(r) == "BaseError([Message(text='', code='custom', index=[])])"


# Generated at 2022-06-24 10:27:21.227994
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    error1 = BaseError(text="", code="", key=0, position=Position(0, 0, 0), messages=[])
    error2 = BaseError(text="", code="", key=0, position=Position(0, 0, 0), messages=[])
    error3 = BaseError(text="", code="", key=0, position=Position(0, 0, 0), messages=[Message(text="", code="", key=0, position=Position(0, 0, 0), start_position=Position(0, 0, 0), end_position=Position(0, 0, 0))])

    # Verify the __hash__ method is working
    assert {error1: 1}[error1] == 1
    assert {error2: 1}[error2] == 1
    assert {error3: 1}[error3] == 1

# Generated at 2022-06-24 10:27:31.015315
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    assert isinstance(str(BaseError()), str)

# Generated at 2022-06-24 10:27:36.938775
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=None, error=None)
    i = iter(result)
    expected1 = ValidationResult(value=None, error=None).value
    expected2 = ValidationResult(value=None, error=None).error
    actual = next(i)
    assert expected1 == actual
    actual = next(i)
    assert expected2 == actual


# Generated at 2022-06-24 10:27:46.303259
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    class a:
        def __init__(self, *, value: typing.Any = None, error: ValidationError = None) -> None:
            assert value is None or error is None
            self.value = value
            self.error = error
        # __iter__
        def __iter__(self) -> typing.Iterator:
            yield self.value
            yield self.error
        # __repr__
        def __repr__(self) -> str:
            class_name = self.__class__.__name__
            if self.error is not None:
                return f"{class_name}(error={self.error!r})"
            return f"{class_name}(value={self.value!r})"
    
    
    # 1.
    s = a(value = 1)

# Generated at 2022-06-24 10:27:50.140902
# Unit test for constructor of class Position
def test_Position():
    # Initialize the object
    my_pos = Position(1, 2, 0)
    expected = Position(1, 2, 0)

    assert my_pos == expected, "Object should be Position(1, 2, 0)"


# Generated at 2022-06-24 10:27:52.958215
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    assert repr(Message(text='May not have more than 100 characters')) == "Message(text='May not have more than 100 characters', code='custom')"


# Generated at 2022-06-24 10:27:56.066844
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    error = BaseError()
    assert isinstance(error, BaseError)
    assert error.__hash__() is not None
    # TODO: assert_equal(error, error)


# Generated at 2022-06-24 10:28:00.202313
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    e = BaseError(text= 'test_BaseError___repr__')
    assert str(e) == "['test_BaseError___repr__']"
    assert dict(e) == {'': 'test_BaseError___repr__'}, dict(e)

# Generated at 2022-06-24 10:28:04.153405
# Unit test for constructor of class Position
def test_Position():
    position = Position(line_no = 1, column_no = 1, char_index = 1)
    assert isinstance(position, Position) is True
    assert position.line_no == 1
    assert position.column_no == 1
    assert position.char_index == 1


# Generated at 2022-06-24 10:28:08.683347
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='text', code='code', index=[3,4], start_position=Position(1,1,1), end_position=Position(1,1,1))
    message2 = Message(text='text', code='code', index=[3,4], start_position=Position(1,1,1), end_position=Position(1,1,1))
    assert message1 == message2
    assert message1 == message1


# Generated at 2022-06-24 10:28:12.572439
# Unit test for constructor of class BaseError
def test_BaseError():
    message = Message(text='error1', code='custom', key='key1')
    message2 = Message(text='error2', code='custom2', key=2)
    error = BaseError(messages=[message, message2])
    print(error)


# Generated at 2022-06-24 10:28:24.039601
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    messages = [
        Message(text="Error 1", index=[], code="error1"),
        Message(text="Error 2", index=["a"], code="error2"),
        Message(text="Error 3", index=["a", "b"], code="error3"),
        Message(text="Error 4", index=["a", "b", "c"], code="error4"),
        Message(text="Error 5", index=["a", "b", "d"], code="error5"),
        Message(text="Error 6", index=["a", "e"], code="error6"),
        Message(text="Error 7", index=["f"], code="error7"),
    ]
    error = BaseError(messages=messages)
    assert len(error) == 3


# Generated at 2022-06-24 10:28:26.963695
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    assert repr(Message(text="May not have more than 100 characters", key="username")) == "Message(text='May not have more than 100 characters', code='custom', index=['username'])"


# Generated at 2022-06-24 10:28:29.766814
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    value, error = CodeType.validate_or_error("hard")
    assert len(error) == 2


# Generated at 2022-06-24 10:28:32.701226
# Unit test for constructor of class Position
def test_Position():
    position = Position(line_no=1, column_no=1, char_index=0)
    assert position.line_no == 1
    assert position.column_no == 1
    assert position.char_index == 0


# Generated at 2022-06-24 10:28:35.372113
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    assert list(ValidationError(messages=[Message(index=["a"], text="error")])) == ["a"]

# Generated at 2022-06-24 10:28:41.035349
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    assert repr(ValidationResult(value={})) == "ValidationResult(value={})"
    assert repr(ValidationResult(error=ValidationError(text="bad"))) == (
        "ValidationResult(error=ValidationError(text='bad', code='custom'))"
    )
    # End of unit test for method __repr__ of class ValidationResult



# Generated at 2022-06-24 10:28:46.110415
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    e = ValidationError(
        messages=[
            Message(text="my error message", code="my_code", key="my_value"),
            Message(text="my second message", code="my_code", key="my_value"),
        ]
    )
    assert str(e) == "{'': 'my error message'}"
    e = ValidationError(text="my error message")
    assert str(e) == "my error message"



# Generated at 2022-06-24 10:28:49.954071
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    p = Position(line_no=1, column_no=2, char_index=3)
    assert repr(p) == "Position(line_no=1, column_no=2, char_index=3)"


# Generated at 2022-06-24 10:28:53.993043
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    messages = [
        Message(text="Text A", key=0),
        Message(text="Text B", key=1),
        Message(text="Text C", key=2),
    ]
    error = BaseError(messages=messages)
    assert len(error) == 3


# Generated at 2022-06-24 10:29:04.898659
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    # Test equal
    assert Position(line_no=1, column_no=0, char_index=0) == Position(line_no=1, column_no=0, char_index=0)
    assert Position(line_no=1, column_no=1, char_index=1) == Position(line_no=1, column_no=1, char_index=1)
    assert Position(line_no=2, column_no=2, char_index=2) == Position(line_no=2, column_no=2, char_index=2)

    # Test not equal
    assert Position(line_no=1, column_no=0, char_index=0) != Position(line_no=1, column_no=1, char_index=1)

# Generated at 2022-06-24 10:29:12.631006
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    assert hash(Message('max length error')) == hash(Message('max length error'))
    assert hash(Message('max length error', code='max_length')) == hash(Message('max length error', code='max_length'))
    assert hash(Message('max length error', code='max_length')) != hash(Message('max length error', code='max_length2'))
    assert hash(Message('max length error', index=['message'])) == hash(Message('max length error', index=['message']))
    assert hash(Message('max length error', index=['message1'])) != hash(Message('max length error', index=['message2']))


# Generated at 2022-06-24 10:29:17.339070
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    result = ValidationResult(value=5)
    assert repr(result) == "ValidationResult(value=5)"
    result = ValidationResult(error=ValidationError(text="error"))
    assert repr(result) == "ValidationResult(error=ValidationError('error'))"


# Generated at 2022-06-24 10:29:19.101031
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError() == BaseError()


# Generated at 2022-06-24 10:29:21.614183
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    

    count = 0
    try:
        BaseError()
    except Exception as ex:
        count = count + 1
        print(ex)
    assert count == 1





# Generated at 2022-06-24 10:29:26.127580
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    def run(line_no: int, column_no: int, char_index: int) -> None:
        try:
            Position(line_no, column_no, char_index)
            assert False
        except AssertionError:
            raise
        except:
            pass

    run(1, 2, 3)


# Generated at 2022-06-24 10:29:37.730907
# Unit test for constructor of class BaseError
def test_BaseError():
    error = BaseError(
        text="Test error",
        code="code",
        key="key"
    )

    assert error.messages()[0].text == "Test error"
    assert error.messages()[0].code == "code"
    assert error.messages()[0].key == "key"

    error2 = BaseError(
        messages=[Message(
            text="Test error",
            code="code",
            key="key"
        )]
    )

    assert error2.messages()[0].text == "Test error"
    assert error2.messages()[0].code == "code"
    assert error2.messages()[0].key == "key"


# Generated at 2022-06-24 10:29:43.673693
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    e = BaseError(text="error1")
    assert str(e) == "error1"
    e = BaseError(messages=[Message(text="error1")])
    assert str(e) == "{'': 'error1'}"
    e = BaseError(messages=[Message(text="error1", key="key1")])
    assert str(e) == "{'key1': 'error1'}"

# Generated at 2022-06-24 10:29:47.109962
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result1 = ValidationResult(value=[1, 2, 3])
    print(list(result1))
    result2 = ValidationResult(error=ValidationError(text='Invalid price'))
    print(list(result2))


# Generated at 2022-06-24 10:29:49.586894
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    p = Position(1, 2, 3)
    assert repr(p) == "Position(line_no=1, column_no=2, char_index=3)"


# Generated at 2022-06-24 10:29:57.017609
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result = ValidationResult(error=ValidationError())
    assert isinstance(validation_result.__iter__(), typing.Iterator)
    assert list(validation_result) == [None, validation_result.error]
    validation_result = ValidationResult(value=1)
    assert isinstance(validation_result.__iter__(), typing.Iterator)
    assert list(validation_result) == [validation_result.value, None]

test_ValidationResult___iter__()


# Generated at 2022-06-24 10:30:08.400844
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    # test_Message___repr__#1
    m = Message(text='text', code='code', index=['a','b','c'], start_position=Position(0,0,0), end_position=Position(0,0,0))
    assert m == eval(repr(m))
    # test_Message___repr__#2
    m = Message(text='text', code='code', index=None, start_position=None, end_position=None)
    assert m == eval(repr(m))
    # test_Message___repr__#3
    m = Message(text='text', code='code', index=None, position=Position(0,0,0))
    assert m == eval(repr(m))
    # test_Message___repr__#4

# Generated at 2022-06-24 10:30:10.048167
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    error = BaseError(text='text', code='code', key='key')
    assert len(error) == 0


# Generated at 2022-06-24 10:30:14.599930
# Unit test for constructor of class BaseError
def test_BaseError():
    err = BaseError(text="error message", code="code")
    assert err.messages() == [Message(text="error message", code="code")]
    assert not err
    assert err.messages() == [Message(text="error message", code="code")]
    assert err.text == "error message"
    assert err.code == "code"
    repr(err)
    str(err)



# Generated at 2022-06-24 10:30:17.994400
# Unit test for constructor of class Position
def test_Position():
    my_position = Position(1, 1, 1)
    assert my_position.line_no == 1
    assert my_position.column_no == 1
    assert my_position.char_index == 1


# Generated at 2022-06-24 10:30:26.213397
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    def check(text, code, key, position, expected_hash):
        message = Message(text=text, code=code, key=key, position=position)
        error = BaseError(messages=[message])
        assert hash(error) == expected_hash

    check("message", "code", "key", Position(1, 2, 3), -223732076)
    check("message", "code", "key", None, -294620707)
    check("message", "code", None, Position(1, 2, 3), -223732076)
    check("message", "code", None, None, -294620707)
    check("message", None, "key", Position(1, 2, 3), -223732076)
    check("message", None, "key", None, -294620707)

# Generated at 2022-06-24 10:30:29.920743
# Unit test for constructor of class Position
def test_Position():
    pos = Position(3, 1, 0)
    if pos.line_no == 3 and pos.column_no == 1 and pos.char_index == 0:
        print("success")
    else:
        print("fail")

# test_Position()


# Generated at 2022-06-24 10:30:37.648417
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(
        text="Must have maximum length of 100 characters",
        code="max_length",
        key="username",
        position=Position(1, 5, 2),
    ) == Message(
        text="Must have maximum length of 100 characters",
        code="max_length",
        key="username",
        position=Position(1, 5, 2),
    )
    assert Message(
        text="Must have maximum length of 100 characters",
        code="max_length",
        key="username",
        position=Position(1, 5, 2),
    ) != Message(
        text="Must have maximum length of 100 characters",
        code="max_length",
        key="username",
        position=Position(1, 4, 1),
    )

# Generated at 2022-06-24 10:30:38.745018
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    error = BaseError()
    assert not list(error)

# Generated at 2022-06-24 10:30:40.529474
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    # Given
    validation_result = ValidationResult()
    if not validation_result:
        raise Exception("no validation result")


# Generated at 2022-06-24 10:30:42.301841
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1,2,3) != Position(1,2,4)

# Generated at 2022-06-24 10:30:46.909294
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    assert hash(ValidationError(text='msg')) == hash(ValidationError(text='msg'))
    assert hash(ValidationError(text='msg')) != hash(ValidationError(text='msg', code='abc'))
    assert hash(BaseError(text='msg', key='abc')) == hash(BaseError(text='msg', index=['abc']))

# Generated at 2022-06-24 10:30:53.288773
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    vr = ValidationResult(value = '123')
    print(vr.value)
    vr = ValidationResult(error = 'error')
    print(vr.error)
    print(bool(vr))
    print(repr(vr))
    vr = ValidationResult(value = '123', error= 'error')
    print(repr(vr))

test_ValidationResult()

# Generated at 2022-06-24 10:30:56.338543
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    true_result = ValidationResult(value=None)
    assert bool(true_result) == True
    false_result = ValidationResult(error=None)
    assert bool(false_result) == False


# Generated at 2022-06-24 10:30:58.639784
# Unit test for constructor of class ValidationError
def test_ValidationError():
    error = ValidationError(text="Error Message")
    assert error.start_position is None
    assert error.end_position is None


# Example for class ValidationResult

# Generated at 2022-06-24 10:31:04.549213
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    pos1 = Position(line_no=1, column_no=2, char_index=3)
    pos2 = Position(line_no=1, column_no=2, char_index=3)
    print(pos1 == pos2)

test_Position___eq__()



# Generated at 2022-06-24 10:31:06.754019
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    with pytest.raises(IndexError):
        # Here we invoke function __getitem__ of class BaseError with
        # argument key = []. Since BaseError._message_dict = {},
        # we expect to catch an IndexError exception.
        BaseError().__getitem__([])

# Generated at 2022-06-24 10:31:15.570521
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    obj = BaseError(text='Text', code='Code', key=10, position=Position(
        line_no=1, column_no=1, char_index=1), messages=[Message(text='Text', code='Code', key=10, index=[1, 2], position=Position(
        line_no=1, column_no=1, char_index=1), start_position=Position(
        line_no=1, column_no=1, char_index=1), end_position=Position(
        line_no=1, column_no=1, char_index=1))])

    assert isinstance(obj, BaseError)

# Generated at 2022-06-24 10:31:19.967628
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    assert repr(BaseError(text="Sample error message", code="custom", key=4, position=Position(1,2,3))) == "BaseError(text='Sample error message', code='custom', index=[4])"
    print("test_BaseError___repr__ ok")


# Generated at 2022-06-24 10:31:24.153783
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    message = Message(
        code="max_length", index=[1], text="May not have more than 100 characters"
    )
    expected_result = hash((("max_length", (1,)),))
    actual_result = hash(message)
    assert actual_result == expected_result


# Generated at 2022-06-24 10:31:27.436663
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    pos1 = Position(1, 1, 10)
    pos1_bis = Position(1, 1, 10)
    assert pos1 == pos1_bis
    assert pos1 == pos1
    pos2 = Position(1, 2, 10)
    assert not (pos1 == pos2)


# Generated at 2022-06-24 10:31:39.397523
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    line_no_pos = 10
    column_no_pos = 20
    char_index_pos = 30

    line_no_pos2 = 10
    column_no_pos2 = 20
    char_index_pos2 = 30

    line_no_neg = 15
    column_no_neg = 25
    char_index_neg = 35

    position = Position(line_no_pos, column_no_pos, char_index_pos)
    position2 = Position(line_no_pos2, column_no_pos2, char_index_pos2)
    position3 = Position(line_no_neg, column_no_neg, char_index_neg)

    assert position == position
    assert position == position2
    assert position != position3


# Generated at 2022-06-24 10:31:49.973059
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    import unittest

    class BaseError___eq__Tests(unittest.TestCase):
        def test_equal(self):

            self.assertEqual(
                ValidationError(text="Text", code="code", key="key"),
                ValidationError(text="Text", code="code", key="key"),
            )

            self.assertEqual(
                ValidationError(
                    messages=[Message(text="Text", code="code", key="key")]
                ),
                ValidationError(
                    messages=[Message(text="Text", code="code", key="key")]
                ),
            )


# Generated at 2022-06-24 10:32:01.771561
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    class TestHash:
        def __hash__(self):
            return 1

    assert hash(BaseError()) == hash(BaseError())
    error = BaseError(text="error1")
    assert hash(error) != hash(BaseError())
    error2 = BaseError(text="error1")
    assert hash(error) == hash(error2)

    error3 = BaseError(messages=[Message(text="text1")])
    assert hash(error3) == hash(BaseError(messages=[Message(text="text1")]))
    assert hash(error3) != hash(BaseError(messages=[Message(text="text2")]))

    error4 = BaseError(messages=[Message(text="text1", code="code1")])

# Generated at 2022-06-24 10:32:04.670001
# Unit test for constructor of class ParseError
def test_ParseError():
    temp_ParseError = ParseError(text="text", code="code", key="key", position="position")
    assert temp_ParseError.text == "text"
    assert temp_ParseError.code == "code"
    assert temp_ParseError.key == "key"
    assert temp_ParseError.position == "position"


# Generated at 2022-06-24 10:32:08.922404
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert list(ValidationResult(value=1)) == [1, None]
    assert list(ValidationResult(error=ValidationError())) == [None, ValidationError()]

# Generated at 2022-06-24 10:32:15.675415
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    import json
    msg = BaseError(text='msg_text', code='msg_code', key='msg_key', position='msg_position')
    assert msg == BaseError(text='msg_text', code='msg_code', key='msg_key', position='msg_position')
    assert not msg == BaseError(text='not_msg_text', code='not_msg_code', key='not_msg_key', position='not_msg_position')
    print(json.dumps(msg, default=lambda o: o.__dict__, sort_keys=True, indent=4))

# Generated at 2022-06-24 10:32:17.920597
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    # Unit test for method __hash__
    # of class BaseError
    message = Message(text="", code="", key=None)
    error = BaseError(messages=[message])
    assert hash(BaseError(messages=[message])) == hash(error)


# Generated at 2022-06-24 10:32:20.761207
# Unit test for constructor of class Position
def test_Position():
    position = Position(1,2,3)
    assert position.line_no == 1
    assert position.column_no == 2
    assert position.char_index == 3



# Generated at 2022-06-24 10:32:23.425570
# Unit test for constructor of class BaseError
def test_BaseError():
    message = Message("foo")
    error = BaseError(messages=[message])
    assert dict(error) == dict({"": "foo"})

# Generated at 2022-06-24 10:32:32.093911
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    expect_message1 = "test error message"
    expect_message2 = "test error message2"
    expect_message3 = "test error message3"
    error = BaseError(text = expect_message1 )
    assert str(error) == expect_message1
    error2 = BaseError(text = expect_message2 , key = "test_key1" )
    error3 = BaseError(text = expect_message3 , key = "test_key2" )
    error4 = BaseError(messages = [error2, error3])
    assert str(error4) == "{'test_key1': 'test error message2', 'test_key2': 'test error message3'}"
    

# Generated at 2022-06-24 10:32:34.989640
# Unit test for constructor of class Position
def test_Position():
    p1 = Position(1, 2, 3)
    p2 = Position(1, 2, 3)
    assert p1 == p2


# Generated at 2022-06-24 10:32:40.658679
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(line_no=0, column_no=0, char_index=0) == Position(
        line_no=0, column_no=0, char_index=0
    )
    assert Position(line_no=0, column_no=0, char_index=0) != Position(
        line_no=1, column_no=0, char_index=0
    )
    assert Position(line_no=0, column_no=0, char_index=0) != Position(
        line_no=0, column_no=1, char_index=0
    )
    assert Position(line_no=0, column_no=0, char_index=0) != Position(
        line_no=0, column_no=0, char_index=1
    )


# Generated at 2022-06-24 10:32:41.958568
# Unit test for constructor of class ParseError
def test_ParseError():
  assert True


# Generated at 2022-06-24 10:32:44.406235
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    error = BaseError(
        text="An error", code="some_code", key="key1"
    )
    ref = "An error"
    assert error["key1"] == ref

# Generated at 2022-06-24 10:32:49.721326
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='May not have more than 100 characters', code='max_length', key='username')
    message2 = Message(text='May not have more than 100 characters', code='max_length', key='username')
    message3 = Message(text='May not have more than 100 characters', code='min_length', key='username')
    message4 = Message(text='May not have more than 100 characters', code='max_length', key='password')
    assert message1 == message2
    assert message1 != message3
    assert message1 != message4

# Generated at 2022-06-24 10:32:53.076879
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
  expected_response = 'ValidationResult(value={})'
  response = ValidationResult(value={})
  assert response.__repr__() == expected_response

# Generated at 2022-06-24 10:32:59.124332
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error = BaseError(
        text="May not have more than 100 characters",
        code="max_length",
        key="username",
        position=Position(line_no=1, column_no=7, char_index=6),
    )
    # Actual output (class BaseError, method __eq__): <__main__.BaseError object at 0x7f3b22c72b80>
    print("Actual output (class BaseError, method __eq__):", error.__eq__)


# Generated at 2022-06-24 10:33:02.021487
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    assert repr(ValidationResult(value=None, error=None)) == 'ValidationResult(error=None)'
    assert repr(ValidationResult(value=123, error=None)) == 'ValidationResult(value=123)'

# Generated at 2022-06-24 10:33:12.651127
# Unit test for constructor of class Message
def test_Message():
    message = Message(text="a", index=[0, 1], code="custom")
    assert message.text == "a"
    assert message.index == [0, 1]
    assert message.code == "custom"

    message = Message(text="a", start_position=Position(1, 2, 3))
    assert message.text == "a"
    assert message.start_position == Position(1, 2, 3)
    assert message.end_position == Position(1, 2, 3)

    message = Message(text="a", start_position=Position(1, 2, 3), end_position=Position(4, 5, 6))
    assert message.text == "a"
    assert message.start_position == Position(1, 2, 3)
    assert message.end_position == Position(4, 5, 6)

# Generated at 2022-06-24 10:33:23.052128
# Unit test for method __getitem__ of class BaseError

# Generated at 2022-06-24 10:33:27.275863
# Unit test for constructor of class Message
def test_Message():
    message = Message(text="The current value is not a string")
    assert message.text == "The current value is not a string"
    assert message.code == "custom"
    assert message.index == []
    assert message.start_position is None
    assert message.end_position is None


# Generated at 2022-06-24 10:33:31.308300
# Unit test for constructor of class Message
def test_Message():
    m = Message(text="t", code="c", index=[1,2])
    assert m.text == "t"
    assert m.code == "c"
    assert m.index == [1,2]


# Generated at 2022-06-24 10:33:33.062010
# Unit test for constructor of class ValidationError
def test_ValidationError():
    with pytest.raises(AssertionError):
        ValidationError()

# Generated at 2022-06-24 10:33:37.619231
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    assert ValidationError(text='text').messages() == [Message(text='text')]
    assert ValidationError(text='text', code='code').messages() == [Message(text='text', code='code')]
    assert ValidationError(text='text', code='code', key='key').messages() == [Message(text='text', code='code', key='key')]


# Generated at 2022-06-24 10:33:39.157245
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    assert bool(ValidationResult(value=1)) is True
    assert bool(ValidationResult(error=ValidationError())) is False



# Generated at 2022-06-24 10:33:46.120173
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="test message", code="code", index=[1, 2, 3], position="position")
    message2 = Message(text="test message", code="code", index=[1, 2, 3], position="position")
    message3 = Message(text="test message", code="code", index=[1, 2, 3])

    assert message1 == message2
    assert message1 != message3


# Generated at 2022-06-24 10:33:55.435320
# Unit test for constructor of class Message
def test_Message():
    expected = Message(text='May not have more than 100 characters',
                       code='max_length',
                       key='username',
                       position=Position(1, 1, 0),
                       start_position=Position(2, 3, 0),
                       end_position=Position(4, 5, 5))

    actual = Message(text='May not have more than 100 characters',
                     code='max_length',
                     key='username')

    # Check all fields are equal
    assert expected.text == actual.text
    assert expected.code == actual.code
    assert expected.key == actual.key
    assert expected.position == actual.position
    assert expected.start_position == actual.start_position
    assert expected.end_position == actual.end_position



# Generated at 2022-06-24 10:33:58.326167
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    value, error = validate_or_error(1, int)
    assert isinstance(value, ValidationResult)
    assert isinstance(error, ValidationResult)
    assert bool(value)
    assert not bool(error)
    assert value.error is None
    assert error.error is not None

# Generated at 2022-06-24 10:34:02.358714
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    message1 = BaseError("abc", "code", "key");
    message2 = BaseError("def", "code", "key");
    assert hash(message1) != hash(message2)
    message1 = BaseError("abc", "code", "key");
    message2 = BaseError(messages= Message("abc", "code", "key"));
    assert hash(message1) == hash(message2)

# Generated at 2022-06-24 10:34:05.643545
# Unit test for constructor of class ValidationError
def test_ValidationError():
    e1 = ValidationError(text='invalid', code='min_value')
    e2 = ValidationError(text='invalid', code='min_value')
    print(e1 == e2)

# Generated at 2022-06-24 10:34:09.084236
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    result = ValidationResult(value=1)
    assert bool(result) is True

    result = ValidationResult(error=ValidationError(text="Some error"))
    assert bool(result) is False



# Generated at 2022-06-24 10:34:17.319288
# Unit test for constructor of class BaseError
def test_BaseError():

    error = BaseError(text="text")
    assert error.messages() == [
        Message(text="text")
    ]
    assert error.text == "text"
    assert error.code == "custom"
    assert error.key == ""

    error = BaseError(text="text1", code="code1")
    assert error.messages() == [
        Message(text="text1", code="code1")
    ]
    assert error.text == "text1"
    assert error.code == "code1"
    assert error.key == ""

    error = BaseError(text="text2", key="key2")
    assert error.messages() == [
        Message(text="text2", key="key2")
    ]
    assert error.text == "text2"
    assert error.code == "custom"


# Generated at 2022-06-24 10:34:24.490532
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    value = 'value'
    error = ValidationError(text='error')
    result = ValidationResult(value=value)
    expected_value = value
    expected_error = None
    assert (result.value == expected_value) and (result.error == expected_error)
    result = ValidationResult(error=error)
    expected_value = None
    expected_error = error
    assert (result.value == expected_value) and (result.error == expected_error)

# Generated at 2022-06-24 10:34:33.270518
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    assert hash(Message(text="text", index=[1, 2])) == hash(
        Message(text="text", index=[1, 2])
    )
    assert hash(Message(text="text", index=[1, 2])) == hash(
        Message(text="text", index=[1, 2])
    )
    assert hash(Message(text="text", index=[1, 2])) != hash(
        Message(text="text", index=[1, 2, 3])
    )
    assert hash(Message(text="text", index=[1, 2])) != hash(
        Message(text="text", index=[1, 2, 3])
    )
    assert hash(Message(text="text", index=[1, 2])) != hash(
        Message(text="text", index=[1, 2], code="custom")
    )
   

# Generated at 2022-06-24 10:34:40.263809
# Unit test for constructor of class BaseError
def test_BaseError():
    # test BaseError with a single message
    error = BaseError(text="xx")
    assert error._messages == [Message(text="xx")]
    assert {"" : "xx"} == error._message_dict

    # test BaseError with multiple messages
    error = BaseError(messages=[Message(text="xx"), Message(text="yy")])
    assert error._messages == [Message(text="xx"), Message(text="yy")]
    assert {"" : ["xx", "yy"]} == error._message_dict

# Generated at 2022-06-24 10:34:41.980555
# Unit test for constructor of class Position
def test_Position():
    p = Position(1,2,3)
    assert p.line_no == 1
    assert p.column_no == 2
    assert p.char_index == 3
    
#Unit test for constructor of class Message

# Generated at 2022-06-24 10:34:46.697922
# Unit test for constructor of class ValidationError
def test_ValidationError():
    assert repr(ValidationError(text='error1', code='code', key='key', position=Position(line_no=1, column_no=3, char_index=4))) == "ValidationError(text='error1', code='code')"

    assert repr(ValidationError(messages=[Message(text='error1', code='code', key='key', position=Position(line_no=1, column_no=3, char_index=4))])) == "ValidationError([Message(text='error1', code='code', key='key', position=Position(line_no=1, column_no=3, char_index=4))])"
    

# Generated at 2022-06-24 10:34:50.209135
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    assert bool(ValidationResult(value=1)) is True
    assert bool(ValidationResult(error=ValidationError(text="error"))) is False


# Generated at 2022-06-24 10:34:57.068042
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    value = [1,2,3]
    result = ValidationResult(value=value)
    assert len(result) == 2
    assert result.value == value
    assert result.error is None
    assert bool(result)
    print(result)

    error = ValidationError()
    result = ValidationResult(error=error)
    assert len(result) == 2
    assert result.value is None
    assert result.error == error
    assert not bool(result)
    print(result)


if __name__ == "__main__":
    test_ValidationResult()

# Generated at 2022-06-24 10:35:00.192168
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    o = BaseError()
    o._messages = []
    o._message_dict = {}
    assert o.messages() == []
    with raises(KeyError):
        o[""]


# Generated at 2022-06-24 10:35:02.106958
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    message = Message(text='test_hash')
    assert hash(message) == hash(('custom', ('test_hash',)))

# Generated at 2022-06-24 10:35:05.639773
# Unit test for constructor of class Position
def test_Position():
    test = Position(0,0,0)
    assert test.line_no == 0
    assert test.column_no == 0
    assert test.char_index == 0
    print('Pass test for constructor of class Position')


# Generated at 2022-06-24 10:35:10.676330
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    pos1 = Position(1, 2, 3)
    pos2 = Position(1, 2, 3)
    pos3 = Position(4, 5, 6)

    assert pos1 == pos2
    assert pos2 == pos1
    assert not (pos1 == pos3)
    assert not (pos3 == pos1)


# Generated at 2022-06-24 10:35:14.043417
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    # test __init__
    assert ValidationResult(value=None, error=None)
    assert ValidationResult(value=None, error="")
    assert ValidationResult(value="", error=None)

# Generated at 2022-06-24 10:35:16.563960
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    v = ValidationResult(value=1)
    assert repr(v) == "ValidationResult(value=1)"



# Generated at 2022-06-24 10:35:19.507977
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    assert repr(ValidationResult(value=100)) == "ValidationResult(value=100)"
    assert repr(ValidationResult(error=ValidationError(text="oops"))) == "ValidationResult(error=ValidationError(text='oops'))"

# Generated at 2022-06-24 10:35:25.387163
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    """
    Basic test for method __hash__ of class Message
    """
    # AssertError.__hash__(self, **kwargs: typing.Any) -> int
    class_name = "Message"
    hash_value = 1
    assert 1 == hash_value, f"{class_name} method __hash__ return value error, should be {1}, actually {hash_value}"


# Generated at 2022-06-24 10:35:28.571699
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    error = BaseError(text="custom message")
    assert str(error) == "custom message"
    error = BaseError(messages=[Message(text="custom message")])
    assert str(error) == "custom message"
