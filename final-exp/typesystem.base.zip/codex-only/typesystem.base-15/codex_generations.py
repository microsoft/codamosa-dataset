

# Generated at 2022-06-24 10:25:37.527620
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(3, 5, 7) == Position(3, 5, 7)
    assert not Position(3, 4, 7) == Position(3, 5, 7)
    assert not Position(2, 5, 7) == Position(3, 5, 7)
    assert not Position(3, 5, 8) == Position(3, 5, 7)
    assert not Position(3, 5, 7) == 5


# Generated at 2022-06-24 10:25:40.186969
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    msg = Message(text="May not have more than 100 characters", code="max_length")
    val_err = BaseError(messages=[msg])
    assert repr(val_err) == 'BaseError([Message(text=\'May not have more than 100 characters\', code=\'max_length\', index=[])])'

# Generated at 2022-06-24 10:25:43.308603
# Unit test for constructor of class Position
def test_Position():
    position1 = Position(1, 2, 3)
    position2 = Position(1, 2, 3)
    assert position1 == position2
    assert repr(position1) == "Position(line_no=1, column_no=2, char_index=3)"


# Generated at 2022-06-24 10:25:50.316160
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    value = 'some value'

    vr = ValidationResult(value=value)
    res1 = list(vr)
    assert res1[0] == value
    assert res1[1] == None

    vr = ValidationResult(error=ValueError())
    res2 = list(vr)
    assert res2[0] == None
    assert res2[1] == ValueError

    assert res1 != res2


# Generated at 2022-06-24 10:25:54.765392
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    Message(text="text", code="code", index=["index"], position="position")
    Message(text="text", code="code", index=["index"], start_position="start_position", end_position="end_position")
    Message(text="text", code="code")
    Message(text="text")
    Message()



# Generated at 2022-06-24 10:25:59.169669
# Unit test for constructor of class Position
def test_Position():
    assert Position(0,1,2) == Position(0,1,2)
    assert Position(0,1,2) != Position(1,1,2)
    assert Position(0,1,2) != Position(0,2,2)
    assert Position(0,1,2) != Position(0,1,3)



# Generated at 2022-06-24 10:26:05.689436
# Unit test for constructor of class Message
def test_Message():
    pos = Position(5, 6, 7)
    msg = Message(text="some text", key="some key", code="some code", position=pos)
    assert msg.text == "some text"
    assert msg.code == "some code"
    assert msg.index == ["some key"]
    assert msg.start_position == pos
    assert msg.end_position == pos



# Generated at 2022-06-24 10:26:15.223030
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    def __eq__(self, other: typing.Any) -> bool:
        return isinstance(other, Message) and (
            self.text == other.text
            and self.code == other.code
            and self.index == other.index
            and self.start_position == other.start_position
            and self.end_position == other.end_position
        )


# Generated at 2022-06-24 10:26:23.768969
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    error = BaseError(
        text='May not have more than 100 characters',
        code='max_length',
        key='username'
    )
    assert error.messages() == [
        Message(text='May not have more than 100 characters', code='max_length', key='username')
    ]
    assert error.messages(add_prefix='users') == [
        Message(text='May not have more than 100 characters', code='max_length', index=['users', 'username'])
    ]

test_BaseError_messages()

# Generated at 2022-06-24 10:26:27.770772
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    foo_v, foo_e = ValidationResult(value=True)
    bar_v, bar_e = ValidationResult(error=True)
    assert foo_v and not bar_e, "Expected True, False"



# Generated at 2022-06-24 10:26:37.490756
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    # 
    # The output will be:
    # 
    # 1. ('Max length is 4', 'max_length')
    # 2. ('max_length', ('name',))
    # 3. ('max_length', ('user', 0, 'age'))
    # 4. ('max_length', ('user', 1, 'age'))
    # 5. ('max_length', ('user', 'age', 2))
    # 
    err_1 = BaseError(text='Max length is 4', code='max_length')
    assert hash(err_1) == hash(('Max length is 4', 'max_length'))
    err_2 = BaseError(text='Max length is 4', code='max_length', key='name')
    assert hash(err_2) == hash(('max_length', ('name',)))


# Generated at 2022-06-24 10:26:40.114522
# Unit test for constructor of class Position
def test_Position():
    input_value = Position(1, 2, 3)
    assert input_value.line_no == 1
    assert input_value.column_no == 2
    assert input_value.char_index == 3


# Generated at 2022-06-24 10:26:43.841292
# Unit test for constructor of class ValidationError
def test_ValidationError():
    error = ValidationError(
        text="Not a valid", code="code", key="key", position=1
    )
    assert error.messages() == [
        Message(text="Not a valid", code="code", key="key", position=1)
    ]
    assert error._message_dict == {"key": "Not a valid"}

# Generated at 2022-06-24 10:26:53.592984
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    line_no1 = 2
    column_no1 = 3
    char_index1 = 4
    position1 = Position(line_no1, column_no1, char_index1)

    line_no2 = 2
    column_no2 = 3
    char_index2 = 4
    position2 = Position(line_no2, column_no2, char_index2)

    assert position1 == position2

    line_no3 = 3
    column_no3 = 3
    char_index3 = 4
    position3 = Position(line_no3, column_no3, char_index3)

    assert position1 != position3

    line_no4 = 2
    column_no4 = 4
    char_index4 = 4
    position4 = Position(line_no4, column_no4, char_index4)

# Generated at 2022-06-24 10:26:57.897944
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 1, 1) == Position(1, 1, 1)
    assert not Position(1, 1, 1) == Position(2, 1, 1)
    assert not Position(1, 1, 1) == Position(1, 2, 1)
    assert not Position(1, 1, 1) == Position(1, 1, 2)


# Generated at 2022-06-24 10:27:03.109801
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    # Just to check at least one character of expected string is present
    actual = Position(line_no=1, column_no=2, char_index=3).__repr__()
    assert 'line_no=1' in actual
    assert 'column_no=2' in actual
    assert 'char_index=3' in actual


# Generated at 2022-06-24 10:27:10.047216
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    e = BaseError()
    assert e._message_dict == {}
    assert e.messages() == []

    e = BaseError(text="foo", key="bar")
    assert e._message_dict == {"bar": "foo"}
    assert e.messages() == [Message(text="foo", key="bar")]

    e = BaseError(messages=[Message(text="a", key="a"), Message(text="b", key="b")])
    assert e._message_dict == {"a": "a", "b": "b"}
    assert e.messages() == [Message(text="a", key="a"), Message(text="b", key="b")]



# Generated at 2022-06-24 10:27:12.951472
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    # Given
    data = {'username': 'abc'}
    error = ValidationError(text='abc', key='username')
    # When
    actual = list(error)
    # Then
    expected = ['abc']
    assert actual == expected


# Generated at 2022-06-24 10:27:20.657018
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    assert len(BaseError({})) == 0
    assert len(BaseError({"username": "Not a valid username"})) == 1
    assert len(BaseError({"username": "Not a valid username"}, {"password": "Not a valid password"})) == 2
    assert len(BaseError({"username": "Not a valid username"}, {"password": "Not a valid password"}, {"email": "Not a valid email"})) == 3
    assert len(BaseError({"username": "Not a valid username"}, {"password": "Not a valid password"}, {"email": "Not a valid email"}, {"phone": "Not a valid phone"})) == 4


# Generated at 2022-06-24 10:27:23.142169
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    foo = ValidationResult()
    assert not foo
    foo.error = ValidationError(messages=[Message(text='foo')])
    assert foo


# Generated at 2022-06-24 10:27:27.493222
# Unit test for constructor of class BaseError
def test_BaseError():
    error = BaseError(key="age", text="May not be over 10.")
    assert error["age"] == "May not be over 10."

    error = BaseError(key="age", text="Must be a positive integer.")
    assert error["age"] == "Must be a positive integer."



# Generated at 2022-06-24 10:27:37.392924
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(text = "Text1",
                    code = "Code1",
                    key = "k1")
    error2 = BaseError(text = "Text1",
                    code = "Code1",
                    key = "k1")
    error3 = BaseError(text = "Text2",
                    code = "Code1",
                    key = "k1")
    error4 = BaseError(text = "Text2",
                    code = "Code2",
                    position = Position(1,1,1))
    result = error1 == error2
    expected = True
    assert result == expected
    result = error1 == error3
    expected = False
    assert result == expected
    result = error4 == error4
    expected = True
    assert result == expected


# Generated at 2022-06-24 10:27:46.574685
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    code = 'max_length'
    text = 'May not have more than 100 characters'
    line_no = 0
    column_no = 1
    char_index = 2
    position = Position(line_no, column_no, char_index)
    start_position = Position(line_no + 2, column_no + 2, char_index + 2)
    end_position = Position(line_no + 3, column_no + 3, char_index + 3)


# Generated at 2022-06-24 10:27:49.991593
# Unit test for constructor of class Position
def test_Position():
    assert Position(line_no=1, column_no=2, char_index=3) == Position(
        line_no=1, column_no=2, char_index=3
    )


# Generated at 2022-06-24 10:27:57.863144
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    messages=[Message(text='message1', code=None, key=None, index=None, position=Position(1,2,3)),
              Message(text='message2', code=None, key=None, index=None, position=Position(1,2,3)),
              Message(text='message3', code=None, key=None, index=None, position=Position(1,2,3))]
    err = BaseError(messages=messages)

    assert err['0'] == err[0] == 'message1'
    assert err['1'] == err[1] == 'message2'
    assert err['2'] == err[2] == 'message3'
    assert err['3'] == err[3] == {}


# Generated at 2022-06-24 10:28:01.818129
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    b = BaseError(text="text", code="code", key="key", position="position", messages="messages")
    assert b.__repr__() == 'BaseError(text="text", code="code", key="key", position="position", messages="messages")'



# Generated at 2022-06-24 10:28:06.273372
# Unit test for constructor of class Position
def test_Position():
    pos = Position(0, 0, 0)
    assert pos.line_no == 0
    assert pos.column_no == 0
    assert pos.char_index == 0
    assert pos != '0'
    assert repr(pos)=='Position(line_no=0, column_no=0, char_index=0)'



# Generated at 2022-06-24 10:28:16.315541
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    first = Message("Text", code = "code", index=[1, 2, 3])
    second = Message("Text", code = "code", index=[1, 2, 3])
    assert first == second

    first = Message("Text", code = "code2", index=[1, 2, 3])
    second = Message("Text", code = "code", index=[1, 2, 3])
    assert not(first == second)

    first = Message("Text", code = "code", index=[1, 2, 3])
    second = Message("Text2", code = "code", index=[1, 2, 3])
    assert not(first == second)

    first = Message("Text", code = "code", index=[1, 3, 3])
    second = Message("Text", code = "code", index=[1, 2, 3])

# Generated at 2022-06-24 10:28:27.552990
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    def check(text, code, key, index, start_position, end_position, right_value):
        message1 = Message(text=text, code=code, key=key, index=index, start_position=start_position, end_position=end_position)
        message2 = Message(text=text, code=code, key=key, index=index, start_position=start_position, end_position=end_position)
        return (message1 == message2) == right_value

# Generated at 2022-06-24 10:28:29.242145
# Unit test for constructor of class Position
def test_Position():
    assert Position(1,2,3) == Position(1,2,3)
    assert Position(1,2,3) != Position(4,5,6)


# Generated at 2022-06-24 10:28:39.797275
# Unit test for constructor of class ValidationError
def test_ValidationError():
    # Test with a single, text message
    error = ValidationError(text="Hello, World!")
    assert str(error) == "Hello, World!"
    assert error.messages() == [Message(text="Hello, World!")]

    # Test with a single, text message and a key
    error = ValidationError(text="Hello, World!", key="username")
    assert str(error) == "{'username': 'Hello, World!'}"
    assert error.messages() == [Message(text="Hello, World!", key="username")]

    # Test with a single, text message, a key and a code
    error = ValidationError(text="Hello, World!", key="username", code="bad")
    assert str(error) == "{'username': 'Hello, World!'}"

# Generated at 2022-06-24 10:28:46.559925
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    assert repr(BaseError(text='text0', code='code0', key='key0', position=Position(1, 1, 1))) == \
           "BaseError(text='text0', code='code0', index=['key0'], start_position=Position(line_no=1, column_no=1, char_index=1), end_position=Position(line_no=1, column_no=1, char_index=1))"

# Generated at 2022-06-24 10:28:48.837846
# Unit test for constructor of class Position
def test_Position():
    # Case 0
    p = Position(1, 1, 1)
    assert p.line_no == 1
    assert p.column_no == 1
    assert p.char_index == 1


# Generated at 2022-06-24 10:28:54.558230
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    error = ValidationError(
        messages=[
            Message(index=[0], text="Must be greater than 10"),
            Message(index=[1], text="Must be less than 20"),
            Message(index=[1, "name"], text="Name must be non-empty"),
        ]
    )

    assert dict(error) == {"0": "Must be greater than 10", "1": {"name": "Name must be non-empty"}}



# Generated at 2022-06-24 10:29:04.718879
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    BaseError___iter__ = BaseError.__iter__
    BaseError___iter__.__annotations__ = {}
    def decorated(self):
        self = BaseError(text="message1", code="code1")
        assert self == {"" : "message1"}
        assert len(self) == 1
        assert set(self) == {""}
        it = BaseError___iter__(self)
        assert "" == next(it)
        it = BaseError___iter__(self)
        try:
            next(it)
            next(it)
        except StopIteration:
            pass
        else:
            assert False
        assert set(BaseError___iter__(BaseError())) == set()
    return locals()


# Generated at 2022-06-24 10:29:09.432697
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    r1 = ValidationResult(value = 3)
    assert r1.value == 3
    assert r1.error is None
    r2 = ValidationResult(error = Exception('Invalid data'))
    assert r2.value is None
    assert r2.error is not None
    assert r2.error.args[0] == 'Invalid data'
    assert not r1
    assert r2


# Generated at 2022-06-24 10:29:15.897789
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    a = Position(line_no=1, column_no=2, char_index=3)
    b = Position(line_no=1, column_no=2, char_index=3)
    c = Position(line_no=4, column_no=5, char_index=6)
    assert a == b
    assert a != c


# Generated at 2022-06-24 10:29:17.245719
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    print("Test BaseError.__repr__")
    pass

# Generated at 2022-06-24 10:29:20.555243
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    assert eval(repr(ValidationResult(value=1))) == ValidationResult(value=1)
    error = ValidationError(text='E')
    assert eval(repr(ValidationResult(error=error))) == ValidationResult(error=error)
    return True


# Generated at 2022-06-24 10:29:24.434372
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    code = "max_length"
    key = "username"
    text = "May not have more than 100 characters"
    message = Message(text=text, code=code, key=key)
    assert str(message) == 'Message(text=\'May not have more than 100 characters\', code=\'max_length\', index=[\'username\'])'



# Generated at 2022-06-24 10:29:36.372007
# Unit test for constructor of class BaseError
def test_BaseError():
    error = BaseError(text='error', code='error0')
    assert error.messages() == [Message(text='error', code='error0')]
    assert error == BaseError(text='error', code='error0')
    assert repr(error) == "BaseError(text='error', code='error0')"

    msgs = BaseError(text='error0', code='error0').messages()  # type: ignore
    msgs += BaseError(text='error1', code='error1').messages()  # type: ignore
    error = BaseError(messages=msgs)
    assert error.messages() == [
        Message(text='error0', code='error0'),
        Message(text='error1', code='error1'),
    ]
    assert error == BaseError(messages=msgs)

# Generated at 2022-06-24 10:29:47.099489
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    from typesystem.types import String
    schema = String()
    error = ValidationError(
        text = "Must be at least 2 characters long.",
        code = 'min_length',
        key = 'username'
    )
    result = schema.validate_or_error('')
    if result.error != error:
        print(f'result.error: {result.error}')
        print(f'TEST FAILS')
    else: print(f'TEST PASSES')
    print(f'result.error: {result.error}')
    print(f'str(result.error): {str(result.error)}')
    print(f'repr(result.error): {repr(result.error)}')
    result = schema.validate_or_error('1')

# Generated at 2022-06-24 10:29:49.587422
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(0, 0, 0) == Position(0, 0, 0)
    assert not Position(0, 0, 0) == Position(0, 0, 1)


# Generated at 2022-06-24 10:29:52.235225
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError("Test Error")
    assert err.messages()


# Generated at 2022-06-24 10:29:53.534932
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    error = BaseError()
    iterator = error.__iter__()
    next(iterator)
    assert False


# Generated at 2022-06-24 10:29:58.760803
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text = 'May not have more than 100 characters', code = 'max_length')
    message2 = Message(text = 'May not have more than 100 characters', code = 'max_length')
    message3 = Message(text = 'May not have more than 100 characters', code = 'min_length')
    assert message1 == message2
    assert message1 != message3


# Generated at 2022-06-24 10:30:09.872370
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
	class BaseError(Mapping, Exception):
		"""
		A validation or parse error, containing one or more error messages.
		Error information is accessible either by accessing as a dict-like object,
		eg. `dict(error)` or by returning the list of messages with `error.messages()`.

		ValidationError is either raised, in the `validate()` usage:

		value = MySchema.validate(data)

		Or returned in the `validate_or_error()` usage:

		value, error = MySchema.validate_or_error(data)
		"""


# Generated at 2022-06-24 10:30:12.242184
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    message=Message(text='123',code='123',key='123',start_position='123',end_position='123')
    print(hash(message))
    pass


# Generated at 2022-06-24 10:30:22.891300
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    # 0 elements
    try:
        val = BaseError()
    except BaseException:
        assert False, 'unexpected exception thrown'
    assert hash(val) == hash(type(val))

    # single element, no key
    try:
        val = BaseError(text='text1')
    except BaseException:
        assert False, 'unexpected exception thrown'
    assert hash(val) == hash(type(val))

    # single element, key
    try:
        val = BaseError(text='text1', key='key1')
    except BaseException:
        assert False, 'unexpected exception thrown'
    assert hash(val) == hash(type(val))

    # two elements, no key

# Generated at 2022-06-24 10:30:25.470552
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    position = Position(line_no=2,column_no=8,char_index=25)
    assert 'Position(line_no=2, column_no=8, char_index=25)' == position.__repr__()


# Generated at 2022-06-24 10:30:31.253479
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    assert repr(Position(line_no=0, column_no=0, char_index=0)) == 'Position(line_no=0, column_no=0, char_index=0)'
    assert repr(Position(line_no=1, column_no=1, char_index=1)) == 'Position(line_no=1, column_no=1, char_index=1)'
    assert repr(Position(line_no=100, column_no=100, char_index=100)) == 'Position(line_no=100, column_no=100, char_index=100)'


# Generated at 2022-06-24 10:30:43.926672
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    assert str(BaseError(text="error1")) == "error1"
    assert str(BaseError(messages=[Message(text="error1")])) == "error1"
    assert str(BaseError(messages=[Message(text="error2", key="key1")])) == "{key1: 'error2'}"
    assert str(BaseError(messages=[Message(text="error1", index=["k1"])])) == '{"k1": "error1"}'
    assert str(BaseError(messages=[Message(text="error1", index=["k1", "k2"])])) == '{"k1": {"k2": "error1"}}'

# Generated at 2022-06-24 10:30:51.788343
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    from typesystem.schema import Schema
    from typesystem.types import String
    from typesystem import ValidationError
    from typesystem.components import ValidationError
    from typesystem.components import ValidationError

    def __init__(self, *, text: str, code: str = None, key: typing.Union[int, str] = None, index: typing.List[typing.Union[int, str]] = None, position: Position = None, start_position: Position = None, end_position: Position = None):
        self.text = text
        self.code = "custom" if code is None else code
        if key is not None:
            assert index is None
            self.index = [key]
        else:
            self.index = [] if index is None else index


# Generated at 2022-06-24 10:30:57.102346
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    # Constructor test
    ValidationResult(value="value1")
    ValidationResult(error="error1")
    try:
        ValidationResult(value="value1", error="error1")
        assert False, "ValidationResult must raise AssertError."
    except AssertionError:
        pass
    try:
        ValidationResult()
        assert False, "ValidationResult must raise AssertError."
    except AssertionError:
        pass


# Generated at 2022-06-24 10:31:00.792692
# Unit test for constructor of class Position
def test_Position():
    pos = Position(1, 2, 3)
    assert pos.line_no == 1
    assert pos.column_no == 2
    assert pos.char_index == 3


# Generated at 2022-06-24 10:31:03.128068
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    m1 = Message(text="m1")
    m2 = Message(text="m1")
    assert m1 == m2


# Generated at 2022-06-24 10:31:11.283721
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    res = ValidationResult(value=5)
    assert res.value == 5
    assert res.error is None
    assert not res.error
    res = ValidationResult(error=5)
    assert res.value is None
    assert res.error == 5
    assert res.error
    assert (res.value, res.error) == (None, 5)
    assert not (res.value, res.error) == (1, 5)
    assert not (res.value, res.error) == (0, 5)
    assert (res.value, res.error) == (None, 6)

# Generated at 2022-06-24 10:31:21.498243
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    import typesystem
    s = typesystem.Schema(
        fields={
            "name": typesystem.String(min_length=4, max_length=6),
            "age": typesystem.Integer(minimum=1, maximum=100),
        }
    )
    data = {"name": "", "age": -1}
    r = ValidationResult(error=s.validate(data))
    if(r.value != -1):
        print("test_ValidationResult: ", r.value)
    if(r.error == None):
        print("test_ValidationResult: ", r.error)
        return False
    return True


# Generated at 2022-06-24 10:31:29.536724
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    # Create an ValidationError instance
    # Root with a single error message
    error = BaseError(text='error_message', code='custom', key=None)
    # Call method from class ValidationError
    error__repr__ = error.__repr__()
    # Check the method returns expected value
    assert error__repr__ == "BaseError(text='error_message', code='custom')"

    # Create an ValidationError instance
    # Root with multiple error messages
    error = BaseError(messages=[Message(text='error_message1', code='custom', key=None),
                                Message(text='error_message2', code='custom', key=None)])
    # Call method from class ValidationError
    error__repr__ = error.__repr__()
    # Check the method returns expected value
    assert error

# Generated at 2022-06-24 10:31:31.778909
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    my_schema = BaseError()
    actual = my_schema[""]
    expected = ""
    assert actual == expected

# Generated at 2022-06-24 10:31:36.415097
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    exc = BaseError(messages=[
        Message(text="First error message"),
        Message(text="Second error message"),
        Message(text="Third error message")
    ])
    assert list(exc) == []


# Generated at 2022-06-24 10:31:41.987945
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    messages = [
        Message(text="Message 1"),
        Message(text="Message 2"),
        Message(text="Message 3", index=[0]),
    ]
    error = BaseError(messages=messages)
    assert hasattr(error, "__iter__")
    assert next(iter(error)) == "Message 1"
    assert next(iter(error)) == "Message 2"
    assert next(iter(error)) == {"0": "Message 3"}
    with pytest.raises(StopIteration):
        next(iter(error))

# Generated at 2022-06-24 10:31:44.891340
# Unit test for constructor of class Position
def test_Position():
    p = Position(2, 3, 8)
    assert p.line_no == 2
    assert p.column_no == 3
    assert p.char_index == 8


# Generated at 2022-06-24 10:31:52.679740
# Unit test for constructor of class ValidationError
def test_ValidationError():
    try:
        data = '{"key1": 1, "key2": 2}'
        key = "key1"
        code = "code1"
        text = "text1"
        message = Message(text=text, code=code, key=key)
        error = ValidationError(messages=[message])
        assert error
        assert error.messages() == [message]
        assert error[key] == text

        message = Message(text=text, code=code, index=["key1"])
        error = ValidationError(messages=[message])
        assert error
        assert error.messages() == [message]
        assert error["key1"] == text

    except Exception:
        assert False, "Constructor of class ValidationError failed"



# Generated at 2022-06-24 10:31:59.065938
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(0, 0, 0) == Position(0, 0, 0)
    assert not (Position(0, 0, 0) == Position(0, 0, 1))
    assert not (Position(0, 0, 0) == Position(0, 1, 0))
    assert not (Position(0, 0, 0) == Position(1, 0, 0))
    assert not (Position(0, 0, 0) == object)


# Generated at 2022-06-24 10:32:06.341381
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    assert str(BaseError(text="missing_required")) == 'missing_required'
    assert str(BaseError(messages=[Message(text="min_length")])) == 'min_length'
    assert str(BaseError(messages=[Message(text="max_length", key="username")])) == "{'username': 'max_length'}"
    assert str(
        ValidationError(
            messages=[
                Message(text="missing_required", key="username"),
                Message(text="min_length", key="password"),
            ]
        )
    ) == "{'username': 'missing_required', 'password': 'min_length'}"


# Generated at 2022-06-24 10:32:09.311402
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    print('::: TEST ::: test_BaseError___iter__()')
    assert [item for item in BaseError({})], 'Empty mapping should return empty iterator.'


# Generated at 2022-06-24 10:32:15.930633
# Unit test for constructor of class ParseError
def test_ParseError():
    # Test constructor of ParseError without parameters
    try:
        ParseError()
    except:
        assert False

    # Test constructor of ParseError with parameters
    try:
        ParseError(text="", code="", key="")
    except:
        assert False

    # Test constructor of ParseError with error messages
    try:
        ParseError(messages=[])
    except:
        assert False

if __name__ == "__main__":
    try:
        test_ParseError()
    except:
        print("Error in test_ParseError")

# Generated at 2022-06-24 10:32:21.440642
# Unit test for method __eq__ of class BaseError

# Generated at 2022-06-24 10:32:24.092328
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    error = ValidationError(text="Required")
    assert len(error)==1


# Generated at 2022-06-24 10:32:33.591954
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    p1 = Position(line_no=1, column_no=10, char_index=100)
    p2 = Position(line_no=1, column_no=10, char_index=100)
    p3 = Position(line_no=1, column_no=10, char_index=200)
    p4 = Position(line_no=1, column_no=20, char_index=100)
    p5 = Position(line_no=2, column_no=10, char_index=100)


# Generated at 2022-06-24 10:32:38.291518
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    value = 1
    error = ValidationError(text="Error message")
    obj = ValidationResult(value=value, error=error)
    for rst in obj:
        print(f"{rst!r}")



# Generated at 2022-06-24 10:32:40.061090
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    assert str(ValidationResult(value=None)) == f"ValidationResult(value=None)"


# Generated at 2022-06-24 10:32:45.287001
# Unit test for constructor of class ParseError
def test_ParseError():
    text = 'Validation failed'
    code = 'custom'
    key = 'username'
    position = Position(line_no=1, column_no=2, char_index=3)
    error = ParseError(text=text, code=code, key=key, position=position)
    assert error.messages()[0] == Message(
        text=text, code=code, key=key, position=position
    )


# Generated at 2022-06-24 10:32:49.930478
# Unit test for constructor of class ValidationError
def test_ValidationError():
    v = ValidationError(text="May not have more than 100 characters", code="max_length")
    assert v.messages() == [Message(text="May not have more than 100 characters", code="max_length")]
    # Testing equal
    assert v == ValidationError(text="May not have more than 100 characters", code="max_length")
    assert v != ValidationError(text="Valid", code="may_have_more")
    # Testing hashable
    try:
        hash(v)
    except TypeError:
        assert False



# Generated at 2022-06-24 10:32:58.870373
# Unit test for constructor of class ParseError
def test_ParseError():
    assert ParseError(messages=[Message(text="message", code="code", key="key")]) == ParseError(messages=[Message(text="message", code="code", key="key")])
    assert ParseError(messages=[Message(text="message", code="code", key="key")]) != ParseError(messages=[Message(text="message", code="code", key="key2")])
    assert ParseError(messages=[Message(text="message", code="code", key="key")]) != ParseError(messages=[Message(text="message2", code="code", key="key")])
    assert ParseError(messages=[Message(text="message", code="code", key="key")]) != ParseError(messages=[Message(text="message", code="code2", key="key")])
    assert Parse

# Generated at 2022-06-24 10:33:03.654501
# Unit test for constructor of class Message
def test_Message():
    M = Message(text="I'm a message", code="my_code",
                key=1, index=[2, 3, 4],
                start_position=Position(1, 2, 3),
                end_position=Position(4, 5, 6))
    assert M.text == "I'm a message"
    assert M.code == "my_code"
    assert M.key == 1
    assert M.index == [2, 3, 4]
    assert M.start_position == Position(1, 2, 3)
    assert M.end_position == Position(4, 5, 6)
    # Test __eq__

# Generated at 2022-06-24 10:33:06.336070
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    res = ValidationResult(value=10)
    assert repr(res) == "ValidationResult(value=10)"
    res = ValidationResult(error="error")
    assert repr(res) == "ValidationResult(error='error')"

# Generated at 2022-06-24 10:33:09.991317
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert not ValidationResult(value=3)
    assert ValidationResult(error=ValidationError())
    assert not ValidationResult(value=3, error=ValidationError())
    assert ValidationResult(value=3, error=BaseError())



# Generated at 2022-06-24 10:33:12.009846
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    assert bool(ValidationResult(value=True))
    assert not bool(ValidationResult(error=ValidationError()))

# Generated at 2022-06-24 10:33:17.977143
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    from . import validate_or_error

    class MySchema(Schema):
        foo = fields.Integer()

    value, error = validate_or_error(MySchema, {"foo": "1"})
    assert value, error

    value, error = validate_or_error(MySchema, {})
    assert not error
    assert not value

    value, error = validate_or_error(MySchema, {"foo": "h"})
    assert not error
    assert not value

# Generated at 2022-06-24 10:33:26.726077
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    position = Position(line_no = 1, column_no = 2, char_index = 4)
    m = Message(text = 'msg text', code = 'msg code', key = 'msg key', index = ['index1', 2, 'index3'],
                position = position)
    m1 = Message(text = 'msg text', code = 'msg code', key = 'msg key', index = ['index1', 2, 'index3'],
                position = position)
    assert(m == m1)
    assert(hash(m) == hash(m1))
    m2 = Message(text = 'msg text', code = 'msg code', key = 'msg key', index = ['index1', 2, 'index3'],
                start_position = position, end_position = position)
    assert(m == m2)

# Generated at 2022-06-24 10:33:31.219140
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    messages = [Message(text="error 1"), Message(text="error 2")]
    errors = BaseError(messages=messages, key=5)
    assert list(errors) == ["error 1", "error 2"]



# Generated at 2022-06-24 10:33:35.019732
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    position = Position(
        line_no=1, column_no=2, char_index=3
    )
    print(position)
    assert position.__repr__() == "Position(line_no=1, column_no=2, char_index=3)"

# Generated at 2022-06-24 10:33:36.557639
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 1, 1) == Position(1, 1, 1)



# Generated at 2022-06-24 10:33:38.982203
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    result1 = ValidationResult(value=1)
    result2 = ValidationResult(error=ValidationError())

    assert bool(result1)
    assert not bool(result2)

# Generated at 2022-06-24 10:33:43.934816
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    message = Message(text='May not have more than 100 characters', code='max_length', key='username')
    result = str(message)
    expected = "Message(text='May not have more than 100 characters', code='max_length', index=['username'])"
    assert result == expected


# Generated at 2022-06-24 10:33:48.991504
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    from typesystem import ValidationResult
    obj = ValidationResult(value='Sydney')
    assert repr(obj) == 'ValidationResult(value=\'Sydney\')'
    obj = ValidationResult(error=ValidationError())
    assert repr(obj) == 'ValidationResult(error=ValidationError({}))'



# Generated at 2022-06-24 10:33:51.245869
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    assert bool(ValidationResult(value=1)) == True
    assert bool(ValidationResult(error=1)) == False


# Generated at 2022-06-24 10:33:58.779910
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    # OK
    error = BaseError(text="Some error message", code="err_code", key="key")
    assert error["key"] == "Some error message"

    # OK
    error = BaseError(text="Some error message", code="err_code")
    error_dict = error.messages()[0]
    assert error_dict[""] == "Some error message"

    # NOK
    error = BaseError(text="Some error message", code="err_code")
    try:
        error["key"]
        success = False
    except KeyError:
        success = True
    assert success is True


# Generated at 2022-06-24 10:34:08.430184
# Unit test for constructor of class ValidationError
def test_ValidationError():
    error = ValidationError(
        text="The field is required.",
        code="required",
        key="username",
    )
    assert error.messages() == [
        Message(
            text="The field is required.",
            code="required",
            key="username",
        )
    ]
    error = ValidationError(
        messages=[
            Message(
                text="The field is required.",
                code="required",
                key="username",
            )
        ]
    )
    assert error.messages() == [
        Message(
            text="The field is required.",
            code="required",
            key="username",
        )
    ]


# Generated at 2022-06-24 10:34:12.512263
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    error = BaseError(messages=[
        Message(text='text 1', code='code 1', key=0),
        Message(text='text 2', code='code 2', key=1),
        Message(text='text 3', code='code 3', key=2),
    ])

    assert error[1] == 'text 2'


# Generated at 2022-06-24 10:34:15.504909
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    text = 'This is an error!'
    code = 'error.code'
    key = 'key'
    position = Position(0, 0, 0)
    messages = [Message(text, code, key, position)]
    error = BaseError(messages)

    assert str(error) == 'This is an error!'

# Generated at 2022-06-24 10:34:17.847589
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    ValidationResult(error=ValidationError(text="No value provided."))
    ValidationResult(value=42)

# Generated at 2022-06-24 10:34:22.975223
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    def test(value: typing.Any) -> None:
        error = BaseError(messages=value)
        assert len(error) == value, f"len(BaseError(messages={value!r})) = {len(error)}"
    test(1)
    test(2)



# Generated at 2022-06-24 10:34:32.363278
# Unit test for constructor of class Message
def test_Message():
    message = Message(text='a', code='b', key=1, position=1)
    assert message.text == 'a'
    assert message.code == 'b'
    assert message.index == [1]
    assert message.start_position == message.end_position == 1

    message = Message(text='a', code='b', key=1, start_position=1, end_position=2)
    assert message.text == 'a'
    assert message.code == 'b'
    assert message.index == [1]
    assert message.start_position == 1
    assert message.end_position == 2

    message = Message(text='a', code='b', index=['c','d'])
    assert message.text == 'a'
    assert message.code == 'b'

# Generated at 2022-06-24 10:34:40.457275
# Unit test for constructor of class Position
def test_Position():
    #test for init function
    test_Position = Position(1, 2, 3)
    assert test_Position.line_no == 1
    assert test_Position.column_no == 2
    assert test_Position.char_index ==3
    #test for equal function
    Position1 = Position(1,2,3)
    Position2 = Position(1, 2, 3)
    assert Position1 == Position2
    #test for __repr__
    assert str(test_Position) == 'Position(line_no=1, column_no=2, char_index=3)'
#test for constructor of class Message

# Generated at 2022-06-24 10:34:46.166629
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    class_name = "Position"
    _line_no = 123
    _column_no = 456
    _char_index = 789
    p = Position(line_no=_line_no, column_no=_column_no, char_index=_char_index)
    a = f"{class_name}(line_no={_line_no}, column_no={_column_no}, char_index={_char_index})"
    assert repr(p) == a


# Generated at 2022-06-24 10:34:51.256650
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    fake_msg = Message(text='xyzzy', code='plugh',
        key='fred', index=[1, 'a'],
        start_position=Position(0, 0, 0),
        end_position=Position(0, 0, 0))
    assert hash(fake_msg) != 0


# Generated at 2022-06-24 10:34:56.282496
# Unit test for constructor of class ParseError
def test_ParseError():
    message = Message(text='test', code='test')
    error = ParseError(messages=[message])
    assert error.messages() == [message]
    assert dict(error) == {'': 'test'}
    assert str(error) == 'test'
    assert repr(error) == "ParseError([Message(text='test', code='test', index=[])])"


# Generated at 2022-06-24 10:34:59.533193
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    p = Position(line_no=1, column_no=2, char_index=3)
    assert repr(p) == 'Position(line_no=1, column_no=2, char_index=3)'



# Generated at 2022-06-24 10:35:06.187198
# Unit test for constructor of class Position
def test_Position():
    input1 = (1, 2, 3)
    input2 = 8
    position1 = Position(*input1)
    position2 = Position(**input2)
    assert position1.line_no == input1[0]
    assert position1.column_no == input1[1]
    assert position1.char_index == input1[2]
    assert position2.line_no == input2
    assert position2.column_no == input2
    assert position2.char_index == input2


# Generated at 2022-06-24 10:35:11.358355
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    actual_result = Message(text='The username field is empty', code='required', key='username').__repr__()

    expected_result = "Message(text='The username field is empty', code='required', index=['username'])"

    assert actual_result == expected_result



# Generated at 2022-06-24 10:35:21.554245
# Unit test for constructor of class ValidationError
def test_ValidationError():
    # test_ValidationError()

    # Instantiate ValidationError with a single error message.
    e = ValidationError(text="example text", code="example code", key="example key")
    # Check that creating a ValidationError with a single error message
    # also works when using positional args.
    e = ValidationError("example text", "example code", "example key")

    # Check that calling ValidationError with more than one positional arg for
    # the message text aborts with a TypeError.
    with pytest.raises(TypeError):
        e = ValidationError("example text", "example code", "example key", "oops")

    # Check that the .messages() method only returns messages if 'e' has been
    # supplied with a single error message.
    messages = e.messages()
    assert len(messages)

# Generated at 2022-06-24 10:35:27.462865
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    t1 = BaseError()
    t2 = BaseError(messages=[Message(text="text", code="code", key="key")])
    assert str(t1) == "{}"
    assert str(t2) == "{'key': 'text'}"


if __name__ == "__main__":
    import pytest
    import sys
    pytest.main(sys.argv)

# Generated at 2022-06-24 10:35:35.276092
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    error = BaseError()
    messages = error.messages()
    assert len(messages) == 0

    error = BaseError(text="error message")
    messages = error.messages()
    assert len(messages) == 1
    assert messages[0].text == "error message"
    assert messages[0].index == []

    error = BaseError(text=None, key="username", code="max_length", messages=[])
    messages = error.messages()
    assert len(messages) == 0

    error = BaseError(
        text=None,
        key="username",
        code="max_length",
        messages=[Message(text="some text", index=[1, 2])],
    )
    messages = error.messages()
    assert len(messages) == 1