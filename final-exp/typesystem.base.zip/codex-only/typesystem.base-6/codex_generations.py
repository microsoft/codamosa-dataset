

# Generated at 2022-06-24 10:25:29.182611
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    v = ValidationError(text = "test_BaseError___hash__")
    return hash(v)

# Generated at 2022-06-24 10:25:40.016733
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    assert str(BaseError()) == "{}"
    assert (
        str(
            BaseError(text="required", code="required", key="timestamp")
        )
        == '{"timestamp": "required"}'
    )
    assert (
        str(
            BaseError(
                messages=[
                    Message(text="required", code="required"),
                    Message(text="invalid", code="invalid", key="timestamp"),
                ]
            )
        )
        == '{"": "required", "timestamp": "invalid"}'
    )

# Generated at 2022-06-24 10:25:47.242137
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    message1 = Message('text1', 'code1', 'key1', [0, 1, 2, 3], Position(1, 1, 1))
    message2 = Message('text2', 'code2', 'key2', [4, 5, 6, 7], Position(2, 2, 2))
    message3 = Message('text3', 'code3', 'key3', [8, 9, 10, 11], Position(3, 3, 3))
    message4 = Message('text4', 'code4', 'key4', [0, 1, 2, 3], Position(1, 1, 1))
    message5 = Message('text5', 'code5', 'key5', [4, 5, 6, 7], Position(2, 2, 2))

# Generated at 2022-06-24 10:25:53.976237
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    e = ValidationError(messages=[
        Message(index=[], text='foo'),
        Message(index=[0], text='bar'),
        Message(index=[1], text='baz'),
        Message(index=[0, 'a'], text='qux'),
        Message(index=[1, 'b'], text='quux'),
    ])
    assert e[''] == 'foo'
    assert e[0] == 'bar'
    assert e[1] == 'baz'
    assert e[0]['a'] == 'qux'
    assert e[1]['b'] == 'quux'

# Generated at 2022-06-24 10:25:56.769253
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    print(BaseError(messages=[Message(text="Forbidden", code="forbidden")]).__len__())
    print(BaseError(messages=[Message(text="Forbidden", code="forbidden"), Message(text="Forbidden", code="forbidden")]).__len__())

test_BaseError___len__()

# Generated at 2022-06-24 10:26:01.068895
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    """
    Test method __iter__ of class ValidationResult.
    """
    error_message = "message"
    expected = "ValidationResult(error=ValidationError(text=message))"
    actual = repr(ValidationResult(error=ValidationError(text=error_message)))
    assert expected == actual


# Generated at 2022-06-24 10:26:06.054137
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    # Check length of empty BaseError
    error = BaseError(text="")
    assert len(error) == 1
    # Check length of populated BaseError
    error = BaseError(text="First error")
    assert len(error) == 1
    error = BaseError(messages=[Message(text="First error"), Message(text="Second error")])
    assert len(error) == 2


# Generated at 2022-06-24 10:26:15.529232
# Unit test for constructor of class ValidationError
def test_ValidationError():
    def assert_ValidationError(*, text, code, key, position, index, **kwargs):
        error = ValidationError(text=text, code=code, key=key, position=position, **kwargs)  # type: ignore
        # TODO: should we assert for other things?
        assert error.messages() == [Message(text=text, code=code, key=key, position=position, index=index)] 

    assert_ValidationError(text='may not be empty', code=None, key=None, position=None, index=[])
    assert_ValidationError(text='may not be empty', code=None, key='next_page', position=Position(10, 11, 100), index=['next_page'])
    # TODO: add more cases

test_ValidationError()

# Generated at 2022-06-24 10:26:27.665186
# Unit test for constructor of class BaseError
def test_BaseError():
    error = BaseError(text='error')
    assert error.messages() == [
        Message(text='error', code='custom')
    ]

    error = BaseError(text='foo', text='bar')
    assert error.messages() == [
        Message(text='bar', code='custom')
    ]

    error = BaseError(text='error', code='wrong_length')
    assert error.messages() == [
        Message(text='error', code='wrong_length')
    ]

    error = BaseError(text='error', index='key')
    assert error.messages() == [
        Message(text='error', code='custom', index=['key'])
    ]

    error = BaseError(text='error', index=['key', 'subkey'])

# Generated at 2022-06-24 10:26:37.416491
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    assert repr(ValidationError(text="Hello")) == "ValidationError(text='Hello', code='custom')"
    
    assert repr(ValidationError([
        Message(text="Hello"),
        Message(text="World")
    ])) == "ValidationError([Message(text='Hello', code='custom', index=[]), Message(text='World', code='custom', index=[])])"
    
    assert repr(ValidationError([
        Message(text="Hello", index=[1]),
        Message(text="World", index=[2])
    ])) == "ValidationError([Message(text='Hello', code='custom', index=[1]), Message(text='World', code='custom', index=[2])])"
    

# Generated at 2022-06-24 10:26:40.325129
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    e1 = BaseError(text="ERROR1")
    e2 = BaseError(text="ERROR1")
    e3 = BaseError(text="ERROR3")
    assert e1 == e2
    assert not e1 == e3


# Generated at 2022-06-24 10:26:48.840735
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    case_1 = Message(text="May not have more than 100 characters", code=None, key=None, index=[], position=Position(line_no=1, column_no=1, char_index=0))
    obj = BaseError(messages=[case_1])
    assert hash(obj) == -7146185651395133677

    case_2 = Message(text="May not have more than 100 characters")
    obj = BaseError(messages=[case_2])
    assert hash(obj) == -7146185651395133677

    case_3 = Message(text="May not have more than 200 characters")
    obj = BaseError(messages=[case_3])
    assert hash(obj) == -368161210021063344


# Generated at 2022-06-24 10:26:53.400366
# Unit test for constructor of class ValidationError
def test_ValidationError():
    error = ValidationError(
        text='Hello',
        code='my-code'
    )
    assert error['key'] == "Hello"
    assert error.messages()[0].text == "Hello"
    assert error.messages()[0].code == "my-code"


# Generated at 2022-06-24 10:26:55.740336
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    v = ValidationResult(value=True)
    try:
        assert v.value == True
        assert v.error == None
    except Exception:
        assert False



# Generated at 2022-06-24 10:27:02.012722
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    message1 = Message(text='message1', code='code1', key=None)
    message2 = Message(text='message2', code='code2', key=None)
    message3 = Message(text='message3', code='code3', key=None)
    error = BaseError(messages = [message1, message2])
    error2 = BaseError(messages = [message2, message3])
    assert error == error2

# Generated at 2022-06-24 10:27:03.654547
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    a = Position(1, 2, 3)
    b = Position(1, 2, 3)
    assert a == b



# Generated at 2022-06-24 10:27:06.671601
# Unit test for constructor of class ValidationError
def test_ValidationError():
    error = ValidationError(text="test1", code="error1")

    assert error._messages == [Message(text="test1", code="error1", key="")]
    assert error[""] == "test1"

# Generated at 2022-06-24 10:27:09.176906
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError(text="example", code="sample", key="key1")
    assert error is not None


# Generated at 2022-06-24 10:27:12.363117
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    BaseError(text='Not a draft')
    BaseError(messages=[
        Message(text='Must contain at least one field of type string.'),
        Message(text='Must not be empty.'),
    ])

# Generated at 2022-06-24 10:27:22.015369
# Unit test for constructor of class BaseError
def test_BaseError():
    try:
        error = BaseError()
        assert False
    except TypeError:
        pass

    error = BaseError(
        text="May not have more than 100 characters", code="max_length"
    )
    assert dict(error) == {"" : "May not have more than 100 characters"}
    assert error.messages() == [
        Message(
            text="May not have more than 100 characters",
            code="max_length",
            index=[],
        )
    ]
    assert error == BaseError(
        text="May not have more than 100 characters", code="max_length"
    )
    assert error != BaseError(text="Does not match regex", code="max_length")
    assert error != BaseError(
        text="May not have more than 100 characters", code="max_length", key="username"
    )

# Generated at 2022-06-24 10:27:25.610289
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    from typesystem import ValidationResult
    v = ValidationResult(value=10)
    assert v.__repr__() == "ValidationResult(value=10)"
    assert repr(v) == "ValidationResult(value=10)"


# Generated at 2022-06-24 10:27:27.767374
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    assert repr(ValidationResult(value=1)) == "ValidationResult(value=1)"
    assert repr(ValidationResult(error=ValidationError(text="err"))) == "ValidationResult(error=ValidationError(text='err'))"

# Generated at 2022-06-24 10:27:35.800269
# Unit test for constructor of class Message
def test_Message():
    assert Message(
        text="May not have more than 100 characters",
        code="max_length",
        key=0,
        position=Position(line_no=0, column_no=0, char_index=0),
    ) == Message(
        text="May not have more than 100 characters",
        code="max_length",
        key=0,
        position=Position(line_no=0, column_no=0, char_index=0),
    )

# Generated at 2022-06-24 10:27:38.974005
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    msg = Message(text="test", code="test")
    try:
        raise BaseError(messages=[msg])
    except BaseError as e:
        assert msg in e.messages()


# Generated at 2022-06-24 10:27:44.544558
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():

    e1 = "test1 is not a number"
    e2_txt = "test2 is not a number"
    msg_list = [Message(text=e1)]
    msg_list.append(Message(text=e2_txt, key="test2"))
    e = BaseError(messages=msg_list)

    assert e["test2"] == e2_txt
    assert e["test1"] == e1


# Generated at 2022-06-24 10:27:55.878771
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    m1 = Message(text='text', code='code', start_position=Position(1, 2, 3))
    m2 = Message(text='text', code='code', start_position=Position(1, 2, 3))
    m3 = Message(text='different text', code='code', start_position=Position(1, 2, 3))
    m4 = Message(text='text', code='different code', start_position=Position(1, 2, 3))

    def hash_xor(iterable):
        acc = 0
        for elem in iterable:
            acc ^= hash(elem)
        return acc

    assert hash_xor([m1, m2, m3, m4]) == 0
    assert hash_xor([m1, m2]) == 0

# Generated at 2022-06-24 10:27:57.137305
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    _getitem_test_dict = dict()
    _getitem_test_key = ""


# Generated at 2022-06-24 10:28:07.221057
# Unit test for constructor of class BaseError
def test_BaseError():
    error = BaseError(text="an error")
    assert dict(error) == {"": "an error"}
    assert len(error.messages()) == 1
    assert error.messages()[0] == Message(text="an error", code="custom")

    error = BaseError(key="fee", text="an error")
    assert dict(error) == {"fee": "an error"}
    assert len(error.messages()) == 1
    assert error.messages()[0] == Message(text="an error", code="custom", key="fee")

    error = BaseError(index=["fee"], text="an error")
    assert dict(error) == {"fee": "an error"}
    assert len(error.messages()) == 1

# Generated at 2022-06-24 10:28:09.893513
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError()
    assert error
    assert list(error) == []
    assert not error.messages()



# Generated at 2022-06-24 10:28:11.290211
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
   error = BaseError()
   assert error['abc'] is None

# Generated at 2022-06-24 10:28:13.620580
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    obj = Message(text='error text', code='error code')
    assert obj.__hash__() == hash(('error code', ('',)))

# Generated at 2022-06-24 10:28:25.220656
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    class_name = Message.__name__
    a = Message(text='1', code='1', key='1', index=['a'], position=Position(1,1,1), start_position=Position(1,1,1), end_position=Position(1,1,1))
    b = Message(text='1', code='1', key='1', index=['a'], position=Position(1,1,1), start_position=Position(1,1,1), end_position=Position(1,1,1))
    c = Message(text='2', code='2', key='2', index=['b'], position=Position(2,2,2), start_position=Position(2,2,2), end_position=Position(2,2,2))

# Generated at 2022-06-24 10:28:35.283819
# Unit test for constructor of class Message
def test_Message():
    line_no = 1
    column_no = 3
    char_index = 10
    text = "Non-string value"
    code = "custom"
    key = "char_index"
    index = ["char_index", "1"]
    position = Position(line_no, column_no, char_index)
    start_position = Position(line_no, column_no, char_index)
    end_position = Position(line_no, column_no, char_index)
    a = Message(text=text, code=code, key=key, index=index, position=position)
    b = Message(text=text, code=code, key=key, index=index,
                start_position=start_position, end_position=end_position)
    assert(a == b)

# Generated at 2022-06-24 10:28:40.604472
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    error = BaseError(messages=[Message(index=[0, 'x'], text="X!")])
    assert error.messages(add_prefix=1) == [Message(index=[1, 0, 'x'], text="X!")]
    assert error.messages() == [Message(index=[0, 'x'], text="X!")]

# Generated at 2022-06-24 10:28:45.130173
# Unit test for constructor of class ValidationError
def test_ValidationError():
    # construct with error message
    error = ValidationError("username must be at least 8 characters long")
    print(error)

    # construct with list of error messages
    error = ValidationError(messages=[Message("username must be at least 8 characters long")])
    print(error)


if __name__ == "__main__":
    test_ValidationError()

# Generated at 2022-06-24 10:28:52.145965
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    text = 'test'
    code = 'asdf'
    key = 'asdf'
    position = Position(1, 1, 1)
    start_position = Position(1, 2, 2)
    end_position = Position(1, 3, 3)
    index = [1, 2, 3]

    return_value = Message(text=text, key=key, position=position).__repr__()
    assert return_value == "Message(text='test', code='custom', index=[ 'asdf' ], position=Position(line_no=1, column_no=1, char_index=1))"
    return_value = Message(text=text, code=code, position=position).__repr__()

# Generated at 2022-06-24 10:29:02.966965
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    # Test with a ValidationError with only a text
    error = BaseError(text="Username must have at least 5 characters")
    assert repr(error) == "BaseError(text='Username must have at least 5 characters', code='custom')"
    assert repr(error) == repr(BaseError(**eval(repr(error))))
    # Test with a ValidationError with a text and a code
    error = BaseError(text="Username must have at least 5 characters", code="min_length")
    assert repr(error) == "BaseError(text='Username must have at least 5 characters', code='min_length')"
    assert repr(error) == repr(BaseError(**eval(repr(error))))
    # Test with a ValidationError with a text and a key

# Generated at 2022-06-24 10:29:07.317917
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError(
        message='test',
        line_no=1,
        column_no=1,
        char_index=0
    )
    print(error)
    assert error.text == 'test'
    assert error.line_no == 1
    assert error.column_no == 1
    assert error.char_index == 0

# Generated at 2022-06-24 10:29:14.554361
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    text = "May not have more than 100 characters"
    classes = [ValidationError, ParseError]
    assert classes[0](text=text).__repr__() == 'ValidationError(text=\'May not have more than 100 characters\', code=\'custom\')'
    assert classes[1](text=text).__repr__() == 'ParseError(text=\'May not have more than 100 characters\', code=\'custom\')'



# Generated at 2022-06-24 10:29:23.364458
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    # Test when start_position and end_position are the same
    # Set the key
    key = 0
    # Set the code
    code = "test_code"
    # Set the text
    text = "test_text"
    # Set the position
    position = Position(line_no=3, column_no=4, char_index=5)
    # Create the message
    message = Message(text=text, code=code, key=key, position=position)
    # Get the hash
    hash_value = message.__hash__()
    # Assert that the has is correct
    assert hash_value == -9223923000303896309

    # Test when start_position and end_position are different
    # Set the key
    key = 0
    # Set the code
    code = "test_code"


# Generated at 2022-06-24 10:29:25.094139
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    error = ParseError(text='Invalid date format', code='invalid_format')

    assert str(error) == 'Invalid date format'


# Generated at 2022-06-24 10:29:32.138719
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    error = BaseError(messages=[
        Message(text="Error text", code="Error code", key="Error key", position=Position(line_no=1, column_no=2, char_index=3))
    ])
    result = list(error)
    assert len(result) == 1
    assert result[0] == {
        "Error key": "Error text"
    }


# Generated at 2022-06-24 10:29:35.786239
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    position = Position(line_no=0, column_no=2, char_index=2)
    assert repr(position) == "Position(line_no=0, column_no=2, char_index=2)"


# Generated at 2022-06-24 10:29:37.193860
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    BaseError()
    BaseError2()


# Generated at 2022-06-24 10:29:41.545791
# Unit test for constructor of class ParseError
def test_ParseError():
    messages = [Message(text="test1", code="code1", key="key1", index=["index1"])]
    e = ParseError(messages=messages)
    assert(e._messages == messages)


# Generated at 2022-06-24 10:29:50.302572
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():

    # Create object of class BaseError
    obj_of_class_BaseError = BaseError(
        text="May not have more than 100 characters",
        code="max_length",
        key="username",
    )

    # Create object of class BaseError
    obj_of_class_BaseError = BaseError(
        text="May not have more than 100 characters",
        code="max_length",
        key="username",
    )

    # Create object of class BaseError
    obj_of_class_BaseError = BaseError(
        text="May not have more than 100 characters",
        code="max_length",
        key="username",
    )

    # Create object of class BaseError

# Generated at 2022-06-24 10:29:53.276251
# Unit test for constructor of class BaseError
def test_BaseError():
    BaseError()
    BaseError(text="a", code="a", key="a", position="a")
    BaseError(messages="a")
    return True


# Generated at 2022-06-24 10:30:02.055931
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError(
        text="Text",
        code="Code",
        key="Key",
        position=Position(1, 2, 3),
        messages=["Message"],
    )
    assert error.messages() == [Message(
        text="Text",
        code="Code",
        key="Key",
        position=Position(1, 2, 3),
    )]
    assert error.messages(add_prefix="Prefix") == [Message(
        text="Text",
        code="Code",
        index=["Prefix", "Key"],
        position=Position(1, 2, 3),
    )]
    assert dict(error) == {"Key": "Text"}
    assert error == ParseError([Message("Text", "Code", key="Key", position=Position(1, 2, 3))])

# Generated at 2022-06-24 10:30:04.654328
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    # Test ValidationResult object with error attribute set to None
    acutal_result = ValidationResult(value='value')
    assert acutal_result.__bool__() == True

    # Test ValidationResult object with value attribute set to None
    acutal_result = ValidationResult(error='error')
    assert acutal_result.__bool__() == False

# Generated at 2022-06-24 10:30:08.026805
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    # Init
    test_error_obj = BaseError()
    # Assertion
    try:
        assert len(test_error_obj) is 0
    except Exception as e:
        assert False



# Generated at 2022-06-24 10:30:16.311317
# Unit test for constructor of class Message
def test_Message():
    message = Message(text="error")

    assert message.text == "error"
    assert message.code == "custom"
    assert message.index == []
    assert message.start_position == Position(line_no=0, column_no=0, char_index=0)
    assert message.end_position == Position(line_no=0, column_no=0, char_index=0)

    message = Message(text="error", code="max_length", key="username")

    assert message.text == "error"
    assert message.code == "max_length"
    assert message.index == ["username"]
    assert message.start_position == Position(line_no=0, column_no=0, char_index=0)

# Generated at 2022-06-24 10:30:25.382658
# Unit test for constructor of class ValidationError
def test_ValidationError():
    errors = [
        Message(text='foo'),
        Message(text='bar'),
    ]
    ve = ValidationError(messages=errors)
    assert ve._messages == errors
    assert list(ve) == ['', 'foo', 'bar']
    assert ve[''] == 'foo'
    assert ve['bar'] == 'bar'
    assert ve == ValidationError(messages=errors)
    assert ve != ValidationError(messages=errors[::-1])
    assert ve == ValidationError(messages=errors)
    assert ve != ValidationError(messages=errors[::-1])
    assert hash(ve) == hash(errors)

# Generated at 2022-06-24 10:30:28.135593
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    # BaseError.__iter__() -> <iterator object at 0x0000026BF3714EB8>
    assert BaseError().__iter__() == BaseError().__iter__()


# Generated at 2022-06-24 10:30:31.687179
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    e1 = BaseError(text='Invalid input', code='invalid')
    e2 = BaseError(text='Invalid input', code='invalid')
    assert hash(e1) == hash(e2)
    assert e1 == e2


# Generated at 2022-06-24 10:30:41.730812
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    # Test case 1:
    m = Message(text='a', code='b', index=[1])
    assert hash(m) == hash(('b', (1,)))

    # Test case 2:
    m = Message(text='a', code='b', index=[])
    assert hash(m) == hash(('b', ()))

    # Test case 3:
    m = Message(text='a', code='b')
    assert hash(m) == hash(('b', ()))

    # Test case 4:
    m = Message(text='a')
    assert hash(m) == hash(('custom', ()))

# Generated at 2022-06-24 10:30:44.202931
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    error = BaseError(text='May not have more than 100 characters')
    assert str(error) == 'May not have more than 100 characters'


# Generated at 2022-06-24 10:30:52.971107
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    assert str(BaseError()) == "{}"
    assert str(BaseError(text="Error message")) == "Error message"
    assert str(BaseError(messages=[Message(text="Error message")])) == "Error message"
    assert str(
        BaseError(messages=[Message(text="Error message", key="username")])
    ) == '{"username": "Error message"}'
    assert str(
        BaseError(
            messages=[Message(text="Error message", index=["users", 0, "username"])]
        )
    ) == '{"users": [{"username": "Error message"}]}'

# Generated at 2022-06-24 10:30:56.233093
# Unit test for constructor of class ValidationError
def test_ValidationError():
    error = ValidationError(text='message text', code='custom code')
    print(error, type(error))
    error = ValidationError(messages=[Message(text='message text'), Message(text='message text2')])
    print(error, type(error))

# Generated at 2022-06-24 10:30:58.381582
# Unit test for constructor of class Position
def test_Position():
    position = Position(1,2,3)
    assert position.line_no == 1
    assert position.column_no == 2
    assert position.char_index == 3


# Generated at 2022-06-24 10:31:03.930201
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    import typesystem

    error = ValidationError(
        text="Must be an integer", code="invalid", key="age"
    )
    assert isinstance(error, typesystem.ValidationError)
    assert error["age"] == "Must be an integer"


# Generated at 2022-06-24 10:31:08.474895
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    error = ValidationError(messages=[
        Message(text="a", code="a"),
        Message(text="b", code="b"),
        Message(text="c", code="c"),
        Message(text="d", code="d"),
        Message(text="e", code="e"),
    ])
    assert error["c"] == "c"

# Generated at 2022-06-24 10:31:14.042183
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert str(ValidationResult(value = 3)) == "ValidationResult(value=3)"
    assert str(ValidationResult(error = ValidationError(text = 'too short'))) == "ValidationResult(error=ValidationError(text='too short', code='custom'))"
    assert bool(ValidationResult(value = 3)) == True
    assert bool(ValidationResult(error = ValidationError(text = 'too short'))) == False

# Generated at 2022-06-24 10:31:19.564969
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    line_no = 1
    column_no = 2
    char_index = 3
    obj = Position(line_no, column_no, char_index)
    result = repr(obj)
    assert result == "Position(line_no=1, column_no=2, char_index=3)"


# Generated at 2022-06-24 10:31:28.358372
# Unit test for constructor of class Position
def test_Position():
    val = Position(1,2,3)
    assert val.line_no == 1
    assert val.column_no == 2
    assert val.char_index == 3
    assert val == Position(1,2,3)
    # Unit test for equality of class Position
    assert val == Position(1,2,3)
    assert val != Position(1,2,3)
    assert val != Position(1,2,3)
    assert val != Position(1,2,3)
    assert val != Position(1,2,3)
    assert val != Position(1,2,3)
    assert val != Position(1,2,3)
    assert val != Position(1,2,3)
    assert val != Position(1,2,3)
    assert val != Position(1,2,3)

# Generated at 2022-06-24 10:31:40.399145
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    input1 = Position(9, 5, 1)
    input2 = Position(9, 5, 1)
    output = Position.__eq__(input1, input2)
    expected_output = True
    assert output == expected_output


    input1 = Position(-6, 6, 1)
    input2 = Position(8, 8, 1)
    output = Position.__eq__(input1, input2)
    expected_output = False
    assert output == expected_output

    input1 = Position(9, 9, 9)
    input2 = Position(9, 5, 1)
    output = Position.__eq__(input1, input2)
    expected_output = False
    assert output == expected_output

    input1 = Position(9, 9, 9)
    input2 = Position(9, 9, 9)
   

# Generated at 2022-06-24 10:31:42.241546
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult(value='test')
    assert result.value == 'test'
    assert result.error is None

    result = ValidationResult(error='test')
    assert result.value is None
    assert result.error == 'test'

# Generated at 2022-06-24 10:31:51.630430
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    msg1 = Message(text='abc', code='123', index=[0, 1],
        start_position=Position(line_no=1, column_no=2, char_index=0),
        end_position=Position(line_no=1, column_no=5, char_index=3),
    )
    msg2 = Message(text='abc', code='123', index=[0, 1],
        start_position=Position(line_no=1, column_no=2, char_index=0),
        end_position=Position(line_no=1, column_no=5, char_index=3),
    )

# Generated at 2022-06-24 10:31:54.941591
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    message = Message(text ="未知的错误代码", code ="custom", key="username", index=["username"])
    assert isinstance(hash(message), int)

# Generated at 2022-06-24 10:32:05.074520
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    msg = Message(text='No more than 100 characters', code='max_length', key='username', index=['username'])
    assert msg.__repr__() == f"Message(text='No more than 100 characters', code='max_length', index=['username'])"
    msg = Message(text='No more than 100 characters', code='max_length', key='username', index=['users', 3])
    assert msg.__repr__() == f"Message(text='No more than 100 characters', code='max_length', index=['users', 3])"
    msg = Message(text='No more than 100 characters', position=Position(line_no=1, column_no=1, char_index=1), index=['username'])

# Generated at 2022-06-24 10:32:15.538501
# Unit test for constructor of class BaseError
def test_BaseError():
    msg = Message("Hello, world!")
    b = BaseError()
    assert b._messages == []
    assert b._message_dict == {}
    c = BaseError(messages=[msg])
    assert c._messages == [msg]
    assert c._message_dict == {}
    d = BaseError(text=msg.text, code=msg.code, key=msg.index[0])
    assert d._messages == [msg]
    assert d._message_dict == {"": msg.text}
    e = BaseError()
    assert e._messages == []
    assert e._message_dict == {}
    f = BaseError(messages=[msg])
    assert f._messages == [msg]
    assert f._message_dict == {}

# Generated at 2022-06-24 10:32:20.861191
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="The message") == BaseError(text="The message")
    assert BaseError(text="The message") != BaseError(text="The message 1")
    assert BaseError(text="The message", index=["a"]) != BaseError(text="The message")
    assert BaseError(text="The message") == BaseError(messages=[Message(text="The message")])
    assert BaseError(text="The message") != BaseError(messages=[Message(text="The message 1")])
    assert BaseError(text="The message", index=["a"]) != BaseError(messages=[Message(text="The message")])
    assert BaseError(messages=[Message(text="The message")]) == BaseError(messages=[Message(text="The message")])

# Generated at 2022-06-24 10:32:31.516723
# Unit test for constructor of class Message
def test_Message():
    message1 = Message(text="", code=None, key=None, index=None, position=None, start_position=None, end_position=None)
    assert message1.text == ""
    assert message1.code == "custom"
    assert message1.index == []
    assert message1.start_position is None
    assert message1.end_position is None

    message2 = Message(text="test", code="test_code", key="test_key", index=["test_index1", "test_index2"], position=Position(line_no=1, column_no=1, char_index=1), start_position=None, end_position=None)
    assert message2.text == "test"
    assert message2.code == "test_code"

# Generated at 2022-06-24 10:32:39.215492
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    if (ValidationResult().__bool__() == True):
        print("Test 1 passed")
    else:
        print("Test 1 failed")
    if (ValidationResult(error=ValidationError()).__bool__() == False):
        print("Test 2 passed")
    else:
        print("Test 2 failed")
    if (ValidationResult(value=1).__bool__() == True):
        print("Test 3 passed")
    else:
        print("Test 3 failed")


# Generated at 2022-06-24 10:32:44.266793
# Unit test for constructor of class Position
def test_Position():
    position = Position(1, 2, 3)
    assert repr(position) == "Position(line_no=1, column_no=2, char_index=3)"
    assert position == Position(1, 2, 3)
    assert position != Position(2, 2, 3)
    assert position != Position(1, 1, 3)
    assert position != Position(1, 2, 4)


# Generated at 2022-06-24 10:32:44.814396
# Unit test for constructor of class BaseError
def test_BaseError():
    BaseError

# Generated at 2022-06-24 10:32:49.546141
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Init
    messages = [Message(text='TEST_TEXT_1'), Message(text='TEST_TEXT_2')]
    test_BaseError = BaseError(messages=messages)
    test_BaseError__ = BaseError(messages=messages)
    other = {'other': 'other'}
    # Action
    # Test
    assert test_BaseError == test_BaseError
    assert test_BaseError == test_BaseError__
    assert test_BaseError != other


# Generated at 2022-06-24 10:32:57.146601
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    base_error = BaseError(messages=[Message(key="eric", text="text_eric", code="code_eric"), Message(key="eric", text="text_eric_2", code="code_eric_2")])
    assert repr(base_error) == "BaseError([Message(text='text_eric', code='code_eric', index=['eric'], start_position=None, end_position=None), Message(text='text_eric_2', code='code_eric_2', index=['eric'], start_position=None, end_position=None)])"



# Generated at 2022-06-24 10:33:05.661839
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    with pytest.raises(AssertionError):
        ValidationResult()
    with pytest.raises(AssertionError):
        ValidationResult(value=[1, 2], error=[1])

    ValidationResult(value=[1, 2]) == ValidationResult(value=[1, 2])
    ValidationResult(value=[1, 2]) != ValidationResult(value=[1, 3])
    ValidationResult(error=[1, 2]) == ValidationResult(error=[1, 2])
    ValidationResult(error=[1, 2]) != ValidationResult(error=[1, 3])

    ValidationResult(value=[1, 2]) == (1, 2)
    ValidationResult(error=[1, 2]) == ([1], [2])

# Generated at 2022-06-24 10:33:07.213692
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert tuple(ValidationResult(value=1, error=None)) == (1, None)
    assert tuple(ValidationResult(value=None, error=ValidationError(text="hi"))) == (None, ValidationError(text="hi"))


# Generated at 2022-06-24 10:33:09.136829
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    validation_result = ValidationResult(value=5)
    assert validation_result.value == 5


if __name__ == "__main__":
    import sys

    assert sys.version_info >= (3, 7), "Python 3.7 or above required"

    test_ValidationResult()

# Generated at 2022-06-24 10:33:16.855266
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    """Unit test for method __getitem__ of class BaseError"""
    error_obj = BaseError(messages=[Message(text='aaa'), Message(text='bbb', key=1), Message(text='ccc', key=2)])
    assert error_obj[''] == 'aaa'
    assert error_obj[1] == 'bbb'
    assert error_obj[2] == 'ccc'
    with pytest.raises(KeyError) as exc:
        error_obj[3]
    assert '3' == str(exc.value)



# Generated at 2022-06-24 10:33:19.322442
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    fct = ValidationResult.__iter__
    assert fct.__name__ == "__iter__"
    assert isinstance(fct, collections.abc.Iterator)

# Generated at 2022-06-24 10:33:28.903097
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    msg_lst = [
        Message(
            text="Abc",
            code="efg",
            key="a",
            start_position=Position(1,2,3),
            end_position=Position(3,4,5)
        ),
        Message(
            text="Abc",
            code="efg",
            key="b",
            start_position=Position(1,2,3),
            end_position=Position(3,4,5)
        ),
        Message(
            text="Abc",
            code="efg",
            key="c",
            start_position=Position(1,2,3),
            end_position=Position(3,4,5)
        )
    ]

    # No input cases

# Generated at 2022-06-24 10:33:35.410967
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test 1
    messages1 = [Message(text='Error 1', code='code1', key='key1', start_position=Position(line_no=1, column_no=1, char_index=0), end_position=Position(line_no=1, column_no=1, char_index=0)),
                 Message(text='Error 2', code='code2', key='key2'),
                 Message(text='Error 3', code='code3', key='key3')
                 ]

# Generated at 2022-06-24 10:33:41.094750
# Unit test for constructor of class ValidationError
def test_ValidationError():
    error_message = Message("error")
    ValidationError(messages=[error_message])
    ValidationError(text="error")
    ValidationError.__init__(
        ValidationError(),
        text="error",
    )
    ValidationError(
        text="error",
        code="code",
        key="key",
        position=Position(1, 2, 3),
    )
    ValidationError(
        text="error",
        start_position=Position(1, 2, 3),
        end_position=Position(1, 4, 5),
    )

# Generated at 2022-06-24 10:33:49.571037
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    # Setup
    line_no_1 = 1
    column_no_1 = 1
    char_index_1 = 1
    position_1 = Position(line_no=line_no_1, column_no=column_no_1, char_index=char_index_1)
    expected_repr_1 = "Position(line_no=1, column_no=1, char_index=1)"

    # Exercise
    repr_1 = repr(position_1)

    # Verify
    assert repr_1 == expected_repr_1


# Generated at 2022-06-24 10:33:59.062880
# Unit test for constructor of class ValidationError
def test_ValidationError():
    # Test for instantiate the class with a single text and key
    text = "Test"
    key = 1
    ve = ValidationError(text=text, key=key)
    assert isinstance(ve, BaseError)
    assert ve.messages() == [Message(text=text, key=key)]
    assert ve.messages(add_prefix=key) == [Message(text=text, key=[1])]
    assert list(ve) == [text]
    assert len(ve) == 1
    assert ve[key] == text
    assert ve.messages() == [Message(text=text, key=key)]
    assert ve.messages(add_prefix=key) == [Message(text=text, key=[1])]
    assert str(ve) == text

# Generated at 2022-06-24 10:34:03.202678
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    v = ValidationResult(value = 'hello')
    assert len(v) == 2
    assert v[0] == 'hello'
    assert v[1] == None


# Generated at 2022-06-24 10:34:05.489722
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    e = BaseError(text='hi', code='hi', key='hi', position='hi', messages='hi')
    assert e.messages() == "hi"

# Generated at 2022-06-24 10:34:13.329360
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    class_name = 'Position'
    line_no = 3
    column_no = 5
    char_index = 8
    position = Position(line_no, column_no, char_index)
    assert position.__eq__(position)
    other_position_1 = Position(line_no, column_no, char_index)
    assert position.__eq__(other_position_1) 
    other_position_2 = Position(line_no - 1, column_no, char_index)
    assert not position.__eq__(other_position_2) 
    other_position_3 = Position(line_no, column_no - 1, char_index)
    assert not position.__eq__(other_position_3) 

# Generated at 2022-06-24 10:34:21.180224
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    from typesystem.base import Message
    from typesystem.base import Position
    position = Position(line_no=1, column_no=2, char_index=3)
    message = Message(text="this is an error", code="custom", key="name",
                      index=['users', 3, 'username'], position=position)
    assert message.__repr__() == \
           "Message(text='this is an error', code='custom', index=['users', 3, 'username'], position=Position(line_no=1, column_no=2, char_index=3))"

# Generated at 2022-06-24 10:34:30.966527
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    # Prepare
    from typesystem import String

    # Execute
    my_schema = String(max_length=10, min_length=4)
    error = my_schema.validate_or_error('12345678901234567890')[1]

    # Expect
    assert error.messages()[0].start_position.line_no == 1
    assert error.messages()[0].start_position.column_no == 0
    assert error.messages()[0].start_position.char_index == 0
    assert error.messages()[0].end_position.line_no == 1
    assert error.messages()[0].end_position.column_no == 20
    assert error.messages()[0].end_position.char_index == 20


# Generated at 2022-06-24 10:34:34.532816
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)
    assert Position(1, 2, 3) != 1


# Generated at 2022-06-24 10:34:39.519219
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    messages = [
        Message(text="may not be empty"),
        Message(text="may not be longer than 100 characters", key="name"),
    ]
    error = BaseError(messages=messages)
    assert str(error) == "{'': 'may not be empty', 'name': 'may not be longer than 100 characters'}"



# Generated at 2022-06-24 10:34:41.312395
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert iter(vr)


# Generated at 2022-06-24 10:34:42.562969
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    error = BaseError(messages=[Message(text="x")])
    assert error.messages() == [Message(text="x")]


# Generated at 2022-06-24 10:34:49.834926
# Unit test for constructor of class Message
def test_Message():
    m = Message(text="text", code="code", key="key", position=Position(1, 1, 1),
                start_position=Position(2, 1, 1), end_position=Position(3, 1, 1)
                )
    assert m.text == "text"
    assert m.code == "code"
    assert m.index == ["key"]
    assert m.start_position == m.end_position
    assert m.start_position == Position(2, 1, 1)

    m = Message(text="text", code="code", index=["key", 1, "key2"], position=Position(1, 1, 1),
                start_position=Position(2, 1, 1), end_position=Position(3, 1, 1)
                )
    assert m.text == "text"

# Generated at 2022-06-24 10:34:53.555829
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():

    # Type test
    assert isinstance(BaseError().__len__(), int)
    assert isinstance(BaseError(messages=[Message(text="error1")]).__len__(), int)
    assert isinstance(BaseError(text="error1").__len__(), int)

# Generated at 2022-06-24 10:35:01.880209
# Unit test for constructor of class ValidationError
def test_ValidationError():
    # Helper function for testing
    def init_as_dict(d: dict):
        d = dict(d)
        for key, val in d.items():
            if isinstance(val, dict):
                d[key] = init_as_dict(val)
        return ValidationError(messages=[Message(index=[], text=text)])

    # Test initialization with a single error message
    text = "Test error message"
    error = ValidationError(text=text)
    assert error.messages() == [Message(text=text, code="custom")]
    assert dict(error) == {"": error.messages()[0].text}

    # Test initialization with a list of error messages
    error = ValidationError(messages=[Message(index=[], text="Test error")])

# Generated at 2022-06-24 10:35:03.990677
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    """
    All field are not None
    """
    a = ValidationResult(value="a", error="b")
    assert not a



# Generated at 2022-06-24 10:35:11.324936
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    message1 = Message(text="text")
    message2 = Message(text="text")
    message3 = Message(text="text", code="code")
    message4 = Message(text="text", code="code")
    message5 = Message(text="text", key="key")
    message6 = Message(text="text", key="key")
    message7 = Message(text="text", code="code", index=["index"])
    message8 = Message(text="text", code="code", index=["index"])

    assert hash(message1) == hash(message1)
    assert hash(message2) == hash(message2)
    assert hash(message3) == hash(message3)
    assert hash(message4) == hash(message4)
    assert hash(message5) == hash(message5)

# Generated at 2022-06-24 10:35:14.996863
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    # Initialization of message for unit testing
    message = Message(text = "", code = "", key = None, index = [], start_position = None, end_position = None, )
    assert hash(message) == hash(())

# Generated at 2022-06-24 10:35:23.516710
# Unit test for constructor of class ValidationError
def test_ValidationError():
    # test __init__() with valid inputs
    message = "May not have more than 100 characters"
    key = "username"
    position = Position(1, 1, 1)
    error = ValidationError(text=message, key=key, position=position)

    assert error.messages() == [
        Message(text=message, key=key, position=position)
    ]

    message1 = "May not have more than 100 characters"
    key1 = "username"
    position1 = Position(1, 1, 1)

    message2 = "Must have more than 10 characters"
    key2 = "password"
    position2 = Position(1, 11, 1)


# Generated at 2022-06-24 10:35:27.033367
# Unit test for constructor of class Position
def test_Position():
    p = Position(1, 1, 1)
    assert p.line_no == 1 and p.column_no == 1 and p.char_index == 1


# Generated at 2022-06-24 10:35:28.321826
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    assert hash(BaseError()) == hash(BaseError())

