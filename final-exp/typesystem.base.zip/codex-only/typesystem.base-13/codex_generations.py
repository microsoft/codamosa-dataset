

# Generated at 2022-06-24 10:25:30.042438
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    self = BaseError(messages=[Message(text='error text')])
    self.messages()



# Generated at 2022-06-24 10:25:33.555031
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    instance = Message()
    assert(instance.__repr__() == "Message(text=None, code='custom', index=[])")

# Generated at 2022-06-24 10:25:42.250011
# Unit test for method __eq__ of class Message

# Generated at 2022-06-24 10:25:44.277262
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 0) == Position(1, 2, 0)
    assert not Position(1, 2, 0) == Position(2, 2, 0)


# Generated at 2022-06-24 10:25:46.621316
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    error= BaseError()
    assert error.__repr__() == 'BaseError({})'
    return

# Generated at 2022-06-24 10:25:49.674026
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult()
    assert not isinstance(result, Iterable)

    result = ValidationResult(value=True)
    assert not isinstance(result, Iterable)

    result = ValidationResult(error=ValidationError())
    assert isinstance(result, Iterable)
    assert next(iter(result)) is None
    assert next(iter(result)) is not None

test_ValidationResult___iter__()

# Generated at 2022-06-24 10:25:53.276914
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    assert bool(ValidationResult(value=0))
    assert not bool(ValidationResult(error=None))
    assert not bool(ValidationResult(error=0))
    assert not bool(ValidationResult(error='error'))

# Generated at 2022-06-24 10:25:58.993729
# Unit test for constructor of class ValidationError
def test_ValidationError():
    c = ValidationError(text = "May not have more than 100 characters", code = "max_length", key = 1)
    assert 'May not have more than 100 characters' == c.messages()[0].text
    assert ['1'] == c.messages()[0].index
    assert ['1'] == c._message_dict.keys()
    assert {"May not have more than 100 characters"} == set(c.values())


# Generated at 2022-06-24 10:26:07.410181
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    error = BaseError(messages=[Message(text="First message"), Message(text="Second message")])
    messages = error.messages()
    assert len(messages) == 2
    expected_messages = [Message(text="First message"), Message(text="Second message")]
    assert messages == expected_messages

    messages = error.messages(add_prefix="users")
    assert len(messages) == 2
    expected_messages = [Message(text="First message", index=["users"]), Message(text="Second message", index=["users"])]
    assert messages == expected_messages

    messages = error.messages(add_prefix=1)
    assert len(messages) == 2
    expected_messages = [Message(text="First message", index=[1]), Message(text="Second message", index=[1])]

# Generated at 2022-06-24 10:26:16.407423
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(line_no=1, column_no=2, char_index=3) == Position(line_no=1, column_no=2, char_index=3)
    assert Position(line_no=1, column_no=2, char_index=3) == Position(line_no=1, column_no=2, char_index=4)
    assert Position(line_no=1, column_no=2, char_index=3) == Position(line_no=1, column_no=3, char_index=3)
    assert Position(line_no=1, column_no=2, char_index=3) == Position(line_no=2, column_no=2, char_index=3)

# Generated at 2022-06-24 10:26:27.884162
# Unit test for constructor of class BaseError
def test_BaseError():
    # Instantiated as a ValidationError with a single error message
    msg = Message(text="err message")
    error = BaseError(text="err message", code="custom")

    assert msg == error._messages[0]
    assert error._message_dict == {"": "err message"}
    assert msg.text == error._messages[0].text

    assert msg == error.messages(add_prefix="add text")[0]
    assert isinstance(error.messages(add_prefix="add text"), list)

    assert list(error.keys()) == [""]
    assert list(error.values()) == ["err message"]
    assert list(error.items()) == [("", "err message")]
    assert len(error) == 1

    assert error[""] == "err message"

# Generated at 2022-06-24 10:26:31.680035
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    result_ok = ValidationResult(value=2)
    assert bool(result_ok) == True
    result_fail = ValidationResult(error=ValidationError(text='error'))
    assert bool(result_fail) == False

# Generated at 2022-06-24 10:26:35.205936
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    position = Position(line_no=1, column_no=2, char_index=3)

    result = repr(position)
    expected = "Position(line_no=1, column_no=2, char_index=3)"

    assert result == expected


# Generated at 2022-06-24 10:26:37.736417
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    a = Position(line_no=1, column_no=2, char_index=3)
    assert repr(a) == "Position(line_no=1, column_no=2, char_index=3)"


# Generated at 2022-06-24 10:26:41.467913
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    assert repr(BaseError(messages=[Message(text='foo')])) == "BaseError([Message(text='foo', code='custom')])"
    assert repr(BaseError(messages=[Message(text='foo', index=['bar'])])) == "BaseError([Message(text='foo', code='custom', index=['bar'])])"


# Generated at 2022-06-24 10:26:45.934786
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    error = ValidationError(
        messages=[
            Message(text="item 0", index=[0]),
            Message(text="item 1", index=[1]),
            Message(text="item 2", index=[2]),
            Message(text="item 3", index=[3]),
            Message(text="item 4", index=[4]),
        ]
    )
    assert str(error) == "{0: 'item 0', 1: 'item 1', 2: 'item 2', 3: 'item 3', 4: 'item 4'}"

# Generated at 2022-06-24 10:26:48.903466
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    from typet import Message
    '''
    Test for method __repr__ of class Message
    '''
    m = Message(text="May not have more than 100 characters", code="max_length", key="username")

    # 以下内容为测试代码，可以根据需要修改
    assert str(m) == "Message(text='May not have more than 100 characters', code='max_length', index=['username'])"

# Generated at 2022-06-24 10:26:51.340507
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    # hash_function should be a function which takes exactly one argument
    # and returns an integer
    assert hasattr(Message(text="Hello").__hash__, "__call__")

# Generated at 2022-06-24 10:26:56.134126
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    vr = ValidationResult(value=18)
    vr_string = repr(vr)
    assert vr_string == "ValidationResult(value=18)"
    vr = ValidationResult(error=ValidationError(text="Empty string"))
    vr_string = repr(vr)
    assert vr_string == "ValidationResult(error=ValidationError(text='Empty string'))"

# Generated at 2022-06-24 10:27:05.355571
# Unit test for constructor of class Message
def test_Message():
    msg = Message(
        text="May not have more than 100 characters",
        code="max_length",
        key="username",
        index=["users", 3, "username"],
        position=Position(line_no=3, column_no=8, char_index=71),
    )
    assert msg.text == "May not have more than 100 characters"
    assert msg.code == "max_length"
    assert msg.key == "username"
    assert msg.index == ["users", 3, "username"]
    assert msg.position.line_no == 3
    assert msg.position.column_no == 8
    assert msg.position.char_index == 71


# Generated at 2022-06-24 10:27:12.691329
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    # case 1: no arguments
    result = ValidationResult()
    assert result.value is None
    assert result.error is None
    
    # case 2: value is not None
    result = ValidationResult(value=1)
    assert result.value == 1
    assert result.error is None

    # case 3: error is not None
    result = ValidationResult(error="error")
    assert result.value is None
    assert result.error == "error"


# Generated at 2022-06-24 10:27:17.557826
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    line_no = 10
    column_no = 20
    char_index = 30
    position = Position(line_no, column_no, char_index)
    assert repr(position) == f"Position(line_no={line_no}, column_no={column_no}, char_index={char_index})"


# Generated at 2022-06-24 10:27:20.280552
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError_test = ParseError()
    print("test_ParseError")
    print("constructor ParseError:")
    print(ParseError_test)
    print("")


# Generated at 2022-06-24 10:27:24.180841
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    messages = [Message(text="msg1", code="err"), Message(text="msg2", code="err")]
    error = BaseError(messages=messages)

    # test iter
    assert list(iter(error)) == [0, 1]


# Generated at 2022-06-24 10:27:25.938288
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    result = ValidationResult()
    assert result.error is None
    assert not result


# Generated at 2022-06-24 10:27:28.423455
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    error = BaseError(messages=[Message(text="abc")])
    result = error.__str__()
    assert result == "abc"



# Generated at 2022-06-24 10:27:33.400462
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    a = Message(text="foo", code="bar", key=1, position=Position(line_no=1, column_no=2, char_index=3))
    b = Message(text="foo", code="bar", key=1, position=Position(line_no=1, column_no=2, char_index=3))
    assert a == b


# Generated at 2022-06-24 10:27:44.041244
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    # Initialising variable
    message = Message(
        text="May not have more than 100 characters",
        code="max_length",
        key="username",
        index=["users", 3, "username"],
        position=Position(line_no=3, column_no=29, char_index=197),
        start_position=Position(line_no=3, column_no=29, char_index=197),
        end_position=Position(line_no=3, column_no=86, char_index=254),
    )

# Generated at 2022-06-24 10:27:47.575965
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    assert hash(ValidationError()) == hash(ValidationError())
    assert hash(ValidationError(text="1")) == hash(ValidationError(text="1"))



# Generated at 2022-06-24 10:27:50.331874
# Unit test for constructor of class Position
def test_Position():
    p = Position(1, 2, 3)
    assert p.line_no == 1
    assert p.column_no == 2
    assert p.char_index == 3


# Generated at 2022-06-24 10:27:52.790966
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    err = BaseError(text="This is error text")
    assert str(err) == "This is error text"


# Generated at 2022-06-24 10:27:55.944371
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    try:
        from typesystem.base import BaseError
    except ImportError:
        pass
    error = BaseError(text="error occurred here")
    assert str(error) == "error occurred here"

# Generated at 2022-06-24 10:27:58.458691
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    validation_result = ValidationResult(value = 'test_value')
    assert validation_result.__bool__() == True




# Generated at 2022-06-24 10:28:05.909253
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    error = BaseError(text="a string")
    r = repr(error)
    assert r == "BaseError(text='a string')"

    error = BaseError(messages=[])
    r = repr(error)
    assert r == "BaseError([])"

    error = BaseError(messages=[Message(text="a string", code="a code", key="a key")])
    r = repr(error)
    assert r == "BaseError([Message(text='a string', code='a code', index=['a key'])])"


# Generated at 2022-06-24 10:28:09.297879
# Unit test for constructor of class BaseError
def test_BaseError():
    error = BaseError()
    error = BaseError(text='Text', code='Code')
    error = BaseError(messages=[Message(text='Text', code='Code')])



# Generated at 2022-06-24 10:28:10.779249
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    from .helper import BaseError___hash__
    BaseError___hash__(BaseError)

# Generated at 2022-06-24 10:28:16.642196
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message = Message(text="abc", code="cde", index=["fgh"], start_position=Position(1, 2, 3), end_position=Position(4, 5, 6))
    other = Message(text="abc", code="cde", index=["fgh"], start_position=Position(1, 2, 3), end_position=Position(4, 5, 6))
    assert message == other
    assert not message == "abc"
    assert not message == None
    assert not message == 123


# Generated at 2022-06-24 10:28:19.389116
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    BaseError._message_dict={"x": "y"}
    res=BaseError.__getitem__("x")
    assert res == "y"

# Generated at 2022-06-24 10:28:29.399662
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    expectedMessage = ['May not have more than 100 characters']
    expectedText = expectedMessage[0]
    expectedCode = "ValueError"
    expectedKey = "CodeError"
    expectedIndex = [1, 2, 3]
    expectedStartPosition = Position(1, 2, 3)
    expectedEndPosition = Position(4, 5, 6)

    # Test 1
    messageWithKey = Message(
        text=expectedText,
        code=expectedCode,
        index=expectedIndex,
        key=expectedKey
    )

    error = BaseError(messages=[messageWithKey])

    result = error[expectedKey]
    assert result == expectedText
    # End Test 1

    # Test 2

# Generated at 2022-06-24 10:28:29.989974
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    pass

# Generated at 2022-06-24 10:28:37.317305
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    class_name = "BaseError"
    text1 = 'text1'
    code1 = 'code1'
    key1 = 'key1'
    position1 = Position(1,2,3)
    print(BaseError(text=text1, code=code1, key=key1, position=position1))
    print(BaseError(messages=[Message(text=text1, code=code1, key=key1, position=position1), Message(text=text1, code=code1, key=key1, position=position1)]))
test_BaseError___repr__()

# Generated at 2022-06-24 10:28:42.213791
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vresult = ValidationResult(value=1)
    for v, e in vresult:
        assert v == 1
        assert e is None
    vresult = ValidationResult(error=ValidationError(text='test error'))
    for v, e in vresult:
        assert v is None
        assert e == ValidationError(text='test error')


# Generated at 2022-06-24 10:28:50.001474
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    assert hash(Message(text="More than 100 characters", code="max_length", key="username")) == hash(
        Message(text="More than 100 characters", code="max_length", key="username")
    )
    assert hash(Message(text="More than 100 characters", code="max_length", index=["username"])) == hash(
        Message(text="More than 100 characters", code="max_length", index=["username"])
    )
    assert hash(Message(text="More than 100 characters", code="max_length", index=["user", "username"])) == hash(
        Message(text="More than 100 characters", code="max_length", index=["user", "username"])
    )

# Generated at 2022-06-24 10:28:52.495291
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    try:
        raise ValidationError(text="An error message.")
    except ValidationError as ve:
        assert str(ve) == "An error message."


# Generated at 2022-06-24 10:29:03.325652
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    error = BaseError(messages=[Message(text='field is required')])
    assert str(error) == "{'': 'field is required'}"
    error = BaseError(messages=[Message(text='field is required', code='required')])
    assert str(error) == "{'': 'field is required'}"
    error = BaseError(messages=[Message(text='field is required', index=['users', 0, 'username'])])
    assert str(error) == "{'users': {0: {'username': 'field is required'}}}"
    error = BaseError(messages=[Message(text='field is required', index=['users', 0, 'username'], code='required')])
    assert str(error) == "{'users': {0: {'username': 'field is required'}}}"

# Generated at 2022-06-24 10:29:11.743432
# Unit test for method __repr__ of class Message
def test_Message___repr__():
  text = "Error"
  code = 'email_invalid'
  key = "email"
  index = [0, "email"]
  line_no = 1
  column_no = 2
  char_index = 3
  position = Position(line_no,column_no,char_index)
  start_position = Position(line_no,column_no,char_index)
  end_position = Position(line_no,column_no,char_index)
  message = Message(text=text,code=code,key=key,index=index,position=position,start_position=start_position,end_position=end_position)

# Generated at 2022-06-24 10:29:19.249848
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    obj = Position(0, 0, 0)
    exp_cls_name = f'Position'
    cls_name = obj.__class__.__name__
    assert cls_name == exp_cls_name

    exp_str = f"{exp_cls_name}(line_no={obj.line_no}, column_no={obj.column_no}, char_index={obj.char_index})"
    assert str(obj) == exp_str

test_Position___repr__()


# Generated at 2022-06-24 10:29:20.448003
# Unit test for constructor of class ValidationError
def test_ValidationError():
    try:
        raise ValidationError(text="hello")
    except ValidationError:
        print("pass")


# Generated at 2022-06-24 10:29:27.058848
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    # Arrange
    messages = [
        Message(text="Foo error", index=[0, "address", "city"]),
        Message(text="Bar error", index=[0, "address", "postcode"]),
        Message(text="Postcode error", index=[0, "address", "postcode"]),
        Message(text="Baz error", index=[1, "postcode"]),
    ]
    error = BaseError(messages=messages)

    # Act
    messages0_address = error[0]["address"]
    messages0_address_city = error[0]["address"]["city"]
    messages0_address_postcode = error[0]["address"]["postcode"]
    messages1_postcode = error[1]["postcode"]

    # Assert

# Generated at 2022-06-24 10:29:37.350336
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    class _ExpectedException(Exception):
        pass

    def __iter__(self):
        raise _ExpectedException()
    BaseError.__iter__ = __iter__

    class BaseErrorTest(BaseError):
        def __init__(self):
            BaseError.__init__(self, text="", code="", key="")
            self.assert_called = False
    BaseErrorTest.__iter__ = __iter__

    obj = BaseErrorTest()
    try:
        for _ in obj:
            pass
    except _ExpectedException:
        obj.assert_called = True
    if not obj.assert_called:
        raise AssertionError("__iter__ not called")



# Generated at 2022-06-24 10:29:42.759314
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    """
    It should test that BaseError.__hash__(self) raises a TypeError when self is NoneType.
    
    """
    # Define variables
    Base_Error = None
    
    # Call function
    with pytest.raises(TypeError):
        BaseError.__hash__(Base_Error)


# Generated at 2022-06-24 10:29:47.139881
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    error = BaseError(text="text", code="code")
    assert hash(error) == hash(BaseError(text="text", code="code"))
    assert hash(error) != hash(BaseError(text="text", code="code1"))
    assert hash(error) != hash(BaseError(text="text1", code="code"))



# Generated at 2022-06-24 10:29:57.787597
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    message_00 = Message(text="This should not have more than 100 characters.",
                          code="max_length",
                          key="first_name",
                          position=Position(line_no=1, column_no=2, char_index=3))
    assert message_00.__repr__() == \
           "Message(text='This should not have more than 100 characters.', code='max_length', index=['first_name'], position=Position(line_no=1, column_no=2, char_index=3))"

    message_01 = Message(text="This should not have more than 100 characters.",
                          code="max_length",
                          index=["first_name"],
                          position=Position(line_no=1, column_no=2, char_index=3))

# Generated at 2022-06-24 10:29:59.584715
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    ValidationResult(value='value')
    ValidationResult(error='error')
    ValidationResult()

# Generated at 2022-06-24 10:30:01.058205
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
  b = BaseError(text='error')
  assert len(b) == 1

# Generated at 2022-06-24 10:30:06.066581
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    # Test if the length of BaseError is the same as the length of its messages
    messages = [
        Message(text="1"),
        Message(text="2"),
    ]
    error = BaseError(messages=messages)
    assert len(error) == len(messages)


# Generated at 2022-06-24 10:30:14.282835
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    assert list(BaseError(messages=[Message(text="Test message")])) == []
    assert (
        list(BaseError(messages=[Message(key="Test key", text="Test message")]))
        == ["Test key"]
    )
    assert (
        list(
            BaseError(
                messages=[Message(index=[1, "Test key"], text="Test message")]
            )
        )
        == [1]
    )
    assert (
        list(
            BaseError(
                messages=[
                    Message(index=[1, "Test key"], text="Test message"),
                    Message(index=[2, "Test key"], text="Test message"),
                ]
            )
        )
        == [1, 2]
    )

# Generated at 2022-06-24 10:30:23.944503
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    error = BaseError(text="A", key="a")
    text = error["a"]
    assert text == "A"
    error = BaseError(text="B", key="a", index=["b"])
    value = error["b"]
    assert "a" in value
    text = value["a"]
    assert text == "B"
    error = BaseError(text="C", key="c", index=["d", 0])
    value = error["d"]
    assert 0 in value
    value = value[0]
    assert "c" in value
    text = value["c"]
    assert text == "C"
    error = BaseError(messages=[Message(text="D", key="d")])
    text = error["d"]
    assert text == "D"

# Generated at 2022-06-24 10:30:33.841848
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    a = BaseError(text="Text")
    b = a
    c = BaseError(text="Text")
    assert a == b
    assert a == c
    assert a == a
    assert b == a
    assert b == c
    assert c == a
    assert c == b
    assert c == c
    d = BaseError(text="Text", key="key")
    assert a == d
    assert b == d
    assert c == d
    assert d == a
    assert d == b
    assert d == c
    assert d == d
    e = BaseError(text="Text2")
    assert a != e
    assert b != e
    assert c != e
    assert d != e
    assert e != a
    assert e != b
    assert e != c
    assert e != d
    assert e == e
   

# Generated at 2022-06-24 10:30:36.872195
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    e = BaseError(text='May not have more than 100 characters', code='max_length', key='username')
    assert str(e) == 'May not have more than 100 characters'

# Generated at 2022-06-24 10:30:47.333911
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError()
    assert isinstance(e, Exception)
    assert repr(e) == "ParseError()"
    assert str(e) == "{}"
    assert dict(e) == {}

    e = ParseError(text="Invalid JSON", code="invalid_json", key="password")
    assert repr(e) == "ParseError(text='Invalid JSON', code='invalid_json')"
    assert str(e) == "Invalid JSON"
    assert dict(e) == {"password": "Invalid JSON"}

    e = ParseError(
        messages=[
            Message(text="Error in /foo", index=["foo"]),
            Message(text="Error in /bar", index=["bar"]),
        ]
    )

# Generated at 2022-06-24 10:30:57.746128
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    assert repr(Message(text='May not have more than 100 characters', code='max_length')) == "Message(text='May not have more than 100 characters', code='max_length')"
    assert repr(Message(text='May not have more than 100 characters', code='max_length', key='username')) == "Message(text='May not have more than 100 characters', code='max_length', index=['username'])"
    assert repr(Message(text='May not have more than 100 characters', code='max_length', index=['users', 3, 'username'])) == "Message(text='May not have more than 100 characters', code='max_length', index=['users', 3, 'username'])"
    pos = Position(line_no=1, column_no=2, char_index=3)

# Generated at 2022-06-24 10:31:01.316010
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(error=ValidationError())
    assert tuple(result) == (None, ValidationError())

# Generated at 2022-06-24 10:31:08.983783
# Unit test for constructor of class Message
def test_Message():
    error = Message(
        text = "Error text",
        code = "Some code",
        key = "some_key",
        start_position = Position(1, 2, 3),
        end_position = Position(3, 4, 5),
    )
    assert error.text == "Error text"
    assert error.code == "Some code"
    assert error.index == ["some_key"]
    assert error.start_position == Position(1, 2, 3)
    assert error.end_position == Position(3, 4, 5)

test_Message()

# Generated at 2022-06-24 10:31:12.704367
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    from pyspark.sql import Row
    from python_schema import String, Structure

    class TestSchema(Structure):
        value: String

    TestSchema.validate([Row(value=1)])


# Generated at 2022-06-24 10:31:24.399776
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    error = BaseError(messages=[
        Message(text="One", code="a", key="a"),
        Message(text="Two", code="b", key="b"),
        Message(text="Three", code="c", key="c"),
    ])
    assert error["a"] == "One"
    assert error["b"] == "Two"
    assert error["c"] == "Three"
    assert error["d"] is None
    assert error.messages() == [
        Message(text="One", code="a", key="a"),
        Message(text="Two", code="b", key="b"),
        Message(text="Three", code="c", key="c"),
    ]
    # Unit test for method __getitem__ of class BaseError

# Generated at 2022-06-24 10:31:27.173953
# Unit test for constructor of class ParseError
def test_ParseError():
    errors = ParseError(text='May not have more than 100 characters')
    assert errors.messages() == [Message(text='May not have more than 100 characters')]


# Generated at 2022-06-24 10:31:29.713017
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    class_name = "ValidationResult"
    assert repr(ValidationResult(value='data')) == f"{class_name}(value='data')"
    assert repr(ValidationResult(error='error')) == f"{class_name}(error='error')"

# Generated at 2022-06-24 10:31:36.694611
# Unit test for constructor of class BaseError
def test_BaseError():
    # Instantiated as a ValidationError with a single error message.
    error = BaseError(text="Message", code="code", key="key", position="position")
    assert error._messages
    assert error._message_dict

    # Instantiated as a ValidationError with multiple error messages.
    error = BaseError(messages="messages")
    assert error._messages
    assert error._message_dict



# Generated at 2022-06-24 10:31:41.259965
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    assert repr(BaseError(text="May not be greater than 100", code="max_value")) == "BaseError(text='May not be greater than 100', code='max_value')"
    assert repr(BaseError(messages=[Message(text="May not be greater than 100", code="max_value")])) == "BaseError([Message(text='May not be greater than 100', code='max_value')])"

# Generated at 2022-06-24 10:31:50.770854
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    message = Message(text='blah', code='baz', key='foo')
    assert hash(message) == hash(('baz', ('foo',)))
    assert hash(message) != hash(('baz', ('foo', 'bar')))
    assert hash(message) != hash(('baz', ('foo', 'bar'), ('a', 'b')))
    message = Message(text='blah', code='baz', index=('foo', 'bar'))
    assert hash(message) == hash(('baz', ('foo', 'bar')))
    message = Message(text='blah', code='baz', index=(('foo', 'bar'), 'baz'))
    assert hash(message) == hash(('baz', ('foo', 'bar'), ('baz',)))

# Generated at 2022-06-24 10:32:02.301913
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # TODO: use pytest.mark.parametrize
    es = []
    es.append(
        BaseError(
            text="May not have more than 100 characters",
            code="max_length",
            key="username",
        )
    )
    es.append(
        BaseError(
            text="May not have more than 100 characters",
            code="max_length",
            key="username",
            position=Position(line_no=0, column_no=0, char_index=0),
        )
    )
    es.append(
        BaseError(
            text="May not have more than 100 characters",
            code="max_length",
            key="username",
            position=Position(line_no=3, column_no=5, char_index=5),
        )
    )
   

# Generated at 2022-06-24 10:32:11.595572
# Unit test for constructor of class Message
def test_Message():
    message = Message(text='Message text', code='sample_code', key='sample_key', index=['index 1', 'index 2'])
    assert message.text == 'Message text'
    assert message.code == 'sample_code'
    assert message.index == ['index 1', 'index 2']

    test_message = Message(text='Message text')
    assert message == test_message
    assert hash(message) == hash(test_message)
    assert message.__repr__() == "Message(text='Message text', code='sample_code', index=['index 1', 'index 2'])"


# Generated at 2022-06-24 10:32:17.471003
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=1)
    assert [x for x in result] == [1, None]
    result = ValidationResult(error=1)
    assert [x for x in result] == [None, 1]
    try:
        result = ValidationResult(value=1, error=2)
    except Exception as exc:
        assert str(exc) == 'AssertionError: assert value is None or error is None'


# Generated at 2022-06-24 10:32:24.095084
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    message = Message(text='May not have more than 100 characters', code='max_length', key='username', 
                    position=Position(line_no=1, column_no=1, char_index=1), start_position=Position(line_no=2, column_no=2, char_index=2), 
                    end_position=Position(line_no=3, column_no=3, char_index=3))
    print(f'Test for method __repr__ of class Message: {message}')


# Generated at 2022-06-24 10:32:26.255997
# Unit test for constructor of class ValidationError
def test_ValidationError():
    messages = Message(text="abcde")
    error = ValidationError(messages=messages)
    assert error == ValidationError(messages=messages)



# Generated at 2022-06-24 10:32:33.221646
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    Message1 = Message(text='text_value_17', code='code_value_18', key=19, position=Position(line_no=20, column_no=21, char_index=22), start_position=Position(line_no=23, column_no=24, char_index=25), end_position=Position(line_no=26, column_no=27, char_index=28))
    result = repr(Message1)
    assert result == "Message(text='text_value_17', code='code_value_18', index=(19,), start_position=Position(line_no=23, column_no=24, char_index=25), end_position=Position(line_no=26, column_no=27, char_index=28))"

# Generated at 2022-06-24 10:32:36.782525
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    assert str(ValidationError(messages=[Message(text="error message text")])) == "error message text"


# Generated at 2022-06-24 10:32:46.050086
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    keys = ["key1", "key2", "key3"]
    messages = [Message(text="Message1"), Message(text="Message2"), Message(text="Message3")]
    error = BaseError(messages=messages)
    hash_set = {error}
    for i in range(len(keys)):
        for j in range(i + 1, len(keys)):
            for k in range(j + 1, len(keys)):
                indexs1 = [keys[i], keys[j], keys[k]]
                indexs2 = [keys[k], keys[j], keys[i]]
                indexs3 = [keys[j], keys[k], keys[i]]
                indexs4 = [keys[j]]
                indexs5 = [keys[j], keys[k], keys[i], keys[k]]

# Generated at 2022-06-24 10:32:50.631683
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert_equels(
        Position(0, 0, 0),
        Position(0, 0, 0)
    )
    assert_not_eq(
        Position(0, 0, 0),
        Position(1, 0, 0)
    )
    assert_not_eq(
        Position(0, 0, 0),
        Position(0, 1, 0)
    )
    assert_not_eq(
        Position(0, 0, 0),
        Position(0, 0, 1)
    )



# Generated at 2022-06-24 10:32:52.904952
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    assert ValidationResult(value=1)
    assert not ValidationResult(error=ValidationError(text="error"))


# Generated at 2022-06-24 10:32:56.252076
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    v = ValidationResult(value = True)
    assert v.value
    assert not v.error
    assert bool(v)

    v = ValidationResult(error = "error")
    assert not v.value
    assert v.error
    assert not bool(v)


# Generated at 2022-06-24 10:32:58.518773
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='1', code=None, key=None, index=None, position=None, start_position=None, end_position=None)
    message2 = Message(text='1', code=None, key=None, index=None, position=None, start_position=None, end_position=None)
    assert message1 == message2
    assert not (message1 != message2)


# Generated at 2022-06-24 10:33:07.089780
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    import sys
    import typing
    from typesystem import ValidationError

    def make_subclass(*, error_code):
        class CustomError(ValidationError):
            error_code = error_code
        return CustomError
    ErrorWithErrorCode = make_subclass(error_code='key')
    e1 = ErrorWithErrorCode(text='Text', code='code', key='key')
    repr_e1 = repr(e1)
    assert repr_e1 == "ErrorWithErrorCode(text='Text', code='code')"
    e1_explicit = ErrorWithErrorCode(text='Text', code='code', key='key')
    repr_e1_explicit = repr(e1_explicit)
    assert repr_e1_explicit == "ErrorWithErrorCode(text='Text', code='code')"
   

# Generated at 2022-06-24 10:33:16.469672
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    position_one = Position(line_no=42, column_no=12, char_index=911)
    assert position_one == position_one
    assert position_one != "42"
    assert position_one != Position(line_no=42, column_no=12, char_index=911)
    assert position_one != Position(line_no=42, column_no=12, char_index=912)
    assert position_one != Position(line_no=42, column_no=11, char_index=911)
    assert position_one != Position(line_no=41, column_no=12, char_index=911)
    assert position_one != (42, 12, 911)



# Generated at 2022-06-24 10:33:22.089503
# Unit test for constructor of class Position
def test_Position():
    pos_1 = Position(1, 2, 3)
    pos_2 = Position(1, 2, 3)
    pos_3 = Position(1, 3, 3)
    pos_4 = Position(2, 2, 3)
    pos_5 = Position(2, 2, 4)

    assert pos_1 == pos_2
    assert pos_1 != pos_3
    assert pos_1 != pos_4
    assert pos_1 != pos_5



# Generated at 2022-06-24 10:33:25.433314
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    validate_result = ValidationResult(value={"age":"20"})
    print(validate_result)
    validate_result = ValidationResult(error=str("input is empty"))
    print(validate_result)


# Generated at 2022-06-24 10:33:29.158538
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    pos1 = Position(1, 2, 3)
    pos2 = Position(1, 2, 3)
    msg1 = Message(text='hello', code='', position=pos1)
    msg2 = Message(text='hello', code='', position=pos2)
    assert msg1.__hash__() == msg2.__hash__()

# Generated at 2022-06-24 10:33:32.823342
# Unit test for constructor of class Message
def test_Message():
    text = '1'
    code = '2'
    key = '3'
    position = Position(1,2,3)
    mess = Message(text=text, code=code, key=key, position=position)
    assert mess.text == text
    assert mess.code == code
    assert mess.index == [key]
    assert mess.start_position == mess.end_position == position


# Generated at 2022-06-24 10:33:40.751561
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    print(Message(text="This is a text message"))
    print(Message(index=[1, "a"], text="This is an index message."))
    print(Message(index=[1, "a"], text="This is a position message.", position=Position(3, 2, 5)))
    print(Message(index=[1, "a"], text="This is a start_position and end_position message.", start_position=Position(3, 2, 5), end_position=Position(3, 2, 5)))
    print(Message(index=[1, "a"], text="This is a messages message.", messages=[Message(text="Inner message 1"), Message(text="Inner message 2")]))

# Generated at 2022-06-24 10:33:48.648636
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    result = BaseError(
        text="May not have more than 100 characters",
        code="max_length",
        key="username",
        position=Position(
            line_no=1, column_no=1, char_index=0
        )
    ).messages()
    assert result[0] == Message(text="May not have more than 100 characters", code="max_length", index=["username"], position=Position(line_no=1, column_no=1, char_index=0))



# Generated at 2022-06-24 10:33:51.495279
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    vr = ValidationResult(value=0)
    assert bool(vr)
    vr = ValidationResult(error=ValidationError())
    assert not bool(vr)

# Generated at 2022-06-24 10:33:59.981228
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    value = 'one'
    error = ValidationError(text = 'error')

    result = ValidationResult(value = value)
    assert(result.value == value)
    assert(result.error is None)
    assert(len(result.__dict__) == 2)

    result = ValidationResult(error = error)
    assert(result.value is None)
    assert(type(result.error) is ValidationError)
    assert(result.error.text == 'error')
    assert(len(result.__dict__) == 2)

    result = ValidationResult(value = value, error = error)
    assert(result.value == value)
    assert(result.error == error)
    assert(len(result.__dict__) == 2)

# Generated at 2022-06-24 10:34:03.705332
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    error = ValidationError(messages=[
        Message(text='May not have more than 100 characters', key='username'),
    ])
    assert len(error) == 1
    

# Generated at 2022-06-24 10:34:12.359734
# Unit test for constructor of class BaseError
def test_BaseError():
    
    err = BaseError()
    print(err)
    assert(len(err) == 0)
    err1 = BaseError(key='foo')
    assert(len(err1) == 0)
    err1['foo'] = 'bar'
    assert(err1['foo'] == 'bar')
    assert ('foo' in err1)
    assert ('foobar' not in err1)
    m = err1.messages()
    assert(len(m) == 0)
    err1.messages(add_prefix='foobar')
    m = err1.messages(add_prefix='foobar')
    assert(len(m) == 0)
    err1['foo']['bar'] = 'foobar'
    assert(len(err1) == 1)

# Generated at 2022-06-24 10:34:13.971971
# Unit test for constructor of class ValidationError
def test_ValidationError():
    assert ValidationError(text="test", code="test", key="test", position="test") == {'test': 'test'}

# Generated at 2022-06-24 10:34:17.736728
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult(value="value")
    assert result
    assert result.value == "value"
    assert result.error is None

    result = ValidationResult(error="error")
    assert not result
    assert result.value is None
    assert result.error == "error"

    result = ValidationResult()
    assert not result
    assert result.value is None
    assert result.error is None

# Generated at 2022-06-24 10:34:22.463000
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    v = ValidationResult(value = 10)
    assert v.value == 10
    assert v.error == None
    w = ValidationResult(error = ValidationError("error"))
    assert w.value == None
    assert w.error == ValidationError("error")

# Generated at 2022-06-24 10:34:28.254290
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result1 = ValidationResult(value=1)
    assert result1.value == 1 and result1.error == None

    result2 = ValidationResult(error="error")
    assert result2.value == None and result2.error == "error"

Result = ValidationResult
"""
An alias for `ValidationResult`.

Deprecated: Use `ValidationResult` instead.
"""
assert not typing.TYPE_CHECKING


# Generated at 2022-06-24 10:34:35.361291
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    import json
    class BaseError:
        def __init__(self, *, text: str = None, code: str = None, key: typing.Union[int, str] = None, position: Position = None, messages: typing.List[Message] = None):
            if messages is None:
                assert text is not None
                messages = [Message(text=text, code=code, key=key, position=position)]
            else:
                assert text is None
                assert code is None
                assert key is None
                assert position is None
                assert len(messages)
            self._messages = messages
            self._message_dict: typing.Dict[
                typing.Union[int, str], typing.Union[str, dict]
            ] = {}
            for message in messages:
                insert_into = self._message_dict
               

# Generated at 2022-06-24 10:34:45.160272
# Unit test for constructor of class ValidationError
def test_ValidationError():
    validation_error = ValidationError(text='The data is not valid', code='invalid_data', key='data')
    validation_error2 = ValidationError(text='The data is not valid', code='invalid_data', key='data')
    validation_error3 = ValidationError(text='The data is not valid', code='invalid_data')
    assert validation_error == validation_error2
    assert validation_error != validation_error3
    assert validation_error.messages() == validation_error2.messages()
    assert validation_error != validation_error2.messages()

    validation_error = ValidationError(messages=[Message(text='The data is not valid', code='invalid_data', key='data')])

# Generated at 2022-06-24 10:34:48.685007
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    error = BaseError(text="Invalid data", code="custom", index=['my_key'])
    assert set(error.keys()) == {'my_key'}



# Generated at 2022-06-24 10:34:58.408730
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    result1 = (Message(text="May not have more than 100 characters",
        code="max_length", index=["username"],
        start_position=Position(line_no=1, column_no=2, char_index=0),
        end_position=Position(line_no=1, column_no=22, char_index=10))
        == Message(text="May not have more than 100 characters",
        code="max_length", index=["username"],
        start_position=Position(line_no=1, column_no=2, char_index=0),
        end_position=Position(line_no=1, column_no=22, char_index=10)))
    assert result1 is True

# Generated at 2022-06-24 10:35:08.088261
# Unit test for method __eq__ of class Message
def test_Message___eq__():

    # Test __eq__ with text, code, key, index, start_position, end_position
    test_Message___eq___1_value = "test_Message___eq___1_value"
    test_Message___eq___1_code = "test_Message___eq___1_code"
    test_Message___eq___1_key = "test_Message___eq___1_key"
    test_Message___eq___1_index = [0, "test_Message___eq___1_index_1"]
    test_Message___eq___2_value = "test_Message___eq___2_value"
    test_Message___eq___2_code = "test_Message___eq___2_code"

# Generated at 2022-06-24 10:35:11.035184
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
   error = BaseError()
   print(error)


# Generated at 2022-06-24 10:35:21.309772
# Unit test for constructor of class ParseError
def test_ParseError():
    # constructor of ParseError
    try:
        raise ParseError()
    except ParseError:
        pass
    try:
        raise ParseError(text="ParseError")
    except ParseError:
        pass
    try:
        raise ParseError(code="ParseError")
    except ParseError:
        pass
    try:
        raise ParseError(key="ParseError")
    except ParseError:
        pass
    try:
        raise ParseError(position="ParseError")
    except ParseError:
        pass
    try:
        raise ParseError(messages="ParseError")
    except ParseError:
        pass
    try:
        raise ParseError(text="ParseError", code="ParseError")
    except ParseError:
        pass
   

# Generated at 2022-06-24 10:35:26.471948
# Unit test for constructor of class BaseError
def test_BaseError():
    error1 = BaseError(code='a', key='a')
    assert isinstance(error1, BaseError)

    error2 = BaseError(messages=[Message(text='b', code='b', key='b')])
    assert isinstance(error2, BaseError)

    assert error1 != error2

# Generated at 2022-06-24 10:35:29.508719
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    value = None
    error = ValidationError(messages=[Message(text="message")])
    val_res = ValidationResult(value=value, error=error)
    assert val_res.__bool__()
