

# Generated at 2022-06-24 10:25:31.167099
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    pass

# Generated at 2022-06-24 10:25:34.619883
# Unit test for constructor of class Message
def test_Message():
    assert Message(text="text", code="code", key="key", index=["index"]) == Message(text="text", code="code", key="key", index=["index"])

# Generated at 2022-06-24 10:25:35.874577
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    a = BaseError()
    print(str(a))
    print(str(a))

# Generated at 2022-06-24 10:25:40.139257
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    # given a ValidationError with a single error message
    messages = [Message(text="Hello", code="world")]
    error = BaseError(messages=messages)
    # when calling error.messages()
    result = error.messages()
    # then the error has been returned
    assert [Message(text="Hello", code="world")] == result



# Generated at 2022-06-24 10:25:42.331692
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    v = ValidationResult(value = 1)
    v1, v2 = v
    assert v1 == 1
    assert v2 is None



# Generated at 2022-06-24 10:25:45.960364
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():

    error = BaseError(
            text='This is a test-text',
            code='test-code',
    )

    assert error['test-code'] == 'This is a test-text'

# Generated at 2022-06-24 10:25:48.476963
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    assert ValidationResult(error=ValidationError()).__repr__() == 'ValidationResult(error=ValidationError([]))'
    assert ValidationResult(value=1).__repr__() == 'ValidationResult(value=1)'
test_ValidationResult___repr__()


# Generated at 2022-06-24 10:25:53.083309
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    # Fixture
    error1 = BaseError(text="msg1")
    error2 = BaseError(text="msg2")
    error3 = BaseError(text="msg3")
    # Test
    error = BaseError(messages=[error1, error2, error3])
    assert error.messages() == [error1, error2, error3]

# Generated at 2022-06-24 10:25:55.775790
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    result = ValidationResult(value=1)
    expected_value = 'ValidationResult(value=1)'
    assert result.__repr__() == expected_value



# Generated at 2022-06-24 10:25:59.038203
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert ValidationResult(value=10) == (10, None)
    assert ValidationResult(error=ValidationError(text="not a number")) == (None, ValidationError(text="not a number"))

test_ValidationResult()

# Generated at 2022-06-24 10:26:07.441713
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    message1 = Message(text="State must be in county's state", index=["state_code"], start_position=Position(line_no=1, column_no=1, char_index=0))
    message2 = Message(text="State must be in county's state", index=["state_code"], start_position=Position(line_no=2, column_no=3, char_index=1))
    message3 = Message(text="State must be in county's state", index=["state_code"], start_position=Position(line_no=1, column_no=1, char_index=0))
    message4 = Message(text="State must be in county's state", index=["state_code"], start_position=None)

# Generated at 2022-06-24 10:26:11.311619
# Unit test for constructor of class ValidationError
def test_ValidationError():
    print(ValidationError(text='text_example', code='code_example', key='key_example'))
    print(ValidationError(messages=[Message(text='text_example', code='code_example', key='key_example')]))


# Generated at 2022-06-24 10:26:12.490384
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    assert bool(ValidationResult(value=1)) is True
    assert bool(ValidationResult(error=ValidationError())) is False


# Generated at 2022-06-24 10:26:17.486998
# Unit test for constructor of class Message
def test_Message():
    """
    Instantiate a Message object
    """
    l = Message(
        text = 'test', 
        code = 'test',
        index = [1,2],
        start_position = Position(1, 1, 1),
        end_position = Position(1, 10, 10)
    )
    assert l.text == 'test'
    assert l.code == 'test'
    assert l.index == [1, 2]
    assert l.start_position == Position(1, 1, 1)
    assert l.end_position == Position(1, 10, 10)


# Generated at 2022-06-24 10:26:18.353880
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    __tracebackhide__ = True


# Generated at 2022-06-24 10:26:28.846820
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    r = ValidationResult(value = 'hello')
    assert len(r) == 2
    assert r.value == 'hello'
    assert r.error == None
    assert bool(r)

    r = ValidationResult(error = ValidationError(text='error'))
    assert len(r) == 2
    assert r.value == None
    assert r.error.text == 'error'
    assert not bool(r)

    r = ValidationResult(value = 'hello', error = ValidationError(text='error'))
    assert len(r) == 2
    assert r.value == 'hello'
    assert r.error.text == 'error'
    assert bool(r)

# Generated at 2022-06-24 10:26:32.871532
# Unit test for constructor of class ParseError
def test_ParseError():
    a = ValidationError(text="test", code="test2", key="test3")
    assert isinstance(a, ValidationError)
    assert a.text == "test"
    assert a.code == "test2"
    assert a.key == "test3"


# Generated at 2022-06-24 10:26:39.831274
# Unit test for constructor of class ParseError
def test_ParseError():
    # ParseError is a subclass of BaseError
    item = ParseError(text="bad parse")
    assert isinstance(item, BaseError)

    # ParseError can be instantiated with a single message.
    item = ParseError(text="bad parse", code="bad_parse", key="name")
    assert "name" in item
    assert item["name"] == "bad parse"
    assert item.messages() == [
        Message(text="bad parse", code="bad_parse", key="name"),
    ]

    # ParseError can be instantiated with a list of messages.

# Generated at 2022-06-24 10:26:48.954392
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    branch_candidates = {
        'BaseError': (BaseError, BaseError),
        'BaseError,add_prefix': (BaseError, str),
    }
    for branch_name in ['BaseError', 'BaseError,add_prefix']:
        branch = branch_candidates[branch_name]
        if branch_name == 'BaseError':
            # instantiate BaseError
            error = BaseError()
            # no add_prefix
            messages = error.messages()
            branch_type = branch[1]
        elif branch_name == 'BaseError,add_prefix':
            # instantiate BaseError
            error = BaseError()
            # add_prefix = '1'
            to_add_prefix = '1'
            messages = error.messages(add_prefix=to_add_prefix)
            branch_type

# Generated at 2022-06-24 10:26:55.569514
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error_1 = BaseError(text="May not have more than 100 characters", code="max_length")
    error_2 = BaseError(text="May not have more than 100 characters", code="max_length")
    error_3 = BaseError(text="May not have more than 100 characters", code="max_length")
    error_4 = BaseError(text="May not have more than 100 characters", code="max_length")
    assert error_1 == error_2
    assert error_2 == error_3
    assert error_3 == error_4


# Generated at 2022-06-24 10:26:59.737677
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    expected = "Position(line_no=1, column_no=2, char_index=3)"
    actual = str(Position(line_no=1, column_no=2, char_index=3))
    assert expected == actual


# Generated at 2022-06-24 10:27:09.033198
# Unit test for constructor of class BaseError
def test_BaseError():
    # Populating dict
    error = BaseError()
    error_dict = dict(error)
    assert error_dict == {}

    error = BaseError(text = "this is a test")
    error_dict = dict(error)
    assert error_dict == {'': 'this is a test'}

    error = BaseError(text = "this is a test", code = "THIS_CODE")
    error_dict = dict(error)
    assert error_dict == {'': 'this is a test'}

    error = BaseError(text = "this is a test", key = "key1")
    error_dict = dict(error)
    assert error_dict == {'key1': 'this is a test'}


# Generated at 2022-06-24 10:27:12.222628
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(line_no=1, column_no=2, char_index=3) == Position(line_no=1, column_no=2, char_index=3)



# Generated at 2022-06-24 10:27:21.912970
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    import pytest
    import typesystem

    an_object1 = {
                "children": [
                    {"age": 4, "name": "Alice"}
                ],
                "surname": "Smith"
            }
    an_object2 = {
                "children": [
                    {"age": 4, "name": "Alice"}
                ],
                "surname": "Smith"
            }

    an_error = ValidationError(text="oh no", code="custom", key="key")
    assert an_error.__hash__() == hash(an_error)
    an_error_updated = an_error
    an_error_updated.__hash__() == hash(an_error_updated)

    an_error2 = ValidationError(text="oh no", code="custom", key="key", index=["key"])


# Generated at 2022-06-24 10:27:31.650998
# Unit test for constructor of class ValidationError
def test_ValidationError():
    error = ValidationError(text='test', code='test', key='test', position='test')
    assert(error.text == 'test')
    assert(error.code == 'test')
    assert(error.key == 'test')
    assert(error.position == 'test')
    assert(error._messages.text == 'test')
    assert(error._messages.code == 'test')
    assert(type(error._messages.index) == list)
    assert(error._messages.index == ['test'])
    assert(error._messages.position == 'test')
    assert(error._message_dict == {'test': 'test'})
    assert(len(error) == 1)
    assert(iter(error) == iter({'test': 'test'}))

# Generated at 2022-06-24 10:27:36.835328
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    message = Message(text='my error')
    error = BaseError(messages=[message])

    assert error[''] == 'my error'

    message = Message(text='my error', key='my-key')
    error = BaseError(messages=[message])

    assert error['my-key'] == 'my-key'

# Generated at 2022-06-24 10:27:46.237882
# Unit test for constructor of class ParseError
def test_ParseError():
    assert ParseError(text='text', code='code', key='key') == ParseError(text='text', code='code', key='key')
    assert ParseError(text='text', code='code') == ParseError(text='text', code='code')
    assert ParseError(text='text') == ParseError(text='text')
    assert ParseError(messages=[Message(text='text')]) == ParseError(messages=[Message(text='text')])
    assert repr(ParseError(text='text')) == 'ParseError(text="text", code="custom")'
    assert repr(ParseError(text='text', code='code')) == 'ParseError(text="text", code="code")'

# Generated at 2022-06-24 10:27:50.089312
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    # Check that repr(Message()) returns a value that eval() would be happy to see. If it does, we know that repr() is
    # working correctly
    assert eval(repr(Message()), {}) == Message()


# Generated at 2022-06-24 10:27:57.710809
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():

    # (1)
    error_1: BaseError = BaseError(text="x", code="x10", key=1)
    assert repr(error_1)=="BaseError(text='x', code='x10', key=1)"

    # (2)
    error_2: BaseError = BaseError(messages=[Message(text="a", code="x"),
                                              Message(text="b", code="x"),
                                              Message(text="c", code="x")])
    assert repr(error_2)=="BaseError([Message(text='a', code='x'), "\
                          "Message(text='b', code='x'), "\
                          "Message(text='c', code='x')])"

# Generated at 2022-06-24 10:28:04.738573
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error = ValidationError(text="invalid")
    assert error == ValidationError(text="invalid")
    assert error != ValidationError(text="invalid", key='field')
    assert error != ValidationError(text="invalid", position=Position(1, 1, 1))
    assert error != ValidationError(text="invalid", code='error')
    assert error != ValidationError(messages=[Message(text="invalid", code='error')])
    assert error != ValidationError(messages=[Message(text="invalid-2", code='error')])
    assert error != ValidationError(messages=[Message(text="invalid-2", code='error'), Message(text="invalid-2", code='error')])

# Generated at 2022-06-24 10:28:07.148495
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    from typesystem.test_cases.test_base_error import test_BaseError___repr__
    return test_BaseError___repr__()


# Generated at 2022-06-24 10:28:09.447267
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    e = BaseError(text='Mensaje de prueba')
    print(e)
    assert True

# Generated at 2022-06-24 10:28:12.185679
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert (Position(1,2,3)) == (Position(1,2,3))
    assert not (Position(1,2,3)) == (Position(1,2,4))

# Generated at 2022-06-24 10:28:24.142363
# Unit test for constructor of class ValidationError
def test_ValidationError():
    print('\nIn function: ', test_ValidationError.__name__)
    # Case 1
    # Instantiated as a ValidationError with a single error message.
    text = 'hello'
    code = 'test_code'
    key = 'test_key'
    error = ValidationError(text=text, code=code, key=key)
    assert len(error) == 1
    assert len(error.messages()) == 1
    assert error[''] == 'hello'
    assert error.messages()[0] == Message(text=text, code=code, key=key)
    # Case 2
    # Instantiated as a ValidationError with multiple error messages.

# Generated at 2022-06-24 10:28:28.329052
# Unit test for constructor of class Message
def test_Message():
    msg = Message(text= "May not have more than 100 characters", code= "max_length", key= "username")
    assert isinstance(msg, Message)
    assert msg.text == "May not have more than 100 characters"
    assert msg.code == "max_length"
    assert msg.key == "username"


# Generated at 2022-06-24 10:28:39.525368
# Unit test for constructor of class ParseError
def test_ParseError():
    str_text = 'abc'
    str_message = Message(text = str_text)
    int_text = 123
    int_message = Message(text = int_text)
    str_code = 'xyz'
    str_key = 'username'
    position = Position(line_no = 1, column_no = 2, char_index = 3)
    messages = [str_message, int_message]
    assert ParseError(text = str_text).messages()[0].text == str_text
    assert ParseError(text = str_text, code = str_code).messages()[0].code == str_code
    assert ParseError(text = str_text, key = str_key).messages()[0].index == [str_key]

# Generated at 2022-06-24 10:28:40.135874
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    pass

# Generated at 2022-06-24 10:28:44.031205
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="first", code="second", key=3, index=[4], position=Position(5, 6, 7), start_position=Position(8, 9, 10), end_position=Position(11, 12, 13)) == Message(text="first", code="second", key=3, index=[4], position=Position(5, 6, 7), start_position=Position(8, 9, 10), end_position=Position(11, 12, 13))




# Generated at 2022-06-24 10:28:50.882196
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    """
    Tests that the method __hash__ of class BaseError works correctly.
    """
    assert hash(ValidationError(text="Validation Error Message")) == hash(ValidationError())
    assert hash(ValidationError(text="Validation Error Message")) == hash(ValidationError(text="Validation Error Message"))
    assert hash(ValidationError(text="Validation Error Message")) != hash(ValidationError(text="Validation Error Message", code="Validation Error Code"))
    assert hash(ValidationError(text="Validation Error Message", code="Validation Error Code")) == hash(ValidationError(text="Validation Error Message", code="Validation Error Code"))
    assert hash(ValidationError(text="Validation Error Message", code="Validation Error Code")) == hash(ValidationError(text="Validation Error Message", code="Validation Error Code"))

# Generated at 2022-06-24 10:28:59.286201
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1,1,1) == Position(1,1,1)
    assert not Position(1,1,1) == Position(2,1,1)
    assert not Position(1,1,1) == Position(1,2,1)
    assert not Position(1,1,1) == Position(1,1,2)
    assert Position(1,1,1) != Position(2,1,1)
    assert Position(1,1,1) != Position(1,2,1)
    assert Position(1,1,1) != Position(1,1,2)


# Generated at 2022-06-24 10:29:08.064568
# Unit test for constructor of class ParseError
def test_ParseError():
    message = "fail"
    code = "custom"
    key = "key"
    position = Position(1,1,1)

    assert ParseError(text=message) == ParseError(text=message)
    assert ParseError(text=message) == ParseError(text=message, code=code)
    assert ParseError(text=message) == ParseError(text=message, key=key)
    assert ParseError(text=message) == ParseError(text=message, position=position)

    assert ParseError(messages=[Message(text=message)]) == ParseError(messages=[Message(text=message)])
    assert ParseError(messages=[]) == ParseError(messages=[])


# Generated at 2022-06-24 10:29:10.210341
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    p = Position(1, 2, 3)
    assert repr(p) == 'Position(line_no=1, column_no=2, char_index=3)'


# Generated at 2022-06-24 10:29:18.145155
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    b1 = BaseError(text="a", code="a", key='a', position=Position(1,1,1), messages=[Message(text="a", code="a", key='a', position=Position(1,1,1))])
    b2 = BaseError(text="a", code="a", key='a', position=Position(1,1,1), messages=[Message(text="a", code="a", key='a', position=Position(1,1,1))])
    assert b1 == b2


# Generated at 2022-06-24 10:29:20.709735
# Unit test for constructor of class Message
def test_Message():
    msg = Message(text="text", code="code", index=["index"])
    expected = Message(text="text", code="code", index=["index"])
    assert msg == expected


# Generated at 2022-06-24 10:29:23.769373
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    """
    Testing function for method of class BaseError.
    """
    base_error = BaseError()
    assert len(base_error) == 1 #if the size of the base_error is 1
    assert base_error[0] == "" #if the first index of the base_error is null



# Generated at 2022-06-24 10:29:28.642334
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    from typesystem import String
    from typesystem import validate
    from typesystem import validate_or_error
    from typesystem import ValidationError

    class TestSchema(String):
        max_length = 10

    value, error = validate_or_error(TestSchema(), "Hello World")

    # Verify that `error` is a ValidationError instance
    assert isinstance(error, ValidationError)

    # Verify that `error` is iterable and has length 1
    assert isinstance(error, collections.abc.Iterable)
    assert len(error) == 1


# Generated at 2022-06-24 10:29:30.900972
# Unit test for constructor of class Message
def test_Message():
    assert Message(text="あ", code="custom") == Message(text="あ", code="custom")


# Generated at 2022-06-24 10:29:36.472587
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    BaseError(messages=[Message(text="a"), Message(text="b")]) == BaseError(messages=[Message(text="a"), Message(text="b")])
    BaseError(messages=[Message(text="a"), Message(text="b"), Message(text="c")]) == BaseError(messages=[Message(text="a"), Message(text="b")])

# Generated at 2022-06-24 10:29:42.968872
# Unit test for constructor of class ParseError
def test_ParseError():
    parnet_dict = {}
    key = 'test_key'
    text = 'test_text'
    parse_error = ParseError(text=text, key=key)
    parse_error_dict = parse_error.__dict__
    parnet_dict['_messages'] = {'test_key': 'test_text'}
    assert parnet_dict == parse_error_dict


# Generated at 2022-06-24 10:29:50.569684
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    from random import randint
    from itertools import product

    for _ in range(100):
        num_messages_1 = randint(0,10)
        error_1 = BaseError(messages=[Message(text="Error" + str(i), code="Bad", key=i) for i in range(num_messages_1)])
        num_messages_2 = randint(0,10)
        error_2 = BaseError(messages=[Message(text="Error" + str(i), code="Bad", key=i) for i in range(num_messages_2)])
        assert (error_1 == error_2) == (hash(error_1) == hash(error_2))

# Generated at 2022-06-24 10:29:58.804272
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    s = set()
    s.add(BaseError(text="a", key="k"))
    s.add(BaseError(text="a", key="k"))
    assert len(s) == 1

    s = set()
    s.add(BaseError(text="a", key="k"))
    s.add(BaseError(text="a", key="k", code="c"))
    assert len(s) == 2

    s = set()
    s.add(BaseError(text="a", key="k", code="c"))
    s.add(BaseError(text="b", key="k", code="c"))
    assert len(s) == 2

# Generated at 2022-06-24 10:30:02.960926
# Unit test for constructor of class BaseError
def test_BaseError():
    error = BaseError(text="May not be empty.")
    value_validated = dict(error)
    value_assert = {"": "May not be empty."}
    assert value_validated == value_assert



# Generated at 2022-06-24 10:30:06.580219
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    data = [1,2,3,4]
    expect = [1,2,3,4]
    instance = ValidationResult(value=data)
    result = [i for i in instance]
    assert result is not None
    assert result == expect

# Generated at 2022-06-24 10:30:13.508816
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    value = [1, 2, 3]
    error = ValidationError(messages=[Message(text="error 1")])
    result = ValidationResult(value=value)
    assert result.__repr__() == "ValidationResult(value=[1, 2, 3])"
    result = ValidationResult(error=error)
    assert result.__repr__() == "ValidationResult(error=ValidationError([Message(text='error 1', code='custom', index=[], position=Position(line_no=1, column_no=1, char_index=0))]))"

# Generated at 2022-06-24 10:30:17.204593
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    assert repr(Position(line_no=0, column_no=1, char_index=9)) == "Position(line_no=0, column_no=1, char_index=9)"



# Generated at 2022-06-24 10:30:21.997598
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    # value, error = MySchema.validate_or_error(data)
    assert ValidationResult(value = 0, error = ValidationError()).value == 0
    assert ValidationResult(value = 0, error = ValidationError()).error.text == None
    assert ValidationResult(value = None, error = ValidationError(text = 'error')).error.text == 'error'

# Generated at 2022-06-24 10:30:32.066696
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    # Simple key lookup test
    err = ValidationError(text="", key="key")
    assert dict(err).get("key") == ""

    # Key lookup test with prefix
    err = ValidationError(text="", key="key")
    assert dict(err).get("key") == ""

    # Multi-level lookup test
    err = ValidationError(text="", key="key_2")
    err2 = ValidationError(text="", key="key_1")
    err2.add_child_error(err)
    assert dict(err2).get("key").get("key_2") == ""

    # Key lookup test with prefix
    err = ValidationError(text="", key="key")
    err.add_prefix("prefix")
    assert dict(err).get("prefix").get("key") == ""

    #

# Generated at 2022-06-24 10:30:38.959406
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError(text="test", code="test_code", key="key_test", position=Position(1, 2, 3))
    assert error._messages[0].text == "test"
    assert error._messages[0].code == "test_code"
    assert error._messages[0].key == "key_test"
    assert error._messages[0].position == Position(1, 2, 3)


# Generated at 2022-06-24 10:30:48.634788
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    assert repr(ValidationError(_messages=[Message(text="A",code="B",index=["C"],position=Position(line_no=1,column_no=1,char_index=1))])) == "ValidationError([Message(text='A', code='B', index=['C'], position=Position(line_no=1, column_no=1, char_index=1))])"
    assert repr(ValidationError(_messages=[Message(text="A",code="B",index=["C"],position=Position(line_no=1,column_no=1,char_index=1))],_message_dict={})) == "ValidationError([Message(text='A', code='B', index=['C'], position=Position(line_no=1, column_no=1, char_index=1))])"

# Generated at 2022-06-24 10:30:50.444240
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():

    BaseError() == BaseError()

# Generated at 2022-06-24 10:30:55.107894
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    error = BaseError()
    assert len(error) == 0
    error = BaseError(text="Nope")
    assert len(error) == 1
    error = BaseError(messages=[Message(text="Nope", code="no_such_file")])
    assert len(error) == 1



# Generated at 2022-06-24 10:30:57.775680
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    a = BaseError(text="text", code="code", key="key", position=Position(2, 2, 2), messages=[])
    b = BaseError(text="text", code="code", key="key", position=Position(2, 2, 2), messages=[])
    assert a == b
    assert hash(a) == hash(b)


# Generated at 2022-06-24 10:31:08.800754
# Unit test for constructor of class ValidationError
def test_ValidationError():
  with pytest.raises(AssertionError):
    ValidationError(messages=[])
  with pytest.raises(AssertionError):
    ValidationError(messages=None, text="")
  with pytest.raises(AssertionError):
    ValidationError(messages=None, code="")
  with pytest.raises(AssertionError):
    ValidationError(messages=None, key="")
  with pytest.raises(AssertionError):
    ValidationError(messages=None, position="")

  assert len(ValidationError().messages()) == 0
  assert len(ValidationError(messages=[Message(text="hello")]).messages()) == 1



# Generated at 2022-06-24 10:31:16.650907
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    text = "text"
    code = "code"
    index = [1, 1]
    start_position = "start_position"
    end_position = "end_position"
    position = "position"
    message = Message(text=text, code=code, index=index, start_position=start_position, end_position=end_position)
    s = message.__repr__()
    assert s == f"Message(text={text!r}, code={code!r}, index={index!r}, start_position={start_position!r}, end_position={end_position!r})"
    message = Message(text=text, code=code, index=index)
    s = message.__repr__()

# Generated at 2022-06-24 10:31:20.340714
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    instance = BaseError(text='test', code='test', key=0, position=Position(line_no=1, column_no=2, char_index=0))
    instance.messages(add_prefix=0)


# Generated at 2022-06-24 10:31:22.568733
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    message = Message(text="text", code="code", index=[])
    assert hash(message) == hash(("code", ()))



# Generated at 2022-06-24 10:31:34.134114
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    vr = ValidationResult(value=object())
    assert repr(vr) == "ValidationResult(value=<object object at 0x7f1dabf69cb0>)"
    vr = ValidationResult(error=ValidationError())
    assert repr(vr) == "ValidationResult(error=<class 'typesystem.errors.ValidationError'>([]))"
    vr = ValidationResult(error=ValidationError(text=str()))
    assert repr(vr) == "ValidationResult(error=<class 'typesystem.errors.ValidationError'>(text=''))"
    vr = ValidationResult(error=ValidationError(messages=[Message(text=str())]))

# Generated at 2022-06-24 10:31:42.910286
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="x") == Message(text="x")
    assert Message(text="x") == Message(text="x", code="custom")
    assert Message(text="x") == Message(text="x", key="x")
    assert Message(text="x") == Message(text="x", index=["x"])
    assert Message(text="x") == Message(text="x", position=Position(1, 1, 1))
    assert Message(text="x") == Message(
        text="x", start_position=Position(1, 1, 1), end_position=Position(1, 1, 1)
    )
    assert Message(text="x") != Message(text="y")
    assert Message(text="x") != Message(text="x", code="x")

# Generated at 2022-06-24 10:31:50.875900
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    with pytest.raises(AssertionError) as info:
        BaseError(text = "hello", code = "say", key = "goodbye")
    assert BaseError(text = "hello", code = "say", key = "goodbye").text == "hello"
    assert BaseError(text = "hello", code = "say", key = "goodbye").code == "say"
    assert BaseError(text = "hello", code = "say", key = "goodbye").key == "goodbye"
    # assert BaseError(text = "hello", code = "say", key = "goodbye").start_position != "0"


# Generated at 2022-06-24 10:31:53.262430
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    assert bool(ValidationResult(value=42))
    assert not bool(ValidationResult(error="oops!"))

# Generated at 2022-06-24 10:31:54.280254
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    val_err = ValidationErro

# Generated at 2022-06-24 10:31:57.071559
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    ValidationResult(value=1).__bool__() == True
    ValidationResult(error=ValidationError()).__bool__() == False

# Generated at 2022-06-24 10:32:00.580922
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    position = Position(line_no=1, column_no=2, char_index=3)
    assert repr(position) == 'Position(line_no=1, column_no=2, char_index=3)'


# Generated at 2022-06-24 10:32:04.184692
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    # Simple test case
    position1 = Position(line_no=1, column_no=2, char_index=3)
    position2 = Position(line_no=1, column_no=2, char_index=3)
    assert position1 == position2


# Generated at 2022-06-24 10:32:15.211571
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    from typesystem.fields import String, Float
    obj = String()
    validate_result = obj.validate_or_error("abc")
    try:
        validate_result.value.isupper()
    except AttributeError as e:
        print(validate_result)
        print(validate_result.error)
        for key in validate_result.error:
            print(key, validate_result.error[key])
        print(e)

    validate_result = obj.validate_or_error(123)
    print(validate_result)
    print(validate_result.error)
    for key in validate_result.error:
        print(key, validate_result.error[key])
    print(validate_result.error.messages())

    obj = Float()
    validate_result = obj.valid

# Generated at 2022-06-24 10:32:16.985109
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    error = BaseError(messages=[Message(text="message 1"), Message(text="message 2")])

    for message in error:
        print(message)

test_BaseError___iter__()

# Generated at 2022-06-24 10:32:23.493796
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    # test value
    A = ValidationResult(value=1)
    assert A.value == 1
    assert A.error == None

    B = ValidationResult(error=2)
    assert B.value == None
    assert B.error == 2

    # test __iter__
    x, y = ValidationResult(value=1)
    assert x == 1
    assert y == None

    x, y = ValidationResult(error=2)
    assert x == None
    assert y == 2

    assert int(ValidationResult(value=1)) == 1
    assert int(ValidationResult(error=2)) == 0

# Generated at 2022-06-24 10:32:31.234867
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    #test 1 : value, error
    assert ValidationResult(error=ValidationError(text="This is a test error!")) == ValidationResult(error=ValidationError(text="This is a test error!"))
    #test 2 : value, error
    assert ValidationResult(value=42) == ValidationResult(value=42)
    #test 3 : value, error
    assert ValidationResult(value=42, error=ValidationError(text="This is a test error!")) == ValidationResult(value=42, error=ValidationError(text="This is a test error!"))
    #test 4 : value, error
    assert ValidationResult(value=42, error=ValidationError(text="This is a test error!")) != ValidationResult(error=ValidationError(text="This is a test error!"))
    #test 5 :

# Generated at 2022-06-24 10:32:42.336094
# Unit test for constructor of class BaseError
def test_BaseError():
    msg = Message(text="foo", code="A", key="b", index=["c", 1, 2], position=Position(
        line_no=100, column_no=999, char_index=9999))
    assert msg.text == "foo"
    assert msg.code == "A"
    assert msg.key is None
    assert msg.index == ["c", 1, 2]
    assert msg.position is None
    assert msg.start_position == Position(
        line_no=100, column_no=999, char_index=9999)
    assert msg.end_position == Position(
        line_no=100, column_no=999, char_index=9999)
    err = ValidationError(messages=[msg])
    assert err._message_dict == {'c': {1: {2: 'foo'}}}


# Generated at 2022-06-24 10:32:46.866182
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    class_name = 'Position'
    line_no = 1
    column_no = 2
    char_index = 3
    ret = f"{class_name}(line_no={line_no}, column_no={column_no}, char_index={char_index})"

    position = Position(1, 2, 3)
    assert position.__repr__() == ret


# Generated at 2022-06-24 10:32:49.244290
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    pos1 = Position(1, 1, 1)
    pos2 = Position(1, 1, 1)
    pos3 = Position(2, 1, 1)
    assert pos1 == pos2
    assert pos1 != pos3


# Generated at 2022-06-24 10:32:58.212371
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(line_no=0, column_no=0, char_index=0) == Position(line_no=0, column_no=0, char_index=0)
    assert Position(line_no=1, column_no=0, char_index=0) == Position(line_no=1, column_no=0, char_index=0)
    assert Position(line_no=0, column_no=1, char_index=0) == Position(line_no=0, column_no=1, char_index=0)
    assert Position(line_no=0, column_no=0, char_index=1) == Position(line_no=0, column_no=0, char_index=1)



# Generated at 2022-06-24 10:33:04.579310
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    error = ValidationError(text="a", code="b", key="c")
    expect = [Message(text="a", code="b", key="c")]
    assert error.messages() == expect

    error = ValidationError(messages=[Message(text="a", code="b", index=["c"])])
    assert error.messages() == expect

    expect = [Message(text="a", code="b", index=["d", "c"])]
    assert error.messages(add_prefix="d") == expect

# Generated at 2022-06-24 10:33:15.360333
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    test_Message = Message(text="May not have more than 100 characters", code="max_length", key="username", position=Position(line_no=17, column_no=12, char_index=23), start_position=Position(line_no=17, column_no=12, char_index=23), end_position=Position(line_no=17, column_no=12, char_index=23))

    output = test_Message.__repr__()
    output_expected = "Message(text='May not have more than 100 characters', code='max_length', index=['username'], position=Position(line_no=17, column_no=12, char_index=23))"

    assert output == output_expected


# Generated at 2022-06-24 10:33:17.560066
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    e1 = BaseError(text='First error')
    e2 = BaseError(text='First error')
    assert hash(e1) == hash(e2)

# Generated at 2022-06-24 10:33:18.866356
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    ValidationResult(value=1).__bool__()



# Generated at 2022-06-24 10:33:27.450772
# Unit test for constructor of class ValidationError
def test_ValidationError():
    class_name = "Test"
    message = "test"
    code = "test"
    key = "test"
    index = []
    position = Position(1, 2, 3)
    start_position = Position(3, 2, 1)
    end_position = Position(1, 2, 3)
    error_case_1 = ValidationError(text=message, code=code, key=key, position=position)
    error_case_2 = ValidationError(messages=[Message(text=message, code=code, index=index, start_position=start_position, end_position=end_position)])
    error_case_3 = ValidationError(text=message, code=code, key=key, position=position)

    assert(error_case_1 == error_case_3)

# Generated at 2022-06-24 10:33:29.899140
# Unit test for method __len__ of class BaseError

# Generated at 2022-06-24 10:33:33.489147
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test with invalid parameter type
    try:
        BaseError().__eq__(None)
    except TypeError:
        assert True
    else:
        assert False



# Generated at 2022-06-24 10:33:35.977005
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    error = BaseError(messages=[Message(text="Hello world!")])
    assert str(error) == "Hello world!"
    error = BaseError(messages=[Message(text="Hello world!", key="key_test")])
    assert str(error) == {"key_test": "Hello world!"}


# Generated at 2022-06-24 10:33:36.386605
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    pass

# Generated at 2022-06-24 10:33:42.888615
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    import pytest
    Message = __loader__.get_fixture('Message')
    """Unit test for method __repr__ of class Message"""

    # Test attributes of class Message
    message = Message(text='May not have more than 100 characters', code='max_length', key=None, index=None, position=None, start_position=None, end_position=None)
    assert message.text == 'May not have more than 100 characters'
    assert message.code == 'max_length'
    assert message.index == []

    # Test method __repr__ of class Message
    message = Message(text='May not have more than 100 characters', code='max_length', key=None, index=None, position=None, start_position=None, end_position=None)

# Generated at 2022-06-24 10:33:46.507804
# Unit test for method messages of class BaseError
def test_BaseError_messages():
  message=Message(text='May not be true')
  error = BaseError(messages=[message,message])
  assert error.messages() == [message, message]


# Generated at 2022-06-24 10:33:56.253536
# Unit test for constructor of class BaseError
def test_BaseError():
    assert BaseError(text="some message") == BaseError(messages=[Message(text="some message")])
    assert BaseError(text="some message") == BaseError(messages=[Message(text="some message")])
    assert BaseError(text="some message", code="my_code") == BaseError(messages=[Message(text="some message", code="my_code")])
    assert BaseError(text="some message", code="my_code") == BaseError(messages=[Message(text="some message", code="my_code")])
    assert BaseError(text="some message", code="my_code") != BaseError(messages=[Message(text="some other message", code="my_code")])
    assert BaseError(text="some message", code="my_code") != BaseError(messages=[Message(text="some message")])


# Generated at 2022-06-24 10:34:01.724683
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    message_1 = Message()
    BaseError(messages=[message_1])

    message_2 = Message(index=['key'])
    BaseError(messages=[message_2])

    message_3 = Message(index=[1, 'key'])
    BaseError(messages=[message_3])

    message_4 = Message(index=[1, 2])
    BaseError(messages=[message_4])

    message_5 = Message(index=[2, 1])
    BaseError(messages=[message_5])

    message_6 = Message(index=[2, 1, 'a'])
    BaseError(messages=[message_6])

# Example, extract

# Generated at 2022-06-24 10:34:07.458740
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    error = BaseError(messages=[Message(index=["key_1"], text="value_1"), Message(index=["key_2", "subkey_2"], text="value_2")])
    assert isinstance(error, BaseError)

    assert error["key_1"] == "value_1"
    assert error["key_2"] == {"subkey_2": "value_2"}



# Generated at 2022-06-24 10:34:09.788182
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result = ValidationResult(value="item1")
    for i in validation_result:
        assert i == "item1"


# Generated at 2022-06-24 10:34:17.797248
# Unit test for constructor of class Message
def test_Message():
    # test construct Message with position
    position = Position(1,1,1)
    m = Message(text="a",position=position)
    assert m.text == "a"
    assert m.position == position
    assert m.key == []
    assert m.code == "custom"
    # test construct with start_position and end_position
    s_position = Position(1,1,1)
    e_position = Position(1,2,2)
    m = Message(text="a",start_position=s_position,end_position=e_position)
    assert m.text == "a"
    assert m.start_position == s_position
    assert m.end_position == e_position
    assert m.key == []
    assert m.code == "custom"
    # test construct with key and code
   

# Generated at 2022-06-24 10:34:26.651485
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    vr = ValidationResult(value=1)
    vr1 = ValidationResult(value=None)
    vr2 = ValidationResult(error="error")
    assert vr.value == 1
    assert vr1.value is None
    assert vr2.error == "error"
    assert vr == ValidationResult(value=1)
    assert vr1 == ValidationResult(value=None)
    assert vr2 == ValidationResult(error="error")
    assert bool(vr)  # __bool__
    assert bool(vr1)
    assert not bool(vr2)

# Generated at 2022-06-24 10:34:32.623398
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    a = Message(
        text = "UnitTest",
        code = 'Test',
        index = ['key']
    )
    b = Message(
        text = "UnitTest",
        code = 'Test',
        index = ['key']
    )
    c = Message(
        text = "UnitTest",
        code = 'Test',
        index = []
    )
    assert a == b, 'a == b is not ture'
    assert a != c, 'a != c is not ture'


# Generated at 2022-06-24 10:34:40.209376
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    code = str(time.time())
    index = list(map(int, range(100)))
    m1 = Message(
        text="My Custom Message",
        code=code,
        index=index,
        start_position=Position(1, 2, 3),
    )
    m2 = Message(
        text="My Custom Message",
        code=code,
        index=index,
        start_position=Position(1, 2, 3),
    )
    assert m1 == m2
    assert hash(m1) == hash(m2)



# Generated at 2022-06-24 10:34:45.319034
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert ValidationError(text="text1") == ValidationError(text="text1")
    assert ValidationError(text="text1") != ValidationError(text="text2")
    assert ValidationError(text="text1") != ValidationError(text="text1", code="code1")
    assert ValidationError(text="text1", key="key1") != ValidationError(text="text1")
    assert ValidationError(text="text1", key="key1", index=["index1"]) != ValidationError(text="text1")
    assert ValidationError(text="text1") != ValidationError(text="text1", code="code1", key="key1", index=["index1"])
    assert ValidationError(text="text1", code="code1", key="key1", index=["index1"])

# Generated at 2022-06-24 10:34:47.251740
# Unit test for constructor of class ParseError
def test_ParseError():
    pe = ParseError()
    assert pe


# Generated at 2022-06-24 10:34:51.435380
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    result=ValidationResult(value=1)
    assert(bool(result)==True)
    result = ValidationResult(error=ValidationError)
    assert(bool(result)==False)

# This test will cause the program to crash

# Generated at 2022-06-24 10:35:00.584987
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    text = "May not have more than 100 characters"
    code = "max_length"
    key = "username"
    index = ["users", 3, "username"]
    line_no = 100
    column_no = 200
    char_index = 300

    position = Position(line_no, column_no, char_index)
    start_position = Position(line_no, column_no, char_index)
    end_position = Position(line_no, column_no, char_index)
    result = Message(text=text, index=index, position=position)
    assert result.__repr__() == "Message(text=May not have more than 100 characters, code=custom, index=['users', 3, 'username'], position=Position(line_no=100, column_no=200, char_index=300))"

# Generated at 2022-06-24 10:35:08.445969
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    pos1 = Position(line_no = 1, column_no = 1, char_index = 1)
    pos2 = Position(line_no = 1, column_no = 1, char_index = 1)
    assert pos1 == pos2
    pos1 = Position(line_no = 1, column_no = 1, char_index = 2)
    assert pos1 != pos2
    pos1 = Position(line_no = 2, column_no = 1, char_index = 1)
    assert pos1 != pos2
    pos1 = Position(line_no = 1, column_no = 2, char_index = 1)
    assert pos1 != pos2


# Generated at 2022-06-24 10:35:09.018910
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    pass

# Generated at 2022-06-24 10:35:14.142092
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    assert hash(Message(text='May not have more than 100 characters', code='max_length', key='username')) == hash(
        Message(text='May not have more than 100 characters', code='max_length', key='username')
    )


# Generated at 2022-06-24 10:35:21.414838
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    message = BaseError(text='a')
    assert message.messages() == [Message(text='a')]

    message = BaseError(messages=[Message(text='a'), Message(text='b'), Message(text='c')])
    assert message.messages() == [Message(text='a'), Message(text='b'), Message(text='c')]
    assert message.messages(add_prefix=2) == [Message(text='a', index=[2]), Message(text='b', index=[2]), Message(text='c', index=[2])]

# Generated at 2022-06-24 10:35:22.448748
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    assert len(BaseError())==0


# Generated at 2022-06-24 10:35:25.619162
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    positional1 = Position(1, 1, 1)
    positional2 = Position(1, 1, 1)
    assert positional1 == positional2



# Generated at 2022-06-24 10:35:28.778478
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert ValidationResult(value=True) == ValidationResult(error=ValidationResult(value=True))
    assert ValidationResult(value=True) != ValidationResult(error=ValidationResult(value=False))

# Generated at 2022-06-24 10:35:36.113789
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    # => class BaseError(_collections_abc.Mapping, Exception):
    # case 1
    # => def __init__(
    #         self,
    #         *,
    #         text: str = None,
    #         code: str = None,
    #         key: typing.Union[int, str] = None,
    #         position: Position = None,
    #         messages: typing.List[Message] = None,
    #     ):
    #         # Instantiated as a ValidationError with a single error message.
    #         assert text is not None
    #         messages = [Message(text=text, code=code, key=key, position=position)]
    assert repr(BaseError(text='text')) == "BaseError(text='text', code='custom')"