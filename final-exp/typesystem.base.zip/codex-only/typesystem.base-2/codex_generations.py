

# Generated at 2022-06-24 10:25:34.442840
# Unit test for constructor of class ValidationError
def test_ValidationError():
    # Initialize ValidationError instance with a single message
    err_msg = ValidationError(text='test', code='test code', key='test key', position=Position(0,0,0))
    assert err_msg.messages()[0] == Message(text='test', code='test code', key='test key', position=Position(0,0,0))
    # Initialize ValidationError instance with multiple messages
    err_msg = ValidationError(messages=[Message(text='test', code='test code', key='test key', position=Position(0,0,0))])
    assert err_msg.messages()[0] == Message(text='test', code='test code', key='test key', position=Position(0,0,0))

# Generated at 2022-06-24 10:25:41.006746
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    error = ValidationError(
        messages=[
            Message(text="A", code="1", key="1", index=["a"], position=Position(1, 1, 1)),
            Message(text="B", code="2", key="2", index=["b"], position=Position(2, 2, 2)),
            Message(text="C", code="3", key="3", index=["c"], position=Position(3, 3, 3)),
            Message(text="D", code="4", key="4", index=["d"], position=Position(4, 4, 4)),
        ]
    )

# Generated at 2022-06-24 10:25:44.666899
# Unit test for constructor of class Message
def test_Message():
    m = Message(text="Error", code="custom", key="key", position=Position(1, 2, 3))
    assert m.text == "Error"
    assert m.code == "custom"
    assert m.index == ["key"]
    assert m.start_position == m.end_position == Position(1, 2, 3)


# Generated at 2022-06-24 10:25:54.308375
# Unit test for constructor of class Message
def test_Message():
    assert Message(text="max_length") == Message(text="max_length")
    assert Message(text="max_length", code="max_length") == Message(text="max_length", code="max_length")
    assert Message(text="max_length", key="username") == Message(text="max_length", key="username")
    assert Message(text="max_length", index=["users", 2, "username"]) == Message(text="max_length", index=["users", 2, "username"])
    assert Message(text="max_length", position=Position(1,2,3)) == Message(text="max_length", position=Position(1,2,3))

# Generated at 2022-06-24 10:26:01.824292
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    b1 = BaseError(text='1', code='1', key='1', position='1', messages=['1'])
    b2 = BaseError(text='2', code='2', key='2', position='2', messages=['2'])
    assert b1 != b2
    # Your code here
    b3 = BaseError(text='1', code='1', key='1', position='1', messages=['1'])
    assert b1 == b3
    # Your code here
    b4 = BaseError(text='2', code='2', key='2', position='2', messages=[])
    assert b2 == b4


# Generated at 2022-06-24 10:26:05.125588
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    a = ValidationResult(value = 1)
    assert a.value == 1

    b = ValidationResult(error = 1)
    assert b.error == 1
    return

# Generated at 2022-06-24 10:26:14.764332
# Unit test for constructor of class BaseError
def test_BaseError():
    error = BaseError(text='hello')
    assert error.messages() == [Message(text='hello', code='custom')]

    error = BaseError(messages=[Message(text='foo'), Message(text='bar')])
    assert error.messages() == [Message(text='foo'), Message(text='bar')]

    error = BaseError(text='test')
    assert error._messages == [Message(text='test', code='custom')]
    assert error._message_dict == {'': 'test'}
    assert error.messages() == [Message(text='test', code='custom')]

    error = BaseError(messages=[Message(text='foo', key='bar'), Message(text='baz')])

# Generated at 2022-06-24 10:26:20.026303
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    expected_result = {0: {'username': 'violates max length', 'password': 'violates min length'}, 
                       1: {'username': 'violates max length'}}
    
    error1 = BaseError(text="violates max length", code="custom", key="username")
    error2 = BaseError(text="violates min length", code="custom", key="password")
    error3 = BaseError(text="violates max length", code="custom", key="username")
    error = BaseError(messages=[error1, error2, error3])

    actual_result = {0: error[0], 1: error[1]}
    assert actual_result == expected_result, f"actual_result={actual_result}, expected_result={expected_result}."


# Generated at 2022-06-24 10:26:27.439329
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    print(Position(line_no=0, column_no=0, char_index=0))
    print(Position(line_no=1, column_no=1, char_index=1))
    print(Position(line_no=2, column_no=2, char_index=2))
    print(Position(line_no=3, column_no=3, char_index=3))
    print(Position(line_no=4, column_no=4, char_index=4))


# Generated at 2022-06-24 10:26:31.633177
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    # Instantiate with multiple error messages
    BaseError(messages=[Message(text='text', code='code', index=['key'])])
    # Instantiate with a single error message
    BaseError(text='text', code='code', key='key')


# Generated at 2022-06-24 10:26:35.306895
# Unit test for constructor of class Position
def test_Position():
    p1 = Position(1, 1, 1)
    p2 = Position(1, 1, 1)
    assert p1 == p2
    assert p1 != None
    assert p1.column_no == 1
    assert p1.char_index == 1
    assert p1.line_no == 1
    assert p1 != p2
    return 0

# Generated at 2022-06-24 10:26:38.793999
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    error = BaseError(messages=[Message(text='text1'), Message(text='text2')])
    assert error.messages() == [Message(text='text1'), Message(text='text2')]
    assert error.messages(add_prefix='prefix') == [Message(text='text1', index=['prefix']), Message(text='text2', index=['prefix'])]

# Generated at 2022-06-24 10:26:40.976752
# Unit test for constructor of class ParseError
def test_ParseError():
    data = {
        "type": "hello"
    }
    try:
        raise ParseError(data, json.dumps(data))
    except ParseError as e:
        assert e.code == "type"

# Generated at 2022-06-24 10:26:48.186895
# Unit test for constructor of class BaseError
def test_BaseError():
    assert BaseError(text='Invalid IP Address').error == 'Invalid IP Address'
    assert BaseError(text="Invalid IP Address", code = "INVALID_IP_ADDRESS").code == "INVALID_IP_ADDRESS"
    assert BaseError(text="Invalid IP Address", key = "IP").key == "IP"
    assert BaseError(messages=[Message(text="Invalid IP Address", code="INVALID_IP_ADDRESS")]).text == "Invalid IP Address"
    assert BaseError(messages=[Message(text="Invalid IP Address", code="INVALID_IP_ADDRESS")]).code == "INVALID_IP_ADDRESS"

# Generated at 2022-06-24 10:26:56.796159
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    message = Message(text='text', code='code', key='key')
    assert hash(message) == hash(message)

    equal = Message(text='text', code='code', key='key')
    assert hash(message) == hash(equal)

    equal = Message(text='text', code='code', key='key2')
    assert hash(message) != hash(equal)

    equal = Message(text='text', code='code', index=[1])
    assert hash(message) != hash(equal)

    equal = Message(text='text', code='code2', key='key')
    assert hash(message) != hash(equal)

    equal = Message(text='text2', code='code', key='key')
    assert hash(message) != hash(equal)


# Generated at 2022-06-24 10:27:05.389114
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    error = ValidationError(text="ok")
    assert error.messages() == [Message(text="ok", code="custom", index=[])]

    error = ValidationError(text="ok", key="a")
    assert error.messages() == [Message(text="ok", code="custom", index=["a"])]

    error = ValidationError(text="ok", key="a", add_prefix="AX")
    assert error.messages() == [Message(text="ok", code="custom", index=["AX", "a"])]

    error = ValidationError(messages=error.messages())
    assert error.messages() == [Message(text="ok", code="custom", index=["a"])]

    error = ValidationError(messages=error.messages(), add_prefix="AX")
    assert error.messages

# Generated at 2022-06-24 10:27:08.691766
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    error = BaseError(messages=[Message(text="", code="", key=None)])
    assert len(error) == 1


# Generated at 2022-06-24 10:27:13.327895
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    # ValidationResult(value={}) should return True
    result = ValidationResult(value={})
    assert result is not None
    # ValidationResult(error={}) should return False
    result = ValidationResult(error={})
    assert result is None

Validated = typing.Union[ValidationResult, BaseError]



# Generated at 2022-06-24 10:27:17.089926
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    x = ValidationResult()
    assert x.__repr__() == "ValidationResult(error=None)"
    x = ValidationResult(value = 1)
    assert x.__repr__() == "ValidationResult(value=1)"


# Generated at 2022-06-24 10:27:27.960899
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    code = 'max_length'
    key = 'a'
    index = ['username']
    start_position = None
    end_position = None
    text = 'May not have more than 100 characters'
    message = Message(text=text, code=code, key=key, index=index, start_position=start_position, end_position=end_position)
    assert len(message.messages())==1
    assert message.messages()[0].text == text
    assert message.messages()[0].code == code
    assert message.messages()[0].index == index
    assert message.messages()[0].start_position == start_position
    assert message.messages()[0].end_position == end_position
    assert hash(message) == hash((code, tuple(index)))


# Generated at 2022-06-24 10:27:33.541831
# Unit test for constructor of class Message
def test_Message():
    m1 = Message(text='Text', code='code', key='key', start_position=Position(1, 2, 3), end_position=Position(4, 5, 6))
    assert m1.text == 'Text' and m1.code == 'code' and m1.key == 'key' and m1.start_position == Position(1, 2, 3) and m1.end_position == Position(4, 5, 6)



# Generated at 2022-06-24 10:27:35.528955
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    ValidationResult(value=3)
    ValidationResult(error=3)



# Generated at 2022-06-24 10:27:36.437873
# Unit test for constructor of class BaseError
def test_BaseError():
    assert BaseError()

# Generated at 2022-06-24 10:27:39.112270
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    e = BaseError(messages=[Message(text='hello', index=[])], code=None, key=None)
    assert e[''] == 'hello'



# Generated at 2022-06-24 10:27:43.721619
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    message = Message(text="message-text", code="message-code", index=['key-index'])
    try:
        assert str(message) == "Message(text='message-text', code='message-code', index=['key-index'])"
    except AssertionError:
        print(str(message))



# Generated at 2022-06-24 10:27:51.231633
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    a = Message(
        text="May not have more than 100 characters",
        code=None,
        key="username",
        position=Position(line_no=1, column_no=1, char_index=0),
    )
    b = Message(
        text="May not have more than 100 characters",
        key="username",
        position=Position(line_no=1, column_no=1, char_index=0),
    )
    assert a == b
    assert hash(a) == hash(b)

# Generated at 2022-06-24 10:27:59.092289
# Unit test for constructor of class BaseError
def test_BaseError():
    error = BaseError()
    assert error
    assert len(error) == 0
    assert not error._messages
    assert not error._message_dict
    # __iter__
    assert list(iter(error)) == []
    # __getitem__
    with pytest.raises(KeyError):
        error[""]
    error = BaseError(messages=[Message(text="abc")])
    assert error
    assert len(error) == 1
    assert error._messages == [Message(text="abc")]
    assert error._message_dict == {"": "abc"}
    # __iter__
    assert list(iter(error)) == [""]
    # __getitem__
    assert error[""] == "abc"
    with pytest.raises(KeyError):
        error["1"]

# Generated at 2022-06-24 10:28:00.558484
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    b = BaseError()
    for i in b:
        print(i)

# Generated at 2022-06-24 10:28:05.278798
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    data = [1,2,3]
    value, error = ValidationResult(value=data).__iter__()
    assert(repr(ValidationResult(value=value)) == f"ValidationResult(value={value!r})")
    assert(repr(ValidationResult(error=error)) == f"ValidationResult(error={error!r})")

# Generated at 2022-06-24 10:28:15.332007
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text='a', code='b', key='c') == BaseError(text='a', code='b', key='c')
    assert BaseError(text='a', code='b', key='c') != BaseError(text='a', code='b', key='d')
    assert BaseError(text='a', code='b', key='c') != BaseError(text='a', code='b')
    assert BaseError(text='a', code='b', key='c') != BaseError(text='a', code='b', key='c', index=[])
    assert BaseError(text='a', code='b', key='c', index=['d']) != BaseError(text='a', code='b', key='c')

# Generated at 2022-06-24 10:28:19.388718
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    string = "Position(line_no=1, column_no=2, char_index=3)"
    instance = Position(line_no=1, column_no=2, char_index=3)
    assert repr(instance) == string


# Generated at 2022-06-24 10:28:21.177304
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    def test_BaseError_str(x: ValidationError, y: str) -> bool:
        return str(x) == y
    assert test_BaseError_str(ValidationError(text="test"), "test")


# Generated at 2022-06-24 10:28:30.438876
# Unit test for constructor of class BaseError
def test_BaseError():
    error = BaseError(text="May not have more than 100 characters", code="max_length", key="username", position="position_value")
    assert error._messages == [Message(text="May not have more than 100 characters", code="max_length", key="username", position="position_value")]
    assert error.text == "May not have more than 100 characters"
    assert error.code == "max_length"
    assert error.key == "username"
    assert error.position == "position_value"
    assert error.messages == [Message(text="May not have more than 100 characters", code="max_length", key="username", position="position_value")]
    assert error._message_dict == {"username": "May not have more than 100 characters"}
    assert "username" in error

# Generated at 2022-06-24 10:28:31.669545
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 1, 1) == Position(1, 1, 1)


# Generated at 2022-06-24 10:28:42.890276
# Unit test for constructor of class Message
def test_Message():
    TestCase = namedtuple('TestCase', ['text', 'code', 'key', 'index', 'position', 'start_position', 'end_position'])
    cases = (
        TestCase(text='text1', code='code1', key='key1', index=None, position=(0,0), start_position=None, end_position=None),
        TestCase(text='text2', code='code2', key='key2', index=None, position=None, start_position=(0,0), end_position=(0,0)),
        TestCase(text='text3', code='code3', key='key3', index=None, position=None, start_position=(0,0), end_position=(1,0)),
    )
    passed = True

# Generated at 2022-06-24 10:28:49.720251
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    from typesystem.error import ValidationResult
    from typesystem.error import ValidationError
    from typesystem.error import Message
    from typesystem.error import Position
    vr = ValidationResult(value = 3.14)
    assert(vr)
    assert((vr.value, vr.error) == tuple(vr))
    ve = ValidationError(text = 'hello world', code = 'print', key = 'message', position = Position(line_no = 1, column_no = 1, char_index = 0))
    vr = ValidationResult(error = ve)
    assert(not vr)
    assert((vr.value, vr.error) == tuple(vr))


# Generated at 2022-06-24 10:29:00.548610
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    # Case: Multiple messages
    error = BaseError(messages=[Message(text='test-test-test')])
    assert repr(error) == "BaseError([Message(text='test-test-test', index=[], code='custom')])"

    # Case: Single message without index, key, code
    error = BaseError(text='test-test-test')
    assert repr(error) == "BaseError(text='test-test-test', code='custom')"

    # Case: Single message with code
    error = BaseError(text='test-test-test', code='test')
    assert repr(error) == "BaseError(text='test-test-test', code='test')"

    # Case: Single message with key
    error = BaseError(text='test-test-test', key='test')
    assert repr(error)

# Generated at 2022-06-24 10:29:09.801216
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    # One Message, no index
    error = ValidationError(
        text="May not have more than 100 characters",
        code="max_length",
        key="username",
    )
    assert error["username"] == "May not have more than 100 characters"
    assert len(error) == 1
    assert error.messages() == [
        Message(
            text="May not have more than 100 characters", code="max_length", key="username"
        )
    ]
    assert error["username"] == "May not have more than 100 characters"
    assert error == ValidationError(
        text="May not have more than 100 characters",
        code="max_length",
        key="username",
    )

# Generated at 2022-06-24 10:29:13.025579
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    e = SimpleError('test')
    assert e.messages() == [Message(text='test', code='validation_error')]



# Generated at 2022-06-24 10:29:16.494404
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    result_1 = ValidationResult(value=42)
    assert bool(result_1)

    result_2 = ValidationResult(error=ValidationError())
    assert not bool(result_2)

# Generated at 2022-06-24 10:29:21.802103
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    # Arrange
    line_no = 1
    column_no = 2
    char_index = 5
    m = Message(text='Some text', code='some_code', 
                start_position=Position(line_no, column_no, char_index),
                end_position=Position(line_no, column_no, char_index))


if __name__ == "__main__":
    # Just for unit test this module
    test_Message___repr__()

# Generated at 2022-06-24 10:29:28.747273
# Unit test for constructor of class BaseError
def test_BaseError():
    assert BaseError(text = "error message") == BaseError(messages = [Message(text = "error message")])
    assert BaseError(code = "code") == BaseError(messages = [Message(text = "", code = "code")])
    assert BaseError(key = "key") == BaseError(messages = [Message(text = "", key = "key")])
    assert BaseError(position = Position(1,2,3)) == BaseError(messages = [Message(text = "", position = Position(1,2,3))])
    assert BaseError(messages = [Message(text = "error message 1"), Message(text = "error message 2")]) == BaseError(messages = [Message(text = "error message 1"), Message(text = "error message 2")])


# Generated at 2022-06-24 10:29:33.863847
# Unit test for constructor of class BaseError
def test_BaseError():
    with pytest.raises(AssertionError):
        BaseError(text='Error', code='Not good')
    with pytest.raises(AssertionError):
        BaseError(text='Error', key='Not good')
    with pytest.raises(AssertionError):
        BaseError(text='Error', index=[1, 2, 3])
    with pytest.raises(AssertionError):
        BaseError(text='Error', position=Position(1, 2, 3)) # missing some arguments
    with pytest.raises(AssertionError):
        BaseError(messages=[])
    with pytest.raises(AssertionError):
        BaseError(text='Error', messages=[Message(text='Error 1', index=[1, 2])])

# Generated at 2022-06-24 10:29:39.127740
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    error = BaseError(messages=[Message(text="text", index=[])])
    assert list(error.messages()) == [Message(text="text", index=[])]
    error = BaseError(messages=[Message(text="text", index=[])], add_prefix="prefix")
    assert list(error.messages()) == [Message(text="text", index=["prefix"])]



# Generated at 2022-06-24 10:29:46.231930
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    assert str(BaseError()) == "{}"
    assert str(BaseError(text="error", code="code")) == "error"
    assert str(BaseError(messages=[Message(text="error", code="code", key="foo")])) == '{"foo": "error"}'
    assert str(
        BaseError(messages=[Message(text="error", code="code", key="foo"),
                             Message(text="error", code="code", key="bar")])
    ) == '{"foo": "error", "bar": "error"}'

# Generated at 2022-06-24 10:29:52.842241
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    print("######### test_BaseError___eq__() ########")
    from typesystem import ValidationError
    from typesystem.schema import StringType, IntegerType
    string_type = StringType(max_length=100)

    # Initializing these variables for usage in the code below.
    error = None
    other1 = None
    other2 = None

    # Check for equality for two ValidationErrors with one message each.
    error = ValidationError(text="This is a short text", code="short_text")
    other1 = ValidationError(text="This is a short text", code="short_text")
    other2 = ValidationError(text="This is a short text", code="long_text")
    assert error.__eq__(other1) == True
    assert error.__eq__(other2) == False



# Generated at 2022-06-24 10:29:53.857396
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    pass


# Generated at 2022-06-24 10:30:00.478323
# Unit test for constructor of class ParseError
def test_ParseError():
    temp = ParseError(text='test', code='test', key='test', position='test')
    assert type(temp._message_dict) == dict
    assert type(temp._messages) == list
    assert len(temp._messages) == 1
    assert type(temp._messages[0]) == Message
    assert temp._messages[0].text == 'test'
    assert temp._messages[0].code == 'test'
    assert temp._messages[0].key == 'test'
    assert temp._messages[0].position == 'test'
    

# Generated at 2022-06-24 10:30:07.028663
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult()
    assert str(result) == "ValidationResult(value=None)"
    result = ValidationResult(value=1)
    assert str(result) == "ValidationResult(value=1)"
    result = ValidationResult(error=ValidationError())
    assert str(result) == "ValidationResult(error=ValidationError({}))"
    result = ValidationResult(value=2, error=ValidationError())

# Generated at 2022-06-24 10:30:11.851392
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    # test for class ValidationError
    error = ValidationError(text='error1')
    assert error['test'] == 'error1'
    # test for class ParseError
    error = ParseError(text='error1')
    assert error['test'] == 'error1'
    print ('BaseError.__getitem__() unit test passed.')



# Generated at 2022-06-24 10:30:14.992495
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # Call __iter__
    validation_result = ValidationResult()
    result = next(iter(validation_result))


# Generated at 2022-06-24 10:30:16.540305
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    assert bool(ValidationError(text="foo")) == False


# Generated at 2022-06-24 10:30:18.127904
# Unit test for constructor of class Position
def test_Position():
    print(Position(1, 1, 1))
    assert Position(1, 1, 1) == Position(1, 1, 1)


# Generated at 2022-06-24 10:30:22.963706
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    # Structural equality is supported
    err1 = BaseError(text='Error 1', code='error_code_1')
    err2 = BaseError(text='Error 1', code='error_code_1')
    assert err1 == err2
    assert err1 is not err2
    # String equality is supported too
    assert str(err1) == 'Error 1'
    assert str(err2) == 'Error 1'

# Generated at 2022-06-24 10:30:31.340935
# Unit test for constructor of class ValidationError
def test_ValidationError():
    import jsonschema

    class MySchema(jsonschema.Draft7Validator):
        def __init__(self):
            schema = {
                "$schema": "http://json-schema.org/draft-07/schema#",
                "properties": {"foo": {"maxLength": 2}},
            }
            super().__init__(schema)

    schema = MySchema()
    errors = schema.iter_errors({"foo": "bar"})
    error = next(errors)
    err = error.message

    # noinspection PyTypeChecker
    print(type(err))
    print(err)
    assert 1

# Generated at 2022-06-24 10:30:43.914393
# Unit test for constructor of class BaseError
def test_BaseError():
    with pytest.raises(AssertionError):
        BaseError(text="a", messages=[])
    with pytest.raises(AssertionError):
        BaseError(messages=[Message(text="a"), Message(text="b")], text="a")
    with pytest.raises(AssertionError):
        BaseError(text="a", messages=[Message(text="a"), Message(text="b")])
    a = BaseError(text="a")
    b = BaseError(messages=[Message(text="a")])
    assert a == b
    assert a._message_dict == {"": "a"}
    assert a.messages() == [Message(text="a")]
    assert a[""] == "a"

# Generated at 2022-06-24 10:30:50.108249
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    def _(line_no, column_no, char_index):
        obj = Position(line_no=line_no, column_no=column_no, char_index=char_index)
        return f"{obj!r}"
    # Do:
    res = _(
        line_no=1,
        column_no=2,
        char_index=3,
    )
    # Assert:
    expected = "Position(line_no=1, column_no=2, char_index=3)"
    assert res == expected


# Generated at 2022-06-24 10:30:52.993068
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    assert repr(Position(line_no = 1, column_no = 2, char_index = 3)) == "Position(line_no=1, column_no=2, char_index=3)"


# Generated at 2022-06-24 10:30:55.561121
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    assert iter({}) == {}.__iter__()
    assert {}.__iter__() == {}.__iter__()



# Generated at 2022-06-24 10:30:57.473119
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert ValidationResult(value=1) == (1, None)
    assert ValidationResult(error="error") == (None, "error")



# Generated at 2022-06-24 10:31:04.548476
# Unit test for constructor of class Message
def test_Message():
    position = Position(1, 2, 3)
    message = Message(
        text="error", code="code", key="key", index=["a", "b"], position=position
    )
    assert message.text == "error"
    assert message.code == "code"
    assert message.index == ["a", "b"]
    assert message.start_position == position
    assert message.end_position == position
    #
    message = Message(
        text="error", code="code", index=["a", "b"], start_position=position, end_position=position
    )
    assert message.text == "error"
    assert message.code == "code"
    assert message.index == ["a", "b"]
    assert message.start_position == position
    assert message.end_position == position
    #

# Generated at 2022-06-24 10:31:11.676416
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    e1 = BaseError(text='text1', code='code1', key='key1', position='position1', messages=[Message(text='text11', code='code11', key='key11', position='position11')])
    e2 = BaseError(text='text2', code='code2', key='key2', position='position2', messages=[Message(text='text22', code='code22', key='key22', position='position22')])
    assert (e1 == e2) == False


# Generated at 2022-06-24 10:31:15.014179
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    message = Message(text="May not have more than 100 characters", code="max_length", key="username")
    assert hash(message) == hash(message)

# Generated at 2022-06-24 10:31:20.475140
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    code = "test_code"
    index = ["test", 1, "test"]
    text = "test_text"
    pos = Position(1, 2, 3)
    msg = Message(text=text, code=code, index=index, position=pos)
    assert hash(msg) == hash((code, tuple(index)))

# Generated at 2022-06-24 10:31:21.975984
# Unit test for constructor of class ParseError
def test_ParseError():
    pe = ParseError()
    assert pe is not None


# Generated at 2022-06-24 10:31:27.544701
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    class SubError(BaseError):
        def __init__(self, *, text: str = None, code: str = None, key: typing.Union[int, str] = None, position: Position = None, messages: typing.List[Message] = None):
            super().__init__(text=text, code=code, key=key, position=position, messages=messages)
    err = SubError(text="May not have more than 100 characters", code="max_length", key="length")
    None


# Generated at 2022-06-24 10:31:39.810613
# Unit test for method messages of class BaseError
def test_BaseError_messages():
    from bson import ObjectId

    class User:
        name: str
        email: str
        friends: typing.List["User"] = Field(default_factory=list)
        object_id: ObjectId = Field(default_factory=ObjectId)

    UserSchema = Schema(User)

    user1 = User(name="John", email="john@example.com")
    user2 = User(name="Bob", email="bob@example.com")

    user1.friends.append(user2)


# Generated at 2022-06-24 10:31:46.249899
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    data = {
        1,
        2,
        3
    }
    error = BaseError(messages=[
        Message(text="error1", code=None, key=1),
        Message(text="error2", code=None, key=2),
        Message(text="error3", code=None, key=3)
    ])
    assert len(error) == 3


# Generated at 2022-06-24 10:31:58.198022
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    # Test for a case when self.line_no of expected result does not match to one of actual result
    test_case = Position(line_no=10, column_no=10, char_index=10)
    assert test_case.__eq__(Position(line_no=11, column_no=10, char_index=10)) == False

    # Test for a case when self.column_no of expected result does not match to one of actual result
    test_case = Position(line_no=10, column_no=10, char_index=10)
    assert test_case.__eq__(Position(line_no=10, column_no=11, char_index=10)) == False

    # Test for a case when self.char_index of expected result does not match to one of actual result

# Generated at 2022-06-24 10:32:02.247763
# Unit test for constructor of class ValidationError
def test_ValidationError():
    error = ValidationError(text="Error", code="custom", key="key")
    assert error._messages == [Message(
        text="Error", code="custom", key="key", position=None)]
    assert error._message_dict == {"key": "Error"}


# Generated at 2022-06-24 10:32:04.767488
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    """
    Test case for the method BaseError.__repr__
    """
    test_object = BaseError()
    assert test_object != 2



# Generated at 2022-06-24 10:32:15.501502
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    a_message = Message(text='an error')
    a_message_two = Message(text='an error')
    another_message = Message(text='another error')

    assert hash(a_message) == hash(a_message_two)
    assert hash(a_message) != hash(another_message)

    an_error = ValidationError(messages=[a_message])
    an_error_two = ValidationError(messages=[a_message_two])
    another_error = ValidationError(messages=[another_message])

    assert hash(an_error) == hash(an_error_two)
    assert hash(an_error) != hash(another_error)

    an_error_three = ValidationError(
        messages=[a_message, another_message]
    )
    an_error_four = Val

# Generated at 2022-06-24 10:32:19.783125
# Unit test for method __iter__ of class BaseError
def test_BaseError___iter__():
    d1 = BaseError({'name': "Not equal to 5.0", 'error': "e1", 'key': "k1"})
    d2 = BaseError(error=d1)
    for key in d2:
        print(key, end =' ')
        

# Generated at 2022-06-24 10:32:23.618077
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    a = ValidationResult(value = 1)
    assert (1, None) == a
    # Check if bool() returns True
    assert bool(a)

    b = ValidationResult(error = 2)
    assert (None, 2) == b
    # Check if bool() returns False
    assert not bool(b)

# Generated at 2022-06-24 10:32:27.143160
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError(text="This is an error")
    assert error.messages(add_prefix="x") == [
        Message(text="This is an error", code="custom", index=["x"])
    ]


# Generated at 2022-06-24 10:32:33.516893
# Unit test for constructor of class Message
def test_Message():
    message = Message(text="Pin must contain only digits", code="bad_pin",
                      key="pin", start_position=Position(1,2,3),
                      end_position=Position(1,2,3))
    assert message.text == "Pin must contain only digits"
    assert message.code == "bad_pin"
    assert message.index == ["pin"]
    assert message.start_position == Position(1,2,3)
    assert message.end_position == Position(1,2,3)
    

# Generated at 2022-06-24 10:32:44.522500
# Unit test for constructor of class ParseError
def test_ParseError():
    pe1 = ParseError()
    assert pe1.messages()[0].text == "Unexpected EOF"
    pe2 = ParseError(text="Unexpected character")
    assert pe2.messages()[0].text == "Unexpected character"
    pe3 = ParseError(text="Unexpected character", code="invalid_character", position=Position(1,1,1))
    assert pe3.messages()[0].text == "Unexpected character"
    assert pe3.messages()[0].code == "invalid_character"
    assert pe3.messages()[0].position == Position(1,1,1)
    pe4 = ParseError(messages=[Message("Unexpected character", code="invalid_character", position=Position(1,1,1))])
    assert pe4.messages

# Generated at 2022-06-24 10:32:45.728106
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    with pytest.raises(AssertionError):
        BaseError(text='abc')
    BaseError(messages=[Message(text='abc')])


# Generated at 2022-06-24 10:32:52.335419
# Unit test for method __getitem__ of class BaseError
def test_BaseError___getitem__():
    errors = [
        Message(text="May not be empty", code="empty", index=[], position=(1, 1)),
        Message(text="May not have more than 100 characters", code="max_length", index=[], position=(1, 1)),
        Message(text="May not contain more than 10 items", code="max_items", index=["items"], position=(1, 1)),
    ]
    error = ValidationError(messages=errors)
    try:
        error['']
        assert False
    except KeyError:
        assert True
    assert error[0] == 'May not contain more than 10 items'
    assert error['items'][0] == 'May not contain more than 10 items'
    try:
        error['items'][0]['items']
        assert False
    except KeyError:
        assert True

# Unit

# Generated at 2022-06-24 10:32:53.244977
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    pass


# Generated at 2022-06-24 10:32:56.290160
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = ValidationError(text="error", code="error", key="error")
    error2 = ValidationError(text="error", code="error", key="error")
    assert error1 == error2
    assert error1 == error2



# Generated at 2022-06-24 10:32:59.589539
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    assert (Position(line_no=1, column_no=2, char_index=3)).__repr__() == ('Position(line_no=1, column_no=2, char_index=3)')

# Generated at 2022-06-24 10:33:05.399961
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    print("\n\n###### Running test_Position___repr__")
    line_no = 1
    column_no = 1
    char_index = 2
    position = Position(line_no, column_no, char_index)
    print("position = {}".format(position))
    assert position.line_no == line_no
    assert position.column_no == column_no
    assert position.char_index == char_index
    print("test_Position___repr__ passed")


# Generated at 2022-06-24 10:33:09.992477
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    v1 = ValidationResult(value = 0)
    assert v1.__repr__() == "ValidationResult(value=0)"
    v2 = ValidationResult(error = 12)
    assert v2.__repr__() == "ValidationResult(error=12)"



# Generated at 2022-06-24 10:33:17.835439
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    pos = Position(line_no=1, column_no=2, char_index=3)
    assert pos == pos
    assert pos == Position(line_no=1, column_no=2, char_index=3)
    assert not pos == Position(line_no=1, column_no=2, char_index=2)
    assert not pos == Position(line_no=1, column_no=1, char_index=3)
    assert not pos == Position(line_no=0, column_no=2, char_index=3)
    assert not pos == None
    assert not pos == 123



# Generated at 2022-06-24 10:33:26.610203
# Unit test for method __len__ of class BaseError
def test_BaseError___len__():
    # Create some error messages containing valid position information
    msg1 = Message(
        text="foo", code="c1", key="name", start_position=Position(0, 2, 2)
    )
    msg2 = Message(text="bar", code="c2", key="age", start_position=Position(2, 3, 3))
    msg3 = Message(
        text="baz",
        code="c2",
        index=["name"],
        start_position=Position(4, 5, 5),
    )
    msg4 = Message(
        text="quux",
        code="c4",
        index=["foo", "bar"],
        start_position=Position(6, 7, 7),
    )

# Generated at 2022-06-24 10:33:36.687440
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    messages = [Message(text="text1"), Message(text="text2")]
    error = ValidationError(messages=messages)
    error_hash = hash(error)
    assert error_hash == hash(error)
    assert error_hash != hash(ValidationError(messages=[messages[1]] + [messages[0]]))
    assert error_hash != hash(ValidationError(messages=[] + [messages[0]]))
    assert error_hash != hash(ValidationError(messages=[messages[0]] + []))
    assert error_hash != hash(ValidationError(messages=messages + []))
    assert error_hash != hash(ValidationError(messages=[] + messages))


# Generated at 2022-06-24 10:33:47.468503
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    error = ValidationError(text='hello', code='test')
    assert repr(error) == "ValidationError(text='hello', code='test')"
    error = ValidationError(messages=[Message(text='hello')])
    assert repr(error) == "ValidationError([Message(text='hello', code='custom', index=[])])"
    error = ValidationError(messages=[Message(text='hello', index=['user'])])
    assert repr(error) == "ValidationError([Message(text='hello', code='custom', index=['user'])])"
    error = ValidationError(messages=[Message(text='hello', index=['user', 'name'])])
    assert repr(error) == "ValidationError([Message(text='hello', code='custom', index=['user', 'name'])])"

# Generated at 2022-06-24 10:33:56.924217
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    message = Message(text='My first message', code='my_code_1', index=['index1', 'index2'], start_position=Position(line_no=2, column_no=2, char_index=2), end_position=Position(line_no=2, column_no=2, char_index=2))
    print(repr(message))
    message2 = Message(text='My second message', code='my_code_2', index=['index3', 'index4'], start_position=Position(line_no=3, column_no=3, char_index=3), end_position=Position(line_no=3, column_no=3, char_index=3))
    print(repr(message2))

test_Message___repr__()

# Generated at 2022-06-24 10:34:04.218601
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    messages = [
        Message(text="message1", code="custom", index=["user", "username"]),
        Message(text="message2", code="custom", index=["user", "password"]),
        Message(text="message3", code="custom", index=["user", 0, "username"]),
        Message(text="message4", code="custom", index=["user", 0, "password"]),
        Message(text="message5", code="custom", index=["user", 1, "username"]),
        Message(text="message6", code="custom", index=["user", 1, "password"]),
    ]
    error = BaseError(messages = messages)

    # Check that two different ValidationErrors with the same messages
    # are equal
    error1 = BaseError(messages = messages)
    assert error == error1

# Generated at 2022-06-24 10:34:10.228571
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult()
    assert not result
    assert result.value is None
    assert result.error is None

    result = ValidationResult(value=True)
    assert result
    assert result.value is True
    assert result.error is None

    result = ValidationResult(error=ValidationError(text="oops"))
    assert not result
    assert result.value is None
    assert isinstance(result.error, ValidationError)
    assert "oops" in str(result.error)

# Generated at 2022-06-24 10:34:14.013856
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    """
    To test the method __eq__ of class Message
    """
    msg1 = Message(text="hello", code="a", key=1, position=1)
    msg2 = Message(text="hello", code="a", key=1, position=1)
    assert msg1 == msg2


# Generated at 2022-06-24 10:34:25.136239
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="file", key="name") == Message(text="file", key="name")
    assert Message(text="file", code="required") == Message(text="file", code="required")
    assert Message(text="file", position=Position(1, 2, 3)) == Message(text="file", position=Position(1, 2, 3))
    assert Message(text="file", index=["a"]) == Message(text="file", index=["a"])
    assert Message(text="file", index=["a", "b"]) == Message(text="file", index=["a", "b"])
    assert Message(text="file") == Message(text="file")
    assert Message(text="file") != Message(text="File")

# Generated at 2022-06-24 10:34:30.801832
# Unit test for method __hash__ of class BaseError
def test_BaseError___hash__():
    # Setup test
    error1 = BaseError(text="error1")
    error2 = BaseError(text="error1")
    error3 = BaseError(text="error3")

    # Execute test
    hash1 = error1.__hash__()
    hash2 = error2.__hash__()
    hash3 = error3.__hash__()

    # Verify results
    assert hash1 == hash2
    assert hash1 != hash3
    assert hash2 != hash3

# Generated at 2022-06-24 10:34:41.079136
# Unit test for constructor of class ParseError
def test_ParseError():
    p = ParseError(text="hey")
    assert p._messages[0].text == "hey"
    assert p._message_dict[""] == "hey"
    assert p.messages()[0].text == "hey"
    assert list(p) == [""]
    assert len(p) == 1
    assert p[""] == "hey"
    assert p == ParseError(text="hey")
    assert not p == ParseError(text="hello")
    assert str(p) == "hey"
    assert p == ParseError(messages=[Message(text="hey")])
    assert p == ParseError(text="hey", messages=[Message(text="hey")])
    assert p == ParseError(text="hey", messages=[Message(text="hey"), Message(text="hey")])
    assert p == Parse

# Generated at 2022-06-24 10:34:44.841788
# Unit test for method __hash__ of class Message
def test_Message___hash__():
    m = Message(text="banana", index=["users", 5], start_position=Position(1, 2, 3))
    m2 = Message(text="banana", index=["users", 5], start_position=Position(1, 2, 3))
    assert hash(m) == hash(m2)
    m.code = "min_length"
    m2.code = "min_length"
    assert hash(m) == hash(m2)
    m2.code = "max_length"
    assert hash(m) != hash(m2)



# Generated at 2022-06-24 10:34:49.860699
# Unit test for method __repr__ of class Position
def test_Position___repr__():
    s = Position(line_no=1, column_no=1, char_index=0)
    assert repr(s) == 'Position(line_no=1, column_no=1, char_index=0)'


# Generated at 2022-06-24 10:34:52.539313
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert list(ValidationResult(value=1)) == [1, None]
    assert list(ValidationResult(error=ValidationError())) == [None, ValidationError()]

# Generated at 2022-06-24 10:34:58.098829
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    """
    test_ValidationResult___iter__ test
    """
    first_value = "first value"
    second_value = "second_value"
    validation_result = ValidationResult(value=first_value)
    for i, item in enumerate(validation_result):
        if i == 1:
            assert item == second_value, "second_value expected"
        else:
            assert item == first_value, "first_value expected"


# Generated at 2022-06-24 10:35:08.017317
# Unit test for method __repr__ of class Message
def test_Message___repr__():
    class_name = Message.__name__
    text = '"May not have more than 100 characters"'
    code = 'max_length'
    index = [3]
    start_position = Position(1,1,1)
    end_position = Position(1,1,1)
    position = Position(1,1,1)
    assert Message(text=text, code=code, index=index, start_position=start_position,end_position=end_position).__repr__() == f"{class_name}(text={text!r}, code={code!r}, index={index!r}, start_position={start_position!r}, end_position={end_position!r})"

# Generated at 2022-06-24 10:35:19.659952
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # case 1
    msg1 = Message(text="test", code="test", start_position=Position(1, 1, 1))
    msg2 = Message(text="test", code="test", start_position=Position(1, 1, 1))
    result = msg1 == msg2
    assert result is True
    # case 2
    msg1 = Message(text="test", code="test", start_position=Position(1, 2, 1))
    msg2 = Message(text="test", code="test", start_position=Position(1, 1, 1))
    result = msg1 == msg2
    assert result is False
    # case 3
    msg1 = Message(text="test", code="test", start_position=Position(1, 1, 1))

# Generated at 2022-06-24 10:35:26.376687
# Unit test for method __bool__ of class ValidationResult
def test_ValidationResult___bool__():
    x = ValidationResult(value=1)
    assert bool(x) is True
    assert bool(ValidationResult(value=0)) is True
    assert bool(ValidationResult(value=None)) is True
    assert bool(ValidationResult(value="")) is True
    assert bool(ValidationResult(value=False)) is True
    assert bool(ValidationResult(error="")) is False
    assert bool(ValidationResult(error=ValidationError())) is False

