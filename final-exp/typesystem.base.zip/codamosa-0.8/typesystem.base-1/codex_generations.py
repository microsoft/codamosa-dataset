

# Generated at 2022-06-12 15:28:47.691327
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    x, y = ValidationResult(value=23)
    assert x == 23
    assert y is None


# Generated at 2022-06-12 15:28:50.387240
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    v = ValidationResult(value=4)

    test_list = list(v)
    expected_list = [4, None]

    assert expected_list == test_list


# Generated at 2022-06-12 15:28:56.017127
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    # 1. test for class BaseError with one message
    validation_error = BaseError(text='May not have more than 100 characters',code='max_length', key='username')
    print(validation_error)
    assert validation_error.__repr__() == "BaseError(text='May not have more than 100 characters', code='max_length', index=['username'])"


# Generated at 2022-06-12 15:29:08.081456
# Unit test for method __eq__ of class Message
def test_Message___eq__():

    assert Message(text="", code="", index=[]) == Message(text="", code="", index=[])
    assert Message(text="", code="", index=[]) == Message(text="", code="", index=[])
    assert Message(text="", code="", index=[]) == Message(text="", code="", index=[])
    assert Message(text="", code="", index=[]) == Message(text="", code="", index=[])
    assert Message(text="", code="", index=[]) == Message(text="", code="", index=[])
    assert Message(text="", code="", index=[]) == Message(text="", code="", index=[])
    assert Message(text="", code="", index=[]) == Message(text="", code="", index=[])

# Generated at 2022-06-12 15:29:20.559516
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    """
    Assert that Message.__eq__() and Message.__hash__() are symmetric.
    """
    messages = [
        Message(text="foo"),
        Message(text="foo", code="code"),
        Message(text="foo", key="key"),
        Message(text="foo", index=[0, 1]),
        Message(
            text="foo",
            start_position=Position(1, 2, 3),
            end_position=Position(4, 5, 6),
        ),
    ]
    for message1 in messages:
        assert message1 == message1
        assert hash(message1) == hash(message1)
        for message2 in messages:
            if message1 == message2:
                assert hash(message1) == hash(message2)

# Generated at 2022-06-12 15:29:27.850818
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    """
    Method __eq__ of class Message
    """
    # Initialize a test object
    message = Message(text='text', code='code', key='key', index=['index'])

    # Assert
    assert message == Message(text='text', code='code', key='key', index=['index'])
    assert message != Message(text='text', code='code', key='key', index=['index', 'index'])
    assert message != Message(text='text', code='code', index=['index', 'index'])
    assert message != Message(text='text', code='code', key='key')
    assert message != Message(text='text', code='code2', key='key', index=['index'])
    assert message != Message(text='text2', code='code', key='key', index=['index'])

# Generated at 2022-06-12 15:29:33.020342
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test BaseError.__eq__ with arguments: error1, error2
    # Valid arguments
    error1 = ValidationError(text="abc")
    error2 = ValidationError(text="abc")
    assert error1 == error2
    assert error2 == error1
    error1 = ValidationError(messages=[Message(text="abc1"), Message(text="abc2")])
    error2 = ValidationError(messages=[Message(text="abc2"), Message(text="abc1")])
    assert error1 == error2
    assert error2 == error1
    error1 = ValidationError(text="abc")
    error2 = ValidationError(messages=[Message(text="abc")])
    assert error1 == error2
    assert error2 == error1

    # Invalid arguments

# Generated at 2022-06-12 15:29:35.474103
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    print(BaseError())

print(test_BaseError___repr__.__doc__)
test_BaseError___repr__()
print()

# Generated at 2022-06-12 15:29:45.325970
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    '''Unit test for method __eq__ of class Position'''
    assert Position(line_no=1, column_no=2, char_index=3) == Position(line_no=1, column_no=2, char_index=3)
    assert Position(line_no=1, column_no=2, char_index=3) != Position(line_no=2, column_no=2, char_index=3)
    assert Position(line_no=1, column_no=2, char_index=3) != Position(line_no=1, column_no=3, char_index=3)
    assert Position(line_no=1, column_no=2, char_index=3) != Position(line_no=1, column_no=2, char_index=4)

# Generated at 2022-06-12 15:29:55.337199
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    import typesystem
    validation_result_1 = typesystem.ValidationResult(value='test')
    expected_1 = ['test', None]
    actual_1: typing.List[typing.Any] = [validation_result_1.value, validation_result_1.error]
    if not actual_1 == expected_1:
        print(f"Fail. actual_1 {actual_1} is not equal to expected_1 {expected_1}")
    validation_result_2 = typesystem.ValidationResult(error='test')
    expected_2 = [None, 'test']
    actual_2: typing.List[typing.Any] = [validation_result_2.value, validation_result_2.error]

# Generated at 2022-06-12 15:30:06.148591
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert list(ValidationResult(value=1)) == [1, None]
    assert list(ValidationResult(value=1, error=ValidationError(text="error"))) == [1, None]
    assert list(ValidationResult(error=ValidationError(text="error"))) == [None, ValidationError(text="error")]



# Generated at 2022-06-12 15:30:16.886597
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    p1 = Position(line_no = 1, column_no = 1, char_index = 1)
    p2 = Position(line_no = 1, column_no = 1, char_index = 1)
    p3 = Position(line_no = 2, column_no = 1, char_index = 1)
    p4 = Position(line_no = 1, column_no = 2, char_index = 1)
    p5 = Position(line_no = 1, column_no = 1, char_index = 2)
    p6 = Position(line_no = 1, column_no = 2, char_index = 2)
    
    assert p1 == p2
    assert p1 != p3
    assert p1 != p4
    assert p1 != p5
    assert p1 != p6


# Generated at 2022-06-12 15:30:20.328874
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    from typesystem import Schema

    schema = Schema([str])
    validation_result = schema.validate_or_error(["test"])
    assert validation_result.value == ["test"]
    assert validation_result.error is None

    value, error = validation_result
    assert value == ["test"]
    assert error is None


# Generated at 2022-06-12 15:30:25.182305
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    obj = ValidationResult(value = {'a': 1, 'b': 2})
    for val in obj:
        print(val)

    with pytest.raises(AssertionError):
        ValidationResult(value = {'a': 1, 'b': 2}, error = 'err')

    with pytest.raises(AssertionError):
        ValidationResult(value = None, error = None)


# Generated at 2022-06-12 15:30:31.675015
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    text = 'May not have more than 100 characters'
    code = 'max_length'
    key = 'username'
    messages = [Message(text=text, code=code, key=key)]
    new_BaseError = BaseError(messages=messages)
    expected_result = f"BaseError([Message(text={text}, code={code}, key={key})])"
    assert repr(new_BaseError) == expected_result


# Generated at 2022-06-12 15:30:34.562674
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    import typesystem
    assert list(ValidationResult(value=1)) == [1, None]
    assert list(ValidationResult(error=typesystem.ValidationError())) == [None, typesystem.ValidationError()]

# Generated at 2022-06-12 15:30:36.799806
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    v = ValidationResult(value='abc')
    v = v.__iter__()
    assert next(v) == 'abc'
    assert next(v) is None
    with pytest.raises(StopIteration):
        next(v)


# Generated at 2022-06-12 15:30:42.871529
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    BaseError(text='asd') == BaseError(text='asd')
    BaseError(text='asd') != BaseError(text='qwe')
    BaseError(text='asd') != BaseError(text=123)
    BaseError(text='asd') == BaseError(text='asd')
    BaseError(text='asd') != BaseError(text='qwe')
    BaseError(text='asd') != BaseError(text=123)


# Generated at 2022-06-12 15:30:52.835287
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    from typesystem.base import BaseType
    from typesystem.field import Field

    class PersonSchema(BaseType):
        name = Field(str)
        age = Field(int)

    schema = PersonSchema()

    # Instantiated as a ValidationError with a single error message.
    error1 = ValidationError(text="Required", code="required", key="age")
    assert repr(error1) == "ValidationError(text='Required', code='required')"

    # Instantiated as a ValidationError with a list of error messages.
    error2 = ValidationError(
        messages=[
            Message(text="Required", code="required", key="name"),
            Message(text="Not an integer", code="invalid", key="age"),
        ]
    )

# Generated at 2022-06-12 15:30:54.906991
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    print(BaseError(text="error message"))
    print(BaseError(messages=[Message(text="error message")]))


# Generated at 2022-06-12 15:31:12.233540
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    def must_be_a_list(param_1):
        a = list()
        if isinstance(param_1, list):
            a = list(param_1)
        else:
            raise ValidationError({"a_key" : "param_1 must be a list"})
        return a
    a = ValidationResult(value = [1, 2, 3])
    b = ValidationResult(error = ValidationError({"a_key" : "param_1 must be a list"}))
    assert a is not None
    assert b is not None

    # Check if the iterator of a returns the expected value
    a_iter = iter(a)
    assert next(a_iter) == [1, 2, 3]
    assert next(a_iter) is None

    # Check if the iterator of b returns the expected value


# Generated at 2022-06-12 15:31:16.042784
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    data = {'id': 1,
            'name': 'A green door',
            'price': 12.50,
            'tags': ['home', 'green']}
    value, error = MySchema.validate_or_error(data)
    assert isinstance(value, ValidationResult)
    validation_result = value
    for i in validation_result:
        print(i)


# Generated at 2022-06-12 15:31:19.091844
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError(text="error"))
    assert list(vr) == [None, ValidationError(text="error")]
    

# Generated at 2022-06-12 15:31:22.330575
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    value, error = ValidationResult(value=4)
    assert list(value) == [4, None]
    assert list(error) == [None, ValidationError()]


# Generated at 2022-06-12 15:31:24.904305
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=1)
    it = iter(result)
    i1 = next(it)
    i2 = next(it)
    assert i1 == 1
    assert i2 is None


# Generated at 2022-06-12 15:31:28.627517
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert ['value', 'error'] == list(ValidationResult(value='value'))
    assert ['error', None] == list(ValidationResult(error='error'))


# Generated at 2022-06-12 15:31:34.248449
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    res1 = ValidationResult(value=[1, 'two', 3])
    res2 = ValidationResult(error=ParseError(text='Expected , delimiter'))

    assert list(iter(res1)) == [res1.value, res1.error]
    assert list(iter(res2)) == [res2.value, res2.error]


# Generated at 2022-06-12 15:31:36.057200
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(error=ValidationError())
    assert len(list(iter(result))) == 2

# Generated at 2022-06-12 15:31:37.635456
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=123)
    assert list(vr) == [123, None]



# Generated at 2022-06-12 15:31:40.387901
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    val = ValidationResult(value = 123)
    assert list(val) == [123, None]
    err = ValidationResult(error = "some error")
    assert list(err) == [None, "some error"]

# Generated at 2022-06-12 15:31:49.639265
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    """
    Make sure the method __iter__ of class ValidationResult works fine

    """
    vr = ValidationResult(value=1)
    vr_iter = vr.__iter__()
    assert vr_iter.__next__() == 1
    vr_iter.__next__()


# Generated at 2022-06-12 15:31:52.999026
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    """
    Test method __iter__ of class ValidationResult
    """
    result = ValidationResult(value="test_value")
    assert isinstance(result.__iter__(), typing.Iterator)
    for v in result:
        if v is not None:
            assert v == "test_value"

# Generated at 2022-06-12 15:31:57.113148
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=1)
    assert isinstance(result, ValidationResult)
    assert result.value == 1
    assert result.error is None
    v, e = result
    assert v == 1
    assert e is None


# Generated at 2022-06-12 15:32:00.385944
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    results = [
        ValidationResult(value=True),
        ValidationResult(error=ValidationError("error msg"))
    ]
    for result in results:
        for item in result:
            pass
        pass

# Generated at 2022-06-12 15:32:06.735403
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result_valid = ValidationResult(value=10)
    result_invalid = ValidationResult(error=ValidationError())
    # Test validity
    assert all([x is result_valid.value for x in result_valid])
    assert all([x is result_invalid.error for x in result_invalid])
    # Test invalidity
    assert all([x is not result_invalid.value for x in result_invalid])
    assert all([x is not result_valid.error for x in result_valid])


# Generated at 2022-06-12 15:32:08.333891
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert list(ValidationResult(value=1)) == [1, None]
    assert list(ValidationResult(error=ValidationError())) == [None, ValidationError()]

# Generated at 2022-06-12 15:32:13.833479
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    value = "foo"
    error = ValidationError(messages=[Message(text="bar")])
    result = ValidationResult(value=value, error=error)
    assert len(result) == 2
    assert result[0] == value
    assert result[1] == error
    assert list(result) == [value, error]
    assert list(iter(result)) == [value, error]


# Generated at 2022-06-12 15:32:17.723388
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert list(ValidationResult()) == [None, None]
    assert list(ValidationResult(error=ValidationError())) == [None, ValidationError()]
    assert list(ValidationResult(value=123)) == [123, None]



# Generated at 2022-06-12 15:32:20.770483
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value="value1")
    result_list = [item for item in result]
    print(result_list)
    print(result_list[0])
    print(result_list[1])


# Generated at 2022-06-12 15:32:25.124864
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    v = ValidationResult(value=1)
    assert v
    assert next(iter(v)) == 1

    e = ValidationResult(error=ParseError(text="Error: parse error"))
    assert not e
    assert isinstance(next(iter(e)), ParseError)

test_ValidationResult___iter__()

# Generated at 2022-06-12 15:32:37.851342
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    obj = ValidationResult(value=1,)
    assert list(obj) == [1, None]
    obj = ValidationResult(error='foo',)
    assert list(obj) == [None, 'foo']


# Generated at 2022-06-12 15:32:39.104120
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    ValidationResult(value=1)
    ValidationResult(error=ValidationError())

# Generated at 2022-06-12 15:32:46.378328
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    res = ValidationResult(value=1)
    assert list(res) == [1, None]
    assert next(iter(res)) == 1
    res = ValidationResult(error=ValidationError(text="error message", code="code"))
    assert list(res) == [None, ValidationError(text="error message", code="code")]
    assert next(iter(res)) is None

if __name__ == "__main__":
    import pytest
    pytest.main(["-s", "-v", "--tb=native"] + sys.argv)

# Generated at 2022-06-12 15:32:47.199484
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    ValidationResult(value=6)


# Generated at 2022-06-12 15:32:57.050573
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():

    vr1 = ValidationResult(value=42)
    vr2 = ValidationResult(error="wrong answer")

    # Test with if __name__ == '__main__':
    assert isinstance(vr1, ValidationResult)
    assert isinstance(vr2, ValidationResult)
    assert not vr1
    assert vr2
    assert vr1.value == 42
    assert vr1.error is None
    assert vr2.value is None
    assert vr2.error == "wrong answer"

    # Test the method __iter__ of class ValidationResult
    _vr1 = iter(vr1)
    assert next(_vr1) == 42
    assert next(_vr1) is None

    _vr2 = iter(vr2)
    assert next(_vr2) == None
    assert next(_vr2)

# Generated at 2022-06-12 15:33:02.261548
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    parameters = [
        {"value": None, "error": ValidationError()},
        {"value": 1, "error": None},
    ]
    expected_values = [
        None, 1
    ]

    values = []
    for parameter in parameters:
        result = ValidationResult(**parameter)
        for value in result:
            values.append(value)

    assert values == expected_values

# Generated at 2022-06-12 15:33:08.059627
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # Unit test for method __iter__ of class ValidationResult
    ValidationResult(value="value", error="error")
    # func(ValidationResult())
    # func(ValidationResult(value=1, error=2))
    # func(ValidationResult(value=[3], error=[4]))
    # func(ValidationResult(value={5}, error={6}))
    # try:
        # pass
   # except error:
        # pass
    # finally:
        # pass
    # else:
        # pass
    # if __name__ == '__main__':
    #     pass

# Generated at 2022-06-12 15:33:19.589245
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    for value in [
        1,
        3.1415926535,
        False,
        True,
        None,
        "a",
        "ab",
        "abc",
        "abcde",
        [1],
        [1, 2],
        [1, 2, 3],
        [1, 2, 3, 4],
    ]:
        x, y = ValidationResult(value=value)
        assert x == value
        assert y is None
        assert x is ValidationResult(value=value)[0]
        assert y is ValidationResult(value=value)[1]

# Generated at 2022-06-12 15:33:22.735247
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    v = ValidationResult(value = 'value')
    assert list(v) == ['value', None] 

    v = ValidationResult(error = 'error')
    assert list(v) == [None, 'error']



# Generated at 2022-06-12 15:33:29.288711
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    import inspect
    import sys
    from typesystem import TypeSystem

    # Arrange
    value = 'test'
    validation_result = ValidationResult(value=value)

    # Act
    for item in validation_result:
        pass

    # Assert
    assert (
        # NOTE: This is a side effect of being able to iterate over the result
        #       of ValidationResult, it is not an intended feature.
        inspect.isgenerator(item),
        "Generator is expected to be generated, but got {}".format(type(item)),
    )
    assert (
        sys.version_info.major >= 3,
        "Native generator is expected to be created, but the Python version is {}".format(sys.version_info.major),
    )