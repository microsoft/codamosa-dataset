

# Generated at 2022-06-12 15:28:54.537284
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert iter(ValidationResult(value=1)) == (1, None)
    assert iter(ValidationResult(error=ValidationError())) == (None, ValidationError())



# Generated at 2022-06-12 15:28:57.468889
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr1 = ValidationResult(value=123)
    assert list(vr1) == [123, None]
    vr2 = ValidationResult(error="Error")
    assert list(vr2) == [None, "Error"]


# Generated at 2022-06-12 15:29:08.287476
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    error_msg = BaseError(text='some error')
    assert 'some error' == str(error_msg)
    error_msg = BaseError(messages = [Message(text='some error', key = 'username', position = Position(line_no=1,column_no=1,char_index=1))])
    assert {'username': 'some error'} == dict(error_msg)
    error_msg = BaseError(messages = [Message(text='some error', code='max_length')])
    assert str(error_msg) == str(dict(error_msg))
    error_msg = BaseError(messages = [Message(text='some error', index = ['username'])])
    assert {'username': 'some error'} == dict(error_msg)

# Generated at 2022-06-12 15:29:11.908374
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert (1, None) == ValidationResult(value=1)
    assert (None, 2) == ValidationResult(error=2)
    assert (1, 2) == ValidationResult(value=1, error=2)

# Generated at 2022-06-12 15:29:17.258576
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    error = BaseError(text="This is a BaseError")
    assert str(error) == "This is a BaseError"

    assert str(BaseError(messages=[Message(text="This is a BaseError")])) == (
        "{'': 'This is a BaseError'}"
    )


# Generated at 2022-06-12 15:29:22.238863
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # Arrange
    aResult = ValidationResult(value="ok")
    aResult2 = ValidationResult(error=ValidationError(text="error"))

    # Act/Assert
    assert list(aResult) == ["ok", None]
    assert list(aResult2) == [None, ValidationError(text="error")]



# Generated at 2022-06-12 15:29:25.557720
# Unit test for constructor of class BaseError
def test_BaseError():
    error = BaseError(
        code="foo", text="text", key=1, position=Position(1, 1, 1), messages=[]
    )
    assert error.messages() == [Message(code="foo", text="text", key=1, position=Position(1, 1, 1))]

# Generated at 2022-06-12 15:29:34.167394
# Unit test for constructor of class BaseError
def test_BaseError():
    error = BaseError(text="Error Message", code="my_code", key="my_key")
    print(error)
    # output:
    # BaseError(text='Error Message', code='my_code')

    error = BaseError(messages=[Message(text="Error Message 1", key="my_key"), Message(text="Error Message 2")])
    print(error)
    # output:
    # BaseError([Message(text='Error Message 1', code='custom', key='my_key'), Message(text='Error Message 2', code='custom')])



# Generated at 2022-06-12 15:29:44.428752
# Unit test for constructor of class ParseError
def test_ParseError():
    # test case with 1 message, with code and index
    text = 'test_1'
    code = 'error_code_1'
    index = 'test_index_1'
    error_1 = ParseError(text=text, code=code, index=index)
    assert error_1['test_index_1'] == 'test_1'
    assert len(error_1) == 1
    assert error_1.messages() == [Message(text='test_1', code='error_code_1', index=['test_index_1'])]
    assert error_1._messages == [Message(text='test_1', code='error_code_1', index=['test_index_1'])]
    assert error_1._message_dict == {'test_index_1': 'test_1'}

   

# Generated at 2022-06-12 15:29:46.050963
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    error = ValidationError()
    assert str(error) == "{}"
test_BaseError___str__()


# Generated at 2022-06-12 15:30:05.977153
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    BaseError(text="error").__str__()
    BaseError(messages=[Message(text="error")]).__str__()
    BaseError(messages=[Message(text="error", index=[1])]).__str__()
    BaseError(messages=[Message(text="error", index=[1, "key"])]).__str__()
    BaseError(messages=[Message(text="error", index=["key"])]).__str__()



# Generated at 2022-06-12 15:30:13.069399
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    error = BaseError(messages=[Message(text='May not have more than 100 characters')])
    error1 = BaseError(messages=[Message(text='May not have more than 100 characters'),Message(text='This field is required.')])
    error2 = BaseError(messages=[Message(text='May not have more than 100 characters',code='max_length')])
    error3 = BaseError(messages=[Message(text='May not have more than 100 characters',code='max_length', key='username')])
    assert len(error) == 1
    assert len(error1) == 2
    assert len(error2) == 1
    assert len(error3) == 1
    assert error.messages()[0].text == 'May not have more than 100 characters'
    assert error['username'] == 'May not have more than 100 characters'


# Generated at 2022-06-12 15:30:16.444827
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    str(BaseError(text='error')) == 'error'
    assert str(BaseError(messages=[Message(text='error')])) == 'error'



# Generated at 2022-06-12 15:30:17.021276
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    BaseError()

# Generated at 2022-06-12 15:30:18.220796
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    assert str(ValidationError(text="hello")) == "hello"

# Generated at 2022-06-12 15:30:19.517875
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    error = ValidationError(text="The field 'username' may not be empty.")
    assert str(error) == "The field 'username' may not be empty."


# Generated at 2022-06-12 15:30:23.003243
# Unit test for constructor of class ParseError
def test_ParseError():
    msg = Message(text="error 1")
    err = ParseError(messages=[msg])
    assert len(err) == 1
    assert err.messages() == [msg]
    assert err[''] == "error 1"


# Generated at 2022-06-12 15:30:34.096525
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    # Test with a ValidationError that contains only one message, and therefore
    # the message text is used as the exception text
    error = ValidationError(text='The value is invalid')
    assert str(error) == 'The value is invalid'

    # Test with a ParseError that contains multiple error messages.
    # The error messages are returned as a formatted string, where the keys of
    # the error messages are used to create the nested structure.
    error = ParseError(messages=[
        Message(text='Missing key', code='required', key='username'),
        Message(text='Missing key', code='required', key='password'),
    ])

# Generated at 2022-06-12 15:30:41.554359
# Unit test for constructor of class BaseError
def test_BaseError():
    # Instantiated as a ValidationError with a single error message.
    e = BaseError(text="May not have more than 100 characters", code='max_length', key='username')
    assert dict(e) == { "username" : "May not have more than 100 characters" }
    assert e.messages()[0] == Message(text="May not have more than 100 characters", code='max_length', key='username')
    assert len(e) == 1
    
    e = BaseError(messages=[Message(text="May not have more than 100 characters", code='max_length', key='username')])
    assert dict(e) == { "username" : "May not have more than 100 characters" }

# Generated at 2022-06-12 15:30:43.224969
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    error = BaseError(text="hello world")
    assert str(error) == "hello world"



# Generated at 2022-06-12 15:30:52.880692
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1,1,1) == Position(1,1,1)
    assert Position(1,1,1) == Position(1,1,2)
    assert not Position(1,1,1) == Position(1,1,2)
    assert Position(1,1,1) != Position(1,1,2)
    assert Position(1,1,1) != Position(2,1,2)

# Generated at 2022-06-12 15:31:00.302174
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    # positive tests
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert not Position(1, 2, 3) == Position(1, 2, 4)
    assert not Position(1, 2, 3) == Position(1, 3, 3)
    assert not Position(1, 2, 3) == Position(1, 3, 4)
    assert not Position(1, 2, 3) == Position(2, 2, 3)
    # negative tests
    assert not Position(1, 2, 3) == Position(2, 3, 4)
    assert not Position(1, 2, 3) == None
    assert not Position(1, 2, 3) == "abc"


# Generated at 2022-06-12 15:31:03.818009
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(4, 5, 6)


# Generated at 2022-06-12 15:31:06.757346
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    try:
        raise BaseError(text="error message")
    except BaseError as err:
        result = str(err)
        expected = "error message"
        assert result == expected

# Generated at 2022-06-12 15:31:14.348906
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    def test_method_on_instance(self):
        assert(str(obj) == str(obj))
    # Test 1: Test case on instance BaseError - Case where there is one Message and its index is empty
    obj = BaseError(messages = [Message(text="I am just a single message", code="custom")])
    test_method_on_instance(obj)
    # Test 2: Test case on instance BaseError - Case where there is more than one Message
    obj = BaseError(messages = [Message(text="I am a single message", code="custom", key="msg1"), 
                                Message(text="I am a single message", code="custom", key="msg2")])
    test_method_on_instance(obj)


# Generated at 2022-06-12 15:31:19.189629
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    error = BaseError(text="text")
    assert str(error) == "text"

    error = BaseError(messages=[Message(index=[], text="text1")])
    assert str(error) == "text1"

    error = BaseError(messages=[Message(index=["a"], text="text2")])
    assert str(error) == "{'a': 'text2'}"

# Generated at 2022-06-12 15:31:23.086098
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    err = BaseError(
        text="May not have more than 100 characters",
        code="max_length",
        key="username",
    )
    err_str = str(err)
    assert err_str == "May not have more than 100 characters"

# Generated at 2022-06-12 15:31:26.198417
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 1, 1) == Position(1, 1, 1)



# Generated at 2022-06-12 15:31:30.150805
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    data = ValidationError(text='Test error message')
    assert str(data) == 'Test error message'
    data = ValidationError(messages=[Message(text='Test error message')])
    assert str(data) == "{'': 'Test error message'}"

# Generated at 2022-06-12 15:31:33.721548
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(line_no=1, column_no=2, char_index=3) == Position(line_no=1, column_no=2, char_index=3)

# Generated at 2022-06-12 15:31:53.493498
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    position0 = Position(1, 2, 3)
    position1 = Position(1, 2, 3)
    position2 = Position(1, 2, 4)
    position3 = Position(1, 3, 3)
    position4 = Position(2, 2, 3)
    position5 = Position(1, 2, 3, 4)

    assert position0 is not position1
    assert position0 == position0
    assert position0 == position1
    assert position0 != position2
    assert position0 != position3
    assert position0 != position4
    assert position0 != position5


# Generated at 2022-06-12 15:31:59.790371
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 1, 1) == Position(1, 1, 1)
    assert Position(1, 1, 2) != Position(1, 2, 1)
    assert Position(1, 1, 2) != Position(2, 1, 1)
    assert Position(1, 1, 2) != Position(2, 2, 1)
    assert Position(1, 1, 2) != Position(2, 2, 2)
    assert Position(1, 1, 2) != 1



# Generated at 2022-06-12 15:32:04.464053
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    p1 = Position(10, 20, 30)
    p2 = Position(10, 20, 30)
    assert p1 == p2, "Проверка равенства метода __eq__ класса Position"
    
    

# Generated at 2022-06-12 15:32:11.020205
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    # Test with a Position object having different value
    position1 = Position(line_no=2, column_no=2, char_index=1)
    position2 = Position(line_no=2, column_no=3, char_index=1)
    assert not (position1 == position2)

    # Test with a Position object with equal value
    position3 = Position(line_no=4, column_no=4, char_index=4)
    position4 = Position(line_no=4, column_no=4, char_index=4)
    assert position3 == position4

    # Test with a non-Position object
    position5 = Position(line_no=2, column_no=2, char_index=1)
    assert not (position5 == 2)
    assert not (position5 == "text")

#

# Generated at 2022-06-12 15:32:19.647974
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    pos_1 = Position(line_no=1, column_no=1, char_index=1)
    pos_2 = Position(line_no=1, column_no=1, char_index=2)
    pos_3 = Position(line_no=1, column_no=2, char_index=1)
    pos_4 = Position(line_no=2, column_no=1, char_index=1)
    assert pos_1 != pos_2 != pos_3 != pos_4 != pos_1
    assert pos_1 == pos_1 == Position(line_no=1, column_no=1, char_index=1)


# Generated at 2022-06-12 15:32:27.962092
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(line_no=1, column_no=2, char_index=3) == Position(line_no=1, column_no=2, char_index=3)
    assert Position(line_no=1, column_no=2, char_index=3) != Position(line_no=1, column_no=2, char_index=4)
    assert Position(line_no=1, column_no=2, char_index=3) != Position(line_no=1, column_no=3, char_index=3)
    assert Position(line_no=1, column_no=2, char_index=3) != Position(line_no=2, column_no=2, char_index=3)

# Generated at 2022-06-12 15:32:33.564409
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    data = [([1, 2, 3], [1, 2, 3], True), ([1, 2, 3], [2, 1, 3], False)]
    for x, y, expected in data:
        actual = Position.__eq__(x, y)
        assert actual == expected

test_Position___eq__()


# Generated at 2022-06-12 15:32:38.234165
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    # Failed case:
    p1 = Position(100,100,100)
    p2 = Position(201,201,201)
    assert p1 == p2

    # Success case:
    p1 = Position(100,100,100)
    p2 = Position(100,100,100)
    assert p1 == p2

# Generated at 2022-06-12 15:32:41.899034
# Unit test for method __eq__ of class Position
def test_Position___eq__():

    p1=Position(1,1,1)
    p2=Position(1,2,2)
    p3=Position(1,1,1)

    assert p1==p3
    assert p1!=p2


# Generated at 2022-06-12 15:32:49.238138
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(line_no=1, column_no=3, char_index=3) == Position(line_no=1, column_no=3, char_index=3)
    assert Position(line_no=1, column_no=3, char_index=3) != Position(line_no=2, column_no=3, char_index=3)
    assert Position(line_no=1, column_no=3, char_index=3) != Position(line_no=1, column_no=2, char_index=3)
    assert Position(line_no=1, column_no=3, char_index=3) != Position(line_no=1, column_no=3, char_index=2)
    

# Generated at 2022-06-12 15:33:17.410920
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    inst_1 = Position(line_no=1, column_no=2, char_index=3)
    inst_2 = Position(line_no=1, column_no=2, char_index=3)
    inst_3 = Position(line_no=1, column_no=3, char_index=3)
    inst_4 = Position(line_no=2, column_no=2, char_index=3)
    inst_5 = Position(line_no=1, column_no=2, char_index=4)
    assert inst_1 == inst_1
    assert inst_1 == inst_2
    assert inst_2 == inst_1
    assert inst_1 != inst_3
    assert inst_1 != inst_4
    assert inst_1 != inst_5
    inst_6 = inst_3


# Generated at 2022-06-12 15:33:25.484806
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    p1 = Position(line_no=1, column_no=2, char_index=3)
    p2 = Position(line_no=1, column_no=2, char_index=3)
    assert p1 == p2
    p1 = Position(line_no=4, column_no=5, char_index=6)
    assert not (p1 == p2)
    p1 = Position(line_no=1, column_no=5, char_index=6)
    assert not (p1 == p2)
    p1 = Position(line_no=1, column_no=2, char_index=6)
    assert not (p1 == p2)


# Generated at 2022-06-12 15:33:31.483447
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    pos_1 = Position(
        line_no=1, column_no=2, char_index=3
    )
    pos_2 = Position(
        line_no=1, column_no=2, char_index=3
    )
    pos_3 = Position(
        line_no=4, column_no=2, char_index=3
    )
    assert (pos_1 == pos_2)
    assert not (pos_1 == pos_3)
    assert (pos_1 == pos_1)


# Generated at 2022-06-12 15:33:34.910602
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    first = Position(1, 2, 3)
    second = Position(1, 2, 3)
    third = Position(1, 2, 4)

    assert(first == second)
    assert(first != third)
    assert(second != third)


# Generated at 2022-06-12 15:33:37.322867
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    # Tests that __eq__ is reflexive
    # Should be true for all classes
    assert Position(1,1,1) == Position(1,1,1)
    

# Generated at 2022-06-12 15:33:39.297698
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    first = Position(1, 2, 3)
    second = Position(1, 2, 3)
    assert first == second


# Generated at 2022-06-12 15:33:45.502850
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    # Line no and column no
    position_1 = Position(line_no=1, column_no=1, char_index=1)
    position_2 = Position(line_no=1, column_no=1, char_index=1)
    position_3 = Position(line_no=2, column_no=2, char_index=2)
    assert position_1 == position_2
    assert position_1 != position_3

    # Char index
    position_1 = Position(line_no=1, column_no=1, char_index=1)
    position_2 = Position(line_no=1, column_no=1, char_index=1)
    position_3 = Position(line_no=1, column_no=1, char_index=2)
    assert position_1 == position_2


# Generated at 2022-06-12 15:33:54.720390
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    p1 = Position(1, 2, 3)
    p2 = Position(1, 2, 3)
    p3 = Position(1, 2, 3)
    assert p1.__eq__(p2)
    assert p2.__eq__(p1)
    assert p1 == p2
    assert p2 == p1
    assert p1 is p1
    assert p1 is not p2
    assert p1 is not p3
    assert p2 is not p3
    assert p1.__eq__(p1)
    assert p2.__eq__(p2)
    assert p3.__eq__(p3)
    assert p1.__ne__(p2)
    assert p2.__ne__(p1)
    assert p1 != p2
    assert p2 != p1

# Generated at 2022-06-12 15:34:01.032206
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    p1 = Position(line_no=1, column_no=1, char_index=1)
    p2 = Position(line_no=2, column_no=2, char_index=2)
    p1_copied = Position(line_no=1, column_no=1, char_index=1)
    assert p1 == p1_copied
    assert not p1 == p2
    assert not p1 == object()
    assert p1_copied == p1



# Generated at 2022-06-12 15:34:06.124433
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    var_position = Position(line_no=1, column_no=1, char_index=1)
    var_a = var_position
    # Line 5
    assert var_a == var_position
    # Line 6
    var_a = Position(line_no=1, column_no=1, char_index=2)
    # Line 7
    assert not (var_a == var_position)

