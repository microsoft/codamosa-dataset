

# Generated at 2022-06-12 15:28:50.993404
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    messages = [Message(text='a', code='b', key='c'), Message(text='d', code='e', key='f')]
    base_error_1 = BaseError(messages=messages)
    base_error_2 = BaseError(messages=messages)
    assert base_error_1 == base_error_2


# Generated at 2022-06-12 15:28:54.580697
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    message = Message(text='text',  code='code', key='key', position=Position(1, 2, 3))
    assert BaseError(text='text', code='code', key='key', position=Position(1, 2, 3)) == BaseError(messages=[message])


# Generated at 2022-06-12 15:28:56.588268
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    v = ValidationResult(value = 1)
    assert v.value == 1
    assert v.error == None


# Generated at 2022-06-12 15:29:00.774492
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    '''
    Test for __iter__ method of class ValidationResult.
    '''
    args = {k:v for k,v in test_ValidationResult_create_object().items() if k in ['value', 'error']}
    result = ValidationResult(**args)
    iterator = result.__iter__()
    assert isinstance(iterator, typing.Iterator)
    assert next(iterator) == args['value']
    assert next(iterator) == args['error']


# Generated at 2022-06-12 15:29:02.356349
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='Test')
    message2 = Message(text='Test')
    assert message1 == message2

test_Message___eq__()


# Generated at 2022-06-12 15:29:05.060159
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert list(ValidationResult(value=0)) == [0, None]
    assert list(ValidationResult(error=ValidationError())) == [None, ValidationError()]


# Generated at 2022-06-12 15:29:06.250293
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    error = BaseError()
    assert str(error) == error.__repr__()

# Generated at 2022-06-12 15:29:13.896934
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    import pytest
    from typesystem import ValidationResult

    t = ValidationResult(value = 1)
    v_lst = []
    for i in t:
        v_lst.append(i)
    assert v_lst == [1, None]
    t = ValidationResult(error = ValidationError())
    v_lst = []
    for i in t:
        v_lst.append(i)
    assert v_lst == [None, ValidationError()]
    with pytest.raises(AssertionError):
        ValidationResult()

# Generated at 2022-06-12 15:29:20.834273
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    test_case_list = [
        # normal test case
        (ValidationResult(error=ValidationError()), (None, ValidationError())),
        # boundary test case
        (ValidationResult(value=1), (1, None)),
    ]
    for test_case in test_case_list:
        assert test_case[0].__iter__() == test_case[1]


# Generated at 2022-06-12 15:29:31.771075
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    from _test.helpers import assert_equal
    assert_equal(
        iter(ValidationResult(value=1)),
        [1, None]
    )
    assert_equal(
        iter(ValidationResult(value=2)),
        [2, None]
    )
    assert_equal(
        iter(ValidationResult(error=ValidationError(text='error'))),
        [None, ValidationError(text='error')]
    )
    assert_equal(
        iter(ValidationResult(error=ValidationError(text='error2'))),
        [None, ValidationError(text='error2')]
    )


# Generated at 2022-06-12 15:29:45.566789
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    print("Testing method '__eq__' of class 'Message'...")
    message1 = Message(text="May not have more than 100 characters", code="max_length",
        key="username", index=['users', 3, 'username'], position=Position(line_no=5, column_no=3, char_index=50),
        start_position=Position(line_no=5, column_no=3, char_index=50), end_position=Position(line_no=5, column_no=3, char_index=50))

# Generated at 2022-06-12 15:29:49.990659
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    _v = ValidationResult()
    assert list(_v) == [None, None]
    _v = ValidationResult(value=1)
    assert list(_v) == [1, None]
    _v = ValidationResult(error=ValidationError())
    assert list(_v) == [None, ValidationError()]

# Generated at 2022-06-12 15:29:58.420026
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    test_data = [
        [
            (
                BaseError(text="TestError"),
                "BaseError(text='TestError', code='custom')"
            ),
            (
                BaseError(text="TestError", code="max_length"),
                "BaseError(text='TestError', code='max_length')"
            ),
            (
                BaseError(text="TestError", key="TestKey"),
                "BaseError(text='TestError', code='custom')"
            ),
            (
                BaseError(messages=[Message(text="TestError1"), Message(text="TestError2")]),
                "BaseError([Message(text='TestError1', code='custom'), Message(text='TestError2', code='custom')])"
            ),
        ],
    ]

# Generated at 2022-06-12 15:30:00.564795
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    ValidationResult()
    assert True

# Generated at 2022-06-12 15:30:02.670317
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError() == BaseError()
    assert BaseError(text='a') != BaseError(text='a')
    assert BaseError(text='a') != ValidationError(text='a')
    assert ValidationError(text='a') == ValidationError(text='a')


# Generated at 2022-06-12 15:30:11.203217
# Unit test for method __eq__ of class Message

# Generated at 2022-06-12 15:30:16.534497
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    value, error = ValidationResult(value=[1, 2, 3])
    assert value == [1, 2, 3]
    assert error is None
    value, error = ValidationResult(error=ValidationError(text="test"))
    assert value is None
    assert error.text == "test"


# Generated at 2022-06-12 15:30:22.896206
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    obj = Message(text="This is an error message.", code="error_code", index=[1])
    assert obj == obj
    assert obj == Message(text="This is an error message.", code="error_code", index=[1])
    assert obj != None
    assert obj != object()
    assert obj != Message(text="This is a different error message.", code="error_code", index=[1])
    assert obj != Message(text="This is an error message.", code="different_code", index=[1])
    assert obj != Message(text="This is an error message.", code="error_code", index=[2])
    assert obj != Message(text="This is an error message.", code="error_code", index=[1], start_position=(1,1,0))

# Generated at 2022-06-12 15:30:26.162688
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    for _ in ValidationResult():
        pass
    for _ in ValidationResult(value="hello"):
        pass
    for _ in ValidationResult(error="error"):
        pass


# Generated at 2022-06-12 15:30:33.273395
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message = Message(text="test", code="test", key="test", index=["test"], position=Position(line_no=1, column_no=1, char_index=1), start_position=Position(line_no=1, column_no=1, char_index=1), end_position=Position(line_no=1, column_no=1, char_index=1))
    print(message)
    result = message.__eq__(message)
    assert result == True


# Generated at 2022-06-12 15:30:43.800967
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert list(ValidationResult(value="value 1")) == ["value 1", None]
    assert list(ValidationResult(error="error 1")) == [None, "error 1"]



# Generated at 2022-06-12 15:30:53.834169
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    print (ValidationResult.__iter__.__doc__)
    from typesystem.schema import Schema
    from typesystem.fields import Text
    from typesystem.types import String
    class MySchema(Schema):
        text = Text(type=String, max_length=12)
    my_schema = MySchema()
    val_result = my_schema.validate_or_error('123456789012')
    print('val_result:', val_result)
    assert val_result
    assert isinstance(val_result, ValidationResult)
    assert val_result.value == '123456789012'
    assert val_result.error is None
    print((val_result.value, val_result.error))

# Generated at 2022-06-12 15:30:57.759801
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    val = ValidationResult(value=1)
    v, e = iter(val)
    assert v == 1
    assert e is None

    val = ValidationResult(error=ValidationError(text='err'))
    v, e = iter(val)
    assert v is None
    assert e == ValidationError(text='err')


# Generated at 2022-06-12 15:31:01.741131
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    from typesystem import String
    schema = String()
    result = schema.validate_or_error("foo")
    value, error = result
    assert value == "foo"
    assert error is None
    result = schema.validate_or_error("")
    value, error = result
    assert value is None
    assert isinstance(error, ValidationError)
    assert str(error) == "this field may not be blank"


# Generated at 2022-06-12 15:31:07.044379
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    
    from typesystem.schema import String, BadValueError
    
    schema = String()
    
    result = schema.validate_or_error('my_string')
    
    assert result.value == 'my_string'
    assert result.error == None
    
    for it in result:
        v, e = it
        assert v == result.value
        assert e == result.error
        
    with pytest.raises(BadValueError):
        schema.validate_or_error(123)
        
    result = schema.validate_or_error(123)

    assert result.value == None
    assert result.error != None
    
    for it in result:
        v, e = it
        assert v == result.value
        assert e == result.error
        


# Generated at 2022-06-12 15:31:10.323924
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    value = "value"
    error = "error"
    instance = ValidationResult(value=value, error=error)
    next(instance.__iter__()) == value
    next(instance.__iter__()) == error

ValidationResult.__iter__.__test__ = False

# Generated at 2022-06-12 15:31:13.444206
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # Arrange
    # Act
    test = ValidationResult(value=1)
    result = [x for x in test]
    expected = [1, None]
    # Assert
    assert result == expected


# Generated at 2022-06-12 15:31:17.450536
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    value, error = ValidationResult(value="value").__iter__()
    assert value == "value"
    assert error is None
    value, error = ValidationResult(error="error").__iter__()
    assert value is None
    assert error == "error"


# Generated at 2022-06-12 15:31:19.336206
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert iter(ValidationResult(value=1)) == iter((1, None))
    assert iter(ValidationResult(error=ValidationError())) == iter((None, ValidationError()))

# Generated at 2022-06-12 15:31:26.465454
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # units passed
    validation_result = ValidationResult(value = 0)
    actual = list(iter(validation_result))
    expected = [0, None]
    assert actual == expected
    # units passed
    validation_error = ValidationError(text = "error")
    validation_result = ValidationResult(error = validation_error)
    actual = list(iter(validation_result))
    expected = [None, validation_error]
    assert actual == expected
    # units passed
    validation_result = ValidationResult()
    actual = list(iter(validation_result))
    expected = [None, None]
    assert actual == expected


# Generated at 2022-06-12 15:31:37.183840
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert tuple(ValidationError()) == ()
    assert tuple(ValidationResult()) == (None, None)
    assert tuple(ValidationResult(value=1)) == (1, None)
    assert tuple(ValidationResult(error=ValidationError())) == (None, ValidationError())


# Generated at 2022-06-12 15:31:41.328467
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=2)
    vr_it = iter(vr)
    assert tuple(vr_it) == (2, None)

    vr = ValidationResult(error="error")
    vr_it = iter(vr)
    assert tuple(vr_it) == (None, "error")

# Generated at 2022-06-12 15:31:46.362106
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    cases = [
        ValidationResult(),
        ValidationResult(value=None),
        ValidationResult(error=None),
        ValidationResult(value='some data'),
        ValidationResult(error=ValidationError())
    ]
    for c in cases:
        for value, error in c:
            assert c.value is value
            assert c.error is error


# Generated at 2022-06-12 15:31:48.857924
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value = "test")
    assert next(iter(result)) == "test"
    assert list(result) == ["test", None]


# Generated at 2022-06-12 15:31:54.254381
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    not_none = True
    t1 = ValidationResult(value=1)
    val, err = iter(t1)
    assert val == 1
    assert err is None
    val2, err2 = t1
    assert val2 == 1
    assert err2 is None

    t2 = ValidationResult(error="error")
    val, err = iter(t2)
    assert val is None
    assert err == "error"
    val2, err2 = t2
    assert val2 is None
    assert err2 == "error"

# Generated at 2022-06-12 15:31:58.545926
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    v = ValidationResult(value=1)
    a = list(v)
    assert a == [1, None]

    v = ValidationResult(error=ValidationError())
    a = list(v)
    assert a == [None, ValidationError()]


# Generated at 2022-06-12 15:32:05.627541
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=42)
    value, error = result
    assert value == 42
    assert error is None
    assert bool(result) is True
    assert repr(result) == "ValidationResult(value=42)"
    
    result = ValidationResult(error=ValidationError(text="error"))
    value, error = result
    assert value is None
    assert isinstance(error, ValidationError)
    assert bool(result) is False
    assert repr(result) == "ValidationResult(error=ValidationError(text='error'))"



# Generated at 2022-06-12 15:32:07.539901
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result = ValidationResult(value=1) 
    assert tuple(validation_result) == (1, None)


# Generated at 2022-06-12 15:32:09.173118
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    it = iter(ValidationResult())
    assert next(it) is None
    assert next(it) is None


# Generated at 2022-06-12 15:32:11.557238
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=2)
    assert len(list(result)) == 2


# Generated at 2022-06-12 15:32:26.654187
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    a, b = ValidationResult()
    assert a == None
    assert b is None

    a, b = ValidationResult(value=5)
    assert a == 5
    assert b == None

    a, b = ValidationResult(error=ValidationError(text="abc", code="cde"))
    assert a is None
    assert b == ValidationError(text="abc", code="cde")


# Generated at 2022-06-12 15:32:32.548972
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    """
    ValidationResult.__iter__() should return an iterator for unpacking.
    """
    value = 42
    result = ValidationResult(value=value)
    # Test result by unpacking it
    result_value, result_error = result
    assert result_value == value
    assert result_error is None


# Generated at 2022-06-12 15:32:36.422515
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    object_ = ValidationResult(value=None, error=None)
    assert object_.value is None
    assert object_.error is None
    result_1 = tuple(object_)
    assert result_1 == (None, None)


# Generated at 2022-06-12 15:32:39.199704
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert list(ValidationResult(value=1, error=None)) == [1, None]
    assert list(ValidationResult(value=None, error=ValidationError())) == [None, ValidationError()]



# Generated at 2022-06-12 15:32:47.125396
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    collection_type_for_value, collection_type_for_error = ValidationResult()
    assert collection_type_for_value is None
    assert collection_type_for_error is None
    collection_type_for_value, collection_type_for_error = ValidationResult(value=123)
    assert collection_type_for_value == 123
    assert collection_type_for_error is None
    collection_type_for_value, collection_type_for_error = ValidationResult(error=ValidationError())
    assert collection_type_for_value is None
    assert isinstance(collection_type_for_error, ValidationError)

# Generated at 2022-06-12 15:32:48.993041
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert list(ValidationResult(value="a")) == ["a", None]
    assert list(ValidationResult(error="b")) == [None, "b"]


# Generated at 2022-06-12 15:32:53.096921
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    v = ValidationResult(value=42)
    assert list(v) == [42, None]

    v = ValidationResult(error=ValidationError(text="Oops"))
    assert list(v) == [None, ValidationError(text="Oops")]


# Generated at 2022-06-12 15:32:59.062120
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=10)
    assert 10 == result.value
    assert None == result.error
    value, error = result
    assert 10 == value
    assert None == error
    result = ValidationResult(error=ValidationError())
    assert None == result.value
    assert ValidationError() == result.error
    value, error = result
    assert None == value
    assert ValidationError() == error

# Generated at 2022-06-12 15:33:07.365724
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # testing ValidationResult.__iter__()
    # this function assumes that __iter__ of ValidationResult is the same as the function __iter__()
    val = ValidationResult(value=7)
    assert val.__iter__() is val.__iter__()
    # testing ValidationResult.__len__()
    # this function assumes that __len__ of ValidationResult is the same as the function __len__()
    assert len(val) == len(val)
    # testing for the existence of ValueError and TypeError in ValidationResult
    try:
        value, error = val
    except ValueError:
        pass
    except TypeError:
        pass
    # testing ValidationResult.__contains__()
    # this function assumes that __contains__ of ValidationResult is the same as the function __contains__()

# Generated at 2022-06-12 15:33:14.159484
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # First test case, no error
    result = ValidationResult(value=12)
    assert next(iter(result)) == 12
    # Second test case, with error
    result = ValidationResult(error=ValidationError(text="One error happened."))
    assert next(iter(result)) is None
    assert next(iter(result)) == ValidationError(text="One error happened.")
test_ValidationResult___iter__()


# Generated at 2022-06-12 15:33:37.406443
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value='test')
    assert list(result) == [result.value, result.error]

# Generated at 2022-06-12 15:33:40.574465
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result = ValidationResult(value=1)
    for x in validation_result:
        assert x == 1

    validation_result = ValidationResult(error=ValidationError())
    for x in validation_result:
        assert x is None

# Generated at 2022-06-12 15:33:42.162039
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    x = ValidationResult()
    l = list(iter(x))
    assert len(l) == 2



# Generated at 2022-06-12 15:33:47.039987
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():

    # Create a ValidationResult object with value
    result = ValidationResult(value="my string")

    # Get all available field values
    value, error = result

    # Check if the value is as expected
    assert value == "my string"

    # Check if the error is as expected
    assert error is None


# Generated at 2022-06-12 15:33:49.442415
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    value, error = [], None
    result = ValidationResult(value=value, error=error)
    assert list(result) == list((value, error))
    value, error = None, []
    result = ValidationResult(value=value, error=error)
    assert list(result) == list((value, error))


# Generated at 2022-06-12 15:33:54.680420
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    inst1 = ValidationResult()
    expected1 = (None, None)
    assert tuple(inst1) == expected1
    inst2 = ValidationResult(value=1)
    expected2 = (1, None)
    assert tuple(inst2) == expected2
    inst3 = ValidationResult(error=ValidationError())
    expected3 = (None, ValidationError())
    assert tuple(inst3) == expected3



# Generated at 2022-06-12 15:33:56.776914
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert list(ValidationResult(value=2)) == [2, None]
    assert list(ValidationResult(error="Big error")) == [None, "Big error"]

# Generated at 2022-06-12 15:34:02.927996
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    try:
        result = ValidationResult(value=4)
        for elem in result:
            assert elem == 4
    except:
        assert False

    
    try:
        result = ValidationResult(error=ValidationError(messages=[Message(text="Invalid")]))
        for elem in result:
            assert isinstance(elem, ValidationError)
            assert elem.messages()[0].text == "Invalid"
    except:
        assert False

# Generated at 2022-06-12 15:34:05.635037
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # Test pep 8
    self:VAlidationResult=None
    assert isinstance(self.__iter__(),typing.Iterator)
    assert isinstance(iter(self),typing.Iterator)


# Generated at 2022-06-12 15:34:08.141522
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():    
    # Arrange
    a = ValidationResult()

    # Act
    b = a.__iter__()

    #Assert
    assert a.__iter__() == b

